// bannercontroller.js
const pg = require('../General/Model');
const path = require('path');
const fs = require('fs').promises; // use promises API
const fssync = require('fs'); // small sync checks (existsSync)
const BANNERS_DIR = path.resolve(__dirname, 'banners');
const DEFAULT_IMAGE = path.join(BANNERS_DIR, 'default_banner.png');

class BannerDatabase {
  // Create Banner
  static async createBanner(type, imagePath) {
    const query = `
      INSERT INTO banners (type, image)
      VALUES ($1, $2)
      RETURNING *
    `;
    try {
      const result = await pg.query(query, [type, imagePath]);
      return result.rows[0];
    } catch (error) {
      console.error('Error creating banner:', error);
      throw error;
    }
  }

  // Get Banner by Type
  static async getBannerByType(type) {
    const query = `
      SELECT * FROM banners 
      WHERE type = $1 
      ORDER BY created_at DESC 
      LIMIT 1
    `;
    try {
      const result = await pg.query(query, [type]);
      return result.rows[0] || null;
    } catch (error) {
      console.error('Error getting banner by type:', error);
      throw error;
    }
  }

  // Get All Banners
  static async getAllBanners() {
    const query = `
      SELECT * FROM banners 
      ORDER BY created_at DESC
    `;
    try {
      const result = await pg.query(query);
      return result.rows;
    } catch (error) {
      console.error('Error getting all banners:', error);
      throw error;
    }
  }

  // Update Banner
  static async updateBanner(type, newImagePath) {
    try {
      // First, find the existing banner to get the old image path
      const existingBanner = await this.getBannerByType(type);

      if (existingBanner && existingBanner.image) {
        const oldImagePath = path.join(BANNERS_DIR, existingBanner.image);

        // Delete the old image file if it exists
        if (fssync.existsSync(oldImagePath)) {
          try {
            await fs.unlink(oldImagePath);
            console.log(`Deleted old image: ${oldImagePath}`);
          } catch (unlinkErr) {
            console.warn(`Failed deleting old image ${oldImagePath}:`, unlinkErr.message);
          }
        }
      }

      // Update the banner in the database
      const query = `
        UPDATE banners 
        SET image = $2, updated_at = CURRENT_TIMESTAMP
        WHERE type = $1
        RETURNING *
      `;

      const result = await pg.query(query, [type, newImagePath]);
      return result.rows[0] || null;
    } catch (error) {
      console.error('Error updating banner:', error);
      throw error;
    }
  }

  // Returns array of { id, type, filename, binary: Buffer|null }
  static async getAllImagesBinary() {
    const query = `
      SELECT id, type, image 
      FROM banners 
      ORDER BY created_at DESC
    `;
    try {
      const result = await pg.query(query);
      const imageBinaries = [];

      // Ensure banners dir exists (defensive)
      if (!fssync.existsSync(BANNERS_DIR)) {
        console.warn('BANNERS_DIR does not exist:', BANNERS_DIR);
      }

      for (const banner of result.rows) {
        const filename = banner.image || null;
        let buffer = null;

        if (filename) {
          // use resolved path to avoid cwd issues
          const filePath = path.join(BANNERS_DIR, filename);
          console.log('imagePath========================>>>>>>>>', filePath);

          try {
            // check existence before reading
            if (fssync.existsSync(filePath)) {
              buffer = await fs.readFile(filePath);
            } else {
              console.warn(`File missing on disk for banner id=${banner.id}: ${filePath}`);
            }
          } catch (fileErr) {
            console.error(`Error reading image file ${filePath}:`, fileErr.message);
            buffer = null;
          }
        } else {
          console.warn(`No filename stored in DB for banner id=${banner.id}`);
        }

        // If buffer still null, try default image as fallback (if exists)
        if (!buffer && fssync.existsSync(DEFAULT_IMAGE)) {
          try {
            buffer = await fs.readFile(DEFAULT_IMAGE);
            console.log(`Using default image fallback for banner id=${banner.id}`);
          } catch (defErr) {
            console.error('Failed to read default image:', defErr.message);
          }
        }

        imageBinaries.push({
          id: banner.id,
          type: banner.type,
          filename,
          binary: buffer // may be null if neither file nor default exists
        });
      }

      return imageBinaries;
    } catch (error) {
      console.error('Error getting all image binaries:', error);
      throw error;
    }
  }
}

module.exports = BannerDatabase;
