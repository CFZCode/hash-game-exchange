// bannerroutes.js (updated)
const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const BannerDatabase = require('./bannercontroller');

const router = express.Router();

const BANNERS_DIR = path.resolve(__dirname, 'banners');
const DEFAULT_IMAGE = path.join(BANNERS_DIR, 'default_banner.png');

// Ensure banners directory exists at startup
if (!fs.existsSync(BANNERS_DIR)) {
  fs.mkdirSync(BANNERS_DIR, { recursive: true });
  console.log('Created banners directory:', BANNERS_DIR);
}

// Multer storage config (keeps extension, unique filename)
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, BANNERS_DIR);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const name = `${file.fieldname}-${Date.now()}-${Math.round(Math.random() * 1e9)}${ext}`;
    cb(null, name);
  }
});

const upload = multer({
  storage,
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (!['.png', '.jpg', '.jpeg'].includes(ext)) {
      return cb(new Error('Only images are allowed (.png, .jpg, .jpeg)'));
    }
    cb(null, true);
  }
});

router.post('/createBanner', upload.single('image'), async (req, res) => {
  console.log('File:', req.file);
  console.log('Body:', req.body);

  try {
    if (!req.file) {
      return res.status(400).json({ status: 'error', message: 'No image uploaded' });
    }

    if (!req.body.type) {
      return res.status(400).json({ status: 'error', message: 'Type parameter is required' });
    }

    const banner = await BannerDatabase.createBanner(req.body.type, req.file.filename);

    console.log('Banner created:', banner);

    res.status(201).json({ status: 'success', data: { banner } });
  } catch (error) {
    console.error('Error creating banner:', error);
    res.status(500).json({ status: 'error', message: error.message });
  }
});

router.get('/banner/:type', async (req, res) => {
  try {
    const banner = await BannerDatabase.getBannerByType(req.params.type);
    if (!banner) return res.status(404).json({ status: 'error', message: 'Banner not found' });
    res.status(200).json({ status: 'success', banner });
  } catch (error) {
    res.status(500).json({ status: 'error', message: error.message });
  }
});

router.get('/getBannerAll', async (req, res) => {
  try {
    const banners = await BannerDatabase.getAllBanners();
    res.status(200).json({ status: 'success', banners });
  } catch (error) {
    res.status(500).json({ status: 'error', message: error.message });
  }
});

router.post('/updateBanner', upload.single('image'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ status: 'error', message: 'No image uploaded' });

    const banner = await BannerDatabase.updateBanner(req.body.type, req.file.filename);
    if (!banner) return res.status(404).json({ status: 'error', message: 'Banner not found' });

    res.status(200).json({ status: 'success', data: { banner } });
  } catch (error) {
    res.status(500).json({ status: 'error', message: error.message });
  }
});

// Serve a single image safely by filename
router.get('/image/:filename', (req, res) => {
  // sanitize filename: allow only safe characters
  const filename = path.basename(req.params.filename); // prevents ../ attacks
  const imagePath = path.join(BANNERS_DIR, filename);

  // If file doesn't exist, send default image (if available) or 404
  const fileToSend = fs.existsSync(imagePath) ? imagePath : (fs.existsSync(DEFAULT_IMAGE) ? DEFAULT_IMAGE : null);

  if (!fileToSend) {
    return res.status(404).json({ status: 'error', message: 'Image not found' });
  }

  res.sendFile(fileToSend, (err) => {
    if (err) {
      console.error('sendFile error:', err);
      // fallback to default if not already sending it
      if (fileToSend !== DEFAULT_IMAGE && fs.existsSync(DEFAULT_IMAGE)) {
        return res.sendFile(DEFAULT_IMAGE);
      }
      return res.status(500).json({ status: 'error', message: 'Error sending image' });
    }
  });
});

// Get all images as base64 (safe reading)
router.get('/getAllImagesBinary', async (req, res) => {
  try {
    const rows = await BannerDatabase.getAllImagesBinary(); // expects rows { id, type, filename }
    const images = rows.map(row => {
      const filename = row.filename || '';
      const fullPath = path.join(BANNERS_DIR, filename);
      let binary;
      if (filename && fs.existsSync(fullPath)) {
        try {
          binary = fs.readFileSync(fullPath);
        } catch (e) {
          console.warn(`Failed reading ${fullPath}:`, e.message);
          binary = fs.existsSync(DEFAULT_IMAGE) ? fs.readFileSync(DEFAULT_IMAGE) : null;
        }
      } else {
        binary = fs.existsSync(DEFAULT_IMAGE) ? fs.readFileSync(DEFAULT_IMAGE) : null;
      }

      return {
        id: row.id,
        type: row.type,
        filename,
        base64: binary ? binary.toString('base64') : null
      };
    });

    res.status(200).json({ status: 'success', count: images.length, images });
  } catch (error) {
    console.error('getAllImagesBinary error:', error);
    res.status(500).json({ status: 'error', message: error.message });
  }
});

module.exports = router;
