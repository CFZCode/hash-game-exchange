// email.service.js
const nodemailer = require('nodemailer');
const pg = require('../General/Model');
const EmailTemplateService = require('./templet');

// Legacy SMTP — used as a fallback only when the admin has NOT configured a
// Gmail address + app password in siteconfig. Kept so OTP / general emails keep
// working out of the box; the deposit/withdrawal notification flow is meant to
// use the admin-configured Gmail credentials (see _getTransporter below).
const LEGACY_SMTP = {
    host: 'mx3594.syd1.mymailhosting.com',
    port: 465,
    secure: true,
    auth: { user: 'service@example.com', pass: 'REMOVED_SECRET' },
};

class EmailService {
    constructor() {
        // Cached transporter — rebuilt whenever the credentials in siteconfig
        // change, so admin updates take effect WITHOUT a server restart.
        this._transporter = null;
        this._cachedKey = null;        // identifies which creds the cache was built with
        this._legacyTransporter = null;
    }

    // Reads Gmail SMTP credentials from siteconfig, falling back to .env. The
    // admin sets these in admin-management → My Account (PUT /email/settings).
    async _getCredentials() {
        try {
            const { rows } = await pg.query(
                'SELECT gmailuser, gmailapppassword FROM siteconfig LIMIT 1'
            );
            const user = rows[0]?.gmailuser || process.env.GMAIL_USER || null;
            const pass = rows[0]?.gmailapppassword || process.env.GMAIL_APP_PASSWORD || null;
            return { user, pass };
        } catch (err) {
            console.error('Failed to read Gmail credentials from siteconfig:', err.message);
            return { user: process.env.GMAIL_USER || null, pass: process.env.GMAIL_APP_PASSWORD || null };
        }
    }

    _getLegacyTransporter() {
        if (!this._legacyTransporter) {
            this._legacyTransporter = nodemailer.createTransport(LEGACY_SMTP);
        }
        return { transporter: this._legacyTransporter, fromAddress: LEGACY_SMTP.auth.user };
    }

    // Returns a nodemailer transporter. Prefers the admin-configured Gmail
    // credentials; falls back to the legacy SMTP account when none are set so
    // the platform never silently stops sending email.
    async _getTransporter() {
        const { user, pass } = await this._getCredentials();
        if (!user || !pass) {
            return this._getLegacyTransporter();
        }
        const key = `${user}:${pass}`;
        if (!this._transporter || this._cachedKey !== key) {
            this._transporter = nodemailer.createTransport({
                host: 'smtp.gmail.com',
                port: 465,
                secure: true,
                auth: { user, pass },
            });
            this._cachedKey = key;
        }
        return { transporter: this._transporter, fromAddress: user };
    }

    async sendOTPEmail(email, otp, purpose) {
        try {
            console.log(`Sending OTP email to ${email} for ${purpose}...`);

            const templates = {
                register: {
                    title: 'Complete Your Registration',
                    message: 'Use this code to complete your registration:'
                },
                login: {
                    title: 'Login Verification',
                    message: 'Use this code to verify your login:'
                },
                'reset-password': {
                    title: 'Reset Your Password',
                    message: 'Use this code to reset your password:'
                },
                'reset-2fa': {
                    title: 'Reset Your 2FA',
                    message: 'Use this code to reset your two-factor authentication:'
                }
            };

            const template = templates[purpose];

            const { transporter, fromAddress } = await this._getTransporter();
            const info = await transporter.sendMail({
                from: fromAddress,
                to: email,
                subject: template.title,
                html: EmailTemplateService.getTemplate('otp', {
                    title: template.title,
                    message: template.message,
                    otp
                })
            });

            console.log(`OTP email sent successfully to ${email}. Message ID: ${info.messageId}`);
            return info;
        } catch (error) {
            console.error(`Failed to send OTP email to ${email}:`, error);
            return null;
        }
    }

    async sendGeneralEmail(to, subject, data) {
        try {
            console.log(`Sending general email to ${to} with subject: ${subject}...`);

            const { transporter, fromAddress } = await this._getTransporter();
            const info = await transporter.sendMail({
                from: fromAddress,
                to,
                subject,
                html: EmailTemplateService.getTemplate('general', data)
            });

            console.log(`General email sent successfully to ${to}. Message ID: ${info.messageId}`);
            return info;
        } catch (error) {
            console.error(`Failed to send general email to ${to}:`, error);
            return null;
        }
    }

    async sendBulkEmails(emails, subject, data) {
        console.log(`Sending bulk emails to ${emails.length} recipients...`);

        const promises = emails.map(email =>
            this.sendGeneralEmail(email, subject, data)
        );

        const results = await Promise.allSettled(promises);

        results.forEach((result, index) => {
            if (result.status === 'fulfilled') {
                console.log(`Email sent successfully to ${emails[index]}`);
            } else {
                console.error(`Failed to send email to ${emails[index]}:`, result.reason);
            }
        });

        return results;
    }
}

module.exports = new EmailService();
