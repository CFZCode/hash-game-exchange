// routes.js
const express = require('express');
const router = express.Router();
const OTPService = require('./otpcontroller');
const EmailService = require('./controller');
const db = require('../General/Model');
const { protectStaff } = require('../system/middleware/auth');

// SuperAdmin guard — notification email + Gmail app-password are sensitive, so
// only the owner (role level 0) can read or change them.
const onlySuperAdmin = (req, res, next) => {
    if (!req.staff || req.staff.level !== 0) {
        return res.status(403).json({ success: false, error: 'SuperAdmin only' });
    }
    next();
};

/* ──────────────────────────────────────────────────────────────
   Email notification settings (admin-management → My Account)
   Stored in the single siteconfig row:
     • gmailuser            — Gmail address used to SEND mail (SMTP login)
     • gmailapppassword     — Gmail App Password (never returned to the client)
     • apaynotificationemail— inbox that RECEIVES deposit/withdrawal alerts
   ────────────────────────────────────────────────────────────── */

// GET current settings — the app password is never sent back, only whether one
// is configured (hasAppPassword).
router.get('/settings', protectStaff, onlySuperAdmin, async (req, res) => {
    try {
        const { rows } = await db.query(
            'SELECT gmailuser, gmailapppassword, apaynotificationemail FROM siteconfig LIMIT 1'
        );
        const row = rows[0] || {};
        res.json({
            success: true,
            gmailuser: row.gmailuser || '',
            apaynotificationemail: row.apaynotificationemail || '',
            hasAppPassword: !!row.gmailapppassword,
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// PUT update settings. gmailapppassword is only written when a non-empty value
// is supplied, so saving the form without re-typing the password keeps it.
router.put('/settings', protectStaff, onlySuperAdmin, async (req, res) => {
    try {
        const { gmailuser, gmailapppassword, apaynotificationemail } = req.body || {};
        const sets = [];
        const vals = [];
        let i = 1;
        if (gmailuser !== undefined) { sets.push(`gmailuser=$${i++}`); vals.push(String(gmailuser).trim() || null); }
        if (apaynotificationemail !== undefined) { sets.push(`apaynotificationemail=$${i++}`); vals.push(String(apaynotificationemail).trim() || null); }
        if (gmailapppassword) { sets.push(`gmailapppassword=$${i++}`); vals.push(String(gmailapppassword).trim()); }
        if (!sets.length) return res.status(400).json({ success: false, error: 'Nothing to update' });
        await db.query(`UPDATE siteconfig SET ${sets.join(', ')}, updatedat=now()`, vals);
        res.json({ success: true, message: 'Email settings saved' });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// POST send a test email to the configured notification inbox so the admin can
// confirm the SMTP credentials work after a domain/credential change.
router.post('/settings/test', protectStaff, onlySuperAdmin, async (req, res) => {
    try {
        const { rows } = await db.query('SELECT apaynotificationemail FROM siteconfig LIMIT 1');
        const to = rows[0]?.apaynotificationemail;
        if (!to) return res.status(400).json({ success: false, error: 'Set a notification email first' });
        const info = await EmailService.sendGeneralEmail(to, 'Test — Notification email is working', {
            title: 'Notification email is working',
            content: `<p>This is a test from your admin panel. Deposit & withdrawal notifications will arrive at <b>${to}</b>.</p>`,
        });
        if (!info) return res.status(500).json({ success: false, error: 'Send failed — check Gmail address / app password' });
        res.json({ success: true, message: `Test email sent to ${to}` });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// OTP Routes
router.post('/otp/send', async (req, res) => {
    try {
        const { email, purpose } = req.body;
        
        if (!['register', 'login', 'reset-password'].includes(purpose)) {
            throw new Error('Invalid OTP purpose');
        }

        const otp = await OTPService.generateAndSaveOTP(email, purpose);
        await EmailService.sendOTPEmail(email, otp, purpose);

        res.json({
            success: true,
            message: 'OTP sent successfully'
        });
    } catch (error) {
        res.status(200).json({
            success: false,
            error: error.message
        });
    }
});

router.post('/otp/resend', async (req, res) => {
    try {
        const { email, purpose } = req.body;

        // Check if we can resend OTP (2-minute cooldown)
        const canResend = await OTPService.canResendOTP(email, purpose);
        if (!canResend) {
            throw new Error('Please wait 2 minutes before requesting a new OTP');
        }

        const otp = await OTPService.generateAndSaveOTP(email, purpose);
        await EmailService.sendOTPEmail(email, otp, purpose);

        res.json({
            success: true,
            message: 'New OTP sent successfully'
        });
    } catch (error) {
        res.status(200).json({
            success: false,
            error: error.message
        });
    }
});

router.post('/otp/verify', async (req, res) => {
    try {
        const { email, otp, purpose } = req.body;
        await OTPService.verifyOTP(email, otp, purpose);
        res.json({
            success: true,
            message: 'OTP verified successfully'
        });
    } catch (error) {
        res.status(200).json({
            success: false,
            error: error.message
        });
    }
});

// General Email Routes
router.post('/email/send', async (req, res) => {
    try {
        const { to, subject, title, content, ctaLink, ctaText } = req.body;
        await EmailService.sendGeneralEmail(to, subject, {
            title,
            content,
            ctaLink,
            ctaText
        });
        res.json({
            success: true,
            message: 'Email sent successfully'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

router.post('/email/bulk', async (req, res) => {
    try {
        const { emails, subject, title, content, ctaLink, ctaText } = req.body;
        const results = await EmailService.sendBulkEmails(
            emails,
            subject,
            {
                title,
                content,
                ctaLink,
                ctaText
            }
        );
        res.json({
            success: true,
            data: results
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});


// 2FA Reset Routes
router.post('/2fa/reset', async (req, res) => {
    try {
        const { identifier } = req.body;

        if (!identifier) {
            throw new Error('Email or username is required');
        }

        // Find user by email or name
        const userResult = await db.query(
            'SELECT id, email FROM users WHERE email = $1 OR name = $1',
            [identifier]
        );

        if (!userResult.rows.length) {
            throw new Error('User not found');
        }

        const { id: uid, email } = userResult.rows[0];

        // Check if 2FA is enabled
        const twoFAResult = await db.query(
            'SELECT is_enabled FROM user_2fa WHERE uid = $1',
            [uid]
        );

        if (!twoFAResult.rows.length || !twoFAResult.rows[0].is_enabled) {
            throw new Error('2FA is not enabled');
        }

        // Generate and send OTP
        const otp = await OTPService.generateAndSaveOTP(email, 'reset-2fa');
        await EmailService.sendOTPEmail(email, otp, 'reset-2fa');

        res.json({
            success: true,
            message: 'OTP sent successfully for 2FA reset'
        });
    } catch (error) {
        res.status(200).json({
            success: false,
            error: error.message
        });
    }
});

router.post('/2fa/reset-verify', async (req, res) => {
    try {
        const { identifier, otp } = req.body;

        if (!identifier || !otp) {
            throw new Error('Email or username and OTP are required');
        }

        // Find user by email or name
        const userResult = await db.query(
            'SELECT id, email FROM users WHERE email = $1 OR name = $1',
            [identifier]
        );

        if (!userResult.rows.length) {
            throw new Error('User not found');
        }

        const { id: uid, email } = userResult.rows[0];

        // Verify OTP
        await OTPService.verifyOTP(email, otp, 'reset-2fa');

        // Disable 2FA
        await db.query(
            'UPDATE user_2fa SET is_enabled = false, secret_key = null WHERE uid = $1',
            [uid]
        );

        res.json({
            success: true,
            message: '2FA has been reset successfully'
        });
    } catch (error) {
        res.status(200).json({
            success: false,
            error: error.message
        });
    }
});
module.exports = router;