const axios = require('axios');

// local cache for conversion rates
let conversionRates = {};

// fallback rates (optional, approximate)
const FALLBACK_RATES = {
  USDT: 1,
  BTC: 60000,
  ETH: 2500,
  INR: 0.012,
  BDT: 0.009
};

// Fetch rates from API with timeout & retry logic
const updateConversionRates = async () => {
  const url = 'https://example.com/rate';

  try {
    console.log('[ConversionRates] Fetching latest rates...');
    const response = await axios.get(url, { timeout: 5000 });
    if (response.data && typeof response.data === 'object') {
      conversionRates = response.data;
      console.log('[ConversionRates] Updated successfully:', Object.keys(conversionRates));
    } else {
      throw new Error('Invalid response format');
    }
  } catch (error) {
    console.error('[ConversionRates] Failed to fetch rates:', error.message);

    // fallback if conversionRates is empty
    if (Object.keys(conversionRates).length === 0) {
      console.warn('[ConversionRates] Using fallback rates');
      conversionRates = FALLBACK_RATES;
    }
  }
};

// Core conversion function
const convertToUSDT = async (amount, coin) => {
  const symbol = coin?.toUpperCase?.() || '';

  if (symbol === 'USDT') return amount;

  // ensure rates exist
  if (!conversionRates[symbol]) {
    console.warn(`[ConversionRates] Rate missing for ${symbol}, using fallback.`);
    const rate = FALLBACK_RATES[symbol];
    return rate ? amount * rate : amount; // return same amount if unknown
  }

  const rate = conversionRates[symbol];
  const result = amount * rate;
  return Number(result.toFixed(6)); // normalize
};

// Initialize and schedule updates
// (async () => {
//   await updateConversionRates();
//   setInterval(updateConversionRates, 3600000); // every hour
// })();

module.exports = { convertToUSDT };
