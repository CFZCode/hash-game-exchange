const pg = require('../General/Model');// Adjust path as needed to your database connection
const { recordActivity } = require('../system/utils/recordActivity');
const { assertWithdrawalAllowed } = require('../system/utils/withdrawalLocks');

// Actor id from the x-staff-id header (this admin route predates JWT auth).
const headerStaffId = (req) => {
  const v = req.headers && (req.headers['x-staff-id'] || req.headers['x_staff_id']);
  const n = Number(v);
  return Number.isFinite(n) && n > 0 ? n : null;
};
// Normalise a free-form withdrawal status into a clean action key.
const withdrawAction = (status) => {
  const s = String(status || '').toLowerCase();
  if (s === 'rejected' || s === 'failed' || s === 'declined') return 'withdraw.rejected';
  if (['done', 'approved', 'success', 'completed', 'paid'].includes(s)) return 'withdraw.approved';
  return null; // intermediate status — not an approval/rejection, skip alert/log
};

// Get all fiat withdrawal data
const getTreeIdsSql = `
WITH RECURSIVE tree AS (
  SELECT id FROM staff WHERE id = $1
  UNION ALL
  SELECT s.id
  FROM staff s
  JOIN tree t ON s.parent_id = t.id
)
SELECT array_agg(id) AS ids FROM tree
`;
async function visibleIds(staffId) {
  const { rows:[{ ids }] } = await pg.query(getTreeIdsSql, [staffId]);
  return ids;                   // => e.g. [1,4,9,12]
}
// exports.getFiatWithdrawData = async (req, res) => {
//   try {
//     // get staffId from header (same as in crypto stats route)
//     let ids = await visibleIds(req.headers['x-staff-id']);
//     ids = ids.map(x => Number(x));

//     // base query
//     let query = `
//       SELECT 
//         fw.*, 
//         u.name 
//       FROM fiat_withdrawals fw
//       LEFT JOIN users u ON fw.uid = u.id
//       WHERE 1=1
//     `;

//     // staff visibility filter
//     if (ids.includes(1)) {
//       // super admin can see all, including users without parent staff
//       query += ` AND (u.parent_staff_id = ANY($1::bigint[]) OR u.parent_staff_id IS NULL)`;
//     } else {
//       // normal staff restricted to their ids
//       query += ` AND u.parent_staff_id = ANY($1::bigint[])`;
//     }

//     // order by latest
//     query += ` ORDER BY fw.date DESC`;

//     // run query
//     const result = await pg.query(query, [ids]);

//     res.json({
//       success: true,
//       data: result.rows
//     });
//   } catch (error) {
//     console.error('Error fetching fiat withdrawal data:', error);
//     res.status(500).json({
//       success: false,
//       error: 'Failed to fetch fiat withdrawal data'
//     });
//   }
// };


// Create a new fiat withdrawal request
// exports.createFiatWithdrawal = async (req, res) => {
//   const { 
//     uid, 
//     amount, 
//     currency, 
//     bank_name, 
//     account_number, 
//     account_holder_name, 
//     ifsc_code, 
//     upi_id 
//   } = req.body;

//   // Validation
//   if (!uid || !amount || !currency || !account_holder_name) {
//     return res.status(400).json({ error: 'Missing required fields' });
//   }

//   if (currency === 'INR' && !ifsc_code && !upi_id) {
//     return res.status(400).json({ error: 'For INR withdrawals, either IFSC code or UPI ID is required' });
//   }

//   if (currency !== 'INR' && (!bank_name || !account_number || !ifsc_code)) {
//     return res.status(400).json({ error: 'Bank details are required for non-INR withdrawals' });
//   }

//   try {
//     const query = `
//       INSERT INTO fiat_withdrawals 
//         (uid, amount, currency, bank_name, account_number, account_holder_name, ifsc_code, upi_id, status)
//       VALUES 
//         ($1, $2, $3, $4, $5, $6, $7, $8, 'In Queue')
//       RETURNING *
//     `;
    
//     const values = [
//       uid, 
//       amount, 
//       currency, 
//       bank_name || null, 
//       account_number || null, 
//       account_holder_name, 
//       ifsc_code || null, 
//       upi_id || null
//     ];
    
//     const result = await pg.query(query, values);
//     res.status(201).json(result.rows[0]);
//   } catch (error) {
//     console.error('Error creating fiat withdrawal:', error);
//     res.status(500).json({ error: 'Failed to create fiat withdrawal request' });
//   }
// };

exports.getFiatWithdrawData = async (req, res) => {
  try {
    const fiatQuery = `
      SELECT fw.*, u.name
      FROM fiat_withdrawals fw
      LEFT JOIN users u ON fw.uid = u.id
      ORDER BY fw.date DESC
    `;

    // A-Pay (auto payout) withdrawals — user_id holds custom_user_id (= users.id).
    const apayQuery = `
      SELECT aw.*, u.name
      FROM apaywithdrawals aw
      LEFT JOIN users u ON u.id::text = aw.user_id
      ORDER BY aw.created_at DESC
    `;

    // F2Pay (direct payout) withdrawals — user_id is the numeric users.id.
    const f2payQuery = `
      SELECT fw.*, u.name
      FROM f2paywithdrawals fw
      LEFT JOIN users u ON u.id = fw.user_id
      ORDER BY fw.created_at DESC
    `;

    const [fiatResult, apayResult, f2payResult] = await Promise.all([
      pg.query(fiatQuery),
      pg.query(apayQuery),
      pg.query(f2payQuery)
    ]);

    // Map A-Pay rows into the fiat_withdrawals shape so they show in the same
    // admin table. Account fields come from payout_details (varies per PS).
    const apayRows = apayResult.rows.map(row => {
      let d = row.payout_details || {};
      if (typeof d === 'string') { try { d = JSON.parse(d); } catch { d = {}; } }
      return {
        id: row.order_id,
        uid: row.user_id,
        amount: row.amount,
        currency: row.currency,
        bank_name: d.bank_name || row.payment_system || null,
        account_number: d.account_number || null,
        account_holder_name: d.account_name || null,
        ifsc_code: d.bank_code || null,
        upi_id: d.upi_id || null,
        status: row.status,
        date: row.created_at,
        name: row.name || null,
        // extra A-Pay context for the admin panel
        source: 'apay',
        payment_system: row.payment_system,
        order_id: row.order_id,
        error_reason: row.error_reason,
        refunded: row.refunded
      };
    });

    // Map F2Pay rows into the same shape (fields live directly on the row).
    const f2payRows = f2payResult.rows.map(row => ({
      id: row.mch_order_no,
      uid: row.user_id,
      amount: row.amount,
      currency: row.currency,
      bank_name: 'Bank Transfer (F2Pay)',
      account_number: row.account_number,
      account_holder_name: row.account_holder_name,
      ifsc_code: row.ifsc,
      upi_id: null,
      status: row.status,
      date: row.created_at,
      name: row.name || null,
      // extra context for the admin panel
      source: 'f2pay',
      payment_system: 'BANK_INR',
      order_id: row.mch_order_no,
      error_reason: row.error_reason,
      refunded: row.refunded
    }));

    const combined = [
      ...fiatResult.rows.map(r => ({ ...r, source: 'fiat' })),
      ...apayRows,
      ...f2payRows
    ].sort((a, b) => new Date(b.date) - new Date(a.date));

    res.json(combined);
  } catch (error) {
    console.error('Error fetching fiat withdrawal data:', error);
    res.status(500).json({ error: 'Failed to fetch fiat withdrawal data' });
  }
};
exports.createFiatWithdrawal = async (req, res) => {
  const { 
    uid, 
    amount, 
    currency, 
    bank_name, 
    account_number, 
    account_holder_name, 
    ifsc_code, 
    upi_id 
  } = req.body;

  // Validation
  if (!uid || !amount || !currency || !account_holder_name) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  if (currency === 'INR' && !ifsc_code && !upi_id) {
    return res.status(400).json({ error: 'For INR withdrawals, either IFSC code or UPI ID is required' });
  }

  if (currency !== 'INR' && (!bank_name || !account_number || !ifsc_code)) {
    return res.status(400).json({ error: 'Bank details are required for non-INR withdrawals' });
  }

  try {
    await assertWithdrawalAllowed(uid, { amount, currency });
  } catch (e) {
    return res.status(403).json({ error: e.message, message: e.message, code: e.code });
  }

  try {
    // Start a transaction
    await pg.query('BEGIN');
    
    // Check if user has sufficient balance
    const currencyLower = currency.toLowerCase();
    const balanceQuery = `SELECT ${currencyLower} FROM credits WHERE uid = $1`;
    const balanceResult = await pg.query(balanceQuery, [uid]);
    
    if (balanceResult.rows.length === 0) {
      await pg.query('ROLLBACK');
      return res.status(404).json({ error: 'User not found' });
    }
    
    const currentBalance = parseFloat(balanceResult.rows[0][currencyLower] || 0);
    
    if (currentBalance < amount) {
      await pg.query('ROLLBACK');
      return res.status(400).json({ error: 'Insufficient balance' });
    }
    
    // Deduct amount from user's credits
    const updateQuery = `
      UPDATE credits 
      SET ${currencyLower} = ${currencyLower} - $1 
      WHERE uid = $2
      RETURNING ${currencyLower} as new_balance
    `;
    
    const updateResult = await pg.query(updateQuery, [amount, uid]);
    
    // Create withdrawal record
    const withdrawalQuery = `
      INSERT INTO fiat_withdrawals 
        (uid, amount, currency, bank_name, account_number, account_holder_name, ifsc_code, upi_id, status)
      VALUES 
        ($1, $2, $3, $4, $5, $6, $7, $8, 'In Queue')
      RETURNING *
    `;
    
    const values = [
      uid, 
      amount, 
      currency, 
      bank_name || null, 
      account_number || null, 
      account_holder_name, 
      ifsc_code || null, 
      upi_id || null
    ];
    
    const withdrawalResult = await pg.query(withdrawalQuery, values);
    
    // Commit the transaction
    await pg.query('COMMIT');
    
    // Return both the withdrawal request and the new balance
    res.status(201).json({
      withdrawal: withdrawalResult.rows[0],
      new_balance: updateResult.rows[0].new_balance
    });
    
  } catch (error) {
    // Rollback in case of any error
    await pg.query('ROLLBACK');
    console.error('Error processing fiat withdrawal:', error);
    res.status(500).json({ error: 'Failed to process fiat withdrawal request' });
  }
};
// Update fiat withdrawal status
exports.updateFiatWithdrawStatus = async (req, res) => {
  const { id, status } = req.body;
  if (!id || !status) {
    return res.status(400).json({ error: 'Missing required fields' });
  }
  try {
    await pg.query('BEGIN');

    // Lock and read the current withdrawal so we can refund safely / once
    const existing = await pg.query(
      'SELECT uid, amount, currency, status FROM fiat_withdrawals WHERE id = $1 FOR UPDATE',
      [id]
    );

    if (existing.rows.length === 0) {
      await pg.query('ROLLBACK');
      return res.status(404).json({ error: 'Fiat withdrawal not found' });
    }

    const wd = existing.rows[0];
    const prevStatus = (wd.status || '').toLowerCase();
    const isRejecting = String(status).toLowerCase() === 'rejected';

    // The amount was deducted from the user's balance at request time.
    // On rejection, return it — but only once (guard against repeated rejects).
    if (isRejecting && prevStatus !== 'rejected') {
      const currencyLower = (wd.currency || 'INR').toLowerCase();
      await pg.query(
        `UPDATE credits SET ${currencyLower} = COALESCE(${currencyLower}, 0) + $1 WHERE uid = $2`,
        [wd.amount, wd.uid]
      );
    }

    const result = await pg.query(
      'UPDATE fiat_withdrawals SET status = $1 WHERE id = $2 RETURNING *',
      [status, id]
    );

    await pg.query('COMMIT');

    const action = withdrawAction(status);
    if (action) {
      recordActivity({
        req, action,
        targetType: 'USER', targetId: wd.uid,
        details: { withdrawalId: id, amount: wd.amount, currency: wd.currency, status },
        actor: { staffId: headerStaffId(req) },
      });
    }

    res.json(result.rows[0]);
  } catch (error) {
    await pg.query('ROLLBACK');
    console.error('Error updating fiat withdrawal status:', error);
    res.status(500).json({ error: 'Failed to update fiat withdrawal status' });
  }
};