const express = require('express');
const router = express.Router();
const fiatWithdrawController = require('./controller'); // Adjust path as needed

// Admin routes
router.get('/getFiatWithdrawData', fiatWithdrawController.getFiatWithdrawData);
// router.post('/updateFiatWithdrawStatus', fiatWithdrawController.updateFiatWithdrawStatus);

// User routes
router.post('/createFiatWithdrawal', fiatWithdrawController.createFiatWithdrawal);

module.exports = router;