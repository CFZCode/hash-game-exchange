const axios = require('axios');
const config = require('../config');

// Declare Notify object
const Notify = {};

// Send notification
Notify.send = function (data) {
	return
};

// Export the Notify module
module.exports = Notify;