'use strict';

var authenticator = require('authenticator');


/**
 * Generate a random base-32 secret
 */
function randomBase32(length) {
    var base32chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    length = length % 2 === 0 ? length : length + 1; // ensuring even length
    var secret = [];
    for (var i = 0; i < length; i++) {
        secret.push(base32chars.split('')[Math.floor(Math.random() * 32)]);
    }
    return secret.join('');
}

const TwoFa = {}

TwoFa.generateCode = function (user) {
    var secret = authenticator.generateKey();
    var domain = 'example.com';
    var size = '300x300';
    var url =
        'https://chart.googleapis.com/chart?chs=' +
        size +
        '&chld=M|0&cht=qr&chl=otpauth://totp/' +
        user +
        '@' +
        domain +
        '%3Fsecret%3D' +
        secret;

    return {
        code: secret,
        url: url
    }
}

TwoFa.verifyToken = function (code, secret) {

    // Create a new TOTP object.
    // let totp = new OTPAuth.TOTP({
    //     issuer: 'BGame',
    //     label: 'example.com',
    //     algorithm: 'SHA1',
    //     digits: 6,
    //     period: 30,
    //     secret: OTPAuth.Secret.fromBase32(secret)
    // });

    // // Generate a token.
    // let token = totp.generate();

    // console.log(code)
    // console.log(token)
    // console.log(secret)

    var formattedToken = authenticator.generateToken(secret);

    console.log(formattedToken)

    if (parseFloat(formattedToken) === parseFloat(code))
        return true
    else
        return false
}

module.exports = TwoFa