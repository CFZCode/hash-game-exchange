-- Creates bonus_history. Schema derived from queries in
--   bonus/bonusCron.js, bonus/bonusengine.js,
--   bonus/userBonusRoutes.js, bonus/adminBonusRoutes.js
-- Apply with:
--   psql -h 127.0.0.1 -U myapp1 -d myapp1 -f bonus/bonus_history.sql

CREATE TABLE IF NOT EXISTS bonus_history (
    id              BIGSERIAL    PRIMARY KEY,
    userid          BIGINT       NOT NULL,
    bonus_type      TEXT         NOT NULL,                 -- daily / weekly / monthly
    bonus_amount    NUMERIC(20,8) NOT NULL DEFAULT 0,
    wager_change    NUMERIC(20,8) NOT NULL DEFAULT 0,
    claim_deadline  TIMESTAMPTZ  NOT NULL,
    is_claimed      BOOLEAN      NOT NULL DEFAULT FALSE,
    is_unclaimable  BOOLEAN      NOT NULL DEFAULT FALSE,
    claimed_at      TIMESTAMPTZ,
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS bonus_history_user_active_idx
    ON bonus_history (userid, is_claimed, is_unclaimable, claim_deadline);

CREATE INDEX IF NOT EXISTS bonus_history_user_created_idx
    ON bonus_history (userid, created_at DESC);

CREATE INDEX IF NOT EXISTS bonus_history_user_type_idx
    ON bonus_history (userid, bonus_type, is_claimed, is_unclaimable);
