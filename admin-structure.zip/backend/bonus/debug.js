const { debugBonusCalculation } = require('./bonusCron');

(async () => {
  await debugBonusCalculation('7941887539');
})();