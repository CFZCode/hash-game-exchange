// backend/bonus/bonusengine.js

const cron    = require('node-cron');
const pg      = require('../General/Model');
const winston = require('winston');
const { getVipLevelDetails } = require('./calculateVip');

/* ─────────────── logger ─────────────── */
const logger = winston.createLogger({
  level : process.env.BONUS_LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.printf(({ timestamp, level, message }) =>
      `${timestamp} [${level}] ${message}`
    )
  ),
  transports: [
    new winston.transports.File({ filename: 'bonuslogs/bonusEngine.log' }),
    new winston.transports.Console({ format: winston.format.simple() })
  ]
});

/* ─────────────── flags & constants ─────────────── */
const IST_MS      = 5.5 * 60 * 60 * 1000;    // UTC → IST
const PERIODS     = ['daily','weekly','monthly'];
const DRY_FLAGS   = ['--dry','-d','dry'];
const args        = process.argv.slice(2);
const simulateMode= args[0]==='simulate';
const DRY         = () => args.some(f => DRY_FLAGS.includes(f));
const FORCE       = simulateMode || args.includes('--force');

/* ─────────────── UTC↔IST helpers ─────────────── */
const toIST   = d => new Date(d.getTime() + IST_MS);
const fromIST = d => new Date(d.getTime() - IST_MS);

const startOfISTDay = now => { const t=toIST(now); t.setHours(0,0,0,0); return fromIST(t) };
const endOfISTDay   = now => { const t=toIST(now); t.setHours(23,59,59,999); return fromIST(t) };

const weekBounds = now => {
  const ist = toIST(now);
  const mon = new Date(ist);
  mon.setDate(mon.getDate() - ((ist.getDay()+6)%7));
  mon.setHours(0,0,0,0);
  const sun = new Date(mon);
  sun.setDate(mon.getDate()+6);
  sun.setHours(23,59,59,999);
  return { start: fromIST(mon), end: fromIST(sun) };
};

const monthBounds = now => {
  const ist   = toIST(now);
  const start = new Date(ist.getFullYear(), ist.getMonth(),   1);
  const end   = new Date(ist.getFullYear(), ist.getMonth()+1, 0, 23,59,59,999);
  return { start: fromIST(start), end: fromIST(end) };
};

const isPayoutDay = (period, now=new Date()) => {
  const ist = toIST(now);
  if (period==='daily')   return true;
  if (period==='weekly')  return ist.getDay()===0;
  if (period==='monthly') {
    const last = new Date(ist.getFullYear(), ist.getMonth()+1,0).getDate();
    return ist.getDate()===last;
  }
  return false;
};

const columnName = p => {
  if (!PERIODS.includes(p)) throw new Error(`Invalid period ${p}`);
  return `${p}bonus`;
};

function parseWager(v) {
  if (typeof v==='number') return v;
  const n = parseFloat(String(v).replace(/,/g,'').trim());
  return isNaN(n)?0:n;
}

/* ───────── calculateWagerBonus ───────── */
/* ───────── calculateWagerBonus (latest‑row, |Δ|) ───────── */
async function calculateWagerBonus(uid, period, start, end) {
  const q = `
      SELECT previous_wager, new_wager, updated_at
        FROM userwager_history
       WHERE uid = $1
         AND updated_at >= $2
         AND updated_at <  $3
    ORDER BY updated_at DESC
       LIMIT 1`;
  const { rows } = await pg.query(q, [uid, start, end]);
  if (!rows.length)
    return { eligible:false, bonusAmount:0, wagerChange:0, reason:'no-history' };

  const { previous_wager, new_wager, updated_at } = rows[0];
  const prev  = parseWager(previous_wager);
  const cur   = parseWager(new_wager);
  const delta = Math.abs(cur - prev);

  logger.debug(`uid ${uid}|${period}|latest ${prev}→${cur}| |Δ| ${delta}`);

  if (!delta)
    return { eligible:false, bonusAmount:0, wagerChange:0, reason:'no-change' };

  /* ---- VIP check ---- */
  const { rows:[wRow] } =
        await pg.query('SELECT wager FROM userwager WHERE uid=$1',[uid]);
  const vip  = getVipLevelDetails(parseWager(wRow?.wager));
  const vipNumber = txt => {
    const m = String(txt || '').match(/\d+/);
    return m ? Number(m[0]) : 0;
  };
  const lvl  = vipNumber(vip.previousVipLevel);
  const need = { daily:20, weekly:25, monthly:30 }[period];

  if (lvl < need)
    return { eligible:false, bonusAmount:0, wagerChange:delta, reason:`vip<${need}` };

  /* ---- bonus math ---- */
  const base  = delta * 0.01;                          // 1 %
  const mult  = { daily:0.5, weekly:0.15, monthly:0.2 }[period];
  const bonus = Math.floor(base * mult *
                           (vip.bonusMultiplier || 1) * 100) / 100;

  return bonus < 0.1
       ? { eligible:false, bonusAmount:0, wagerChange:delta, reason:'final<min' }
       : { eligible:true,  bonusAmount:bonus, wagerChange:delta, vipLevel:lvl };
}



/* ───────── helpers ───────── */
async function ensureUserBonus(uid) {
  const { rowCount } = await pg.query('SELECT 1 FROM userbonus WHERE userid=$1',[uid]);
  if (!rowCount && !DRY()) {
    await pg.query('INSERT INTO userbonus(userid,name) VALUES($1,$2)',[uid,`User ${uid}`]);
  }
}

async function clearUserBonus(uid,period) {
  if (!DRY()) {
    await pg.query(
      `UPDATE userbonus SET ${columnName(period)}=0 WHERE userid=$1`,
      [uid]
    );
  }
}

async function expireOld(now=new Date()) {
  const { rows } = await pg.query(
    `SELECT id,userid,bonus_type
       FROM bonus_history
      WHERE is_claimed=FALSE
        AND is_unclaimable=FALSE
        AND claim_deadline<$1`,[now]
  );
  if (!rows.length) return 0;
  const ids = rows.map(r=>r.id);
  if (!DRY()) {
    await pg.query(
      `UPDATE bonus_history SET is_unclaimable=TRUE WHERE id=ANY($1::bigint[])`,[ids]
    );
    for(const r of rows) clearUserBonus(r.userid,r.bonus_type);
  }
  return rows.length;
}

/* ───────── per-period ───────── */
async function processPeriod(uid,period,now=new Date()) {
  if (!isPayoutDay(period,now)) return false;

  const { start,end } =
        period==='daily'  ? { start:startOfISTDay(now), end:endOfISTDay(now) }
      : period==='weekly' ? weekBounds(now)
      :                     monthBounds(now);

  const resetCol = `last_${period}_reset`;
  const { rows:[ub] } = await pg.query(
    `SELECT ${resetCol} FROM userbonus WHERE userid=$1`,[uid]
  );
  if (!DRY() && !FORCE && ub?.[resetCol] && new Date(ub[resetCol])>=start) {
    return false;
  }

  if (!DRY()) {
    await pg.query(
      `UPDATE bonus_history
          SET is_unclaimable=TRUE
        WHERE userid=$1 AND bonus_type=$2
          AND is_claimed=FALSE AND is_unclaimable=FALSE`,
      [uid,period]
    );
    await clearUserBonus(uid,period);
  }

  const { eligible, bonusAmount, wagerChange } =
        await calculateWagerBonus(uid,period,start,end);
  const amount   = eligible?bonusAmount:0;
  const deadline = endOfISTDay(now);

  if (!DRY()) {
    const { rows:[bh] } = await pg.query(
      `INSERT INTO bonus_history
         (userid,bonus_type,wager_change,bonus_amount,claim_deadline)
       VALUES($1,$2,$3,$4,$5) RETURNING id`,
      [uid,period,wagerChange,amount,deadline]
    );
    await pg.query(
      `UPDATE userbonus
          SET ${columnName(period)}=$1, ${resetCol}=NOW()
        WHERE userid=$2`,
      [amount,uid]
    );
    logger.info(`${period} bonus for user ${uid} → ${amount} (hist ${bh.id})`);
  }

  return true;
}

/* ───────── full cycle ───────── */
async function processBonusCalculation({ now=new Date() }={}) {
  logger.info(`==== bonus cycle start ${now.toISOString()}`);
  if (DRY()) await pg.query('BEGIN');

  const expired = await expireOld(now);
  logger.info(`expired rows → ${expired}`);

  const { rows:users } = await pg.query(
    `SELECT DISTINCT uid FROM userwager
     WHERE (REPLACE(COALESCE(wager,'0')::text,',',''))::numeric>0`
  );

  let created=0;
  for(const { uid } of users) {
    try {
      if (DRY()) await pg.query('BEGIN');
      await ensureUserBonus(uid);
      for(const p of PERIODS) {
        if(await processPeriod(uid,p,now)) created++;
      }
      if (DRY()) await pg.query('COMMIT');
    } catch(e) {
      if (DRY()) await pg.query('ROLLBACK');
      logger.error(`user ${uid} failed: ${e.message}`);
    }
  }

  if (DRY()) await pg.query('ROLLBACK');
  logger.info(`cycle done – bonuses created ${created}`);
}

/* ───────── timers ───────── */
async function getUserBonusTimers(uid) {
  const { rows } = await pg.query(
    `SELECT id,bonus_type,bonus_amount,claim_deadline
       FROM bonus_history
      WHERE userid=$1
        AND is_claimed=FALSE
        AND is_unclaimable=FALSE
        AND claim_deadline>=NOW()`,[uid]
  );
  return {
    userid: uid,
    activeBonuses: rows.map(b=>({
      id: b.id,
      type: b.bonus_type,
      amount: Number(b.bonus_amount),
      deadline: b.claim_deadline,
      secondsLeft:
        Math.max(0,Math.floor((new Date(b.claim_deadline)-Date.now())/1000))
    }))
  };
}

/* ───────── cron + export ───────── */
function initCron(io) {
  cron.schedule(
    '0 0 * * *',
    ()=>processBonusCalculation().catch(e=>logger.error('cron error',e)),
    { timezone:'Asia/Kolkata' }
  );
  if(io) setInterval(async()=>{
    for(const s of io.sockets.sockets.values()){
      if(!s.userid) continue;
      try{
        s.emit('bonusTimerUpdate',await getUserBonusTimers(s.userid));
      }catch(e){
        logger.error(`timer err for ${s.userid}: ${e.message}`);
      }
    }
  },1000);
  logger.info('cron registered at IST 00:00');
}

module.exports = { initCron, processBonusCalculation, getUserBonusTimers };

/* ───────── CLI ───────── */
if(require.main===module){
  const cmd  = args[0];
  const days = parseInt(args[1]||'1',10);

  if(cmd==='simulate'){
    const utcNow  = new Date();
    const istMid  = toIST(utcNow);
    istMid.setHours(0,0,0,0);
    const simStart = fromIST(istMid);

    (async()=>{
      for(let i=0;i<days;i++){
        const dayNow = new Date(simStart.getTime()+i*24*60*60*1000);
        logger.info(`\n=== SIM DAY ${i+1} | ${dayNow.toISOString()} ===`);
        await processBonusCalculation({ now:dayNow });
      }
      logger.info('simulation complete');
      process.exit(0);
    })();
  } else {
    (async()=>{
      await processBonusCalculation();
      process.exit(0);
    })();
  }
}
