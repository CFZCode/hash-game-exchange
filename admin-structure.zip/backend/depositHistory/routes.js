const express = require('express');
const router = express.Router();
const pg = require('../General/Model');

// Get crypto deposits with pagination
const getTreeIdsSql = `
WITH RECURSIVE tree AS (
  SELECT id FROM staff WHERE id = $1
  UNION ALL
  SELECT s.id
  FROM staff s
  JOIN tree t ON s.parent_id = t.id
)
SELECT array_agg(id) AS ids FROM tree
`;
async function visibleIds(staffId) {
  const { rows:[{ ids }] } = await pg.query(getTreeIdsSql, [staffId]);
  return ids;                   // => e.g. [1,4,9,12]
}

// usd_rate is "USD per 1 unit of currency" — so 1 INR = 0.01077705 USD.
// To convert a USD value to INR: inr = usd / usd_rate_of_INR.
// Fallback of 0.012 (~₹83/USD) avoids divide-by-zero if the row is missing.
async function getInrUsdRate() {
  const { rows } = await pg.query(
    `SELECT usd_rate FROM exchangerate WHERE currency = 'INR' LIMIT 1`
  );
  const rate = Number(rows[0]?.usd_rate);
  return Number.isFinite(rate) && rate > 0 ? rate : 0.012;
}
router.get('/crypto/deposits', async (req, res) => {
  let ids = await visibleIds(req.headers['x-staff-id']);
  ids = ids.map(x => Number(x)); // ensure numbers

  console.log("hellotesthb (staff visibility IDs):", ids);

  try {
    // ccdeposit.amount is stored as USD (USDT ≈ USD). Convert per-row to INR.
    const inrUsdRate = await getInrUsdRate();

    const {
      page = 1,
      limit = 10,
      status,
      startDate,
      endDate,
      userid,
      chain
    } = req.query;

    let countQuery = `
      SELECT COUNT(*)
      FROM ccdeposit cd
      LEFT JOIN users u ON cd.userid = u.id::text
      WHERE 1=1
    `;
    
    const values = [];
    let valueIndex = 1;

    // ✅ Staff visibility filter
    if (ids.includes(1)) {
      countQuery += ` AND (u.parent_staff_id = ANY($${valueIndex}::bigint[]) OR u.parent_staff_id IS NULL)`;
    } else {
      countQuery += ` AND u.parent_staff_id = ANY($${valueIndex}::bigint[])`;
    }
    values.push(ids);
    valueIndex++;

    if (status) {
      countQuery += ` AND LOWER(cd.status) = LOWER($${valueIndex})`;
      values.push(status);
      valueIndex++;
    }

    if (startDate) {
      countQuery += ` AND cd.created_at >= $${valueIndex}`;
      values.push(startDate);
      valueIndex++;
    }

    if (endDate) {
      countQuery += ` AND cd.created_at < ($${valueIndex}::date + 1)`;
      values.push(endDate);
      valueIndex++;
    }

    if (userid) {
      countQuery += ` AND (cd.userid = $${valueIndex} OR u.name ILIKE '%' || $${valueIndex} || '%')`;
      values.push(userid);
      valueIndex++;
    }

    if (chain) {
      countQuery += ` AND cd.chain = $${valueIndex}`;
      values.push(chain);
      valueIndex++;
    }

    const countResult = await pg.query(countQuery, values);
    const totalItems = parseInt(countResult.rows[0].count);

    // ✅ Main query with same filters
    //   cd.amount (stored as USD) is converted to INR in the `amount` output column,
    //   and the raw USD value is preserved as `amount_usd` for reference.
    let query = `
      SELECT
        cd.id, cd.userid, cd.coinid, cd.price, cd.orderid, cd.chain,
        cd.deposit_address,
        ROUND(cd.amount / $2::numeric, 2) AS amount,
        cd.amount AS amount_usd,
        'INR'::text AS currency,
        cd.memo, cd.checkout_url, cd.confirms_needed,
        cd.created_at, cd.updated_at, cd.status,
        u.name as username
      FROM ccdeposit cd
      LEFT JOIN users u ON cd.userid = u.id::text
      WHERE 1=1
    `;

    // same staff filter
    if (ids.includes(1)) {
      query += ` AND (u.parent_staff_id = ANY($1::bigint[]) OR u.parent_staff_id IS NULL)`;
    } else {
      query += ` AND u.parent_staff_id = ANY($1::bigint[])`;
    }

    let paramIndex = 3; // $1 = staff ids, $2 = inr rate
    if (status) {
      query += ` AND LOWER(cd.status) = LOWER($${paramIndex++})`;
    }
    if (startDate) {
      query += ` AND cd.created_at >= $${paramIndex++}`;
    }
    if (endDate) {
      query += ` AND cd.created_at < ($${paramIndex++}::date + 1)`;
    }
    if (userid) {
      query += ` AND (cd.userid = $${paramIndex} OR u.name ILIKE '%' || $${paramIndex} || '%')`;
      paramIndex++;
    }
    if (chain) {
      query += ` AND cd.chain = $${paramIndex++}`;
    }

    const offset = (parseInt(page) - 1) * parseInt(limit);
    query += ` ORDER BY cd.created_at DESC LIMIT $${paramIndex++} OFFSET $${paramIndex++}`;

    // rebuild values array to match positions: $1=ids, $2=inrRate, then filters, then limit/offset
    const queryValues = [ids, inrUsdRate];
    if (status) queryValues.push(status);
    if (startDate) queryValues.push(startDate);
    if (endDate) queryValues.push(endDate);
    if (userid) queryValues.push(userid);
    if (chain) queryValues.push(chain);
    queryValues.push(parseInt(limit), offset);

    const result = await pg.query(query, queryValues);

    res.json({
      success: true,
      data: result.rows,
      page: parseInt(page),
      limit: parseInt(limit),
      total: totalItems,
      totalPages: Math.ceil(totalItems / parseInt(limit))
    });
  } catch (error) {
    console.error('Error fetching crypto deposits:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});
// Get crypto deposit stats
router.get('/crypto/stats', async (req, res) => {
  let ids = await visibleIds(req.headers['x-staff-id']);
  ids = ids.map(x => Number(x));

  console.log("hellotesthb (staff visibility IDs):", ids);

  try {
    // ccdeposit.amount is stored as USD (USDT ≈ USD). Convert the SUM to INR.
    const inrUsdRate = await getInrUsdRate();

    let query = `
      SELECT
        COUNT(*)::integer as total_transactions,
        COALESCE(SUM(cd.amount) / $2::numeric, 0)::float as total_amount,
        COALESCE(SUM(CASE WHEN LOWER(cd.status) = 'success' THEN cd.amount END) / $2::numeric, 0)::float as successful_amount,
        COALESCE(SUM(CASE WHEN LOWER(cd.status) = 'processing' THEN cd.amount END) / $2::numeric, 0)::float as processing_amount,
        'INR'::text as currency,
        COUNT(CASE WHEN LOWER(cd.status) = 'success' THEN 1 END)::integer as successful_transactions,
        COUNT(CASE WHEN LOWER(cd.status) = 'processing' THEN 1 END)::integer as processing_transactions,
        COUNT(CASE WHEN LOWER(cd.status) = 'failed' THEN 1 END)::integer as failed_transactions
      FROM ccdeposit cd
      LEFT JOIN users u ON cd.userid = u.id::text
      WHERE 1=1
    `;

    if (ids.includes(1)) {
      query += ` AND (u.parent_staff_id = ANY($1::bigint[]) OR u.parent_staff_id IS NULL)`;
    } else {
      query += ` AND u.parent_staff_id = ANY($1::bigint[])`;
    }

    const result = await pg.query(query, [ids, inrUsdRate]);

    res.json({
      success: true,
      data: result.rows[0]
    });
  } catch (error) {
    console.error('Error fetching crypto deposit stats:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    });
  }
});
router.get('/fiat/deposits', async (req, res) => {
    try {
        // Convert every row's amount to INR using its own currency + exchangerate.
        const inrUsdRate = await getInrUsdRate();

        const {
            page = 1,
            limit = 10,
            status,
            startDate,
            endDate,
            userid,
            currency,
            provider
        } = req.query;

        // Cast currency/status to text in every UNION branch — pay_in_transactions
        // and apaydeposits store currency as varchar, fiat_deposits as text. Without
        // a uniform type the planner can't infer parameter types in the WHERE clause
        // (Postgres 42P18: "could not determine data type of parameter $1").
        let countQuery = `
            SELECT COUNT(*)
            FROM (
                SELECT id, user_id, currency::text AS currency, status::text AS status, created_at, 'PayIn' AS provider_type
                FROM pay_in_transactions
                UNION ALL
                SELECT id, user_id, currency::text AS currency, status::text AS status, created_at, 'APay' AS provider_type
                FROM apaydeposits
                UNION ALL
                SELECT deposit_id AS id, user_id, currency::text AS currency, status::text AS status, created_at, 'Fiat' AS provider_type
                FROM fiat_deposits
                UNION ALL
                SELECT id, uid AS user_id, 'INR'::text AS currency, status::text AS status, created_at, 'CricPay' AS provider_type
                FROM cricpaytransactions
                UNION ALL
                SELECT id, user_id, currency::text AS currency, status::text AS status, created_at, 'F2Pay' AS provider_type
                FROM f2paydeposits
            ) combined
            LEFT JOIN users u ON combined.user_id = u.id
            WHERE 1=1
        `;

        const values = [];
        let valueIndex = 1;

        if (status !== undefined) {
            countQuery += ` AND LOWER(combined.status) = LOWER($${valueIndex})`;
            values.push(status);
            valueIndex++;
        }

        if (startDate) {
            countQuery += ` AND combined.created_at >= $${valueIndex}`;
            values.push(startDate);
            valueIndex++;
        }

        if (endDate) {
            countQuery += ` AND combined.created_at < ($${valueIndex}::date + 1)`;
            values.push(endDate);
            valueIndex++;
        }

        if (userid) {
            countQuery += ` AND (combined.user_id::text = $${valueIndex} OR u.name ILIKE '%' || $${valueIndex} || '%')`;
            values.push(String(userid).trim());
            valueIndex++;
        }

        if (currency) {
            countQuery += ` AND combined.currency = $${valueIndex}`;
            values.push(currency);
            valueIndex++;
        }

        if (provider) {
            countQuery += ` AND combined.provider_type = $${valueIndex}`;
            values.push(provider);
            valueIndex++;
        }

        const countResult = await pg.query(countQuery, values);
        const totalItems = parseInt(countResult.rows[0].count);

        // Inline the INR usd_rate as a SQL numeric literal to avoid clashing with the
        // filter/limit/offset parameter positions below. Value is a validated Number.
        const rateLiteral = Number(inrUsdRate).toFixed(10);

        let query = `
            SELECT
                combined.id, combined.user_id, combined.transaction_id, combined.out_trade_no,
                'INR'::text AS currency,
                combined.currency AS original_currency,
                CASE
                    WHEN combined.currency = 'INR' THEN combined.amount
                    WHEN er.usd_rate IS NOT NULL
                        THEN ROUND(combined.amount * er.usd_rate / ${rateLiteral}::numeric, 2)
                    ELSE combined.amount
                END AS amount,
                combined.amount AS original_amount,
                combined.pay_amount, combined.merchant_ratio, combined.real_amount,
                combined.status, combined.pay_type, combined.created_at, combined.updated_at,
                combined.provider_type, combined.provider_name,
                u.name as username
            FROM (
                SELECT
                    id, user_id, transaction_id, out_trade_no,
                    currency::text AS currency, amount,
                    pay_amount, merchant_ratio, real_amount, status::text AS status,
                    pay_type, created_at, updated_at, 'PayIn' AS provider_type,
                    'okpay' AS provider_name
                FROM pay_in_transactions
                UNION ALL
                SELECT
                    id, user_id, custom_transaction_id AS transaction_id, NULL AS out_trade_no,
                    currency::text AS currency,
                    -- Success rows show what the user actually paid (paid_amount
                    -- from the postback), others the requested amount.
                    CASE WHEN status = 'Success' AND paid_amount > 0 THEN paid_amount ELSE amount END AS amount,
                    NULL AS pay_amount, NULL AS merchant_ratio,
                    NULL AS real_amount, status::text AS status, payment_system AS pay_type,
                    created_at, updated_at, 'APay' AS provider_type,
                    'paykasma' AS provider_name
                FROM apaydeposits
                UNION ALL
                SELECT
                    deposit_id AS id, user_id, transaction_id, NULL AS out_trade_no,
                    currency::text AS currency, amount, NULL AS pay_amount, NULL AS merchant_ratio,
                    NULL AS real_amount, status::text AS status, 'Fiat' AS pay_type,
                    created_at, created_at AS updated_at, 'Fiat' AS provider_type,
                    'inhouse' AS provider_name
                FROM fiat_deposits
                UNION ALL
                SELECT
                    id, uid AS user_id, transaction_code AS transaction_id, NULL AS out_trade_no,
                    'INR'::text AS currency, amount, NULL AS pay_amount, NULL AS merchant_ratio,
                    NULL AS real_amount, status::text AS status, payment_method AS pay_type,
                    created_at, updated_at, 'CricPay' AS provider_type,
                    'cricpay' AS provider_name
                FROM cricpaytransactions
                UNION ALL
                SELECT
                    id, user_id, mch_order_no AS transaction_id, plat_no AS out_trade_no,
                    currency::text AS currency, amount, NULL AS pay_amount, NULL AS merchant_ratio,
                    NULL AS real_amount, status::text AS status, 'UpiMixed' AS pay_type,
                    created_at, updated_at, 'F2Pay' AS provider_type,
                    'f2pay' AS provider_name
                FROM f2paydeposits
            ) combined
            LEFT JOIN users u ON combined.user_id = u.id
            LEFT JOIN exchangerate er ON er.currency = combined.currency
            WHERE 1=1
        `;

        // Reuse the same `values` array the count query pushed — its filters live
        // at positions 1..N. Reset valueIndex so the main query's WHERE references
        // those exact positions instead of marching past the array length (which
        // collapses parameter types and triggers Postgres 42P18).
        valueIndex = 1;

        if (status !== undefined) query += ` AND LOWER(combined.status) = LOWER($${valueIndex++})`;
        if (startDate) query += ` AND combined.created_at >= $${valueIndex++}`;
        if (endDate) query += ` AND combined.created_at < ($${valueIndex++}::date + 1)`;
        if (userid) { query += ` AND (combined.user_id::text = $${valueIndex} OR u.name ILIKE '%' || $${valueIndex} || '%')`; valueIndex++; }
        if (currency) query += ` AND combined.currency = $${valueIndex++}`;
        if (provider) query += ` AND combined.provider_type = $${valueIndex++}`;

        const offset = (parseInt(page) - 1) * parseInt(limit);
        query += ` ORDER BY combined.created_at DESC LIMIT $${valueIndex} OFFSET $${valueIndex + 1}`;
        values.push(parseInt(limit), offset);

        const result = await pg.query(query, values);

        res.json({
            success: true,
            data: result.rows,
            page: parseInt(page),
            limit: parseInt(limit),
            total: totalItems,
            totalPages: Math.ceil(totalItems / parseInt(limit))
        });
    } catch (error) {
        console.error('Error fetching fiat deposits:', error);
       
        res.status(500).json({
            success: false,
            error: 'Internal server error'
        });
    }
});
// router.get('/fiat/deposits', async (req, res) => {
//     try {
//         const {
//             page = 1,
//             limit = 10,
//             status,
//             startDate,
//             endDate,
//             userid,
//             currency,
//             provider
//         } = req.query;

//         let countQuery = `
//             SELECT COUNT(*) 
//             FROM (
//                 SELECT id, user_id, currency, status::text AS status, created_at, 'PayIn' AS provider
//                 FROM pay_in_transactions
//                 UNION ALL
//                 SELECT id, user_id, currency, status, created_at, 'APay' AS provider
//                 FROM apaydeposits
//                 UNION ALL
//                 SELECT deposit_id AS id, user_id, currency, status, created_at, 'Fiat' AS provider
//                 FROM fiat_deposits
//                 UNION ALL
//                 SELECT id, uid AS user_id, 'INR' AS currency, status, created_at, 'CricPay' AS provider
//                 FROM cricpaytransactions
//             ) combined
//             LEFT JOIN users u ON combined.user_id = u.id
//             WHERE 1=1
//         `;
        
//         const values = [];
//         let valueIndex = 1;

//         if (status !== undefined) {
//             countQuery += ` AND combined.status = $${valueIndex}`;
//             values.push(status);
//             valueIndex++;
//         }

//         if (startDate) {
//             countQuery += ` AND combined.created_at >= $${valueIndex}`;
//             values.push(startDate);
//             valueIndex++;
//         }

//         if (endDate) {
//             countQuery += ` AND combined.created_at <= $${valueIndex}`;
//             values.push(endDate);
//             valueIndex++;
//         }

//         if (userid) {
//             countQuery += ` AND combined.user_id = $${valueIndex}`;
//             values.push(parseInt(userid));
//             valueIndex++;
//         }

//         if (currency) {
//             countQuery += ` AND combined.currency = $${valueIndex}`;
//             values.push(currency);
//             valueIndex++;
//         }

//         if (provider) {
//             countQuery += ` AND combined.provider = $${valueIndex}`;
//             values.push(provider);
//             valueIndex++;
//         }

//         const countResult = await pg.query(countQuery, values);
//         const totalItems = parseInt(countResult.rows[0].count);

//         let query = `
//             SELECT 
//                 combined.*,
//                 u.name as username
//             FROM (
//                 SELECT 
//                     id, user_id, transaction_id, out_trade_no, currency, amount, 
//                     pay_amount, merchant_ratio, real_amount, status::text AS status, 
//                     pay_type, created_at, updated_at, 'PayIn' AS provider
//                 FROM pay_in_transactions
//                 UNION ALL
//                 SELECT 
//                     id, user_id, custom_transaction_id AS transaction_id, NULL AS out_trade_no, 
//                     currency, amount, NULL AS pay_amount, NULL AS merchant_ratio, 
//                     NULL AS real_amount, status, payment_system AS pay_type, 
//                     created_at, updated_at, 'APay' AS provider
//                 FROM apaydeposits
//                 UNION ALL
//                 SELECT 
//                     deposit_id AS id, user_id, transaction_id, NULL AS out_trade_no, 
//                     currency, amount, NULL AS pay_amount, NULL AS merchant_ratio, 
//                     NULL AS real_amount, status, 'Fiat' AS pay_type, 
//                     created_at, updated_at, 'Fiat' AS provider
//                 FROM fiat_deposits
//                 UNION ALL
//                 SELECT 
//                     id, uid AS user_id, transaction_code AS transaction_id, NULL AS out_trade_no,
//                     'INR' AS currency, amount, NULL AS pay_amount, NULL AS merchant_ratio,
//                     NULL AS real_amount, status, payment_method AS pay_type,
//                     created_at, updated_at, 'CricPay' AS provider
//                 FROM cricpaytransactions
//             ) combined
//             LEFT JOIN users u ON combined.user_id = u.id
//             WHERE 1=1
//         `;

//         if (status !== undefined) query += ` AND combined.status = $${valueIndex++}`;
//         if (startDate) query += ` AND combined.created_at >= $${valueIndex++}`;
//         if (endDate) query += ` AND combined.created_at <= $${valueIndex++}`;
//         if (userid) query += ` AND combined.user_id = $${valueIndex++}`;
//         if (currency) query += ` AND combined.currency = $${valueIndex++}`;
//         if (provider) query += ` AND combined.provider = $${valueIndex++}`;

//         const offset = (parseInt(page) - 1) * parseInt(limit);
//         query += ` ORDER BY combined.created_at DESC LIMIT $${valueIndex} OFFSET $${valueIndex + 1}`;
//         values.push(parseInt(limit), offset);

//         const result = await pg.query(query, values);

//         res.json({
//             success: true,
//             data: result.rows,
//             page: parseInt(page),
//             limit: parseInt(limit),
//             total: totalItems,
//             totalPages: Math.ceil(totalItems / parseInt(limit))
//         });
//     } catch (error) {
//         console.error('Error fetching fiat deposits:', error);
       
//         res.status(500).json({
//             success: false,
//             error: 'Internal server error'
//         });
//     }
// });
router.get('/fiat/stats', async (req, res) => {
    try {
        // Normalise every fiat row to INR before summing, using each row's own currency.
        // INR rows pass through; other currencies use exchangerate.usd_rate.
        // When ?currency=XXX is passed, the totals are scoped to that currency
        // (and total_amount is left in that currency, not INR-converted).
        const currency = (req.query.currency || '').toString().toUpperCase().trim();

        // Cast every UNION branch's currency/status to text so PG can infer types
        // when we add a parameterised WHERE clause.
        const baseUnion = `
            SELECT amount, currency::text AS currency, status::text AS status, 'pay_in_transactions' AS source
            FROM pay_in_transactions
            UNION ALL
            SELECT
                CASE WHEN status = 'Success' AND paid_amount > 0 THEN paid_amount ELSE amount END AS amount,
                currency::text AS currency, status::text AS status, 'apaydeposits' AS source
            FROM apaydeposits
            UNION ALL
            SELECT amount, currency::text AS currency, status::text AS status, 'fiat_deposits' AS source
            FROM fiat_deposits
            UNION ALL
            SELECT amount, 'INR'::text AS currency, status::text AS status, 'cricpaytransactions' AS source
            FROM cricpaytransactions
            UNION ALL
            SELECT amount, currency::text AS currency, status::text AS status, 'f2paydeposits' AS source
            FROM f2paydeposits
        `;

        let query;
        let params;
        if (currency) {
            // Single-currency view: report amount in that currency, no conversion.
            query = `
                SELECT
                    COUNT(*)::integer as total_transactions,
                    COALESCE(SUM(combined.amount), 0)::float as total_amount,
                    COALESCE(SUM(CASE
                        WHEN status = '1' OR status IN ('Success', 'Successful', 'Approved') OR
                             (source = 'cricpaytransactions' AND status = 'Successful')
                        THEN combined.amount END), 0)::float as successful_amount,
                    COALESCE(SUM(CASE
                        WHEN status = '0' OR status = 'Pending' OR
                             (source = 'cricpaytransactions' AND status IN ('Pending', 'Processing'))
                        THEN combined.amount END), 0)::float as processing_amount,
                    COUNT(CASE
                        WHEN status = '1' OR status IN ('Success', 'Successful', 'Approved') OR
                             (source = 'cricpaytransactions' AND status = 'Successful')
                        THEN 1 END)::integer as successful_transactions,
                    COUNT(CASE
                        WHEN status = '0' OR status = 'Pending' OR
                             (source = 'cricpaytransactions' AND status IN ('Pending', 'Processing'))
                        THEN 1 END)::integer as processing_transactions,
                    COUNT(CASE
                        WHEN status = '2' OR status IN ('Failed', 'Rejected') OR
                             (source = 'cricpaytransactions' AND status IN ('Failed', 'Rejected', 'Error'))
                        THEN 1 END)::integer as failed_transactions
                FROM (${baseUnion}) combined
                WHERE UPPER(combined.currency) = $1
            `;
            params = [currency];
        } else {
            const inrUsdRate = await getInrUsdRate();
            query = `
                SELECT
                    COUNT(*)::integer as total_transactions,
                    COALESCE(SUM(
                        CASE
                            WHEN combined.currency = 'INR' THEN combined.amount
                            WHEN er.usd_rate IS NOT NULL
                                THEN combined.amount * er.usd_rate / $1::numeric
                            ELSE 0
                        END
                    ), 0)::float as total_amount,
                    COALESCE(SUM(
                        CASE
                            WHEN NOT (status = '1' OR status IN ('Success', 'Successful', 'Approved') OR
                                      (source = 'cricpaytransactions' AND status = 'Successful')) THEN 0
                            WHEN combined.currency = 'INR' THEN combined.amount
                            WHEN er.usd_rate IS NOT NULL
                                THEN combined.amount * er.usd_rate / $1::numeric
                            ELSE 0
                        END
                    ), 0)::float as successful_amount,
                    COALESCE(SUM(
                        CASE
                            WHEN NOT (status = '0' OR status = 'Pending' OR
                                      (source = 'cricpaytransactions' AND status IN ('Pending', 'Processing'))) THEN 0
                            WHEN combined.currency = 'INR' THEN combined.amount
                            WHEN er.usd_rate IS NOT NULL
                                THEN combined.amount * er.usd_rate / $1::numeric
                            ELSE 0
                        END
                    ), 0)::float as processing_amount,
                    'INR'::text as currency,
                    COUNT(CASE
                        WHEN status = '1' OR status IN ('Success', 'Successful', 'Approved') OR
                             (source = 'cricpaytransactions' AND status = 'Successful')
                        THEN 1 END)::integer as successful_transactions,
                    COUNT(CASE
                        WHEN status = '0' OR status = 'Pending' OR
                             (source = 'cricpaytransactions' AND status IN ('Pending', 'Processing'))
                        THEN 1 END)::integer as processing_transactions,
                    COUNT(CASE
                        WHEN status = '2' OR status IN ('Failed', 'Rejected') OR
                             (source = 'cricpaytransactions' AND status IN ('Failed', 'Rejected', 'Error'))
                        THEN 1 END)::integer as failed_transactions
                FROM (${baseUnion}) combined
                LEFT JOIN exchangerate er ON er.currency = combined.currency
            `;
            params = [inrUsdRate];
        }

        const result = await pg.query(query, params);
        res.json({
            success: true,
            data: { ...result.rows[0], currency: currency || 'INR' }
        });
    } catch (error) {
        console.error('Error fetching fiat stats:', error);
        res.status(500).json({
            success: false,
            error: error && error.message ? error.message : 'Internal server error'
        });
    }
});

module.exports = router;