const express = require('express');
const { rejectDemoUser } = require('../system/utils/demoUsers');
const router = express.Router();
const cricpayController = require('./controller');

// Routes for Cricpay Payment Gateway
router.get('/check-payment-status', cricpayController.checkPaymentStatus);
router.post('/payment-request', rejectDemoUser, cricpayController.paymentRequest);
router.post('/check-transaction-status', cricpayController.checkTransactionStatus);
router.post('/payout-request', rejectDemoUser, cricpayController.payoutRequest);
router.post('/payment-callback', cricpayController.paymentCallback);

module.exports = router;