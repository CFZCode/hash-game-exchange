const axios = require('axios');
const crypto = require('crypto');
const pg = require('../General/Model');
const querystring = require('querystring');

// Cricpay API configurations
const BASE_URL = 'https://prodapi.cricpayz.io:14495';
const MERCHANT_CODE = 'REMOVED_SECRET';
const SECRET_API_KEY = 'REMOVED_SECRET';
const SECRET_API_IV = 'REMOVED_SECRET';


function decrypt(encrypted, secretApiKey, secretApiIv) {
  console.log('Decrypting callback data:', { encrypted });
  const decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(secretApiKey, 'hex'), Buffer.from(secretApiIv, 'hex'));
  let decrypted = decipher.update(encrypted, 'hex', 'utf8');
  decrypted += decipher.final('utf8');
  console.log('Decrypted data:', decrypted);
  return decrypted;
}

// Check Payment Method Status
const checkPaymentStatus = async (req, res) => {
  console.log('Received checkPaymentStatus request');
  try {
    console.log('Calling Cricpay API:', `${BASE_URL}/api/appuser/checkDWStatus/${MERCHANT_CODE}`);
    const response = await axios.get(`${BASE_URL}/api/appuser/checkDWStatus/${MERCHANT_CODE}`);
    console.log('Cricpay API response:', response.data);
    if (response.data.status === 'Success') {
      res.status(200).json(response.data.data[0]);
    } else {
      console.log('Failed to fetch payment status:', response.data);
      res.status(400).json({ status: 'Error', message: 'Failed to fetch payment status' });
    }
  } catch (error) {
    console.error('Error in checkPaymentStatus:', error.message);
    res.status(500).json({ status: 'Error', message: error.message });
  }
};

// Payment Request (Deposit)
const paymentRequest = async (req, res) => {
  const { amount, userId, paymentMethod, userName } = req.body;
  const transactionCode = `DW-${Date.now()}-${Math.floor(Math.random() * 10000)}`;
  console.log('Received paymentRequest:', { amount, userId, paymentMethod,  userName, transactionCode });

  // Validate input
  if (!amount || !userId || !paymentMethod || !userName) {
    console.log('Missing required fields in paymentRequest');
    return res.status(400).json({ status: 'Error', message: 'Missing required fields' });
  }

  try {
    console.log('Starting database transaction for paymentRequest');
    await pg.query('BEGIN');

    // Verify user exists in credits table
    console.log('Checking user in credits table:', userId);
    const userCheck = await pg.query('SELECT uid FROM credits WHERE uid = $1', [userId]);
    console.log('User check result:', userCheck.rows);
    if (userCheck.rows.length === 0) {
      throw new Error('User not found in credits table');
    }

    // Store transaction in database
    const transactionQuery = `
      INSERT INTO cricpaytransactions (uid, transaction_code, amount, payment_method, status, created_at)
      VALUES ($1, $2, $3, $4, $5, NOW())
      RETURNING id
    `;
    const transactionValues = [userId, transactionCode, amount, paymentMethod, 'Pending'];
    console.log('Inserting transaction:', transactionValues);
    const transactionResult = await pg.query(transactionQuery, transactionValues);
    console.log('Transaction inserted:', transactionResult.rows[0]);

    // Prepare Cricpay payment request
    const payload = {
      merchantCode: MERCHANT_CODE,
      transaction_code: transactionCode,
      amount: amount.toString(),
      userId:userId.toString(),
      paymentMethod,
      userName,
    };
    console.log('Sending Cricpay payment request:', payload);

    const response = await axios.post(`${BASE_URL}/api/appuser/loginPaymentGateway`, payload);
    console.log('Cricpay payment response:', response.data);

    if (response.data.status === 'Success') {
      console.log('Committing transaction for successful payment request');
      await pg.query('COMMIT');
      res.status(200).json({
        status: 'Success',
        accessURL: response.data.accessURL,
        transactionCode,
      });
    } else {
      console.log('Updating transaction to Failed:', response.data.message);
      await pg.query('UPDATE cricpaytransactions SET status = $1 WHERE transaction_code = $2', ['Failed', transactionCode]);
      await pg.query('COMMIT');
      res.status(400).json({ status: 'Error', message: response.data.message });
    }
  } catch (error) {
    console.error('Error in paymentRequest:', error.message);
    await pg.query('ROLLBACK');
    res.status(500).json({ status: 'Error', message: error.message });
  }
};

// Check Transaction Status
const checkTransactionStatus = async (req, res) => {
  const { transactionCode } = req.body;
  console.log('Received checkTransactionStatus request:', { transactionCode });

  if (!transactionCode) {
    console.log('Missing transactionCode in checkTransactionStatus');
    return res.status(400).json({ status: 'Error', message: 'Transaction code is required' });
  }

  try {
    console.log('Starting database transaction for checkTransactionStatus');
    await pg.query('BEGIN');

    const payload = {
      merchantCode: MERCHANT_CODE,
      transaction_code: transactionCode,
    };
    console.log('Sending Cricpay status check request:', payload);

    const response = await axios.post(`${BASE_URL}/api/appuser/checkStatusByTrn`, payload);
    console.log('Cricpay status check response:', response.data);

    if (response.data.statusCode === 'Success') {
      console.log('Updating transaction status:', response.data.trn_status);
      await pg.query('UPDATE cricpaytransactions SET status = $1 WHERE transaction_code = $2', [response.data.trn_status, transactionCode]);
      await pg.query('COMMIT');
      res.status(200).json(response.data);
    } else {
      console.log('Failed to fetch transaction status:', response.data);
      await pg.query('COMMIT');
      res.status(400).json({ status: 'Error', message: 'Failed to fetch transaction status' });
    }
  } catch (error) {
    console.error('Error in checkTransactionStatus:', error.message);
    await pg.query('ROLLBACK');
    res.status(500).json({ status: 'Error', message: error.message });
  }
};

// Payout Request
const payoutRequest = async (req, res) => {
  const { amount, userId, accountHolder, accountNumber, ifscCode } = req.body;
  const transactionCode = `DW-${Date.now()}-${Math.floor(Math.random() * 10000)}`;
  console.log('Received payoutRequest:', { amount, userId, accountHolder, accountNumber, ifscCode, transactionCode });

  // Validate input
  if (!amount || !userId || !accountHolder || !accountNumber || !ifscCode) {
    console.log('Missing required fields in payoutRequest');
    return res.status(400).json({ status: 'Error', message: 'Missing required fields' });
  }

  try {
    console.log('Starting database transaction for payoutRequest');
    await pg.query('BEGIN');

    // Verify user exists in credits table
    console.log('Checking user in credits table:', userId);
    const userCheck = await pg.query('SELECT uid FROM credits WHERE uid = $1', [userId]);
    console.log('User check result:', userCheck.rows);
    if (userCheck.rows.length === 0) {
      throw new Error('User not found in credits table');
    }

    // Store transaction in database
    const transactionQuery = `
      INSERT INTO cricpaytransactions (uid, transaction_code, amount, payment_method, status, created_at)
      VALUES ($1, $2, $3, $4, $5, NOW())
      RETURNING id
    `;
    const transactionValues = [userId, transactionCode, amount, 'Payout_Bank', 'Pending'];
    console.log('Inserting transaction:', transactionValues);
    const transactionResult = await pg.query(transactionQuery, transactionValues);
    console.log('Transaction inserted:', transactionResult.rows[0]);

    // Prepare Cricpay payout request
    const payload = {
      merchantCode: MERCHANT_CODE,
      transaction_code: transactionCode,
      amount: amount.toString(),
      userId,
      account_holder: accountHolder,
      account_number: accountNumber,
      ifsc_code: ifscCode,
    };
    console.log('Sending Cricpay payout request:', payload);

    const response = await axios.post(`${BASE_URL}/api/appuser/doWithdraw`, payload);
    console.log('Cricpay payout response:', response.data);

    if (response.data.status === 'Success') {
      console.log('Committing transaction for successful payout request');
      await pg.query('COMMIT');
      res.status(200).json(response.data);
    } else {
      console.log('Updating transaction to Failed:', response.data.message);
      await pg.query('UPDATE cricpaytransactions SET status = $1 WHERE transaction_code = $2', ['Failed', transactionCode]);
      await pg.query('COMMIT');
      res.status(response.status).json(response.data);
    }
  } catch (error) {
    console.error('Error in payoutRequest:', error.message);
    await pg.query('ROLLBACK');
    res.status(500).json({ status: 'Error', message: error.message });
  }
};

// Callback API for Cricpay to update transaction status

// const paymentCallback = async (req, res) => {
//   const { transaction_code, data } = req.body;
//   console.log('Received paymentCallback:', { transaction_code, data });

//   try {
//     console.log('Starting database transaction for paymentCallback');
//     await pg.query('BEGIN');

//     // Decrypt the callback data and parse query string
//     const decryptedString = decrypt(data, SECRET_API_KEY, SECRET_API_IV);
//     const decryptedData = querystring.parse(decryptedString);
//     const { transaction_status, transaction_amount, transaction_fee, remark } = decryptedData;
//     console.log('Parsed callback data:', { transaction_status, transaction_amount, transaction_fee, remark });

//     // Validate required fields
//     if (!transaction_status || !transaction_amount) {
//       throw new Error('Missing required fields in decrypted callback data');
//     }

//     // Determine transaction status
//     const status = parseInt(transaction_status) === 1 ? 'Successful' : 'Failed';
//     console.log('Determined transaction status:', status);

//     // Update transaction status in database
//     const updateTransactionQuery = `
//       UPDATE cricpaytransactions
//       SET status = $1, amount = $2, fee = $3, remark = $4, updated_at = NOW()
//       WHERE transaction_code = $5
//       RETURNING uid
//     `;
//     const transactionValues = [
//       status,
//       parseFloat(transaction_amount),
//       parseFloat(transaction_fee) || 0,
//       remark || '',
//       transaction_code
//     ];
//     console.log('Updating transaction:', transactionValues);
//     const transactionResult = await pg.query(updateTransactionQuery, transactionValues);
//     console.log('Transaction update result:', transactionResult.rows);

//     if (status === 'Successful' && transactionResult.rows.length > 0) {
//       const uid = transactionResult.rows[0].uid;
//       console.log('Updating user balance for uid:', uid);

//       // Update user's INR balance in credits table
//       const updateBalanceQuery = `
//         UPDATE credits
//         SET inr = inr + $1
//         WHERE uid = $2
//       `;
//       await pg.query(updateBalanceQuery, [parseFloat(transaction_amount), uid]);
//       console.log('User balance updated:', { uid, amount: transaction_amount });
//     }

//     console.log('Committing transaction for paymentCallback');
//     await pg.query('COMMIT');
//     res.status(200).json({ status: 'Success', message: 'Callback processed successfully' });
//   } catch (error) {
//     console.error('Error in paymentCallback:', error.message);
//     await pg.query('ROLLBACK');
//     res.status(500).json({ status: 'Error', message: 'Failed to process callback' });
//   }
// };
const paymentCallback = async (req, res) => {
  const { transaction_code, data } = req.body;
  console.log('Received paymentCallback:', { transaction_code, data });

  try {
    console.log('Starting database transaction for paymentCallback');
    await pg.query('BEGIN');

    // Decrypt the callback data and parse query string
    const decryptedString = decrypt(data, SECRET_API_KEY, SECRET_API_IV);
    const decryptedData = querystring.parse(decryptedString);
    const { transaction_status, transaction_amount, transaction_fee, remark } = decryptedData;
    console.log('Parsed callback data:', { transaction_status, transaction_amount, transaction_fee, remark });

    // Validate required fields
    if (!transaction_status || !transaction_amount) {
      throw new Error('Missing required fields in decrypted callback data');
    }

    // Determine transaction status
    const status = parseInt(transaction_status) === 1 ? 'Successful' : 'Failed';
    console.log('Determined transaction status:', status);

    // Check existing transaction status
    const checkTransactionQuery = `
      SELECT status, amount
      FROM cricpaytransactions
      WHERE transaction_code = $1
    `;
    const checkResult = await pg.query(checkTransactionQuery, [transaction_code]);
    
    if (checkResult.rows.length === 0) {
      throw new Error('Transaction not found');
    }

    const existingTransaction = checkResult.rows[0];
    
    // Handle case 2: Allow success callback for previously rejected deposits
    if (existingTransaction.status === 'Successful' && status === 'Successful') {
      console.log('Ignoring duplicate success callback');
      await pg.query('COMMIT');
      return res.status(200).json({ status: 'Success', message: 'Callback already processed' });
    }

    // Update transaction status in database
    // For case 1: Update amount to match paid amount regardless of requested amount
    const updateTransactionQuery = `
      UPDATE cricpaytransactions
      SET status = $1, 
          amount = $2, 
          fee = $3, 
          remark = $4, 
          updated_at = NOW()
      WHERE transaction_code = $5
      RETURNING uid
    `;
    const transactionValues = [
      status,
      parseFloat(transaction_amount),
      parseFloat(transaction_fee) || 0,
      remark || '',
      transaction_code
    ];
    console.log('Updating transaction:', transactionValues);
    const transactionResult = await pg.query(updateTransactionQuery, transactionValues);
    console.log('Transaction update result:', transactionResult.rows);

    if (status === 'Successful' && transactionResult.rows.length > 0) {
      const uid = transactionResult.rows[0].uid;
      console.log('Updating user balance for uid:', uid);

      // Update user's INR balance in credits table
      const updateBalanceQuery = `
        UPDATE credits
        SET inr = inr + $1
        WHERE uid = $2
      `;
      await pg.query(updateBalanceQuery, [parseFloat(transaction_amount), uid]);
      console.log('User balance updated:', { uid, amount: transaction_amount });
    }

    console.log('Committing transaction for paymentCallback');
    await pg.query('COMMIT');
    res.status(200).json({ status: 'Success', message: 'Callback processed successfully' });
  } catch (error) {
    console.error('Error in paymentCallback:', error.message);
    await pg.query('ROLLBACK');
    res.status(500).json({ status: 'Error', message: 'Failed to process callback' });
  }
};
module.exports = {
  checkPaymentStatus,
  paymentRequest,
  checkTransactionStatus,
  payoutRequest,
  paymentCallback,
};