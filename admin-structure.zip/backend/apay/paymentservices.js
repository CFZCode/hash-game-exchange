const crypto = require('crypto');
const axios = require('axios');
const pg = require('../General/Model');
const emailService = require('../emailservice/controller');
// Shared pool + BEGIN/COMMIT helper — see General/Model/pool.js.
const { withTransaction } = require('../General/Model/pool');
const { assertWithdrawalAllowed } = require('../system/utils/withdrawalLocks');

// Fallback used only if the siteconfig row is missing or the column is null.
const FALLBACK_NOTIFICATION_EMAIL = 'salvin.dev.cfz@gmail.com';

const WITHDRAWAL_PAYMENT_SYSTEMS = {
   // INR: 'imps',         // data: { account_name, account_number, bank_code (IFSC) }
    BDT: 'bkash_api_v',  // data: { account_number: "01XXXXXXXXX" }  (or nagad_api_v: 11 digits)
    PKR: 'pkr_w',        // data: { account_number(CNIC/acct), bank_name, phone_number(03…) }
    NPR: 'esewa_p2p',    // data: { phone:{...} } OR { bank:{...} }
};

// Paykassma (2026-08): imps is our WITHDRAWAL channel — its deposit button must
// not be shown even though payment-systems-info reports deposit:true, otherwise
// every click creates an empty request against an inoperative method.
const DEPOSIT_HIDDEN_SYSTEMS = ['imps'];

// Paykassma (2026-08): Indian methods must not receive FTD (first-time
// depositor) traffic — upi_fast_v especially. These are only offered to users
// who already have at least one Success deposit; until then they are hidden
// from the method list and refused by createDeposit.
const FTD_RESTRICTED_SYSTEMS = ['upi_fast_v'];

// A Pending deposit older than this with no postback is treated as abandoned.
const UNATTEMPTED_AFTER_MINUTES = 15;

// A-Pay's system names → what the player sees. Unlisted ones show the raw name.
const PAYMENT_SYSTEM_LABELS = {
    imps: 'Bank Transfer (IMPS)',
    upi_p2p: 'UPI',
    upi_fast_v: 'UPI Fast',
    phonepe: 'PhonePe',
    paytm: 'Paytm',
    bkash_api_v: 'bKash',
    nagad_api_v: 'Nagad',
    nagad_b: 'Nagad (Bank)',
    easypaisa: 'EasyPaisa',
    jazzcash_fast: 'JazzCash',
    nayapay_l: 'NayaPay',
    raast_p2p: 'Raast',
    pkr_w: 'Bank Transfer',
    khalti_l: 'Khalti',
    esewa_p2p: 'eSewa',
};

const PS_CACHE_TTL_MS = 5 * 60 * 1000;
// Keyed by project, so the deposit and withdrawal services share one fetch.
const psCache = new Map();

// Throws on the first bad payout field — runs before any balance is held.
function validateWithdrawalData(paymentSystem, data) {
    const str = (v) => (v === undefined || v === null) ? '' : String(v);
    switch (paymentSystem) {
        case 'imps': // INR
            if (!/^[a-zA-Z\s]{1,30}$/.test(str(data.account_name))) {
                throw new Error('account_name must be letters/spaces only (max 30)');
            }
            if (!/^[0-9]+$/.test(str(data.account_number))) {
                throw new Error('account_number must be digits only');
            }
            if (!/^[A-Z]{4}0[A-Z0-9]{6}$/.test(str(data.bank_code))) {
                throw new Error('bank_code (IFSC) is invalid, e.g. BKID0000001');
            }
            break;

        case 'bkash_api_v': // BDT (bKash)
            if (!/^01[0-9]{9}$/.test(str(data.account_number))) {
                throw new Error('account_number must match ^01[0-9]{9}$ (11 digits starting with 01)');
            }
            break;

        case 'nagad_api_v': // BDT (Nagad)
            if (!/^[0-9]{11}$/.test(str(data.account_number))) {
                throw new Error('account_number must be exactly 11 digits');
            }
            break;

        case 'pkr_w': // PKR (bank / EasyPaisa / JazzCash via CNIC)
            if (!/^[0-9]{9,17}$/.test(str(data.account_number))) {
                throw new Error('account_number must be 9-17 digits (CNIC for EasyPaisa/JazzCash, else bank account)');
            }
            if (!/^[A-Za-z0-9\s)(–-]{2,67}$/.test(str(data.bank_name))) {
                throw new Error('bank_name is invalid (2-67 chars)');
            }
            if (!/^03[0-9]{9}$/.test(str(data.phone_number))) {
                throw new Error('phone_number must be 11 digits starting with 03');
            }
            break;

        case 'esewa_p2p': // NPR — phone OR bank variant
            if (data.payment_method === 'phone') {
                if (!/^[0-9]{10}$/.test(str(data.phone_number))) {
                    throw new Error('phone_number must be exactly 10 digits');
                }
            } else if (data.payment_method === 'bank') {
                if (!/^[a-zA-Z.& -]{1,100}$/.test(str(data.bank_name))) {
                    throw new Error('bank_name is invalid (1-100 chars: letters, space, . & -)');
                }
                if (!/^[0-9]{10}$/.test(str(data.phone_number))) {
                    throw new Error('phone_number must be exactly 10 digits');
                }
            } else {
                throw new Error('payment_method must be "phone" or "bank"');
            }
            break;

        default:
            break;   // Unknown PS — let A-Pay validate it.
    }
}

class PaymentService {
    constructor(config) {
        this.DEPOSIT_API_KEY = config.DEPOSIT_API_KEY;
        this.WEBHOOK_ACCESS_KEY = config.WEBHOOK_ACCESS_KEY;
        this.WEBHOOK_PRIVATE_KEY = config.WEBHOOK_PRIVATE_KEY;
        this.BASE_URL = config.BASE_URL || 'https://pay-crm.com';
        this.PROJECT_ID = config.PROJECT_ID;
        this.DEFAULT_WEBHOOK_ID = config.DEFAULT_WEBHOOK_ID;
        this.DEFAULT_RETURN_URL = config.DEFAULT_RETURN_URL;
        // 7-digit id for the WITHDRAWAL postback url; unset = project default.
        this.WITHDRAWAL_WEBHOOK_ID = config.WITHDRAWAL_WEBHOOK_ID;
    }

    // Admin-set via PUT /api/admin/config/global { apaynotificationemail }.
    async getNotificationEmail() {
        try {
            const { rows } = await pg.query(
                'SELECT apaynotificationemail FROM siteconfig LIMIT 1'
            );
            return rows[0]?.apaynotificationemail || FALLBACK_NOTIFICATION_EMAIL;
        } catch (err) {
            console.error('Failed to read apaynotificationemail from siteconfig:', err.message);
            return FALLBACK_NOTIFICATION_EMAIL;
        }
    }

    // Fire-and-forget. Never throws — email must not break a payment flow.
    notifyAdmin(subject, contentHtml) {
        this.getNotificationEmail()
            .then(to => emailService.sendGeneralEmail(to, subject, {
                title: subject,
                content: contentHtml,
            }))
            .catch(err => console.error('Admin notify failed:', err.message));
    }

    // Renders a labeled key/value table for the email body.
    static renderDetailsTable(rows) {
        const cells = rows
            .filter(([, v]) => v !== undefined && v !== null && v !== '')
            .map(([k, v]) => `
                <tr>
                    <td style="padding:6px 12px;border:1px solid #e2e8f0;background:#f8fafc;font-weight:600;">${k}</td>
                    <td style="padding:6px 12px;border:1px solid #e2e8f0;">${v}</td>
                </tr>
            `).join('');
        return `<table style="border-collapse:collapse;width:100%;font-size:14px;">${cells}</table>`;
    }

    // Signature generation for webhook verification
   
    generateWebhookSignature(transactions) {
        // Use JSON.stringify with specific options to match PHP's JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
        const transactionsJson = JSON.stringify(transactions, null, 0)
            .replace(/\\"/g, '"')  // Remove escaped quotes
            .replace(/\\\//g, '/');  // Remove escaped slashes
    
        const md5Transactions = crypto
            .createHash('md5')
            .update(transactionsJson)
            .digest('hex');
        
        return crypto
            .createHash('sha1')
            .update(`${this.WEBHOOK_ACCESS_KEY}${this.WEBHOOK_PRIVATE_KEY}${md5Transactions}`)
            .digest('hex');
    }

    // Payment systems A-Pay has enabled for this project, cached 5 min.
    // force=true skips the cache — used by the admin overview's Refresh.
    async fetchPaymentSystems(force = false) {
        const key = `${this.BASE_URL}|${this.PROJECT_ID}`;
        const cached = psCache.get(key);
        if (!force && cached && (Date.now() - cached.at) < PS_CACHE_TTL_MS) {
            return cached.systems;
        }

        try {
            const response = await axios.get(`${this.BASE_URL}/Remotes/payment-systems-info`, {
                params: { project_id: Number(this.PROJECT_ID) },
                headers: { apikey: this.DEPOSIT_API_KEY },
                timeout: 10000,
            });
            if (!response.data?.success || !Array.isArray(response.data.payment_systems)) {
                throw new Error(response.data?.message || 'payment-systems-info returned no list');
            }
            psCache.set(key, { at: Date.now(), systems: response.data.payment_systems });
            return response.data.payment_systems;
        } catch (err) {
            console.error('payment-systems-info failed:', err.message);
            // A stale list still works; without one there is nothing to offer.
            return cached ? cached.systems : [];
        }
    }

    // TRUE once the user has at least one Success gateway deposit — the
    // "trusted player" test Paykassma's FTD rule needs. Unknown/missing user
    // counts as FTD, which only ever hides methods, never exposes them.
    async hasSuccessfulDeposit(userId) {
        if (userId === undefined || userId === null || userId === '') return false;
        try {
            const { rows } = await pg.query(
                `SELECT 1 FROM apaydeposits WHERE user_id = $1 AND status = 'Success' LIMIT 1`,
                [userId]
            );
            return rows.length > 0;
        } catch (err) {
            console.error('hasSuccessfulDeposit failed:', err.message);
            return false;   // fail closed — treat as FTD
        }
    }

    // Deposit methods enabled for one currency, with that method's limits.
    // userId is optional; without it FTD-restricted methods are hidden.
    async getPaymentMethods(currency, userId) {
        const cur = String(currency || '').toUpperCase();
        const systems = await this.fetchPaymentSystems();

        let list = systems
            .filter(ps => ps.deposit && String(ps.currency || '').toUpperCase() === cur)
            .filter(ps => !DEPOSIT_HIDDEN_SYSTEMS.includes(ps.name));

        if (list.some(ps => FTD_RESTRICTED_SYSTEMS.includes(ps.name))) {
            const trusted = await this.hasSuccessfulDeposit(userId);
            if (!trusted) {
                list = list.filter(ps => !FTD_RESTRICTED_SYSTEMS.includes(ps.name));
            }
        }

        return list
            .map(ps => ({
                name: ps.name,
                label: PAYMENT_SYSTEM_LABELS[ps.name] || ps.name,
                currency: cur,
                min: Number(ps.min_deposit) || 0,
                max: Number(ps.max_deposit) || 0,
            }))
            .sort((a, b) => a.min - b.min);
    }

    // Everything A-Pay currently has for this project, grouped per currency in
    // the order the business talks about them (INR, PKR, NPR, BDT), each
    // currency's methods in A-Pay's own sequence. Overlaid with OUR policy so
    // the admin page shows not just what the gateway enables but what the site
    // actually offers and why. Read-only — feeds the admin "Payment Methods"
    // page.
    async getPaymentSystemsOverview(force = false) {
        const CURRENCY_ORDER = ['INR', 'PKR', 'NPR', 'BDT'];
        const systems = await this.fetchPaymentSystems(force);
        const key = `${this.BASE_URL}|${this.PROJECT_ID}`;
        const cached = psCache.get(key);

        const currencies = CURRENCY_ORDER.map(cur => {
            const list = systems.filter(ps => String(ps.currency || '').toUpperCase() === cur);
            return {
                currency: cur,
                methods: list.map(ps => {
                    const hidden = DEPOSIT_HIDDEN_SYSTEMS.includes(ps.name);
                    const ftd = FTD_RESTRICTED_SYSTEMS.includes(ps.name);
                    return {
                        name: ps.name,
                        label: PAYMENT_SYSTEM_LABELS[ps.name] || ps.name,
                        deposit: {
                            gateway_enabled: Boolean(ps.deposit),
                            // What the player can actually see on the site.
                            site_offered: Boolean(ps.deposit) && !hidden,
                            min: Number(ps.min_deposit) || 0,
                            max: Number(ps.max_deposit) || 0,
                        },
                        withdrawal: {
                            gateway_enabled: Boolean(ps.withdrawal),
                            min: Number(ps.min_withdrawals) || 0,
                            max: Number(ps.max_withdrawals) || 0,
                        },
                        notes: [
                            hidden ? 'Hidden on site — used as withdrawal channel (Paykassma)' : null,
                            ftd ? 'FTD-restricted — only users with a successful deposit see it' : null,
                        ].filter(Boolean),
                    };
                }),
            };
        });

        // Any currency A-Pay adds that we don't order explicitly still shows, last.
        const extras = [...new Set(systems
            .map(ps => String(ps.currency || '').toUpperCase())
            .filter(c => c && !CURRENCY_ORDER.includes(c)))];
        for (const cur of extras) {
            currencies.push({
                currency: cur,
                methods: systems
                    .filter(ps => String(ps.currency || '').toUpperCase() === cur)
                    .map(ps => ({
                        name: ps.name,
                        label: PAYMENT_SYSTEM_LABELS[ps.name] || ps.name,
                        deposit: {
                            gateway_enabled: Boolean(ps.deposit),
                            site_offered: Boolean(ps.deposit) && !DEPOSIT_HIDDEN_SYSTEMS.includes(ps.name),
                            min: Number(ps.min_deposit) || 0,
                            max: Number(ps.max_deposit) || 0,
                        },
                        withdrawal: {
                            gateway_enabled: Boolean(ps.withdrawal),
                            min: Number(ps.min_withdrawals) || 0,
                            max: Number(ps.max_withdrawals) || 0,
                        },
                        notes: [],
                    })),
            });
        }

        return {
            success: true,
            project_id: this.PROJECT_ID,
            fetched_at: cached ? new Date(cached.at).toISOString() : null,
            cache_age_seconds: cached ? Math.round((Date.now() - cached.at) / 1000) : null,
            currencies,
        };
    }

    async createDeposit(depositData) {
        try {
            // payment_system is optional — unset picks the first enabled method.
            const requiredFields = ['amount', 'currency', 'custom_user_id'];
            requiredFields.forEach(field => {
                if (!depositData[field]) {
                    throw new Error(`Missing required field: ${field}`);
                }
            });

            const currency = String(depositData.currency || '').toUpperCase();

            // Only a payment_system A-Pay has enabled for this currency —
            // filtered by the same hidden/FTD rules the method list applies,
            // so a hand-crafted request can't reach imps or upi_fast_v either.
            const methods = await this.getPaymentMethods(currency, depositData.custom_user_id);
            const method = depositData.payment_system
                ? methods.find(m => m.name === depositData.payment_system)
                : methods[0];
            if (!method) {
                throw new Error(`No payment method available for ${currency}`);
            }
            const paymentSystem = method.name;

            const amount = Number(depositData.amount);
            if (!Number.isFinite(amount) || amount <= 0) {
                throw new Error('Invalid amount');
            }
            if (amount < method.min || (method.max && amount > method.max)) {
                throw new Error(`${method.label} accepts ${method.min} - ${method.max} ${currency}`);
            }

            const projectId = Number(depositData.project_id || this.PROJECT_ID);
            // Registered with A-Pay support — never taken from the request body.
            const webhookId = Number(this.DEFAULT_WEBHOOK_ID) || 3039314;

            const payload = {
                amount: String(amount),
                currency,
                payment_system: paymentSystem,
                custom_transaction_id: depositData.custom_transaction_id || `TX_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`,
                custom_user_id: depositData.custom_user_id,
                return_url: depositData.return_url || this.DEFAULT_RETURN_URL,
                language: "EN",
                webhook_id: webhookId,
                // project_id: projectId
            };

            console.log('Deposit request payload:', payload);
            const response = await axios.post(
                `${this.BASE_URL}/Remotes/create-payment-page`, 
                payload,
                {
                    headers: {
                        'apikey': this.DEPOSIT_API_KEY
                    }
                }
            );

            if (response.data.success) {
                // Store deposit in database
                const createQuery = `
                    INSERT INTO apaydeposits
                    (order_id, user_id, amount, currency, payment_system,
                     custom_transaction_id, status, payment_details)
                    VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
                    ON CONFLICT (order_id) DO UPDATE SET
                        status = EXCLUDED.status,
                        payment_details = EXCLUDED.payment_details,
                        updated_at = CURRENT_TIMESTAMP
                    RETURNING *
                `;
                const values = [
                    response.data.order_id,
                    depositData.custom_user_id,
                    amount,
                    currency,
                    paymentSystem,
                    payload.custom_transaction_id,
                    'Pending',
                    JSON.stringify(response.data || {})
                ];

                await pg.query(createQuery, values);

                // Notify admin: deposit request created (Pending).
                this.notifyAdmin(
                    `Deposit request created — ${currency} ${amount}`,
                    PaymentService.renderDetailsTable([
                        ['Status', 'Pending (request created)'],
                        ['User ID', depositData.custom_user_id],
                        ['Amount', `${amount} ${currency}`],
                        ['Currency', currency],
                        ['Payment system', paymentSystem],
                        ['Order ID', response.data.order_id],
                        ['Custom transaction ID', payload.custom_transaction_id],
                        ['Project ID', projectId],
                        ['Created at', new Date().toISOString()],
                    ])
                );

                return response.data;
            } else {
                // Handle failed deposit
                const failedQuery = `
                    INSERT INTO apaydeposits 
                    (order_id, user_id, amount, currency, payment_system, 
                     custom_transaction_id, status, error_reason)
                    VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
                `;
                const failedValues = [
                    crypto.randomBytes(16).toString('hex'),
                    depositData.custom_user_id,
                    amount,
                    currency,
                    paymentSystem,
                    payload.custom_transaction_id,
                    'Failed',
                    response.data.message || 'Unknown error'
                ];
                await pg.query(failedQuery, failedValues);

                // Notify admin: gateway rejected the deposit creation outright.
                this.notifyAdmin(
                    `Deposit request FAILED — ${currency} ${amount}`,
                    PaymentService.renderDetailsTable([
                        ['Status', 'Failed (gateway rejected creation)'],
                        ['Reason', response.data.message || 'Unknown error'],
                        ['User ID', depositData.custom_user_id],
                        ['Amount', `${amount} ${currency}`],
                        ['Currency', currency],
                        ['Payment system', paymentSystem],
                        ['Custom transaction ID', payload.custom_transaction_id],
                        ['Project ID', projectId],
                        ['Failed at', new Date().toISOString()],
                    ])
                );

                throw new Error(response.data.message || 'Deposit request failed');
            }
        } catch (error) {
            console.error('Deposit creation error:', {
                message: error.message,
                status: error.response?.status,
                response: error.response?.data || null
            });

            const gatewayMessage = error.response?.data?.message || error.response?.data?.error;
            if (gatewayMessage) {
                throw new Error(gatewayMessage);
            }

            throw error;
        }
    }

    async getDepositInfo(orderId) {
        try {
            const response = await axios.get(`${this.BASE_URL}/Remotes/deposit-info`, {
                params: {
                    project_id: this.PROJECT_ID,
                    order_id: orderId
                },
                headers: {
                    'apikey': this.DEPOSIT_API_KEY
                }
            });

            return response.data;
        } catch (error) {
            console.error('Deposit info retrieval error:', error);
            throw error;
        }
    }

    async processWebhook(webhookData) {
        try {
            const { access_key, signature, transactions } = webhookData;
            console.log(webhookData);
            // Validate access key
            if (access_key !== this.WEBHOOK_ACCESS_KEY) {
                throw new Error('Invalid webhook access key');
            }

            // Verify webhook signature with precise matching
            const expectedSignature = this.generateWebhookSignature(transactions);
            if (signature !== expectedSignature) {
                console.error('Signature Mismatch', {
                    received: signature,
                    expected: expectedSignature
                });
                throw new Error('Invalid webhook signature');
            }

            // Transaction processing logic remains the same
            for (const transaction of transactions) {
                const { order_id, status, amount, custom_user_id, currency, custom_transaction_id, payment_system } = transaction;

                // Update deposit status; on Success also store the amount the
                // user actually paid (postback amount, may differ from requested).
               const response= await this.updateDepositStatus(order_id, status, webhookData,status === 'Success' ? amount : undefined);

                // Handle transaction based on status
                if (status === 'Success' && response==true) {
                    await this.creditUserBalance(custom_user_id, amount, currency);

                    this.notifyAdmin(
                        `Deposit SUCCESS — ${currency} ${amount}`,
                        PaymentService.renderDetailsTable([
                            ['Status', 'Success (credited)'],
                            ['User ID', custom_user_id],
                            ['Amount', `${amount} ${currency}`],
                            ['Currency', currency],
                            ['Payment system', payment_system],
                            ['Order ID', order_id],
                            ['Custom transaction ID', custom_transaction_id],
                            ['Confirmed at', new Date().toISOString()],
                        ])
                    );
                } else if (['Failed', 'Rejected'].includes(status)) {
                    await this.handleFailedTransaction(order_id, status);

                    this.notifyAdmin(
                        `Deposit ${status.toUpperCase()} — ${currency} ${amount}`,
                        PaymentService.renderDetailsTable([
                            ['Status', status],
                            ['User ID', custom_user_id],
                            ['Amount', `${amount} ${currency}`],
                            ['Currency', currency],
                            ['Payment system', payment_system],
                            ['Order ID', order_id],
                            ['Custom transaction ID', custom_transaction_id],
                            ['Failed at', new Date().toISOString()],
                        ])
                    );
                }
            }

            return { status: 'OK' };
        } catch (error) {
            console.error('Webhook processing error:', error);
            throw error;
        }
    }
    async updateDepositStatus(orderId, status, webhookData, paidAmount = 0) {
        const result = await pg.query(`
            UPDATE apaydeposits
            SET status = $1,
                paid_amount = $2,
                updated_at = CURRENT_TIMESTAMP,
                webhook_response = $3
            WHERE order_id = $4
              AND status NOT IN ('Success', 'Failed')
        `, [status, paidAmount, JSON.stringify(webhookData), orderId]);
        return result.rowCount > 0;
    }
    async creditUserBalance(userId, amount, currency) {
        const creditQuery = `
            UPDATE credits
            SET ${currency.toLowerCase()} = COALESCE(${currency.toLowerCase()}, 0) + $1
            WHERE uid = $2
        `;
        await pg.query(creditQuery, [amount, userId]);
    }
    async handleFailedTransaction(orderId, status) {
        const failQuery = `
            UPDATE apaydeposits
            SET status = $1,
                error_reason = $2
            WHERE order_id = $3
        `;
        await pg.query(failQuery, [status, 'Payment gateway rejection', orderId]);
    }

    // ------------------------------------------------------------------
    // Unattempted deposits — user opened the payment page and left without
    // paying. A-Pay sends no postback for that, so we detect it ourselves:
    // the frontend pings /deposit-return when the player lands back on the
    // site, and a cron sweeper catches players who never come back at all.
    // Both funnel through resolveDepositReturn(), which asks A-Pay's
    // GET /Remotes/deposit-info for the truth before deciding.
    // ------------------------------------------------------------------

    // Idempotent — run at boot. Also filed as system/migrations/apaydeposits_unattempted.sql.
    async ensureUnattemptSchema() {
        await pg.query(
            `ALTER TABLE apaydeposits ADD COLUMN IF NOT EXISTS unattempt_notified boolean NOT NULL DEFAULT false`
        );
        await pg.query(
            `CREATE INDEX IF NOT EXISTS idx_apaydeposits_pending_sweep
                ON apaydeposits (created_at)
                WHERE status = 'Pending' AND unattempt_notified = false`
        );
    }

    // Claims the row atomically (status still Pending, not yet notified) so the
    // return endpoint, the sweeper, and clustered pm2 workers can all race —
    // exactly one of them sends the email. A webhook arriving later simply
    // overwrites the status again and the normal Success/Failed path runs.
    async markUnattempted(orderId, trigger) {
        const { rows } = await pg.query(
            `UPDATE apaydeposits
                SET status = 'Unattempted',
                    unattempt_notified = TRUE,
                    error_reason = COALESCE(error_reason, 'User did not complete the payment'),
                    updated_at = CURRENT_TIMESTAMP
              WHERE order_id = $1 AND status = 'Pending' AND unattempt_notified = FALSE
              RETURNING user_id, amount, currency, payment_system, custom_transaction_id, created_at`,
            [orderId]
        );
        if (rows.length === 0) return false;   // someone else claimed it, or status moved on

        const row = rows[0];
        this.notifyAdmin(
            `Unattempt Payment — ${row.currency} ${row.amount}`,
            PaymentService.renderDetailsTable([
                ['Status', 'Unattempted — user did not deposit the amount'],
                ['Detected by', trigger],
                ['User ID', row.user_id],
                ['Amount', `${row.amount} ${row.currency}`],
                ['Payment system', row.payment_system],
                ['Order ID', orderId],
                ['Custom transaction ID', row.custom_transaction_id],
                ['Requested at', row.created_at ? new Date(row.created_at).toISOString() : ''],
                ['Detected at', new Date().toISOString()],
                ['Note', 'If the user completes this payment later, a normal Deposit SUCCESS email will follow.'],
            ])
        );
        return true;
    }

    // One order: confirm with A-Pay deposit-info, then either let the normal
    // Failed path run, flag a missed Success, or mark it Unattempted.
    // Returns the final status string for the caller (frontend toast).
    async resolveDepositReturn(orderId, trigger) {
        const { rows } = await pg.query(
            `SELECT order_id, status FROM apaydeposits WHERE order_id = $1`,
            [orderId]
        );
        if (rows.length === 0) throw new Error('Unknown order_id');

        // Webhook already decided — nothing to detect.
        if (rows[0].status !== 'Pending') return rows[0].status;

        // Ask A-Pay before declaring anything — the postback may simply not
        // have arrived yet. On a network error info stays null and the deposit
        // is treated as still-Pending.
        let info = null;
        try {
            info = await this.getDepositInfo(orderId);
        } catch (err) {
            console.error(`deposit-info failed for ${orderId}:`, err.message);
        }

        if (info?.status === 'Success') {
            // Paid, but our webhook hasn't credited yet (or was missed).
            // updateDepositStatus's NOT IN ('Success','Failed') guard makes this
            // idempotent: whichever of poll/webhook lands first gets true and
            // credits; the other gets false and skips. paid_amount = info.amount.
            const updated = await this.updateDepositStatus(orderId, 'Success', { source: 'deposit-info poll', info }, info.amount);
            if (updated) {
                await this.creditUserBalance(info.custom_user_id, info.amount, info.currency);
            }
            this.notifyAdmin(
                `Deposit SUCCESS (via poll) — ${info.currency} ${info.amount}`,
                PaymentService.renderDetailsTable([
                    ['Status', updated
                        ? 'Success reported by deposit-info — credited'
                        : 'Success reported by deposit-info — already processed, no double credit'],
                    ['User ID', info.custom_user_id],
                    ['Amount', `${info.amount} ${info.currency}`],
                    ['Payment system', info.payment_system],
                    ['Order ID', orderId],
                    ['Detected at', new Date().toISOString()],
                ])
            );
            return 'Success';
        }

        if (info && ['Failed', 'Rejected'].includes(info.status)) {
            // A real payment problem — keep the existing failed-payment email,
            // exactly as the webhook path words it.
            await this.handleFailedTransaction(orderId, info.status);
            this.notifyAdmin(
                `Deposit ${info.status.toUpperCase()} — ${info.currency} ${info.amount}`,
                PaymentService.renderDetailsTable([
                    ['Status', info.status],
                    ['User ID', info.custom_user_id],
                    ['Amount', `${info.amount} ${info.currency}`],
                    ['Currency', info.currency],
                    ['Payment system', info.payment_system],
                    ['Order ID', orderId],
                    ['Failed at', new Date().toISOString()],
                ])
            );
            return info.status;
        }

        // Still Pending at the gateway too — the user generated the QR / page
        // and walked away without paying.
        await this.markUnattempted(orderId, trigger);
        return 'Unattempted';
    }

    // Cron sweep: Pending deposits past the grace period whose player never
    // returned to the site (closed the tab, killed the app).
    async sweepUnattemptedDeposits() {
        // Rows older than a day are retired QUIETLY — an email about a deposit
        // abandoned yesterday is noise, and after downtime (or on the first
        // deploy of this feature) the backlog would otherwise flood the admin
        // inbox 50 emails per tick.
        await pg.query(
            `UPDATE apaydeposits
                SET status = 'Unattempted',
                    unattempt_notified = TRUE,
                    error_reason = COALESCE(error_reason, 'User did not complete the payment'),
                    updated_at = CURRENT_TIMESTAMP
              WHERE status = 'Pending' AND unattempt_notified = FALSE
                AND created_at < NOW() - INTERVAL '24 hours'`
        );

        const { rows } = await pg.query(
            `SELECT order_id FROM apaydeposits
              WHERE status = 'Pending' AND unattempt_notified = FALSE
                AND created_at < NOW() - INTERVAL '${UNATTEMPTED_AFTER_MINUTES} minutes'
              ORDER BY created_at ASC
              LIMIT 50`
        );
        for (const { order_id } of rows) {
            try {
                await this.resolveDepositReturn(order_id, `No payment within ${UNATTEMPTED_AFTER_MINUTES} minutes (sweeper)`);
            } catch (err) {
                console.error(`Unattempted sweep failed for ${order_id}:`, err.message);
            }
        }
        return rows.length;
    }

    // Auto payout — validate, hold balance, send, refund on failure. README §4.
    async createWithdrawal(withdrawalData) {
        // 1) Validate
        const requiredFields = ['amount', 'currency', 'custom_user_id'];
        requiredFields.forEach(field => {
            if (!withdrawalData[field]) {
                throw new Error(`Missing required field: ${field}`);
            }
        });

        const currency = String(withdrawalData.currency || '').toUpperCase();
        if (!WITHDRAWAL_PAYMENT_SYSTEMS[currency]) {
            throw new Error(`Unsupported currency: ${currency}. Supported: ${Object.keys(WITHDRAWAL_PAYMENT_SYSTEMS).join(', ')}`);
        }

        const amount = Number(withdrawalData.amount);
        if (!Number.isFinite(amount) || amount <= 0) {
            throw new Error('Invalid amount');
        }

        // Payout destination — fields depend on the PS, passed through as-is.
        const payoutData = withdrawalData.data;
        if (!payoutData || typeof payoutData !== 'object' || Object.keys(payoutData).length === 0) {
            throw new Error('Payout details (data) are required for withdrawal');
        }

        const userId = withdrawalData.custom_user_id;
        const paymentSystem = withdrawalData.payment_system || WITHDRAWAL_PAYMENT_SYSTEMS[currency];

        await assertWithdrawalAllowed(userId, { amount, currency });

        // Validate payout fields BEFORE holding any balance — fail fast on bad input.
        try {
            validateWithdrawalData(paymentSystem, payoutData);
        } catch (e) {
            throw new Error(`Invalid payout details for ${paymentSystem}: ${e.message}`);
        }

        // Safe column name: `currency` is a validated key of WITHDRAWAL_PAYMENT_SYSTEMS.
        const col = currency.toLowerCase();
        const customTxnId = withdrawalData.custom_transaction_id
            || `WD_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;

        // 2) Check + hold under a row lock, so concurrent payouts can't overdraw.
        await withTransaction(async (client) => {
            const bal = await client.query(
                `SELECT COALESCE(${col}, 0) AS balance FROM credits WHERE uid = $1 FOR UPDATE`,
                [userId]
            );
            if (bal.rows.length === 0) throw new Error('User not found');
            if (Number(bal.rows[0].balance) < amount) throw new Error('Insufficient balance');

            await client.query(
                `UPDATE credits SET ${col} = COALESCE(${col}, 0) - $1 WHERE uid = $2`,
                [amount, userId]
            );
        });

        // 3) Send to A-Pay. On ANY failure, refund the hold so the user isn't debited.
        let response;
        let payload;
        try {
            payload = {
                amount: String(amount),
                currency,
                payment_system: paymentSystem,
                custom_transaction_id: customTxnId,
                custom_user_id: userId,
                data: payoutData,
            };
            if (this.WITHDRAWAL_WEBHOOK_ID) {
                payload.webhook_id = this.WITHDRAWAL_WEBHOOK_ID;
            }

            console.log('Withdrawal request payload:', payload);
            response = await axios.post(
                `${this.BASE_URL}/Remotes/create-withdrawal`,
                payload,
                {
                    params: { project_id: Number(this.PROJECT_ID) },
                    headers: { apikey: this.DEPOSIT_API_KEY },
                }
            );
        } catch (error) {
            await this.refundBalance(userId, amount, currency);
            const msg = error.response?.data?.message || error.response?.data?.error || error.message;
            // Simple, screenshot-friendly error log: message + payload + A-Pay response.
            console.error('\n========== A-PAY WITHDRAWAL FAILED (gateway error) ==========');
            console.error('Message  :', msg);
            console.error('Payload  :', JSON.stringify(payload, null, 2));
            console.error('Response :', JSON.stringify(error.response?.data || null, null, 2));
            console.error('=============================================================\n');
            await this.recordFailedWithdrawal(userId, amount, currency, paymentSystem, customTxnId, payoutData, msg, error.response?.data?.order_id);
            this.notifyAdmin(
                `Withdrawal request FAILED — ${currency} ${amount}`,
                PaymentService.renderDetailsTable([
                    ['Status', 'Failed (gateway error — balance refunded)'],
                    ['Reason', msg],
                    ['User ID', userId],
                    ['Amount', `${amount} ${currency}`],
                    ['Payment system', paymentSystem],
                    ['Custom transaction ID', customTxnId],
                    ['Failed at', new Date().toISOString()],
                ])
            );
            throw new Error(msg);
        }

        if (!response.data?.success) {
            await this.refundBalance(userId, amount, currency);
            const msg = response.data?.message || 'Withdrawal request failed';
            // Simple, screenshot-friendly error log: message + payload + A-Pay response.
            console.error('\n========== A-PAY WITHDRAWAL FAILED (gateway rejected) ==========');
            console.error('Message  :', msg);
            console.error('Payload  :', JSON.stringify(payload, null, 2));
            console.error('Response :', JSON.stringify(response.data || null, null, 2));
            console.error('===============================================================\n');
            await this.recordFailedWithdrawal(userId, amount, currency, paymentSystem, customTxnId, payoutData, msg, response.data?.order_id);
            this.notifyAdmin(
                `Withdrawal request FAILED — ${currency} ${amount}`,
                PaymentService.renderDetailsTable([
                    ['Status', 'Failed (gateway rejected — balance refunded)'],
                    ['Reason', msg],
                    ['User ID', userId],
                    ['Amount', `${amount} ${currency}`],
                    ['Payment system', paymentSystem],
                    ['Custom transaction ID', customTxnId],
                    ['Failed at', new Date().toISOString()],
                ])
            );
            throw new Error(msg);
        }

        // 4) Accepted — store Pending. Balance stays held until the postback decides.
        await pg.query(
            `INSERT INTO apaywithdrawals
                (order_id, user_id, amount, currency, payment_system,
                 custom_transaction_id, status, payout_details, payment_details)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
             ON CONFLICT (order_id) DO UPDATE SET
                status = EXCLUDED.status,
                payment_details = EXCLUDED.payment_details,
                updated_at = CURRENT_TIMESTAMP`,
            [
                response.data.order_id,
                userId,
                amount,
                currency,
                paymentSystem,
                customTxnId,
                'Pending',
                JSON.stringify(payoutData),
                JSON.stringify(response.data || {}),
            ]
        );

        this.notifyAdmin(
            `Withdrawal request created — ${currency} ${amount}`,
            PaymentService.renderDetailsTable([
                ['Status', 'Pending (sent to gateway — balance held)'],
                ['User ID', userId],
                ['Amount', `${amount} ${currency}`],
                ['Payment system', paymentSystem],
                ['Order ID', response.data.order_id],
                ['Custom transaction ID', customTxnId],
                ['Created at', new Date().toISOString()],
            ])
        );

        return response.data;
    }

    // Audit row for a synchronous rejection — caller already refunded.
    async recordFailedWithdrawal(userId, amount, currency, paymentSystem, customTxnId, payoutData, reason, orderId) {
        try {
            await pg.query(
                `INSERT INTO apaywithdrawals
                    (order_id, user_id, amount, currency, payment_system,
                     custom_transaction_id, status, payout_details, error_reason, refunded)
                 VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, TRUE)
                 ON CONFLICT (order_id) DO NOTHING`,
                [
                    orderId || crypto.randomBytes(16).toString('hex'),
                    userId,
                    amount,
                    currency,
                    paymentSystem,
                    customTxnId,
                    'Failed',
                    JSON.stringify(payoutData || {}),
                    reason,
                ]
            );
        } catch (err) {
            console.error('Failed to record failed withdrawal:', err.message);
        }
    }

    async processWithdrawalWebhook(webhookData) {
        const { access_key, signature, transactions } = webhookData;

        // Clear marker so it's obvious in logs when A-Pay hits the withdrawal webhook.
        console.log('\n########## WITHDRAWAL WEBHOOK HIT ##########');
        console.log('Time      :', new Date().toISOString());
        console.log('Body      :', JSON.stringify(webhookData, null, 2));
        console.log('Statuses  :', (transactions || []).map(t => `${t.order_id}=${t.status}`).join(', '));
        console.log('###########################################\n');

        try {
        // Same auth + signature scheme as deposit (A-Pay uses one signing formula).
        if (access_key !== this.WEBHOOK_ACCESS_KEY) {
            throw new Error('Invalid webhook access key');
        }
        const expectedSignature = this.generateWebhookSignature(transactions);
        if (signature !== expectedSignature) {
            console.error('Withdrawal signature mismatch', { received: signature, expected: expectedSignature });
            throw new Error('Invalid webhook signature');
        }

        for (const transaction of transactions) {
            const { order_id, status, amount, custom_user_id, currency, custom_transaction_id, payment_system } = transaction;

            await pg.query(
                `UPDATE apaywithdrawals
                    SET status = $1, webhook_response = $2, updated_at = CURRENT_TIMESTAMP
                  WHERE order_id = $3`,
                [status, JSON.stringify(webhookData), order_id]
            );

            if (status === 'Success') {
                // Balance was already debited at request time — nothing to credit.
                this.notifyAdmin(
                    `Withdrawal SUCCESS — ${currency} ${amount}`,
                    PaymentService.renderDetailsTable([
                        ['Status', 'Success (paid out)'],
                        ['User ID', custom_user_id],
                        ['Amount', `${amount} ${currency}`],
                        ['Payment system', payment_system],
                        ['Order ID', order_id],
                        ['Custom transaction ID', custom_transaction_id],
                        ['Confirmed at', new Date().toISOString()],
                    ])
                );
            } else if (['Failed', 'Rejected'].includes(status)) {
                const refunded = await this.refundWithdrawalOnce(order_id);
                this.notifyAdmin(
                    `Withdrawal ${status.toUpperCase()} — ${currency} ${amount}`,
                    PaymentService.renderDetailsTable([
                        ['Status', `${status}${refunded ? ' (balance refunded)' : ' (already refunded / no record)'}`],
                        ['User ID', custom_user_id],
                        ['Amount', `${amount} ${currency}`],
                        ['Payment system', payment_system],
                        ['Order ID', order_id],
                        ['Custom transaction ID', custom_transaction_id],
                        ['Failed at', new Date().toISOString()],
                    ])
                );
                void refunded;
            }
        }

        return { status: 'OK' };
        } catch (err) {
            // Keep the error visible on the row, then re-throw so A-Pay retries.
            await this.saveWebhookError(transactions, err.message, webhookData);
            throw err;
        }
    }

    // Records the error on still-Pending rows without changing status.
    async saveWebhookError(transactions, errorMessage, webhookData) {
        try {
            const orderIds = (transactions || []).map(t => t && t.order_id).filter(Boolean);
            for (const orderId of orderIds) {
                await pg.query(
                    `UPDATE apaywithdrawals
                        SET error_reason = $1, webhook_response = $2, updated_at = CURRENT_TIMESTAMP
                      WHERE order_id = $3 AND status = 'Pending'`,
                    [`Webhook error: ${errorMessage}`, JSON.stringify(webhookData), orderId]
                );
            }
        } catch (e) {
            console.error('Failed to save webhook error to row:', e.message);
        }
    }

    // Refunds a held withdrawal exactly once — see README §4.
    async refundWithdrawalOnce(orderId) {
        return withTransaction(async (client) => {
            const res = await client.query(
                `SELECT user_id, amount, currency, refunded
                   FROM apaywithdrawals WHERE order_id = $1 FOR UPDATE`,
                [orderId]
            );
            if (res.rows.length === 0) return false;   // no such withdrawal
            const row = res.rows[0];
            if (row.refunded) return false;            // already refunded earlier

            const cur = String(row.currency || '').toUpperCase();
            if (!WITHDRAWAL_PAYMENT_SYSTEMS[cur]) {
                console.error(`Refund skipped — unknown currency "${row.currency}" for order ${orderId}`);
                return false;
            }
            const col = cur.toLowerCase();

            await client.query(
                `UPDATE credits SET ${col} = COALESCE(${col}, 0) + $1 WHERE uid = $2`,
                [row.amount, row.user_id]
            );
            await client.query(
                `UPDATE apaywithdrawals SET refunded = TRUE, updated_at = CURRENT_TIMESTAMP WHERE order_id = $1`,
                [orderId]
            );
            return true;
        });
    }

    // Currency is whitelisted before the column name is built (no injection).
    async refundBalance(userId, amount, currency) {
        const cur = String(currency || '').toUpperCase();
        if (!WITHDRAWAL_PAYMENT_SYSTEMS[cur]) {
            console.error(`Refund skipped — unknown currency "${currency}" for user ${userId}`);
            return;
        }
        const col = cur.toLowerCase();
        await pg.query(
            `UPDATE credits SET ${col} = COALESCE(${col}, 0) + $1 WHERE uid = $2`,
            [amount, userId]
        );
    }
}

module.exports = PaymentService;
