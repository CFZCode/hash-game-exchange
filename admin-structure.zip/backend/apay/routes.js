const express = require('express');
const { rejectDemoUser } = require('../system/utils/demoUsers');
const cron = require('node-cron');
const PaymentService = require('./paymentservices');

// DEPOSIT — LIVE credentials. Do not swap while testing withdrawals.
const paymentService = new PaymentService({
    DEPOSIT_API_KEY: 'REMOVED_SECRET',
    WEBHOOK_ACCESS_KEY: 'REMOVED_SECRET',
    WEBHOOK_PRIVATE_KEY: 'REMOVED_SECRET',
    PROJECT_ID: '3039314',
    BASE_URL: 'https://pay-crm.com',
    DEFAULT_WEBHOOK_ID: 3039314,
    DEFAULT_RETURN_URL: 'https://example.com'
});

// WITHDRAWAL — same project, separate webhook id. Real money moves.
const withdrawalService = new PaymentService({
    DEPOSIT_API_KEY: 'REMOVED_SECRET',
    WEBHOOK_ACCESS_KEY: 'REMOVED_SECRET',
    WEBHOOK_PRIVATE_KEY: 'REMOVED_SECRET',
    PROJECT_ID: '3039314',
    BASE_URL: 'https://pay-crm.com',
    WITHDRAWAL_WEBHOOK_ID: '9007433'    // prod withdrawal webhook id
});

// TEST credentials — swap into the block above to test against project 6987753.
// DEPOSIT_API_KEY:      'REMOVED_SECRET',
// WEBHOOK_ACCESS_KEY:   'REMOVED_SECRET',
// WEBHOOK_PRIVATE_KEY:  'REMOVED_SECRET',
// PROJECT_ID:           '6987753',
// WITHDRAWAL_WEBHOOK_ID:'7467101'

const router = express.Router();

// Deposit methods A-Pay currently has enabled for a currency — README §2.
// user_id is optional; without it FTD-restricted methods (upi_fast_v) are hidden.
router.get('/payment-methods', async (req, res) => {
    try {
        const { currency, user_id } = req.query;
        if (!currency) {
            return res.status(400).json({ success: false, message: 'currency is required' });
        }

        const methods = await paymentService.getPaymentMethods(currency, user_id);
        res.json({
            success: true,
            currency: String(currency).toUpperCase(),
            methods,
        });
    } catch (error) {
        console.error('payment-methods error:', error.message);
        res.status(400).json({ success: false, message: error.message });
    }
});

// Admin overview: every payment system A-Pay has for this project, all four
// currencies in business order (INR, PKR, NPR, BDT), methods in A-Pay's own
// sequence, overlaid with our site policy (imps hidden, FTD gating).
// ?fresh=1 bypasses the 5-minute cache. Read-only.
router.get('/payment-systems-overview', async (req, res) => {
    try {
        const force = req.query.fresh === '1' || req.query.fresh === 'true';
        const overview = await paymentService.getPaymentSystemsOverview(force);
        res.json(overview);
    } catch (error) {
        console.error('payment-systems-overview error:', error.message);
        res.status(400).json({ success: false, message: error.message });
    }
});

// Create Deposit Endpoint
router.post('/create-deposit', rejectDemoUser, async (req, res) => {
    try {
        const depositResult = await paymentService.createDeposit(req.body);
        res.json(depositResult);
    } catch (error) {
        res.status(400).json({
            success: false,
            message: error.message,
            status: 'Failed',
            code: error.response?.data?.code || 400
        });
    }
});

// Deposit Info Endpoint
router.get('/deposit-info', async (req, res) => {
    try {
        const { order_id } = req.query;
        
        if (!order_id) {
            return res.status(400).json({
                success: false,
                message: 'order_id is required'
            });
        }

        const result = await paymentService.getDepositInfo(order_id);
        res.json(result);
    } catch (error) {
        res.status(400).json({
            success: false,
            message: error.message,
            code: error.response?.data?.code || 400
        });
    }
});

// Player landed back on the site from the A-Pay payment page (return_url or
// the Back button). Confirms the real state with deposit-info: still Pending →
// marked Unattempted + "Unattempt Payment" admin email; Failed/Rejected → the
// usual failed-payment email. Response status drives the frontend toast.
router.post('/deposit-return', async (req, res) => {
    try {
        const { order_id } = req.body;
        if (!order_id) {
            return res.status(400).json({ success: false, message: 'order_id is required' });
        }
        const status = await paymentService.resolveDepositReturn(
            String(order_id),
            'User returned from the payment page without paying'
        );
        res.json({ success: true, status });
    } catch (error) {
        console.error('deposit-return error:', error.message);
        res.status(400).json({ success: false, message: error.message });
    }
});

// Webhook Callback Endpoint
router.post('/webhook', async (req, res) => {
    try {
        const result = await paymentService.processWebhook(req.body);
        res.json(result);
    } catch (error) {
        console.error('Webhook processing error:', error);
        res.status(400).json({
            status: 'Error',
            message: error.message
        });
    }
});

// Body: { amount, currency, custom_user_id, data, payment_system?, custom_transaction_id? }
router.post('/create-withdrawal', async (req, res) => {
    try {
        const result = await withdrawalService.createWithdrawal(req.body);
        res.json(result);
    } catch (error) {
        res.status(400).json({
            success: false,
            message: error.message,
            status: 'Failed',
            code: error.response?.data?.code || 400
        });
    }
});

// Registered with A-Pay as the withdrawal postback url (webhook id 9007433).
router.post('/withdrawal-webhook', async (req, res) => {
    try {
        console.log('>>> /withdrawal-webhook HIT at', new Date().toISOString());
        const result = await withdrawalService.processWithdrawalWebhook(req.body);
        res.json(result);
    } catch (error) {
        console.error('Withdrawal webhook processing error:', error);
        res.status(400).json({
            status: 'Error',
            message: error.message
        });
    }
});

// Unattempted-deposit sweeper: every 5 min, Pending deposits older than the
// grace period with no postback get the "Unattempt Payment" email once.
// Safe under pm2 clustering — markUnattempted() claims each row atomically.
paymentService.ensureUnattemptSchema()
    .then(() => {
        cron.schedule('*/5 * * * *', () => {
            paymentService.sweepUnattemptedDeposits()
                .catch(err => console.error('Unattempted sweep failed:', err.message));
        });
    })
    .catch(err => console.error('Unattempt schema setup failed:', err.message));

module.exports = router;
