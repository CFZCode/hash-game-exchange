const crypto = require('crypto');
const axios = require('axios');
const pg = require('../General/Model');
const emailService = require('../emailservice/controller');
// App-wide shared pool + transaction helper (see General/Model/pool.js).
// Used for withdrawal transactions (BEGIN/COMMIT + SELECT ... FOR UPDATE).
const { withTransaction } = require('../General/Model/pool');

// Fallback used only if the siteconfig row is missing or the column is null.
const FALLBACK_NOTIFICATION_EMAIL = 'salvin.dev.cfz@gmail.com';

const WITHDRAWAL_PAYMENT_SYSTEMS = {
    INR: 'imps',         // data: { account_name, account_number, bank_code (IFSC) }
    BDT: 'bkash_api_v',  // data: { account_number: "01XXXXXXXXX" }  (or nagad_api_v: 11 digits)
    PKR: 'pkr_w',        // data: { account_number(CNIC/acct), bank_name, phone_number(03…) }
    NPR: 'esewa_p2p',    // data: { phone:{...} } OR { bank:{...} }
};

// Validates the payout `data` object against A-Pay's withdrawal schema for each
// payment system, so malformed requests are rejected BEFORE we hold any balance.
// Throws on the first problem; returns silently when valid.
function validateWithdrawalData(paymentSystem, data) {
    const str = (v) => (v === undefined || v === null) ? '' : String(v);
    switch (paymentSystem) {
        case 'imps': // INR
            if (!/^[a-zA-Z\s]{1,30}$/.test(str(data.account_name))) {
                throw new Error('account_name must be letters/spaces only (max 30)');
            }
            if (!/^[0-9]+$/.test(str(data.account_number))) {
                throw new Error('account_number must be digits only');
            }
            if (!/^[A-Z]{4}0[A-Z0-9]{6}$/.test(str(data.bank_code))) {
                throw new Error('bank_code (IFSC) is invalid, e.g. BKID0000001');
            }
            break;

        case 'bkash_api_v': // BDT (bKash)
            if (!/^01[0-9]{9}$/.test(str(data.account_number))) {
                throw new Error('account_number must match ^01[0-9]{9}$ (11 digits starting with 01)');
            }
            break;

        case 'nagad_api_v': // BDT (Nagad)
            if (!/^[0-9]{11}$/.test(str(data.account_number))) {
                throw new Error('account_number must be exactly 11 digits');
            }
            break;

        case 'pkr_w': // PKR (bank / EasyPaisa / JazzCash via CNIC)
            if (!/^[0-9]{9,17}$/.test(str(data.account_number))) {
                throw new Error('account_number must be 9-17 digits (CNIC for EasyPaisa/JazzCash, else bank account)');
            }
            if (!/^[A-Za-z0-9\s)(–-]{2,67}$/.test(str(data.bank_name))) {
                throw new Error('bank_name is invalid (2-67 chars)');
            }
            if (!/^03[0-9]{9}$/.test(str(data.phone_number))) {
                throw new Error('phone_number must be 11 digits starting with 03');
            }
            break;

        case 'esewa_p2p': // NPR — phone OR bank variant
            if (data.payment_method === 'phone') {
                if (!/^[0-9]{10}$/.test(str(data.phone_number))) {
                    throw new Error('phone_number must be exactly 10 digits');
                }
            } else if (data.payment_method === 'bank') {
                if (!/^[a-zA-Z.& -]{1,100}$/.test(str(data.bank_name))) {
                    throw new Error('bank_name is invalid (1-100 chars: letters, space, . & -)');
                }
                if (!/^[0-9]{10}$/.test(str(data.phone_number))) {
                    throw new Error('phone_number must be exactly 10 digits');
                }
            } else {
                throw new Error('payment_method must be "phone" or "bank"');
            }
            break;

        default:
            // Unknown PS — let it pass through (A-Pay will validate). Should not
            // happen since currency→PS is whitelisted above.
            break;
    }
}

class PaymentService {
    constructor(config) {
        this.DEPOSIT_API_KEY = config.DEPOSIT_API_KEY;
        this.WEBHOOK_ACCESS_KEY = config.WEBHOOK_ACCESS_KEY;
        this.WEBHOOK_PRIVATE_KEY = config.WEBHOOK_PRIVATE_KEY;
        this.BASE_URL = config.BASE_URL || 'https://pay-crm.com';
        this.PROJECT_ID = config.PROJECT_ID;
        this.DEFAULT_WEBHOOK_ID = config.DEFAULT_WEBHOOK_ID;
        this.DEFAULT_RETURN_URL = config.DEFAULT_RETURN_URL;
        // Optional: 7-digit webhook id A-Pay support registers for WITHDRAWAL
        // postbacks (separate URL from deposits). If unset, A-Pay uses the
        // project's default webhook url.
        this.WITHDRAWAL_WEBHOOK_ID = config.WITHDRAWAL_WEBHOOK_ID;
    }

    // Reads the admin-configured notification email from siteconfig.
    // Admins can update this via PUT /api/admin/config/global { apaynotificationemail }.
    async getNotificationEmail() {
        try {
            const { rows } = await pg.query(
                'SELECT apaynotificationemail FROM siteconfig LIMIT 1'
            );
            return rows[0]?.apaynotificationemail || FALLBACK_NOTIFICATION_EMAIL;
        } catch (err) {
            console.error('Failed to read apaynotificationemail from siteconfig:', err.message);
            return FALLBACK_NOTIFICATION_EMAIL;
        }
    }

    // Fire-and-forget admin notification. Never throws — email failures must
    // not break the deposit/webhook flow.
    notifyAdmin(subject, contentHtml) {
        this.getNotificationEmail()
            .then(to => emailService.sendGeneralEmail(to, subject, {
                title: subject,
                content: contentHtml,
            }))
            .catch(err => console.error('Admin notify failed:', err.message));
    }

    // Renders a labeled key/value table for the email body.
    static renderDetailsTable(rows) {
        const cells = rows
            .filter(([, v]) => v !== undefined && v !== null && v !== '')
            .map(([k, v]) => `
                <tr>
                    <td style="padding:6px 12px;border:1px solid #e2e8f0;background:#f8fafc;font-weight:600;">${k}</td>
                    <td style="padding:6px 12px;border:1px solid #e2e8f0;">${v}</td>
                </tr>
            `).join('');
        return `<table style="border-collapse:collapse;width:100%;font-size:14px;">${cells}</table>`;
    }

    // Signature generation for webhook verification
   
    generateWebhookSignature(transactions) {
        // Use JSON.stringify with specific options to match PHP's JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
        const transactionsJson = JSON.stringify(transactions, null, 0)
            .replace(/\\"/g, '"')  // Remove escaped quotes
            .replace(/\\\//g, '/');  // Remove escaped slashes
    
        const md5Transactions = crypto
            .createHash('md5')
            .update(transactionsJson)
            .digest('hex');
        
        return crypto
            .createHash('sha1')
            .update(`${this.WEBHOOK_ACCESS_KEY}${this.WEBHOOK_PRIVATE_KEY}${md5Transactions}`)
            .digest('hex');
    }

    async createDeposit(depositData) {
        try {
            // Validate required fields
            const requiredFields = [
                'amount', 'currency', 'payment_system',
                'custom_user_id'
            ];
            requiredFields.forEach(field => {
                if (!depositData[field]) {
                    throw new Error(`Missing required field: ${field}`);
                }
            });

            const currency = String(depositData.currency || '').toUpperCase();
            
            // Verified against the live project via /Remotes/payment-systems-info.
            // NPR only has esewa_p2p enabled (not bare "esewa").
            const CURRENCY_PAYMENT_SYSTEMS = {
                INR: 'phonepe',
                BDT: 'bkash_api_v',
                PKR: 'easypaisa',
                NPR: 'esewa_p2p',
            };
            if (!CURRENCY_PAYMENT_SYSTEMS[currency]) {
                throw new Error(`Unsupported currency: ${currency}. Supported: ${Object.keys(CURRENCY_PAYMENT_SYSTEMS).join(', ')}`);
            }

            const projectId = Number(depositData.project_id || this.PROJECT_ID);
            const webhookId = 3039314;
            const paymentSystem = depositData.payment_system || CURRENCY_PAYMENT_SYSTEMS[currency];

            console.log("project is ",projectId);
            console.log("project webhook is ",webhookId);
            console.log("deposite key ",this.DEPOSIT_API_KEY);
            

            const payload = {
                amount: String(depositData.amount),
                currency,
                payment_system: paymentSystem,
                custom_transaction_id: depositData.custom_transaction_id || `TX_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`,
                custom_user_id: depositData.custom_user_id,
                return_url: depositData.return_url || this.DEFAULT_RETURN_URL,
                language: "EN",
                webhook_id: webhookId,
                // project_id: projectId
            };

            console.log('Deposit request payload:', payload);
            const response = await axios.post(
                `${this.BASE_URL}/Remotes/create-payment-page`, 
                payload,
                {
                    headers: {
                        'apikey': this.DEPOSIT_API_KEY
                    }
                }
            );

            if (response.data.success) {
                // Store deposit in database
                const createQuery = `
                    INSERT INTO apaydeposits
                    (order_id, user_id, amount, currency, payment_system,
                     custom_transaction_id, status, payment_details)
                    VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
                    ON CONFLICT (order_id) DO UPDATE SET
                        status = EXCLUDED.status,
                        payment_details = EXCLUDED.payment_details,
                        updated_at = CURRENT_TIMESTAMP
                    RETURNING *
                `;
                const values = [
                    response.data.order_id,
                    depositData.custom_user_id,
                    depositData.amount,
                    currency,
                    paymentSystem,
                    payload.custom_transaction_id,
                    'Pending',
                    JSON.stringify(response.data || {})
                ];

                await pg.query(createQuery, values);

                // Notify admin: deposit request created (Pending).
                this.notifyAdmin(
                    `Deposit request created — ${currency} ${depositData.amount}`,
                    PaymentService.renderDetailsTable([
                        ['Status', 'Pending (request created)'],
                        ['User ID', depositData.custom_user_id],
                        ['Amount', `${depositData.amount} ${currency}`],
                        ['Currency', currency],
                        ['Payment system', paymentSystem],
                        ['Order ID', response.data.order_id],
                        ['Custom transaction ID', payload.custom_transaction_id],
                        ['Project ID', projectId],
                        ['Created at', new Date().toISOString()],
                    ])
                );

                return response.data;
            } else {
                // Handle failed deposit
                const failedQuery = `
                    INSERT INTO apaydeposits 
                    (order_id, user_id, amount, currency, payment_system, 
                     custom_transaction_id, status, error_reason)
                    VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
                `;
                const failedValues = [
                    crypto.randomBytes(16).toString('hex'),
                    depositData.custom_user_id,
                    depositData.amount,
                    currency,
                    paymentSystem,
                    payload.custom_transaction_id,
                    'Failed',
                    response.data.message || 'Unknown error'
                ];
                await pg.query(failedQuery, failedValues);

                // Notify admin: gateway rejected the deposit creation outright.
                this.notifyAdmin(
                    `Deposit request FAILED — ${currency} ${depositData.amount}`,
                    PaymentService.renderDetailsTable([
                        ['Status', 'Failed (gateway rejected creation)'],
                        ['Reason', response.data.message || 'Unknown error'],
                        ['User ID', depositData.custom_user_id],
                        ['Amount', `${depositData.amount} ${currency}`],
                        ['Currency', currency],
                        ['Payment system', paymentSystem],
                        ['Custom transaction ID', payload.custom_transaction_id],
                        ['Project ID', projectId],
                        ['Failed at', new Date().toISOString()],
                    ])
                );

                throw new Error(response.data.message || 'Deposit request failed');
            }
        } catch (error) {
            console.error('Deposit creation error:', {
                message: error.message,
                status: error.response?.status,
                response: error.response?.data || null
            });

            const gatewayMessage = error.response?.data?.message || error.response?.data?.error;
            if (gatewayMessage) {
                throw new Error(gatewayMessage);
            }

            throw error;
        }
    }

    async getDepositInfo(orderId) {
        try {
            const response = await axios.get(`${this.BASE_URL}/Remotes/deposit-info`, {
                params: {
                    project_id: this.PROJECT_ID,
                    order_id: orderId
                },
                headers: {
                    'apikey': this.DEPOSIT_API_KEY
                }
            });

            return response.data;
        } catch (error) {
            console.error('Deposit info retrieval error:', error);
            throw error;
        }
    }

    async processWebhook(webhookData) {
        try {
            const { access_key, signature, transactions } = webhookData;
            console.log(webhookData);
            // Validate access key
            if (access_key !== this.WEBHOOK_ACCESS_KEY) {
                throw new Error('Invalid webhook access key');
            }

            // Verify webhook signature with precise matching
            const expectedSignature = this.generateWebhookSignature(transactions);
            if (signature !== expectedSignature) {
                console.error('Signature Mismatch', {
                    received: signature,
                    expected: expectedSignature
                });
                throw new Error('Invalid webhook signature');
            }

            // Transaction processing logic remains the same
            for (const transaction of transactions) {
                const { order_id, status, amount, custom_user_id, currency, custom_transaction_id, payment_system } = transaction;

                // Update deposit status
                await this.updateDepositStatus(order_id, status, webhookData);

                // Handle transaction based on status
                if (status === 'Success') {
                    await this.creditUserBalance(custom_user_id, amount, currency);

                    this.notifyAdmin(
                        `Deposit SUCCESS — ${currency} ${amount}`,
                        PaymentService.renderDetailsTable([
                            ['Status', 'Success (credited)'],
                            ['User ID', custom_user_id],
                            ['Amount', `${amount} ${currency}`],
                            ['Currency', currency],
                            ['Payment system', payment_system],
                            ['Order ID', order_id],
                            ['Custom transaction ID', custom_transaction_id],
                            ['Confirmed at', new Date().toISOString()],
                        ])
                    );
                } else if (['Failed', 'Rejected'].includes(status)) {
                    await this.handleFailedTransaction(order_id, status);

                    this.notifyAdmin(
                        `Deposit ${status.toUpperCase()} — ${currency} ${amount}`,
                        PaymentService.renderDetailsTable([
                            ['Status', status],
                            ['User ID', custom_user_id],
                            ['Amount', `${amount} ${currency}`],
                            ['Currency', currency],
                            ['Payment system', payment_system],
                            ['Order ID', order_id],
                            ['Custom transaction ID', custom_transaction_id],
                            ['Failed at', new Date().toISOString()],
                        ])
                    );
                }
            }

            return { status: 'OK' };
        } catch (error) {
            console.error('Webhook processing error:', error);
            throw error;
        }
    }
    async updateDepositStatus(orderId, status, webhookData) {
        const updateQuery = `
            UPDATE apaydeposits 
            SET status = $1, 
                updated_at = CURRENT_TIMESTAMP,
                webhook_response = $2
            WHERE order_id = $3
        `;
        await pg.query(updateQuery, [status, JSON.stringify(webhookData), orderId]);
    }
    async creditUserBalance(userId, amount, currency) {
        const creditQuery = `
            UPDATE credits
            SET ${currency.toLowerCase()} = COALESCE(${currency.toLowerCase()}, 0) + $1
            WHERE uid = $2
        `;
        await pg.query(creditQuery, [amount, userId]);
    }
    async handleFailedTransaction(orderId, status) {
        const failQuery = `
            UPDATE apaydeposits
            SET status = $1,
                error_reason = $2
            WHERE order_id = $3
        `;
        await pg.query(failQuery, [status, 'Payment gateway rejection', orderId]);
    }

    // ──────────────────────────────────────────────────────────────
    // WITHDRAWAL (auto payout) — A-Pay POST /Remotes/create-withdrawal
    //
    // Flow (opposite of deposit — money leaves):
    //   1. Validate currency (INR/BDT/PKR/NPR) + payout details.
    //   2. Atomically check balance and HOLD (deduct) it.
    //   3. Send the payout request to A-Pay. If anything fails → refund the hold.
    //   4. Store the Pending withdrawal. Balance stays held until the postback:
    //        Success            → already debited, nothing to do.
    //        Failed / Rejected  → refund exactly once.
    // ──────────────────────────────────────────────────────────────

    async createWithdrawal(withdrawalData) {
        // 1) Validate
        const requiredFields = ['amount', 'currency', 'custom_user_id'];
        requiredFields.forEach(field => {
            if (!withdrawalData[field]) {
                throw new Error(`Missing required field: ${field}`);
            }
        });

        const currency = String(withdrawalData.currency || '').toUpperCase();
        if (!WITHDRAWAL_PAYMENT_SYSTEMS[currency]) {
            throw new Error(`Unsupported currency: ${currency}. Supported: ${Object.keys(WITHDRAWAL_PAYMENT_SYSTEMS).join(', ')}`);
        }

        const amount = Number(withdrawalData.amount);
        if (!Number.isFinite(amount) || amount <= 0) {
            throw new Error('Invalid amount');
        }

        // Payout destination (bank/UPI/phone). Required — A-Pay rejects without it.
        // Exact fields depend on the payment_system; we pass them through as-is.
        const payoutData = withdrawalData.data;
        if (!payoutData || typeof payoutData !== 'object' || Object.keys(payoutData).length === 0) {
            throw new Error('Payout details (data) are required for withdrawal');
        }

        const userId = withdrawalData.custom_user_id;
        const paymentSystem = withdrawalData.payment_system || WITHDRAWAL_PAYMENT_SYSTEMS[currency];

        // Validate payout fields BEFORE holding any balance — fail fast on bad input.
        try {
            validateWithdrawalData(paymentSystem, payoutData);
        } catch (e) {
            throw new Error(`Invalid payout details for ${paymentSystem}: ${e.message}`);
        }

        // Safe column name: `currency` is a validated key of WITHDRAWAL_PAYMENT_SYSTEMS.
        const col = currency.toLowerCase();
        const customTxnId = withdrawalData.custom_transaction_id
            || `WD_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;

        // 2) Balance check + hold (deduct) inside a transaction with a row lock,
        //    so two concurrent withdrawals can never overdraw the same user.
        await withTransaction(async (client) => {
            const bal = await client.query(
                `SELECT COALESCE(${col}, 0) AS balance FROM credits WHERE uid = $1 FOR UPDATE`,
                [userId]
            );
            if (bal.rows.length === 0) throw new Error('User not found');
            if (Number(bal.rows[0].balance) < amount) throw new Error('Insufficient balance');

            await client.query(
                `UPDATE credits SET ${col} = COALESCE(${col}, 0) - $1 WHERE uid = $2`,
                [amount, userId]
            );
        });

        // 3) Send to A-Pay. On ANY failure, refund the hold so the user isn't debited.
        let response;
        let payload;
        try {
            payload = {
                amount: String(amount),
                currency,
                payment_system: paymentSystem,
                custom_transaction_id: customTxnId,
                custom_user_id: userId,
                data: payoutData,
            };
            if (this.WITHDRAWAL_WEBHOOK_ID) {
                payload.webhook_id = this.WITHDRAWAL_WEBHOOK_ID;
            }

            console.log('Withdrawal request payload:', payload);
            response = await axios.post(
                `${this.BASE_URL}/Remotes/create-withdrawal`,
                payload,
                {
                    params: { project_id: Number(this.PROJECT_ID) },
                    headers: { apikey: this.DEPOSIT_API_KEY },
                }
            );
        } catch (error) {
            await this.refundBalance(userId, amount, currency);
            const msg = error.response?.data?.message || error.response?.data?.error || error.message;
            // Simple, screenshot-friendly error log: message + payload + A-Pay response.
            console.error('\n========== A-PAY WITHDRAWAL FAILED (gateway error) ==========');
            console.error('Message  :', msg);
            console.error('Payload  :', JSON.stringify(payload, null, 2));
            console.error('Response :', JSON.stringify(error.response?.data || null, null, 2));
            console.error('=============================================================\n');
            await this.recordFailedWithdrawal(userId, amount, currency, paymentSystem, customTxnId, payoutData, msg, error.response?.data?.order_id);
            this.notifyAdmin(
                `Withdrawal request FAILED — ${currency} ${amount}`,
                PaymentService.renderDetailsTable([
                    ['Status', 'Failed (gateway error — balance refunded)'],
                    ['Reason', msg],
                    ['User ID', userId],
                    ['Amount', `${amount} ${currency}`],
                    ['Payment system', paymentSystem],
                    ['Custom transaction ID', customTxnId],
                    ['Failed at', new Date().toISOString()],
                ])
            );
            throw new Error(msg);
        }

        if (!response.data?.success) {
            await this.refundBalance(userId, amount, currency);
            const msg = response.data?.message || 'Withdrawal request failed';
            // Simple, screenshot-friendly error log: message + payload + A-Pay response.
            console.error('\n========== A-PAY WITHDRAWAL FAILED (gateway rejected) ==========');
            console.error('Message  :', msg);
            console.error('Payload  :', JSON.stringify(payload, null, 2));
            console.error('Response :', JSON.stringify(response.data || null, null, 2));
            console.error('===============================================================\n');
            await this.recordFailedWithdrawal(userId, amount, currency, paymentSystem, customTxnId, payoutData, msg, response.data?.order_id);
            this.notifyAdmin(
                `Withdrawal request FAILED — ${currency} ${amount}`,
                PaymentService.renderDetailsTable([
                    ['Status', 'Failed (gateway rejected — balance refunded)'],
                    ['Reason', msg],
                    ['User ID', userId],
                    ['Amount', `${amount} ${currency}`],
                    ['Payment system', paymentSystem],
                    ['Custom transaction ID', customTxnId],
                    ['Failed at', new Date().toISOString()],
                ])
            );
            throw new Error(msg);
        }

        // 4) Accepted — store Pending. Balance stays held until the postback decides.
        await pg.query(
            `INSERT INTO apaywithdrawals
                (order_id, user_id, amount, currency, payment_system,
                 custom_transaction_id, status, payout_details, payment_details)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
             ON CONFLICT (order_id) DO UPDATE SET
                status = EXCLUDED.status,
                payment_details = EXCLUDED.payment_details,
                updated_at = CURRENT_TIMESTAMP`,
            [
                response.data.order_id,
                userId,
                amount,
                currency,
                paymentSystem,
                customTxnId,
                'Pending',
                JSON.stringify(payoutData),
                JSON.stringify(response.data || {}),
            ]
        );

        this.notifyAdmin(
            `Withdrawal request created — ${currency} ${amount}`,
            PaymentService.renderDetailsTable([
                ['Status', 'Pending (sent to gateway — balance held)'],
                ['User ID', userId],
                ['Amount', `${amount} ${currency}`],
                ['Payment system', paymentSystem],
                ['Order ID', response.data.order_id],
                ['Custom transaction ID', customTxnId],
                ['Created at', new Date().toISOString()],
            ])
        );

        return response.data;
    }

    // Audit row for a withdrawal the gateway rejected synchronously. Balance has
    // already been refunded by the caller, so refunded = TRUE.
    async recordFailedWithdrawal(userId, amount, currency, paymentSystem, customTxnId, payoutData, reason, orderId) {
        try {
            await pg.query(
                `INSERT INTO apaywithdrawals
                    (order_id, user_id, amount, currency, payment_system,
                     custom_transaction_id, status, payout_details, error_reason, refunded)
                 VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, TRUE)
                 ON CONFLICT (order_id) DO NOTHING`,
                [
                    orderId || crypto.randomBytes(16).toString('hex'),
                    userId,
                    amount,
                    currency,
                    paymentSystem,
                    customTxnId,
                    'Failed',
                    JSON.stringify(payoutData || {}),
                    reason,
                ]
            );
        } catch (err) {
            console.error('Failed to record failed withdrawal:', err.message);
        }
    }

    async processWithdrawalWebhook(webhookData) {
        const { access_key, signature, transactions } = webhookData;

        // Clear marker so it's obvious in logs when A-Pay hits the withdrawal webhook.
        console.log('\n########## WITHDRAWAL WEBHOOK HIT ##########');
        console.log('Time      :', new Date().toISOString());
        console.log('Body      :', JSON.stringify(webhookData, null, 2));
        console.log('Statuses  :', (transactions || []).map(t => `${t.order_id}=${t.status}`).join(', '));
        console.log('###########################################\n');

        try {
        // Same auth + signature scheme as deposit (A-Pay uses one signing formula).
        if (access_key !== this.WEBHOOK_ACCESS_KEY) {
            throw new Error('Invalid webhook access key');
        }
        const expectedSignature = this.generateWebhookSignature(transactions);
        if (signature !== expectedSignature) {
            console.error('Withdrawal signature mismatch', { received: signature, expected: expectedSignature });
            throw new Error('Invalid webhook signature');
        }

        for (const transaction of transactions) {
            const { order_id, status, amount, custom_user_id, currency, custom_transaction_id, payment_system } = transaction;

            await pg.query(
                `UPDATE apaywithdrawals
                    SET status = $1, webhook_response = $2, updated_at = CURRENT_TIMESTAMP
                  WHERE order_id = $3`,
                [status, JSON.stringify(webhookData), order_id]
            );

            if (status === 'Success') {
                // Balance was already debited at request time — nothing to credit.
                this.notifyAdmin(
                    `Withdrawal SUCCESS — ${currency} ${amount}`,
                    PaymentService.renderDetailsTable([
                        ['Status', 'Success (paid out)'],
                        ['User ID', custom_user_id],
                        ['Amount', `${amount} ${currency}`],
                        ['Payment system', payment_system],
                        ['Order ID', order_id],
                        ['Custom transaction ID', custom_transaction_id],
                        ['Confirmed at', new Date().toISOString()],
                    ])
                );
            } else if (['Failed', 'Rejected'].includes(status)) {
                const refunded = await this.refundWithdrawalOnce(order_id);
                this.notifyAdmin(
                    `Withdrawal ${status.toUpperCase()} — ${currency} ${amount}`,
                    PaymentService.renderDetailsTable([
                        ['Status', `${status}${refunded ? ' (balance refunded)' : ' (already refunded / no record)'}`],
                        ['User ID', custom_user_id],
                        ['Amount', `${amount} ${currency}`],
                        ['Payment system', payment_system],
                        ['Order ID', order_id],
                        ['Custom transaction ID', custom_transaction_id],
                        ['Failed at', new Date().toISOString()],
                    ])
                );
                void refunded;
            }
        }

        return { status: 'OK' };
        } catch (err) {
            // Webhook failed (bad access key / signature / processing). Save the
            // error onto any still-Pending row(s) referenced by this webhook so it's
            // visible in the DB for debugging. Status stays Pending; we re-throw so
            // A-Pay gets a non-2XX and retries.
            await this.saveWebhookError(transactions, err.message, webhookData);
            throw err;
        }
    }

    // Saves a webhook error onto the still-Pending withdrawal row(s) referenced by
    // the webhook, without changing their status. Never throws.
    async saveWebhookError(transactions, errorMessage, webhookData) {
        try {
            const orderIds = (transactions || []).map(t => t && t.order_id).filter(Boolean);
            for (const orderId of orderIds) {
                await pg.query(
                    `UPDATE apaywithdrawals
                        SET error_reason = $1, webhook_response = $2, updated_at = CURRENT_TIMESTAMP
                      WHERE order_id = $3 AND status = 'Pending'`,
                    [`Webhook error: ${errorMessage}`, JSON.stringify(webhookData), orderId]
                );
            }
        } catch (e) {
            console.error('Failed to save webhook error to row:', e.message);
        }
    }

    // Refunds a held withdrawal exactly once. Inside a transaction it locks the
    // withdrawal row (FOR UPDATE), checks the `refunded` flag, then credits the
    // balance and marks it refunded together — so duplicate Failed/Rejected
    // postbacks can't refund twice (the second one waits, then sees refunded=TRUE).
    // Amount/currency come from OUR stored row — never trusted from the webhook.
    async refundWithdrawalOnce(orderId) {
        return withTransaction(async (client) => {
            const res = await client.query(
                `SELECT user_id, amount, currency, refunded
                   FROM apaywithdrawals WHERE order_id = $1 FOR UPDATE`,
                [orderId]
            );
            if (res.rows.length === 0) return false;   // no such withdrawal
            const row = res.rows[0];
            if (row.refunded) return false;            // already refunded earlier

            const cur = String(row.currency || '').toUpperCase();
            if (!WITHDRAWAL_PAYMENT_SYSTEMS[cur]) {
                console.error(`Refund skipped — unknown currency "${row.currency}" for order ${orderId}`);
                return false;
            }
            const col = cur.toLowerCase();

            await client.query(
                `UPDATE credits SET ${col} = COALESCE(${col}, 0) + $1 WHERE uid = $2`,
                [row.amount, row.user_id]
            );
            await client.query(
                `UPDATE apaywithdrawals SET refunded = TRUE, updated_at = CURRENT_TIMESTAMP WHERE order_id = $1`,
                [orderId]
            );
            return true;
        });
    }

    // Adds `amount` back to the user's per-currency balance. Currency is validated
    // against the allowed set before the column name is built (no SQL injection).
    async refundBalance(userId, amount, currency) {
        const cur = String(currency || '').toUpperCase();
        if (!WITHDRAWAL_PAYMENT_SYSTEMS[cur]) {
            console.error(`Refund skipped — unknown currency "${currency}" for user ${userId}`);
            return;
        }
        const col = cur.toLowerCase();
        await pg.query(
            `UPDATE credits SET ${col} = COALESCE(${col}, 0) + $1 WHERE uid = $2`,
            [amount, userId]
        );
    }
}

module.exports = PaymentService;
