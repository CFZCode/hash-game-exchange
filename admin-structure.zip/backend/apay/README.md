# A-Pay payment gateway

Deposits and automatic withdrawals (payouts) for INR / BDT / PKR / NPR through
[A-Pay](https://docs.a-pay.one/). Everything in this folder talks to one A-Pay
project; the code is `paymentservices.js` (logic) and `routes.js` (HTTP + creds).

Mounted at **`/remotes`** (`../index.js`), so the public paths are
`/remotes/create-deposit`, `/remotes/webhook`, `/remotes/create-withdrawal`,
`/remotes/withdrawal-webhook`, `/remotes/payment-methods`, `/remotes/deposit-info`,
`/remotes/deposit-return`.

---

## 1. A-Pay basics

| Thing | Value |
|---|---|
| Base URL | `https://pay-crm.com` |
| Auth | header `apikey` + query `project_id` |
| Project | `3039314` (prod). Test project `6987753` — keys commented in `routes.js` |
| Deposit webhook id | `3039314` |
| Withdrawal webhook id | `9007433` |
| Errors | always HTTP 400 with `{success:false, message, code}` |

A-Pay offers two integration styles. We use the **payment page**
(`/Remotes/create-payment-page`) — A-Pay returns a hosted URL and the player is
redirected there. The alternative (`/Remotes/create-deposit`, we build the UPI /
QR screen ourselves) is not used.

### Endpoints we call

| Endpoint | Used by |
|---|---|
| `GET /Remotes/payment-systems-info` | `fetchPaymentSystems()` — which methods are enabled + limits |
| `POST /Remotes/create-payment-page` | `createDeposit()` |
| `GET /Remotes/deposit-info` | `getDepositInfo()` |
| `POST /Remotes/create-withdrawal` | `createWithdrawal()` |

`GET /Remotes/deposit-info` is also polled by the unattempted-deposit
detection (§3a) before a Pending deposit is declared abandoned.

### Endpoints A-Pay has that we do **not** use yet

- `GET /Remotes/withdrawal-info` — would let a cron resolve withdrawals whose
  postback never arrived (right now such a withdrawal stays Pending and the
  player's balance stays held forever).
- `POST /Remotes/create-lost-transaction` — multipart receipt upload for
  "money left my account but nothing was credited" complaints.
- `POST /Remotes/deposit-activate` — only needed for direct-API flows where the
  player submits a UTR / transaction id. Not needed with the payment page.
  Worth knowing: the direct-API `create-deposit` response returns
  `upi_address` plus `paymentpage_url` (a `upi://` deep link) and
  PhonePe/Paytm-specific links — the pieces needed to open the player's UPI
  app directly instead of showing a QR (which, uploaded from the gallery, is
  capped at ₹2,000 by the banks). Paykassma's guidance for that flow: show
  the UPI address / deep link on phones, the QR only on desktop. On the
  hosted payment page we use, that behaviour is theirs to control.
- `POST /reports/create` → `/reports/status/{id}` → `/reports/download/{id}` —
  CSV export (UTF-8, `;` delimiter, max 31-day range) for reconciliation.
- Settlement (withdrawing our own balance from A-Pay) has no public API — it is
  arranged with their financier.

---

## 2. Payment methods are read live, not hardcoded

A-Pay enables and disables payment systems per project **on their side**. The
project used to have `esewa_p2p` for NPR; it now has `khalti_l` instead, and the
old hardcoded map meant every NPR deposit failed with *"No payment system found
with such params or payment system is disabled"* until someone noticed.

So `fetchPaymentSystems()` reads `GET /Remotes/payment-systems-info` and caches
it for 5 minutes (A-Pay's own docs suggest refreshing about that often). On top
of it:

- `getPaymentMethods(currency, userId)` keeps the systems flagged for deposit
  in that currency, attaches a label and that method's min/max, lowest minimum
  first — after two policy filters Paykassma asked for (2026-08):
  - `DEPOSIT_HIDDEN_SYSTEMS` (`imps`): imps is our withdrawal channel; its
    deposit button only produced empty requests against an inoperative method,
    so it is never offered for deposit even while A-Pay reports `deposit: true`.
  - `FTD_RESTRICTED_SYSTEMS` (`upi_fast_v`): Indian methods must not get
    first-time-depositor traffic. The method is only listed/accepted once the
    user has ≥1 `Success` row in `apaydeposits` (`hasSuccessfulDeposit()`).
    No/unknown `userId` counts as FTD — fail closed.
- `GET /remotes/payment-methods?currency=BDT&user_id=…` exposes the list to the
  frontend, which renders one card per method.
- `createDeposit()` only accepts a `payment_system` that appears in that same
  filtered list (so hand-crafted requests can't reach imps / upi_fast_v
  either), and checks the amount against that method's limits.

Net effect: A-Pay enabling a new method makes it appear in the deposit screen
with no deploy, and disabling one removes it instead of producing failures.

If the call fails, the last cached list is used even when older than 5 minutes.
With no cache at all the list comes back empty and deposits are refused — that
is deliberate, guessing a payment system only moves the failure to the gateway.

### Snapshot of what was enabled on 2026-08-13

| Currency | Deposit | Withdrawal (`withdrawal: true`) |
|---|---|---|
| INR | `imps` 300–100000, `upi_fast_v` 300–50000, `upi_p2p` 500–50000, `phonepe` 500–50000, `paytm` 500–50000 | `imps` 5000–50000 |
| BDT | `bkash_api_v` 100–25000, `nagad_b` 100–30000, `nagad_api_v` 400–25000 | none |
| PKR | `easypaisa` 100–150000, `jazzcash_fast` 100–50000, `raast_p2p` 1500–250000 | `pkr_w` 1500–150000 |
| NPR | `khalti_l` 400–25000 | none |

---

## 3. Deposit flow

1. Frontend calls `GET /remotes/payment-methods?currency=…`, shows the cards,
   player picks one.
2. `POST /remotes/create-deposit` with `{amount, currency, custom_user_id,
   payment_system}`. `payment_system` is optional — without it the first
   (lowest-minimum) enabled method is used.
3. `createDeposit()` validates: currency is one we hold a balance in, the method
   is enabled for it, the amount is a positive number inside that method's
   min/max. `webhook_id` and `return_url` come from config, never from the
   request body.
4. A-Pay returns `{success, url, order_id}`; the row is stored `Pending` in
   `apaydeposits` and the player is redirected to `url`.
5. A-Pay POSTs the result to `/remotes/webhook`. On `Success` the player's
   per-currency column in `credits` is credited **with the amount from the
   postback** (A-Pay's docs are explicit about this — never trust our own stored
   amount, the player may have paid something else).

Statuses: `Pending`, `Success`, `Failed`, `Rejected`, plus our own
`Unattempted` (§3a).

### 3a. Unattempted deposits ("Unattempt Payment" email)

A-Pay sends **no postback** when a player opens the payment page and leaves
without paying — the row would sit `Pending` forever and nobody would know.
Two detectors close that gap, both funnelling into
`resolveDepositReturn(orderId, trigger)`:

1. **Return ping.** Before redirecting, the frontend stores
   `{order_id, at}` in `localStorage` (`apay_pending_deposit`). When the
   player lands back on the site — return_url or the Back button — the app
   (`useDepositReturnCheck` in App.jsx) POSTs `/remotes/deposit-return` and
   shows a toast with the outcome.
2. **Cron sweeper.** `routes.js` schedules `sweepUnattemptedDeposits()` every
   5 minutes for players who closed the tab and never came back: `Pending`
   rows older than 15 min (`UNATTEMPTED_AFTER_MINUTES`) that haven't been
   notified yet.

`resolveDepositReturn` never trusts our row alone — it confirms with
`GET /Remotes/deposit-info` first, then:

| Gateway says | Action |
|---|---|
| `Success` | status updated; admin email **"Deposit SUCCESS (via poll — VERIFY CREDIT)"** — crediting is left to the webhook because deposits have no idempotence flag (§6.1) |
| `Failed` / `Rejected` | the usual failed-deposit email, same wording as the webhook path |
| still `Pending` / unreachable | `markUnattempted()` → status `Unattempted`, admin email **"Unattempt Payment — user did not deposit the amount"** |

`markUnattempted()` claims the row atomically
(`UPDATE … WHERE status='Pending' AND unattempt_notified=FALSE RETURNING`),
so the return ping, the sweeper, and clustered pm2 workers can all race and
exactly one email goes out. A postback arriving later simply overwrites
`Unattempted` and the normal Success/Failed handling (and email) runs.

Schema: `unattempt_notified boolean` + a partial index on the sweep — applied
idempotently at boot (`ensureUnattemptSchema()`) and filed as
`system/migrations/apaydeposits_unattempted.sql`.

## 4. Withdrawal flow (money leaves)

1. Validate currency, amount, and the payout `data` against that payment
   system's schema — `validateWithdrawalData()` — *before* touching the balance,
   so a typo'd IFSC never holds a player's money.
2. Inside a transaction, `SELECT … FOR UPDATE` the `credits` row, check the
   balance and deduct it. The row lock is what stops two concurrent withdrawals
   from overdrawing the same wallet.
3. `POST /Remotes/create-withdrawal`. Any failure — network error or
   `success:false` — refunds the hold immediately and writes a `Failed` audit
   row with `refunded = TRUE`.
4. On acceptance the row is stored `Pending` and the balance stays held.
5. `/remotes/withdrawal-webhook` decides: `Success` → nothing to do, already
   debited. `Failed`/`Rejected` → `refundWithdrawalOnce()` refunds exactly once.

### Why the refund can only happen once

`refundWithdrawalOnce()` locks the `apaywithdrawals` row, checks the `refunded`
flag, then credits the balance and sets the flag **in the same transaction**. A
duplicate `Failed` postback blocks on the lock, then sees `refunded = TRUE` and
does nothing. Amount and currency come from our stored row, never from the
postback body.

### Payout `data` per payment system

| PS | Currency | Fields |
|---|---|---|
| `imps` | INR | `account_name` (letters/spaces, ≤30), `account_number` (digits), `bank_code` IFSC `^[A-Z]{4}0[A-Z0-9]{6}$` |
| `bkash_api_v` | BDT | `account_number` `^01[0-9]{9}$` |
| `nagad_api_v` | BDT | `account_number` — exactly 11 digits |
| `pkr_w` | PKR | `account_number` 9–17 digits (CNIC for EasyPaisa/JazzCash, else bank a/c), `bank_name` 2–67 chars, `phone_number` `^03[0-9]{9}$` |
| `esewa_p2p` | NPR | `payment_method: 'phone'` → `phone_number` 10 digits; `'bank'` → + `bank_name` |

---

## 5. Postback (webhook) verification

Both webhooks receive `{access_key, signature, transactions[]}` and are checked
the same way — A-Pay signs deposits and withdrawals with one formula:

```
sha1( access_key + private_key + md5( JSON(transactions) ) )
```

The JSON must match PHP's `json_encode(..., JSON_UNESCAPED_SLASHES |
JSON_UNESCAPED_UNICODE)`. In Node that is plain `JSON.stringify(transactions)` —
JS does not escape forward slashes to begin with.

Each transaction carries `order_id`, `status`, `amount`, `currency`,
`payment_system`, `custom_transaction_id`, `custom_user_id`, and `created_at` /
`activated_at` as unix UTC timestamps.

We must answer `{"status":"OK"}` with HTTP 200. **A-Pay retries on any non-2XX**,
which is why a failing webhook is written back onto the still-`Pending` row
(`saveWebhookError()`) rather than swallowed — the retry is expected and the
error needs to be visible in the DB meanwhile.

---

## 6. Known issues — not fixed yet

1. **A repeated `Success` deposit postback credits twice.** `apaydeposits` has
   no `credited` flag (`apaywithdrawals` has `refunded`, deposits have nothing),
   so nothing makes crediting idempotent. Since A-Pay retries on non-2XX, a
   postback carrying two transactions where the second one throws will re-credit
   the first on every retry. Needs a `credited boolean` column plus a
   `FOR UPDATE` check, the same shape as `refundWithdrawalOnce()`.
2. **`generateWebhookSignature()` corrupts the JSON.** The
   `.replace(/\\"/g, '"')` turns escaped quotes inside string values back into
   raw quotes, which breaks the signature the moment any field contains a quote.
   It should be plain `JSON.stringify(transactions)`.
3. **`creditUserBalance()` builds a column name from the postback's `currency`**
   with no whitelist. `refundBalance()` guards this; the credit path does not.
4. **Live API keys are hardcoded in `routes.js`** and committed. The webhook
   private key is the signing secret — anyone holding it can forge a `Success`
   postback and credit any wallet. Move to env vars and have A-Pay rotate them.
   `console.log` on the deposit path also prints the API key.
5. **BDT and NPR withdrawals point at systems A-Pay reports as disabled**
   (`bkash_api_v` and `esewa_p2p` both have `withdrawal: false`). Confirm with
   A-Pay support which system BDT/NPR payouts should use.
6. `paymentservices.old.js` is a dead copy of an earlier version.

---

## 7. Testing

A-Pay provides a separate test project (`6987753`, keys commented at the top of
`routes.js`) and their support team triggers callback statuses by hand, so the
webhook handlers can be exercised without moving real money. Swap the credential
block, never both — the deposit service is live.
