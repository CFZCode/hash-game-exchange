export function getCurrentTimestampInt64() {
    const currentTimestampInt64 = BigInt(Date.now()) * 1000000n;
    console.log(currentTimestampInt64);
    return currentTimestampInt64.toString();
  }
  
