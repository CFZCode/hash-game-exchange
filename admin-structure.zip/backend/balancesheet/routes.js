// routes/balancesheet.js — per-user balance sheet, open to the whole staff hierarchy
const router = require('express').Router();
const { protectStaff } = require('../system/middleware/auth');
const ctrl = require('./controller');

// Any authenticated staff member may view a user's balance sheet. The user-listing
// endpoints are already scoped per-staff, so each staff only ever has IDs for users
// within their own downline to look up here.
router.get('/:userId', protectStaff, ctrl.getBalanceSheet);

module.exports = router;
