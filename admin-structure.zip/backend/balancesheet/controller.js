/* ──────────────────────────────────────────────────────────────────────────
   Per-user BALANCE SHEET  (SuperAdmin only)

   Builds a single chronological ledger for one user by merging every
   balance-affecting event from the tables that actually move money:

     • staff_transfers  — agent deposits ("deposit") and withdrawals ("withdraw")
                          (transfer_type='transfer' only; legacy 'gt'/'casino'
                          settlement rows are EXCLUDED so they don't double-count
                          with the per-bet ledger entries below. The GT
                          settlement model is gone — no new rows of those types
                          are written — but historical ones must stay filtered.)
     • fiat_deposits    — bank deposits (approved/success)
     • apaydeposits     — payment-gateway deposits (Success)
     • fiat_withdrawals — bank withdrawals (not rejected/failed)
     • apaywithdrawals  — gateway withdrawals (Success/Pending, not refunded)
     • credits_ledger   — sports bet settlement P&L (netamount: +win / -loss)
     • gis_transactions — casino bet (debit) / win (credit) / refund (credit)

   Each event is normalised to a signed amount (credit = +, debit = -). The
   running balance is the cumulative sum over ALL events in time order, so it is
   consistent across pages. Results are returned newest-first, paginated.

   Money columns in `credits` are per-currency; staff_transfers is INR-only.
   ────────────────────────────────────────────────────────────────────────── */
const pg = require('../General/Model');

// Currencies we can build a sheet for = the per-currency columns on `credits`.
const ALLOWED_CURRENCIES = new Set([
  'INR', 'PKR', 'USDT', 'USD', 'EUR', 'BDT', 'NPR', 'BTC', 'ETH', 'LTC', 'BCH',
  'TRX', 'DOGE', 'ADA', 'XRP', 'BNB', 'USDC', 'BUSD', 'SC', 'MVR', 'AED',
]);

const num = (v) => { const n = Number(v); return Number.isFinite(n) ? n : 0; };
const round2 = (n) => Math.round((Number(n) || 0) * 100) / 100;

// Each source returns rows: { ts, type, category, description, amount(signed), currency }
async function collectEvents(userId, currency) {
  const cur = currency;
  const col = cur.toLowerCase();
  const events = [];

  // 1) Manual agent credits / collects (INR only — staff_transfers has no currency)
  if (cur === 'INR') {
    // `note` is added by a migration; fall back gracefully if not yet applied.
    const baseSql = (noteCol) =>
      `SELECT created_at, amount, from_type, from_id, to_type, to_id, direction, ${noteCol} AS note
         FROM staff_transfers
        WHERE transfer_type = 'transfer'
          AND ( (to_type='user'  AND to_id  = $1)
             OR (from_type='user' AND from_id = $1) )
        ORDER BY created_at ASC`;
    let rows;
    try {
      ({ rows } = await pg.query(baseSql('note'), [userId]));
    } catch (e) {
      if (e.code === '42703') ({ rows } = await pg.query(baseSql('NULL'), [userId])); // undefined_column
      else throw e;
    }
    for (const r of rows) {
      const isCredit = r.to_type === 'user' && String(r.to_id) === String(userId);
      const amt = num(r.amount) * (isCredit ? 1 : -1);
      events.push({
        ts: r.created_at,
        type: isCredit ? 'CREDIT' : 'DEBIT',
        category: 'Agent',
        description: (isCredit ? 'Credited by agent / deposit' : 'Collected by agent / withdraw')
          + (r.note ? ` — ${r.note}` : ''),
        amount: amt,
        currency: cur,
      });
    }
  }

  // 2) Bank (fiat) deposits
  {
    const { rows } = await pg.query(
      `SELECT created_at, amount, status, transaction_id
         FROM fiat_deposits
        WHERE user_id = $1 AND upper(currency) = $2
          AND lower(status) IN ('approved','success','done','completed')
        ORDER BY created_at ASC`,
      [userId, cur]
    );
    for (const r of rows) events.push({
      ts: r.created_at, type: 'CREDIT', category: 'Deposit',
      description: `Bank deposit${r.transaction_id ? ` (${r.transaction_id})` : ''}`,
      amount: num(r.amount), currency: cur,
    });
  }

  // 3) Gateway (apay) deposits
  {
    const { rows } = await pg.query(
      `SELECT created_at,
              CASE WHEN paid_amount > 0 THEN paid_amount ELSE amount END AS amount,
              order_id
         FROM apaydeposits
        WHERE user_id = $1 AND upper(currency) = $2 AND status = 'Success'
        ORDER BY created_at ASC`,
      [userId, cur]
    );
    for (const r of rows) events.push({
      ts: r.created_at, type: 'CREDIT', category: 'Deposit',
      description: `Gateway deposit${r.order_id ? ` (${r.order_id})` : ''}`,
      amount: num(r.amount), currency: cur,
    });
  }

  // 4) Bank (fiat) withdrawals
  {
    const { rows } = await pg.query(
      `SELECT date, amount, status
         FROM fiat_withdrawals
        WHERE uid = $1 AND upper(currency) = $2
          AND lower(status) NOT IN ('rejected','failed')
        ORDER BY date ASC`,
      [userId, cur]
    );
    for (const r of rows) events.push({
      ts: r.date, type: 'DEBIT', category: 'Withdrawal',
      description: `Bank withdrawal (${r.status})`,
      amount: -num(r.amount), currency: cur,
    });
  }

  // 5) Gateway (apay) withdrawals — user_id is text here
  {
    const { rows } = await pg.query(
      `SELECT created_at, amount, status, order_id
         FROM apaywithdrawals
        WHERE user_id = $1::text AND upper(currency) = $2
          AND status IN ('Success','Pending') AND COALESCE(refunded,false) = false
        ORDER BY created_at ASC`,
      [String(userId), cur]
    );
    for (const r of rows) events.push({
      ts: r.created_at, type: 'DEBIT', category: 'Withdrawal',
      description: `Gateway withdrawal (${r.status})${r.order_id ? ` ${r.order_id}` : ''}`,
      amount: -num(r.amount), currency: cur,
    });
  }

  // 6) Sports bet settlement — credits_ledger.netamount is signed (+win/-loss)
  {
    const { rows } = await pg.query(
      `SELECT created_at, amount, netamount, profit, loss, description, reason
         FROM credits_ledger
        WHERE user_id::text = $1::text AND upper(currency) = $2
        ORDER BY created_at ASC`,
      [String(userId), cur]
    );
    for (const r of rows) {
      const net = r.netamount != null ? num(r.netamount) : num(r.amount);
      events.push({
        ts: r.created_at,
        type: net >= 0 ? 'CREDIT' : 'DEBIT',
        category: 'Sports',
        description: r.description || `Sports settlement (${r.reason || ''})`.trim(),
        amount: net, currency: cur,
      });
    }
  }

  // 7) Casino — gis_transactions (bet = debit, win/refund = credit).
  //    The GIS provider labels the INR wallet as 'PKR' and the USDT wallet as
  //    'USD', so a casino row's `currency` is the provider label, not the wallet.
  //    We therefore include every gis currency that maps to the SAME wallet
  //    column as the sheet currency (CUR2COL mirrors gis/controller.js).
  //    Casino rows have no timestamps in this DB, so they fall back to "now"
  //    and sort to the most-recent end of the ledger, ordered by id.
  {
    const CUR2COL = { PKR: 'inr', INR: 'inr', USD: 'usdt', USDT: 'usdt', EUR: 'eur' };
    const wallet = CUR2COL[cur];
    if (wallet) {
      const gisCurrencies = Object.keys(CUR2COL).filter(c => CUR2COL[c] === wallet);
      const { rows } = await pg.query(
        `SELECT id, transaction_datetime, created_at, amount, action, round_id
           FROM gis_transactions
          WHERE user_id = $1 AND upper(currency) = ANY($2::text[])
          ORDER BY id ASC`,
        [userId, gisCurrencies]
      );
      const fallbackTs = new Date();
      for (const r of rows) {
        const isBet = r.action === 'bet';
        const amt = num(r.amount) * (isBet ? -1 : 1);
        if (amt === 0) continue;  // skip zero-value win/refund rows (no balance effect)
        events.push({
          ts: r.transaction_datetime || r.created_at || fallbackTs,
          seq: Number(r.id) || 0,
          type: isBet ? 'DEBIT' : 'CREDIT',
          category: 'Casino',
          description: `Casino ${r.action}${r.round_id ? ` · round ${r.round_id}` : ''}`,
          amount: amt, currency: cur,
        });
      }
    }
  }

  return events;
}

exports.getBalanceSheet = async (req, res, next) => {
  try {
    const userId = req.params.userId;
    if (!userId) return res.status(400).json({ status: 'fail', message: 'Missing userId' });

    const currency = String(req.query.currency || 'INR').toUpperCase();
    if (!ALLOWED_CURRENCIES.has(currency))
      return res.status(400).json({ status: 'fail', message: `Unsupported currency: ${currency}` });

    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const limit = Math.min(200, Math.max(5, parseInt(req.query.limit, 10) || 50));

    // User header info + current live balance
    const { rows: uRows } = await pg.query(
      `SELECT u.id, u.name, u.email,
              COALESCE(c.${currency.toLowerCase()}, 0) AS live_balance,
              s.name AS staff_name,
              COALESCE(u.is_demo, false) AS is_demo
         FROM users u
         LEFT JOIN credits c ON c.uid = u.id
         LEFT JOIN staff s   ON s.id = u.parent_staff_id
        WHERE u.id = $1`,
      [userId]
    );
    if (!uRows.length) return res.status(404).json({ status: 'fail', message: 'User not found' });
    const user = uRows[0];

    // Open (unsettled) sports bets hold their stake OUT of the live wallet at
    // placement, but have no settlement ledger row yet — so the wallet legitimately
    // sits below the ledger by exactly this amount. Surface it so the sheet
    // reconciles:  live_balance + open_exposure = ledger_balance.
    // Sports betting is INR-only here, so it is 0 for other currencies.
    let openExposure = 0;
    if (currency === 'INR') {
      const { rows: oe } = await pg.query(
        `SELECT COALESCE(SUM(stake_amount), 0) AS s
           FROM "SportsBet"
          WHERE user_id = $1 AND status IN ('open', 'manual')`,
        [String(userId)]
      );
      openExposure = round2(oe[0].s);
    }

    // Gather + sort ascending, compute running balance over the full set.
    // Tie-break on `seq` (used by casino rows that share a fallback timestamp).
    const events = await collectEvents(userId, currency);
    events.sort((a, b) => {
      const d = new Date(a.ts) - new Date(b.ts);
      if (d) return d;
      return (a.seq || 0) - (b.seq || 0);
    });

    let running = 0;
    let totalCredit = 0, totalDebit = 0;
    for (const e of events) {
      running += e.amount;
      e.amount = round2(e.amount);
      e.balance = round2(running);
      if (e.amount >= 0) totalCredit += e.amount; else totalDebit += e.amount;
      delete e.seq;   // internal sort key — not part of the API response
    }

    // Newest first for display
    const ordered = events.slice().reverse();
    const total = ordered.length;
    const start = (page - 1) * limit;
    const pageRows = ordered.slice(start, start + limit);

    res.json({
      status: 'success',
      user: {
        id: String(user.id),
        name: user.name,
        email: user.email,
        staff_name: user.staff_name || null,
        is_demo: !!user.is_demo,
        live_balance: round2(user.live_balance),
      },
      currency,
      summary: {
        total_credit: round2(totalCredit),
        total_debit: round2(totalDebit),
        net: round2(totalCredit + totalDebit),
        ledger_balance: round2(running),   // running total of recorded events
        open_exposure: openExposure,       // stake held in unsettled bets (not yet in ledger)
        // True when the live wallet matches the ledger once unsettled stakes are
        // accounted for. A small tolerance absorbs rounding.
        reconciled: Math.abs(round2(user.live_balance) + openExposure - round2(running)) < 1,
        event_count: total,
      },
      pagination: { page, limit, total, pages: Math.max(1, Math.ceil(total / limit)) },
      rows: pageRows,
    });
  } catch (err) {
    next(err);
  }
};
