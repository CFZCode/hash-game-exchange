const { parse } = require('json2csv');
const fs = require('fs');

// Your JSON data
const jsonData =[{
        "id": 13136,
        "title": "Lost",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/e1efce3059dd913aba07faaedc6410cfed52f23c.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/13136.png"
            }
        }
    }, {
        "id": 13159,
        "title": "Sugar Pop",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/ce9b1a3fe497f4f6c4fcb012899fab19bb8f61fa.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/13159.png"
            }
        }
    }, {
        "id": 13161,
        "title": "Sushi Bar",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/24997e055aac3e3895878153ac3b3ea397e86c22.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/13161.png"
            }
        }
    }, {
        "id": 13163,
        "title": "The Exterminator",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/b55be19b03997b8cb3b197905aa33cad39aedadf.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/13163.png"
            }
        }
    }, {
        "id": 13176,
        "title": "Pai Gow",
        "platform": "desktop-and-mobile",
        "type": "table",
        "subtype": "live-casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/c78c49d9da98193e5592963a5929f5d3a66a8fd9.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/13176.png"
            }
        }
    }, {
        "id": 13177,
        "title": "Pirate 21",
        "platform": "desktop-and-mobile",
        "type": "table",
        "subtype": "live-casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/cbdfdf1859e93b483f38a6b15d82430889f6bb7d.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/13177.png"
            }
        }
    }, {
        "id": 13178,
        "title": "Pontoon",
        "platform": "desktop-and-mobile",
        "type": "table",
        "subtype": "live-casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/5ad37ce45dcabd44fd5a3baa3dd1f228fb9c5b74.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/13178.png"
            }
        }
    }, {
        "id": 13179,
        "title": "Red Dog",
        "platform": "desktop-and-mobile",
        "type": "table",
        "subtype": "live-casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/7dad4f64542405c77ee089d2c2eb7fe2ba6373e9.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/13179.png"
            }
        }
    }, {
        "id": 13181,
        "title": "Super 7 Blackjack",
        "platform": "desktop-and-mobile",
        "type": "table",
        "subtype": "live-casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/778a430cedd308789878b37a5d14efc2818e0299.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/13181.png"
            }
        }
    }, {
        "id": 13183,
        "title": "Vip American Roulette",
        "platform": "desktop-and-mobile",
        "type": "table",
        "subtype": "live-casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/7c6ffe9d319310e7763b02d5e7e2a245027d31fb.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/13183.png"
            }
        }
    }, {
        "id": 13184,
        "title": "Vip European Roulette",
        "platform": "desktop-and-mobile",
        "type": "table",
        "subtype": "live-casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/72da29015271c794d24fd38bc453002104be26d7.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/13184.png"
            }
        }
    }, {
        "id": 16850,
        "title": "Tower of Fortuna",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/c3b9b42e9e54584ac165b443a6b7b01aa7fa4793.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/16850.png"
            }
        }
    }, {
        "id": 16988,
        "title": "7 Fortune Frenzy",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/a06b87d3cf919f3909e92365657ae0584b070625.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/16988.png"
            }
        }
    }, {
        "id": 16989,
        "title": "Jungle Stripes",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/3ec582d29e81f2817fc3e8831e748260fbfd864e.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/16989.png"
            }
        }
    }, {
        "id": 16990,
        "title": "Hat Trick Hero",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/0e2709e16a5a114506d2841a3729b34c1f06e4ea.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/16990.png"
            }
        }
    }, {
        "id": 16991,
        "title": "Lava Gold",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/c4c673c5c5a9b4598921363a2432463bb372c5d2.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/16991.png"
            }
        }
    }, {
        "id": 17448,
        "title": "Return to Paris",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/d9a0ecb3d745a18b7132a68a30785daf6014acf6.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/17448.png"
            },
            "rtp": 96.4,
            "volatility": "medium"
        }
    }, {
        "id": 17707,
        "title": "Stay Frosty!",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/be08fc4a70677482513fa2fb8b80a7425a9baaa9.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/17707.png"
            }
        }
    }, {
        "id": 17708,
        "title": "Thai Blossoms",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/8fda2c82491ab6706ae4365124a460cdded91212.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/17708.png"
            },
            "rtp": 96.1,
            "volatility": "high"
        }
    }, {
        "id": 17932,
        "title": "Take The Kingdom",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/18ab3eb98132e1205f3cc2d522e1e678f25d2a5f.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/17932.png"
            }
        }
    }, {
        "id": 18024,
        "title": "Gold Tiger Ascent",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/34463110ffc4b683072ca2a824af6ace233f2e85.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/18024.png"
            },
            "rtp": 92,
            "volatility": "high"
        }
    }, {
        "id": 18226,
        "title": "Triple Juicy Drops",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/bdff81ec0fb7d3cbd8f1c6690f8003c9837e0f95.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/18226.png"
            }
        }
    }, {
        "id": 18611,
        "title": "Lost: Mystery Chests",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/d0b144bb40d4d3d89fbef162141a951599327648.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/18611.png"
            }
        }
    }, {
        "id": 18658,
        "title": "Primal Wilderness",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/b65529957eb826f62d6889fdb84c7b1e0402f890.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/18658.png"
            }
        }
    }, {
        "id": 18723,
        "title": "Alkemor’s Elements",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/89eb1d66254869d119bdff7f7bfb04d4de038441.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/18723.png"
            }
        }
    }, {
        "id": 19232,
        "title": "Book of Helios",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/acdb6ef0f6d6ca5b99087b0c20907fba8765ab63.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/19232.png"
            }
        }
    }, {
        "id": 19234,
        "title": "Deuces Wild Video Poker",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/8dd346da3019a128d0f3df027632113306804f77.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/19234.png"
            }
        }
    }, {
        "id": 19235,
        "title": "Dragon Kings",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/eddc24995cd8d50db2e3748bc82c4ad37f97a277.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/19235.png"
            }
        }
    }, {
        "id": 19236,
        "title": "Draw High Low",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/e7fb068363cf25d4398b3b1e1ea49d37cf8f3986.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/19236.png"
            }
        }
    }, {
        "id": 19458,
        "title": "Winds of Wealth",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/9ea5a7bf77d604d160a7e001e604549b8c121565.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/19458.png"
            }
        }
    }, {
        "id": 19558,
        "title": "Captain’s Quest Treasure Island",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/cdcd1cf4a339ac1d85f137702c32503a1432b4ed.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/19558.png"
            }
        }
    }, {
        "id": 19720,
        "title": "Rags to Witches",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/c1165c79a9911d120df7c51513707a1375e146ac.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/19720.png"
            }
        }
    }, {
        "id": 19777,
        "title": "Trinity Reels",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/02c029c78130227ef13c77b51ce0b7ba44ffa850.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/19777.png"
            }
        }
    }, {
        "id": 19916,
        "title": "Sleighin",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/8897704b4b86474f98cc4ffaf5bf4a40.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/19916.png"
            }
        }
    }, {
        "id": 20761,
        "title": "Bounding Luck",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/10448c9cd304451d8f8f57181b5c739e.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/20761.png"
            }
        }
    }, {
        "id": 20886,
        "title": "Golden Dragon Inferno",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/41d5538671739e46d3bd64459b7ed1c354fc676c.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/20886.png"
            }
        }
    }, {
        "id": 20887,
        "title": "Wilds of Fortune",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/69be984b6706cac2bd950207f0ca2821aa95e5c9.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/20887.png"
            }
        }
    }, {
        "id": 20888,
        "title": "Gemini Joker",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/c3aa3aaaf90949ba6594510d9fff1174ec4622c8.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/20888.png"
            }
        }
    }, {
        "id": 20889,
        "title": "Kensei Blades",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/c5b01cf0e4899506c907a7bc8e92aa8367e6e6e5.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/20889.png"
            }
        }
    }, {
        "id": 20923,
        "title": "It Came From Venus JP",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/2b5f9ba6242277efcad5d7f6c0d52de785a0f3b3.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/20923.png"
            }
        }
    }, {
        "id": 20924,
        "title": "Puppy Love",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/4f059f7d06291d5e487f6eca8d8cfd71b2da1189.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/20924.png"
            }
        }
    }, {
        "id": 20925,
        "title": "The Curious Machine",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/c15dbd7bc478a649e29d59250a27e7a7a67c7d3f.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/20925.png"
            }
        }
    }, {
        "id": 20926,
        "title": "Tycoons",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/e692e191425d11f5efa4c58555a95a885f61330b.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/20926.png"
            }
        }
    }, {
        "id": 20927,
        "title": "Woodlanders",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/7dd86749662b347ac1aaa884af05f485e34cc44b.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/20927.png"
            }
        }
    }, {
        "id": 20928,
        "title": "Hearts Desire",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/273b6cb165fb8ebdf22698bc71aa9e943fc506ad.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/20928.png"
            }
        }
    }, {
        "id": 21010,
        "title": "Expansion",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/b08a44dd30034b5602bc5d2f6473d01f53a3279b.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/21010.png"
            }
        }
    }, {
        "id": 21171,
        "title": "Triple Cash Or Crash",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/8e2707343c0c73b70b16c6c890cae338bfa7dd4c.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/21171.png"
            }
        }
    }, {
        "id": 21586,
        "title": "Mr. Vegas 2: Big Money Tower",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": null,
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/21586.png"
            }
        }
    }, {
        "id": 21587,
        "title": "Charms & Treasures",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": null,
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/21587.png"
            }
        }
    }, {
        "id": 21588,
        "title": "Supreme 777 Jackpots",
        "platform": "desktop-and-mobile",
        "type": "table",
        "subtype": "live-casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": null,
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/21588.png"
            }
        }
    }, {
        "id": 21589,
        "title": "Hot Lucky 7's",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": null,
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/21589.png"
            }
        }
    }, {
        "id": 21590,
        "title": "Pho Sho",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": null,
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/21590.png"
            }
        }
    }, {
        "id": 22171,
        "title": "Wish Granted",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": null,
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/22171.png"
            }
        }
    }, {
        "id": 22172,
        "title": "April Fury and the Chamber of Scarabs",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": null,
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/22172.png"
            }
        }
    }, {
        "id": 22209,
        "title": "72 Fortunes",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": null,
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/22209.png"
            }
        }
    }, {
        "id": 22281,
        "title": "Super Golden Dragon Inferno",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": null,
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/22281.png"
            }
        }
    }, {
        "id": 24213,
        "title": "Triple Lucky 8's",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": null,
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/24213.png"
            }
        }
    }, {
        "id": 24253,
        "title": "Enchanted: Forest of Fortune - Hold & Win",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": null,
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/24253.png"
            }
        }
    }, {
        "id": 24893,
        "title": "Rise of Triton",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/b12bf156f5c7a9586a82dfd36f4b8b46c8f8031b.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/24893.png"
            }
        }
    }, {
        "id": 24894,
        "title": "Tycoons: Billionaire Bucks",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/f3a494d7a789d2c12a67488d5a447d6df64665aa.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/24894.png"
            }
        }
    }, {
        "id": 25083,
        "title": "Plinko Rush",
        "platform": "desktop-and-mobile",
        "type": "arcade",
        "subtype": "live-casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/d53f3fc2d66a4b9aa1a01868e5447d92.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/25083.png"
            }
        }
    }, {
        "id": 25124,
        "title": "Rockstar WT",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/5577ddfb9f974d28af0554e28ebc8435.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/25124.png"
            }
        }
    }, {
        "id": 25489,
        "title": "Take the Vault - Hold & Win",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/a8b5e43394c84bf1a5e52e62493129d8.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/25489.png"
            }
        }
    }, {
        "id": 25697,
        "title": "Tiger’s Luck – HOLD & WIN",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/5ef4fc264a31448da33a22de1f0f9b84.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/25697.png"
            }
        }
    }, {
        "id": 25844,
        "title": "COINS OF RA",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/b365a95ff8cd46f68c5ab7ebe8ad72a2.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/25844.png"
            }
        }
    }, {
        "id": 26256,
        "title": "HEIST: BANK RUSH – HOLD & WIN",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/4ea76ad64c294f689b8b816bee880032.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/26256.png"
            }
        }
    }, {
        "id": 26848,
        "title": "STAMPEDE GOLD",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/e20aec288d3d4cfcb821a5fc0c5678ce.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/26848.png"
            }
        }
    }, {
        "id": 26938,
        "title": "CAISHEN GOD of FORTUNE",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-06-05",
        "vendorGroups": [],
        "details": {
            "image": "https://stage.gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/ec23facc879b4832ad090ff2f854c34f.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/26938.png"
            }
        }
    }, {
        "id": 30517,
        "title": "A Night in Paris JP",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-03",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/d14301d5d1e0bdea162a7694304857b6b03ea3d2.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/30517.png"
            },
            "rtp": 96.92,
            "volatility": "medium"
        }
    }, {
        "id": 30518,
        "title": "The Curious Machine Plus",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-03",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/5dbdc7c5bc01ab52be11a09b7b4c46f53eb85410.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/30518.png"
            },
            "rtp": 97.5,
            "volatility": "medium"
        }
    }, {
        "id": 30519,
        "title": "21 Burn Blackjack",
        "platform": "desktop-and-mobile",
        "type": "table",
        "subtype": "live-casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-03",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/9ee03fd322a5ef9a70c6bee2e280fd47e4ac5a5f.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/30519.png"
            },
            "rtp": 99.5
        }
    }, {
        "id": 30520,
        "title": "American Blackjack",
        "platform": "desktop-and-mobile",
        "type": "table",
        "subtype": "live-casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-03",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/fcd6ab3484871b3255e3f0b5d7ca79c62de4d81a.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/30520.png"
            },
            "rtp": 97.68
        }
    }, {
        "id": 30521,
        "title": "American Roulette",
        "platform": "desktop-and-mobile",
        "type": "table",
        "subtype": "live-casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-03",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/81fc3eafb08c016003a1e2b8575fb9669d5013ae.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/30521.png"
            },
            "rtp": 94.74
        }
    }, {
        "id": 30522,
        "title": "Baccarat",
        "platform": "desktop-and-mobile",
        "type": "table",
        "subtype": "live-casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-03",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/43b35c5fd5d59d0ac5b743be60a868d12081474b.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/30522.png"
            },
            "rtp": 98.99
        }
    }, {
        "id": 30523,
        "title": "Caribbean Poker",
        "platform": "desktop-and-mobile",
        "type": "table",
        "subtype": "live-casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-03",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/b40aa472b71071fe40b473671905d12745040d8d.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/30523.png"
            },
            "rtp": 94.78
        }
    }, {
        "id": 30524,
        "title": "European Blackjack",
        "platform": "desktop-and-mobile",
        "type": "table",
        "subtype": "live-casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-03",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/3e7daedeaee5d04d72eaa478c3dc2fdc23f28754.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/30524.png"
            },
            "rtp": 99.38
        }
    }, {
        "id": 30525,
        "title": "European Roulette",
        "platform": "desktop-and-mobile",
        "type": "table",
        "subtype": "live-casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-03",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/2349a14d78704d54e291fd82e70e055e03eae21a.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/30525.png"
            },
            "rtp": 97.3
        }
    }, {
        "id": 30526,
        "title": "Oasis Poker",
        "platform": "desktop-and-mobile",
        "type": "table",
        "subtype": "live-casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-03",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/3f02eae7db0bfadbeaeb65115dcf1584cf2413b0.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/30526.png"
            },
            "rtp": 99.39
        }
    }, {
        "id": 30527,
        "title": "Three Card Rummy",
        "platform": "desktop-and-mobile",
        "type": "table",
        "subtype": "live-casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-03",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/efa1be1be62a1d029aae352389c245693a0fd26e.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/30527.png"
            },
            "rtp": 98.04
        }
    }, {
        "id": 30528,
        "title": "Triple Edge Poker",
        "platform": "desktop-and-mobile",
        "type": "table",
        "subtype": "live-casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-03",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/8c4a52db04360bb264dda921b076174a5b37ba43.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/30528.png"
            },
            "rtp": 97.99
        }
    }, {
        "id": 30529,
        "title": "Zoom Roulette",
        "platform": "desktop-and-mobile",
        "type": "table",
        "subtype": "live-casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-03",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/bbb44830203be0b692741efadaadad5204d9f284.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/30529.png"
            },
            "rtp": 97.3
        }
    }, {
        "id": 30533,
        "title": "GEMMED!",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-03",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/258a92b1731c1ce8d056e964735c78817df868e9.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/30533.png"
            },
            "rtp": 96.46,
            "volatility": "high"
        }
    }, {
        "id": 31928,
        "title": "The Slotfather Book of wins",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-03",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/1a052c57d47c4234a31bad9f151c8868.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/31928.png"
            }
        }
    }, {
        "id": 32001,
        "title": "COINS OF ALKEMOR – HOLD & WIN",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-03",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/c9c03cf31214416fae72229ac95b0501.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32001.png"
            }
        }
    }, {
        "id": 32124,
        "title": "A Big Catch – HOLD & WINTM",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-03",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/8a2c45cf69fd44c4a06a6eddd90513ab.jpg",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32124.png"
            }
        }
    }, {
        "id": 32212,
        "title": "TAKE THE SHOT",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-03",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/aae90e4b7a474ebda355ba5c35f4951e.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32212.png"
            }
        }
    }, {
        "id": 32337,
        "title": "GOLDEN DESTINY – HOLD & WIN",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-03",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/8f840a7e532d45dc812a56f81a14b6e2.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32337.png"
            }
        }
    }, {
        "id": 32795,
        "title": "2 Million B.C.",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/6edbba0a86b2e12b8c67989d94231e1c74fc9d5c.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32795.png"
            },
            "rtp": 91.94,
            "volatility": "medium"
        }
    }, {
        "id": 32796,
        "title": "4 Seasons",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/4a78c3aa34e2ff236a73576c9853193bff9655be.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32796.png"
            },
            "rtp": 95.3,
            "volatility": "medium"
        }
    }, {
        "id": 32797,
        "title": "7th Heaven",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/570ee23d35060a182ecc20d4c3c7967b6d02f782.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32797.png"
            },
            "rtp": 95.8,
            "volatility": "medium"
        }
    }, {
        "id": 32798,
        "title": "A Christmas Carol",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/c2182d4521ec77cefa0ae22756ee7806ed24c6df.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32798.png"
            },
            "rtp": 94.58,
            "volatility": "medium"
        }
    }, {
        "id": 32799,
        "title": "A Night in Paris",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/222482fd889a21a9c9bbd2e7f667800669a6e36a.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32799.png"
            },
            "rtp": 96.92,
            "volatility": "medium"
        }
    }, {
        "id": 32800,
        "title": "After Night Falls",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/6a6bd74399962821887b88a0b881ab4a3c8328e6.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32800.png"
            },
            "rtp": 97.27,
            "volatility": "medium"
        }
    }, {
        "id": 32801,
        "title": "Alkemor's Tower",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/1b72ada1ea8fa3952563444bce41046c7d07ef73.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32801.png"
            },
            "rtp": 94.96,
            "volatility": "medium"
        }
    }, {
        "id": 32802,
        "title": "Arrival",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/444572b99735ffae1ab64c51ef5339ccdb88d830.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32802.png"
            },
            "rtp": 92.26,
            "volatility": "medium"
        }
    }, {
        "id": 32803,
        "title": "At The Copa",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/52942dd04f4c4571a8d3aff003b6216c67907656.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32803.png"
            },
            "rtp": 97.42,
            "volatility": "medium"
        }
    }, {
        "id": 32804,
        "title": "At the Movies",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/56b3f08f214e08df3a4452eb5e0d9332904764e9.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32804.png"
            },
            "rtp": 94.75,
            "volatility": "medium"
        }
    }, {
        "id": 32805,
        "title": "Barbary Coast",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/19f1be2a4e805fd5f0611dab0bf6392563e45709.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32805.png"
            },
            "rtp": 93.2,
            "volatility": "medium"
        }
    }, {
        "id": 32806,
        "title": "Birds",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/deeb8f483359ae09cfa5d3a13926a6ff66db24eb.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32806.png"
            },
            "rtp": 96.48,
            "volatility": "medium"
        }
    }, {
        "id": 32807,
        "title": "Black Gold",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/135022a0d4ba32d84165e4706017e0df939841db.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32807.png"
            },
            "rtp": 94.31,
            "volatility": "medium"
        }
    }, {
        "id": 32808,
        "title": "Blood Eternal",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/cbc6e2122126b9bb6a108c050dbef80678541c64.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32808.png"
            },
            "rtp": 95.03,
            "volatility": "medium"
        }
    }, {
        "id": 32809,
        "title": "Boomanji",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/49c5734935cebe987e5dbefcab97dbddb54c959f.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32809.png"
            },
            "rtp": 95.96,
            "volatility": "high"
        }
    }, {
        "id": 32810,
        "title": "Charms And Clovers",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/66840cdea981f09175bf103f5fc4b1941c824e03.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32810.png"
            },
            "rtp": 96.31,
            "volatility": "medium"
        }
    }, {
        "id": 32811,
        "title": "Dr. Jekyll & Mr. Hyde",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/39361993eddf06d39460187a0994b8bb8d10b604.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32811.png"
            },
            "rtp": 96.17,
            "volatility": "medium"
        }
    }, {
        "id": 32812,
        "title": "Enchanted",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/37bf001b5a80bad9bd9fe6562291bf7d295b80f3.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32812.png"
            },
            "rtp": 89.4,
            "volatility": "low"
        }
    }, {
        "id": 32813,
        "title": "Enchanted JP",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/cdaa2ecd725659251ffad61bc2cdf2b3326cb316.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32813.png"
            }
        }
    }, {
        "id": 32814,
        "title": "Event Horizon",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/a3eea254021d2c4cf39dff6c1e8426fed27c0785.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32814.png"
            },
            "rtp": 96.51,
            "volatility": "high"
        }
    }, {
        "id": 32815,
        "title": "Fa-Fa Twins",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/c49811878cfaa7225cdfbd4b29e038c7c639b1d7.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32815.png"
            },
            "rtp": 95.29,
            "volatility": "medium"
        }
    }, {
        "id": 32816,
        "title": "Fire & Steel",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/7456c57a4413a0aa1f8463662c83a32a1a855230.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32816.png"
            },
            "rtp": 95.21,
            "volatility": "medium"
        }
    }, {
        "id": 32817,
        "title": "Frankenslot's Monster",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/afecb3b7c3b4dcd78c9b13ff7864baa6dc7208ed.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32817.png"
            },
            "rtp": 96.83,
            "volatility": "medium"
        }
    }, {
        "id": 32818,
        "title": "Fruit Zen",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/177e47882fbb66bb37b0271f7abd7b543386f632.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32818.png"
            },
            "rtp": 95.96,
            "volatility": "medium"
        }
    }, {
        "id": 32819,
        "title": "Giovanni's Gems",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/e19e22cb5bbb46cd1ebb01e97ce0c334e2d88826.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32819.png"
            },
            "rtp": 94.35,
            "volatility": "medium"
        }
    }, {
        "id": 32820,
        "title": "Gladiator",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/8eb4703064df64b3a5e53106a218ef1c6ee5bbbe.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32820.png"
            },
            "rtp": 92.67,
            "volatility": "medium"
        }
    }, {
        "id": 32821,
        "title": "Glam Life",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/d79ede036dc848f3fbafabc468d402a3aa3a4e66.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32821.png"
            },
            "rtp": 92.02,
            "volatility": "medium"
        }
    }, {
        "id": 32822,
        "title": "Good Girl, Bad Girl",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/6d0e8cb4a9280c114225dea9033bc891259887bc.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32822.png"
            },
            "volatility": "medium"
        }
    }, {
        "id": 32823,
        "title": "Great 88",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/7ed532a1db4c780e7c003fb41d672a9d54477f96.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32823.png"
            },
            "rtp": 95.36,
            "volatility": "high"
        }
    }, {
        "id": 32824,
        "title": "Greedy Goblins",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/5d06b5caa3f51e0e8b1de473cb533b1f901ce71a.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32824.png"
            },
            "rtp": 97.2,
            "volatility": "high"
        }
    }, {
        "id": 32825,
        "title": "Gypsy Rose",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/0902edfcb547599cf78b1a138fc832ae6b20dba8.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32825.png"
            },
            "rtp": 97.63,
            "volatility": "medium"
        }
    }, {
        "id": 32826,
        "title": "Heist",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/f9bf44831114b8c2954da59561b30a07398adfe9.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32826.png"
            },
            "rtp": 93.8,
            "volatility": "medium"
        }
    }, {
        "id": 32827,
        "title": "House of Fun",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/cc0e1f4dea79a7b75697f38986d6a1bf445e8e2d.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32827.png"
            },
            "rtp": 94.96,
            "volatility": "medium"
        }
    }, {
        "id": 32828,
        "title": "It Came From Venus JP Plus",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/444a1bc0e27d0a887118852f3f539d2c08cd79e8.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32828.png"
            }
        }
    }, {
        "id": 32829,
        "title": "Jumbo Joker",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/9850e0ee167932ddc1274a7ebf5849a12bea14f0.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32829.png"
            },
            "rtp": 95,
            "volatility": "high"
        }
    }, {
        "id": 32830,
        "title": "Kawaii Kitty",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/ac463ebc8ccdb7e55de59f664d00c1535d1644fa.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32830.png"
            },
            "rtp": 95.27,
            "volatility": "medium"
        }
    }, {
        "id": 32831,
        "title": "Legend Of The Nile",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/e24176d27231addc7bfc0f7de456dcf751ae4c6b.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32831.png"
            },
            "rtp": 95.62,
            "volatility": "high"
        }
    }, {
        "id": 32832,
        "title": "Lucky Seven",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/4e4b0b2e043914f07215109722cb323157e9cae0.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32832.png"
            },
            "rtp": 97,
            "volatility": "medium"
        }
    }, {
        "id": 32833,
        "title": "Madder Scientist",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/75a0b119fb83581c19a441ec012b9e436cbbed4c.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32833.png"
            },
            "rtp": 95.18,
            "volatility": "medium"
        }
    }, {
        "id": 32834,
        "title": "Magic Shoppe",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/e3b87030d2e734ac44db3694a822b3321322ff62.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32834.png"
            },
            "rtp": 94.58,
            "volatility": "medium"
        }
    }, {
        "id": 32835,
        "title": "Mamma Mia",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/86b9fb82d47120ec22bb3bebc68c6d373b116f9a.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32835.png"
            },
            "rtp": 93.46,
            "volatility": "low"
        }
    }, {
        "id": 32836,
        "title": "Mega Gems",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/688d3ca59f247c99bbaffddc00e6b7b3b4a6acca.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32836.png"
            },
            "rtp": 95.18,
            "volatility": "high"
        }
    }, {
        "id": 32837,
        "title": "Mega Glam Life JP",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/70b4e0ea616a051433f908932594219bfec53998.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32837.png"
            }
        }
    }, {
        "id": 32838,
        "title": "More Gold Diggin",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/2c67cbdcc967fb2defd1742a595c78062e383940.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32838.png"
            },
            "rtp": 93.66,
            "volatility": "high"
        }
    }, {
        "id": 32839,
        "title": "Mr. Vegas",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/68ffdaab9229fc07fbf1c2bb84624d5ac3f61415.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32839.png"
            },
            "rtp": 93.6,
            "volatility": "medium"
        }
    }, {
        "id": 32840,
        "title": "Ogre Empire",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/b27fd5ba3a90cd58d400a1997de4e2567388d926.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32840.png"
            },
            "rtp": 95.22,
            "volatility": "medium"
        }
    }, {
        "id": 32841,
        "title": "Once Upon A Time",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/3f561b02d843ec7dcafadf2721d381b7321c7b05.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32841.png"
            },
            "rtp": 95.28,
            "volatility": "medium"
        }
    }, {
        "id": 32842,
        "title": "Paco and the Popping Peppers",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/511cebca114f504e47cf08acb9a053e39c6def57.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32842.png"
            },
            "rtp": 94.29,
            "volatility": "medium"
        }
    }, {
        "id": 32843,
        "title": "Pinocchio",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/aa560ec93fb953f32018566bf867fd897ec97c78.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32843.png"
            },
            "rtp": 96.53,
            "volatility": "low"
        }
    }, {
        "id": 32844,
        "title": "Puppy Love Plus",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/ab9045be94dc42399a9b797ac5e7d4d52f5b0055.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32844.png"
            },
            "rtp": 97.23,
            "volatility": "medium"
        }
    }, {
        "id": 32845,
        "title": "Reels Of Wealth",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/bf33c7fcede63fe53ab5f1ce7ba7518aa49ab6cf.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32845.png"
            },
            "rtp": 95.29,
            "volatility": "high"
        }
    }, {
        "id": 32846,
        "title": "Rook's Revenge",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/f0fa0c97f4296ceca9f8ed6e45543aea5806294f.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32846.png"
            },
            "rtp": 93.66,
            "volatility": "high"
        }
    }, {
        "id": 32847,
        "title": "Safari Sam",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/5f42c94351c23421eefd5143a51c5705563f0ab5.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32847.png"
            },
            "rtp": 97.5,
            "volatility": "medium"
        }
    }, {
        "id": 32848,
        "title": "Sin City Nights",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/f69868c016a5f8334d37139ffa8c43d767391b85.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32848.png"
            },
            "rtp": 93.66,
            "volatility": "medium"
        }
    }, {
        "id": 32849,
        "title": "Slotfather",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/20bf0212b9ae46057478686a24cd2e004e63c992.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32849.png"
            },
            "rtp": 95.69,
            "volatility": "medium"
        }
    }, {
        "id": 32850,
        "title": "Slotfather 2",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/4f92772d76aa82bb3b95877beafb5dd7be6bc010.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32850.png"
            },
            "rtp": 96.6,
            "volatility": "medium"
        }
    }, {
        "id": 32851,
        "title": "Slotfather JP",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/bf4811e082bb8f14518e73ee24d072422c6a16ea.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32851.png"
            }
        }
    }, {
        "id": 32852,
        "title": "Slots Angels",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/6a02add6e384ec2b2b62126edf8b0c06ecae258b.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32852.png"
            },
            "rtp": 96.89,
            "volatility": "medium"
        }
    }, {
        "id": 32853,
        "title": "Stampede",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/b99bc2e9dedbcdad377abce252f85e6bc473c372.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32853.png"
            },
            "rtp": 95.27,
            "volatility": "high"
        }
    }, {
        "id": 32854,
        "title": "Sugar Pop 2",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/ebbc260e53756ec963b87d1bfe087ad9a4484d2f.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32854.png"
            },
            "rtp": 96.46,
            "volatility": "medium"
        }
    }, {
        "id": 32855,
        "title": "The Angler",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/dd4269a1c116027b62222c8765e095049c1669fd.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32855.png"
            },
            "rtp": 97.1,
            "volatility": "medium"
        }
    }, {
        "id": 32856,
        "title": "The Golden Owl of Athena",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/56eea0bfece39a96cfed1372a8fe0e13058b06b3.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32856.png"
            },
            "rtp": 95.05,
            "volatility": "medium"
        }
    }, {
        "id": 32857,
        "title": "The Tipsy Tourist",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/f9d6be4560ddfa1535d5fae6b25d8201c03f60f7.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32857.png"
            },
            "rtp": 97.1,
            "volatility": "high"
        }
    }, {
        "id": 32858,
        "title": "The True Sheriff",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/4cb38718ff7f6c975727e32c2bcb4371bb26d683.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32858.png"
            },
            "rtp": 97.03,
            "volatility": "medium"
        }
    }, {
        "id": 32859,
        "title": "Tiger's Claw",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/1e99f486a542f214631615cd3a8ac51faaf348c0.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32859.png"
            },
            "rtp": 95.14,
            "volatility": "high"
        }
    }, {
        "id": 32860,
        "title": "Treasure Room",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/c24e3b1c589c8ad514f2ba8710f48d11ff22c029.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32860.png"
            },
            "rtp": 94,
            "volatility": "medium"
        }
    }, {
        "id": 32861,
        "title": "True Illusions",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/05fb978ccf975dbad401edfef3470901af93dc4b.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32861.png"
            },
            "rtp": 96.62,
            "volatility": "medium"
        }
    }, {
        "id": 32862,
        "title": "Tycoons Plus",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/64aefb77f4e52c900169c27f85bd95975257aeb9.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32862.png"
            },
            "rtp": 95.34,
            "volatility": "medium"
        }
    }, {
        "id": 32863,
        "title": "Under the Bed",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/e528fae2b2c0ddeed983f83ab0ab73f339d4d7bc.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32863.png"
            },
            "rtp": 97.4,
            "volatility": "medium"
        }
    }, {
        "id": 32864,
        "title": "Under the Sea",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/2240ef4a706e2d16691e43e7ea4b1d89a2efac2a.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32864.png"
            },
            "rtp": 96.4,
            "volatility": "medium"
        }
    }, {
        "id": 32865,
        "title": "Viking Age",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/6cc660e203317f8e82f919aa819466d605a6a457.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32865.png"
            },
            "rtp": 94.2,
            "volatility": "medium"
        }
    }, {
        "id": 32866,
        "title": "Weekend In Vegas",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/f17da43f8c1bc10f371e911f386984393b3e8431.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32866.png"
            },
            "rtp": 96.6,
            "volatility": "medium"
        }
    }, {
        "id": 32867,
        "title": "Genie's Fortune",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/7aeceae634bbbb3e79e4bb49bf045f65f1982cf9.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32867.png"
            },
            "rtp": 95.61,
            "volatility": "medium"
        }
    }, {
        "id": 32868,
        "title": "Single Deck Blackjack",
        "platform": "desktop-and-mobile",
        "type": "table",
        "subtype": "live-casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/f47c1df49ec648105c5ed980eaf46c0856d236dd.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32868.png"
            },
            "rtp": 99.55
        }
    }, {
        "id": 32869,
        "title": "Top Card Trumps",
        "platform": "desktop-and-mobile",
        "type": "table",
        "subtype": "live-casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/9f16b0ff1497c3a8d79152dcbcf97420242474f6.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32869.png"
            }
        }
    }, {
        "id": 32882,
        "title": "Faerie Spells",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/3e13b835bcb89004877e1e746d17ac58c241bf70.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32882.png"
            },
            "rtp": 96.03,
            "volatility": "medium"
        }
    }, {
        "id": 32883,
        "title": "Yak, Yeti and Roll",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/a7814f7bf316a4c20b6e0433c7733958d30dfb5e.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32883.png"
            },
            "rtp": 95.93,
            "volatility": "medium"
        }
    }, {
        "id": 32884,
        "title": "Chilli Pop",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/f873e8c215c848f5430212906b32bb4ba00d89bb.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32884.png"
            },
            "rtp": 95.38,
            "volatility": "medium"
        }
    }, {
        "id": 32887,
        "title": "Carnaval Forever",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/f4ebfab49afe9f11b3835844726dc8aa28bba5d4.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32887.png"
            },
            "rtp": 96.22,
            "volatility": "medium"
        }
    }, {
        "id": 32959,
        "title": "Viking Voyage",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/e42baa3c915e329dcec2467e131cf080efc9c533.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32959.png"
            },
            "rtp": 95.85,
            "volatility": "high"
        }
    }, {
        "id": 32960,
        "title": "Fruit Bat Crazy",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/de5d4316b6c631a688d76c851a58572b32bf16ec.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32960.png"
            },
            "rtp": 95.21,
            "volatility": "medium"
        }
    }, {
        "id": 32961,
        "title": "Spinfinity Man",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/8b20e0301abb0e473c151e4700e89089ba206561.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32961.png"
            },
            "rtp": 95.8,
            "volatility": "high"
        }
    }, {
        "id": 32963,
        "title": "Gold Canyon",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/680f73f358dc7b7f002d5107ac4cc57e61565551.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32963.png"
            },
            "rtp": 96.13,
            "volatility": "high"
        }
    }, {
        "id": 32982,
        "title": "Wolf Moon Rising",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/4e931409af886264bbdafcf8ffa59e50806166e9.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32982.png"
            },
            "rtp": 96.52,
            "volatility": "medium"
        }
    }, {
        "id": 32984,
        "title": "BAMBOO RUSH",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/dbfc31058c8d1f23c6bf26fcc10854e0e36dc0dd.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32984.png"
            },
            "rtp": 96.9,
            "volatility": "medium"
        }
    }, {
        "id": 32985,
        "title": "Caishen’s Arrival",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/16af84045ad3df8807a6c7a0324af1d93fe69d94.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32985.png"
            },
            "rtp": 95.87,
            "volatility": "high"
        }
    }, {
        "id": 32986,
        "title": "Take The Bank",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/f7452fcf49e8ec80edddd160a14a4a42784485f8.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32986.png"
            },
            "rtp": 96.1,
            "volatility": "medium"
        }
    }, {
        "id": 32988,
        "title": "Dragon & Phoenix",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/613b08a6394f71c40b73cc85a9b650498feb7eb0.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/32988.png"
            },
            "rtp": 96.01
        }
    }, {
        "id": 33003,
        "title": "Super Sweets",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/ff0901670757fd2b3943063247a3d352b8f22ea3.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/33003.png"
            },
            "rtp": 95.03,
            "volatility": "medium"
        }
    }, {
        "id": 33005,
        "title": "Total Overdrive",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/ea0abbbd0ad5daa7d17593757fed3f7a9af22b95.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/33005.png"
            },
            "rtp": 96.92,
            "volatility": "medium"
        }
    }, {
        "id": 33006,
        "title": "Spring Tails",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/8b56d8596912fadcad86296d14e0207e0e400955.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/33006.png"
            },
            "rtp": 95.9,
            "volatility": "very-high"
        }
    }, {
        "id": 33034,
        "title": "Monster Pop",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/64585e42e030b89fbc3456cd0525d5bdb208c83a.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/33034.png"
            },
            "rtp": 97.07,
            "volatility": "medium"
        }
    }, {
        "id": 33037,
        "title": "Back to Venus",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/cd28fbab876450d31c03c5d71d2656619ff768c2.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/33037.png"
            },
            "rtp": 97.07,
            "volatility": "medium"
        }
    }, {
        "id": 33050,
        "title": "Quest To The West",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/5152c15092584ca9de24edc53a0054f7938234a0.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/33050.png"
            },
            "rtp": 97.53,
            "volatility": "medium"
        }
    }, {
        "id": 33054,
        "title": "The Hive",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/e6ef71639157661237e1d5cb3929c439c486312d.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/33054.png"
            },
            "rtp": 96.13,
            "volatility": "low"
        }
    }, {
        "id": 33072,
        "title": "Mystic Hive",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/49aa976fbd98310901a3e5443942fdc5e881ab4c.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/33072.png"
            },
            "rtp": 96.13,
            "volatility": "low"
        }
    }, {
        "id": 33078,
        "title": "Dim Sum Prize",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/9905a36d9cf26a37dbb72aa5f01bdb2525a36401.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/33078.png"
            },
            "rtp": 97.18,
            "volatility": "medium"
        }
    }, {
        "id": 33079,
        "title": "Primal Hunt",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/d9ce44299fdc408899de6b28af74332310b72013.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/33079.png"
            },
            "rtp": 96.1
        }
    }, {
        "id": 33169,
        "title": "Book of Darkness",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/1d3b399de09537d244139c8ea4b939c8806c2c36.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/33169.png"
            },
            "rtp": 96.48,
            "volatility": "high"
        }
    }, {
        "id": 33232,
        "title": "Gears of Time",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/8000c1df76b5dbf16ce5ead8eee048031b2ac7b6.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/33232.png"
            },
            "rtp": 96.98,
            "volatility": "medium"
        }
    }, {
        "id": 33233,
        "title": "Take Santa's Shop",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/e067ad85bc39cd730d4a0580c7866b83395378d8.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/33233.png"
            },
            "rtp": 96.08,
            "volatility": "medium"
        }
    }, {
        "id": 33293,
        "title": "Golden Horns",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/417c1727d8fc08a29ea6dda24459b20d05fd26b1.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/33293.png"
            },
            "rtp": 96.26,
            "volatility": "high"
        }
    }, {
        "id": 33308,
        "title": "Take Olympus",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/8437b1c2fc4b0d7c30deefffc097b1f079826702.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/33308.png"
            },
            "rtp": 95.49,
            "volatility": "low"
        }
    }, {
        "id": 33344,
        "title": "Safari Sam 2",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/06c3185256cda9c484857ed3ea3b135a35fe4cb4.jpeg",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/33344.png"
            },
            "rtp": 96.3,
            "volatility": "medium"
        }
    }, {
        "id": 33345,
        "title": "Stacked",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/b34b5acf1e5bd6987d330e0a2a8e1fc9c0761ec7.jpeg",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/33345.png"
            },
            "rtp": 96.39
        }
    }, {
        "id": 33360,
        "title": "Mr.Macau",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/a936cf7a76bf008cc3283ecbc53d68aaa5fba1bd.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/33360.png"
            },
            "rtp": 97.07,
            "volatility": "medium"
        }
    }, {
        "id": 33383,
        "title": "Wild Drops",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/4a012f6bfc9c04cfb792ef06e8eec1f4d2772819.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/33383.png"
            },
            "rtp": 96.11,
            "volatility": "high"
        }
    }, {
        "id": 33391,
        "title": "88 Frenzy Fortune",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-09-09",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/c6b4cfa8de4f15e781ce1560e874adf4e5e36892.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/33391.png"
            },
            "rtp": 96,
            "volatility": "medium"
        }
    }, {
        "id": 33951,
        "title": "CHILLIPOP: GET EM ALL - HOLD & WIN",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-12-16",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/7a691ed57ec44bc082dc6a2a2f50961d.jpg",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/33951.png"
            }
        }
    }, {
        "id": 33976,
        "title": "TREASURES OF CLEOPATRA",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-12-16",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/f16eb65ca098416ea0a68909d69a91fc.jpg",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/33976.png"
            }
        }
    }, {
        "id": 34008,
        "title": "Olympus Plinko",
        "platform": "desktop-and-mobile",
        "type": "other",
        "subtype": "live-casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-12-16",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/322ec557de654d859940b24fe8434759.jpg",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/34008.png"
            }
        }
    }, {
        "id": 34102,
        "title": "Super Sugar Pop – HOLD & WIN",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-12-16",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/8dbbe74d176d40718c70d4fd98a3fb0d.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/34102.png"
            }
        }
    }, {
        "id": 34183,
        "title": "COINS OF ZEUS – HOLD & WIN",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-12-16",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/7cd7e5e415b24d18b4efe19d02511f95.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/34183.png"
            }
        }
    }, {
        "id": 34238,
        "title": "ULTIMATE GOLDEN DRAGON INFERNO – HOLD & WIN",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-12-16",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/9e1dbcbd606047e289732af51a325546.png",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/34238.png"
            }
        }
    }, {
        "id": 34307,
        "title": "COINS OF CHRISTMAS – HOLD & WIN",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2024-12-16",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/7c1811c943a142c680a9c93f7f6ac030.jpg",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/34307.png"
            }
        }
    }, {
        "id": 34586,
        "title": "Fury Dragon – Hold & Win",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2025-02-03",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/472d4b516be74f53a46f14379160108f.jpg",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/34586.png"
            }
        }
    }, {
        "id": 34610,
        "title": "THE TIPSY TOURIST: BEACH BONANZA – HOLD & WINTM",
        "platform": "desktop-and-mobile",
        "type": "slots",
        "subtype": "casino",
        "enabled": 1,
        "fun_mode": 0,
        "campaigns": 0,
        "vendor": "betsoft",
        "created_at": "2025-02-03",
        "vendorGroups": [],
        "details": {
            "image": "https://gis-static.com/games/011be2c798c16b1ad58cf30f3aa78dcb/Betsoft/f581a5afc7184a178fcd5a267bdedc75.jpg",
            "thumbnails": {
                "300x300": "https://cdn.onlinegames99.com/thumbnails/34610.png"
            }
        }
    }];
// Flatten and convert JSON to CSV
const flattenedData = jsonData.map(item => ({
    id: item.id,
    title: item.title,
    platform: item.platform,
    type: item.type,
    subtype: item.subtype,
    enabled: item.enabled,
    fun_mode: item.fun_mode,
    campaigns: item.campaigns,
    vendor: item.vendor,
    created_at: item.created_at,
    vendor_groups: JSON.stringify(item.vendorGroups),
    details_description_en: item.details?.description?.en || "", // Use optional chaining and fallback to empty string if undefined
    details_thumbnails_300x300: item.details?.thumbnails?.['300x300'] || "" // Same for thumbnails
}));

// Convert to CSV
const csv = parse(flattenedData);

// Write CSV to file
fs.writeFileSync('games1.csv', csv);

console.log('CSV file created successfully!');
