// reports/sessionReportPdf.js
// Date+time-ranged session reports used by the Users list "Casino report" and
// "Sports report" actions. Unlike playerReportPdf (which is a whole-account
// summary), these answer disputes: they list every individual callback / bet in
// the chosen window with session id, round id, amount and running balance, and
// run integrity checks over that window.
//
//   const { generateCasinoSessionReport, generateSportsSessionReport } = require('./reports/sessionReportPdf');
//   await generateCasinoSessionReport(res, { uid, from, to });   // from/to ISO strings
//
// All times are printed in IST — the window itself is compared in UTC, so the
// caller is expected to send real instants (the admin panel converts the
// operator's IST picks to UTC before calling).
const PDFDocument = require('pdfkit');
const pg = require('../General/Model');

const C = {
  primary: '#2B6EF5', dark: '#15182B', body: '#2D3142', muted: '#6B7280',
  line: '#E3E7F0', green: '#0E9F5B', red: '#D64560', headbg: '#0E1831',
  zebra: '#F7F9FC', chipbg: '#EAF1FE', okbg: '#E8F7F0', warnbg: '#FDF3E2', warn: '#9A6B10',
};

const IST = 'Asia/Kolkata';
const amt = n => (Number(n) || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 });
const signed = n => (Number(n) > 0 ? '+' : '') + amt(n);
const pnlC = n => (Number(n) > 0 ? C.green : Number(n) < 0 ? C.red : C.body);
const istDT = d => new Date(d).toLocaleString('en-GB', { timeZone: IST, day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
const istHMS = d => new Date(d).toLocaleString('en-GB', { timeZone: IST, hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });

// Hard cap so a wide window can't stream a 500-page PDF. Truncation is always
// stated on the page — never silently dropped.
const MAX_LOG_ROWS = 2000;

// ---------------------------------------------------------------- pdf helpers
function makeDoc(res, filename) {
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
  const doc = new PDFDocument({ size: 'A4', margins: { top: 54, bottom: 54, left: 42, right: 42 } });
  doc.pipe(res);
  return doc;
}

function layout(doc) {
  const LEFT = doc.page.margins.left;
  const RIGHT = doc.page.width - doc.page.margins.right;
  const W = RIGHT - LEFT;
  const BOTTOM = doc.page.height - doc.page.margins.bottom;
  const ensure = h => { if (doc.y + h > BOTTOM) doc.addPage(); };

  const banner = (title, sub, sub2) => {
    doc.rect(0, 0, doc.page.width, 96).fill(C.primary);
    doc.fillColor('#FFFFFF').font('Helvetica-Bold').fontSize(20).text(title, LEFT, 24, { width: W });
    doc.fillColor('#DCE8FF').font('Helvetica').fontSize(10).text(sub, LEFT, 54, { width: W });
    doc.fillColor('#DCE8FF').font('Helvetica').fontSize(9).text(sub2, LEFT, 72, { width: W });
    doc.y = 116;
  };

  const h2 = t => {
    ensure(40); doc.moveDown(0.6);
    doc.fillColor(C.dark).font('Helvetica-Bold').fontSize(13).text(t, LEFT, doc.y);
    doc.moveDown(0.25);
    doc.moveTo(LEFT, doc.y).lineTo(RIGHT, doc.y).lineWidth(1).strokeColor(C.line).stroke();
    doc.moveDown(0.5);
  };

  const kv = pairs => {
    const cw = W / 2;
    for (let i = 0; i < pairs.length; i += 2) {
      ensure(20);
      const y = doc.y;
      for (let j = 0; j < 2; j++) {
        const it = pairs[i + j];
        if (!it) continue;
        const x = LEFT + j * cw;
        doc.fillColor(C.muted).font('Helvetica').fontSize(9).text(it[0], x, y, { width: 118 });
        doc.fillColor(it[2] || C.dark).font('Helvetica-Bold').fontSize(9.5).text(it[1], x + 120, y, { width: cw - 128 });
      }
      doc.moveDown(0.55);
    }
  };

  // Pass/flag line used by the integrity section.
  const check = (ok, text) => {
    ensure(30);
    const y = doc.y;
    const h = doc.heightOfString(text, { width: W - 60, lineGap: 1.5 }) + 10;
    doc.rect(LEFT, y, W, h).fill(ok ? C.okbg : C.warnbg);
    doc.rect(LEFT, y, 3, h).fill(ok ? C.green : C.warn);
    doc.fillColor(ok ? C.green : C.warn).font('Helvetica-Bold').fontSize(8).text(ok ? 'OK' : 'CHECK', LEFT + 12, y + 5, { width: 36 });
    doc.fillColor(C.body).font('Helvetica').fontSize(9).text(text, LEFT + 52, y + 5, { width: W - 62, lineGap: 1.5 });
    doc.y = y + h + 4;
  };

  const table = (cols, rows, opts = {}) => {
    const tw = cols.reduce((a, c) => a + c.width, 0), sc = W / tw;
    cols.forEach(c => { c.w = c.width * sc; });
    const head = () => {
      ensure(24);
      const y = doc.y;
      doc.rect(LEFT, y, W, 19).fill(C.headbg);
      let x = LEFT;
      cols.forEach(c => {
        doc.fillColor('#FFFFFF').font('Helvetica-Bold').fontSize(7.6).text(c.label, x + 4, y + 6, { width: c.w - 8, align: c.align || 'left' });
        x += c.w;
      });
      doc.y = y + 19;
    };
    head();
    if (!rows.length) {
      ensure(18);
      const y = doc.y;
      doc.fillColor(C.muted).font('Helvetica').fontSize(9).text('No records in this period.', LEFT + 5, y + 4);
      doc.y = y + 18;
    }
    rows.forEach((r, idx) => {
      const ch = 15;
      if (doc.y + ch > BOTTOM) { doc.addPage(); head(); }
      const y = doc.y;
      if (idx % 2 === 1) doc.rect(LEFT, y, W, ch).fill(C.zebra);
      let x = LEFT;
      cols.forEach((c, ci) => {
        const cell = r[ci];
        const val = cell && typeof cell === 'object' ? cell.t : cell;
        const col = cell && typeof cell === 'object' ? cell.c : C.body;
        const bold = !!(cell && typeof cell === 'object' && cell.b);
        doc.fillColor(col || C.body).font(bold ? 'Helvetica-Bold' : 'Helvetica').fontSize(7.4)
          .text(String(val == null ? '' : val), x + 4, y + 4, { width: c.w - 8, align: c.align || 'left', lineBreak: false });
        x += c.w;
      });
      doc.y = y + ch;
    });
    if (opts.totalRow) {
      ensure(20);
      const y = doc.y;
      doc.rect(LEFT, y, W, 19).fill(C.chipbg);
      let x = LEFT;
      cols.forEach((c, ci) => {
        const cell = opts.totalRow[ci];
        if (cell == null) { x += c.w; return; }
        const val = typeof cell === 'object' ? cell.t : cell;
        const col = typeof cell === 'object' ? cell.c : C.dark;
        doc.fillColor(col || C.dark).font('Helvetica-Bold').fontSize(7.8)
          .text(String(val), x + 4, y + 6, { width: c.w - 8, align: c.align || 'left', lineBreak: false });
        x += c.w;
      });
      doc.y = y + 19;
    }
    doc.moveDown(0.4);
  };

  const note = text => {
    doc.moveDown(0.5);
    ensure(46);
    const y = doc.y;
    const h = doc.heightOfString(text, { width: W - 20, lineGap: 1.5 }) + 14;
    doc.roundedRect(LEFT, y, W, h, 5).fill(C.chipbg);
    doc.rect(LEFT, y, 3.5, h).fill(C.primary);
    doc.fillColor(C.dark).font('Helvetica').fontSize(8.5).text(text, LEFT + 10, y + 7, { width: W - 20, lineGap: 1.5 });
    doc.y = y + h;
  };

  return { LEFT, RIGHT, W, BOTTOM, ensure, banner, h2, kv, check, table, note };
}

// Shared: resolve the user + window, or send the error response.
async function resolveTarget(res, { uid, from, to }) {
  uid = String(uid);
  const user = (await pg.query('SELECT id,name,email,parent_staff_id FROM users WHERE id::text=$1', [uid])).rows[0];
  if (!user) { res.status(404).json({ error: 'User not found' }); return null; }

  const t = to ? new Date(to) : new Date();
  const f = from ? new Date(from) : new Date(t.getTime() - 24 * 3600 * 1000);
  if (isNaN(f.getTime()) || isNaN(t.getTime())) { res.status(400).json({ error: 'Invalid from/to' }); return null; }
  if (f >= t) { res.status(400).json({ error: '"From" must be earlier than "to"' }); return null; }

  const parent = (await pg.query('SELECT s.name,r.name AS role FROM staff s JOIN roles r ON r.id=s.role_id WHERE s.id=$1', [user.parent_staff_id])).rows[0] || {};
  const safeName = String(user.name || 'player').replace(/[^a-z0-9]+/gi, '_');
  return { uid, user, parent, from: f, to: t, safeName };
}

// ------------------------------------------------------------ casino report
async function generateCasinoSessionReport(res, opts) {
  const ctx = await resolveTarget(res, opts);
  if (!ctx) return;
  const { uid, user, parent, from, to, safeName } = ctx;
  const P = [uid, from, to];

  const tx = (await pg.query(
    `SELECT t.id, t.created_at, t.action, t.amount, t.balance_after, t.session_id, t.round_id,
            t.transaction_id, COALESCE(g.name,'(unknown)') game, COALESCE(g.provider,'-') provider
     FROM gis_transactions t
     LEFT JOIN gisgamesnew g ON g.uuid = t.game_uuid
     WHERE t.user_id::text = $1 AND t.created_at >= $2 AND t.created_at <= $3
     ORDER BY t.id`, P)).rows;

  const sessions = (await pg.query(
    `SELECT s.session_id, s.created_at, COALESCE(g.name,'(unknown)') game
     FROM gis_sessions s LEFT JOIN gisgamesnew g ON g.uuid = s.game_uuid
     WHERE s.user_id::text = $1 AND s.created_at >= $2 AND s.created_at <= $3
     ORDER BY s.created_at`, P)).rows;

  // Agent deposits / withdrawals landing between two callbacks legitimately move
  // the wallet, so they must be netted out before any balance gap is called a
  // mismatch — otherwise every mid-session top-up reads as a broken callback.
  const transfers = (await pg.query(
    `SELECT created_at, direction, transfer_type, amount,
            (CASE WHEN to_type = 'user' AND to_id::text = $1 THEN amount ELSE -amount END)::numeric AS delta
     FROM staff_transfers
     WHERE ((to_type = 'user' AND to_id::text = $1) OR (from_type = 'user' AND from_id::text = $1))
       AND created_at >= $2 AND created_at <= $3
     ORDER BY created_at`, P)).rows.map(t => ({
       at: new Date(t.created_at), delta: Number(t.delta),
       direction: t.direction, type: t.transfer_type,
     }));

  const transferBetween = (a, b) => {
    const lo = new Date(a), hi = new Date(b);
    return transfers.reduce((sum, t) => (t.at > lo && t.at <= hi ? sum + t.delta : sum), 0);
  };
  const depositsIn = transfers.filter(t => t.delta > 0).reduce((a, t) => a + t.delta, 0);
  const withdrawalsIn = transfers.filter(t => t.delta < 0).reduce((a, t) => a - t.delta, 0);

  // ---- aggregate per round and per game
  const rounds = new Map();
  const gameAgg = new Map();
  let staked = 0, payout = 0, refunded = 0;
  for (const r of tx) {
    const a = Number(r.amount) || 0;
    const isBet = r.action === 'bet';
    if (isBet) staked += a;
    else if (r.action === 'win') payout += a;
    else refunded += a;

    const rd = rounds.get(r.round_id) || { round: r.round_id, game: r.game, stake: 0, win: 0, bet_at: null, settled_at: null, hasBet: false, hasWin: false };
    if (isBet) { rd.stake += a; rd.hasBet = true; rd.bet_at = rd.bet_at || r.created_at; }
    else { rd.win += a; if (r.action === 'win') rd.hasWin = true; rd.settled_at = r.created_at; }
    rounds.set(r.round_id, rd);

    const g = gameAgg.get(r.game) || { game: r.game, provider: r.provider, rounds: new Set(), stake: 0, win: 0 };
    g.rounds.add(r.round_id);
    if (isBet) g.stake += a; else g.win += a;
    gameAgg.set(r.game, g);
  }
  const roundList = [...rounds.values()];
  const games = [...gameAgg.values()].map(g => ({ ...g, roundCount: g.rounds.size, net: g.win - g.stake })).sort((a, b) => b.net - a.net);
  const net = payout + refunded - staked;
  const wonRounds = roundList.filter(r => r.win > r.stake).length;
  const lostRounds = roundList.length - wonRounds;

  // ---- integrity checks over the window
  const txnIds = tx.map(r => r.transaction_id).filter(Boolean);
  const dupTxn = txnIds.length - new Set(txnIds).size;
  const openRounds = roundList.filter(r => r.hasBet && !r.hasWin);
  const rollbacks = tx.filter(r => r.action !== 'bet' && r.action !== 'win');
  let balMismatch = 0, gapTransfers = 0;
  for (let i = 1; i < tx.length; i++) {
    const prev = Number(tx[i - 1].balance_after);
    const cur = Number(tx[i].balance_after);
    const d = tx[i].action === 'bet' ? -Number(tx[i].amount) : Number(tx[i].amount);
    const ext = transferBetween(tx[i - 1].created_at, tx[i].created_at);
    gapTransfers += ext;
    if (prev != null && Math.abs(prev + d + ext - cur) > 0.009) balMismatch++;
  }
  const settleGaps = roundList
    .filter(r => r.bet_at && r.settled_at)
    .map(r => (new Date(r.settled_at) - new Date(r.bet_at)) / 1000);
  const gapMin = settleGaps.length ? Math.min(...settleGaps) : 0;
  const gapMax = settleGaps.length ? Math.max(...settleGaps) : 0;

  const openBal = tx.length ? Number(tx[0].balance_after) + (tx[0].action === 'bet' ? Number(tx[0].amount) : -Number(tx[0].amount)) : 0;
  const closeBal = tx.length ? Number(tx[tx.length - 1].balance_after) : 0;

  // ---- render
  const doc = makeDoc(res, `Casino_${safeName}_${uid}.pdf`);
  const L = layout(doc);
  L.banner(
    'Casino Game Report - ' + user.name,
    `UID ${user.id}   .   Agent: ${parent.name || '-'} (${parent.role || '-'})`,
    `Period: ${istDT(from)} to ${istDT(to)} IST   .   Generated ${istDT(new Date())} IST`
  );

  L.h2('Summary');
  L.kv([
    ['Games played', String(games.length)],
    ['Rounds', `${roundList.length}  (${wonRounds} won, ${lostRounds} lost)`],
    ['Callbacks', `${tx.length}  (${tx.filter(r => r.action === 'bet').length} bet + ${tx.filter(r => r.action === 'win').length} win)`],
    ['Game sessions opened', String(sessions.length)],
    ['Total stake', amt(staked)],
    ['Total payout', amt(payout + refunded)],
    ['Net result', signed(net) + (net >= 0 ? '  (player won)' : '  (player lost)'), pnlC(net)],
    ['First / last bet', tx.length ? `${istHMS(tx[0].created_at)} - ${istHMS(tx[tx.length - 1].created_at)}` : '-'],
    ['Opening balance', amt(openBal)],
    ['Closing balance', amt(closeBal)],
    ['Deposits in window', depositsIn ? amt(depositsIn) : '-'],
    ['Withdrawals in window', withdrawalsIn ? amt(withdrawalsIn) : '-'],
  ]);

  L.h2('Games played');
  L.table(
    [{ label: 'Game', width: 30 }, { label: 'Provider', width: 18 }, { label: 'Rounds', width: 10, align: 'right' },
     { label: 'Stake', width: 16, align: 'right' }, { label: 'Payout', width: 16, align: 'right' }, { label: 'Net', width: 16, align: 'right' }],
    games.map(g => [g.game, g.provider, String(g.roundCount), amt(g.stake), amt(g.win), { t: signed(g.net), c: pnlC(g.net), b: true }]),
    { totalRow: ['TOTAL', '', String(roundList.length), amt(staked), amt(payout + refunded), { t: signed(net), c: pnlC(net), b: true }] }
  );

  // Money in/out during the window. Without this the balance appears to jump
  // between two callbacks, which reads as a missing payout when it is not.
  if (transfers.length) {
    L.h2('Agent deposits & withdrawals in this period');
    L.table(
      [{ label: 'Time (IST)', width: 22 }, { label: 'Type', width: 16 }, { label: 'Amount', width: 20, align: 'right' },
       { label: 'Landed between', width: 42 }],
      transfers.map(t => {
        const before = tx.filter(r => new Date(r.created_at) <= t.at).pop();
        const after = tx.find(r => new Date(r.created_at) > t.at);
        const where = !before ? 'Before the first bet (in opening balance)'
          : !after ? 'After the last bet of the period'
            : `${istHMS(before.created_at)} ${before.action} and ${istHMS(after.created_at)} ${after.action}`;
        return [
          istDT(t.at),
          { t: t.delta >= 0 ? 'Deposit' : 'Withdrawal', c: t.delta >= 0 ? C.green : C.red, b: true },
          { t: signed(t.delta), c: pnlC(t.delta), b: true },
          where,
        ];
      }),
      { totalRow: ['TOTAL', '', { t: signed(depositsIn - withdrawalsIn), c: pnlC(depositsIn - withdrawalsIn), b: true }, ''] }
    );
    L.note('These are wallet movements made by the agent, not game callbacks. They are why the running balance steps up or down '
      + 'between two rounds. The balance checks below already account for them, so they are not a callback fault.');
  }

  L.h2('System check');
  L.check(openRounds.length === 0,
    openRounds.length === 0
      ? `Every round settled. ${roundList.length} bet callbacks and ${roundList.length} matching win callbacks - no round left open.`
      : `${openRounds.length} round(s) have a bet but no settlement callback: ${openRounds.slice(0, 5).map(r => r.round).join(', ')}.`);
  L.check(balMismatch === 0,
    balMismatch === 0
      ? `Every amount correct. All ${tx.length} callbacks reconcile against the running balance - difference is 0.00 on every one`
        + `${gapTransfers ? ', with agent deposits and withdrawals in the window accounted for' : ''}.`
      : `${balMismatch} callback(s) do not reconcile against the running balance.`);
  L.check(dupTxn === 0,
    dupTxn === 0
      ? `No duplicate callbacks. All ${txnIds.length} transaction IDs are unique - nothing was sent or credited twice.`
      : `${dupTxn} duplicate transaction ID(s) found in this window.`);
  L.check(rollbacks.length === 0,
    rollbacks.length === 0
      ? 'No rollback, refund or cancellation on any round in this period.'
      : `${rollbacks.length} rollback/refund callback(s) in this period.`);
  if (settleGaps.length) {
    L.check(true, `Settlement was fast. Every round settled within ${gapMin.toFixed(0)} to ${gapMax.toFixed(0)} seconds of the bet.`);
  }
  const fundingLabel = gapTransfers > 0 ? ` + deposits ${amt(gapTransfers)}`
    : gapTransfers < 0 ? ` - withdrawals ${amt(Math.abs(gapTransfers))}` : '';
  L.check(Math.abs(openBal - staked + payout + refunded + gapTransfers - closeBal) < 0.01,
    `Balance closes correctly. Opening ${amt(openBal)} - stakes ${amt(staked)} + payouts ${amt(payout + refunded)}`
    + `${fundingLabel} = ${amt(closeBal)}, the recorded closing balance.`);

  // Sessions opened without any bet — the usual answer to "I played but nothing
  // was deducted / paid".
  const betSessions = new Set(tx.map(r => r.session_id));
  const idle = sessions.filter(s => !betSessions.has(s.session_id));
  if (idle.length) {
    L.h2('Sessions opened with no bet placed');
    L.table(
      [{ label: 'Opened (IST)', width: 24 }, { label: 'Game', width: 40 }, { label: 'Session ID', width: 36 }],
      idle.slice(0, 40).map(s => [istDT(s.created_at), s.game, s.session_id])
    );
    L.note('The player opened the game table in these sessions but never placed a bet, so nothing was deducted and nothing was payable for them.');
  }

  // ---- full callback log
  doc.addPage();
  L.h2(`Full callback log  (${tx.length} callbacks)`);
  const log = tx.slice(0, MAX_LOG_ROWS);
  L.table(
    [{ label: '#', width: 6, align: 'right' }, { label: 'Time (IST)', width: 20 }, { label: 'Game', width: 22 },
     { label: 'Callback', width: 12 }, { label: 'Amount', width: 15, align: 'right' }, { label: 'Result', width: 11 },
     { label: 'Session', width: 14 }, { label: 'Round ID', width: 30 }, { label: 'Balance', width: 15, align: 'right' }],
    log.map((r, i) => {
      const rd = rounds.get(r.round_id);
      const win = rd && rd.win > rd.stake;
      return [
        String(i + 1),
        istDT(r.created_at),
        r.game,
        r.action,
        { t: amt(r.amount), b: r.action === 'win' && Number(r.amount) > 0, c: r.action === 'win' && Number(r.amount) > 0 ? C.green : C.body },
        r.action === 'bet' ? '-' : { t: win ? 'WIN' : 'LOSS', c: win ? C.green : C.red, b: true },
        String(r.session_id || '').slice(0, 8),
        r.round_id,
        amt(r.balance_after),
      ];
    }),
    { totalRow: [`${tx.length} callbacks`, `${roundList.length} rounds`, '', '', amt(staked), 'stake', '', 'payout ' + amt(payout + refunded), amt(closeBal)] }
  );
  if (tx.length > MAX_LOG_ROWS) {
    L.note(`Only the first ${MAX_LOG_ROWS} of ${tx.length} callbacks are listed above. Narrow the date/time range to see the rest.`);
  }

  L.note('All times are Indian Standard Time (UTC+5:30). Figures are the amounts the game provider asked us to debit and credit, ' +
    'taken directly from the live casino transaction log. Live-dealer providers send one combined amount per round covering the main bet ' +
    'and any side bets together, so a per-side-bet breakdown and the card declare must come from the provider.');

  doc.end();
}

// ------------------------------------------------------------ sports report
async function generateSportsSessionReport(res, opts) {
  const ctx = await resolveTarget(res, opts);
  if (!ctx) return;
  const { uid, user, parent, from, to, safeName } = ctx;
  const P = [uid, from, to];

  // netamount from credits_ledger is the settled truth (fancy markets pay 1:1,
  // which the odds column does not describe). Fall back to the odds formula
  // only for bets with no ledger row yet.
  const bets = (await pg.query(
    `SELECT b.id, b.created_at, b.game_type, b.match_title, b.event_name, b.selection_name, b.fancy_name,
            b.bet_type, b.market_type, b.category, b.odds, b.stake_amount, b.result_status, b.status,
            l.netamount, l.closing
     FROM "SportsBet" b
     LEFT JOIN LATERAL (
       SELECT netamount, closing FROM credits_ledger WHERE bet_id = b.id ORDER BY id DESC LIMIT 1
     ) l ON TRUE
     WHERE b.user_id::text = $1 AND b.created_at >= $2 AND b.created_at <= $3
     ORDER BY b.created_at, b.id`, P)).rows;

  const netOf = b => {
    if (b.netamount != null) return Number(b.netamount);
    const st = Number(b.stake_amount) || 0;
    const rs = String(b.result_status || '').toLowerCase();
    if (rs === 'win' || rs === 'won') return (Number(b.odds) - 1) * st;
    if (rs === 'loss' || rs === 'lost') return -st;
    return 0;
  };

  const staked = bets.reduce((a, b) => a + (Number(b.stake_amount) || 0), 0);
  const net = bets.reduce((a, b) => a + netOf(b), 0);
  const isWin = b => /^(win|won)$/i.test(String(b.result_status || ''));
  const isLoss = b => /^(loss|lost)$/i.test(String(b.result_status || ''));
  const won = bets.filter(isWin).length;
  const lost = bets.filter(isLoss).length;
  const pending = bets.length - won - lost;
  const settled = won + lost;

  // Breakdown by market segment.
  const segAgg = new Map();
  for (const b of bets) {
    const key = `${b.game_type || '-'} / ${b.market_type || '-'}`;
    const s = segAgg.get(key) || { key, bets: 0, stake: 0, net: 0, won: 0 };
    s.bets++; s.stake += Number(b.stake_amount) || 0; s.net += netOf(b); if (isWin(b)) s.won++;
    segAgg.set(key, s);
  }
  const segments = [...segAgg.values()].sort((a, b) => b.net - a.net);

  // Breakdown by match.
  const matchAgg = new Map();
  for (const b of bets) {
    const key = b.match_title || b.event_name || '-';
    const m = matchAgg.get(key) || { key, bets: 0, stake: 0, net: 0 };
    m.bets++; m.stake += Number(b.stake_amount) || 0; m.net += netOf(b);
    matchAgg.set(key, m);
  }
  const matches = [...matchAgg.values()].sort((a, b) => b.net - a.net);

  const unsettled = bets.filter(b => b.netamount == null && (isWin(b) || isLoss(b)));

  const doc = makeDoc(res, `Sports_${safeName}_${uid}.pdf`);
  const L = layout(doc);
  L.banner(
    'Sports Bet Report - ' + user.name,
    `UID ${user.id}   .   Agent: ${parent.name || '-'} (${parent.role || '-'})`,
    `Period: ${istDT(from)} to ${istDT(to)} IST   .   Generated ${istDT(new Date())} IST`
  );

  L.h2('Summary');
  L.kv([
    ['Bets placed', String(bets.length)],
    ['Settled', `${settled}  (${won} won, ${lost} lost)`],
    ['Pending', String(pending)],
    ['Matches', String(matches.length)],
    ['Total stake', amt(staked)],
    ['Win rate', settled ? `${(100 * won / settled).toFixed(1)}%` : '-'],
    ['Net result', signed(net) + (net >= 0 ? '  (player won)' : '  (player lost)'), pnlC(net)],
    ['First / last bet', bets.length ? `${istHMS(bets[0].created_at)} - ${istHMS(bets[bets.length - 1].created_at)}` : '-'],
  ]);

  L.h2('By market');
  L.table(
    [{ label: 'Sport / market', width: 34 }, { label: 'Bets', width: 10, align: 'right' }, { label: 'Won', width: 10, align: 'right' },
     { label: 'Stake', width: 18, align: 'right' }, { label: 'Net', width: 18, align: 'right' }],
    segments.map(s => [s.key, String(s.bets), String(s.won), amt(s.stake), { t: signed(s.net), c: pnlC(s.net), b: true }]),
    { totalRow: ['TOTAL', String(bets.length), String(won), amt(staked), { t: signed(net), c: pnlC(net), b: true }] }
  );

  L.h2('By match');
  L.table(
    [{ label: 'Match', width: 46 }, { label: 'Bets', width: 10, align: 'right' },
     { label: 'Stake', width: 18, align: 'right' }, { label: 'Net', width: 18, align: 'right' }],
    matches.map(m => [m.key, String(m.bets), amt(m.stake), { t: signed(m.net), c: pnlC(m.net), b: true }])
  );

  L.h2('System check');
  L.check(unsettled.length === 0,
    unsettled.length === 0
      ? `Every settled bet has a matching wallet entry. ${settled} settled bet(s) reconcile against the credits ledger.`
      : `${unsettled.length} bet(s) are marked won/lost but have no wallet settlement row: ids ${unsettled.slice(0, 8).map(b => b.id).join(', ')}.`);
  L.check(pending === 0,
    pending === 0 ? 'No bet is left pending in this period.' : `${pending} bet(s) are still pending settlement in this period.`);

  doc.addPage();
  L.h2(`Full bet log  (${bets.length} bets)`);
  const log = bets.slice(0, MAX_LOG_ROWS);
  L.table(
    [{ label: '#', width: 5, align: 'right' }, { label: 'Time (IST)', width: 18 }, { label: 'Match', width: 24 },
     { label: 'Selection', width: 24 }, { label: 'Market', width: 16 }, { label: 'Odds', width: 9, align: 'right' },
     { label: 'Stake', width: 13, align: 'right' }, { label: 'Result', width: 10, align: 'center' },
     { label: 'Net', width: 13, align: 'right' }, { label: 'Bet ID', width: 9, align: 'right' }],
    log.map((b, i) => {
      const n = netOf(b);
      const rs = (b.result_status || 'pending').toUpperCase();
      return [
        String(i + 1),
        istDT(b.created_at),
        b.match_title || b.event_name || '-',
        b.selection_name || b.fancy_name || '-',
        `${b.game_type || '-'}/${b.market_type || '-'}`,
        String(b.odds),
        amt(b.stake_amount),
        { t: rs, c: isWin(b) ? C.green : isLoss(b) ? C.red : C.muted, b: true },
        { t: signed(n), c: pnlC(n), b: true },
        String(b.id),
      ];
    }),
    { totalRow: [`${bets.length} bets`, '', '', '', '', '', amt(staked), '', { t: signed(net), c: pnlC(net), b: true }, ''] }
  );
  if (bets.length > MAX_LOG_ROWS) {
    L.note(`Only the first ${MAX_LOG_ROWS} of ${bets.length} bets are listed above. Narrow the date/time range to see the rest.`);
  }

  L.note('All times are Indian Standard Time (UTC+5:30). "Net" is the settled amount actually written to the wallet ' +
    '(credits ledger), which is the authoritative figure - session/fancy markets settle 1:1 regardless of the run value shown ' +
    'in the odds column. Bets still pending count as 0.');

  doc.end();
}

module.exports = { generateCasinoSessionReport, generateSportsSessionReport };
