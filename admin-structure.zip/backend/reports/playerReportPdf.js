// reports/playerReportPdf.js
// Reusable player-report PDF generator. Streams a multi-page PDF (account
// summary, overall/daily/weekly P&L, profit-trajectory analysis, casino
// game-by-game breakdown, sports-bet detail) to an Express response.
//
//   const { generatePlayerReport } = require('./reports/playerReportPdf');
//   await generatePlayerReport(res, { uid, from, to });   // from/to optional ISO strings
const PDFDocument = require('pdfkit');
const pg = require('../General/Model');

const C = { primary:'#2B6EF5', dark:'#15182B', body:'#2D3142', muted:'#6B7280', line:'#E3E7F0', green:'#0E9F5B', red:'#D64560', headbg:'#0E1831', zebra:'#F7F9FC', chipbg:'#EAF1FE' };
const inr = n => { const v=Number(n||0); return (v<0?'-':'')+'Rs '+Math.abs(v).toLocaleString('en-IN',{maximumFractionDigits:2}); };
const pnl = n => Number(n)>0?C.green:(Number(n)<0?C.red:C.body);
const dfmt = iso => new Date(iso).toLocaleDateString('en-GB',{day:'2-digit',month:'short',year:'numeric'});

async function generatePlayerReport(res, { uid, from, to }) {
  uid = String(uid);
  // Build a reusable created_at filter fragment; $1 is always uid.
  const dp = [];
  if (from) dp.push(new Date(from));
  if (to) dp.push(new Date(to));
  const dcl = (col = 'created_at') => { let c = '', i = 2; if (from) { c += ` AND ${col} >= $${i++}`; } if (to) { c += ` AND ${col} <= $${i++}`; } return c; };
  const P = [uid, ...dp];

  const user = (await pg.query(`SELECT id,name,email,parent_staff_id,status,bet_status,sports_betlocked,casino_locked,exposure_limit,last_ip,last_login_at FROM users WHERE id::text=$1`, [uid])).rows[0];
  if (!user) { res.status(404).json({ error: 'User not found' }); return; }
  const parent = (await pg.query(`SELECT s.name,r.name AS role FROM staff s JOIN roles r ON r.id=s.role_id WHERE s.id=$1`, [user.parent_staff_id])).rows[0] || {};
  const bal = (await pg.query('SELECT inr FROM credits WHERE uid::text=$1', [uid])).rows[0] || { inr: 0 };

  const casino = (await pg.query(`SELECT SUM(CASE WHEN action='bet' THEN amount ELSE 0 END)::numeric staked,SUM(CASE WHEN action='win' THEN amount ELSE 0 END)::numeric won,SUM(CASE WHEN action='refund' THEN amount ELSE 0 END)::numeric refund,COUNT(*) FILTER(WHERE action='bet')::int bets FROM gis_transactions WHERE user_id::text=$1 ${dcl()}`, P)).rows[0];
  const cs = Number(casino.staked || 0), cw = Number(casino.won || 0);
  const casinoNet = cw - cs + Number(casino.refund || 0);
  const rtp = cs ? 100 * cw / cs : 0;

  const sports = (await pg.query(`SELECT id,created_at,match_title,selection_name,bet_type,odds,stake_amount,result_status FROM "SportsBet" WHERE user_id::text=$1 ${dcl()} ORDER BY created_at`, P)).rows;
  const sportsStaked = sports.reduce((a, b) => a + Number(b.stake_amount), 0);
  const sportsNet = sports.reduce((a, b) => a + (b.result_status === 'win' ? (Number(b.odds) - 1) * Number(b.stake_amount) : b.result_status === 'loss' ? -Number(b.stake_amount) : 0), 0);
  const combined = casinoNet + sportsNet;

  const games = (await pg.query(`SELECT COALESCE(g.name,'(unknown)') game,COALESCE(g.provider,'-') provider,COUNT(*) FILTER(WHERE t.action='bet')::int rounds,SUM(CASE WHEN t.action='bet' THEN t.amount ELSE 0 END)::numeric staked,SUM(CASE WHEN t.action='win' THEN t.amount ELSE 0 END)::numeric won,SUM(CASE WHEN t.action='win' THEN t.amount WHEN t.action='refund' THEN t.amount ELSE -t.amount END)::numeric net FROM gis_transactions t LEFT JOIN gisgamesnew g ON g.uuid=t.game_uuid WHERE t.user_id::text=$1 ${dcl('t.created_at')} GROUP BY 1,2 ORDER BY net DESC`, P)).rows;

  const cDaily = (await pg.query(`SELECT to_char(date_trunc('day',created_at),'YYYY-MM-DD') d,SUM(CASE WHEN action='win' THEN amount WHEN action='refund' THEN amount ELSE -amount END)::numeric net,SUM(CASE WHEN action='bet' THEN amount ELSE 0 END)::numeric staked,SUM(CASE WHEN action='win' THEN amount ELSE 0 END)::numeric won,COUNT(*) FILTER(WHERE action='bet')::int bets FROM gis_transactions WHERE user_id::text=$1 ${dcl()} GROUP BY 1 ORDER BY 1`, P)).rows;
  const sDaily = (await pg.query(`SELECT to_char(date_trunc('day',created_at),'YYYY-MM-DD') d,SUM(CASE WHEN result_status='win' THEN (odds-1)*stake_amount WHEN result_status='loss' THEN -stake_amount ELSE 0 END)::numeric net,COUNT(*)::int bets FROM "SportsBet" WHERE user_id::text=$1 ${dcl()} GROUP BY 1`, P)).rows;
  const cWeekly = (await pg.query(`SELECT to_char(date_trunc('week',created_at),'YYYY-MM-DD') w,SUM(CASE WHEN action='win' THEN amount WHEN action='refund' THEN amount ELSE -amount END)::numeric net,COUNT(*) FILTER(WHERE action='bet')::int bets FROM gis_transactions WHERE user_id::text=$1 ${dcl()} GROUP BY 1`, P)).rows;
  const sWeekly = (await pg.query(`SELECT to_char(date_trunc('week',created_at),'YYYY-MM-DD') w,SUM(CASE WHEN result_status='win' THEN (odds-1)*stake_amount WHEN result_status='loss' THEN -stake_amount ELSE 0 END)::numeric net,COUNT(*)::int bets FROM "SportsBet" WHERE user_id::text=$1 ${dcl()} GROUP BY 1`, P)).rows;
  const merge = (a, b, k) => { const m = {}; for (const r of a) m[r[k]] = { key: r[k], casino: Number(r.net), cb: r.bets, cs: Number(r.staked || 0), cw: Number(r.won || 0), sports: 0, sb: 0 }; for (const r of b) { m[r[k]] = m[r[k]] || { key: r[k], casino: 0, cb: 0, cs: 0, cw: 0, sports: 0, sb: 0 }; m[r[k]].sports = Number(r.net); m[r[k]].sb = r.bets; } return Object.values(m).sort((x, y) => x.key < y.key ? -1 : 1); };
  const daily = merge(cDaily, sDaily, 'd'), weekly = merge(cWeekly, sWeekly, 'w');

  let run = 0, minRun = { v: Infinity }, maxDay = { v: -Infinity };
  const running = cDaily.map(r => { run += Number(r.net); const o = { d: r.d, staked: Number(r.staked), won: Number(r.won), net: Number(r.net), run, rtp: Number(r.staked) ? 100 * Number(r.won) / Number(r.staked) : 0 }; if (run < minRun.v) minRun = { v: run, d: r.d }; if (Number(r.net) > maxDay.v) maxDay = { v: Number(r.net), d: r.d, rtp: o.rtp, staked: o.staked, won: o.won }; return o; });
  const topWins = (await pg.query(`SELECT to_char(t.created_at,'DD Mon YY, HH24:MI') tt,t.amount,COALESCE(g.name,'?') game FROM gis_transactions t LEFT JOIN gisgamesnew g ON g.uuid=t.game_uuid WHERE t.user_id::text=$1 AND t.action='win' ${dcl('t.created_at')} ORDER BY t.amount DESC LIMIT 10`, P)).rows;
  const totalBets = Number(casino.bets || 0) + sports.length;
  const rangeLabel = (from || to) ? `${from ? dfmt(from) : 'start'}  to  ${to ? dfmt(to) : 'now'}` : 'All time';

  // ---- Stream headers + PDF ----
  const safeName = String(user.name || 'player').replace(/[^a-z0-9]+/gi, '_');
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="Player_${safeName}_${uid}.pdf"`);

  const doc = new PDFDocument({ size: 'A4', margins: { top: 54, bottom: 54, left: 48, right: 48 } });
  doc.pipe(res);
  const LEFT = doc.page.margins.left, RIGHT = doc.page.width - doc.page.margins.right, W = RIGHT - LEFT, BOTTOM = doc.page.height - doc.page.margins.bottom, PW = doc.page.width;
  const ensure = h => { if (doc.y + h > BOTTOM) doc.addPage(); };
  function h2(t) { ensure(40); doc.moveDown(0.6); doc.fillColor(C.dark).font('Helvetica-Bold').fontSize(13).text(t, LEFT, doc.y); doc.moveDown(0.25); doc.moveTo(LEFT, doc.y).lineTo(RIGHT, doc.y).lineWidth(1).strokeColor(C.line).stroke(); doc.moveDown(0.5); }
  function kv(p) { const cw2 = W / 2; for (let i = 0; i < p.length; i += 2) { ensure(20); const y = doc.y; for (let j = 0; j < 2; j++) { const it = p[i + j]; if (!it) continue; const x = LEFT + j * cw2; doc.fillColor(C.muted).font('Helvetica').fontSize(9).text(it[0], x, y, { width: 120 }); doc.fillColor(it[2] || C.dark).font('Helvetica-Bold').fontSize(9.5).text(it[1], x + 122, y, { width: cw2 - 130 }); } doc.moveDown(0.55); } }
  function bullet(t) { ensure(22); const y = doc.y; doc.circle(LEFT + 4, y + 6, 1.8).fill(C.primary); doc.fillColor(C.body).font('Helvetica').fontSize(9.5).text(t, LEFT + 16, y, { width: W - 16, lineGap: 2 }); doc.moveDown(0.4); }
  function table(cols, rows, opts = {}) { const tw = cols.reduce((a, c) => a + c.width, 0), sc = W / tw; cols.forEach(c => c.w = c.width * sc); const head = () => { ensure(24); const y = doc.y; doc.rect(LEFT, y, W, 20).fill(C.headbg); let x = LEFT; cols.forEach(c => { doc.fillColor('#FFFFFF').font('Helvetica-Bold').fontSize(8.5).text(c.label, x + 5, y + 6, { width: c.w - 10, align: c.align || 'left' }); x += c.w; }); doc.y = y + 20; }; head(); if (!rows.length) { ensure(18); const y = doc.y; doc.fillColor(C.muted).font('Helvetica').fontSize(9).text('No records in this period.', LEFT + 5, y + 4); doc.y = y + 18; } rows.forEach((r, idx) => { const ch = 18; if (doc.y + ch > BOTTOM) { doc.addPage(); head(); } const y = doc.y; if (idx % 2 === 1) doc.rect(LEFT, y, W, ch).fill(C.zebra); let x = LEFT; cols.forEach((c, ci) => { const cell = r[ci]; const val = typeof cell === 'object' ? cell.t : cell; const col = typeof cell === 'object' ? cell.c : C.body; doc.fillColor(col).font(typeof cell === 'object' && cell.b ? 'Helvetica-Bold' : 'Helvetica').fontSize(8.5).text(String(val), x + 5, y + 5, { width: c.w - 10, align: c.align || 'left' }); x += c.w; }); doc.y = y + ch; }); if (opts.totalRow) { ensure(20); const y = doc.y; doc.rect(LEFT, y, W, 20).fill(C.chipbg); let x = LEFT; cols.forEach((c, ci) => { const cell = opts.totalRow[ci]; if (cell == null) { x += c.w; return; } const val = typeof cell === 'object' ? cell.t : cell; const col = typeof cell === 'object' ? cell.c : C.dark; doc.fillColor(col).font('Helvetica-Bold').fontSize(8.8).text(String(val), x + 5, y + 6, { width: c.w - 10, align: c.align || 'left' }); x += c.w; }); doc.y = y + 20; } doc.moveDown(0.4); }

  // Header
  doc.rect(0, 0, PW, 96).fill(C.primary);
  doc.fillColor('#FFFFFF').font('Helvetica-Bold').fontSize(22).text('Player Report - ' + user.name, LEFT, 26, { width: W });
  doc.fillColor('#DCE8FF').font('Helvetica').fontSize(10).text(`UID ${user.id}   .   Agent: ${parent.name || '-'} (${parent.role || '-'})`, LEFT, 56, { width: W });
  doc.fillColor('#DCE8FF').font('Helvetica').fontSize(9).text(`Period: ${rangeLabel}   .   Generated ${new Date().toLocaleString('en-GB')}`, LEFT, 72, { width: W });
  doc.y = 116;

  h2('Account Summary');
  kv([['Name', user.name], ['UID', String(user.id)], ['Email', user.email || '-'], ['Upline agent', `${parent.name || '-'} (${parent.role || '-'})`], ['Account status', user.status || '-'], ['Betting status', user.bet_status || '-'], ['Current balance', inr(bal.inr), C.green], ['Exposure limit', inr(user.exposure_limit)], ['Sports lock', user.sports_betlocked ? 'LOCKED' : 'Open'], ['Casino lock', user.casino_locked ? 'LOCKED' : 'Open'], ['Last login', user.last_login_at ? new Date(user.last_login_at).toLocaleString('en-GB') : '-'], ['Last IP', user.last_ip || '-']]);

  h2('Overall Profit & Loss  (player view: + = player up, - = player down)');
  table([{ label: 'Segment', width: 30 }, { label: 'Bets', width: 14, align: 'right' }, { label: 'Staked', width: 28, align: 'right' }, { label: 'Won', width: 28, align: 'right' }, { label: 'Net P&L', width: 28, align: 'right' }],
    [['Casino (slots/live)', String(casino.bets || 0), inr(cs), inr(cw + Number(casino.refund || 0)), { t: inr(casinoNet), c: pnl(casinoNet), b: true }], ['Sports exchange', String(sports.length), inr(sportsStaked), inr(sportsStaked + sportsNet), { t: inr(sportsNet), c: pnl(sportsNet), b: true }]],
    { totalRow: ['TOTAL', String(totalBets), inr(cs + sportsStaked), '', { t: inr(combined), c: pnl(combined), b: true }] });

  h2('Daily Profit & Loss');
  table([{ label: 'Date', width: 26 }, { label: 'Casino net', width: 24, align: 'right' }, { label: 'Sports net', width: 24, align: 'right' }, { label: 'Bets', width: 12, align: 'right' }, { label: 'Total P&L', width: 24, align: 'right' }],
    daily.map(r => { const t = r.casino + r.sports; return [dfmt(r.key), { t: inr(r.casino), c: pnl(r.casino) }, { t: inr(r.sports), c: pnl(r.sports) }, String((r.cb || 0) + (r.sb || 0)), { t: inr(t), c: pnl(t), b: true }]; }),
    { totalRow: ['TOTAL', { t: inr(casinoNet), c: pnl(casinoNet) }, { t: inr(sportsNet), c: pnl(sportsNet) }, String(totalBets), { t: inr(combined), c: pnl(combined), b: true }] });

  h2('Weekly Profit & Loss  (week starting Monday)');
  table([{ label: 'Week of', width: 30 }, { label: 'Casino net', width: 22, align: 'right' }, { label: 'Sports net', width: 22, align: 'right' }, { label: 'Bets', width: 12, align: 'right' }, { label: 'Total P&L', width: 22, align: 'right' }],
    weekly.map(r => { const t = r.casino + r.sports; const e = new Date(r.key); e.setDate(e.getDate() + 6); return [`${dfmt(r.key)} - ${dfmt(e.toISOString())}`, { t: inr(r.casino), c: pnl(r.casino) }, { t: inr(r.sports), c: pnl(r.sports) }, String((r.cb || 0) + (r.sb || 0)), { t: inr(t), c: pnl(t), b: true }]; }),
    { totalRow: ['TOTAL', { t: inr(casinoNet), c: pnl(casinoNet) }, { t: inr(sportsNet), c: pnl(sportsNet) }, String(totalBets), { t: inr(combined), c: pnl(combined), b: true }] });

  // Trajectory page (only meaningful with casino data)
  if (cDaily.length) {
    doc.addPage();
    doc.rect(0, 0, PW, 70).fill(C.dark);
    doc.fillColor('#FFFFFF').font('Helvetica-Bold').fontSize(17).text('Casino P&L Trajectory', LEFT, 20, { width: W });
    doc.fillColor('#AEB6D6').font('Helvetica').fontSize(9.5).text('How the net result built up, biggest wins and win-rate', LEFT, 46, { width: W });
    doc.y = 90;
    h2('Key findings');
    if (Number.isFinite(minRun.v)) bullet(`Lowest running net in the period was ${inr(minRun.v)} on ${dfmt(minRun.d)}.`);
    if (Number.isFinite(maxDay.v)) bullet(`Best single day was ${dfmt(maxDay.d)}: staked ${inr(maxDay.staked)}, won ${inr(maxDay.won)} (${maxDay.rtp.toFixed(0)}% return) = ${inr(maxDay.v)}.`);
    if (games[0]) bullet(`Most profitable game: ${games[0].game} (${inr(games[0].net)}). Biggest single win: ${topWins[0] ? inr(topWins[0].amount) + ' on ' + topWins[0].game : '-'}.`);
    bullet(`Overall casino return-to-player is ${rtp.toFixed(1)}% (won ${inr(cw)} on ${inr(cs)} staked) across ${casino.bets || 0} rounds. Typical live-casino RTP is ~97%.`);
    h2('Cumulative net - day by day');
    table([{ label: 'Date', width: 22 }, { label: 'Staked', width: 20, align: 'right' }, { label: 'Won', width: 20, align: 'right' }, { label: 'Day net', width: 20, align: 'right' }, { label: 'RTP', width: 10, align: 'right' }, { label: 'Running total', width: 22, align: 'right' }],
      running.map(r => [dfmt(r.d), inr(r.staked), inr(r.won), { t: inr(r.net), c: pnl(r.net) }, r.rtp.toFixed(0) + '%', { t: inr(r.run), c: pnl(r.run), b: true }]));
    h2('Top 10 single wins');
    table([{ label: 'When', width: 28 }, { label: 'Game', width: 42 }, { label: 'Win amount', width: 30, align: 'right' }], topWins.map(w => [w.tt, w.game, { t: inr(w.amount), c: C.green, b: true }]));
  }

  // Game-by-game page
  if (games.length) {
    doc.addPage();
    doc.rect(0, 0, PW, 70).fill(C.dark);
    doc.fillColor('#FFFFFF').font('Helvetica-Bold').fontSize(17).text('Casino - Game-by-Game Win / Loss', LEFT, 24, { width: W });
    doc.fillColor('#AEB6D6').font('Helvetica').fontSize(9.5).text(`Across ${games.length} games`, LEFT, 48, { width: W });
    doc.y = 90;
    const topW = games[0], topL = games[games.length - 1], mostP = [...games].sort((a, b) => b.rounds - a.rounds)[0], prof = games.filter(g => Number(g.net) > 0).length;
    h2('Highlights');
    kv([['Wins most on', `${topW.game}  (${inr(topW.net)})`, C.green], ['Loses most on', `${topL.game}  (${inr(topL.net)})`, C.red], ['Most played', `${mostP.game}  (${mostP.rounds} rounds)`], ['Games played', String(games.length)], ['Profitable games', `${prof} of ${games.length}`], ['Net casino P&L', inr(casinoNet), pnl(casinoNet)]]);
    h2('All games (sorted by net P&L)');
    table([{ label: 'Game', width: 34 }, { label: 'Provider', width: 22 }, { label: 'Rounds', width: 12, align: 'right' }, { label: 'Staked', width: 18, align: 'right' }, { label: 'Won', width: 18, align: 'right' }, { label: 'Net P&L', width: 18, align: 'right' }],
      games.map(g => [g.game, g.provider, String(g.rounds), inr(g.staked), inr(g.won), { t: inr(g.net), c: pnl(g.net), b: true }]),
      { totalRow: ['TOTAL', '', String(casino.bets || 0), inr(cs), inr(cw), { t: inr(casinoNet), c: pnl(casinoNet), b: true }] });
  }

  // Sports detail page
  doc.addPage();
  h2(`Sports Bets - full detail (${sports.length})`);
  table([{ label: 'Date', width: 20 }, { label: 'Match', width: 32 }, { label: 'Selection', width: 20 }, { label: 'Type', width: 10 }, { label: 'Odds', width: 10, align: 'right' }, { label: 'Stake', width: 14, align: 'right' }, { label: 'Result', width: 12, align: 'center' }],
    sports.map(b => [new Date(b.created_at).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' }), b.match_title, b.selection_name, b.bet_type, String(b.odds), inr(b.stake_amount), { t: (b.result_status || '-').toUpperCase(), c: b.result_status === 'win' ? C.green : C.red, b: true }]));

  doc.moveDown(0.6);
  const y = doc.y; ensure(46);
  doc.roundedRect(LEFT, y, W, 40, 5).fill(C.chipbg); doc.rect(LEFT, y, 3.5, 40).fill(C.primary);
  doc.fillColor(C.dark).font('Helvetica').fontSize(8.5).text(
    'P&L is shown from the player view (positive = player up = a liability to the agent/house). Casino net = wins minus stakes across all rounds ' +
    '(bet/win churn), which is not the same as the wallet balance because winnings are typically re-wagered. Figures reflect the selected period only.',
    LEFT + 10, y + 7, { width: W - 20, lineGap: 1.5 });
  doc.y = y + 40;

  doc.end();
}

module.exports = { generatePlayerReport };
