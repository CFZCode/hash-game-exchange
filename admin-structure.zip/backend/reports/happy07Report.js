// reports/happy07Report.js
// Standalone, fully-formatted player statement PDF.
// Pulls LIVE data (agent credits, every bet, settlement ledger, wallet) and
// writes a multi-section A4 PDF to disk. Per-bet P&L is taken from the
// settlement ledger (credits_ledger.netamount) so it matches the wallet exactly.
//
//   node reports/happy07Report.js <uid> [outfile.pdf]
//   node reports/happy07Report.js 9181647851
const fs = require('fs');
const path = require('path');
const PDFDocument = require('pdfkit');
const { Client } = require('pg');

const CONN = 'postgres://myapp1:myapp1@127.0.0.1:5432/myapp1';

const C = { primary:'#2B6EF5', dark:'#15182B', body:'#2D3142', muted:'#6B7280', line:'#E3E7F0', green:'#0E9F5B', red:'#D64560', headbg:'#0E1831', zebra:'#F7F9FC', chipbg:'#EAF1FE', amber:'#B7791F' };
const inr = n => { const v=Number(n||0); return (v<0?'-':'')+'Rs '+Math.abs(v).toLocaleString('en-IN',{maximumFractionDigits:2}); };
const pnl = n => Number(n)>0?C.green:(Number(n)<0?C.red:C.body);
const dts = iso => new Date(iso).toLocaleString('en-GB',{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'});

async function build(uid, outfile) {
  uid = String(uid);
  const db = new Client({ connectionString: CONN });
  await db.connect();

  const user = (await db.query(`SELECT id,name,email,parent_staff_id,status,bet_status,sports_betlocked,casino_locked FROM users WHERE id::text=$1`, [uid])).rows[0];
  if (!user) throw new Error('User not found: ' + uid);
  const agent = (await db.query(`SELECT s.name, r.name role, s.agent_code FROM staff s LEFT JOIN roles r ON r.id=s.role_id WHERE s.id=$1`, [user.parent_staff_id])).rows[0] || {};
  const wallet = Number((await db.query('SELECT inr FROM credits WHERE uid::text=$1', [uid])).rows[0]?.inr || 0);

  const credits = (await db.query(
    `SELECT st.amount, st.transfer_type, st.created_at, s.name agent
       FROM staff_transfers st LEFT JOIN staff s ON s.id=st.from_id
      WHERE st.to_type='user' AND st.to_id::text=$1 AND st.transfer_type='transfer'
      ORDER BY st.created_at`, [uid])).rows;
  const agentCredit = credits.reduce((a,r)=>a+Number(r.amount),0);

  // Every bet joined to its settlement ledger row (net P&L is the source of truth).
  const bets = (await db.query(
    `SELECT sb.id, sb.created_at, sb.match_title, sb.selection_name, sb.bet_type, sb.market_type,
            sb.odds, sb.stake_amount, sb.result_status,
            cl.netamount, cl.reason
       FROM "SportsBet" sb
       LEFT JOIN credits_ledger cl ON cl.bet_id = sb.id AND cl.user_id::text = sb.user_id::text
      WHERE sb.user_id::text=$1
      ORDER BY sb.id`, [uid])).rows;

  const staked = bets.reduce((a,b)=>a+Number(b.stake_amount||0),0);
  const won = bets.filter(b=>b.result_status==='won');
  const lost = bets.filter(b=>b.result_status==='loss');
  const winNet = won.reduce((a,b)=>a+Number(b.netamount||0),0);
  const lossNet = lost.reduce((a,b)=>a+Number(b.netamount||0),0);
  const netPnl = bets.reduce((a,b)=>a+Number(b.netamount||0),0);

  // Chronological balance-sheet events in plain language (agent credit, then each result).
  const events = [];
  for (const c of credits) events.push({ ts:c.created_at, cat:'Money added', desc:`Money added by your agent (${c.agent||'agent'})`, amt:Number(c.amount) });
  const led = (await db.query(
    `SELECT cl.created_at, cl.netamount, cl.market_type,
            sb.selection_name, sb.result_status
       FROM credits_ledger cl
       LEFT JOIN "SportsBet" sb ON sb.id = cl.bet_id AND sb.user_id::text = cl.user_id::text
      WHERE cl.user_id::text=$1 ORDER BY cl.created_at`, [uid])).rows;
  for (const l of led) {
    const kind = l.market_type==='Bookmaker' ? 'Match bet' : 'Fancy bet';
    const outcome = l.result_status==='won' ? 'WON' : 'LOST';
    const sel = (l.selection_name||'-').trim();
    events.push({ ts:l.created_at, cat: outcome==='WON'?'You won':'You lost',
      desc:`${kind}: ${sel} (${outcome})`, amt:Number(l.netamount||0) });
  }
  events.sort((a,b)=> new Date(a.ts)-new Date(b.ts));
  let run=0; for (const e of events){ run+=e.amt; e.bal=run; }

  // ---------------- PDF ----------------
  outfile = outfile || path.join(process.cwd(), `${(user.name||'player').replace(/[^a-z0-9]+/gi,'_')}_UID${uid}_Statement.pdf`);
  const doc = new PDFDocument({ size:'A4', margins:{ top:54, bottom:56, left:46, right:46 } });
  const stream = fs.createWriteStream(outfile);
  doc.pipe(stream);
  const LEFT=doc.page.margins.left, RIGHT=doc.page.width-doc.page.margins.right, W=RIGHT-LEFT, BOTTOM=doc.page.height-doc.page.margins.bottom, PW=doc.page.width;
  const ensure = h => { if (doc.y+h>BOTTOM) doc.addPage(); };
  function h2(t,sub){ ensure(42); doc.moveDown(0.5); doc.fillColor(C.dark).font('Helvetica-Bold').fontSize(13).text(t,LEFT,doc.y); if(sub){doc.fillColor(C.muted).font('Helvetica').fontSize(8.5).text(sub,LEFT,doc.y+1);} doc.moveDown(0.2); doc.moveTo(LEFT,doc.y).lineTo(RIGHT,doc.y).lineWidth(1).strokeColor(C.line).stroke(); doc.moveDown(0.5); }
  function kv(p){ const cw=W/2; for(let i=0;i<p.length;i+=2){ ensure(20); const y=doc.y; for(let j=0;j<2;j++){ const it=p[i+j]; if(!it)continue; const x=LEFT+j*cw; doc.fillColor(C.muted).font('Helvetica').fontSize(9).text(it[0],x,y,{width:130}); doc.fillColor(it[2]||C.dark).font('Helvetica-Bold').fontSize(9.5).text(it[1],x+132,y,{width:cw-140}); } doc.moveDown(0.55);} }
  function table(cols,rows,opts={}){ const tw=cols.reduce((a,c)=>a+c.width,0),sc=W/tw; cols.forEach(c=>c.w=c.width*sc);
    const head=()=>{ ensure(24); const y=doc.y; doc.rect(LEFT,y,W,20).fill(C.headbg); let x=LEFT; cols.forEach(c=>{ doc.fillColor('#FFF').font('Helvetica-Bold').fontSize(8).text(c.label,x+5,y+6,{width:c.w-10,align:c.align||'left'}); x+=c.w;}); doc.y=y+20; };
    head(); if(!rows.length){ ensure(18); doc.fillColor(C.muted).font('Helvetica').fontSize(9).text('No records.',LEFT+5,doc.y+4); doc.y+=18; }
    rows.forEach((r,idx)=>{ const ch=r._h||18; if(doc.y+ch>BOTTOM){doc.addPage();head();} const y=doc.y; if(idx%2===1)doc.rect(LEFT,y,W,ch).fill(C.zebra); let x=LEFT; cols.forEach(c=>{ const cell=r[c.key]; const val=typeof cell==='object'&&cell?cell.t:cell; const col=typeof cell==='object'&&cell?cell.c:C.body; const bold=typeof cell==='object'&&cell&&cell.b; doc.fillColor(col==null?C.body:col).font(bold?'Helvetica-Bold':'Helvetica').fontSize(8.3).text(val==null?'':String(val),x+5,y+5,{width:c.w-10,align:c.align||'left'}); x+=c.w; }); doc.y=y+ch; });
    if(opts.total){ ensure(20); const y=doc.y; doc.rect(LEFT,y,W,20).fill(C.chipbg); let x=LEFT; cols.forEach(c=>{ const cell=opts.total[c.key]; const val=typeof cell==='object'&&cell?cell.t:cell; const col=typeof cell==='object'&&cell?cell.c:C.dark; doc.fillColor(col==null?C.dark:col).font('Helvetica-Bold').fontSize(8.6).text(val==null?'':String(val),x+5,y+6,{width:c.w-10,align:c.align||'left'}); x+=c.w; }); doc.y=y+20; }
    doc.moveDown(0.4); }
  function statCard(x,y,w,label,value,color){ doc.roundedRect(x,y,w,52,6).fill('#FFF'); doc.roundedRect(x,y,w,52,6).lineWidth(1).strokeColor(C.line).stroke(); doc.rect(x,y,4,52).fill(color); doc.fillColor(C.muted).font('Helvetica').fontSize(8).text(label.toUpperCase(),x+12,y+9,{width:w-18,characterSpacing:0.4}); doc.fillColor(color).font('Helvetica-Bold').fontSize(14).text(value,x+12,y+24,{width:w-18}); }

  // Header band
  doc.rect(0,0,PW,104).fill(C.primary);
  doc.fillColor('#FFF').font('Helvetica-Bold').fontSize(21).text('My Account Statement', LEFT,24,{width:W});
  doc.fillColor('#FFF').font('Helvetica-Bold').fontSize(13).text(user.name, LEFT,50,{width:W});
  doc.fillColor('#DCE8FF').font('Helvetica').fontSize(9).text(`Player ID: ${user.id}   .   Your agent: ${agent.name||'-'}`, LEFT,70,{width:W});
  doc.fillColor('#DCE8FF').font('Helvetica').fontSize(8.5).text(`Date: ${new Date().toLocaleString('en-GB')}   .   All amounts in Rupees (INR)`, LEFT,84,{width:W});
  doc.y=122;

  // Stat cards - plain language
  const gap=10, cw3=(W-2*gap)/3;
  const cy=doc.y;
  statCard(LEFT,cy,cw3,'Money added by agent', inr(agentCredit), C.primary);
  statCard(LEFT+cw3+gap,cy,cw3,'Total win / loss', (netPnl>=0?'+':'')+inr(netPnl), pnl(netPnl));
  statCard(LEFT+2*(cw3+gap),cy,cw3,'Balance in account', inr(wallet), C.green);
  doc.y=cy+52+14;

  // Plain one-line summary anyone can read
  ensure(40);
  const sy=doc.y;
  doc.roundedRect(LEFT,sy,W,34,5).fill('#F0F6FF');
  doc.fillColor(C.dark).font('Helvetica').fontSize(9.5).text(
    `In simple words: your agent added ${inr(agentCredit)}. You won ${inr(winNet)} and lost ${inr(Math.abs(lossNet))}. ` +
    `So the money in your account right now is ${inr(wallet)}.`,
    LEFT+12,sy+8,{width:W-24,lineGap:2});
  doc.y=sy+34+12;

  h2('Your Details');
  kv([['Your name',user.name],['Player ID',String(user.id)],['Email',user.email||'-'],
      ['Your agent',`${agent.name||'-'}`],
      ['Account status',(user.status||'-').toUpperCase()],['Betting',(user.bet_status||'-').toUpperCase()],
      ['Money added by agent',inr(agentCredit),C.primary],['Balance in account',inr(wallet),C.green]]);

  h2('How much you won and lost');
  table([
    {key:'seg',label:'Result',width:34},{key:'bets',label:'No. of bets',width:14,align:'right'},
    {key:'staked',label:'Amount bet',width:24,align:'right'},{key:'net',label:'Win / Loss',width:24,align:'right'}],
    [ {seg:'Bets you WON', bets:String(won.length), staked:inr(won.reduce((a,b)=>a+Number(b.stake_amount),0)), net:{t:'+'+inr(winNet),c:pnl(winNet),b:true}},
      {seg:'Bets you LOST',  bets:String(lost.length), staked:inr(lost.reduce((a,b)=>a+Number(b.stake_amount),0)), net:{t:inr(lossNet),c:pnl(lossNet),b:true}} ],
    { total:{ seg:'TOTAL', bets:String(bets.length), staked:inr(staked), net:{t:(netPnl>=0?'+':'')+inr(netPnl),c:pnl(netPnl),b:true} } });

  h2('Money statement (step by step)','Shows every add and every bet result, and your balance after each');
  table([
    {key:'ts',label:'Date & time',width:25},{key:'cat',label:'What happened',width:17},{key:'desc',label:'Details',width:46},
    {key:'amt',label:'Amount',width:19,align:'right'},{key:'bal',label:'Balance',width:19,align:'right'}],
    events.map(e=>({ _h:20, ts:dts(e.ts), cat:e.cat,
      desc:e.desc, amt:{t:(e.amt>=0?'+':'')+inr(e.amt),c:pnl(e.amt),b:true}, bal:{t:inr(e.bal),b:true} })),
    { total:{ ts:'FINAL BALANCE', cat:'', desc:'', amt:'', bal:{t:inr(run),c:C.green,b:true} } });

  // Full bet detail
  doc.addPage();
  h2(`Every bet you made (${bets.length})`,'Each bet with what you bet on, the amount, and how much you won or lost');
  table([
    {key:'no',label:'#',width:7,align:'right'},{key:'dt',label:'Date',width:15},{key:'match',label:'Match',width:32},
    {key:'sel',label:'You bet on',width:26},{key:'mt',label:'Bet type',width:15},
    {key:'stake',label:'Amount bet',width:17,align:'right'},
    {key:'res',label:'Result',width:12,align:'center'},{key:'net',label:'Won / Lost',width:18,align:'right'}],
    bets.map((b,i)=>{ const net=Number(b.netamount||0); return { _h:22,
      no:String(i+1), dt:new Date(b.created_at).toLocaleDateString('en-GB',{day:'2-digit',month:'short'}),
      match:b.match_title, sel:b.selection_name, mt:(b.market_type==='Bookmaker'?'Match odds':'Fancy'),
      stake:inr(b.stake_amount),
      res:{t:(b.result_status==='won'?'WON':'LOST'),c:b.result_status==='won'?C.green:C.red,b:true},
      net:{t:(net>=0?'+':'')+inr(net),c:pnl(net),b:true} }; }),
    { total:{ no:'', dt:'', match:'TOTAL', sel:'', mt:'', stake:inr(staked), res:'', net:{t:(netPnl>=0?'+':'')+inr(netPnl),c:pnl(netPnl),b:true} } });

  // Simple final calculation
  doc.moveDown(0.4);
  h2('Final calculation');
  kv([['Money added by agent',inr(agentCredit)],['+ Total you won',inr(winNet),C.green],
      ['- Total you lost',inr(Math.abs(lossNet)),C.red],['= Balance you should have',inr(agentCredit+netPnl),C.dark],
      ['Balance in your account',inr(wallet),C.green],
      ['Difference',inr(wallet-(agentCredit+netPnl)), (wallet-(agentCredit+netPnl))===0?C.green:C.red]]);

  const y=doc.y+6; ensure(46);
  doc.roundedRect(LEFT,y,W,40,5).fill(C.chipbg); doc.rect(LEFT,y,3.5,40).fill(C.primary);
  doc.fillColor(C.dark).font('Helvetica').fontSize(8.6).text(
    'How to read this: Balance = money your agent added + bets you won - bets you lost. ' +
    'The "Difference" is zero, which means everything matches and your account balance is correct. All amounts are in Rupees.',
    LEFT+10,y+8,{width:W-20,lineGap:1.8});

  doc.end();
  await db.end();
  await new Promise((resolve,reject)=>{ stream.on('finish',resolve); stream.on('error',reject); }); // fully flushed to disk
  return outfile;
}

if (require.main === module) {
  const uid = process.argv[2] || '9181647851';
  const out = process.argv[3];
  build(uid, out).then(f=>{ console.log('PDF written:', f); process.exit(0); })
    .catch(e=>{ console.error('FAILED:', e.message); process.exit(1); });
}
module.exports = { build };
