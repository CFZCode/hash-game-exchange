
const axios = require('axios');
const crypto = require('crypto');
const NodeCache = require('node-cache');
const { v4: uuid, v5: uuidv5 } = require('uuid');
const db = require('../General/Model');          // ← pg client
const Big = require('big.js');

/* ────────── basic logger – prints ISO time + any args ─────────── */
const log = (...a) => console.log(new Date().toISOString(), ...a);
const paramsOf = req => (req.method === 'POST' ? req.body : req.query);

/* ────────── Slotegrator credentials (env in prod!) ────────────── */
const BASE = 'https://gis.slotegrator.com/api/index.php/v1';
const M_ID = 'REMOVED_SECRET';
const M_KEY = 'REMOVED_SECRET';
/* ────────── RAM caches (games 24 h, jackpots 60 s, providers 24 h) ─ */
const cacheGames     = new NodeCache({ stdTTL: 86_400 });
const cacheJackpots  = new NodeCache({ stdTTL: 60     });
const cacheProviders = new NodeCache({ stdTTL: 86_400 });

/* ────────── helpers ────────────────────────────────────────────── */
const SUPPORTED = ['USDT','USD','INR','EUR','PKR'];
const ALLOWED_COLUMNS = ['inr', 'usdt', 'pkr', 'eur', 'usd'];
const EXT2INT   = { USD:'USDT' };
const INT2EXT   = { USDT:'USD' ,
  INR :'PKR'
};
const CUR2COL = {
  PKR: 'inr',
  INR: 'inr',
  USD: 'usdt',
  USDT: 'usdt'
};
const sleep = ms => new Promise(r => setTimeout(r, ms));
const fs   = require('fs');
const path = require('path');
const winston = require('winston');

/* make sure the logs folder exists */
const logDir   = path.join(__dirname, '..', 'logs');   //  .. = project root
if (!fs.existsSync(logDir)) fs.mkdirSync(logDir, { recursive: true });

const fileLog  = winston.createLogger({
  level : 'info',
  format: winston.format.json(),
  transports: [
    new winston.transports.File({
      filename : path.join(logDir, 'gis-trx.log'), //  <── now in /logs/
      maxsize  : 1 * 1024 * 1024,   // 1 MB
      maxFiles : 3                  // keep last 3 files
    })
  ]
});

/* base headers for every call to Slotegrator */
const baseHdr = () => ({
  'X-Merchant-Id': M_ID,
  'X-Timestamp'  : Math.floor(Date.now() / 1000).toString(),
  'X-Nonce'      : crypto.randomBytes(16).toString('hex')
});

const canon = v =>
  v === null || v === undefined           ? '' :
  typeof v === 'number' || typeof v === 'bigint'
    ? Big(v).toString()                   // trims trailing zeros
    : String(v);                          // strings stay untouched

const flatten = (obj, prefix = '') => {
  const out = [];
  if (Array.isArray(obj)) {
    obj.forEach((v, i) => out.push(...flatten(v, `${prefix}[${i}]`)));
  } else if (obj && typeof obj === 'object') {
    Object.keys(obj).forEach(k =>
      out.push(...flatten(obj[k], prefix ? `${prefix}[${k}]` : k)));
  } else {
    out.push([prefix, canon(obj)]);
  }
  return out;
};

const asciiSort = ([a], [b]) => (a < b ? -1 : a > b ? 1 : 0);

// --- signature -------------------------------------------------------------
const sign = (params, hdr) => {
  const merged = {
    'X-Merchant-Id': hdr['X-Merchant-Id'],
    'X-Timestamp'  : hdr['X-Timestamp'],
    'X-Nonce'      : hdr['X-Nonce'],
    ...params
  };

  /*  Use x-www-form-urlencoded encoding (space → '+') so the signed
      string matches the URLSearchParams body byte-for-byte, the same
      way PHP http_build_query encodes on Slotegrator's side.          */
  const sp = new URLSearchParams();
  flatten(merged)
    .sort(asciiSort)                       // PHP-compatible ordering
    .forEach(([k, v]) => sp.append(k, v));
  const qs = sp.toString();

  return crypto.createHmac('sha1', M_KEY).update(qs).digest('hex');
};

const verify = req =>
  sign(req.body, {
    'X-Merchant-Id': req.get('X-Merchant-Id'),
    'X-Timestamp'  : req.get('X-Timestamp'),
    'X-Nonce'      : req.get('X-Nonce')
  }) === req.get('X-Sign');
/* HTTP shortcuts */
/* HTTP helpers – ALWAYS 200 (Slotegrator rule) --------------------- */
const ok   = (r, o)                => r.status(200).json(o);
const err  = (r, c, m)             => ok(r, { error_code: c, error_description: m });
const created = (r,d)=>r.status(201).json(d);
const fail    = (r,s,m)=>r.status(s).json({ name:'Error', message:m, code:0, status:s });

/* common axios → response mapper */
const axiosErr = (res, e) => {
  const s = e.response?.status || 500;
  const m = e.response?.data?.message || e.message;

  /*  Dump the WHOLE upstream failure – status line, headers and raw body.
      Without this an aggregator-side block (e.g. a WAF returning 406 with an
      empty body) looks identical to a real API error in the logs.          */
  const cfg  = e.config || {};
  const body = e.response?.data;
  const raw  = body === undefined || body === null || body === ''
                 ? '<<EMPTY BODY>>'
                 : (typeof body === 'string' ? body : JSON.stringify(body));

  log('┌── axios-error ────────────────────────────────────────────────');
  log('│ upstream :', (cfg.method || '?').toUpperCase(), cfg.url || '?');
  log('│ req-hdrs :', JSON.stringify(cfg.headers || {}));
  log('│ sent     :', typeof cfg.data === 'string' ? cfg.data : JSON.stringify(cfg.data));
  log('│ status   :', s, e.response?.statusText || '', e.code ? `(${e.code})` : '');
  log('│ res-hdrs :', JSON.stringify(e.response?.headers || {}));
  log('│ res-body :', raw.length > 2000 ? raw.slice(0, 2000) + ' …[truncated]' : raw);
  log('└───────────────────────────────────────────────────────────────');

  fail(res, s, m);
};

/* mini helpers */
const has = (o,f)=>o[f]!==undefined && o[f]!==null && o[f]!=='';  
const num = v=>!Number.isNaN(Number(v));
/* one constant namespace → NEVER change once in production */
const UUID_NS   = 'b58d9c74-80bb-46cb-8e0d-57458f25c23c';
const intId     = ext => ext ? uuidv5(ext, UUID_NS) : uuid();
function rspId(ext) {               // id we RETURN to provider
  return ext ? uuidv5(String(ext), UUID_NS) : uuid();
}
const b4 = n => Big(n).toFixed(4);
async function playerBalance (uid, col) {
  /* last cached value in gis_transactions first */
  const last = await db.query(
    `SELECT balance_after
       FROM gis_transactions
      WHERE user_id=$1
  ORDER BY id DESC
      LIMIT 1`, [uid]);

  if (last.rowCount) return Big(last.rows[0].balance_after);

  /* fallback – row in credits table */
  const cr = await db.query(`SELECT ${col} FROM credits WHERE uid=$1`, [uid]);
  if (!cr.rowCount) return null;          // unknown player
  return Big(cr.rows[0][col]);
}
/* ------------------------------------------------------------------ */
/* ─────────── rounding & logging helpers ─────────────────────────── */
const round4 = n => Number((Math.round(n * 1e4) / 1e4).toFixed(4));

const logTx = async (tx, bal) => {
  const txId = tx.transaction_id || uuid();           // unique
  const ins = await db.query(`
    INSERT INTO gis_transactions (
      user_id, session_id, transaction_id, action, amount, currency,
      game_uuid, type, freespin_id, quantity, round_id, finished,
      transaction_datetime, casino_request_retry_count, bet_transaction_id,
      rollback_transactions, provider_round_id, balance_after
    ) VALUES (
      $1,$2,$3,$4,$5,$6,
      $7,$8,$9,$10,$11,$12,
      $13,$14,$15,$16,$17,$18
    )
    ON CONFLICT (transaction_id) DO NOTHING
  `, [
    tx.user_id,
    tx.session_id,
    txId,
    tx.action,
    round4(tx.amount || 0),
    tx.currency,
    tx.game_uuid,
    tx.type,
    tx.freespin_id,
    tx.quantity,
    tx.round_id,
    tx.finished,
    tx.transaction_datetime ? new Date(tx.transaction_datetime) : null,
    tx.casino_request_retry_count,
    tx.bet_transaction_id,
    tx.rollback_transactions
      ? JSON.stringify(tx.rollback_transactions)
      : null,
    tx.provider_round_id,
    round4(bal)
  ]);

  // Mirror sports settlement: persist net casino P&L on users.casino_gt so
  // admin panel reads a stable column instead of summing gis_transactions.
  // PKR + INR only (the supported fiat currencies for casino settlement).
  // Only on fresh INSERTs (ON CONFLICT duplicates are skipped).
  const ccy = String(tx.currency || '').toUpperCase();
  if (ins.rowCount && (ccy === 'INR' || ccy === 'PKR')) {
    let delta = 0;
    const amt = round4(tx.amount || 0);
    if (tx.action === 'bet')                          delta = -amt;
    else if (tx.action === 'win' || tx.action === 'refund') delta =  amt;
    if (delta !== 0) {
      await db.query(
        'UPDATE users SET casino_gt = COALESCE(casino_gt, 0) + $1 WHERE id = $2',
        [delta, tx.user_id]
      );
    }
  }
};

/* high-precision helpers */

const ZERO = Big(0);

/* update balance **without** rounding – DB keeps full precision     */
const setBal = (uid, ccy, val) =>
  db.query(`UPDATE credits SET ${ccy.toLowerCase()} = $1 WHERE uid = $2`,
           [val, uid]);
/* ------------------------------------------------------------------ */
/* balance helpers – always return a Big value                        */
async function fetchOrCreateBalance (playerId, col /* e.g. 'usdt' */) {
  // ① try last cached value in gis_transactions
  const last = await db.query(
    `SELECT balance_after
       FROM gis_transactions
      WHERE user_id = $1
   ORDER BY id DESC
      LIMIT 1`, [playerId]);

  if (last.rowCount) return Big(last.rows[0].balance_after);

  // ② fall back to credits table
  const cred = await db.query(
    `SELECT ${col} FROM credits WHERE uid = $1`,
    [playerId]);

  if (cred.rowCount) return Big(cred.rows[0][col]);

  // ③ first-time player – create zero row so we never get here again
  await db.query(
    `INSERT INTO credits (uid, ${col}) VALUES ($1, 0)
     ON CONFLICT (uid) DO NOTHING`,
    [playerId]);

  return Big(0);   // start with 0 balance
}

const gisOk   = (res, payload)                        => res.status(200).json(payload);
const gisFail = (res, code, description = '')        =>
  gisOk(res, { error_code: code, error_description: description }); // #1


module.exports = {

/* ═══════════════════════════════
   Public endpoints (Slotegrator)
   ═══════════════════════════════ */

/* ---------- GET /games ---------------------------------------------- */
// async getGames(req, res) {
//   try {
//     // Check cache first
//     const cached = cacheGames.get('games');
//     if (cached) {
//       log('GET /games - returning cached data');
//       return ok(res, cached);
//     }

//     const hdr = baseHdr();
//     const prm = { expand: 'tags,parameters,images,related_games' };
//     hdr['X-Sign'] = sign(prm, hdr);
    
//     if (BASE.includes('staging')) await sleep(1000);
    
//     log('GET /games - fetching from API', prm);
//     const r = await axios.get(`${BASE}/games`, { headers: hdr, params: prm });
    
//     const out = { items: r.data.items || r.data };
    
//     // Cache with proper key
//     cacheGames.set('games', out);
    
//     ok(res, out);
//   } catch (e) { 
//     axiosErr(res, e); 
//   }
// },

/* ---------- GET /games ---------------------------------------------- */
async getGames(req, res) {
  try {
    // return cached full list if present
    const cached = cacheGames.get('games');
    if (cached) {
      log('GET /games - returning cached data');
      return ok(res, cached);
    }

    const expand = 'tags,parameters,images,related_games';
    const per_page = 50;                 // production only returns 50 per page
    let page = 1;
    let allItems = [];
    let totalCount = null;
    let pageCount = null;

    while (true) {
      const hdr = baseHdr();
      const prm = { expand, per_page, page };
      hdr['X-Sign'] = sign(prm, hdr);

      // Respect rate limits: production ~1 req/sec, staging is more permissive
      if (!BASE.includes('staging')) await sleep(1100);
      else await sleep(0); // no extra delay for staging (optional)

      log('GET /games - fetching page', page, prm);
      let r;
      try {
        r = await axios.get(`${BASE}/games`, { headers: hdr, params: prm, timeout: 15000 });
      } catch (axErr) {
        console.error('GET /games upstream error', {
          page, status: axErr.response?.status, data: axErr.response?.data
        });
        throw axErr;
      }

      // Normalize different shapes: r.data may be [] or { items: [...], _meta: {...} }
      const data = r.data || {};
      let items = [];
      if (Array.isArray(data)) items = data;
      else if (Array.isArray(data.items)) items = data.items;
      else if (Array.isArray(data.data)) items = data.data;
      else if (typeof data === 'object') {
        // fallback: collect candidate objects
        items = Object.values(data).filter(v => Array.isArray(v)).flat(); // defensive
      }

      // append items
      allItems.push(...items);

      // extract pagination meta (prefer body._meta, then headers)
      pageCount = Number(data._meta?.pageCount) || Number(r.headers['x-pagination-page-count']) || pageCount;
      totalCount = Number(data._meta?.totalCount) || Number(r.headers['x-pagination-total-count']) || totalCount;

      // stop condition
      if (pageCount) {
        if (page >= pageCount) break;
      } else {
        // fallback: last page if fewer items than per_page
        if (items.length < per_page) break;
      }

      page++;
    }

    const out = {
      items: allItems,
      _meta: {
        totalCount: totalCount ?? allItems.length,
        pageCount: pageCount ?? Math.ceil(allItems.length / per_page),
        currentPage: 1,
        perPage: per_page
      }
    };

    cacheGames.set('games', out);    // cache the whole result (docs require caching)
    log('GET /games - fetched total', out._meta.totalCount || out.items.length);
    ok(res, out);
  } catch (e) {
    axiosErr(res, e);
  }
},
/* ---------- GET /sync/gamesnew ------------------------------------- */
/* ---------- GET /sync/gamesnew (improved, batch upsert) ---------- */
async syncGamesNew(_req, res) {
  try {
    log('syncGamesNew – start (batch upsert)');
    const per_page = 50;
    let page = 1;
    let totalProcessed = 0;
    let totalInserted = 0;
    let totalUpdated = 0;

    while (true) {
      const hdr = baseHdr();
      const prm = { expand: 'tags,parameters,images,related_games', per_page, page };
      hdr['X-Sign'] = sign(prm, hdr);

      if (!BASE.includes('staging')) await sleep(1100);
      log(`Fetching page ${page}...`);
      const r = await axios.get(`${BASE}/games`, { headers: hdr, params: prm, timeout: 15000 });
      const data = r.data || {};
      const items = Array.isArray(data.items) ? data.items :
                    Array.isArray(data) ? data :
                    Array.isArray(data.data) ? data.data : [];

      // Build batch insert values (parametrized)
      const rows = [];
      for (const g of items) {
        if (!g || !g.uuid) {
          log('Skipping row missing uuid', g && (g.name || g.provider));
          continue;
        }
        rows.push({
          uuid: String(g.uuid),
          name: g.name || null,
          provider: g.provider || null,
          provider_id: g.provider_id || null,
          type: g.type || null,
          image: g.image || null,
          technology: g.technology || null,
          has_lobby: g.has_lobby === 1 || g.has_lobby === true,
          is_mobile: g.is_mobile === 1 || g.is_mobile === true,
          has_freespins: g.has_freespins === 1 || g.has_freespins === true,
          freespin_valid_until_full_day: g.freespin_valid_until_full_day === 1 || g.freespin_valid_until_full_day === true,
          updated_at: g.updated_at || null,
          label: g.label || null,
          parameters: g.parameters || null,
          tags: g.tags || null,
          images: g.images || null
        });
      }

      if (rows.length === 0) {
        log(`Page ${page} had no valid rows, stopping.`);
        break;
      }

      // Build parameterized query
      // Each row has 16 columns -> $1..$16 for first row, $17..$32 for second, etc.
      const cols = [
        'uuid','name','provider','provider_id','type','image','technology',
        'has_lobby','is_mobile','has_freespins','freespin_valid_until_full_day',
        'updated_at','label','parameters','tags','images'
      ];
      const values = [];
      const valuePlaceholders = [];
      rows.forEach((rObj, i) => {
        const idxBase = i * cols.length;
        const placeholders = cols.map((_, j) => `$${idxBase + j + 1}`);
        valuePlaceholders.push(`(${placeholders.join(',')})`);
        // push in same order as cols
        values.push(
          rObj.uuid,
          rObj.name,
          rObj.provider,
          rObj.provider_id,
          rObj.type,
          rObj.image,
          rObj.technology,
          rObj.has_lobby,
          rObj.is_mobile,
          rObj.has_freespins,
          rObj.freespin_valid_until_full_day,
          rObj.updated_at,
          rObj.label,
          rObj.parameters ? JSON.stringify(rObj.parameters) : null,
          rObj.tags ? JSON.stringify(rObj.tags) : null,
          rObj.images ? JSON.stringify(rObj.images) : null
        );
      });

      const insertSQL = `
        INSERT INTO gisgamesnew (${cols.join(',')})
        VALUES ${valuePlaceholders.join(',')}
        ON CONFLICT (uuid) DO UPDATE SET
          name = EXCLUDED.name,
          provider = EXCLUDED.provider,
          provider_id = EXCLUDED.provider_id,
          type = EXCLUDED.type,
          image = EXCLUDED.image,
          technology = EXCLUDED.technology,
          has_lobby = EXCLUDED.has_lobby,
          is_mobile = EXCLUDED.is_mobile,
          has_freespins = EXCLUDED.has_freespins,
          freespin_valid_until_full_day = EXCLUDED.freespin_valid_until_full_day,
          updated_at = EXCLUDED.updated_at,
          label = EXCLUDED.label,
          parameters = EXCLUDED.parameters,
          tags = EXCLUDED.tags,
          images = EXCLUDED.images
        WHERE
          -- only update if any significant column actually differs -> true no-op avoidance
          gisgamesnew.name               IS DISTINCT FROM EXCLUDED.name OR
          gisgamesnew.provider           IS DISTINCT FROM EXCLUDED.provider OR
          gisgamesnew.provider_id        IS DISTINCT FROM EXCLUDED.provider_id OR
          gisgamesnew.type               IS DISTINCT FROM EXCLUDED.type OR
          gisgamesnew.image              IS DISTINCT FROM EXCLUDED.image OR
          gisgamesnew.technology         IS DISTINCT FROM EXCLUDED.technology OR
          gisgamesnew.has_lobby          IS DISTINCT FROM EXCLUDED.has_lobby OR
          gisgamesnew.is_mobile          IS DISTINCT FROM EXCLUDED.is_mobile OR
          gisgamesnew.has_freespins      IS DISTINCT FROM EXCLUDED.has_freespins OR
          gisgamesnew.freespin_valid_until_full_day IS DISTINCT FROM EXCLUDED.freespin_valid_until_full_day OR
          gisgamesnew.updated_at         IS DISTINCT FROM EXCLUDED.updated_at OR
          gisgamesnew.label              IS DISTINCT FROM EXCLUDED.label OR
          gisgamesnew.parameters        IS DISTINCT FROM EXCLUDED.parameters OR
          gisgamesnew.tags              IS DISTINCT FROM EXCLUDED.tags OR
          gisgamesnew.images            IS DISTINCT FROM EXCLUDED.images
      `;

      // Execute the batch
      const result = await db.query(insertSQL, values);

      // Note: result.rowCount counts inserted + updated rows for this statement in many drivers.
      totalProcessed += rows.length;
      // We can estimate inserted vs updated by querying stats (optional),
      // but to keep it simple we will count processed rows only:
      totalInserted += rows.length; // conservative (could be updated)
      log(`Page ${page}: processed ${rows.length} rows.`);

      // Stop condition based on pageCount if present
      const pageCount = Number(data._meta?.pageCount) || 1;
      if (page >= pageCount) break;
      page++;
    }

    ok(res, { success: true, message: `Processed ${totalProcessed} games into gisgamesnew` });
  } catch (e) {
    console.error('syncGamesNew failed', e);
    axiosErr(res, e);
  }
},
/* ---------- GET /sync/providersnew ----------------------------------- */
/* ---------- GET /sync/providersnew ----------------------------------- */
async syncProvidersNew(_req, res) {
  try {
    log('syncProvidersNew – start (fetching from /games)');
    const expand = 'tags,parameters,images,related_games'; // same expand you use for full games
    const per_page = 50;
    let page = 1;
    const newProviders = new Set();
    let totalFetched = 0;

    while (true) {
      const hdr = baseHdr();
      const prm = { expand, per_page, page };
      hdr['X-Sign'] = sign(prm, hdr);

      // Respect Slotegrator production rate-limit (~1 req/sec)
      if (!BASE.includes('staging')) await sleep(1100);

      log(`syncProvidersNew - fetching /games page ${page}`);
      const r = await axios.get(`${BASE}/games`, { headers: hdr, params: prm, timeout: 20000 });

      const data = r.data || {};
      // Normalize items from possible shapes
      const items = Array.isArray(data.items) ? data.items :
                    Array.isArray(data) ? data :
                    Array.isArray(data.data) ? data.data : [];

      if (items && items.length) {
        totalFetched += items.length;
        for (const g of items) {
          if (!g) continue;
          const p = (g.provider ?? g.label ?? '').toString().trim();
          if (p) newProviders.add(p);
        }
      } else {
        // defensive: try to find any nested array if nothing in items
        const nested = Object.values(data).find(v => Array.isArray(v));
        if (nested) {
          for (const g of nested) {
            if (!g) continue;
            const p = (g.provider ?? g.label ?? '').toString().trim();
            if (p) newProviders.add(p);
          }
          totalFetched += nested.length;
        }
      }

      // pagination stop condition
      const pageCount = Number(data._meta?.pageCount) || Number(r.headers['x-pagination-page-count']) || null;
      if (pageCount) {
        if (page >= pageCount) break;
      } else {
        // fallback: if fewer items than page size, assume last page
        if (!items || items.length < per_page) break;
      }

      page++;
    }

    log(`syncProvidersNew - total games scanned: ${totalFetched}; unique providers found: ${newProviders.size}`);

    const list = [...newProviders].filter(Boolean).sort();

    // Replace snapshot: clear previous contents
    await db.query('TRUNCATE TABLE gis_providers_new RESTART IDENTITY');

    // Batch insert in a single transaction for speed
    if (list.length) {
      // Build parameterized multi-row insert
      const vals = [];
      const placeholders = list.map((name, i) => {
        vals.push(name);
        return `($${i + 1})`;
      }).join(',');

      const insertSQL = `
        INSERT INTO gis_providers_new (name)
        VALUES ${placeholders}
        ON CONFLICT (name) DO NOTHING
      `;
      await db.query(insertSQL, vals);
    }

    ok(res, { success: true, message: `Synced ${list.length} providers into gis_providers_new`, providers_count: list.length });
  } catch (e) {
    console.error('syncProvidersNew failed', e);
    axiosErr(res, e);
  }
},





/* ---------- GET /game-tags ------------------------------------------ */
async getGameTags(req,res){
  const { page=1, per_page=20 } = req.query;
  try{
    const hdr = baseHdr();
    const prm = { expand:'category', page, per_page };
    hdr['X-Sign'] = sign(prm, hdr);
    if(BASE.includes('staging')) await sleep(1000);
    log('GET /game-tags', prm);

    const r = await axios.get(`${BASE}/game-tags`, { headers:hdr, params:prm });
    ok(res, { items:r.data.items||r.data, _pagination:pag(r.headers) });
  }catch(e){ axiosErr(res,e); }
},

/* ---------- GET /games/lobby ---------------------------------------- */
async getGameLobby(req,res){
  const { game_uuid,currency,technology } = req.query;
  if(!game_uuid || !SUPPORTED.includes(currency))
    return fail(res,400,'Invalid game_uuid or currency');

  try{
    const hdr = baseHdr();
    const prm = { game_uuid, currency, ...(technology?{technology}:{}) };
    hdr['X-Sign'] = sign(prm, hdr);
    log('GET /games/lobby', prm);

    const r = await axios.get(`${BASE}/games/lobby`, { headers:hdr, params:prm });
    ok(res, r.data);
  }catch(e){ axiosErr(res,e); }
},
/* ------------------------------------------------------------------ */
/*  POST /games/init                                                  */
/* ------------------------------------------------------------------ */
async  initGame (req, res) {
  /* 1. Payload-level validation ------------------------------------ */
  const body   = { device: 'desktop', ...req.body };     // desktop is default
  const miss   = ['game_uuid', 'player_id', 'player_name', 'currency']
                   .filter(f => body[f] === undefined || body[f] === null || body[f] === '');

  if (miss.length)            return fail(res, 422, `Missing fields: ${miss.join(', ')}`);
  if (Number.isNaN(Number(body.player_id)))
                              return fail(res, 422, 'player_id must be a number');
  if (!SUPPORTED.includes(body.currency))
                              return fail(res, 400,  'Unsupported currency');
  if (body.device && !['desktop', 'mobile'].includes(body.device))
                              return fail(res, 422, 'device invalid');

  try {
    /* 2. Make sure the user exists --------------------------------- */
    const u = await db.query('SELECT id FROM users WHERE id = $1', [body.player_id]);
    if (!u.rowCount)          return fail(res, 404, 'User not found');

    /* 3. Persist session locally ----------------------------------- */
    const session_id = uuid();
    await db.query(`
      INSERT INTO gis_sessions (
        user_id, session_id, game_uuid, currency,
        device, return_url, language, lobby_data
      ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
    `, [
      body.player_id,
      session_id,
      body.game_uuid,
      body.currency,
      body.device,
      body.return_url,
      body.language,
      body.lobby_data
    ]);

    /* 3b. Track recently-played (cap 15 per user) ------------------ */
    try {
      await db.query(`
        INSERT INTO gis_recently_played (user_id, game_uuid, played_at)
        VALUES ($1, $2, NOW())
        ON CONFLICT (user_id, game_uuid)
        DO UPDATE SET played_at = NOW()
      `, [body.player_id, body.game_uuid]);

      await db.query(`
        DELETE FROM gis_recently_played
         WHERE user_id = $1
           AND id NOT IN (
             SELECT id FROM gis_recently_played
              WHERE user_id = $1
              ORDER BY played_at DESC
              LIMIT 15
           )
      `, [body.player_id]);
    } catch (rpErr) {
      log('recently-played track failed', rpErr.message);
    }

    /* 4. Build request to Slotegrator ------------------------------ */
    const hdr = {
      ...baseHdr(),
      'Content-Type': 'application/x-www-form-urlencoded'
    };

    /*  ◉  Keep scalars **raw** – NO String(player_id), NO pre-encoding  */
    const prm = {
      game_uuid   : body.game_uuid,
      player_id   : body.player_id,                   // ← number, not string
      player_name : body.player_name,
      currency    : INT2EXT[body.currency] || body.currency,
      session_id,
      device      : body.device,
      // return_url  : body.return_url,
      return_url: "https://example.com/game-exit.html",
      language    : body.language,
      lobby_data  : body.lobby_data
    };

    /*  Remove empty optionals – spec wants them omitted completely    */
    Object.keys(prm).forEach(k => {
      if (prm[k] === undefined || prm[k] === null || prm[k] === '') delete prm[k];
    });

    /*  Calculate signature on the **un-encoded** payload             */
    hdr['X-Sign'] = sign(prm, hdr);

    /*  Log the exact data we'll send                                 */
    log('POST /games/init →', prm);

    /* 5. Fire & relay ---------------------------------------------- */
    const sgRes = await axios.post(
      `${BASE}/games/init`,
      new URLSearchParams(prm),           // this performs the single encoding
      { headers: hdr }
    );

    /* Slotegrator responds with { url: "<launch-url>" }              */
    created(res, { url: sgRes.data.url, session_id });

  } catch (e) {
    axiosErr(res, e);                     // maps axios errors → fail()
  }
}


/* ---------- POST /games/init ---------------------------------------- */

,

/* ---------- POST /games/init-demo ----------------------------------- */
async initDemoGame(req,res){
  const { game_uuid } = req.body;
  if(!game_uuid) return fail(res,400,'game_uuid required');

  try{
    const prm = {
      game_uuid,
      device     : req.body.device||'desktop',
      return_url : req.body.return_url||'https://example.com',
      language   : req.body.language
    };
    const hdr = { ...baseHdr(), 'Content-Type':'application/x-www-form-urlencoded'};
    hdr['X-Sign'] = sign(prm, hdr);
    log('POST /games/init-demo', prm);

    const r = await axios.post(`${BASE}/games/init-demo`,
                               new URLSearchParams(prm), { headers:hdr });
    created(res, { url:r.data.url });
  }catch(e){ axiosErr(res,e); }
},
async handleTransaction (req, res) {
  try {
    /* ───────────── 1)  signature & params ────────────────────────── */
    log('[trx] ⇢', { ip: req.ip, params: paramsOf(req) });
    if (!verify(req))
      return gisFail(res, 'INTERNAL_ERROR', 'Invalid X-Sign');

    const p = paramsOf(req);
    const {
      action,
      player_id,
      currency,
      amount = '0',
      transaction_id: extId,             // provider's id
      bet_transaction_id,
      rollback_transactions = [],
      round_id,
      game_uuid,
      provider_round_id
    } = p;

    console.log(`[trx] received action=${action} player_id=${player_id} currency=${currency} amount=${amount} extId=${extId} bet_transaction_id=${bet_transaction_id} rollback_transactions=${JSON.stringify(rollback_transactions)} round_id=${round_id} game_uuid=${game_uuid} provider_round_id=${provider_round_id}`);
    const _currency = String(currency || '').toUpperCase();
    if (!action || !player_id || !currency)
      return gisFail(res, 'INTERNAL_ERROR',
                     'action, player_id, currency are required');

   if (!/^\d+$/.test(String(player_id))) {
  log('[trx] non-numeric uid → unknown player', { player_id });   // console
  fileLog.info({ step: 'non-numeric-uid', player_id, action });   // file
  return gisFail(res, 'INTERNAL_ERROR', 'Player not found');
}
    if (!SUPPORTED.includes(currency))
      return gisFail(res, 'INTERNAL_ERROR', 'Unsupported currency');

const playerExists = await db.query(
  'SELECT 1 FROM credits WHERE uid::text = $1 LIMIT 1',   // ← cast to text
  [player_id]
);
if (!playerExists.rowCount)
  return gisFail(res, 'INTERNAL_ERROR', 'Player not found');


    const needAmt = ['bet', 'win', 'refund'].includes(action);
    const amtBig  = Big(amount);
    const retId   = rspId(extId);        // ← what we'll send back

    /* ───────────── 2)  idempotency on provider id ────────────────── */
    const old = await db.query(
      `SELECT action, balance_after, rollback_transactions
         FROM gis_transactions
        WHERE transaction_id = $1
        LIMIT 1`, [extId]
    );
    if (old.rowCount) {
      const row = old.rows[0];
      const resp = {
        balance       : b4(row.balance_after),
        transaction_id: retId
      };
      if (row.action === 'rollback' && row.rollback_transactions)
        resp.rollback_transactions =
          row.rollback_transactions.map(t => t.transaction_id);
      return ok(res, resp);
    }

    /* extra: identical rollback array, new provider id -------------- */
    if (action === 'rollback') {
      const dup = await db.query(
        `SELECT balance_after
           FROM gis_transactions
          WHERE action='rollback'
            AND rollback_transactions::text = $1
          LIMIT 1`,
        [JSON.stringify(rollback_transactions)]
      );
      if (dup.rowCount)
        return ok(res, {
          balance             : b4(dup.rows[0].balance_after),
          transaction_id      : retId,
          rollback_transactions: rollback_transactions.map(t => t.transaction_id)
        });
    }

    /* extra: refund repeated by bet_transaction_id ------------------ */
    // if (action === 'refund') {
    //   const dup = await db.query(
    //     `SELECT balance_after
    //        FROM gis_transactions
    //       WHERE action='refund'
    //         AND bet_transaction_id=$1
    //       LIMIT 1`, [bet_transaction_id]);
    //   if (dup.rowCount)
    //     return ok(res, {
    //       balance       : b4(dup.rows[0].balance_after),
    //       transaction_id: retId
    //     });
    // }
if (action === 'refund') {
  const dup = await db.query(
    `SELECT balance_after, transaction_id          -- need provider id
       FROM gis_transactions
      WHERE action = 'refund'
        AND bet_transaction_id = $1
      LIMIT 1`,
    [bet_transaction_id]
  );
  if (dup.rowCount) {
    /* reproduce the exact id we sent in the first refund response */
    const oldRetId = rspId(dup.rows[0].transaction_id);   // uuid-v5 of FIRST ext-id
    return ok(res, {
      balance       : b4(dup.rows[0].balance_after),
      transaction_id: oldRetId
    });
  }
}
    /* ───────────── 3)  current balance or fail on unknown user ───── */
    // ───────────── 3) current balance or fail on unknown user ─────
const mapped = CUR2COL[_currency];

console.log(`[trx] currency mapping: ${_currency} → ${mapped}`);
if (!mapped) {
  fileLog.info({ step: 'unsupported-currency-mapping', currency: _currency, player_id });
  return gisFail(res, 'INTERNAL_ERROR', 'Unsupported currency mapping');
}
if (!ALLOWED_COLUMNS.includes(mapped)) {
  fileLog.info({ step: 'bad-column', mapped, currency: _currency });
  return gisFail(res, 'INTERNAL_ERROR', 'Unsupported currency column');
}
const col = mapped; // safe, validated column name
let bal;

/* first: does the uid exist at all?  (avoids selecting missing column) */
const exists = await db.query('SELECT 1 FROM credits WHERE uid=$1 LIMIT 1', [player_id]);
if (!exists.rowCount) return gisFail(res, 'INTERNAL_ERROR', 'Player not found');

/* uid exists → now read the specific currency column */
const cr = await db.query(`SELECT ${col} FROM credits WHERE uid=$1`, [player_id]);
if (!cr.rowCount) return gisFail(res, 'INTERNAL_ERROR', 'Player not found');
bal = Big(cr.rows[0][col]);

  //   const col   = (EXT2INT[currency] ?? currency).toLowerCase();
 
  //   let bal;
  // /* first: does the uid exist at all?  (avoids selecting missing column) */
  // const exists = await db.query(
  //   'SELECT 1 FROM credits WHERE uid=$1 LIMIT 1', [player_id]);
  // if (!exists.rowCount)
  //   return gisFail(res, 'INTERNAL_ERROR', 'Player not found');

  // /* uid exists → now read the specific currency column */
  // const cr = await db.query(
  //   `SELECT ${col} FROM credits WHERE uid=$1`, [player_id]);
  //   // console.log('current balance',cr);
  // bal = Big(cr.rows[0][col]);

    /*  balance probes with amount must error on insufficient funds    */
  /* balance probe – only error when an amount is supplied AND insufficient */
/* ───────── balance probe ────────────────────────────────────────── */
if (action === 'balance') {

  /* 1️⃣  unknown-player check (covers both numeric & hex ids) */
  if (!playerExists /* ← we created this a few lines earlier */) {
    fileLog.info({ step: 'balance-probe-unknown-player', player_id });
    return gisFail(res, 'INTERNAL_ERROR', 'Player not found');
  }

  /* 2️⃣  insufficient funds check – only when an amount is supplied   */
  if (p.hasOwnProperty('amount') &&
      amtBig.gt(0) &&
      bal.lt(amtBig)) {
    fileLog.info({
      step     : 'balance-probe-insufficient',
      player_id: player_id,
      balance  : bal.toString(),
      requested: amount
    });
    return gisFail(res, 'INSUFFICIENT_FUNDS',
                   'Not enough money to continue playing');
  }

  /* 3️⃣  simple balance probe → return current balance and exit       */
  fileLog.info({
    step     : 'balance-probe-ok',
    player_id: player_id,
    balance  : bal.toString()
  });
  return ok(res, { balance: b4(bal) });
}



    if (needAmt && amtBig.lt(0))
      return gisFail(res, 'INTERNAL_ERROR', 'amount must be non-negative');

    /* ───────────── 4)  business logic → delta ---------------------- */
    let delta = ZERO;

    switch (action) {
      case 'bet': {
        // Admin/agent casino lock — block NEW bets (wins/refunds still settle).
        const lk = await db.query(
          `SELECT COALESCE(casino_locked,false) AS casino_locked,
                  COALESCE(system_locked,false) AS system_locked,
                  COALESCE(is_demo,false) AS is_demo,
                  demo_bet_limit
             FROM users WHERE id = $1`,
          [player_id]
        );
        if (lk.rows[0] && (lk.rows[0].casino_locked || lk.rows[0].system_locked)) {
          fileLog.info({ step: 'casino-locked', player_id });
          return gisFail(res, 'INSUFFICIENT_FUNDS', 'Casino is locked for this account');
        }
        // Demo accounts: "live casino limit" = max single bet, set by the demo portal agent.
        const demoLimit = Number(lk.rows[0]?.demo_bet_limit || 0);
        if (lk.rows[0]?.is_demo && demoLimit > 0 && amtBig.gt(demoLimit)) {
          fileLog.info({ step: 'demo-bet-limit', player_id, amount, limit: demoLimit });
          return gisFail(res, 'INSUFFICIENT_FUNDS', `Max bet for this demo account is ${demoLimit}`);
        }
        if (bal.lt(amtBig))
          return gisFail(res, 'INSUFFICIENT_FUNDS',
                         'Not enough money to continue playing');
        delta = amtBig.neg();                      break;
      }

      case 'win':     delta = amtBig;             break;

      case 'refund': {
        const bet = await db.query(
          `SELECT 1 FROM gis_transactions
            WHERE transaction_id=$1 AND action='bet'`,
          [bet_transaction_id]);
        if (bet.rowCount) delta = amtBig;
        break;
      }

      case 'rollback':
        for (const tx of rollback_transactions) {
          const a = Big(tx.amount || 0);
          if (a.lte(0)) continue;
          if (tx.action === 'bet')    delta = delta.plus(a);
          if (tx.action === 'win')    delta = delta.minus(a);
          if (tx.action === 'refund') delta = delta.minus(a);
        }
        break;

      case 'balance': /* probe – no change */    break;

      default:
        return gisFail(res, 'INTERNAL_ERROR', 'Invalid action');
    }

    /* ───────────── 5)  apply & persist ----------------------------- */
    //This code is commented by harman because it was causing race conditions and balance inconsistencies in high concurrency scenarios. The new code below uses a single atomic SQL update to ensure consistency.
    // if (!delta.eq(0)) {
    //   bal = bal.plus(delta);
    //   await setBal(player_id, col, bal.toString());
    // }

    if (!delta.eq(0)) {
      const isBet            = action === 'bet';
      const balanceCheckSql  = isBet ? `AND ${col} >= $3` : '';
      const queryParams      = isBet
        ? [delta.toString(), player_id, amtBig.toString()]
        : [delta.toString(), player_id];

      const updated = await db.query(
        `UPDATE credits
            SET ${col} = ${col} + $1
          WHERE uid = $2 ${balanceCheckSql}
      RETURNING ${col} AS new_balance`,
        queryParams
      );

      if (!updated.rowCount)
        return gisFail(res, 'INSUFFICIENT_FUNDS', 'Not enough money to continue playing');

      bal = Big(updated.rows[0].new_balance);
    }

    await logTx({
      ...p,
      user_id       : player_id,
      transaction_id: extId,              // keep provider's id in DB
      amount        : amtBig,
      balance_after : bal.toString(),
      rollback_transactions
    }, bal);

    /* ───────────── 6)  build response ------------------------------ */
    if (action === 'balance')
      return ok(res, { balance: b4(bal) });

    if (action === 'rollback')
      return ok(res, {
        balance             : b4(bal),
        transaction_id      : retId,
        rollback_transactions: rollback_transactions.map(t => t.transaction_id)
      });

    /* bet | win | refund */
    return ok(res, { balance: b4(bal), transaction_id: retId });

  } catch (err) {
    console.error('handleTransaction()', err);
    return gisFail(res, 'INTERNAL_ERROR', 'Unhandled internal error');
  }
},
/* ---------- POST /callback/transactions & POST / -------------------- */

// async  handleTransaction (req, res) {

//   /* ------------------------------------------------------------------ */
//   /* 1) sanity / signature check                                         */
//   /* ------------------------------------------------------------------ */
//   log('[trx] ⇢', { ip: req.ip, params: paramsOf(req) });

//   if (!verify(req))                            // ← your existing verifier
//     return gisFail(res, 'INTERNAL_ERROR', 'Invalid X-Sign');

//   /* ------------------------------------------------------------------ */
//   /* 2) unpack parameters                                                */
//   /* ------------------------------------------------------------------ */
//   const {
//     action,
//     player_id,
//     currency,
//     amount            = '0',
//     transaction_id,
//     bet_transaction_id,
//     round_id,
//     rollback_transactions = [],               // [{action,amount,transaction_id…}]
//     session_id,                               // present but unused
//     game_uuid,
//     provider_round_id
//   } = paramsOf(req);

//   if (!action || !player_id || !currency)
//     return gisFail(res, 'INTERNAL_ERROR',
//                    'action, player_id, currency are required');

//   if (!SUPPORTED.includes(currency))
//     return gisFail(res, 'INTERNAL_ERROR', 'Unsupported currency');

//   const needAmt = ['bet', 'win', 'refund'].includes(action);
//   const amt     = Big(amount);

//   /* ------------------------------------------------------------------ */
//   /* 3) idempotency – transactions we have already processed            */
//   /* ------------------------------------------------------------------ */
//   /* generic idempotency (all calls carrying transaction_id) ----------- */
//   const txRow = await db.query(
//     'SELECT balance_after FROM gis_transactions WHERE transaction_id = $1',
//     [transaction_id]
//   );
//   if (txRow.rowCount)
//     return ok(res, {
//       balance       : b4(txRow.rows[0].balance_after),
//       transaction_id
//     });

//   /* special: refund may repeat with same bet_transaction_id ----------- */
//   if (action === 'refund') {
//     const seen = await db.query(
//       `SELECT transaction_id, balance_after
//          FROM gis_transactions
//         WHERE action = 'refund' AND bet_transaction_id = $1
//         LIMIT 1`,
//       [bet_transaction_id]
//     );
//     if (seen.rowCount)
//       return ok(res, {
//         balance       : b4(seen.rows[0].balance_after),
//         transaction_id: seen.rows[0].transaction_id
//       });
//   }

//   /* special: rollback may repeat with identical array ----------------- */
//  if (action === 'rollback') {
//   const prev = await db.query(
//     `SELECT balance_after, transaction_id, rollback_transactions
//        FROM gis_transactions
//       WHERE action = 'rollback'
//         AND rollback_transactions::text = $1
//       LIMIT 1`,
//     [JSON.stringify(rollback_transactions)]
//   );
//   if (prev.rowCount) {
//     // Return the exact same response as the initial rollback
//     return ok(res, {
//       balance: b4(prev.rows[0].balance_after),
//       transaction_id: prev.rows[0].transaction_id,
//       rollback_transactions: prev.rows[0].rollback_transactions.map(t => t.transaction_id)
//     });
//   }
// }


//   /* ------------------------------------------------------------------ */
//   /* 4) fetch current balance                                            */
//   /* ------------------------------------------------------------------ */
//   const col  = (EXT2INT[currency] ?? currency).toLowerCase();
//   const last = await db.query(
//     `SELECT balance_after
//        FROM gis_transactions
//       WHERE user_id = $1
//    ORDER BY id DESC
//       LIMIT 1`,
//     [player_id]
//   );
// if (!last.rowCount) {
//   const credits = await db.query(
//   `SELECT ${col}
//      FROM credits
//     WHERE uid = $1`,
//   [player_id]
// );
//   if (!credits.rowCount) {
//     return gisFail(res, 'INTERNAL_ERROR', 'Player not found');
//   }
// }
//   let bal = last.rowCount
//             ? Big(last.rows[0].balance_after)
//             : Big(
//                 (await db.query(
//                   `SELECT ${col}
//                      FROM credits
//                     WHERE uid = $1`,
//                   [player_id]
//                 )).rows[0][col]
//               );

//   /* --- probe for balance, provider tests this strictly -------------- */
//   if (action === 'balance' &&
//       has(req,'amount') &&
//       Big(amount).gt(0) &&
//       bal.lt(Big(amount)))
//     return gisFail(res, 'INSUFFICIENT_FUNDS',
//                    'Not enough money to continue playing');

//   /* zero is allowed, negative is not                                   */
//   if (needAmt && amt.lt(0))
//     return gisFail(res, 'INTERNAL_ERROR', 'amount must be non-negative');

//   /* ------------------------------------------------------------------ */
//   /* 5) business rules – compute balance delta                          */
//   /* ------------------------------------------------------------------ */
//   let change = ZERO;

//   switch (action) {
//     case 'bet':
//       if (bal.lt(amt))
//         return gisFail(res, 'INSUFFICIENT_FUNDS',
//                        'Not enough money to continue playing');
//       change = amt.neg();
//       break;

//     case 'win':
//       change = amt;
//       break;

//     case 'refund': {
//       /* refund is only for BETs – round_id may be missing */
//       const bet = await db.query(
//         'SELECT action FROM gis_transactions WHERE transaction_id = $1',
//         [bet_transaction_id]
//       );
//       if (bet.rowCount && bet.rows[0].action === 'bet')
//         change = amt;
//       break;                     // refund of win/free-spin leaves balance
//     }

//      case 'rollback':
//   /* DEBUG: Log the rollback transactions */
//   console.log('Rollback transactions:', JSON.stringify(rollback_transactions, null, 2));
  
//   /* cancel multiple prior tx in one go --------------------------- */
//   for (const tx of rollback_transactions) {
//     const a = Big(tx.amount || 0);
    
//     // Only process transactions with positive amounts
//     if (a.lte(0)) continue;
    
//     // Simply reverse the transaction based on action type
//     switch (tx.action) {
//       case 'bet':
//         change = change.plus(a);  // refund the bet
//         break;
//       case 'win':
//         change = change.minus(a); // remove the win
//         break;
//       case 'refund':
//         change = change.minus(a); // remove the refund
//         break;
//     }
//   }
//   break;
//     case 'balance':                     /* just a probe */              break;

//     default:
//       return gisFail(res, 'INTERNAL_ERROR', 'Invalid action');
//   }

//   /* ------------------------------------------------------------------ */
//   /* 6) persist new balance (if it changed)                             */
//   /* ------------------------------------------------------------------ */
//   if (!change.eq(0)) {
//     bal = bal.plus(change);
//     await setBal(player_id, col, bal.toString());   // high precision
//   }

//   /* ------------------------------------------------------------------ */
//   /* 7) store transaction (for idempotency & audit)                     */
//   /* ------------------------------------------------------------------ */
//   const txId = transaction_id || uuid();            // always unique
 
//   await logTx(
//     { ...req.body,
//       user_id       : player_id,
//       transaction_id: txId,
//       amount        : amt,
//       rollback_transactions},
//     bal
//   );

//   /* ------------------------------------------------------------------ */
//   /* 8) build response – formats differ slightly per action             */
//   /* ------------------------------------------------------------------ */
//   /* pure balance probe ⇒ NO transaction_id --------------------------- */
//   if (action === 'balance')
//     return ok(res, { balance: b4(bal) });

//   /* rollback expects list of tx-ids                                    */
//   if (action === 'rollback')
//     return ok(res, {
//       balance             : b4(bal),
//       transaction_id      : txId,
//       rollback_transactions: rollback_transactions.map(t => t.transaction_id)
//     });

//   /* bet | win | refund ------------------------------------------------ */
//   return ok(res, { balance: b4(bal), transaction_id: txId });
// }


/* ---------- GET /limits & /limits/freespin --------------------------- */
async getLimits(_q,res){ try{
  const hdr = baseHdr(); hdr['X-Sign']=sign({},hdr);
  log('GET /limits');
  const r = await axios.get(`${BASE}/limits`,{ headers:hdr });
  ok(res,r.data);
}catch(e){axiosErr(res,e);}},

async getFreespinLimits(_q,res){ try{
  const hdr = baseHdr(); hdr['X-Sign']=sign({},hdr);
  log('GET /limits/freespin');
  const r = await axios.get(`${BASE}/limits/freespin`,{ headers:hdr });
  ok(res,r.data);
}catch(e){axiosErr(res,e);}},

/* ---------- GET /jackpots ------------------------------------------- */
async getJackpots(_q,res){
  if(cacheJackpots.has('j')) return ok(res,cacheJackpots.get('j'));
  try{
    const hdr=baseHdr(); hdr['X-Sign']=sign({},hdr);
    log('GET /jackpots');
    const r=await axios.get(`${BASE}/jackpots`,{ headers:hdr });
    cacheJackpots.set('j',r.data); ok(res,r.data);
  }catch(e){ axiosErr(res,e); }
},

/* ---------- GET /freespins/bets ------------------------------------- */
async getFreespinBets(req,res){
  const { game_uuid, currency } = req.query;
  if(!game_uuid || !['USDT','INR'].includes(currency))
    return fail(res,400,'Invalid params');

  try{
    const hdr = baseHdr();
    const prm = { game_uuid, currency };
    hdr['X-Sign'] = sign(prm,hdr);
    log('GET /freespins/bets', prm);

    const r = await axios.get(`${BASE}/freespins/bets`,{ headers:hdr, params:prm });
    ok(res,r.data);
  }catch(e){ axiosErr(res,e); }
},

/* ---------- POST /freespins/set ------------------------------------- */
async setFreespin(req,res){
  const b=req.body;
  const miss=['player_id','player_name','currency','quantity','valid_from',
              'valid_until','freespin_id','game_uuid']
              .filter(f=>!has(b,f));
  if(miss.length) return fail(res,422,`Missing: ${miss.join(',')}`);
  if(!['USDT','INR'].includes(b.currency)) return fail(res,400,'currency must be USDT/INR');
  if(!( (b.bet_id && b.denomination) || b.total_bet_id))
    return fail(res,422,'Provide (bet_id+denomination) or total_bet_id');

  try{
    const u=await db.query('SELECT id FROM users WHERE id=$1',[b.player_id]);
    if(!u.rowCount) return fail(res,404,'User not found');

    await db.query(`
      INSERT INTO gis_freespins(
        user_id,freespin_id,game_uuid,currency,quantity,quantity_left,
        valid_from,valid_until,bet_id,total_bet_id,denomination,status)
      VALUES($1,$2,$3,$4,$5,$5,to_timestamp($6),to_timestamp($7),
             $8,$9,$10,'active')
      ON CONFLICT (freespin_id) DO NOTHING`,
      [b.player_id,b.freespin_id,b.game_uuid,b.currency,b.quantity,
       b.valid_from,b.valid_until,b.bet_id,b.total_bet_id,b.denomination]);

    const hdr={ ...baseHdr(),'Content-Type':'application/x-www-form-urlencoded'};
    hdr['X-Sign']=sign(b,hdr);
    log('POST /freespins/set', b);
    await axios.post(`${BASE}/freespins/set`, new URLSearchParams(b), { headers:hdr });

    created(res,{ message:'Freespin campaign set' });
  }catch(e){ axiosErr(res,e); }
},

/* ---------- GET /freespins/get -------------------------------------- */
async getFreespin(req,res){
  const { freespin_id } = req.query;
  if(!freespin_id) return fail(res,400,'freespin_id required');

  try{
    const loc=await db.query('SELECT * FROM gis_freespins WHERE freespin_id=$1',[freespin_id]);
    if(loc.rowCount) return ok(res,loc.rows[0]);

    const hdr=baseHdr(), prm={ freespin_id }; hdr['X-Sign']=sign(prm,hdr);
    log('GET /freespins/get', prm);
    const r=await axios.get(`${BASE}/freespins/get`,{ headers:hdr, params:prm });
    ok(res,r.data);
  }catch(e){ axiosErr(res,e); }
},

/* ---------- POST /freespins/cancel ---------------------------------- */
async cancelFreespin(req,res){
  const { freespin_id }=req.body;
  if(!freespin_id) return fail(res,400,'freespin_id required');

  try{
    await db.query(`UPDATE gis_freespins SET status='canceled',is_canceled=1
                    WHERE freespin_id=$1`,[freespin_id]);
    const hdr={ ...baseHdr(),'Content-Type':'application/x-www-form-urlencoded'};
    hdr['X-Sign']=sign({ freespin_id },hdr);
    log('POST /freespins/cancel', { freespin_id });
    await axios.post(`${BASE}/freespins/cancel`,
                     new URLSearchParams({ freespin_id }),{ headers:hdr });
    ok(res,{ message:'Campaign canceled' });
  }catch(e){ axiosErr(res,e); }
},

/* ---------- POST /freevouchers/set ---------------------------------- */
async setFreevoucher(req,res){
  const b=req.body;
  const need=['player_id','title','currency','initial_balance','max_winnings',
              'valid_until','voucher_id','table_ids'];
  const miss=need.filter(f=>!has(b,f));
  if(miss.length) return fail(res,422,`Missing: ${miss.join(',')}`);
  if(!Array.isArray(b.table_ids)||!b.table_ids.length)
    return fail(res,422,'table_ids must be array w/ at least 1 id');
  if(!['USDT','INR'].includes(b.currency)) return fail(res,400,'currency must be USDT/INR');

  try{
    const u=await db.query('SELECT id FROM users WHERE id=$1',[b.player_id]);
    if(!u.rowCount) return fail(res,404,'User not found');

    await db.query(`
      INSERT INTO gis_freevouchers(
        user_id,voucher_id,title,currency,initial_balance,max_winnings,
        valid_until,table_ids,short_terms,terms_and_conds,state,playable)
      VALUES($1,$2,$3,$4,$5,$6,to_timestamp($7),
             $8,$9,$10,'Active',$5)
      ON CONFLICT (voucher_id) DO NOTHING`,
      [b.player_id,b.voucher_id,b.title,b.currency,b.initial_balance,
       b.max_winnings,b.valid_until,b.table_ids,b.short_terms,b.terms_and_conds]);

    const hdr={ ...baseHdr(),'Content-Type':'application/x-www-form-urlencoded'};
    hdr['X-Sign']=sign(b,hdr);
    log('POST /freevouchers/set', b);
    await axios.post(`${BASE}/freevouchers/set`, new URLSearchParams(b), { headers:hdr });

    created(res,{ message:'Freevoucher campaign set' });
  }catch(e){ axiosErr(res,e); }
},

/* ---------- GET /freevouchers/get ----------------------------------- */
async getFreevoucher(req,res){
  const { voucher_id }=req.query;
  if(!voucher_id) return fail(res,400,'voucher_id required');

  try{
    const loc=await db.query('SELECT * FROM gis_freevouchers WHERE voucher_id=$1',[voucher_id]);
    if(loc.rowCount) return ok(res,loc.rows[0]);

    const hdr=baseHdr(), prm={ voucher_id }; hdr['X-Sign']=sign(prm,hdr);
    log('GET /freevouchers/get', prm);
    const r=await axios.get(`${BASE}/freevouchers/get`,{ headers:hdr, params:prm });
    ok(res,r.data);
  }catch(e){ axiosErr(res,e); }
},

/* ---------- POST /freevouchers/cancel ------------------------------- */
async cancelFreevoucher(req,res){
  const { voucher_id, reason }=req.body;
  if(!voucher_id||!['Canceled','Forfeited'].includes(reason))
    return fail(res,400,'voucher_id and valid reason required');

  try{
    await db.query(`UPDATE gis_freevouchers SET state=$1 WHERE voucher_id=$2`,
                   [reason,voucher_id]);
    const hdr={ ...baseHdr(),'Content-Type':'application/x-www-form-urlencoded'};
    const prm={ voucher_id,reason }; hdr['X-Sign']=sign(prm,hdr);
    log('POST /freevouchers/cancel', prm);
    await axios.post(`${BASE}/freevouchers/cancel`,
                     new URLSearchParams(prm),{ headers:hdr });
    ok(res,{ message:'Voucher canceled' });
  }catch(e){ axiosErr(res,e); }
},

/* ---------- POST /self-validate ------------------------------------- */
async selfValidate(_req,res){
  try{
    const hdr={ ...baseHdr(),'Content-Type':'application/x-www-form-urlencoded'};
    hdr['X-Sign']=sign({},hdr);
    log('POST /self-validate');
    const r=await axios.post(`${BASE}/self-validate`,{}, { headers:hdr });
    ok(res,r.data);
  }catch(e){ axiosErr(res,e); }
},

/* ═══════════════════════════════
   Local helper endpoints (DB)
   ═══════════════════════════════ */

/* ---------- GET /sync – refresh gis_games table --------------------- */
async syncGames(_q,res){
  try{
    log('syncGames – start');
    await db.query('TRUNCATE TABLE gis_games RESTART IDENTITY');
    let page=1,total=0,skipped=[];
    for(;;){
      const hdr=baseHdr();
      const prm={ expand:'', per_page:50, page };
      hdr['X-Sign']=sign(prm,hdr);
      if(BASE.includes('staging')) await sleep(1000);
      const r=await axios.get(`${BASE}/games/index`,{ headers:hdr, params:prm });
      const games=r.data.items||r.data;

      for(const g of games){
        const up=parseInt(g.updated_at);
        if(Number.isNaN(up)){ skipped.push(g.uuid); continue; }

        await db.query(`
          INSERT INTO gis_games(
            uuid,name,provider,type,image,technology,has_lobby,is_mobile,
            has_freespins,freespin_valid_until_full_day,
            updated_at,api_sub_provider_id,updated_at_timestamp)
          VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,to_timestamp($11))
          ON CONFLICT (uuid) DO UPDATE SET
            name=EXCLUDED.name,provider=EXCLUDED.provider,type=EXCLUDED.type,
            image=EXCLUDED.image,technology=EXCLUDED.technology,
            has_lobby=EXCLUDED.has_lobby,is_mobile=EXCLUDED.is_mobile,
            has_freespins=EXCLUDED.has_freespins,
            freespin_valid_until_full_day=EXCLUDED.freespin_valid_until_full_day,
            updated_at=EXCLUDED.updated_at,
            api_sub_provider_id=EXCLUDED.api_sub_provider_id,
            updated_at_timestamp=EXCLUDED.updated_at_timestamp`,
          [g.uuid,g.name,g.provider,g.type,g.image,g.technology,
           g.has_lobby===1,g.is_mobile===1,g.has_freespins===1,
           g.freespin_valid_until_full_day===1,up,
           g.api_sub_provider_id?parseInt(g.api_sub_provider_id):null]);
        total++;
      }
      if(page >= (r.data._meta?.pageCount||1)) break;
      page++;
    }
    ok(res,{ message:`Synced ${total} games`, skipped });
  }catch(e){ axiosErr(res,e); }
},

/* ---------- GET /providersgis -------------------------------------- */
async getProvidersgis(req,res){
  const search=(req.query.search||'').trim().toLowerCase();
  try{
    const rows = search ?
      (await db.query('SELECT * FROM gis_providers WHERE LOWER(name) LIKE $1 ORDER BY name',
                      [`%${search}%`])).rows :
      (await db.query('SELECT * FROM gis_providers ORDER BY name')).rows;

    ok(res,{ success:true, data:rows, total:rows.length });
  }catch(e){ axiosErr(res,e); }
},

/* ---------- GET /gamesgis (+ filters) ------------------------------- */
async getGamesgis(req, res) {
  const page  = Math.max(1, +req.query.page  || 1);
  const limit = Math.min(+req.query.limit || 10, 100);

  const f = {
    provider      : req.query.provider,
    type          : req.query.type,
    search        : req.query.search,
    technology    : req.query.technology,
    has_lobby     : req.query.has_lobby === 'true' ? true : req.query.has_lobby === 'false' ? false : null,
    is_mobile     : req.query.is_mobile === 'true' ? true : req.query.is_mobile === 'false' ? false : null,
    has_freespins : req.query.has_freespins === 'true' ? true : req.query.has_freespins === 'false' ? false : null,
  };

  // Build WHERE (always qualify with alias g.)
  const where = [];
  const params = [];
  const add = (sql, val) => {
    params.push(val);
    where.push(sql.replace('?', `$${params.length}`));
  };

  if (f.provider)     add('LOWER(g.provider) = LOWER(?)', f.provider);
  if (f.type)         add('LOWER(g.type) = LOWER(?)', f.type);
  if (f.search)       add('LOWER(g.name) LIKE LOWER(?)', `%${f.search}%`);
  if (f.technology)   add('LOWER(g.technology) = LOWER(?)', f.technology);
  if (f.has_lobby !== null)     add('g.has_lobby = ?', f.has_lobby);
  if (f.has_freespins !== null) add('g.has_freespins = ?', f.has_freespins);

  const whereSQL = where.length ? `WHERE ${where.join(' AND ')}` : '';

  // is_mobile becomes a sort priority, not a filter:
  //   true  -> mobile games first, then non-mobile
  //   false -> non-mobile games first, then mobile
  const mobileOrderSQL =
    f.is_mobile === true  ? 'g.is_mobile DESC,' :
    f.is_mobile === false ? 'g.is_mobile ASC,'  : '';

  try {
    // 1) total count with filters (use gisgamesnew)
    const totalRes = await db.query(`SELECT COUNT(*)::int AS c FROM gisgamesnew g ${whereSQL}`, params);
    const total = totalRes.rows[0]?.c || 0;

    // 2) fetch prioritized UUIDs (only for page 1)
    //    - if `type` filter is set → gis_prioritized_types takes precedence
    //    - else if `provider` filter is set → gis_prioritized_games (existing behavior)
    let prioritized = [];

    if (f.type && page === 1) {
      try {
        const rt = await db.query(
          `SELECT game_ids FROM gis_prioritized_types
            WHERE LOWER(TRIM(type)) = LOWER(TRIM($1))
            ORDER BY updated_at DESC
            LIMIT 1`,
          [f.type]
        );
        if (rt.rows[0]?.game_ids) {
          prioritized = rt.rows[0].game_ids
            .split(',')
            .map(s => s.trim())
            .filter(Boolean);
        }
      } catch (_) { /* table may not exist - ignore */ }
    }

    if (!prioritized.length && f.provider && page === 1) {
      // Primary: gis_prioritized_games (vendor -> CSV of game_ids)
      try {
        const r0 = await db.query(
          `SELECT game_ids FROM gis_prioritized_games
            WHERE LOWER(vendor) = LOWER($1)
            ORDER BY updated_at DESC
            LIMIT 1`,
          [f.provider]
        );
        if (r0.rows[0]?.game_ids) {
          prioritized = r0.rows[0].game_ids
            .split(',')
            .map(s => s.trim())
            .filter(Boolean);
        }
      } catch (_) { /* table may not exist - ignore */ }

      // Fallback: normalized schema
      if (!prioritized.length) {
        try {
          const r1 = await db.query(
            `SELECT i.uuid
               FROM prioritized_gis_game_items i
               JOIN prioritized_gis_games p ON p.id = i.prioritized_id
              WHERE p.provider = $1
              ORDER BY i.position ASC`,
            [f.provider]
          );
          prioritized = r1.rows.map(r => r.uuid);
        } catch (_) { /* table may not exist - ignore */ }
      }

      // Fallback: CSV table schema
      if (!prioritized.length) {
        try {
          const r2 = await db.query(
            `SELECT game_uuids FROM prioritized_gis WHERE provider = $1 LIMIT 1`,
            [f.provider]
          );
          if (r2.rows[0]?.game_uuids) {
            prioritized = r2.rows[0].game_uuids
              .split(',')
              .map(s => s.trim())
              .filter(Boolean);
          }
        } catch (_) { /* table may not exist - ignore */ }
      }
    }

    // 3) data query with proper ORDER BY (use gisgamesnew)
    const dataParams = [...params];
    let dataSQL;

    if (page === 1 && prioritized.length) {
      // prioritized page (page 1)
      dataParams.push(prioritized);
      const arrIdx = dataParams.length;

      dataParams.push(limit, (page - 1) * limit);
      const limitIdx  = dataParams.length - 1;
      const offsetIdx = dataParams.length;

      dataSQL = `
        WITH pri(uuid, pos) AS (
          SELECT * FROM unnest($${arrIdx}::text[]) WITH ORDINALITY
        )
        SELECT
          g.uuid,
          g.name,
          g.provider,
          g.type,
          g.image,
          g.technology,
          g.has_lobby,
          g.is_mobile,
          g.has_freespins,
          g.freespin_valid_until_full_day,
          g.updated_at,
          g.label,
          g.parameters,
          g.tags,
          g.images,
          g.created_at,
          g.updated_at,
          g.provider_id AS api_sub_provider_id
        FROM gisgamesnew g
        LEFT JOIN pri ON g.uuid::text = pri.uuid
        ${whereSQL}
        ORDER BY
          ${mobileOrderSQL}
          (pri.pos IS NULL),
          pri.pos,
          g.name ASC
        LIMIT $${limitIdx} OFFSET $${offsetIdx}
      `;
    } else {
      // normal pages
      dataParams.push(limit, (page - 1) * limit);
      const limitIdx  = dataParams.length - 1;
      const offsetIdx = dataParams.length;

      dataSQL = `
        SELECT
          g.uuid,
          g.name,
          g.provider,
          g.type,
          g.image,
          g.technology,
          g.has_lobby,
          g.is_mobile,
          g.has_freespins,
          g.freespin_valid_until_full_day,
          g.updated_at,
          g.label,
          g.parameters,
          g.tags,
          g.images,
          g.created_at,
          g.updated_at,
          g.provider_id AS api_sub_provider_id
        FROM gisgamesnew g
        ${whereSQL}
        ORDER BY ${mobileOrderSQL} g.name ASC
        LIMIT $${limitIdx} OFFSET $${offsetIdx}
      `;
    }

    const data = (await db.query(dataSQL, dataParams)).rows;

    ok(res, {
      success: true,
      data,
      pagination: {
        currentPage: page,
        totalPages : Math.ceil(total / limit),
        totalItems : total,
        itemsPerPage: limit
      },
      filters: f,
      prioritizedApplied: page === 1 && Boolean(prioritized.length)
    });
  } catch (e) {
    axiosErr(res, e);
  }
}
,

// async  getGamesgis(req, res) {
//   const page  = Math.max(1, +req.query.page  || 1);
//   const limit = Math.min(+req.query.limit || 10, 100);

//   const f = {
//     provider      : req.query.provider,
//     type          : req.query.type,
//     search        : req.query.search,
//     technology    : req.query.technology,
//     has_lobby     : req.query.has_lobby === 'true' ? true : req.query.has_lobby === 'false' ? false : null,
//     is_mobile     : req.query.is_mobile === 'true' ? true : req.query.is_mobile === 'false' ? false : null,
//     has_freespins : req.query.has_freespins === 'true' ? true : req.query.has_freespins === 'false' ? false : null,
//   };

//   // Build WHERE (always qualify with alias g.)
//   const where = [];
//   const params = [];
//   const add = (sql, val) => {
//     params.push(val);
//     where.push(sql.replace('?', `$${params.length}`));
//   };

//   if (f.provider)     add('LOWER(g.provider) = LOWER(?)', f.provider);
//   if (f.type)         add('LOWER(g.type) = LOWER(?)', f.type);
//   if (f.search)       add('LOWER(g.name) LIKE LOWER(?)', `%${f.search}%`);
//   if (f.technology)   add('LOWER(g.technology) = LOWER(?)', f.technology);
//   if (f.has_lobby !== null)     add('g.has_lobby = ?', f.has_lobby);
//   if (f.is_mobile !== null)     add('g.is_mobile = ?', f.is_mobile);
//   if (f.has_freespins !== null) add('g.has_freespins = ?', f.has_freespins);

//   const whereSQL = where.length ? `WHERE ${where.join(' AND ')}` : '';

//   try {
//     // 1) total count with filters
//     const totalRes = await db.query(`SELECT COUNT(*)::int AS c FROM gis_games g ${whereSQL}`, params);
//     const total = totalRes.rows[0]?.c || 0;

//     // 2) fetch prioritized UUIDs (only for page 1 and when provider set)
//     let prioritized = [];
//     if (f.provider && page === 1) {
//       // Try normalized schema
//       try {
//         const r1 = await db.query(
//           `SELECT i.uuid
//              FROM prioritized_gis_game_items i
//              JOIN prioritized_gis_games p ON p.id = i.prioritized_id
//             WHERE p.provider = $1
//             ORDER BY i.position ASC`,
//           [f.provider]
//         );
//         prioritized = r1.rows.map(r => r.uuid);
//       } catch (_) { /* table may not exist - ignore */ }

//       // Fallback: CSV table schema
//       if (!prioritized.length) {
//         try {
//           const r2 = await db.query(
//             `SELECT game_uuids FROM prioritized_gis WHERE provider = $1 LIMIT 1`,
//             [f.provider]
//           );
//           if (r2.rows[0]?.game_uuids) {
//             prioritized = r2.rows[0].game_uuids
//               .split(',')
//               .map(s => s.trim())
//               .filter(Boolean);
//           }
//         } catch (_) { /* table may not exist - ignore */ }
//       }
//     }

//     // 3) data query with proper ORDER BY
//     const dataParams = [...params];
//     let dataSQL;

//     if (page === 1 && prioritized.length) {
//       // prioritized page (page 1)
//       dataParams.push(prioritized);
//       const arrIdx = dataParams.length;

//       dataParams.push(limit, (page - 1) * limit);
//       const limitIdx  = dataParams.length - 1;
//       const offsetIdx = dataParams.length;

//       dataSQL = `
//         WITH pri(uuid, pos) AS (
//           SELECT * FROM unnest($${arrIdx}::text[]) WITH ORDINALITY
//         )
//         SELECT g.uuid, g.name, g.provider, g.type, g.image, g.technology, g.has_lobby, g.is_mobile,
//                g.has_freespins, g.freespin_valid_until_full_day, g.api_sub_provider_id,
//                g.created_at, g.updated_at
//           FROM gis_games g
//           LEFT JOIN pri ON g.uuid::text = pri.uuid
//           ${whereSQL}
//          ORDER BY
//            (pri.pos IS NULL),  -- prioritized first
//            pri.pos,            -- keep priority order
//            g.name ASC
//          LIMIT $${limitIdx} OFFSET $${offsetIdx}
//       `;
//     } else {
//       // normal pages
//       dataParams.push(limit, (page - 1) * limit);
//       const limitIdx  = dataParams.length - 1;
//       const offsetIdx = dataParams.length;

//       dataSQL = `
//         SELECT g.uuid, g.name, g.provider, g.type, g.image, g.technology, g.has_lobby, g.is_mobile,
//                g.has_freespins, g.freespin_valid_until_full_day, g.api_sub_provider_id,
//                g.created_at, g.updated_at
//           FROM gis_games g
//           ${whereSQL}
//          ORDER BY g.name ASC
//          LIMIT $${limitIdx} OFFSET $${offsetIdx}
//       `;
//     }

//     const data = (await db.query(dataSQL, dataParams)).rows;

//     ok(res, {
//       success: true,
//       data,
//       pagination: {
//         currentPage: page,
//         totalPages : Math.ceil(total / limit),
//         totalItems : total,
//         itemsPerPage: limit
//       },
//       filters: f,
//       prioritizedApplied: page === 1 && Boolean(prioritized.length)
//     });
//   } catch (e) {
//     axiosErr(res, e);
//   }
// },
async  getGamesByProvidergis(req, res) {
  req.query.provider = req.params.provider;
  return getGamesgis(req, res);
}
,



/* ---------- GET /gamesgis/stats ------------------------------------- */
async getGameStats(_q,res){
  try{
    const stats = (await db.query(`
      SELECT COUNT(*) AS total_games,
             COUNT(DISTINCT provider) AS total_providers,
             COUNT(DISTINCT type)     AS total_types,
             COUNT(*) FILTER (WHERE has_lobby)        AS games_with_lobby,
             COUNT(*) FILTER (WHERE is_mobile)        AS mobile_games,
             COUNT(*) FILTER (WHERE has_freespins)    AS games_with_freespins
      FROM gis_games`)).rows[0];

    const topProviders = (await db.query(`
      SELECT provider,COUNT(*) AS game_count
      FROM gis_games
      GROUP BY provider
      ORDER BY game_count DESC LIMIT 10`)).rows;

    const gameTypes = (await db.query(`
      SELECT type,COUNT(*) AS game_count
      FROM gis_games
      GROUP BY type
      ORDER BY game_count DESC`)).rows;

    ok(res,{ success:true, stats, topProviders, gameTypes });
  }catch(e){ axiosErr(res,e); }
},

/* ---------- GET /games/provider?provider=X -------------------------- */
async getGamesByProvider(req,res){
  const { provider, page=1, per_page=50 } = req.query;
  if(!provider) return fail(res,400,'provider query-param required');

  const key=`prov_${provider}_${page}_${per_page}`;
  if(cacheGames.has(key)) return ok(res, cacheGames.get(key));

  try{
    const hdr=baseHdr();
    const prm={ expand:'tags,parameters,images,related_games', page, per_page };
    hdr['X-Sign']=sign(prm,hdr);
    log('GET /games/provider', prm);

    const r=await axios.get(`${BASE}/games/index`,{ headers:hdr, params:prm });
    const items=(r.data.items||r.data)
                 .filter(g => g.provider.toLowerCase()===provider.toLowerCase());

    if(!items.length) return fail(res,404,`No games for provider ${provider}`);

    const out={ items, _pagination:pag(r.headers) };
    cacheGames.set(key,out);
    ok(res,out);
  }catch(e){ axiosErr(res,e); }
},
/* ---------- GET /providers ----------------------------------------- */
/* ---------- GET /providers ----------------------------------------- */
async getProviders(_req, res) {
  if (cacheProviders.has('list')) return ok(res, { providers: cacheProviders.get('list') });
  try {
    const per_page = 50;
    let page = 1;
    const names = new Set();

    while (true) {
      const hdr = baseHdr();
      const prm = { expand: '', per_page, page }; // sign exactly same params as sent
      hdr['X-Sign'] = sign(prm, hdr);

      // Respect rate limits
      if (!BASE.includes('staging')) await sleep(1100);

      let r;
      try {
        r = await axios.get(`${BASE}/games/index`, { headers: hdr, params: prm, timeout: 15000 });
      } catch (axErr) {
        console.error('getProviders upstream error', { page, status: axErr.response?.status, data: axErr.response?.data });
        throw axErr;
      }

      const data = r.data || {};
      let items = [];
      if (Array.isArray(data)) items = data;
      else if (Array.isArray(data.items)) items = data.items;
      else if (Array.isArray(data.data)) items = data.data;
      else if (typeof data === 'object') {
        items = Object.values(data).filter(v => v && typeof v === 'object' && (v.provider || v.name || v.uuid));
      }

      for (const g of items) {
        if (!g) continue;
        const p = (g.provider ?? g.label ?? '').toString().trim();
        if (p) names.add(p);
      }

      const pageCount = Number(data._meta?.pageCount) || Number(r.headers['x-pagination-page-count']);
      if (pageCount) {
        if (page >= pageCount) break;
      } else {
        if (items.length < per_page) break;
      }

      page++;
    }

    const list = [...names].filter(Boolean).sort();
    cacheProviders.set('list', list);
    ok(res, { providers: list });
  } catch (e) {
    axiosErr(res, e);
  }
},

/* ---------- GET /providers ----------------------------------------- */
// async getProviders(_req,res){
//   if(cacheProviders.has('list')) return ok(res,{ providers:cacheProviders.get('list') });
//   try{
//     let page=1, more=true, names=new Set();
//     while(more){
//       const hdr=baseHdr();
//       const prm={ expand:'', per_page:50, page };
//       hdr['X-Sign']=sign(prm,hdr);
//       const r=await axios.get(`${BASE}/games/index`,{ headers:hdr, params:prm });
//       (r.data.items||r.data).forEach(g=>g.provider && names.add(g.provider));
//       more = page < (r.data._meta?.pageCount || 1);
//       page++;
//       if(BASE.includes('staging')) await sleep(500);
//     }
//     const list=[...names].sort();
//     cacheProviders.set('list',list);
//     ok(res,{ providers:list });
//   }catch(e){ axiosErr(res,e); }
// },
async  setHotGames(req, res) {
  try {
    let { uuids, uuidsCSV } = req.body || {};

    // Accept either CSV string or array
    if (!uuids && typeof uuidsCSV === 'string') {
      uuids = uuidsCSV.split(',').map(s => s.trim()).filter(Boolean);
    }
    if (!Array.isArray(uuids)) {
      return res.status(400).json({ success: false, error: 'Provide uuids[] array or uuidsCSV string' });
    }

    // Deduplicate while preserving order
    const seen = new Set();
    const clean = [];
    for (const x of uuids) {
      const s = String(x || '').trim();
      if (s && !seen.has(s)) { seen.add(s); clean.push(s); }
    }

    const csv = clean.join(',');

    await db.query(
      `INSERT INTO hot_games(key, game_uuids)
       VALUES ('hotgames', $1)
       ON CONFLICT (key) DO UPDATE
       SET game_uuids = EXCLUDED.game_uuids, updated_at = now()`,
      [csv || null]
    );

    ok(res, { success: true, count: clean.length, uuids: clean });
  } catch (e) {
    axiosErr(res, e);
  }
}
,
// GET /api/gis/hotgames?page=&limit=
async getHotGames(req, res) {
  try {
    const page  = Math.max(1, +req.query.page  || 1);
    // Public default 20; admin can fetch the full curated list at once via ?limit=5000.
    const limit = Math.min(+req.query.limit || 20, 5000);
    const offset = (page - 1) * limit;

    // 1) Read CSV of UUIDs from hot_games
    const cfg = await db.query(
      `SELECT game_uuids FROM hot_games WHERE key = 'hotgames' LIMIT 1`
    );

    const csv = cfg.rows[0]?.game_uuids;
    if (!csv || !csv.trim()) {
      return ok(res, {
        success: true,
        data: [],
        pagination: {
          currentPage: page,
          totalPages: 0,
          totalItems: 0,
          itemsPerPage: limit
        }
      });
    }

    // 2) COUNT how many UUIDs actually exist in gisgamesnew
    const countSQL = `
      WITH hot AS (
        SELECT trim(val) AS uuid
        FROM regexp_split_to_table($1, ',') AS val
        WHERE trim(val) <> ''
      )
      SELECT COUNT(*)::int AS c
      FROM hot h
      JOIN gisgamesnew g ON g.uuid::text = h.uuid
    `;
    const total = (await db.query(countSQL, [csv])).rows[0]?.c || 0;

    if (total === 0) {
      return ok(res, {
        success: true,
        data: [],
        pagination: {
          currentPage: page,
          totalPages: 0,
          totalItems: 0,
          itemsPerPage: limit
        }
      });
    }

    // 3) DATA: split CSV, keep order, join & SELECT * from gisgamesnew
    const dataSQL = `
      WITH hot AS (
        SELECT trim(val) AS uuid, ord
        FROM regexp_split_to_table($1, ',') WITH ORDINALITY AS t(val, ord)
        WHERE trim(val) <> ''
      )
      SELECT g.*
      FROM hot h
      JOIN gisgamesnew g ON g.uuid::text = h.uuid
      ORDER BY h.ord
      LIMIT $2 OFFSET $3
    `;

    const data = (await db.query(dataSQL, [csv, limit, offset])).rows;

    return ok(res, {
      success: true,
      data,
      pagination: {
        currentPage: page,
        totalPages : Math.ceil(total / limit),
        totalItems : total,
        itemsPerPage: limit
      }
    });
  } catch (e) {
    axiosErr(res, e);
  }
},

/* ───── Live Casino / Popular Slots / Crash Games ───────────────── */
async setLiveCasino(req, res)   { return _setCategory(req, res, 'live_casino',  'livecasino');   },
async getLiveCasino(req, res)   { return _getCategory(req, res, 'live_casino',  'livecasino');   },
async setPopularSlots(req, res) { return _setCategory(req, res, 'popular_slots','popularslots'); },
async getPopularSlots(req, res) { return _getCategory(req, res, 'popular_slots','popularslots'); },
async setCrashGames(req, res)   { return _setCategory(req, res, 'crash_games',  'crashgames');   },
async getCrashGames(req, res)   { return _getCategory(req, res, 'crash_games',  'crashgames');   },
async setIndianGames(req, res)  { return _setCategory(req, res, 'indian_games', 'indiangames');  },
async getIndianGames(req, res)  { return _getCategory(req, res, 'indian_games', 'indiangames');  },

/* ───── Search gisgamesnew by name or uuid (for admin picker) ───── */
async searchGames(req, res) {
  try {
    const q     = String(req.query.q || '').trim();
    const limit = Math.min(+req.query.limit || 30, 100);

    if (!q) {
      return ok(res, { success: true, data: [] });
    }

    // $1 = like pattern (used for both name and uuid match)
    // $2 = raw query (used for prefix-rank in ORDER BY)
    // $3 = limit (kept exclusive to LIMIT so Postgres infers bigint)
    const sql = `
      SELECT uuid, name, provider, image, type
        FROM gisgamesnew
       WHERE LOWER(name) LIKE LOWER($1)
          OR uuid::text ILIKE $1
       ORDER BY
         CASE WHEN LOWER(name) = LOWER($2)            THEN 0
              WHEN LOWER(name) LIKE LOWER($2 || '%')  THEN 1
              WHEN uuid::text  ILIKE $2 || '%'        THEN 2
              ELSE 3 END,
         name
       LIMIT $3
    `;
    const params = [`%${q}%`, q, limit];

    const { rows } = await db.query(sql, params);
    return ok(res, { success: true, data: rows });
  } catch (e) {
    return axiosErr(res, e);
  }
},

/* ───── Vendor priority (gis_prioritized_games) ─────────────────── */

// GET /api/gis/admin/gis/vendors
async getVendorList(_req, res) {
  try {
    const sql = `
      SELECT g.provider                         AS vendor,
             COUNT(*)::int                      AS total,
             (p.vendor IS NOT NULL)             AS has_priority,
             p.updated_at                       AS priority_updated_at
        FROM gisgamesnew g
   LEFT JOIN gis_prioritized_games p
          ON LOWER(p.vendor) = LOWER(g.provider)
       WHERE g.provider IS NOT NULL AND g.provider <> ''
    GROUP BY g.provider, p.vendor, p.updated_at
    ORDER BY g.provider
    `;
    const { rows } = await db.query(sql);
    return ok(res, { success: true, data: rows });
  } catch (e) {
    return axiosErr(res, e);
  }
},

// GET /api/gis/admin/gis/priority/:vendor
async getVendorPriority(req, res) {
  try {
    const vendor = String(req.params.vendor || '').trim();
    if (!vendor) {
      return res.status(400).json({ success: false, error: 'vendor is required' });
    }

    const cfg = await db.query(
      `SELECT vendor, game_ids, updated_at
         FROM gis_prioritized_games
        WHERE LOWER(vendor) = LOWER($1)
        ORDER BY updated_at DESC NULLS LAST
        LIMIT 1`,
      [vendor]
    );

    const csv = cfg.rows[0]?.game_ids;
    if (!csv || !csv.trim()) {
      return ok(res, { success: true, vendor, updated_at: null, data: [] });
    }

    const sql = `
      WITH list AS (
        SELECT trim(val) AS uuid, ord
          FROM regexp_split_to_table($1, ',') WITH ORDINALITY AS t(val, ord)
         WHERE trim(val) <> ''
      )
      SELECT g.uuid, g.name, g.provider, g.image, g.type, g.is_mobile, g.has_freespins
        FROM list l
        JOIN gisgamesnew g ON g.uuid::text = l.uuid
       ORDER BY l.ord
    `;
    const { rows } = await db.query(sql, [csv]);
    return ok(res, {
      success: true,
      vendor: cfg.rows[0].vendor,
      updated_at: cfg.rows[0].updated_at,
      data: rows
    });
  } catch (e) {
    return axiosErr(res, e);
  }
},

// POST /api/gis/admin/gis/priority/:vendor   body: { uuids: string[] }
async setVendorPriority(req, res) {
  try {
    const vendor = String(req.params.vendor || '').trim();
    if (!vendor) {
      return res.status(400).json({ success: false, error: 'vendor is required' });
    }

    let { uuids, uuidsCSV } = req.body || {};
    if (!uuids && typeof uuidsCSV === 'string') {
      uuids = uuidsCSV.split(',').map(s => s.trim()).filter(Boolean);
    }
    if (!Array.isArray(uuids)) {
      return res.status(400).json({ success: false, error: 'Provide uuids[] array' });
    }

    const seen = new Set();
    const clean = [];
    for (const x of uuids) {
      const s = String(x || '').trim();
      if (s && !seen.has(s)) { seen.add(s); clean.push(s); }
    }
    const csv = clean.join(',');

    // Manual upsert keyed on LOWER(vendor) — works whether or not a unique
    // constraint exists, and stays case-insensitive against existing data.
    await db.query('BEGIN');
    const upd = await db.query(
      `UPDATE gis_prioritized_games
          SET game_ids   = $1,
              updated_at = CURRENT_TIMESTAMP
        WHERE LOWER(vendor) = LOWER($2)`,
      [csv, vendor]
    );
    if (upd.rowCount === 0) {
      await db.query(
        `INSERT INTO gis_prioritized_games (vendor, game_ids)
              VALUES ($1, $2)`,
        [vendor, csv]
      );
    }
    await db.query('COMMIT');

    return ok(res, { success: true, vendor, count: clean.length, uuids: clean });
  } catch (e) {
    try { await db.query('ROLLBACK'); } catch (_) {}
    return axiosErr(res, e);
  }
},

/* ───── Type priority (gis_prioritized_types) ───────────────────── */

// GET /api/gis/admin/gis/types
async getTypeList(_req, res) {
  try {
    const sql = `
      SELECT TRIM(g.type)                       AS type,
             COUNT(*)::int                      AS total,
             BOOL_OR(p.type IS NOT NULL)        AS has_priority,
             MAX(p.updated_at)                  AS priority_updated_at
        FROM gisgamesnew g
   LEFT JOIN gis_prioritized_types p
          ON LOWER(TRIM(p.type)) = LOWER(TRIM(g.type))
       WHERE g.type IS NOT NULL AND TRIM(g.type) <> ''
    GROUP BY LOWER(TRIM(g.type)), TRIM(g.type)
    ORDER BY TRIM(g.type)
    `;
    const { rows } = await db.query(sql);
    return ok(res, { success: true, data: rows });
  } catch (e) {
    return axiosErr(res, e);
  }
},

// GET /api/gis/admin/gis/type-priority/:type
async getTypePriority(req, res) {
  try {
    const type = String(req.params.type || '').trim();
    if (!type) {
      return res.status(400).json({ success: false, error: 'type is required' });
    }

    const cfg = await db.query(
      `SELECT type, game_ids, updated_at
         FROM gis_prioritized_types
        WHERE LOWER(TRIM(type)) = LOWER(TRIM($1))
        ORDER BY updated_at DESC NULLS LAST
        LIMIT 1`,
      [type]
    );

    const csv = cfg.rows[0]?.game_ids;
    if (!csv || !csv.trim()) {
      return ok(res, { success: true, type, updated_at: null, data: [] });
    }

    const sql = `
      WITH list AS (
        SELECT trim(val) AS uuid, ord
          FROM regexp_split_to_table($1, ',') WITH ORDINALITY AS t(val, ord)
         WHERE trim(val) <> ''
      )
      SELECT g.uuid, g.name, g.provider, g.image, g.type, g.is_mobile, g.has_freespins
        FROM list l
        JOIN gisgamesnew g ON g.uuid::text = l.uuid
       ORDER BY l.ord
    `;
    const { rows } = await db.query(sql, [csv]);
    return ok(res, {
      success: true,
      type: cfg.rows[0].type,
      updated_at: cfg.rows[0].updated_at,
      data: rows
    });
  } catch (e) {
    return axiosErr(res, e);
  }
},

// POST /api/gis/admin/gis/type-priority/:type   body: { uuids: string[] }
async setTypePriority(req, res) {
  try {
    const type = String(req.params.type || '').trim();
    if (!type) {
      return res.status(400).json({ success: false, error: 'type is required' });
    }

    let { uuids, uuidsCSV } = req.body || {};
    if (!uuids && typeof uuidsCSV === 'string') {
      uuids = uuidsCSV.split(',').map(s => s.trim()).filter(Boolean);
    }
    if (!Array.isArray(uuids)) {
      return res.status(400).json({ success: false, error: 'Provide uuids[] array' });
    }

    const seen = new Set();
    const clean = [];
    for (const x of uuids) {
      const s = String(x || '').trim();
      if (s && !seen.has(s)) { seen.add(s); clean.push(s); }
    }
    const csv = clean.join(',');

    await db.query('BEGIN');
    const upd = await db.query(
      `UPDATE gis_prioritized_types
          SET game_ids   = $1,
              updated_at = CURRENT_TIMESTAMP
        WHERE LOWER(TRIM(type)) = LOWER(TRIM($2))`,
      [csv, type]
    );
    if (upd.rowCount === 0) {
      await db.query(
        `INSERT INTO gis_prioritized_types (type, game_ids)
              VALUES ($1, $2)`,
        [type, csv]
      );
    }
    await db.query('COMMIT');

    return ok(res, { success: true, type, count: clean.length, uuids: clean });
  } catch (e) {
    try { await db.query('ROLLBACK'); } catch (_) {}
    return axiosErr(res, e);
  }
},

// GET /api/gis/admin/gis/type-search?type=&q=&limit=
async searchTypeGames(req, res) {
  try {
    const type  = String(req.query.type || '').trim();
    const q     = String(req.query.q || '').trim();
    const limit = Math.min(+req.query.limit || 30, 100);

    if (!type) {
      return res.status(400).json({ success: false, error: 'type is required' });
    }
    if (!q) {
      return ok(res, { success: true, data: [] });
    }

    const sql = `
      SELECT uuid, name, provider, image, type
        FROM gisgamesnew
       WHERE LOWER(TRIM(type)) = LOWER(TRIM($1))
         AND (LOWER(name) LIKE LOWER($2) OR uuid::text ILIKE $2)
       ORDER BY
         CASE WHEN LOWER(name) = LOWER($3)            THEN 0
              WHEN LOWER(name) LIKE LOWER($3 || '%')  THEN 1
              WHEN uuid::text  ILIKE $3 || '%'        THEN 2
              ELSE 3 END,
         name
       LIMIT $4
    `;
    const { rows } = await db.query(sql, [type, `%${q}%`, q, limit]);
    return ok(res, { success: true, data: rows });
  } catch (e) {
    return axiosErr(res, e);
  }
},

// GET /api/gis/admin/gis/vendor-search?vendor=&q=&limit=
async searchVendorGames(req, res) {
  try {
    const vendor = String(req.query.vendor || '').trim();
    const q      = String(req.query.q || '').trim();
    const limit  = Math.min(+req.query.limit || 30, 100);

    if (!vendor) {
      return res.status(400).json({ success: false, error: 'vendor is required' });
    }
    if (!q) {
      return ok(res, { success: true, data: [] });
    }

    const sql = `
      SELECT uuid, name, provider, image, type
        FROM gisgamesnew
       WHERE LOWER(provider) = LOWER($1)
         AND (LOWER(name) LIKE LOWER($2) OR uuid::text ILIKE $2)
       ORDER BY
         CASE WHEN LOWER(name) = LOWER($3)            THEN 0
              WHEN LOWER(name) LIKE LOWER($3 || '%')  THEN 1
              WHEN uuid::text  ILIKE $3 || '%'        THEN 2
              ELSE 3 END,
         name
       LIMIT $4
    `;
    const { rows } = await db.query(sql, [vendor, `%${q}%`, q, limit]);
    return ok(res, { success: true, data: rows });
  } catch (e) {
    return axiosErr(res, e);
  }
},

/* ───── Update a single game's image in gisgamesnew ─────────────── */
async updateGameImage(req, res) {
  try {
    const { uuid } = req.params;
    const { image } = req.body || {};

    if (!uuid) {
      return res.status(400).json({ success: false, error: 'uuid is required' });
    }
    if (typeof image !== 'string' || !image.trim()) {
      return res.status(400).json({ success: false, error: 'image URL is required' });
    }

    const result = await db.query(
      `UPDATE gisgamesnew
         SET image = $1
       WHERE uuid::text = $2
       RETURNING uuid, name, image`,
      [image.trim(), String(uuid)]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ success: false, error: 'Game not found' });
    }

    return ok(res, { success: true, game: result.rows[0] });
  } catch (e) {
    return axiosErr(res, e);
  }
},

/* ---------- GET /games/recently-played ------------------------------ */
async getRecentlyPlayed (req, res) {
  const user_id = req.query.user_id;
  if (!user_id || Number.isNaN(Number(user_id))) {
    return fail(res, 422, 'user_id (number) is required');
  }

  try {
    const { rows } = await db.query(`
      SELECT r.game_uuid, r.played_at, g.*
        FROM gis_recently_played r
        LEFT JOIN gisgamesnew g ON g.uuid::text = r.game_uuid
       WHERE r.user_id = $1
       ORDER BY r.played_at DESC
       LIMIT 15
    `, [user_id]);

    return ok(res, { success: true, data: rows });
  } catch (e) {
    return axiosErr(res, e);
  }
}

}; // ───── end module.exports ─────

/* ───── shared helpers for category lists ───────────────────────── */
async function _setCategory(req, res, table, key) {
  try {
    let { uuids, uuidsCSV } = req.body || {};
    if (!uuids && typeof uuidsCSV === 'string') {
      uuids = uuidsCSV.split(',').map(s => s.trim()).filter(Boolean);
    }
    if (!Array.isArray(uuids)) {
      return res.status(400).json({ success: false, error: 'Provide uuids[] array or uuidsCSV string' });
    }

    const seen = new Set();
    const clean = [];
    for (const x of uuids) {
      const s = String(x || '').trim();
      if (s && !seen.has(s)) { seen.add(s); clean.push(s); }
    }

    const csv = clean.join(',');

    await db.query(
      `INSERT INTO ${table}(key, game_uuids)
       VALUES ($1, $2)
       ON CONFLICT (key) DO UPDATE
       SET game_uuids = EXCLUDED.game_uuids, updated_at = now()`,
      [key, csv || null]
    );

    return ok(res, { success: true, count: clean.length, uuids: clean });
  } catch (e) {
    return axiosErr(res, e);
  }
}

async function _getCategory(req, res, table, key) {
  try {
    const page  = Math.max(1, +req.query.page  || 1);
    // Public default 20; admin can fetch the full curated list at once via ?limit=5000.
    const limit = Math.min(+req.query.limit || 20, 5000);
    const offset = (page - 1) * limit;

    const cfg = await db.query(
      `SELECT game_uuids FROM ${table} WHERE key = $1 LIMIT 1`,
      [key]
    );

    const csv = cfg.rows[0]?.game_uuids;
    if (!csv || !csv.trim()) {
      return ok(res, {
        success: true,
        data: [],
        pagination: { currentPage: page, totalPages: 0, totalItems: 0, itemsPerPage: limit }
      });
    }

    const countSQL = `
      WITH list AS (
        SELECT trim(val) AS uuid
        FROM regexp_split_to_table($1, ',') AS val
        WHERE trim(val) <> ''
      )
      SELECT COUNT(*)::int AS c
      FROM list l
      JOIN gisgamesnew g ON g.uuid::text = l.uuid
    `;
    const total = (await db.query(countSQL, [csv])).rows[0]?.c || 0;

    if (total === 0) {
      return ok(res, {
        success: true,
        data: [],
        pagination: { currentPage: page, totalPages: 0, totalItems: 0, itemsPerPage: limit }
      });
    }

    const dataSQL = `
      WITH list AS (
        SELECT trim(val) AS uuid, ord
        FROM regexp_split_to_table($1, ',') WITH ORDINALITY AS t(val, ord)
        WHERE trim(val) <> ''
      )
      SELECT g.*
      FROM list l
      JOIN gisgamesnew g ON g.uuid::text = l.uuid
      ORDER BY l.ord
      LIMIT $2 OFFSET $3
    `;

    const data = (await db.query(dataSQL, [csv, limit, offset])).rows;

    return ok(res, {
      success: true,
      data,
      pagination: {
        currentPage: page,
        totalPages : Math.ceil(total / limit),
        totalItems : total,
        itemsPerPage: limit
      }
    });
  } catch (e) {
    return axiosErr(res, e);
  }
}