CREATE TABLE IF NOT EXISTS gis_recently_played (
    id         SERIAL PRIMARY KEY,
    user_id    BIGINT NOT NULL,
    game_uuid  TEXT   NOT NULL,
    played_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT gis_recently_played_user_game_uniq UNIQUE (user_id, game_uuid)
);

CREATE INDEX IF NOT EXISTS gis_recently_played_user_played_idx
    ON gis_recently_played (user_id, played_at DESC);
