const express = require('express');
const ctr = require('./controller');
const router = express.Router();

/* ───── Game catalogue & lobby ─────────────────────────────── */
router.get('/games', ctr.getGames);
router.get('/game-tags', ctr.getGameTags);
router.get('/games/lobby', ctr.getGameLobby);
router.post('/games/init', ctr.initGame);
router.post('/games/init-demo', ctr.initDemoGame);
router.get('/games/recently-played', ctr.getRecentlyPlayed);
router.get('/games/provider', ctr.getGamesByProvider);
router.get('/providers', ctr.getProviders);
router.get('/sync/gamesnew', ctr.syncGamesNew);
router.get('/sync/providersnew', ctr.syncProvidersNew);

/* ───── Callback (transactions) ─────────────────────────────── */
router.post('/callback/transactions', ctr.handleTransaction);

/* ───── Limits & jackpots ───────────────────────────────────── */
router.get('/limits', ctr.getLimits);
router.get('/limits/freespin', ctr.getFreespinLimits);
router.get('/jackpots', ctr.getJackpots);

/* ───── Freespins ───────────────────────────────────────────── */
router.get('/freespins/bets', ctr.getFreespinBets);
router.post('/freespins/set', ctr.setFreespin);
router.get('/freespins/get', ctr.getFreespin);
router.post('/freespins/cancel', ctr.cancelFreespin);

/* ───── Freevouchers ────────────────────────────────────────── */
router.post('/freevouchers/set', ctr.setFreevoucher);
router.get('/freevouchers/get', ctr.getFreevoucher);
router.post('/freevouchers/cancel', ctr.cancelFreevoucher);

/* ───── Self-validate & sync ────────────────────────────────── */
router.get('/self-validate', ctr.selfValidate);
router.get('/sync', ctr.syncGames);

/* ───── GIS local DB search endpoints ───────────────────────── */
router.get('/providersgis', ctr.getProvidersgis);
router.get('/gamesgis', ctr.getGamesgis);
router.get('/gamesgis/provider/:provider', ctr.getGamesByProvidergis);
router.get('/gamesgis/stats', ctr.getGameStats);
router.get('/hotgames', ctr.getHotGames);
router.get('/livecasino', ctr.getLiveCasino);
router.get('/popularslots', ctr.getPopularSlots);
router.get('/crashgames', ctr.getCrashGames);
router.get('/indiangames', ctr.getIndianGames);

// Admin (protect this)
router.post('/admin/gis/hotgames', ctr.setHotGames);
router.post('/admin/gis/livecasino', ctr.setLiveCasino);
router.post('/admin/gis/popularslots', ctr.setPopularSlots);
router.post('/admin/gis/crashgames', ctr.setCrashGames);
router.post('/admin/gis/indiangames', ctr.setIndianGames);
router.put('/admin/gis/games/:uuid/image', ctr.updateGameImage);
router.get('/admin/gis/games/search', ctr.searchGames);

/* ───── Admin: per-vendor priority for gis_prioritized_games ────── */
router.get('/admin/gis/vendors',           ctr.getVendorList);
router.get('/admin/gis/priority/:vendor',  ctr.getVendorPriority);
router.post('/admin/gis/priority/:vendor', ctr.setVendorPriority);
router.get('/admin/gis/vendor-search',     ctr.searchVendorGames);

/* ───── Admin: per-type priority for gis_prioritized_types ──────── */
router.get('/admin/gis/types',                  ctr.getTypeList);
router.get('/admin/gis/type-priority/:type',    ctr.getTypePriority);
router.post('/admin/gis/type-priority/:type',   ctr.setTypePriority);
router.get('/admin/gis/type-search',             ctr.searchTypeGames);

/* ───── Admin: provider enable/disable ──────────────────────── */
const { protectStaff } = require('../system/middleware/auth');
const db = require('../General/Model');
const { validateTransactionPassword } = require('../system/controllers/lordsController');

router.get('/admin/providers', protectStaff, async (_req, res) => {
  try {
    const { rows } = await db.query(
      'SELECT name, enabled FROM gis_providers_new ORDER BY name'
    );
    res.json({ success: true, data: rows });
  } catch (e) {
    console.error('[gis admin/providers GET] failed:', e.message);
    res.status(500).json({ success: false, message: e.message });
  }
});

router.put('/admin/providers', protectStaff, async (req, res) => {
  try {
    const { updates, transactionPassword } = req.body || {};
    if (!Array.isArray(updates) || !updates.length) {
      return res.status(400).json({ success: false, message: 'updates array required' });
    }
    await validateTransactionPassword(req.staff.id, transactionPassword);

    await db.query('BEGIN');
    for (const u of updates) {
      if (!u || typeof u.name !== 'string') continue;
      await db.query(
        'UPDATE gis_providers_new SET enabled = $1 WHERE name = $2',
        [!!u.enabled, u.name]
      );
    }
    await db.query('COMMIT');

    const { rows } = await db.query(
      'SELECT name, enabled FROM gis_providers_new ORDER BY name'
    );
    res.json({ success: true, data: rows });
  } catch (e) {
    try { await db.query('ROLLBACK'); } catch (_) {}
    console.error('[gis admin/providers PUT] failed:', e.message);
    res.status(400).json({ success: false, message: e.message || 'Update failed' });
  }
});

module.exports = router;
