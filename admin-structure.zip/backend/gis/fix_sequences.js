/**
 * Resyncs every SERIAL/IDENTITY sequence in the DB to MAX(column).
 * Fixes "duplicate key value violates unique constraint *_pkey" errors
 * caused by sequences lagging behind table data (typical after a restore
 * or manual INSERT with explicit ids).
 *
 * Usage:
 *   node gis/fix_sequences.js
 *   node gis/fix_sequences.js --dry-run        # report only, no changes
 *   node gis/fix_sequences.js --table gis_sessions   # one table only
 *
 * Reads DB URL from config.js (same credentials the API uses).
 */

const { Client } = require('pg');
const cfg = require('../config');

const argv = process.argv.slice(2);
const dryRun  = argv.includes('--dry-run');
const tableArg = (() => {
  const i = argv.indexOf('--table');
  return i >= 0 ? argv[i + 1] : null;
})();

(async () => {
  const client = new Client({ connectionString: cfg.dbUrl });
  await client.connect();

  try {
    // Try pg_get_serial_sequence first (handles SERIAL + IDENTITY when sequence is OWNED BY).
    // Fall back to parsing nextval('name'::regclass) from column_default for sequences that
    // were created manually / via pg_dump without an OWNED BY clause.
    const { rows } = await client.query(`
      SELECT c.table_schema,
             c.table_name,
             c.column_name,
             COALESCE(
               pg_get_serial_sequence(format('%I.%I', c.table_schema, c.table_name), c.column_name),
               (SELECT regexp_replace(c.column_default,
                       '^nextval\\(''([^'']+)''(::regclass)?\\)$', '\\1'))
             ) AS seq
        FROM information_schema.columns c
        JOIN information_schema.tables  t
          ON t.table_schema = c.table_schema
         AND t.table_name   = c.table_name
       WHERE t.table_type   = 'BASE TABLE'
         AND c.table_schema NOT IN ('pg_catalog','information_schema')
         AND (c.column_default LIKE 'nextval(%' OR c.is_identity = 'YES')
       ORDER BY c.table_schema, c.table_name
    `);

    let fixed = 0, ok = 0, skipped = 0, drift = [];

    for (const r of rows) {
      if (tableArg && r.table_name !== tableArg) continue;
      if (!r.seq) { skipped++; continue; }

      const maxQ = await client.query(
        `SELECT COALESCE(MAX(${quoteIdent(r.column_name)}), 0)::bigint AS m
           FROM ${quoteIdent(r.table_schema)}.${quoteIdent(r.table_name)}`
      );
      const maxId = BigInt(maxQ.rows[0].m);

      const seqQ = await client.query(
        `SELECT last_value, is_called FROM ${r.seq}`
      );
      const last = BigInt(seqQ.rows[0].last_value);
      const called = seqQ.rows[0].is_called;
      const nextWouldBe = called ? last + 1n : last;

      const isBehind = maxId > 0n && nextWouldBe <= maxId;

      if (isBehind) {
        drift.push({
          table: `${r.table_schema}.${r.table_name}`,
          col: r.column_name,
          maxId: maxId.toString(),
          nextWouldBe: nextWouldBe.toString(),
        });

        if (!dryRun) {
          if (maxId === 0n) {
            await client.query(`SELECT setval($1, 1, false)`, [r.seq]);
          } else {
            await client.query(`SELECT setval($1, $2::bigint, true)`, [r.seq, maxId.toString()]);
          }
          fixed++;
        }
      } else {
        ok++;
      }
    }

    console.log('\n=== Sequence audit ===');
    console.log(`scanned : ${rows.length}`);
    console.log(`healthy : ${ok}`);
    console.log(`skipped : ${skipped}`);
    console.log(`behind  : ${drift.length}`);
    if (drift.length) {
      console.table(drift);
    }
    if (dryRun) {
      console.log('\n(dry-run) no changes applied. Re-run without --dry-run to fix.');
    } else {
      console.log(`\nresynced: ${fixed}`);
    }
  } finally {
    await client.end();
  }
})().catch(e => {
  console.error(e);
  process.exit(1);
});

function quoteIdent(s) {
  return '"' + String(s).replace(/"/g, '""') + '"';
}
