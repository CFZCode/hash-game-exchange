-- ============================================================
-- Fix: "duplicate key value violates unique constraint *_pkey"
-- Cause: SERIAL/IDENTITY sequence is behind MAX(id) in the table,
--        so nextval() returns an id that already exists.
-- This happens after a pg_dump restore, COPY, or manual INSERT
-- with explicit ids that didn't update the sequence.
--
-- Run as the DB owner:
--   psql -h 127.0.0.1 -U myapp1 -d myapp1 -f fix_sequences.sql
-- ============================================================

-- 1) Inspect the offending table first (read-only)
\echo '--- gis_sessions definition ---'
\d gis_sessions

\echo '--- gis_sessions row count + max(id) ---'
SELECT COUNT(*) AS rows, COALESCE(MAX(id), 0) AS max_id FROM gis_sessions;

\echo '--- current sequence value for gis_sessions ---'
SELECT pg_get_serial_sequence('gis_sessions','id') AS seq,
       last_value
  FROM pg_sequences
 WHERE schemaname = 'public'
   AND sequencename = (
        SELECT split_part(pg_get_serial_sequence('gis_sessions','id'), '.', 2)
   );

-- 2) Resync sequences for EVERY table+column that owns one.
-- Uses pg_get_serial_sequence so it handles SERIAL, BIGSERIAL,
-- and identity columns uniformly. Safe to re-run.
DO $$
DECLARE
    r          RECORD;
    seq        TEXT;
    new_max    BIGINT;
    fixed      INT := 0;
    skipped    INT := 0;
BEGIN
    FOR r IN
        SELECT c.table_schema, c.table_name, c.column_name
          FROM information_schema.columns c
          JOIN information_schema.tables  t
            ON t.table_schema = c.table_schema
           AND t.table_name   = c.table_name
         WHERE t.table_type   = 'BASE TABLE'
           AND c.table_schema NOT IN ('pg_catalog','information_schema')
           AND (c.column_default LIKE 'nextval(%'
                OR c.is_identity = 'YES')
    LOOP
        seq := pg_get_serial_sequence(
                 format('%I.%I', r.table_schema, r.table_name),
                 r.column_name);

        IF seq IS NULL THEN
            skipped := skipped + 1;
            CONTINUE;
        END IF;

        EXECUTE format(
            'SELECT COALESCE(MAX(%I), 0) FROM %I.%I',
            r.column_name, r.table_schema, r.table_name)
        INTO new_max;

        -- setval(seq, max, true) means "next nextval() returns max+1".
        -- If the table is empty, set to 1 with is_called=false so first
        -- nextval() returns 1.
        IF new_max = 0 THEN
            PERFORM setval(seq, 1, false);
        ELSE
            PERFORM setval(seq, new_max, true);
        END IF;

        fixed := fixed + 1;
        RAISE NOTICE 'resynced %.%.% -> % (max=%)',
            r.table_schema, r.table_name, r.column_name, seq, new_max;
    END LOOP;

    RAISE NOTICE '=== done. fixed=%, skipped=% ===', fixed, skipped;
END$$;

-- 3) Verify gis_sessions specifically
\echo '--- gis_sessions sequence after fix ---'
SELECT pg_get_serial_sequence('gis_sessions','id') AS seq,
       last_value
  FROM pg_sequences
 WHERE schemaname = 'public'
   AND sequencename = (
        SELECT split_part(pg_get_serial_sequence('gis_sessions','id'), '.', 2)
   );
