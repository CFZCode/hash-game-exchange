# GIS Games — Priority & Admin Management

How GIS (Slotegrator) casino games are ordered, curated, and managed from the admin panel.

- **Backend:** [controller.js](controller.js), [routes.js](routes.js) — mounted under `/api/gis`
- **Admin UI:** `adminpanel/src/components/` → `ProvidersPriority.tsx`, `VendorPriority.tsx`, `TypePriority.tsx`
- **Source of truth for games:** the `gisgamesnew` table (synced from Slotegrator GIS API). Everything below only stores **ordered lists of `uuid`s** that point back into `gisgamesnew`.

---

## 1. The big picture

There is **no `priority` column on the games themselves.** Instead, ordering is driven by small "list" tables that each hold an **ordered set of game UUIDs**. When the lobby renders, it pulls the relevant list, puts those games first (in list order), and fills the rest alphabetically.

There are **three independent priority systems** plus **provider on/off**:

| System | Admin page | Sidebar label | Storage table | Scope |
|---|---|---|---|---|
| **Curated category rails** | `ProvidersPriority.tsx` | **Providers Priority** | `hot_games`, `live_casino`, `popular_slots`, `crash_games`, `indian_games` | Hand-picked homepage rails (Hot Games, Live Casino, etc.) |
| **Per-vendor priority** | `VendorPriority.tsx` | **Vendor Priority** | `gis_prioritized_games` | Pins games to the top **inside a provider's game list** |
| **Per-type priority** | `TypePriority.tsx` | **Type Priority** | `gis_prioritized_types` | Pins games to the top **inside a game-type list** (slots, live, etc.) |
| **Provider enable/disable** | (provider toggle UI) | — | `gis_providers_new.enabled` | Turns a whole provider on/off; protected by staff auth + transaction password |

> ⚠️ Naming gotcha: the sidebar item **"Providers Priority"** does **not** edit providers — it edits the **curated category rails** (Hot Games, Live Casino, Popular Slots, Crash Games, Indian Games). Actual provider enable/disable lives behind the staff-protected `/api/gis/admin/providers` endpoints.

---

## 2. Data model

All list tables store the order as a **comma-separated string of UUIDs** in one column. Order in the CSV = display order.

### Curated category tables (`hot_games` + [game_categories.sql](../system/migrations/game_categories.sql))
```sql
CREATE TABLE IF NOT EXISTS live_casino (
  key        TEXT PRIMARY KEY,   -- e.g. 'livecasino'
  game_uuids TEXT,               -- 'uuid1,uuid2,uuid3,...'
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- popular_slots, crash_games, indian_games, hot_games share this exact shape
```
A single row per table, keyed by a fixed `key` string (`hotgames`, `livecasino`, `popularslots`, `crashgames`, `indiangames`).

### Per-vendor priority (`gis_prioritized_games`)
```
vendor      TEXT     -- provider name (matched case-insensitively)
game_ids    TEXT     -- CSV of UUIDs, in priority order
updated_at  TIMESTAMP
```
One row per vendor. Upsert is keyed on `LOWER(vendor)` (see [prioritized_games_unique.sql](../system/migrations/prioritized_games_unique.sql)).

### Per-type priority ([gis_prioritized_types.sql](../system/migrations/gis_prioritized_types.sql))
```sql
CREATE TABLE IF NOT EXISTS gis_prioritized_types (
  id SERIAL PRIMARY KEY,
  type     TEXT NOT NULL,   -- game type, matched on LOWER(TRIM(type))
  game_ids TEXT NOT NULL,   -- CSV of UUIDs, in priority order
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX ... ON gis_prioritized_types (LOWER(TRIM(type)));
```
`type` values in `gisgamesnew` are mixed-case with stray whitespace, so all matching trims + lowercases.

### Legacy / fallback tables
The lobby query still falls back to older schemas if `gis_prioritized_games` has nothing: `prioritized_gis_games` + `prioritized_gis_game_items` (normalized, `position`-ordered) and `prioritized_gis` (CSV `game_uuids`). These are read-only fallbacks; the admin UI writes only to the current tables.

---

## 3. How priority is applied in the lobby

The public games list is served by **`getGamesgis`** → `GET /api/gis/gamesgis` ([controller.js:1539](controller.js#L1539)). Key behavior:

1. **Filters** (`provider`, `type`, `search`, `technology`, `has_lobby`, `has_freespins`) build the `WHERE` clause. `is_mobile` is **not a filter** — it becomes a sort tiebreaker (mobile-first or desktop-first).

2. **Priority only applies to page 1.** Pages 2+ are plain alphabetical.

3. **Which list wins (precedence):**
   - If a **`type`** filter is set → use `gis_prioritized_types` for that type.
   - Else if a **`provider`** filter is set → use `gis_prioritized_games` for that vendor (then legacy fallbacks).
   - Else → no priority list, plain alphabetical.

4. **The ordering SQL** turns the CSV into `(uuid, position)` via `unnest(... ) WITH ORDINALITY`, left-joins it onto `gisgamesnew`, and orders:
   ```sql
   ORDER BY
     <mobileOrder>,        -- optional mobile/desktop bias
     (pri.pos IS NULL),    -- prioritized rows first (false sorts before true)
     pri.pos,              -- keep the admin-defined order
     g.name ASC            -- everything else alphabetical
   ```
   Response includes `prioritizedApplied: true` when a priority list was used on page 1.

### Curated rails
Each rail has its own public endpoint that returns games **strictly in saved CSV order** (`ORDER BY ord` from `WITH ORDINALITY`), joined to `gisgamesnew` so dead UUIDs are silently dropped:
- `GET /api/gis/hotgames`
- `GET /api/gis/livecasino`
- `GET /api/gis/popularslots`
- `GET /api/gis/crashgames`
- `GET /api/gis/indiangames`

All accept `?page=&limit=` (public default `limit=20`; admin loads the full list with `limit=5000`).

---

## 4. Admin endpoints

Defined in [routes.js](routes.js). The curated-list and priority routes are currently **not** behind `protectStaff` (only the provider enable/disable routes are). Treat them as admin-only at the gateway/UI layer.

### Curated category rails
| Method | Path | Action |
|---|---|---|
| `POST` | `/api/gis/admin/gis/hotgames` | Save Hot Games CSV |
| `POST` | `/api/gis/admin/gis/livecasino` | Save Live Casino CSV |
| `POST` | `/api/gis/admin/gis/popularslots` | Save Popular Slots CSV |
| `POST` | `/api/gis/admin/gis/crashgames` | Save Crash Games CSV |
| `POST` | `/api/gis/admin/gis/indiangames` | Save Indian Games CSV |

Body: `{ "uuids": ["uuid1","uuid2", ...] }` **or** `{ "uuidsCSV": "uuid1,uuid2" }`. The controller deduplicates while preserving order, joins to CSV, and upserts the single row (`ON CONFLICT (key) DO UPDATE`). Shared helper `_setCategory` ([controller.js:2553](controller.js#L2553)).

### Per-vendor priority
| Method | Path | Action |
|---|---|---|
| `GET` | `/api/gis/admin/gis/vendors` | List every provider + game count + whether it has a priority list |
| `GET` | `/api/gis/admin/gis/priority/:vendor` | Get that vendor's ordered games |
| `POST` | `/api/gis/admin/gis/priority/:vendor` | Save ordered `uuids[]` for the vendor |
| `GET` | `/api/gis/admin/gis/vendor-search?vendor=&q=` | Search games **within** a vendor (name or uuid) for the picker |

### Per-type priority
| Method | Path | Action |
|---|---|---|
| `GET` | `/api/gis/admin/gis/types` | List every type + game count + has-priority flag |
| `GET` | `/api/gis/admin/gis/type-priority/:type` | Get that type's ordered games |
| `POST` | `/api/gis/admin/gis/type-priority/:type` | Save ordered `uuids[]` for the type |
| `GET` | `/api/gis/admin/gis/type-search?type=&q=` | Search games **within** a type for the picker |

### Game image + global search
| Method | Path | Action |
|---|---|---|
| `PUT` | `/api/gis/admin/gis/games/:uuid/image` | Overwrite `gisgamesnew.image` for one game |
| `GET` | `/api/gis/admin/gis/games/search?q=&limit=` | Global game search (any provider) for the curated-rail picker |

### Provider enable/disable (staff-protected)
| Method | Path | Action |
|---|---|---|
| `GET` | `/api/gis/admin/providers` | List providers + `enabled` flag |
| `PUT` | `/api/gis/admin/providers` | Bulk update `enabled` — requires `protectStaff` + `transactionPassword` |

`PUT` body: `{ updates: [{ name, enabled }], transactionPassword }`. Validated via `validateTransactionPassword(req.staff.id, ...)` and applied in a transaction ([routes.js:89](routes.js#L89)).

---

## 5. Admin UI — what each page does

All three pages share the same UX skeleton: a list table with reorder controls, an "Add Games" search picker, an inline image editor, client-side pagination (50/page), and an explicit **Save** (changes are local until saved — a yellow "unsaved" badge shows when dirty).

### A. "Providers Priority" page → curated rails (`ProvidersPriority.tsx`)
- **Tabs**: Live Casino · Popular Slots · Crash Games · Hot Games · Indian Games.
- Loads the full list (`?limit=5000`), lets you **reorder** (move up/down, jump to top/bottom), **remove**, and **add** games via global search.
- **Save** POSTs the full ordered `uuids[]` to the active rail's `setPath`.
- Search picker uses `/api/gis/admin/gis/games/search` (searches all games, no provider/type constraint).

### B. "Vendor Priority" page (`VendorPriority.tsx`)
- Pick a **vendor** from a dropdown (shows total game count + a green "priority" chip if a list exists).
- Loads that vendor's pinned games from `/api/gis/admin/gis/priority/:vendor`.
- Reorder / remove / add. The picker (`vendor-search`) is **scoped to the selected vendor** and blocks duplicates.
- **Save** → `POST /api/gis/admin/gis/priority/:vendor` with `uuids[]` → writes `gis_prioritized_games`.
- Writes show up in the lobby when the user filters games by that **provider** (page 1).

### C. "Type Priority" page (`TypePriority.tsx`)
- Same as Vendor Priority but keyed on **game type**; picker (`type-search`) is scoped to the selected type.
- **Save** → `POST /api/gis/admin/gis/type-priority/:type` → writes `gis_prioritized_types`.
- Writes show up in the lobby when the user filters games by that **type** (page 1), and **take precedence over vendor priority** if both a type and provider filter are set.

### Changing a game's image (all three pages)
Each row has a ✏️ (pencil) action → opens a dialog with a live preview and an **Image URL** field. Saving calls `PUT /api/gis/admin/gis/games/:uuid/image`, which overwrites `gisgamesnew.image` for that UUID. This is **global** — the new image is used everywhere the game appears, not just in the list you edited.

---

## 6. End-to-end example

**Goal:** put "Sweet Bonanza" at the top of Pragmatic Play's list.

1. Admin opens **Vendor Priority**, selects **Pragmatic Play**.
2. Clicks **Add Games**, searches "sweet bonanza", checks it, **Add Selected**.
3. Uses **Top** to move it to position 1, then **Save Priority**.
4. Backend dedupes → CSV `"<sweet-bonanza-uuid>,..."` → upserts `gis_prioritized_games` for `pragmatic play`.
5. A player browsing games filtered by provider = "Pragmatic Play" sees Sweet Bonanza first on page 1 (`prioritizedApplied: true`), then the rest of the pinned order, then alphabetical.

---

## 7. Notes & gotchas

- **Lists store UUIDs, not games.** If a game leaves `gisgamesnew`, it silently disappears from rails/priority (inner JOIN) — no cleanup needed.
- **Priority is page-1-only** in the generic lobby; deep pages are alphabetical by design.
- **Type beats vendor** when both filters are present.
- **Order is preserved exactly** as saved; dedup keeps the first occurrence.
- **Matching is case-insensitive** for vendor (`LOWER`) and type (`LOWER(TRIM())`).
- Curated-rail and priority write endpoints are **not** staff-protected at the route layer today — only `/api/gis/admin/providers` is. Lock these down at the gateway/UI if exposure is a concern.
