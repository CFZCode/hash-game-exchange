const pg = require("./General/Model");

async function fetchDataFromDb(activeSessionId, table) {
    const { rows } = await pg.query(`SELECT * FROM ${table} WHERE sessionId = $1`, [activeSessionId]);
    return rows;
}

function calculateBetSummary(bets) {
    let summary = {
        individualNumbers: {},
        colors: {
            red: 0,
            green: 0,
            violet: 0
        }
    };

    bets.forEach(bet => {
        const value = bet.value.toString();
        const amount = parseInt(bet.amount);

        // Individual numbers
        if (/^\d+$/.test(value)) {
            let num = parseInt(value);
            summary.individualNumbers[value] = (summary.individualNumbers[value] || 0) + amount;
        }

        // Color bets
        if (value === 'red' || value === 'green' || value === 'violet') {
            summary.colors[value] += amount;
        }
    });

    return summary;
}

function getRandomNumberInRange(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function processBets(summary) {
    const { individualNumbers, colors } = summary;
    const { red, green, violet } = colors;

    let winnerNumber = null;
    let winningColor = '';

    const lowestBetNumber = Object.entries(individualNumbers).reduce((acc, [num, amount]) => {
        amount = parseFloat(amount); // Convert amount to float

        if (acc === null || amount < parseFloat(acc.amount)) {
            return { number: num, amount };
        }
        return acc;
    }, null);

    if (lowestBetNumber !== null) {
        winnerNumber = parseInt(lowestBetNumber.number);
    } else {
        // If no number bets, determine a random winner number based on color bets
        if (green > 0 && red === 0 && violet === 0) {
            winnerNumber = getRandomNumberInRange(1, 9) * 2 - 1; // random odd number
        } else if (red > 0 && green === 0 && violet === 0) {
            winnerNumber = getRandomNumberInRange(1, 9) * 2; // random even number
        } else if (violet > 0 && red === 0 && green === 0) {
            winnerNumber = getRandomNumberInRange(0, 1) * 5; // random 0 or 5
        } else {
            winnerNumber = getRandomNumberInRange(0, 9); // random between 0-9
        }
    }

    // Determine the winning color
    if (winnerNumber === 0 || winnerNumber === 5) {
        if (violet > 0) {
            winningColor = 'violet';
        } else if (winnerNumber === 0 && green > red) {
            winningColor = 'green';
        } else if (winnerNumber === 5 && red > green) {
            winningColor = 'red';
        } else {
            winningColor = winnerNumber === 0 ? 'green' : 'red';
        }
    } else {
        winningColor = winnerNumber % 2 === 0 ? 'red' : 'green';
    }

    return { number: winnerNumber, color: winningColor };
}

async function getNumber(activeSessionId, table) {
    try {
        const bets = await fetchDataFromDb(activeSessionId, table);
        if (bets.length === 0) {
            console.log(`No bets found for Session ${activeSessionId}.`);
            return { number: 11, color: "nocolor" };
        }
        console.log(`Bets for Session ${activeSessionId}:`);
        bets.forEach(bet => {
            console.log(`User ${bet.uid} placed a bet of ${bet.amount} on ${bet.value}`);
        });

        const summary = calculateBetSummary(bets);
        const { number, color } = processBets(summary);
        console.log(`Winning Number for Session ${activeSessionId}: ${number} (${color})`);
        return { number, color };
    } catch (error) {
        console.error("An error occurred:", error);
        return { number: null, color: null };
    }
}

module.exports = { getNumber };
