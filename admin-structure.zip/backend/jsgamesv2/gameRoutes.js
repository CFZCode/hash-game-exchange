var express = require('express');
var router = express.Router();
var GameController = require('./gameController');

router.post('/launch', GameController.getGameLaunchURL);
router.post('/bet-callback', GameController.processBetCallback);
router.get('/games', GameController.getActiveGames);
router.get('/games/search', GameController.searchGames);
router.get('/history',GameController.userhistory);
router.get('/historyAdmin',GameController.userhistoryAdmin);
module.exports = router;