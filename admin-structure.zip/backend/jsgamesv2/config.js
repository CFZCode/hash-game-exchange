module.exports = {
  gameApi: {
    baseUrl: 'https://example.com/api/game/',
    apiKey: 'REMOVED_SECRET',
    apiSecret: 'REMOVED_SECRET',
  },
};