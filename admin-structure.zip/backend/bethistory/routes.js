// routes/transactionRoutes.js
const express = require('express');
const {
  getTransactionHistory,
  getUserTransactionHistory,
  getTransactionStats,
  getUserBetWinCount,
  getLuckySportsTransactionHistory,
  getUserSportsBetsHistory,
  getAllSportsBetsAdmin
} = require('./controller');

const router = express.Router();

// Route for all transactions with pagination and filters
router.get('/transactions', getTransactionHistory);

router.get('/transactions/luckysports', getLuckySportsTransactionHistory);

// Route for specific user transactions
router.get('/transactions/user/:userId', getUserTransactionHistory);

// Route for transaction statistics
router.get('/transactions/stats', getTransactionStats);

router.get('/user/:userId/bet-win-count', getUserBetWinCount);


router.get('/user/bet-history', getUserSportsBetsHistory);

router.get('/admin/bet-history', getAllSportsBetsAdmin);

// Admin analytics stats
router.get('/admin/analytics', async (req, res) => {
    try {
        const pg = require('../General/Model');
        const staffId = req.headers['x-staff-id'];

        let userFilter = '';
        if (staffId) {
            const { visibleStaffIds } = require('../system/helpers/staffTree');
            const sids = (await visibleStaffIds(staffId)).map(Number);
            if (!sids.includes(1)) {
                const uRes = await pg.query(
                    `SELECT array_agg(id) AS uids FROM users WHERE parent_staff_id = ANY($1::bigint[])`, [sids]
                );
                const uids = uRes.rows[0]?.uids || [-1];
                userFilter = ` AND user_id = ANY(ARRAY[${uids.join(',')}]::bigint[])`;
            }
        }

        // Combined view of all 3 transaction tables
        const allTxCTE = `
            WITH all_tx AS (
                SELECT user_id, LOWER(action) AS tx_type, ABS(amount) AS amt, created_at AS ts
                FROM gis_transactions WHERE 1=1 ${userFilter}
                UNION ALL
                SELECT user_id, LOWER(transaction_type) AS tx_type, ABS(amount) AS amt, timestamp AS ts
                FROM js_game_transactions WHERE 1=1 ${userFilter}
                UNION ALL
                SELECT uid AS user_id,
                       CASE WHEN profit > 0 THEN 'win' WHEN profit < 0 THEN 'loss' ELSE 'bet' END AS tx_type,
                       ABS(amount) AS amt, created AS ts
                FROM bets WHERE 1=1 ${userFilter.replace(/user_id/g, 'uid')}
            )`;

        const [totals, today, typeBreak, topUsers] = await Promise.all([
            pg.query(`${allTxCTE}
                SELECT
                    COUNT(*) AS total,
                    COUNT(*) FILTER (WHERE tx_type = 'bet') AS total_bets,
                    COUNT(*) FILTER (WHERE tx_type = 'win') AS total_wins,
                    COUNT(*) FILTER (WHERE tx_type = 'loss') AS total_losses,
                    COALESCE(SUM(CASE WHEN tx_type = 'bet' THEN amt ELSE 0 END), 0) AS total_wagered,
                    COALESCE(SUM(CASE WHEN tx_type = 'win' THEN amt ELSE 0 END), 0) AS total_payouts,
                    COALESCE(SUM(CASE WHEN tx_type = 'loss' THEN amt ELSE 0 END), 0) AS total_losses_amt
                FROM all_tx
            `),
            pg.query(`${allTxCTE}
                SELECT
                    COUNT(*) AS today_total,
                    COUNT(*) FILTER (WHERE tx_type = 'bet') AS today_bets,
                    COUNT(*) FILTER (WHERE tx_type = 'win') AS today_wins,
                    COALESCE(SUM(CASE WHEN tx_type = 'bet' THEN amt ELSE 0 END), 0) AS today_wagered
                FROM all_tx
                WHERE DATE(ts) = CURRENT_DATE
            `),
            pg.query(`${allTxCTE}
                SELECT tx_type AS transaction_type, COUNT(*) AS count,
                       COALESCE(SUM(amt), 0) AS total_amount
                FROM all_tx
                GROUP BY tx_type ORDER BY count DESC
            `),
            pg.query(`${allTxCTE}
                SELECT t.user_id, u.name AS user_name, COUNT(*) AS bet_count,
                       COALESCE(SUM(CASE WHEN t.tx_type = 'bet' THEN t.amt ELSE 0 END), 0) AS wagered,
                       COALESCE(SUM(CASE WHEN t.tx_type = 'win' THEN t.amt ELSE 0 END), 0) AS won
                FROM all_tx t
                LEFT JOIN users u ON u.id = t.user_id
                GROUP BY t.user_id, u.name ORDER BY bet_count DESC LIMIT 10
            `)
        ]);

        res.json({
            totals: totals.rows[0],
            today: today.rows[0],
            typeBreakdown: typeBreak.rows,
            topUsers: topUsers.rows
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;