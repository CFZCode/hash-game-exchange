const pg = require('../General/Model');
// Get user transaction history
const axios = require('axios');

const getTreeIdsSql = `
WITH RECURSIVE tree AS (
  SELECT id FROM staff WHERE id = $1
  UNION ALL
  SELECT s.id
  FROM staff s
  JOIN tree t ON s.parent_id = t.id
)
SELECT array_agg(id) AS ids FROM tree
`;
async function visibleIds(staffId) {
  const { rows: [{ ids }] } = await pg.query(getTreeIdsSql, [staffId]);
  return ids;                   // => e.g. [1,4,9,12]
}
// const getTransactionHistory = async (req, res) => {
//   try {
//     const { page = 1, limit = 10, search = '', userId = null } = req.query;
//     const offset = (Number(page) - 1) * Number(limit);
//     // staff visibility ids
//    let ids = await visibleIds(req.headers['x-staff-id']);
// ids = ids.map(x => Number(x)); // ensure numbers
// let val = false;
// if (ids.includes(1)) {
//   val = true; // add NULL if 1 exists
// }

// console.log("hellotesthb (staff visibility IDs):", ids);
//     // Fetch live game history from the API
//     let liveTransactions = [];
//     try {
//       const apiResponse = await axios.get(`https://api.lagaobet.com/jsGamesv2/historyAdmin`);

//       if (apiResponse.data.success && Array.isArray(apiResponse.data.data)) {
//         liveTransactions = apiResponse.data.data.map(transaction => ({
//           id: transaction.id,
//           transaction_id: transaction.external_transaction_id,
//           round_id: transaction.id,
//           user_id: transaction.client_user_id,
//           session: transaction.serial_number || null,
//           transaction_type: transaction.transaction_type.toUpperCase(),
//           amount: parseFloat(transaction.amount),
//           currency_code: transaction.currency,
//           transaction_timestamp: new Date(transaction.timestamp),
//           reason: transaction.transaction_type.toUpperCase(),
//           round_finished: true,
//           transaction_status: transaction.transaction_status.toUpperCase(),
//           user_name: transaction.username || null, // Use username from API response
//           game_title: transaction.game_name,
//           game_vendor: 'live',
//           source: 'live_games',
//           // parent_staff_id: transaction.parent_staff_id || null 
//         }));
//       }
//     } catch (apiError) {
//       console.error('Error fetching live game history:', apiError.message);
//       // Continue with bets data even if API fails
//     }
//     // -----------------------
//     // Dynamic filters (SQL)
//     // -----------------------
//     let params = [];
//     let conditions = [];

//     // Search filter
//     if (search) {
//       params.push(`%${search}%`);
//       conditions.push(`(u.name ILIKE $${params.length} OR b.gid::text ILIKE $${params.length})`);
//     }

//     // userId filter
//     if (userId) {
//       params.push(userId);
//       conditions.push(`b.uid = $${params.length}`);
//     }

//     // staff visibility filter (ALWAYS applied)
//    // ✅ BUT make sure ids is already flat
// // before this line, flatten it:
// params.push(ids);  // ✅ push the actual array, not a string
// conditions.push(`u.parent_staff_id = ANY($${params.length}::bigint[])`);


//     const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

//     // -----------------------
//     // Main SQL Query
//     // -----------------------
//     let query = `
//       SELECT 
//         b.gid as id,
//         b.gid::text as transaction_id,
//         b.gid as round_id,
//         b.uid as user_id,
//         NULL::text as session,
//         CASE 
//           WHEN b.profit > 0 THEN 'WIN'
//           WHEN b.profit < 0 THEN 'LOSS'
//           ELSE 'BET' 
//         END as transaction_type,
//         b.amount,
//         b.coin as currency_code,
//         b.created as transaction_timestamp,
//         CASE 
//           WHEN b.profit > 0 THEN 'WIN'
//           WHEN b.profit < 0 THEN 'LOSS'
//           ELSE 'DRAW' 
//         END as reason,
//         TRUE as round_finished,
//         CASE WHEN b.hash IS NULL THEN 'ERROR' ELSE 'SUCCESS' END as transaction_status,
//         u.name as user_name,
//         b.game as game_title,
//         CASE 
//           WHEN b.slot IS NOT NULL THEN b.slot 
//           ELSE 'internal' 
//         END as game_vendor,
//         'bets' as source,
//         u.parent_staff_id
//       FROM bets b
//       LEFT JOIN users u ON b.uid = u.id
//       ${whereClause}
//       ORDER BY b.created DESC
//     `;

//     let countQuery = `
//       SELECT COUNT(*)
//       FROM bets b
//       LEFT JOIN users u ON b.uid = u.id
//       ${whereClause}
//     `;

//     // -----------------------
//     // Run DB Queries
//     // -----------------------
//     const [betsResult, countResult] = await Promise.all([
//       pg.query(query, params),
//       pg.query(countQuery, params)
//     ]);

//     console.log("Final Query:", query);
//     console.log("Params:", params);

//     const betsTransactions = betsResult.rows;

//     // -----------------------
//     // Merge DB + Live data
//     // -----------------------
//     let allTransactions = [...betsTransactions, ...liveTransactions];

//     // ✅ Extra safety filter for live transactions (since SQL didn’t filter them)
//    if(!val){
//    allTransactions = allTransactions.filter(t =>
//   t.parent_staff_id && ids.includes(Number(t.parent_staff_id))

// );
//    }

//     // -----------------------
//     // In-memory filters (search/userId safety net)
//     // -----------------------
//     if (search) {
//       const searchLower = search.toLowerCase();
//       allTransactions = allTransactions.filter(t =>
//         (t.user_name && t.user_name.toLowerCase().includes(searchLower)) ||
//         (t.transaction_id && t.transaction_id.toLowerCase().includes(searchLower)) ||
//         (t.session && t.session.toLowerCase().includes(searchLower))
//       );
//     }

//     if (userId) {
//       allTransactions = allTransactions.filter(t => t.user_id.toString() === userId);
//     }

//     // -----------------------
//     // Sort + Pagination
//     // -----------------------
//     allTransactions.sort((a, b) => new Date(b.transaction_timestamp) - new Date(a.transaction_timestamp));

//     const totalCount = allTransactions.length;
//     const totalPages = Math.ceil(totalCount / Number(limit));
//     const paginatedTransactions = allTransactions.slice(offset, offset + Number(limit));

//     res.status(200).json({
//       transactions: paginatedTransactions,
//       pagination: {
//         totalCount,
//         totalPages,
//         currentPage: Number(page),
//         limit: Number(limit)
//       }
//     });

//   } catch (error) {
//     console.error('Error fetching transaction history:', error);
//     res.status(500).json({ error: 'Failed to fetch transaction history' });
//   }
// };




const getTransactionHistory = async (req, res) => {
  try {
    const { page = 1, limit = 10, search = '', userId = null } = req.query;
    const offset = (Number(page) - 1) * Number(limit);

    // staff visibility ids
    let ids = await visibleIds(req.headers['x-staff-id']);
    ids = (Array.isArray(ids) ? ids : []).map(x => Number(x));
    let val = false;
    if (ids.includes(1)) {
      val = true; // add NULL if 1 exists
    }

    console.log("hellotesthb (staff visibility IDs):", ids, "allowNullParent:", val);

    // -----------------------
    // Live game history (best-effort)
    // -----------------------
    let liveTransactions = [];
    try {
      const apiResponse = await axios.get(`https://api.lagaobet.com/jsGamesv2/historyAdmin`);

      if (apiResponse.data && apiResponse.data.success && Array.isArray(apiResponse.data.data)) {
        liveTransactions = apiResponse.data.data.map(transaction => ({
          id: transaction.id,
          transaction_id: transaction.external_transaction_id ? String(transaction.external_transaction_id) : String(transaction.id),
          round_id: transaction.id,
          user_id: transaction.client_user_id,
          session: transaction.serial_number || null,
          transaction_type: (transaction.transaction_type || '').toUpperCase(),
          amount: parseFloat(transaction.amount) || 0,
          currency_code: transaction.currency || null,
          transaction_timestamp: transaction.timestamp ? new Date(transaction.timestamp).toISOString() : new Date().toISOString(),
          reason: (transaction.transaction_type || '').toUpperCase(),
          round_finished: true,
          transaction_status: (transaction.transaction_status || '').toUpperCase(),
          user_name: transaction.username || null,
          game_title: transaction.game_name || null,
          game_vendor: 'live',
          source: 'live_games',
          parent_staff_id: transaction.parent_staff_id != null ? Number(transaction.parent_staff_id) : null
        }));
      }
    } catch (apiError) {
      console.error('Error fetching live game history:', apiError.message || apiError);
      // continue — liveTransactions stays empty or partially filled
    }

    // -----------------------
    // Build dynamic filters for SQL queries
    // -----------------------
    // We'll create helper to build params & conditions per-query to keep $n in order
    const buildFilters = (aliasUser = 'u') => {
      const params = [];
      const conditions = [];

      // Search filter: only applies to DB-side for some fields (we also apply in-memory)
      if (search) {
        params.push(`%${search}%`);
        // search will be applied to username and (for bets) gid; for gis we'll later use transaction_id or game title in SQL if desired
        conditions.push(`(${aliasUser}.name ILIKE $${params.length} OR CAST(NULL AS text) ILIKE $${params.length})`);
      }

      if (userId) {
        params.push(userId);
        // b.uid or gis.user_id will use appropriate table alias in the query body
        conditions.push(`/*USER_FILTER_PLACEHOLDER*/`);
      }

      // staff visibility: always applied
      params.push(ids);
      const idx = params.length;
      if (val) {
        // allow NULL or match any
        conditions.push(`(${aliasUser}.parent_staff_id IS NULL OR ${aliasUser}.parent_staff_id = ANY($${idx}::bigint[]))`);
      } else {
        conditions.push(`${aliasUser}.parent_staff_id = ANY($${idx}::bigint[])`);
      }

      return { params, conditions };
    };

    // -----------------------
    // Query 1: bets (original)
    // -----------------------
    // Build params & conditions specifically for bets (alias user = u)
    let betsParams = [];
    let betsConditions = [];

    if (search) {
      betsParams.push(`%${search}%`);
      betsConditions.push(`(u.name ILIKE $${betsParams.length} OR b.gid::text ILIKE $${betsParams.length})`);
    }
    if (userId) {
      betsParams.push(userId);
      betsConditions.push(`b.uid = $${betsParams.length}`);
    }
    betsParams.push(ids);
    if (val) {
      betsConditions.push(`(u.parent_staff_id IS NULL OR u.parent_staff_id = ANY($${betsParams.length}::bigint[]))`);
    } else {
      betsConditions.push(`u.parent_staff_id = ANY($${betsParams.length}::bigint[])`);
    }
    const betsWhere = betsConditions.length > 0 ? `WHERE ${betsConditions.join(' AND ')}` : '';

    const betsQuery = `
      SELECT 
        b.gid as id,
        b.gid::text as transaction_id,
        b.gid as round_id,
        b.uid as user_id,
        NULL::text as session,
        CASE 
          WHEN b.profit > 0 THEN 'WIN'
          WHEN b.profit < 0 THEN 'LOSS'
          ELSE 'BET' 
        END as transaction_type,
        b.amount,
        b.coin as currency_code,
        b.created as transaction_timestamp,
        CASE 
          WHEN b.profit > 0 THEN 'WIN'
          WHEN b.profit < 0 THEN 'LOSS'
          ELSE 'DRAW' 
        END as reason,
        TRUE as round_finished,
        CASE WHEN b.hash IS NULL THEN 'ERROR' ELSE 'SUCCESS' END as transaction_status,
        u.name as user_name,
        b.game as game_title,
        CASE 
          WHEN b.slot IS NOT NULL THEN b.slot 
          ELSE 'internal' 
        END as game_vendor,
        'bets' as source,
        u.parent_staff_id,
        COALESCE(u.is_demo, false) AS is_demo
      FROM bets b
      LEFT JOIN users u ON b.uid = u.id
      ${betsWhere}
      ORDER BY b.created DESC
    `;

    // -----------------------
    // Query 2: gis_transactions joined to gis_games and users
    // -----------------------
    let gisParams = [];
    let gisConditions = [];

    if (search) {
      gisParams.push(`%${search}%`);
      // we'll search by user name OR transaction_id OR game name (via gis_games.name)
      gisConditions.push(`(ug.name ILIKE $${gisParams.length} OR gis.transaction_id::text ILIKE $${gisParams.length} OR g.name ILIKE $${gisParams.length})`);
    }
    if (userId) {
      gisParams.push(userId);
      gisConditions.push(`gis.user_id = $${gisParams.length}`);
    }
    gisParams.push(ids);
    if (val) {
      gisConditions.push(`(ug.parent_staff_id IS NULL OR ug.parent_staff_id = ANY($${gisParams.length}::bigint[]))`);
    } else {
      gisConditions.push(`ug.parent_staff_id = ANY($${gisParams.length}::bigint[])`);
    }
    const gisWhere = gisConditions.length > 0 ? `WHERE ${gisConditions.join(' AND ')}` : '';

    // Map fields from gis_transactions and games into common shape
    const gisQuery = `
      SELECT
        gis.id as id,
        gis.transaction_id::text as transaction_id,
        gis.round_id::text as round_id,
        gis.user_id as user_id,
        gis.session_id::text as session,
        gis.action::text as transaction_type,
        gis.amount,
        gis.currency,
        COALESCE(gis.transaction_datetime, gis.created_at) as transaction_timestamp,
        gis.action::text as reason,
        gis.finished as round_finished,
        'SUCCESS' as transaction_status,
        ug.name as user_name,
        g.name as game_title,
        g.provider as game_vendor,
        'gis_transactions' as source,
        ug.parent_staff_id,
        COALESCE(ug.is_demo, false) AS is_demo
      FROM gis_transactions gis
      LEFT JOIN gis_games g ON gis.game_uuid = g.uuid
      LEFT JOIN users ug ON gis.user_id = ug.id
      ${gisWhere}
      ORDER BY COALESCE(gis.transaction_datetime, gis.created_at) DESC
    `;

    // -----------------------
    // Count queries (optional for DB sources) - we won't return DB counts separately because final count is merged
    // -----------------------

    // -----------------------
    // Run DB Queries in parallel
    // -----------------------
    const [betsResult, gisResult] = await Promise.all([
      pg.query(betsQuery, betsParams),
      pg.query(gisQuery, gisParams)
    ]);

    console.log("betsQuery:", betsQuery);
    console.log("betsParams:", betsParams);
    console.log("gisQuery:", gisQuery);
    console.log("gisParams:", gisParams);

    const betsTransactions = (betsResult.rows || []).map(r => ({
      id: r.id,
      transaction_id: String(r.transaction_id),
      round_id: r.round_id,
      user_id: r.user_id,
      session: r.session,
      transaction_type: r.transaction_type,
      amount: parseFloat(r.amount) || 0,
      currency_code: r.currency_code,
      transaction_timestamp: r.transaction_timestamp ? new Date(r.transaction_timestamp).toISOString() : new Date().toISOString(),
      reason: r.reason,
      round_finished: !!r.round_finished,
      transaction_status: r.transaction_status,
      user_name: r.user_name,
      game_title: r.game_title,
      game_vendor: r.game_vendor,
      source: r.source,
      parent_staff_id: r.parent_staff_id != null ? Number(r.parent_staff_id) : null,
      is_demo: !!r.is_demo
    }));

    const gisTransactions = (gisResult.rows || []).map(r => ({
      id: r.id,
      transaction_id: String(r.transaction_id),
      round_id: r.round_id,
      user_id: r.user_id,
      session: r.session,
      transaction_type: (r.transaction_type || '').toUpperCase(),
      amount: parseFloat(r.amount) || 0,
      currency_code: r.currency,
      transaction_timestamp: r.transaction_timestamp ? new Date(r.transaction_timestamp).toISOString() : new Date().toISOString(),
      reason: (r.reason || '').toUpperCase(),
      round_finished: r.round_finished === true || r.round_finished === 't' || r.round_finished === 1,
      transaction_status: r.transaction_status,
      user_name: r.user_name,
      game_title: r.game_title,
      game_vendor: r.game_vendor || 'gis',
      source: r.source,
      parent_staff_id: r.parent_staff_id != null ? Number(r.parent_staff_id) : null,
      is_demo: !!r.is_demo
    }));

    // -----------------------
    // Merge DB + Live data
    // -----------------------
    let allTransactions = [...betsTransactions, ...gisTransactions, ...liveTransactions];

    // Extra safety filter for live transactions (since SQL didn’t filter them)
    if (!val) {
      allTransactions = allTransactions.filter(t => {
        return t.parent_staff_id != null && ids.includes(Number(t.parent_staff_id));
      });
    } else {
      // allow where parent_staff_id is null OR in ids
      allTransactions = allTransactions.filter(t => {
        return t.parent_staff_id == null || ids.includes(Number(t.parent_staff_id));
      });
    }

    // -----------------------
    // In-memory filters (search/userId safety net)
    // - search should match user_name, transaction_id, session, or game_title
    // -----------------------
    if (search) {
      const searchLower = search.toLowerCase();
      allTransactions = allTransactions.filter(t =>
        (t.user_name && t.user_name.toLowerCase().includes(searchLower)) ||
        (t.transaction_id && String(t.transaction_id).toLowerCase().includes(searchLower)) ||
        (t.session && String(t.session).toLowerCase().includes(searchLower)) ||
        (t.game_title && String(t.game_title).toLowerCase().includes(searchLower))
      );
    }

    if (userId) {
      allTransactions = allTransactions.filter(t => String(t.user_id) === String(userId));
    }

    // -----------------------
    // Sort + Pagination
    // -----------------------
    allTransactions.sort((a, b) => new Date(b.transaction_timestamp) - new Date(a.transaction_timestamp));

    const totalCount = allTransactions.length;
    const totalPages = Math.ceil(totalCount / Number(limit));
    const paginatedTransactions = allTransactions.slice(offset, offset + Number(limit));

    res.status(200).json({
      transactions: paginatedTransactions,
      pagination: {
        totalCount,
        totalPages,
        currentPage: Number(page),
        limit: Number(limit)
      }
    });

  } catch (error) {
    console.error('Error fetching transaction history:', error);
    res.status(500).json({ error: 'Failed to fetch transaction history' });
  }
};



const getUserTransactionHistory = async (req, res) => {
  try {

    const userId = req.params.userId;
    const {
      page = 1,
      limit = 10,
      search = '',
      game_title = '',
      game_vendor = '',
      date_from = '',
      date_to = '',
      transaction_status = '',
      transaction_type = '',
      game_type = 'sports'
    } = req.query;

    if (!userId) {
      return res.status(400).json({ error: 'User ID is required' });
    }

    const offset = (Number(page) - 1) * Number(limit);

    // IF Type is sports Bet

    if (game_type == 'sports') {
      let data = await getUserTransactionHistoryForSports(userId, req.query)
      return res.status(200).json(data);
    }

    // IF Type is Original Games (3d_game_session)
    if (game_type == '3dGame') {
      let data = await getUserTransactionHistoryForOriginalGames(userId, req.query)
      return res.status(200).json(data);
    }


    // -----------------------
    // Live game history (user-specific)
    // -----------------------
    let liveTransactions = [];
    try {
   //   const apiResponse = await axios.get(`https://api.lagaobet.com/jsGamesv2/history?userid=${userId}`);
            const apiResponse = await axios.get(`https://example.com/jsGamesv2/history?userid=${userId}`);
      if (apiResponse.data && apiResponse.data.success && Array.isArray(apiResponse.data.data)) {
        liveTransactions = apiResponse.data.data.map(transaction => ({
          id: transaction.id,
          transaction_id: transaction.external_transaction_id ? String(transaction.external_transaction_id) : String(transaction.id),
          round_id: transaction.id,
          user_id: transaction.client_user_id,
          session: transaction.serial_number || null,
          transaction_type: (transaction.transaction_type || '').toUpperCase(),
          amount: parseFloat(transaction.amount) || 0,
          currency_code: transaction.currency || null,
          transaction_timestamp: transaction.timestamp ? new Date(transaction.timestamp).toISOString() : new Date().toISOString(),
          reason: (transaction.transaction_type || '').toUpperCase(),
          round_finished: true,
          transaction_status: (transaction.transaction_status || '').toUpperCase(),
          user_name: transaction.username || null,
          game_title: transaction.game_name || null,
          game_vendor: 'live',
          source: 'live_games'
        }));
      }
    } catch (apiError) {
      console.error('Error fetching live game history:', apiError.message || apiError);
      // continue with DB results
    }

    // -----------------------
    // Build conditions & params for bets query (user-specific)
    // -----------------------
    const betsConditions = ['b.uid = $1'];
    const betsParams = [userId];
    let idx = 2;

    if (search) {
      betsConditions.push(`(b.name ILIKE $${idx} OR b.gid::text ILIKE $${idx} OR b.game::text ILIKE $${idx})`);
      betsParams.push(`%${search}%`);
      idx++;
    }

    if (game_title) {
      // b.game might be a name or uuid depending on schema; original code used b.game so we filter by it
      betsConditions.push(`b.game::text ILIKE $${idx}`);
      betsParams.push(`%${game_title}%`);
      idx++;
    }

    if (game_vendor) {
      // match slot or 'internal' as your original logic
      betsConditions.push(`(b.slot ILIKE $${idx} OR $${idx} = 'internal')`);
      betsParams.push(game_vendor);
      idx++;
    }

    if (date_from) {
      betsConditions.push(`b.created >= $${idx}`);
      betsParams.push(date_from);
      idx++;
    }

    if (date_to) {
      betsConditions.push(`b.created <= $${idx}`);
      betsParams.push(date_to);
      idx++;
    }

    if (transaction_status) {
      betsConditions.push(`(CASE WHEN b.hash IS NULL THEN 'ERROR' ELSE 'SUCCESS' END) = $${idx}`);
      betsParams.push(transaction_status.toUpperCase());
      idx++;
    }

    if (transaction_type) {
      betsConditions.push(`(CASE WHEN b.profit > 0 THEN 'WIN' WHEN b.profit < 0 THEN 'LOSS' ELSE 'BET' END) = $${idx}`);
      betsParams.push(transaction_type.toUpperCase());
      idx++;
    }

    const betsWhere = betsConditions.length > 0 ? `WHERE ${betsConditions.join(' AND ')}` : '';

    const betsQuery = `
      SELECT 
        b.gid as id,
        b.gid::text as transaction_id,
        b.gid as round_id,
        b.uid as user_id,
        b.game as game_title,
        NULL::text as session,
        CASE 
          WHEN b.profit > 0 THEN 'WIN'
          WHEN b.profit < 0 THEN 'LOSS'
          ELSE 'BET' 
        END as transaction_type,
        b.amount,
        b.coin as currency_code,
        b.created as transaction_timestamp,
        CASE 
          WHEN b.profit > 0 THEN 'WIN'
          WHEN b.profit < 0 THEN 'LOSS'
          ELSE 'DRAW' 
        END as reason,
        TRUE as round_finished,
        CASE WHEN b.hash IS NULL THEN 'ERROR' ELSE 'SUCCESS' END as transaction_status,
        b.name as user_name,
        b.game as game_title,
        CASE 
          WHEN b.slot IS NOT NULL THEN b.slot 
          ELSE 'internal' 
        END as game_vendor,
        'bets' as source
      FROM bets b
      ${betsWhere}
    `;

    // -----------------------
    // Build conditions & params for gis_transactions query (user-specific)
    // Join to gis_games to get game name
    // -----------------------
    const gisConditions = ['gis.user_id = $1'];
    const gisParams = [userId];
    let gidx = 2;

    if (search) {
      gisConditions.push(`(u.name ILIKE $${gidx} OR gis.transaction_id::text ILIKE $${gidx} OR g.name ILIKE $${gidx})`);
      gisParams.push(`%${search}%`);
      gidx++;
    }

    if (game_title) {
      gisConditions.push(`g.name ILIKE $${gidx}`);
      gisParams.push(`%${game_title}%`);
      gidx++;
    }

    if (game_vendor) {
      // provider column is present in gis_games as 'provider' in your sample
      gisConditions.push(`(g.provider ILIKE $${gidx} OR ($${gidx} = 'internal' AND gis.game_uuid IS NULL))`);
      gisParams.push(game_vendor);
      gidx++;
    }

    // if (date_from) {
    //   gisConditions.push(`COALESCE(gis.transaction_datetime, gis.created_at) >= $${gidx}`);
    //   gisParams.push(date_from);
    //   gidx++;
    // }

    // if (date_to) {
    //   gisConditions.push(`COALESCE(gis.transaction_datetime, gis.created_at) <= $${gidx}`);
    //   gisParams.push(date_to);
    //   gidx++;
    // }

    if (transaction_status) {
      // gis doesn't have hash; we assume success for non-null responses, otherwise you can adjust
      gisConditions.push(`($${gidx} = 'SUCCESS' OR $${gidx} = 'ERROR')`); // placeholder; we'll filter in-memory for accuracy
      gisParams.push(transaction_status.toUpperCase());
      gidx++;
    }

    if (transaction_type) {
      // action column in gis_transactions corresponds to types like 'win','refund','balance'
      gisConditions.push(`UPPER(gis.action::text) = $${gidx}`);
      gisParams.push(transaction_type.toUpperCase());
      gidx++;
    }

    const gisWhere = gisConditions.length > 0 ? `WHERE ${gisConditions.join(' AND ')}` : '';

    const gisQuery = `
      SELECT
        gis.id as id,
        gis.transaction_id::text as transaction_id,
        gis.round_id::text as round_id,
        gis.user_id as user_id,
        gis.session_id::text as session,
        gis.action::text as transaction_type,
        gis.amount,
        gis.currency,
        COALESCE(gis.transaction_datetime, gis.created_at) as transaction_timestamp,
        gis.action::text as reason,
        gis.finished as round_finished,
        'SUCCESS' as transaction_status,
        u.name as user_name,
        g.name as game_title,
        g.provider as game_vendor,
        'gis_transactions' as source
      FROM gis_transactions gis
      LEFT JOIN gisgamesnew g ON gis.game_uuid = g.uuid
      LEFT JOIN users u ON gis.user_id = u.id
      ${gisWhere}
    `;

    // -----------------------
    // Execute DB queries in parallel
    // -----------------------
    const [betsResult, gisResult] = await Promise.all([
      pg.query(betsQuery, betsParams),
      pg.query(gisQuery, gisParams)
    ]);

    const betsRows = betsResult.rows || [];
    const gisRows = gisResult.rows || [];

    console.log(">>>>>>>>>>>>>>>>>>>>>>gid length::",gisRows.length,betsRows.length)

    // Normalize DB rows to unified shape
    const normalizedBets = betsRows.map(r => ({
      id: r.id,
      transaction_id: r.transaction_id ? String(r.transaction_id) : null,
      round_id: r.round_id,
      user_id: r.user_id,
      session: r.session || null,
      transaction_type: (r.transaction_type || '').toUpperCase(),
      amount: parseFloat(r.amount) || 0,
      currency_code: r.currency_code || null,
      transaction_timestamp: r.transaction_timestamp ? new Date(r.transaction_timestamp).toISOString() : new Date().toISOString(),
      reason: (r.reason || '').toUpperCase(),
      round_finished: !!r.round_finished,
      transaction_status: (r.transaction_status || '').toUpperCase(),
      user_name: r.user_name || null,
      game_title: r.game_title || null,
      game_vendor: (r.game_vendor || '').toLowerCase() === 'internal' ? 'internal' : r.game_vendor,
      source: r.source || 'bets'
    }));

    const normalizedGis = gisRows.map(r => ({
      id: r.id,
      transaction_id: r.transaction_id ? String(r.transaction_id) : null,
      round_id: r.round_id,
      user_id: r.user_id,
      session: r.session || null,
      transaction_type: (r.transaction_type || '').toUpperCase(),
      amount: parseFloat(r.amount) || 0,
      currency_code: r.currency || null,
      transaction_timestamp: r.transaction_timestamp ? new Date(r.transaction_timestamp).toISOString() : new Date().toISOString(),
      reason: (r.reason || '').toUpperCase(),
      round_finished: r.round_finished === true || r.round_finished === 't' || r.round_finished === 1,
      transaction_status: (r.transaction_status || '').toUpperCase(),
      user_name: r.user_name || null,
      game_title: r.game_title || null,
      game_vendor: r.game_vendor || null,
      source: r.source || 'gis_transactions'
    }));

    // -----------------------
    // Merge all sources
    // -----------------------
    let allTransactions = [...normalizedBets, ...normalizedGis, ...liveTransactions.map(t => ({
      ...t,
      transaction_type: (t.transaction_type || '').toUpperCase(),
      transaction_status: (t.transaction_status || '').toUpperCase(),
      transaction_timestamp: t.transaction_timestamp ? new Date(t.transaction_timestamp).toISOString() : new Date().toISOString(),
      game_vendor: t.game_vendor || 'live'
    }))];

    // -----------------------
    // In-memory filtering for live results & safety net for all sources
    // Apply filters: search, game_title, game_vendor, date range, transaction_status, transaction_type
    // -----------------------
    if (search || game_title || game_vendor || date_from || date_to || transaction_status || transaction_type) {
      const searchLower = (search || '').toLowerCase();
      const gtLower = (game_title || '').toLowerCase();
      const gvLower = (game_vendor || '').toLowerCase();
      const tfUpper = transaction_status ? transaction_status.toUpperCase() : '';
      const ttUpper = transaction_type ? transaction_type.toUpperCase() : '';

      allTransactions = allTransactions.filter(t => {
        let ok = true;

        if (search) {
          ok = ok && (
            (t.user_name && t.user_name.toLowerCase().includes(searchLower)) ||
            (t.transaction_id && String(t.transaction_id).toLowerCase().includes(searchLower)) ||
            (t.game_title && t.game_title.toLowerCase().includes(searchLower))
          );
        }

        if (game_title) {
          ok = ok && (t.game_title && t.game_title.toLowerCase().includes(gtLower));
        }

        if (game_vendor) {
          ok = ok && ((t.game_vendor || '').toLowerCase() === gvLower);
        }

        // if (date_from) {
        //   ok = ok && (new Date(t.transaction_timestamp) >= new Date(date_from));
        // }

        // if (date_to) {
        //   ok = ok && (new Date(t.transaction_timestamp) <= new Date(date_to));
        // }

        if (transaction_status) {
          ok = ok && ((t.transaction_status || '').toUpperCase() === tfUpper);
        }

        if (transaction_type) {
          ok = ok && ((t.transaction_type || '').toUpperCase() === ttUpper);
        }

        return ok;
      });
    }

    // -----------------------
    // Sort + Paginate
    // -----------------------
    allTransactions.sort((a, b) => new Date(b.transaction_timestamp) - new Date(a.transaction_timestamp));

    const totalCount = allTransactions.length;
    const totalPages = Math.ceil(totalCount / Number(limit));
    const paginatedTransactions = allTransactions.slice(offset, offset + Number(limit));

    res.status(200).json({
      transactions: paginatedTransactions,
      pagination: {
        totalCount,
        totalPages,
        currentPage: Number(page),
        limit: Number(limit)
      }
    });

  } catch (error) {
    console.error('Error fetching user transaction history:', error);
    res.status(500).json({ error: 'Failed to fetch user transaction history' });
  }
};



const getLuckySportsTransactionHistory = async (req, res) => {
  try {
    const { page = 1, limit = 10, search = '', userId = null } = req.query;
    const offset = (Number(page) - 1) * Number(limit);

    // Fetch live game history from the API
    let liveTransactions = [];
    try {
      const apiResponse = await axios.get(`https://api.lagaobet.com/jsGamesv2/historyAdmin`);

      if (apiResponse.data.success && Array.isArray(apiResponse.data.data)) {
        liveTransactions = apiResponse.data.data
          .filter(transaction => transaction.game_name === "LuckySports") // Filter for LuckySports only
          .map(transaction => ({
            id: transaction.id,
            transaction_id: transaction.external_transaction_id,
            round_id: transaction.id,
            user_id: transaction.client_user_id,
            session: transaction.serial_number || null,
            transaction_type: transaction.transaction_type.toUpperCase(),
            amount: parseFloat(transaction.amount),
            currency_code: transaction.currency,
            transaction_timestamp: new Date(transaction.timestamp),
            reason: transaction.transaction_type.toUpperCase(),
            round_finished: true,
            transaction_status: transaction.transaction_status.toUpperCase(),
            user_name: transaction.username || null,
            game_title: transaction.game_name,
            game_vendor: 'live',
            source: 'live_games'
          }));
      }
    } catch (apiError) {
      console.error('Error fetching live game history:', apiError.message);
      // Continue with bets data even if API fails
    }

    // Query for bets table with JOIN to users table - filtered for LuckySports
    let query = `
      SELECT 
        b.gid as id,
        b.gid::text as transaction_id,
        b.gid as round_id,
        b.uid as user_id,
        NULL::text as session,
        CASE 
          WHEN b.profit > 0 THEN 'WIN'
          WHEN b.profit < 0 THEN 'LOSS'
          ELSE 'BET' 
        END as transaction_type,
        b.amount,
        b.coin as currency_code,
        b.created as transaction_timestamp,
        CASE 
          WHEN b.profit > 0 THEN 'WIN'
          WHEN b.profit < 0 THEN 'LOSS'
          ELSE 'DRAW' 
        END as reason,
        TRUE as round_finished,
        CASE WHEN b.hash IS NULL THEN 'ERROR' ELSE 'SUCCESS' END as transaction_status,
        u.name as user_name,
        b.game as game_title,
        CASE 
          WHEN b.slot IS NOT NULL THEN b.slot 
          ELSE 'internal' 
        END as game_vendor,
        'bets' as source
      FROM bets b
      LEFT JOIN users u ON b.uid = u.id
      WHERE b.game = 'LuckySports'
      ${search ? `AND (u.name ILIKE $1 OR b.gid::text ILIKE $1)` : ''}
      ${userId ? `AND b.uid = ${search ? '$2' : '$1'}` : ''}
    `;

    let countQuery = `
      SELECT COUNT(*) 
      FROM bets b
      LEFT JOIN users u ON b.uid = u.id
      WHERE b.game = 'LuckySports'
      ${search ? `AND (u.name ILIKE $1 OR b.gid::text ILIKE $1)` : ''}
      ${userId ? `AND b.uid = ${search ? '$2' : '$1'}` : ''}
    `;

    let params = [];
    if (search) {
      params.push(`%${search}%`);
    }
    if (userId) {
      params.push(userId);
    }

    query += ` ORDER BY transaction_timestamp DESC`;
    const betsParams = [...params];

    const [betsResult, countResult] = await Promise.all([
      pg.query(query, betsParams),
      pg.query(countQuery, betsParams)
    ]);

    // Combine bets and live transactions
    const betsTransactions = betsResult.rows;
    let allTransactions = [...betsTransactions, ...liveTransactions];

    // Apply filters
    if (search) {
      const searchLower = search.toLowerCase();
      allTransactions = allTransactions.filter(t =>
        (t.user_name && t.user_name.toLowerCase().includes(searchLower)) ||
        (t.transaction_id && t.transaction_id.toLowerCase().includes(searchLower)) ||
        (t.session && t.session.toLowerCase().includes(searchLower))
      );
    }

    if (userId) {
      allTransactions = allTransactions.filter(t => t.user_id.toString() === userId);
    }

    // Sort by transaction_timestamp (latest first)
    allTransactions.sort((a, b) => new Date(b.transaction_timestamp) - new Date(a.transaction_timestamp));

    // Apply pagination
    const totalCount = allTransactions.length;
    const totalPages = Math.ceil(totalCount / Number(limit));
    const paginatedTransactions = allTransactions.slice(offset, offset + Number(limit));

    res.status(200).json({
      transactions: paginatedTransactions,
      pagination: {
        totalCount,
        totalPages,
        currentPage: Number(page),
        limit: Number(limit)
      }
    });

  } catch (error) {
    console.error('Error fetching LuckySports transaction history:', error);
    res.status(500).json({ error: 'Failed to fetch LuckySports transaction history' });
  }
};


// const getUserTransactionHistory = async (req, res) => {
//   try {
//     const userId = req.params.userId;
//     const { page = 1, limit = 10, search = '' } = req.query;

//     if (!userId) {
//       return res.status(400).json({ error: 'User ID is required' });
//     }

//     const offset = (Number(page) - 1) * Number(limit);

//     // Fetch live game history from the API
//     let liveTransactions = [];
//     try {
//       const apiResponse = await axios.get(`https://api.lagaobet.com/jsGamesv2/history?userid=${userId}`);
//       if (apiResponse.data.success && Array.isArray(apiResponse.data.data)) {
//         liveTransactions = apiResponse.data.data.map(transaction => ({
//           id: transaction.id,
//           transaction_id: transaction.external_transaction_id,
//           round_id: transaction.id,
//           user_id: transaction.client_user_id,
//           session: transaction.serial_number || null,
//           transaction_type: transaction.transaction_type.toUpperCase(),
//           amount: parseFloat(transaction.amount),
//           currency_code: transaction.currency,
//           transaction_timestamp: new Date(transaction.timestamp),
//           reason: transaction.transaction_type.toUpperCase(),
//           round_finished: true,
//           transaction_status: transaction.transaction_status.toUpperCase(),
//           user_name: null, // API doesn't provide user name
//           game_title: transaction.game_name,
//           game_vendor: 'live', // Assuming live games have a specific vendor
//           source: 'live_games'
//         }));
//       }
//     } catch (apiError) {
//       console.error('Error fetching live game history:', apiError.message);
//       // Continue with bets data even if API fails
//     }

//     // Query for bets table
//     let query = `
//       SELECT 
//         b.gid as id,
//         b.gid::text as transaction_id,
//         b.gid as round_id,
//         b.uid as user_id,
//         NULL::text as session,
//         CASE 
//           WHEN b.profit > 0 THEN 'WIN'
//           WHEN b.profit < 0 THEN 'LOSS'
//           ELSE 'BET' 
//         END as transaction_type,
//         b.amount,
//         b.coin as currency_code,
//         b.created as transaction_timestamp,
//         CASE 
//           WHEN b.profit > 0 THEN 'WIN'
//           WHEN b.profit < 0 THEN 'LOSS'
//           ELSE 'DRAW' 
//         END as reason,
//         TRUE as round_finished,
//         CASE WHEN b.hash IS NULL THEN 'ERROR' ELSE 'SUCCESS' END as transaction_status,
//         b.name as user_name,
//         b.game as game_title,
//         CASE 
//           WHEN b.slot IS NOT NULL THEN b.slot 
//           ELSE 'internal' 
//         END as game_vendor,
//         'bets' as source
//       FROM bets b
//       WHERE b.uid = $1
//       ${search ? `AND (b.name ILIKE $2 OR b.gid::text ILIKE $2)` : ''}
//     `;

//     let countQuery = `
//       SELECT COUNT(*) 
//       FROM bets b
//       WHERE b.uid = $1
//       ${search ? `AND (b.name ILIKE $2 OR b.gid::text ILIKE $2)` : ''}
//     `;

//     let params = [userId];
//     if (search) {
//       params.push(`%${search}%`);
//     }

//     const transactionsResult = await pg.query(query, params);

//     const countParams = [userId];
//     if (search) {
//       countParams.push(`%${search}%`);
//     }

//     const countResult = await pg.query(countQuery, countParams);

//     // Combine bets and live transactions
//     const betsTransactions = transactionsResult.rows;
//     let allTransactions = [...betsTransactions, ...liveTransactions];

//     // Apply search filter to live transactions
//     if (search) {
//       const searchLower = search.toLowerCase();
//       allTransactions = allTransactions.filter(t => 
//         (t.user_name && t.user_name.toLowerCase().includes(searchLower)) ||
//         (t.transaction_id && t.transaction_id.toLowerCase().includes(searchLower)) ||
//         (t.session && t.session.toLowerCase().includes(searchLower))
//       );
//     }

//     // Sort by transaction_timestamp (latest first)
//     allTransactions.sort((a, b) => new Date(b.transaction_timestamp) - new Date(a.transaction_timestamp));

//     // Apply pagination
//     const totalCount = allTransactions.length;
//     const totalPages = Math.ceil(totalCount / Number(limit));
//     const paginatedTransactions = allTransactions.slice(offset, offset + Number(limit));

//     res.status(200).json({
//       transactions: paginatedTransactions,
//       pagination: {
//         totalCount,
//         totalPages,
//         currentPage: Number(page),
//         limit: Number(limit)
//       }
//     });

//   } catch (error) {
//     console.error('Error fetching user transaction history:', error);
//     res.status(500).json({ error: 'Failed to fetch user transaction history' });
//   }
// };

// Get transaction summary stats
const getTransactionStats = async (req, res) => {
  try {
    const { userId = null } = req.query;

    let query = `
      SELECT 
        (
          (SELECT COUNT(*) FROM js_game_transactions ${userId ? 'WHERE user_id = $1' : ''}) +
          (SELECT COUNT(*) FROM bets ${userId ? 'WHERE uid = $1' : ''})
        ) as total_transactions,
        (
          (SELECT COUNT(*) FROM js_game_transactions WHERE amount > 0 ${userId ? 'AND user_id = $1' : ''}) +
          (SELECT COUNT(*) FROM bets WHERE profit > 0 ${userId ? 'AND uid = $1' : ''})
        ) as winning_transactions,
        (
          (SELECT COUNT(*) FROM js_game_transactions WHERE amount < 0 ${userId ? 'AND user_id = $1' : ''}) +
          (SELECT COUNT(*) FROM bets WHERE profit < 0 ${userId ? 'AND uid = $1' : ''})
        ) as losing_transactions,
        (
          (SELECT COALESCE(SUM(amount), 0) FROM js_game_transactions ${userId ? 'WHERE user_id = $1' : ''}) +
          (SELECT COALESCE(SUM(profit), 0) FROM bets ${userId ? 'WHERE uid = $1' : ''})
        ) as net_amount
    `;

    let params = [];
    if (userId) {
      params.push(userId);
    }

    const result = await pg.query(query, params);
    res.status(200).json(result.rows[0]);

  } catch (error) {
    console.error('Error fetching transaction stats:', error);
    res.status(500).json({ error: 'Failed to fetch transaction stats' });
  }
};
const getUserBetWinCount = async (req, res) => {
  const userId = req.params.userId;

  if (!userId || isNaN(userId)) {
    return res.status(400).json({ error: 'Invalid userId' });
  }

  try {
    // Query bets table for bet and win counts
    const betsQuery = `
      SELECT 
        COUNT(*) as bet_count, 
        COUNT(CASE WHEN profit > 0 THEN 1 END) as win_count 
      FROM bets 
      WHERE uid = $1
    `;
    const betsResult = await pg.query(betsQuery, [userId]);

    let betsBetCount = 0;
    let betsWinCount = 0;

    if (betsResult.rows && betsResult.rows.length > 0) {
      betsBetCount = parseInt(betsResult.rows[0].bet_count) || 0;
      betsWinCount = parseInt(betsResult.rows[0].win_count) || 0;
    }

    // Query game transaction tables (gis + js) for bet and win counts
    const txQuery = `
      SELECT transaction_type, COUNT(*) as count
      FROM (
        SELECT LOWER(action) as transaction_type FROM gis_transactions WHERE user_id = $1
        UNION ALL
        SELECT LOWER(transaction_type) as transaction_type FROM js_game_transactions WHERE user_id = $1
      ) t
      WHERE transaction_type IN ('bet', 'win')
      GROUP BY transaction_type
    `;
    const txResult = await pg.query(txQuery, [userId]);

    let txBetCount = 0;
    let txWinCount = 0;

    if (txResult.rows && txResult.rows.length > 0) {
      txResult.rows.forEach(row => {
        const count = parseInt(row.count) || 0;
        if (row.transaction_type === 'bet') {
          txBetCount += count;
        } else if (row.transaction_type === 'win') {
          txWinCount += count;
        }
      });
    }

    // Combine counts from both tables
    const result = {
      betCount: betsBetCount + txBetCount,
      winCount: betsWinCount + txWinCount
    };

    console.log(`User ${userId} - Bet Count: ${result.betCount}, Win Count: ${result.winCount} (Bets table: ${betsBetCount}, ${betsWinCount}; Transactions table: ${txBetCount}, ${txWinCount})`);

    res.status(200).json(result);
  } catch (error) {
    console.error('Error fetching bet and win counts:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

// const getUserTransactionHistoryForSports = async (user_id, query) => {
//   try {
//     const userId = user_id;

//     const {
//       page = 1,
//       limit = 10,
//       date_from = '',
//       status,
//       type,

//     } = query;

//     if (!userId) {
//       return res.status(400).json({ error: 'User ID is required' });
//     }

//     const offset = (Number(page) - 1) * Number(limit);

//     // -----------------------
//     // Build WHERE conditions
//     // -----------------------
//     // const conditions = ['cl.user_id = $1', `cl.reason != 'refund'`];
//     const conditions = ['cl.user_id = $1'];

//     const params = [userId];
//     let idx = 2;

//     if (status) {
//       conditions.push(`sb.result_status = $${idx}`);
//       params.push(status);
//       idx++;
//     }

//     if (type) {
//       conditions.push(`sb.status = $${idx}`);
//       params.push(type);
//       idx++;
//     }

//     // if (user_id) {
//     //   conditions.push(`cl.created_at >= $${idx}`);
//     //   params.push(date_from);
//     //   idx++;
//     // }

//     // if (date_from) {
//     //   conditions.push(`cl.created_at >= $${idx}`);
//     //   params.push(date_from);
//     //   idx++;
//     // }
//     const whereClause = `WHERE ${conditions.join(' AND ')}`;

//     // -----------------------
//     // Main Query
//     // -----------------------

//     const dataQuery = `
//   SELECT
//     cl.id,
//     cl.user_id,
//     cl.currency,
//     cl.amount,
//     cl.reason,
//     cl.description,
//     cl.eventid,
//     cl.job_id,
//     cl.match_id,
//     cl.meta,
//     cl.market_type,
//     cl.sport_id,
//     cl.commission,
//     cl.netamount,
//     cl.profit,
//     cl.created_at,

//     /* ---------- Bet Category ---------- */
//     CASE
//       WHEN cl.sport_id IS NULL THEN 'casino'
//       ELSE 'sport'
//     END AS bet_category,

//     /* ---------- Sports Bet Fields ---------- */
//     sb.match_title,
//     sb.selection_name AS sport_selection,
//     sb.market_type    AS sport_market,
//     sb.stake_amount   AS sport_stake,
//     sb.odds           AS sport_odds,
//     sb.result_status,
//     sb.status,
//     /* ---------- Unified Bet Type ---------- */
//     CASE
//       WHEN cl.sport_id IS NOT NULL THEN sb.bet_type
//       ELSE 'null'
//     END AS bet_type

//   FROM credits_ledger cl

//   LEFT JOIN "SportsBet" sb
//     ON cl.sport_id IS NOT NULL
//     AND cl.job_id = sb.job_id
//     AND cl.user_id = sb.user_id::text
//    ${whereClause}

//   ORDER BY cl.created_at DESC
//   LIMIT $${idx} OFFSET $${idx + 1}
// `;

//     const countQuery = `
//       SELECT COUNT(*) 
//       FROM credits_ledger cl
//       ${whereClause}
//     `;

//     // Add pagination params
//     params.push(Number(limit), offset);

//     const [dataResult, countResult] = await Promise.all([
//       pg.query(dataQuery, params),
//       pg.query(countQuery, params.slice(0, idx - 1))]);

//     const totalCount = Number(countResult.rows[0].total);
//     const totalPages = Math.ceil(totalCount / limit);
//     const currentPage = Number(page);
//     const paginatedTransactions = dataResult.rows;

//     return {
//       success: true,
//       transactions: paginatedTransactions,
//       pagination: {
//         totalCount,
//         totalPages,
//         currentPage,
//         limit: Number(limit)
//       }
//     };


//     // -----------------------
//     // Count Query (for pagination)
//     // -----------------------
//     // const countQuery = `
//     //   SELECT COUNT(*) 
//     //   FROM "SportsBet" sb
//     //   ${whereClause}
//     // `;

//     // // -----------------------
//     // // Execute Queries
//     // // -----------------------
//     // const [dataResult, countResult] = await Promise.all([
//     //   pg.query(dataQuery, params),
//     //   pg.query(countQuery, params.slice(0, idx - 1)) // exclude limit & offset
//     // ]);

//     // const transactions = dataResult.rows;
//     // const totalCount = Number(countResult.rows[0].count);
//     // const totalPages = Math.ceil(totalCount / Number(limit));

//     // // -----------------------
//     // // Response
//     // // -----------------------

//     // let data = {
//     //   transactions,
//     //   pagination: {
//     //     totalCount,
//     //     totalPages,
//     //     currentPage: Number(page),
//     //     limit: Number(limit)
//     //   }
//     // }

//     // return { success: true, data }

//   } catch (error) {
//     console.error('Error fetching user transaction history:', error);
//     return { success: false, message: error?.message, data: null }
//   }
// };



const getUserTransactionHistoryForSports = async (user_id, query) => {
  try {
    const userId = user_id;

    const {
      page = 1,
      limit = 30,
      date_from = '',
      status,
      type,

    } = query;

    if (!userId) {
      return res.status(400).json({ error: 'User ID is required' });
    }

    const offset = (Number(page) - 1) * Number(limit);

    // -----------------------
    // Build WHERE conditions
    // -----------------------
    // const conditions = ['cl.user_id = $1', `cl.reason != 'refund'`];
    const conditions = ['sb.user_id = $1'];

    const params = [userId];
    let idx = 2;

    if (status) {
      conditions.push(`sb.result_status = $${idx}`);
      params.push(status);
      idx++;
    }

    if (type) {
      conditions.push(`sb.status = $${idx}`);
      params.push(type);
      idx++;
    }

    // if (user_id) {
    //   conditions.push(`cl.created_at >= $${idx}`);
    //   params.push(date_from);
    //   idx++;
    // }

    // if (date_from) {
    //   conditions.push(`cl.created_at >= $${idx}`);
    //   params.push(date_from);
    //   idx++;
    // }
    const whereClause = `WHERE ${conditions.join(' AND ')}`;

    // -----------------------
    // Main Query
    // -----------------------

    // Drive FROM "SportsBet" so OPEN/unsettled bets (which have no credits_ledger
    // row yet) are always included. Join the settlement ledger 1:1 on bet_id
    // (job_id is NULL on open bets and not unique per bet, so it both dropped open
    // bets and fan-out duplicated settled ones). Bet placement currently leaves
    // sb.created_at NULL, so expose a robust timestamp that falls back to the
    // settlement/update time and finally the match start, and order by it.
    const dataQuery = `
  SELECT
    sb.id              AS id,            /* stable per-bet id (was cl.id, NULL for open bets) */
    cl.id              AS ledger_id,
    sb.user_id         AS user_id,
    cl.currency,
    cl.amount,
    cl.reason,
    cl.description,
    cl.eventid,
    cl.job_id,
    cl.match_id,
    cl.meta,
    COALESCE(cl.market_type, sb.market_type) AS market_type,
    cl.sport_id,
    cl.commission,
    cl.netamount,
    cl.profit,
    COALESCE(sb.created_at, cl.created_at, sb.updated_at, sb.match_start_time) AS created_at,

    /* ---------- Bet Category ---------- */
    'sport' AS bet_category,

    /* ---------- Sports Bet Fields ---------- */
    sb.match_title,
    sb.selection_name AS sport_selection,
    sb.market_type    AS sport_market,
    sb.stake_amount   AS sport_stake,
    sb.liability      AS liability,
    sb.odds           AS sport_odds,
    sb.result_status,
    sb.status,
    sb.created_at     AS bet_created_at,
    sb.updated_at     AS bet_updated_at,
    /* ---------- Unified Bet Type ---------- */
    sb.bet_type AS bet_type

  FROM "SportsBet" sb

  LEFT JOIN credits_ledger cl
    ON cl.bet_id = sb.id
    AND cl.user_id = sb.user_id::text
   ${whereClause}

  ORDER BY COALESCE(sb.created_at, cl.created_at, sb.updated_at, sb.match_start_time) DESC NULLS LAST, sb.id DESC
  LIMIT $${idx} OFFSET $${idx + 1}
`;

    const countQuery = `
      SELECT COUNT(*)
      FROM "SportsBet" sb
      ${whereClause}
    `;

    // Add pagination params
    params.push(Number(limit), offset);

    let [dataResult, countResult] = await Promise.all([
      pg.query(dataQuery, params),
      pg.query(countQuery, params.slice(0, idx - 1)),
    ]);

    const totalCount = Number(countResult.rows[0].count);
    const totalPages = Math.ceil(totalCount / limit);
    const currentPage = Number(page);
    const paginatedTransactions = dataResult.rows;

    return {
      success: true,
      transactions: paginatedTransactions,
      pagination: {
        totalCount,
        totalPages,
        currentPage,
        limit: Number(limit)
      }
    };

  } catch (error) {
    console.error('Error fetching user transaction history:', error);
    return { success: false, message: error?.message, data: null }
  }
};


// Old version — read sessions from our local 3d_game_session table. Kept for reference.
// const getUserTransactionHistoryForOriginalGames = async (user_id, query) => {
//   try {
//     const { page = 1, limit = 10 } = query;
//     const offset = (Number(page) - 1) * Number(limit);
//
//     const result = await pg.query(
//       `SELECT * FROM "3d_game_session" WHERE user_id = $1 ORDER BY created_at DESC`,
//       [user_id]
//     );
//
//     const transactions = result.rows.map(r => ({
//       session_id: r.session_id,
//       user_id: r.user_id,
//       initial_amount: parseFloat(r.initial_amount) || 0,
//       final_amount: parseFloat(r.final_amount) || 0,
//       net_result: parseFloat(r.net_result) || 0,
//       status: !r.session_closed ? 'PENDING' : (Number(r.net_result) > 0 ? 'WIN' : 'LOSS'),
//       created_at: r.created_at
//     })).filter(t => t.initial_amount !== t.final_amount);
//
//     const totalCount = transactions.length;
//     return {
//       success: true,
//       transactions: transactions.slice(offset, offset + Number(limit)),
//       pagination: {
//         totalCount,
//         totalPages: Math.ceil(totalCount / Number(limit)),
//         currentPage: Number(page),
//         limit: Number(limit)
//       }
//     };
//
//   } catch (error) {
//     console.error('Error fetching original games history:', error);
//     return { success: false, message: error?.message, data: null }
//   }
// };

// New version — match-level history from the MyApp provider API (paginated server-side).
const getUserTransactionHistoryForOriginalGames = async (user_id, query) => {
  try {
    const { page = 1, limit = 10 } = query;
    const offset = (Number(page) - 1) * Number(limit);

    const { data } = await axios.post(
      'https://example.com/api/v1/user/game-history',
      { userId: String(user_id), offset, limit: Number(limit) },
      { timeout: 15000 }
    );

    if (!data || !data.success) {
      return { success: false, message: (data && data.message) || 'Failed to fetch game history', data: null };
    }

    const transactions = (data.list || []).map(m => ({
      match_id: m.matchId,
      game: m.game,
      game_type: m.gameType,
      total_bet: Number(m.totalBet) || 0,
      won: Number(m.won) || 0,
      net_result: Number(m.profitLoss) || 0,
      status: m.isWinner ? 'WIN' : (Number(m.profitLoss) < 0 ? 'LOSS' : 'DRAW'),
      created_at: m.playedAt
    }));

    const totalCount = Number(data.total) || 0;
    return {
      success: true,
      transactions,
      pagination: {
        totalCount,
        totalPages: Math.ceil(totalCount / Number(limit)),
        currentPage: Number(page),
        limit: Number(limit)
      }
    };

  } catch (error) {
    console.error('Error fetching original games history:', error?.response?.data || error.message);
    return { success: false, message: error?.message, data: null }
  }
};


const getUserSportsBetsHistory = async (req, res) => {

  try {
    // const { user_id } = req.params;

    // if (!user_id) {
    //   return res.status(400).json({ message: 'User ID is required' });
    // }

    console.log("::::::::::::::::::::::::histor>>>>>>>>>>>>>>>")
    const { page = 1, limit = 10, user_id } = req.query;

    if (!user_id) {
      return res.status(400).json({ message: 'User ID is required' });
    }
    const offset = (Number(page) - 1) * Number(limit);

    const conditions = [];
    let idx = 1;

    if (user_id) {
      conditions.push(`user_id = $${idx}`);
      idx++;
    }

    const whereClause = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

    const dataQuery = `
    SELECT * FROM "SportsBet" ${whereClause} ORDER BY created_at DESC LIMIT $2 OFFSET $3
    `;


    const statsQuery = `
    SELECT * FROM "SportsBet" WHERE user_id=$1`;
    const [dataResult, statsResult] = await Promise.all([
      pg.query(dataQuery, [user_id, limit, offset]),
      pg.query(statsQuery, [user_id])
    ]);

    const stats = statsResult.rows || [];

    const totalCount = Number(stats?.length);
    const totalPages = Math.ceil(totalCount / limit);
    const currentPage = Number(page);
    const paginatedTransactions = dataResult.rows;


    const statsData = {
      totalBets: totalCount,
      totalWins: stats.filter(item => item.result_status === 'won').length,
      totalLosses: stats.filter(item => item.result_status === 'lost').length,
      totalDraws: stats.filter(item => item.result_status === 'draw').length,
      totalPending: stats.filter(item => item.result_status === 'pending').length,
    }

    return res.status(200).json({
      success: true,
      list: paginatedTransactions,
      pagination: {
        totalCount,
        totalPages,
        currentPage,
        limit: Number(limit)
      },
      stats: statsData
    });
  } catch (error) {
    console.error('Error fetching user Bet history:', error);
    return res.status(500).json({ success: false, message: error?.message, data: null })
  }
}

const getAllSportsBetsAdmin = async (req, res) => {
  try {
    const { page = 1, limit = 10, status, game_type } = req.query;

    const offset = (Number(page) - 1) * Number(limit);

    let conditions = [];
    let values = [];
    let idx = 1;

    // Staff visibility filter
    const _staffId = req.headers['x-staff-id'];
    if (_staffId) {
      const { visibleStaffIds } = require('../system/helpers/staffTree');
      const sids = (await visibleStaffIds(_staffId)).map(Number);
      if (!sids.includes(1)) {
        const uRes = await pg.query(
          `SELECT array_agg(id) AS uids FROM users WHERE parent_staff_id = ANY($1::bigint[])`,
          [sids]
        );
        const uids = uRes.rows[0]?.uids || [-1];
        conditions.push(`user_id = ANY($${idx}::bigint[])`);
        values.push(uids);
        idx++;
      }
    }

    if (status) {
      conditions.push(`status = $${idx}`);
      values.push(status);
      idx++;
    }

    if (game_type) {
      conditions.push(`game_type = $${idx}`);
      values.push(game_type);
      idx++;
    }

    const whereClause = conditions.length
      ? `WHERE ${conditions.join(" AND ")}`
      : "";

    // ✅ Main data query
    const dataQuery = `
      SELECT *,
             COALESCE((SELECT du.is_demo FROM users du WHERE du.id = "SportsBet".user_id), false) AS is_demo
      FROM "SportsBet"
      ${whereClause}
      ORDER BY created_at DESC
      LIMIT $${idx} OFFSET $${idx + 1}
    `;

    values.push(Number(limit), Number(offset));

    // ✅ Optimized stats query (NO full table load 🚀)
    const statsQuery = `
      SELECT 
        COUNT(*) AS total_bets,
        COUNT(*) FILTER (WHERE result_status = 'won') AS total_wins,
        COUNT(*) FILTER (WHERE result_status = 'loss') AS total_losses,
        COUNT(*) FILTER (WHERE result_status = 'draw') AS total_draws,
        COUNT(*) FILTER (WHERE result_status = 'pending') AS total_pending
      FROM "SportsBet"
      ${whereClause}
    `;

    const countQuery = `
      SELECT COUNT(*) FROM "SportsBet" ${whereClause}
    `;

    const [dataResult, statsResult, countResult] = await Promise.all([
      pg.query(dataQuery, values),
      pg.query(statsQuery, values.slice(0, values.length - 2)), // remove limit & offset
      pg.query(countQuery, values.slice(0, values.length - 2))
    ]);

    const totalCount = Number(countResult.rows[0].count);
    const totalPages = Math.ceil(totalCount / limit);

    return res.status(200).json({
      success: true,
      list: dataResult.rows,
      pagination: {
        totalCount,
        totalPages,
        currentPage: Number(page),
        limit: Number(limit)
      },
      stats: {
        totalBets: Number(statsResult.rows[0].total_bets),
        totalWins: Number(statsResult.rows[0].total_wins),
        totalLosses: Number(statsResult.rows[0].total_losses),
        totalDraws: Number(statsResult.rows[0].total_draws),
        totalPending: Number(statsResult.rows[0].total_pending)
      }
    });

  } catch (error) {
    console.error("Error fetching all bets (admin):", error);
    return res.status(500).json({
      success: false,
      message: error.message,
      data: null
    });
  }
};

module.exports = {
  getTransactionHistory,
  getUserTransactionHistory,
  getTransactionStats,
  getUserBetWinCount,
  getLuckySportsTransactionHistory,
  getUserSportsBetsHistory,
  getAllSportsBetsAdmin,
};