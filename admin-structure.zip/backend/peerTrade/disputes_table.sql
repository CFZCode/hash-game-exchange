CREATE TABLE IF NOT EXISTS p2p_disputes (
    id SERIAL PRIMARY KEY,
    order_id INTEGER NOT NULL,
    order_no VARCHAR(50),
    user_id VARCHAR(100),
    order_type VARCHAR(10) DEFAULT 'BUY',
    reason VARCHAR(100) NOT NULL,
    message TEXT,
    screenshot VARCHAR(255),
    status VARCHAR(20) DEFAULT 'OPEN',
    admin_note TEXT,
    resolved_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
