const express = require('express');
const router = express.Router();
const controller = require('./controler');
const upload = require('./middleware'); // multer middleware


// =============================
// ADMIN ROUTES
// =============================
router.post('/admin/p2p/payment-type', controller.createPaymentType);
router.post('/admin/p2p/payment-account', upload.single('qr_image'), controller.createPaymentAccount);
router.post('/admin/p2p/create-offer', controller.createOffer);
router.post('/admin/p2p/release/:orderId', controller.releaseOrder);

router.get('/admin/p2p/payment-types', controller.getPaymentTypes);
router.get('/admin/p2p/payment-accounts', controller.getPaymentAccounts);
router.get('/admin/p2p/offers', controller.getAdminOffers);
router.get('/admin/p2p/orders', controller.getAdminOrders);
router.get('/admin/p2p/sell-orders', controller.getAdminSellOrders);

router.post('/admin/p2p/cancel/:orderId', controller.cancelOrder);
router.delete('/admin/p2p/order/:orderId', controller.deleteOrder);
router.put('/admin/p2p/order/:orderId/status', controller.updateOrderStatus);


router.post(
    '/admin/p2p/sell-release/:orderId',
    upload.single('admin_payment_proof'),
    controller.releaseSellOrder
);
router.post('/admin/p2p/sell-release/:orderId', controller.releaseSellOrder);
router.post('/admin/p2p/sell-cancel/:orderId', controller.cancelSellOrder);

router.get('/admin/p2p/disputes', controller.getAdminDisputes);
router.put('/admin/p2p/dispute/:disputeId/status', controller.updateDisputeStatus);


// =============================
// USER ROUTES
// =============================
router.get('/p2p/offers', controller.getOffers);
router.get('/p2p/sell-orders/:userId', controller.getUserSellOrders);
router.post('/p2p/create-order', controller.createOrder);
router.get('/p2p/order/:orderId', controller.getOrderDetails);
router.get('/p2p/orders/:userId', controller.getUserOrders);

router.post(
    '/p2p/create-sell-order',
    upload.single('qr_image'),
    controller.createSellOrder
);
router.post(
    '/p2p/mark-paid/:orderId',
    upload.single('file'),
    controller.markPaid
);




router.post(
    '/p2p/dispute',
    upload.single('screenshot'),
    controller.createDispute
);


module.exports = router;