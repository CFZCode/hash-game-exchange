const pg = require('../General/Model');

const generateOrderNo = () =>
    'P2P' + Date.now() + Math.floor(Math.random() * 1000);

// Time remaining helper
const getTimeRemaining = (expiresAt) => {
    if (!expiresAt) return { expired: false, remaining: null };
    const now = new Date();
    const end = new Date(expiresAt);
    const diff = end - now;

    if (diff <= 0) return { expired: true, remaining: null };

    const minutes = Math.floor(diff / (1000 * 60));
    const seconds = Math.floor((diff % (1000 * 60)) / 1000);

    return {
        expired: false,
        remaining: { minutes, seconds, total_ms: diff }
    };
};

// Add time remaining to order rows
const addTimeInfo = (rows) => {
    return rows.map(row => ({
        ...row,
        ...getTimeRemaining(row.expires_at)
    }));
};

module.exports = {

    // =============================
    // ADMIN: CREATE PAYMENT TYPE
    // =============================
    createPaymentType: async (req, res) => {

        const { name, code } = req.body;

        try {

            const result = await pg.query(`
                INSERT INTO p2p_payment_types (name, code)
                VALUES ($1,$2)
                RETURNING *
            `, [name, code]);

            res.json(result.rows[0]);

        } catch (err) {

            res.status(500).json({ error: err.message });

        }
    },


    // =============================
    // ADMIN: CREATE PAYMENT ACCOUNT
    // =============================
    createPaymentAccount: async (req, res) => {

        const {
            payment_type_id,
            account_name,
            account_number,
            ifsc_code,
            upi_id,
            extra_details
        } = req.body;

        const qr_image = req.file ? req.file.filename : null;

        try {

            const result = await pg.query(`
                INSERT INTO p2p_payment_accounts
                (payment_type_id, account_name, account_number, ifsc_code, upi_id, qr_image, extra_details)
                VALUES ($1,$2,$3,$4,$5,$6,$7)
                RETURNING *
            `, [
                payment_type_id,
                account_name || null,
                account_number || null,
                ifsc_code || null,
                upi_id || null,
                qr_image || null,
                extra_details || null
            ]);

            res.json(result.rows[0]);

        } catch (err) {

            res.status(500).json({ error: err.message });

        }
    },


    // =============================
    // ADMIN: CREATE OFFER
    // =============================
    createOffer: async (req, res) => {

        const {
            username,
            coin,
            fiat,
            price,
            min_limit,
            max_limit,
            available_amount,
            payment_account_ids,
            payment_time,
            is_featured,
            is_verified,
            is_kyc_verified,
            segment
        } = req.body;

        try {

            await pg.query('BEGIN');

            const avatar_letter = username.charAt(0).toUpperCase();

            const offer = await pg.query(`
                INSERT INTO p2p_offers (
                    username,
                    avatar_letter,
                    coin,
                    fiat,
                    price,
                    min_limit,
                    max_limit,
                    available_amount,
                    payment_time,
                    is_featured,
                    is_verified,
                    is_kyc_verified,
                    segment
                )
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
                RETURNING id
            `, [
                username,
                avatar_letter,
                coin,
                fiat,
                price,
                min_limit,
                max_limit,
                available_amount,
                payment_time || 30,
                is_featured || false,
                is_verified || false,
                is_kyc_verified || false,
                segment || 'BUY'
            ]);

            const offerId = offer.rows[0].id;

            for (const pid of payment_account_ids) {

                await pg.query(`
                    INSERT INTO p2p_offer_payments
                    (offer_id, payment_account_id)
                    VALUES ($1,$2)
                `, [offerId, pid]);
            }

            await pg.query('COMMIT');

            res.json({ message: 'Offer created successfully' });

        } catch (err) {

            await pg.query('ROLLBACK');
            res.status(500).json({ error: err.message });

        }
    },


    // =============================
    // USER: GET OFFERS
    // =============================
    getOffers: async (req, res) => {

        const { segment, coin, fiat } = req.query;

        try {

            const result = await pg.query(`
                SELECT
                    o.*,
                    json_agg(
                        json_build_object(
                            'id', pa.id,
                            'type', pt.name
                        )
                    ) AS payments
                FROM p2p_offers o
                LEFT JOIN p2p_offer_payments op ON op.offer_id = o.id
                LEFT JOIN p2p_payment_accounts pa ON pa.id = op.payment_account_id
                LEFT JOIN p2p_payment_types pt ON pt.id = pa.payment_type_id
                WHERE o.status = true
                AND ($1::text IS NULL OR o.segment = $1)
                AND ($2::text IS NULL OR o.coin = $2)
                AND ($3::text IS NULL OR o.fiat = $3)
                GROUP BY o.id
                ORDER BY o.is_featured DESC, o.price ASC
            `, [
                segment || null,
                coin || null,
                fiat || null
            ]);

            res.json(result.rows);

        } catch (err) {

            res.status(500).json({ error: err.message });

        }
    },


    // =============================
    // USER: CREATE ORDER (BUY)
    // =============================
    createOrder: async (req, res) => {

        const {
            user_id,
            offer_id,
            crypto_amount,
            payment_account_id
        } = req.body;

        try {

            await pg.query('BEGIN');

            const offerData = await pg.query(
                `SELECT * FROM p2p_offers WHERE id=$1`,
                [offer_id]
            );

            if (offerData.rowCount === 0)
                throw new Error('Offer not found');

            const offer = offerData.rows[0];

            if (offer.available_amount < crypto_amount)
                throw new Error('Insufficient liquidity');

            const fiat_amount = crypto_amount * offer.price;
            const orderNo = generateOrderNo();
            const paymentTime = offer.payment_time || 30; // minutes

            await pg.query(`
                UPDATE p2p_offers
                SET available_amount = available_amount - $1
                WHERE id=$2
            `, [crypto_amount, offer_id]);

            const order = await pg.query(`
                INSERT INTO p2p_orders (
                    order_no,
                    user_id,
                    offer_id,
                    payment_account_id,
                    coin,
                    fiat,
                    price,
                    crypto_amount,
                    fiat_amount,
                    expires_at
                )
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9, NOW() + ($10 || ' minutes')::INTERVAL)
                RETURNING *
            `, [
                orderNo,
                user_id,
                offer_id,
                payment_account_id,
                offer.coin,
                offer.fiat,
                offer.price,
                crypto_amount,
                fiat_amount,
                paymentTime
            ]);

            await pg.query('COMMIT');

            const row = order.rows[0];
            res.json({
                ...row,
                payment_time: paymentTime,
                ...getTimeRemaining(row.expires_at)
            });

        } catch (err) {

            await pg.query('ROLLBACK');
            res.status(500).json({ error: err.message });

        }
    },


    // =============================
    // USER: GET ORDER DETAILS
    // =============================
    getOrderDetails: async (req, res) => {

        const { orderId } = req.params;

        try {

            const result = await pg.query(`
                SELECT
                    o.*,
                    pa.*,
                    pt.name AS payment_name,
                    off.payment_time
                FROM p2p_orders o
                JOIN p2p_payment_accounts pa ON pa.id = o.payment_account_id
                JOIN p2p_payment_types pt ON pt.id = pa.payment_type_id
                JOIN p2p_offers off ON off.id = o.offer_id
                WHERE o.id = $1
            `, [orderId]);

            if (result.rowCount === 0) {
                return res.status(404).json({ error: 'Order not found' });
            }

            const row = result.rows[0];
            res.json({
                ...row,
                ...getTimeRemaining(row.expires_at)
            });

        } catch (err) {

            res.status(500).json({ error: err.message });

        }
    },


    // =============================
    // USER: MARK PAID
    // =============================
    markPaid: async (req, res) => {

        const { orderId } = req.params;
        const { utr_number } = req.body;

        try {

            // Check if order is expired
            const orderCheck = await pg.query(
                `SELECT status, expires_at FROM p2p_orders WHERE id = $1`,
                [orderId]
            );

            if (orderCheck.rowCount === 0) {
                return res.status(404).json({ error: 'Order not found' });
            }

            const order = orderCheck.rows[0];

            if (order.status === 'CANCELLED') {
                return res.status(400).json({ error: 'Order has been cancelled' });
            }

            if (order.status === 'EXPIRED') {
                return res.status(400).json({ error: 'Order has expired. Please create a new order.' });
            }

            const timeInfo = getTimeRemaining(order.expires_at);
            if (timeInfo.expired) {
                return res.status(400).json({ error: 'Payment time has expired. Please create a new order.' });
            }

            const file = req.file ? req.file.filename : null;

            await pg.query(`
                UPDATE p2p_orders
                SET
                    status = 'PAID',
                    payment_proof = $1,
                    utr_number = $2,
                    paid_at = NOW()
                WHERE id = $3
            `, [file, utr_number, orderId]);

            res.json({ message: 'Marked as paid' });

        } catch (err) {

            res.status(500).json({ error: err.message });

        }
    },


    // =============================
    // ADMIN: RELEASE FUNDS
    // =============================
    releaseOrder: async (req, res) => {

        const { orderId } = req.params;

        try {

            await pg.query('BEGIN');

            const orderData = await pg.query(
                `SELECT * FROM p2p_orders WHERE id=$1`,
                [orderId]
            );

            if (orderData.rowCount === 0)
                throw new Error('Order not found');

            const order = orderData.rows[0];

            if (order.status !== 'PAID')
                throw new Error('Order not paid');

            await pg.query(`
                UPDATE credits
                SET ${order.coin} = ${order.coin} + $1
                WHERE uid = $2
            `, [order.crypto_amount, order.user_id]);

            await pg.query(`
                UPDATE p2p_orders
                SET status='RELEASED', released_at=NOW()
                WHERE id=$1
            `, [orderId]);

            await pg.query('COMMIT');

            res.json({ message: 'Funds released successfully' });

        } catch (err) {

            await pg.query('ROLLBACK');
            res.status(500).json({ error: err.message });

        }
    },


    // =============================
    // ADMIN: GET PAYMENT TYPES
    // =============================
    getPaymentTypes: async (req, res) => {
        try {
            const result = await pg.query(
                `SELECT * FROM p2p_payment_types ORDER BY id ASC`
            );
            res.json(result.rows);
        } catch (err) {
            res.status(500).json({ error: err.message });
        }
    },


    // =============================
    // ADMIN: GET PAYMENT ACCOUNTS
    // =============================
    getPaymentAccounts: async (req, res) => {
        try {
            const result = await pg.query(`
                SELECT pa.*, pt.name AS type_name, pt.code AS type_code
                FROM p2p_payment_accounts pa
                JOIN p2p_payment_types pt ON pt.id = pa.payment_type_id
                ORDER BY pa.id ASC
            `);
            res.json(result.rows);
        } catch (err) {
            res.status(500).json({ error: err.message });
        }
    },


    // =============================
    // ADMIN: GET ALL OFFERS
    // =============================
    getAdminOffers: async (req, res) => {
        try {
            const result = await pg.query(`
                SELECT
                    o.*,
                    json_agg(
                        json_build_object(
                            'id', pa.id,
                            'type', pt.name
                        )
                    ) FILTER (WHERE pa.id IS NOT NULL) AS payments
                FROM p2p_offers o
                LEFT JOIN p2p_offer_payments op ON op.offer_id = o.id
                LEFT JOIN p2p_payment_accounts pa ON pa.id = op.payment_account_id
                LEFT JOIN p2p_payment_types pt ON pt.id = pa.payment_type_id
                GROUP BY o.id
                ORDER BY o.created_at DESC
            `);
            res.json(result.rows);
        } catch (err) {
            res.status(500).json({ error: err.message });
        }
    },


    // =============================
    // ADMIN: GET ALL ORDERS
    // =============================
    getAdminOrders: async (req, res) => {
        try {
            const result = await pg.query(`
                SELECT
                    o.*,
                    off.username AS merchant_name,
                    off.payment_time
                FROM p2p_orders o
                LEFT JOIN p2p_offers off ON off.id = o.offer_id
                ORDER BY o.created_at DESC
            `);
            res.json(addTimeInfo(result.rows));
        } catch (err) {
            res.status(500).json({ error: err.message });
        }
    },


    // =============================
    // ADMIN: CANCEL ORDER
    // =============================
    cancelOrder: async (req, res) => {
        const { orderId } = req.params;
        try {
            await pg.query('BEGIN');

            const orderData = await pg.query(
                `SELECT * FROM p2p_orders WHERE id=$1`, [orderId]
            );
            if (orderData.rowCount === 0) throw new Error('Order not found');

            const order = orderData.rows[0];
            if (order.status === 'RELEASED') throw new Error('Cannot cancel a released order');

            // Restore liquidity to offer
            await pg.query(`
                UPDATE p2p_offers
                SET available_amount = available_amount + $1
                WHERE id = $2
            `, [order.crypto_amount, order.offer_id]);

            await pg.query(`
                UPDATE p2p_orders
                SET status = 'CANCELLED', released_at = NOW()
                WHERE id = $1
            `, [orderId]);

            await pg.query('COMMIT');
            res.json({ message: 'Order cancelled, liquidity restored' });
        } catch (err) {
            await pg.query('ROLLBACK');
            res.status(500).json({ error: err.message });
        }
    },


    // =============================
    // ADMIN: DELETE ORDER
    // =============================
    deleteOrder: async (req, res) => {
        const { orderId } = req.params;
        try {
            await pg.query('BEGIN');

            const orderData = await pg.query(
                `SELECT * FROM p2p_orders WHERE id=$1`, [orderId]
            );
            if (orderData.rowCount === 0) throw new Error('Order not found');

            const order = orderData.rows[0];

            // Restore liquidity if order was not released
            if (order.status !== 'RELEASED' && order.status !== 'CANCELLED' && order.status !== 'EXPIRED') {
                await pg.query(`
                    UPDATE p2p_offers
                    SET available_amount = available_amount + $1
                    WHERE id = $2
                `, [order.crypto_amount, order.offer_id]);
            }

            await pg.query(`DELETE FROM p2p_orders WHERE id = $1`, [orderId]);

            await pg.query('COMMIT');
            res.json({ message: 'Order deleted' });
        } catch (err) {
            await pg.query('ROLLBACK');
            res.status(500).json({ error: err.message });
        }
    },


    // =============================
    // ADMIN: UPDATE ORDER STATUS
    // =============================
    updateOrderStatus: async (req, res) => {
        const { orderId } = req.params;
        const { status } = req.body;

        const allowed = ['PENDING', 'PAID', 'RELEASED', 'CANCELLED', 'EXPIRED'];
        if (!allowed.includes(status)) {
            return res.status(400).json({ error: `Invalid status. Allowed: ${allowed.join(', ')}` });
        }

        try {
            await pg.query(`
                UPDATE p2p_orders SET status = $1 WHERE id = $2
            `, [status, orderId]);
            res.json({ message: `Order status updated to ${status}` });
        } catch (err) {
            res.status(500).json({ error: err.message });
        }
    },


    // =============================
    // USER: GET MY ORDERS
    // =============================
    getUserOrders: async (req, res) => {
        const { userId } = req.params;
        const { status } = req.query;
        try {
            const result = await pg.query(`
                SELECT
                    o.*,
                    off.username AS merchant_name,
                    off.coin,
                    off.fiat,
                    off.payment_time,
                    pa.account_name,
                    pa.upi_id,
                    pt.name AS payment_type
                FROM p2p_orders o
                LEFT JOIN p2p_offers off ON off.id = o.offer_id
                LEFT JOIN p2p_payment_accounts pa ON pa.id = o.payment_account_id
                LEFT JOIN p2p_payment_types pt ON pt.id = pa.payment_type_id
                WHERE o.user_id = $1
                AND ($2::text IS NULL OR o.status = $2)
                ORDER BY o.created_at DESC
            `, [userId, status || null]);
            res.json(addTimeInfo(result.rows));
        } catch (err) {
            res.status(500).json({ error: err.message });
        }
    },


    // =============================
    // USER: CREATE SELL ORDER
    // =============================
    createSellOrder: async (req, res) => {

        const {
            user_id,
            offer_id,
            crypto_amount,
            payment_type_id,
            account_name,
            account_number,
            ifsc_code,
            upi_id
        } = req.body;

        const qr_image = req.file ? req.file.filename : null;

        try {

            await pg.query('BEGIN');

            const offerData = await pg.query(
                `SELECT * FROM p2p_offers WHERE id=$1`,
                [offer_id]
            );

            if (offerData.rowCount === 0)
                throw new Error('Offer not found');

            const offer = offerData.rows[0];

            // Check user balance
            const wallet = await pg.query(
                `SELECT ${offer.coin} FROM credits WHERE uid=$1`,
                [user_id]
            );

            if (wallet.rows[0][offer.coin] < crypto_amount)
                throw new Error('Insufficient balance');

            const fiat_amount = crypto_amount * offer.price;
            const orderNo = generateOrderNo();
            const paymentTime = offer.payment_time || 30;

            // Deduct crypto immediately
            await pg.query(`
                UPDATE credits
                SET ${offer.coin} = ${offer.coin} - $1
                WHERE uid=$2
            `, [crypto_amount, user_id]);

            const order = await pg.query(`
                INSERT INTO p2p_orders_sell (
                    order_no,
                    user_id,
                    offer_id,
                    coin,
                    fiat,
                    price,
                    crypto_amount,
                    fiat_amount,
                    payment_type_id,
                    account_name,
                    account_number,
                    ifsc_code,
                    upi_id,
                    qr_image,
                    expires_at
                )
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14, NOW() + ($15 || ' minutes')::INTERVAL)
                RETURNING *
            `, [
                orderNo,
                user_id,
                offer_id,
                offer.coin,
                offer.fiat,
                offer.price,
                crypto_amount,
                fiat_amount,
                payment_type_id,
                account_name || null,
                account_number || null,
                ifsc_code || null,
                upi_id || null,
                qr_image,
                paymentTime
            ]);

            await pg.query('COMMIT');

            const row = order.rows[0];
            res.json({
                ...row,
                payment_time: paymentTime,
                ...getTimeRemaining(row.expires_at)
            });

        } catch (err) {

            await pg.query('ROLLBACK');
            res.status(500).json({ error: err.message });

        }
    },

    // =============================
    // ADMIN: GET SELL ORDERS
    // =============================
    getAdminSellOrders: async (req, res) => {

        try {

            const result = await pg.query(`
                SELECT
                    s.*,
                    off.username AS merchant_name,
                    off.payment_time,
                    pt.name AS payment_type
                FROM p2p_orders_sell s
                LEFT JOIN p2p_offers off ON off.id = s.offer_id
                LEFT JOIN p2p_payment_types pt ON pt.id = s.payment_type_id
                ORDER BY s.created_at DESC
            `);

            res.json(addTimeInfo(result.rows));

        } catch (err) {

            res.status(500).json({ error: err.message });

        }
    },

    // =============================
    // ADMIN: RELEASE SELL ORDER (WITH PROOF)
    // =============================
    releaseSellOrder: async (req, res) => {

        const { orderId } = req.params;
        const { admin_note } = req.body;

        const admin_payment_proof = req.file ? req.file.filename : null;

        try {

            const orderData = await pg.query(
                `SELECT * FROM p2p_orders_sell WHERE id=$1`,
                [orderId]
            );

            if (orderData.rowCount === 0)
                throw new Error('Order not found');

            const order = orderData.rows[0];

            if (order.status === 'RELEASED')
                throw new Error('Already released');

            await pg.query(`
                UPDATE p2p_orders_sell
                SET
                    status = 'RELEASED',
                    admin_payment_proof = $1,
                    admin_note = $2,
                    released_at = NOW()
                WHERE id = $3
            `, [admin_payment_proof, admin_note || null, orderId]);

            res.json({ message: 'Sell order completed successfully' });

        } catch (err) {

            res.status(500).json({ error: err.message });

        }
    },

    // =============================
    // ADMIN: CANCEL SELL ORDER
    // =============================
    cancelSellOrder: async (req, res) => {

        const { orderId } = req.params;

        try {

            await pg.query('BEGIN');

            const orderData = await pg.query(
                `SELECT * FROM p2p_orders_sell WHERE id=$1`,
                [orderId]
            );

            if (orderData.rowCount === 0)
                throw new Error('Order not found');

            const order = orderData.rows[0];

            if (order.status === 'RELEASED')
                throw new Error('Cannot cancel released order');

            // Refund crypto
            await pg.query(`
                UPDATE credits
                SET ${order.coin} = ${order.coin} + $1
                WHERE uid=$2
            `, [order.crypto_amount, order.user_id]);

            await pg.query(`
                UPDATE p2p_orders_sell
                SET status='CANCELLED'
                WHERE id=$1
            `, [orderId]);

            await pg.query('COMMIT');

            res.json({ message: 'Sell order cancelled & refunded' });

        } catch (err) {

            await pg.query('ROLLBACK');
            res.status(500).json({ error: err.message });

        }
    },

    // =============================
    // USER: GET MY SELL ORDERS
    // =============================
    getUserSellOrders: async (req, res) => {

        const { userId } = req.params;

        try {

            const result = await pg.query(`
                SELECT
                    s.*,
                    off.payment_time,
                    pt.name AS payment_type
                FROM p2p_orders_sell s
                LEFT JOIN p2p_offers off ON off.id = s.offer_id
                LEFT JOIN p2p_payment_types pt ON pt.id = s.payment_type_id
                WHERE s.user_id = $1
                ORDER BY s.created_at DESC
            `, [userId]);

            res.json(addTimeInfo(result.rows));

        } catch (err) {

            res.status(500).json({ error: err.message });

        }
    },


    // =============================
    // USER: CREATE DISPUTE
    // =============================
    createDispute: async (req, res) => {

        const { order_id, user_id, order_type, reason, message } = req.body;
        const screenshot = req.file ? req.file.filename : null;

        if (!order_id || !reason) {
            return res.status(400).json({ error: 'Order ID and reason are required' });
        }

        try {

            // Verify order exists
            const table = order_type === 'SELL' ? 'p2p_orders_sell' : 'p2p_orders';
            const orderCheck = await pg.query(
                `SELECT order_no, status FROM ${table} WHERE id = $1`,
                [order_id]
            );

            if (orderCheck.rowCount === 0) {
                return res.status(404).json({ error: 'Order not found' });
            }

            const order = orderCheck.rows[0];

            // Check for duplicate dispute
            const existing = await pg.query(
                `SELECT id FROM p2p_disputes WHERE order_id = $1 AND order_type = $2 AND status = 'OPEN'`,
                [order_id, order_type || 'BUY']
            );

            if (existing.rowCount > 0) {
                return res.status(400).json({ error: 'A dispute is already open for this order' });
            }

            const result = await pg.query(`
                INSERT INTO p2p_disputes (order_id, order_no, user_id, order_type, reason, message, screenshot)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
                RETURNING *
            `, [
                order_id,
                order.order_no,
                user_id || null,
                order_type || 'BUY',
                reason,
                message || null,
                screenshot
            ]);

            res.json({ message: 'Dispute submitted successfully', dispute: result.rows[0] });

        } catch (err) {

            res.status(500).json({ error: err.message });

        }
    },


    // =============================
    // ADMIN: GET ALL DISPUTES
    // =============================
    getAdminDisputes: async (req, res) => {

        try {

            const result = await pg.query(`
                SELECT d.*,
                       u.name AS user_name,
                       u.email AS user_email
                FROM p2p_disputes d
                LEFT JOIN users u ON u.id::text = d.user_id
                ORDER BY
                    CASE d.status WHEN 'OPEN' THEN 0 WHEN 'IN_REVIEW' THEN 1 ELSE 2 END,
                    d.created_at DESC
            `);

            res.json(result.rows);

        } catch (err) {

            res.status(500).json({ error: err.message });

        }
    },


    // =============================
    // ADMIN: UPDATE DISPUTE STATUS
    // =============================
    updateDisputeStatus: async (req, res) => {

        const { disputeId } = req.params;
        const { status, admin_note } = req.body;

        const allowed = ['OPEN', 'IN_REVIEW', 'RESOLVED', 'REJECTED'];
        if (!allowed.includes(status)) {
            return res.status(400).json({ error: `Invalid status. Allowed: ${allowed.join(', ')}` });
        }

        try {

            await pg.query(`
                UPDATE p2p_disputes
                SET status = $1,
                    admin_note = $2,
                    resolved_at = $3
                WHERE id = $4
            `, [
                status,
                admin_note || null,
                (status === 'RESOLVED' || status === 'REJECTED') ? new Date() : null,
                disputeId
            ]);

            res.json({ message: `Dispute status updated to ${status}` });

        } catch (err) {

            res.status(500).json({ error: err.message });

        }
    },

};
