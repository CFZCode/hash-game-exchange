const cron = require('node-cron');
const pg = require('../General/Model');

console.log("P2P Auto-Cancel Worker Started...");

// =============================
// Auto-cancel expired orders
// =============================
const cancelExpiredOrders = async () => {

    try {

        // ── BUY ORDERS: Cancel expired PENDING orders ──
        const expiredBuy = await pg.query(`
            SELECT id, offer_id, crypto_amount, status
            FROM p2p_orders
            WHERE status = 'PENDING'
              AND expires_at IS NOT NULL
              AND expires_at <= NOW()
        `);

        for (const order of expiredBuy.rows) {

            await pg.query('BEGIN');

            try {

                // Restore liquidity to offer
                await pg.query(`
                    UPDATE p2p_offers
                    SET available_amount = available_amount + $1
                    WHERE id = $2
                `, [order.crypto_amount, order.offer_id]);

                // Mark as expired
                await pg.query(`
                    UPDATE p2p_orders
                    SET status = 'EXPIRED', released_at = NOW()
                    WHERE id = $1
                `, [order.id]);

                await pg.query('COMMIT');
                console.log(`Buy order #${order.id} expired & cancelled`);

            } catch (err) {

                await pg.query('ROLLBACK');
                console.error(`Error cancelling buy order #${order.id}:`, err.message);

            }
        }

        // ── SELL ORDERS: Cancel expired PENDING orders ──
        const expiredSell = await pg.query(`
            SELECT id, user_id, coin, crypto_amount, status
            FROM p2p_orders_sell
            WHERE status = 'PENDING'
              AND expires_at IS NOT NULL
              AND expires_at <= NOW()
        `);

        for (const order of expiredSell.rows) {

            await pg.query('BEGIN');

            try {

                // Refund crypto to user
                await pg.query(`
                    UPDATE credits
                    SET ${order.coin} = ${order.coin} + $1
                    WHERE uid = $2
                `, [order.crypto_amount, order.user_id]);

                // Mark as expired
                await pg.query(`
                    UPDATE p2p_orders_sell
                    SET status = 'EXPIRED'
                    WHERE id = $1
                `, [order.id]);

                await pg.query('COMMIT');
                console.log(`Sell order #${order.id} expired, crypto refunded to user #${order.user_id}`);

            } catch (err) {

                await pg.query('ROLLBACK');
                console.error(`Error cancelling sell order #${order.id}:`, err.message);

            }
        }

        if (expiredBuy.rowCount > 0 || expiredSell.rowCount > 0) {
            console.log(`Expired: ${expiredBuy.rowCount} buy, ${expiredSell.rowCount} sell orders`);
        }

    } catch (error) {

        console.error("P2P Worker Error:", error);

    }

};

// =============================
// Run every minute
// =============================
cron.schedule('* * * * *', cancelExpiredOrders, {
    timezone: "Asia/Kolkata"
});

// Run once on startup
cancelExpiredOrders();
