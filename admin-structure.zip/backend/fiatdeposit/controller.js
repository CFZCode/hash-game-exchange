const pg = require('../General/Model');
const { selfServeSql } = require('../system/utils/branch');
const fs = require('fs');
const path = require('path');

let _wagerSchemaReady = false;
async function ensureWagerSchema() {
    if (_wagerSchemaReady) return;
    try {
        await pg.query(`
            ALTER TABLE users
              ADD COLUMN IF NOT EXISTS wager_multiplier numeric DEFAULT 3,
              ADD COLUMN IF NOT EXISTS lock_targetx     boolean DEFAULT false,
              ADD COLUMN IF NOT EXISTS parent_staff_id  bigint
        `);
        await pg.query(`
            CREATE TABLE IF NOT EXISTS userwager (
              uid    bigint PRIMARY KEY,
              wager  numeric DEFAULT 0
            )
        `);
        _wagerSchemaReady = true;
    } catch (e) {
        console.warn('[ensureWagerSchema] failed:', e?.message);
        // Don't throw — let the calling query surface the real error.
    }
}

module.exports = {
    // User: Create Deposit

    async createDeposit(req, res) {
        try {
            const {
                user_id,
                amount,
                transaction_id,
                currency,
                bank_name,
                account_number,
                ifsc_code,
                account_holder_name
            } = req.body;

            const screenshot = req.file?.filename || null; // handle uploaded file safely

            // Optional validation (uncomment if needed)
            // if (!user_id || !amount || !transaction_id || !screenshot) {
            //   return res.status(400).json({ success: false, message: 'Missing required fields' });
            // }

            const result = await pg.query(
                `INSERT INTO fiat_deposits (
         user_id,
         amount,
         transaction_id,
         currency,
         bank_name,
         account_number,
         ifsc_code,
         account_holder_name,
         screenshot_path,
         status,
         created_at,
         updated_at
       )
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,'pending',NOW(),NOW())
       RETURNING *`,
                [
                    user_id,
                    amount,
                    transaction_id,
                    currency || 'INR',
                    bank_name,
                    account_number,
                    ifsc_code,
                    account_holder_name,
                    screenshot
                ]
            );

            res.json({ success: true, data: result.rows[0] });
        } catch (error) {
            console.error('Create deposit error:', error);
            res.status(500).json({ success: false, message: error.message });
        }
    }
    ,
    // async createDeposit(req, res) {
    //   try {
    //     const { userId, amount, paymentMethod } = req.body;
    //     const screenshot = req.file?.filename;

    //     if (!userId || !amount || !paymentMethod || !screenshot) {
    //       return res.status(400).json({ success: false, message: 'Missing required fields' });
    //     }

    //     const result = await pg.query(
    //       `INSERT INTO deposits (user_id, amount, payment_method, screenshot, status)
    //        VALUES ($1, $2, $3, $4, 'pending') RETURNING *`,
    //       [userId, amount, paymentMethod, screenshot]
    //     );

    //     res.json({ success: true, data: result.rows[0] });
    //   } catch (error) {
    //     res.status(500).json({ success: false, message: error.message });
    //   }
    // },



    // User: Get all deposits
    async getUserDeposits(req, res) {
        try {
            const { userId } = req.params;

            const result = await pg.query(
                `SELECT * FROM deposits WHERE user_id = $1 ORDER BY created_at DESC`,
                [userId]
            );

            res.json({ success: true, data: result.rows });
        } catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    },

    // User: Get deposit by ID
    async getDepositById(req, res) {
        try {
            const { depositId } = req.params;
            const { userId } = req.query;

            const result = await pg.query(
                `SELECT * FROM deposits WHERE id = $1 AND user_id = $2`,
                [depositId, userId]
            );

            if (result.rowCount === 0) {
                return res.status(404).json({ success: false, message: 'Deposit not found' });
            }

            res.json({ success: true, data: result.rows[0] });
        } catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    },

    // User: Get screenshot
    async getDepositScreenshot(req, res) {
        try {
            const { filename } = req.params;
            const filePath = path.join(__dirname, '../../uploads/deposits', filename);

            if (!fs.existsSync(filePath)) {
                return res.status(404).json({ success: false, message: 'Screenshot not found' });
            }

            res.sendFile(filePath);
        } catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    },

    async getAllDeposits(req, res) {
        try {
            const result = await pg.query(`
        SELECT d.*, u.email
        FROM deposits d
        JOIN users u ON d.uid = u.id
        ORDER BY d.date DESC
      `);

            console.log("Deposits fetched:", result.rows.length);
            res.json({ success: true, data: result.rows });
        } catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    },

    // Admin: Get pending deposits
    async getPendingDeposits(_req, res) {
        try {
            const result = await pg.query(
                `SELECT d.*, u.email
         FROM deposits d
         JOIN users u ON d.user_id = u.id
         WHERE d.status = 'pending'
         ORDER BY d.created_at DESC`
            );

            res.json({ success: true, data: result.rows });
        } catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    },

    // Admin: Approve deposit
    async approveDeposit(req, res) {
        const client = await pg.connect();
        try {
            const { depositId } = req.body;

            await client.query('BEGIN');

            const { rows: depositRows } = await client.query(
                `UPDATE deposits
         SET status = 'approved', approved_at = CURRENT_TIMESTAMP
         WHERE id = $1 AND status = 'pending'
         RETURNING *`,
                [depositId]
            );

            if (depositRows.length === 0) {
                throw new Error('Deposit not found or already processed');
            }

            const deposit = depositRows[0];

            await client.query(
                `UPDATE users
         SET balance = balance + $1
         WHERE id = $2`,
                [deposit.amount, deposit.user_id]
            );

            await client.query('COMMIT');
            res.json({ success: true, message: 'Deposit approved and balance updated' });
        } catch (error) {
            await client.query('ROLLBACK');
            res.status(500).json({ success: false, message: error.message });
        } finally {
            client.release();
        }
    },

    // Admin: Reject deposit
    async rejectDeposit(req, res) {
        try {
            const { depositId, comment } = req.body;

            const result = await pg.query(
                `UPDATE deposits
         SET status = 'rejected', admin_comment = $2, rejected_at = CURRENT_TIMESTAMP
         WHERE id = $1 AND status = 'pending'
         RETURNING *`,
                [depositId, comment]
            );

            if (result.rowCount === 0) {
                return res.status(404).json({ success: false, message: 'Deposit not found or already processed' });
            }

            res.json({ success: true, message: 'Deposit rejected' });
        } catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    },

    // Add new endpoint to get users with lock status

    async getUsersWagersAndDepositTarget(req, res) {
        try {
            await ensureWagerSchema();
            const query = `
      WITH crypto_deposits AS (
        SELECT
          c.userid::bigint as user_id,
          COALESCE(SUM(c.amount::numeric * e.usd_rate), 0) as total_usd
        FROM ccdeposit c
        JOIN exchangerate e ON CASE
          WHEN c.coinid = 1155 THEN 'BTC'
          WHEN c.coinid = 1161 THEN 'ETH'
          WHEN c.coinid = 1173 THEN 'LTC'
          WHEN c.coinid = 1169 THEN 'BCH'
          WHEN c.coinid = 1280 THEN 'USDT'
          WHEN c.coinid = 1482 THEN 'TRX'
          WHEN c.coinid = 1492 THEN 'DOGE'
          WHEN c.coinid = 1375 THEN 'ADA'
          WHEN c.coinid = 1331 THEN 'XRP'
          WHEN c.coinid = 1168 THEN 'BNB'
          WHEN c.coinid = 1282 THEN 'USDC'
          WHEN c.coinid = 1864 THEN 'SHIB'
        END = e.currency
        WHERE c.status = 'Success'
        GROUP BY c.userid
      ),
      fiat_deps AS (
        SELECT
          f.user_id::bigint as user_id,
          COALESCE(SUM(f.amount::numeric), 0) as total_usd
        FROM fiat_deposits f
        WHERE LOWER(f.status) IN ('approved', 'success')
        GROUP BY f.user_id
      ),
      payin_deps AS (
        SELECT
          p.user_id::bigint as user_id,
          COALESCE(SUM(p.amount::numeric), 0) as total_usd
        FROM pay_in_transactions p
        WHERE p.status = 1
        GROUP BY p.user_id
      ),
      total_deposits AS (
        SELECT
          user_id,
          SUM(total_usd) as total_deposit_usd
        FROM (
          SELECT user_id, total_usd FROM crypto_deposits
          UNION ALL
          SELECT user_id, total_usd FROM fiat_deps
          UNION ALL
          SELECT user_id, total_usd FROM payin_deps
        ) combined
        GROUP BY user_id
      ),
      wagers AS (
        SELECT
          uid::bigint AS user_id,
          SUM(
            CASE
              WHEN REPLACE(wager::text, ',', '') ~ '^[0-9]+(\\.[0-9]+)?$'
              THEN REPLACE(wager::text, ',', '')::numeric
              ELSE 0::numeric
            END
          ) AS wager
        FROM userwager
        GROUP BY uid
      )
      SELECT
        u.id,
        u.name,
        u.email,
        COALESCE(u.wager_multiplier, 3) AS wager_multiplier,
        COALESCE(u.lock_targetx, false) AS lock_targetx,
        COALESCE(w.wager, 0)::numeric AS wager,
        COALESCE(td.total_deposit_usd, 0)::numeric AS total_deposit,
        (COALESCE(td.total_deposit_usd, 0) * COALESCE(u.wager_multiplier, 3))::numeric AS target,
        CASE
          WHEN (COALESCE(td.total_deposit_usd, 0) * COALESCE(u.wager_multiplier, 3)) = 0
            THEN 0
          ELSE ROUND(
            (COALESCE(w.wager, 0) * 100.0) /
            (COALESCE(td.total_deposit_usd, 0) * COALESCE(u.wager_multiplier, 3)),
            2
          )
        END AS target_percentage,
        u.created AS user_created_at
      FROM users u
      LEFT JOIN total_deposits td ON td.user_id = u.id
      LEFT JOIN wagers w          ON w.user_id = u.id
      WHERE ${selfServeSql('u')}
      ORDER BY u.created DESC;
    `;

            const result = await pg.query(query);

            const data = result.rows.map(r => ({
                id: r.id,
                name: r.name,
                email: r.email,
                wager_multiplier: Number(r.wager_multiplier),
                is_locked: Boolean(r.lock_targetx),
                wager: Number(r.wager),
                total_deposit: Number(r.total_deposit),
                target: Number(r.target),
                target_percentage: Number(r.target_percentage),
                user_created_at: r.user_created_at
            }));

            res.status(200).json({ success: true, data });
        } catch (error) {
            console.error('Error fetching users+wagers+total deposit target:', error);
            res.status(500).json({
                success: false,
                message: error?.message || 'Server error',
                code: error?.code || null,
                detail: error?.detail || null,
                where: error?.where || null,
            });
        }
    },


    async updateAllUsersWagerTargetMultiplier(req, res) {
        try {
            const { multiplier } = req.body;

            if (!multiplier || multiplier <= 0) {
                return res.status(400).json({
                    success: false,
                    message: "Multiplier must be a positive number"
                });
            }

            // ✅ CRITICAL FIX: Only update users where lock_targetx is FALSE or NULL
            const result = await pg.query(
                `UPDATE users
       SET wager_multiplier = $1
       WHERE (lock_targetx IS NULL OR lock_targetx = false)
       RETURNING id`,
                [multiplier]
            );

            res.status(200).json({
                success: true,
                message: `Multiplier updated for ${result.rowCount} users (locked users excluded)`,
                updatedCount: result.rowCount
            });
        } catch (err) {
            console.error("Error updating multiplier for all users:", err);
            res.status(500).json({ success: false, message: "Server error" });
        }
    },

    // ✅ CORRECTED: Toggle lock status for a user
    async toggleUserTargetXLock(req, res) {
        try {
            const { id } = req.params;
            const { is_locked } = req.body;
            console.log(`Toggling lock for user ID ${id} to ${is_locked}`);

            const result = await pg.query(
                `UPDATE users SET lock_targetx = $1 WHERE id = $2 RETURNING lock_targetx`,
                [is_locked, id]
            );

            if (result.rowCount === 0) {
                return res.status(404).json({
                    success: false,
                    message: "User not found"
                });
            }

            res.status(200).json({
                success: true,
                message: is_locked ? "TargetX locked" : "TargetX unlocked",
                lock_targetx: result.rows[0].lock_targetx
            });
        } catch (err) {
            console.error("Error toggling lock:", err);
            res.status(500).json({ success: false, message: "Server error" });
        }
    },
    // Update individual user's wager multiplier
    async updateUserWagerTargetMultiplier(req, res) {
        try {
            const { id } = req.params;
            const { multiplier } = req.body;

            if (!multiplier || multiplier <= 0) {
                return res.status(400).json({
                    success: false,
                    message: "Multiplier must be a positive number"
                });
            }

            await pg.query(
                `UPDATE users SET wager_multiplier = $1 WHERE id = $2`,
                [multiplier, id]
            );

            res.status(200).json({ success: true, message: "Multiplier updated" });
        } catch (err) {
            console.error("Error updating multiplier:", err);
            res.status(500).json({ success: false, message: "Server error" });
        }
    },


    async getUserMinimumWager(req, res) {
        const { uid } = req.params;

        try {
            console.log(`Checking wager eligibility for UID: ${uid}`);

            // 1. Get TOTAL wager
            const wagerResult = await pg.query(
                'SELECT wager FROM userwager WHERE uid = $1',
                [uid]
            );

            const rawWager = wagerResult.rowCount > 0 ? wagerResult.rows[0].wager : '0';
            const wager = parseFloat(rawWager.toString().replace(/,/g, '')) || 0;

            // 2. Get TOTAL approved deposits from all sources in USD
            const depositResult = await pg.query(
                `WITH crypto_deposits AS (
        SELECT COALESCE(SUM(c.amount::numeric * e.usd_rate), 0) as total_usd
        FROM ccdeposit c
        JOIN exchangerate e ON CASE
          WHEN c.coinid = 1155 THEN 'BTC'
          WHEN c.coinid = 1161 THEN 'ETH'
          WHEN c.coinid = 1173 THEN 'LTC'
          WHEN c.coinid = 1169 THEN 'BCH'
          WHEN c.coinid = 1280 THEN 'USDT'
          WHEN c.coinid = 1482 THEN 'TRX'
          WHEN c.coinid = 1492 THEN 'DOGE'
          WHEN c.coinid = 1375 THEN 'ADA'
          WHEN c.coinid = 1331 THEN 'XRP'
          WHEN c.coinid = 1168 THEN 'BNB'
          WHEN c.coinid = 1282 THEN 'USDC'
          WHEN c.coinid = 1864 THEN 'SHIB'
        END = e.currency
        WHERE c.status = 'Success' AND c.userid::bigint = $1::bigint
      ),
      fiat_deposits AS (
        /* fiat deposits are already in INR — sum directly, no conversion */
        SELECT COALESCE(SUM(f.amount::numeric), 0) as total_usd
        FROM fiat_deposits f
        WHERE LOWER(f.status) IN ('approved', 'success') AND f.user_id::bigint = $1::bigint
      ),
      payin_deposits AS (
        /* payin deposits are already in INR — sum directly, no conversion */
        SELECT COALESCE(SUM(p.amount::numeric), 0) as total_usd
        FROM pay_in_transactions p
        WHERE p.status = 1 AND p.user_id::bigint = $1::bigint
      )
      SELECT (
        (SELECT total_usd FROM crypto_deposits) +
        (SELECT total_usd FROM fiat_deposits) +
        (SELECT total_usd FROM payin_deposits)
      ) AS total_deposit`,
                [uid]
            );

            const totalDeposit = parseFloat(depositResult.rows[0].total_deposit) || 0;

            // 3. Get user's individual wager_multiplier
            const userMultiplierResult = await pg.query(
                `SELECT wager_multiplier FROM users WHERE id = $1::bigint`,
                [uid]
            );

            const userMultiplier = userMultiplierResult.rowCount > 0
                ? Number(userMultiplierResult.rows[0].wager_multiplier)
                : null;

            let multiplier;
            let multiplierSource;

            // 4. Priority: user-specific multiplier > common multiplier
            if (userMultiplier !== null && userMultiplier !== 0) {
                multiplier = userMultiplier;
                multiplierSource = 'user';
            } else {
                // Fallback to common multiplier
                const multiplierResult = await pg.query(
                    `SELECT multiplier FROM wager_multiplier_common ORDER BY id DESC LIMIT 1`
                );

                multiplier = multiplierResult.rowCount > 0
                    ? Number(multiplierResult.rows[0].multiplier)
                    : 3;
                multiplierSource = 'common';
            }

            // 5. Calculate target and eligibility
            const target = totalDeposit * multiplier;
            let eligible = wager > target;

            if (totalDeposit === 0) {
                eligible = false;
            }

            // 6. Percentage achieved
            const percentage = target > 0
                ? Number(((wager / target) * 100).toFixed(2))
                : 0;

            res.json({
                uid: Number(uid),
                wager,
                total_deposit: totalDeposit,
                multiplier,
                multiplier_source: multiplierSource,
                target,
                percentage,
                eligible
            });

        } catch (error) {
            console.error('Error checking wager:', error);
            res.status(500).json({ error: 'Internal server error' });
        }
    },



    async getAllWagerMultipliers(req, res) {
        try {
            const result = await pg.query(`
      SELECT id, multiplier, created_at
      FROM wager_multiplier_common
      ORDER BY id DESC
    `);

            res.status(200).json({
                success: true,
                data: result.rows
            });

        } catch (err) {
            console.error("Error fetching multiplier list:", err);
            res.status(500).json({
                success: false,
                message: "Server error"
            });
        }
    },



};
