// routes/depositRoutes.js
const express = require('express');
const { rejectDemoUser } = require('../system/utils/demoUsers');
const router = express.Router();
const depositController = require('./controller');
const multer = require('multer');
const path = require('path');

// Configure multer for file uploads
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/deposit_screenshots/');
    },
    filename: function (req, file, cb) {
        cb(null, 'deposit_' + Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({
    storage: storage,
    limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
    fileFilter: function (req, file, cb) {
        // Accept only images
        if (!file.originalname.match(/\.(jpg|jpeg|png|gif)$/)) {
            return cb(new Error('Only image files are allowed!'), false);
        }
        cb(null, true);
    }
});

// User routes
router.post('/create', upload.single('screenshot'), rejectDemoUser, depositController.createDeposit);
router.get('/user-deposits', depositController.getUserDeposits);
router.get('/deposit/:depositId', depositController.getDepositById);
router.get('/screenshot/:depositId', depositController.getDepositScreenshot);

router.get('/check-wager/:uid', depositController.getUserMinimumWager);
// Admin routes

router.get('/admin/common-targetx', depositController.getAllWagerMultipliers);
router.post('/admin/targetx/:id', depositController.updateUserWagerTargetMultiplier);
router.post('/admin/update-all-targetx', depositController.updateAllUsersWagerTargetMultiplier);
router.post('/admin/targetx/:id/lock', depositController.toggleUserTargetXLock);


router.get('/admin/all-wagers', depositController.getUsersWagersAndDepositTarget);

// Admin routes
router.get('/admin/all-deposits', depositController.getAllDeposits);
router.get('/admin/pending-deposits', depositController.getPendingDeposits);
router.put('/admin/approve/:depositId', depositController.approveDeposit);
router.put('/admin/reject/:depositId', depositController.rejectDeposit);

module.exports = router;