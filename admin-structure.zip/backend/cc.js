const crypto = require('crypto');

// Replace these with your actual values

const app_id = "REMOVED_SECRET";      // Replace with your actual CCPayment App ID
const app_secret = "REMOVED_SECRET";

// Example body from the Postman request
const body = {
};

// Generate the current timestamp
const timestamp = 1728833344;

// Generate the signature
function generateSignature(app_id, app_secret, body, timestamp) {
    const signText = `${app_id}${timestamp}${JSON.stringify(body)}`;
    console.log(signText);
    return crypto.createHmac('sha256', app_secret).update(signText).digest('hex');
}

// Call the function
const sign = generateSignature(app_id, app_secret, body, timestamp);

console.log('Timestamp:', timestamp);
console.log('Generated Sign:', sign);
