# Teen Patti launch proxy

The MyApp Originals Teen Patti titles are hosted by an external provider. The
player never talks to that provider directly — this module is the only thing that
does.

Mounted at **`/api/teenpatti`** (`../index.js`), so the public path is
`POST /api/teenpatti/launch`.

---

## Why a proxy at all

The provider's launch endpoint has **no authentication**, and the `amount` in the
request body becomes the player's game coins. Called from the browser, anyone
could open DevTools and mint themselves `amount: 99999999` worth of real-money
coins. So the browser calls us, we authenticate the player, and we decide the
amount ourselves.

```
browser ──POST /api/teenpatti/launch (session token)──► us ──POST /user/launch──► provider
                                                        │  ◄── { success, gameUrl } ──┘
        ◄──────────── { success, gameUrl } ─────────────┘
```

## Request / response

`POST /api/teenpatti/launch`

Auth: the player's normal session token — `Authorization: Bearer <token>`, or a
`token` / `x-auth-token` header, or `token` in the body (whatever `guardPlayer`
accepts). **The body carries nothing else**; `userId` comes from the verified
token, not from the request.

| Status | Body |
|---|---|
| 200 | `{ success: true, gameUrl }` |
| 401 | `{ error }` — no/expired session (from `guardPlayer`) |
| 404 | `{ success: false, message: 'User not found' }` |
| 403 | `{ success: false, message }` — the provider refused this player ("This user is not allowed to launch the game"); not retryable |
| 409 | `{ success: false, message: 'Game is already open…' }` — the provider allows one live session per user |
| 502 | `{ success: false, message }` — provider down, timeout, or a non-success payload |

## Configuration

| Env var | Default | Meaning |
|---|---|---|
| `TEENPATTI_LAUNCH_URL` | `https://example.com/api/v1/user/launch` | Provider launch endpoint |
| `TEENPATTI_RESERVE_AMOUNT` | `100000` | Reserve sent as `amount` |
| `TEENPATTI_CURRENCY` | `INR` | `currency` field |

Defaults are baked in, so the module runs with nothing added to `.env`. Set the
vars when the provider hands over the permanent https host.

## What this module does NOT do

- **It does not move money.** No debit on launch, no credit on close. The
  provider settles the session back to us over a server-to-server callback, and
  that callback is not built yet — the provider's operator-callback side is still
  disabled and its contract has not been handed over. Deducting `amount` here
  before that exists would take the player's balance with nothing to return it.
  Once the callback lands, the debit belongs in the same place as the settlement,
  not here.
- **It does not sign the request.** The provider's `signature` field is optional
  today. It becomes required later; the secret and formula are still owed to us.
- **It does not cache `gameUrl`.** Every launch is a fresh call. The frontend
  keeps the URL for the length of the session so a page refresh rejoins the same
  match instead of hitting the provider's one-session-per-user 409.

## Known state of the provider (as of 2026-08-13)

The endpoint is up and vetting players: an unknown `userId` comes back
`403 {"success":false,"message":"This user is not allowed to launch the game."}`,
and an empty body `400`. It no longer answers "Launch rejected by operator." to
everything, so the operator-callback half appears to be enabled — but that has
not been confirmed with a real player id, and nothing here has been run
end-to-end yet.

Still owed by the provider: the settlement-callback contract, the `signature`
secret and formula (the field is optional today, required later), and a permanent
domain for `gameUrl`, which currently comes off a temporary Cloudflare tunnel.
