/*
 * Teen Patti (MyApp Originals) — launch proxy.
 * Mounted at /api/teenpatti (../index.js). See README.md.
 */

const express = require('express');
const axios = require('axios');
const router = express.Router();
const pg = require('../General/Model');
const { guardPlayer } = require('../system/middleware/guardPlayer');

const LAUNCH_URL =
  process.env.TEENPATTI_LAUNCH_URL || 'https://example.com/api/v1/user/launch';
// Reserve sent to the provider. Never taken from the request — the browser does
// not get to decide how many game coins it is given.
const RESERVE_AMOUNT = Number(process.env.TEENPATTI_RESERVE_AMOUNT || 100000);
const CURRENCY = process.env.TEENPATTI_CURRENCY || 'INR';

router.post('/launch', guardPlayer, async (req, res) => {
  const uid = req.playerUid;

  let userName = 'Player';
  try {
    const { rows } = await pg.query('SELECT name FROM users WHERE id = $1', [uid]);
    if (!rows[0]) return res.status(404).json({ success: false, message: 'User not found' });
    userName = rows[0].name || 'Player';
  } catch (err) {
    console.error('[teenpatti] user lookup failed', err.message);
    return res.status(500).json({ success: false, message: 'Server error' });
  }

  try {
    const { data } = await axios.post(
      LAUNCH_URL,
      {
        userId: String(uid),
        userName,
        amount: RESERVE_AMOUNT,
        currency: CURRENCY,
      },
      { timeout: 15000 }
    );

    if (!data || !data.success || !data.gameUrl) {
      return res
        .status(502)
        .json({ success: false, message: (data && data.message) || 'Game is not available right now.' });
    }

    return res.json({ success: true, gameUrl: data.gameUrl });
  } catch (err) {
    const status = err.response && err.response.status;
    const message = err.response && err.response.data && err.response.data.message;

    if (status === 409) {
      return res.status(409).json({
        success: false,
        message: 'Game is already open. Please close the other tab first.',
      });
    }
    // The provider vets the player before it will open a session ("This user is
    // not allowed to launch the game"). Nothing on our side can retry past that,
    // so say so rather than dressing it up as a temporary outage.
    if (status === 403) {
      console.error('[teenpatti] launch refused for uid', uid, message || '');
      return res
        .status(403)
        .json({ success: false, message: message || 'This account cannot open the game.' });
    }
    console.error('[teenpatti] launch failed', status || '', message || err.message);
    return res
      .status(502)
      .json({ success: false, message: 'Game is not available right now. Please try again.' });
  }
});

module.exports = router;
