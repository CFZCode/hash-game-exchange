const pg = require('./General/Model');

async function checkAndInsertSiteConfig() {
  try {
    // Check if siteconfig has any rows
    const checkResult = await pg.query('SELECT COUNT(*) as count FROM siteconfig');
    const count = parseInt(checkResult.rows[0].count);

    console.log(`Siteconfig table has ${count} rows`);

    if (count === 0) {
      console.log('Inserting default siteconfig row...');

      // Insert a default row with basic values
      const insertQuery = `
        INSERT INTO siteconfig (
          registerbonus, sports, affiliatebonus, comissionpercent,
          inr, mvr, aed, pkr, cryptocoin, bjb, casino, lotto,
          vipclub, clubmembership, bonus, affiliate, crash, originals,
          livegames, slotsgames, alllivegames, allslotsgames,
          lotterygames, indiangames, cards, jilli, bdt, clubrake,
          instantgames, btc, eth, ltc, bch, usdt, trx, doge, ada,
          xrp, bnb, usdp, nexo, mkr, tusd, usdc, busd,
          createdat, updatedat
        ) VALUES (
          100, true, 10, 5,
          true, true, true, true, true, true, true, true,
          true, true, true, true, true, true,
          true, true, true, true,
          true, true, true, true, true, true,
          true, true, true, true, true, true, true, true, true,
          true, true, true, true, true, true, true, true,
          NOW(), NOW()
        )
      `;

      await pg.query(insertQuery);
      console.log('Default siteconfig row inserted successfully');
    } else {
      console.log('Siteconfig already has data');
    }

    // Verify the data
    const verifyResult = await pg.query('SELECT sports FROM siteconfig LIMIT 1');
    console.log('Sports enabled:', verifyResult.rows[0]?.sports);

  } catch (error) {
    console.error('Error:', error);
  } finally {
    process.exit(0);
  }
}

checkAndInsertSiteConfig();