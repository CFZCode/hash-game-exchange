const { spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const rootDir = path.resolve(__dirname);
const cronDir = path.join(rootDir, 'sportsmain', 'cron');
const logsDir = path.join(rootDir, 'logs');

const cronFiles = ['allevent', 'odds', 'job', 'settlement'];

const apps = [
  {
    name: 'lagaobet-server',
    script: path.join(rootDir, 'index.js'),
    cwd: rootDir,
    out_file: path.join(logsDir, 'lagaobet-server-out.log'),
    error_file: path.join(logsDir, 'lagaobet-server-error.log'),
  },
  ...cronFiles.map((fileName) => ({
    name: `${fileName}-lagaobet`,
    script: path.join(cronDir, `${fileName}.js`),
    cwd: cronDir,
    out_file: path.join(logsDir, `${fileName}-lagaobet-out.log`),
    error_file: path.join(logsDir, `${fileName}-lagaobet-error.log`),
  })),
];

function ensureLogsDir() {
  try {
    fs.mkdirSync(logsDir, { recursive: true });
  } catch (err) {
    console.error('Unable to create logs directory:', err.message);
    process.exit(1);
  }
}

function runPm2(args) {
  const result = spawnSync('pm2', args, { stdio: 'inherit' });
  if (result.error) {
    console.error('Failed to run pm2:', result.error.message);
    process.exit(1);
  }
  if (result.status !== 0) {
    console.error(`pm2 exited with code ${result.status}: pm2 ${args.join(' ')}`);
    process.exit(result.status);
  }
}

function startApp(app) {
  console.log(`\nStopping existing pm2 process for '${app.name}' if present...`);
  spawnSync('pm2', ['delete', app.name], { stdio: 'ignore' });

  const args = [
    'start',
    app.script,
    '--name',
    app.name,
    '--cwd',
    app.cwd,
    '--instances',
    '1',
    '--restart-delay',
    '5000',
    '--max-restarts',
    '10',
    '--merge-logs',
    '--output',
    app.out_file,
    '--error',
    app.error_file,
    '--env',
    'production',
  ];

  console.log(`Starting '${app.name}'...`);
  runPm2(args);
}

function main() {
  ensureLogsDir();

  for (const app of apps) {
    startApp(app);
  }

  console.log('\nAll configured PM2 apps are now started.');
  console.log('Run `pm2 status` to verify.');
}

if (require.main === module) {
  main();
} else {
  module.exports = { apps, main };
}
