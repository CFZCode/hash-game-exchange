/* ──────────────────────────────────────────────────────────────────────────
   ⚠ DEPRECATED — DO NOT APPLY. Use reconcile_to_ledger.js instead.
   This script sums the `credit=` value out of each FAN-loss ledger description,
   but a description can record a credit that was never applied to the wallet
   (the desc is built before the `fixed → 0` override / under old code). On a real
   account that over-counted by ₹100 (e.g. user 7029357215: this script targets
   ₹74,331; the true ledger balance is ₹74,431). Kept for reference only.
   ---------------------------------------------------------------------------
   ONE-TIME RECONCILIATION — FAN per-bet over-credit repair
   ---------------------------------------------------------------------------
   Background: processnonfancy() used to credit the wallet via calculateFinalCredit(),
   which looked the winner up by NAME in the exposure map. Fancy exposures are keyed
   by the bet's own selection, never the winner name, so:
     • LOSING FAN bets were refunded their full stake (wallet ended ABOVE the ledger)
     • WINNING FAN bets were sometimes paid 0 (wallet ended BELOW the ledger)
   The settlement code is now fixed; this script repairs balances already settled.

   Every `FAN per-bet` ledger row stores the wrong wallet amount in its description
   (`...; credit=X`). For LOSSES the correct credit was 0, so the wallet was
   over-credited by exactly X — that is fully recoverable here and is reversed.

   WINS are only REPORTED (not auto-adjusted): the correct payout needs the blocked
   liability which isn't in the ledger, and some may have been manually compensated.

   USAGE (run from myapp/backend):
     node scripts/one-off/reconcile_fan_overcredit.js          # DRY RUN (no writes)
     APPLY=1 node scripts/one-off/reconcile_fan_overcredit.js  # apply, in one txn
   ────────────────────────────────────────────────────────────────────────── */
const { pool, withTransaction } = require('../../General/Model/pool');

const APPLY = process.env.APPLY === '1';
const round2 = (n) => Math.round((Number(n) || 0) * 100) / 100;

// Pull the wallet amount that was actually applied at settlement out of the desc.
function parseCredit(desc) {
  const m = /credit=(-?\d+(?:\.\d+)?)/.exec(desc || '');
  return m ? Number(m[1]) : null;
}

(async () => {
  console.log(`\n=== FAN over-credit reconciliation (${APPLY ? 'APPLY' : 'DRY RUN'}) ===\n`);

  const { rows } = await pool.query(`
    SELECT id, user_id, currency, netamount, description
      FROM credits_ledger
     WHERE description LIKE 'FAN per-bet%'
     ORDER BY user_id, created_at ASC
  `);

  const perUser = new Map();   // user_id -> { overcredit, lossRows, winRows, badRows }
  for (const r of rows) {
    const credit = parseCredit(r.description);
    const u = perUser.get(r.user_id) || { overcredit: 0, lossRows: [], winRows: [], badRows: [] };
    if (credit == null) { u.badRows.push(r.id); }          // couldn't parse — review by hand
    else if (Number(r.netamount) < 0) {                    // LOSS: over-credited by `credit`
      u.overcredit += credit;
      u.lossRows.push({ id: r.id, credit });
    } else if (Number(r.netamount) > 0) {                  // WIN: report only
      u.winRows.push({ id: r.id, credit, net: Number(r.netamount) });
    }
    perUser.set(r.user_id, u);
  }

  let totalOver = 0, affected = 0, flaggedNeg = 0, flaggedWins = 0, flaggedBad = 0;
  const updates = [];   // { user_id, currency, from, to, delta }

  for (const [user_id, u] of perUser) {
    const overcredit = round2(u.overcredit);
    if (u.winRows.length) flaggedWins++;
    if (u.badRows.length) flaggedBad++;
    if (overcredit <= 0) continue;

    // Currency column: FAN bets are INR per the ledger rows above.
    const { rows: wRows } = await pool.query(`SELECT inr FROM credits WHERE uid = $1`, [String(user_id)]);
    if (!wRows.length) { console.log(`! user ${user_id}: no credits row, skipping`); continue; }
    const cur = round2(wRows[0].inr);
    const target = round2(cur - overcredit);

    affected++;
    totalOver += overcredit;

    if (target < 0) {
      flaggedNeg++;
      console.log(`⚠ user ${user_id}: over-credited ₹${overcredit}, but wallet only ₹${cur} → would go negative (₹${target}). NEEDS MANUAL REVIEW (funds likely withdrawn). SKIPPED.`);
      continue;
    }

    console.log(`• user ${user_id}: wallet ₹${cur} → ₹${target}  (debit ₹${overcredit}; ${u.lossRows.length} losing FAN bets)`);
    if (u.winRows.length) console.log(`    ↳ also ${u.winRows.length} winning FAN bet(s) — review for possible under-payment`);
    updates.push({ user_id, from: cur, to: target, delta: overcredit });
  }

  console.log(`\n--- Summary ---`);
  console.log(`Users with over-credit (loss refunds): ${affected}`);
  console.log(`Total over-credit to recover:          ₹${round2(totalOver)}`);
  console.log(`Skipped (would go negative):           ${flaggedNeg}`);
  console.log(`Users with winning FAN bets to review: ${flaggedWins}`);
  console.log(`Users with unparseable rows:           ${flaggedBad}`);
  console.log(`Wallet updates to apply:               ${updates.length}`);

  if (!APPLY) {
    console.log(`\nDRY RUN — no changes written. Re-run with APPLY=1 to apply the ${updates.length} updates.\n`);
    await pool.end();
    return;
  }

  await withTransaction(async (client) => {
    for (const up of updates) {
      await client.query(`UPDATE credits SET inr = $1 WHERE uid = $2`, [up.to, String(up.user_id)]);
    }
  });
  console.log(`\nAPPLIED ${updates.length} wallet corrections in one transaction.\n`);
  await pool.end();
})().catch(e => { console.error('RECONCILE ERROR', e); process.exit(1); });
