/* READ-ONLY — inspect winning FAN per-bet rows for possible under-payment.
   Old bug could pay a winning FAN bet less than stake+winnings. The correct NET
   wallet effect of a winning bet = netamount (profit). With the stake returned,
   the settlement credit should have been stake + netamount (yes/back). We print
   what was actually applied (`credit=` in desc) vs that expected value so each can
   be judged by hand. USAGE:  node sportsmain/cron/inspect_fan_wins.js */
const { pool } = require('../../General/Model/pool');
const round2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const field = (desc, key) => {
  const m = new RegExp(`${key}="?(-?[\\d.]+|[^";]+)`).exec(desc || '');
  return m ? m[1].trim() : null;
};

(async () => {
  const { rows } = await pool.query(`
    SELECT id, user_id, netamount, profit, created_at, description
      FROM credits_ledger
     WHERE description LIKE 'FAN per-bet%' AND netamount > 0
     ORDER BY user_id, created_at ASC
  `);
  console.log(`\n=== Winning FAN per-bet rows: ${rows.length} ===\n`);
  for (const r of rows) {
    const stake = Number(field(r.description, 'stake'));
    const applied = Number(field(r.description, 'credit'));   // old finalcredit actually credited
    const net = round2(r.netamount);
    const betType = field(r.description, 'bet_type');
    // yes/back: expected settlement credit = stake returned + winnings(=netamount)
    const expectedYesBack = round2(stake + net);
    console.log({
      ledger_id: r.id, user_id: r.user_id, bet_type: betType,
      stake, netamount: net, applied_credit: applied,
      expected_if_yes_back: expectedYesBack,
      shortfall_if_yes_back: round2(expectedYesBack - applied),
      when: r.created_at,
      desc: (r.description || '').slice(0, 160),
    });
  }
  console.log('\nNote: for no/lay bets the blocked liability differs from stake — judge those by hand.\n');
  await pool.end();
})().catch(e => { console.error('ERR', e); process.exit(1); });
