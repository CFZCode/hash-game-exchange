/* ──────────────────────────────────────────────────────────────────────────
   RECONCILE WALLET → LEDGER TRUTH
   ---------------------------------------------------------------------------
   Repairs wallets that drifted from the ledger because of the FAN over-credit /
   NaN settlement bugs. Instead of trusting the (sometimes wrong) `credit=` value
   in each ledger description, this recomputes the AUTHORITATIVE balance the exact
   same way balancesheet/controller.js does — deposits + withdrawals + agent
   transfers + casino + signed sports `netamount` — and sets the live wallet to it.

   Why this is correct and the desc-based reconcile is not:
     • The admin "Net" the operator wants the wallet to match IS this ledger total.
     • A losing bet's description can record a `credit=` it never applied (the desc
       is built before the `fixed → 0` override / under old code), so summing those
       over-counts. Targeting the ledger total sidesteps that entirely.

   SAFETY:
     • Skips any user with OPEN/unsettled bets — their wallet legitimately sits
       below the ledger (stake is held), so we must not "correct" it.
     • By default only applies REDUCTIONS (wallet above ledger = over-credit to
       reclaim). Increasing a wallet (paying a user) requires ALLOW_CREDIT=1, so a
       ledger gap can never silently hand out money.

   USAGE (from myapp/backend):
     node scripts/one-off/reconcile_to_ledger.js <userId>            # DRY RUN, one user
     node scripts/one-off/reconcile_to_ledger.js --all              # DRY RUN, every user with a wallet
     APPLY=1 node scripts/one-off/reconcile_to_ledger.js <userId>   # apply (single txn)
     APPLY=1 ALLOW_CREDIT=1 node scripts/one-off/reconcile_to_ledger.js --all
   ────────────────────────────────────────────────────────────────────────── */
const { pool, withTransaction } = require('../../General/Model/pool');

const APPLY = process.env.APPLY === '1';
const ALLOW_CREDIT = process.env.ALLOW_CREDIT === '1';
const CUR = (process.env.CURRENCY || 'INR').toUpperCase();
const COL = CUR.toLowerCase();
const arg = process.argv[2];
const num = (v) => { const n = Number(v); return Number.isFinite(n) ? n : 0; };
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;

async function ledgerBalance(userId) {
  let bal = 0;
  if (CUR === 'INR') {
    const { rows } = await pool.query(
      `SELECT amount, to_type, to_id FROM staff_transfers
        WHERE transfer_type='transfer'
          AND ((to_type='user' AND to_id=$1) OR (from_type='user' AND from_id=$1))`, [userId]);
    for (const t of rows) bal += num(t.amount) * (t.to_type === 'user' && String(t.to_id) === String(userId) ? 1 : -1);
  }
  { const { rows } = await pool.query(
      `SELECT amount FROM fiat_deposits WHERE user_id=$1 AND upper(currency)=$2 AND lower(status) IN ('approved','success','done','completed')`, [userId, CUR]);
    for (const x of rows) bal += num(x.amount); }
  { const { rows } = await pool.query(
      `SELECT amount FROM apaydeposits WHERE user_id=$1 AND upper(currency)=$2 AND status='Success'`, [userId, CUR]);
    for (const x of rows) bal += num(x.amount); }
  { const { rows } = await pool.query(
      `SELECT amount FROM fiat_withdrawals WHERE uid=$1 AND upper(currency)=$2 AND lower(status) NOT IN ('rejected','failed')`, [userId, CUR]);
    for (const x of rows) bal -= num(x.amount); }
  { const { rows } = await pool.query(
      `SELECT amount FROM apaywithdrawals WHERE user_id=$1::text AND upper(currency)=$2 AND status IN ('Success','Pending') AND COALESCE(refunded,false)=false`, [String(userId), CUR]);
    for (const x of rows) bal -= num(x.amount); }
  { const { rows } = await pool.query(
      `SELECT netamount, amount FROM credits_ledger WHERE user_id::text=$1::text AND upper(currency)=$2`, [String(userId), CUR]);
    for (const x of rows) bal += x.netamount != null ? num(x.netamount) : num(x.amount); }
  { const CUR2COL = { PKR:'inr', INR:'inr', USD:'usdt', USDT:'usdt', EUR:'eur' };
    const wallet = CUR2COL[CUR];
    if (wallet) {
      const gisCur = Object.keys(CUR2COL).filter(c => CUR2COL[c] === wallet);
      const { rows } = await pool.query(
        `SELECT amount, action FROM gis_transactions WHERE user_id=$1 AND upper(currency)=ANY($2::text[])`, [userId, gisCur]);
      for (const x of rows) bal += num(x.amount) * (x.action === 'bet' ? -1 : 1);
    } }
  return r2(bal);
}

// Does the user have ANY tracked funding row? If not, their wallet was seeded by an
// untracked path (admin/test credit that logs nothing) and the ledger reconstruction
// is meaningless — we must never reduce a wallet we cannot account for.
async function hasTrackedFunding(userId) {
  const { rows } = await pool.query(
    `SELECT
       (SELECT COUNT(*) FROM staff_transfers WHERE transfer_type='transfer'
          AND ((to_type='user' AND to_id=$1) OR (from_type='user' AND from_id=$1)))
     + (SELECT COUNT(*) FROM fiat_deposits  WHERE user_id=$1)
     + (SELECT COUNT(*) FROM apaydeposits   WHERE user_id=$1) AS c`, [userId]);
  return Number(rows[0].c) > 0;
}

async function openBetStake(userId) {
  const { rows } = await pool.query(
    `SELECT COUNT(*) c, COALESCE(SUM(stake_amount),0) stake FROM "SportsBet"
      WHERE user_id=$1 AND status IN ('open','manual')`, [String(userId)]);
  return { count: Number(rows[0].c), stake: r2(rows[0].stake) };
}

(async () => {
  console.log(`\n=== reconcile wallet → ledger (${CUR}) (${APPLY ? 'APPLY' : 'DRY RUN'}) ===\n`);

  let userIds;
  if (arg && arg !== '--all') {
    userIds = [arg];
  } else if (arg === '--all') {
    const { rows } = await pool.query(`SELECT uid FROM credits WHERE ${COL} IS NOT NULL ORDER BY uid`);
    userIds = rows.map(r => String(r.uid));
  } else {
    console.error('usage: node reconcile_to_ledger.js <userId> | --all'); await pool.end(); process.exit(1);
  }

  const updates = [];
  let skippedOpen = 0, skippedCredit = 0, skippedIncomplete = 0, inSync = 0;

  for (const userId of userIds) {
    const { rows: w } = await pool.query(`SELECT ${COL} AS bal FROM credits WHERE uid=$1`, [String(userId)]);
    if (!w.length) continue;
    const live = r2(w[0].bal);
    const target = await ledgerBalance(userId);
    const delta = r2(target - live);
    if (Math.abs(delta) < 0.01) { inSync++; continue; }

    // A wallet can never be negative. A negative target means the ledger sources
    // don't fully reconstruct this user's balance (direct admin credit, test funding,
    // a channel the controller doesn't track) — so the ledger is NOT authoritative
    // here and we must not touch the wallet.
    if (target < 0) {
      console.log(`⏭  user ${userId}: target ₹${target} < 0 — ledger incomplete, NOT a clean over-credit. SKIP (manual review)`);
      skippedIncomplete++; continue;
    }

    if (!(await hasTrackedFunding(userId))) {
      console.log(`⏭  user ${userId}: wallet ₹${live} but NO tracked funding rows — seeded by an untracked admin/test credit. SKIP (wallet is the only record).`);
      skippedIncomplete++; continue;
    }

    const ob = await openBetStake(userId);
    if (ob.count > 0) {
      console.log(`⏭  user ${userId}: drift ₹${r2(live - target)} but ${ob.count} open bet(s) (₹${ob.stake} held) — SKIP (wallet legitimately below ledger)`);
      skippedOpen++; continue;
    }
    if (delta > 0 && !ALLOW_CREDIT) {
      console.log(`⏭  user ${userId}: ledger ₹${target} > wallet ₹${live} (under-credited by ₹${delta}) — SKIP (set ALLOW_CREDIT=1 to pay out)`);
      skippedCredit++; continue;
    }
    console.log(`• user ${userId}: wallet ₹${live} → ₹${target}  (${delta < 0 ? 'reclaim' : 'credit'} ₹${Math.abs(delta)})`);
    updates.push({ userId, live, target, delta });
  }

  console.log(`\n--- Summary ---`);
  console.log(`Already in sync           : ${inSync}`);
  console.log(`Skipped (ledger incomplete): ${skippedIncomplete}`);
  console.log(`Skipped (open bets)       : ${skippedOpen}`);
  console.log(`Skipped (would credit)    : ${skippedCredit}`);
  console.log(`Wallet updates to apply   : ${updates.length}`);
  const net = r2(updates.reduce((s, u) => s + u.delta, 0));
  console.log(`Net wallet change         : ₹${net}`);

  if (!APPLY) { console.log(`\nDRY RUN — no changes written. Re-run with APPLY=1 to apply ${updates.length} update(s).\n`); await pool.end(); return; }

  // --all is a TRIAGE report, not a bulk-apply list: it surfaces directly-funded /
  // test accounts the ledger can't see (e.g. ₹1,000,000 → ₹0). Refuse to mass-write
  // unless the operator has reviewed and explicitly opts in.
  if (arg === '--all' && process.env.CONFIRM_BULK !== '1') {
    console.log(`\nREFUSING bulk apply across ${updates.length} users without review.`);
    console.log(`Apply per verified user:  APPLY=1 node scripts/one-off/reconcile_to_ledger.js <userId>`);
    console.log(`Or, after reviewing every line above:  CONFIRM_BULK=1 APPLY=1 ... --all\n`);
    await pool.end(); return;
  }

  await withTransaction(async (client) => {
    for (const u of updates) await client.query(`UPDATE credits SET ${COL} = $1 WHERE uid = $2`, [u.target, String(u.userId)]);
  });
  console.log(`\nAPPLIED ${updates.length} wallet correction(s) in one transaction.\n`);
  await pool.end();
})().catch(e => { console.error('RECONCILE ERROR', e); process.exit(1); });
