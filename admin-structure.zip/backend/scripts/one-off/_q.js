/* READ-ONLY ad-hoc query runner.
   USAGE (from myapp/backend):  node scripts/one-off/_q.js "SELECT ..."
   Refuses anything that is not a single SELECT/WITH statement.
*/
const { pool } = require('../../General/Model/pool');

const sql = process.argv[2];
if (!sql) { console.error('usage: node scripts/one-off/_q.js "<select>"'); process.exit(1); }

const stripped = sql.replace(/--[^\n]*/g, '').trim().replace(/;\s*$/, '');
if (!/^(select|with)\b/i.test(stripped) || /;/.test(stripped)) {
  console.error('refused: read-only single SELECT/WITH statements only'); process.exit(1);
}
if (/\b(insert|update|delete|drop|alter|truncate|create|grant|copy)\b/i.test(stripped)) {
  console.error('refused: mutating keyword detected'); process.exit(1);
}

(async () => {
  try {
    const { rows } = await pool.query(stripped);
    console.log(JSON.stringify(rows, null, 1));
    console.error(`(${rows.length} rows)`);
  } catch (e) { console.error('ERROR: ' + e.message); process.exitCode = 1; }
  finally { await pool.end(); }
})();
