#!/usr/bin/env node
/**
 * Follow-up to fix_inverted_mo_settlements.js: the JS-side deltas were sent as floats
 * into numeric columns, leaving ~2.7e-7 of dust on users.total_profit / gt / net_win
 * (e.g. 16340209.4500000002668). Values are correct to the paisa; this just rounds the
 * columns to 2dp so reports don't render the trailing noise.
 *
 * Usage: node scripts/one-off/round_shiv81_numeric_dust.js [--apply]
 */
const { pool } = require('../../General/Model/pool');
const APPLY = process.argv.includes('--apply');
const USER_ID = '6631974593';

(async () => {
    const before = (await pool.query(
        `SELECT net_win::text, net_loss::text, total_profit::text, gt::text FROM users WHERE id=$1`, [USER_ID])).rows;
    console.log('BEFORE'); console.table(before);

    if (!APPLY) { console.log('DRY RUN — re-run with --apply'); await pool.end(); return; }

    await pool.query(
        `UPDATE users SET total_profit = round(total_profit, 2), gt = round(gt, 2),
                          net_win = round(net_win, 2), net_loss = round(net_loss, 2)
         WHERE id = $1`, [USER_ID]);

    const after = (await pool.query(
        `SELECT net_win::text, net_loss::text, total_profit::text, gt::text FROM users WHERE id=$1`, [USER_ID])).rows;
    console.log('AFTER'); console.table(after);
    const last = (await pool.query(
        `SELECT closing::text FROM credits_ledger WHERE user_id=$1 ORDER BY id DESC LIMIT 1`, [USER_ID])).rows[0];
    const u = after[0];
    console.log('last ledger closing:', last.closing, '| total_profit:', u.total_profit);
    console.log('identity net_win+net_loss:', (Number(u.net_win) + Number(u.net_loss)).toFixed(2));
    await pool.end();
})().catch(e => { console.error('FAILED:', e.message); process.exit(1); });
