#!/usr/bin/env node
/**
 * One-off repair for MO/BM markets that settled INVERTED for user 6631974593 (Shiv81).
 *
 * Cause (fixed in sportsmain/cron/settlement.js):
 *   resolveMobmWinner() mapped the result feed's runner name ("Jan-Lennard Struff ")
 *   back onto the short event-title label ("Struff" = team_one), then
 *   moBmBetWinCredit() tested `norm(selection_name) === norm(winnerName)`.
 *   "janlennard struff" !== "struff", so selIsWinner was false for EVERY bet in the
 *   market: backs on the actual winner were booked as losses and lays against the
 *   winner as wins. The same mismatch made findExposureValue() miss both exposure
 *   keys, so finalcredit came out 0 and the liability blocked at bet placement was
 *   never released back to the wallet.
 *
 * Affected markets (found by scanning every 'MO/BM per-bet' ledger row for a winner
 * label that strictly equals no selection but fuzzy-matches one):
 *   1. match 5160166007896 'Fe Cina v Halys'      Bookmaker        winner Quentin Halys
 *   2. match 5790435291741 'Struff v Alek Shevchenko' Game Winner 3/8  winner Jan-Lennard Struff
 *
 * Everything below is DERIVED from the stored rows (odds, stake, liability, and the
 * exposure snapshot in sports_settlement_report) — not hand-entered — and asserted
 * against the recorded values before anything is written.
 *
 * Usage:  node scripts/one-off/fix_inverted_mo_settlements.js          (dry run)
 *         node scripts/one-off/fix_inverted_mo_settlements.js --apply  (one transaction)
 */
const fs = require('fs');
const path = require('path');
const { pool, withTransaction } = require('../../General/Model/pool');

const APPLY = process.argv.includes('--apply');
const USER_ID = '6631974593';
const r2 = (n) => Math.round(Number(n) * 100) / 100;
const norm = (s) => (s || '').toString().toLowerCase().replace(/\s+/g, ' ').replace(/[^\w\s]/g, '').trim();
function namesMatch(a, b) {
    const x = norm(a), y = norm(b);
    if (!x || !y) return false;
    if (x === y) return true;
    if (x.startsWith(y) || y.startsWith(x)) return true;
    return x.includes(y) || y.includes(x);
}
const matchesAny = (names, t) => (Array.isArray(names) ? names : [names]).some(n => namesMatch(n, t));
function runnerList(bet) {
    let r = bet?.runners;
    if (typeof r === 'string') { try { r = JSON.parse(r); } catch (e) { r = null; } }
    return Array.isArray(r) ? r.filter(x => typeof x === 'string' && x.trim()) : [];
}
function pickRunner(runners, name) {
    const t = norm(name);
    if (!t || !runners.length) return null;
    for (const r of runners) if (norm(r) === t) return r;
    for (const r of runners) { const n = norm(r); if (n.startsWith(t) || t.startsWith(n)) return r; }
    for (const r of runners) { const n = norm(r); if (n.includes(t) || t.includes(n)) return r; }
    return null;
}
function sideAliases(bet) {
    const runners = runnerList(bet);
    const one = [bet?.team_one].filter(Boolean);
    const two = [bet?.team_two].filter(Boolean);
    if (runners.length === 2) {
        const r1 = pickRunner(runners, bet.team_one);
        const r2x = pickRunner(runners, bet.team_two);
        if (r1) one.push(r1);
        if (r2x && r2x !== r1) two.push(r2x);
        if (r1 && !r2x) { const rest = runners.find(r => r !== r1); if (rest) two.push(rest); }
        if (!r1 && r2x) { const rest = runners.find(r => r !== r2x); if (rest) one.push(rest); }
    }
    return { one, two, runners };
}
// settlement.js getOdds(): BM prices are stored as integers (87 -> 1.87, 151 -> 2.51)
function normalizeOdds(odds) {
    let n;
    if (odds > 100) n = (odds / 100) + 1;
    else if (odds < 100) n = 1 + (odds / 100);
    else n = 2.0;
    return Math.floor(n * 100) / 100;
}
const getOdds = (b) => String(b.game_type).toUpperCase() === 'BM' ? normalizeOdds(Number(b.odds)) : Number(b.odds);
const findExposure = (map, names, fb) => {
    for (const name of names) {
        const t = norm(name); if (!t) continue;
        for (const k of Object.keys(map || {})) if (norm(k) === t) return Number(map[k]);
    }
    return fb;
};

const MARKETS = [
    { match_id: '5160166007896', market_type: 'Bookmaker', winner: 'Quentin Halys ', marketwin_id: 195 },
    { match_id: '5790435291741', market_type: 'Game Winner 3/8', winner: 'Jan-Lennard Struff ', marketwin_id: 213 },
];
// First ledger row of the earliest affected market, and the closing immediately before
// it. Verified: the closing chain obeys closing[i]-closing[i-1] === netamount[i] from
// ledger id 600 onward, so the chain can be re-walked exactly from here.
const CHAIN_FROM_ID = 750;
const CHAIN_BASELINE = 9207750;

(async () => {
    const q = async (sql, p = []) => (await pool.query(sql, p)).rows;
    const snap = { markets: [] };
    snap.credits = await q(`SELECT * FROM credits WHERE uid=$1`, [USER_ID]);
    snap.users = await q(`SELECT id, net_win, net_loss, total_profit, gt FROM users WHERE id=$1`, [USER_ID]);
    snap.ledger_chain = await q(`SELECT * FROM credits_ledger WHERE user_id=$1 AND id >= $2 ORDER BY id`, [USER_ID, CHAIN_FROM_ID]);

    let dNetWin = 0, dNetLoss = 0, dWallet = 0;
    const ledgerFix = new Map();   // ledger id -> corrected fields
    const betFix = new Map();      // bet id    -> corrected result_status
    const plan = [];

    for (const M of MARKETS) {
        const bets = await q(
            `SELECT * FROM "SportsBet" WHERE user_id=$1 AND match_id=$2 AND market_type=$3 ORDER BY id`,
            [USER_ID, M.match_id, M.market_type]);
        const ledger = await q(
            `SELECT * FROM credits_ledger WHERE user_id=$1 AND match_id=$2 AND market_type=$3 ORDER BY id`,
            [USER_ID, M.match_id, M.market_type]);
        const report = await q(
            `SELECT * FROM sports_settlement_report WHERE user_id=$1 AND match_id=$2 AND market_type=$3 ORDER BY id`,
            [USER_ID, M.match_id, M.market_type]);
        snap.markets.push({ ...M, bets, ledger, report,
            marketwins: await q(`SELECT * FROM "marketwins" WHERE id=$1`, [M.marketwin_id]) });

        if (!bets.length || bets.length !== ledger.length) throw new Error(`${M.match_id}: ${bets.length} bets vs ${ledger.length} ledger rows`);

        // the winner must be a real runner of this market
        const sides = sideAliases(bets[0]);
        const winnerIsOne = matchesAny(sides.one, M.winner);
        const winnerIsTwo = matchesAny(sides.two, M.winner);
        if (winnerIsOne === winnerIsTwo) throw new Error(`${M.match_id}: winner "${M.winner}" is ambiguous between sides`);

        // exposure snapshot the settlement itself recorded (authoritative)
        const withMap = report.find(r => r.exposures_map && Object.keys(r.exposures_map).length);
        if (!withMap) throw new Error(`${M.match_id}: no exposures snapshot in sports_settlement_report`);
        const map = withMap.exposures_map;
        const t1 = findExposure(map, sides.one, 0);
        const t2 = findExposure(map, sides.two, 0);
        if (t1 === 0 || t2 === 0) throw new Error(`${M.match_id}: exposures did not resolve (${JSON.stringify(map)})`);

        // finalcredit exactly as processMobmGroup computes it once names resolve
        let finalcredit = 0;
        const [w, l] = winnerIsOne ? [t1, t2] : [t2, t1];
        if (t1 > 0 && t2 > 0) finalcredit = w;
        else if (t1 < 0 && t2 < 0) finalcredit = Math.abs(l) - Math.abs(w);
        else if (w <= 0) finalcredit = 0;
        else finalcredit = Math.abs(t1) + Math.abs(t2);
        finalcredit = r2(Math.max(0, finalcredit));

        const creditedBefore = r2(report.reduce((a, r) => a + Number(r.credit_amount || 0), 0));
        dWallet = r2(dWallet + finalcredit - creditedBefore);

        const rows = [];
        let mNet = 0;
        for (const b of bets) {
            const lg = ledger.find(x => x.bet_id === b.id);
            if (!lg) throw new Error(`bet ${b.id}: no ledger row`);
            const isBack = String(b.bet_type).toLowerCase() === 'back';
            const selWins = namesMatch(b.selection_name, M.winner);
            const odds = getOdds(b);
            const stake = Number(b.stake_amount);
            const credit = isBack ? (selWins ? r2(Math.max(0, (odds - 1) * stake)) : 0)
                                  : (selWins ? 0 : r2(stake));
            const status = credit > 0 ? 'won' : 'loss';
            let profit = 0, loss = 0;
            if (credit > 0) profit = credit;
            else if (isBack) loss = r2(-stake);
            else loss = r2(-Number(b.liability));
            const net = r2(profit + loss);
            mNet = r2(mNet + net);

            dNetWin = r2(dNetWin + profit - Number(lg.profit || 0));
            dNetLoss = r2(dNetLoss + loss - Number(lg.loss || 0));

            betFix.set(b.id, status);
            ledgerFix.set(lg.id, { amount: credit, profit, loss: loss || null, netamount: net, bet_id: b.id, market: M });
            rows.push({ bet: b.id, type: b.bet_type, stake, odds, sel: b.selection_name.trim(),
                was: b.result_status, now: status,
                netamount: `${Number(lg.netamount)} -> ${net}` });
        }
        plan.push({ M, rows, finalcredit, creditedBefore, t1, t2, sides, mNet,
            oldNet: r2(ledger.reduce((a, r) => a + Number(r.netamount || 0), 0)) });
    }

    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const backup = path.join(__dirname, `backup_inverted_mo_${stamp}.json`);
    fs.writeFileSync(backup, JSON.stringify(snap, null, 2));
    console.log(`Backup: ${backup}`);

    for (const p of plan) {
        console.log(`\n===== ${p.M.match_id}  ${p.M.market_type}  winner="${p.M.winner}" =====`);
        console.log(`sides: ${JSON.stringify(p.sides.one)} exp=${p.t1}  |  ${JSON.stringify(p.sides.two)} exp=${p.t2}`);
        console.table(p.rows);
        console.log(`market P&L: ${p.oldNet} -> ${p.mNet}   wallet credit: ${p.creditedBefore} -> ${p.finalcredit}`);
    }

    // ---- rewrite the closing chain by walking netamount ----
    let running = CHAIN_BASELINE;
    const chainPlan = [];
    for (const row of snap.ledger_chain) {
        const fix = ledgerFix.get(row.id);
        const net = fix ? fix.netamount : r2(Number(row.netamount || 0));
        running = r2(running + net);
        if (r2(Number(row.closing)) !== running) chainPlan.push({ id: row.id, was: Number(row.closing), now: running });
    }
    console.log(`\n===== CLOSING CHAIN: ${chainPlan.length} of ${snap.ledger_chain.length} rows shift =====`);
    console.table(chainPlan.slice(0, 12));
    if (chainPlan.length > 12) console.log(`... +${chainPlan.length - 12} more`);

    const u = snap.users[0], wal = snap.credits[0];
    const dTotal = r2(dNetWin + dNetLoss);
    const newTP = r2(Number(u.total_profit) + dTotal);
    console.log('\n===== BALANCES =====');
    console.table([
        { field: 'credits.inr (wallet)', was: Number(wal.inr), delta: dWallet, now: r2(Number(wal.inr) + dWallet) },
        { field: 'users.net_win', was: Number(u.net_win), delta: dNetWin, now: r2(Number(u.net_win) + dNetWin) },
        { field: 'users.net_loss', was: Number(u.net_loss), delta: dNetLoss, now: r2(Number(u.net_loss) + dNetLoss) },
        { field: 'users.total_profit', was: Number(u.total_profit), delta: dTotal, now: newTP },
        { field: 'users.gt', was: Number(u.gt), delta: dTotal, now: r2(Number(u.gt) + dTotal) },
    ]);

    // ---- guards ----
    const newNW = r2(Number(u.net_win) + dNetWin), newNL = r2(Number(u.net_loss) + dNetLoss);
    if (r2(newNW + newNL) !== newTP) throw new Error(`net_win+net_loss (${r2(newNW + newNL)}) != total_profit (${newTP})`);
    if (running !== newTP) throw new Error(`chain end (${running}) != total_profit (${newTP})`);
    if (r2(Number(u.total_profit)) !== r2(Number(snap.ledger_chain[snap.ledger_chain.length - 1].closing)))
        throw new Error('pre-state: total_profit != last closing');
    console.log('\nguards OK: chain end == total_profit == net_win+net_loss');

    if (!APPLY) { console.log('\nDRY RUN — re-run with --apply to write.'); await pool.end(); return; }

    const note = `[corrected ${new Date().toISOString()}] inverted MO settlement: winner label was the event-title name`;
    await withTransaction(async (c) => {
        for (const [betId, status] of betFix)
            await c.query(`UPDATE "SportsBet" SET result_status=$1, updated_at=NOW() WHERE id=$2`, [status, betId]);

        let run = CHAIN_BASELINE;
        for (const row of snap.ledger_chain) {
            const fix = ledgerFix.get(row.id);
            const net = fix ? fix.netamount : r2(Number(row.netamount || 0));
            run = r2(run + net);
            if (fix) {
                const desc = `MO/BM per-bet; winner="${fix.market.winner}"; bet_id=${fix.bet_id}; ` +
                             `credit=${fix.amount}; ${note}`;
                await c.query(
                    `UPDATE credits_ledger SET amount=$1, profit=$2, loss=$3, netamount=$4, closing=$5, description=$6 WHERE id=$7`,
                    [fix.amount, fix.profit, fix.loss, fix.netamount, run, desc, row.id]);
            } else if (r2(Number(row.closing)) !== run) {
                await c.query(`UPDATE credits_ledger SET closing=$1 WHERE id=$2`, [run, row.id]);
            }
        }

        if (dWallet !== 0) await c.query(`UPDATE credits SET inr = inr + $1 WHERE uid=$2`, [dWallet, USER_ID]);
        await c.query(
            `UPDATE users SET net_win = net_win + $1, net_loss = net_loss + $2,
                              total_profit = total_profit + $3, gt = COALESCE(gt,0) + $3 WHERE id=$4`,
            [dNetWin, dNetLoss, dTotal, USER_ID]);

        for (const p of plan) {
            await c.query(`UPDATE "marketwins" SET winteam=$1, team1ex=$2, team2ex=$3, payout=$4 WHERE id=$5`,
                [p.M.winner, p.t1, p.t2, p.finalcredit, p.M.marketwin_id]);
            const reports = snap.markets.find(m => m.match_id === p.M.match_id).report;
            const first = reports[0]?.bet_id;
            for (const rep of reports)
                await c.query(
                    `UPDATE sports_settlement_report
                        SET resolved_winner=$1, resolved_team=$1, credit_amount=$2,
                            decision_path = to_jsonb(ARRAY[$3::text, $4::text]) WHERE id=$5`,
                    [p.M.winner, rep.bet_id === first ? p.finalcredit : 0,
                     `matched runner "${p.M.winner}"`, note, rep.id]);
        }
    });
    console.log('\nAPPLIED.');

    const after = {
        bets: await q(`SELECT id, match_id, bet_type, selection_name, result_status FROM "SportsBet"
                       WHERE user_id=$1 AND match_id = ANY($2) ORDER BY id`, [USER_ID, MARKETS.map(m => m.match_id)]),
        user: (await q(`SELECT net_win, net_loss, total_profit, gt FROM users WHERE id=$1`, [USER_ID]))[0],
        wallet: (await q(`SELECT inr FROM credits WHERE uid=$1`, [USER_ID]))[0],
        last: (await q(`SELECT id, closing FROM credits_ledger WHERE user_id=$1 ORDER BY id DESC LIMIT 1`, [USER_ID]))[0],
    };
    console.log('\n===== AFTER =====');
    console.table(after.bets.map(b => ({ ...b, selection_name: b.selection_name.trim() })));
    console.table([{ ...after.user, wallet_inr: after.wallet.inr, last_closing: after.last.closing }]);
    console.log(`identity: net_win+net_loss = ${r2(Number(after.user.net_win) + Number(after.user.net_loss))} | total_profit = ${Number(after.user.total_profit)} | last closing = ${Number(after.last.closing)}`);
    await pool.end();
})().catch(e => { console.error('FAILED:', e.message); process.exit(1); });
