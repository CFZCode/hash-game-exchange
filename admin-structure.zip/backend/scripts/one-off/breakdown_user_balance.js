/* READ-ONLY — full per-source breakdown of a user's wallet vs every money source.
   Distinguishes a genuine wallet bug from a balance-sheet blind spot (gt/casino
   transfers, admin credits, sports placement) that the balance sheet omits.
   USAGE: node scripts/one-off/breakdown_user_balance.js <userId> [currency]
*/
const { pool } = require('../../General/Model/pool');
const userId = process.argv[2];
const CUR = (process.argv[3] || 'INR').toUpperCase();
const COL = CUR.toLowerCase();
const num = (v) => { const n = Number(v); return Number.isFinite(n) ? n : 0; };
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
if (!userId) { console.error('usage: <userId> [cur]'); process.exit(1); }

async function sumQ(label, sql, params, sign = 1, field = 'amount') {
  try {
    const { rows } = await pool.query(sql, params);
    let s = 0; for (const r of rows) s += num(r[field]);
    return { label, total: r2(sign * s), n: rows.length };
  } catch (e) { return { label, total: 0, n: 0, err: e.message }; }
}

(async () => {
  const parts = [];
  // agent transfers split by type
  for (const t of ['transfer', 'gt', 'casino']) {
    const { rows } = await pool.query(
      `SELECT amount, to_type, to_id FROM staff_transfers
        WHERE transfer_type=$2 AND ((to_type='user' AND to_id=$1) OR (from_type='user' AND from_id=$1))`, [userId, t]);
    let s = 0; for (const r of rows) s += num(r.amount) * (r.to_type === 'user' && String(r.to_id) === String(userId) ? 1 : -1);
    parts.push({ label: `staff_transfers[${t}]`, total: r2(s), n: rows.length });
  }
  parts.push(await sumQ('fiat_deposits', `SELECT amount FROM fiat_deposits WHERE user_id=$1 AND upper(currency)=$2 AND lower(status) IN ('approved','success','done','completed')`, [userId, CUR], +1));
  parts.push(await sumQ('apaydeposits', `SELECT amount FROM apaydeposits WHERE user_id=$1 AND upper(currency)=$2 AND status='Success'`, [userId, CUR], +1));
  parts.push(await sumQ('fiat_withdrawals', `SELECT amount FROM fiat_withdrawals WHERE uid=$1 AND upper(currency)=$2 AND lower(status) NOT IN ('rejected','failed')`, [userId, CUR], -1));
  parts.push(await sumQ('apaywithdrawals', `SELECT amount FROM apaywithdrawals WHERE user_id=$1::text AND upper(currency)=$2 AND status IN ('Success','Pending') AND COALESCE(refunded,false)=false`, [String(userId), CUR], -1));
  // sports cron settlement (net)
  { const { rows } = await pool.query(`SELECT netamount, amount FROM credits_ledger WHERE user_id::text=$1::text AND upper(currency)=$2`, [String(userId), CUR]);
    let s = 0; for (const r of rows) s += r.netamount != null ? num(r.netamount) : num(r.amount); parts.push({ label: 'credits_ledger(net)', total: r2(s), n: rows.length }); }
  // casino
  { const CUR2COL = { PKR:'inr', INR:'inr', USD:'usdt', USDT:'usdt', EUR:'eur' }; const w = CUR2COL[CUR];
    if (w) { const gc = Object.keys(CUR2COL).filter(c => CUR2COL[c] === w);
      const { rows } = await pool.query(`SELECT amount, action FROM gis_transactions WHERE user_id=$1 AND upper(currency)=ANY($2::text[])`, [userId, gc]);
      let s = 0; for (const r of rows) s += num(r.amount) * (r.action === 'bet' ? -1 : 1); parts.push({ label: 'gis_transactions', total: r2(s), n: rows.length }); } }
  // sports placement/payout via sportbetscontroller path (SportsBet table) — settled bets
  { const { rows } = await pool.query(`SELECT status, COUNT(*) c, COALESCE(SUM(stake_amount),0) stake FROM "SportsBet" WHERE user_id=$1 GROUP BY status`, [String(userId)]);
    parts.push({ label: 'SportsBet rows (info)', total: 0, n: rows.reduce((a,b)=>a+Number(b.c),0), info: rows.map(r=>`${r.status}:${r.c}(₹${r2(r.stake)})`).join(' ') }); }

  const { rows: w } = await pool.query(`SELECT ${COL} AS bal FROM credits WHERE uid=$1`, [String(userId)]);
  const live = w.length ? r2(num(w[0].bal)) : null;
  const trackedAll = r2(parts.reduce((a, p) => a + p.total, 0));
  const bsLedger = r2(parts.filter(p => !['staff_transfers[gt]','staff_transfers[casino]','SportsBet rows (info)'].includes(p.label)).reduce((a,p)=>a+p.total,0));

  console.log(`\n=== user ${userId} (${CUR}) ===`);
  console.log(`live wallet            : ₹${live}`);
  for (const p of parts) console.log(`  ${p.label.padEnd(24)} ₹${String(p.total).padStart(12)}  (${p.n} rows)${p.info ? '  '+p.info : ''}${p.err ? '  ERR:'+p.err : ''}`);
  console.log(`  ${'—'.repeat(40)}`);
  console.log(`balance-sheet ledger   : ₹${bsLedger}   (admin "Net" — excludes gt/casino transfers)`);
  console.log(`ALL sources (incl gt)  : ₹${trackedAll}`);
  console.log(`drift vs balance-sheet : ₹${r2(live - bsLedger)}`);
  console.log(`drift vs ALL sources   : ₹${r2(live - trackedAll)}   <- if ~0, wallet is CORRECT (balance-sheet just hides gt)\n`);
  await pool.end();
})().catch(e => { console.error('ERR', e); process.exit(1); });
