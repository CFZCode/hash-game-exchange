/* READ-ONLY diagnostic — reconcile one user's wallet against the ledger.
   No writes. Mirrors balancesheet/controller.js to compute the authoritative
   ledger balance, then compares to the live wallet and lists the FAN rows.

   USAGE (from myapp/backend):
     node scripts/one-off/diagnose_user_balance.js <userId> [currency]
*/
const { pool } = require('../../General/Model/pool');

const userId = process.argv[2];
const cur = (process.argv[3] || 'INR').toUpperCase();
const col = cur.toLowerCase();
const num = (v) => { const n = Number(v); return Number.isFinite(n) ? n : 0; };
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;

if (!userId) { console.error('usage: node diagnose_user_balance.js <userId> [currency]'); process.exit(1); }

(async () => {
  let ledger = 0;

  // agent transfers (INR only)
  if (cur === 'INR') {
    const { rows } = await pool.query(
      `SELECT amount, to_type, to_id FROM staff_transfers
        WHERE transfer_type='transfer'
          AND ((to_type='user' AND to_id=$1) OR (from_type='user' AND from_id=$1))`, [userId]);
    for (const t of rows) ledger += num(t.amount) * (t.to_type === 'user' && String(t.to_id) === String(userId) ? 1 : -1);
  }
  // deposits
  for (const q of [
    [`SELECT amount FROM fiat_deposits WHERE user_id=$1 AND upper(currency)=$2 AND lower(status) IN ('approved','success','done','completed')`, +1],
    [`SELECT amount FROM apaydeposits WHERE user_id=$1 AND upper(currency)=$2 AND status='Success'`, +1],
  ]) { const { rows } = await pool.query(q[0], [userId, cur]); for (const x of rows) ledger += q[1] * num(x.amount); }
  // withdrawals
  { const { rows } = await pool.query(
      `SELECT amount FROM fiat_withdrawals WHERE uid=$1 AND upper(currency)=$2 AND lower(status) NOT IN ('rejected','failed')`, [userId, cur]);
    for (const x of rows) ledger -= num(x.amount); }
  { const { rows } = await pool.query(
      `SELECT amount FROM apaywithdrawals WHERE user_id=$1::text AND upper(currency)=$2 AND status IN ('Success','Pending') AND COALESCE(refunded,false)=false`, [String(userId), cur]);
    for (const x of rows) ledger -= num(x.amount); }
  // sports settlement (signed netamount)
  { const { rows } = await pool.query(
      `SELECT netamount, amount FROM credits_ledger WHERE user_id::text=$1::text AND upper(currency)=$2`, [String(userId), cur]);
    for (const x of rows) ledger += x.netamount != null ? num(x.netamount) : num(x.amount); }
  // casino
  { const CUR2COL = { PKR:'inr', INR:'inr', USD:'usdt', USDT:'usdt', EUR:'eur' };
    const wallet = CUR2COL[cur];
    if (wallet) {
      const gisCur = Object.keys(CUR2COL).filter(c => CUR2COL[c] === wallet);
      const { rows } = await pool.query(
        `SELECT amount, action FROM gis_transactions WHERE user_id=$1 AND upper(currency)=ANY($2::text[])`, [userId, gisCur]);
      for (const x of rows) ledger += num(x.amount) * (x.action === 'bet' ? -1 : 1);
    } }

  // live wallet
  const { rows: w } = await pool.query(`SELECT ${col} AS bal FROM credits WHERE uid=$1`, [String(userId)]);
  const live = w.length ? num(w[0].bal) : null;

  // open (unsettled) bets — if any, the wallet legitimately sits below the ledger
  const { rows: ob } = await pool.query(
    `SELECT COUNT(*) c, COALESCE(SUM(stake_amount),0) stake FROM "SportsBet"
      WHERE user_id=$1 AND status IN ('open','manual')`, [String(userId)]);

  // FAN loss rows (what the reconcile script keys on)
  const { rows: fan } = await pool.query(
    `SELECT id, netamount, description FROM credits_ledger
      WHERE user_id::text=$1::text AND description LIKE 'FAN per-bet%' AND netamount < 0
      ORDER BY created_at`, [String(userId)]);

  console.log(`\n=== user ${userId} (${cur}) ===`);
  console.log(`live wallet     : ₹${r2(live)}`);
  console.log(`ledger balance  : ₹${r2(ledger)}   <- admin "Net"`);
  console.log(`drift (live-ledg): ₹${r2(live - ledger)}`);
  console.log(`open bets       : ${ob[0].c} (stake ₹${r2(ob[0].stake)})`);
  console.log(`\nFAN loss rows the reconcile script would reverse:`);
  for (const f of fan) {
    const m = /credit=(-?\d+(?:\.\d+)?)/.exec(f.description || '');
    console.log(`  id=${f.id} net=${r2(f.netamount)} desc credit=${m ? m[1] : 'NaN/none'}`);
  }
  console.log(`\nCorrect target wallet (match the ledger) = ₹${r2(ledger)}\n`);
  await pool.end();
})().catch(e => { console.error('DIAG ERROR', e); process.exit(1); });
