// One-off: make wallet_history.transaction_time auto-populate on insert, and
// backfill existing NULL rows. Safe to re-run.
const { pool } = require('../General/Model/pool');

(async () => {
  try {
    await pool.query(`ALTER TABLE wallet_history ALTER COLUMN transaction_time SET DEFAULT NOW()`);
    console.log('Default set: transaction_time -> NOW()');

    const r = await pool.query(`UPDATE wallet_history SET transaction_time = NOW() WHERE transaction_time IS NULL`);
    console.log(`Backfilled ${r.rowCount} NULL row(s).`);
  } catch (e) {
    console.error('Failed:', e.message);
    process.exitCode = 1;
  } finally {
    await pool.end();
  }
})();
