/*
 * 3D Game (MyApp) — routes.
 * Mounted at /api/3dgame (../index.js). See README.md.
 */

const express = require('express');
const router = express.Router();
const { launchGame, gameCallback } = require('./controller');
const { protectStaff } = require('../system/middleware/auth');
const admin = require('./adminController');

router.post('/launch', launchGame);
router.post('/callback', gameCallback);

// Admin panel "3D Games" page: dashboard | gameplay | users | live
router.get('/admin/:report', protectStaff, admin.superAdminOnly, admin.report);

module.exports = router;
