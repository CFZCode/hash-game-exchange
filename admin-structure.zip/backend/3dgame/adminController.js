/*
 * 3D Game (MyApp) — admin panel reports.
 *
 * The game server owns the gameplay data (rounds, pots, the 5% house
 * commission), so these handlers only forward the admin panel's request to it
 * and hand back the answer. The panel never talks to the game server itself:
 * staff auth lives here, and the game server trusts this backend through a
 * shared key (THREEDGAME_ADMIN_KEY here = ADMIN_API_KEY there).
 * See README.md.
 */

const axios = require('axios');

// Same box as the game server, so skip the public round trip by default.
const ADMIN_URL = process.env.THREEDGAME_ADMIN_URL || 'http://127.0.0.1:9073/api/v1/admin/3d-games';

const REPORTS = ['dashboard', 'gameplay', 'users', 'live'];

// Platform-wide money figures: SuperAdmin only. Executives act as their parent
// staff (protectStaff), so a SuperAdmin's executive passes on level 0 too.
const superAdminOnly = (req, res, next) => {
  const staff = req.staff || {};
  if (staff.db_role === 'SuperAdmin' || Number(staff.level) === 0) return next();
  return res.status(403).json({ success: false, message: 'Only the super admin can view 3D game reports' });
};

const report = async (req, res) => {
  const name = req.params.report;
  if (!REPORTS.includes(name)) return res.status(404).json({ success: false, message: 'Unknown report' });

  const key = process.env.THREEDGAME_ADMIN_KEY;
  if (!key) {
    console.error('[3dgame] THREEDGAME_ADMIN_KEY is not set');
    return res.status(503).json({ success: false, message: '3D game reports are not configured' });
  }

  try {
    // "All games" / "all time" arrive as empty values; the game server reads an
    // empty filter as an invalid one, so leave those out.
    const params = Object.fromEntries(Object.entries(req.query).filter(([, v]) => v !== ''));
    const { data } = await axios.get(`${ADMIN_URL}/${name}`, {
      params,
      headers: { 'x-admin-key': key },
      timeout: 20000,
    });
    return res.json(data);
  } catch (err) {
    const status = err.response && err.response.status;
    const message = err.response && err.response.data && err.response.data.message;
    // A bad filter is the caller's mistake — pass the reason through.
    if (status === 400) return res.status(400).json({ success: false, message: message || 'Invalid filter' });
    // Anything else (incl. the game server rejecting our key) is ours to fix;
    // never relay its 401, the panel would log the staff member out.
    console.error('[3dgame] admin report failed', name, status || '', message || err.message);
    return res.status(502).json({ success: false, message: '3D game server is not reachable right now' });
  }
};

module.exports = { report, superAdminOnly };
