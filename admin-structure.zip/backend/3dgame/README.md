# 3D Game launch proxy

Launch proxy for the MyApp 3D game titles, same provider endpoint the Teen
Patti module uses (`../teenpatti/`).

Mounted at **`/api/3dgame`** (`../index.js`), so the public path is
`POST /api/3dgame/launch`.

## Request / response

`POST /api/3dgame/launch`

Body:

```json
{ "user_id": "123", "currency": "INR" }
```

`user_id` is required; `currency` defaults to `INR`. The player's name is read
from `users` and the launch `amount` is the player's **entire `credits.inr`
balance** — the browser no longer sends (or decides) an amount. The proxy
forwards the payload to the provider's launch endpoint (as camelCase — the
provider's contract) and returns its `gameUrl` as `game_url`.

| Status | Body |
|---|---|
| 200 | `{ success: true, game_url }` |
| 400 | `{ success: false, message }` — missing `user_id`, or `credits.inr` ≤ 0 |
| 403 | `{ success: false, message }` — provider refused this player; not retryable |
| 404 | `{ success: false, message: 'User not found' }` |
| 409 | `{ success: false, message: 'Game is already open…' }` — one live session per user |
| 502 | `{ success: false, message }` — provider down, timeout, or non-success payload |

## Callback

`POST /api/3dgame/callback` — called by the provider's game server. Body carries
a `type`:

- `type: "launch"` — acknowledged with `{ success: true, message: "success" }`,
  nothing stored.
- `type: "active"` — inserts a row into `3d_game_session` (`session_id`,
  `user_id`, `initial_amount`) **and debits `initial_amount` from
  `credits.inr`**, both inside one DB transaction (`withTransaction`). A
  replayed callback finds the row already there (`ON CONFLICT DO NOTHING`,
  rowCount 0) and does **not** debit again — it still gets success. If the
  player's `inr` is below `initial_amount` the whole thing rolls back and the
  reply is 400 `Insufficient balance`, so the session is not recorded. On
  success the reply is exactly `{ success: true, message: "success" }` — the
  game server only proceeds on that exact shape, so don't change it.
- `type: "result"` — matches the `3d_game_session` row by `sessionId` and, only
  if `session_closed` is still `false`, stores `finalAmount` → `final_amount`,
  `netResult` → `net_result`, flips `session_closed` to `true` **and credits
  `finalAmount` back to `credits.inr`** (same transaction). The net effect on
  the player across a session is therefore `finalAmount - initialAmount` =
  `netResult`. A replayed callback matches no open row and credits nothing.
  Replies `{ success: true, message: "success" }` either way.
- any other `type` — logged, replies 400 `{ success: false, message: 'unknown type' }`.

The launch payload sends this endpoint's public URL to the provider as
`callbackUrl` (from `THREEDGAME_CALLBACK_URL`), so launch and callback both
live on this one module.

## Admin reports

`GET /api/3dgame/admin/:report` — `dashboard`, `gameplay`, `users` or `live`.
Feeds the admin panel's **3D Games** page (collection, the 5% house commission,
round-by-round game play, who played, live tables).

Staff token required (`protectStaff`) and **SuperAdmin only** — the figures are
platform-wide, not scoped to a downline. The query string is forwarded as-is to
the game server's `GET /api/v1/admin/3d-games/:report` and its JSON is returned
unchanged; the parameters and response shapes are documented in the game
server repo (`ADMIN-3DGAMES-API.md`).

The game server trusts this backend through a shared key sent as `x-admin-key`.
A 400 from it (bad filter) is passed through; any other failure becomes a 502
so a game-server auth problem can never log a staff member out of the panel.

## Configuration

| Env var | Default | Meaning |
|---|---|---|
| `THREEDGAME_LAUNCH_URL` | `https://example.com/api/v1/user/launch` | Provider launch endpoint |
| `THREEDGAME_ADMIN_URL` | `http://127.0.0.1:9073/api/v1/admin/3d-games` | Game server admin reports base URL |
| `THREEDGAME_ADMIN_KEY` | *(empty — reports return 503)* | Shared key; must equal the game server's `ADMIN_API_KEY` |
| `THREEDGAME_CALLBACK_URL` | *(empty)* | Public URL of `POST /api/3dgame/callback`, e.g. `https://<our-domain>/api/3dgame/callback`; sent to the provider at launch |

## Session table

```sql
CREATE TABLE IF NOT EXISTS "3d_game_session" (
  session_id      varchar(64) PRIMARY KEY,
  user_id         varchar(64) NOT NULL,
  initial_amount  numeric     NOT NULL,
  final_amount    numeric     DEFAULT 0,
  net_result      numeric     DEFAULT 0,
  session_closed  boolean     DEFAULT false
);
```

`session_id` is the provider session `String(_id)`, `initial_amount` the launch
`amount`, `final_amount`/`net_result` come from session close
(`session.finalCoins` / `session.netResult`), and `session_closed` starts
`false` until the session is settled.

## Interim state — read before shipping to players

The `amount` is now server-decided (the player's `credits.inr`), so the browser
can no longer mint game coins. But `user_id` is still trusted from the request
body — there is no `guardPlayer` auth, so anyone can launch (and thereby lock
up the balance of) any user id they can guess. Before go-live, switch to the
Teen Patti pattern (session token → uid).
