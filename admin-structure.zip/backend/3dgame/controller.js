/*
 * 3D Game (MyApp) — launch controller.
 * The launch reserve is the player's whole INR balance; see README.md.
 */

const axios = require('axios');
const pg = require('../General/Model');
const { withTransaction } = require('../General/Model/pool');

const LAUNCH_URL = process.env.THREEDGAME_LAUNCH_URL || 'https://example.com/api/v1/user/launch';
// Public URL of our own POST /api/3dgame/callback, sent to the provider at launch.
const CALLBACK_URL = process.env.THREEDGAME_CALLBACK_URL || 'https://example.com/api/3dgame/callback';

// The provider's game server treats a callback as OK only on exactly this shape.
const CALLBACK_OK = { success: true, message: 'success' };

const fail = (res, status, message) => res.status(status).json({ success: false, message });

/* ---------------------------------- launch --------------------------------- */

const launchGame = async (req, res) => {
  const { user_id, currency } = req.body;
  if (!user_id) return fail(res, 400, 'user_id is required');

  // Name comes from users, the reserve from credits — not from the browser.
  let userName;
  let amount;
  try {
    const { rows: users } = await pg.query('SELECT name FROM users WHERE id = $1', [user_id]);
    if (!users[0]) return fail(res, 404, 'User not found');
    userName = users[0].name || 'Player';

    const { rows: credits } = await pg.query('SELECT inr FROM credits WHERE uid = $1', [
      String(user_id),
    ]);
    amount = Number(credits[0] && credits[0].inr) || 0;
  } catch (err) {
    console.error('[3dgame] user/balance lookup failed', err.message);
    return fail(res, 500, 'Server error');
  }

  //if (amount <= 0) return fail(res, 400, 'Insufficient INR balance');

  try {
    console.log('[3dgame] launch', { user_id, userName, amount, currency });

    // Provider payload stays camelCase — that's MyApp's contract.
    const { data } = await axios.post(
      LAUNCH_URL,
      {
        userId: String(user_id),
        userName,
        amount,
        currency: currency || 'INR',
        callbackUrl: CALLBACK_URL,
      },
      { timeout: 15000 }
    );

    if (!data || !data.success || !data.gameUrl) {
      return fail(res, 502, (data && data.message) || 'Game is not available right now.');
    }

    return res.json({ success: true, game_url: data.gameUrl });
  } catch (err) {
    const status = err.response && err.response.status;
    const message = err.response && err.response.data && err.response.data.message;

    if (status === 409) {
      return fail(res, 409, 'Game is already open. Please close the other tab first.');
    }
    if (status === 403) {
      console.error('[3dgame] launch refused for user_id', user_id, message || '');
      return fail(res, 403, message || 'This account cannot open the game.');
    }
    console.error('[3dgame] launch failed', status || '', message || err.message);
    return fail(res, 502, 'Game is not available right now. Please try again.');
  }
};


const sessionActive = ({ sessionId, userId, initialAmount }) =>
  withTransaction(async (client) => {
    const ins = await client.query(
      `INSERT INTO "3d_game_session" (session_id, user_id, initial_amount)
       VALUES ($1, $2, $3)
       ON CONFLICT (session_id) DO NOTHING`,
      [String(sessionId), String(userId), Number(initialAmount) || 0]
    );
    if (ins.rowCount === 0) return; // replay — already opened and debited

    const debit = await client.query(
      `UPDATE credits SET inr = inr - $2 WHERE uid = $1 AND inr >= $2`,
      [String(userId), Number(initialAmount) || 0]
    );
    if (debit.rowCount === 0) {
      throw Object.assign(new Error('Insufficient balance'), { insufficient: true });
    }
  });

const sessionResult = ({ sessionId, finalAmount, netResult }) =>
  withTransaction(async (client) => {
    const upd = await client.query(
      `UPDATE "3d_game_session"
       SET final_amount = $2, net_result = $3, session_closed = true
       WHERE session_id = $1 AND session_closed = false
       RETURNING user_id`,
      [String(sessionId), Number(finalAmount) || 0, Number(netResult) || 0]
    );
    if (upd.rowCount === 0) return;

    const credit = Number(finalAmount) || 0;
    if (credit > 0) {
      await client.query('UPDATE credits SET inr = inr + $2 WHERE uid = $1', [
        upd.rows[0].user_id,
        credit,
      ]);
    }
  });

const gameCallback = async (req, res) => {
  const { type, sessionId, userId, initialAmount } = req.body;

  try {
    if (type === 'launch') return res.json(CALLBACK_OK);

    if (type === 'active') {
      if (!sessionId || !userId || !initialAmount) {
        return fail(res, 400, 'sessionId, userId and initialAmount are required');
      }
      await sessionActive(req.body);
      return res.json(CALLBACK_OK);
    }

    if (type === 'result') {
      if (!sessionId) return fail(res, 400, 'sessionId is required');
      await sessionResult(req.body);
      return res.json(CALLBACK_OK);
    }

    console.error('[3dgame] callback with unknown type', type);
    return fail(res, 400, 'unknown type');
  } catch (err) {
    if (err.insufficient) return fail(res, 400, 'Insufficient balance');
    console.error('[3dgame] callback failed', err.message);
    return fail(res, 500, 'Server error');
  }
};

module.exports = { launchGame, gameCallback };
