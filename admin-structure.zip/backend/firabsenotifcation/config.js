const admin = require('firebase-admin');
const serviceAccount = require('../myapp-e3078-firebase-adminsdk-fbsvc-be450133a1.json');

admin.initializeApp({
    credential: admin.credential.cert(serviceAccount)
});

module.exports = admin;
