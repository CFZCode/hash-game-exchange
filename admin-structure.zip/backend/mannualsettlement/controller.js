
// import xssClean from "xss-clean";
// import fetch from "node-fetch";
// import Wallet from "../model/admin/Wallet.js";
// import SportsBet from "../model/user/SportsBet.js";
// import UserExposure from "../model/user/UserExposure.js";
// import sequelize from "../config/db.js";
// import MannualResult from '../model/admin/manualresult.js'

// import { Op, Sequelize } from "sequelize";
// import { fn, col, literal } from "sequelize";

const pg = require('../General/Model')


let cachedUsdRate = 0;
let cachedAt = 0;

const getMoMatches = async (req, res) => {
    const limit = parseInt(req.query.limit, 10) || 100;
    const offset = parseInt(req.query.offset, 10) || 0;

    try {
        const query = `
            SELECT 
                match_id,
                eventid,
                game_type,
                market_type,
                MAX(match_title) AS match_title,
                MAX(team_one) AS team_one,
                MAX(team_two) AS team_two,
                COUNT(*) AS totalbets,

                (ARRAY_AGG(counts ORDER BY created_at DESC))[1] AS counts,
                (ARRAY_AGG(runners ORDER BY created_at DESC))[1] AS runners

            FROM "SportsBet"
            WHERE game_type IN ('MO', 'BM')
              AND status = 'open'
              AND match_id IS NOT NULL
              AND eventid IS NOT NULL

            GROUP BY match_id, eventid, game_type, market_type
            ORDER BY MAX(created_at) DESC
            LIMIT $1 OFFSET $2
        `;

        const { rows } = await pg.query(query, [limit, offset]);

        const payload = rows.map(r => ({
            matchId: r.match_id,
            eventId: r.eventid,
            gameType: r.game_type,
            marketType: r.market_type,
            matchTitle: r.match_title,
            teamOne: r.team_one,
            teamTwo: r.team_two,
            totalBets: parseInt(r.totalbets, 10),
            counts: r.counts,
            runners: r.runners
        }));

        return res.json({ success: true, data: payload });

    } catch (err) {
        console.error('getMoMatches error:', err);
        return res.status(500).json({ success: false, error: err.message });
    }
};

// ------------------------ EXPORT ------------------------
const getFanOpenBets = async (req, res) => {
    const limit = parseInt(req.query.limit, 10) || 100;
    const offset = parseInt(req.query.offset, 10) || 0;

    const marketsforfancy = [
        '1st Innings 6 Overs Line',
        '2nd Innings 6 Overs Line',
        '3rd Innings 6 Overs Line',
        '1st Innings 50 Overs Line',
        '2nd Innings 50 Overs Line',
        '3rd Innings 50 Overs Line',
        '1st Innings 40 Overs Line',
        '2nd Innings 40 Overs Line',
        '3rd Innings 40 Overs Line',
        '1st Innings 30 Overs Line',
        '2nd Innings 30 Overs Line',
        '3rd Innings 30 Overs Line',
        '1st Innings 20 Overs Line',
        '2nd Innings 20 Overs Line',
        '3rd Innings 20 Overs Line',
        '1st Innings 10 Overs Line',
        '2nd Innings 10 Overs Line',
        '3rd Innings 10 Overs Line',
        'Over By Over',
        'Ball By Ball',
        'Normal',
        'khado',
        'meter',
        'fancy1',
        'oddeven'
    ];

    try {
        // 1. Get Aggregated Groups
        const query = `
    SELECT
        match_id,
        eventid,
        market_type,
        selection_name,
        game_type,
        MAX(match_title) AS match_title,
        MAX(event_name) AS event_name,
        COUNT(*) AS totalbets,
        MAX(counts) AS counts
    FROM "SportsBet"
    WHERE game_type = 'FAN'
      AND status = 'open'
      AND match_id IS NOT NULL
      AND eventid IS NOT NULL
    GROUP BY match_id, eventid, market_type, selection_name, game_type
    ORDER BY MAX(created_at) DESC
    LIMIT $1 OFFSET $2
`;

        const { rows: groups } = await pg.query(query, [limit, offset]);

        if (!groups.length) {
            return res.json({ success: true, data: { fancy1: [], others: [] } });
        }

        // 1. Build Criteria
        const criteria = groups.map(g => ({
            match_id: g.match_id,
            eventid: g.eventid,
            market_type: g.market_type,
            selection_name: g.selection_name,
            game_type: g.game_type
        }));

        // 2. Build Dynamic WHERE (OR conditions)
        let values = [];
        let conditions = [];

        criteria.forEach((c) => {
            const baseIndex = values.length;

            conditions.push(`(
        match_id = $${baseIndex + 1}
        AND eventid = $${baseIndex + 2}
        AND market_type = $${baseIndex + 3}
        AND selection_name = $${baseIndex + 4}
        AND game_type = $${baseIndex + 5}
    )`);

            values.push(
                c.match_id,
                c.eventid,
                c.market_type,
                c.selection_name,
                c.game_type
            );
        });

        // 3. Final Query
        const query2 = `
    SELECT *
    FROM "SportsBet"
    WHERE status = 'open'
    ${conditions.length ? `AND (${conditions.join(' OR ')})` : ''}
    ORDER BY created_at ASC
`;

        // 4. Execute
        const { rows: bets } = await pg.query(query2, values);

        // 3. Grouping Map
        const groupMap = new Map();
        groups.forEach(g => {
            let mType = g.market_type;
            let groupKey = mType; // Default: use the market type itself
            const isFancy = marketsforfancy.includes(mType);

            if (!isFancy) {
                // Keep original mType, but group under 'others'
                groupKey = 'others';
            }

            // For fancy markets, include selection_name to keep each session separate.
            // For 'others', omit selection_name so all selections merge into one entry.
            const key = isFancy
                ? `${g.match_id}||${g.eventid}||${mType}||${g.game_type}||${g.selection_name}`
                : `${g.match_id}||${g.eventid}||${mType}||${g.game_type}`;

            if (groupMap.has(key)) {
                const existing = groupMap.get(key);
                existing.totalBets += parseInt(g.totalbets, 10);
            } else {
                groupMap.set(key, {
                    groupKey,
                    matchId: g.match_id,
                    eventId: g.eventid,
                    matchTitle: g.match_title,
                    eventName: g.event_name || null,
                    marketType: mType, // Original type
                    selectionName: isFancy ? g.selection_name : undefined,
                    gameType: g.game_type,
                    totalBets: parseInt(g.totalbets, 10),
                    counts: g.counts !== null ? Number(g.counts) : null,
                    bets: []
                });
            }
        });

        // 4. Attach Bets
        bets.forEach(b => {
            let mType = b.market_type;
            const isFancy = marketsforfancy.includes(mType);

            // Match the same key logic used when building the groupMap
            const key = isFancy
                ? `${b.match_id}||${b.eventid}||${mType}||${b.game_type}||${b.selection_name}`
                : `${b.match_id}||${b.eventid}||${mType}||${b.game_type}`;
            const bucket = groupMap.get(key);
            if (bucket) {
                bucket.bets.push({
                    id: b.id,
                    userId: b.user_id,
                    betType: b.bet_type,
                    selectionName: b.selection_name,
                    marketType: b.market_type,
                    gameType: b.game_type,
                    teamOne: b.team_one,
                    teamTwo: b.team_two,
                    odds: b.odds !== null ? Number(b.odds) : null,
                    stakeAmount: b.stake_amount !== null ? Number(b.stake_amount) : null,
                    originalCurrency: b.original_currency,
                    originalAmount: b.original_amount !== null ? Number(b.original_amount) : null,
                    usdAmount: b.usd_amount !== null ? Number(b.usd_amount) : null,
                    liability: b.liability !== null ? Number(b.liability) : null,
                    status: b.status,
                    createdAt: b.created_at,
                    eventName: b.event_name || null,
                    counts: b.counts !== null ? Number(b.counts) : null,
                    runners: b.runners || null
                });
            }
        });

        // 5. Final Payload
        const payload = {};
        // Initialize payload keys
        marketsforfancy.forEach(m => {
            payload[m] = [];
        });
        payload['others'] = [];

        for (const val of groupMap.values()) {
            const listKey = val.groupKey;
            delete val.groupKey;

            if (payload[listKey]) {
                payload[listKey].push(val);
            } else {
                // strict fallback, though if logic holds it should already be 'others'
                payload['others'].push(val);
            }
        }

        return res.json({ success: true, data: payload });

    } catch (err) {

        console.error('getFanOpenBets error:', err);
        return res.status(500).json({ success: false, error: err.message });
    }
};



const declareResult = async (req, res) => {
    const { eventid, match_id, match_title, game_type, market_type, winnerName, winnerId, fancyName } = req.body;

    const keys = ['eventid', 'match_id', 'match_title', 'game_type', 'market_type'];

    const missingKeys = keys.find(key => !req.body[key]);
    if (missingKeys) {
        return res.status(400).json({ success: false, error: `${missingKeys} is required` });
    }

    try {
        await pg.query('BEGIN');

        // 1. Insert into mannual_result
        const insertQuery = `
            INSERT INTO mannual_result 
            (eventid, match_id, match_title, game_type, market_type, "winnerName", "winnerId", "fancyName", created_at, updated_at)
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8,NOW(),NOW())
            RETURNING *
        `;

        const result = await pg.query(insertQuery, [
            eventid,
            match_id,
            match_title,
            game_type,
            market_type,
            winnerName || null,
            winnerId || null,
            fancyName || null
        ]);

        // 2. Update sports_bet
        let updateQuery = `
            UPDATE "SportsBet"
            SET status = 'manual'
            WHERE match_id = $1
              AND market_type = $2
              AND game_type = $3
              AND status = 'open'
        `;

        const values = [match_id, market_type, game_type];

        if (['fancy1', 'oddeven', 'Over By Over', 'Ball By Ball', 'khado', 'meter', 'Normal'].includes(market_type)) {
            updateQuery += ` AND selection_name = $4`;
            values.push(fancyName);
        }

        const updateRes = await pg.query(updateQuery, values);

        await pg.query('COMMIT');

        return res.status(200).json({
            success: true,
            message: "Result declared successfully",
            data: {
                manualResult: result.rows[0],
                updatedBets: updateRes.rowCount
            }
        });

    } catch (error) {
        await pg.query('ROLLBACK');
        console.error("declareResult error:", error);

        return res.status(500).json({
            success: false,
            error: error.message
        });
    }
};

const voidResult = async (req, res) => {
    const { eventid, match_id, market_type, gametype, selection_name } = req.body;



    const keys = ["match_id", "market_type", "gametype", "selection_name"];

    const missingKeys = keys.find(key => !req.body[key]);
    if (missingKeys) {
        return res.status(400).json({ success: false, error: `${missingKeys} is required` });
    }

    try {
        await pg.query('BEGIN');

        let where = `WHERE match_id = $1 AND market_type = $2 AND status = 'open'`;
        const values = [match_id, market_type];

        if (gametype) {
            values.push(gametype);
            where += ` AND game_type = $${values.length}`;
        }

        if (selection_name) {
            values.push(selection_name);
            where += ` AND selection_name = $${values.length}`;
        }

        // 1. Get users
        const usersRes = await pg.query(`
            SELECT DISTINCT user_id FROM "SportsBet" ${where}
        `, values);

        const userIds = usersRes.rows.map(r => r.user_id);

        for (let uid of userIds) {

            const exposureRes = await pg.query(`
                SELECT * FROM user_exposures
                WHERE user_id = $1 AND match_id = $2 AND game_type = $3
            `, [uid, match_id, market_type]);

            let minExp = 0;

            exposureRes.rows.forEach(e => {
                const val = parseFloat(e.exposure_amount || 0);
                if (val < minExp) minExp = val;
            });

            if (minExp < 0) {
                await pg.query(`
                    UPDATE credits
                    SET inr = inr + $1
                    WHERE uid = $2
                `, [Math.abs(minExp), uid]);
            }

            await pg.query(`
                DELETE FROM user_exposures
                WHERE user_id = $1 AND match_id = $2 AND game_type = $3
            `, [uid, match_id, market_type]);
        }

        // 2. Update bets
        await pg.query(`
            UPDATE "SportsBet"
            SET status = 'closed',
                result_status = 'refunded',
                match_end_time = NOW()
            ${where}
        `, values);

        await pg.query('COMMIT');

        return res.json({
            success: true,
            message: "Voided successfully",
            count: userIds.length
        });

    } catch (error) {
        await pg.query('ROLLBACK');
        console.error("voidResult error:", error);

        return res.status(500).json({
            success: false,
            error: error.message
        });
    }
};

// ─────────────────────────────────────────────
// GET open bets for a specific market (before settlement)
// ─────────────────────────────────────────────
const getOpenBetsForMarket = async (req, res) => {
    const { match_id, market_type, game_type, selection_name } = req.query;

    if (!match_id || !market_type) {
        return res.status(400).json({
            success: false,
            error: "match_id and market_type are required"
        });
    }

    try {
        const query = `
            SELECT 
                b.id,
                b.user_id AS "userId",
                COALESCE(u.name, b.user_id::text) AS "username",
                b.bet_type AS "betType",
                b.selection_name AS "selectionName",
                b.market_type AS "marketType",
                b.game_type AS "gameType",
                b.odds::numeric AS "odds",
                b.stake_amount::numeric AS "stakeAmount",
                b.liability::numeric AS "liability",
                b.status,
                b.match_id AS "matchId",
                b.eventid AS "eventId",
                b.created_at AS "createdAt"
            FROM "SportsBet" b
            LEFT JOIN users u ON u.id = b.user_id
               WHERE 
                b.match_id = $1
                AND b.market_type = $2
                AND b.status = 'open'
                AND ($3::text IS NULL OR b.game_type = $3)
                AND ($4::text IS NULL OR b.selection_name = $4) 
            ORDER BY b.created_at DESC

        `;

        const values = [
            match_id,
            market_type,
            game_type || null,
            selection_name || null
        ];

        const { rows } = await pg.query(query, values);

        return res.json({ success: true, data: rows });

    } catch (err) {
        console.error('getOpenBetsForMarket error:', err);
        return res.status(500).json({ success: false, error: err.message });
    }
};


const voidSingleOpenBet = async (req, res) => {
    const { bet_id } = req.body;

    if (!bet_id) {
        return res.status(400).json({
            success: false,
            error: "bet_id is required"
        });
    }

    try {
        await pg.query('BEGIN');

        // 1. Get the open bet
        const betResult = await pg.query(
            `SELECT * 
             FROM "SportsBet" 
             WHERE id = $1 AND status = 'open'
             FOR UPDATE`,
            [bet_id]
        );

        if (betResult.rows.length === 0) {
            await pg.query('ROLLBACK');
            return res.status(404).json({
                success: false,
                error: "Open bet not found"
            });
        }

        const bet = betResult.rows[0];
        const uid = bet.user_id;
        const match_id = bet.match_id;
        const market_type = bet.market_type;

        // 2. Get exposures
        const exposureResult = await pg.query(
            `SELECT * 
             FROM "user_exposures" 
             WHERE user_id = $1 
             AND match_id = $2 
             AND game_type = $3`,
            [uid, match_id, market_type]
        );

        const exposures = exposureResult.rows;

        // 3. Count other open bets
        const otherBetsResult = await pg.query(
            `SELECT COUNT(*) 
             FROM "SportsBet" 
             WHERE match_id = $1 
             AND market_type = $2 
             AND user_id = $3 
             AND status = 'open'
             AND id <> $4`,
            [match_id, market_type, uid, bet_id]
        );

        const otherBets = parseInt(otherBetsResult.rows[0].count, 10);

        // 4. Refund logic
        if (otherBets === 0 && exposures.length > 0) {
            let minExp = 0;

            exposures.forEach(e => {
                const val = parseFloat(e.exposure_amount || 0);
                if (val < minExp) minExp = val;
            });

            if (minExp < 0) {
                const refundAmount = Math.abs(minExp);

                await pg.query(
                    `UPDATE "credits" 
                     SET inr = inr + $1 
                     WHERE uid = $2`,
                    [refundAmount, uid]
                );
            }

            // Delete exposures
            await pg.query(
                `DELETE FROM user_exposures 
                 WHERE user_id = $1 
                 AND match_id = $2 
                 AND game_type = $3`,
                [uid, match_id, market_type]
            );
        }

        // 5. Close the bet
        await pg.query(
            `UPDATE "SportsBet" 
             SET status = 'closed',
                 result_status = 'refunded',
                 match_end_time = NOW()
             WHERE id = $1`,
            [bet_id]
        );

        await pg.query('COMMIT');

        return res.json({
            success: true,
            message: "Bet voided successfully",
            betId: bet_id,
            userId: uid
        });

    } catch (error) {
        await pg.query('ROLLBACK');
        console.error("voidSingleOpenBet error:", error);

        return res.status(500).json({
            success: false,
            error: error.message || "Internal Server Error"
        });
    }
};





const controller = {
    getMoMatches,
    getFanOpenBets,
    declareResult,
    voidResult,
    getOpenBetsForMarket,
    voidSingleOpenBet,
};

module.exports = controller;
