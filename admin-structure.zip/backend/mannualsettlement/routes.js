
const express = require("express");
const controller = require("./controller");
const router = express.Router();
const voidAfterSettlementController = require("./voidaftersettlement");
const { protectStaff } = require("../system/middleware/auth");
const { withActivity } = require("../system/utils/recordActivity");


router.get('/momatches', controller.getMoMatches);
router.get('/fanmatches', controller.getFanOpenBets);
router.post('/declareresult', protectStaff,
  withActivity({
    action: 'settle.declare-result',
    describe: req => ({
      targetType: 'MARKET', targetId: req.body && req.body.match_id,
      details: req.body ? {
        eventid: req.body.eventid, market_type: req.body.market_type,
        game_type: req.body.game_type, winnerName: req.body.winnerName,
        winnerId: req.body.winnerId, fancyName: req.body.fancyName,
      } : undefined,
    }),
  }),
  controller.declareResult);
router.post('/void', protectStaff,
  withActivity({
    action: 'settle.void-market',
    describe: req => ({
      targetType: 'MARKET', targetId: req.body && req.body.match_id,
      details: req.body ? {
        eventid: req.body.eventid, market_type: req.body.market_type,
        gametype: req.body.gametype, selection_name: req.body.selection_name,
      } : undefined,
    }),
  }),
  controller.voidResult);




// // Void per bet (before settlement)
router.get('/open-bets', controller.getOpenBetsForMarket);
router.post('/void-single-bet', protectStaff,
  withActivity({
    action: 'settle.void-bet',
    describe: req => ({ targetType: 'BET', targetId: req.body && req.body.bet_id }),
  }),
  controller.voidSingleOpenBet);

// // Void after settlement routes
router.get('/settled-markets', voidAfterSettlementController.getSettledMarkets);
router.get('/settled-bets', voidAfterSettlementController.getSettledBets);
// These two are called with the legacy x-staff-id header (no JWT), so they
// can't use protectStaff/withActivity — they log inline via recordActivity.
router.post('/void-market-after-settlement', voidAfterSettlementController.voidMarketAfterSettlement);
router.post('/void-bet-after-settlement', voidAfterSettlementController.voidSingleBetAfterSettlement);

// module.exports = router;
module.exports = router;