
const pg = require('../General/Model')
const { recordActivity } = require('../system/utils/recordActivity')

// Actor id comes from the legacy x-staff-id header (these routes predate JWT auth).
const headerStaffId = (req) => {
  const v = req.headers && (req.headers['x-staff-id'] || req.headers['x_staff_id']);
  const n = Number(v);
  return Number.isFinite(n) && n > 0 ? n : null;
};



// ─────────────────────────────────────────────
// 1. GET settled markets
// ─────────────────────────────────────────────
const getSettledMarkets = async (req, res) => {
    const limit = parseInt(req.query.limit, 10) || 100;
    const offset = parseInt(req.query.offset, 10) || 0;
    const search = req.query.search || '';

    try {
        let searchClause = '';
        const values = [limit, offset];
        let idx = 3;

        if (search) {
            searchClause = `
                AND (
                    cl.match_id ILIKE $${idx}
                    OR cl.market_type ILIKE $${idx}
                    OR cl.description ILIKE $${idx}
                    OR sb.match_title ILIKE $${idx}
                    OR sb.team_one ILIKE $${idx}
                    OR sb.team_two ILIKE $${idx}
                )
            `;
            values.push(`%${search}%`);
        }

        const query = `
            SELECT
                cl.match_id,
                cl.market_type,
                cl.sport_id,
                MAX(cl.eventid) AS eventid,
                MAX(cl.description) AS description,
                COUNT(cl.id) AS total_entries,
                COUNT(DISTINCT cl.user_id) AS total_users,
                SUM(cl.netamount) AS total_netamount,
                MAX(cl.created_at) AS last_settled_at,
                MAX(sb.match_title) AS match_title,
                MAX(sb.team_one) AS team_one,
                MAX(sb.team_two) AS team_two,
                MAX(sb.game_type) AS game_type
            FROM credits_ledger cl
            LEFT JOIN "SportsBet" sb ON cl.bet_id = sb.id
            WHERE cl.bet_id IS NOT NULL
              AND cl.match_id IS NOT NULL
              AND cl.sport_id IS NOT NULL
              AND cl.created_at >= NOW() - INTERVAL '30 hours'
              ${searchClause}
            GROUP BY cl.match_id, cl.market_type, cl.sport_id
            ORDER BY MAX(cl.created_at) DESC
            LIMIT $1 OFFSET $2
        `;

        const { rows } = await pg.query(query, values);

        return res.json({
            success: true,
            data: rows.map(r => ({
                matchId: r.match_id,
                marketType: r.market_type,
                sportId: r.sport_id,
                eventId: r.eventid,
                description: r.description,
                matchTitle: r.match_title,
                teamOne: r.team_one,
                teamTwo: r.team_two,
                gameType: r.game_type,
                totalEntries: Number(r.total_entries),
                totalUsers: Number(r.total_users),
                totalNetAmount: Number(r.total_netamount) || 0,
                lastSettledAt: r.last_settled_at,
            }))
        });

    } catch (err) {
        console.error('getSettledMarkets error:', err);
        return res.status(500).json({ success: false, error: err.message });
    }
};

// ─────────────────────────────────────────────
// 2. GET settled bets
// ─────────────────────────────────────────────
const getSettledBets = async (req, res) => {
    const { match_id, market_type } = req.query;

    if (!match_id || !market_type) {
        return res.status(400).json({
            success: false,
            error: "match_id and market_type are required"
        });
    }

    try {
        const query = `
            SELECT
                cl.id AS ledger_id,
                cl.bet_id,
                cl.user_id,
                cl.amount,
                cl.netamount,
                cl.profit,
                cl.loss,
                cl.commission,
                cl.description,
                cl.market_type,
                cl.sport_id,
                cl.match_id,
                cl.eventid,
                cl.job_id,
                cl.created_at,
                COALESCE(u.name, cl.user_id::text) AS username,
                sb.bet_type,
                sb.selection_name,
                sb.odds,
                sb.stake_amount,
                sb.game_type,
                sb.result_status
            FROM credits_ledger cl
            LEFT JOIN users u ON cl.user_id::text = u.id::text
            LEFT JOIN "SportsBet" sb ON cl.bet_id = sb.id
            WHERE cl.match_id = $1
              AND cl.market_type = $2
              AND cl.bet_id IS NOT NULL
              AND cl.sport_id IS NOT NULL
              AND cl.created_at >= NOW() - INTERVAL '30 hours'
            ORDER BY cl.created_at DESC
        `;

        const { rows } = await pg.query(query, [match_id, market_type]);

        return res.json({
            success: true,
            data: rows.map(e => ({
                ledgerId: e.ledger_id,
                betId: e.bet_id,
                userId: e.user_id,
                username: e.username,
                amount: Number(e.amount) || 0,
                netamount: Number(e.netamount) || 0,
                profit: Number(e.profit) || 0,
                loss: Number(e.loss) || 0,
                commission: Number(e.commission) || 0,
                description: e.description,
                marketType: e.market_type,
                sportId: e.sport_id,
                matchId: e.match_id,
                eventId: e.eventid,
                jobId: e.job_id,
                createdAt: e.created_at,
                betType: e.bet_type,
                selectionName: e.selection_name,
                odds: e.odds ? Number(e.odds) : null,
                stakeAmount: e.stake_amount ? Number(e.stake_amount) : null,
                gameType: e.game_type,
                resultStatus: e.result_status,
            }))
        });

    } catch (err) {
        console.error('getSettledBets error:', err);
        return res.status(500).json({ success: false, error: err.message });
    }
};

// ─────────────────────────────────────────────
// CORE: Reverse ledger entry
// ─────────────────────────────────────────────
async function reverseLedgerEntry(entry, client) {
    const userId = entry.user_id;
    const amount = Number(entry.amount) || 0;
    const netamount = Number(entry.netamount) || 0;
    const profit = Number(entry.profit) || 0;
    const loss = Number(entry.loss) || 0;

    if (amount !== 0) {
        await client.query(
            `UPDATE credits SET inr = inr - $1 WHERE uid = $2`,
            [amount, userId]
        );
    }

    // `gt` is the user's LIFETIME sports P&L, incremented by the same netamount
    // that settlement added — so a void has to walk it back too, or the figure
    // (and every agent roll-up built on it) keeps counting a voided market.
    await client.query(
        `UPDATE users
         SET net_win = net_win - $1,
             net_loss = net_loss - $2,
             total_profit = total_profit - $3,
             gt = COALESCE(gt, 0) - $3
         WHERE id = $4`,
        [profit, loss, netamount, userId]
    );

    await client.query(
        `DELETE FROM credits_ledger WHERE id = $1`,
        [entry.id]
    );
}

// ─────────────────────────────────────────────
// 3. VOID entire market
// ─────────────────────────────────────────────
const voidMarketAfterSettlement = async (req, res) => {
    const { match_id, market_type } = req.body;

    if (!match_id || !market_type) {
        return res.status(400).json({ success: false, error: "match_id and market_type are required" });
    }

    try {
        await pg.query('BEGIN');

        const { rows: entries } = await pg.query(
            `SELECT * FROM credits_ledger
             WHERE match_id = $1
               AND market_type = $2
               AND bet_id IS NOT NULL
               AND sport_id IS NOT NULL`,
            [match_id, market_type]
        );

        if (!entries.length) {
            await pg.query('ROLLBACK');
            return res.status(404).json({ success: false, error: "No settled entries found" });
        }

        for (const entry of entries) {
            await reverseLedgerEntry(entry, pg);
        }

        await pg.query(
            `UPDATE "SportsBet"
             SET result_status = 'voided_after_settlement'
             WHERE match_id = $1 AND market_type = $2 AND status = 'closed'`,
            [match_id, market_type]
        );

        const userIds = [...new Set(entries.map(e => e.user_id))];

        for (const userId of userIds) {
            const { rows: wallet } = await pg.query(
                `SELECT inr FROM credits WHERE uid = $1 FOR UPDATE`,
                [userId]
            );

            const userEntry = entries.find(e => e.user_id == userId);

            await pg.query(
                `INSERT INTO credits_ledger (
                    user_id, currency, amount, reason, description,
                    match_id, market_type, sport_id, eventid,
                    netamount, profit, loss, closing, commission, balance, created_at
                ) VALUES (
                    $1,'INR',0,'VOID_AFTER_SETTLEMENT',$2,
                    $3,$4,$5,$6,
                    0,0,0,0,0,$7,NOW()
                )`,
                [
                    userId,
                    `Market voided after settlement; match_id=${match_id}; market_type=${market_type}`,
                    match_id,
                    market_type,
                    userEntry?.sport_id,
                    userEntry?.eventid,
                    wallet[0]?.inr || 0
                ]
            );
        }

        await pg.query('COMMIT');

        recordActivity({
            req, action: 'settle.void-market-after',
            targetType: 'MARKET', targetId: match_id,
            details: { market_type, processedEntries: entries.length, affectedUsers: userIds.length },
            actor: { staffId: headerStaffId(req) },
        });
        return res.json({
            success: true,
            message: "Market voided successfully",
            processedEntries: entries.length,
            affectedUsers: userIds.length
        });

    } catch (err) {
        await pg.query('ROLLBACK');
        return res.status(500).json({ success: false, error: err.message });
    }
};

// ─────────────────────────────────────────────
// 4. VOID single bet after settlement
// ─────────────────────────────────────────────
const voidSingleBetAfterSettlement = async (req, res) => {
    const { ledger_id } = req.body;

    if (!ledger_id) {
        return res.status(400).json({ success: false, error: "ledger_id is required" });
    }

    try {
        await pg.query('BEGIN');

        const { rows } = await pg.query(
            `SELECT * FROM credits_ledger WHERE id = $1 AND bet_id IS NOT NULL`,
            [ledger_id]
        );

        if (!rows.length) {
            await pg.query('ROLLBACK');
            return res.status(404).json({ success: false, error: "Ledger entry not found" });
        }

        const entry = rows[0];

        await reverseLedgerEntry(entry, pg);

        await pg.query(
            `UPDATE "SportsBet"
             SET result_status = 'voided_after_settlement'
             WHERE id = $1`,
            [entry.bet_id]
        );

        const { rows: wallet } = await pg.query(
            `SELECT inr FROM credits WHERE uid = $1 FOR UPDATE`,
            [entry.user_id]
        );

        await pg.query(
            `INSERT INTO credits_ledger (
                user_id, currency, amount, reason, description,
                match_id, market_type, sport_id, eventid, job_id, bet_id,
                netamount, profit, loss, closing, commission, balance, created_at
            ) VALUES (
                $1,'INR',0,'VOID_SINGLE_BET_AFTER_SETTLEMENT',$2,
                $3,$4,$5,$6,$7,$8,
                0,0,0,0,0,$9,NOW()
            )`,
            [
                entry.user_id,
                `Bet #${entry.bet_id} voided after settlement`,
                entry.match_id,
                entry.market_type,
                entry.sport_id,
                entry.eventid,
                entry.job_id,
                entry.bet_id,
                wallet[0]?.credit || 0
            ]
        );

        await pg.query('COMMIT');

        recordActivity({
            req, action: 'settle.void-bet-after',
            targetType: 'BET', targetId: ledger_id,
            details: { betId: entry.bet_id, userId: entry.user_id },
            actor: { staffId: headerStaffId(req) },
        });
        return res.json({
            success: true,
            message: "Bet voided successfully",
            betId: entry.bet_id,
            userId: entry.user_id
        });

    } catch (err) {
        await pg.query('ROLLBACK');
        return res.status(500).json({ success: false, error: err.message });
    }
};

module.exports = {
    getSettledMarkets,
    getSettledBets,
    voidMarketAfterSettlement,
    voidSingleBetAfterSettlement
};