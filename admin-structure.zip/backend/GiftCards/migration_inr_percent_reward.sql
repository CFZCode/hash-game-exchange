-- Gift cards: INR currency + percentage-of-deposit rewards.
-- Existing cards were created in USD, so the column is added with DEFAULT 'USD'
-- (back-filling them as USD), then the default is switched to INR for new cards.

BEGIN;

ALTER TABLE gift_cards ADD COLUMN IF NOT EXISTS currency varchar(10) NOT NULL DEFAULT 'USD';
ALTER TABLE gift_cards ALTER COLUMN currency SET DEFAULT 'INR';

ALTER TABLE gift_cards ADD COLUMN IF NOT EXISTS reward_type varchar(10) NOT NULL DEFAULT 'fixed';
ALTER TABLE gift_cards ADD COLUMN IF NOT EXISTS reward_percent numeric(6,2);
ALTER TABLE gift_cards ADD COLUMN IF NOT EXISTS max_reward numeric(18,2);

ALTER TABLE gift_cards DROP CONSTRAINT IF EXISTS gift_cards_reward_type_chk;
ALTER TABLE gift_cards ADD CONSTRAINT gift_cards_reward_type_chk
    CHECK (reward_type IN ('fixed', 'percent'));

-- Only the user's first-ever successful deposit (any gateway) can qualify
ALTER TABLE gift_cards ADD COLUMN IF NOT EXISTS first_deposit_only boolean NOT NULL DEFAULT false;

-- Actual amount credited on claim (percent rewards vary per user)
ALTER TABLE user_gift_cards ADD COLUMN IF NOT EXISTS claimed_amount numeric(18,2);

COMMIT;
