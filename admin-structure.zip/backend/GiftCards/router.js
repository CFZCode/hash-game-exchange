const express = require('express');
const router = express.Router();
const giftCardController = require('./controller');

// Admin – Create Gift Card
router.post('/admin/create', giftCardController.createGiftCard);

// Admin – List All Gift Cards
router.get('/admin/list', giftCardController.listGiftCards);

// Admin – Delete Gift Card
router.delete('/admin/delete/:id', giftCardController.deleteGiftCard);
router.post('/search', giftCardController.searchGiftCardByKey);

// User – Activate Gift Card
router.post('/activate', giftCardController.activateGiftCard);

router.get(
    '/user/:userId/active-with-status',
    giftCardController.listActiveGiftCardsWithStatus
);
// User – Claim Gift Card
router.post('/claim', giftCardController.claimGiftCard);

// User – Get Claimed Gift Cards
router.get('/user/:userId/claimed', giftCardController.getClaimedGiftCards);

// Admin – Analytics
router.get('/admin/analytics', giftCardController.getGiftCardAnalytics);

// Admin – Records (all user gift card transactions)
router.get('/admin/records', giftCardController.getGiftCardRecords);


module.exports = router;
