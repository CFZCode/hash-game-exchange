const pg = require('../General/Model');

// Helper to handle async routes
const asyncHandler = fn => (req, res, next) =>
    Promise.resolve(fn(req, res, next)).catch(next);

const getUsdRate = async (currency) => {
    const result = await pg.query(
        `
    SELECT usd_rate
    FROM exchangerate
    WHERE currency = $1
    LIMIT 1
    `,
        [currency.toUpperCase()]
    );

    if (result.rows.length === 0) {
        throw new Error(`USD rate not found for currency ${currency}`);
    }

    return Number(result.rows[0].usd_rate);
};

// Convert `amount` from one currency to another via exchangerate.usd_rate
// (usd_rate = USD per 1 unit). USD/USDT are treated as 1:1 with USD.
const USD_LIKE = ['USD', 'USDT'];
const convertAmount = async (amount, from, to) => {
    const f = (from || 'USD').toUpperCase();
    const t = (to || 'USD').toUpperCase();
    if (f === t || (USD_LIKE.includes(f) && USD_LIKE.includes(t))) return Number(amount);
    const fromRate = USD_LIKE.includes(f) ? 1 : await getUsdRate(f);
    const toRate = USD_LIKE.includes(t) ? 1 : await getUsdRate(t);
    return (Number(amount) * fromRate) / toRate;
};

const SUPPORTED_CURRENCIES = ['INR', 'USD'];
const REWARD_TYPES = ['fixed', 'percent'];

/**
 * Reward credited on claim, in the gift card's currency.
 * fixed   → gc.amount
 * percent → reward_percent % of the qualifying deposit, capped at max_reward
 */
const computeReward = (gc, qualifyingDeposit) => {
    if (gc.reward_type === 'percent') {
        const pct = Number(gc.reward_percent || 0);
        let reward = (Number(qualifyingDeposit || 0) * pct) / 100;
        if (gc.max_reward != null && Number(gc.max_reward) > 0) {
            reward = Math.min(reward, Number(gc.max_reward));
        }
        return Number(reward.toFixed(2));
    }
    return Number(gc.amount || 0);
};

// helper  function

/**
 * Middleware: Check User Deposit (USD)
 * Body must contain:
 * userId, startDate, endDate, requiredDepositUSD
 */
const checkDeposit = asyncHandler(async (req, res, next) => {
    const { userId, startDate, endDate, requiredDepositUSD } = req.body;

    if (!userId || !startDate || !requiredDepositUSD) {
        return res.status(400).json({
            error: 'userId, startDate and requiredDepositUSD are required'
        });
    }

    const end = endDate ? endDate : new Date();

    let totalUsdDeposit = 0;

    try {
        /* ───────────── pay_in_transactions ───────────── */
        const payinResult = await pg.query(
            `
      SELECT currency, amount
      FROM pay_in_transactions
      WHERE user_id = $1
        AND status = 1
        AND created_at BETWEEN $2 AND $3
      `,
            [userId, startDate, end]
        );

        for (const row of payinResult.rows) {
            const rate = await getUsdRate(row.currency);
            totalUsdDeposit += Number(row.amount) * rate;
        }

        /* ───────────── apaydeposits ───────────── */
        const apayResult = await pg.query(
            `
      SELECT currency,
             CASE WHEN paid_amount > 0 THEN paid_amount ELSE amount END AS amount
      FROM apaydeposits
      WHERE user_id = $1
        AND status = 'Success'
        AND created_at BETWEEN $2 AND $3
      `,
            [userId, startDate, end]
        );

        for (const row of apayResult.rows) {
            const rate = await getUsdRate(row.currency);
            totalUsdDeposit += Number(row.amount) * rate;
        }

        /* ───────────── ccdeposit (USDT ≈ USD) ───────────── */
        const ccResult = await pg.query(
            `
      SELECT amount
      FROM ccdeposit
      WHERE userid = $1
        AND status = 'Success'
        AND created_at BETWEEN $2 AND $3
      `,
            [userId, startDate, end]
        );

        for (const row of ccResult.rows) {
            totalUsdDeposit += Number(row.amount);
        }

        const isDepositMet = totalUsdDeposit >= Number(requiredDepositUSD);

        // Attach summary to request
        req.depositSummary = {
            totalUsdDeposit: Number(totalUsdDeposit.toFixed(2)),
            requiredDepositUSD: Number(requiredDepositUSD),
            isDepositMet
        };

        next();
    } catch (error) {
        console.error('checkDeposit middleware error:', error);
        return res.status(500).json({
            error: 'Failed to calculate deposit'
        });
    }
});

/**
 * Every successful deposit across all gateways, one row per deposit.
 * Mirrors the sources and success statuses used by depositHistory.
 */
const SUCCESSFUL_DEPOSITS_SQL = `
    SELECT 'pay_in_transactions' AS source, id, user_id::text AS user_id, currency::text AS currency,
           amount, status::text AS status, created_at::timestamp AS created_at
    FROM pay_in_transactions
    UNION ALL
    SELECT 'apaydeposits', id, user_id::text, currency::text,
           CASE WHEN paid_amount > 0 THEN paid_amount ELSE amount END,
           status::text, created_at::timestamp
    FROM apaydeposits
    UNION ALL
    SELECT 'fiat_deposits', deposit_id, user_id::text, COALESCE(currency, 'INR')::text,
           amount, status::text, created_at::timestamp
    FROM fiat_deposits
    UNION ALL
    SELECT 'cricpaytransactions', id, uid::text, 'INR',
           amount, status::text, created_at::timestamp
    FROM cricpaytransactions
    UNION ALL
    SELECT 'f2paydeposits', id, user_id::text, COALESCE(currency, 'INR')::text,
           amount, status::text, created_at::timestamp
    FROM f2paydeposits
    UNION ALL
    SELECT 'ccdeposit', id, userid::text, 'USDT',
           amount, status::text, created_at::timestamp
    FROM ccdeposit
`;
const SUCCESS_FILTER = `LOWER(d.status) IN ('1', 'success', 'successful', 'approved', 'done', 'completed')`;

// Shape a deposit row as a check result, amounts expressed in `cur`
const depositResult = async (row, cur, extra = {}) => ({
    status: true,
    source: row.source,
    transactionId: row.id,
    originalCurrency: row.currency,
    originalAmount: Number(row.amount),
    currency: cur,
    amount: Number((await convertAmount(row.amount, row.currency, cur)).toFixed(2)),
    usdAmount: Number((await convertAmount(row.amount, row.currency, 'USD')).toFixed(2)),
    createdAt: row.created_at,
    ...extra
});

/**
 * Helper: Check deposit by ONE transaction
 * Returns the first transaction in the window that meets the required amount,
 * expressed in `currency` (the gift card's currency; defaults to USD for legacy cards).
 */
const checkDepositByOneTransaction = async ({
    userId,
    startDate,
    endDate,
    requiredAmount,
    requiredDepositUSD,
    currency = 'USD'
}) => {
    const required = Number(requiredAmount ?? requiredDepositUSD);
    if (!userId || !startDate || !required) {
        throw new Error('userId, startDate and requiredAmount are required');
    }

    const end = endDate ? endDate : new Date();
    const cur = (currency || 'USD').toUpperCase();

    const result = await pg.query(
        `
    SELECT d.* FROM (${SUCCESSFUL_DEPOSITS_SQL}) d
    WHERE d.user_id = $1::text
      AND ${SUCCESS_FILTER}
      AND d.created_at BETWEEN $2 AND $3
    ORDER BY d.created_at ASC
    `,
        [userId, startDate, end]
    );

    for (const row of result.rows) {
        const hit = await depositResult(row, cur);
        if (hit.amount >= required) return hit;
    }

    // ❌ No single transaction matched
    return {
        status: false,
        currency: cur,
        requiredAmount: required,
        message: 'No single deposit transaction meets the required amount'
    };
};

/**
 * Helper: First-deposit-only check
 * Only the user's very first successful deposit (ever, across all gateways)
 * can qualify. It must be made on/after `fromDate` (the card's creation), before
 * `endDate`, and meet the minimum. A second or later deposit never qualifies.
 */
const checkFirstDeposit = async ({ userId, fromDate, endDate, requiredAmount, currency = 'INR' }) => {
    const required = Number(requiredAmount);
    const cur = (currency || 'INR').toUpperCase();
    const fail = message => ({ status: false, firstDeposit: true, currency: cur, requiredAmount: required, message });

    const result = await pg.query(
        `
    SELECT d.* FROM (${SUCCESSFUL_DEPOSITS_SQL}) d
    WHERE d.user_id = $1::text
      AND ${SUCCESS_FILTER}
    ORDER BY d.created_at ASC, d.id ASC
    LIMIT 1
    `,
        [userId]
    );

    if (result.rows.length === 0) {
        return fail('Make your first deposit to unlock this gift card');
    }

    const first = result.rows[0];
    const firstAt = new Date(first.created_at);
    if (fromDate && firstAt < new Date(fromDate)) {
        return fail('This gift card is only for your first deposit, and you have already deposited before');
    }
    if (endDate && firstAt > new Date(endDate)) {
        return fail('Your first deposit was made after this gift card expired');
    }

    const hit = await depositResult(first, cur, { firstDeposit: true });
    if (hit.amount < required) {
        return { ...fail('Your first deposit was below the minimum amount'), firstDepositAmount: hit.amount };
    }
    return hit;
};

// gift_cards.end_date is a DATE, which pg parses as midnight at the START of that day.
// The card is valid for the whole end date, so count up to the last millisecond of it.
const cardEndDate = row =>
    row.end_date ? new Date(new Date(row.end_date).getTime() + 24 * 60 * 60 * 1000 - 1) : new Date();

// Pick the right deposit check for a gift card row (gc.* joined with the activation).
// Deposits count from the card's creation (row.created_at), not the user's activation,
// so a user who deposits first and enters the code afterwards still qualifies.
const checkDepositForCard = (row, userId, endDate) =>
    row.first_deposit_only
        ? checkFirstDeposit({
            userId,
            fromDate: row.created_at,
            endDate,
            requiredAmount: row.deposit_amount,
            currency: row.currency
        })
        : checkDepositByOneTransaction({
            userId,
            startDate: row.created_at,
            endDate,
            requiredAmount: row.deposit_amount,
            currency: row.currency
        });

/**
 * Helper: Check Wager by Period (USD based)
 * Calculates total wager amount played by user
 */
const checkWagerByPeriod = async ({
    userId,
    startDate,
    endDate,
    requiredAmount,
    requiredWagerUSD,
    currency = 'USD'
}) => {
    const required = Number(requiredAmount ?? requiredWagerUSD);
    if (!userId || !startDate || !required) {
        throw new Error('userId, startDate and requiredAmount are required');
    }
    const cur = (currency || 'USD').toUpperCase();
    requiredWagerUSD = await convertAmount(required, cur, 'USD');

    const end = endDate ? endDate : new Date();
    let totalUsdWager = 0;

    /* ───────────── SportsBet ───────────── */
    const sportsResult = await pg.query(
        `
    SELECT usd_amount
    FROM "SportsBet"
    WHERE user_id = $1
      AND result_status IN ('won', 'loss')
      AND created_at BETWEEN $2 AND $3
    `,
        [userId, startDate, end]
    );

    for (const row of sportsResult.rows) {
        totalUsdWager += Number(row.usd_amount || 0);
    }

    /* ───────────── gis_transactions (casino) ───────────── */
    const gisResult = await pg.query(
        `
    SELECT amount, currency
    FROM gis_transactions
    WHERE user_id = $1
      AND action = 'bet'
      AND created_at BETWEEN $2 AND $3
    `,
        [userId, startDate, end]
    );

    for (const row of gisResult.rows) {
        if (!row.amount || !row.currency) continue;
        const rate = await getUsdRate(row.currency);
        totalUsdWager += Number(row.amount) * rate;
    }

    /* ───────────── js_game_transactions ───────────── */
    const jsResult = await pg.query(
        `
    SELECT amount, currency
    FROM js_game_transactions
    WHERE user_id = $1
      AND transaction_type = 'bet'
      AND timestamp BETWEEN $2 AND $3
    `,
        [userId, startDate, end]
    );

    for (const row of jsResult.rows) {
        const rate = await getUsdRate(row.currency);
        totalUsdWager += Number(row.amount) * rate;
    }

    const isWagerMet = totalUsdWager >= Number(requiredWagerUSD);

    return {
        status: isWagerMet,
        currency: cur,
        totalWager: Number((await convertAmount(totalUsdWager, 'USD', cur)).toFixed(2)),
        requiredWager: required,
        totalUsdWager: Number(totalUsdWager.toFixed(2)),
        requiredWagerUSD: Number(Number(requiredWagerUSD).toFixed(2))
    };
};


/**
 * Admin – Create Gift Card
 */
const createGiftCard = asyncHandler(async (req, res) => {
    const {
        uniqueKey,
        description,
        periodDays,
        endDate,
        depositStatus,
        depositAmount,
        wagerStatus,
        wagerTimes,
        allUserStatus,
        amount,
        currency = 'INR',
        rewardType = 'fixed',
        rewardPercent,
        maxReward,
        firstDepositOnly
    } = req.body;

    if (!uniqueKey) {
        return res.status(400).json({ error: 'Unique key is required' });
    }

    const cur = String(currency).toUpperCase();
    if (!SUPPORTED_CURRENCIES.includes(cur)) {
        return res.status(400).json({ error: `Unsupported currency ${currency}` });
    }
    if (!REWARD_TYPES.includes(rewardType)) {
        return res.status(400).json({ error: 'rewardType must be fixed or percent' });
    }

    if (rewardType === 'fixed') {
        if (!(Number(amount) > 0)) {
            return res.status(400).json({ error: 'Claim amount must be greater than 0' });
        }
    } else {
        const pct = Number(rewardPercent);
        if (!(pct > 0 && pct <= 500)) {
            return res.status(400).json({ error: 'Reward percent must be between 0 and 500' });
        }
        // Percentage reward is paid on the qualifying deposit, so a minimum deposit is mandatory
        if (depositStatus !== true || !(Number(depositAmount) > 0)) {
            return res.status(400).json({ error: 'Percentage reward requires a minimum deposit condition' });
        }
        if (maxReward != null && maxReward !== '' && !(Number(maxReward) > 0)) {
            return res.status(400).json({ error: 'Max reward must be greater than 0' });
        }
    }

    if (firstDepositOnly === true && depositStatus !== true) {
        return res.status(400).json({ error: 'First deposit only requires a minimum deposit condition' });
    }
    if (depositStatus === true && !(Number(depositAmount) > 0)) {
        return res.status(400).json({ error: 'Minimum deposit amount is required' });
    }
    if (wagerStatus === true && !(Number(wagerTimes) > 0)) {
        return res.status(400).json({ error: 'Wager multiplier is required' });
    }

    try {
        const result = await pg.query(
            `
      INSERT INTO gift_cards (
        unique_key,
        description,
        period_days,
        end_date,
        deposit_status,
        deposit_amount,
        wager_status,
        wager_times,
        all_user_status,
        amount,
        currency,
        reward_type,
        reward_percent,
        max_reward,
        first_deposit_only
      ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)
      RETURNING *
      `,
            [
                uniqueKey,
                description || null,
                periodDays || null,
                endDate || null,
                depositStatus === true,
                depositStatus === true ? depositAmount : null,
                wagerStatus === true,
                wagerStatus === true ? wagerTimes : null,
                allUserStatus === true,
                rewardType === 'fixed' ? amount : null,
                cur,
                rewardType,
                rewardType === 'percent' ? rewardPercent : null,
                rewardType === 'percent' && maxReward ? maxReward : null,
                firstDepositOnly === true
            ]
        );

        return res.status(201).json({
            message: 'Gift card created successfully',
            giftCard: result.rows[0]
        });
    } catch (error) {
        console.error('Error creating gift card:', error);

        if (error.code === '23505') {
            return res.status(409).json({
                error: 'Gift card with this unique key already exists'
            });
        }

        return res.status(500).json({
            error: 'Failed to create gift card'
        });
    }
});

/**
 * Admin – List All Gift Cards
 */
const listGiftCards = asyncHandler(async (req, res) => {
    try {
        const result = await pg.query(
            `
      SELECT
        id,
        unique_key as "uniqueKey",
        description,
        period_days as "periodDays",
        end_date as "endDate",
        deposit_status as "depositStatus",
        deposit_amount as "depositAmount",
        wager_status as "wagerStatus",
        wager_times as "wagerTimes",
        all_user_status as "allUserStatus",
        amount,
        currency,
        reward_type as "rewardType",
        reward_percent as "rewardPercent",
        max_reward as "maxReward",
        first_deposit_only as "firstDepositOnly",
        is_active as "isActive",
        created_at as "createdAt"
      FROM gift_cards
      ORDER BY created_at DESC
      `
        );

        return res.status(200).json(result.rows);
    } catch (error) {
        console.error('Error fetching gift cards:', error);
        return res.status(500).json({
            error: 'Failed to fetch gift cards'
        });
    }
});

/**
 * Admin – Delete Gift Card
 */
const deleteGiftCard = asyncHandler(async (req, res) => {
    const { id } = req.params;

    if (!id) {
        return res.status(400).json({ error: 'Gift card ID is required' });
    }

    try {
        const result = await pg.query(
            `
      DELETE FROM gift_cards
      WHERE id = $1
      RETURNING id
      `,
            [id]
        );

        if (result.rowCount === 0) {
            return res.status(404).json({
                error: 'Gift card not found'
            });
        }

        return res.status(200).json({
            message: 'Gift card deleted successfully'
        });
    } catch (error) {
        console.error('Error deleting gift card:', error);
        return res.status(500).json({
            error: 'Failed to delete gift card'
        });
    }
});
/**
 * Search Gift Card by Exact Unique Key
 * Body: { uniqueKey }
 */
const searchGiftCardByKey = asyncHandler(async (req, res) => {
    const { uniqueKey } = req.body;

    if (!uniqueKey) {
        return res.status(400).json({
            error: 'uniqueKey is required'
        });
    }

    try {
        const result = await pg.query(
            `
      SELECT
        id,
        unique_key as "uniqueKey",
        description,
        period_days as "periodDays",
        end_date as "endDate",
        deposit_status as "depositStatus",
        deposit_amount as "depositAmount",
        wager_status as "wagerStatus",
        wager_times as "wagerTimes",
        all_user_status as "allUserStatus",
        amount,
        currency,
        reward_type as "rewardType",
        reward_percent as "rewardPercent",
        max_reward as "maxReward",
        first_deposit_only as "firstDepositOnly",
        is_active as "isActive",
        created_at as "createdAt",
        updated_at as "updatedAt"
      FROM gift_cards
      WHERE unique_key = $1
      LIMIT 1
      `,
            [uniqueKey]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({
                error: 'Gift card not found'
            });
        }

        return res.status(200).json({
            success: true,
            giftCard: result.rows[0]
        });
    } catch (error) {
        console.error('Error searching gift card:', error);
        return res.status(500).json({
            error: 'Failed to search gift card'
        });
    }
});

/**
 * User – Activate Gift Card
 * Body: { userId, uniqueKey }
 */
const activateGiftCard = asyncHandler(async (req, res) => {
    const { userId, uniqueKey } = req.body;

    if (!userId || !uniqueKey) {
        return res.status(400).json({
            error: 'userId and uniqueKey are required'
        });
    }

    try {
        // 1️⃣ Find gift card by unique key
        const giftResult = await pg.query(
            `
      SELECT id, is_active
      FROM gift_cards
      WHERE unique_key = $1
      LIMIT 1
      `,
            [uniqueKey]
        );

        if (giftResult.rows.length === 0) {
            return res.status(404).json({
                error: 'Invalid gift card code'
            });
        }

        const giftCard = giftResult.rows[0];

        if (!giftCard.is_active) {
            return res.status(400).json({
                error: 'This gift card is not active'
            });
        }

        // 2️⃣ Check if user already activated this gift card
        const existing = await pg.query(
            `
      SELECT id, status
      FROM user_gift_cards
      WHERE user_id = $1 AND gift_card_id = $2
      LIMIT 1
      `,
            [userId, giftCard.id]
        );

        if (existing.rows.length > 0) {
            return res.status(409).json({
                error: `Gift card already ${existing.rows[0].status.toLowerCase()}`
            });
        }

        // 3️⃣ Activate gift card
        const insertResult = await pg.query(
            `
      INSERT INTO user_gift_cards (user_id, gift_card_id)
      VALUES ($1, $2)
      RETURNING id, start_date, status
      `,
            [userId, giftCard.id]
        );

        return res.status(201).json({
            success: true,
            message: 'Gift card activated successfully',
            activation: insertResult.rows[0]
        });
    } catch (error) {
        console.error('Error activating gift card:', error);
        return res.status(500).json({
            error: 'Failed to activate gift card'
        });
    }
});

/**
 * User – List Active Gift Cards with Deposit & Wager Status
 */
const listActiveGiftCardsWithStatus = asyncHandler(async (req, res) => {
    const { userId } = req.params;

    if (!userId) {
        return res.status(400).json({ error: 'userId is required' });
    }

    try {
        const result = await pg.query(
            `
      SELECT DISTINCT
        gc.*,
        ugc.id            AS user_gift_card_id,
        ugc.start_date    AS user_start_date,
        ugc.status        AS user_gift_status
      FROM gift_cards gc
      LEFT JOIN user_gift_cards ugc
        ON ugc.gift_card_id = gc.id
       AND ugc.user_id = $1
      WHERE
        gc.is_active = true
        AND (
          ugc.id IS NOT NULL
          OR gc.all_user_status = true
        )
      ORDER BY gc.created_at DESC
      `,
            [userId]
        );

        const response = [];

        for (const row of result.rows) {
            const startDate =
                row.user_start_date ||
                row.created_at; // fallback for all_user_status cards

            let depositCheck = null;
            let wagerCheck = null;

            /* ───────── Deposit Check ───────── */
            if (row.deposit_status === true) {
                depositCheck = await checkDepositForCard(row, userId, cardEndDate(row));
            }

            /* ───────── Wager Check ───────── */
            if (row.wager_status === true) {
                const requiredWager =
                    row.deposit_status && row.deposit_amount
                        ? row.deposit_amount * row.wager_times
                        : row.wager_times;

                wagerCheck = await checkWagerByPeriod({
                    userId,
                    startDate,
                    endDate: cardEndDate(row),
                    requiredAmount: requiredWager,
                    currency: row.currency
                });
            }

            response.push({
                giftcards: {
                    id: row.id,
                    uniqueKey: row.unique_key,
                    description: row.description,
                    periodDays: row.period_days,
                    endDate: row.end_date,
                    depositStatus: row.deposit_status,
                    depositAmount: row.deposit_amount,
                    wagerStatus: row.wager_status,
                    wagerTimes: row.wager_times,
                    allUserStatus: row.all_user_status,
                    isActive: row.is_active,
                    amount: row.amount,
                    currency: row.currency,
                    rewardType: row.reward_type,
                    rewardPercent: row.reward_percent,
                    maxReward: row.max_reward,
                    firstDepositOnly: row.first_deposit_only,
                    // What the user would receive if they claimed now
                    estimatedReward: computeReward(row, depositCheck?.amount),
                },

                usergiftcards: row.user_gift_card_id
                    ? {
                        id: row.user_gift_card_id,
                        status: row.user_gift_status,
                        startDate: row.user_start_date
                    }
                    : null,

                ...(row.deposit_status && {
                    deposit: depositCheck
                }),

                ...(row.wager_status && {
                    wager: wagerCheck
                })
            });
        }

        return res.status(200).json({
            success: true,
            data: response
        });
    } catch (error) {
        console.error(
            'Error listing active gift cards with status:',
            error
        );
        return res.status(500).json({
            error: 'Failed to fetch gift cards'
        });
    }
});

/**
 * User – Claim Gift Card
 * Body: { userId, giftCardId }
 */
const claimGiftCard = asyncHandler(async (req, res) => {
    const { userId, giftCardId } = req.body;

    if (!userId || !giftCardId) {
        return res.status(400).json({
            error: 'userId and giftCardId are required'
        });
    }

    try {
        /* ───────── Fetch user gift card ───────── */
        const ugcResult = await pg.query(
            `
      SELECT
        ugc.id AS ugc_id,
        ugc.start_date,
        ugc.status,
        gc.*
      FROM user_gift_cards ugc
      JOIN gift_cards gc ON gc.id = ugc.gift_card_id
      WHERE ugc.user_id = $1
        AND ugc.gift_card_id = $2
      LIMIT 1
      `,
            [userId, giftCardId]
        );

        if (ugcResult.rows.length === 0) {
            return res.status(404).json({
                error: 'Gift card not activated by user'
            });
        }

        const row = ugcResult.rows[0];

        if (row.status !== 'Activated') {
            return res.status(400).json({
                error: `Gift card already ${row.status.toLowerCase()}`
            });
        }

        const startDate = row.start_date;
        const endDate = cardEndDate(row);

        /* ───────── Deposit Check ───────── */
        let depositCheck = null;
        if (row.deposit_status === true) {
            depositCheck = await checkDepositForCard(row, userId, endDate);

            if (!depositCheck.status) {
                return res.status(400).json({
                    error: 'Deposit condition not met',
                    deposit: depositCheck
                });
            }
        }

        /* ───────── Wager Check ───────── */
        if (row.wager_status === true) {
            const requiredWager =
                row.deposit_status && row.deposit_amount
                    ? row.deposit_amount * row.wager_times
                    : row.wager_times;

            const wagerCheck = await checkWagerByPeriod({
                userId,
                startDate,
                endDate,
                requiredAmount: requiredWager,
                currency: row.currency
            });

            if (!wagerCheck.status) {
                return res.status(400).json({
                    error: 'Wager condition not met',
                    wager: wagerCheck
                });
            }
        }

        /* ───────── Credit Wallet (card currency) ───────── */
        const claimAmount = computeReward(row, depositCheck?.amount);
        const walletColumn = row.currency === 'INR' ? 'inr' : 'usdt';

        await pg.query('BEGIN');

        // Flip status first so a concurrent claim can't credit twice
        const statusResult = await pg.query(
            `
      UPDATE user_gift_cards
      SET status = 'Claimed',
          claimed_amount = $2,
          updated_at = NOW()
      WHERE id = $1 AND status = 'Activated'
      RETURNING id
      `,
            [row.ugc_id, claimAmount]
        );

        if (statusResult.rowCount === 0) {
            await pg.query('ROLLBACK');
            return res.status(409).json({ error: 'Gift card already claimed' });
        }

        const creditResult = await pg.query(
            `
      UPDATE credits
      SET ${walletColumn} = COALESCE(${walletColumn}, 0) + $1
      WHERE uid = $2
      RETURNING uid, ${walletColumn}
      `,
            [claimAmount, userId]
        );

        console.log('Credit update result:', creditResult.rows, 'amount:', claimAmount, row.currency, 'userId:', userId);

        await pg.query('COMMIT');

        return res.status(200).json({
            success: true,
            message: 'Gift card claimed successfully',
            creditedAmount: claimAmount,
            currency: row.currency,
            ...(row.currency !== 'INR' && { creditedAmountUSD: claimAmount })
        });
    } catch (error) {
        await pg.query('ROLLBACK');
        console.error('Error claiming gift card:', error);
        return res.status(500).json({
            error: 'Failed to claim gift card'
        });
    }
});

/* ───────────────────────────────────────────────
   GET /user/:userId/claimed
   Returns all gift cards successfully claimed by a user
   ─────────────────────────────────────────────── */
const getClaimedGiftCards = asyncHandler(async (req, res) => {
    const { userId } = req.params;

    if (!userId) {
        return res.status(400).json({ error: 'userId is required' });
    }

    const result = await pg.query(
        `
        SELECT
            ugc.id,
            ugc.gift_card_id,
            gc.unique_key,
            gc.description,
            gc.deposit_amount,
            gc.wager_times,
            gc.period_days,
            gc.currency,
            gc.reward_type,
            gc.reward_percent,
            ugc.claimed_amount,
            ugc.start_date,
            ugc.updated_at AS claimed_at,
            ugc.status
        FROM user_gift_cards ugc
        JOIN gift_cards gc ON gc.id = ugc.gift_card_id
        WHERE ugc.user_id = $1
          AND ugc.status = 'Claimed'
        ORDER BY ugc.updated_at DESC
        `,
        [userId]
    );

    return res.status(200).json({
        success: true,
        count: result.rows.length,
        data: result.rows
    });
});


/**
 * Admin – Gift Card Analytics & Records
 */
const getGiftCardAnalytics = asyncHandler(async (req, res) => {
    try {
        // Legacy USD cards are converted so the claimed total is in INR
        const usdToInr = await convertAmount(1, 'USD', 'INR');

        // Summary stats
        const statsResult = await pg.query(`
            SELECT
                COUNT(DISTINCT gc.id) AS total_cards,
                COUNT(ugc.id) AS total_activations,
                COUNT(ugc.id) FILTER (WHERE ugc.status = 'Claimed') AS total_claimed,
                COUNT(ugc.id) FILTER (WHERE ugc.status = 'Activated') AS total_activated,
                COALESCE(SUM(
                    CASE WHEN gc.currency = 'INR'
                         THEN COALESCE(ugc.claimed_amount, gc.amount)
                         ELSE COALESCE(ugc.claimed_amount, gc.amount) * $1
                    END
                ) FILTER (WHERE ugc.status = 'Claimed'), 0) AS total_claimed_amount
            FROM gift_cards gc
            LEFT JOIN user_gift_cards ugc ON ugc.gift_card_id = gc.id
        `, [usdToInr]);

        // Per-card breakdown
        const cardsResult = await pg.query(`
            SELECT
                gc.id,
                gc.unique_key,
                gc.amount,
                gc.currency,
                gc.reward_type,
                gc.reward_percent,
                gc.max_reward,
                gc.created_at,
                COUNT(ugc.id) AS activations,
                COUNT(ugc.id) FILTER (WHERE ugc.status = 'Claimed') AS claims
            FROM gift_cards gc
            LEFT JOIN user_gift_cards ugc ON ugc.gift_card_id = gc.id
            GROUP BY gc.id
            ORDER BY gc.created_at DESC
        `);

        return res.status(200).json({
            success: true,
            stats: statsResult.rows[0],
            cards: cardsResult.rows
        });
    } catch (error) {
        console.error('Error fetching gift card analytics:', error);
        return res.status(500).json({ error: 'Failed to fetch analytics' });
    }
});

/**
 * Admin – All user gift card records (claimed + activated)
 */
const getGiftCardRecords = asyncHandler(async (req, res) => {
    const { status, search, page = 1, limit = 25 } = req.query;
    const offset = (Number(page) - 1) * Number(limit);

    try {
        let where = 'WHERE 1=1';
        const params = [];
        let paramIdx = 0;

        if (status && status !== 'all') {
            paramIdx++;
            where += ` AND ugc.status = $${paramIdx}`;
            params.push(status);
        }

        if (search) {
            paramIdx++;
            where += ` AND (gc.unique_key ILIKE $${paramIdx} OR ugc.user_id::text = $${paramIdx + 1})`;
            params.push(`%${search}%`, String(search));
            paramIdx++;
        }

        const countResult = await pg.query(
            `SELECT COUNT(*) FROM user_gift_cards ugc JOIN gift_cards gc ON gc.id = ugc.gift_card_id ${where}`,
            params
        );

        paramIdx++;
        const limitParam = paramIdx;
        paramIdx++;
        const offsetParam = paramIdx;

        const result = await pg.query(
            `SELECT
                ugc.id,
                ugc.user_id,
                ugc.gift_card_id,
                ugc.status,
                ugc.start_date,
                ugc.updated_at,
                gc.unique_key,
                gc.description,
                gc.amount,
                gc.currency,
                gc.reward_type,
                gc.reward_percent,
                ugc.claimed_amount,
                gc.first_deposit_only,
                gc.deposit_status,
                gc.deposit_amount,
                gc.wager_status,
                gc.wager_times
            FROM user_gift_cards ugc
            JOIN gift_cards gc ON gc.id = ugc.gift_card_id
            ${where}
            ORDER BY ugc.updated_at DESC
            LIMIT $${limitParam} OFFSET $${offsetParam}`,
            [...params, Number(limit), offset]
        );

        return res.status(200).json({
            success: true,
            total: Number(countResult.rows[0].count),
            page: Number(page),
            limit: Number(limit),
            data: result.rows
        });
    } catch (error) {
        console.error('Error fetching gift card records:', error);
        return res.status(500).json({ error: 'Failed to fetch records' });
    }
});

module.exports = {
    createGiftCard,
    listGiftCards,
    deleteGiftCard,
    searchGiftCardByKey,
    activateGiftCard,
    checkDeposit,
    checkDepositByOneTransaction,
    checkWagerByPeriod,
    listActiveGiftCardsWithStatus,
    claimGiftCard,
    getClaimedGiftCards,
    getGiftCardAnalytics,
    getGiftCardRecords
};
