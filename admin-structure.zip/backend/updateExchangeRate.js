// exchange-job.js
const cron = require('node-cron');
const axios = require('axios');
const pg = require('./General/Model');

const Redis = (() => {
  try {
    return require('ioredis');
  } catch (e) {
    return null;
  }
})();

const logger = {
  info: (message) => console.log(`[INFO] ${message}`),
  error: (message, error) => console.error(`[ERROR] ${message}`, error)
};

// CONFIG
const CACHE_TTL_MS = process.env.CACHE_TTL_MS ? parseInt(process.env.CACHE_TTL_MS, 10) : 15_000; // 15s
const MIN_POLL_INTERVAL_MS = process.env.MIN_POLL_INTERVAL_MS ? parseInt(process.env.MIN_POLL_INTERVAL_MS, 10) : 5_000; // 5s
const MAX_RETRIES = process.env.MAX_RETRIES ? parseInt(process.env.MAX_RETRIES, 10) : 3;
const REDIS_URL = process.env.REDIS_URL || null;
const REDIS_LOCK_KEY = 'exchange_job_lock';
const REDIS_CACHE_KEY = 'exchange_job_cache';
const REDIS_LOCK_TTL = 30_000; // 30s lock

// Optional Redis client (if REDIS_URL configured and ioredis installed)
let redis = null;
if (REDIS_URL && Redis) {
  try {
    redis = new Redis(REDIS_URL);
    redis.on('error', (e) => logger.error('Redis error', e));
    logger.info('Using Redis for lock + cache.');
  } catch (e) {
    logger.error('Failed to create Redis client, falling back to in-memory cache', e);
    redis = null;
  }
} else if (REDIS_URL && !Redis) {
  logger.info('REDIS_URL provided but ioredis not installed. Install with `npm i ioredis` to enable Redis-backed locking/cache.');
}

// Simple in-memory cache fallback (per-process)
let inMemoryCache = { data: null, expiresAt: 0 };
let lastRequestAt = 0;
let circuitOpenUntil = 0;
let localLock = false; // process-level lock to avoid concurrent runs in same process

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function acquireRedisLock() {
  if (!redis) return true; // no redis => fall back to local lock in code
  const token = Date.now() + ':' + Math.random().toString(36).slice(2);
  const ok = await redis.set(REDIS_LOCK_KEY, token, 'NX', 'PX', REDIS_LOCK_TTL);
  return ok ? token : null;
}
async function releaseRedisLock(token) {
  if (!redis || !token) return;
  // safe release using Lua script to match token
  const lua = `
  if redis.call("get", KEYS[1]) == ARGV[1] then
    return redis.call("del", KEYS[1])
  else
    return 0
  end
  `;
  try { await redis.eval(lua, 1, REDIS_LOCK_KEY, token); } catch (e) { /* ignore */ }
}

async function getCachedData() {
  const now = Date.now();
  if (redis) {
    try {
      const raw = await redis.get(REDIS_CACHE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed.expiresAt && parsed.expiresAt > now) return parsed.data;
      }
    } catch (e) {
      logger.error('Redis read error (cache)', e);
    }
  } else {
    if (inMemoryCache.data && inMemoryCache.expiresAt > now) return inMemoryCache.data;
  }
  return null;
}

async function setCachedData(data, ttl = CACHE_TTL_MS) {
  const expiresAt = Date.now() + ttl;
  if (redis) {
    try {
      await redis.set(REDIS_CACHE_KEY, JSON.stringify({ data, expiresAt }), 'PX', ttl);
    } catch (e) {
      logger.error('Redis write error (cache)', e);
    }
  } else {
    inMemoryCache = { data, expiresAt };
  }
}

// safe axios instance
const http = axios.create({
  timeout: 10_000,
  validateStatus: () => true // we'll handle status codes manually
});

async function fetchCryptoRatesSafe() {
  const now = Date.now();

  // circuit-breaker check
  if (now < circuitOpenUntil) {
    const cached = await getCachedData();
    if (cached) return cached;
    throw new Error('Circuit open: upstream temporarily unavailable');
  }

  // return cache if fresh
  const cached = await getCachedData();
  if (cached) return cached;

  // local rate-limit to avoid too frequent requests in same process
  const sinceLast = now - lastRequestAt;
  if (sinceLast < MIN_POLL_INTERVAL_MS) {
    // wait if no cache is available
    if (cached) return cached;
    await sleep(MIN_POLL_INTERVAL_MS - sinceLast);
  }

  lastRequestAt = Date.now();

  const ids = [
    'bitcoin','ethereum','litecoin','bitcoin-cash','tether','tron','dogecoin','cardano',
    'ripple','binancecoin','shiba-inu','usd-coin','binance-usd','matic-network','maker',
    'nexo','siacoin','bitbop','tether-us','true-usd'
  ].join(',');

  const url = 'https://api.coingecko.com/api/v3/simple/price';
  let attempt = 0;
  let backoff = 500;

  while (attempt <= MAX_RETRIES) {
    attempt++;
    try {
      const res = await http.get(url, { params: { ids, vs_currencies: 'usd' } });

      if (res.status === 200 && res.data) {
        // map ids to your currency codes (same map as before)
        const idToCurrencyMap = {
          'bitcoin': 'btc','ethereum': 'eth','litecoin': 'ltc','bitcoin-cash':'bch',
          'tether':'usdt','tron':'trx','dogecoin':'doge','cardano':'ada','ripple':'xrp',
          'binancecoin':'bnb','shiba-inu':'shib','usd-coin':'usdc','binance-usd':'busd',
          'matic-network':'matic','maker':'mkr','nexo':'nexo','siacoin':'sc','bitbop':'bjb',
          'tether-us':'usdp','true-usd':'tusd'
        };

        const rates = {};
        for (const [id, value] of Object.entries(res.data)) {
          const currency = idToCurrencyMap[id];
          if (currency && value && value.usd != null) rates[currency] = value.usd;
        }
        // stablecoin defaults
        ['usdt','usdc','busd','usdp','tusd'].forEach(s => {
          if (!rates[s] || Math.abs(rates[s] - 1) > 0.05) rates[s] = 1.0;
        });

        // cache and return
        await setCachedData(rates, CACHE_TTL_MS);
        return rates;
      }

      if (res.status === 429) {
        // respect Retry-After
        const ra = res.headers && (res.headers['retry-after'] || res.headers['Retry-After']);
        const waitS = ra ? parseInt(ra, 10) : null;
        const waitMs = (waitS && !Number.isNaN(waitS)) ? waitS * 1000 : backoff;
        logger.error(`CoinGecko 429 received. retry-after: ${ra}, waiting ${waitMs}ms (attempt ${attempt})`);
        // open circuit briefly after repeated 429s
        if (attempt >= 2) circuitOpenUntil = Date.now() + Math.max(30_000, waitMs);
        await sleep(waitMs);
        backoff *= 2;
        continue;
      }

      if (res.status >= 500 && res.status < 600) {
        logger.error(`CoinGecko 5xx ${res.status}, retrying after ${backoff}ms`);
        await sleep(backoff);
        backoff *= 2;
        continue;
      }

      // other client errors: don't retry
      throw new Error(`Upstream error ${res.status} ${res.statusText || ''}`);
    } catch (err) {
      logger.error(`Fetch attempt ${attempt} failed`, err && err.message ? err.message : err);
      if (attempt > MAX_RETRIES) {
        // open circuit for a minute to avoid thrashing
        circuitOpenUntil = Date.now() + 60_000;
        const cached2 = await getCachedData();
        if (cached2) return cached2;
        throw err;
      }
      await sleep(backoff);
      backoff *= 2;
    }
  }
  // fallback to cache if any
  const finalCached = await getCachedData();
  if (finalCached) return finalCached;
  throw new Error('Failed to fetch crypto rates');
}

async function fetchFiatRatesSafe() {
  try {
    const res = await http.get('https://open.er-api.com/v6/latest/USD');
    if (res.status !== 200 || !res.data || !res.data.rates) {
      throw new Error(`Fiat rates fetch failed ${res.status}`);
    }
    const rates = {};
    rates['inr'] = res.data.rates.INR ? (1 / res.data.rates.INR) : 0.01;
    rates['eur'] = res.data.rates.EUR ? (1 / res.data.rates.EUR) : 1.08;
    rates['npr'] = res.data.rates.NPR ? (1 / res.data.rates.NPR) : 0.0075;
    rates['aed'] = res.data.rates.AED ? (1 / res.data.rates.AED) : 0.27;
    rates['mvr'] = res.data.rates.MVR ? (1 / res.data.rates.MVR) : 0.05;
    rates['pkr'] = res.data.rates.PKR ? (1 / res.data.rates.PKR) : 0.0035;
    return rates;
  } catch (err) {
    logger.error('Error fetching fiat rates', err);
    throw err;
  }
}

async function updateExchangeRates() {
  // Acquire lock (redis or local)
  if (localLock) {
    logger.info('Local lock active, skipping concurrent run');
    return;
  }
  localLock = true;
  let redisToken = null;
  try {
    if (redis) {
      redisToken = await acquireRedisLock();
      if (!redisToken) {
        logger.info('Another instance holds Redis lock, skipping run.');
        return;
      }
    }

    logger.info('Starting exchange rate update job');

    // fetch rates safely
    const cryptoRates = await fetchCryptoRatesSafe();
    const fiatRates = await fetchFiatRatesSafe();
    const allRates = { ...cryptoRates, ...fiatRates };

    // DB logic remains similar to your original code
    const { rows: dbRates } = await pg.query('SELECT * FROM exchangerate');
    const dbCurrencies = dbRates.map(r => r.currency.toLowerCase());

    for (const rate of dbRates) {
      const currency = rate.currency.toLowerCase();
      if (allRates[currency]) {
        const newRate = parseFloat(allRates[currency].toFixed(8));
        if (parseFloat(rate.usd_rate) !== newRate) {
          await pg.query(
            'UPDATE exchangerate SET usd_rate = $1, last_updated = $2 WHERE currency = $3',
            [newRate, new Date(), rate.currency]
          );
          logger.info(`Updated ${rate.currency}: ${newRate}`);
        }
      }
    }

    for (const [currency, rate] of Object.entries(allRates)) {
      if (!dbCurrencies.includes(currency.toLowerCase())) {
        const newRate = parseFloat(rate.toFixed(8));
        await pg.query(
          'INSERT INTO exchangerate (currency, usd_rate, last_updated) VALUES ($1, $2, $3)',
          [currency.toUpperCase(), newRate, new Date()]
        );
        logger.info(`Added new currency ${currency.toUpperCase()}: ${newRate}`);
      }
    }

    logger.info('Exchange rate update job completed successfully');
  } catch (error) {
    logger.error('Error updating exchange rates:', error && error.message ? error.message : error);
  } finally {
    // Release locks
    if (redis && redisToken) await releaseRedisLock(redisToken);
    localLock = false;
  }
}

function initExchangeRateUpdateJob() {
  // Every 10 minutes as before
  cron.schedule('*/10 * * * *', async () => {
    try {
      await updateExchangeRates();
    } catch (error) {
      logger.error('Scheduled exchange rate update failed:', error);
    }
  });

  logger.info('Exchange rate update job scheduled (every 10 minutes).');

  // Run immediately on startup (but guarded by locks)
  updateExchangeRates().catch(err => logger.error('Initial update failed:', err));
}

module.exports = { initExchangeRateUpdateJob, updateExchangeRates };
