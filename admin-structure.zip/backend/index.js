const express = require("express");
const server = express();
const app = require("http").createServer(server);
const bcrypt = require("bcryptjs");
const io = require("socket.io")(app, {
  cors: {
    // origin: "https://example.com",
    origin: ["http://localhost:3000", "https://example.com", "http://localhost:3001", "https://example.com", "https://example.com", "http://localhost:3002", "http://localhost:3003", "http://localhost:3004", "http://5.182.208.159:3003", "https://snapmoney.casino", "https://betgohere.com"],
    credentials: true,
    methods: ["GET", "POST"]
  }
})

const { encode } = require("./General/Buffer");
const C = require("./General/Constant");
const { getNumber } = require('./getnumber');
const cron = require('node-cron');
const { convertToUSDT } = require('./conversiontousdt');
const fs = require('fs');
const path = require('path');
const nodemailer = require('nodemailer');
const randomstring = require('randomstring');
const bodyParser = require("body-parser");
const axios = require('axios');
const compr = require("compression");
const siofu = require("socketio-file-upload");
const cors = require("cors");
var pg = require("./General/Model");
const xss = require("xss-clean");
const helmet = require("helmet");
const _ = require("lodash");
// const jwt = require('jsonwebtoken');
const { expressjwt: jwt } = require("express-jwt");
const cluster = require("cluster");
const totalCPUs = require("os").cpus().length;


const H = require("./General/Helper");
const Market = require("./General/Market");
const { safeCol } = require("./General/dbSafe");
const Token = require("./Users/Token");
const Notify = require("./Users/Notify");
const Admin = require("./Admin");
// const Sports = require('./Sports');
const Users = require("./Users");
const Games = require("./Games");
const Bots = require("./Games/Bots");
const Crash = require("./Games/Crash");
const Keno = require("./Games/Keno");
const Deposit = require("./Wallet/Deposit");
const WalletNotify = require("./Wallet/WalletNotify");
const inr_deposit = require("./Wallet/inrdeposit");
const inr_history = require("./Wallet/inrhistory");
const BlockNotify = require("./Wallet/BlockNotify");
const Slots = require("./Slots");
const SlotsRule = require("./Slots/Rule");
const md5 = require('md5');
require('dotenv').config();
const requestIp = require('request-ip');
const https = require('https');
const crypto = require('crypto');
const bonusRoutes = require('./bonus/routes');
const bannerRoutes = require('./Banners/bannerroutes');
const blogAdminRoutes = require('./Blogs/blogroutes');
const blogPublicRoutes = require('./Blogs/getBlogRoutes');
const { UPLOAD_DIR: BLOG_UPLOAD_DIR } = require('./Blogs/uploads');
const faroutes = require('./2fa/routes');
const swaproutes = require('./internalswap/routes');
const wpayRoutes = require('./waypay/routes');
const apayRoutes = require('./apay/routes');
const f2payRoutes = require('./f2pay/routes');
const jsGamesRoutes = require('./jsgames/routes');
const jsGamesv2Routes = require('./jsgamesv2/gameRoutes');
const logger = require('./jsgamesv2/logger');
const clubRoutes = require('./clubmembership/routes');
const kycRoutes = require('./kyc/routes');
const giftCardRoutes = require('./GiftCards/router');
const emailRoutes = require('./emailservice/routes');
const firebaseRoutes = require('./firabsenotifcation/routes');
const exchangeRateRoutes = require('./exchangerate/routes');
const apiGameRoutes = require('./xgamingapi/routes');
const bankDetailsRoutes = require('./BankDetails/bankroutes');
const teamRoutes = require('./affiliate/teamaffiliateroutes');
const affiliateRoutes = require('./affiliate/affiliateroutes');
const clubNotificationRoutes = require('./clubmembership/clubnotification/routes');
const depsoitHistoryRoute = require('./depositHistory/routes');
const fiatWithdrawRoutes = require('./fiatwithdraw/routes');
const betHistoryRoutes = require('./bethistory/routes');
const clubBannerRoutes = require('./clubmembership/clubbanners/routes');
const depositRoutes = require('./fiatdeposit/routes');
const userBonusRoutes = require('./bonus/userBonusRoutes');
const adminBonusRoutes = require('./bonus/adminBonusRoutes');
const reportRoutes = require('./reports/routes');
const cricpayRoutes = require('./cricpay/routes');
const girRoutes = require('./gis/routes');
const userRoutes = require('./Users/routes');
const sportsRoutes = require('./sportsapi/sportsapiroutes');
const exchangeRateService = require('./updateExchangeRate');
const authRoutes = require('./system/routes/routes');
const staffRoutes = require('./system/routes/staff');
const staffRoutesPublic = require('./system/routes/public');
const spinwinRoutes = require('./spinwin/routes');
const teenPattiRoutes = require('./teenpatti/routes');
const threeDGameRoutes = require('./3dgame/routes');
const staffRoutesDeposit = require('./system/deposit/routes');
const lordsRoutes = require('./system/routes/lords');
const accessRoutes = require('./system/routes/access');
const { protectStaff } = require('./system/middleware/auth');
const { guardAdmin } = require('./system/middleware/guardAdmin');
const { guardPlayer } = require('./system/middleware/guardPlayer');
const { withActivity, recordActivity } = require('./system/utils/recordActivity');
const { generatePlayerReport } = require('./reports/playerReportPdf');
const { generateCasinoSessionReport, generateSportsSessionReport } = require('./reports/sessionReportPdf');
const { validateTransactionPassword } = require('./system/controllers/lordsController');
const { registrationCodeStatus, selfServeSql } = require('./system/utils/branch');
const sportsmain = require('./sportsmain/API/routes');
const locksystemRoutes = require('./locksystem/routes');
const { initCron } = require('./bonus/bonusengine');

const { EventEmitter } = require('events');
const sportsBettingRoutes = require('./sportsbet/routes');
const mannualSettlementRoutes = require('./mannualsettlement/routes');
const { ensureDemoSchema, rejectDemoUser } = require('./system/utils/demoUsers');
// INstantiating the express-jwt middleware
const jwtMW = jwt({
  secret: "REMOVED_SECRET",
  algorithms: ["RS256"],
});

// General Config
var config = require("./config");
const { sign } = require("crypto");

let users = 0;

if (!config.developer && cluster.isMaster) {
  console.log(`Number of CPUs is ${totalCPUs}`);
  console.log(`Master ${process.pid} is running`);

  // Fork workers.
  for (let i = 0; i < totalCPUs; i++) {
    cluster.fork();
  }

  cluster.on("exit", (worker, code, signal) => {
    console.log(`worker ${worker.process.pid} died`);
    console.log("Let's fork another worker!");
    cluster.fork();
  });
} else {
  // See the react auth blog in which cors is required for access
  server.use((req, res, next) => {
    // res.setHeader('Access-Control-Allow-Origin', 'http://localhost:3004');
    res.setHeader("Access-Control-Allow-Headers", "Content-type,Authorization", "Access-Control-Allow-Origin");
    next();
  });
  // parse application/json
  server.use(bodyParser.json());
  // parse application/x-www-form-urlencoded
  server.use(
    bodyParser.urlencoded({
      extended: true,
    })
  );
  server.get('/health', (req, res) => res.json({ ok: true, time: Date.now() }));
  // superadmindemo & co: no writes, blanked replies (see system/utils/demoView.js)
  server.use(require('./system/utils/demoView').demoViewGuard);

  // -------------------
  // // Graceful shutdown
  // // -------------------
  // function gracefulShutdown() {
  //   console.log('SIGTERM received — shutting down gracefully');
  //   server.close(() => {
  //     console.log('HTTP server closed');
  //     if (io && typeof io.close === 'function') {
  //       io.close(() => {
  //         console.log('Socket.IO closed');
  //         // close DB / redis pools here
  //         process.exit(0);
  //       });
  //     } else {
  //       process.exit(0);
  //     }
  //   });

  //   setTimeout(() => {
  //     console.error('Could not close connections in time, forcefully terminating');
  //     process.exit(1);
  //   }, 10000);
  // }

  // process.on('SIGTERM', gracefulShutdown);
  // process.on('SIGINT', gracefulShutdown);

  // process.on('uncaughtException', (err) => {
  //   console.error('Uncaught Exception', err);
  // });
  // process.on('unhandledRejection', (reason) => {
  //   console.error('Unhandled Rejection', reason);
  // });
  server.use((err, req, res, next) => {
    console.error('Unhandled error:', err && (err.stack || err.message || err));
    // safe JSON response so client doesn't see raw 500 page
    res.status(err && err.status ? err.status : 500).json({ error: 'internal_server_error' });
  });

  server.use(cors(
    {
      origin: '*',
      credentials: true,

    }
  ));
  EventEmitter.defaultMaxListeners = 100;
  server.set("io", io);
  // setup viewEngine
  // configViewEngine(server);
  // init Web Routes
  // routes.initWebRouter(server);
  //Server Security
  server.use(
    helmet({
      crossOriginEmbedderPolicy: false,
      frameguard: false
    })
  );
  server.use(xss());
  server.use(compr());

  //Upload Image
  server.use(siofu.router);

  console.log(`Worker ${process.pid} started`);


  const { v4: uuidv4 } = require('uuid');

  const uploadsDir = path.join(__dirname, 'uploads/deposit_screenshots');
  if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
  }
  //  exchangeRateService.initExchangeRateUpdateJob();
  initCron(io);
  ensureDemoSchema().catch(e => console.error('[demoUsers] schema init failed:', e.message));
  require('./siteconfig/sockets/configSocket')(io);

  server.use('/banners', express.static(path.join(__dirname, 'banners')));
  server.use('/bonus', bonusRoutes);
  server.use('/giftCard', giftCardRoutes);
  server.use('/Userbonus', userBonusRoutes);
  server.use('/Adminbonus', adminBonusRoutes);
  server.use('/affiliateAdmin', teamRoutes);
  server.use('/api/banners', bannerRoutes);
  // Blog. Public reads are open; every write needs a staff token (protectStaff
  // enforces, unlike guardAdmin's audit mode). Images are read by the site and
  // the admin panel from other origins, so they opt out of helmet's
  // same-origin resource policy.
  server.use('/api/getblog', blogPublicRoutes);
  server.use('/api/blogs', protectStaff, blogAdminRoutes);
  server.use(
    '/uploads/blogs',
    (req, res, next) => {
      res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
      res.setHeader('X-Content-Type-Options', 'nosniff');
      next();
    },
    express.static(BLOG_UPLOAD_DIR, { maxAge: '30d', immutable: true, index: false, dotfiles: 'deny' })
  );
  server.use('/api/sportsmain', sportsmain);
  server.use('/sports', sportsRoutes);
  server.use('/sportsapi', sportsRoutes);
  server.use('/locksystem', locksystemRoutes);
  server.use('/xGaming', apiGameRoutes);
  server.use('/sportsbetting', sportsBettingRoutes);
  server.use('/api/internalsettle', mannualSettlementRoutes);
  server.use('/exchangeRate', exchangeRateRoutes);
  server.use('/internalswap', swaproutes);
  server.use('/email', emailRoutes);
  server.use('/api/payments', wpayRoutes);
  server.use('/firebase', firebaseRoutes);
  server.use('/remotes', apayRoutes);
  server.use('/f2pay', f2payRoutes);
  server.use('/jsGames', jsGamesRoutes);
  server.use('/jsGamesv2', jsGamesv2Routes);
  server.use('/affiliate', affiliateRoutes);
  server.use('/clubmembership', clubRoutes);
  server.use('/clubnotification', clubNotificationRoutes);
  server.use('/depositHistory', depsoitHistoryRoute);
  server.use(fiatWithdrawRoutes);
  server.use('/api/deposits', depositRoutes);
  server.use('/api/deposit', staffRoutesDeposit);
  server.use('/clubbanner', clubBannerRoutes);
  server.use('/bankdetails', bankDetailsRoutes);
  server.use('/betHistory', betHistoryRoutes);
  server.use('/2fa', faroutes);
  server.use('/kyc', kycRoutes);
  server.use('/user', userRoutes);
  server.use('/reports', reportRoutes);
  server.use('/cricpay', cricpayRoutes);
  server.use('/api/gis', girRoutes);
  server.use('/api/staff/auth', authRoutes);
  server.use('/api/staff', staffRoutes);
  server.use('/lords', lordsRoutes);
  server.use('/lords/access', accessRoutes);
  server.use('/api/demo-portal', require('./system/routes/demoPortal'));
  server.use('/api/branch', require('./system/routes/branch'));
  server.use('/marketing', require('./system/routes/marketing'));
  server.use('/api/public', staffRoutesPublic);
  server.use('/api/spinwin', spinwinRoutes);
  server.use('/api/teenpatti', teenPattiRoutes);
  server.use('/api/3dgame', threeDGameRoutes);
  server.use('/api/admin/balance-sheet', require('./balancesheet/routes'));
  server.use('/api/admin/agent-report', require('./report/routes'));
  server.use('/api/admin/config', require('./siteconfig/routes/configRoutes')(io));
  server.use('/api/admin/lookup', require('./siteconfig/routes/lookupRoutes')());
  server.use('/api/admin/users', require('./siteconfig/routes/userTreeRoutes')());
  const withdrawalControl = require('./siteconfig/routes/withdrawalControlRoutes')(io);
  server.use('/api/admin/withdrawal-control', withdrawalControl.admin);
  server.use('/api/withdrawal-status', withdrawalControl.public);
  server.use('/api/admin', require('./siteconfig/routes/adminRiskRoutes')());

  server.use(function (err, req, res, next) {
    logger.error('Unhandled error', { error: err });
    res.status(500).json({ success: false, error: 'Internal server error' });
  });
  // Constants
  const API_KEY = "REMOVED_SECRET";
  const PRODUCT_INFO = "Product Name";
  const CUSTOMER_NAME = "Jon Doe";
  const CUSTOMER_EMAIL = "jondoe@gmail.com";
  const CUSTOMER_MOBILE = "9009090909";
  const REDIRECT_URL = "https://example.com";

  // POST route for creating a payment order

  server.post('/createorderupi', rejectDemoUser, (req, res) => {
    console.log('Request body:', req.body);

    const { uid, amount } = req.body;

    if (!uid || !amount) {
      return res.status(400).json({ status: false, msg: "Missing uid or amount" });
    }

    const CLIENT_TXN_ID = uuidv4();
    console.log(CLIENT_TXN_ID);
    const date = new Date();
    const istOffset = 5.5 * 60 * 60 * 1000; // IST is UTC + 5:30 in milliseconds
    const istDate = new Date(date.getTime() + istOffset);

    // Format the IST date as dd/mm/yyyy
    const formattedDate = `${istDate.getDate()}-${istDate.getMonth() + 1}-${istDate.getFullYear()}`;
    const orderData = JSON.stringify({
      key: API_KEY,
      client_txn_id: CLIENT_TXN_ID,
      amount: amount,
      p_info: PRODUCT_INFO,
      customer_name: CUSTOMER_NAME,
      customer_email: CUSTOMER_EMAIL,
      customer_mobile: CUSTOMER_MOBILE,
      redirect_url: REDIRECT_URL,
      udf1: uid,
      udf2: formattedDate
    });

    const options = {
      hostname: 'api.ekqr.in',
      path: '/api/create_order',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': orderData.length,
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*',
      }
    };

    const request = https.request(options, (response) => {
      let data = '';

      response.on('data', (chunk) => {
        data += chunk;
      });

      response.on('end', () => {
        try {
          const parsedData = JSON.parse(data);

          if (parsedData.status) {
            const transactionidgateway = parsedData.data.order_id;
            const status = 'pending';

            // Insert data into PostgreSQL
            const insertQuery = `
            INSERT INTO upideposit (uid, transactioniduser, transactionidgateway, transactiondate, amount, status)
            VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING *;
          `;
            const values = [uid, CLIENT_TXN_ID, transactionidgateway, formattedDate, amount, status];

            pg.query(insertQuery, values, (err, result) => {
              if (err) {
                console.error('Error saving to database:', err);
                return res.status(500).json({ status: false, msg: "Database insert failed", error: err.message });
              }

              res.json({
                status: true,
                msg: "Order Created and saved in DB",
                data: parsedData.data,
                savedTransaction: result.rows[0]
              });
            });
          } else {
            res.status(500).json({
              status: false,
              msg: parsedData.msg || "Order creation failed",
            });
          }
        } catch (error) {
          res.status(500).json({
            status: false,
            msg: "Error parsing response",
            error: error.message
          });
        }
      });
    });

    request.on('error', (error) => {
      res.status(500).json({
        status: false,
        msg: "Request failed",
        error: error.message
      });
    });

    request.write(orderData);
    request.end();
  });
  server.post('/checkorderstatusupi', (req, res) => {
    const { client_txn_id, txn_date } = req.body;

    if (!client_txn_id || !txn_date) {
      return res.status(400).json({ status: false, msg: "Missing client_txn_id or txn_date" });
    }

    // Prepare the data to send to the external API
    const statusData = JSON.stringify({
      key: API_KEY,  // Your API Key
      client_txn_id: client_txn_id,
      txn_date: txn_date
    });

    const options = {
      hostname: 'api.ekqr.in',
      path: '/api/check_order_status',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': statusData.length,
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*',
      }
    };

    const request = https.request(options, (response) => {
      let data = '';

      // A chunk of data has been received.
      response.on('data', (chunk) => {
        data += chunk;
      });

      // The whole response has been received.
      response.on('end', () => {
        try {
          const parsedData = JSON.parse(data); // Parse JSON response

          if (parsedData.status) {
            res.json({
              status: true,
              msg: "Order status fetched",
              data: parsedData.data
            });
          } else {
            res.status(500).json({
              status: false,
              msg: parsedData.msg || "Order status fetch failed",
            });
          }
        } catch (error) {
          res.status(500).json({
            status: false,
            msg: "Error parsing response",
            error: error.message
          });
        }
      });
    });

    // Handle request error
    request.on('error', (error) => {
      res.status(500).json({
        status: false,
        msg: "Request failed",
        error: error.message
      });
    });

    // Write data to request body and end the request
    request.write(statusData);
    request.end();
  });

  server.post('/update-gis-images-run-all', guardAdmin('update-gis-images-run-all'), async (req, res) => {
    const limit = 50;
    const previewOnly = !!req.body.previewOnly;

    let lastId = 0;
    let totalProcessed = 0;
    let totalUpdated = 0;
    let totalFailed = 0;

    // 🔹 Normalize game name
    const normalizeGameName = (name = '') =>
      name
        .toLowerCase()
        .replace(/[\u2122®©]/g, '')      // ™ ® ©
        .replace(/\(.*?\)/g, '')         // (Mobile), (HD)
        .replace(/\s+-\s+mobile$/i, '')  // " - Mobile"
        .replace(/\s+mobile$/i, '')      // trailing mobile
        .replace(/[-_]/g, ' ')            // dash to space
        .replace(/\s+/g, ' ')
        .trim();

    // 🔹 Normalize provider (BFGames ⇄ BF Games)
    const normalizeProvider = (provider = '') =>
      provider
        .toLowerCase()
        .replace(/\s+/g, '') // 🔥 remove ALL spaces
        .trim();

    try {
      while (true) {
        // 🔥 ID-based pagination (NO SKIPS)
        const gamesRes = await pg.query(
          `
        SELECT id, name, provider, image, images
        FROM gisgamesnew
        WHERE id > $1
        ORDER BY id
        LIMIT $2
        `,
          [lastId, limit]
        );

        if (gamesRes.rowCount === 0) break;

        for (const game of gamesRes.rows) {
          lastId = game.id;
          totalProcessed++;

          try {
            const normalizedName = normalizeGameName(game.name);
            const normalizedProvider = normalizeProvider(game.provider);

            // 🔍 Match provider + name
            const matchRes = await pg.query(
              `
            SELECT image_url
            FROM provider_games
            WHERE replace(lower(provider_name), ' ', '') = $1
              AND lower(trim(game_name)) = $2
            LIMIT 1
            `,
              [normalizedProvider, normalizedName]
            );

            if (matchRes.rowCount === 0) continue;

            const newImage = matchRes.rows[0].image_url;

            // ⏭ Skip if already correct
            if (game.image === newImage) continue;

            // 📝 Update
            if (!previewOnly) {
              await pg.query(
                `
              UPDATE gisgamesnew
              SET image = $1,
                  images = CASE
                    WHEN jsonb_typeof(images) = 'array'
                         AND jsonb_array_length(images) > 0
                    THEN jsonb_set(images, '{0,url}', to_jsonb($1::text), true)
                    ELSE images
                  END
              WHERE id = $2
              `,
                [newImage, game.id]
              );
            }

            totalUpdated++;
          } catch (rowErr) {
            totalFailed++;
            continue;
          }
        }

        // Optional progress log
        if (totalProcessed % 500 === 0) {
          console.log(
            `[GIS IMAGE SYNC] processed=${totalProcessed}, updated=${totalUpdated}`
          );
        }
      }

      return res.json({
        success: true,
        previewOnly,
        totalProcessed,
        totalUpdated,
        totalFailed,
        message: 'GIS image sync completed successfully',
      });
    } catch (err) {
      console.error('update-gis-images-run-all error:', err);
      return res.status(500).json({
        success: false,
        error: err.message,
      });
    }
  });

  server.post('/webhook/paymentstatuspui', async (req, res) => {
    const {
      amount,
      client_txn_id,
      status,
      customer_email,
      customer_mobile,
      customer_name,
      customer_vpa,
      id, // order id of upigateway
      p_info,
      remark,
      txnAt,
      udf1, // uid
      udf2, // formatted date
      upi_txn_id
    } = req.body;

    try {
      // Find the deposit record using the client_txn_id (transactioniduser in upideposit table)
      const depositQuery = 'SELECT * FROM upideposit WHERE transactioniduser = $1';
      const depositResult = await pg.query(depositQuery, [client_txn_id]);

      if (depositResult.rows.length === 0) {
        return res.status(404).json({ status: false, msg: "Transaction not found" });
      }

      const deposit = depositResult.rows[0];
      const uid = deposit.uid; // Extract the uid from the upideposit table

      // If the payment was successful, update the status in upideposit and add money to the user's INR balance
      if (status === 'success') {
        // Update the upideposit table to mark the transaction as successful
        const updateDepositQuery = `
        UPDATE upideposit 
        SET status = 'success'
        WHERE transactioniduser = $1
      `;
        await pg.query(updateDepositQuery, [client_txn_id]);

        // Update the user's INR balance in the credits table
        const updateCreditsQuery = `
        UPDATE credits
        SET inr = inr + $1
        WHERE uid = $2
      `;
        await pg.query(updateCreditsQuery, [parseFloat(amount), uid]);

        return res.json({ status: true, msg: "Payment successful, user balance updated" });
      } else if (status === 'failure') {
        // If the payment failed, just update the status to 'failed' in upideposit table
        const updateDepositQuery = `
        UPDATE upideposit 
        SET status = 'failed'
        WHERE transactioniduser = $1
      `;
        await pg.query(updateDepositQuery, [client_txn_id]);

        return res.json({ status: true, msg: "Payment failed, status updated" });
      } else {
        return res.status(400).json({ status: false, msg: "Invalid status" });
      }
    } catch (error) {
      console.error('Error processing webhook:', error);
      return res.status(500).json({ status: false, msg: "Internal server error", error: error.message });
    }
  });

  server.post('/update-image', guardAdmin('update-image'), async (req, res) => {

    const previewOnly = !!req.body.previewOnly;

    try {
      await pg.query('BEGIN');

      // Preview rows that would be updated
      const previewSql = `
      SELECT g2.id AS gisgamesnew_id,
             g2.name AS gisgamesnew_name,
             g2.image AS gisgamesnew_image,
             g1.image AS gis_games_image
      FROM gisgamesnew g2
      JOIN gis_games g1 ON lower(trim(g1.name)) = lower(trim(g2.name))
      ORDER BY g2.id
      LIMIT 1000;
    `;
      const previewRes = await pg.query(previewSql);

      if (previewOnly) {
        await pg.query('ROLLBACK');
        return res.json({
          previewOnly: true,
          matches: previewRes.rows,
          matchesCount: previewRes.rowCount,
        });
      }

      // Do the update
      const updateSql = `
      UPDATE gisgamesnew g2
      SET image = g1.image,
          images = CASE
            WHEN jsonb_typeof(g2.images) = 'array' AND jsonb_array_length(g2.images) > 0 THEN
              jsonb_set(g2.images, '{0,url}', to_jsonb(g1.image::text), true)
            ELSE
              g2.images
          END
      FROM gis_games g1
      WHERE lower(trim(g1.name)) = lower(trim(g2.name))
      RETURNING g2.id, g2.name, g2.image;
    `;

      const updateRes = await pg.query(updateSql);

      await pg.query('COMMIT');

      return res.json({
        success: true,
        updatedCount: updateRes.rowCount,
        updatedRows: updateRes.rows,
        preview: previewRes.rows,
      });
    } catch (err) {
      await pg.query('ROLLBACK');
      console.error('update-image error:', err);
      return res.status(500).json({ success: false, error: err.message });
    } finally {
      console.log("done");
    }
  });


  //xgaming
  // Base URL and credentials for API requests
  const BASE_URL_CASINO = 'https://gamerun.gaminghub360.com';
  const SECREATEkEYCASINO = 'Hja934U1nz';
  const casinoId = 'skyla_prod';

  // Helper function to generate X-Auth header
  const generateXAuthHeader = (commandName) => {
    return crypto.createHash('sha1').update(commandName + casinoId + SECREATEkEYCASINO).digest('hex');
  };

  // Generate a unique session ID for each game run
  const generateSessionIdC = () => {
    return crypto.randomBytes(16).toString('hex');
  };
  const allowedVendors = [
    'amatic', 'amusnet', 'netent', 'greentube', 'quickspin',
    'wazdan', 'pragmaticplay', 'playngo', 'merkur', 'microgaming', 'gamomat'
  ];
  // GameRun API: Constructs the game URL with all necessary parameters

  server.post('/api/casino/gamerun', async (req, res) => {
    const { game_id, currency, mode, language, home_url, device, user_id, vendor, title, coin } = req.body;
    const session = generateSessionIdC(); // Generate a unique session for each game run

    try {
      // Fetch the list of games

      // Determine the BASE_URL_CASINO based on the vendor
      const BASE_URL_CASINO = allowedVendors.includes(vendor) ? 'https://gamerun.thexgaming.com' : 'https://gamerun.gaminghub360.com';

      // Generate the GameRun URL
      const gameRunUrl = `${BASE_URL_CASINO}/?mode=${mode}&game_id=${game_id}&session=${session}&currency=${currency}&language=${language}&casino_id=${casinoId}&home_url=${home_url}&device=${device}`;

      const query = `
       INSERT INTO game_runs (game_id, user_id, currency, mode, language, home_url, device, vendor, title, session_id, url, coin)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
     `;
      const values = [game_id, user_id, currency, mode, language, home_url, device, vendor, title, session, gameRunUrl, coin];

      await pg.query(query, values);

      res.json({ gameRunUrl });

    } catch (error) {
      res.status(500).json({ message: 'Failed to generate GameRun URL and save data', error: error.message });
    }
  });


  const generateResponseHash = (status, responseTimestamp) => {
    return crypto.createHash('sha1').update(status + responseTimestamp + SECREATEkEYCASINO).digest('hex');
  };

  // Helper function to generate current timestamp
  const getCurrentTimestamp = () => {
    return new Date().toISOString().replace('T', ' ').slice(0, 19);
  };

  // Helper function to verify hash from request
  const verifyHash = (command, request_timestamp, reqHash) => {
    const calculatedHash = crypto.createHash('sha1').update(command + request_timestamp + SECREATEkEYCASINO).digest('hex');
    return calculatedHash === reqHash;
  };

  server.post('/api/casino/authenticate', async (req, res) => {
    const { command, request_timestamp, hash, data } = req.body;

    // Log received request data
    console.log('Received request:', { command, request_timestamp, hash, data });

    // Step 1: Verify the hash
    if (!verifyHash(command, request_timestamp, hash)) {
      console.log('Invalid hash:', { command, request_timestamp, hash, data });

      return res.status(403).json({
        request: {
          command,
          request_timestamp,
          hash,
          data
        },
        response: {
          status: "ERROR",
          response_timestamp: getCurrentTimestamp(),
          hash: generateResponseHash('ERROR', getCurrentTimestamp()),
          data: {
            error_code: "60",
            error_message: "Invalid hash"
          }
        }
      });
    }

    // Step 2: Check for session
    if (!data || !data.session) {
      console.log('Invalid session:', { command, request_timestamp, hash, data });

      return res.status(400).json({
        request: {
          command,
          request_timestamp,
          hash,
          data
        },
        response: {
          status: "ERROR",
          response_timestamp: getCurrentTimestamp(),
          hash: generateResponseHash('ERROR', getCurrentTimestamp()),
          data: {
            error_code: "61",
            error_message: "Invalid session"
          }
        }
      });
    }

    try {
      // Step 3: Fetch game run data based on session
      const result = await pg.query(
        'SELECT * FROM game_runs WHERE session_id = $1 LIMIT 1',
        [data.session]
      );
      console.log('Game run data:', result.rows);

      // Step 4: Handle if session not found
      if (result.rows.length === 0) {
        console.log('Session not found:', { command, request_timestamp, hash, data });

        return res.status(404).json({
          request: {
            command,
            request_timestamp,
            hash,
            data
          },
          response: {
            status: "ERROR",
            response_timestamp: getCurrentTimestamp(),
            hash: generateResponseHash('ERROR', getCurrentTimestamp()),
            data: {
              error_code: "74",
              error_message: "Session not found in game runs"
            }
          }
        });
      }

      const gameRun = result.rows[0];
      const userId = gameRun.user_id;
      const currency = gameRun.currency;
      const coin = gameRun.coin;
      console.log(userId);
      // Step 5: Fetch user data based on user_id
      const userResult = await pg.query(
        'SELECT * FROM users WHERE id = $1 LIMIT 1',
        [userId]
      );
      console.log('User data:', userResult.rows);

      // Step 6: Handle if user not found
      if (userResult.rows.length === 0) {
        console.log('User not found:', { command, request_timestamp, hash, data });

        return res.status(404).json({
          request: {
            command,
            request_timestamp,
            hash,
            data
          },
          response: {
            status: "ERROR",
            response_timestamp: getCurrentTimestamp(),
            hash: generateResponseHash('ERROR', getCurrentTimestamp()),
            data: {
              error_code: "74",
              error_message: "User not found"
            }
          }
        });
      }

      const user = userResult.rows[0];

      // Step 7: Fetch user's balance based on coin type (from credits table)
      const balanceResult = await pg.query(
        'SELECT * FROM credits WHERE uid = $1 LIMIT 1',
        [userId]
      );
      console.log('User balance data:', balanceResult.rows);

      if (balanceResult.rows.length === 0) {
        console.log('User balance not found:', { command, request_timestamp, hash, data });

        return res.status(404).json({
          request: {
            command,
            request_timestamp,
            hash,
            data
          },
          response: {
            status: "ERROR",
            response_timestamp: getCurrentTimestamp(),
            hash: generateResponseHash('ERROR', getCurrentTimestamp()),
            data: {
              error_code: "74",
              error_message: "User balance not found"
            }
          }
        });
      }

      const userBalance = balanceResult.rows[0];
      const userCoinBalance = userBalance[coin.toLowerCase()] || 0.00;

      // Step 8: Create response data
      const responseData = {
        request: { command, request_timestamp, hash, data },
        response: {
          status: "OK",
          response_timestamp: getCurrentTimestamp(),
          hash: generateResponseHash('OK', getCurrentTimestamp()),
          data: {
            user_id: String(user.id),
            user_name: user.name,
            user_country: "India",
            balance: userCoinBalance,
            currency_code: currency.toUpperCase()
          }
        }
      };

      // Log response data before sending
      console.log('Sending response:', responseData);

      res.json(responseData);
    } catch (error) {
      console.error('Error during authentication:', error);

      return res.status(500).json({
        request: {
          command,
          request_timestamp,
          hash,
          data
        },
        response: {
          status: "ERROR",
          response_timestamp: getCurrentTimestamp(),
          hash: generateResponseHash('ERROR', getCurrentTimestamp()),
          data: {
            error_code: "90",
            error_message: "Internal server error"
          }
        }
      });
    }
  });

  // 2. Balance API Callback
  server.post('/api/casino/balance', async (req, res) => {
    const { command, request_timestamp, hash, data } = req.body;

    // Verify the hash
    if (!verifyHash(command, request_timestamp, hash)) {
      return res.status(403).json({
        request: {
          command,
          request_timestamp,
          hash,
          data
        },
        response: {
          status: "ERROR",
          response_timestamp: getCurrentTimestamp(),
          hash: generateResponseHash('ERROR', getCurrentTimestamp()),
          data: {
            error_code: "60",
            error_message: "Invalid hash"
          }
        }
      });
    }

    // Check for required fields in the request data
    if (!data || !data.session || !data.user_id || !data.currency_code) {
      return res.status(400).json({
        request: { command, request_timestamp, hash, data },
        response: {
          status: "ERROR",
          response_timestamp: getCurrentTimestamp(),
          hash: generateResponseHash('ERROR', getCurrentTimestamp()),
          data: {
            error_code: "70",
            error_message: "Required fields are missing"
          }
        }
      });
    }

    try {
      // Convert user_id to bigint since it is stored as bigint in game_runs table
      const userId = BigInt(data.user_id);

      // Query the game_runs table to get the coin associated with this session and user
      const gameRun = await pg.query('SELECT * FROM game_runs WHERE session_id = $1 AND user_id = $2', [data.session, userId]);

      // If no matching game run found, return error
      if (gameRun.rows.length === 0) {
        return res.status(404).json({
          request: { command, request_timestamp, hash, data },
          response: {
            status: 'ERROR',
            response_timestamp: getCurrentTimestamp(),
            hash: generateResponseHash('ERROR', getCurrentTimestamp()),
            data: {
              error_code: '74',
              error_message: 'User not found',
            },
          },
        });
      }

      // Get the coin type from the game run
      const coin = gameRun.rows[0].coin;

      // Query the credits table to get the balance based on the coin type
      const creditQuery = await pg.query('SELECT * FROM credits WHERE uid = $1', [userId]);

      if (creditQuery.rows.length === 0) {
        return res.status(404).json({
          request: { command, request_timestamp, hash, data },
          response: {
            status: 'ERROR',
            response_timestamp: getCurrentTimestamp(),
            hash: generateResponseHash('ERROR', getCurrentTimestamp()),
            data: {
              error_code: '74',
              error_message: 'User not found',
            },
          },
        });
      }

      // Get the balance from the corresponding coin field in the credits table
      const userCredits = creditQuery.rows[0];
      // Modify the balance retrieval to round to 2 decimal places
      let balance = parseFloat((userCredits[coin.toLowerCase()] || 0).toFixed(2));  // Get the balance based on the coin type

      // Prepare response
      const responseTimestamp = getCurrentTimestamp();
      const responseHash = generateResponseHash('OK', responseTimestamp);

      const responseData = {
        request: { command, request_timestamp, hash, data },
        response: {
          status: 'OK',
          response_timestamp: responseTimestamp,
          hash: responseHash,
          data: {
            balance: balance,
            currency_code: data.currency_code,
          },
        },
      };
      console.log(responseData);
      // Send the response
      res.json(responseData);
    } catch (error) {
      console.error('Error processing balance request:', error);
      return res.status(500).json({
        request: { command, request_timestamp, hash, data },
        response: {
          status: 'ERROR',
          response_timestamp: getCurrentTimestamp(),
          hash: generateResponseHash('ERROR', getCurrentTimestamp()),
          data: {
            error_code: '90',
            error_message: 'Internal server error',
          },
        },
      });
    }
  });

  const insertOrUpdateTransaction = async (data, userId, status) => {
    try {
      // Check if the transaction with the same transaction_id and user_id already exists
      const checkTransaction = await pg.query(
        'SELECT * FROM transactionscasino WHERE transaction_id = $1 AND user_id = $2',
        [data.transaction_id, userId]
      );

      if (checkTransaction.rows.length > 0) {
        // If a record exists, update the existing transaction
        await pg.query(
          'UPDATE transactionscasino SET round_id = $1, transaction_type = $2, amount = $3, currency_code = $4, transaction_timestamp = $5, reason = $6, round_finished = $7, transaction_status = $8, updated_at = CURRENT_TIMESTAMP WHERE transaction_id = $9 AND user_id = $10',
          [
            data.round_id,
            data.transaction_type,
            data.amount,
            data.currency_code,
            data.transaction_timestamp,
            data.reason || 'No reason provided',
            data.round_finished,
            status, // Set transaction status here
            data.transaction_id,
            userId,
          ]
        );
        console.log('Transaction updated successfully');
      } else {
        // If no record exists, insert a new transaction
        await pg.query(
          'INSERT INTO transactionscasino (transaction_id, round_id, user_id, session, transaction_type, amount, currency_code, transaction_timestamp, reason, round_finished, transaction_status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)',
          [
            data.transaction_id,
            data.round_id,
            userId,
            data.session || "No Session",
            data.transaction_type,
            data.amount,
            data.currency_code,
            data.transaction_timestamp,
            data.reason || 'No reason provided',
            data.round_finished,
            status // Set transaction status here
          ]
        );
        console.log('Transaction inserted successfully');
      }
    } catch (error) {
      console.error('Error inserting or updating transaction:', error);
      throw error;
    }
  };


  // 3. Change Balance API Callback
  // API to Change Balance
  server.post('/api/casino/changebalance', async (req, res) => {
    const { command, request_timestamp, hash, data } = req.body;

    // Verify the Hash
    if (!verifyHash(command, request_timestamp, hash)) {
      return res.status(403).json({
        request: { command, request_timestamp, hash, data },
        response: {
          status: "ERROR",
          response_timestamp: getCurrentTimestamp(),
          hash: generateResponseHash('ERROR', getCurrentTimestamp()),
          data: {
            error_code: "60",
            error_message: "Invalid hash"
          }
        }
      });
    }

    // Validate required fields
    if (!data || !data.user_id || !data.transaction_type || !data.transaction_id || !data.round_id || data.round_finished === undefined || !data.game_id || !data.transaction_timestamp) {
      return res.status(400).json({
        request: { command, request_timestamp, hash, data },
        response: {
          status: "ERROR",
          response_timestamp: getCurrentTimestamp(),
          hash: generateResponseHash('ERROR', getCurrentTimestamp()),
          data: {
            error_code: "70",
            error_message: "Required fields are missing"
          }
        }
      });
    }

    try {
      // Log the incoming request data
      console.log(`Received change balance request: ${JSON.stringify(data)}`);

      // Convert user_id from string to BIGINT
      const userId = BigInt(data.user_id);
      let session = data.session;
      let gameRun;
      // If session is null, retrieve it from transactionscasino using transaction_id and user_id
      if (!session) {
        const transaction = await pg.query('SELECT session FROM transactionscasino WHERE transaction_id = $1 AND user_id = $2', [data.transaction_id, userId]);
        if (transaction.rows.length > 0) {
          session = transaction.rows[0].session;
          // Query the game_runs table to get the coin associated with this session and user
          gameRun = await pg.query('SELECT * FROM game_runs WHERE session_id = $1 AND user_id = $2', [session, userId]);
        } else {
          gameRun = await pg.query(
            'SELECT * FROM game_runs WHERE user_id = $1 ORDER BY created_at DESC LIMIT 1',
            [userId]
          );
        }
      }
      else {
        gameRun = await pg.query('SELECT * FROM game_runs WHERE session_id = $1 AND user_id = $2', [session, userId]);
      }
      // If no matching game run found, return error
      if (gameRun.rows.length === 0) {
        await insertOrUpdateTransaction(data, userId, "ERROR");
        return res.status(200).json({
          request: { command, request_timestamp, hash, data },
          response: {
            status: 'ERROR',
            response_timestamp: getCurrentTimestamp(),
            hash: generateResponseHash('ERROR', getCurrentTimestamp()),
            data: {
              error_code: '74',
              error_message: 'User not found',
            },
          },
        });
      }

      // Get the coin type from the game run
      const coin = gameRun.rows[0].coin;
      console.log("Coin Type:", coin);
      console.log(gameRun);
      // Query the credits table to get the balance based on the coin type
      const creditQuery = await pg.query('SELECT * FROM credits WHERE uid = $1', [userId]);

      if (creditQuery.rows.length === 0) {
        return res.status(200).json({
          request: { command, request_timestamp, hash, data },
          response: {
            status: 'ERROR',
            response_timestamp: getCurrentTimestamp(),
            hash: generateResponseHash('ERROR', getCurrentTimestamp()),
            data: {
              error_code: '74',
              error_message: 'User not found',
            },
          },
        });
      }

      // Get the balance from the corresponding coin field in the credits table
      const userCredits = creditQuery.rows[0];

      const userBalance = parseFloat((userCredits[coin.toLowerCase()] || 0).toFixed(2));
      // Validate transaction amount
      let updatedBalance = userBalance;
      let errorMessage = '';
      if (data.transaction_type === "BET") {
        updatedBalance -= parseFloat(data.amount);
        if (updatedBalance < 0) {
          errorMessage = "Insufficient balance for BET";
        }
      } else if (data.transaction_type === "WIN") {
        updatedBalance += parseFloat(data.amount);
      } else if (data.transaction_type === "REFUND") {
        updatedBalance += parseFloat(data.amount);
      } else {
        errorMessage = "Invalid transaction type";
      }
      if (errorMessage) {
        await insertOrUpdateTransaction(data, userId, "ERROR");
        return res.status(200).json({
          request: { command, request_timestamp, hash, data },
          response: {
            status: "ERROR",
            response_timestamp: getCurrentTimestamp(),
            hash: generateResponseHash('ERROR', getCurrentTimestamp()),
            data: {
              error_code: updatedBalance < 0 ? "71" : "90",
              error_message: errorMessage
            }
          }
        });
      }

      // Update the user's balance in the credits table (using the specific coin)
      await pg.query(`UPDATE credits SET ${safeCol(coin)} = $1 WHERE uid = $2`, [updatedBalance, userId]);
      await insertOrUpdateTransaction(data, userId, "OK");
      // Send successful response
      return res.json({
        request: { command, request_timestamp, hash, data },
        response: {
          status: "OK",
          response_timestamp: getCurrentTimestamp(),
          hash: generateResponseHash('OK', getCurrentTimestamp()),
          data: {
            balance: updatedBalance,
            currency_code: data.currency_code
          }
        }
      });

    } catch (err) {
      console.error('Error processing changebalance:', err);
      await insertOrUpdateTransaction(data, userId, "ERROR");
      return res.status(500).json({
        request: { command, request_timestamp, hash, data },
        response: {
          status: "ERROR",
          response_timestamp: getCurrentTimestamp(),
          hash: generateResponseHash('ERROR', getCurrentTimestamp()),
          data: {
            error_code: "99",
            error_message: "Internal server error"
          }
        }
      });
    }
  });



  // 4. Status API Callback
  server.post('/api/casino/status', async (req, res) => {
    const { command, request_timestamp, hash, data } = req.body;

    // Step 1: Verify hash
    if (!verifyHash(command, request_timestamp, hash)) {
      return res.status(403).json({
        request: { command, request_timestamp, hash, data },
        response: {
          status: "ERROR",
          response_timestamp: getCurrentTimestamp(),
          hash: generateResponseHash('ERROR', getCurrentTimestamp()),
          data: {
            error_code: "60",
            error_message: "Invalid hash"
          }
        }
      });
    }

    // Step 2: Validate required fields
    if (!data || !data.user_id || !data.transaction_id || !data.round_id) {
      return res.status(400).json({
        request: { command, request_timestamp, hash, data },
        response: {
          status: "ERROR",
          response_timestamp: getCurrentTimestamp(),
          hash: generateResponseHash('ERROR', getCurrentTimestamp()),
          data: {
            error_code: "80",
            error_message: "user_id, transaction_id, and round_id are required"
          }
        }
      });
    }

    // Convert user_id to BigInt
    const userId = BigInt(data.user_id);
    const transactionId = data.transaction_id;

    try {
      // Step 3: Fetch the transaction status from the database
      const result = await pg.query(
        'SELECT transaction_status FROM transactionscasino WHERE transaction_id = $1 AND user_id = $2',
        [transactionId, userId]
      );

      if (result.rows.length === 0) {
        // Step 4: If no transaction found
        return res.status(200).json({
          request: { command, request_timestamp, hash, data },
          response: {
            status: "ERROR",
            response_timestamp: getCurrentTimestamp(),
            hash: generateResponseHash('ERROR', getCurrentTimestamp()),
            data: {
              error_code: "81",
              error_message: "Transaction not found"
            }
          }
        });
      }

      // Transaction found, get its status
      const transactionStatus = result.rows[0].transaction_status;

      // Step 5: Prepare response based on transaction status
      const responseTimestamp = getCurrentTimestamp();
      const responseHash = generateResponseHash('OK', responseTimestamp);

      const responseData = {
        request: { command, request_timestamp, hash, data },
        response: {
          status: "OK",
          response_timestamp: responseTimestamp,
          hash: responseHash,
          data: {
            user_id: data.user_id,
            transaction_id: data.transaction_id,
            transaction_status: transactionStatus
          }
        }
      };

      res.json(responseData);

    } catch (error) {
      console.error('Error fetching transaction status:', error);
      return res.status(500).json({
        request: { command, request_timestamp, hash, data },
        response: {
          status: "ERROR",
          response_timestamp: getCurrentTimestamp(),
          hash: generateResponseHash('ERROR', getCurrentTimestamp()),
          data: {
            error_code: "90",
            error_message: "Internal Server Error"
          }
        }
      });
    }
  });

  // 5. Cancel API Callback
  server.post('/api/casino/cancel', async (req, res) => {
    const { command, request_timestamp, hash, data } = req.body;

    // Verify the Hash
    if (!verifyHash(command, request_timestamp, hash)) {
      return res.status(403).json({
        request: { command, request_timestamp, hash, data },
        response: {
          status: "ERROR",
          response_timestamp: getCurrentTimestamp(),
          hash: generateResponseHash('ERROR', getCurrentTimestamp()),
          data: {
            error_code: "60",
            error_message: "Invalid hash"
          }
        }
      });
    }

    // Validate required fields
    if (!data || !data.user_id || !data.transaction_id || !data.round_id || data.round_finished === undefined || !data.game_id) {
      return res.status(400).json({
        request: { command, request_timestamp, hash, data },
        response: {
          status: "ERROR",
          response_timestamp: getCurrentTimestamp(),
          hash: generateResponseHash('ERROR', getCurrentTimestamp()),
          data: {
            error_code: "70",
            error_message: "Required fields are missing"
          }
        }
      });
    }

    try {
      console.log(`Received cancel request: ${JSON.stringify(data)}`);

      const userId = BigInt(data.user_id);
      const transactionId = data.transaction_id;

      // Find the transaction in the transactionscasino table
      const transactionResult = await pg.query('SELECT * FROM transactionscasino WHERE transaction_id = $1 AND user_id = $2', [transactionId, userId]);
      if (transactionResult.rows.length === 0) {
        // If transaction not found, update status to ERROR
        await pg.query(
          'UPDATE transactionscasino SET transaction_status = $1, updated_at = CURRENT_TIMESTAMP WHERE transaction_id = $2 AND user_id = $3',
          ['ERROR', transactionId, userId]
        );

        return res.status(200).json({
          request: { command, request_timestamp, hash, data },
          response: {
            status: "ERROR",
            response_timestamp: getCurrentTimestamp(),
            hash: generateResponseHash('ERROR', getCurrentTimestamp()),
            data: {
              error_code: "81",
              error_message: "Transaction not found"
            }
          }
        });
      }

      const transaction = transactionResult.rows[0];
      const session = transaction.session;
      const amount = transaction.amount;

      // Get the coin type from the game_runs table using session and user_id
      const gameRunResult = await pg.query('SELECT * FROM game_runs WHERE session_id = $1 AND user_id = $2', [session, userId]);
      if (gameRunResult.rows.length === 0) {
        return res.status(200).json({
          request: { command, request_timestamp, hash, data },
          response: {
            status: "ERROR",
            response_timestamp: getCurrentTimestamp(),
            hash: generateResponseHash('ERROR', getCurrentTimestamp()),
            data: {
              error_code: "82",
              error_message: "Session not found"
            }
          }
        });
      }

      const coin = gameRunResult.rows[0].coin.toLowerCase();
      console.log("Coin Type:", coin);

      // Retrieve user's balance from the credits table
      const creditResult = await pg.query('SELECT * FROM credits WHERE uid = $1', [userId]);
      if (creditResult.rows.length === 0) {
        return res.status(200).json({
          request: { command, request_timestamp, hash, data },
          response: {
            status: 'ERROR',
            response_timestamp: getCurrentTimestamp(),
            hash: generateResponseHash('ERROR', getCurrentTimestamp()),
            data: {
              error_code: '74',
              error_message: 'User not found',
            },
          },
        });
      }

      const userCredits = creditResult.rows[0];
      const userBalance = parseFloat((userCredits[coin] || 0).toFixed(2));
      const updatedBalance = userBalance + amount;

      // Update the user's balance in the credits table
      await pg.query(`UPDATE credits SET ${safeCol(coin)} = $1 WHERE uid = $2`, [updatedBalance, userId]);

      // Update the transaction status to 'CANCELED'
      await pg.query(
        'UPDATE transactionscasino SET transaction_status = $1, updated_at = CURRENT_TIMESTAMP WHERE transaction_id = $2 AND user_id = $3',
        ['CANCELED', transactionId, userId]
      );

      const responseTimestamp = getCurrentTimestamp();
      const responseHash = generateResponseHash('OK', responseTimestamp);

      const responseData = {
        request: { command, request_timestamp, hash, data },
        response: {
          status: "OK",
          response_timestamp: responseTimestamp,
          hash: responseHash,
          data: {
            user_id: data.user_id,
            transaction_id: data.transaction_id,
            transaction_status: "CANCELED",
            updated_balance: updatedBalance
          }
        }
      };

      return res.json(responseData);

    } catch (err) {
      console.error('Error processing cancel:', err);

      if (data && data.transaction_id && data.user_id) {
        await pg.query(
          'UPDATE transactionscasino SET transaction_status = $1, updated_at = CURRENT_TIMESTAMP WHERE transaction_id = $2 AND user_id = $3',
          ['ERROR', data.transaction_id, data.user_id]
        );
      }

      return res.status(500).json({
        request: { command, request_timestamp, hash, data },
        response: {
          status: "ERROR",
          response_timestamp: getCurrentTimestamp(),
          hash: generateResponseHash('ERROR', getCurrentTimestamp()),
          data: {
            error_code: "99",
            error_message: "Internal server error"
          }
        }
      });
    }
  });




  // Casino Balance API
  server.get('/api/casino/casino-balance', async (req, res) => {
    try {
      const headers = {
        'X-Auth': generateXAuthHeader('balanceLimits'),
        'X-Casino-Id': casinoId
      };

      const response = await axios.get(`${BASE_URL_CASINO}/api/casino/balance`, { headers });
      res.json(response.data);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch casino balance', error: error.message });
    }
  });

  // EGT Jackpots Info API        
  server.get('/sportsCheck', async (req, res) => {
    try {
      // Query to get the sports value from siteconfig table
      const query = 'SELECT sports FROM siteconfig LIMIT 1';
      const result = await pg.query(query);

      // Check if we got a result
      if (result.rows.length === 0) {
        return res.status(404).json({
          success: false,
          message: 'Site configuration not found'
        });
      }

      // Get the sports value (boolean)
      const sportsEnabled = result.rows[0].sports;

      // Return the result
      res.json({
        success: true,
        sportsEnabled: sportsEnabled,
        message: `Sports is ${sportsEnabled ? 'enabled' : 'disabled'}`
      });

    } catch (error) {
      console.error('Error checking sports status:', error);
      res.status(500).json({
        success: false,
        message: 'Internal server error',
        error: error.message
      });
    }
  });
  server.get('/api/casino/jackpots', async (req, res) => {
    const { currency } = req.query;
    try {
      const headers = {
        'X-Auth': generateXAuthHeader('egtJackpotInfo'),
        'X-Casino-Id': casinoId
      };

      const response = await axios.get(`${BASE_URL_CASINO}/api/jackpots/egt-jackpot-info`, {
        headers,
        params: { currency }
      });
      res.json(response.data);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch jackpots info', error: error.message });
    }
  });


  const fetchGameList = async () => {
    try {
      const xAuthHeader = generateXAuthHeader('games');
      const headers = {
        'X-Auth': xAuthHeader,
        'X-Casino-Id': casinoId
      };

      // Make a GET request to the external Casino API
      const response = await axios.get('https://gamerun.gaminghub360.com/api/casino/games/list', { headers });
      return response.data.games;
    } catch (error) {
      console.error('Error fetching game list:', error);
      throw new Error('Failed to fetch game list');
    }
  };

  // New Route: Get Vendors and Their Types
  server.get('/api/casino/vendors', async (req, res) => {
    try {
      const games = await fetchGameList();
      const vendors = {};

      games.forEach(game => {
        const vendor = game.vendor;
        const type = game.type;

        // If the vendor is not already in the vendors object, initialize it
        if (!vendors[vendor]) {
          vendors[vendor] = new Set();
        }

        // Add the type to the set of types for this vendor
        vendors[vendor].add(type);
      });

      // Convert the sets into arrays for easier consumption
      const vendorList = Object.keys(vendors).map(vendor => ({
        vendor,
        types: Array.from(vendors[vendor])
      }));

      res.json(vendorList);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch vendor list' });
    }
  });

  // Modified Route: Get Filtered Games List by Vendor and Type
  server.get('/api/casino/games/list', async (req, res) => {
    try {
      const { type, vendor } = req.query;

      // Fetch the game list from the external API
      const games = await fetchGameList();

      // Filter the games based on the query parameters (type and vendor)
      const filteredGames = games.filter(game => {
        return (
          (!type || game.type === type) &&
          (!vendor || game.vendor === vendor)
        );
      });

      // Return the filtered list of games
      res.json(filteredGames);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch game list' });
    }
  });


  // List of all vendors we want to fetch games for
  const targetVendors = [
    'quickspin',
    'wazdan'
  ];

  server.get('/api/casino/games/lists', async (req, res) => {
    try {
      // Fetch all games from the external API
      const allGames = await fetchGameList();

      // Filter games to only include our target vendors
      const filteredGames = allGames.filter(game =>
        [
          'betsoft'
        ].includes(game.vendor.toLowerCase())
      );

      // Return games with basic metadata
      const response = {
        filteredGames
      };

      res.json(response);
    } catch (error) {
      console.error('Error fetching game list:', error);
      res.status(500).json({
        message: 'Failed to fetch game list',
        error: error.message
      });
    }
  });
  server.get('/api/games/list', async (req, res) => {
    try {
      const { type, vendor } = req.query;

      // Fetch all games from the apigames table
      const result = await pg.query('SELECT * FROM apigames');

      // Get all games from the result
      const games = result.rows;

      // Filter the games based on query parameters (type and vendor)
      const filteredGames = games.filter(game => {
        return (
          (!type || game.type === type) &&
          (!vendor || game.vendor === vendor)
        );
      });

      // Group games by vendor
      const gamesByVendor = filteredGames.reduce((acc, game) => {
        if (!acc[game.vendor]) {
          acc[game.vendor] = [];
        }
        acc[game.vendor].push(game);
        return acc;
      }, {});

      // Return the games grouped by vendor
      res.json(gamesByVendor);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch game list' });
    }
  });


 
  const appId = "REMOVED_SECRET";      // Replace with your actual CCPayment App ID
  const appSecret = "REMOVED_SECRET";


  // Serve the specific file
  server.get('/ccpaymentf60749fa4cee4f9dfe786aba9d7be0da.txt', (req, res) => {
    console.log('Current directory:', __dirname);
    res.sendFile(path.join(__dirname, 'ccpaymentf60749fa4cee4f9dfe786aba9d7be0da.txt'));
  });

  server.post('/createDeposit', rejectDemoUser, (req, res) => {
    const { coinId, price, orderId, chain, generateCheckoutURL, returnUrl, userid } = req.body; // Expecting these in the request body

    // Validate request body
    if (!coinId || !price || !orderId || !chain || !userid) {
      return res.status(400).send('coinId, price, orderId, chain, and userid are required');
    }

    // Create request payload
    const args = JSON.stringify({
      coinId,
      price,
      orderId,
      chain,
      generateCheckoutURL,
      returnUrl
    });

    const timestamp = Math.floor(Date.now() / 1000);
    const signText = appId + timestamp + args;

    // Generate signature for request
    const sign = crypto
      .createHmac('sha256', appSecret)
      .update(signText)
      .digest('hex');

    const options = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'CCPayment-Client/1.0',
        'Appid': appId,
        'Sign': sign,
        'Timestamp': timestamp.toString(),
      },
    };

    const request = https.request('https://ccpayment.com/ccpayment/v2/createAppOrderDepositAddress', options, (response) => {
      let respData = '';

      // Collect response chunks
      response.on('data', (chunk) => {
        respData += chunk;
      });

      // Handle response when the request ends
      response.on('end', async () => {
        try {
          // Log raw response for debugging



          // Parse the response JSON safely
          const jsonResponse = JSON.parse(respData);

          // Check if the response indicates success
          if (jsonResponse.code === 10000) {
            const { address, amount, memo, checkoutUrl, confirmsNeeded } = jsonResponse.data;

            // Insert the deposit data into the ccdeposit table
            const query = `
            INSERT INTO ccdeposit 
            (userid, coinid, price, orderid, chain, deposit_address, amount, memo, checkout_url, confirms_needed, status, created_at, updated_at)
            VALUES 
            ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, 'Processing', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
          `;
            const values = [userid, coinId, price, orderId, chain, address, amount, memo, checkoutUrl, confirmsNeeded];

            await pg.query(query, values);
            console.log(jsonResponse.data);
            // Return success message to the client
            res.status(200).json({
              message: 'Deposit address created and saved successfully',
              data: jsonResponse.data,
            });
          } else {
            // Handle any API errors returned by the external service
            res.status(400).send(`Error: ${jsonResponse.msg}`);
          }
        } catch (err) {
          // Log the error and return a failure response
          console.error('Error parsing or processing response:', err);
          res.status(500).send('Error processing deposit response');
        }
      });
    });

    request.on('error', (e) => {
      // Handle request errors
      console.error(`Problem with request: ${e.message}`);
      res.status(500).send('Error creating deposit address');
    });

    // Write request body and end the request
    request.write(args);
    request.end();
  });


  // Get Order Information API
  server.post('/getOrder', (req, res) => {
    const { orderId } = req.body; // Expecting orderId in the request body

    if (!orderId) {
      return res.status(400).send('orderId is required');
    }

    const args = JSON.stringify({ "orderId": orderId });
    const timestamp = Math.floor(Date.now() / 1000);
    const signText = appId + timestamp + args;

    const sign = crypto
      .createHmac('sha256', appSecret)
      .update(signText)
      .digest('hex');

    const options = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'CCPayment-Client/1.0',
        'Appid': appId,
        'Sign': sign,
        'Timestamp': timestamp.toString(),
      },
    };

    const request = https.request('https://ccpayment.com/ccpayment/v2/getAppOrderInfo', options, (response) => {
      let respData = '';
      response.on('data', (chunk) => {
        respData += chunk;
      });

      response.on('end', () => {
        console.log('Get Order Info Response:', respData);
        res.send(respData); // Return the response to the client
      });
    });

    request.write(args);
    request.end();
  });

  // Function to fetch the list of coins
  function fetchCoinList(callback) {
    const path = "https://ccpayment.com/ccpayment/v2/getCoinList";
    const timestamp = Math.floor(Date.now() / 1000);
    const signText = appId + timestamp;

    const sign = crypto
      .createHmac("sha256", appSecret)
      .update(signText)
      .digest("hex");

    const options = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "User-Agent": "CCPayment-Client/1.0",
        "Appid": appId,
        "Sign": sign,
        "Timestamp": timestamp.toString(),
      },
      timeout: 10000,
    };

    let settled = false;
    const finish = (value) => {
      if (settled) return;
      settled = true;
      callback(value);
    };

    const req = https.request(path, options, (res) => {
      let respData = "";

      res.on("data", (chunk) => {
        respData += chunk;
      });

      res.on("end", () => {
        if (res.statusCode < 200 || res.statusCode >= 300) {
          console.error('CCPayment getCoinList non-2xx:', res.statusCode, respData.slice(0, 200));
          return finish(null);
        }
        try {
          finish(JSON.parse(respData));
        } catch (e) {
          console.error('CCPayment getCoinList JSON parse error:', e.message, respData.slice(0, 200));
          finish(null);
        }
      });
    });

    req.on('timeout', () => {
      console.error('CCPayment getCoinList request timed out');
      req.destroy(new Error('upstream timeout'));
    });

    req.on('error', (e) => {
      console.error('Error fetching coin list:', e);
      finish(null);
    });

    req.end();
  }

  // API endpoint to get coin details by symbol
  server.post('/getCoinDetails', (req, res) => {
    const { symbol } = req.body;

    if (!symbol) {
      return res.status(400).send('Symbol is required');
    }

    // Fetch the list of coins
    fetchCoinList((response) => {
      if (!response || response.code !== 10000) {
        return res.status(500).send('Error fetching coin list');
      }

      // Find the coin with the given symbol
      const coin = response.data.coins.find(coin => coin.symbol === symbol);

      if (!coin) {
        return res.status(404).send('Coin not found');
      }

      // Return the coin details
      res.json(coin);
    });
  });
  server.get('/getAllChains', (req, res) => {
    const path = 'https://ccpayment.com/ccpayment/v2/getChainList';
    const args = ''; // No parameters needed for the full list

    const timestamp = Math.floor(Date.now() / 1000);
    let signText = appId + timestamp;

    // Generate the signature
    const sign = crypto
      .createHmac('sha256', appSecret)
      .update(signText)
      .digest('hex');

    const options = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'CCPayment-Client/1.0',
        'Appid': appId,
        'Sign': sign,
        'Timestamp': timestamp.toString(),
      },
    };

    // Make the request to the external API
    const request = https.request(path, options, (response) => {
      let respData = '';

      response.on('data', (chunk) => {
        respData += chunk;
      });

      response.on('end', () => {
        console.log('Response:', respData);
        res.send(respData); // Send the response back to the client
      });
    });

    request.on('error', (error) => {
      console.error('Error:', error);
      res.status(500).send('Error fetching data');
    });

    request.write(args); // Send the request with no arguments
    request.end();
  });


  function verifySignature(content, signature, app_id, app_secret, timestamp) {
    const signText = `${app_id}${timestamp}${content}`;
    const serverSign = crypto.createHmac('sha256', app_secret).update(signText).digest('hex');

    console.log(serverSign);
    console.log(signature);
    return serverSign === signature;
  }


  server.use(express.text());
  // Webhook endpoint to handle deposit notifications

  function getOrderInfo(orderId, callback) {
    // Check if orderId is provided
    if (!orderId) {
      return callback('orderId is required', null);
    }

    const args = JSON.stringify({ "orderId": orderId });
    const timestamp = Math.floor(Date.now() / 1000);
    const signText = appId + timestamp + args;

    // Generate the sign using HMAC SHA-256
    const sign = crypto
      .createHmac('sha256', appSecret)
      .update(signText)
      .digest('hex');

    // Define request options
    const options = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'CCPayment-Client/1.0',
        'Appid': appId,
        'Sign': sign,
        'Timestamp': timestamp.toString(),
      },
    };

    // Create the request
    const request = https.request('https://ccpayment.com/ccpayment/v2/getAppOrderInfo', options, (response) => {
      let respData = '';

      // Collect data as it comes in
      response.on('data', (chunk) => {
        respData += chunk;
      });

      // When the response is complete
      response.on('end', () => {
        // If successful, pass the response back via the callback
        callback(respData);
      });
    });

    // Handle request error
    request.on('error', (err) => {
      callback(err, null);
    });

    // Write the orderId argument to the request body
    request.write(args);
    request.end();
  }


  server.post('/api/ccpaymentnotify', async (req, res) => {
    const timestamp = req.header('Timestamp');
    const sign = req.header('Sign');
    const content = Object.keys(req.body).length === 0 ? "" : JSON.stringify(req.body);

    console.log(`Received webhook - Type: ${req.body.type}, OrderId: ${req.body.msg?.orderId}, RecordId: ${req.body.msg?.recordId}`);

    if (!verifySignature(content, sign, appId, appSecret, timestamp)) {
      console.log('Signature verification failed');
      return res.status(401).send('Invalid signature');
    }

    console.log('Signature verified successfully');

    const { type, msg } = req.body;

    if (type === 'ApiDeposit') {
      const { recordId, orderId, coinId, coinSymbol, status } = msg;

      console.log(`Processing ApiDeposit - OrderId: ${orderId}, CoinSymbol: ${coinSymbol}, Status: ${status}`);

      try {
        console.log(`Starting transaction for OrderId: ${orderId}`);
        await pg.query('BEGIN');

        // Acquire an advisory lock based on orderId
        console.log(`Acquiring advisory lock for OrderId: ${orderId}`);
        await pg.query('SELECT pg_advisory_xact_lock(hashtext($1))', [orderId]);
        console.log(`Acquired advisory lock for OrderId: ${orderId}`);

        // Check if the orderId exists and its status
        console.log(`Querying ccdeposit for OrderId: ${orderId}`);
        const depositQuery = 'SELECT userid, status FROM ccdeposit WHERE orderid = $1 LIMIT 1';
        const depositResult = await pg.query(depositQuery, [orderId]);

        if (depositResult.rows.length === 0) {
          console.log(`No matching deposit found for OrderId: ${orderId}`);
          await pg.query('COMMIT');
          console.log(`Transaction committed for OrderId: ${orderId} - No deposit found`);
          return res.status(200).send('success');
        }

        const { userid, status: depositStatus } = depositResult.rows[0];
        console.log(`Found deposit - OrderId: ${orderId}, UserId: ${userid}, Status: ${depositStatus}`);

        // Skip processing if the deposit is in a final state
        if (['Success', 'Failed', 'Rejected'].includes(depositStatus)) {
          console.log(`OrderId: ${orderId} already processed with status: ${depositStatus}`);
          await pg.query('COMMIT');
          console.log(`Transaction committed for OrderId: ${orderId} - Skipped due to final status`);
          return res.status(200).send('success');
        }

        // Fetch order info
        console.log(`Fetching order info for OrderId: ${orderId}`);
        getOrderInfo(orderId, async (orderInfoRaw) => {
          try {
            if (!orderInfoRaw) {
              console.log(`No order info found for OrderId: ${orderId}`);
              await pg.query('COMMIT');
              console.log(`Transaction committed for OrderId: ${orderId} - No order info`);
              return res.status(200).send('success');
            }

            console.log(`Received order info for OrderId: ${orderId}`);
            const orderInfo = JSON.parse(orderInfoRaw);
            console.log(`Parsed order info - OrderId: ${orderId}, PaidList length: ${orderInfo.data.paidList.length}`);

            if (orderInfo.data.paidList.length === 0) {
              console.log(`No payments made for OrderId: ${orderId}`);
              await pg.query('COMMIT');
              console.log(`Transaction committed for OrderId: ${orderId} - No payments`);
              return res.status(200).send('success');
            }

            // Process each payment in the paidList
            for (const payment of orderInfo.data.paidList) {
              console.log(`Processing payment for OrderId: ${orderId} - PaymentStatus: ${payment.status}, Amount: ${payment.amount}`);

              if (payment.status === 'Success') {
                const amount = parseFloat(payment.amount);
                const coinSymbolLower = coinSymbol.toLowerCase();
                console.log(`Updating credits for UserId: ${userid}, Coin: ${coinSymbolLower}, Amount: ${amount}`);

                // Update user's credits
                const updateQuery = `UPDATE credits SET ${coinSymbolLower} = ${coinSymbolLower} + $1 WHERE uid = $2::bigint`;
                await pg.query(updateQuery, [amount, userid]);
                console.log(`Successfully updated ${coinSymbolLower} for UserId: ${userid} by amount: ${amount}`);

                // Update deposit status to 'Success'
                const updateDepositQuery = 'UPDATE ccdeposit SET status = $1 WHERE orderid = $2';
                await pg.query(updateDepositQuery, ['Success', orderId]);
                console.log(`Updated ccdeposit status to Success for OrderId: ${orderId}`);
              } else if (payment.status === 'Processing') {
                console.log(`Payment is Processing for OrderId: ${orderId}`);
                const updateDepositQuery = 'UPDATE ccdeposit SET status = $1 WHERE orderid = $2';
                await pg.query(updateDepositQuery, ['Processing', orderId]);
                console.log(`Updated ccdeposit status to Processing for OrderId: ${orderId}`);
              } else if (payment.status === 'Failed') {
                console.log(`Payment Failed for OrderId: ${orderId}`);
                const updateDepositQuery = 'UPDATE ccdeposit SET status = $1 WHERE orderid = $2';
                await pg.query(updateDepositQuery, ['Failed', orderId]);
                console.log(`Updated ccdeposit status to Failed for OrderId: ${orderId}`);
              } else {
                console.log(`Payment status ${payment.status} treated as Rejected for OrderId: ${orderId}`);
                const updateDepositQuery = 'UPDATE ccdeposit SET status = $1 WHERE orderid = $2';
                await pg.query(updateDepositQuery, ['Rejected', orderId]);
                console.log(`Updated ccdeposit status to Rejected for OrderId: ${orderId}`);
              }
            }

            await pg.query('COMMIT');
            console.log(`Transaction committed for OrderId: ${orderId} - Processing complete`);
            res.status(200).send('success');
          } catch (err) {
            await pg.query('ROLLBACK');
            console.error(`Error processing order info for OrderId: ${orderId}:`, err);
            res.status(500).send('Internal server error');
          }
        });
      } catch (err) {
        await pg.query('ROLLBACK');
        console.error(`Error processing webhook for OrderId: ${orderId}:`, err);
        res.status(500).send('Internal server error');
      }
    } else if (type === 'ActivateWebhookURL') {
      console.log('Received ActivateWebhookURL request');
      res.json({ msg: "success" });
    } else {
      console.log(`Unknown webhook type: ${type}`);
      res.status(200).send('success');
    }
  });
  server.post('/user/change-password', async (req, res) => {
    try {
      const { uid, oldPassword, newPassword } = req.body;

      // Validate request body
      if (!uid || !oldPassword || !newPassword) {
        return res.status(400).json({ success: false, message: 'Missing required fields' });
      }

      // Defense in depth (fail-open): if the caller supplies a valid session
      // token, it must belong to the uid being changed — this stops a
      // token-bearing client from changing someone else's password. No/invalid
      // token falls through to the current-password check below, so this never
      // breaks callers that don't send a token.
      try {
        const auth = req.headers.authorization || '';
        const tok = auth.startsWith('Bearer ') ? auth.slice(7).trim()
                  : (req.headers.token || req.body.token || null);
        if (tok) {
          const tokUid = await new Promise((resolve) =>
            Token.getID(tok, (id) => resolve(id || null)));
          if (tokUid && String(tokUid) !== String(uid)) {
            return res.status(403).json({ success: false, message: 'Token does not match account' });
          }
        }
      } catch (e) {
        console.warn('[change-password] optional token check skipped:', e && e.message);
      }

      // Get user from database
      const userResult = await pg.query('SELECT * FROM users WHERE id = $1', [uid]);

      if (userResult.rows.length === 0) {
        return res.status(404).json({ success: false, message: 'User not found' });
      }

      const user = userResult.rows[0];

      // Verify old password
      const isPasswordValid = await bcrypt.compare(oldPassword, user.password);

      if (!isPasswordValid) {
        return res.status(401).json({ success: false, message: 'Current password is incorrect' });
      }

      // Hash new password
      const hashedPassword = await bcrypt.hash(newPassword, 10);

      // Update both password fields in the database
      await pg.query(
        'UPDATE users SET password = $1, password2 = $2 WHERE id = $3',
        [hashedPassword, newPassword, uid]
      );

      return res.status(200).json({ success: true, message: 'Password updated successfully' });
    } catch (error) {
      console.error('Error changing password:', error);
      return res.status(500).json({ success: false, message: 'Internal server error' });
    }
  });

  server.get("/", function (req, res, next) {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    res.sendStatus(403);
  });

  //Get the Hour
  server.get("/hour", function (req, res) {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    let hour = new Date().getHours();
    res.json({ hour });

  });

  const OPERATOR_CODE = 'I201';
  const SECRET_KEY = 'REMOVED_SECRET';
  const BASE_URL = 'https://staging.gsimw.com/api/operators';
  server.get('/fetch-products', async (req, res) => {
    const currentTimestampInt64 = BigInt(Date.now()) * 1000000n;
    const requestTime = Math.floor(Date.now() / 1000);;
    const productListSign = md5(`${requestTime}${SECRET_KEY}productlist${OPERATOR_CODE}`);
    try {
      const productResponse = await axios.get(`${BASE_URL}/available-products`, {
        params: {
          operator_code: OPERATOR_CODE,
          sign: productListSign,
          request_time: requestTime,
        },
      });

      res.json(productResponse.data);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Internal server error' });
    }
  });
  server.get('/fetch-games', async (req, res) => {
    const { providerName, gameType } = req.query;
    if (!providerName || !gameType) {
      return res.status(400).json({ error: 'providerName and gameType are required' });
    }
    const currentTimestampInt64 = BigInt(Date.now()) * 1000000n;
    const requestTime = Math.floor(Date.now() / 1000);;

    const productListSign = md5(`${requestTime}${SECRET_KEY}productlist${OPERATOR_CODE}`);

    try {

      const productResponse = await axios.get(`${BASE_URL}/available-products`, {
        params: {
          operator_code: OPERATOR_CODE,
          sign: productListSign,
          request_time: requestTime,
        },
      });

      const products = productResponse.data;
      const filteredProducts = products.filter(product => product.provider === providerName);
      console.log(filteredProducts);
      if (filteredProducts.length === 0) {
        return res.status(404).json({ error: 'No products found for the given provider' });
      }

      const gameResponses = await Promise.all(filteredProducts.map(async (product) => {
        const gameListSign = md5(`${requestTime}${SECRET_KEY}gamelist${OPERATOR_CODE}`);
        console.log(product.product_code);
        console.log(OPERATOR_CODE);
        console.log(gameType);
        console.log(sign);
        console.log(requestTime);
        const gameResponse = await axios.get(`${BASE_URL}/provider-games`, {
          params: {
            product_code: product.product_code,
            operator_code: OPERATOR_CODE,
            sign: gameListSign,
            request_time: requestTime,
            game_type: gameType,
          },
        });
        return gameResponse.data;
      }));
      console.log(gameResponses);
      res.json(gameResponses);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  server.post('/launch-game', async (req, res) => {
    const { memberAccount, gameType, productCode, gameCode } = req.body;

    if (!memberAccount || !gameType || !productCode) {
      return res.status(400).json({ error: 'memberAccount, gameType, and productCode are required' });
    }

    try {

      const userQuery = 'SELECT password, name FROM users WHERE id = $1';
      const userResult = await pg.query(userQuery, [memberAccount]);

      if (userResult.rows.length === 0) {
        return res.status(404).json({ error: 'User not found' });
      }

      const user = userResult.rows[0];
      const password = user.password;
      const nickname = user.name;


      const requestTime = Math.floor(Date.now() / 1000);;
      const launchGameSign = md5(`${requestTime}${SECRET_KEY}launchgame${OPERATOR_CODE}`);

      const ip = requestIp.getClientIp(req) || '127.0.0.1';
      console.log({
        operator_code: OPERATOR_CODE,
        member_account: memberAccount,
        password: password,
        currency: 'USD',
        game_code: gameCode,
        product_code: productCode,
        game_type: gameType,
        language_code: 0,
        ip: ip,
        platform: 'web',
        sign: launchGameSign,
        request_time: requestTime,
        nickname: nickname,
      });
      const launchGameResponse = await axios.post(`${BASE_URL}/launch-game`, {
        operator_code: OPERATOR_CODE,
        member_account: memberAccount,
        password: password,
        currency: 'USD',
        game_code: gameCode,
        product_code: productCode,
        game_type: gameType,
        language_code: 0,
        ip: ip,
        platform: 'web',
        sign: launchGameSign,
        request_time: requestTime,
        nickname: nickname,
        operator_lobby_url: "http://localhost:3000"
      });
      res.json(launchGameResponse.data);
    } catch (error) {
      console.error('Error launching game:', error.response ? error.response.data : error.message);
      res.status(500).json({ error: error.message.toString() });
    }
  });
  const RESPONSE_CODES = {
    SUCCESS: 0,
    FAILED: 16,
    API_ERROR: 19,
    INTERNAL_SERVER_ERROR: 999,
    MEMBER_NOT_EXISTS: 1000,
    INSUFFICIENT_BALANCE: 1001,
    INCORRECT_AGENT_KEY: 1002,
    DUPLICATE_TRANSACTION: 1003,
    INVALID_SIGN: 1004,
    NO_GET_GAME_LIST: 1005,
    BET_NOT_EXIST: 1006,
    PRODUCT_UNDER_MAINTENANCE: 2000
  };

  const conversionCurrencies = ['IDR2', 'KRW2', 'MMK2', 'VND2', 'LAK2', 'KHR2'];
  const validCurrencies = [
    'CNY', 'USD', 'KRW', 'MYR', 'SGD', 'JPY', 'THB', 'IDR', 'VND', 'AUD', 'GBP', 'CHF', 'MXN', 'CAD', 'RUB', 'INR', 'RON',
    'DKK', 'NOK', 'COP', 'MMK', 'PLN', 'HRK', 'CZK', 'HUF', 'ZAR', 'SEK', 'NZD', 'TRY', 'BND', 'KHR', 'USDT', 'BDT', 'EUR',
    'BRL', 'PHP', 'TND', 'TWD', 'UAH', 'PKR', 'HKD', 'MAD', 'EGP', 'ZMW', 'NPR', 'KSH', 'AED', 'LAK', 'NGN', 'KES', 'UGX',
    'SAR', 'AZN', 'BGN', 'ARS', 'AMD', 'NTD', 'CLP', 'NGN', 'NPR', 'LKR', 'VES', 'PEN', 'MNT', 'IDR2', 'KRW2', 'MMK2',
    'VND2', 'LAK2', 'KHR2'
  ];
  server.post('/api/seamless/balance', async (req, res) => {
    const { member_account, operator_code, product_code, currency, sign, request_time } = req.body;

    if (!member_account || !operator_code || !product_code || !currency || !sign || !request_time) {
      return res.status(400).json({ code: RESPONSE_CODES.API_ERROR, message: 'Invalid request parameters' });
    }


    const computedSign = md5(operator_code + request_time + 'getbalance' + SECRET_KEY);

    // Validate the sign
    if (computedSign !== sign) {
      return res.status(400).json({ code: RESPONSE_CODES.INVALID_SIGN, message: 'Invalid sign' });
    }
    try {
      const productUnderMaintenance = false;
      if (productUnderMaintenance) {
        return res.status(400).json({ code: RESPONSE_CODES.PRODUCT_UNDER_MAINTENANCE, message: 'Product under maintenance' });
      }

      const result = await pg.query('SELECT usdt FROM credits WHERE uid = $1', [member_account]);

      if (result.rows.length === 0) {
        return res.status(400).json({ code: RESPONSE_CODES.MEMBER_NOT_EXISTS, message: 'Member not exists' });
      }

      let balance = parseFloat(result.rows[0].usdt);

      const conversionCurrencies = ['IDR2', 'KRW2', 'MMK2', 'VND2', 'LAK2', 'KHR2'];
      if (conversionCurrencies.includes(currency)) {
        balance /= 1000;
      }
      balance = Math.round(balance * 10000) / 10000;
      return res.json({ code: RESPONSE_CODES.SUCCESS, message: 'Success', balance });
    } catch (err) {
      console.error('Database query error', err);
      return res.status(500).json({ code: RESPONSE_CODES.INTERNAL_SERVER_ERROR, message: 'Internal server error' });
    }
  });
  function validateSign({ operator_code, request_time, action, sign }) {
    const computedSign = md5(operator_code + request_time + action + SECRET_KEY);
    return computedSign === sign;
  }

  async function getPlayerBalance(member_account) {
    const result = await pool.query('SELECT usdt FROM credits WHERE uid = $1', [member_account]);
    return result.rows.length ? parseFloat(result.rows[0].usdt) : null;
  }

  async function updatePlayerBalance(member_account, new_balance) {
    await pool.query('UPDATE credits SET usdt = $1 WHERE uid = $2', [new_balance, member_account]);
  }

  // Replay / duplicate protection for seamless-wallet transactions.
  //
  // Previously this always returned false, so the same provider transaction id
  // could be replayed indefinitely and credit the player every time (money
  // printing). We now reserve each transaction id exactly once in a dedicated
  // table: the first time an id is seen the INSERT succeeds (rowCount 1) and we
  // return false = "not a duplicate, process it"; any later replay of the same
  // id conflicts, inserts nothing (rowCount 0) and we return true = "duplicate,
  // reject with DUPLICATE_TRANSACTION" — which is exactly what the callers
  // already do.
  //
  // Safety rails so this can never wrongly block a real transaction:
  //   * fail-OPEN — any table/query error is logged and we return false.
  //   * kill switch — set env SEAMLESS_DEDUP=false to restore the old no-op.
  let _seamlessDedupReady = false;
  const ensureSeamlessDedupTable = async () => {
    if (_seamlessDedupReady) return;
    // Use the shared `pg` client (the app-wide, always-defined DB client) rather
    // than `pool`, which is not imported into this file.
    await pg.query(`CREATE TABLE IF NOT EXISTS seamless_processed_tx (
      transaction_id text PRIMARY KEY,
      processed_at   timestamptz NOT NULL DEFAULT now()
    )`);
    _seamlessDedupReady = true;
  };
  const checkDuplicateTransaction = async (transaction_id) => {
    if (String(process.env.SEAMLESS_DEDUP || 'true').toLowerCase() === 'false') return false;
    if (transaction_id === undefined || transaction_id === null || transaction_id === '') return false;
    try {
      await ensureSeamlessDedupTable();
      const r = await pg.query(
        `INSERT INTO seamless_processed_tx (transaction_id) VALUES ($1)
           ON CONFLICT (transaction_id) DO NOTHING`,
        [String(transaction_id)]
      );
      return r.rowCount === 0; // 0 rows inserted => id already existed => duplicate
    } catch (e) {
      // Never let an infra hiccup block a legitimate transaction.
      console.error('[seamless] dedup check failed (fail-open, allowing tx):', e && e.message);
      return false;
    }
  };

  const validateCurrency = (currency) => {
    return validCurrencies.includes(currency);
  };
  server.post('/api/seamless/withdraw', async (req, res) => {
    const { member_account, operator_code, product_code, currency, transactions, sign, request_time } = req.body;

    if (!validateSign({ operator_code, request_time, action: 'withdraw', sign })) {
      return res.status(400).json({ code: RESPONSE_CODES.INVALID_SIGN, message: 'Invalid sign' });
    }

    if (!validateCurrency(currency)) {
      return res.status(400).json({ code: RESPONSE_CODES.INCORRECT_AGENT_KEY, message: 'Invalid currency' });
    }

    try {
      let before_balance = await getPlayerBalance(member_account);

      if (before_balance === null) {
        return res.status(400).json({ code: RESPONSE_CODES.MEMBER_NOT_EXISTS, message: 'Member not exists' });
      }

      let balance = before_balance;

      for (const transaction of transactions) {
        if (await checkDuplicateTransaction(transaction.id)) {
          return res.status(400).json({ code: RESPONSE_CODES.DUPLICATE_TRANSACTION, message: 'Duplicate transaction' });
        }

        if (parseFloat(transaction.amount) > balance) {
          return res.status(400).json({ code: RESPONSE_CODES.INSUFFICIENT_BALANCE, message: 'Insufficient balance' });
        }

        balance -= parseFloat(transaction.amount); // Deduct the amount
      }

      if (conversionCurrencies.includes(currency)) {
        balance /= 1000;
      }
      balance = Math.round(balance * 10000) / 10000;

      await updatePlayerBalance(member_account, balance);

      return res.json({ code: RESPONSE_CODES.SUCCESS, message: '', before_balance, balance });
    } catch (err) {
      console.error('Database query error', err);
      return res.status(500).json({ code: RESPONSE_CODES.INTERNAL_SERVER_ERROR, message: 'Internal server error' });
    }
  });

  server.post('/api/seamless/deposit', async (req, res) => {
    const { member_account, operator_code, product_code, currency, transactions, sign, request_time } = req.body;

    if (!validateSign({ operator_code, request_time, action: 'deposit', sign })) {
      return res.status(400).json({ code: RESPONSE_CODES.INVALID_SIGN, message: 'Invalid sign' });
    }

    if (!validateCurrency(currency)) {
      return res.status(400).json({ code: RESPONSE_CODES.INCORRECT_AGENT_KEY, message: 'Invalid currency' });
    }

    try {
      let before_balance = await getPlayerBalance(member_account);

      if (before_balance === null) {
        return res.status(400).json({ code: RESPONSE_CODES.MEMBER_NOT_EXISTS, message: 'Member not exists' });
      }

      let balance = before_balance;

      for (const transaction of transactions) {
        if (await checkDuplicateTransaction(transaction.id)) {
          return res.status(400).json({ code: RESPONSE_CODES.DUPLICATE_TRANSACTION, message: 'Duplicate transaction' });
        }

        balance += parseFloat(transaction.amount);
      }

      if (conversionCurrencies.includes(currency)) {
        balance /= 1000;
      }
      balance = Math.round(balance * 10000) / 10000;

      await updatePlayerBalance(member_account, balance);

      return res.json({ code: RESPONSE_CODES.SUCCESS, message: '', before_balance, balance });
    } catch (err) {
      console.error('Database query error', err);
      return res.status(500).json({ code: RESPONSE_CODES.INTERNAL_SERVER_ERROR, message: 'Internal server error' });
    }
  });

  server.post('/api/seamless/transfer', async (req, res) => {
    const { member_account, operator_code, product_code, currency, transactions, sign, request_time } = req.body;

    if (!validateSign({ operator_code, request_time, action: 'transfer', sign })) {
      return res.status(400).json({ code: RESPONSE_CODES.INVALID_SIGN, message: 'Invalid sign' });
    }

    if (!validateCurrency(currency)) {
      return res.status(400).json({ code: RESPONSE_CODES.INCORRECT_AGENT_KEY, message: 'Invalid currency' });
    }

    try {
      let before_balance = await getPlayerBalance(member_account);

      if (before_balance === null) {
        return res.status(400).json({ code: RESPONSE_CODES.MEMBER_NOT_EXISTS, message: 'Member not exists' });
      }

      let balance = before_balance;

      for (const transaction of transactions) {
        if (await checkDuplicateTransaction(transaction.id)) {
          return res.status(400).json({ code: RESPONSE_CODES.DUPLICATE_TRANSACTION, message: 'Duplicate transaction' });
        }

        if (parseFloat(transaction.amount) + balance < 0) {
          return res.status(400).json({ code: RESPONSE_CODES.INSUFFICIENT_BALANCE, message: 'Insufficient balance' });
        }

        balance += parseFloat(transaction.amount);
      }

      if (conversionCurrencies.includes(currency)) {
        balance /= 1000;
      }
      balance = Math.round(balance * 10000) / 10000;

      await updatePlayerBalance(member_account, balance);

      return res.json({ code: RESPONSE_CODES.SUCCESS, message: '', before_balance, balance });
    } catch (err) {
      console.error('Database query error', err);
      return res.status(500).json({ code: RESPONSE_CODES.INTERNAL_SERVER_ERROR, message: 'Internal server error' });
    }
  });

  server.post('/api/seamless/rollback', async (req, res) => {
    const { member_account, operator_code, product_code, currency, transactions, sign, request_time } = req.body;

    if (!validateSign({ operator_code, request_time, action: 'rollback', sign })) {
      return res.status(400).json({ code: RESPONSE_CODES.INVALID_SIGN, message: 'Invalid sign' });
    }

    if (!validateCurrency(currency)) {
      return res.status(400).json({ code: RESPONSE_CODES.INCORRECT_AGENT_KEY, message: 'Invalid currency' });
    }

    try {
      let before_balance = await getPlayerBalance(member_account);

      if (before_balance === null) {
        return res.status(400).json({ code: RESPONSE_CODES.MEMBER_NOT_EXISTS, message: 'Member not exists' });
      }

      let balance = before_balance;

      for (const transaction of transactions) {
        if (await checkDuplicateTransaction(transaction.id)) {
          return res.status(400).json({ code: RESPONSE_CODES.DUPLICATE_TRANSACTION, message: 'Duplicate transaction' });
        }

        balance -= parseFloat(transaction.amount);
      }

      if (conversionCurrencies.includes(currency)) {
        balance /= 1000;
      }
      balance = Math.round(balance * 10000) / 10000;

      await updatePlayerBalance(member_account, balance);

      return res.json({ code: RESPONSE_CODES.SUCCESS, message: '', before_balance, balance });
    } catch (err) {
      console.error('Database query error', err);
      return res.status(500).json({ code: RESPONSE_CODES.INTERNAL_SERVER_ERROR, message: 'Internal server error' });
    }
  });

  server.post('/api/seamless/cancel', async (req, res) => {
    const { member_account, operator_code, product_code, currency, transactions, sign, request_time } = req.body;

    if (!validateSign({ operator_code, request_time, action: 'cancel', sign })) {
      return res.status(400).json({ code: RESPONSE_CODES.INVALID_SIGN, message: 'Invalid sign' });
    }

    if (!validateCurrency(currency)) {
      return res.status(400).json({ code: RESPONSE_CODES.INCORRECT_AGENT_KEY, message: 'Invalid currency' });
    }

    try {
      let before_balance = await getPlayerBalance(member_account);

      if (before_balance === null) {
        return res.status(400).json({ code: RESPONSE_CODES.MEMBER_NOT_EXISTS, message: 'Member not exists' });
      }

      let balance = before_balance;

      for (const transaction of transactions) {
        if (await checkDuplicateTransaction(transaction.id)) {
          return res.status(400).json({ code: RESPONSE_CODES.DUPLICATE_TRANSACTION, message: 'Duplicate transaction' });
        }

        balance += parseFloat(transaction.amount);
      }

      if (conversionCurrencies.includes(currency)) {
        balance /= 1000;
      }
      balance = Math.round(balance * 10000) / 10000;

      await updatePlayerBalance(member_account, balance);

      return res.json({ code: RESPONSE_CODES.SUCCESS, message: '', before_balance, balance });
    } catch (err) {
      console.error('Database query error', err);
      return res.status(500).json({ code: RESPONSE_CODES.INTERNAL_SERVER_ERROR, message: 'Internal server error' });
    }
  });

  server.post('/api/seamless/pushbet', async (req, res) => {
    const { operator_code, currency, transactions, sign, request_time } = req.body;

    if (!validateSign({ operator_code, request_time, action: 'pushbet', sign })) {
      return res.status(400).json({ code: RESPONSE_CODES.INVALID_SIGN, message: 'Invalid sign' });
    }

    if (!validateCurrency(currency)) {
      return res.status(400).json({ code: RESPONSE_CODES.INCORRECT_AGENT_KEY, message: 'Invalid currency' });
    }

    try {
      for (const transaction of transactions) {
        const { member_account, wager_code, wager_status, product_code, bet_amount, valid_bet_amount, prize_amount, tip_amount, game_type, settled_at } = transaction;

        // Implement logic to handle the pushbet transaction

        console.log({
          member_account,
          wager_code,
          wager_status,
          product_code,
          bet_amount,
          valid_bet_amount,
          prize_amount,
          tip_amount,
          game_type,
          settled_at,
        });
      }

      return res.json({ code: RESPONSE_CODES.SUCCESS, message: '' });
    } catch (err) {
      console.error('Processing error', err);
      return res.status(500).json({ code: RESPONSE_CODES.INTERNAL_SERVER_ERROR, message: 'Internal server error' });
    }
  });
  // server.post('/api/seamless/withdraw',async(req,res)=>{
  //   const { member_account, operator_code, product_code, currency, transactions, sign, request_time } = req.body;

  //   if (!validateSign({ operator_code, request_time, action: 'withdraw', sign })) {
  //     return res.status(400).json({ code: RESPONSE_CODES.INVALID_SIGN, message: 'Invalid sign' });
  //   }

  //   try {
  //     let before_balance = await getPlayerBalance(member_account);

  //     if (before_balance === null) {
  //       return res.status(400).json({ code: RESPONSE_CODES.MEMBER_NOT_EXISTS, message: 'Member not exists' });
  //     }

  //     let balance = before_balance;

  //     for (const transaction of transactions) {
  //       if (parseFloat(transaction.amount) > balance) {
  //         return res.status(400).json({ code: RESPONSE_CODES.INSUFFICIENT_BALANCE, message: 'Insufficient balance' });
  //       }


  //       balance += parseFloat(transaction.amount); 
  //     }

  //     await updatePlayerBalance(member_account, balance);



  //     return res.json({ code: RESPONSE_CODES.SUCCESS, message: '', before_balance, balance });
  //   } catch (err) {
  //     console.error('Database query error', err);
  //     return res.status(500).json({ code: RESPONSE_CODES.INTERNAL_SERVER_ERROR, message: 'Internal server error' });
  //   }
  // });

  // server.post('/api/seamless/deposit',async(req,res)=>{
  //   const { member_account, operator_code, product_code, currency, transactions, sign, request_time } = req.body;

  //   if (!validateSign({ operator_code, request_time, action: 'deposit',  sign })) {
  //     return res.status(400).json({ code: RESPONSE_CODES.INVALID_SIGN, message: 'Invalid sign' });
  //   }

  //   try {
  //     let before_balance = await getPlayerBalance(member_account);

  //     if (before_balance === null) {
  //       return res.status(400).json({ code: RESPONSE_CODES.MEMBER_NOT_EXISTS, message: 'Member not exists' });
  //     }

  //     let balance = before_balance;

  //     for (const transaction of transactions) {
  //       balance += parseFloat(transaction.amount);
  //     }

  //     await updatePlayerBalance(member_account, balance);

  //     return res.json({ code: RESPONSE_CODES.SUCCESS, message: '', before_balance, balance });
  //   } catch (err) {
  //     console.error('Database query error', err);
  //     return res.status(500).json({ code: RESPONSE_CODES.INTERNAL_SERVER_ERROR, message: 'Internal server error' });
  //   }

  // });
  // server.post('/api/seamless/transfer',async(req,res)=>{
  //   const { member_account, operator_code, product_code, currency, transactions, sign, request_time } = req.body;

  //   if (!validateSign({ operator_code, request_time, action: 'transfer',  sign })) {
  //     return res.status(400).json({ code: RESPONSE_CODES.INVALID_SIGN, message: 'Invalid sign' });
  //   }

  //   try {
  //     let before_balance = await getPlayerBalance(member_account);

  //     if (before_balance === null) {
  //       return res.status(400).json({ code: RESPONSE_CODES.MEMBER_NOT_EXISTS, message: 'Member not exists' });
  //     }

  //     let balance = before_balance;

  //     for (const transaction of transactions) {
  //       if (parseFloat(transaction.amount) + balance < 0) {
  //         return res.status(400).json({ code: RESPONSE_CODES.INSUFFICIENT_BALANCE, message: 'Insufficient balance' });
  //       }

  //       // Process the transaction
  //       balance += parseFloat(transaction.amount);
  //     }

  //     await updatePlayerBalance(member_account, balance);

  //     return res.json({ code: RESPONSE_CODES.SUCCESS, message: '', before_balance, balance });
  //   } catch (err) {
  //     console.error('Database query error', err);
  //     return res.status(500).json({ code: RESPONSE_CODES.INTERNAL_SERVER_ERROR, message: 'Internal server error' });
  //   }
  // });
  // server.post('/api/seamless/rollback',async(req,res)=>{
  //   const { member_account, operator_code, product_code, currency, transactions, sign, request_time } = req.body;

  //   if (!validateSign({ operator_code, request_time, action: 'rollback', sign })) {
  //     return res.status(400).json({ code: RESPONSE_CODES.INVALID_SIGN, message: 'Invalid sign' });
  //   }

  //   try {
  //     let before_balance = await getPlayerBalance(member_account);

  //     if (before_balance === null) {
  //       return res.status(400).json({ code: RESPONSE_CODES.MEMBER_NOT_EXISTS, message: 'Member not exists' });
  //     }

  //     let balance = before_balance;

  //     for (const transaction of transactions) {
  //       // Process the rollback transaction
  //       balance -= parseFloat(transaction.amount); // Rollback adds the amount back to the balance
  //     }

  //     await updatePlayerBalance(member_account, balance);

  //     return res.json({ code: RESPONSE_CODES.SUCCESS, message: '', before_balance, balance });
  //   } catch (err) {
  //     console.error('Database query error', err);
  //     return res.status(500).json({ code: RESPONSE_CODES.INTERNAL_SERVER_ERROR, message: 'Internal server error' });
  //   }
  // });
  // server.post('/api/seamless/cancel',async(req,res)=>{
  //   const { member_account, operator_code, product_code, currency, transactions, sign, request_time } = req.body;

  //   if (!validateSign({ operator_code, request_time, action: 'cancel',sign })) {
  //     return res.status(400).json({ code: RESPONSE_CODES.INVALID_SIGN, message: 'Invalid sign' });
  //   }

  //   try {
  //     let before_balance = await getPlayerBalance(member_account);

  //     if (before_balance === null) {
  //       return res.status(400).json({ code: RESPONSE_CODES.MEMBER_NOT_EXISTS, message: 'Member not exists' });
  //     }

  //     let balance = before_balance;

  //     for (const transaction of transactions) {
  //       // Process the cancel transaction
  //       balance += parseFloat(transaction.amount); // Cancel adds the amount back to the balance
  //     }

  //     await updatePlayerBalance(member_account, balance);

  //     return res.json({ code: RESPONSE_CODES.SUCCESS, message: '', before_balance, balance });
  //   } catch (err) {
  //     console.error('Database query error', err);
  //     return res.status(500).json({ code: RESPONSE_CODES.INTERNAL_SERVER_ERROR, message: 'Internal server error' });
  //   }
  // });
  // server.post('/api/seamless/pushbet',async(req,res)=>{
  //   const { operator_code, currency, transactions, sign, request_time } = req.body;

  //   if (!validateSign({ operator_code, request_time, action: 'pushbet',sign })) {
  //     return res.status(400).json({ code: RESPONSE_CODES.INVALID_SIGN, message: 'Invalid sign' });
  //   }

  //   try {
  //     for (const transaction of transactions) {
  //       const { member_account, wager_code, wager_status, product_code, bet_amount, valid_bet_amount, prize_amount, tip_amount, game_type, settled_at } = transaction;

  //       console.log({
  //         member_account,
  //         wager_code,
  //         wager_status,
  //         product_code,
  //         bet_amount,
  //         valid_bet_amount,
  //         prize_amount,
  //         tip_amount,
  //         game_type,
  //         settled_at,
  //       });
  //     }

  //     return res.json({ code: RESPONSE_CODES.SUCCESS, message: '' });
  //   } catch (err) {
  //     console.error('Processing error', err);
  //     return res.status(500).json({ code: RESPONSE_CODES.INTERNAL_SERVER_ERROR, message: 'Internal server error' });
  //   }
  // });
  server.get('/game-list', async (req, res) => {
    const providerCode = req.query.s || "EVOLUTION";
    try {
      console.log("Making request to external API with the following payload:");
      console.log({
        method: "game_list",
        agent_code: "Skyla_USD",
        agent_token: "REMOVED_SECRET",
        provider_code: providerCode
      });

      const response = await axios.post('https://api.nexusggreu.com', {
        method: "game_list",
        agent_code: "Skyla_USD",
        agent_token: "REMOVED_SECRET",
        provider_code: providerCode
      }, {
        headers: {
          'Content-Type': 'application/json',
        }
      });

      if (response.data.status === 1) {
        res.json({ games: response.data.games });
      } else {
        res.status(400).json({ error: response.data.msg });
      }
    } catch (error) {
      if (error.response) {
        // The request was made and the server responded with a status code
        // that falls out of the range of 2xx
        console.error("Error response from the API:");
        console.error("Status:", error.response.status);
        console.error("Data:", error.response.data);
        res.status(error.response.status).json({ error: error.response.data });
      } else if (error.request) {
        // The request was made but no response was received
        console.error("No response received from the API:");
        console.error(error.request);
        res.status(500).json({ error: "No response received from the API" });
      } else {
        // Something happened in setting up the request that triggered an Error
        console.error("Error in setting up the request:");
        console.error("Message:", error.message);
        res.status(500).json({ error: "Failed to fetch data: " + error.message });
      }
    }
  });

  server.get('/game-list-new', async (req, res) => {
    try {

      const gameLabels = req.query.lable ? req.query.lable.split(',') : [];
      if (gameLabels.length === 0) {
        return res.status(400).json({ error: "No game labels provided" });
      }

      console.log("Making request to external API with the following payload:");

      const response = await axios.post('http://asiaapi.net/API/', {
        hall: "937387",
        key: "myapp_games",
        cmd: "gamesList",
        cdnUrl: "",
        img: "game_img_2"
      }, {
        headers: {
          'Content-Type': 'application/json',
        }
      });

      if (response.data.status === "success") {
        const content = response.data.content;
        const gameList = content.gameList;

        let sortedGames = {};
        gameLabels.forEach(label => {
          sortedGames[label] = [];
        });


        gameList.forEach(game => {
          if (sortedGames.hasOwnProperty(game.label)) {
            sortedGames[game.label].push(game);
          }
        });

        res.json({ games: sortedGames });
      } else {
        res.status(400).json({ error: response.data.msg });
      }
    } catch (error) {
      if (error.response) {
        console.error("Error response from the API:");
        console.error("Status:", error.response.status);
        console.error("Data:", error.response.data);
        res.status(error.response.status).json({ error: error.response.data });
      } else if (error.request) {
        console.error("No response received from the API:");
        console.error(error.request);
        res.status(500).json({ error: "No response received from the API" });
      } else {
        console.error("Error in setting up the request:");
        console.error("Message:", error.message);
        res.status(500).json({ error: "Failed to fetch data: " + error.message });
      }
    }
  });

  server.post('/game_launch_new', async (req, res) => {
    const { user_code, game_code } = req.body;
    try {
      const response = await axios.post('http://asiaapi.net/API/openGame/', {
        cmd: "openGame",
        hall: "937387",
        domain: "http://localhost:3000",
        exitUrl: "http://localhost:3000",
        localhost: "http://localhost:3000",
        language: "en",
        key: "myapp_games",
        continent: "asia",
        login: user_code,
        gameId: game_code,
        cdnUrl: "https://example.com",
        demo: "0"
      }, {
        headers: {
          'Content-Type': 'application/json',
        }
      });

      res.status(response.status).json(response.data);
    } catch (error) {
      console.error("Failed to launch game: " + error.message);
      if (error.response) {
        res.status(error.response.status).json(error.response.data);
      } else {
        res.status(500).json({ msg: "Internal Server Error" });
      }
    }
  });

  //   server.get('/game-list', async (req, res) => {

  //     try {
  //         console.log("Making request to external API with the following payload:");
  //         console.log({
  //             method: "game_list",
  //             agent_code: "Skyla_USD",
  //             agent_token: "REMOVED_SECRET",
  //             provider_code: "EVOLUTION"
  //         });

  //         const response = await axios.post('https://api.nexusggreu.com', {
  //             method: "game_list",
  //             agent_code: "Skyla_USD",
  //             agent_token: "REMOVED_SECRET",
  //             provider_code: "EVOLUTION"
  //         }, {
  //             headers: {
  //                 'Content-Type': 'application/json',
  //             }
  //         });

  //         if (response.data.status === 1) {
  //             res.json({ games: response.data.games });
  //         } else {
  //             res.status(400).json({ error: response.data.msg });
  //         }
  //     } catch (error) {
  //         if (error.response) {
  //             // The request was made and the server responded with a status code
  //             // that falls out of the range of 2xx
  //             console.error("Error response from the API:");
  //             console.error("Status:", error.response.status);
  //             console.error("Data:", error.response.data);
  //             res.status(error.response.status).json({ error: error.response.data });
  //         } else if (error.request) {
  //             // The request was made but no response was received
  //             console.error("No response received from the API:");
  //             console.error(error.request);
  //             res.status(500).json({ error: "No response received from the API" });
  //         } else {
  //             // Something happened in setting up the request that triggered an Error
  //             console.error("Error in setting up the request:");
  //             console.error("Message:", error.message);
  //             res.status(500).json({ error: "Failed to fetch data: " + error.message });
  //         }
  //     }
  // });
  async function getUserBalance(userCode) {
    try {
      const result = await pg.query('SELECT usdt FROM credits WHERE uid = $1', [userCode]);
      return result.rows.length ? result.rows[0].usdt : 0;
    } catch (err) {
      console.error('Error fetching user balance', err);
      throw err;
    }
  }

  async function updateUserBalance(userCode, newBalance) {
    // This is a placeholder function, replace with actual database logic
    try {
      const result = await pg.query('UPDATE credits SET usdt = $1 WHERE uid = $2 RETURNING *', [newBalance, userCode]);
      return result.rows.length > 0;
    } catch (err) {
      console.error('Error updating user balance', err);
      return false;
    }
  }

  async function getBalanceInfo(req, res) {
    const { user_code } = req.body;

    try {
      const userBalance = await getUserBalance(user_code);
      res.json({
        status: 1,
        msg: "SUCCESS",
        user_balance: userBalance
      });
    } catch (error) {
      res.json({
        status: 0,
        user_balance: 0,
        msg: "INTERNAL_ERROR"
      });
    }
  }



  // async function setTransaction(req, res) {
  //   const { user_code, game_type } = req.body;
  //   let { bet_money, win_money } = req.body;

  //   // If game_type is "live" or "slot", extract the values from the respective block
  //   if (game_type === "live" && req.body.live) {
  //     bet_money = req.body.live.bet_money;
  //     win_money = req.body.live.win_money;
  //   } else if (game_type === "slot" && req.body.slot) {
  //     bet_money = req.body.slot.bet_money;
  //     win_money = req.body.slot.win_money;
  //   }

  //   const userBalance = await getUserBalance(user_code);

  //   // Check if user has enough funds for the transaction
  //   if (userBalance < bet_money) {
  //     console.error(`User ${user_code} has insufficient funds for the transaction.`);
  //     return res.json({
  //       status: 0,
  //       msg: "INSUFFICIENT_USER_FUNDS"
  //     });
  //   }

  //   // Calculate new balance after the transaction
  //   const newBalance = userBalance - bet_money + win_money;

  //   // Update user balance in the database
  //   const updateResult = await updateUserBalance(user_code, newBalance);

  //   if (!updateResult) {
  //     console.error(`Failed to update balance for user ${user_code}.`);
  //     return res.json({
  //       status: 0,
  //       msg: "INTERNAL_ERROR"
  //     });
  //   }

  //   console.log(`Transaction successful for user ${user_code}. New balance: ${newBalance}. Bet: ${bet_money}. Win: ${win_money}. User balance before transaction: ${userBalance}`);

  //   // Return updated user balance
  //   res.json({
  //     status: 1,
  //     user_balance: newBalance
  //   });
  // }

  async function setTransaction(req, res) {
    const { user_code, game_type, method, user_balance } = req.body;
    let bet_money, win_money, provider_code, game_code, type, txn_id, txn_type;

    if (game_type === "live" && req.body.live) {
      ({ bet_money, win_money, provider_code, game_code, type, txn_id, txn_type } = req.body.live);
    } else if (game_type === "slot" && req.body.slot) {
      ({ bet_money, win_money, provider_code, game_code, type, txn_id, txn_type } = req.body.slot);
    } else {
      return res.json({ status: 0, msg: "INVALID_GAME_TYPE" });
    }

    try {
      const userBalance = await getUserBalance(user_code);

      if (userBalance < bet_money) {
        console.error(`User ${user_code} has insufficient funds for the transaction.`);
        return res.json({
          status: 0,
          msg: "INSUFFICIENT_USER_FUNDS"
        });
      }

      const newBalance = userBalance - bet_money + win_money;
      await updateUserBalance(user_code, newBalance);


      const transactionQuery = game_type === "live" ?
        `INSERT INTO transaction_live (method, user_code, user_balance, game_type, provider_code, game_code, type, bet_money, win_money, txn_id, txn_type)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)` :
        `INSERT INTO transaction_slot (method, user_code, user_balance, game_type, provider_code, game_code, type, bet_money, win_money, txn_id, txn_type)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`;

      await pg.query(transactionQuery, [method, user_code, newBalance, game_type, provider_code, game_code, type, bet_money, win_money, txn_id, txn_type]);

      console.log(`Transaction successful for user ${user_code}. New balance: ${newBalance}. Bet: ${bet_money}. Win: ${win_money}. User balance before transaction: ${userBalance}`);

      res.json({
        status: 1,
        user_balance: newBalance,
        msg: "SUCCESS",
      });
    } catch (error) {
      console.error('Error processing transaction', error);
      res.json({
        status: 0,
        user_balance: 0,
        msg: "SITE_ERROR_1",
      });
    }
  }


  async function getUserBalanceNew(userCode) {
    try {
      const result = await pg.query('SELECT usdt FROM credits WHERE uid = $1', [userCode]);
      if (result.rows.length > 0) {
        const balance = parseFloat(result.rows[0].usdt).toFixed(2);
        return balance;
      } else {
        return "0.00";
      }
    } catch (err) {
      console.error('Error fetching user balance', err);
      throw new Error('Internal Server Error');
    }
  }
  async function updateUserBalanceNew(userCode, newBalance) {
    try {
      const result = await pg.query('UPDATE credits SET usdt = $1 WHERE uid = $2', [newBalance, userCode]);
      return result.rowCount > 0;
    } catch (err) {
      console.error('Error updating user balance', err);
      return false;
    }
  }

  async function getGameName(gameId) {
    try {
      const response = await axios.post('http://asiaapi.net/API/', {
        hall: "937387",
        key: "myapp_games",
        cmd: "gamesList",
        cdnUrl: "",
        img: "game_img_2"
      }, {
        headers: {
          'Content-Type': 'application/json',
        }
      });

      const gameList = response.data.content.gameList;
      const game = gameList.find(g => g.id === gameId.toString());
      return game ? game.name : gameId;
    } catch (err) {
      console.error('Error fetching game name', err);
      throw new Error('Failed to fetch game name');
    }
  }
  server.post("/processRequest", async (req, res) => {
    const { cmd, login, bet, win, sessionId, tradeId, action, betInfo, matrix, date, WinLines, gameId } = req.body;

    if (!cmd || !login) {
      return res.status(400).json({
        status: "fail",
        error: "Invalid request parameters"
      });
    }

    try {
      if (cmd === "getBalance") {
        const userBalance = await getUserBalanceNew(login);
        return res.json({
          status: "success",
          error: "",
          login: login,
          balance: userBalance,
          currency: "USD"
        });
      } else if (cmd === "writeBet") {
        if (!bet || !win) {
          return res.status(400).json({
            status: "fail",
            error: "Invalid request parameters"
          });
        }

        const userBalance = await getUserBalanceNew(login);

        if (userBalance < bet) {
          return res.status(400).json({
            status: "fail",
            error: "fail_balance"
          });
        }

        const newBalance = parseFloat(userBalance) - parseFloat(bet) + parseFloat(win);

        const updateResult = await updateUserBalanceNew(login, newBalance.toFixed(2));
        if (!updateResult) {
          return res.status(500).json({
            status: "fail",
            error: "INTERNAL_ERROR"
          });
        }

        const gameName = await getGameName(gameId);


        await pg.query(
          `INSERT INTO transactions (
          login, session_id, trade_id, bet, win, balance_before, balance_after, action, game_name, bet_info, matrix, date, win_lines
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)`,
          [login, sessionId, tradeId, bet, win, userBalance, newBalance.toFixed(2), action, gameName, betInfo, matrix, date, WinLines]
        );

        return res.json({
          status: "success",
          error: "",
          login: login,
          balance: newBalance.toFixed(2),
          currency: "USD"
        });
      } else {
        return res.status(400).json({
          status: "fail",
          error: "Unknown command"
        });
      }
    } catch (err) {
      return res.status(500).json({
        status: "fail",
        error: err.message
      });
    }
  });

  // server.post("/writeBet", async (req, res) => {
  //   const { cmd, login, bet, win, sessionId, tradeId, action, betInfo, matrix, date, WinLines, gameId } = req.body;

  //   if (cmd !== "writeBet" || !login || !bet || !win) {
  //     return res.status(400).json({
  //       status: "fail",
  //       error: "Invalid request parameters"
  //     });
  //   }

  //   try {
  //     const userBalance = await getUserBalanceNew(login);

  //     if (userBalance < bet) {
  //       return res.status(400).json({
  //         status: "fail",
  //         error: "fail_balance"
  //       });
  //     }

  //     const newBalance = parseFloat(userBalance) - parseFloat(bet) + parseFloat(win);

  //     const updateResult = await updateUserBalanceNew(login, newBalance.toFixed(2));
  //     if (!updateResult) {
  //       return res.status(500).json({
  //         status: "fail",
  //         error: "INTERNAL_ERROR"
  //       });
  //     }

  //     const gameName = await getGameName(gameId);
  //     if (!gameName) {
  //       return res.status(500).json({
  //         status: "fail",
  //         error: "Failed to fetch game name"
  //       });
  //     }

  //     await pg.query(
  //       `INSERT INTO transactions (
  //         login, session_id, trade_id, bet, win, balance_before, balance_after, action, game_name, bet_info, matrix, date, win_lines
  //       ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)`,
  //       [login, sessionId, tradeId, bet, win, userBalance, newBalance.toFixed(2), action, gameName, betInfo, matrix, date, WinLines]
  //     );

  //     res.json({
  //       status: "success",
  //       error: "",
  //       login: login,
  //       balance: newBalance.toFixed(2),
  //       currency: "USD"
  //     });
  //   } catch (err) {
  //     res.status(500).json({
  //       status: "fail",
  //       error: err.message
  //     });
  //   }
  // });
  // server.post("/getBalance", async (req, res) => {
  //   const { cmd, login } = req.body;
  //   if (cmd !== "getBalance" || !login) {
  //     return res.status(400).json({
  //       status: "fail",
  //       error: "Invalid request parameters"
  //     });
  //   }
  //   try {
  //     const userBalance = await getUserBalanceNew(login);
  //     res.json({
  //       status: "success",
  //       error: "",
  //       login: login,
  //       balance: userBalance,
  //       currency: "USD"
  //     });
  //   } catch (err) {
  //     res.status(500).json({
  //       status: "fail",
  //       error: "Internal Server Error"
  //     });
  //   }
  // });

  server.post("/gold_api", async (req, res) => {
    const { method } = req.body;
    switch (method) {
      case "user_balance":
        await getBalanceInfo(req, res);
        break;
      case "transaction":
        await setTransaction(req, res);
        break;
      default:
        res.json({ status: 0, msg: "INVALID_METHOD" });
    }
  });

  server.post('/game_launch', async (req, res) => {
    const { user_code, provider_code, game_code } = req.body;

    try {
      const response = await axios.post('https://api.nexusggreu.com', {
        method: "game_launch",
        agent_code: "Skyla_USD",
        agent_token: "REMOVED_SECRET",
        user_code: user_code || "",
        provider_code: provider_code || "EVOLUTION",
        game_code: game_code,
        lang: "en"
      }, {
        headers: {
          'Content-Type': 'application/json',
        }
      });

      res.status(response.status).json(response.data);
    } catch (error) {
      console.error("Failed to launch game: " + error.message);
      if (error.response) {
        res.status(error.response.status).json(error.response.data);
      } else {
        res.status(500).json({ msg: "Internal Server Error" });
      }
    }
  });

  //vault pro 

  // Helper function to calculate a date 30 days from now
  const getIncomeDate = () => {
    const incomeDate = new Date();
    incomeDate.setDate(incomeDate.getDate() + 30);
    return incomeDate;
  };

  // Transfer In API
  server.post('/transfer-in', guardPlayer, async (req, res) => {
    const { coin, amount } = req.body;
    const uid = req.playerUid; // from the authenticated token, never client-supplied

    if (amount <= 0) {
      return res.status(400).json({ error: 'Transfer amount must be greater than zero' });
    }

    try {
      console.log("Starting transfer-in transaction...");

      // Start the transaction
      await pg.query('BEGIN');

      // Check the current wallet balance
      console.time('walletQuery');
      const walletQuery = await pg.query(`SELECT ${safeCol(coin)} FROM credits WHERE uid = $1`, [uid]);
      console.timeEnd('walletQuery');

      if (walletQuery.rowCount === 0) {
        throw new Error('User wallet not found');
      }

      const walletBalance = walletQuery.rows[0][coin];

      if (walletBalance < amount) {
        throw new Error('Insufficient wallet balance');
      }

      // Deduct amount from wallet
      console.time('deductWallet');
      await pg.query(`UPDATE credits SET ${safeCol(coin)} = ${safeCol(coin)} - $1 WHERE uid = $2`, [amount, uid]);
      console.timeEnd('deductWallet');

      // Check if entry exists in vault
      console.time('vaultQuery');
      const vaultQuery = await pg.query(`SELECT "vaultBalance" FROM vault_pro WHERE userid = $1 AND coin = $2`, [uid, coin]);
      console.timeEnd('vaultQuery');

      if (vaultQuery.rowCount > 0) {
        // Update vault balance and updatedAt
        console.time('updateVault');
        await pg.query(
          `UPDATE vault_pro 
         SET "vaultBalance" = "vaultBalance" + $1, "updatedAt" = NOW() 
         WHERE userid = $2 AND coin = $3`,
          [amount, uid, coin]
        );
        console.timeEnd('updateVault');
      } else {
        // Insert new vault entry with incomeDate = current timestamp + 30 days
        console.time('insertVault');
        await pg.query(
          `INSERT INTO vault_pro (userid, "vaultBalance", coin, "createdAt", "updatedAt", "incomeDate") 
         VALUES ($1, $2, $3, NOW(), NOW(), $4)`,
          [uid, amount, coin, getIncomeDate()]
        );
        console.timeEnd('insertVault');
      }

      await pg.query('COMMIT');
      console.log("Transaction committed successfully.");
      res.json({ message: 'Amount transferred to vault successfully' });
    } catch (error) {
      console.error('Error in transaction:', error.message);
      await pg.query('ROLLBACK');
      res.status(500).json({ error: error.message });
    }
  });
  // Transfer Out API
  server.post('/transfer-out', guardPlayer, async (req, res) => {
    const { coin, amount } = req.body;
    const uid = req.playerUid; // from the authenticated token, never client-supplied

    if (amount <= 0) {
      return res.status(400).json({ error: 'Transfer amount must be greater than zero' });
    }

    try {
      console.log("Starting transfer-out transaction...");

      // Begin the transaction
      await pg.query('BEGIN');

      // Check vault balance
      const vaultQuery = await pg.query(`SELECT "vaultBalance" FROM vault_pro WHERE userid = $1 AND coin = $2`, [uid, coin]);
      if (vaultQuery.rowCount === 0) {
        throw new Error('No vault entry found for this coin');
      }

      const vaultBalance = vaultQuery.rows[0].vaultBalance;

      if (vaultBalance < amount) {
        throw new Error('Insufficient vault balance');
      }

      // Deduct amount from vault and update updatedAt
      await pg.query(
        `UPDATE vault_pro 
       SET "vaultBalance" = "vaultBalance" - $1, "updatedAt" = NOW() 
       WHERE userid = $2 AND coin = $3`,
        [amount, uid, coin]
      );

      // Add amount to wallet
      await pg.query(`UPDATE credits SET ${safeCol(coin)} = ${safeCol(coin)} + $1 WHERE uid = $2`, [amount, uid]);

      // Commit the transaction
      await pg.query('COMMIT');
      console.log("Transaction committed successfully.");
      res.json({ message: 'Amount transferred from vault successfully' });
    } catch (error) {
      console.error('Error in transaction:', error.message);

      // Rollback the transaction in case of an error
      await pg.query('ROLLBACK');
      res.status(500).json({ error: error.message });
    }
  });

  // Get Vault Data API
  server.post('/vault-data', async (req, res) => {
    const { uid, coin } = req.body;

    try {
      const vaultDataQuery = await pg.query(`
      SELECT vp."vaultBalance"
      FROM vault_pro vp
      INNER JOIN users u ON u.id = vp.userid
      WHERE vp.userid = $1 AND vp.coin = $2
    `, [uid, coin]);

      if (vaultDataQuery.rowCount === 0) {
        return res.status(200).json({ vaultBalance: 0 });
      }

      res.json(vaultDataQuery.rows[0]);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Fetch all vault_pro data with usernames for admin
  server.get('/admin/vault-data', guardAdmin('admin/vault-data'), async (req, res) => {
    try {
      const vaultDataQuery = await pg.query(`
      SELECT vp.userid, vp."vaultBalance", vp.coin, vp."createdAt", vp."updatedAt", vp."incomeDate", u.name
      FROM vault_pro vp
      INNER JOIN users u ON u.id = vp.userid
    `);

      if (vaultDataQuery.rowCount === 0) {
        return res.status(404).json({ message: 'No vault data found' });
      }

      res.json(vaultDataQuery.rows);
    } catch (error) {
      console.log(error);
      res.status(500).json({ error: 'Failed to fetch vault data' });
    }
  });

  // API to get referral code by UID
  server.get('/get-referral-code/:uid', async (req, res) => {
    const { uid } = req.params;

    try {
      // Fetch the referral code from the users table
      const userQuery = await pg.query('SELECT referalcode FROM users WHERE id = $1', [uid]);

      if (userQuery.rowCount === 0) {
        return res.status(404).json({ error: 'User not found' });
      }

      const { referalcode } = userQuery.rows[0];
      res.json({ referralCode: referalcode ?? "No Code" });
    } catch (error) {
      console.error('Error fetching referral code:', error.message);
      res.status(500).json({ error: 'Failed to fetch referral code' });
    }
  });
  server.put('/editProfile', async (req, res) => {  // PUT method for updating
    const { uid, username } = req.body;

    if (!username) {
      return res.status(400).json({ error: 'Username is required' });
    }

    try {
      // Check if the user exists based on uid
      const userExistsQuery = await pg.query('SELECT 1 FROM users WHERE id = $1', [uid]);

      if (userExistsQuery.rowCount === 0) {
        return res.status(404).json({ error: 'User not found' });
      }

      // Update the username in the users table based on uid
      await pg.query('UPDATE users SET name = $1 WHERE id = $2', [username, uid]);


      // Respond with a success message and the referral code if it exists
      res.json({ message: 'Username updated successfully' });
    } catch (error) {
      console.error('Error updating username', error.message);
      res.status(500).json({ error: 'Failed to update username' });
    }
  });

  // API to get referral code by UID
  server.get('/get-referral-link/:uid', async (req, res) => {
    const { uid } = req.params;

    try {
      // Fetch the referral code from the users table
      const userQuery = await pg.query('SELECT referral_link FROM users WHERE id = $1', [uid]);
      if (userQuery.rowCount === 0) {
        return res.status(404).json({ error: 'User not found' });
      }

      const referalLink = userQuery.rows[0]["referral_link"];
      res.json({ referralLink: referalLink ?? "No Link" });
    } catch (error) {
      console.error('Error fetching referral link:', error.message);
      res.status(500).json({ error: 'Failed to fetch referral link' });
    }
  });
  server.get('/verify-referral-code/:referralCode', async (req, res) => {
    const { referralCode } = req.params;

    if (!referralCode) {
      return res.status(400).json({ error: 'Referral code is required' });
    }

    try {
      // Check if the referral code exists in the users table
      const referralQuery = await pg.query('SELECT 1 FROM users WHERE referalcode = $1', [referralCode]);

      // Staff codes (agents, branches, sub branches) attach the player at
      // signup too. A locked branch code is reported as not valid.
      const codeStatus = referralQuery.rowCount > 0 ? 'none' : await registrationCodeStatus(referralCode);
      if (codeStatus === 'blocked') {
        return res.json({ valid: false, reason: 'This branch code is not accepting registrations right now.' });
      }

      if (referralQuery.rowCount > 0 || codeStatus === 'ok') {
        return res.json({ valid: true });  // Referral code is valid
      } else {
        return res.json({ valid: false });  // Referral code not found
      }
    } catch (error) {
      console.error('Error verifying referral code:', error.message);
      res.status(500).json({ error: 'Failed to verify referral code' });
    }
  });
  server.get('/api/members/:uid', async (req, res) => {
    const uid = req.params.uid;

    try {
      // Step 1: Fetch the username from the users table based on the uid
      const userResult = await pg.query('SELECT name FROM users WHERE id = $1', [uid]);

      // If no user is found with the given uid
      if (userResult.rows.length === 0) {
        return res.status(404).json({ message: 'User not found' });
      }

      const ownername = userResult.rows[0].name;

      // Step 2: Fetch the total count and member details from the team table
      const teamResult = await pg.query(
        'SELECT COUNT(*) AS total_members, ARRAY_AGG(membername) AS members FROM team WHERE ownername = $1',
        [ownername]
      );

      const totalMembers = teamResult.rows[0].total_members;
      const members = teamResult.rows[0].members;

      // Step 3: Fetch the total amount (commission) received from the rewards table for each member
      const rewardsResult = await pg.query(
        `SELECT membername, SUM(amount) AS total_amount
       FROM rewards
       WHERE ownername = $1
       AND membername = ANY($2)
       GROUP BY membername`,
        [ownername, members]
      );

      // Create a map to store the total commission per member
      const rewardsMap = rewardsResult.rows.reduce((acc, row) => {
        acc[row.membername] = row.total_amount;
        return acc;
      }, {});

      // Step 4: Return the total count, member details, and commission data
      const membersWithRewards = members.map(member => ({
        membername: member,
        total_commission: rewardsMap[member] || 0 // Default to 0 if no reward is found for the member
      }));

      return res.status(200).json({
        ownername,
        totalMembers,
        members: membersWithRewards,
      });

    } catch (err) {
      console.error('Error fetching members data', err);
      return res.status(500).json({ message: 'Internal Server Error' });
    }
  });

  // API route to get rewards based on uid and filter (today or all)
  server.get('/api/rewards/:uid', async (req, res) => {
    const uid = req.params.uid;
    const filter = req.query.filter; // 'today' or 'all'

    try {
      // Step 1: Fetch the username (ownername) from the users table based on the uid
      const userResult = await pg.query('SELECT name FROM users WHERE id = $1', [uid]);

      // If no user is found with the given uid
      if (userResult.rows.length === 0) {
        return res.status(404).json({ message: 'User not found' });
      }

      const ownername = userResult.rows[0].name;

      // Step 2: Prepare the base query to fetch rewards data
      let query = 'SELECT * FROM rewards WHERE ownername = $1';
      let params = [ownername];

      // Step 3: Modify the query based on the filter
      if (filter === 'today') {
        query += ' AND "createdAt"::date = CURRENT_DATE'; // Fetch only today's data
      }

      const rewardsResult = await pg.query(query, params);

      // Step 4: Calculate the total amount
      const totalAmountResult = await pg.query(
        'SELECT SUM(amount) AS total_amount FROM rewards WHERE ownername = $1' +
        (filter === 'today' ? ' AND "createdAt"::date = CURRENT_DATE' : ''),
        [ownername]
      );

      const totalAmount = totalAmountResult.rows[0].total_amount || 0;

      // Step 5: Return the rewards data and total amount
      return res.status(200).json({
        ownername,
        totalAmount,
        rewards: rewardsResult.rows,
      });

    } catch (err) {
      console.error('Error fetching rewards data', err);
      return res.status(500).json({ message: 'Internal Server Error' });
    }
  });






  //post inr

  server.post("/hr", function (req, res) {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    const { uid, date, amount_deposit, txid_in, status, name } = req.body;
    inr_deposit.inrapi({ uid, date, amount_deposit, txid_in, status, name });
    res.send(req.body);
  });
  server.post('/send-otp', async (req, res) => {
    const { to } = req.body;


    const otp = randomstring.generate({
      length: 6,
      charset: 'numeric',
    });
    // const logoPath = './assets/logo.png';
    // const logoBuffer = fs.readFileSync(logoPath);


    // const logoBase64 = logoBuffer.toString('base64');
    // const logoDataURL = `data:image/png;base64,${logoBase64}`;



    const transporter = nodemailer.createTransport({
      host: 'smtpout.secureserver.net',
      port: 465,
      secure: true,
      auth: {
        user: 'support@example.com',
        pass: 'REMOVED_SECRET',
      },
    });


    const mailOptions = {
      from: 'support@example.com',
      to,
      subject: 'OTP Verification',
      html: `
      <div style="background-color: #13182e; padding: 20px; text-align: center; border-radius: 10px; width: fit-content; margin: auto;">
        <h1 style="color: #fff; font-size: 24px;">Your OTP for verification is:</h1>
        <p style="color: #fff; font-size: 36px; font-weight: bold; margin: 10px 0;">${otp}</p>
      </div>
    `,
    };

    try {

      await transporter.sendMail(mailOptions);
      // Do NOT return the OTP in the response — that defeats verification.
      // The user receives it by email; the server verifies it separately.
      res.status(200).send({ message: 'OTP sent successfully' });
    } catch (error) {
      console.error('Error sending OTP:', error);
      res.status(500).send({ message: 'Error sending OTP' });
    }
  });


  let task;

  const startAutomaticMode = () => {
    task = cron.schedule('* * * * *', async () => {
      try {
        const result = await pg.query('SELECT * FROM house');
        const houses = result.rows;

        for (const house of houses) {
          const { uid, max, current } = house;
          let newMax = max;
          let newCurrent = current;

          // Illusion logic with a 70-30 win-loss ratio
          const winProbability = 0.7;
          const randomValue = Math.random();

          if (randomValue < winProbability) { // 70% chance to win
            if (max > current) {
              newCurrent += 1; // Increase current for a win
            } else if (max < current) {
              newMax -= 1; // Decrease max for a win
            } else {
              newCurrent -= 1; // Special case: Draw results in a decrease
            }
          } else { // 30% chance to lose
            if (max > current) {
              newCurrent -= 1; // Decrease current for a loss
            } else if (max < current) {
              newMax += 1; // Increase max for a loss
            } else {
              newCurrent += 1; // Special case: Draw results in an increase
            }
          }

          // Ensure values are not negative
          newMax = Math.max(newMax, 0);
          newCurrent = Math.max(newCurrent, 0);

          await pg.query('UPDATE house SET max = $1, current = $2 WHERE uid = $3', [newMax, newCurrent, uid]);
        }
      } catch (error) {
        console.error('Error running cron job:', error);
      }
    });
    task.start();
  };


  const stopAutomaticMode = () => {
    if (task) {
      task.stop();
    }
  };

  server.get('/start-house', (req, res) => {
    startAutomaticMode();
    res.json({ message: 'Automatic mode started' });
  });

  server.get('/stop-house', (req, res) => {
    stopAutomaticMode();
    res.json({ message: 'Automatic mode stopped' });
  });

  server.get('/reset-house', async (req, res) => {
    try {
      await pg.query('UPDATE house SET max = 50, current = 0');
      res.json({ message: 'House reset successfully' });
    } catch (error) {
      res.status(500).json({ error: 'Failed to reset house' });
    }
  });

  server.get('/win-house', async (req, res) => {
    try {
      await pg.query('UPDATE house SET max = 0, current = 0');
      res.json({ message: 'Win condition set successfully' });
    } catch (error) {
      res.status(500).json({ error: 'Failed to set win condition' });
    }
  });

  server.get('/gethouse', async (req, res) => {
    try {
      const result = await pg.query(
        `SELECT house.uid, house.max, house.current, users.name 
         FROM house 
         JOIN users ON house.uid = users.id`
      );
      res.json(result.rows);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch house data' });
    }
  });

  server.post('/updatehouse', async (req, res) => {
    const { uid, max, current } = req.body;
    try {
      await pg.query('UPDATE house SET max = $1, current = $2 WHERE uid = $3', [max, current, uid]);
      res.json({ message: 'House updated successfully' });
    } catch (error) {
      res.status(500).json({ error: 'Failed to update house' });
    }
  });

  // Function to fetch wallet details
  // Function to fetch wallet details
  const fetchWalletDetails = async () => {
    const query = `
    SELECT u.id as uid, u.name, c.btc, c.eth, c.ltc, c.bch, c.usdt, c.trx, c.doge, c.ada, c.xrp, c.bnb, c.usdp, c.nexo, c.mkr, c.tusd, c.usdc, c.busd, c.nc, c.inr, c.shib, c.matic, c.bjb, c.sc, c.mvr, c.aed, c.npr, c.pkr, c.bdt
    FROM users u
    JOIN credits c ON u.id = c.uid
    WHERE ${selfServeSql('u')}
    ORDER BY u.name
  `;
    const res = await pg.query(query);
    return res.rows;
  };

  // API endpoint to get wallet details
  server.get('/getwallet', protectStaff, async (req, res) => {
    try {
      // Direct users only (users table parent_staff_id IS NULL)
      const walletDetails = await fetchWalletDetails();
      res.json(walletDetails);
    } catch (error) {
      console.error('Error fetching wallet details:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });
  // Function to get current balance before update
  const getCurrentBalance = async (uid, coin) => {
    const query = `
    SELECT ${coin} 
    FROM credits 
    WHERE uid = $1
  `;

    const result = await pg.query(query, [uid]);
    return result.rows[0] ? parseFloat(result.rows[0][coin]) || 0 : 0;
  };

  // Function to get username from users table
  const getUsername = async (uid) => {
    const query = `
    SELECT name 
    FROM users 
    WHERE id = $1
  `;

    const result = await pg.query(query, [uid]);
    return result.rows[0] ? result.rows[0].name : 'Unknown';
  };

  // Function to add wallet history record
  const addWalletHistory = async (uid, username, coin, operation, amount, previousBalance, newBalance, description = null) => {
    const query = `
    INSERT INTO wallet_history
    (uid, username, coin, operation, amount, previous_balance, new_balance, description, transaction_time)
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, NOW())
  `;

    await pg.query(query, [
      uid,
      username,
      coin,
      operation,
      amount,
      previousBalance,
      newBalance,
      description
    ]);
  };

  // Updated credit wallet balance function with history using direct pg.query
  const creditWalletBalance = async (uid, coin, amount, description = null) => {
    try {
      // Get current balance before update
      const previousBalance = await getCurrentBalance(uid, coin);
      const username = await getUsername(uid);
      const newBalance = previousBalance + parseFloat(amount);

      // Begin transaction
      await pg.query('BEGIN');

      // Update balance
      const updateQuery = `
      UPDATE credits
      SET ${coin} = ${coin} + $1
      WHERE uid = $2
    `;
      await pg.query(updateQuery, [amount, uid]);

      // Add history record
      await addWalletHistory(
        uid,
        username,
        coin,
        'credit',
        amount,
        previousBalance,
        newBalance,
        description
      );

      await pg.query('COMMIT');
    } catch (error) {
      await pg.query('ROLLBACK');
      throw error;
    }
  };

  // Updated debit wallet balance function with history using direct pg.query
  const debitWalletBalance = async (uid, coin, amount, description = null) => {
    try {
      // Get current balance before update
      const previousBalance = await getCurrentBalance(uid, coin);
      const username = await getUsername(uid);
      const newBalance = Math.max(0, previousBalance - parseFloat(amount));

      // Begin transaction
      await pg.query('BEGIN');

      // Update balance
      const updateQuery = `
      UPDATE credits
      SET ${coin} = GREATEST(0, ${coin} - $1)
      WHERE uid = $2
    `;
      await pg.query(updateQuery, [amount, uid]);

      // Add history record
      await addWalletHistory(
        uid,
        username,
        coin,
        'debit',
        amount,
        previousBalance,
        newBalance,
        description
      );

      await pg.query('COMMIT');
    } catch (error) {
      await pg.query('ROLLBACK');
      throw error;
    }
  };

  // Updated API endpoint to update wallet balance
  // coin is interpolated directly into the UPDATE statement below, so it must
  // be whitelisted to avoid SQL injection / updating arbitrary columns.
  const WALLET_COINS = [
    'btc', 'eth', 'ltc', 'bch', 'usdt', 'trx', 'doge', 'ada', 'xrp', 'bnb',
    'usdp', 'nexo', 'mkr', 'tusd', 'usdc', 'busd', 'nc', 'inr', 'shib',
    'matic', 'bjb', 'sc', 'mvr', 'aed', 'npr', 'pkr', 'bdt',
  ];

  // Report PDFs (one-click download from the Users list). Hierarchy-scoped:
  // SuperAdmin (level 0) sees anyone; others only users in their own downline.
  // Returns true when the caller may pull reports for this uid, and sends the
  // 404/403 itself when they may not.
  const canReportOn = async (req, res, uid) => {
    const { rows: [u] } = await pg.query('SELECT id, parent_staff_id FROM users WHERE id::text=$1', [uid]);
    if (!u) { res.status(404).json({ error: 'User not found' }); return false; }
    if (req.staff.level === 0) return true;
    const psid = u.parent_staff_id;
    let allowed = psid != null && Number(psid) === Number(req.staff.id);
    if (!allowed && psid != null) {
      const { rows } = await pg.query('SELECT 1 FROM staff_hierarchy WHERE ancestor_id=$1 AND descendant_id=$2 LIMIT 1', [req.staff.id, psid]);
      allowed = rows.length > 0;
    }
    if (!allowed) { res.status(403).json({ error: 'User is not in your hierarchy' }); return false; }
    return true;
  };

  // Wraps a report generator with the hierarchy guard and uniform error handling.
  const reportRoute = (label, generate) => async (req, res) => {
    try {
      const uid = String(req.params.uid);
      if (!await canReportOn(req, res, uid)) return;
      await generate(res, { uid, from: req.query.from, to: req.query.to });
    } catch (e) {
      console.error(`[${label} report]`, e);
      if (!res.headersSent) res.status(500).json({ error: 'Failed to generate report' });
      else res.end();
    }
  };

  server.get('/api/report/player/:uid', protectStaff, reportRoute('player', generatePlayerReport));

  // Date+time-ranged dispute reports: every callback / bet in the window with
  // session id, round id, amount and running balance.
  server.get('/api/report/casino/:uid', protectStaff, reportRoute('casino', generateCasinoSessionReport));
  server.get('/api/report/sports/:uid', protectStaff, reportRoute('sports', generateSportsSessionReport));

  server.post('/updatebalance', protectStaff,
    withActivity({
      action: 'wallet.balance.update',
      describe: req => ({
        targetType: 'USER', targetId: req.body && req.body.uid,
        details: req.body ? {
          operation: req.body.operation,
          coin: req.body.coin,
          amount: req.body.amount,
        } : undefined,
      }),
    }),
    async (req, res) => {
    const { uid, coin, amount, operation, description, transactionPassword } = req.body;

    try {
      if (!WALLET_COINS.includes(coin)) {
        return res.status(400).json({ error: 'Invalid coin' });
      }
      if (operation !== 'credit' && operation !== 'debit') {
        return res.status(400).json({ error: 'Invalid operation type' });
      }
      const amt = parseFloat(amount);
      if (isNaN(amt) || amt <= 0) {
        return res.status(400).json({ error: 'Invalid amount' });
      }

      // Verify the logged-in staff's transaction password (throws on mismatch)
      await validateTransactionPassword(req.staff.id, transactionPassword);

      // The target must be a direct or branch player (agent players' money
      // only moves through their agent)
      const { rows } = await pg.query(
        `SELECT 1 FROM users u WHERE u.id = $1 AND ${selfServeSql('u')}`,
        [uid]
      );
      if (!rows.length) {
        return res.status(403).json({ error: 'User is not your direct user' });
      }

      if (operation === 'credit') {
        await creditWalletBalance(uid, coin, amount, description);
      } else {
        await debitWalletBalance(uid, coin, amount, description);
      }

      res.json({ message: 'Balance updated successfully' });
    } catch (error) {
      // validateTransactionPassword throws user-facing messages (e.g. "Invalid
      // transaction password") — surface those as 400, hide everything else.
      const msg = error && error.message ? error.message : 'Internal Server Error';
      if (/transaction password|Staff not found/i.test(msg)) {
        return res.status(400).json({ error: msg });
      }
      console.error('Error updating wallet balance:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });

  server.post("/adminwalletadd", guardAdmin('adminwalletadd'), async (req, res) => {
    const { amount } = req.body;

    if (!amount || isNaN(amount)) {
      return res.status(400).json({ error: "Invalid amount" });
    }

    try {
      // Update staff_id = 1
      const result = await pg.query(
        `UPDATE staff_balances 
       SET inr = inr + $1 
       WHERE staff_id = 1
       RETURNING staff_id, inr`,
        [amount]
      );

      if (result.rowCount === 0) {
        return res.status(404).json({ error: "Staff ID 1 not found" });
      }

      res.json({
        message: "Balance updated successfully",
        balance: result.rows[0],
      });
    } catch (err) {
      console.error("Error updating staff balance:", err);
      res.status(500).json({ error: "Internal Server Error" });
    }
  });

  // API endpoint to get wallet history for a user
  server.get('/wallethistory/:uid', async (req, res) => {
    const { uid } = req.params;
    const { coin, limit = 50, offset = 0 } = req.query;

    try {
      let query = `
      SELECT * FROM wallet_history 
      WHERE uid = $1
    `;

      const queryParams = [uid];
      let paramIndex = 2;

      if (coin) {
        query += ` AND coin = $${paramIndex++}`;
        queryParams.push(coin);
      }

      query += ` ORDER BY transaction_time DESC LIMIT $${paramIndex++} OFFSET $${paramIndex}`;
      queryParams.push(limit, offset);

      const result = await pg.query(query, queryParams);

      res.json({
        history: result.rows,
        count: result.rowCount
      });
    } catch (error) {
      console.error('Error fetching wallet history:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });
  // Fetch transaction live data with join to users
  server.get('/transaction/live', guardAdmin('transaction/live'), async (req, res) => {
    const query = `
    SELECT 
      transaction_live.id, 
      transaction_live.method, 
      transaction_live.user_code, 
      transaction_live.user_balance, 
      transaction_live.game_type, 
      transaction_live.provider_code, 
      transaction_live.game_code, 
      transaction_live.type, 
      transaction_live.bet_money, 
      transaction_live.win_money, 
      transaction_live.txn_id, 
      transaction_live.txn_type,
      users.name AS user_name 
    FROM transaction_live 
    JOIN users ON transaction_live.user_code = CAST(users.id AS VARCHAR(50))
  `;

    try {
      console.log('Executing query:', query);
      const result = await pg.query(query);
      res.json(result.rows);
    } catch (error) {
      console.error('Error fetching live transactions:', error);
      res.status(500).json({ error: 'Failed to fetch live transaction data', details: error.message });
    }
  });

  // Fetch transaction slot data with join to users
  server.get('/transaction/slot', guardAdmin('transaction/slot'), async (req, res) => {
    const query = `
    SELECT 
      transaction_slot.id, 
      transaction_slot.method, 
      transaction_slot.user_code, 
      transaction_slot.user_balance, 
      transaction_slot.game_type, 
      transaction_slot.provider_code, 
      transaction_slot.game_code, 
      transaction_slot.type, 
      transaction_slot.bet_money, 
      transaction_slot.win_money, 
      transaction_slot.txn_id, 
      transaction_slot.txn_type,
      users.name AS user_name 
    FROM transaction_slot 
    JOIN users ON transaction_slot.user_code = CAST(users.id AS VARCHAR(50))
  `;

    try {
      console.log('Executing query:', query);
      const result = await pg.query(query);
      res.json(result.rows);
    } catch (error) {
      console.error('Error fetching slot transactions:', error);
      res.status(500).json({ error: 'Failed to fetch slot transaction data', details: error.message });
    }
  });
  server.post('/updateWithdrawStatus', guardAdmin('updateWithdrawStatus'), async (req, res) => {
    const { id, status } = req.body; // Expecting 'id' instead of 'uid'

    try {
      const result = await pg.query(
        'UPDATE withdrawals SET status = $1 WHERE id = $2 RETURNING *', // Change 'uid' to 'id'
        [status, id]
      );

      if (result.rowCount === 0) {
        return res.status(404).json({ message: 'ID not found' });
      }

      // Log + alert on admin approve/reject (financial). Actor from x-staff-id.
      const w = result.rows[0] || {};
      const s = String(status || '').toLowerCase();
      const action = (s === 'rejected' || s === 'failed' || s === 'declined') ? 'withdraw.rejected'
        : (['done', 'approved', 'success', 'completed', 'paid'].includes(s) ? 'withdraw.approved' : null);
      if (action) {
        const sid = Number(req.headers['x-staff-id'] || req.headers['x_staff_id']);
        recordActivity({
          req, action,
          targetType: 'USER', targetId: w.uid,
          details: { withdrawalId: id, amount: w.amount, currency: w.currency || w.coin, status },
          actor: { staffId: Number.isFinite(sid) && sid > 0 ? sid : null },
        });
      }

      res.json(result.rows[0]);
    } catch (error) {
      console.error('Error updating withdrawal status:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  /**
   * Enhanced User Deletion API
   * 
   * This API endpoint automatically identifies all tables with user references
   * and deletes related records before deleting the user.
   */
  server.delete('/deleteUser', guardAdmin('deleteUser'), async (req, res) => {
    const { id } = req.body;

    if (!id) {
      return res.status(400).json({ message: 'User ID is required' });
    }

    try {
      // Start a transaction
      await pg.query('BEGIN');

      // Step 1: Get all tables in the database
      const tablesQuery = `
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      AND table_type = 'BASE TABLE';
    `;
      const tablesResult = await pg.query(tablesQuery);
      const tables = tablesResult.rows.map(row => row.table_name);

      // Step 2: For each table, check if it has user reference columns
      const userReferenceTables = [];
      const possibleUserColumns = ['user_id', 'userid', 'uid', 'id_user', 'user'];

      for (const table of tables) {
        // Skip the users table itself
        if (table === 'users') continue;

        // Get all columns for this table
        const columnsQuery = `
        SELECT column_name 
        FROM information_schema.columns 
        WHERE table_schema = 'public' 
        AND table_name = $1;
      `;
        const columnsResult = await pg.query(columnsQuery, [table]);
        const columns = columnsResult.rows.map(row => row.column_name);

        // Check if any of the possible user columns exist in this table
        for (const possibleColumn of possibleUserColumns) {
          if (columns.includes(possibleColumn)) {
            userReferenceTables.push({ table, column: possibleColumn });
            break;
          }
        }
      }

      console.log(`Found ${userReferenceTables.length} tables with user references`);

      // Step 3: Delete records from all tables that reference the user
      const deletionResults = [];

      for (const { table, column } of userReferenceTables) {
        try {
          const deleteQuery = `DELETE FROM "${table}" WHERE "${column}" = $1`;
          const deleteResult = await pg.query(deleteQuery, [id]);

          deletionResults.push({
            table,
            column,
            recordsDeleted: deleteResult.rowCount
          });

          console.log(`Deleted ${deleteResult.rowCount} records from ${table}`);
        } catch (error) {
          console.error(`Error deleting from ${table}:`, error);
          // Continue with other tables even if one fails
        }
      }

      // Step 4: Finally delete the user
      const userDeleteResult = await pg.query('DELETE FROM users WHERE id = $1 RETURNING *', [id]);

      if (userDeleteResult.rowCount === 0) {
        await pg.query('ROLLBACK');
        return res.status(404).json({ message: 'User not found' });
      }

      // Commit the transaction
      await pg.query('COMMIT');

      res.json({
        message: `User with id ${id} deleted successfully`,
        relatedRecordsDeleted: deletionResults,
        user: userDeleteResult.rows[0]
      });

    } catch (error) {
      // Rollback in case of error
      await pg.query('ROLLBACK');
      console.error('Error in user deletion process:', error);
      res.status(500).json({
        message: 'Internal server error',
        error: error.toString(),
        details: error.detail || null,
        hint: error.hint || null
      });
    }
  });
  const getTreeIdsSql = `
WITH RECURSIVE tree AS (
  SELECT id FROM staff WHERE id = $1
  UNION ALL
  SELECT s.id
  FROM staff s
  JOIN tree t ON s.parent_id = t.id
)
SELECT array_agg(id) AS ids FROM tree
`;
  async function visibleIds(staffId) {
    const { rows: [{ ids }] } = await pg.query(getTreeIdsSql, [staffId]);
    return ids;                   // => e.g. [1,4,9,12]
  }
  // Fetch withdrawal data including user names and conversion to USDT
  // const getWithdrawData = async (staffId) => {
  //   try {
  //     // get visible staff IDs for this staff user
  //     let ids = await visibleIds(staffId);
  //     ids = ids.map(x => Number(x));

  //     // base query
  //     let query = `
  //       SELECT 
  //         w.id, 
  //         w.uid, 
  //         w.date, 
  //         w.amount, 
  //         w.wallet, 
  //         w.coin, 
  //         w.status, 
  //         u.name, 
  //         w.chain
  //       FROM withdrawals w
  //       JOIN users u ON w.uid = u.id
  //       WHERE 1=1
  //     `;

  //     // visibility filter (same logic as crypto stats)
  //     if (ids.includes(1)) {
  //       query += ` AND (u.parent_staff_id = ANY($1::bigint[]) OR u.parent_staff_id IS NULL)`;
  //     } else {
  //       query += ` AND u.parent_staff_id = ANY($1::bigint[])`;
  //     }

  //     // execute query
  //     const withdrawResult = await pg.query(query, [ids]);

  //     // convert each withdrawal to USDT equivalent
  //     const withdrawals = await Promise.all(
  //       withdrawResult.rows.map(async (withdraw) => {
  //         const amountInUSDT = await convertToUSDT(parseFloat(withdraw.amount), withdraw.coin);
  //         return { ...withdraw, amount_usdt: amountInUSDT };
  //       })
  //     );

  //     return withdrawals;
  //   } catch (error) {
  //     console.error('Error fetching withdrawal data:', error);
  //     throw error;
  //   }
  // };

  const getWithdrawData = async () => {
    try {
      const withdrawResult = await pg.query(`
      SELECT w.id,w.uid, w.date, w.amount, w.wallet, w.coin,w.status, u.name , w.chain
      FROM withdrawals w
      JOIN users u ON w.uid = u.id
    `);

      const withdrawals = await Promise.all(withdrawResult.rows.map(async (withdraw) => {
        const amountInUSDT = await convertToUSDT(parseFloat(withdraw.amount), withdraw.coin);
        return { ...withdraw, amount_usdt: amountInUSDT };
      }));

      return withdrawals;
    } catch (error) {
      console.error('Error fetching withdrawal data:', error);
      throw error;
    }
  };

  server.get('/getWithdrawDataUser', async (req, res) => {
    try {
      const { uid } = req.query; // Get uid from query parameters

      if (!uid) {
        return res.status(400).json({ error: 'User ID (uid) is required' });
      }

      const data = await getWithdrawDataUser(uid);
      res.json(data);
    } catch (error) {
      console.error('Error fetching withdrawal data:', error);
      res.status(500).send('Internal Server Error');
    }
  });

  const getWithdrawDataUser = async (uid) => {
    try {
      const withdrawResult = await pg.query(
        `SELECT w.uid, w.date, w.amount, w.wallet, w.coin, w.status, u.name 
       FROM withdrawals w
       JOIN users u ON w.uid = u.id
       WHERE w.uid = $1`,
        [uid]
      );

      const withdrawals = await Promise.all(withdrawResult.rows.map(async (withdraw) => {
        const amountInUSDT = await convertToUSDT(parseFloat(withdraw.amount), withdraw.coin);
        return { ...withdraw, amount_usdt: amountInUSDT };
      }));

      return withdrawals;
    } catch (error) {
      console.error('Error fetching withdrawal data:', error);
      throw error;
    }
  };

  // Fetch deposit data including user names without conversion
  const getDepositData = async () => {
    try {
      const depositResult = await pg.query(`
      SELECT d.uid, d.date, d.txtid, d.amount, d.coin, u.name
      FROM deposits d
      JOIN users u ON d.uid = u.id
    `);

      return depositResult.rows;
    } catch (error) {
      console.error('Error fetching deposit data:', error);
      throw error;
    }
  };

  // Define endpoints
  server.get('/getWithdrawData', guardAdmin('getWithdrawData'), async (req, res) => {
    try {
      const data = await getWithdrawData();
      res.json(data);
    } catch (error) {
      console.error('Error fetching withdrawal data:', error);
      res.status(500).send('Internal Server Error');
    }
  });

  server.get('/getDepositData', guardAdmin('getDepositData'), async (req, res) => {
    try {
      const data = await getDepositData();
      res.json(data);
    } catch (error) {
      res.status(500).send('Internal Server Error');
    }
  });


  /**
   * Get User Data API
   * Fetches user details with total deposits, withdrawals, and PNL in USD
   */
  const getUserData = async () => {
    try {
      // Fetch users
      const usersResult = await pg.query('SELECT id, name, email, country, phone, COALESCE(is_demo, false) AS is_demo FROM users');
      const users = usersResult.rows;

      // Fetch deposits in USD from all sources, grouped by user
      const cryptoDepositsResult = await pg.query(`
      SELECT c.userid as user_id, COALESCE(SUM(c.amount::numeric * e.usd_rate), 0) as total_usd
      FROM ccdeposit c
      JOIN exchangerate e ON CASE
        WHEN c.coinid = 1155 THEN 'BTC'
        WHEN c.coinid = 1161 THEN 'ETH'
        WHEN c.coinid = 1173 THEN 'LTC'
        WHEN c.coinid = 1169 THEN 'BCH'
        WHEN c.coinid = 1280 THEN 'USDT'
        WHEN c.coinid = 1482 THEN 'TRX'
        WHEN c.coinid = 1492 THEN 'DOGE'
        WHEN c.coinid = 1375 THEN 'ADA'
        WHEN c.coinid = 1331 THEN 'XRP'
        WHEN c.coinid = 1168 THEN 'BNB'
        WHEN c.coinid = 1282 THEN 'USDC'
        WHEN c.coinid = 1864 THEN 'SHIB'
      END = e.currency
      WHERE c.status = 'Success'
      GROUP BY c.userid
    `);

      const fiatDepositsResult = await pg.query(`
      SELECT f.user_id, COALESCE(SUM(f.amount::numeric * e.usd_rate), 0) as total_usd
      FROM fiat_deposits f
      JOIN exchangerate e ON f.currency = e.currency
      WHERE f.status = 'approved'
      GROUP BY f.user_id
    `);

      const apayDepositsResult = await pg.query(`
      SELECT a.user_id, COALESCE(SUM((CASE WHEN a.status = 'Success' AND a.paid_amount > 0 THEN a.paid_amount ELSE a.amount END)::numeric * e.usd_rate), 0) as total_usd
      FROM apaydeposits a
      JOIN exchangerate e ON a.currency = e.currency
      WHERE a.status = 'Success'
      GROUP BY a.user_id
    `);

      const f2payDepositsResult = await pg.query(`
      SELECT f.user_id, COALESCE(SUM(f.amount::numeric * e.usd_rate), 0) as total_usd
      FROM f2paydeposits f
      JOIN exchangerate e ON f.currency = e.currency
      WHERE f.status = 'Success'
      GROUP BY f.user_id
    `);

      const payInDepositsResult = await pg.query(`
      SELECT p.user_id as user_id, COALESCE(SUM(p.amount::numeric * e.usd_rate), 0) as total_usd
      FROM pay_in_transactions p
      JOIN exchangerate e ON p.currency = e.currency
      WHERE p.status = 1
      GROUP BY p.user_id
    `);

      // Fetch withdrawals in USD, grouped by user
      const cryptoWithdrawalsResult = await pg.query(`
      SELECT w.uid as user_id, COALESCE(SUM(w.amount::numeric * e.usd_rate), 0) as total_usd
      FROM withdrawals w
      JOIN exchangerate e ON UPPER(w.coin) = e.currency
      WHERE w.status = 'Done'
      GROUP BY w.uid
    `);

      const fiatWithdrawalsResult = await pg.query(`
      SELECT f.uid as user_id, COALESCE(SUM(f.amount::numeric * e.usd_rate), 0) as total_usd
      FROM fiat_withdrawals f
      JOIN exchangerate e ON f.currency = e.currency
      WHERE f.status = 'Done'
      GROUP BY f.uid
    `);

      const apayWithdrawalsResult = await pg.query(`
      SELECT a.user_id, COALESCE(SUM(a.amount::numeric * e.usd_rate), 0) as total_usd
      FROM apaywithdrawals a
      JOIN exchangerate e ON a.currency = e.currency
      WHERE a.status = 'Success'
      GROUP BY a.user_id
    `);

      const f2payWithdrawalsResult = await pg.query(`
      SELECT f.user_id, COALESCE(SUM(f.amount::numeric * e.usd_rate), 0) as total_usd
      FROM f2paywithdrawals f
      JOIN exchangerate e ON f.currency = e.currency
      WHERE f.status = 'Success'
      GROUP BY f.user_id
    `);

      // Map deposits and withdrawals to users
      const userDeposits = {};
      const userWithdrawals = {};

      // Combine deposits (cast user_id to varchar for consistency)
      for (const row of cryptoDepositsResult.rows) {
        const userId = row.user_id.toString();
        userDeposits[userId] = (userDeposits[userId] || 0) + parseFloat(row.total_usd);
      }
      for (const row of fiatDepositsResult.rows) {
        const userId = row.user_id.toString();
        userDeposits[userId] = (userDeposits[userId] || 0) + parseFloat(row.total_usd);
      }
      for (const row of apayDepositsResult.rows) {
        const userId = row.user_id.toString();
        userDeposits[userId] = (userDeposits[userId] || 0) + parseFloat(row.total_usd);
      }
      for (const row of f2payDepositsResult.rows) {
        const userId = row.user_id.toString();
        userDeposits[userId] = (userDeposits[userId] || 0) + parseFloat(row.total_usd);
      }
      for (const row of payInDepositsResult.rows) {
        const userId = row.user_id.toString();
        userDeposits[userId] = (userDeposits[userId] || 0) + parseFloat(row.total_usd);
      }

      // Combine withdrawals (cast user_id to varchar for consistency)
      for (const row of cryptoWithdrawalsResult.rows) {
        const userId = row.user_id.toString();
        userWithdrawals[userId] = (userWithdrawals[userId] || 0) + parseFloat(row.total_usd);
      }
      for (const row of fiatWithdrawalsResult.rows) {
        const userId = row.user_id.toString();
        userWithdrawals[userId] = (userWithdrawals[userId] || 0) + parseFloat(row.total_usd);
      }
      for (const row of apayWithdrawalsResult.rows) {
        const userId = row.user_id.toString();
        userWithdrawals[userId] = (userWithdrawals[userId] || 0) + parseFloat(row.total_usd);
      }
      for (const row of f2payWithdrawalsResult.rows) {
        const userId = row.user_id.toString();
        userWithdrawals[userId] = (userWithdrawals[userId] || 0) + parseFloat(row.total_usd);
      }

      // Keys stay *_usd, but the values are sent in INR
      const inrRateResult = await pg.query(`SELECT usd_rate FROM exchangerate WHERE currency = 'INR' LIMIT 1`);
      const inrRate = parseFloat(inrRateResult.rows[0].usd_rate);

      // Process users
      for (const user of users) {
        const userId = user.id.toString();
        user.total_deposit_usd = (parseFloat(userDeposits[userId] || 0) / inrRate).toFixed(2);
        user.total_withdrawal_usd = (parseFloat(userWithdrawals[userId] || 0) / inrRate).toFixed(2);
        user.pnl_usd = (parseFloat(user.total_deposit_usd) - parseFloat(user.total_withdrawal_usd)).toFixed(2);
      }

      return users;
    } catch (error) {
      console.error('Error fetching user data:', error);
      throw error;
    }
  };

  // Define endpoint
  server.get('/getUserData', guardAdmin('getUserData'), async (req, res) => {
    try {
      const data = await getUserData();
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: 'Internal Server Error', details: error.toString() });
    }
  });
  // Total deposits endpoint
  server.get('/total-deposits', guardAdmin('total-deposits'), async (req, res) => {
    try {
      const result = await pg.query('SELECT amount, coin FROM deposits');
      const deposits = result.rows;
      let totalDeposits = 0;

      for (const deposit of deposits) {
        const amountInUSDT = await convertToUSDT(deposit.amount, deposit.coin);
        totalDeposits += amountInUSDT;
      }

      res.json({ total_deposits_usdt: totalDeposits });
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch deposits' });
    }
  });

  // Total withdrawals endpoint
  server.get('/total-withdrawals', guardAdmin('total-withdrawals'), async (req, res) => {
    try {
      const result = await pg.query('SELECT amount, coin FROM withdrawals');
      const withdrawals = result.rows;
      let totalWithdrawals = 0;

      for (const withdrawal of withdrawals) {
        const amountInUSDT = await convertToUSDT(withdrawal.amount, withdrawal.coin);
        totalWithdrawals += amountInUSDT;
      }

      res.json({ total_withdrawals_usdt: totalWithdrawals });
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch withdrawals' });
    }
  });
  // User endpoints
  server.get('/users', guardAdmin('users'), async (req, res) => {
    try {
      const result = await pg.query('SELECT * FROM users');
      res.json(result.rows);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch users' });
    }
  });

  // Deposit endpoints
  server.get('/deposits', guardAdmin('deposits'), async (req, res) => {
    try {
      const result = await pg.query('SELECT * FROM deposits');
      const depositsInUSDT = await Promise.all(result.rows.map(async deposit => {
        const amountInUSDT = await convertToUSDT(deposit.amount, deposit.coin);
        return { ...deposit, amount_in_usdt: amountInUSDT };
      }));
      res.json(depositsInUSDT);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch deposits' });
    }
  });

  // Withdrawal endpoints
  server.get('/withdrawals', guardAdmin('withdrawals'), async (req, res) => {
    try {
      const result = await pg.query('SELECT * FROM withdrawals');
      const withdrawalsInUSDT = await Promise.all(result.rows.map(async withdrawal => {
        const amountInUSDT = await convertToUSDT(withdrawal.amount, withdrawal.coin);
        return { ...withdrawal, amount_in_usdt: amountInUSDT };
      }));
      res.json(withdrawalsInUSDT);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch withdrawals' });
    }
  });

  // Bet endpoints
  server.get('/bets', async (req, res) => {
    try {
      const result = await pg.query('SELECT * FROM bets');
      res.json(result.rows);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch bets' });
    }
  });

  // Get total deposits and withdrawals for each user
  server.get('/user-summary', guardAdmin('user-summary'), async (req, res) => {
    try {
      const result = await pg.query(`
      SELECT 
        u.id,
        u.name,
        u.email,
        COALESCE(SUM(d.amount), 0) AS total_deposit_usdt,
        COALESCE(SUM(w.amount), 0) AS total_withdrawal_usdt
      FROM 
        users u
      LEFT JOIN 
        deposits d ON u.id = d.uid
      LEFT JOIN 
        withdrawals w ON u.id = w.uid
      GROUP BY 
        u.id
    `);
      res.json(result.rows);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch user summary' });
    }
  });

  // Get today's deposits
  server.get('/today-deposits', guardAdmin('today-deposits'), async (req, res) => {
    try {
      const result = await pg.query(`
      SELECT * FROM deposits
      WHERE DATE(date) = CURRENT_DATE
    `);
      res.json(result.rows);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch today\'s deposits' });
    }
  });

  // Get today's withdrawals
  server.get('/today-withdrawals', guardAdmin('today-withdrawals'), async (req, res) => {
    try {
      const result = await pg.query(`
      SELECT * FROM withdrawals
      WHERE DATE(date) = CURRENT_DATE
    `);
      res.json(result.rows);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch today\'s withdrawals' });
    }
  });

  // Get today's withdrawals
  // server.get('/api/depositNew', async (req, res) => {
  //   const { uid } = req.query;  // Extract the uid from query parameters
  //   try {
  //     // Query for regular deposits
  //     const ccDepositResult = await pg.query(`
  //       SELECT orderid as id, amount, status, created_at as date, 'Crypto' as type
  //       FROM ccdeposit
  //       WHERE userid = $1
  //       ORDER BY created_at DESC
  //     `, [uid]);

  //     // Query for fiat deposits
  //     const fiatDepositResult = await pg.query(`
  //       SELECT deposit_id as id, amount, currency, status, created_at as date, 
  //              bank_name, account_number, transaction_id, 'Fiat' as type
  //       FROM fiat_deposits
  //       WHERE user_id = $1
  //       ORDER BY created_at DESC
  //     `, [uid]);

  //     // Format fiat deposits to match your component's expected format
  //     const fiatDeposits = fiatDepositResult.rows.map(row => ({
  //       date: row.date,
  //       amount: `${row.amount} ${row.currency}`,
  //       status: row.status,
  //       details: `Txn: ${row.transaction_id || 'N/A'}`
  //     }));

  //     // Format crypto deposits
  //     const cryptoDeposits = ccDepositResult.rows.map(row => ({
  //       date: row.date,
  //       amount: row.amount,
  //       status: row.status,
  //       details: `Order: ${row.id}`
  //     }));

  //     // Combine both types of deposits
  //     res.json({
  //       deposits: cryptoDeposits,
  //       fiatDeposits: fiatDeposits
  //     });
  //   } catch (error) {
  //     console.error('Error fetching deposits:', error);
  //     res.status(500).json({ error: 'Failed to fetch deposits' });
  //   }
  // });

  // server.get('/api/withdrawNew', async (req, res) => {
  //   const { uid } = req.query;  // Extract uid from query parameters
  //   try {
  //     const withdrawalsQuery = `
  //       SELECT wallet, amount, status, date 
  //       FROM withdrawals
  //       WHERE uid = $1 AND DATE(date) = CURRENT_DATE
  //     `;

  //     const fiatWithdrawalsQuery = `
  //       SELECT amount, status, date, currency, bank_name, account_number, 
  //              account_holder_name, ifsc_code, upi_id, name 
  //       FROM fiat_withdrawals
  //       WHERE uid = $1 AND DATE(date) = CURRENT_DATE
  //     `;

  //     // Execute both queries in parallel
  //     const [withdrawalsResult, fiatWithdrawalsResult] = await Promise.all([
  //       pg.query(withdrawalsQuery, [uid]),
  //       pg.query(fiatWithdrawalsQuery, [uid])
  //     ]);

  //     // Combine results and send response
  //     res.json({
  //       withdrawals: withdrawalsResult.rows,
  //       fiatWithdrawals: fiatWithdrawalsResult.rows
  //     });

  //   } catch (error) {
  //     console.error(error);
  //     res.status(500).json({ error: "Failed to fetch today's withdrawals" });
  //   }
  // });
  server.get('/api/depositNew', async (req, res) => {
    const { uid } = req.query; // Extract the uid from query parameters
    try {
      // Query for regular deposits (Crypto)
      const ccDepositResult = await pg.query(`
      SELECT orderid as id, amount, status, created_at as date, 'Crypto' as type
      FROM ccdeposit
      WHERE userid = $1
      ORDER BY created_at DESC
    `, [uid]);

      // Query for fiat deposits
      const fiatDepositResult = await pg.query(`
      SELECT deposit_id as id, amount, currency, status, created_at as date,
             bank_name, account_number, transaction_id, 'Fiat' as type
      FROM fiat_deposits
      WHERE user_id = $1
      ORDER BY created_at DESC
    `, [uid]);

      // Query for apaydeposits — on Success show what the user actually paid
      // (paid_amount from the postback), otherwise the requested amount.
      const apayDepositResult = await pg.query(`
      SELECT order_id as id,
             CASE WHEN status = 'Success' AND paid_amount > 0 THEN paid_amount ELSE amount END as amount,
             currency, status, created_at as date,
             payment_system, custom_transaction_id, 'UPI' as type
      FROM apaydeposits
      WHERE user_id = $1
      ORDER BY created_at DESC
    `, [uid]);

      // Query for pay_in_transactions
      const payInTransactionResult = await pg.query(`
      SELECT transaction_id as id, amount, currency, status, created_at as date,
             pay_type, 'PayIn' as type
      FROM pay_in_transactions
      WHERE user_id = $1
      ORDER BY created_at DESC
    `, [uid]);

      // Query for f2pay deposits
      const f2payDepositResult = await pg.query(`
      SELECT mch_order_no as id, amount, currency, status, created_at as date, 'UPI' as type
      FROM f2paydeposits
      WHERE user_id = $1
      ORDER BY created_at DESC
    `, [uid]);

      // Function to normalize status values
      const normalizeStatus = (status) => {
        if (status === undefined || status === null) return 'pending';
        if (typeof status === 'number') {
          return status === 0 ? 'pending' : status === 1 ? 'approved' : 'pending';
        }
        return String(status).toLowerCase(); // Ensure consistent casing
      };

      // Format fiat deposits
      const fiatDeposits = fiatDepositResult.rows.map(row => ({
        date: row.date,
        amount: `${row.amount} ${row.currency}`,
        status: normalizeStatus(row.status),
        details: `Txn: ${row.transaction_id || 'N/A'}`
      }));

      // Format apaydeposits
      const apayDeposits = apayDepositResult.rows.map(row => ({
        date: row.date,
        amount: `${row.amount} ${row.currency}`,
        status: normalizeStatus(row.status),
        details: `Txn: ${row.custom_transaction_id || 'N/A'}`
      }));

      // Format pay_in_transactions
      const payInTransactions = payInTransactionResult.rows.map(row => ({
        date: row.date,
        amount: `${row.amount} ${row.currency}`,
        status: normalizeStatus(row.status),
        details: `Type: ${row.pay_type || 'N/A'}`
      }));

      // Format f2pay deposits
      const f2payDeposits = f2payDepositResult.rows.map(row => ({
        date: row.date,
        amount: `${row.amount} ${row.currency}`,
        status: normalizeStatus(row.status),
        details: `Txn: ${row.id}`
      }));

      // Format crypto deposits
      const cryptoDeposits = ccDepositResult.rows.map(row => ({
        date: row.date,
        amount: row.amount,
        status: normalizeStatus(row.status),
        details: `Order: ${row.id}`
      }));

      // Combine fiat-like deposits (fiat, apay, pay_in) into fiatDeposits array
      const combinedFiatDeposits = [
        ...fiatDeposits,
        ...apayDeposits,
        ...payInTransactions,
        ...f2payDeposits
      ].sort((a, b) => new Date(b.date) - new Date(a.date)); // Sort by date DESC

      // Combine all deposits
      res.json({
        deposits: cryptoDeposits,
        fiatDeposits: combinedFiatDeposits
      });
    } catch (error) {
      console.error('Error fetching deposits:', error);
      res.status(500).json({ error: 'Failed to fetch deposits' });
    }
  });

  server.get('/api/withdrawNew', async (req, res) => {
    const { uid } = req.query;  // Extract uid from query parameters
    try {
      const withdrawalsQuery = `
      SELECT wallet, amount, status, date , chain
      FROM withdrawals
      WHERE uid = $1
      ORDER BY date DESC
    `;

      const fiatWithdrawalsQuery = `
      SELECT amount, status, date, currency, bank_name, account_number,
              account_holder_name, ifsc_code, upi_id, name
      FROM fiat_withdrawals
      WHERE uid = $1
      ORDER BY date DESC
    `;

      // A-Pay (auto payout) withdrawals — stored with user_id = custom_user_id (= uid).
      const apayWithdrawalsQuery = `
      SELECT amount, currency, status, payment_system, payout_details,
             error_reason, order_id, created_at AS date
      FROM apaywithdrawals
      WHERE user_id = $1
      ORDER BY created_at DESC
    `;

      // F2Pay (direct payout) withdrawals — user_id is the numeric users.id.
      const f2payWithdrawalsQuery = `
      SELECT amount, currency, status, mch_order_no, account_number, ifsc,
             account_holder_name, error_reason, created_at AS date
      FROM f2paywithdrawals
      WHERE user_id = $1
      ORDER BY created_at DESC
    `;

      // Execute all queries in parallel
      const [withdrawalsResult, fiatWithdrawalsResult, apayWithdrawalsResult, f2payWithdrawalsResult] = await Promise.all([
        pg.query(withdrawalsQuery, [uid]),
        pg.query(fiatWithdrawalsQuery, [uid]),
        pg.query(apayWithdrawalsQuery, [uid]),
        pg.query(f2payWithdrawalsQuery, [uid])
      ]);

      // Map A-Pay withdrawals into the fiat_withdrawals shape so they appear in the
      // existing fiat withdrawal history. Account fields come from payout_details
      // (shape varies per payment system: imps/bkash/pkr_w/esewa).
      const apayWithdrawals = apayWithdrawalsResult.rows.map(row => {
        let d = row.payout_details || {};
        if (typeof d === 'string') { try { d = JSON.parse(d); } catch { d = {}; } }
        return {
          amount: row.amount,
          status: row.status,
          date: row.date,
          currency: row.currency,
          bank_name: d.bank_name || row.payment_system || null,
          account_number: d.account_number || null,
          account_holder_name: d.account_name || null,
          ifsc_code: d.bank_code || null,
          upi_id: d.upi_id || null,
          name: d.account_name || null
        };
      });

      // Map F2Pay withdrawals into the same fiat_withdrawals shape.
      const f2payWithdrawals = f2payWithdrawalsResult.rows.map(row => ({
        amount: row.amount,
        status: row.status,
        date: row.date,
        currency: row.currency,
        bank_name: 'Bank Transfer (F2Pay)',
        account_number: row.account_number,
        account_holder_name: row.account_holder_name,
        ifsc_code: row.ifsc,
        upi_id: null,
        name: row.account_holder_name
      }));

      // Merge fiat + A-Pay + F2Pay withdrawals, newest first
      const fiatWithdrawals = [
        ...fiatWithdrawalsResult.rows,
        ...apayWithdrawals,
        ...f2payWithdrawals
      ].sort((a, b) => new Date(b.date) - new Date(a.date));

      // Combine results and send response
      res.json({
        withdrawals: withdrawalsResult.rows,
        fiatWithdrawals,
        apayWithdrawals,   // also exposed separately for the UI if needed
        f2payWithdrawals
      });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to fetch today's withdrawals" });
    }
  });

  // Get today's transactions (deposits and withdrawals)
  server.get('/today-transactions', guardAdmin('today-transactions'), async (req, res) => {
    try {
      const deposits = await pg.query(`
      SELECT * FROM deposits
      WHERE DATE(date) = CURRENT_DATE
    `);
      const withdrawals = await pool.query(`
      SELECT * FROM withdrawals
      WHERE DATE(date) = CURRENT_DATE
    `);
      res.json([...deposits.rows, ...withdrawals.rows]);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch today\'s transactions' });
    }
  });


  /**
   * Admin Dashboard API
   * Returns comprehensive statistics for admin dashboard with all amounts converted to USD:
   * - Total deposits (crypto, fiat, UPI, PayIn)
   * - Total withdrawals (crypto, fiat)
   * - Today's deposits and withdrawals (current date)
   * - Total number of users
   * - Today's new user registrations
   */
  // server.get('/api/admin/dashboard', async (req, res) => {
  //   try {
  //     const today = new Date();
  //     today.setHours(0, 0, 0, 0);
  //     const todayISO = today.toISOString();
  //     const yesterday = new Date(today);
  //     yesterday.setDate(today.getDate() - 1);
  //     const yesterdayISO = yesterday.toISOString();

  //     // Coin ID to currency mapping for ccdeposit
  //     const coinIdToCurrency = {
  //       1155: 'BTC',
  //       1161: 'ETH',
  //       1173: 'LTC',
  //       1169: 'BCH',
  //       1280: 'USDT',
  //       1482: 'TRX',
  //       1492: 'DOGE',
  //       1375: 'ADA',
  //       1331: 'XRP',
  //       1168: 'BNB',
  //       1282: 'USDC',
  //       1864: 'SHIB'
  //     };

  //     // Run all queries in parallel for better performance
  //     const [
  //       // User statistics
  //       totalUsersResult,
  //       todayUsersResult,

  //       // Total deposits from different sources (in USD)
  //       totalCryptoDepositsResult,
  //       totalFiatDepositsResult,
  //       totalApayDepositsResult,
  //       totalPayInTransactionsResult,

  //       // Previous total deposits (up to yesterday, in USD)
  //       prevTotalCryptoDepositsResult,
  //       prevTotalFiatDepositsResult,
  //       prevTotalApayDepositsResult,
  //       prevTotalPayInTransactionsResult,

  //       // Today's deposits (in USD)
  //       todayCryptoDepositsResult,
  //       todayFiatDepositsResult,
  //       todayApayDepositsResult,
  //       todayPayInTransactionsResult,

  //       // Total withdrawals (in USD)
  //       totalCryptoWithdrawalsResult,
  //       totalFiatWithdrawalsResult,

  //       // Previous total withdrawals (up to yesterday, in USD)
  //       prevTotalCryptoWithdrawalsResult,
  //       prevTotalFiatWithdrawalsResult,

  //       // Today's withdrawals (in USD)
  //       todayCryptoWithdrawalsResult,
  //       todayFiatWithdrawalsResult,
  //     ] = await Promise.all([
  //       // User statistics
  //       pg.query('SELECT COUNT(*) as count FROM users'),
  //       pg.query('SELECT COUNT(*) as count FROM users WHERE created >= $1', [todayISO]),

  //       // Total deposits from all sources (converted to USD)
  //       pg.query(`
  //         SELECT COALESCE(SUM(c.amount::numeric * e.usd_rate), 0) as total
  //         FROM ccdeposit c
  //         JOIN exchangerate e ON CASE
  //           WHEN c.coinid = 1155 THEN 'BTC'
  //           WHEN c.coinid = 1161 THEN 'ETH'
  //           WHEN c.coinid = 1173 THEN 'LTC'
  //           WHEN c.coinid = 1169 THEN 'BCH'
  //           WHEN c.coinid = 1280 THEN 'USDT'
  //           WHEN c.coinid = 1482 THEN 'TRX'
  //           WHEN c.coinid = 1492 THEN 'DOGE'
  //           WHEN c.coinid = 1375 THEN 'ADA'
  //           WHEN c.coinid = 1331 THEN 'XRP'
  //           WHEN c.coinid = 1168 THEN 'BNB'
  //           WHEN c.coinid = 1282 THEN 'USDC'
  //           WHEN c.coinid = 1864 THEN 'SHIB'
  //         END = e.currency
  //         WHERE c.status = 'Success'
  //       `),
  //       pg.query(`
  //         SELECT COALESCE(SUM(f.amount::numeric * e.usd_rate), 0) as total
  //         FROM fiat_deposits f
  //         JOIN exchangerate e ON f.currency = e.currency
  //         WHERE f.status = 'approved'
  //       `),
  //       pg.query(`
  //         SELECT COALESCE(SUM((CASE WHEN a.status = 'Success' AND a.paid_amount > 0 THEN a.paid_amount ELSE a.amount END)::numeric * e.usd_rate), 0) as total
  //         FROM apaydeposits a
  //         JOIN exchangerate e ON a.currency = e.currency
  //         WHERE a.status = 'Success'
  //       `),
  //       pg.query(`
  //         SELECT COALESCE(SUM(p.amount::numeric * e.usd_rate), 0) as total
  //         FROM pay_in_transactions p
  //         JOIN exchangerate e ON p.currency = e.currency
  //         WHERE p.status = 1
  //       `),

  //       // Previous total deposits (up to yesterday, in USD)
  //       pg.query(`
  //         SELECT COALESCE(SUM(c.amount::numeric * e.usd_rate), 0) as total
  //         FROM ccdeposit c
  //         JOIN exchangerate e ON CASE
  //           WHEN c.coinid = 1155 THEN 'BTC'
  //           WHEN c.coinid = 1161 THEN 'ETH'
  //           WHEN c.coinid = 1173 THEN 'LTC'
  //           WHEN c.coinid = 1169 THEN 'BCH'
  //           WHEN c.coinid = 1280 THEN 'USDT'
  //           WHEN c.coinid = 1482 THEN 'TRX'
  //           WHEN c.coinid = 1492 THEN 'DOGE'
  //           WHEN c.coinid = 1375 THEN 'ADA'
  //           WHEN c.coinid = 1331 THEN 'XRP'
  //           WHEN c.coinid = 1168 THEN 'BNB'
  //           WHEN c.coinid = 1282 THEN 'USDC'
  //           WHEN c.coinid = 1864 THEN 'SHIB'
  //         END = e.currency
  //         WHERE c.status = 'Success' AND c.created_at < $1
  //       `, [todayISO]),
  //       pg.query(`
  //         SELECT COALESCE(SUM(f.amount::numeric * e.usd_rate), 0) as total
  //         FROM fiat_deposits f
  //         JOIN exchangerate e ON f.currency = e.currency
  //         WHERE f.status = 'approved' AND f.created_at < $1
  //       `, [todayISO]),
  //       pg.query(`
  //         SELECT COALESCE(SUM((CASE WHEN a.status = 'Success' AND a.paid_amount > 0 THEN a.paid_amount ELSE a.amount END)::numeric * e.usd_rate), 0) as total
  //         FROM apaydeposits a
  //         JOIN exchangerate e ON a.currency = e.currency
  //         WHERE a.status = 'Success' AND a.created_at < $1
  //       `, [todayISO]),
  //       pg.query(`
  //         SELECT COALESCE(SUM(p.amount::numeric * e.usd_rate), 0) as total
  //         FROM pay_in_transactions p
  //         JOIN exchangerate e ON p.currency = e.currency
  //         WHERE p.status = 1 AND p.created_at < $1
  //       `, [todayISO]),

  //       // Today's deposits (in USD)
  //       pg.query(`
  //         SELECT COALESCE(SUM(c.amount::numeric * e.usd_rate), 0) as total, COUNT(*) as count
  //         FROM ccdeposit c
  //         JOIN exchangerate e ON CASE
  //           WHEN c.coinid = 1155 THEN 'BTC'
  //           WHEN c.coinid = 1161 THEN 'ETH'
  //           WHEN c.coinid = 1173 THEN 'LTC'
  //           WHEN c.coinid = 1169 THEN 'BCH'
  //           WHEN c.coinid = 1280 THEN 'USDT'
  //           WHEN c.coinid = 1482 THEN 'TRX'
  //           WHEN c.coinid = 1492 THEN 'DOGE'
  //           WHEN c.coinid = 1375 THEN 'ADA'
  //           WHEN c.coinid = 1331 THEN 'XRP'
  //           WHEN c.coinid = 1168 THEN 'BNB'
  //           WHEN c.coinid = 1282 THEN 'USDC'
  //           WHEN c.coinid = 1864 THEN 'SHIB'
  //         END = e.currency
  //         WHERE c.status = 'Success' AND c.created_at >= $1
  //       `, [todayISO]),
  //       pg.query(`
  //         SELECT COALESCE(SUM(f.amount::numeric * e.usd_rate), 0) as total, COUNT(*) as count
  //         FROM fiat_deposits f
  //         JOIN exchangerate e ON f.currency = e.currency
  //         WHERE f.status = 'approved' AND f.created_at >= $1
  //       `, [todayISO]),
  //       pg.query(`
  //         SELECT COALESCE(SUM((CASE WHEN a.status = 'Success' AND a.paid_amount > 0 THEN a.paid_amount ELSE a.amount END)::numeric * e.usd_rate), 0) as total, COUNT(*) as count
  //         FROM apaydeposits a
  //         JOIN exchangerate e ON a.currency = e.currency
  //         WHERE a.status = 'Success' AND a.created_at >= $1
  //       `, [todayISO]),
  //       pg.query(`
  //         SELECT COALESCE(SUM(p.amount::numeric * e.usd_rate), 0) as total, COUNT(*) as count
  //         FROM pay_in_transactions p
  //         JOIN exchangerate e ON p.currency = e.currency
  //         WHERE p.status = 1 AND p.created_at >= $1
  //       `, [todayISO]),

  //       // Total withdrawals (in USD)
  //       pg.query(`
  //         SELECT COALESCE(SUM(w.amount::numeric * e.usd_rate), 0) as total
  //         FROM withdrawals w
  //         JOIN exchangerate e ON UPPER(w.coin) = e.currency
  //         WHERE w.status = 'Done'
  //       `),
  //       pg.query(`
  //         SELECT COALESCE(SUM(f.amount::numeric * e.usd_rate), 0) as total
  //         FROM fiat_withdrawals f
  //         JOIN exchangerate e ON f.currency = e.currency
  //         WHERE f.status = 'Done'
  //       `),

  //       // Previous total withdrawals (up to yesterday, in USD)
  //       pg.query(`
  //         SELECT COALESCE(SUM(w.amount::numeric * e.usd_rate), 0) as total
  //         FROM withdrawals w
  //         JOIN exchangerate e ON UPPER(w.coin) = e.currency
  //         WHERE w.status = 'Done' AND w.date < $1
  //       `, [todayISO]),
  //       pg.query(`
  //         SELECT COALESCE(SUM(f.amount::numeric * e.usd_rate), 0) as total
  //         FROM fiat_withdrawals f
  //         JOIN exchangerate e ON f.currency = e.currency
  //         WHERE f.status = 'Done' AND f.date < $1
  //       `, [todayISO]),

  //       // Today's withdrawals (in USD)
  //       pg.query(`
  //         SELECT COALESCE(SUM(w.amount::numeric * e.usd_rate), 0) as total, COUNT(*) as count
  //         FROM withdrawals w
  //         JOIN exchangerate e ON UPPER(w.coin) = e.currency
  //         WHERE w.status = 'Done' AND w.date >= $1
  //       `, [todayISO]),
  //       pg.query(`
  //         SELECT COALESCE(SUM(f.amount::numeric * e.usd_rate), 0) as total, COUNT(*) as count
  //         FROM fiat_withdrawals f
  //         JOIN exchangerate e ON f.currency = e.currency
  //         WHERE f.status = 'Done' AND f.date >= $1
  //       `, [todayISO]),
  //     ]);

  //     // Calculate totals (all in USD)
  //     const totalDeposits = parseFloat(totalCryptoDepositsResult.rows[0].total) +
  //                           parseFloat(totalFiatDepositsResult.rows[0].total) +
  //                           parseFloat(totalApayDepositsResult.rows[0].total) +
  //                           parseFloat(totalPayInTransactionsResult.rows[0].total);

  //     const prevTotalDeposits = parseFloat(prevTotalCryptoDepositsResult.rows[0].total) +
  //                               parseFloat(prevTotalFiatDepositsResult.rows[0].total) +
  //                               parseFloat(prevTotalApayDepositsResult.rows[0].total) +
  //                               parseFloat(prevTotalPayInTransactionsResult.rows[0].total);

  //     const totalWithdrawals = parseFloat(totalCryptoWithdrawalsResult.rows[0].total) +
  //                              parseFloat(totalFiatWithdrawalsResult.rows[0].total);

  //     const prevTotalWithdrawals = parseFloat(prevTotalCryptoWithdrawalsResult.rows[0].total) +
  //                                  parseFloat(prevTotalFiatWithdrawalsResult.rows[0].total);

  //     const todayDepositsAmount = parseFloat(todayCryptoDepositsResult.rows[0].total) +
  //                                 parseFloat(todayFiatDepositsResult.rows[0].total) +
  //                                 parseFloat(todayApayDepositsResult.rows[0].total) +
  //                                 parseFloat(todayPayInTransactionsResult.rows[0].total);

  //     const todayDepositsCount = parseInt(todayCryptoDepositsResult.rows[0].count) +
  //                               parseInt(todayFiatDepositsResult.rows[0].count) +
  //                               parseInt(todayApayDepositsResult.rows[0].count) +
  //                               parseInt(todayPayInTransactionsResult.rows[0].count);

  //     const todayWithdrawalsAmount = parseFloat(todayCryptoWithdrawalsResult.rows[0].total) +
  //                                    parseFloat(todayFiatWithdrawalsResult.rows[0].total);

  //     const todayWithdrawalsCount = parseInt(todayCryptoWithdrawalsResult.rows[0].count) +
  //                                   parseInt(todayFiatWithdrawalsResult.rows[0].count);

  //     // Format and send response (all monetary values in USD)
  //     res.json({
  //       totalUsers: parseInt(totalUsersResult.rows[0].count),
  //       previousTotalUsers: parseInt(totalUsersResult.rows[0].count) - parseInt(todayUsersResult.rows[0].count),
  //       newUsersToday: parseInt(todayUsersResult.rows[0].count),

  //       deposits: {
  //         total: totalDeposits.toFixed(2),
  //         previousTotal: prevTotalDeposits.toFixed(2),
  //         breakdown: {
  //           crypto: parseFloat(totalCryptoDepositsResult.rows[0].total).toFixed(2),
  //           fiat: parseFloat(totalFiatDepositsResult.rows[0].total).toFixed(2),
  //           upi: parseFloat(totalApayDepositsResult.rows[0].total).toFixed(2),
  //           payIn: parseFloat(totalPayInTransactionsResult.rows[0].total).toFixed(2)
  //         },
  //         today: {
  //           amount: todayDepositsAmount.toFixed(2),
  //           count: todayDepositsCount,
  //           breakdown: {
  //             crypto: {
  //               amount: parseFloat(todayCryptoDepositsResult.rows[0].total).toFixed(2),
  //               count: parseInt(todayCryptoDepositsResult.rows[0].count)
  //             },
  //             fiat: {
  //               amount: parseFloat(todayFiatDepositsResult.rows[0].total).toFixed(2),
  //               count: parseInt(todayFiatDepositsResult.rows[0].count)
  //             },
  //             upi: {
  //               amount: parseFloat(todayApayDepositsResult.rows[0].total).toFixed(2),
  //               count: parseInt(todayApayDepositsResult.rows[0].count)
  //             },
  //             payIn: {
  //               amount: parseFloat(todayPayInTransactionsResult.rows[0].total).toFixed(2),
  //               count: parseInt(todayPayInTransactionsResult.rows[0].count)
  //             }
  //           }
  //         }
  //       },

  //       withdrawals: {
  //         total: totalWithdrawals.toFixed(2),
  //         previousTotal: prevTotalWithdrawals.toFixed(2),
  //         breakdown: {
  //           crypto: parseFloat(totalCryptoWithdrawalsResult.rows[0].total).toFixed(2),
  //           fiat: parseFloat(totalFiatWithdrawalsResult.rows[0].total).toFixed(2)
  //         },
  //         today: {
  //           amount: todayWithdrawalsAmount.toFixed(2),
  //           count: todayWithdrawalsCount,
  //           breakdown: {
  //             crypto: {
  //               amount: parseFloat(todayCryptoWithdrawalsResult.rows[0].total).toFixed(2),
  //               count: parseInt(todayCryptoWithdrawalsResult.rows[0].count)
  //             },
  //             fiat: {
  //               amount: parseFloat(todayFiatWithdrawalsResult.rows[0].total).toFixed(2),
  //               count: parseInt(todayFiatWithdrawalsResult.rows[0].count)
  //             }
  //           }
  //         }
  //       },

  //       financials: {
  //         netBalance: (totalDeposits - totalWithdrawals).toFixed(2),
  //         previousNetBalance: (prevTotalDeposits - prevTotalWithdrawals).toFixed(2),
  //         todayNetBalance: (todayDepositsAmount - todayWithdrawalsAmount).toFixed(2)
  //       },

  //       timestamp: new Date().toISOString(),
  //       date: new Date().toLocaleDateString()
  //     });
  //   } catch (error) {
  //     console.error('Error fetching admin dashboard data:', error);
  //     res.status(500).json({ 
  //       error: 'Failed to fetch dashboard data',
  //       details: error.toString()
  //     });
  //   }
  // });
  /**
   * Admin Dashboard API (old, amounts in USD)
   * Returns comprehensive statistics for admin dashboard with all amounts converted to USD:
   * - Total deposits (crypto, fiat, UPI, PayIn)
   * - Total withdrawals (crypto, fiat)
   * - Today's deposits and withdrawals (current date)
   * - Total number of users
   * - Today's new user registrations
   */
  server.get('/api/admin/dashboard-old', protectStaff, async (req, res) => {
    try {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const todayISO = today.toISOString();
      const yesterday = new Date(today);
      yesterday.setDate(today.getDate() - 1);
      const yesterdayISO = yesterday.toISOString();

      // Coin ID to currency mapping for ccdeposit
      const coinIdToCurrency = {
        1155: 'BTC',
        1161: 'ETH',
        1173: 'LTC',
        1169: 'BCH',
        1280: 'USDT',
        1482: 'TRX',
        1492: 'DOGE',
        1375: 'ADA',
        1331: 'XRP',
        1168: 'BNB',
        1282: 'USDC',
        1864: 'SHIB'
      };

      // Run all queries in parallel for better performance
      const [
        // User statistics
        totalUsersResult,
        todayUsersResult,

        // Total deposits from different sources (in USD)
        totalCryptoDepositsResult,
        totalFiatDepositsResult,
        totalApayDepositsResult,
        totalPayInTransactionsResult,
        totalF2payDepositsResult,

        // Previous total deposits (up to yesterday, in USD)
        prevTotalCryptoDepositsResult,
        prevTotalFiatDepositsResult,
        prevTotalApayDepositsResult,
        prevTotalPayInTransactionsResult,
        prevTotalF2payDepositsResult,

        // Today's deposits (in USD)
        todayCryptoDepositsResult,
        todayFiatDepositsResult,
        todayApayDepositsResult,
        todayPayInTransactionsResult,
        todayF2payDepositsResult,

        // Total withdrawals (in USD)
        totalCryptoWithdrawalsResult,
        totalFiatWithdrawalsResult,
        totalF2payWithdrawalsResult,

        // Previous total withdrawals (up to yesterday, in USD)
        prevTotalCryptoWithdrawalsResult,
        prevTotalFiatWithdrawalsResult,
        prevTotalF2payWithdrawalsResult,

        // Today's withdrawals (in USD)
        todayCryptoWithdrawalsResult,
        todayFiatWithdrawalsResult,
        todayF2payWithdrawalsResult,
      ] = await Promise.all([
        // User statistics
        pg.query('SELECT COUNT(*) as count FROM users'),
        pg.query('SELECT COUNT(*) as count FROM users WHERE created >= $1', [todayISO]),

        // Total deposits from all sources (converted to USD)
        pg.query(`
        SELECT COALESCE(SUM(c.amount::numeric * e.usd_rate), 0) as total
        FROM ccdeposit c
        JOIN exchangerate e ON CASE
          WHEN c.coinid = 1155 THEN 'BTC'
          WHEN c.coinid = 1161 THEN 'ETH'
          WHEN c.coinid = 1173 THEN 'LTC'
          WHEN c.coinid = 1169 THEN 'BCH'
          WHEN c.coinid = 1280 THEN 'USDT'
          WHEN c.coinid = 1482 THEN 'TRX'
          WHEN c.coinid = 1492 THEN 'DOGE'
          WHEN c.coinid = 1375 THEN 'ADA'
          WHEN c.coinid = 1331 THEN 'XRP'
          WHEN c.coinid = 1168 THEN 'BNB'
          WHEN c.coinid = 1282 THEN 'USDC'
          WHEN c.coinid = 1864 THEN 'SHIB'
        END = e.currency
        WHERE c.status = 'Success'
      `),
        pg.query(`
        SELECT COALESCE(SUM(f.amount::numeric * e.usd_rate), 0) as total
        FROM fiat_deposits f
        JOIN exchangerate e ON f.currency = e.currency
        WHERE f.status = 'approved'
      `),
        pg.query(`
        SELECT COALESCE(SUM((CASE WHEN a.status = 'Success' AND a.paid_amount > 0 THEN a.paid_amount ELSE a.amount END)::numeric * e.usd_rate), 0) as total
        FROM apaydeposits a
        JOIN exchangerate e ON a.currency = e.currency
        WHERE a.status = 'Success'
      `),
        pg.query(`
        SELECT COALESCE(SUM(p.amount::numeric * e.usd_rate), 0) as total
        FROM pay_in_transactions p
        JOIN exchangerate e ON p.currency = e.currency
        WHERE p.status = 1
      `),
        pg.query(`
        SELECT COALESCE(SUM(d.amount::numeric * e.usd_rate), 0) as total
        FROM f2paydeposits d
        JOIN exchangerate e ON d.currency = e.currency
        WHERE d.status = 'Success'
      `),

        // Previous total deposits (up to yesterday, in USD)
        pg.query(`
        SELECT COALESCE(SUM(c.amount::numeric * e.usd_rate), 0) as total
        FROM ccdeposit c
        JOIN exchangerate e ON CASE
          WHEN c.coinid = 1155 THEN 'BTC'
          WHEN c.coinid = 1161 THEN 'ETH'
          WHEN c.coinid = 1173 THEN 'LTC'
          WHEN c.coinid = 1169 THEN 'BCH'
          WHEN c.coinid = 1280 THEN 'USDT'
          WHEN c.coinid = 1482 THEN 'TRX'
          WHEN c.coinid = 1492 THEN 'DOGE'
          WHEN c.coinid = 1375 THEN 'ADA'
          WHEN c.coinid = 1331 THEN 'XRP'
          WHEN c.coinid = 1168 THEN 'BNB'
          WHEN c.coinid = 1282 THEN 'USDC'
          WHEN c.coinid = 1864 THEN 'SHIB'
        END = e.currency
        WHERE c.status = 'Success' AND c.created_at < $1
      `, [todayISO]),
        pg.query(`
        SELECT COALESCE(SUM(f.amount::numeric * e.usd_rate), 0) as total
        FROM fiat_deposits f
        JOIN exchangerate e ON f.currency = e.currency
        WHERE f.status = 'approved' AND f.created_at < $1
      `, [todayISO]),
        pg.query(`
        SELECT COALESCE(SUM((CASE WHEN a.status = 'Success' AND a.paid_amount > 0 THEN a.paid_amount ELSE a.amount END)::numeric * e.usd_rate), 0) as total
        FROM apaydeposits a
        JOIN exchangerate e ON a.currency = e.currency
        WHERE a.status = 'Success' AND a.created_at < $1
      `, [todayISO]),
        pg.query(`
        SELECT COALESCE(SUM(p.amount::numeric * e.usd_rate), 0) as total
        FROM pay_in_transactions p
        JOIN exchangerate e ON p.currency = e.currency
        WHERE p.status = 1 AND p.created_at < $1
      `, [todayISO]),
        pg.query(`
        SELECT COALESCE(SUM(d.amount::numeric * e.usd_rate), 0) as total
        FROM f2paydeposits d
        JOIN exchangerate e ON d.currency = e.currency
        WHERE d.status = 'Success' AND d.created_at < $1
      `, [todayISO]),

        // Today's deposits (in USD)
        pg.query(`
        SELECT COALESCE(SUM(c.amount::numeric * e.usd_rate), 0) as total, COUNT(*) as count
        FROM ccdeposit c
        JOIN exchangerate e ON CASE
          WHEN c.coinid = 1155 THEN 'BTC'
          WHEN c.coinid = 1161 THEN 'ETH'
          WHEN c.coinid = 1173 THEN 'LTC'
          WHEN c.coinid = 1169 THEN 'BCH'
          WHEN c.coinid = 1280 THEN 'USDT'
          WHEN c.coinid = 1482 THEN 'TRX'
          WHEN c.coinid = 1492 THEN 'DOGE'
          WHEN c.coinid = 1375 THEN 'ADA'
          WHEN c.coinid = 1331 THEN 'XRP'
          WHEN c.coinid = 1168 THEN 'BNB'
          WHEN c.coinid = 1282 THEN 'USDC'
          WHEN c.coinid = 1864 THEN 'SHIB'
        END = e.currency
        WHERE c.status = 'Success' AND c.created_at >= $1
      `, [todayISO]),
        pg.query(`
        SELECT COALESCE(SUM(f.amount::numeric * e.usd_rate), 0) as total, COUNT(*) as count
        FROM fiat_deposits f
        JOIN exchangerate e ON f.currency = e.currency
        WHERE f.status = 'approved' AND f.created_at >= $1
      `, [todayISO]),
        pg.query(`
        SELECT COALESCE(SUM((CASE WHEN a.status = 'Success' AND a.paid_amount > 0 THEN a.paid_amount ELSE a.amount END)::numeric * e.usd_rate), 0) as total, COUNT(*) as count
        FROM apaydeposits a
        JOIN exchangerate e ON a.currency = e.currency
        WHERE a.status = 'Success' AND a.created_at >= $1
      `, [todayISO]),
        pg.query(`
        SELECT COALESCE(SUM(p.amount::numeric * e.usd_rate), 0) as total, COUNT(*) as count
        FROM pay_in_transactions p
        JOIN exchangerate e ON p.currency = e.currency
        WHERE p.status = 1 AND p.created_at >= $1
      `, [todayISO]),
        pg.query(`
        SELECT COALESCE(SUM(d.amount::numeric * e.usd_rate), 0) as total, COUNT(*) as count
        FROM f2paydeposits d
        JOIN exchangerate e ON d.currency = e.currency
        WHERE d.status = 'Success' AND d.created_at >= $1
      `, [todayISO]),

        // Total withdrawals (in USD)
        pg.query(`
        SELECT COALESCE(SUM(w.amount::numeric * e.usd_rate), 0) as total
        FROM withdrawals w
        JOIN exchangerate e ON UPPER(w.coin) = e.currency
        WHERE w.status = 'Done'
      `),
        pg.query(`
        SELECT COALESCE(SUM(f.amount::numeric * e.usd_rate), 0) as total
        FROM fiat_withdrawals f
        JOIN exchangerate e ON f.currency = e.currency
        WHERE f.status = 'Done'
      `),
        pg.query(`
        SELECT COALESCE(SUM(w.amount::numeric * e.usd_rate), 0) as total
        FROM f2paywithdrawals w
        JOIN exchangerate e ON w.currency = e.currency
        WHERE w.status = 'Success'
      `),

        // Previous total withdrawals (up to yesterday, in USD)
        pg.query(`
        SELECT COALESCE(SUM(w.amount::numeric * e.usd_rate), 0) as total
        FROM withdrawals w
        JOIN exchangerate e ON UPPER(w.coin) = e.currency
        WHERE w.status = 'Done' AND w.date < $1
      `, [todayISO]),
        pg.query(`
        SELECT COALESCE(SUM(f.amount::numeric * e.usd_rate), 0) as total
        FROM fiat_withdrawals f
        JOIN exchangerate e ON f.currency = e.currency
        WHERE f.status = 'Done' AND f.date < $1
      `, [todayISO]),
        pg.query(`
        SELECT COALESCE(SUM(w.amount::numeric * e.usd_rate), 0) as total
        FROM f2paywithdrawals w
        JOIN exchangerate e ON w.currency = e.currency
        WHERE w.status = 'Success' AND w.created_at < $1
      `, [todayISO]),

        // Today's withdrawals (in USD)
        pg.query(`
        SELECT COALESCE(SUM(w.amount::numeric * e.usd_rate), 0) as total, COUNT(*) as count
        FROM withdrawals w
        JOIN exchangerate e ON UPPER(w.coin) = e.currency
        WHERE w.status = 'Done' AND w.date >= $1
      `, [todayISO]),
        pg.query(`
        SELECT COALESCE(SUM(f.amount::numeric * e.usd_rate), 0) as total, COUNT(*) as count
        FROM fiat_withdrawals f
        JOIN exchangerate e ON f.currency = e.currency
        WHERE f.status = 'Done' AND f.date >= $1
      `, [todayISO]),
        pg.query(`
        SELECT COALESCE(SUM(w.amount::numeric * e.usd_rate), 0) as total, COUNT(*) as count
        FROM f2paywithdrawals w
        JOIN exchangerate e ON w.currency = e.currency
        WHERE w.status = 'Success' AND w.created_at >= $1
      `, [todayISO]),
      ]);

      // Calculate totals (all in USD)
      const totalDeposits = parseFloat(totalCryptoDepositsResult.rows[0].total) +
        parseFloat(totalFiatDepositsResult.rows[0].total) +
        parseFloat(totalApayDepositsResult.rows[0].total) +
        parseFloat(totalPayInTransactionsResult.rows[0].total) +
        parseFloat(totalF2payDepositsResult.rows[0].total);

      const prevTotalDeposits = parseFloat(prevTotalCryptoDepositsResult.rows[0].total) +
        parseFloat(prevTotalFiatDepositsResult.rows[0].total) +
        parseFloat(prevTotalApayDepositsResult.rows[0].total) +
        parseFloat(prevTotalPayInTransactionsResult.rows[0].total) +
        parseFloat(prevTotalF2payDepositsResult.rows[0].total);

      const totalWithdrawals = parseFloat(totalCryptoWithdrawalsResult.rows[0].total) +
        parseFloat(totalFiatWithdrawalsResult.rows[0].total) +
        parseFloat(totalF2payWithdrawalsResult.rows[0].total);

      const prevTotalWithdrawals = parseFloat(prevTotalCryptoWithdrawalsResult.rows[0].total) +
        parseFloat(prevTotalFiatWithdrawalsResult.rows[0].total) +
        parseFloat(prevTotalF2payWithdrawalsResult.rows[0].total);

      const todayDepositsAmount = parseFloat(todayCryptoDepositsResult.rows[0].total) +
        parseFloat(todayFiatDepositsResult.rows[0].total) +
        parseFloat(todayApayDepositsResult.rows[0].total) +
        parseFloat(todayPayInTransactionsResult.rows[0].total) +
        parseFloat(todayF2payDepositsResult.rows[0].total);

      const todayDepositsCount = parseInt(todayCryptoDepositsResult.rows[0].count) +
        parseInt(todayFiatDepositsResult.rows[0].count) +
        parseInt(todayApayDepositsResult.rows[0].count) +
        parseInt(todayPayInTransactionsResult.rows[0].count) +
        parseInt(todayF2payDepositsResult.rows[0].count);

      const todayWithdrawalsAmount = parseFloat(todayCryptoWithdrawalsResult.rows[0].total) +
        parseFloat(todayFiatWithdrawalsResult.rows[0].total) +
        parseFloat(todayF2payWithdrawalsResult.rows[0].total);

      const todayWithdrawalsCount = parseInt(todayCryptoWithdrawalsResult.rows[0].count) +
        parseInt(todayFiatWithdrawalsResult.rows[0].count) +
        parseInt(todayF2payWithdrawalsResult.rows[0].count);

      // Calculate fiat breakdown for today (combining fiat_deposits, apaydeposits, pay_in_transactions, and f2paydeposits)
      const todayFiatDepositsAmount = parseFloat(todayFiatDepositsResult.rows[0].total) +
        parseFloat(todayApayDepositsResult.rows[0].total) +
        parseFloat(todayPayInTransactionsResult.rows[0].total) +
        parseFloat(todayF2payDepositsResult.rows[0].total);

      const todayFiatDepositsCount = parseInt(todayFiatDepositsResult.rows[0].count) +
        parseInt(todayApayDepositsResult.rows[0].count) +
        parseInt(todayPayInTransactionsResult.rows[0].count) +
        parseInt(todayF2payDepositsResult.rows[0].count);

      // Calculate fiat breakdown for total (combining fiat_deposits, apaydeposits, pay_in_transactions, and f2paydeposits)
      const totalFiatDepositsAmount = parseFloat(totalFiatDepositsResult.rows[0].total) +
        parseFloat(totalApayDepositsResult.rows[0].total) +
        parseFloat(totalPayInTransactionsResult.rows[0].total) +
        parseFloat(totalF2payDepositsResult.rows[0].total);

      // Fiat withdrawals breakdown (fiat_withdrawals + f2paywithdrawals)
      const totalFiatWithdrawalsAmount = parseFloat(totalFiatWithdrawalsResult.rows[0].total) +
        parseFloat(totalF2payWithdrawalsResult.rows[0].total);

      const todayFiatWithdrawalsAmount = parseFloat(todayFiatWithdrawalsResult.rows[0].total) +
        parseFloat(todayF2payWithdrawalsResult.rows[0].total);

      const todayFiatWithdrawalsCount = parseInt(todayFiatWithdrawalsResult.rows[0].count) +
        parseInt(todayF2payWithdrawalsResult.rows[0].count);

      // Format and send response (all monetary values in USD)
      res.json({
        totalUsers: parseInt(totalUsersResult.rows[0].count),
        previousTotalUsers: parseInt(totalUsersResult.rows[0].count) - parseInt(todayUsersResult.rows[0].count),
        newUsersToday: parseInt(todayUsersResult.rows[0].count),

        deposits: {
          total: totalDeposits.toFixed(2),
          previousTotal: prevTotalDeposits.toFixed(2),
          breakdown: {
            crypto: parseFloat(totalCryptoDepositsResult.rows[0].total).toFixed(2),
            fiat: totalFiatDepositsAmount.toFixed(2)
          },
          today: {
            amount: todayDepositsAmount.toFixed(2),
            count: todayDepositsCount,
            breakdown: {
              crypto: {
                amount: parseFloat(todayCryptoDepositsResult.rows[0].total).toFixed(2),
                count: parseInt(todayCryptoDepositsResult.rows[0].count)
              },
              fiat: {
                amount: todayFiatDepositsAmount.toFixed(2),
                count: todayFiatDepositsCount
              }
            }
          }
        },

        withdrawals: {
          total: totalWithdrawals.toFixed(2),
          previousTotal: prevTotalWithdrawals.toFixed(2),
          breakdown: {
            crypto: parseFloat(totalCryptoWithdrawalsResult.rows[0].total).toFixed(2),
            fiat: totalFiatWithdrawalsAmount.toFixed(2)
          },
          today: {
            amount: todayWithdrawalsAmount.toFixed(2),
            count: todayWithdrawalsCount,
            breakdown: {
              crypto: {
                amount: parseFloat(todayCryptoWithdrawalsResult.rows[0].total).toFixed(2),
                count: parseInt(todayCryptoWithdrawalsResult.rows[0].count)
              },
              fiat: {
                amount: todayFiatWithdrawalsAmount.toFixed(2),
                count: todayFiatWithdrawalsCount
              }
            }
          }
        },

        financials: {
          netBalance: (totalDeposits - totalWithdrawals).toFixed(2),
          previousNetBalance: (prevTotalDeposits - prevTotalWithdrawals).toFixed(2),
          todayNetBalance: (todayDepositsAmount - todayWithdrawalsAmount).toFixed(2)
        },

        timestamp: new Date().toISOString(),
        date: new Date().toLocaleDateString()
      });
    } catch (error) {
      console.error('Error fetching admin dashboard data:', error);
      res.status(500).json({
        error: 'Failed to fetch dashboard data',
        details: error.toString()
      });
    }
  });
  /**
   * Admin Dashboard API
   * Returns comprehensive statistics for admin dashboard with all amounts converted to INR:
   * - Total deposits (crypto, fiat, UPI, PayIn)
   * - Total withdrawals (crypto, fiat)
   * - Today's deposits and withdrawals (current date)
   * - Total number of users
   * - Today's new user registrations
   */
  server.get('/api/admin/dashboard', protectStaff, async (req, res) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayISO = today.toISOString();

    const yesterday = new Date(today);
    yesterday.setDate(today.getDate() - 1);
    const yesterdayISO = yesterday.toISOString();

    // Coin ID to currency mapping for ccdeposit
    const coinIdToCurrency = {
      1155: 'BTC',
      1161: 'ETH',
      1173: 'LTC',
      1169: 'BCH',
      1280: 'USDT',
      1482: 'TRX',
      1492: 'DOGE',
      1375: 'ADA',
      1331: 'XRP',
      1168: 'BNB',
      1282: 'USDC',
      1864: 'SHIB'
    };

    // Run all queries in parallel for better performance
    const [
      // User statistics
      totalUsersResult,
      todayUsersResult,

      // Total deposits from different sources (in USD)
      totalCryptoDepositsResult,
      totalFiatDepositsResult,
      totalApayDepositsResult,
      totalPayInTransactionsResult,
      totalF2payDepositsResult,

      // Previous total deposits (up to yesterday, in USD)
      prevTotalCryptoDepositsResult,
      prevTotalFiatDepositsResult,
      prevTotalApayDepositsResult,
      prevTotalPayInTransactionsResult,
      prevTotalF2payDepositsResult,

      // Today's deposits (in USD)
      todayCryptoDepositsResult,
      todayFiatDepositsResult,
      todayApayDepositsResult,
      todayPayInTransactionsResult,
      todayF2payDepositsResult,

      // Total withdrawals (in USD)
      totalCryptoWithdrawalsResult,
      totalFiatWithdrawalsResult,
      totalF2payWithdrawalsResult,
      totalApayWithdrawalsResult,

      // Previous total withdrawals (up to yesterday, in USD)
      prevTotalCryptoWithdrawalsResult,
      prevTotalFiatWithdrawalsResult,
      prevTotalF2payWithdrawalsResult,
      prevTotalApayWithdrawalsResult,

      // Today's withdrawals (in USD)
      todayCryptoWithdrawalsResult,
      todayFiatWithdrawalsResult,
      todayF2payWithdrawalsResult,
      todayApayWithdrawalsResult,

      // INR exchange rate
      inrRateResult,
    ] = await Promise.all([

      // User statistics
      pg.query('SELECT COUNT(*) as count FROM users WHERE NOT COALESCE(is_demo, false)'),
      pg.query(
        'SELECT COUNT(*) as count FROM users WHERE created >= $1 AND NOT COALESCE(is_demo, false)',
        [todayISO]
      ),

      // =========================================================
      // TOTAL DEPOSITS
      // =========================================================

      // Crypto deposits
      pg.query(`
        SELECT COALESCE(SUM(c.amount::numeric * e.usd_rate), 0) as total
        FROM ccdeposit c
        JOIN exchangerate e ON CASE
          WHEN c.coinid = 1155 THEN 'BTC'
          WHEN c.coinid = 1161 THEN 'ETH'
          WHEN c.coinid = 1173 THEN 'LTC'
          WHEN c.coinid = 1169 THEN 'BCH'
          WHEN c.coinid = 1280 THEN 'USDT'
          WHEN c.coinid = 1482 THEN 'TRX'
          WHEN c.coinid = 1492 THEN 'DOGE'
          WHEN c.coinid = 1375 THEN 'ADA'
          WHEN c.coinid = 1331 THEN 'XRP'
          WHEN c.coinid = 1168 THEN 'BNB'
          WHEN c.coinid = 1282 THEN 'USDC'
          WHEN c.coinid = 1864 THEN 'SHIB'
        END = UPPER(e.currency)
        WHERE c.status = 'Success'
      `),

      // Fiat deposits
      pg.query(`
        SELECT COALESCE(SUM(f.amount::numeric * e.usd_rate), 0) as total
        FROM fiat_deposits f
        JOIN exchangerate e ON UPPER(f.currency) = UPPER(e.currency)
        WHERE f.status = 'approved'
      `),

      // Apay deposits
      pg.query(`
        SELECT COALESCE(
          SUM(
            (
              CASE
                WHEN a.status = 'Success' AND a.paid_amount > 0
                THEN a.paid_amount
                ELSE a.amount
              END
            )::numeric * e.usd_rate
          ),
          0
        ) as total
        FROM apaydeposits a
        JOIN exchangerate e ON UPPER(a.currency) = UPPER(e.currency)
        WHERE a.status = 'Success'
      `),

      // Pay-in transactions
      pg.query(`
        SELECT COALESCE(SUM(p.amount::numeric * e.usd_rate), 0) as total
        FROM pay_in_transactions p
        JOIN exchangerate e ON UPPER(p.currency) = UPPER(e.currency)
        WHERE p.status = 1
      `),

      // F2Pay deposits
      pg.query(`
        SELECT COALESCE(SUM(d.amount::numeric * e.usd_rate), 0) as total
        FROM f2paydeposits d
        JOIN exchangerate e ON UPPER(d.currency) = UPPER(e.currency)
        WHERE d.status = 'Success'
      `),

      // =========================================================
      // PREVIOUS TOTAL DEPOSITS
      // =========================================================

      // Crypto deposits
      pg.query(`
        SELECT COALESCE(SUM(c.amount::numeric * e.usd_rate), 0) as total
        FROM ccdeposit c
        JOIN exchangerate e ON CASE
          WHEN c.coinid = 1155 THEN 'BTC'
          WHEN c.coinid = 1161 THEN 'ETH'
          WHEN c.coinid = 1173 THEN 'LTC'
          WHEN c.coinid = 1169 THEN 'BCH'
          WHEN c.coinid = 1280 THEN 'USDT'
          WHEN c.coinid = 1482 THEN 'TRX'
          WHEN c.coinid = 1492 THEN 'DOGE'
          WHEN c.coinid = 1375 THEN 'ADA'
          WHEN c.coinid = 1331 THEN 'XRP'
          WHEN c.coinid = 1168 THEN 'BNB'
          WHEN c.coinid = 1282 THEN 'USDC'
          WHEN c.coinid = 1864 THEN 'SHIB'
        END = UPPER(e.currency)
        WHERE c.status = 'Success'
          AND c.created_at < $1
      `, [todayISO]),

      // Fiat deposits
      pg.query(`
        SELECT COALESCE(SUM(f.amount::numeric * e.usd_rate), 0) as total
        FROM fiat_deposits f
        JOIN exchangerate e ON UPPER(f.currency) = UPPER(e.currency)
        WHERE f.status = 'approved'
          AND f.created_at < $1
      `, [todayISO]),

      // Apay deposits
      pg.query(`
        SELECT COALESCE(
          SUM(
            (
              CASE
                WHEN a.status = 'Success' AND a.paid_amount > 0
                THEN a.paid_amount
                ELSE a.amount
              END
            )::numeric * e.usd_rate
          ),
          0
        ) as total
        FROM apaydeposits a
        JOIN exchangerate e ON UPPER(a.currency) = UPPER(e.currency)
        WHERE a.status = 'Success'
          AND a.created_at < $1
      `, [todayISO]),

      // Pay-in transactions
      pg.query(`
        SELECT COALESCE(SUM(p.amount::numeric * e.usd_rate), 0) as total
        FROM pay_in_transactions p
        JOIN exchangerate e ON UPPER(p.currency) = UPPER(e.currency)
        WHERE p.status = 1
          AND p.created_at < $1
      `, [todayISO]),

      // F2Pay deposits
      pg.query(`
        SELECT COALESCE(SUM(d.amount::numeric * e.usd_rate), 0) as total
        FROM f2paydeposits d
        JOIN exchangerate e ON UPPER(d.currency) = UPPER(e.currency)
        WHERE d.status = 'Success'
          AND d.created_at < $1
      `, [todayISO]),

      // =========================================================
      // TODAY'S DEPOSITS
      // =========================================================

      // Crypto deposits
      pg.query(`
        SELECT
          COALESCE(SUM(c.amount::numeric * e.usd_rate), 0) as total,
          COUNT(*) as count
        FROM ccdeposit c
        JOIN exchangerate e ON CASE
          WHEN c.coinid = 1155 THEN 'BTC'
          WHEN c.coinid = 1161 THEN 'ETH'
          WHEN c.coinid = 1173 THEN 'LTC'
          WHEN c.coinid = 1169 THEN 'BCH'
          WHEN c.coinid = 1280 THEN 'USDT'
          WHEN c.coinid = 1482 THEN 'TRX'
          WHEN c.coinid = 1492 THEN 'DOGE'
          WHEN c.coinid = 1375 THEN 'ADA'
          WHEN c.coinid = 1331 THEN 'XRP'
          WHEN c.coinid = 1168 THEN 'BNB'
          WHEN c.coinid = 1282 THEN 'USDC'
          WHEN c.coinid = 1864 THEN 'SHIB'
        END = UPPER(e.currency)
        WHERE c.status = 'Success'
          AND c.created_at >= $1
      `, [todayISO]),

      // Fiat deposits
      pg.query(`
        SELECT
          COALESCE(SUM(f.amount::numeric * e.usd_rate), 0) as total,
          COUNT(*) as count
        FROM fiat_deposits f
        JOIN exchangerate e ON UPPER(f.currency) = UPPER(e.currency)
        WHERE f.status = 'approved'
          AND f.created_at >= $1
      `, [todayISO]),

      // Apay deposits
      pg.query(`
        SELECT
          COALESCE(
            SUM(
              (
                CASE
                  WHEN a.status = 'Success' AND a.paid_amount > 0
                  THEN a.paid_amount
                  ELSE a.amount
                END
              )::numeric * e.usd_rate
            ),
            0
          ) as total,
          COUNT(*) as count
        FROM apaydeposits a
        JOIN exchangerate e ON UPPER(a.currency) = UPPER(e.currency)
        WHERE a.status = 'Success'
          AND a.created_at >= $1
      `, [todayISO]),

      // Pay-in transactions
      pg.query(`
        SELECT
          COALESCE(SUM(p.amount::numeric * e.usd_rate), 0) as total,
          COUNT(*) as count
        FROM pay_in_transactions p
        JOIN exchangerate e ON UPPER(p.currency) = UPPER(e.currency)
        WHERE p.status = 1
          AND p.created_at >= $1
      `, [todayISO]),

      // F2Pay deposits
      pg.query(`
        SELECT
          COALESCE(SUM(d.amount::numeric * e.usd_rate), 0) as total,
          COUNT(*) as count
        FROM f2paydeposits d
        JOIN exchangerate e ON UPPER(d.currency) = UPPER(e.currency)
        WHERE d.status = 'Success'
          AND d.created_at >= $1
      `, [todayISO]),

      // =========================================================
      // TOTAL WITHDRAWALS
      // =========================================================

      // Crypto withdrawals
      pg.query(`
        SELECT COALESCE(SUM(w.amount::numeric * e.usd_rate), 0) as total
        FROM withdrawals w
        JOIN exchangerate e ON UPPER(w.coin) = UPPER(e.currency)
        WHERE w.status = 'Done'
      `),

      // Fiat withdrawals
      pg.query(`
        SELECT COALESCE(SUM(f.amount::numeric * e.usd_rate), 0) as total
        FROM fiat_withdrawals f
        JOIN exchangerate e ON UPPER(f.currency) = UPPER(e.currency)
        WHERE f.status = 'Done'
      `),

      // F2Pay withdrawals
      pg.query(`
        SELECT COALESCE(SUM(w.amount::numeric * e.usd_rate), 0) as total
        FROM f2paywithdrawals w
        JOIN exchangerate e ON UPPER(w.currency) = UPPER(e.currency)
        WHERE w.status = 'Success'
      `),

      // Apay withdrawals
      pg.query(`
        SELECT COALESCE(SUM(w.amount::numeric * e.usd_rate), 0) as total
        FROM apaywithdrawals w
        JOIN exchangerate e ON UPPER(w.currency) = UPPER(e.currency)
        WHERE w.status = 'Success'
      `),

      // =========================================================
      // PREVIOUS TOTAL WITHDRAWALS
      // =========================================================

      // Crypto withdrawals
      pg.query(`
        SELECT COALESCE(SUM(w.amount::numeric * e.usd_rate), 0) as total
        FROM withdrawals w
        JOIN exchangerate e ON UPPER(w.coin) = UPPER(e.currency)
        WHERE w.status = 'Done'
          AND w.date < $1
      `, [todayISO]),

      // Fiat withdrawals
      pg.query(`
        SELECT COALESCE(SUM(f.amount::numeric * e.usd_rate), 0) as total
        FROM fiat_withdrawals f
        JOIN exchangerate e ON UPPER(f.currency) = UPPER(e.currency)
        WHERE f.status = 'Done'
          AND f.date < $1
      `, [todayISO]),

      // F2Pay withdrawals
      pg.query(`
        SELECT COALESCE(SUM(w.amount::numeric * e.usd_rate), 0) as total
        FROM f2paywithdrawals w
        JOIN exchangerate e ON UPPER(w.currency) = UPPER(e.currency)
        WHERE w.status = 'Success'
          AND w.created_at < $1
      `, [todayISO]),

      // Apay withdrawals
      pg.query(`
        SELECT COALESCE(SUM(w.amount::numeric * e.usd_rate), 0) as total
        FROM apaywithdrawals w
        JOIN exchangerate e ON UPPER(w.currency) = UPPER(e.currency)
        WHERE w.status = 'Success'
          AND w.created_at < $1
      `, [todayISO]),

      // =========================================================
      // TODAY'S WITHDRAWALS
      // =========================================================

      // Crypto withdrawals
      pg.query(`
        SELECT
          COALESCE(SUM(w.amount::numeric * e.usd_rate), 0) as total,
          COUNT(*) as count
        FROM withdrawals w
        JOIN exchangerate e ON UPPER(w.coin) = UPPER(e.currency)
        WHERE w.status = 'Done'
          AND w.date >= $1
      `, [todayISO]),

      // Fiat withdrawals
      pg.query(`
        SELECT
          COALESCE(SUM(f.amount::numeric * e.usd_rate), 0) as total,
          COUNT(*) as count
        FROM fiat_withdrawals f
        JOIN exchangerate e ON UPPER(f.currency) = UPPER(e.currency)
        WHERE f.status = 'Done'
          AND f.date >= $1
      `, [todayISO]),

      // F2Pay withdrawals
      pg.query(`
        SELECT
          COALESCE(SUM(w.amount::numeric * e.usd_rate), 0) as total,
          COUNT(*) as count
        FROM f2paywithdrawals w
        JOIN exchangerate e ON UPPER(w.currency) = UPPER(e.currency)
        WHERE w.status = 'Success'
          AND w.created_at >= $1
      `, [todayISO]),

      // Apay withdrawals
      pg.query(`
        SELECT
          COALESCE(SUM(w.amount::numeric * e.usd_rate), 0) as total,
          COUNT(*) as count
        FROM apaywithdrawals w
        JOIN exchangerate e ON UPPER(w.currency) = UPPER(e.currency)
        WHERE w.status = 'Success'
          AND w.created_at >= $1
      `, [todayISO]),

      // =========================================================
      // INR EXCHANGE RATE
      // =========================================================

      pg.query(`
        SELECT usd_rate
        FROM exchangerate
        WHERE UPPER(currency) = 'INR'
      `),
    ]);

    // USD -> INR conversion
    // usd_rate = value of 1 INR in USD
    const inrUsdRate = parseFloat(inrRateResult.rows[0]?.usd_rate);

    if (!inrUsdRate) {
      throw new Error('INR rate not found in exchangerate');
    }

    const toINR = (usd) => (usd / inrUsdRate).toFixed(2);

    // =========================================================
    // CALCULATE TOTAL DEPOSITS
    // =========================================================

    const totalDeposits =
      parseFloat(totalCryptoDepositsResult.rows[0].total) +
      parseFloat(totalFiatDepositsResult.rows[0].total) +
      parseFloat(totalApayDepositsResult.rows[0].total) +
      parseFloat(totalPayInTransactionsResult.rows[0].total) +
      parseFloat(totalF2payDepositsResult.rows[0].total);

    const prevTotalDeposits =
      parseFloat(prevTotalCryptoDepositsResult.rows[0].total) +
      parseFloat(prevTotalFiatDepositsResult.rows[0].total) +
      parseFloat(prevTotalApayDepositsResult.rows[0].total) +
      parseFloat(prevTotalPayInTransactionsResult.rows[0].total) +
      parseFloat(prevTotalF2payDepositsResult.rows[0].total);

    // =========================================================
    // CALCULATE TOTAL WITHDRAWALS
    // =========================================================

    const totalWithdrawals =
      parseFloat(totalCryptoWithdrawalsResult.rows[0].total) +
      parseFloat(totalFiatWithdrawalsResult.rows[0].total) +
      parseFloat(totalF2payWithdrawalsResult.rows[0].total) +
      parseFloat(totalApayWithdrawalsResult.rows[0].total);

    const prevTotalWithdrawals =
      parseFloat(prevTotalCryptoWithdrawalsResult.rows[0].total) +
      parseFloat(prevTotalFiatWithdrawalsResult.rows[0].total) +
      parseFloat(prevTotalF2payWithdrawalsResult.rows[0].total) +
      parseFloat(prevTotalApayWithdrawalsResult.rows[0].total);

    // =========================================================
    // TODAY'S DEPOSITS
    // =========================================================

    const todayDepositsAmount =
      parseFloat(todayCryptoDepositsResult.rows[0].total) +
      parseFloat(todayFiatDepositsResult.rows[0].total) +
      parseFloat(todayApayDepositsResult.rows[0].total) +
      parseFloat(todayPayInTransactionsResult.rows[0].total) +
      parseFloat(todayF2payDepositsResult.rows[0].total);

    const todayDepositsCount =
      parseInt(todayCryptoDepositsResult.rows[0].count) +
      parseInt(todayFiatDepositsResult.rows[0].count) +
      parseInt(todayApayDepositsResult.rows[0].count) +
      parseInt(todayPayInTransactionsResult.rows[0].count) +
      parseInt(todayF2payDepositsResult.rows[0].count);

    // =========================================================
    // TODAY'S WITHDRAWALS
    // =========================================================

    const todayWithdrawalsAmount =
      parseFloat(todayCryptoWithdrawalsResult.rows[0].total) +
      parseFloat(todayFiatWithdrawalsResult.rows[0].total) +
      parseFloat(todayF2payWithdrawalsResult.rows[0].total) +
      parseFloat(todayApayWithdrawalsResult.rows[0].total);

    const todayWithdrawalsCount =
      parseInt(todayCryptoWithdrawalsResult.rows[0].count) +
      parseInt(todayFiatWithdrawalsResult.rows[0].count) +
      parseInt(todayF2payWithdrawalsResult.rows[0].count) +
      parseInt(todayApayWithdrawalsResult.rows[0].count);

    // =========================================================
    // FIAT DEPOSITS BREAKDOWN
    // fiat_deposits + apaydeposits + pay_in_transactions + f2paydeposits
    // =========================================================

    const todayFiatDepositsAmount =
      parseFloat(todayFiatDepositsResult.rows[0].total) +
      parseFloat(todayApayDepositsResult.rows[0].total) +
      parseFloat(todayPayInTransactionsResult.rows[0].total) +
      parseFloat(todayF2payDepositsResult.rows[0].total);

    const todayFiatDepositsCount =
      parseInt(todayFiatDepositsResult.rows[0].count) +
      parseInt(todayApayDepositsResult.rows[0].count) +
      parseInt(todayPayInTransactionsResult.rows[0].count) +
      parseInt(todayF2payDepositsResult.rows[0].count);

    const totalFiatDepositsAmount =
      parseFloat(totalFiatDepositsResult.rows[0].total) +
      parseFloat(totalApayDepositsResult.rows[0].total) +
      parseFloat(totalPayInTransactionsResult.rows[0].total) +
      parseFloat(totalF2payDepositsResult.rows[0].total);

    // =========================================================
    // FIAT WITHDRAWALS BREAKDOWN
    // fiat_withdrawals + f2paywithdrawals + apaywithdrawals
    // =========================================================

    const totalFiatWithdrawalsAmount =
      parseFloat(totalFiatWithdrawalsResult.rows[0].total) +
      parseFloat(totalF2payWithdrawalsResult.rows[0].total) +
      parseFloat(totalApayWithdrawalsResult.rows[0].total);

    const todayFiatWithdrawalsAmount =
      parseFloat(todayFiatWithdrawalsResult.rows[0].total) +
      parseFloat(todayF2payWithdrawalsResult.rows[0].total) +
      parseFloat(todayApayWithdrawalsResult.rows[0].total);

    const todayFiatWithdrawalsCount =
      parseInt(todayFiatWithdrawalsResult.rows[0].count) +
      parseInt(todayF2payWithdrawalsResult.rows[0].count) +
      parseInt(todayApayWithdrawalsResult.rows[0].count);

    // =========================================================
    // RESPONSE
    // =========================================================

    res.json({
      totalUsers: parseInt(totalUsersResult.rows[0].count),

      previousTotalUsers:
        parseInt(totalUsersResult.rows[0].count) -
        parseInt(todayUsersResult.rows[0].count),

      newUsersToday: parseInt(todayUsersResult.rows[0].count),

      deposits: {
        total: toINR(totalDeposits),

        previousTotal: toINR(prevTotalDeposits),

        breakdown: {
          crypto: toINR(
            parseFloat(totalCryptoDepositsResult.rows[0].total)
          ),

          fiat: toINR(totalFiatDepositsAmount)
        },

        today: {
          amount: toINR(todayDepositsAmount),

          count: todayDepositsCount,

          breakdown: {
            crypto: {
              amount: toINR(
                parseFloat(todayCryptoDepositsResult.rows[0].total)
              ),

              count: parseInt(
                todayCryptoDepositsResult.rows[0].count
              )
            },

            fiat: {
              amount: toINR(todayFiatDepositsAmount),

              count: todayFiatDepositsCount
            }
          }
        }
      },

      withdrawals: {
        total: toINR(totalWithdrawals),

        previousTotal: toINR(prevTotalWithdrawals),

        breakdown: {
          crypto: toINR(
            parseFloat(totalCryptoWithdrawalsResult.rows[0].total)
          ),

          fiat: toINR(totalFiatWithdrawalsAmount)
        },

        today: {
          amount: toINR(todayWithdrawalsAmount),

          count: todayWithdrawalsCount,

          breakdown: {
            crypto: {
              amount: toINR(
                parseFloat(todayCryptoWithdrawalsResult.rows[0].total)
              ),

              count: parseInt(
                todayCryptoWithdrawalsResult.rows[0].count
              )
            },

            fiat: {
              amount: toINR(todayFiatWithdrawalsAmount),

              count: todayFiatWithdrawalsCount
            }
          }
        }
      },

      financials: {
        netBalance: toINR(
          totalDeposits - totalWithdrawals
        ),

        previousNetBalance: toINR(
          prevTotalDeposits - prevTotalWithdrawals
        ),

        todayNetBalance: toINR(
          todayDepositsAmount - todayWithdrawalsAmount
        )
      },

      timestamp: new Date().toISOString(),

      date: new Date().toLocaleDateString()
    });

  } catch (error) {
    console.error(
      'Error fetching admin dashboard data:',
      error
    );

    res.status(500).json({
      error: 'Failed to fetch dashboard data',
      details: error.toString()
    });
  }
});
  /**
   * Admin Detailed User Statistics API
   * Provides detailed information about user growth and activity
   */
  server.get('/api/admin/user-stats', protectStaff, async (req, res) => {
    try {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const todayISO = today.toISOString();

      // Get counts for different user segments
      const [
        totalUsersResult,
        todayUsersResult,
        activeUsersResult,
        prevActiveUsersResult,
        verifiedUsersResult,
        prevVerifiedUsersResult,
        usersByCountryResult,
        registrationTrendResult
      ] = await Promise.all([
        pg.query('SELECT COUNT(*) as count FROM users WHERE NOT COALESCE(is_demo, false)'),
        pg.query('SELECT COUNT(*) as count FROM users WHERE created >= $1 AND NOT COALESCE(is_demo, false)', [todayISO]),
        pg.query("SELECT COUNT(*) as active FROM users WHERE created >= (CURRENT_DATE - INTERVAL '30 days') AND NOT COALESCE(is_demo, false)"),
        pg.query("SELECT COUNT(*) as active FROM users WHERE created >= (CURRENT_DATE - INTERVAL '60 days') AND created < (CURRENT_DATE - INTERVAL '30 days') AND NOT COALESCE(is_demo, false)"),
        pg.query(`
        SELECT COUNT(*) as count
        FROM users u
        LEFT JOIN user_kyc k ON u.id = k.user_id::bigint
        WHERE k.status = 'Verified' AND NOT COALESCE(u.is_demo, false)
      `),
        pg.query(`
        SELECT COUNT(*) as count
        FROM users u
        LEFT JOIN user_kyc k ON u.id = k.user_id::bigint
        WHERE k.status = 'Verified' AND u.created < $1 AND NOT COALESCE(u.is_demo, false)
      `, [todayISO]),
        pg.query("SELECT country, COUNT(*) as count FROM users WHERE country IS NOT NULL AND NOT COALESCE(is_demo, false) GROUP BY country ORDER BY count DESC LIMIT 10"),
        pg.query(`
        SELECT 
          DATE(created) as date,
          COUNT(*) as count
        FROM users
        WHERE created >= CURRENT_DATE - INTERVAL '30 days' AND NOT COALESCE(is_demo, false)
        GROUP BY DATE(created)
        ORDER BY date ASC
      `)
      ]);

      res.json({
        totalUsers: parseInt(totalUsersResult.rows[0].count),
        previousTotalUsers: parseInt(totalUsersResult.rows[0].count) - parseInt(todayUsersResult.rows[0].count),
        newUsersToday: parseInt(todayUsersResult.rows[0].count),
        activeUsers30d: parseInt(activeUsersResult.rows[0].active),
        previousActiveUsers30d: parseInt(prevActiveUsersResult.rows[0].active),
        verifiedUsers: parseInt(verifiedUsersResult.rows[0].count),
        previousVerifiedUsers: parseInt(prevVerifiedUsersResult.rows[0].count),
        topCountries: usersByCountryResult.rows,
        registrationTrend: registrationTrendResult.rows,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error fetching user statistics:', error);
      res.status(500).json({
        error: 'Failed to fetch user statistics',
        details: error.toString()
      });
    }
  });



  // Get live bets
  server.get('/live-bets', async (req, res) => {
    try {
      const result = await pg.query(`
      SELECT * FROM bets
      ORDER BY created DESC
      LIMIT 50
    `);
      res.json(result.rows);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch live bets' });
    }
  });


  server.post("/inrhistory", async function (req, res) {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    const { name } = req.body;

    pg.query("SELECT date,amount,status,trxid FROM inr_deposit WHERE name = $1", [name], function (err, result) {
      if (err) {
        console.log("Error on select query:", err);
        res.status(500).json({ error: 'An error occurred while fetching data.' });
        return;
      }

      // Directly send the result as a response
      res.json(result.rows);
    });
  });


  //Wallet Notify
  server.get("/walletNotify", function (req, res) {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    WalletNotify.update(io, req._parsedUrl.query);
    res.send("*ok*");
  });

  //Blcok Notify
  server.get("/blockNotify", function (req, res) {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    BlockNotify.update(io, req._parsedUrl.query);
    res.send("*ok*");
  });

  //CryptoApi.io Notification
  server.get("/crypto_callbacks", function (req, res) {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    Deposit.update(io, req._parsedUrl.query);
    res.send("*ok*");
  });

  //Get the market rate
  server.get("/rate", function (req, res) {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    res.json(Market.rate());
  });

  // Load Files (Avatar)
  server.get("/uploads/:name", function (req, res, next) {
    // res.setHeader('Cross-Origin-Resource-Policy', false);
    res.setHeader("Cross-Origin-Resource-Policy", "example.com");
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    res.sendFile(__dirname + "/uploads/" + req.params.name);
  });

  //Slots EVO Callback info
  server.post("/callback_evo", function (req, res) {
    var body = req.body;
    var user = null,
      info,
      game,
      gid,
      bet = 0,
      win = 0;

    _.forEach(body, function (value, key) {
      if (key === "event[data][user][agregator_user_id]") {
        user = value;
      }
      if (key === "event[data][game][response]") {
        info = value;
      }
      if (key === "event[data][game][game_id]") {
        game = value;
      }
      if (key === "event[data][game][round][round_id]") {
        gid = value;
      }
      if (key === "event[data][pay_for_action_this_round]") {
        bet = value;
      }
      if (key === "event[data][game][round][win]") {
        win = value;
      }
    });

    user = _.toNumber(user);
    bet = _.toNumber(bet);
    win = _.toNumber(win);

    if (user !== null) {
      if (bet !== 0) {
        if (win !== 0) {
          //Player Winner
          H.wait(1000).then(() => {
            SlotsRule.winner(user, bet, win, info, game, gid);
          });
        } else {
          //Player Lost
          H.wait(1000).then(() => {
            SlotsRule.lost(user, bet, info, game, gid);
          });
        }
      }
    }
    res.sendStatus(200);
  });

  server.get('/bet30', async (req, res) => {
    const { id } = req.query; // Use req.query instead of req.body for GET requests

    try {
      const { rows } = await pg.query('SELECT * FROM bets_30s WHERE uid = $1', [id]);
      res.status(200).json(rows); // Send the fetched data as JSON response
    } catch (error) {
      console.error('Error fetching data:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  server.get('/bet1', async (req, res) => {
    const { id } = req.query; // Use req.query instead of req.body for GET requests

    try {
      const { rows } = await pg.query('SELECT * FROM bets_1m WHERE uid = $1', [id]);
      res.status(200).json(rows); // Send the fetched data as JSON response
    } catch (error) {
      console.error('Error fetching data:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  server.get('/bet2', async (req, res) => {
    const { id } = req.query; // Use req.query instead of req.body for GET requests

    try {
      const { rows } = await pg.query('SELECT * FROM bets_2m WHERE uid = $1', [id]);
      res.status(200).json(rows); // Send the fetched data as JSON response
    } catch (error) {
      console.error('Error fetching data:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });


  let users = 0;

  const sessionDurations = {
    '30s': 30000,
    '1m': 60000,
    '2m': 120000,
  };

  const betEndBuffer = 3000; // 3 seconds to stop accepting bets
  const namespaces = ['30s', '1m', '2m'];
  const currentSessionIds = { '30s': null, '1m': null, '2m': null };
  const acceptBets = { '30s': true, '1m': true, '2m': true };

  const generateSessionId = (type) => {
    const currentTimestamp = Date.now();
    const timeValue = parseInt(type.slice(0, -1), 10);
    const timeUnit = type.slice(-1);

    let timeInMilliseconds;
    if (timeUnit === 's') {
      timeInMilliseconds = timeValue * 1000;
    } else if (timeUnit === 'm') {
      timeInMilliseconds = timeValue * 60 * 1000;
    } else {
      throw new Error('Invalid time unit');
    }

    const sessionId = currentTimestamp + timeInMilliseconds;
    return sessionId;
  };

  const generateRandomWinningNumber = () => {
    const number = Math.floor(Math.random() * 10); // Random number between 0 and 10
    const color = number % 2 === 0 ? 'red' : 'green'; // Red for even, green for odd
    console.log(`Winning Number for Session  ${number} (${color})`);
    return { number, color };
  };

  const generateWinningNumber = async (sessionId, namespace) => {
    // const client = createClient();
    try {
      const tablePrefix = namespace.replace('s', 's').replace('m', 'm');
      // const winningResult = await getNumber(sessionId,bets_${tablePrefix});  
      const winningResult = await getNumber(sessionId, `bets_${tablePrefix}`);
      if (!winningResult || winningResult.number === 11) {
        console.log(`No bets placed for session ${sessionId}. Generating random number.`);
        return generateRandomWinningNumber();
      } else {
        console.log(`Winning Number for Session ${sessionId}: ${winningResult.number} (${winningResult.color})`);
      }
      return winningResult;
    } finally {
      // client.end();
    }
  };

  const checkWinningBet = (bet, winningResult) => {
    if (!winningResult || !winningResult.number) {
      return false; // No valid winning result
    }
    if (bet.value === winningResult.number.toString()) {
      return true; // Exact number match
    } else if (bet.value === winningResult.color) {
      return true; // Color match
    }
    return false;
  };

  const calculateWinAmount = (bet, winningResult) => {
    if (bet.value === winningResult.number.toString()) {
      return bet.amount * 9.5; // Exact number match
    } else if (bet.value === winningResult.color) {
      if ((winningResult.number === 0 && bet.value === 'red') || (winningResult.number === 5 && bet.value === 'green')) {
        return bet.amount * 1.5; // Special color payout for 0 and 5
      } else if (winningResult.number === 0 || winningResult.number === 5) {
        return bet.amount * 4.75; // Violet payout for 0 and 5
      } else {
        return bet.amount * 2; // Regular color match
      }
    }
    return 0; // No win
  };

  const fetchDataFromDb = async (activeSessionId, table) => {
    // const client = createClient();
    try {
      console.log('table');
      console.log(table);
      const res = await pg.query(`SELECT * FROM ${table} WHERE sessionId = $1`, [activeSessionId]);
      console.log('data');
      console.log(res.rows);
      return res.rows;
    } finally {
      // client.end();
    }
  };

  // const insertBet = async (sessionId, betData, namespace) => {
  //   // const client = createClient();
  //   try {
  //     const tablePrefix = namespace.replace('s', 's').replace('m', 'm');
  //     const { uid, value, amount, cointype } = betData;
  //     console.log(`bets_${tablePrefix}`);
  //     await pg.query('BEGIN');
  //     // Deduct bet amount from user's balance
  //     const updateBalanceQuery = `UPDATE credits SET ${cointype} = ${cointype} - $1 WHERE uid = $2`;
  //     await pg.query(updateBalanceQuery, [amount, uid]);

  //     // Insert bet data
  //     const insertBetQuery = `INSERT INTO bets_${tablePrefix} (uid, value, amount, cointype, sessionId, status) VALUES ($1, $2, $3, $4, $5, 'null')`;
  //     await pg.query(insertBetQuery, [uid, value, amount, cointype, sessionId]);

  //     await pg.query('COMMIT');
  //     socket.emit('walletUpdate', { coin:cointype,balance:amount,uid:uid});
  //   } catch (error) {
  //     await pg.query('ROLLBACK');
  //     throw error;
  //   } finally {
  //     // client.end();
  //   }
  // };

  const insertBet = async (sessionId, betData, namespace, socket) => {
    // const client = createClient();
    try {
      const tablePrefix = namespace.replace('s', 's').replace('m', 'm');
      const { uid, value, amount, cointype } = betData;
      console.log(`bets_${tablePrefix}`);

      await pg.query('BEGIN');

      // Fetch the user's current balance
      const balanceQuery = `SELECT ${cointype} FROM credits WHERE uid = $1`;
      const { rows } = await pg.query(balanceQuery, [uid]);
      const currentBalance = rows[0][cointype];

      // Deduct bet amount from user's balance
      const newBalance = currentBalance - amount;
      const updateBalanceQuery = `UPDATE credits SET ${cointype} = $1 WHERE uid = $2`;
      await pg.query(updateBalanceQuery, [newBalance, uid]);

      // Insert bet data
      const insertBetQuery = `INSERT INTO bets_${tablePrefix} (uid, value, amount, cointype, sessionId, status) VALUES ($1, $2, $3, $4, $5, 'null')`;
      await pg.query(insertBetQuery, [uid, value, amount, cointype, sessionId]);

      await pg.query('COMMIT');

      // Emit the updated balance to the user
      socket.emit('walletUpdate', { coin: cointype, balance: newBalance, uid: uid });
    } catch (error) {
      await pg.query('ROLLBACK');
      throw error;
    } finally {
      // client.end();
    }
  };


  const updateSessionStatus = async (sessionId, namespace) => {
    // const client = createClient();
    try {
      const tablePrefix = namespace.replace('s', 's').replace('m', 'm');
      await pg.query(`UPDATE session_${tablePrefix} SET status = 'inactive' WHERE sessionId = $1`, [sessionId]);
    } finally {
      // client.end();
    }
  };

  // const updateBalanceAndNotify = async (bet, winAmount, namespace) => {
  //   // const client = createClient();
  //   try {
  //     const { uid, cointype } = bet;

  //     await pg.query('BEGIN');
  //     if (winAmount > 0) {
  //       // Update user's balance only if they have won
  //       const updateBalanceQuery = `UPDATE credits SET ${cointype} = ${cointype} + $1 WHERE uid = $2`;
  //       await pg.query(updateBalanceQuery, [winAmount, uid]);
  //     }

  //     await pg.query('COMMIT');

  //     // Notify user
  //     io.of(`/${namespace}`).to(uid).emit('balanceUpdate', {
  //       message: winAmount > 0 ? 'Congratulations! You won!' : 'Better luck next time!',
  //       winAmount,
  //       cointype,
  //     });
  //   } catch (error) {
  //     await pg.query('ROLLBACK');
  //     throw error;
  //   } finally {
  //     // client.end();
  //   }
  // };

  const updateBalanceAndNotify = async (bet, winAmount, namespace) => {
    // const client = createClient();
    try {
      const { uid, cointype } = bet;

      await pg.query('BEGIN');
      let updatedBalance = 0;

      if (winAmount > 0) {
        // Update user's balance if they have won and get the updated balance
        const updateBalanceQuery = `UPDATE credits SET ${cointype} = ${cointype} + $1 WHERE uid = $2 RETURNING ${cointype}`;
        const { rows } = await pg.query(updateBalanceQuery, [winAmount, uid]);
        updatedBalance = rows[0][cointype];
      }

      await pg.query('COMMIT');

      // Notify user of win or loss
      io.of(`/${namespace}`).to(uid).emit('balanceUpdate', {
        message: winAmount > 0 ? 'Congratulations! You won!' : 'Better luck next time!',
        winAmount,
        cointype,
      });

      // Emit wallet update with the updated balance if there was a win
      if (winAmount > 0) {
        socket.emit('walletUpdate', {
          coin: cointype,
          balance: updatedBalance,
          uid: uid
        });
      }
    } catch (error) {
      await pg.query('ROLLBACK');
      throw error;
    } finally {
      // client.end();
    }
  };

  const broadcastSessionData = async (namespace) => {
    try {
      const tablePrefix = namespace.replace('s', 's').replace('m', 'm');
      const sessionDataQuery = `
      SELECT 
        session_${tablePrefix}.sessionId,
        betOutcome_${tablePrefix}.betNumber,
        betOutcome_${tablePrefix}.betColour
      FROM 
        session_${tablePrefix}
      LEFT JOIN 
        betOutcome_${tablePrefix} ON session_${tablePrefix}.sessionId = betOutcome_${tablePrefix}.sessionId;
    `;

      const res = await pg.query(sessionDataQuery);

      const dataWithTimestamps = res.rows.map(row => {
        const timestamp = extractTimestampFromSessionId(row.sessionid);
        const createdAt = new Date(timestamp).toISOString(); // Formatting timestamp to ISO string
        return {
          ...row,
          createdAt,
          namespace
        };
      });

      io.of(`/${namespace}`).emit('sessionData', dataWithTimestamps);
    } finally {
      // client.end();
    }
  };

  const extractTimestampFromSessionId = (sessionId) => {
    // Assuming sessionId is an integer with timestamp at the start
    return parseInt(sessionId, 10); // Extract the timestamp
  };

  const startNewSession = async (namespace) => {
    // const client = createClient();
    try {
      const sessionId = generateSessionId(namespace);
      const previousSessionId = currentSessionIds[namespace];
      currentSessionIds[namespace] = sessionId;
      acceptBets[namespace] = true;

      const sessionDuration = sessionDurations[namespace];
      const tablePrefix = namespace.replace('s', 's').replace('m', 'm');

      await pg.query(`INSERT INTO session_${tablePrefix} (sessionId, status) VALUES ($1, 'active')`, [sessionId]);

      if (previousSessionId) {
        await updateSessionStatus(previousSessionId, namespace);
        await broadcastSessionData(namespace); // Broadcast session data after updating the previous session status
      }

      console.log(`New session started: ${sessionId} in ${namespace}`);
      io.of(`/${namespace}`).emit('sessionUpdate', { type: 'new', sessionId });

      let timeLeft = sessionDuration / 1000;
      const countdown = setInterval(() => {
        timeLeft--;
        io.of(`/${namespace}`).emit('sessionTimer', { sessionId, timeLeft });
        if (timeLeft <= betEndBuffer / 1000 && acceptBets[namespace]) {
          acceptBets[namespace] = false;
          io.of(`/${namespace}`).emit('bettingClosed', { sessionId });
        }
        if (timeLeft <= 0) {
          clearInterval(countdown);
          finishSession(namespace, sessionId); // Moved session finishing logic to a separate function
        }
      }, 1000);
    } catch (error) {
      console.error('Error creating a new session in the database:', error);
    } finally {
      // client.end();
    }
  };

  const finishSession = async (namespace, sessionId) => {
    // const client = createClient();
    try {
      console.log(`Betting ended for session: ${sessionId}`);
      let winningResult;
      try {
        winningResult = await generateWinningNumber(sessionId, namespace);
      } catch (error) {
        console.error('Error generating winning number:', error);
        winningResult = generateRandomWinningNumber(); // Fallback to random winning number
      }

      io.of(`/${namespace}`).emit('winningNumber', { sessionId, ...winningResult });

      const tablePrefix = namespace.replace('s', 's').replace('m', 'm');
      await pg.query(`INSERT INTO betOutcome_${tablePrefix} (sessionId, betNumber, betColour) VALUES ($1, $2, $3)`, [sessionId, winningResult.number, winningResult.color]);

      const bets = await fetchDataFromDb(sessionId, `bets_${tablePrefix}`);
      console.log('bet');
      console.log(bets);
      const betOutcomes = [];
      for (const bet of bets) {
        const isWinningBet = checkWinningBet(bet, winningResult);
        const winAmount = isWinningBet ? calculateWinAmount(bet, winningResult) : 0;
        const winLoss = isWinningBet ? "win" : "loss";
        console.log('win amount');
        console.log(winAmount);
        await pg.query(`INSERT INTO windata_${tablePrefix} (uid, sessionId, winamount, cointype) VALUES ($1, $2, $3, $4)`, [bet.uid, sessionId, winAmount, bet.cointype]);

        await updateBalanceAndNotify(bet, winAmount, namespace);
        console.log(bet.uid);
        //  to(bet.uid)
        betOutcomes.push({
          sessionId,
          betValue: bet.value,
          amountPlaced: bet.amount,
          uid: bet.uid,
          winloss: winLoss,
          winAmount,
          winningNumber: winningResult.number,
          winningColor: winningResult.color
        });
        io.of(`/${namespace}`).to(bet.uid.toString()).emit('betOutcome', {
          sessionId,
          betValue: bet.value,
          amountPlaced: bet.amount,
          uid: bet.uid,
          winloss: winLoss,
          winAmount,
          winningNumber: winningResult.number,
          winningColor: winningResult.color
        });
      }
      io.of(`/${namespace}`).emit('betOutcome', betOutcomes);
      startNewSession(namespace);
    } finally {
      // client.end();
    }
  };
  let uid = "";
  const setEventHandlers = () => {
    console.log("API Server is running on port:", config.port);

    if (config.developer) {
      Crash.idle(io);
      Keno.IdleGame(io);
      Bots.Idle(io);
      // Market.update(); // need at first
      setInterval(() => {
        Market.update();
      }, 3600000);
    } else {
      Market.dummyUpdate();
    }

    io.sockets.on("connection", onPublicConnection);

    const admin = io.of("/pedramx");
    admin.use((socket, next) => {
      next();
    });
    admin.on("connection", onPrivateConnection);
    // namespaces.forEach(namespace => {
    //   const nsp = io.of(`/${namespace}`);
    //   nsp.on('connection', (socket) => {
    //       // console.log("id");
    //       // console.log(uid);
    //     socket.join(uid.toString());
    //     handleNamespaceEvents(socket, namespace);
    //   });
    // });
  };

  const onPublicConnection = (client) => {
    users++;

    const token = client.handshake.query.auth_token;

    if (!token) return;

    let ip = client.request.connection.remoteAddress;
    if (!ip) ip = client.handshake.headers["x-forwarded-for"];
    let origin = client.handshake.headers.origin;
    // let domain = ["https://example.com"];
    let domain = ["http://localhost:3000", "https://example.com", "http://localhost:3001", "https://example.com", "https://example.com", "http://localhost:3002", "http://localhost:3003", "http://localhost:3004", "http://5.182.208.159:3003", "https://snapmoney.casino", "https://betgohere.com"];

    if (config.developer) {
      if (!domain.includes(origin)) {
        Notify.send("ORIGIN => " + origin + " - Details : " + ip);
        return console.log("origin");
      }
    }

    setTimeout(() => {
      client.emit("U2t5cGU6IEBQZWRyb3hhbQ", "U2t5cGU6IEBQZWRyb3hhbQ==");
    }, 2000);

    Notify.send("New Online User, Total: " + users + " / Details: " + ip);

    Token.getID(token, (id) => {
      if (id) {
        uid = id.toString();
        client.userid = id;
        client.join(parseFloat(id));
      }
      client.on("disconnecting", () => {
        users--;
        if (id) client.leave(id);
      });

      Users(client, io, id, siofu);
      Games(client, io, id);
      Slots(client, io, id);
      setupSiteConfigSocket(io);
      client.on('getBonusTimers', async () => {
        if (id) {
          try {
            const timerData = await getUserBonusTimers(id);
            client.emit('bonusTimerUpdate', timerData);
          } catch (error) {
            console.error('Error getting bonus timers:', error);
          }
        }
      });
    });
  };

  // const handleNamespaceEvents = (socket, namespace) => {
  //   socket.on('placeBet', async (betData) => {
  //     const sessionId = currentSessionIds[namespace];
  //     if (acceptBets[namespace]) {
  //       try {
  //         await insertBet(sessionId, betData, namespace,socket);
  //         socket.emit('betResult', { message: 'Bet placed successfully', sessionId });
  //       } catch (error) {
  //         console.error("Error processing the bet:", error);
  //         socket.emit('betError', { error: error.message });
  //       }
  //     } else {
  //       socket.emit('betError', { message: 'Betting is closed for this session.', sessionId });
  //     }
  //   });
  // };

  // namespaces.forEach(namespace => broadcastSessionData(namespace));
  // namespaces.forEach(namespace => startNewSession(namespace));
  function onPrivateConnection(client) {
    Admin(client, io);
  }

  if (config.developer) {
    try {
      setEventHandlers();
    } catch (e) {
      console.log("catch", e);
    }
  } else {
    setEventHandlers();
  }

  if (config.developer) {
    process.stdin.resume();
    function exitHandler(err, exitCode) {
      Notify.send("ERROR EXIT: " + JSON.stringify(err), true);
    }
    process.on(
      "uncaughtException",
      exitHandler.bind(null, {
        exit: true,
      })
    );
  }

  /**
   * Start App
   *
   */
  
  // const { runUploadGis } = require('./uploadgis');
  // runUploadGis({ previewOnly: false })
  //   .then(r => console.log('[uploadgis] done:', r))
  //   .catch(e => console.error('[uploadgis] error:', e));

  app.listen(config.port);

}
