const express = require("express");
const server = express();
const app = require("http").createServer(server);
const io = require("socket.io")(app, {
  cors: {
    origin: "https://stakebet.games",
    credentials: true,
    methods: ["GET", "POST"]
  }
})
const cron = require('node-cron');
const { convertToUSDT } = require('./conversiontousdt');
const fs = require('fs');
const path = require('path');
const nodemailer = require('nodemailer');
const randomstring = require('randomstring');
const bodyParser = require("body-parser");
const axios = require('axios');
const compr = require("compression");
const siofu = require("socketio-file-upload");
const cors = require("cors");
var pg = require("./General/Model");
const xss = require("xss-clean");
const helmet = require("helmet");
const _ = require("lodash");
// const jwt = require('jsonwebtoken');
const { expressjwt: jwt } = require("express-jwt");
const cluster = require("cluster");
const totalCPUs = require("os").cpus().length;

const H = require("./General/Helper");
const Market = require("./General/Market");
const Token = require("./Users/Token");
const Notify = require("./Users/Notify");
const Admin = require("./Admin");
// const Sports = require('./Sports');
const Users = require("./Users");
const Games = require("./Games");
const Bots = require("./Games/Bots");
const Crash = require("./Games/Crash");
const Keno = require("./Games/Keno");
const Deposit = require("./Wallet/Deposit");
const WalletNotify = require("./Wallet/WalletNotify");
const inr_deposit = require("./Wallet/inrdeposit");
const inr_history = require("./Wallet/inrhistory");
const BlockNotify = require("./Wallet/BlockNotify");
const Slots = require("./Slots");
const SlotsRule = require("./Slots/Rule");
const md5 = require('md5');
const requestIp = require('request-ip');
// INstantiating the express-jwt middleware
const jwtMW = jwt({
  secret: "REMOVED_SECRET",
  algorithms: ["RS256"],
});

// General Config
var config = require("./config");
const { sign } = require("crypto");

let users = 0;

if (!config.developer && cluster.isMaster) {
  console.log(`Number of CPUs is ${totalCPUs}`);
  console.log(`Master ${process.pid} is running`);

  // Fork workers.
  for (let i = 0; i < totalCPUs; i++) {
    cluster.fork();
  }

  cluster.on("exit", (worker, code, signal) => {
    console.log(`worker ${worker.process.pid} died`);
    console.log("Let's fork another worker!");
    cluster.fork();
  });
} else {
  // See the react auth blog in which cors is required for access
  server.use((req, res, next) => {
    // res.setHeader('Access-Control-Allow-Origin', 'http://localhost:3004');
    res.setHeader("Access-Control-Allow-Headers", "Content-type,Authorization", "Access-Control-Allow-Origin");
    next();
  });

  // parse application/x-www-form-urlencoded
  server.use(
    bodyParser.urlencoded({
      extended: false,
    })
  );

  // parse application/json
  server.use(bodyParser.json());
  server.use(cors(
    {
      origin: '*',
      credentials: true,

    }
  ));

  //Server Security
  server.use(
    helmet({
      crossOriginEmbedderPolicy: false,
    })
  );
  server.use(xss());
  server.use(compr());

  //Upload Image
  server.use(siofu.router);

  console.log(`Worker ${process.pid} started`);

  server.get("/", function (req, res, next) {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    res.sendStatus(403);
  });

  //Get the Hour
  server.get("/hour", function (req, res) {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    let hour = new Date().getHours();
    res.json({ hour });

  });

  const OPERATOR_CODE = '';
  const SECRET_KEY = '';
  const BASE_URL = 'https://staging.gsimw.com/api/operators';
  server.get('/fetch-products', async (req, res) => {
    const currentTimestampInt64 = BigInt(Date.now()) * 1000000n;
    const requestTime = Math.floor(Date.now() / 1000);;
    const productListSign = md5(`${requestTime}${SECRET_KEY}productlist${OPERATOR_CODE}`);
    try {
      const productResponse = await axios.get(`${BASE_URL}/available-products`, {
        params: {
          operator_code: OPERATOR_CODE,
          sign: productListSign,
          request_time: requestTime,
        },
      });

      res.json(productResponse.data);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Internal server error' });
    }
  });
  server.get('/fetch-games', async (req, res) => {
    const { providerName, gameType } = req.query;
    if (!providerName || !gameType) {
      return res.status(400).json({ error: 'providerName and gameType are required' });
    }
    const currentTimestampInt64 = BigInt(Date.now()) * 1000000n;
    const requestTime = Math.floor(Date.now() / 1000);;

    const productListSign = md5(`${requestTime}${SECRET_KEY}productlist${OPERATOR_CODE}`);

    try {

      const productResponse = await axios.get(`${BASE_URL}/available-products`, {
        params: {
          operator_code: OPERATOR_CODE,
          sign: productListSign,
          request_time: requestTime,
        },
      });

      const products = productResponse.data;
      const filteredProducts = products.filter(product => product.provider === providerName);
      console.log(filteredProducts);
      if (filteredProducts.length === 0) {
        return res.status(404).json({ error: 'No products found for the given provider' });
      }

      const gameResponses = await Promise.all(filteredProducts.map(async (product) => {
        const gameListSign = md5(`${requestTime}${SECRET_KEY}gamelist${OPERATOR_CODE}`);
        console.log(product.product_code);
        console.log(OPERATOR_CODE);
        console.log(gameType);
        console.log(sign);
        console.log(requestTime);
        const gameResponse = await axios.get(`${BASE_URL}/provider-games`, {
          params: {
            product_code: product.product_code,
            operator_code: OPERATOR_CODE,
            sign: gameListSign,
            request_time: requestTime,
            game_type: gameType,
          },
        });
        return gameResponse.data;
      }));
      console.log(gameResponses);
      res.json(gameResponses);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Internal server error' });
    }
  });



  server.post('/launch-game', async (req, res) => {
    const { memberAccount, gameType, productCode, gameCode } = req.body;

    if (!memberAccount || !gameType || !productCode) {
      return res.status(400).json({ error: 'memberAccount, gameType, and productCode are required' });
    }

    try {

      const userQuery = 'SELECT password, name FROM users WHERE id = $1';
      const userResult = await pg.query(userQuery, [memberAccount]);

      if (userResult.rows.length === 0) {
        return res.status(404).json({ error: 'User not found' });
      }

      const user = userResult.rows[0];
      const password = user.password;
      const nickname = user.name;


      const requestTime = Math.floor(Date.now() / 1000);;
      const launchGameSign = md5(`${requestTime}${SECRET_KEY}launchgame${OPERATOR_CODE}`);

      const ip = requestIp.getClientIp(req) || '127.0.0.1';
      console.log({
        operator_code: OPERATOR_CODE,
        member_account: memberAccount,
        password: password,
        currency: 'USD',
        game_code: gameCode,
        product_code: productCode,
        game_type: gameType,
        language_code: 0,
        ip: ip,
        platform: 'web',
        sign: launchGameSign,
        request_time: requestTime,
        nickname: nickname,
      });
      const launchGameResponse = await axios.post(`${BASE_URL}/launch-game`, {
        operator_code: OPERATOR_CODE,
        member_account: memberAccount,
        password: password,
        currency: 'USD',
        game_code: gameCode,
        product_code: productCode,
        game_type: gameType,
        language_code: 0,
        ip: ip,
        platform: 'web',
        sign: launchGameSign,
        request_time: requestTime,
        nickname: nickname,
        operator_lobby_url: "http://localhost:3000"
      });
      res.json(launchGameResponse.data);
    } catch (error) {
      console.error('Error launching game:', error.response ? error.response.data : error.message);
      res.status(500).json({ error: error.message.toString() });
    }
  });

  server.get('/game-list', async (req, res) => {
    const providerCode = req.query.s || "EVOLUTION";
    try {
      console.log("Making request to external API with the following payload:");
      console.log({
        method: "game_list",
        agent_code: "nitesh_usd",
        agent_token: "REMOVED_SECRET",
        provider_code: providerCode
      });

      const response = await axios.post('https://api.nexusggreu.com', {
        method: "game_list",
        agent_code: "nitesh_usd",
        agent_token: "REMOVED_SECRET",
        provider_code: providerCode
      }, {
        headers: {
          'Content-Type': 'application/json',
        }
      });

      if (response.data.status === 1) {
        res.json({ games: response.data.games });
      } else {
        res.status(400).json({ error: response.data.msg });
      }
    } catch (error) {
      if (error.response) {
        // The request was made and the server responded with a status code
        // that falls out of the range of 2xx
        console.error("Error response from the API:");
        console.error("Status:", error.response.status);
        console.error("Data:", error.response.data);
        res.status(error.response.status).json({ error: error.response.data });
      } else if (error.request) {
        // The request was made but no response was received
        console.error("No response received from the API:");
        console.error(error.request);
        res.status(500).json({ error: "No response received from the API" });
      } else {
        // Something happened in setting up the request that triggered an Error
        console.error("Error in setting up the request:");
        console.error("Message:", error.message);
        res.status(500).json({ error: "Failed to fetch data: " + error.message });
      }
    }
  });

  server.get('/game-list-new', async (req, res) => {
    try {

      const gameLabels = req.query.lable ? req.query.lable.split(',') : [];
      if (gameLabels.length === 0) {
        return res.status(400).json({ error: "No game labels provided" });
      }

      console.log("Making request to external API with the following payload:");

      const response = await axios.post('http://asiaapi.net/API/', {
        hall: "937387",
        key: "myapp_games",
        cmd: "gamesList",
        cdnUrl: "",
        img: "game_img_2"
      }, {
        headers: {
          'Content-Type': 'application/json',
        }
      });

      if (response.data.status === "success") {
        const content = response.data.content;
        const gameList = content.gameList;

        let sortedGames = {};
        gameLabels.forEach(label => {
          sortedGames[label] = [];
        });


        gameList.forEach(game => {
          if (sortedGames.hasOwnProperty(game.label)) {
            sortedGames[game.label].push(game);
          }
        });

        res.json({ games: sortedGames });
      } else {
        res.status(400).json({ error: response.data.msg });
      }
    } catch (error) {
      if (error.response) {
        console.error("Error response from the API:");
        console.error("Status:", error.response.status);
        console.error("Data:", error.response.data);
        res.status(error.response.status).json({ error: error.response.data });
      } else if (error.request) {
        console.error("No response received from the API:");
        console.error(error.request);
        res.status(500).json({ error: "No response received from the API" });
      } else {
        console.error("Error in setting up the request:");
        console.error("Message:", error.message);
        res.status(500).json({ error: "Failed to fetch data: " + error.message });
      }
    }
  });

  server.post('/game_launch_new', async (req, res) => {
    const { user_code, game_code } = req.body;
    try {
      const response = await axios.post('http://asiaapi.net/API/openGame/', {
        cmd: "openGame",
        hall: "937387",
        domain: "http://localhost:3000",
        exitUrl: "http://localhost:3000",
        localhost: "http://localhost:3000",
        language: "en",
        key: "myapp_games",
        continent: "asia",
        login: user_code,
        gameId: game_code,
        cdnUrl: "https://api.lagaobet.com",
        demo: "0"
      }, {
        headers: {
          'Content-Type': 'application/json',
        }
      });

      res.status(response.status).json(response.data);
    } catch (error) {
      console.error("Failed to launch game: " + error.message);
      if (error.response) {
        res.status(error.response.status).json(error.response.data);
      } else {
        res.status(500).json({ msg: "Internal Server Error" });
      }
    }
  });

  //   server.get('/game-list', async (req, res) => {

  //     try {
  //         console.log("Making request to external API with the following payload:");
  //         console.log({
  //             method: "game_list",
  //             agent_code: "nitesh_usd",
  //             agent_token: "REMOVED_SECRET",
  //             provider_code: "EVOLUTION"
  //         });

  //         const response = await axios.post('https://api.nexusggreu.com', {
  //             method: "game_list",
  //             agent_code: "nitesh_usd",
  //             agent_token: "REMOVED_SECRET",
  //             provider_code: "EVOLUTION"
  //         }, {
  //             headers: {
  //                 'Content-Type': 'application/json',
  //             }
  //         });

  //         if (response.data.status === 1) {
  //             res.json({ games: response.data.games });
  //         } else {
  //             res.status(400).json({ error: response.data.msg });
  //         }
  //     } catch (error) {
  //         if (error.response) {
  //             // The request was made and the server responded with a status code
  //             // that falls out of the range of 2xx
  //             console.error("Error response from the API:");
  //             console.error("Status:", error.response.status);
  //             console.error("Data:", error.response.data);
  //             res.status(error.response.status).json({ error: error.response.data });
  //         } else if (error.request) {
  //             // The request was made but no response was received
  //             console.error("No response received from the API:");
  //             console.error(error.request);
  //             res.status(500).json({ error: "No response received from the API" });
  //         } else {
  //             // Something happened in setting up the request that triggered an Error
  //             console.error("Error in setting up the request:");
  //             console.error("Message:", error.message);
  //             res.status(500).json({ error: "Failed to fetch data: " + error.message });
  //         }
  //     }
  // });
  async function getUserBalance(userCode) {
    try {
      const result = await pg.query('SELECT usdt FROM credits WHERE uid = $1', [userCode]);
      return result.rows.length ? result.rows[0].usdt : 0;
    } catch (err) {
      console.error('Error fetching user balance', err);
      throw err;
    }
  }

  async function updateUserBalance(userCode, newBalance) {
    // This is a placeholder function, replace with actual database logic
    try {
      const result = await pg.query('UPDATE credits SET usdt = $1 WHERE uid = $2 RETURNING *', [newBalance, userCode]);
      return result.rows.length > 0;
    } catch (err) {
      console.error('Error updating user balance', err);
      return false;
    }
  }

  async function getBalanceInfo(req, res) {
    const { user_code } = req.body;

    try {
      const userBalance = await getUserBalance(user_code);
      res.json({
        status: 1,
        msg: "SUCCESS",
        user_balance: userBalance
      });
    } catch (error) {
      res.json({
        status: 0,
        user_balance: 0,
        msg: "INTERNAL_ERROR"
      });
    }
  }



  // async function setTransaction(req, res) {
  //   const { user_code, game_type } = req.body;
  //   let { bet_money, win_money } = req.body;

  //   // If game_type is "live" or "slot", extract the values from the respective block
  //   if (game_type === "live" && req.body.live) {
  //     bet_money = req.body.live.bet_money;
  //     win_money = req.body.live.win_money;
  //   } else if (game_type === "slot" && req.body.slot) {
  //     bet_money = req.body.slot.bet_money;
  //     win_money = req.body.slot.win_money;
  //   }

  //   const userBalance = await getUserBalance(user_code);

  //   // Check if user has enough funds for the transaction
  //   if (userBalance < bet_money) {
  //     console.error(`User ${user_code} has insufficient funds for the transaction.`);
  //     return res.json({
  //       status: 0,
  //       msg: "INSUFFICIENT_USER_FUNDS"
  //     });
  //   }

  //   // Calculate new balance after the transaction
  //   const newBalance = userBalance - bet_money + win_money;

  //   // Update user balance in the database
  //   const updateResult = await updateUserBalance(user_code, newBalance);

  //   if (!updateResult) {
  //     console.error(`Failed to update balance for user ${user_code}.`);
  //     return res.json({
  //       status: 0,
  //       msg: "INTERNAL_ERROR"
  //     });
  //   }

  //   console.log(`Transaction successful for user ${user_code}. New balance: ${newBalance}. Bet: ${bet_money}. Win: ${win_money}. User balance before transaction: ${userBalance}`);

  //   // Return updated user balance
  //   res.json({
  //     status: 1,
  //     user_balance: newBalance
  //   });
  // }

  async function setTransaction(req, res) {
    const { user_code, game_type, method, user_balance } = req.body;
    let bet_money, win_money, provider_code, game_code, type, txn_id, txn_type;

    if (game_type === "live" && req.body.live) {
      ({ bet_money, win_money, provider_code, game_code, type, txn_id, txn_type } = req.body.live);
    } else if (game_type === "slot" && req.body.slot) {
      ({ bet_money, win_money, provider_code, game_code, type, txn_id, txn_type } = req.body.slot);
    } else {
      return res.json({ status: 0, msg: "INVALID_GAME_TYPE" });
    }

    try {
      const userBalance = await getUserBalance(user_code);

      if (userBalance < bet_money) {
        console.error(`User ${user_code} has insufficient funds for the transaction.`);
        return res.json({
          status: 0,
          msg: "INSUFFICIENT_USER_FUNDS"
        });
      }

      const newBalance = userBalance - bet_money + win_money;
      await updateUserBalance(user_code, newBalance);


      const transactionQuery = game_type === "live" ?
        `INSERT INTO transaction_live (method, user_code, user_balance, game_type, provider_code, game_code, type, bet_money, win_money, txn_id, txn_type)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)` :
        `INSERT INTO transaction_slot (method, user_code, user_balance, game_type, provider_code, game_code, type, bet_money, win_money, txn_id, txn_type)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`;

      await pg.query(transactionQuery, [method, user_code, newBalance, game_type, provider_code, game_code, type, bet_money, win_money, txn_id, txn_type]);

      console.log(`Transaction successful for user ${user_code}. New balance: ${newBalance}. Bet: ${bet_money}. Win: ${win_money}. User balance before transaction: ${userBalance}`);

      res.json({
        status: 1,
        user_balance: newBalance,
        msg: "SUCCESS",
      });
    } catch (error) {
      console.error('Error processing transaction', error);
      res.json({
        status: 0,
        user_balance: 0,
        msg: "SITE_ERROR_1",
      });
    }
  }


  async function getUserBalanceNew(userCode) {
    try {
      const result = await pg.query('SELECT usdt FROM credits WHERE uid = $1', [userCode]);
      if (result.rows.length > 0) {
        const balance = parseFloat(result.rows[0].usdt).toFixed(2);
        return balance;
      } else {
        return "0.00";
      }
    } catch (err) {
      console.error('Error fetching user balance', err);
      throw new Error('Internal Server Error');
    }
  }
  async function updateUserBalanceNew(userCode, newBalance) {
    try {
      const result = await pg.query('UPDATE credits SET usdt = $1 WHERE uid = $2', [newBalance, userCode]);
      return result.rowCount > 0;
    } catch (err) {
      console.error('Error updating user balance', err);
      return false;
    }
  }

  async function getGameName(gameId) {
    try {
      const response = await axios.post('http://asiaapi.net/API/', {
        hall: "937387",
        key: "myapp_games",
        cmd: "gamesList",
        cdnUrl: "",
        img: "game_img_2"
      }, {
        headers: {
          'Content-Type': 'application/json',
        }
      });

      const gameList = response.data.content.gameList;
      const game = gameList.find(g => g.id === gameId.toString());
      return game ? game.name : gameId;
    } catch (err) {
      console.error('Error fetching game name', err);
      throw new Error('Failed to fetch game name');
    }
  }
  server.post("/processRequest", async (req, res) => {
    const { cmd, login, bet, win, sessionId, tradeId, action, betInfo, matrix, date, WinLines, gameId } = req.body;

    if (!cmd || !login) {
      return res.status(400).json({
        status: "fail",
        error: "Invalid request parameters"
      });
    }

    try {
      if (cmd === "getBalance") {
        const userBalance = await getUserBalanceNew(login);
        return res.json({
          status: "success",
          error: "",
          login: login,
          balance: userBalance,
          currency: "USD"
        });
      } else if (cmd === "writeBet") {
        if (!bet || !win) {
          return res.status(400).json({
            status: "fail",
            error: "Invalid request parameters"
          });
        }

        const userBalance = await getUserBalanceNew(login);

        if (userBalance < bet) {
          return res.status(400).json({
            status: "fail",
            error: "fail_balance"
          });
        }

        const newBalance = parseFloat(userBalance) - parseFloat(bet) + parseFloat(win);

        const updateResult = await updateUserBalanceNew(login, newBalance.toFixed(2));
        if (!updateResult) {
          return res.status(500).json({
            status: "fail",
            error: "INTERNAL_ERROR"
          });
        }

        const gameName = await getGameName(gameId);


        await pg.query(
          `INSERT INTO transactions (
          login, session_id, trade_id, bet, win, balance_before, balance_after, action, game_name, bet_info, matrix, date, win_lines
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)`,
          [login, sessionId, tradeId, bet, win, userBalance, newBalance.toFixed(2), action, gameName, betInfo, matrix, date, WinLines]
        );

        return res.json({
          status: "success",
          error: "",
          login: login,
          balance: newBalance.toFixed(2),
          currency: "USD"
        });
      } else {
        return res.status(400).json({
          status: "fail",
          error: "Unknown command"
        });
      }
    } catch (err) {
      return res.status(500).json({
        status: "fail",
        error: err.message
      });
    }
  });

  // server.post("/writeBet", async (req, res) => {
  //   const { cmd, login, bet, win, sessionId, tradeId, action, betInfo, matrix, date, WinLines, gameId } = req.body;

  //   if (cmd !== "writeBet" || !login || !bet || !win) {
  //     return res.status(400).json({
  //       status: "fail",
  //       error: "Invalid request parameters"
  //     });
  //   }

  //   try {
  //     const userBalance = await getUserBalanceNew(login);

  //     if (userBalance < bet) {
  //       return res.status(400).json({
  //         status: "fail",
  //         error: "fail_balance"
  //       });
  //     }

  //     const newBalance = parseFloat(userBalance) - parseFloat(bet) + parseFloat(win);

  //     const updateResult = await updateUserBalanceNew(login, newBalance.toFixed(2));
  //     if (!updateResult) {
  //       return res.status(500).json({
  //         status: "fail",
  //         error: "INTERNAL_ERROR"
  //       });
  //     }

  //     const gameName = await getGameName(gameId);
  //     if (!gameName) {
  //       return res.status(500).json({
  //         status: "fail",
  //         error: "Failed to fetch game name"
  //       });
  //     }

  //     await pg.query(
  //       `INSERT INTO transactions (
  //         login, session_id, trade_id, bet, win, balance_before, balance_after, action, game_name, bet_info, matrix, date, win_lines
  //       ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)`,
  //       [login, sessionId, tradeId, bet, win, userBalance, newBalance.toFixed(2), action, gameName, betInfo, matrix, date, WinLines]
  //     );

  //     res.json({
  //       status: "success",
  //       error: "",
  //       login: login,
  //       balance: newBalance.toFixed(2),
  //       currency: "USD"
  //     });
  //   } catch (err) {
  //     res.status(500).json({
  //       status: "fail",
  //       error: err.message
  //     });
  //   }
  // });
  // server.post("/getBalance", async (req, res) => {
  //   const { cmd, login } = req.body;
  //   if (cmd !== "getBalance" || !login) {
  //     return res.status(400).json({
  //       status: "fail",
  //       error: "Invalid request parameters"
  //     });
  //   }
  //   try {
  //     const userBalance = await getUserBalanceNew(login);
  //     res.json({
  //       status: "success",
  //       error: "",
  //       login: login,
  //       balance: userBalance,
  //       currency: "USD"
  //     });
  //   } catch (err) {
  //     res.status(500).json({
  //       status: "fail",
  //       error: "Internal Server Error"
  //     });
  //   }
  // });

  server.post("/gold_api", async (req, res) => {
    const { method } = req.body;
    switch (method) {
      case "user_balance":
        await getBalanceInfo(req, res);
        break;
      case "transaction":
        await setTransaction(req, res);
        break;
      default:
        res.json({ status: 0, msg: "INVALID_METHOD" });
    }
  });

  server.post('/game_launch', async (req, res) => {
    const { user_code, provider_code, game_code } = req.body;

    try {
      const response = await axios.post('https://api.nexusggreu.com', {
        method: "game_launch",
        agent_code: "nitesh_usd",
        agent_token: "REMOVED_SECRET",
        user_code: user_code || "",
        provider_code: provider_code || "EVOLUTION",
        game_code: game_code,
        lang: "en"
      }, {
        headers: {
          'Content-Type': 'application/json',
        }
      });

      res.status(response.status).json(response.data);
    } catch (error) {
      console.error("Failed to launch game: " + error.message);
      if (error.response) {
        res.status(error.response.status).json(error.response.data);
      } else {
        res.status(500).json({ msg: "Internal Server Error" });
      }
    }
  });


  //post inr

  server.post("/hr", function (req, res) {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    const { uid, date, amount_deposit, txid_in, status, name } = req.body;
    inr_deposit.inrapi({ uid, date, amount_deposit, txid_in, status, name });
    res.send(req.body);
  });
  server.post('/send-otp', async (req, res) => {
    const { to } = req.body;


    const otp = randomstring.generate({
      length: 6,
      charset: 'numeric',
    });
    // const logoPath = './assets/logo.png';
    // const logoBuffer = fs.readFileSync(logoPath);


    // const logoBase64 = logoBuffer.toString('base64');
    // const logoDataURL = `data:image/png;base64,${logoBase64}`;



    const transporter = nodemailer.createTransport({
      host: 'smtpout.secureserver.net',
      port: 465,
      secure: true,
      auth: {
        user: 'support@example.com',
        pass: 'REMOVED_SECRET',
      },
    });


    const mailOptions = {
      from: 'support@example.com',
      to,
      subject: 'OTP Verification',
      html: `
      <div style="background-color: #13182e; padding: 20px; text-align: center; border-radius: 10px; width: fit-content; margin: auto;">
        <h1 style="color: #fff; font-size: 24px;">Your OTP for verification is:</h1>
        <p style="color: #fff; font-size: 36px; font-weight: bold; margin: 10px 0;">${otp}</p>
      </div>
    `,
    };

    try {

      await transporter.sendMail(mailOptions);
      res.status(200).send({ message: 'OTP sent successfully', otp: otp });
    } catch (error) {
      console.error('Error sending OTP:', error);
      res.status(500).send({ message: 'Error sending OTP' });
    }
  });


  let task;

  const startAutomaticMode = () => {
    task = cron.schedule('* * * * *', async () => {
      try {
        const result = await pg.query('SELECT * FROM house');
        const houses = result.rows;

        for (const house of houses) {
          const { uid, max, current } = house;
          let newMax = max;
          let newCurrent = current;

          // Illusion logic with a 70-30 win-loss ratio
          const winProbability = 0.7;
          const randomValue = Math.random();

          if (randomValue < winProbability) { // 70% chance to win
            if (max > current) {
              newCurrent += 1; // Increase current for a win
            } else if (max < current) {
              newMax -= 1; // Decrease max for a win
            } else {
              newCurrent -= 1; // Special case: Draw results in a decrease
            }
          } else { // 30% chance to lose
            if (max > current) {
              newCurrent -= 1; // Decrease current for a loss
            } else if (max < current) {
              newMax += 1; // Increase max for a loss
            } else {
              newCurrent += 1; // Special case: Draw results in an increase
            }
          }

          // Ensure values are not negative
          newMax = Math.max(newMax, 0);
          newCurrent = Math.max(newCurrent, 0);

          await pg.query('UPDATE house SET max = $1, current = $2 WHERE uid = $3', [newMax, newCurrent, uid]);
        }
      } catch (error) {
        console.error('Error running cron job:', error);
      }
    });
    task.start();
  };


  const stopAutomaticMode = () => {
    if (task) {
      task.stop();
    }
  };

  server.get('/start-house', (req, res) => {
    startAutomaticMode();
    res.json({ message: 'Automatic mode started' });
  });

  server.get('/stop-house', (req, res) => {
    stopAutomaticMode();
    res.json({ message: 'Automatic mode stopped' });
  });

  server.get('/reset-house', async (req, res) => {
    try {
      await pg.query('UPDATE house SET max = 50, current = 0');
      res.json({ message: 'House reset successfully' });
    } catch (error) {
      res.status(500).json({ error: 'Failed to reset house' });
    }
  });

  server.get('/win-house', async (req, res) => {
    try {
      await pg.query('UPDATE house SET max = 0, current = 0');
      res.json({ message: 'Win condition set successfully' });
    } catch (error) {
      res.status(500).json({ error: 'Failed to set win condition' });
    }
  });

  server.get('/gethouse', async (req, res) => {
    try {
      const result = await pg.query(
        `SELECT house.uid, house.max, house.current, users.name 
         FROM house 
         JOIN users ON house.uid = users.id`
      );
      res.json(result.rows);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch house data' });
    }
  });

  server.post('/updatehouse', async (req, res) => {
    const { uid, max, current } = req.body;
    try {
      await pg.query('UPDATE house SET max = $1, current = $2 WHERE uid = $3', [max, current, uid]);
      res.json({ message: 'House updated successfully' });
    } catch (error) {
      res.status(500).json({ error: 'Failed to update house' });
    }
  });

  // Function to fetch wallet details
  const fetchWalletDetails = async () => {
    const query = `
    SELECT u.id as uid, u.name, c.btc, c.eth, c.ltc, c.bch, c.usdt, c.trx, c.doge, c.ada, c.xrp, c.bnb, c.usdp, c.nexo, c.mkr, c.tusd, c.usdc, c.busd, c.nc, c.shib, c.matic,c.inr
    FROM users u
    JOIN credits c ON u.id = c.uid
  `;
    const res = await pg.query(query);
    return res.rows;
  };

  // Function to update wallet balance
  const updateWalletBalance = async (uid, coin, amount) => {
    const query = `
    UPDATE credits
    SET ${coin} = $1
    WHERE uid = $2
  `;
    await pg.query(query, [amount, uid]);
  };

  // API endpoint to get wallet details
  server.get('/getwallet', async (req, res) => {
    try {
      const walletDetails = await fetchWalletDetails();
      res.json(walletDetails);
    } catch (error) {
      console.error('Error fetching wallet details:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });

  // API endpoint to update wallet balance
  server.post('/updatebalance', async (req, res) => {
    const { uid, coin, amount } = req.body;
    try {
      await updateWalletBalance(uid, coin, amount);
      res.json({ message: 'Balance updated successfully' });
    } catch (error) {
      console.error('Error updating wallet balance:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });

  // Fetch transaction live data with join to users
  server.get('/transaction/live', async (req, res) => {
    const query = `
    SELECT 
      transaction_live.id, 
      transaction_live.method, 
      transaction_live.user_code, 
      transaction_live.user_balance, 
      transaction_live.game_type, 
      transaction_live.provider_code, 
      transaction_live.game_code, 
      transaction_live.type, 
      transaction_live.bet_money, 
      transaction_live.win_money, 
      transaction_live.txn_id, 
      transaction_live.txn_type,
      users.name AS user_name 
    FROM transaction_live 
    JOIN users ON transaction_live.user_code = CAST(users.id AS VARCHAR(50))
  `;

    try {
      console.log('Executing query:', query);
      const result = await pg.query(query);
      res.json(result.rows);
    } catch (error) {
      console.error('Error fetching live transactions:', error);
      res.status(500).json({ error: 'Failed to fetch live transaction data', details: error.message });
    }
  });

  // Fetch transaction slot data with join to users
  server.get('/transaction/slot', async (req, res) => {
    const query = `
    SELECT 
      transaction_slot.id, 
      transaction_slot.method, 
      transaction_slot.user_code, 
      transaction_slot.user_balance, 
      transaction_slot.game_type, 
      transaction_slot.provider_code, 
      transaction_slot.game_code, 
      transaction_slot.type, 
      transaction_slot.bet_money, 
      transaction_slot.win_money, 
      transaction_slot.txn_id, 
      transaction_slot.txn_type,
      users.name AS user_name 
    FROM transaction_slot 
    JOIN users ON transaction_slot.user_code = CAST(users.id AS VARCHAR(50))
  `;

    try {
      console.log('Executing query:', query);
      const result = await pg.query(query);
      res.json(result.rows);
    } catch (error) {
      console.error('Error fetching slot transactions:', error);
      res.status(500).json({ error: 'Failed to fetch slot transaction data', details: error.message });
    }
  });

  server.post('/updateWithdrawStatus', async (req, res) => {
    const { uid, status } = req.body;

    try {
      const result = await pg.query(
        'UPDATE withdrawals SET status = $1 WHERE uid = $2 RETURNING *',
        [status, uid]
      );

      if (result.rowCount === 0) {
        return res.status(404).json({ message: 'UID not found' });
      }

      res.json(result.rows[0]);
    } catch (error) {
      console.error('Error updating withdrawal status:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  server.delete('/deleteUser', async (req, res) => {
    const { id } = req.body;

    try {
      const result = await pg.query('DELETE FROM users WHERE id = $1 RETURNING *', [id]);

      if (result.rowCount === 0) {
        return res.status(404).json({ message: 'User not found' });
      }

      res.json({ message: `User with id ${id} deleted successfully` });
    } catch (error) {
      console.error('Error deleting user:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  // Fetch withdrawal data including user names and conversion to USDT
  const getWithdrawData = async () => {
    try {
      const withdrawResult = await pg.query(`
      SELECT w.uid, w.date, w.amount, w.wallet, w.coin,w.status, u.name 
      FROM withdrawals w
      JOIN users u ON w.uid = u.id
    `);

      const withdrawals = await Promise.all(withdrawResult.rows.map(async (withdraw) => {
        const amountInUSDT = await convertToUSDT(parseFloat(withdraw.amount), withdraw.coin);
        return { ...withdraw, amount_usdt: amountInUSDT };
      }));

      return withdrawals;
    } catch (error) {
      console.error('Error fetching withdrawal data:', error);
      throw error;
    }
  };

  // Fetch deposit data including user names without conversion
  const getDepositData = async () => {
    try {
      const depositResult = await pg.query(`
      SELECT d.uid, d.date, d.txtid, d.amount, d.coin, u.name
      FROM deposits d
      JOIN users u ON d.uid = u.id
    `);

      return depositResult.rows;
    } catch (error) {
      console.error('Error fetching deposit data:', error);
      throw error;
    }
  };

  // Define endpoints
  server.get('/getWithdrawData', async (req, res) => {
    try {
      const data = await getWithdrawData();
      res.json(data);
    } catch (error) {
      console.error('Error fetching withdrawal data:', error);
      res.status(500).send('Internal Server Error');
    }
  });

  server.get('/getDepositData', async (req, res) => {
    try {
      const data = await getDepositData();
      res.json(data);
    } catch (error) {
      res.status(500).send('Internal Server Error');
    }
  });


  // Fetch user data including total deposits and withdrawals in USDT
  const getUserData = async () => {
    try {
      // Fetch users
      const usersResult = await pg.query('SELECT id, name, email FROM users');
      const users = usersResult.rows;

      // Fetch deposits and withdrawals
      const depositsResult = await pg.query('SELECT uid, amount, coin FROM deposits WHERE status = \'done\'');
      const withdrawalsResult = await pg.query('SELECT uid, amount, coin FROM withdrawals WHERE status = \'done\'');

      // Process users
      for (const user of users) {
        const userDeposits = depositsResult.rows.filter(deposit => deposit.uid === user.id);
        const userWithdrawals = withdrawalsResult.rows.filter(withdrawal => withdrawal.uid === user.id);

        user.total_deposit_usdt = 0;
        for (const deposit of userDeposits) {
          user.total_deposit_usdt += await convertToUSDT(parseFloat(deposit.amount), deposit.coin);
        }

        user.total_withdrawal_usdt = 0;
        for (const withdrawal of userWithdrawals) {
          user.total_withdrawal_usdt += await convertToUSDT(parseFloat(withdrawal.amount), withdrawal.coin);
        }
      }

      return users;
    } catch (error) {
      console.error('Error fetching user data:', error);
      throw error;
    }
  };

  // Define endpoint
  server.get('/getUserData', async (req, res) => {
    try {
      const data = await getUserData();
      res.json(data);
    } catch (error) {
      res.status(500).send('Internal Server Error');
    }
  });
  // Total deposits endpoint
  server.get('/total-deposits', async (req, res) => {
    try {
      const result = await pg.query('SELECT amount, coin FROM deposits');
      const deposits = result.rows;
      let totalDeposits = 0;

      for (const deposit of deposits) {
        const amountInUSDT = await convertToUSDT(deposit.amount, deposit.coin);
        totalDeposits += amountInUSDT;
      }

      res.json({ total_deposits_usdt: totalDeposits });
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch deposits' });
    }
  });

  // Total withdrawals endpoint
  server.get('/total-withdrawals', async (req, res) => {
    try {
      const result = await pg.query('SELECT amount, coin FROM withdrawals');
      const withdrawals = result.rows;
      let totalWithdrawals = 0;

      for (const withdrawal of withdrawals) {
        const amountInUSDT = await convertToUSDT(withdrawal.amount, withdrawal.coin);
        totalWithdrawals += amountInUSDT;
      }

      res.json({ total_withdrawals_usdt: totalWithdrawals });
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch withdrawals' });
    }
  });
  // User endpoints
  server.get('/users', async (req, res) => {
    try {
      const result = await pg.query('SELECT * FROM users');
      res.json(result.rows);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch users' });
    }
  });

  // Deposit endpoints
  server.get('/deposits', async (req, res) => {
    try {
      const result = await pg.query('SELECT * FROM deposits');
      const depositsInUSDT = await Promise.all(result.rows.map(async deposit => {
        const amountInUSDT = await convertToUSDT(deposit.amount, deposit.coin);
        return { ...deposit, amount_in_usdt: amountInUSDT };
      }));
      res.json(depositsInUSDT);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch deposits' });
    }
  });

  // Withdrawal endpoints
  server.get('/withdrawals', async (req, res) => {
    try {
      const result = await pg.query('SELECT * FROM withdrawals');
      const withdrawalsInUSDT = await Promise.all(result.rows.map(async withdrawal => {
        const amountInUSDT = await convertToUSDT(withdrawal.amount, withdrawal.coin);
        return { ...withdrawal, amount_in_usdt: amountInUSDT };
      }));
      res.json(withdrawalsInUSDT);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch withdrawals' });
    }
  });

  // Bet endpoints
  server.get('/bets', async (req, res) => {
    try {
      const result = await pg.query('SELECT * FROM bets');
      res.json(result.rows);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch bets' });
    }
  });

  // Get total deposits and withdrawals for each user
  server.get('/user-summary', async (req, res) => {
    try {
      const result = await pg.query(`
      SELECT 
        u.id,
        u.name,
        u.email,
        COALESCE(SUM(d.amount), 0) AS total_deposit_usdt,
        COALESCE(SUM(w.amount), 0) AS total_withdrawal_usdt
      FROM 
        users u
      LEFT JOIN 
        deposits d ON u.id = d.uid
      LEFT JOIN 
        withdrawals w ON u.id = w.uid
      GROUP BY 
        u.id
    `);
      res.json(result.rows);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch user summary' });
    }
  });

  // Get today's deposits
  server.get('/today-deposits', async (req, res) => {
    try {
      const result = await pg.query(`
      SELECT * FROM deposits
      WHERE DATE(date) = CURRENT_DATE
    `);
      res.json(result.rows);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch today\'s deposits' });
    }
  });

  // Get today's withdrawals
  server.get('/today-withdrawals', async (req, res) => {
    try {
      const result = await pg.query(`
      SELECT * FROM withdrawals
      WHERE DATE(date) = CURRENT_DATE
    `);
      res.json(result.rows);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch today\'s withdrawals' });
    }
  });

  // Get today's transactions (deposits and withdrawals)
  server.get('/today-transactions', async (req, res) => {
    try {
      const deposits = await pg.query(`
      SELECT * FROM deposits
      WHERE DATE(date) = CURRENT_DATE
    `);
      const withdrawals = await pool.query(`
      SELECT * FROM withdrawals
      WHERE DATE(date) = CURRENT_DATE
    `);
      res.json([...deposits.rows, ...withdrawals.rows]);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch today\'s transactions' });
    }
  });

  // Get live bets
  server.get('/live-bets', async (req, res) => {
    try {
      const result = await pg.query(`
      SELECT * FROM bets
      ORDER BY created DESC
      LIMIT 50
    `);
      res.json(result.rows);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch live bets' });
    }
  });


  server.post("/inrhistory", async function (req, res) {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    const { name } = req.body;

    pg.query("SELECT date,amount,status,trxid FROM inr_deposit WHERE name = $1", [name], function (err, result) {
      if (err) {
        console.log("Error on select query:", err);
        res.status(500).json({ error: 'An error occurred while fetching data.' });
        return;
      }

      // Directly send the result as a response
      res.json(result.rows);
    });
  });


  //Wallet Notify
  server.get("/walletNotify", function (req, res) {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    WalletNotify.update(io, req._parsedUrl.query);
    res.send("*ok*");
  });

  //Blcok Notify
  server.get("/blockNotify", function (req, res) {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    BlockNotify.update(io, req._parsedUrl.query);
    res.send("*ok*");
  });

  //CryptoApi.io Notification
  server.get("/crypto_callbacks", function (req, res) {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    Deposit.update(io, req._parsedUrl.query);
    res.send("*ok*");
  });

  //Get the market rate
  server.get("/rate", function (req, res) {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    res.json(Market.rate());
  });

  // Load Files (Avatar)
  server.get("/uploads/:name", function (req, res, next) {
    // res.setHeader('Cross-Origin-Resource-Policy', false);
    res.setHeader("Cross-Origin-Resource-Policy", "example.com");
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    res.sendFile(__dirname + "/uploads/" + req.params.name);
  });

  //Slots EVO Callback info
  server.post("/callback_evo", function (req, res) {
    var body = req.body;
    var user = null,
      info,
      game,
      gid,
      bet = 0,
      win = 0;

    _.forEach(body, function (value, key) {
      if (key === "event[data][user][agregator_user_id]") {
        user = value;
      }
      if (key === "event[data][game][response]") {
        info = value;
      }
      if (key === "event[data][game][game_id]") {
        game = value;
      }
      if (key === "event[data][game][round][round_id]") {
        gid = value;
      }
      if (key === "event[data][pay_for_action_this_round]") {
        bet = value;
      }
      if (key === "event[data][game][round][win]") {
        win = value;
      }
    });

    user = _.toNumber(user);
    bet = _.toNumber(bet);
    win = _.toNumber(win);

    if (user !== null) {
      if (bet !== 0) {
        if (win !== 0) {
          //Player Winner
          H.wait(1000).then(() => {
            SlotsRule.winner(user, bet, win, info, game, gid);
          });
        } else {
          //Player Lost
          H.wait(1000).then(() => {
            SlotsRule.lost(user, bet, info, game, gid);
          });
        }
      }
    }
    res.sendStatus(200);
  });

  /**
   * Socket Event Handlers
   */
  var setEventHandlers = function () {
    console.log("API Server was running on port:", config.port);
    if (config.developer) {
      /**
       * Crash Idle
       */
      Crash.idle(io);
      /**
       * Keno Idle
       */
      Keno.IdleGame(io);
      /**
       * Start Playing Bots
       */
      Bots.Idle(io);

      //Update USD price from Market
      Market.update(); // need at first
      setInterval(function () {
        Market.update();
      }, 3600000);
    } else {
      Market.dummyUpdate();
    }

    /**
     * Listen To Public Socket Requests
     */
    io.sockets.on("connection", onPublicConnection);

    // io.use(function (socket, next) {
    //     if (socket.handshake.query && socket.handshake.query.auth_token) {
    //         jwt.verify(socket.handshake.query.auth_token, 'REMOVED_SECRET', function (err, decoded) {
    //             if (err) return next(new Error('Authentication error'));
    //             socket.decoded = decoded;
    //             next();
    //         });
    //     }
    //     else {
    //         next(new Error('Authentication error'));
    //     }
    // })
    //     .on('connection', function (socket) {
    //         // Connection now authenticated to receive further events
    //         io.sockets.on('connection', onPublicConnection);
    //     });

    /**
     * Listen To Private Socket Requests
     */
    const admin = io.of("/pedramx");

    admin.use((socket, next) => {
      next();
    });

    admin.on("connection", onPrivateConnection);
  };

  /**
   * Public Socket Connection
   */
  function onPublicConnection(client) {
    users++;

    const token = client.handshake.query.auth_token;

    if (_.isUndefined(token)) return;

    let ip = client.request.connection.remoteAddress;

    if (_.isUndefined(ip)) ip = client.handshake.headers["x-forwarded-for"];

    let origin = client.handshake.headers.origin;
    let domain = ["https://stakebet.games"];

    if (config.developer) {
      if (!domain.includes(origin)) {
        Notify.send("ORIGIN => " + origin + " - Details : " + ip);
        return console.log("origin");
      }
    }

    H.wait(2000).then(() => {
      //Powered By
      client.emit("U2t5cGU6IEBQZWRyb3hhbQ", "U2t5cGU6IEBQZWRyb3hhbQ==");
    });

    Notify.send("New Online User, Total: " + users + " / Details: " + ip);

    Token.getID(token, (id) => {
      if (id) {
        client.join(parseFloat(id));
      }

      client.on("disconnecting", () => {
        users--;

        if (id) client.leave(id);
      });

      /*
       * Users Events
       */
      Users(client, io, id, siofu);

      /*
       * Games Events
       */
      Games(client, io, id);

      /*
       * Sports Events
       */
      // Sports(client, io, id);

      /*
       * Slots Events
       */
      Slots(client, io, id);
    });
  }

  /**
   * Private Socket Connection
   */
  function onPrivateConnection(client) {
    /*
     * Admin Events
     */
    Admin(client, io);
  }

  /**
   * Start Listening for Events
   */
  if (config.developer) {
    try {
      setEventHandlers();
    } catch (e) {
      console.log("catch", e);
    }
  } else {
    setEventHandlers();
  }

  /*
   * Procces on Exit
   */
  if (config.developer) {
    process.stdin.resume();
    function exitHandler(err, exitCode) {
      Notify.send("ERROR EXIT: " + JSON.stringify(err), true);
    }
    process.on(
      "uncaughtException",
      exitHandler.bind(null, {
        exit: true,
      })
    );
  }

  /**
   * Start App
   */
  app.listen(config.port);
}
