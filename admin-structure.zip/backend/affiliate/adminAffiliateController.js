const db = require('../General/Model');
const { recordActivity } = require('../system/utils/recordActivity');

// Settings ki safe range — galat value se commission / bonus ka paisa na ban jaye.
const SETTING_LIMITS = {
  affiliatebonus: [0, 1000],
  comissionpercent: [0, 100],
  registerbonus: [0, 100],
};

// Get dashboard stats for admin affiliate panel
exports.getDashboardStats = async (req, res) => {
  try {
    const [totalTeams, totalReferrals, rewardStats, recentActivity] = await Promise.all([
      // Count unique team owners
      db.query(`SELECT COUNT(DISTINCT ownername) as total_teams FROM team`),
      // Count total referrals
      db.query(`SELECT COUNT(*) as total_referrals FROM team`),
      // Reward statistics
      db.query(`
        SELECT
          COALESCE(SUM(amount) FILTER (WHERE type = 'referral' AND locked = true), 0) as total_locked,
          COALESCE(SUM(amount) FILTER (WHERE type = 'commission'), 0) as total_commission,
          COUNT(*) FILTER (WHERE type = 'referral') as total_reward_records
        FROM rewards
      `),
      // Claimed rewards stats
      db.query(`
        SELECT
          COALESCE(SUM(CASE WHEN claimed = true THEN amount ELSE 0 END), 0) as total_claimed,
          COALESCE(SUM(CASE WHEN claimed = false THEN amount ELSE 0 END), 0) as total_unclaimed,
          COUNT(CASE WHEN claimed = true THEN 1 END) as claimed_count,
          COUNT(CASE WHEN claimed = false THEN 1 END) as unclaimed_count
        FROM unlocked_rewards
      `)
    ]);

    res.json({
      success: true,
      data: {
        totalTeams: parseInt(totalTeams.rows[0]?.total_teams || 0),
        totalReferrals: parseInt(totalReferrals.rows[0]?.total_referrals || 0),
        totalLocked: parseFloat(rewardStats.rows[0]?.total_locked || 0),
        // Asli bahar gaya paisa: commission (seedha wallet) + claimed referral rewards
        totalCommission: parseFloat(rewardStats.rows[0]?.total_commission || 0),
        totalDistributed: parseFloat(rewardStats.rows[0]?.total_commission || 0)
          + parseFloat(recentActivity.rows[0]?.total_claimed || 0),
        totalRewardRecords: parseInt(rewardStats.rows[0]?.total_reward_records || 0),
        totalClaimed: parseFloat(recentActivity.rows[0]?.total_claimed || 0),
        totalUnclaimed: parseFloat(recentActivity.rows[0]?.total_unclaimed || 0),
        claimedCount: parseInt(recentActivity.rows[0]?.claimed_count || 0),
        unclaimedCount: parseInt(recentActivity.rows[0]?.unclaimed_count || 0)
      }
    });
  } catch (error) {
    console.error('Error fetching dashboard stats:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch dashboard stats', error: error.message });
  }
};

// Get affiliate settings from siteconfig
exports.getAffiliateSettings = async (req, res) => {
  try {
    const result = await db.query(`
      SELECT affiliatebonus, comissionpercent, registerbonus
      FROM siteconfig LIMIT 1
    `);

    if (result.rows.length === 0) {
      return res.json({
        success: true,
        data: { affiliatebonus: 0, comissionpercent: 0, registerbonus: 0 }
      });
    }

    res.json({ success: true, data: result.rows[0] });
  } catch (error) {
    console.error('Error fetching affiliate settings:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch settings', error: error.message });
  }
};

// Update affiliate settings in siteconfig
exports.updateAffiliateSettings = async (req, res) => {
  try {
    const updates = [];
    const values = [];
    let paramIndex = 1;

    for (const [key, [min, max]] of Object.entries(SETTING_LIMITS)) {
      if (req.body[key] === undefined || req.body[key] === null || req.body[key] === '') continue;
      const value = Number(req.body[key]);
      if (!Number.isFinite(value) || value < min || value > max) {
        return res.status(400).json({ success: false, message: `${key} must be between ${min} and ${max}` });
      }
      updates.push(`${key} = $${paramIndex++}`);
      values.push(value);
    }

    if (updates.length === 0) {
      return res.status(400).json({ success: false, message: 'No valid fields to update' });
    }

    const before = await db.query(`SELECT affiliatebonus, comissionpercent, registerbonus FROM siteconfig LIMIT 1`);
    const result = await db.query(
      `UPDATE siteconfig SET ${updates.join(', ')}, updatedat = NOW() RETURNING affiliatebonus, comissionpercent, registerbonus`,
      values
    );
    recordActivity({
      req,
      action: 'affiliate.settings_update',
      targetType: 'siteconfig',
      details: { before: before.rows[0], after: result.rows[0] },
    });

    res.json({ success: true, data: result.rows[0], message: 'Settings updated successfully' });
  } catch (error) {
    console.error('Error updating affiliate settings:', error);
    res.status(500).json({ success: false, message: 'Failed to update settings', error: error.message });
  }
};

// Get all rewards list for admin view
exports.getRewardsList = async (req, res) => {
  try {
    const page = Math.max(parseInt(req.query.page) || 1, 1);
    const limit = Math.min(Math.max(parseInt(req.query.limit) || 50, 1), 200);
    const offset = (page - 1) * limit;

    const [rewards, count] = await Promise.all([
      db.query(`
        SELECT r.id, r.ownername, r.membername, r."referalCode", r.amount, r.coin,
               r.type, r.locked, r.referalmount, r."createdAt",
               u.email as member_email, u.level as member_level
        FROM rewards r
        LEFT JOIN users u ON u.name = r.membername
        ORDER BY r."createdAt" DESC
        LIMIT $1 OFFSET $2
      `, [limit, offset]),
      db.query(`SELECT COUNT(*) as total FROM rewards`)
    ]);

    res.json({
      success: true,
      data: rewards.rows,
      pagination: {
        page,
        limit,
        total: parseInt(count.rows[0].total),
        totalPages: Math.ceil(parseInt(count.rows[0].total) / limit)
      }
    });
  } catch (error) {
    console.error('Error fetching rewards list:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch rewards', error: error.message });
  }
};

// Get top affiliates by referral count
exports.getTopAffiliates = async (req, res) => {
  try {
    const limit = Math.min(Math.max(parseInt(req.query.limit) || 10, 1), 100);

    const result = await db.query(`
      SELECT t.ownername, t.referral_count, u.id AS uid, u.email, u.level,
             (SELECT COALESCE(SUM(r.amount), 0) FROM rewards r
               WHERE r.ownername = t.ownername AND r.type = 'commission')
           + (SELECT COALESCE(SUM(x.amount), 0) FROM unlocked_rewards x
               WHERE x.ownername = t.ownername AND x.claimed) AS total_earned
        FROM (SELECT ownername, COUNT(DISTINCT membername) AS referral_count
                FROM team GROUP BY ownername) t
        LEFT JOIN users u ON u.name = t.ownername
       ORDER BY t.referral_count DESC
       LIMIT $1
    `, [limit]);

    res.json({ success: true, data: result.rows });
  } catch (error) {
    console.error('Error fetching top affiliates:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch top affiliates', error: error.message });
  }
};
