const db = require('../General/Model');
const { withTransaction } = require('../General/Model/pool');
class AffiliateUnlockController {
     // Calculate unlockable amount based on VIP level wager requirements
  vipLevels() {
    return [
      { wager: 1000, reward: 0.50 },
      { wager: 5000, reward: 2.50 },
      { wager: 17000, reward: 5.00 },
      { wager: 49000, reward: 12.00 },
      { wager: 129000, reward: 25.00 },
      { wager: 321000, reward: 50.00 },
      { wager: 769000, reward: 80.00 },
      { wager: 1793000, reward: 120.00 },
      { wager: 4097000, reward: 205.00 },
      { wager: 9217000, reward: 500.00 }
    ];
  }

  calculateUnlockableAmount(wagerAmount) {
    const vipLevels = this.vipLevels();

    // Find the highest eligible reward tier
    for (let i = vipLevels.length - 1; i >= 0; i--) {
      if (wagerAmount >= vipLevels[i].wager) {
        return vipLevels[i].reward;
      }
    }
    return 0;
  }

  // Referral bonus unlock — member ka wager jis VIP tier ko pehli baar cross kare,
  // us tier ka reward ek hi baar unlock hota hai (unlocked_rewards.wager_amount =
  // tier threshold). Locked pool (rewards.type='referral') se kata jata hai, row
  // lock ke saath, taaki parallel calls double unlock na kar saken.
  // Sirf updateUserWager (Users/Rule.js) se call hota hai — koi public route nahi.
  async processWagerAndUnlock(uid, membername, wagerAmount) {
    const newWager = Number(wagerAmount);
    if (!uid || !membername || !Number.isFinite(newWager) || newWager <= 0) {
      return { success: false, message: 'Invalid input.' };
    }
    const tiers = this.vipLevels().filter(t => newWager >= t.wager);
    if (!tiers.length) return { success: false, message: 'No tier reached.' };

    try {
      return await withTransaction(async (client) => {
        const pool = await client.query(
          `SELECT id, ownername, "referalCode", amount
             FROM rewards
            WHERE membername = $1 AND type = 'referral' AND locked = true
            ORDER BY id
            LIMIT 1
            FOR UPDATE`,
          [membername]
        );
        if (!pool.rows.length) return { success: false, message: 'No locked referral record found.' };
        const reward = pool.rows[0];

        // Pool sirf referrer ka hai — kisi aur uid ko unlock nahi.
        const owner = await client.query(`SELECT id FROM users WHERE name = $1`, [reward.ownername]);
        if (!owner.rows.length || String(owner.rows[0].id) !== String(uid)) {
          return { success: false, message: 'Referrer mismatch.' };
        }

        const done = await client.query(
          `SELECT wager_amount FROM unlocked_rewards WHERE membername = $1`,
          [membername]
        );
        const unlockedTiers = new Set(done.rows.map(r => Number(r.wager_amount)));

        let remaining = Number(reward.amount) || 0;
        const created = [];
        for (const tier of tiers) {
          if (unlockedTiers.has(tier.wager)) continue;
          const amount = Math.min(tier.reward, remaining);
          if (amount <= 0) break;
          const ins = await client.query(
            `INSERT INTO unlocked_rewards (uid, ownername, membername, "referalCode", amount, cointype, wager_amount, "createdAt", claimed)
             VALUES ($1, $2, $3, $4, $5, 'bjb', $6, NOW(), false)
             RETURNING *`,
            [uid, reward.ownername, membername, reward.referalCode, amount, tier.wager]
          );
          created.push(ins.rows[0]);
          remaining -= amount;
        }
        if (!created.length) return { success: false, message: 'Wager level already unlocked.' };

        await client.query(`UPDATE rewards SET amount = $2, "updatedAt" = NOW() WHERE id = $1`, [reward.id, remaining]);
        const unlockedAmount = created.reduce((sum, r) => sum + Number(r.amount), 0);
        console.log(`Referral unlock ${unlockedAmount} for ${reward.ownername} (member ${membername}, wager ${newWager})`);
        return { success: true, unlockedRewards: created, unlockedAmount, newWager };
      });
    } catch (error) {
      console.error('Error processing wager unlock:', error);
      return { success: false, message: 'An error occurred during processing.', error: error.message };
    }
  }


    // Get unclaimed rewards for a user
    async getUnclaimedRewards(uid) {
      try {
        const query = `
          SELECT 
            id,
            ownername,
            membername,
            amount,
            cointype,
            wager_amount,
            "createdAt"
          FROM unlocked_rewards
          WHERE uid = $1 AND claimed = false
          ORDER BY "createdAt" DESC
        `;
        const result = await db.query(query, [uid]);
        
        return {
          unclaimedRewards: result.rows,
          totalUnclaimed: result.rows.reduce((sum, reward) => sum + Number(reward.amount), 0)
        };
      } catch (error) {
        console.error('Error fetching unclaimed rewards:', error);
        throw error;
      }
    }
  
    // Claim — UPDATE ... WHERE claimed = false RETURNING ek atomic step hai, isliye
    // do parallel claims ek hi reward ko do baar credit nahi kar sakte.
    async claimReward(uid, rewardId) {
      return withTransaction(async (client) => {
        const r = await client.query(
          `UPDATE unlocked_rewards SET claimed = true
            WHERE id = $1 AND uid = $2 AND claimed = false
            RETURNING id, amount`,
          [rewardId, uid]
        );
        if (!r.rows.length) throw new Error('Reward not found or already claimed');
        const reward = r.rows[0];
        await client.query(
          `UPDATE credits SET bjb = COALESCE(bjb, 0) + $1 WHERE uid = $2`,
          [reward.amount, uid]
        );
        return {
          success: true,
          message: 'Reward claimed successfully',
          claimedAmount: Number(reward.amount),
          rewardId: reward.id
        };
      });
    }

    async claimAllRewards(uid) {
      try {
        return await withTransaction(async (client) => {
          const r = await client.query(
            `UPDATE unlocked_rewards SET claimed = true
              WHERE uid = $1 AND claimed = false
              RETURNING id, amount, ownername, membername`,
            [uid]
          );
          if (!r.rows.length) {
            return { success: false, message: 'No claimable rewards found for this user.' };
          }
          const totalClaimedAmount = r.rows.reduce((sum, x) => sum + Number(x.amount), 0);
          await client.query(
            `UPDATE credits SET bjb = COALESCE(bjb, 0) + $1 WHERE uid = $2`,
            [totalClaimedAmount, uid]
          );
          console.log(`Referral rewards claimed by ${uid}: ${totalClaimedAmount}`);
          return {
            success: true,
            message: 'All claimable rewards have been successfully claimed.',
            totalClaimedAmount,
            claimedRewards: r.rows.map(x => ({
              id: x.id, amount: Number(x.amount), ownername: x.ownername, membername: x.membername
            }))
          };
        });
      } catch (error) {
        console.error('Error claiming all rewards:', error);
        return { success: false, message: 'Error claiming rewards.', error: error.message };
      }
    }



    // Get user's total unlocked and claimed rewards
    async getUserRewardsSummary(uid) {
      try {
        const query = `
          SELECT 
            SUM(CASE WHEN claimed = false THEN amount ELSE 0 END) as total_unclaimed,
            SUM(CASE WHEN claimed = true THEN amount ELSE 0 END) as total_claimed,
            COUNT(CASE WHEN claimed = false THEN 1 END) as unclaimed_count,
            COUNT(CASE WHEN claimed = true THEN 1 END) as claimed_count
          FROM unlocked_rewards
          WHERE uid = $1
        `;
        const result = await db.query(query, [uid]);
        return result.rows[0];
      } catch (error) {
        console.error('Error getting rewards summary:', error);
        throw error;
      }
    }
  }
  
  module.exports = new AffiliateUnlockController();