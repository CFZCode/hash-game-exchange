// Admin affiliate management — referrers ki list (fraud flags ke saath), detail,
// aur actions: withdrawal lock, USDT/BJB adjust, duplicate commission cleanup,
// referral pool / unlocked reward void. Har action transaction me, row lock ke
// saath, aur admin_activity_logs me record hota hai.
const db = require('../General/Model');
const { withTransaction } = require('../General/Model/pool');
const { recordActivity } = require('../system/utils/recordActivity');

const ADJUST_COINS = ['usdt', 'bjb'];

// userwager.wager text column hai — sirf valid number cast karo.
const WAGER_NUM = `CASE WHEN w.wager ~ '^[0-9]+(\\.[0-9]+)?$' THEN w.wager::numeric ELSE 0 END`;

// ── Multi-account signals (owner a ↔ member b, dono SQL uid expressions) ──
// Same bank account: sabse strong. Same device: same IP + same browser 1 ghante ke andar.
// Shared IP: kamzor — Jio (152.56.0.0/14) CGNAT aur 3 se zyada accounts wale IP ignore.
const BANK_ACCOUNTS = (u) => `
  SELECT NULLIF(TRIM(payout_details::jsonb->>'account_number'), '') AS acct
    FROM apaywithdrawals WHERE user_id = (${u})::text
  UNION
  SELECT NULLIF(TRIM(account_number), '') FROM f2paywithdrawals WHERE user_id = ${u}`;

const SAME_BANK = (a, b) => `EXISTS (
  SELECT 1 FROM (${BANK_ACCOUNTS(a)}) x JOIN (${BANK_ACCOUNTS(b)}) y ON y.acct = x.acct
   WHERE x.acct IS NOT NULL)`;

const SAME_DEVICE = (a, b) => `EXISTS (
  SELECT 1 FROM user_login_history p
    JOIN user_login_history q
      ON q.ip_address = p.ip_address AND q.user_agent = p.user_agent
     AND ABS(EXTRACT(EPOCH FROM (q.created_at - p.created_at))) < 3600
   WHERE p.user_id = ${a} AND q.user_id = ${b})`;

const SHARED_IP = (a, b) => `EXISTS (
  SELECT 1 FROM user_login_history p
    JOIN user_login_history q ON q.ip_address = p.ip_address
   WHERE p.user_id = ${a} AND q.user_id = ${b}
     AND p.ip_address ~ '^[0-9]+\\.[0-9]+\\.[0-9]+\\.[0-9]+$'
     AND NOT (p.ip_address::inet << '152.56.0.0/14'::inet)
     AND (SELECT COUNT(DISTINCT z.user_id) FROM user_login_history z WHERE z.ip_address = p.ip_address) <= 3)`;

const ANY_MEMBER = (cond) => `EXISTS (
  SELECT 1 FROM users m WHERE m.refree = ow.referalcode AND ${cond('ow.id', 'm.id')})`;

const fail = (status, message) => Object.assign(new Error(message), { status });

const sendError = (res, error, label) => {
  if (!error.status) console.error(`[affiliateAdmin] ${label}:`, error);
  res.status(error.status || 500).json({ success: false, message: error.message });
};

const commissionRate = async (client = db) => {
  const r = await client.query(`SELECT COALESCE(comissionpercent, 0) AS pct FROM siteconfig LIMIT 1`);
  return (Number(r.rows[0]?.pct) || 0) / 100 * 0.01;
};

const getOwner = async (client, uid, lock = false) => {
  const r = await client.query(
    `SELECT id, name, referalcode, withdrawal_locked FROM users WHERE id::text = $1 ${lock ? 'FOR UPDATE' : ''}`,
    [String(uid)]
  );
  if (!r.rows.length) throw fail(404, 'User not found');
  return r.rows[0];
};

// Overpaid tab flag hota hai jab paid commission expected se 5% + 0.01 USDT zyada ho.
// shared_ip kamzor hint hai — "flagged only" filter me nahi gina jata.
const WEAK_FLAGS = ['shared_ip', 'withdrawal_locked'];
const withFlags = (row, rate) => {
  const expected = Number(row.members_wager) * rate;
  const paid = Number(row.commission_paid);
  const overpaid = Math.max(paid - expected, 0);
  const flags = [];
  if (Number(row.duplicate_events) > 0) flags.push('duplicate_commission');
  if (paid > expected * 1.05 + 0.01) flags.push('overpaid');
  if (row.same_bank) flags.push('same_bank');
  if (row.same_device) flags.push('same_device');
  if (row.shared_ip) flags.push('shared_ip');
  if (row.rapid_signups) flags.push('rapid_signups');
  if (row.withdrawal_locked) flags.push('withdrawal_locked');
  return { ...row, expected_commission: expected, overpaid, flags };
};

// GET /affiliates?flagged=1&search=
exports.listAffiliates = async (req, res) => {
  try {
    const search = String(req.query.search || '').trim();
    const rate = await commissionRate();
    const { rows } = await db.query(
      `WITH owners AS (
         SELECT o.id, o.name, o.referalcode, o.withdrawal_locked, o.created,
                COUNT(m.id)::int AS members
           FROM users o
           JOIN users m ON m.refree = o.referalcode
          WHERE o.referalcode IS NOT NULL AND o.referalcode <> ''
            AND ($1 = '' OR o.name ILIKE '%' || $1 || '%' OR o.id::text = $1 OR o.referalcode = $1)
          GROUP BY o.id
       )
       SELECT ow.*,
              COALESCE(c.usdt, 0) AS usdt, COALESCE(c.bjb, 0) AS bjb,
              (SELECT COALESCE(SUM(amount), 0) FROM rewards r
                WHERE r.ownername = ow.name AND r.type = 'commission') AS commission_paid,
              (SELECT COUNT(*)::int FROM (
                 SELECT 1 FROM rewards r
                  WHERE r.ownername = ow.name AND r.type = 'commission'
                  GROUP BY r.membername, r."createdAt" HAVING COUNT(*) > 1) d) AS duplicate_events,
              (SELECT COALESCE(SUM(amount), 0) FROM rewards r
                WHERE r.ownername = ow.name AND r.type = 'referral' AND r.locked) AS pool_remaining,
              (SELECT COALESCE(SUM(amount), 0) FROM unlocked_rewards u
                WHERE u.ownername = ow.name AND NOT u.claimed) AS unclaimed,
              (SELECT COALESCE(SUM(amount), 0) FROM unlocked_rewards u
                WHERE u.ownername = ow.name AND u.claimed) AS claimed,
              (SELECT COALESCE(SUM(${WAGER_NUM}), 0) FROM userwager w
                 JOIN users m ON m.id = w.uid WHERE m.refree = ow.referalcode) AS members_wager,
              ${ANY_MEMBER(SAME_BANK)} AS same_bank,
              ${ANY_MEMBER(SAME_DEVICE)} AS same_device,
              ${ANY_MEMBER(SHARED_IP)} AS shared_ip,
              EXISTS (
                SELECT 1 FROM users m1 JOIN users m2
                    ON m2.refree = m1.refree AND m2.id <> m1.id
                   AND ABS(EXTRACT(EPOCH FROM (m2.created - m1.created))) < 60
                 WHERE m1.refree = ow.referalcode) AS rapid_signups
         FROM owners ow
         LEFT JOIN credits c ON c.uid = ow.id
        ORDER BY commission_paid DESC, ow.members DESC`,
      [search]
    );
    let data = rows.map(r => withFlags(r, rate));
    if (req.query.flagged === '1') data = data.filter(r => r.flags.some(f => !WEAK_FLAGS.includes(f)));
    res.json({ success: true, data, commissionRate: rate });
  } catch (error) {
    sendError(res, error, 'listAffiliates');
  }
};

// GET /affiliates/:uid
exports.getAffiliate = async (req, res) => {
  try {
    const owner = await getOwner(db, req.params.uid);
    const rate = await commissionRate();
    const [credits, members, history, pools, unlocked, adjustments] = await Promise.all([
      db.query(`SELECT COALESCE(usdt,0) usdt, COALESCE(bjb,0) bjb, COALESCE(inr,0) inr FROM credits WHERE uid = $1`, [owner.id]),
      db.query(
        `SELECT m.id, m.name, m.created, m.last_ip, m.withdrawal_locked,
                COALESCE(c.inr, 0) AS inr,
                (SELECT COALESCE(SUM(${WAGER_NUM}), 0) FROM userwager w WHERE w.uid = m.id) AS wager,
                (SELECT COALESCE(SUM(CASE WHEN paid_amount > 0 THEN paid_amount ELSE amount END), 0)
                   FROM apaydeposits WHERE user_id = m.id AND status = 'Success')
              + (SELECT COALESCE(SUM(amount), 0) FROM f2paydeposits WHERE user_id = m.id AND status = 'Success') AS deposited,
                (SELECT COALESCE(SUM(amount), 0) FROM apaywithdrawals
                  WHERE user_id = m.id::text AND status = 'Success')
              + (SELECT COALESCE(SUM(amount), 0) FROM f2paywithdrawals
                  WHERE user_id = m.id AND status IN ('Success', 'Processing', 'Pending')) AS withdrawn,
                (SELECT COALESCE(SUM(amount), 0) FROM rewards r
                  WHERE r.ownername = $2 AND r.membername = m.name AND r.type = 'commission') AS commission_paid,
                ${SAME_BANK('$1::bigint', 'm.id')} AS same_bank,
                ${SAME_DEVICE('$1::bigint', 'm.id')} AS same_device,
                ${SHARED_IP('$1::bigint', 'm.id')} AS shared_ip
           FROM users m
           LEFT JOIN credits c ON c.uid = m.id
          WHERE m.refree = $3
          ORDER BY m.created`,
        [owner.id, owner.name, owner.referalcode]
      ),
      db.query(
        `SELECT membername, "createdAt", amount, COUNT(*)::int AS times
           FROM rewards
          WHERE ownername = $1 AND type = 'commission'
          GROUP BY membername, "createdAt", amount
          ORDER BY "createdAt" DESC
          LIMIT 200`,
        [owner.name]
      ),
      db.query(
        `SELECT id, membername, amount, referalmount, locked, "createdAt", "updatedAt"
           FROM rewards WHERE ownername = $1 AND type = 'referral' ORDER BY id`,
        [owner.name]
      ),
      db.query(
        `SELECT id, membername, amount, cointype, wager_amount, claimed, "createdAt"
           FROM unlocked_rewards WHERE ownername = $1 ORDER BY id DESC`,
        [owner.name]
      ),
      db.query(
        `SELECT id, currency, amount, reason, description, created_at
           FROM credits_ledger
          WHERE user_id = $1 AND reason IN ('AFFILIATE_ADJUSTMENT', 'COMMISSION_BUG_CORRECTION')
          ORDER BY created_at DESC`,
        [String(owner.id)]
      ),
    ]);

    const memberRows = members.rows.map(m => ({
      ...m,
      expected_commission: Number(m.wager) * rate,
    }));

    res.json({
      success: true,
      data: {
        owner: { ...owner, ...(credits.rows[0] || { usdt: 0, bjb: 0, inr: 0 }) },
        commissionRate: rate,
        members: memberRows,
        commissionHistory: history.rows,
        pools: pools.rows,
        unlockedRewards: unlocked.rows,
        adjustments: adjustments.rows,
      },
    });
  } catch (error) {
    sendError(res, error, 'getAffiliate');
  }
};

// POST /affiliates/:uid/withdrawal-lock  { locked, includeMembers, reason }
exports.setWithdrawalLock = async (req, res) => {
  const locked = req.body.locked === true;
  const includeMembers = req.body.includeMembers === true;
  const reason = String(req.body.reason || '').trim();
  try {
    if (!reason) throw fail(400, 'Reason is required');
    const result = await withTransaction(async (client) => {
      const owner = await getOwner(client, req.params.uid, true);
      const r = await client.query(
        `UPDATE users SET withdrawal_locked = $1
          WHERE id = $2 OR ($3 AND refree = $4)
          RETURNING id, name`,
        [locked, owner.id, includeMembers, owner.referalcode]
      );
      return { owner, users: r.rows };
    });
    recordActivity({
      req,
      action: locked ? 'affiliate.withdrawal_lock' : 'affiliate.withdrawal_unlock',
      targetType: 'user',
      targetId: result.owner.id,
      details: { reason, includeMembers, users: result.users },
    });
    res.json({ success: true, data: result.users, message: `${result.users.length} account(s) ${locked ? 'locked' : 'unlocked'}` });
  } catch (error) {
    sendError(res, error, 'setWithdrawalLock');
  }
};

// POST /affiliates/:uid/adjust  { coin: 'usdt'|'bjb', amount (+credit / -debit), reason }
// Debit balance se zyada ho to balance 0 tak hi katta hai (negative nahi).
exports.adjustBalance = async (req, res) => {
  const coin = String(req.body.coin || '').toLowerCase();
  const amount = Number(req.body.amount);
  const reason = String(req.body.reason || '').trim();
  try {
    if (!ADJUST_COINS.includes(coin)) throw fail(400, 'Coin must be USDT or BJB');
    if (!Number.isFinite(amount) || amount === 0) throw fail(400, 'Amount must be a non-zero number');
    if (Math.abs(amount) > 100000) throw fail(400, 'Amount too large');
    if (!reason) throw fail(400, 'Reason is required');

    const result = await withTransaction(async (client) => {
      const owner = await getOwner(client, req.params.uid);
      const bal = await client.query(
        `SELECT COALESCE(${coin}, 0) AS balance FROM credits WHERE uid = $1 FOR UPDATE`,
        [owner.id]
      );
      if (!bal.rows.length) throw fail(404, 'Wallet not found');
      const before = Number(bal.rows[0].balance);
      const delta = amount < 0 ? -Math.min(-amount, before) : amount;
      if (delta === 0) throw fail(400, 'Balance is already 0');
      const after = before + delta;

      await client.query(`UPDATE credits SET ${coin} = $1 WHERE uid = $2`, [after, owner.id]);
      // netamount = asli wallet movement (balance sheet ke liye); profit/loss 0 — P&L me na gine.
      await client.query(
        `INSERT INTO credits_ledger (user_id, currency, amount, reason, description, netamount, profit, loss, closing, balance)
         VALUES ($1, $2, $3, 'AFFILIATE_ADJUSTMENT', $4, $3, 0, 0, $5, $5)`,
        [String(owner.id), coin.toUpperCase(), delta, `Admin affiliate adjustment: ${reason}`, after]
      );
      return { owner, before, after, delta };
    });
    recordActivity({
      req,
      action: 'affiliate.balance_adjust',
      targetType: 'user',
      targetId: result.owner.id,
      details: { coin, requested: amount, applied: result.delta, before: result.before, after: result.after, reason },
    });
    res.json({ success: true, data: { coin, ...result }, message: `${coin.toUpperCase()} ${result.before} → ${result.after}` });
  } catch (error) {
    sendError(res, error, 'adjustBalance');
  }
};

// POST /affiliates/:uid/dedupe-commission  { reason }
// Sirf duplicate reward ROWS hatata hai (affiliate history ka display). Wallet se
// paisa wapas lena ho to alag se /adjust use karo.
exports.dedupeCommission = async (req, res) => {
  const reason = String(req.body.reason || '').trim();
  try {
    if (!reason) throw fail(400, 'Reason is required');
    const result = await withTransaction(async (client) => {
      const owner = await getOwner(client, req.params.uid, true);
      const r = await client.query(
        `DELETE FROM rewards r
          USING rewards k
          WHERE r.type = 'commission' AND k.type = 'commission'
            AND r.ownername = $1 AND k.ownername = r.ownername
            AND k.membername = r.membername AND k."createdAt" = r."createdAt"
            AND r.id > k.id
          RETURNING r.id, r.membername, r.amount, r."createdAt"`,
        [owner.name]
      );
      return { owner, removed: r.rows };
    });
    const removedAmount = result.removed.reduce((s, x) => s + Number(x.amount), 0);
    recordActivity({
      req,
      action: 'affiliate.commission_dedupe',
      targetType: 'user',
      targetId: result.owner.id,
      details: { reason, removedRows: result.removed.length, removedAmount, rows: result.removed },
    });
    res.json({
      success: true,
      data: { removedRows: result.removed.length, removedAmount },
      message: `Removed ${result.removed.length} duplicate row(s) (${removedAmount.toFixed(6)} USDT). Wallet not changed.`,
    });
  } catch (error) {
    sendError(res, error, 'dedupeCommission');
  }
};

// POST /pools/:id/void  { reason }
// Referral pool 0 kar deta hai aur us member ke unclaimed unlocked rewards cancel.
exports.voidPool = async (req, res) => {
  const reason = String(req.body.reason || '').trim();
  try {
    if (!reason) throw fail(400, 'Reason is required');
    const result = await withTransaction(async (client) => {
      const p = await client.query(
        `SELECT id, ownername, membername, amount FROM rewards
          WHERE id = $1 AND type = 'referral' FOR UPDATE`,
        [req.params.id]
      );
      if (!p.rows.length) throw fail(404, 'Referral pool not found');
      const pool = p.rows[0];
      await client.query(`UPDATE rewards SET amount = 0, "updatedAt" = NOW() WHERE id = $1`, [pool.id]);
      const cancelled = await client.query(
        `DELETE FROM unlocked_rewards
          WHERE ownername = $1 AND membername = $2 AND claimed = false
          RETURNING id, amount, wager_amount`,
        [pool.ownername, pool.membername]
      );
      return { pool, cancelled: cancelled.rows };
    });
    recordActivity({
      req,
      action: 'affiliate.pool_void',
      targetType: 'reward',
      targetId: result.pool.id,
      details: { reason, pool: result.pool, cancelledUnlocked: result.cancelled },
    });
    res.json({
      success: true,
      data: result,
      message: `Pool voided (${result.pool.amount} removed), ${result.cancelled.length} unclaimed reward(s) cancelled`,
    });
  } catch (error) {
    sendError(res, error, 'voidPool');
  }
};

// POST /unlocked/:id/cancel  { reason }  — sirf unclaimed reward
exports.cancelUnlocked = async (req, res) => {
  const reason = String(req.body.reason || '').trim();
  try {
    if (!reason) throw fail(400, 'Reason is required');
    const r = await withTransaction(async (client) => {
      const d = await client.query(
        `DELETE FROM unlocked_rewards WHERE id = $1 AND claimed = false RETURNING *`,
        [req.params.id]
      );
      if (!d.rows.length) throw fail(404, 'Unclaimed reward not found (already claimed?)');
      return d.rows[0];
    });
    recordActivity({
      req,
      action: 'affiliate.unlocked_cancel',
      targetType: 'reward',
      targetId: r.id,
      details: { reason, reward: r },
    });
    res.json({ success: true, data: r, message: `Cancelled unclaimed reward of ${r.amount}` });
  } catch (error) {
    sendError(res, error, 'cancelUnlocked');
  }
};

// GET /activity — affiliate admin actions ka log
exports.getActivity = async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT id, actor_name, actor_role, action, target_type, target_id, details, status, created_at
         FROM admin_activity_logs
        WHERE action LIKE 'affiliate.%'
        ORDER BY created_at DESC
        LIMIT 200`
    );
    res.json({ success: true, data: rows });
  } catch (error) {
    sendError(res, error, 'getActivity');
  }
};
