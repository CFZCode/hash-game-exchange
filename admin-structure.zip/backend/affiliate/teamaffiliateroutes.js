const express = require('express');
const router = express.Router();
const teamController = require('./affiliateteamcontroller');
const adminAffiliateController = require('./adminAffiliateController');
const manage = require('./adminAffiliateManageController');
const { guardAdmin } = require('../system/middleware/guardAdmin');

// Sab admin routes staff token ke peeche. PUT /settings pehle public tha —
// koi bhi comissionpercent / registerbonus badal sakta tha.
router.use(guardAdmin('affiliateAdmin'));

// Affiliate section sirf SuperAdmin (role level 0) ke liye.
const MAX_LEVEL = 0;
router.use((req, res, next) => {
  if (!req.staff || Number(req.staff.level) > MAX_LEVEL) {
    return res.status(403).json({ success: false, message: 'SuperAdmin access required' });
  }
  next();
});

router.get('/teams', teamController.getAllTeams);
router.get('/teams/:teamId/members', teamController.getTeamMembers);
router.get('/users-with-teams', teamController.getUsersWithTeams);

// Admin affiliate dashboard & settings
router.get('/dashboard-stats', adminAffiliateController.getDashboardStats);
router.get('/settings', adminAffiliateController.getAffiliateSettings);
router.put('/settings', adminAffiliateController.updateAffiliateSettings);
router.get('/rewards-list', adminAffiliateController.getRewardsList);
router.get('/top-affiliates', adminAffiliateController.getTopAffiliates);

// Affiliate management
router.get('/affiliates', manage.listAffiliates);
router.get('/affiliates/:uid', manage.getAffiliate);
router.post('/affiliates/:uid/withdrawal-lock', manage.setWithdrawalLock);
router.post('/affiliates/:uid/adjust', manage.adjustBalance);
router.post('/affiliates/:uid/dedupe-commission', manage.dedupeCommission);
router.post('/pools/:id/void', manage.voidPool);
router.post('/unlocked/:id/cancel', manage.cancelUnlocked);
router.get('/activity', manage.getActivity);

module.exports = router;
