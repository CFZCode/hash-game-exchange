const express = require('express');
const router = express.Router();
const AffiliateController = require('./affiliatecontroller');
const AffiliateUnlockController = require('./affiliateunlockcontroller');
const { guardPlayer } = require('../system/middleware/guardPlayer');

// Paisa/likhne wale routes guardPlayer ke peeche hain. team/add, rewards/record aur
// process-wager public the (koi bhi kisi ka reward unlock + claim kar sakta tha) —
// hata diye, internal code controller seedha call karta hai.


// Get Referral Info for a User
router.get('/referral-info/:userId', async (req, res) => {
  try {
    const userId = req.params.userId;
    const referralInfo = await AffiliateController.getUserReferralInfo(userId);
    res.json(referralInfo);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get Team Data by Referral Code
router.get('/team/:referralCode', async (req, res) => {
  try {
    const referralCode = req.params.referralCode;
    const teamData = await AffiliateController.getTeamData(referralCode);
    res.json(teamData);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get User Rewards
router.get('/rewards/:referralCode', async (req, res) => {
  try {
    const referralCode = req.params.referralCode;
    const rewards = await AffiliateController.getUserRewards(referralCode);
    res.json(rewards);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get unclaimed rewards for a user
router.get('/unclaimed-rewards/:uid', guardPlayer, async (req, res) => {
  try {
    const uid = req.playerUid; // token se, URL wala uid ignore
    const rewards = await AffiliateUnlockController.getUnclaimedRewards(uid);
    res.json(rewards);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Claim a specific reward
router.post('/claim-reward', guardPlayer, async (req, res) => {
  try {
    const uid = req.playerUid; // token se, body wala uid ignore
    const { rewardId } = req.body;
    const result = await AffiliateUnlockController.claimReward(uid, rewardId);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
//claim all reward 
router.post('/claim-reward-all', guardPlayer, async (req, res) => {
  try {
    const uid = req.playerUid; // token se, body wala uid ignore
    const result = await AffiliateUnlockController.claimAllRewards(uid);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;