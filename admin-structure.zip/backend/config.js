const developer = true;

//DEVELOPER
let port = 9051;
let postgresDB = "postgres://myapp1:myapp1@127.0.0.1:5432/myapp1";
let mongoDB = "mongodb://localhost:27017";
let secretRecaptcha = "REMOVED_SECRET";
let apiURL = "https://example.com";
let avatarUrl = "http://localhost:" + port + "/uploads/";
let house = 2; // HoseEdge


//PRODUCTION
// if (!developer) {
//   apiURL = "https://";
//   postgresDB = "postgres://postgres:postgres@127.0.0.1:5432/postgres";
//   mongoDB = "mongodb://localhost:27017";
// }

// Bots Limit Playing
const BotsLimit = 80;

// Default Aff Amount
const aff_amount = "10.000";

const gmail = "support@example.com";
const pass = "REMOVED_SECRET";

// Telegram bot for financial-transaction alerts. Fill these in (here or via the
// TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID env vars). Leave empty to disable Telegram.
const telegramBotToken = process.env.TELEGRAM_BOT_TOKEN || "REMOVED_SECRET";
const telegramChatId   = process.env.TELEGRAM_CHAT_ID   || "REMOVED_SECRET";

// Coin Market API Token
const coinMarketApi = "REMOVED_SECRET";

const NowPaymentApi = "REMOVED_SECRET";

const btcAddress = "bc1qdgtmetrn3ymwqp7d0mlxrkftwk4pne79lqj9lj";
const ethAddress = "0xe195dd2b534281bf4d67bf4fa9e873260d6a6efe";
const ltcAddress = "ltc1qq2e0lp0x6nmua5m4mt9pxzwme90qnl9fwjvx5z";
const trxAddress = "TD4uSraaU8wsjV2tf4krzoZWFEAaE1ecEH";
const bchAddress = "qp0wc5vzm933wmpz5xkcueee2sf3eyywv5h2mdk7l7";
const bAddress = "0xe195dd2b534281bf4d67bf4fa9e873260d6a6efe";
const upi = "myapp.service@okhdfcbank";


// //from binane wallet
const bscAddress = "0xe195dd2b534281bf4d67bf4fa9e873260d6a6efe";

// const coinMarketApi = "REMOVED_SECRET";

// const NowPaymentApi = "REMOVED_SECRET";

// const btcAddress = "bc1qvw9ze6e7f27dstmvz8wrzuf8wlu4dtd3t8znts";
// const ethAddress = "0x25c8B42a43e45a8e4328480D32c4C002aa3261f5";
// const ltcAddress = "ltc1qmsuy45df37fx2u2vykwtltjrj3e729tn3rq7kp";
// const trxAddress = "TPKVkwiy1FLA3hjrHGR9Dmh53RxbGdbHhp";
// const bchAddress = "qryvdxgarl0g7my59zl9w74hk0zk27zmccz9eskz7j";
// const bAddress = "0x25c8B42a43e45a8e4328480D32c4C002aa3261f5";

// //from binance wallet
// const bscAddress = "0x25c8B42a43e45a8e4328480D32c4C002aa3261f5";

// Default Balance
const BALANCE = {
  btc: "0.00000000",
  eth: "0.00000000",
  usdt: "0.00000000",
  bch: "0.00000000",
  ltc: "0.00000000",
  trx: "0.00000000",
  doge: "0.00000000",
  ada: "0.00000000",
  xrp: "0.00000000",
  bnb: "0.00000000",
  usdp: "0.00000000",
  nexo: "0.00000000",
  mkr: "0.00000000",
  tusd: "0.00000000",
  usdc: "0.00000000",
  busd: "0.00000000",
  inr: "0.00000000",
  sc: "0.00000000",
  mvr: "0.00000000",
  bjt: "0.00000000",
  aed: "0.00000000",
  npr: "0.00000000",
  pkr: "0.00000000"
};

// Default Wallet
const WALLET = {
  btc: null,
  eth: null,
  ltc: null,
  bch: null,
  usdt: null,
  trx: null,
  nc: null,
  doge: null,
  ada: null,
  xrp: null,
  bnb: null,
  usdp: null,
  nexo: null,
  mkr: null,
  tusd: null,
  usdc: null,
  busd: null,
  inr: null,
  sc: null,
  mvr: null,
  bjt: null,
  aed: null,
  npr: null,
  pkr: null,
};

module.exports = {
  developer: developer,
  dbUrl: postgresDB,
  mgUrl: mongoDB,
  port: port,
  house: house,
  secretRecaptcha: secretRecaptcha,
  API_URL: apiURL,
  AFF_AMOUNT: aff_amount,
  avatarUrl: avatarUrl,
  BotsLimit: BotsLimit,
  BALANCE: BALANCE,
  WALLET: WALLET,

  GMAIL_NAME: gmail,
  GMAIL_PASS: pass,
  COIN_MARKET_API: coinMarketApi,

  NOW_PAYMENT_API: NowPaymentApi,

  BTC_ADDRESS: btcAddress,
  upi_address: upi,
  ETH_ADDRESS: ethAddress,
  LTC_ADDRESS: ltcAddress,
  TRX_ADDRESS: trxAddress,
  BCH_ADDRESS: bchAddress,
  BINANCE_WALLET_ADDRESS: bAddress,
  BSC_ADDRESS: bscAddress,

  TELEGRAM_BOT_TOKEN: telegramBotToken,
  TELEGRAM_CHAT_ID: telegramChatId,
};
