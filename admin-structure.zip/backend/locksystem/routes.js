const controller = require('./controller');
const express = require('express');
const router = express.Router();
const { protectStaff, accessStaff } = require('../system/middleware/auth.js')


router.post('/update-system-lock', protectStaff, accessStaff, controller.updateLockSystemForAdmin)


module.exports = router;