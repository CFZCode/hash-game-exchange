const pg = require('../General/Model')
const axios = require('axios')

module.exports.updateLockSystemForAdmin = async (req, res) => {
    try {
        const { user_id, staff_id, all_system_blocked, casino_blocked, sports_betlocked } = req.body
        if (!user_id && !staff_id) return res.status(400).json({ success: false, error: "please provide user or staff." })

        let updateObject = {
            ...(all_system_blocked !== undefined && { all_system_blocked }),
            ...(casino_blocked !== undefined && { casino_blocked }),
            ...(sports_betlocked !== undefined && { sports_betlocked })
        }

        const keys = Object.keys(updateObject);
        if (keys.length === 0) {
            return res.status(400).json({ success: false, error: "Nothing to update" });
        }


        await pg.query('BEGIN');



        if (user_id) {
            const setClause = keys
                .map((key, index) => `${key} = $${index + 1}`)
                .join(', ');

            // values for SET
            const values = keys.map(key => updateObject[key]);

            // add user_id for WHERE id
            values.push(user_id);

            // base query
            let query = `UPDATE users SET ${setClause} WHERE id = $${values.length}`;

            // optional condition (safe)
            if (req.staff.level) {
                values.push(req.staff.id);
                query += ` AND parent_staff_id = $${values.length}`;
            }

            await pg.query(query, values);

        }
        else if (staff_id && req.staff.level == 0) {

            const setClause = keys.map((key, index) => `${key} = $${index + 1}`).join(', ');
            const values = keys.map(key => updateObject[key]);

            const checkStaff = await pg.query(`select id FROM staff WHERE id =$1`, [staff_id])
            if (checkStaff?.rows.length == 0) return res.status(400).json({ error: 'Invalid staff id.' });

            values.push(staff_id);
            const query = `UPDATE users SET ${setClause} WHERE parent_staff_id = $${values.length}`;
            const queryForStaff = `UPDATE staff SET ${setClause} WHERE id = $1 AND parent_id IS NOT NULL`;

            await Promise.all([
                pg.query(query, values),
                pg.query(queryForStaff, [staff_id]),
            ])

        }

        await pg.query('COMMIT');
        return res.status(200).json({
            message: "Lock update successfully."
        });
    } catch (error) {
        await pg.query('ROLLBACK');
        console.error('Failed to update lock process:', error);
        return res.status(500).json({ error: 'Failed to update lock process' });
    }
};