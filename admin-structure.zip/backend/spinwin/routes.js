const express = require('express');
const router = express.Router();
const ctrl = require('./controller');
const { protectStaff } = require('../system/middleware/auth');

/* ── Admin routes (staff-protected) ── */
router.get('/admin/config', protectStaff, ctrl.getConfig);
router.put('/admin/config', protectStaff, ctrl.updateConfig);
router.get('/admin/claims', protectStaff, ctrl.listClaims);

/* ── Admin slice management ── */
router.get('/admin/slices', protectStaff, ctrl.getSlices);
router.post('/admin/slices', protectStaff, ctrl.addSlice);
router.put('/admin/slices-bulk', protectStaff, ctrl.bulkUpdateSlices);
router.put('/admin/slices/:id', protectStaff, ctrl.updateSlice);
router.delete('/admin/slices/:id', protectStaff, ctrl.deleteSlice);

/* ── Public routes (frontend wheel render) ── */
router.get('/slices', ctrl.getPublicSlices);

/* ── User routes ── */
router.get('/user/eligibility', ctrl.checkEligibility);
router.post('/user/claim', ctrl.claimReward);

module.exports = router;
