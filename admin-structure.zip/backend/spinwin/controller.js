const pg = require('../General/Model');
const crypto = require('crypto');

/* ══════════════════════════════════════════════
   Helpers
   ══════════════════════════════════════════════ */

// Generate unique 8-char redeem code
async function generateRedeemCode() {
  let code;
  let isUnique = false;
  while (!isUnique) {
    code = crypto.createHash('sha256')
      .update(`spin-${Date.now()}-${Math.random()}`)
      .digest('hex')
      .slice(0, 8)
      .toUpperCase();
    const { rowCount } = await pg.query('SELECT 1 FROM redeembonus WHERE code = $1', [code]);
    if (rowCount === 0) isUnique = true;
  }
  return code;
}

// Weighted random pick from slices
function pickWeightedSlice(slices) {
  const totalWeight = slices.reduce((sum, s) => sum + Number(s.weight), 0);
  let rand = Math.random() * totalWeight;
  for (let i = 0; i < slices.length; i++) {
    rand -= Number(slices[i].weight);
    if (rand <= 0) return i;
  }
  return 0;
}

// Get first deposit across all gateway tables
async function getFirstDeposit(userId) {
  const uid = String(userId);
  const { rows } = await pg.query(
    `SELECT amount, created_at FROM (
       SELECT amount::numeric AS amount, created_at
       FROM ccdeposit
       WHERE userid = $1 AND LOWER(status) IN ('completed', 'success')
       UNION ALL
       SELECT (CASE WHEN paid_amount > 0 THEN paid_amount ELSE amount END)::numeric AS amount, created_at
       FROM apaydeposits
       WHERE user_id = $2::bigint AND LOWER(status) IN ('completed', 'success')
       UNION ALL
       SELECT amount::numeric AS amount, created_at
       FROM pay_in_transactions
       WHERE user_id = $2::bigint AND status = 1
       UNION ALL
       SELECT amount::numeric AS amount, created_at
       FROM fiat_deposits
       WHERE user_id = $2::bigint AND LOWER(status) = 'approved'
     ) AS all_deposits
     ORDER BY created_at ASC
     LIMIT 1`,
    [uid, uid]
  );
  return rows[0] || null;
}

/* ══════════════════════════════════════════════
   ADMIN — Config
   ══════════════════════════════════════════════ */

exports.getConfig = async (req, res, next) => {
  try {
    const { rows } = await pg.query('SELECT * FROM spin_wheel_config ORDER BY id LIMIT 1');
    res.json({ success: true, data: rows[0] || null });
  } catch (e) { next(e); }
};

exports.updateConfig = async (req, res, next) => {
  try {
    const { min_deposit, claim_cooldown_days, is_active, unlimited_spin } = req.body;
    // const { rows } = await pg.query(
    //   `UPDATE spin_wheel_config
    //    SET min_deposit         = COALESCE($1, min_deposit),
    //        claim_cooldown_days = COALESCE($2, claim_cooldown_days),
    //        is_active           = COALESCE($3, is_active),
    //        unlimited_spin      = COALESCE($4, unlimited_spin),
    //        updated_at          = NOW()
    //    WHERE id = (SELECT id FROM spin_wheel_config ORDER BY id LIMIT 1)
    //    RETURNING *`,
    //   [min_deposit, claim_cooldown_days, is_active, unlimited_spin]
    // );

    const { rows } = await pg.query(
      `INSERT INTO spin_wheel_config (min_deposit, claim_cooldown_days, is_active, unlimited_spin, updated_at)
   VALUES ($1, $2, $3, $4, NOW())
   ON CONFLICT (id) DO UPDATE
     SET min_deposit         = COALESCE(EXCLUDED.min_deposit, spin_wheel_config.min_deposit),
         claim_cooldown_days = COALESCE(EXCLUDED.claim_cooldown_days, spin_wheel_config.claim_cooldown_days),
         is_active           = COALESCE(EXCLUDED.is_active, spin_wheel_config.is_active),
         unlimited_spin      = COALESCE(EXCLUDED.unlimited_spin, spin_wheel_config.unlimited_spin),
         updated_at          = NOW()
   RETURNING *`,
      [min_deposit, claim_cooldown_days, is_active, unlimited_spin]
    );
    res.json({ success: true, data: rows[0] });
  } catch (e) { next(e); }
};

/* ══════════════════════════════════════════════
   ADMIN — Slice CRUD
   ══════════════════════════════════════════════ */

exports.getSlices = async (req, res, next) => {
  try {
    const { rows } = await pg.query('SELECT * FROM spin_wheel_slices ORDER BY sort_order ASC');
    res.json({ success: true, data: rows });
  } catch (e) { next(e); }
};

exports.addSlice = async (req, res, next) => {
  try {
    const { label, reward_pct, color, sort_order, is_bad_luck, weight } = req.body;
    if (!label) return res.status(400).json({ success: false, message: 'label required' });
    const { rows } = await pg.query(
      `INSERT INTO spin_wheel_slices (label, reward_pct, color, sort_order, is_bad_luck, weight)
       VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
      [label, reward_pct || 0, color || '#1a1a2e', sort_order || 0, is_bad_luck || false, weight || 10]
    );
    res.json({ success: true, data: rows[0] });
  } catch (e) { next(e); }
};

exports.updateSlice = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { label, reward_pct, color, sort_order, is_bad_luck, weight } = req.body;
    const { rows } = await pg.query(
      `UPDATE spin_wheel_slices
       SET label = COALESCE($1, label), reward_pct = COALESCE($2, reward_pct),
           color = COALESCE($3, color), sort_order = COALESCE($4, sort_order),
           is_bad_luck = COALESCE($5, is_bad_luck), weight = COALESCE($6, weight)
       WHERE id = $7 RETURNING *`,
      [label, reward_pct, color, sort_order, is_bad_luck, weight, id]
    );
    if (!rows.length) return res.status(404).json({ success: false, message: 'Not found' });
    res.json({ success: true, data: rows[0] });
  } catch (e) { next(e); }
};

exports.deleteSlice = async (req, res, next) => {
  try {
    const { rowCount } = await pg.query('DELETE FROM spin_wheel_slices WHERE id = $1', [req.params.id]);
    if (!rowCount) return res.status(404).json({ success: false, message: 'Not found' });
    res.json({ success: true });
  } catch (e) { next(e); }
};

exports.bulkUpdateSlices = async (req, res, next) => {
  try {
    const { slices } = req.body;
    if (!Array.isArray(slices)) return res.status(400).json({ success: false, message: 'slices array required' });

    await pg.query('DELETE FROM spin_wheel_slices');
    for (let i = 0; i < slices.length; i++) {
      const s = slices[i];
      await pg.query(
        `INSERT INTO spin_wheel_slices (label, reward_pct, color, sort_order, is_bad_luck, weight)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [s.label, s.reward_pct || 0, s.color || '#1a1a2e', i + 1, s.is_bad_luck || false, s.weight || 10]
      );
    }
    const { rows } = await pg.query('SELECT * FROM spin_wheel_slices ORDER BY sort_order ASC');
    res.json({ success: true, data: rows });
  } catch (e) { next(e); }
};

/* ══════════════════════════════════════════════
   ADMIN — Claims history
   ══════════════════════════════════════════════ */

exports.listClaims = async (req, res, next) => {
  try {
    const page = Math.max(parseInt(req.query.page) || 1, 1);
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const offset = (page - 1) * limit;

    const { rows } = await pg.query(
      `SELECT c.*, u.name AS username
       FROM spin_wheel_claims c
       LEFT JOIN users u ON u.id = c.user_id
       ORDER BY c.claimed_at DESC
       LIMIT $1 OFFSET $2`,
      [limit, offset]
    );
    const { rows: countRows } = await pg.query('SELECT COUNT(*)::int AS total FROM spin_wheel_claims');
    res.json({ success: true, data: rows, total: countRows[0].total, page, limit });
  } catch (e) { next(e); }
};

/* ══════════════════════════════════════════════
   PUBLIC — Get slices (for frontend wheel render)
   ══════════════════════════════════════════════ */

// GET /api/spinwin/slices  (no auth — frontend needs this to draw the wheel)
exports.getPublicSlices = async (req, res, next) => {
  try {
    const { rows: cfgRows } = await pg.query('SELECT is_active FROM spin_wheel_config ORDER BY id LIMIT 1');
    if (!cfgRows[0]?.is_active) {
      return res.json({ success: true, data: [], disabled: true });
    }
    // Return slices WITHOUT weight (don't expose probabilities to user)
    const { rows } = await pg.query(
      `SELECT id, label, reward_pct, color, sort_order, is_bad_luck
       FROM spin_wheel_slices ORDER BY sort_order ASC`
    );
    res.json({ success: true, data: rows });
  } catch (e) { next(e); }
};

/* ══════════════════════════════════════════════
   USER — Check eligibility
   Logic:
   - First spin is ALWAYS free (no deposit needed)
   - After first spin → cooldown (admin-configurable days)
   - If unlimited_spin is ON → no cooldown, spin anytime
   ══════════════════════════════════════════════ */

exports.checkEligibility = async (req, res, next) => {
  try {
    const userId = req.query.user_id;
    if (!userId) return res.status(400).json({ success: false, message: 'user_id required' });

    const { rows: cfgRows } = await pg.query('SELECT * FROM spin_wheel_config ORDER BY id LIMIT 1');
    const config = cfgRows[0];
    if (!config || !config.is_active) {
      return res.json({ success: true, eligible: false, reason: 'Spin wheel is disabled' });
    }

    // Check how many times user has spun
    const { rows: claimRows } = await pg.query(
      `SELECT claimed_at FROM spin_wheel_claims WHERE user_id = $1 ORDER BY claimed_at DESC LIMIT 1`,
      [userId]
    );

    // Never spun before → always eligible (first spin free)
    if (claimRows.length === 0) {
      const firstDep = await getFirstDeposit(userId);
      return res.json({ success: true, eligible: true, deposit_amount: firstDep?.amount || 0 });
    }

    // Unlimited spin mode → always eligible
    if (config.unlimited_spin) {
      const firstDep = await getFirstDeposit(userId);
      return res.json({ success: true, eligible: true, deposit_amount: firstDep?.amount || 0 });
    }

    // Cooldown check
    const lastClaim = new Date(claimRows[0].claimed_at);
    const cooldownMs = config.claim_cooldown_days * 24 * 60 * 60 * 1000;
    const nextEligible = new Date(lastClaim.getTime() + cooldownMs);

    if (Date.now() < nextEligible.getTime()) {
      return res.json({ success: true, eligible: false, reason: 'Cooldown active', next_eligible: nextEligible });
    }

    // Cooldown passed — check deposit requirement for repeat spins
    const firstDep = await getFirstDeposit(userId);
    if (!firstDep) {
      return res.json({ success: true, eligible: false, reason: 'Make a deposit to spin again' });
    }
    if (Number(firstDep.amount) < Number(config.min_deposit)) {
      return res.json({ success: true, eligible: false, reason: `Minimum deposit of ${config.min_deposit} required` });
    }

    return res.json({ success: true, eligible: true, deposit_amount: firstDep.amount });
  } catch (e) { next(e); }
};

/* ══════════════════════════════════════════════
   USER — Spin & Claim
   Server decides the winning slice (weighted),
   generates a redeem code, returns win_index.
   ══════════════════════════════════════════════ */

exports.claimReward = async (req, res, next) => {
  try {
    const { user_id } = req.body;
    if (!user_id) return res.status(400).json({ success: false, message: 'user_id required' });

    // 1. Config
    const { rows: cfgRows } = await pg.query('SELECT * FROM spin_wheel_config ORDER BY id LIMIT 1');
    const config = cfgRows[0];
    if (!config || !config.is_active) {
      return res.status(400).json({ success: false, message: 'Spin wheel is disabled' });
    }

    // 2. Check claims history
    const { rows: claimRows } = await pg.query(
      `SELECT claimed_at FROM spin_wheel_claims WHERE user_id = $1 ORDER BY claimed_at DESC LIMIT 1`,
      [user_id]
    );

    const hasSpunBefore = claimRows.length > 0;

    // 3. Cooldown check (skip if first spin or unlimited mode)
    if (hasSpunBefore && !config.unlimited_spin) {
      const lastClaim = new Date(claimRows[0].claimed_at);
      const cooldownMs = config.claim_cooldown_days * 24 * 60 * 60 * 1000;
      if (Date.now() < lastClaim.getTime() + cooldownMs) {
        return res.status(400).json({ success: false, message: 'Cooldown period not passed' });
      }

      // Deposit check for repeat spins only
      const firstDep = await getFirstDeposit(user_id);
      if (!firstDep || Number(firstDep.amount) < Number(config.min_deposit)) {
        return res.status(400).json({ success: false, message: 'Deposit requirement not met' });
      }
    }

    // 4. Get slices & pick winner (weighted)
    const { rows: slices } = await pg.query('SELECT * FROM spin_wheel_slices ORDER BY sort_order ASC');
    if (!slices.length) {
      return res.status(400).json({ success: false, message: 'No slices configured' });
    }

    const winIndex = pickWeightedSlice(slices);
    const winSlice = slices[winIndex];
    const isBadLuck = winSlice.is_bad_luck || Number(winSlice.reward_pct) === 0;
    const winPct = Number(winSlice.reward_pct);

    // 5. Generate redeem code with PERCENTAGE (bonus calculated at deposit time)
    let redeemCode = null;
    if (!isBadLuck) {
      // Expire any previous unused spin wheel codes for this user
      await pg.query(
        `UPDATE redeembonus SET status = 'expired', updatedat = NOW()
         WHERE userid = $1 AND source = 'spinwheel' AND status = 'active'`,
        [user_id]
      );

      redeemCode = await generateRedeemCode();

      // Store percentage code — amount=0 placeholder, bonus_pct holds the real value
      // When user redeems during deposit, bonus = deposit_amount × bonus_pct%
      await pg.query(
        `INSERT INTO redeembonus (userid, code, amount, status, bonus_pct, source, createdat, updatedat)
         VALUES ($1, $2, 0, 'active', $3, 'spinwheel', NOW(), NOW())`,
        [user_id, redeemCode, winPct]
      );
    }

    // 6. Record claim
    await pg.query(
      `INSERT INTO spin_wheel_claims (user_id, deposit_amount, reward_amount, slice_label, redeem_code)
       VALUES ($1, 0, 0, $2, $3)`,
      [user_id, winSlice.label, redeemCode]
    );

    res.json({
      success: true,
      win_index: winIndex,
      win_slice: {
        label: winSlice.label,
        reward_pct: winPct,
        is_bad_luck: isBadLuck,
        color: winSlice.color
      },
      redeem_code: redeemCode,
      message: isBadLuck
        ? 'Better luck next time!'
        : `You won ${winSlice.label} bonus on deposit! Use code ${redeemCode} while depositing.`
    });
  } catch (e) { next(e); }
};
