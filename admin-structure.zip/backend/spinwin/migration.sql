-- Spin Wheel Configuration (admin-managed settings)
CREATE TABLE IF NOT EXISTS spin_wheel_config (
  id            SERIAL PRIMARY KEY,
  min_deposit   NUMERIC(18,2)  NOT NULL DEFAULT 100,      -- minimum first deposit to qualify
  reward_pct    NUMERIC(5,2)   NOT NULL DEFAULT 5.00,      -- % of deposit as reward
  claim_cooldown_days INTEGER  NOT NULL DEFAULT 7,          -- days between claims
  is_active     BOOLEAN        NOT NULL DEFAULT TRUE,       -- master on/off
  created_at    TIMESTAMPTZ    DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMPTZ    DEFAULT CURRENT_TIMESTAMP
);

-- Seed one default config row
INSERT INTO spin_wheel_config (min_deposit, reward_pct, claim_cooldown_days, is_active)
VALUES (100, 5.00, 7, true)
ON CONFLICT DO NOTHING;

-- Spin Wheel Claims (one record per user claim)
CREATE TABLE IF NOT EXISTS spin_wheel_claims (
  id              SERIAL PRIMARY KEY,
  user_id         BIGINT         NOT NULL,
  deposit_amount  NUMERIC(18,2)  NOT NULL,   -- the first-deposit amount used
  reward_amount   NUMERIC(18,2)  NOT NULL,   -- calculated reward
  claimed_at      TIMESTAMPTZ    DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_swc_user ON spin_wheel_claims(user_id);
