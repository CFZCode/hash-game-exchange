const crypto = require('crypto');

export function generateMD5Hash(requestTime, operation) {
  const secretKey = 'REMOVED_SECRET';  
  const operatorCode = 'I201';  
  const stringToHash = requestTime + secretKey +operation + operatorCode;
  console.log(stringToHash);
  const hash = crypto.createHash('md5').update(stringToHash).digest('hex');
  console.log(hash);
  return hash;
}
  