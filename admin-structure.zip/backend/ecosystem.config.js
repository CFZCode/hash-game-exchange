module.exports = {
  apps: [
    {
      name: 'sports-worker-fcm',
      script: 'workers/sportsWorker.js',
      instances: 1,
      max_memory_restart: '500M',
      env: {
        NODE_ENV: 'production',
      },
      // new options
      autorestart: true,
      restart_delay: 5000,   // wait 5s before restart to avoid crash loop
      max_restarts: 10,      // limit restarts in short period
      watch: false,
      out_file: './logs/sports-worker-out.log',
      error_file: './logs/sports-worker-err.log',
      merge_logs: true,
    },
  ],
};
