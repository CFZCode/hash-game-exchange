"use strict";

//Random Generate Hash/Result

//Required Libs
var SHA256 = require("crypto-js/sha256");

const Result = {};

Result.make = function (canProfit, payout) {
  let hash = makeHash();
  let result = makeResult(hash);

  if (!canProfit) {
    if (parseFloat(result) > parseFloat(payout)) {
      return Result.make(false, payout);
    }
  }

  // let random = Math.random();

  // if (canProfit) {
  //   hash = makeHash();
  //   result = makeResult(hash);
  //   // if (parseFloat(result) > parseFloat(payout)) {
  //   //   return Result.make(false, payout);
  //   // }
  // } else {
  //   if (result < payout) {
  //     if (random < 0.45) {
  //       return { hash, result };
  //     } else {
  //       return Result.make(false, payout);
  //     }
  //   } else {
  //     Result.make(true, payout);
  //   }

  //   // if (result > payout) {
  //   //   if (random > 0.45) {
  //   //     if (parseFloat(result) > parseFloat(payout)) {
  //   //       return Result.make(false, payout);
  //   //     } else {
  //   //       return { hash, result };
  //   //     }
  //   //   }
  //   // }
  // }

  // if (parseFloat(result) < parseFloat(payout)) {
  //   const random = Math.random(); // Generate a random number between 0 and 1

  //   if (random <= 0.45) {
  //     // Return true 45% of the time
  //     return Result.make(false, payout);
  //   }
  // }

  return { hash, result };
};

function makeHash() {
  var key = "00000000000000" + randomString(50);
  var gameHash = SHA256(key).toString();
  return gameHash;
}

function makeResult(seed) {
  let hash = SHA256(seed).toString();
  let h = parseInt(hash.slice(0, 13), 16);
  let e = Math.pow(2, 52);
  let result = Math.floor((98 * e) / (e - h));
  result = (result / 100).toFixed(2);
  return result;
}

function randomString(length) {
  var chars = "0123456789abcdefghiklmnopqrstuvwxyz".split("");
  var str = "";
  for (var i = 0; i < length; i++) {
    str += chars[Math.floor(Math.random() * chars.length)];
  }
  return str;
}

// Export the Result module
module.exports = Result;
