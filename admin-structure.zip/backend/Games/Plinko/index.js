const _ = require('lodash');
const Rule = require('../Rule');
const Hash = require('../Hash');
const Queue = require('../../General/Queue');
const { encode } = require('../../General/Buffer');
const H = require('../../General/Helper');
const C = require('../../General/Constant');

class Plinko {
    constructor(io, client, data, id){
        this.io = io
        this.client = client
        this.data = data
        this.id = _.toNumber(id);
    }

    /*
 	 * Send Data To Client
    */
    emit(data){
		this.client.emit(C.PLAY_PLINKO, encode(data))
    }

    /*
	 * Intialize Game
    */
    init(){

		let { command, auto } = this.data;

		switch(command)
		{
			case 'play':
				return this.play();
			case 'busted':
				return this.busted();
		}
    }

    /*
     * Play Game
    */
    play(){
    	let self = this;

		Rule.CanPlay(self.id, self.data, self.client, 'plinko', (status, err) => {
            if(status !== true)
            {
                return this.emit({ command: 'error', uid: self.id, message: status, code: err })
            }

			Rule.preparePlay(self.client, self.id, 'plinko', self.data, (isOk) => {
				if(!isOk){
					console.log('Error Plinko Playing: 21')
					return false;
				}

				//Generate Random Hash and Result
	            let randomResult = Hash.make();
	            let hash = randomResult.hash;

	            //Update Queue and Save Result and Hash
	            Queue.update(self.id, 'uid', 'hash', hash);

				//Send Play Game
				this.emit({ command: 'play', hash: hash });
			})
		})
    }

    /*
     * End / Busted Game
    */
    busted(){
    	let self = this;

		let { bonus } = self.data;

		bonus = parseFloat(bonus);

		//Get The Client Game Info
		let info = Queue.getOne('uid', self.id)

		if(!info) {
			console.log('Client Not Playing!', self.id)
			return false;
		}

	    let hash = info.hash;
	    let result = parseFloat(bonus).toFixed(2);
	    let amount = _.toNumber(info.data.amount);

	    if(result === NaN || result === 'NaN' || _.isNaN(result))
	    	return console.log('error on nan bonus')

	    let profit = 0.00000000;
	    let isWinner = false;

	    if(result === '0.50'){
	    	isWinner = true;
	    	profit = amount / 2;
	    }
	    else if(result === '1.00') {
	    	isWinner = true;
	    	profit = 0.00000000;
	    }
		else if(result === '1.10')
		{
			isWinner = true;
			profit = amount /10;
		}
		else if(result === '5.60')
		{
			isWinner = true;
			profit = amount * 4.5;
		}
	    else if(parseFloat(result)>5.60){
	    	isWinner = true;
	    	profit = (amount * bonus) - amount;
	    }
		else {
         isWinner = false;
		 profit = -amount;
		}
		
		profit = H.CryptoSet(profit, info.data.coin);

	    Rule.prepareBusted(self.client, self.io, self.id, 'plinko', info.data, profit, result, hash, isWinner, (res) => {
	    	if(res){
				self.emit({ command: 'busted', profit: profit })
	    	}
	    })
    }
}

module.exports = Plinko;