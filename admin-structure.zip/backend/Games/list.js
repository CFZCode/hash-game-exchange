const games = [
  
  
    {
        id: 7,
        name: "Classic Dice",
        prefix: "classic-dice",
        surfix: "classic_dice",
        image: "/assets/images/covers_new/bcoriginals/classicdicebc.png",
        color: 'linear-gradient(10deg, rgb(255 93 160) 0%, rgb(220, 93, 32) 100%)',
        icon: "mdi mdi-dice-d10",
        hedge: 1
    },
 
    
 
    // {
    //     id: 2,
    //     name: "Hash Dice",
    //     prefix: "hash-dice",
    //     surfix: "hash_dice",
    //     image: "/assets/images/covers_new/bcoriginals/hashdicebc.png",
    //     color: 'linear-gradient(10deg, rgb(119 63 255) 0%, rgb(114, 58, 246) 100%)',
    //     icon: "mdi mdi-dice-6",
    //     hedge: 1
    // },
    {
        id: 6,
        name: "Limbo",
        prefix: "limbo",
        surfix: "limbo",
        image: "/assets/images/covers_new/bcoriginals/limbobc.png",
        color: 'linear-gradient(10deg, rgb(255 234 0) 0%, #ff9800 100%)',
        icon: "mdi mdi-rocket",
        hedge: 1
    },
    // {
    //     id: 18,
    //     name: "Tower",
    //     prefix: "tower",
    //     surfix: "tower",
    //     image: "/assets/images/covers_new/bcoriginals/towerbc.png",
    //     color: 'linear-gradient(10deg, #673ab7 0%, #3f51b5 100%)',
    //     icon: "mdi mdi-tower-fire",
    //     hedge: 1
    // },
    {
        id: 10,
        name: "Plinko",
        prefix: "plinko",
        surfix: "plinko",
        image: "/assets/images/covers_new/bcoriginals/plinkobc.png",
        color: 'linear-gradient(271deg, rgb(90 68 255) 0%, #5e7edb 100%)',
        icon: "mdi mdi-baseball-bat",
        hedge: 1,
        disabled: true
    },
    {
        id: 8,
        name: "Mine",
        prefix: "mine",
        surfix: "mine",
        image: "/assets/images/covers_new/bcoriginals/minebc.png",
        color: 'linear-gradient(162deg, rgb(255 83 31) 0%, rgb(233 30 30) 100%)',
        icon: "mdi mdi-bomb",
        hedge: 1
    },
    {
        id: 5,
        name: "BlackJack",
        prefix: "blackjack",
        surfix: "blackjack",
        image: "/assets/images/covers_new/bcoriginals/blackjackbc.png",
        color: 'linear-gradient(0deg, #ae1d3e 0%, #dc3545 100%)',
        icon: "mdi mdi-dice-6",
        hedge: 1,
        disabled: true
    },
    // {
    //     id: 4,
    //     name: "Hilo",
    //     prefix: "hilo",
    //     surfix: "hilo",
    //     image: "/assets/images/covers_new/bcoriginals/hilobc.png",
    //     color: 'linear-gradient(10deg, #9c27b0 0%, rgb(87 39 212) 100%)',
    //     icon: "mdi mdi-houzz-box",
    //     hedge: 1
    // },
    {
        id: 13,
        name: "Goal",
        prefix: "goal",
        surfix: "goal",
        image: "/assets/images/covers_new/bcoriginals/goalbc.png",
        color: 'linear-gradient(110deg, #8bc34a 0%, #4caf50 100%)',
        icon: "mdi mdi-volleyball",
        hedge: 1
    },
    // {
    //     id: 3,
    //     name: "Crash",
    //     prefix: "crash",
    //     surfix: "crash",
    //     image: "/assets/images/covers_new/bcoriginals/crashbc.png",
    //     color: 'linear-gradient(114deg, rgb(63 81 181 / 55%) 0%, rgb(109, 39, 201) 100%)',
    //     icon: "dripicons-rocket",
    //     hedge: 1
    // },
    {
        id: 16,
        name: "3 Card Monte",
        prefix: "3-card-monte",
        surfix: "3-card-monte",
        image: "/assets/images/covers_new/bcoriginals/3cardmontebc.png",
        color: 'linear-gradient(10deg, #673ab7 0%, #3f51b5 100%)',
        icon: "mdi mdi-cards",
        hedge: 1
    },

    {
        id: 19,
        name: "Diamond",
        prefix: "diamond",
        surfix: "diamond",
        image: "/assets/images/covers_new/bcoriginals/diamondbjb.png",
        color: 'linear-gradient(10deg, #673ab7 0%, #3f51b5 100%)',
        icon: "mdi mdi-diamond",
        hedge: 1
    },

    // {
    //     id: 1,
    //     name: "Keno",
    //     prefix: "keno",
    //     surfix: "keno",
    //     image: "/assets/images/covers_new/bcoriginals/keno.png",
    //     color: 'linear-gradient(rgb(16 169 52) 0%, rgb(65 220 52) 40%)',
    //     icon: "mdi mdi-numeric-7-box",
    //     hedge: 1
    // },
    
    // {
    //     id: 3,
    //     name: "Crash",
    //     prefix: "crash",
    //     surfix: "crash",
    //     image: "/assets/images/covers_new/bcoriginals/crashbc.png",
    //     color: 'linear-gradient(114deg, rgb(63 81 181 / 55%) 0%, rgb(109, 39, 201) 100%)',
    //     icon: "dripicons-rocket",
    //     hedge: 1
    // },
  
 
  
    {
        id: 9,
        name: "Single Keno",
        prefix: "singlekeno",
        surfix: "singlekeno",
        image: "/assets/images/covers_new/bcoriginals/kenomultiplierbc.png",
        color: 'linear-gradient(0deg, rgb(233 30 99) 0%, rgb(254 71 71) 100%)',
        icon: "mdi mdi-cube-outline",
        hedge: 1
    },
   
   
    // {
    //     id: 11,
    //     name: "Wheel",
    //     prefix: "wheel",
    //     surfix: "wheel",
    //     image: "/assets/images/covers_new/bcoriginals/wheelbc.png",
    //     color: 'linear-gradient(110deg, rgba(111, 66, 194, 0.68) 0%, #7551e9 100%)',
    //     icon: "mdi mdi-ship-wheel",
    //     hedge: 1
    // },
    // {
    //     id: 12,
    //     name: "Video Poker",
    //     prefix: "videopoker",
    //     surfix: "videopoker",
    //     image: "/assets/images/covers_new/bcoriginals/videopokerbc.png",
    //     color: 'linear-gradient(110deg, #8bc34a 0%, #009688 100%)',
    //     icon: "mdi mdi-dice-3",
    //     hedge: 1
    // },
   
    // {
    //     id: 14,
    //     name: "Snake And Ladders",
    //     prefix: "snake-and-ladders",
    //     surfix: "snake-and-ladders",
    //     image: "/assets/images/covers_new/bcoriginals/sal.png",
    //     color: 'linear-gradient(10deg, #673ab7 0%, #3f51b5 100%)',
    //     icon: "mdi mdi-blur-linear",
    //     hedge: 1
    // },
    
   
    // {
    //     id: 17,
    //     name: "Jocker",
    //     prefix: "jocker",
    //     surfix: "jocker",
    //     image: "/assets/images/covers_new/jocker.png",
    //     color: 'linear-gradient(10deg, #673ab7 0%, #3f51b5 100%)',
    //     icon: "mdi mdi-cards",
    //     hedge: 1
    // },
   
   
  
   
  
    // {
    //     id: 15,
    //     name: "Roulette",
    //     prefix: "roulette",
    //     surfix: "roulette",
    //     image: "/assets/images/covers_new/roulette.png",
    //     color: 'linear-gradient(10deg, #673ab7 0%, #3f51b5 100%)',
    //     icon: "mdi mdi-plus-circle-multiple-outline",
    //     hedge: 1
    // },
  
    // {
    //     id: 17,
    //     name: "Magic Wheel",
    //     prefix: "magic-wheel",
    //     surfix: "magic-wheel",
    //     image: "/assets/images/covers_new/bcoriginals/magicwheelbc.png",
    //     color: 'linear-gradient(10deg, #673ab7 0%, #3f51b5 100%)',
    //     icon: "mdi mdi-pinwheel",
    //     hedge: 1
    // },
    // {
    //     id: 17,
    //     name: "Jocker",
    //     prefix: "wingo",
    //     surfix: "wingo",
    //           image: "/assets/images/covers_new/wingobc.png",
    //     color: 'linear-gradient(10deg, #673ab7 0%, #3f51b5 100%)',
    //     icon: "mdi mdi-cards",
    //     hedge: 1
    // },
    // {
    //     id: 20,
    //     name: "High or Low",
    //     prefix: "high-or-low",
    //     surfix: "high-or-low",
    //     image: "/assets/images/covers_new/highorlow.png",
    //     color: 'linear-gradient(10deg, #673ab7 0%, #3f51b5 100%)',
    //     icon: "mdi mdi-diamond",
    //     hedge: 1
    // }
];

// Export the Hash module
module.exports = games;





