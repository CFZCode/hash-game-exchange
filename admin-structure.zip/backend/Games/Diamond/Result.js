"use strict";

//Required Libs
var SHA256 = require("crypto-js/sha256");

function random(length) {
  return Math.floor(Math.random() * length);
}

const Result = {};

Result.make = function (canProfit) {
  let hash = makeHash();
  let result = makeResult(hash, canProfit);
  return { hash, result };
};

function makeHash() {
  var key = "00000000000000" + randomString(50);
  var gameHash = SHA256(key).toString();
  return gameHash;
}

function makeResult(seed, canProfit) {
  let r = [1, 2, 3, 4, 5];

  let randomNumbers = [];
  for (var i = 0; i < 5; i++) {
    randomNumbers.push(r[random(r.length)]);
  }

  // if (!canProfit) {
  //     let result = randomNumbers;

  //     let n1 = result[0];
  //     let n2 = result[1];
  //     let n3 = result[2];
  //     let n4 = result[3];
  //     let n5 = result[4];

  //     let isWinner = false;

  //     if (n1 == n2) {
  //         isWinner = true;
  //     }
  //     if (n2 === n3) {
  //         isWinner = true;
  //     }
  //     if (n3 === n4) {
  //         isWinner = true;
  //     }
  //     if (n4 === n5) {
  //         isWinner = true;
  //     }

  //     if (isWinner) {
  //         return makeResult(seed, false);
  //     }
  // }

  return randomNumbers;
}

function randomString(length) {
  var chars = "0123456789abcdefghiklmnopqrstuvwxyz".split("");
  var str = "";
  for (var i = 0; i < length; i++) {
    str += chars[Math.floor(Math.random() * chars.length)];
  }
  return str;
}

// Export the Hash module
module.exports = Result;
