// Declare players object
const players = {};
players.playerPlaying = [];
players.winner = [];

module.exports = players;