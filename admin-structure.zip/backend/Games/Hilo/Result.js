'use strict';

//Random Generate Hash/Result

//Required Libs
var SHA256 = require("crypto-js/sha256");
var H = require("../../General/Helper");

const Result = {}

Result.make = function () {
    let hash = makeHash();
    let result = makeResult();
    return { hash, result };
}

function makeHash() {
    var key = "00000000000000" + randomString(50);
    var gameHash = SHA256(key).toString()
    return gameHash;
}

function makeResult() {
    var arr = [], rand = [];

    for (let i = 1; i < 55; i++) {
        arr.push(i)
    }

    for (let i = 1; i < 55; i++) {
        rand.push(randomChoose(arr))
    }

    return rand
}

function randomChoose(arr) {
    var randIndex = Math.floor(Math.random() * arr.length)
    return arr[randIndex];
}

function randomString(length) {
    var chars = '0123456789abcdefghiklmnopqrstuvwxyz'.split('');
    var str = '';
    for (var i = 0; i < length; i++) {
        str += chars[Math.floor(Math.random() * chars.length)];
    }
    return str;
}

// Export the Result module
module.exports = Result;