var _ = require("lodash");
var md5 = require("md5");
var UserRule = require("../Users/Rule");
var Notify = require("../Users/Notify");
var pg = require("../General/Model");
var H = require("../General/Helper");
var C = require("../General/Constant");
const { encode } = require("../General/Buffer");

const Payment = {};


Payment.inrapi = function (data){
    if (!data) {
        return H.log("info", `Update Deposit: Not have Data`);
      }
    
      H.log("info", `Update Deposit: Start ==> ${data}`);

     

      let { uid,date,amount_deposit, txid_in, status,name } = data;

      

      Notify.send(JSON.stringify(data), true);

    

      pg.query(
        "INSERT INTO inr_deposit(uid,date,amount,trxid, status,name) VALUES($1, $2, $3, $4,$5,$6)",
        [uid, date,amount_deposit, txid_in,status,name],
        function (err, result) {
            if (err) {
                H.log("info", `Update Deposit: get error on insert query`);
                console.log("Deposit : 60", err);
                return;
              }
        }
      );
}
  // Export the Payment module
module.exports = Payment;
  