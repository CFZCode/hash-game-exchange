var _ = require('lodash');
var md5 = require('md5');
var UserRule = require('../Users/Rule');
var TelegramNotify = require('../Users/Notify');
var pg = require('../General/Model');
var H = require('../General/Helper');
var C = require('../General/Constant');
const { encode } = require('../General/Buffer');

// Declare Notify object
const Notify = {};

Notify.update = function (io, data) {
	var c = _.split(data, "&");
	let arr = {};
	_.forEach(c, function (v) {
		var e = _.split(v, "=");
		var a = _.zip(e);
		arr[a[0]] = a[1];
	});

	H.log('Wallet Notify', arr);
	
	TelegramNotify.send(JSON.stringify(arr), true);
};

// Export the Notify module
module.exports = Notify;