var _ = require("lodash");
var md5 = require("md5");
var UserRule = require("../Users/Rule");
var Notify = require("../Users/Notify");
var pg = require("../General/Model");
var H = require("../General/Helper");
var C = require("../General/Constant");
const { encode } = require("../General/Buffer");

const history = {};

history.inrhistory = function (data) {
  if (!data) {
    return H.log("info", `Update Deposit: Not have Data`);
  }

  H.log("info", `Update Deposit: Start ==> ${data}`);

  let name  = data;

  Notify.send(JSON.stringify(data), true);

  pg.query(
    "SELECT date,amount.status,trxid FROM inr_deposit WHERE name = $1",
    [name],
    function (err, result) {
      if (err) {
        H.log("info", `history Deposit: get error on select query`);
        console.log(err);
        return;
      }
 // Use console.log to print the result rows.
      return result.rows;
    }
  );
};

// Export the Payment module
module.exports = history;
