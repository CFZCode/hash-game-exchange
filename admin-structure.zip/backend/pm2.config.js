module.exports = {
  apps: [
    {
      name: 'lagaobet-server',
      // point script to the real entry file (adjust path if your index lives elsewhere)
      script: './index.js',

      // If you need to pass a CLI arg like "backend/index.js", put it in args.
      // But most likely you don't need args; remove if unused.
      // args: 'backend/index.js',

      // use fork mode unless you intentionally want cluster mode
      exec_mode: 'fork',

      // instances: 1 is safe for now; scale later if you need multiple workers/processes
      instances: 1,

      // IMPORTANT: disable watch in production. Use watch only for local dev.
      watch: false,

      // keep an explicit ignore_watch if you ever enable watch dev-side
      ignore_watch: ['node_modules', 'logs', 'uploads', 'kyc', 'bonuslogs', 'Banners', 'clubmembership'],

      // restart controls to avoid tight crash-restart loops
      max_restarts: 10,
      restart_delay: 5000,       // wait 5s between restarts to avoid thrashing

      // logging - helpful for debugging pre-crash output
      error_file: './logs/pm2-error.log',
      out_file: './logs/pm2-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',

      // environment variables
      env: {
        NODE_ENV: 'development',
        DEBUG: '1'
      },

      env_production: {
        NODE_ENV: 'production',
        DEBUG: '0'
      }
    }
  ]
};
