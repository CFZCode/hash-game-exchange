/*
 * dbSafe.js — helpers for safely interpolating identifiers (column names) into
 * SQL. Postgres parameter placeholders ($1, $2 …) only bind VALUES, never
 * identifiers, so currency-column names such as `usdt` still have to be
 * concatenated into the query string. That concatenation is where SQL
 * injection creeps in (e.g. a `coin` of "usdt=usdt WHERE 1=1--").
 *
 * safeCol() is a hard gate that guarantees the identifier is nothing but a
 * short lowercase [a-z0-9_] token. Every legitimate currency column passes
 * unchanged; anything containing a space, quote, parenthesis, semicolon,
 * comment, `=` or `-` is rejected. Because it never rewrites a valid column
 * name, wiring it in cannot change behaviour for real traffic — it only turns
 * a would-be injection into a clean, caught error.
 */

// Known credits-table currency columns (kept in sync with config.BALANCE).
// Used only for an advisory warning — the regex below is the real guarantee,
// so a brand-new currency column that isn't listed here still works fine.
const KNOWN_COINS = new Set([
  'btc', 'eth', 'usdt', 'bch', 'ltc', 'trx', 'doge', 'ada', 'xrp', 'bnb',
  'usdp', 'nexo', 'mkr', 'tusd', 'usdc', 'busd', 'inr', 'sc', 'mvr', 'bjt',
  'aed', 'npr', 'pkr', 'nc',
]);

const IDENT_RE = /^[a-z][a-z0-9_]{0,29}$/;

/**
 * Validate + normalise a currency/column identifier before it is interpolated
 * into SQL. Returns the lowercased identifier, or throws if it is not a plain
 * identifier token.
 *
 * @param {string} coin  raw column name (typically req.body.coin / currency)
 * @returns {string} the safe, lowercased identifier
 */
function safeCol(coin) {
  const c = String(coin == null ? '' : coin).trim().toLowerCase();
  if (!IDENT_RE.test(c)) {
    throw new Error(`Invalid currency/column identifier: ${JSON.stringify(coin)}`);
  }
  if (!KNOWN_COINS.has(c)) {
    // Not fatal — just surfaces new/unexpected columns in the logs.
    console.warn(`[dbSafe] safeCol: identifier "${c}" is not in the known coin list (allowed by format check)`);
  }
  return c;
}

module.exports = { safeCol, KNOWN_COINS };
