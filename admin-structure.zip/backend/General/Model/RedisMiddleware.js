/**
 * RedisMiddleware.js
 * 
 * Handles caching of postgres queries
 * (and presumably other stuff)
 * 
 */



var redis = require("redis"), client = redis.createClient();

redis.debug = true;

client.on("error", function(err) {
	console.log("Error " + err);
});

// node-redis v4+ requires an explicit connect() before any command. We start
// the connect once on first use and reuse the resulting promise.
let _connectPromise = null;
function ensureConnected() {
	if (client.isOpen) return Promise.resolve();
	if (!_connectPromise) {
		_connectPromise = client.connect().catch(err => {
			_connectPromise = null;
			throw err;
		});
	}
	return _connectPromise;
}

///////////////////////////////////////

function get(key, next) {
	client.get('postgres:' + key, function (err, result) {
		if (err || !result) return next(null);
		return next(JSON.parse(result));
	});
}

function set(key, ttl, data, next) {
	client.setex('postgres:' + key, ttl, JSON.stringify(data), function(err, result) {
		if (err || !result) return next(null);
		return next(result);
	});
}

function del(key, next) {
	client.del('postgres:' + key, function(err, result) {
		if (err || !result) return next(null);
		return next(result);
	});
}

// Promise-based helpers used by sportsmain crons and API/service.
// Caller is responsible for JSON encode/decode (matches existing call sites).
async function getCommonData(key) {
	await ensureConnected();
	return client.get(key);
}

async function setCommonData(key, ttlSeconds, value) {
	await ensureConnected();
	return client.setEx(key, ttlSeconds, value);
}

async function delCommonData(key) {
	await ensureConnected();
	return client.del(key);
}

///////////////////////////////////////

module.exports = {
	get: get,
	set: set,
	del: del,
	getCommonData,
	setCommonData,
	delCommonData,
};