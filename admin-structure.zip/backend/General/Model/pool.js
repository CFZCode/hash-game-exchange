// App-wide shared connection POOL — use this whenever you need a real database
// transaction (BEGIN/COMMIT + SELECT ... FOR UPDATE).
//
// Why a Pool and not the shared Client in ./index.js:
//   ./index.js exports ONE shared Client. Running BEGIN/COMMIT on it is not
//   concurrency-safe — one request's transaction would wrap another request's
//   queries on the same connection. A Pool hands each transaction its own
//   connection, so transactions are isolated and FOR UPDATE locks work correctly.
//
// IMPORTANT: there must be only ONE pool for the whole app. Do NOT call
// `new Pool(...)` anywhere else — always `require` this file instead.

const { Pool } = require('pg');
const pg = require('pg');
const config = require('../../config');

// Same type parsers as ./index.js (these are global to the pg module, but we set
// them here too so the pool behaves correctly regardless of module load order).
pg.types.setTypeParser(20, val => val === null ? null : parseInt(val));     // int8  -> integer
pg.types.setTypeParser(1700, val => val === null ? null : parseFloat(val)); // numeric -> float

const pool = new Pool({ connectionString: config.dbUrl });

pool.on('error', err => {
    // A pooled connection died while idle — log it; the pool will recover.
    console.error('Unexpected idle pool client error:', err.message);
});

// Runs fn inside a real transaction on a dedicated pooled connection.
// Commits on success, rolls back on any throw, always releases the connection.
//   await withTransaction(async (client) => {
//       await client.query('SELECT ... FOR UPDATE', [...]);
//       await client.query('UPDATE ...', [...]);
//   });
async function withTransaction(fn) {
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        const result = await fn(client);
        await client.query('COMMIT');
        return result;
    } catch (err) {
        await client.query('ROLLBACK').catch(() => {});
        throw err;
    } finally {
        client.release();
    }
}

module.exports = { pool, withTransaction };
