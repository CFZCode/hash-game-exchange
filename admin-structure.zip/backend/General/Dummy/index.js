function dummy() {
    let self = this;
    self.get = function(name) { return undefined; },
    self.mset = function(name) { return null; }
}

// Export the module
module.exports = dummy;