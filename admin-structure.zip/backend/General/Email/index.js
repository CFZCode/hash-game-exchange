// var assert = require("assert");
// var nodemailer = require("nodemailer");
// var sesTransport = require("nodemailer-ses-transport");
// var config = require("../../config");

// var apiURL = config.apiURL;

// function send(details, callback) {
//   assert(details, callback);

//   let transport =nodemailer.createTransport({
//     host: "mx3594.syd1.mymailhosting.com",
//     port: 465,
//     secure: true,
//     auth: {
//         user: "service@example.com",
//         pass: "REMOVED_SECRET"
//     },
//     logger: true,
//     debug: true
//   });
//   //  nodemailer.createTransport({
//   //   service: "smtpout.secureserver.net",
//   //   port: 465,
//   //   secure: true, 
//   //   logger: true,
//   //   debug: true,
//   //   secureConnection: false,
//   //   auth: {
//   //     user: config.GMAIL_NAME,
//   //     pass: config.GMAIL_PASS,
//   //   },
//   // });

//   transport.sendMail(details, function (err) {
//     if (err) {
//       return callback(err);
//     }
//     callback(true);
//   });
// }

// exports.passwordReset = function (email, password,name,callback) {
//   var html = `
//   <div style="margin: 0 auto; background-color: #13182e; padding: 20px; text-align: center; border-radius: 10px; width: fit-content;">
//     <h2 style="color: white;">You have requested password recovery on example.com</h2>
//     <br>
//     <h3 style="color: white;">UserName</h3>
//     <div>
//       <span id="username" style="color: white;">${name}</span>
//       </div>
//     <br>
//     <br>
//     <h3 style="color: white;">Your New Password</h3>
//     <div>
//       <span id="password" style="color: white;">${password}</span>
//       </div>
//     <br>
//     <br>
//     <span style="color: white;">We only send password resets to the registered email address.</span>
//   </div>


//   `;

//   var details = {
//     to: email,
//     from: config.GMAIL_NAME,
//     subject: "Reset Password Request",
//     html: html,
//     headers: {
//       "Content-Type": "text/html",
//     },
//   };
//   send(details, callback);
// };
const assert = require("assert");
const nodemailer = require("nodemailer");
const config = require("../../config");

function send(details, callback) {
  console.log('send function called with details:', details);

  assert(details, callback);

  let transport = nodemailer.createTransport({
    host: "mx3594.syd1.mymailhosting.com",
    port: 465,
    secure: true,
    auth: {
      user: "service@example.com",
      pass: "REMOVED_SECRET"
    },
    logger: true,
    debug: true
  });

  transport.sendMail(details, function (err, info) {
    if (err) {
      console.error('Error sending email:', err);
      return callback(err);
    }
    console.log('Email sent successfully:', info);
    callback(true);
  });
}

exports.passwordReset = function (email, password, name, callback) {
  console.log('passwordReset called with:', { email, password, name });

  var html = `
  <div style="margin: 0 auto; background-color: #13182e; padding: 20px; text-align: center; border-radius: 10px; width: fit-content;">
    <h2 style="color: white;">You have requested password recovery on example.com</h2>
    <br>
    <h3 style="color: white;">UserName</h3>
    <div>
      <span id="username" style="color: white;">${name}</span>
    </div>
    <br>
    <br>
    <h3 style="color: white;">Your New Password</h3>
    <div>
      <span id="password" style="color: white;">${password}</span>
    </div>
    <br>
    <br>
    <span style="color: white;">We only send password resets to the registered email address.</span>
  </div>
  `;

  var details = {
    to: email,
    from: "service@example.com",
    subject: "Reset Password Request",
    html: html,
    headers: {
      "Content-Type": "text/html",
    },
  };

  send(details, callback);
};