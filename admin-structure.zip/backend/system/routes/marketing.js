// system/routes/marketing.js
// Marketing panel — read-only analytics. Every route is a GET; protectMarketing
// rejects other verbs with 405 before any handler runs.
const router = require('express').Router();
const { protectStaff } = require('../middleware/auth');
const { protectMarketing } = require('../middleware/marketing');
const ctrl = require('../controllers/marketingController');

router.use(protectStaff, protectMarketing);

router.get('/me', ctrl.me);

router.get('/analytics/signups',    ctrl.signups);
router.get('/analytics/deposits',   ctrl.deposits);
router.get('/analytics/retention',  ctrl.retention);
router.get('/analytics/top-agents', ctrl.topAgents);

// Customer directory — powers the Direct/Agent Users tabs and the dashboard
// stat-card drill-down modals.
router.get('/customers', ctrl.customers);

module.exports = router;
