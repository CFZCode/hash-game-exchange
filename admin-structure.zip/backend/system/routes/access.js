// system/routes/access.js
// Access Management — Executives + per-executive activity log.
const router = require('express').Router();
const { protectStaff } = require('../middleware/auth');
const { withActivity } = require('../utils/recordActivity');
const ctrl = require('../controllers/accessController');

router.use(protectStaff);

// Effective permissions snapshot for the logged-in actor.
router.get('/me/permissions', ctrl.getMyPermissions);

// Executives
router.get   ('/executives',                   ctrl.listExecutives);
router.post  ('/executives',
  withActivity({
    action: 'executive.create',
    describe: req => ({ targetType: 'EXECUTIVE', details: { username: req.body.username } }),
  }),
  ctrl.createExecutive);
router.patch ('/executives/:id',
  withActivity({
    action: 'executive.update',
    describe: req => ({ targetType: 'EXECUTIVE', targetId: req.params.id }),
  }),
  ctrl.updateExecutive);
router.patch ('/executives/:id/password',
  withActivity({
    action: 'executive.password.reset',
    describe: req => ({ targetType: 'EXECUTIVE', targetId: req.params.id }),
  }),
  ctrl.resetExecutivePassword);
router.patch ('/executives/:id/lock',
  withActivity({
    action: 'executive.lock',
    describe: req => ({
      targetType: 'EXECUTIVE', targetId: req.params.id,
      details: { status: req.body.status },
    }),
  }),
  ctrl.lockExecutive);

// Marketing accounts (SuperAdmin only — enforced in the controller)
router.get   ('/marketing-users',               ctrl.listMarketingUsers);
router.post  ('/marketing-users',
  withActivity({
    action: 'marketing.create',
    describe: req => ({ targetType: 'MARKETING', details: { username: req.body.username } }),
  }),
  ctrl.createMarketingUser);
router.patch ('/marketing-users/:id/password',
  withActivity({
    action: 'marketing.password.reset',
    describe: req => ({ targetType: 'MARKETING', targetId: req.params.id }),
  }),
  ctrl.resetMarketingPassword);
router.patch ('/marketing-users/:id/lock',
  withActivity({
    action: 'marketing.lock',
    describe: req => ({
      targetType: 'MARKETING', targetId: req.params.id,
      details: { lock: req.body.lock },
    }),
  }),
  ctrl.lockMarketingUser);

// Activity log (read-only)
router.get   ('/executives/:id/activity',      ctrl.getExecutiveActivity);
// Global hierarchy-scoped activity log (SuperAdmin: all; others: self + downline)
router.get   ('/activity',                     ctrl.getActivity);

module.exports = router;
