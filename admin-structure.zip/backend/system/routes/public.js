// backend/system/routes/public.js
const express = require('express');
const router  = express.Router();
const ctrl    = require('../controllers/publicController');

router.get('/ref/:slug', ctrl.resolveWhatsappRef);

// Agent-managed user → list staff_transfers rows that involve the user.
router.get('/user-transfers/:uid', ctrl.getUserTransfers);

module.exports = router;
