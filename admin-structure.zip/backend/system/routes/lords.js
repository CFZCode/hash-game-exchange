// routes/lords.js
const router = require('express').Router();
const { protectStaff } = require('../middleware/auth');
const ctrl = require('../controllers/lordsController');
const { withActivity } = require('../utils/recordActivity');

router.use(protectStaff);

// ─── User Settings ───────────────────────────────────────────────
router.post('/user-setting/update-password',
  withActivity({
    action: 'user.password.reset',
    describe: req => ({
      targetType: req.body.userType, targetId: req.body.userId,
    }),
  }),
  ctrl.updatePassword);

router.post('/user-setting/status',
  withActivity({
    action: 'user.status.update',
    describe: req => ({
      targetType: req.body.userType, targetId: req.body.userId,
      details: {
        status: req.body.status, betStatus: req.body.betStatus,
        sportsLocked: req.body.sportsLocked,
        casinoLocked: req.body.casinoLocked,
        systemLocked: req.body.systemLocked,
      },
    }),
  }),
  ctrl.updateStatus);

router.post('/user-setting/exposure-limit',
  withActivity({
    action: 'user.exposure-limit.update',
    describe: req => ({
      targetType: req.body.userType, targetId: req.body.userId,
      details: { exposureLimit: req.body.exposureLimit },
    }),
  }),
  ctrl.updateExposureLimit);

// ─── Quick Wallet Refill (Staff Portal) ─────────────────────────
router.post('/quick-refill',
  withActivity({
    action: 'user.wallet.refill',
    describe: req => ({
      targetType: 'USER', targetId: req.body.userId,
      details: { amount: req.body.amount, note: req.body.note },
    }),
  }),
  ctrl.quickRefill);

// ─── Deposit / Withdraw (actual amounts, no credit limit) ────────
router.post('/funds/transfer',
  withActivity({
    action: req => String(req.body.direction).toLowerCase() === 'withdraw'
      ? 'funds.withdraw' : 'funds.deposit',
    describe: req => ({
      targetType: req.body.userType, targetId: req.body.userId,
      details: {
        amount: req.body.amount,
        direction: req.body.direction,
        note: req.body.note,
      },
    }),
  }),
  ctrl.transferFunds);

router.get('/transfer/statement', ctrl.transferStatement);

// ─── Net Exposure ───────────────────────────────────────────────
router.get('/net-exposure/sports', ctrl.netExposure);

// ─── Agent Listing ──────────────────────────────────────────────
router.get('/users/all-details', ctrl.allDetails);

// ─── Current User ───────────────────────────────────────────────
// NOTE: despite the name, this just returns the logged-in admin's own
// profile/balance (a read, polled by dashboards) — it is NOT an action,
// so it is intentionally not logged.
router.post('/update-current', ctrl.updateCurrent);

module.exports = router;
