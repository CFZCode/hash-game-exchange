// routes/branch.js   — mounted at /api/branch
// Branch panel: super admin -> branch admin -> sub branch -> players.
// See system/utils/branch.js and controllers/branchController.js.
const router = require('express').Router();
const { protectStaff } = require('../middleware/auth');
const { withActivity } = require('../utils/recordActivity');
const ctrl = require('../controllers/branchController');

router.post('/login', ctrl.login);

router.use(protectStaff, ctrl.access);

router.get('/me', ctrl.me);
router.post('/me/password',
  withActivity({ action: 'branch.password.change' }),
  ctrl.changeMyPassword);

// ─── Super admin: branch admins ───────────────────────────────────
router.get('/branches', ctrl.requireOwner, ctrl.listBranches);
router.post('/branches', ctrl.requireOwner,
  withActivity({ action: 'branch.create', describe: req => ({ details: { name: req.body.name, login: req.body.login } }) }),
  ctrl.createBranch);

// ─── Sub branches (branch admin creates; super admin on its behalf) ──
router.get('/sub-branches', ctrl.listSubBranches);
router.post('/sub-branches',
  withActivity({ action: 'branch.sub.create', describe: req => ({ details: { name: req.body.name, login: req.body.login, branchId: req.body.branchId } }) }),
  ctrl.createSubBranch);

// Lock stops the account's login, everything below it, and new registrations
// on its code.
router.patch('/staff/:id/lock',
  withActivity({ action: 'branch.lock', describe: req => ({ targetType: 'STAFF', targetId: req.params.id, details: { locked: !!req.body.locked } }) }),
  ctrl.setLock);
router.patch('/staff/:id/password',
  withActivity({ action: 'branch.password.reset', describe: req => ({ targetType: 'STAFF', targetId: req.params.id }) }),
  ctrl.resetPassword);

// ─── Reports (read-only, scoped by ?staffId) ──────────────────────
router.get('/summary', ctrl.summary);
router.get('/reports/daily', ctrl.daily);
// Literal path before /players/:id.
router.get('/players/suggest', ctrl.suggestPlayer);
router.post('/players',
  withActivity({ action: 'branch.player.create', describe: req => ({ targetType: 'USER', details: { username: req.body.username, staffId: req.body.staffId } }) }),
  ctrl.createPlayer);
router.get('/players', ctrl.players);
router.get('/players/:id', ctrl.player);
router.get('/transactions', ctrl.transactions);
router.get('/bets', ctrl.bets);

module.exports = router;
