const router = require('express').Router();
const ctrl   = require('../controllers/staffAuthController');
const { protectStaff } = require('../middleware/auth');
router.post('/login', ctrl.login);
router.post('/executive/login', ctrl.executiveLogin);
router.post('/first-login-password', ctrl.firstLoginPassword);
router.post('/logout', protectStaff, ctrl.logout);
module.exports = router;
