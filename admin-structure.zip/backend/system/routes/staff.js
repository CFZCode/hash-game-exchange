// routes/staff.js
const router = require('express').Router();
const { protectStaff } = require('../middleware/auth');
const { withActivity } = require('../utils/recordActivity');
const ctrl = require('../controllers/staffController');
const { denyDemoAgent } = require('../utils/demoUsers');

router.use(protectStaff);

// ─── READ ─────────────────────────────────────────────────
router.get('/tree', ctrl.getTree);
router.get('/', ctrl.listStaff);          // staff in your tree
router.get('/players', ctrl.listPlayers);        // players in your tree

router.get("/:id/percent-chain", ctrl.percentChain);   // root ➜ leaf
router.get("/:id/percent-tree", ctrl.percentTree);    // full subtree
// ─── CREATE ──────────────────────────────────────────────
router.post('/', denyDemoAgent,
  withActivity({
    action: 'staff.create',
    describe: req => ({
      targetType: 'STAFF',
      details: { name: req.body.name, email: req.body.email, role: req.body.role_name },
    }),
  }),
  ctrl.createStaff);        // create next-level staff
router.post('/players', denyDemoAgent,
  withActivity({
    action: 'user.create',
    describe: req => ({
      targetType: 'USER',
      details: { username: req.body.username, email: req.body.email },
    }),
  }),
  ctrl.createPlayer);       // create player
router.patch('/players/:id',
  withActivity({
    action: 'user.update',
    describe: req => ({ targetType: 'USER', targetId: req.params.id }),
  }),
  ctrl.updatePlayer);
router.post('/transfer', denyDemoAgent,
  withActivity({
    action: 'staff.transfer',
    describe: req => ({
      targetType: req.body.toType || 'STAFF', targetId: req.body.toId,
      details: { amount: req.body.amount, direction: req.body.direction || 'deposit' },
    }),
  }),
  ctrl.transfer);           // send INR downwards

// ─── UPDATE ──────────────────────────────────────────────
router.patch('/password',
  withActivity({
    action: 'staff.password.change',
    describe: req => ({ targetType: 'STAFF', targetId: req.body.targetId }),
  }),
  ctrl.changePassword);   // self or SuperAdmin
router.patch('/:id',
  withActivity({
    action: 'staff.update',
    describe: req => ({
      targetType: 'STAFF', targetId: req.params.id,
      details: {
        name: req.body.name, phone: req.body.phone, country: req.body.country,
        percentage: req.body.percentage, passwordChanged: !!req.body.password,
      },
    }),
  }),
  ctrl.editStaff);        // edit descendant

// ─── DELETE ──────────────────────────────────────────────
router.delete('/:id',
  withActivity({
    action: 'staff.delete',
    describe: req => ({ targetType: 'STAFF', targetId: req.params.id }),
  }),
  ctrl.deleteStaff);      // delete descendant
router.delete('/players/:id',
  withActivity({
    action: 'user.delete',
    describe: req => ({ targetType: 'USER', targetId: req.params.id }),
  }),
  ctrl.deletePlayer);
router.get('/:id', ctrl.getById);

router.get("/metrics/:id", ctrl.metrics);      // personalised counts
router.get("/analytics/:id", ctrl.analytics);    // personalised 7-day trend
router.post('/patch-bulk-status',
  withActivity({
    action: 'staff.bulk-status',
    describe: req => ({
      details: { ids: Array.isArray(req.body.ids) ? req.body.ids : [], status: req.body.status },
    }),
  }),
  ctrl.bulkStatus);
// routes/staff.js
router.get('/transactions', ctrl.transferHistory);
router.get('/rollupStaff/:id', ctrl.rollupAll);    // ALL visible accounts
router.get('/rollup/:id', ctrl.rollupById);   // single account

router.get('/transfers/:id?', ctrl.listTransfers);
router.get('/transfers/summary', ctrl.transfersSummary);    // NEW
router.get('/transfers/summary/:id', ctrl.transfersSummaryById); // NEW
router.get('/:id/whatsapp-ref', ctrl.getWhatsappRef);

router.post('/reset-password-for-staff',
  withActivity({
    action: 'staff.password.reset',
    describe: req => ({ targetType: 'STAFF' }),
  }),
  ctrl.resetPasswordForStaff);   // self or SuperAdmin

module.exports = router;
