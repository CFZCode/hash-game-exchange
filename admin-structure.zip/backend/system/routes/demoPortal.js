// routes/demoPortal.js   — mounted at /api/demo-portal
const router = require('express').Router();
const { protectStaff } = require('../middleware/auth');
const { withActivity } = require('../utils/recordActivity');
const ctrl = require('../controllers/demoPortalController');

router.use(protectStaff);

// ─── Owner: manage demo portal agents ─────────────────────────────
// Deposit / withdraw to an agent goes through POST /lords/funds/transfer
// (userType 'STAFF'); the agent is a direct child of the owner.
router.get('/agents', ctrl.requireOwner, ctrl.listAgents);
router.post('/agents', ctrl.requireOwner,
  withActivity({ action: 'demoPortal.agent.create', describe: req => ({ details: { name: req.body.name, email: req.body.email } }) }),
  ctrl.createAgent);
router.patch('/agents/:id/lock', ctrl.requireOwner,
  withActivity({ action: 'demoPortal.agent.lock', describe: req => ({ targetType: 'STAFF', targetId: req.params.id, details: { locked: !!req.body.locked } }) }),
  ctrl.setAgentLock);
router.patch('/agents/:id/password', ctrl.requireOwner,
  withActivity({ action: 'demoPortal.agent.password', describe: req => ({ targetType: 'STAFF', targetId: req.params.id }) }),
  ctrl.resetAgentPassword);
router.get('/agents/:id/users', ctrl.requireOwner, ctrl.listAgentUsers);

// ─── Demo portal agent: own demo accounts ─────────────────────────
// Top-up / take back from a demo account goes through POST /lords/funds/transfer
// (userType 'USER'); demo accounts are direct children of the agent.
router.get('/me', ctrl.requireDemoAgent, ctrl.me);
router.get('/users', ctrl.requireDemoAgent, ctrl.listMyUsers);
router.post('/users', ctrl.requireDemoAgent,
  withActivity({ action: 'demoPortal.user.create', describe: req => ({ details: { username: req.body.username, fund: req.body.fund, casinoLimit: req.body.casinoLimit } }) }),
  ctrl.createDemoUser);
router.patch('/users/:id', ctrl.requireDemoAgent,
  withActivity({ action: 'demoPortal.user.update', describe: req => ({ targetType: 'USER', targetId: req.params.id, details: req.body }) }),
  ctrl.updateDemoUser);

module.exports = router;
