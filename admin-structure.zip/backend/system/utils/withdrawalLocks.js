const pg = require('../../General/Model');
const { withTransaction } = require('../../General/Model/pool');
const { ensureDemoSchema } = require('./demoUsers');

// Withdrawal controls, enforced server-side on every player payout path:
// F2Pay, A-Pay (Paykassma), the manual fiat queue and crypto (socket).
//   siteconfig.withdrawals                    — global ON/OFF
//   users.withdrawal_locked                   — per-player lock
//   siteconfig.withdrawal_limit_enabled       — deposit-multiple cap ON/OFF,
//                                               applies to every player
//   siteconfig.withdrawal_deposit_multiplier  — the cap (default 3×)
//   siteconfig.withdrawal_wager_bonus_enabled — wagering bonus ON/OFF
//   siteconfig.withdrawal_wager_multiplier    — ceiling of that bonus, as a
//                                               multiple of deposits (default 5×)
// All are managed from admin → Users → Financial → Withdrawal.
//
// The cap is  deposits × multiplier  +  wagering bonus, where the bonus is the
// amount the player has bet, up to deposits × wager multiplier. With 1,000
// deposited at the defaults: 1,000 wagered → 3,000 + 1,000 = 4,000 however
// big the win; 5,000 or more wagered → 3,000 + 5,000 = 8,000.

const DEFAULT_MULTIPLIER = 3;
const DEFAULT_WAGER_MULTIPLIER = 5;

const MESSAGES = {
  WITHDRAWAL_GLOBAL_DISABLED: 'Withdrawals are temporarily unavailable. Please try again later.',
  WITHDRAWAL_USER_LOCKED: 'You have reached your withdraw limit',
  WITHDRAWAL_CHECK_FAILED: 'Unable to process withdrawal right now. Please try again later.',
  WITHDRAWAL_DEMO_ACCOUNT: 'Deposits and withdrawals are not available on demo accounts.',
};

const COLUMNS = [
  ['siteconfig', 'withdrawals', 'boolean DEFAULT true NOT NULL'],
  ['siteconfig', 'withdrawal_deposit_multiplier', `numeric DEFAULT ${DEFAULT_MULTIPLIER} NOT NULL`],
  ['siteconfig', 'withdrawal_limit_enabled', 'boolean DEFAULT true NOT NULL'],
  ['siteconfig', 'withdrawal_wager_bonus_enabled', 'boolean DEFAULT true NOT NULL'],
  ['siteconfig', 'withdrawal_wager_multiplier', `numeric DEFAULT ${DEFAULT_WAGER_MULTIPLIER} NOT NULL`],
  ['users', 'withdrawal_locked', 'boolean DEFAULT false NOT NULL'],
];

// Columns are created once per process. Only ALTER when missing — ADD COLUMN
// IF NOT EXISTS still takes an ACCESS EXCLUSIVE lock on `users` — and cap the
// wait so a long-running transaction can't stall every query behind it.
let columnsReady = null;
function ensureWithdrawalLockColumns() {
  if (!columnsReady) {
    columnsReady = (async () => {
      const { rows } = await pg.query(
        `SELECT table_name, column_name
           FROM information_schema.columns
          WHERE table_schema = 'public'
            AND (table_name, column_name) IN (SELECT * FROM unnest($1::text[], $2::text[]))`,
        [COLUMNS.map(c => c[0]), COLUMNS.map(c => c[1])]
      );
      const have = new Set(rows.map(r => `${r.table_name}.${r.column_name}`));
      const missing = COLUMNS
        .filter(([t, c]) => !have.has(`${t}.${c}`))
        .map(([t, c, def]) => `ALTER TABLE public.${t} ADD COLUMN IF NOT EXISTS ${c} ${def}`);
      if (!missing.length) return;
      await withTransaction(async (client) => {
        await client.query(`SET LOCAL lock_timeout = '5s'`);
        for (const sql of missing) await client.query(sql);
      });
      console.log('[withdrawalLocks] added columns:', missing.length);
    })().catch((err) => {
      columnsReady = null; // retry on next call
      throw err;
    });
  }
  return columnsReady;
}

// Lifetime funding per currency, counted the way balancesheet/controller.js
// counts it: deposits that actually credited the wallet (including agent
// transfers, which are INR and have no currency column), and every withdrawal
// that still holds or has paid out money (pending included, failed/refunded
// excluded) — otherwise a player could queue several requests past the cap.
const FAILED = `('failed','rejected','declined','cancelled','canceled','unattempted')`;
async function getFunding(userId, currency) {
  const { rows } = await pg.query(
    `SELECT
       (SELECT COALESCE(SUM(amount::numeric),0) FROM fiat_deposits
         WHERE user_id::text = $1 AND upper(currency) = $2
           AND lower(status) IN ('approved','success','done','completed'))
     + (SELECT COALESCE(SUM((CASE WHEN paid_amount > 0 THEN paid_amount ELSE amount END)::numeric),0)
          FROM apaydeposits
         WHERE user_id::text = $1 AND upper(currency) = $2 AND status = 'Success')
     + (SELECT COALESCE(SUM(amount),0) FROM f2paydeposits
         WHERE user_id::text = $1 AND upper(currency) = $2 AND status = 'Success')
     + (SELECT COALESCE(SUM(amount),0) FROM deposits
         WHERE uid::text = $1 AND upper(coin) = $2)
     + (SELECT COALESCE(SUM(amount),0) FROM staff_transfers
         WHERE $2 = 'INR' AND transfer_type = 'transfer'
           AND to_type = 'user' AND to_id::text = $1)
       AS deposited,
       (SELECT COALESCE(SUM(amount::numeric),0) FROM fiat_withdrawals
         WHERE uid::text = $1 AND upper(currency) = $2 AND lower(status) NOT IN ${FAILED})
     + (SELECT COALESCE(SUM(amount::numeric),0) FROM apaywithdrawals
         WHERE user_id::text = $1 AND upper(currency) = $2
           AND lower(status) NOT IN ${FAILED} AND COALESCE(refunded,false) = false)
     + (SELECT COALESCE(SUM(amount),0) FROM f2paywithdrawals
         WHERE user_id::text = $1 AND upper(currency) = $2
           AND lower(status) NOT IN ${FAILED} AND refunded = false)
     + (SELECT COALESCE(SUM(amount),0) FROM withdrawals
         WHERE uid::text = $1 AND upper(coin) = $2 AND lower(status) NOT IN ${FAILED})
     + (SELECT COALESCE(SUM(amount),0) FROM staff_transfers
         WHERE $2 = 'INR' AND transfer_type = 'transfer'
           AND from_type = 'user' AND from_id::text = $1)
       AS withdrawn`,
    [String(userId), String(currency).toUpperCase()]
  );
  return { deposited: Number(rows[0].deposited), withdrawn: Number(rows[0].withdrawn) };
}

// The casino provider labels wallets differently from us (gis/controller.js
// INT2EXT/CUR2COL): INR play is sent as "PKR" and USDT as "USD", so a PKR row
// in gis_transactions is money from the INR wallet, never the PKR one.
const GIS_LABELS = { INR: ['INR', 'PKR'], USDT: ['USDT', 'USD'], PKR: [] };
const NOT_WAGERED = `('refund','refunded','void','voided','cancelled','canceled')`;

// Lifetime amount bet per currency — what unlocks the wagering bonus.
//   casino  — bets minus refunded bets
//   sports  — settled bets only, refunds/voids excluded; counted at the money
//             actually at risk, so a low-odds lay with a large stake and a
//             tiny liability can't be used to farm turnover
//   in-house games (bets, js_game_transactions)
async function getWagered(userId, currency) {
  const cur = String(currency).toUpperCase();
  const { rows } = await pg.query(
    `SELECT
       GREATEST((SELECT COALESCE(SUM(CASE lower(action) WHEN 'bet' THEN amount
                                                        WHEN 'refund' THEN -amount
                                                        ELSE 0 END),0)
                   FROM gis_transactions
                  WHERE user_id = $1::bigint AND upper(currency) = ANY($3::text[])), 0)
     + (SELECT COALESCE(SUM(LEAST(stake_amount, COALESCE(NULLIF(liability,0), stake_amount))),0)
          FROM "SportsBet"
         WHERE user_id = $1::bigint AND upper(original_currency) = $2
           AND lower(status) = 'closed'
           AND lower(COALESCE(result_status,'')) NOT IN ${NOT_WAGERED})
     + (SELECT COALESCE(SUM(amount),0) FROM bets
         WHERE uid = $1::bigint AND upper(coin) = $2)
     + (SELECT COALESCE(SUM(amount),0) FROM js_game_transactions
         WHERE user_id = $1::bigint AND upper(currency) = $2
           AND lower(transaction_type) = 'bet')
       AS wagered`,
    [String(userId), cur, GIS_LABELS[cur] || [cur]]
  );
  return Number(rows[0].wagered);
}

const round2 = n => Math.floor(n * 100) / 100;

// The cap itself, shared by enforcement and the admin list. `wagered` only
// matters while the wagering bonus is on.
function computeLimit({ currency, deposited, withdrawn, wagered, multiplier, wagerBonusEnabled, wagerMultiplier }) {
  const base = deposited * multiplier;
  const bonusMax = wagerBonusEnabled ? deposited * wagerMultiplier : 0;
  const bonusUnlocked = Math.min(Math.max(wagered || 0, 0), bonusMax);
  const max = base + bonusUnlocked;
  return {
    currency: String(currency).toUpperCase(),
    multiplier,
    deposited,
    withdrawn,
    base_limit: round2(base),
    wager_bonus_enabled: wagerBonusEnabled,
    wager_multiplier: wagerMultiplier,
    wagered: round2(wagered || 0),
    wager_bonus_max: round2(bonusMax),
    wager_bonus_unlocked: round2(bonusUnlocked),
    wager_bonus_locked: round2(bonusMax - bonusUnlocked),
    max_withdrawable: round2(max),
    remaining: Math.max(round2(max - withdrawn), 0),
  };
}

// `currency` is optional: without it only the ON/OFF locks are reported (the
// cap is per currency, so there is nothing to compute).
async function getWithdrawalStatus(userId, currency) {
  await ensureWithdrawalLockColumns();
  await ensureDemoSchema();
  const { rows } = await pg.query(
    `SELECT COALESCE((SELECT withdrawals FROM siteconfig LIMIT 1), true) AS global_enabled,
            COALESCE((SELECT withdrawal_limit_enabled FROM siteconfig LIMIT 1), true) AS limit_applied,
            COALESCE((SELECT withdrawal_deposit_multiplier FROM siteconfig LIMIT 1), $2) AS multiplier,
            COALESCE((SELECT withdrawal_wager_bonus_enabled FROM siteconfig LIMIT 1), true) AS wager_bonus_enabled,
            COALESCE((SELECT withdrawal_wager_multiplier FROM siteconfig LIMIT 1), $3) AS wager_multiplier,
            COALESCE(u.withdrawal_locked, false) AS user_locked,
            COALESCE(u.is_demo, false) AS is_demo
       FROM (SELECT 1) one
       LEFT JOIN users u ON u.id::text = $1`,
    [String(userId), DEFAULT_MULTIPLIER, DEFAULT_WAGER_MULTIPLIER]
  );
  const globalEnabled = rows[0].global_enabled !== false;
  const userLocked = rows[0].user_locked === true;
  const isDemo = rows[0].is_demo === true;
  const limitApplied = rows[0].limit_applied !== false;
  const multiplier = Number(rows[0].multiplier);
  const wagerBonusEnabled = rows[0].wager_bonus_enabled !== false;
  const wagerMultiplier = Number(rows[0].wager_multiplier);
  const code = isDemo ? 'WITHDRAWAL_DEMO_ACCOUNT'
    : !globalEnabled ? 'WITHDRAWAL_GLOBAL_DISABLED'
    : userLocked ? 'WITHDRAWAL_USER_LOCKED'
    : null;

  let limit = null;
  if (limitApplied && currency) {
    const [f, wagered] = await Promise.all([
      getFunding(userId, currency),
      wagerBonusEnabled ? getWagered(userId, currency) : 0,
    ]);
    limit = computeLimit({ currency, ...f, wagered, multiplier, wagerBonusEnabled, wagerMultiplier });
  }

  return {
    allowed: !code,
    global_enabled: globalEnabled,
    user_locked: userLocked,
    is_demo: isDemo,
    limit_applied: limitApplied,
    multiplier,
    wager_bonus_enabled: wagerBonusEnabled,
    wager_multiplier: wagerMultiplier,
    limit,
    code,
    message: code ? MESSAGES[code] : null,
  };
}

const blocked = (code, message) => Object.assign(new Error(message), { code });

// Throws an Error with `code` + a player-safe `message` when the withdrawal
// must not go ahead. Pass { amount, currency } so the deposit-multiple cap
// can be checked. Fails closed: if the check itself errors, block.
async function assertWithdrawalAllowed(userId, { amount, currency } = {}) {
  let status;
  try {
    status = await getWithdrawalStatus(userId, currency);
  } catch (e) {
    console.error('[withdrawalLocks] check failed:', e.message);
    throw blocked('WITHDRAWAL_CHECK_FAILED', MESSAGES.WITHDRAWAL_CHECK_FAILED);
  }
  if (status.user_locked) throw blocked('WITHDRAWAL_LIMIT_EXCEEDED', 'You have reached your withdrawal limit.');
  if (!status.allowed) throw blocked(status.code, status.message);
  if (!status.limit_applied) return;

  const amt = Number(amount);
  if (!currency || !Number.isFinite(amt)) {
    // A payout path that didn't pass amount/currency: block
    // rather than let the payout through unchecked.
    throw blocked('WITHDRAWAL_CHECK_FAILED', MESSAGES.WITHDRAWAL_CHECK_FAILED);
  }
  const { limit } = status;
  if (amt > limit.remaining + 1e-9) {
    const fmt = n => n.toLocaleString('en-IN', { maximumFractionDigits: 2 });
    const basis = limit.wager_bonus_enabled
      ? `${fmt(limit.multiplier)}× your total deposits + ${fmt(limit.wager_bonus_unlocked)} ${limit.currency} unlocked by wagering`
      : `${fmt(limit.multiplier)}× your total deposits`;
    // The bonus unlocks 1:1 with the amount bet, so what is still locked is
    // also how much more the player has to wager to get it.
    const raise = limit.wager_bonus_locked > 0
      ? `Wager ${fmt(limit.wager_bonus_locked)} ${limit.currency} more or deposit to raise your limit.`
      : 'Deposit more to raise your limit.';
    throw blocked(
      'WITHDRAWAL_LIMIT_EXCEEDED',
      limit.remaining > 0
        ? `You can withdraw up to ${fmt(limit.remaining)} ${limit.currency} more (${basis}). ${raise}`
        : `Withdrawal limit reached (${basis}). ${raise}`
    );
  }
}

module.exports = {
  DEFAULT_MULTIPLIER,
  DEFAULT_WAGER_MULTIPLIER,
  ensureWithdrawalLockColumns,
  getFunding,
  getWagered,
  computeLimit,
  getWithdrawalStatus,
  assertWithdrawalAllowed,
};
