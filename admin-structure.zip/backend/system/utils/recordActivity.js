// system/utils/recordActivity.js
// Append-only activity log for EVERY admin-panel action — performed by any
// actor in the hierarchy (SuperAdmin, agents at every level, Executives).
const pg = require('../../General/Model');
const geo = require('./geo');
const financeNotify = require('./financeNotify');

/**
 * Resolve the acting admin from the request (populated by protectStaff) with
 * optional explicit overrides (used by login routes where req.staff is unset).
 * @returns {{staffId:number|null, executiveId:number|null, name:string|null, role:string|null, level:number|null}}
 */
function resolveActor(req, actor = {}) {
  const s = req?.staff || {};
  const executiveId = actor.executiveId != null ? actor.executiveId : (s.executive_id ?? null);
  return {
    staffId: actor.staffId != null ? actor.staffId : (s.id ?? null),
    executiveId,
    name: actor.name != null ? actor.name : (s.name ?? null),
    // Executives always log under the Executive role, regardless of parent role.
    role: actor.role != null ? actor.role : (executiveId ? 'Executive' : (s.role_name ?? null)),
    level: actor.level != null ? actor.level : (s.level ?? null),
  };
}

/**
 * Record an admin action. Must never throw — a logging failure should never
 * break the action itself.
 *
 * @param {Object} args
 * @param {Object} args.req            Express request (ip / user-agent / actor)
 * @param {string} args.action         Dotted action key, e.g. "transfer.credit"
 * @param {string} [args.targetType]
 * @param {string|number} [args.targetId]
 * @param {Object} [args.details]      Free-form JSON
 * @param {'success'|'failed'} [args.status='success']
 * @param {string} [args.errorMessage]
 * @param {Object} [args.actor]        Explicit actor override {staffId, executiveId, name, role, level}
 */
async function recordActivity({
  req,
  action,
  targetType,
  targetId,
  details,
  status = 'success',
  errorMessage,
  actor,
}) {
  try {
    const a = resolveActor(req, actor);
    // Cannot attribute the action to anyone — skip rather than log an orphan row.
    if (a.staffId == null) return;

    const loc = geo.locate(req || {});

    await pg.query(
      `INSERT INTO admin_activity_logs
         (staff_id, executive_id, actor_name, actor_role, actor_level,
          action, target_type, target_id, details,
          ip, country, region, city, user_agent, status, error_message)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16)`,
      [
        a.staffId,
        a.executiveId,
        a.name,
        a.role,
        a.level,
        action,
        targetType || null,
        targetId == null ? null : String(targetId),
        details ? JSON.stringify(details) : null,
        loc.ip,
        loc.country,
        loc.region,
        loc.city,
        (req?.headers?.['user-agent'] || '').slice(0, 500) || null,
        status,
        errorMessage ? String(errorMessage).slice(0, 500) : null,
      ]
    );

    // Fire-and-forget financial alert (email + Telegram). Self-filters to
    // money-movement actions performed by the SuperAdmin or its executive.
    financeNotify.maybeNotify({ action, actor: a, targetType, targetId, details, loc, status });
  } catch (e) {
    // Logging must never break the request path.
    console.error('[recordActivity] failed:', e.message);
  }
}

/**
 * Express middleware that wraps a route so its outcome is logged automatically.
 * Captures success/failure based on the response body / status code.
 *
 *   router.post('/funds/transfer',
 *     protectStaff,
 *     withActivity({
 *       action: 'funds.deposit',
 *       describe: req => ({
 *         targetType: 'user',
 *         targetId: req.body.userId,
 *         details:  { amount: req.body.amount },
 *       }),
 *     }),
 *     ctrl.transferFunds);
 */
function withActivity({ action, describe }) {
  return function activityMiddleware(req, res, next) {
    // `action` may be a function when one route covers several action keys
    // (e.g. deposit vs withdraw on the same endpoint).
    const actionKey = typeof action === 'function' ? action(req) : action;
    const desc = (typeof describe === 'function' ? describe(req) : {}) || {};
    const origJson = res.json.bind(res);
    res.json = (body) => {
      const ok = res.statusCode < 400 && body?.status !== 'fail' && body?.success !== false;
      // fire-and-forget
      recordActivity({
        req,
        action: actionKey,
        targetType: desc.targetType,
        targetId: desc.targetId,
        details: desc.details,
        status: ok ? 'success' : 'failed',
        errorMessage: ok ? undefined : (body?.message || body?.error),
      });
      return origJson(body);
    };
    next();
  };
}

// Back-compat alias — older call sites import recordExecutiveActivity.
const recordExecutiveActivity = recordActivity;

module.exports = { recordActivity, recordExecutiveActivity, withActivity };
