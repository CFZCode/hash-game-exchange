// system/utils/geo.js
// Resolve a client IP to a coarse location using the offline geoip-lite DB.
// Degrades gracefully: if the library/DB is unavailable or the IP is private,
// it simply returns nulls — geolocation must never break the request path.

let geoip = null;
let loadAttempted = false;

function loadGeoip() {
  if (loadAttempted) return geoip;
  loadAttempted = true;
  try {
    // eslint-disable-next-line global-require
    geoip = require('geoip-lite');
  } catch (e) {
    console.warn('[geo] geoip-lite not available — location lookups disabled:', e.message);
    geoip = null;
  }
  return geoip;
}

/**
 * Extract the best-effort client IP from an Express request.
 * Honours x-forwarded-for (first hop) when behind a proxy/load balancer.
 * @param {Object} req
 * @returns {string|null}
 */
function clientIp(req) {
  const ip =
    (req.headers?.['x-forwarded-for'] || '').split(',')[0]?.trim() ||
    req.socket?.remoteAddress ||
    req.ip ||
    null;
  if (!ip) return null;
  // Normalise IPv4-mapped IPv6 (e.g. ::ffff:1.2.3.4) so geoip can resolve it.
  return ip.replace(/^::ffff:/, '');
}

/**
 * Resolve an IP to { country, region, city }. Any field may be null.
 * @param {string|null} ip
 * @returns {{ country: string|null, region: string|null, city: string|null }}
 */
function lookup(ip) {
  const empty = { country: null, region: null, city: null };
  if (!ip) return empty;
  const g = loadGeoip();
  if (!g) return empty;
  try {
    const r = g.lookup(ip);
    if (!r) return empty;
    return {
      country: r.country || null,
      region: (Array.isArray(r.region) ? r.region[0] : r.region) || null,
      city: r.city || null,
    };
  } catch (e) {
    return empty;
  }
}

/** Convenience: pull IP from req and resolve location in one call. */
function locate(req) {
  const ip = clientIp(req);
  return { ip, ...lookup(ip) };
}

module.exports = { clientIp, lookup, locate };
