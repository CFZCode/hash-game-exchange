const pg = require('../../General/Model');
const { withTransaction } = require('../../General/Model/pool');

// Demo accounts, minted from the admin panel's "Demo Portal Agent" section.
//   roles 'DemoAgent'        — a staff login that can only create demo players
//   users.is_demo            — the player is a demo account: no deposits or
//                              withdrawals, shown as DEMO in every report and
//                              left out of dashboard totals
//   users.demo_bet_limit     — max single bet on Slotegrator (live casino /
//                              slots) games; NULL or 0 = no cap
// A demo player's money only ever moves agent <-> player via staff_transfers.

const DEMO_ROLE = 'DemoAgent';
const DEMO_ROLE_LEVEL = 4;

const DEMO_MESSAGE = 'Deposits and withdrawals are not available on demo accounts.';

const COLUMNS = [
  ['users', 'is_demo', 'boolean DEFAULT false NOT NULL'],
  ['users', 'demo_bet_limit', 'numeric'],
];

// Same once-per-process pattern as withdrawalLocks.js: only ALTER when a column
// is missing, and cap the lock wait on `users`.
let schemaReady = null;
function ensureDemoSchema() {
  if (!schemaReady) {
    schemaReady = (async () => {
      const { rows } = await pg.query(
        `SELECT table_name, column_name
           FROM information_schema.columns
          WHERE table_schema = 'public'
            AND (table_name, column_name) IN (SELECT * FROM unnest($1::text[], $2::text[]))`,
        [COLUMNS.map(c => c[0]), COLUMNS.map(c => c[1])]
      );
      const have = new Set(rows.map(r => `${r.table_name}.${r.column_name}`));
      const missing = COLUMNS
        .filter(([t, c]) => !have.has(`${t}.${c}`))
        .map(([t, c, def]) => `ALTER TABLE public.${t} ADD COLUMN IF NOT EXISTS ${c} ${def}`);
      await withTransaction(async (client) => {
        await client.query(`SET LOCAL lock_timeout = '5s'`);
        for (const sql of missing) await client.query(sql);
        await client.query(
          `INSERT INTO roles (id, name, level)
           SELECT m.next_id, $1::text, $2::int
             FROM (SELECT COALESCE(MAX(id), 0) + 1 AS next_id FROM roles) m
            WHERE NOT EXISTS (SELECT 1 FROM roles WHERE name = $1::text)`,
          [DEMO_ROLE, DEMO_ROLE_LEVEL]
        );
        await client.query(`SELECT setval('roles_id_seq', (SELECT MAX(id) FROM roles))`);
        await client.query(
          `CREATE INDEX IF NOT EXISTS idx_users_is_demo ON public.users (id) WHERE is_demo`
        );
      });
      if (missing.length) console.log('[demoUsers] added columns:', missing.length);
    })().catch((err) => {
      schemaReady = null; // retry on next call
      throw err;
    });
  }
  return schemaReady;
}

let demoRoleId = null;
async function getDemoRoleId() {
  if (demoRoleId) return demoRoleId;
  await ensureDemoSchema();
  const { rows } = await pg.query('SELECT id FROM roles WHERE name = $1', [DEMO_ROLE]);
  demoRoleId = Number(rows[0].id);
  return demoRoleId;
}

async function isDemoAgent(staff) {
  if (!staff) return false;
  return Number(staff.role_id) === await getDemoRoleId();
}

// Resolves any of the user identifiers the payment routes receive (numeric id
// or username) and reports whether one of them is a demo player.
async function anyDemoUser(identifiers) {
  const vals = [...new Set(identifiers.filter(v => v != null && v !== '').map(v => String(v).trim()))];
  if (!vals.length) return false;
  await ensureDemoSchema();
  const { rowCount } = await pg.query(
    `SELECT 1 FROM users
      WHERE is_demo AND (id::text = ANY($1) OR lower(name) = ANY($2))
      LIMIT 1`,
    [vals, vals.map(v => v.toLowerCase())]
  );
  return rowCount > 0;
}

const USER_FIELDS = ['user_id', 'uid', 'userid', 'userId', 'custom_user_id', 'username'];

// Express middleware for player-facing deposit/withdraw routes. Must run after
// any multer middleware, since multipart bodies are only parsed there. Fails
// closed: if the lookup errors, the money request is refused.
async function rejectDemoUser(req, res, next) {
  try {
    const body = req.body || {};
    if (await anyDemoUser(USER_FIELDS.map(f => body[f]))) {
      return res.status(403).json({ success: false, status: false, code: 'DEMO_ACCOUNT', message: DEMO_MESSAGE, msg: DEMO_MESSAGE });
    }
    next();
  } catch (e) {
    console.error('[demoUsers] check failed:', e.message);
    res.status(503).json({ success: false, status: false, message: 'Unable to process request right now. Please try again later.' });
  }
}

// Express middleware: a DemoAgent may only act through /api/demo-portal.
async function denyDemoAgent(req, res, next) {
  try {
    if (await isDemoAgent(req.staff))
      return res.status(403).json({ status: 'fail', message: 'Demo portal agents can only create demo accounts.' });
    next();
  } catch (e) {
    next(e);
  }
}

module.exports = {
  DEMO_ROLE,
  DEMO_MESSAGE,
  ensureDemoSchema,
  getDemoRoleId,
  isDemoAgent,
  anyDemoUser,
  rejectDemoUser,
  denyDemoAgent,
};
