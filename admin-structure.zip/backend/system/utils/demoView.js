// "Demo view" staff (staff.demo_view = true), e.g. the superadmindemo account:
// a SuperAdmin login that sees every screen of the admin panel but never any
// real data, and can never change anything.
//
//  • Every request carrying a demo-view token: writes (non-GET) never reach a
//    handler — they get a blank success stub. Reads run, but the JSON reply is
//    blanked (arrays emptied, numbers zeroed, text cleared) keeping its shape,
//    so screens render empty instead of crashing.
//  • The admin panel does the same client side (src/utils/demoView.ts), which
//    also covers calls that are sent without a token.
//
// The flag travels in the signed JWT (demo_view claim) so no DB lookup per
// request is needed.

const jwt = require('jsonwebtoken');
const pg = require('../../General/Model');

// Auth calls must work normally so the demo account can log in / out.
const PASSTHROUGH = [/^\/api\/staff\/auth\/(login|logout)$/];

// Values kept as-is so callers still see a normal success / failure reply.
const KEEP_KEYS = new Set(['status', 'success', 'message', 'msg', 'code', 'error', 'ok']);

let schemaReady = null;
function ensureDemoViewSchema() {
  if (!schemaReady) {
    schemaReady = pg
      .query(`ALTER TABLE staff ADD COLUMN IF NOT EXISTS demo_view BOOLEAN NOT NULL DEFAULT false`)
      .catch((e) => { schemaReady = null; throw e; });
  }
  return schemaReady;
}

function blank(value, key) {
  if (key && KEEP_KEYS.has(key)) return value;
  if (Array.isArray(value)) return [];
  if (value === null || value === undefined) return value;
  if (typeof value === 'number') return 0;
  if (typeof value === 'boolean') return value;
  if (typeof value === 'string') {
    // Numeric strings (pg numerics / bigints) stay numeric so .toFixed() etc. work.
    return value.trim() !== '' && !isNaN(Number(value)) ? '0' : '';
  }
  if (typeof value === 'object') {
    if (value instanceof Date) return null;
    const out = {};
    for (const k of Object.keys(value)) out[k] = blank(value[k], k);
    return out;
  }
  return value;
}

const WRITE_STUB = {
  status: 'success',
  success: true,
  message: 'Demo account — no changes were saved',
  data: [],
};

function isDemoToken(req) {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) return false;
  try {
    return jwt.verify(header.slice(7), process.env.JWT_SECRET).demo_view === true;
  } catch {
    return false;
  }
}

function demoViewGuard(req, res, next) {
  if (!isDemoToken(req)) return next();
  const path = req.originalUrl.split('?')[0];
  if (PASSTHROUGH.some((re) => re.test(path))) return next();

  if (req.method !== 'GET' && req.method !== 'HEAD' && req.method !== 'OPTIONS') {
    return res.status(200).json(WRITE_STUB);
  }

  const json = res.json.bind(res);
  res.json = (body) => json(body && typeof body === 'object' ? blank(body) : body);
  const send = res.send.bind(res);
  res.send = (body) => {
    // Non-JSON payloads (CSV / PDF exports, files) are dropped entirely.
    if (typeof body === 'string' || Buffer.isBuffer(body)) {
      const type = String(res.get('Content-Type') || '');
      if (type.includes('application/json')) return send(body);
      return send('');
    }
    return send(body);
  };
  res.sendFile = () => res.status(204).end();
  res.download = () => res.status(204).end();
  next();
}

module.exports = { demoViewGuard, blank, ensureDemoViewSchema, WRITE_STUB };
