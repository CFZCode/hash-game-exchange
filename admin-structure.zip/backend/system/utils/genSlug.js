module.exports = async function genSlug(len = 7) {
  // dynamic import → no top-level await problems
  const { customAlphabet } = await import('nanoid');          // <- ESM!
  const nanoid = customAlphabet('0123456789abcdefghijklmnopqrstuvwxyz', len);
  return nanoid();                                            // e.g. "ab3k92x"
};