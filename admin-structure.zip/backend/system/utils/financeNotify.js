// system/utils/financeNotify.js
// Email + Telegram alerts for financial transactions performed by the
// SuperAdmin or one of its executives (i.e. an actor operating at role level 0).
//
// Fire-and-forget: a notification failure must NEVER break the action or its
// activity-log write.
const axios = require('axios');
const pg = require('../../General/Model');
const config = require('../../config');
const emailService = require('../../emailservice/controller');

// Financial actions we alert on.
const FINANCIAL_ACTIONS = new Set([
  'wallet.balance.update',  // direct wallet credit / debit
  'user.wallet.refill',     // quick refill
  'funds.deposit',          // agent -> account deposit (actual amount)
  'funds.withdraw',         // account -> agent withdrawal (actual amount)
  'transfer.credit',        // legacy: G/T credit transfer (removed)
  'transfer.casino',        // legacy: casino settlement transfer (removed)
  // Deposit / withdrawal approvals & rejections by the admin.
  'deposit.approved',
  'deposit.rejected',
  'withdraw.approved',
  'withdraw.rejected',
]);

const FALLBACK_EMAIL = 'salvin.dev.cfz@gmail.com';

// Where alerts go — the same admin-configured address the auto deposit/withdraw
// notifications use (siteconfig.apaynotificationemail).
async function getRecipientEmail() {
  try {
    const { rows } = await pg.query('SELECT apaynotificationemail FROM siteconfig LIMIT 1');
    return rows[0]?.apaynotificationemail || FALLBACK_EMAIL;
  } catch (e) {
    return FALLBACK_EMAIL;
  }
}

// Resolve a target's display name (USER / STAFF / EXECUTIVE) for the message.
async function resolveTargetName(targetType, targetId) {
  if (!targetType || targetId == null) return null;
  const id = String(targetId);
  try {
    if (targetType === 'USER') {
      const { rows } = await pg.query('SELECT name FROM users WHERE id::text = $1', [id]);
      return rows[0]?.name || null;
    }
    if (targetType === 'STAFF') {
      const { rows } = await pg.query('SELECT name FROM staff WHERE id::text = $1', [id]);
      return rows[0]?.name || null;
    }
    if (targetType === 'EXECUTIVE') {
      const { rows } = await pg.query('SELECT username AS name FROM executives WHERE id::text = $1', [id]);
      return rows[0]?.name || null;
    }
  } catch (e) { /* leave unresolved */ }
  return null;
}

// Confirm the actor is the SuperAdmin or one of its executives. Executives
// operate as their parent staff, so the parent's level is what matters: level 0.
async function isSuperOrItsExecutive(actor) {
  if (actor && actor.level === 0) return true;
  if (!actor || actor.staffId == null) return false;
  try {
    const { rows } = await pg.query(
      `SELECT r.level FROM staff s JOIN roles r ON r.id = s.role_id WHERE s.id = $1`,
      [actor.staffId]
    );
    return rows.length ? Number(rows[0].level) === 0 : false;
  } catch (e) {
    return false;
  }
}

// Human-readable one-liner describing the transaction.
function describe(action, details, targetLabel) {
  const d = details || {};
  const amt = d.amount != null ? d.amount : '';
  const cur = (d.coin || d.currency) ? String(d.coin || d.currency).toUpperCase() : 'INR';
  switch (action) {
    case 'wallet.balance.update':
      return `${d.operation === 'debit' ? 'Debited' : 'Credited'} ${amt} ${cur} ${d.operation === 'debit' ? 'from' : 'to'} ${targetLabel}`;
    case 'user.wallet.refill':
      return `Refilled ${amt} INR to ${targetLabel}${d.note ? ` — "${d.note}"` : ''}`;
    case 'funds.deposit':
      return `Deposited ${amt} to ${targetLabel}`;
    case 'funds.withdraw':
      return `Withdrew ${amt} from ${targetLabel}`;
    case 'transfer.credit':
      return `Transferred ${amt} credit to ${targetLabel}`;
    case 'transfer.casino':
      return `Casino transfer of ${amt} to ${targetLabel}`;
    case 'deposit.approved':
      return `Approved deposit #${d.depositId ?? ''} for ${targetLabel}${amt ? ` (${amt} ${cur})` : ''}`;
    case 'deposit.rejected':
      return `Rejected deposit #${d.depositId ?? ''} for ${targetLabel}`;
    case 'withdraw.approved':
      return `Approved withdrawal of ${amt} ${cur} for ${targetLabel}`;
    case 'withdraw.rejected':
      return `Rejected withdrawal of ${amt} ${cur} for ${targetLabel} (refunded)`;
    default:
      return `${action} on ${targetLabel}`;
  }
}

function escapeHtml(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function detailsTable(rows) {
  const cells = rows
    .filter(([, v]) => v !== undefined && v !== null && v !== '')
    .map(([k, v]) => `
      <tr>
        <td style="padding:6px 12px;border:1px solid #e2e8f0;background:#f8fafc;font-weight:600;">${escapeHtml(k)}</td>
        <td style="padding:6px 12px;border:1px solid #e2e8f0;">${escapeHtml(v)}</td>
      </tr>`).join('');
  return `<table style="border-collapse:collapse;width:100%;font-size:14px;">${cells}</table>`;
}

async function sendTelegram(text) {
  const token = config.TELEGRAM_BOT_TOKEN;
  const chatId = config.TELEGRAM_CHAT_ID;
  if (!token || !chatId) return; // disabled until creds are filled in
  try {
    await axios.post(
      `https://api.telegram.org/bot${token}/sendMessage`,
      { chat_id: chatId, text, parse_mode: 'HTML', disable_web_page_preview: true },
      { timeout: 8000 }
    );
  } catch (e) {
    console.error('[financeNotify] telegram failed:', e.response?.data?.description || e.message);
  }
}

/**
 * Decide whether an action warrants a financial alert and, if so, send it on
 * both channels. Safe to call for every action — it self-filters.
 *
 * @param {Object} args
 * @param {string} args.action
 * @param {Object} args.actor      { staffId, executiveId, name, role, level }
 * @param {string} [args.targetType]
 * @param {string|number} [args.targetId]
 * @param {Object} [args.details]
 * @param {Object} [args.loc]      { ip, country, region, city }
 * @param {string} [args.status]
 */
async function maybeNotify({ action, actor, targetType, targetId, details, loc, status = 'success' }) {
  try {
    if (status !== 'success') return;
    if (!FINANCIAL_ACTIONS.has(action)) return;
    if (!(await isSuperOrItsExecutive(actor))) return;

    const targetName = await resolveTargetName(targetType, targetId);
    const targetLabel = targetName
      ? `${(targetType || 'record').toLowerCase()} ${targetName}${targetId ? ` (#${targetId})` : ''}`
      : (targetId ? `${(targetType || 'record').toLowerCase()} #${targetId}` : (targetType || 'record').toLowerCase());

    const summary = describe(action, details, targetLabel);
    const actorName = actor?.name || (actor?.staffId != null ? `#${actor.staffId}` : 'Unknown');
    const performedBy = `${actorName}${actor?.executiveId ? ' (Executive)' : ''}`;
    const location = loc ? [loc.city, loc.region, loc.country].filter(Boolean).join(', ') : '';
    const when = new Date().toLocaleString();

    // ── Email ──────────────────────────────────────────────
    const html = `
      <p style="font-size:15px;margin:0 0 12px;"><strong>${escapeHtml(summary)}</strong></p>
      ${detailsTable([
        ['Action', action],
        ['Performed by', performedBy],
        ['Role', actor?.role || ''],
        ['Target', targetLabel],
        ['Amount', details?.amount != null ? `${details.amount} ${(details.coin || details.currency) ? String(details.coin || details.currency).toUpperCase() : 'INR'}` : ''],
        ['When', when],
        ['IP address', loc?.ip || ''],
        ['Location', location],
      ])}
    `;
    getRecipientEmail()
      .then(to => emailService.sendGeneralEmail(to, `Financial alert: ${summary}`, {
        title: 'Financial Transaction Alert',
        content: html,
      }))
      .catch(err => console.error('[financeNotify] email failed:', err.message));

    // ── Telegram ───────────────────────────────────────────
    const tg =
      `💸 <b>Financial Transaction</b>\n` +
      `${escapeHtml(summary)}\n\n` +
      `👤 <b>By:</b> ${escapeHtml(performedBy)}${actor?.role ? ` (${escapeHtml(actor.role)})` : ''}\n` +
      (details?.amount != null ? `💰 <b>Amount:</b> ${escapeHtml(details.amount)} ${escapeHtml((details.coin || details.currency) ? String(details.coin || details.currency).toUpperCase() : 'INR')}\n` : '') +
      `🕒 <b>When:</b> ${escapeHtml(when)}\n` +
      (loc?.ip ? `🌐 <b>IP:</b> ${escapeHtml(loc.ip)}${location ? ` (${escapeHtml(location)})` : ''}\n` : '');
    sendTelegram(tg);
  } catch (e) {
    console.error('[financeNotify] maybeNotify failed:', e.message);
  }
}

module.exports = { maybeNotify, FINANCIAL_ACTIONS };
