const pg = require('../../General/Model');
const { withTransaction } = require('../../General/Model/pool');

// Branch panel. Hierarchy:
//   SuperAdmin  ->  BranchAdmin  ->  SubBranch  ->  players
//   roles 'BranchAdmin' — created by the super admin; sees everything under
//                         its own sub branches and creates them
//   roles 'SubBranch'   — created by a branch admin; owns a registration code
//                         (staff.agent_code). A player who signs up with that
//                         code gets users.parent_staff_id = the sub branch
// Both roles are view-only and sign in at the branch panel's own login. They
// may only call /api/branch (see protectStaff / guardAdmin). Locking one
// (staff.system_locked) ends its session, cascades to everything below it and
// stops its code from taking registrations.

const BRANCH_ADMIN_ROLE = 'BranchAdmin';
const SUB_BRANCH_ROLE = 'SubBranch';
const BRANCH_ROLES = [BRANCH_ADMIN_ROLE, SUB_BRANCH_ROLE];
// Same depth as Agent / SubAgent so nothing level-based treats them as admins.
const ROLE_LEVELS = { [BRANCH_ADMIN_ROLE]: 4, [SUB_BRANCH_ROLE]: 5 };

const isBranchRoleName = (name) => BRANCH_ROLES.includes(name);

// Same once-per-process pattern as demoUsers.js.
let rolesReady = null;
function ensureBranchRoles() {
  if (!rolesReady) {
    rolesReady = (async () => {
      const { rows } = await pg.query('SELECT name FROM roles WHERE name = ANY($1)', [BRANCH_ROLES]);
      const missing = BRANCH_ROLES.filter(n => !rows.some(r => r.name === n));
      if (!missing.length) return;
      await withTransaction(async (client) => {
        await client.query(`SET LOCAL lock_timeout = '5s'`);
        for (const name of missing) {
          await client.query(
            `INSERT INTO roles (id, name, level)
             SELECT m.next_id, $1::text, $2::int
               FROM (SELECT COALESCE(MAX(id), 0) + 1 AS next_id FROM roles) m
              WHERE NOT EXISTS (SELECT 1 FROM roles WHERE name = $1::text)`,
            [name, ROLE_LEVELS[name]]
          );
        }
        await client.query(`SELECT setval('roles_id_seq', (SELECT MAX(id) FROM roles))`);
      });
      console.log('[branch] added roles:', missing.join(', '));
    })().catch((err) => {
      rolesReady = null; // retry on next call
      throw err;
    });
  }
  return rolesReady;
}

let roleIds = null;
async function getBranchRoleIds() {
  if (roleIds) return roleIds;
  await ensureBranchRoles();
  const { rows } = await pg.query('SELECT id, name FROM roles WHERE name = ANY($1)', [BRANCH_ROLES]);
  const byName = Object.fromEntries(rows.map(r => [r.name, Number(r.id)]));
  roleIds = { branchAdmin: byName[BRANCH_ADMIN_ROLE], subBranch: byName[SUB_BRANCH_ROLE] };
  return roleIds;
}

// True when the staff row or anything above it is system locked.
async function isLockedInTree(staffId) {
  const { rowCount } = await pg.query(
    `SELECT 1 FROM staff_hierarchy h JOIN staff s ON s.id = h.ancestor_id
      WHERE h.descendant_id = $1 AND s.system_locked = true
     UNION ALL
     SELECT 1 FROM staff WHERE id = $1 AND system_locked = true
     LIMIT 1`,
    [staffId]
  );
  return rowCount > 0;
}

// What a code typed at signup resolves to:
//   'none'    — not a staff code at all
//   'ok'      — a staff code that may take the registration
//   'blocked' — a sub branch code that is locked (itself or above)
// A branch admin's code is not a signup code, so it reads as 'none'.
async function registrationCodeStatus(code) {
  const c = String(code || '').trim();
  if (!c) return 'none';
  const { rows } = await pg.query(
    `SELECT s.id, r.name AS role FROM staff s JOIN roles r ON r.id = s.role_id
      WHERE s.agent_code = $1 AND r.name NOT IN ('DemoAgent', $2) LIMIT 1`,
    [c, BRANCH_ADMIN_ROLE]
  );
  if (!rows.length) return 'none';
  if (isBranchRoleName(rows[0].role) && await isLockedInTree(rows[0].id)) return 'blocked';
  return 'ok';
}

// Branch players use the site like direct signups — every currency, gateway
// deposits and withdrawals, gift cards, KYC — unlike agent players, whose
// money only moves through their agent. "Self-serve" = no parent staff, or a
// branch / sub branch parent. Use this wherever "direct users only" was meant
// as "players who pay through the site".
const selfServeSql = (alias = 'u') =>
  `(${alias}.parent_staff_id IS NULL OR ${alias}.parent_staff_id IN (
     SELECT bs.id FROM staff bs JOIN roles br ON br.id = bs.role_id
      WHERE br.name IN ('${BRANCH_ADMIN_ROLE}', '${SUB_BRANCH_ROLE}')))`;

async function isSelfServeParent(parentStaffId) {
  if (parentStaffId == null) return true;
  const { rowCount } = await pg.query(
    `SELECT 1 FROM staff s JOIN roles r ON r.id = s.role_id WHERE s.id = $1 AND r.name = ANY($2)`,
    [parentStaffId, BRANCH_ROLES]
  );
  return rowCount > 0;
}

module.exports = {
  BRANCH_ADMIN_ROLE,
  SUB_BRANCH_ROLE,
  BRANCH_ROLES,
  isBranchRoleName,
  ensureBranchRoles,
  getBranchRoleIds,
  isLockedInTree,
  registrationCodeStatus,
  selfServeSql,
  isSelfServeParent,
};
