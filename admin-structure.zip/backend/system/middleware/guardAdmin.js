/*
 * guardAdmin — non-breaking, audit-first authentication guard for admin/staff
 * endpoints that are currently exposed with NO authentication (e.g. /users,
 * /deleteUser, /adminwalletadd, /updateWithdrawStatus and the admin reporting
 * routes).
 *
 * Why audit-first: several admin-panel screens do not yet attach the staff
 * Bearer token to every request. Hard-blocking these endpoints today would
 * break those screens. So this guard defaults to AUDIT mode:
 *
 *   • Valid staff token present  -> attaches req.staff and continues.
 *   • Token missing / invalid    -> logs a structured warning and STILL
 *                                    continues (behaviour identical to today).
 *
 * Rollout to actually close the hole (zero-downtime):
 *   1. Deploy this (audit mode) and watch the logs for
 *      "[guardAdmin] ... unauthenticated ..." lines to see which callers still
 *      omit the token.
 *   2. Make the admin panel attach `Authorization: Bearer <token>` on those
 *      calls and redeploy the panel.
 *   3. When the warnings stop, set env ADMIN_AUTH_ENFORCE=true. The guard then
 *      returns 401 for unauthenticated requests — the hole is closed with no
 *      surprise breakage.
 *
 * Fail-open safety: if the DB lookup that verifies the staff row errors, the
 * request is allowed through even in enforce mode, so a transient DB hiccup can
 * never lock admins out. Only a *missing/invalid token* is blocked in enforce
 * mode.
 */

const jwt = require('jsonwebtoken');
const pg = require('../../General/Model');
const { isBranchRoleName } = require('../utils/branch');

const isEnforced = () =>
  String(process.env.ADMIN_AUTH_ENFORCE || '').toLowerCase() === 'true';

async function verifyStaff(req) {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) return { ok: false, reason: 'no-token' };

  let decoded;
  try {
    decoded = jwt.verify(header.slice(7), process.env.JWT_SECRET);
  } catch (e) {
    return { ok: false, reason: 'bad-token:' + e.name };
  }

  try {
    const { rows } = await pg.query(
      `SELECT s.id, s.role_id, r.level, r.name AS db_role
         FROM staff s JOIN roles r ON r.id = s.role_id
        WHERE s.id = $1`,
      [decoded.id]
    );
    if (!rows.length) return { ok: false, reason: 'staff-not-found' };
    return {
      ok: true,
      staff: {
        ...rows[0],
        name: decoded.name || null,
        role_name: decoded.role_name || null,
      },
    };
  } catch (e) {
    // DB problem — treat as "cannot verify", never block on this.
    return { ok: false, reason: 'db-error', error: e };
  }
}

/**
 * @param {string} label  short route label used in the audit log line
 */
function guardAdmin(label = '') {
  return async function (req, res, next) {
    try {
      const v = await verifyStaff(req);
      if (v.ok) {
        // A verified branch panel account has no business on admin endpoints.
        if (isBranchRoleName(v.staff.db_role))
          return res.status(403).json({ status: 'fail', message: 'Branch accounts can only use the branch panel' });
        req.staff = v.staff;
        return next();
      }

      const ip =
        req.headers['x-forwarded-for'] ||
        (req.socket && req.socket.remoteAddress) ||
        '';
      console.warn(
        `[guardAdmin]${label ? ' ' + label : ''} unauthenticated ` +
        `${req.method} ${req.originalUrl} from ${ip} ` +
        `(${v.reason}) enforce=${isEnforced()}`
      );

      // Block only when enforcing AND we actually saw a missing/invalid token
      // (never on our own DB errors).
      if (isEnforced() && v.reason !== 'db-error') {
        return res.status(401).json({ status: 'fail', message: 'Unauthorized' });
      }
      return next();
    } catch (e) {
      return next(e);
    }
  };
}

module.exports = { guardAdmin };
