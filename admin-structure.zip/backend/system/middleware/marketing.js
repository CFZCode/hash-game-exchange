// system/middleware/marketing.js
// Gate for the marketing panel. Runs after protectStaff, which has already
// verified the JWT and (for executive tokens) confirmed the executive row is
// active and still owned by the parent staff in the token.

const pg = require('../../General/Model');

/**
 * Enforces two things the marketing panel depends on:
 *
 *   1. Read-only. Any verb other than GET/HEAD is rejected outright. The UI
 *      also hides mutations, but this is the guarantee — a marketing token is
 *      incapable of writing through these routes regardless of what is sent.
 *
 *   2. The caller really is a marketing account. A classic executive token, or
 *      a plain staff token, must not be able to read these endpoints just by
 *      knowing the URL, so we re-read `kind` from the database rather than
 *      trusting a claim in the JWT.
 */
exports.protectMarketing = async (req, res, next) => {
  try {
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      return res.status(405).json({
        status: 'fail',
        message: 'The marketing panel is read-only.',
      });
    }

    const executiveId = req.staff?.executive_id;
    if (!executiveId) {
      return res.status(403).json({ status: 'fail', message: 'Marketing account required' });
    }

    const { rows } = await pg.query(
      `SELECT id, username, kind, status, last_login
         FROM executives
        WHERE id = $1`,
      [executiveId]
    );

    if (!rows.length)
      return res.status(401).json({ status: 'fail', message: 'Account not found' });

    const exec = rows[0];

    if (exec.kind !== 'marketing')
      return res.status(403).json({ status: 'fail', message: 'Marketing account required' });

    // protectStaff already checks this, but it is cheap and this middleware is
    // the one thing standing between a revoked account and platform-wide
    // revenue figures — so re-assert it here rather than rely on call order.
    if (exec.status !== 'active')
      return res.status(403).json({ status: 'fail', message: `Account is ${exec.status}.` });

    req.marketing = exec;
    next();
  } catch (e) {
    next(e);
  }
};
