/*
 * guardPlayer — authenticates a PLAYER on REST endpoints and exposes their id
 * as req.playerUid.
 *
 * It uses the same session token players already hold for socket auth: the
 * opaque string stored in the `tokens` table and resolved by Token.getID. The
 * token may arrive as `Authorization: Bearer <t>`, a `token` / `x-auth-token`
 * header, or `token` in the body/query.
 *
 * Why this exists: money endpoints like /transfer-in and /transfer-out used to
 * take `uid` straight from the request body, so anyone could act on any
 * account (IDOR). With this guard the acting user id comes from the verified
 * token instead — the body `uid` is ignored.
 */

const Token = require('../../Users/Token');

function extractToken(req) {
  const auth = req.headers.authorization || '';
  if (auth.startsWith('Bearer ')) return auth.slice(7).trim();
  return (
    req.headers.token ||
    req.headers['x-auth-token'] ||
    (req.body && req.body.token) ||
    (req.query && req.query.token) ||
    null
  );
}

function guardPlayer(req, res, next) {
  const token = extractToken(req);
  if (!token) {
    return res.status(401).json({ error: 'Authentication required' });
  }
  // Token.getID calls back (uid, err): (uid, false) on success, (false, true) on miss.
  Token.getID(token, (uid, err) => {
    if (err || !uid) {
      return res.status(401).json({ error: 'Invalid or expired session' });
    }
    req.playerUid = uid;
    next();
  });
}

module.exports = { guardPlayer };
