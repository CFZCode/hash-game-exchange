
const jwt = require('jsonwebtoken');
const pg = require('../../General/Model');
const { isBranchRoleName } = require('../utils/branch');




exports.protectStaff = async (req, res, next) => {
  try {
    const header = req.headers.authorization || '';
    if (!header.startsWith('Bearer ')) {
      return res.status(401).json({ status: 'fail', message: 'No token' });
    }

    let decoded;
    try {
      // Extract and verify the JWT token
      decoded = jwt.verify(header.slice(7), process.env.JWT_SECRET);
    } catch (jwtError) {
      // Handle JWT-specific errors
      if (jwtError.name === 'TokenExpiredError') {
        return res.status(401).json({
          status: 'fail',
          message: 'Token expired'
        });
      } else if (jwtError.name === 'JsonWebTokenError') {
        return res.status(401).json({
          status: 'fail',
          message: 'Invalid token'
        });
      } else if (jwtError.name === 'NotBeforeError') {
        return res.status(401).json({
          status: 'fail',
          message: 'Token not active'
        });
      } else {
        return res.status(401).json({
          status: 'fail',
          message: 'Token verification failed'
        });
      }
    }

    const { id, executive_id } = decoded;

    const { rows } = await pg.query(
      `SELECT s.id, s.role_id, r.level, r.name AS db_role
       FROM staff s JOIN roles r ON r.id = s.role_id
       WHERE s.id = $1`, [id]
    );

    if (!rows.length) {
      return res.status(401).json({
        status: 'fail',
        message: 'Staff not found'
      });
    }

    // Branch panel accounts are view-only and live entirely under /api/branch.
    if (isBranchRoleName(rows[0].db_role) && !req.originalUrl.startsWith('/api/branch/')) {
      return res.status(403).json({
        status: 'fail',
        message: 'Branch accounts can only use the branch panel'
      });
    }

    req.staff = rows[0]; // {id, role_id, level}

    // Carry the actor's identity from the token so the activity log can snapshot
    // who did what without an extra query on every action.
    req.staff.name = decoded.name || null;
    req.staff.role_name = decoded.role_name || null;
    if (req.staff.level == null && decoded.role_level != null)
      req.staff.level = decoded.role_level;

    // Executive token: verify the executive still exists & is active.
    // Subsequent controllers operate as the parent staff (req.staff.id),
    // but executive_id is also exposed for activity logging + permission checks.
    if (executive_id) {
      const { rows: execRows } = await pg.query(
        `SELECT id, status, parent_staff_id, permissions FROM executives WHERE id = $1`,
        [executive_id]
      );
      if (!execRows.length)
        return res.status(401).json({ status: 'fail', message: 'Executive not found' });
      const exec = execRows[0];
      if (exec.status !== 'active')
        return res.status(403).json({ status: 'fail', message: `Account is ${exec.status}.` });
      if (exec.parent_staff_id !== req.staff.id)
        return res.status(401).json({ status: 'fail', message: 'Token / parent mismatch' });

      req.staff.executive_id = exec.id;
      req.staff.executive_permissions =
        typeof exec.permissions === 'string'
          ? (() => { try { return JSON.parse(exec.permissions); } catch { return null; } })()
          : exec.permissions;
    }

    next();
  } catch (e) {
    next(e);
  }
};

exports.accessStaff = async (req, res, next) => {
  try {
    const key = req.headers['x_api_key']
    if (!key) return res.status(401).json({ status: 'fail', message: 'No key' });

    if (req?.staff?.level) {
      const { rows } = await pg.query(`SELECT id FROM staff WHERE id = $1 AND access_key=$2`, [req?.staff.id, key]);
      if (!rows.length) return res.status(401).json({ status: 'fail', message: 'Staff not found' });
    }


    next();
  } catch (e) {
    next(e);
  }
};