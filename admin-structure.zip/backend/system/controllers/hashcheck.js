const bcrypt = require('bcrypt');

// Test the password against the stored hash
const password = 'REMOVED_SECRET';
const storedHash = '$2b$10$0J6iBtzv719q/6Gy4xqRSu3zG5e3TnwYpM.N0llTY4yr2HLkz6i8C';

bcrypt.compare(password, storedHash).then(result => {
    console.log('Password matches:', result);
});

// Also generate a new hash to see what it should look like
bcrypt.hash(password, 10).then(newHash => {
    console.log('New hash for same password:', newHash);
});