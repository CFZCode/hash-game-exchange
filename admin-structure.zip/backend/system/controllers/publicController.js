// backend/system/controllers/publicController.js

const pg       = require('../../General/Model');

exports.resolveWhatsappRef = async (req,res,next)=>{
  try {
    const { slug } = req.params;                 // /api/ref/:slug
    const { rows:[row] } = await pg.query(
      'SELECT phone FROM staff_whatsapp_ref WHERE slug=$1',[slug]
    );
    if (!row) return res.status(404).json({ error:'Unknown referral code' });
    res.json({ phone: row.phone });
  } catch(e){ next(e); }
};

/* ------------------------------------------------------------------
   GET /api/public/user-transfers/:uid?page&limit
   Lists staff_transfers rows where the given user is either the
   recipient (Credit to User) or the sender (Debit from User).
   Used by the agent-managed-user transactions screen.
------------------------------------------------------------------- */
exports.getUserTransfers = async (req, res, next) => {
  try {
    const uid = Number(req.params.uid);
    if (!Number.isInteger(uid) || uid <= 0) {
      return res.status(400).json({ status: 'error', error: 'Invalid user id' });
    }

    const page  = Math.max(1, +(req.query.page  || 1));
    const limit = Math.min(100, +(req.query.limit || 50));
    const offset = (page - 1) * limit;

    const sql = `
      WITH scoped AS (
        SELECT t.id, t.from_type, t.from_id,
               t.to_type,   t.to_id,
               t.amount,    t.created_at,
               CASE
                 WHEN t.to_type   = 'user' AND t.to_id   = $1 THEN 'deposit'
                 WHEN t.from_type = 'user' AND t.from_id = $1 THEN 'withdraw'
                 ELSE 'internal'
               END AS direction
          FROM staff_transfers t
         WHERE (t.from_type = 'user' AND t.from_id = $1)
            OR (t.to_type   = 'user' AND t.to_id   = $1)
      )
      SELECT s.id,
             s.from_type, s.from_id,
             s.to_type,   s.to_id,
             s.amount,    s.created_at,
             s.direction,
             COALESCE(sf_from.name, u_from.name) AS from_name,
             COALESCE(sf_to.name,   u_to.name)   AS to_name
        FROM scoped s
        LEFT JOIN staff sf_from ON s.from_type = 'staff' AND sf_from.id = s.from_id
        LEFT JOIN staff sf_to   ON s.to_type   = 'staff' AND sf_to.id   = s.to_id
        LEFT JOIN users u_from  ON s.from_type = 'user'  AND u_from.id  = s.from_id
        LEFT JOIN users u_to    ON s.to_type   = 'user'  AND u_to.id    = s.to_id
       ORDER BY s.created_at DESC
       OFFSET $2 LIMIT $3
    `;

    const { rows } = await pg.query(sql, [uid, offset, limit]);
    return res.json({ status: 'success', page, limit, data: rows });
  } catch (e) { next(e); }
};
