// system/controllers/marketingController.js
// Marketing panel — read-only, platform-wide acquisition & deposit analytics.
//
// Auth context: req.staff (set by protectStaff) + req.marketing (set by protectMarketing).
// Every handler here is a GET; protectMarketing rejects any other verb before we
// are reached, so nothing in this file mutates state.
//
// Channel attribution follows the same rule the rest of the codebase uses:
//   users.parent_staff_id IS NULL      → 'online'  (direct signup)
//   users.parent_staff_id IS NOT NULL  → 'agent'   (onboarded under an agent)
// See Users/Rule.js where a `refree` matching a staff.agent_code sets parent_staff_id.

const pg = require('../../General/Model');

/* ─── deposit normalisation ──────────────────────────────────────
   The four deposit tables disagree on column names, status values, and how
   currency is expressed. This CTE flattens them to (user_id, usd, created_at)
   so every query below can treat deposits as one stream.

   Gotchas baked in here:
     - ccdeposit.userid is VARCHAR while users.id is BIGINT → compare as text.
     - ccdeposit has no currency column; it maps coinid → symbol (same mapping
       as the admin dashboard in index.js).
     - pay_in_transactions.status is a SMALLINT (1 = success), not a string.
     - The exchangerate JOIN is INNER, matching the existing dashboard: a
       deposit in a currency with no rate row is excluded rather than counted
       at face value, which would silently inflate USD totals.
*/
const DEPOSITS_CTE = `
  all_deposits AS (
    SELECT u.id AS user_id, (c.amount::numeric * e.usd_rate) AS usd, c.created_at
      FROM ccdeposit c
      JOIN users u ON u.id::text = c.userid
      JOIN exchangerate e ON e.currency = CASE c.coinid
        WHEN 1155 THEN 'BTC'  WHEN 1161 THEN 'ETH'  WHEN 1173 THEN 'LTC'
        WHEN 1169 THEN 'BCH'  WHEN 1280 THEN 'USDT' WHEN 1482 THEN 'TRX'
        WHEN 1492 THEN 'DOGE' WHEN 1375 THEN 'ADA'  WHEN 1331 THEN 'XRP'
        WHEN 1168 THEN 'BNB'  WHEN 1282 THEN 'USDC' WHEN 1864 THEN 'SHIB'
      END
     WHERE c.status = 'Success'
    UNION ALL
    SELECT f.user_id, (f.amount::numeric * e.usd_rate), f.created_at
      FROM fiat_deposits f
      JOIN exchangerate e ON e.currency = f.currency
     WHERE f.status = 'approved'
    UNION ALL
    SELECT a.user_id, ((CASE WHEN a.paid_amount > 0 THEN a.paid_amount ELSE a.amount END)::numeric * e.usd_rate), a.created_at
      FROM apaydeposits a
      JOIN exchangerate e ON e.currency = a.currency
     WHERE a.status = 'Success'
    UNION ALL
    SELECT p.user_id, (p.amount::numeric * e.usd_rate), p.created_at
      FROM pay_in_transactions p
      JOIN exchangerate e ON e.currency = p.currency
     WHERE p.status = 1
  )
`;

const CHANNEL = `CASE WHEN u.parent_staff_id IS NULL THEN 'online' ELSE 'agent' END`;

/* ─── helpers ────────────────────────────────────────────────── */

// Resolve ?from / ?to into a bounded [from, to) window. Defaults to the last 30
// days. `to` is pushed to the end of its day so a same-day from/to still spans
// a full day rather than returning an empty range.
function resolveRange(query) {
  // Caller-supplied values are user error, not server error — tag them so the
  // handler answers 400 rather than 500.
  const bad = (msg) => Object.assign(new Error(msg), { httpStatus: 400 });

  const now = new Date();
  const to = query.to ? new Date(query.to) : now;
  const from = query.from
    ? new Date(query.from)
    : new Date(now.getTime() - 29 * 86400000);

  if (isNaN(from) || isNaN(to)) throw bad('Invalid from/to date');
  if (from > to) throw bad('`from` must be before `to`');

  const toEnd = new Date(to);
  toEnd.setHours(23, 59, 59, 999);

  // Cap the window so a hand-crafted query can't ask for an unbounded scan.
  // Three years covers "since launch" for this platform while still bounding
  // the worst case.
  const MAX_DAYS = 1100;
  if ((toEnd - from) / 86400000 > MAX_DAYS)
    throw bad(`Range too large (max ${MAX_DAYS} days)`);

  return { from: from.toISOString(), to: toEnd.toISOString() };
}

const num = (v) => Number(v || 0);
const fail = (res, e, tag) => {
  const code = e.httpStatus || 500;
  // Only genuine server faults are worth a stack trace in the logs; a bad date
  // from the client is not.
  if (code >= 500) console.error(`[marketing:${tag}]`, e);
  res.status(code).json({ status: 'fail', message: e.message });
};

/* ─── GET /marketing/analytics/signups ───────────────────────────
   Customer acquisition split by channel, plus a per-day series. */
exports.signups = async (req, res) => {
  try {
    const { from, to } = resolveRange(req.query);

    const [totals, series, undated] = await Promise.all([
      pg.query(
        `SELECT ${CHANNEL} AS channel, COUNT(*)::int AS count
           FROM users u
          WHERE u.created >= $1 AND u.created <= $2
          GROUP BY 1`,
        [from, to]
      ),
      pg.query(
        `SELECT to_char(date_trunc('day', u.created), 'YYYY-MM-DD') AS date,
                ${CHANNEL} AS channel,
                COUNT(*)::int AS count
           FROM users u
          WHERE u.created >= $1 AND u.created <= $2
          GROUP BY 1, 2
          ORDER BY 1`,
        [from, to]
      ),
      // Customers whose signup date is a backfilled estimate rather than the
      // real registration date. They now DO appear in the charts, so the UI
      // has to say which portion of the trend is estimated — otherwise the
      // backfill spike reads as genuine acquisition.
      pg.query(
        `SELECT COUNT(*)::int AS count,
                to_char(MIN(created), 'YYYY-MM-DD') AS on_date
           FROM users
          WHERE created_estimated = TRUE
            AND created >= $1 AND created <= $2`,
        [from, to]
      ),
    ]);

    const byChannel = { online: 0, agent: 0 };
    totals.rows.forEach((r) => { byChannel[r.channel] = r.count; });

    // Pivot the (date, channel) rows into one object per date so the chart can
    // render both series without client-side regrouping.
    const buckets = new Map();
    series.rows.forEach(({ date, channel, count }) => {
      if (!buckets.has(date)) buckets.set(date, { date, online: 0, agent: 0 });
      buckets.get(date)[channel] = count;
    });

    res.json({
      status: 'success',
      range: { from, to },
      total: byChannel.online + byChannel.agent,
      byChannel,
      series: [...buckets.values()],
      // Non-zero means part of this trend sits on estimated signup dates.
      estimatedUsers: undated.rows[0].count,
      estimatedOn: undated.rows[0].on_date,
    });
  } catch (e) { fail(res, e, 'signups'); }
};

/* ─── GET /marketing/analytics/deposits ──────────────────────────
   Volume, count, average, and first-time-depositor conversion by channel. */
exports.deposits = async (req, res) => {
  try {
    const { from, to } = resolveRange(req.query);

    const [agg, series, ftd] = await Promise.all([
      pg.query(
        `WITH ${DEPOSITS_CTE}
         SELECT ${CHANNEL} AS channel,
                COALESCE(SUM(d.usd), 0)::numeric(20,2) AS volume,
                COUNT(*)::int                          AS count,
                COALESCE(AVG(d.usd), 0)::numeric(20,2) AS average,
                COUNT(DISTINCT d.user_id)::int         AS depositors
           FROM all_deposits d
           JOIN users u ON u.id = d.user_id
          WHERE d.created_at >= $1 AND d.created_at <= $2
          GROUP BY 1`,
        [from, to]
      ),
      pg.query(
        `WITH ${DEPOSITS_CTE}
         SELECT to_char(date_trunc('day', d.created_at), 'YYYY-MM-DD') AS date,
                ${CHANNEL} AS channel,
                COALESCE(SUM(d.usd), 0)::numeric(20,2) AS volume,
                COUNT(*)::int AS count
           FROM all_deposits d
           JOIN users u ON u.id = d.user_id
          WHERE d.created_at >= $1 AND d.created_at <= $2
          GROUP BY 1, 2
          ORDER BY 1`,
        [from, to]
      ),
      // First-time-depositor conversion: of the users who REGISTERED in this
      // window, how many have ever deposited. Anchoring on the signup cohort
      // (not the deposit date) is what makes this a conversion rate rather
      // than an activity count.
      pg.query(
        `WITH ${DEPOSITS_CTE},
              cohort AS (
                SELECT u.id, ${CHANNEL} AS channel
                  FROM users u
                 WHERE u.created >= $1 AND u.created <= $2
              )
         SELECT c.channel,
                COUNT(*)::int AS cohort_size,
                COUNT(*) FILTER (
                  WHERE EXISTS (SELECT 1 FROM all_deposits d WHERE d.user_id = c.id)
                )::int AS converted
           FROM cohort c
          GROUP BY 1`,
        [from, to]
      ),
    ]);

    const blank = () => ({ volume: 0, count: 0, average: 0, depositors: 0, cohortSize: 0, converted: 0, conversionRate: 0 });
    const byChannel = { online: blank(), agent: blank() };

    agg.rows.forEach((r) => {
      byChannel[r.channel] = {
        ...byChannel[r.channel],
        volume: num(r.volume), count: r.count,
        average: num(r.average), depositors: r.depositors,
      };
    });
    ftd.rows.forEach((r) => {
      const c = byChannel[r.channel];
      c.cohortSize = r.cohort_size;
      c.converted = r.converted;
      c.conversionRate = r.cohort_size ? +(r.converted / r.cohort_size * 100).toFixed(2) : 0;
    });

    const totalVolume = byChannel.online.volume + byChannel.agent.volume;
    const totalCount = byChannel.online.count + byChannel.agent.count;

    const buckets = new Map();
    series.rows.forEach(({ date, channel, volume, count }) => {
      if (!buckets.has(date)) buckets.set(date, { date, online: 0, agent: 0, onlineCount: 0, agentCount: 0 });
      const b = buckets.get(date);
      b[channel] = num(volume);
      b[`${channel}Count`] = count;
    });

    res.json({
      status: 'success',
      range: { from, to },
      totals: {
        volume: totalVolume,
        count: totalCount,
        average: totalCount ? +(totalVolume / totalCount).toFixed(2) : 0,
      },
      byChannel,
      series: [...buckets.values()],
    });
  } catch (e) { fail(res, e, 'deposits'); }
};

/* ─── GET /marketing/analytics/retention ─────────────────────────
   Deposit-derived activity. NOTE: this is *depositing* users per day, not
   logins — the platform has no session/login table to derive true DAU from,
   so the field is named accordingly rather than mislabelled as DAU. */
exports.retention = async (req, res) => {
  try {
    const { from, to } = resolveRange(req.query);

    const [daily, repeat] = await Promise.all([
      pg.query(
        `WITH ${DEPOSITS_CTE}
         SELECT to_char(date_trunc('day', d.created_at), 'YYYY-MM-DD') AS date,
                COUNT(DISTINCT d.user_id)::int AS active_depositors
           FROM all_deposits d
          WHERE d.created_at >= $1 AND d.created_at <= $2
          GROUP BY 1
          ORDER BY 1`,
        [from, to]
      ),
      // Repeat rate = share of depositors in the window with more than one
      // deposit. Computed per channel so acquisition quality is comparable.
      pg.query(
        `WITH ${DEPOSITS_CTE},
              per_user AS (
                SELECT d.user_id, ${CHANNEL} AS channel, COUNT(*)::int AS n
                  FROM all_deposits d
                  JOIN users u ON u.id = d.user_id
                 WHERE d.created_at >= $1 AND d.created_at <= $2
                 GROUP BY 1, 2
              )
         SELECT channel,
                COUNT(*)::int                          AS depositors,
                COUNT(*) FILTER (WHERE n > 1)::int     AS repeat_depositors
           FROM per_user
          GROUP BY 1`,
        [from, to]
      ),
    ]);

    const byChannel = {
      online: { depositors: 0, repeatDepositors: 0, repeatRate: 0 },
      agent: { depositors: 0, repeatDepositors: 0, repeatRate: 0 },
    };
    repeat.rows.forEach((r) => {
      byChannel[r.channel] = {
        depositors: r.depositors,
        repeatDepositors: r.repeat_depositors,
        repeatRate: r.depositors ? +(r.repeat_depositors / r.depositors * 100).toFixed(2) : 0,
      };
    });

    res.json({
      status: 'success',
      range: { from, to },
      series: daily.rows.map((r) => ({ date: r.date, activeDepositors: r.active_depositors })),
      byChannel,
    });
  } catch (e) { fail(res, e, 'retention'); }
};

/* ─── GET /marketing/analytics/top-agents ────────────────────────
   Acquisition leaderboard. Agents are ranked by customers registered in the
   window; deposit volume is the lifetime volume of those same customers. */
exports.topAgents = async (req, res) => {
  try {
    const { from, to } = resolveRange(req.query);
    const limit = Math.min(50, Math.max(1, +(req.query.limit || 10)));

    const { rows } = await pg.query(
      `WITH ${DEPOSITS_CTE},
            cohort AS (
              SELECT u.id, u.parent_staff_id
                FROM users u
               WHERE u.parent_staff_id IS NOT NULL
                 AND u.created >= $1 AND u.created <= $2
            )
       SELECT s.id                                   AS agent_id,
              s.name                                 AS agent_name,
              s.agent_code                           AS agent_code,
              r.name                                 AS role,
              COUNT(DISTINCT c.id)::int              AS customers,
              COALESCE(SUM(d.usd), 0)::numeric(20,2) AS deposit_volume,
              COUNT(d.user_id)::int                  AS deposit_count
         FROM cohort c
         JOIN staff s ON s.id = c.parent_staff_id
         LEFT JOIN roles r ON r.id = s.role_id
         LEFT JOIN all_deposits d ON d.user_id = c.id
        GROUP BY s.id, s.name, s.agent_code, r.name
        ORDER BY customers DESC, deposit_volume DESC
        LIMIT $3`,
      [from, to, limit]
    );

    res.json({
      status: 'success',
      range: { from, to },
      agents: rows.map((r) => ({
        agentId: r.agent_id,
        agentName: r.agent_name,
        agentCode: r.agent_code,
        role: r.role,
        customers: r.customers,
        depositVolume: num(r.deposit_volume),
        depositCount: r.deposit_count,
      })),
    });
  } catch (e) { fail(res, e, 'topAgents'); }
};

/* ─── GET /marketing/me ──────────────────────────────────────────
   Identity for the marketing panel header. Deliberately minimal — no
   permissions blob, no parent staff details. */
exports.me = async (req, res) => {
  try {
    res.json({
      status: 'success',
      user: {
        id: req.marketing.id,
        username: req.marketing.username,
        lastLogin: req.marketing.last_login,
      },
    });
  } catch (e) { fail(res, e, 'me'); }
};

/* ─── GET /marketing/customers ───────────────────────────────────
   Customer directory, used by the Direct/Agent Users tabs and by the
   drill-down modals behind each dashboard stat card.

   Query:
     channel    all | direct | agent     (default all)
     depositors true → only customers who have deposited
     newOnly    true → only customers who registered inside the range
     from,to    range (applies to signup date when newOnly, else ignored)
     search     matches name / email / phone / id
     sort       recent | deposits | name
     page,limit pagination

   Returns full contact details. These are real customer records — the fields
   below are the ones the marketing panel is authorised to display; wallet
   balances, bet history and KYC documents are deliberately not selected. */
exports.customers = async (req, res) => {
  try {
    const page = Math.max(1, +(req.query.page || 1));
    const limit = Math.min(100, Math.max(1, +(req.query.limit || 25)));
    const offset = (page - 1) * limit;

    const channel = ['direct', 'agent'].includes(req.query.channel) ? req.query.channel : 'all';
    const depositorsOnly = req.query.depositors === 'true';
    const newOnly = req.query.newOnly === 'true';
    const search = (req.query.search || '').trim();
    const sort = ['recent', 'deposits', 'name'].includes(req.query.sort) ? req.query.sort : 'recent';

    const filters = [];
    const params = [];

    if (channel === 'direct') filters.push('u.parent_staff_id IS NULL');
    if (channel === 'agent') filters.push('u.parent_staff_id IS NOT NULL');

    if (newOnly) {
      const { from, to } = resolveRange(req.query);
      params.push(from, to);
      filters.push(`u.created >= $${params.length - 1} AND u.created <= $${params.length}`);
    }

    if (search) {
      params.push(`%${search.toLowerCase()}%`);
      const p = `$${params.length}`;
      filters.push(`(lower(u.name) LIKE ${p} OR lower(u.email) LIKE ${p}
                    OR lower(u.phone) LIKE ${p} OR u.id::text LIKE ${p})`);
    }

    if (depositorsOnly) filters.push('d.deposit_count > 0');

    const whereSql = filters.length ? `WHERE ${filters.join(' AND ')}` : '';

    const orderSql = {
      recent: 'u.created DESC NULLS LAST',
      deposits: 'COALESCE(d.deposit_volume, 0) DESC',
      name: 'lower(u.name) ASC',
    }[sort];

    // Per-user deposit rollup, joined once and reused for filter + sort +
    // display so the aggregate is computed a single time.
    const baseSql = `
      WITH ${DEPOSITS_CTE},
           per_user AS (
             SELECT user_id,
                    COUNT(*)::int                          AS deposit_count,
                    COALESCE(SUM(usd), 0)::numeric(20,2)   AS deposit_volume,
                    MAX(created_at)                        AS last_deposit_at
               FROM all_deposits
              GROUP BY user_id
           )
      SELECT %SELECT%
        FROM users u
        LEFT JOIN per_user d ON d.user_id = u.id
        LEFT JOIN staff s    ON s.id = u.parent_staff_id
        LEFT JOIN roles r    ON r.id = s.role_id
        ${whereSql}
    `;

    const countSql = baseSql.replace('%SELECT%', 'COUNT(*)::int AS count');
    const { rows: [{ count }] } = await pg.query(countSql, params);

    params.push(limit, offset);
    const listSql = baseSql.replace('%SELECT%', `
        u.id, u.name, u.email, u.phone, u.country, u.status,
        u.created, u.created_estimated, u.last_login_at, u.last_ip,
        u.referalcode, u.refree,
        s.id AS agent_id, s.name AS agent_name, s.agent_code, r.name AS agent_role,
        COALESCE(d.deposit_count, 0)  AS deposit_count,
        COALESCE(d.deposit_volume, 0) AS deposit_volume,
        d.last_deposit_at
      `) + ` ORDER BY ${orderSql} LIMIT $${params.length - 1} OFFSET $${params.length}`;

    const { rows } = await pg.query(listSql, params);

    res.json({
      status: 'success',
      total: count,
      page,
      limit,
      totalPages: Math.max(1, Math.ceil(count / limit)),
      customers: rows.map((u) => ({
        id: String(u.id),
        name: u.name || null,
        email: u.email || null,
        phone: u.phone || null,
        country: u.country || null,
        status: u.status || 'active',
        channel: u.agent_id ? 'agent' : 'online',
        createdAt: u.created,
        // TRUE means the signup date is a backfilled estimate, not the real
        // registration date — the UI marks these so they are not read as fact.
        createdEstimated: u.created_estimated === true,
        lastLoginAt: u.last_login_at,
        lastIp: u.last_ip || null,
        referralCode: u.referalcode || null,
        referredBy: u.refree || null,
        agent: u.agent_id
          ? { id: u.agent_id, name: u.agent_name, code: u.agent_code, role: u.agent_role }
          : null,
        depositCount: Number(u.deposit_count || 0),
        depositVolume: num(u.deposit_volume),
        lastDepositAt: u.last_deposit_at,
      })),
    });
  } catch (e) { fail(res, e, 'customers'); }
};
