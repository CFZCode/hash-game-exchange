// system/controllers/accessController.js
// Access Management — Executives + per-executive activity log.
//
// Auth context: req.staff = { id, role_id, level }   (set by protectStaff middleware)
// Conventions:
//   - PostgreSQL via require('../../General/Model')
//   - Plaintext transaction_password on staff (matches existing lordsController)
//   - Response shape: { status: 'success' | 'fail', message?, ... }   (matches frontend expectations)

const pg = require('../../General/Model');
const bcrypt = require('bcrypt');

let _accessSchemaReady = false;
async function ensureAccessSchema() {
  if (_accessSchemaReady) return;
  try {
    await pg.query(`
      CREATE TABLE IF NOT EXISTS executives (
        id                    SERIAL       PRIMARY KEY,
        username              VARCHAR(100) NOT NULL UNIQUE,
        password              VARCHAR(255) NOT NULL,
        parent_staff_id       INTEGER      NOT NULL REFERENCES staff(id) ON DELETE CASCADE,
        parent_role_snapshot  VARCHAR(50),
        permissions           JSONB        NOT NULL,
        status                VARCHAR(20)  NOT NULL DEFAULT 'active'
                                CHECK (status IN ('active','inactive','locked')),
        kind                  VARCHAR(20)  NOT NULL DEFAULT 'executive'
                                CHECK (kind IN ('executive','marketing')),
        last_login            TIMESTAMPTZ,
        last_login_ip         VARCHAR(64),
        created_at            TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
        updated_at            TIMESTAMPTZ  NOT NULL DEFAULT NOW()
      )
    `);
    await pg.query(`CREATE INDEX IF NOT EXISTS idx_executives_parent_staff_id ON executives(parent_staff_id)`);
    await pg.query(`CREATE INDEX IF NOT EXISTS idx_executives_username        ON executives(username)`);
    await pg.query(`
      CREATE TABLE IF NOT EXISTS executive_activity_logs (
        id              SERIAL       PRIMARY KEY,
        executive_id    INTEGER      NOT NULL REFERENCES executives(id) ON DELETE CASCADE,
        action          VARCHAR(80)  NOT NULL,
        target_type     VARCHAR(40),
        target_id       VARCHAR(40),
        details         JSONB,
        ip              VARCHAR(64),
        user_agent      VARCHAR(512),
        status          VARCHAR(10)  NOT NULL DEFAULT 'success'
                          CHECK (status IN ('success','failed')),
        error_message   VARCHAR(512),
        created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW()
      )
    `);
    await pg.query(`CREATE INDEX IF NOT EXISTS idx_exec_activity_executive_created ON executive_activity_logs(executive_id, created_at DESC)`);
    await pg.query(`CREATE INDEX IF NOT EXISTS idx_exec_activity_action ON executive_activity_logs(action)`);
    // Unified admin activity log — every action by any actor in the hierarchy.
    await pg.query(`
      CREATE TABLE IF NOT EXISTS admin_activity_logs (
        id              BIGSERIAL    PRIMARY KEY,
        staff_id        INTEGER      NOT NULL REFERENCES staff(id) ON DELETE CASCADE,
        executive_id    INTEGER      REFERENCES executives(id) ON DELETE SET NULL,
        actor_name      VARCHAR(120),
        actor_role      VARCHAR(50),
        actor_level     INTEGER,
        action          VARCHAR(80)  NOT NULL,
        target_type     VARCHAR(40),
        target_id       VARCHAR(60),
        details         JSONB,
        ip              VARCHAR(64),
        country         VARCHAR(80),
        region          VARCHAR(80),
        city            VARCHAR(120),
        user_agent      VARCHAR(512),
        status          VARCHAR(10)  NOT NULL DEFAULT 'success'
                          CHECK (status IN ('success','failed')),
        error_message   VARCHAR(512),
        created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW()
      )
    `);
    await pg.query(`CREATE INDEX IF NOT EXISTS idx_admin_activity_staff_created ON admin_activity_logs(staff_id, created_at DESC)`);
    await pg.query(`CREATE INDEX IF NOT EXISTS idx_admin_activity_executive_created ON admin_activity_logs(executive_id, created_at DESC)`);
    await pg.query(`CREATE INDEX IF NOT EXISTS idx_admin_activity_action ON admin_activity_logs(action)`);
    await pg.query(`CREATE INDEX IF NOT EXISTS idx_admin_activity_created ON admin_activity_logs(created_at DESC)`);
    // Backfill any columns missing from older deployments.
    await pg.query(`
      ALTER TABLE executives
        ADD COLUMN IF NOT EXISTS parent_role_snapshot VARCHAR(50),
        ADD COLUMN IF NOT EXISTS last_login           TIMESTAMPTZ,
        ADD COLUMN IF NOT EXISTS last_login_ip        VARCHAR(64),
        ADD COLUMN IF NOT EXISTS updated_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        ADD COLUMN IF NOT EXISTS kind                 VARCHAR(20) NOT NULL DEFAULT 'executive'
    `);
    await pg.query(`CREATE INDEX IF NOT EXISTS idx_executives_kind ON executives(kind)`);
    _accessSchemaReady = true;
  } catch (e) {
    console.warn('[ensureAccessSchema] failed:', e?.message);
  }
}

/* ─── helpers ────────────────────────────────────────────────── */

const validateTransactionPassword = async (staffId, transactionPassword) => {
  if (!transactionPassword) throw new Error('Transaction password is required');
  const { rows } = await pg.query(
    'SELECT transaction_password FROM staff WHERE id=$1', [staffId]
  );
  if (!rows.length) throw new Error('Staff not found');
  if (rows[0].transaction_password !== transactionPassword) {
    throw new Error('Invalid transaction password');
  }
};

const looksLikeStaffPermissions = (p) =>
  p && typeof p === 'object'
  && p.groups && typeof p.groups === 'object'
  && p.pages && typeof p.pages === 'object'
  && p.authority && typeof p.authority === 'object';

const normaliseExecRow = (r) => ({
  id: r.id,
  username: r.username,
  status: r.status,
  parentUserId: r.parent_staff_id,
  parentUsername: r.parent_username || null,
  parentRole: r.parent_role_snapshot || r.parent_role || null,
  permissions: typeof r.permissions === 'string' ? safeParse(r.permissions) : r.permissions,
  createdAt: r.created_at,
  lastLogin: r.last_login,
});

const safeParse = (s) => { try { return JSON.parse(s); } catch { return null; } };

/* ─── GET /lords/access/executives  list executives owned by req.staff ─── */
exports.listExecutives = async (req, res) => {
  try {
    await ensureAccessSchema();
    const page  = Math.max(1, +(req.query.page  || 1));
    const limit = Math.min(100, +(req.query.limit || 25));
    const offset = (page - 1) * limit;
    const search = (req.query.search || '').trim();

    // Marketing accounts live in this table too but are managed from their own
    // tab — keep them out of the Access Management executive list.
    const filters = ['e.parent_staff_id = $1', "e.kind = 'executive'"];
    const params  = [req.staff.id];
    if (search.length >= 1) {
      params.push(`%${search.toLowerCase()}%`);
      filters.push(`lower(e.username) LIKE $${params.length}`);
    }
    const whereSql = `WHERE ${filters.join(' AND ')}`;

    const { rows: [{ count }] } = await pg.query(
      `SELECT COUNT(*) FROM executives e ${whereSql}`,
      params
    );

    params.push(limit, offset);
    const { rows } = await pg.query(
      `SELECT e.*, s.name AS parent_username, r.name AS parent_role
         FROM executives e
         LEFT JOIN staff s ON s.id = e.parent_staff_id
         LEFT JOIN roles r ON r.id = s.role_id
         ${whereSql}
         ORDER BY e.created_at DESC
         LIMIT $${params.length - 1} OFFSET $${params.length}`,
      params
    );

    res.json({
      status: 'success',
      executives: rows.map(normaliseExecRow),
      total: Number(count),
      page,
      limit,
      totalPages: Math.max(1, Math.ceil(Number(count) / limit)),
    });
  } catch (e) {
    console.error('[listExecutives]', e);
    res.status(500).json({ status: 'fail', message: e.message });
  }
};

/* ─── POST /lords/access/executives  create ─── */
exports.createExecutive = async (req, res) => {
  await ensureAccessSchema();
  await pg.query('BEGIN');
  try {
    const { username, password, permissions, transactionPassword } = req.body;

    if (!username || !password) {
      await pg.query('ROLLBACK');
      return res.status(400).json({ status: 'fail', message: 'Username and password required' });
    }
    if (password.length < 6) {
      await pg.query('ROLLBACK');
      return res.status(400).json({ status: 'fail', message: 'Password must be 6+ characters' });
    }
    if (!looksLikeStaffPermissions(permissions)) {
      await pg.query('ROLLBACK');
      return res.status(400).json({ status: 'fail', message: 'Invalid permissions payload' });
    }

    await validateTransactionPassword(req.staff.id, transactionPassword);

    const dupe = await pg.query('SELECT 1 FROM executives WHERE username=$1', [username]);
    if (dupe.rowCount) {
      await pg.query('ROLLBACK');
      return res.status(409).json({ status: 'fail', message: 'Username already taken' });
    }

    const hashed = await bcrypt.hash(password, 10);

    // Snapshot parent role name
    const { rows: [parent] } = await pg.query(
      `SELECT r.name AS role FROM staff s LEFT JOIN roles r ON r.id = s.role_id WHERE s.id = $1`,
      [req.staff.id]
    );

    const { rows: [created] } = await pg.query(
      `INSERT INTO executives
         (username, password, parent_staff_id, parent_role_snapshot, permissions, status, kind)
       VALUES ($1, $2, $3, $4, $5::jsonb, 'active', 'executive')
       RETURNING *`,
      [username, hashed, req.staff.id, parent?.role || null, JSON.stringify(permissions)]
    );

    await pg.query('COMMIT');
    res.status(201).json({ status: 'success', executive: normaliseExecRow(created) });
  } catch (e) {
    await pg.query('ROLLBACK');
    console.error('[createExecutive]', e);
    res.status(500).json({ status: 'fail', message: e.message });
  }
};

/* ─── PATCH /lords/access/executives/:id  update permissions ─── */
exports.updateExecutive = async (req, res) => {
  try {
    const { id } = req.params;
    const { permissions, transactionPassword } = req.body;

    if (!looksLikeStaffPermissions(permissions))
      return res.status(400).json({ status: 'fail', message: 'Invalid permissions payload' });

    await validateTransactionPassword(req.staff.id, transactionPassword);

    const { rows: [exec] } = await pg.query(
      'SELECT id, parent_staff_id FROM executives WHERE id=$1', [id]
    );
    if (!exec) return res.status(404).json({ status: 'fail', message: 'Executive not found' });
    if (exec.parent_staff_id !== req.staff.id)
      return res.status(403).json({ status: 'fail', message: 'Not your executive' });

    const { rows: [updated] } = await pg.query(
      `UPDATE executives SET permissions = $1::jsonb WHERE id = $2 RETURNING *`,
      [JSON.stringify(permissions), id]
    );

    res.json({ status: 'success', executive: normaliseExecRow(updated) });
  } catch (e) {
    console.error('[updateExecutive]', e);
    res.status(500).json({ status: 'fail', message: e.message });
  }
};

/* ─── PATCH /lords/access/executives/:id/password  reset ─── */
exports.resetExecutivePassword = async (req, res) => {
  try {
    const { id } = req.params;
    const { newPassword, transactionPassword } = req.body;

    if (!newPassword || newPassword.length < 6)
      return res.status(400).json({ status: 'fail', message: 'New password must be 6+ characters' });

    await validateTransactionPassword(req.staff.id, transactionPassword);

    const { rows: [exec] } = await pg.query(
      'SELECT id, parent_staff_id FROM executives WHERE id=$1', [id]
    );
    if (!exec) return res.status(404).json({ status: 'fail', message: 'Executive not found' });
    if (exec.parent_staff_id !== req.staff.id)
      return res.status(403).json({ status: 'fail', message: 'Not your executive' });

    const hashed = await bcrypt.hash(newPassword, 10);
    await pg.query('UPDATE executives SET password=$1 WHERE id=$2', [hashed, id]);

    res.json({ status: 'success', message: 'Password reset' });
  } catch (e) {
    console.error('[resetExecutivePassword]', e);
    res.status(500).json({ status: 'fail', message: e.message });
  }
};

/* ─── PATCH /lords/access/executives/:id/lock  lock or unlock ─── */
exports.lockExecutive = async (req, res) => {
  try {
    const { id } = req.params;
    const { lock, transactionPassword } = req.body;

    await validateTransactionPassword(req.staff.id, transactionPassword);

    const { rows: [exec] } = await pg.query(
      'SELECT id, parent_staff_id FROM executives WHERE id=$1', [id]
    );
    if (!exec) return res.status(404).json({ status: 'fail', message: 'Executive not found' });
    if (exec.parent_staff_id !== req.staff.id)
      return res.status(403).json({ status: 'fail', message: 'Not your executive' });

    const newStatus = lock ? 'locked' : 'active';
    await pg.query('UPDATE executives SET status=$1 WHERE id=$2', [newStatus, id]);

    res.json({ status: 'success', message: lock ? 'Locked' : 'Unlocked', status_value: newStatus });
  } catch (e) {
    console.error('[lockExecutive]', e);
    res.status(500).json({ status: 'fail', message: e.message });
  }
};

/* ─── GET /lords/access/executives/:id/activity ─── */
// Resolve a human-readable name for each row's target (USER / STAFF /
// EXECUTIVE) in a few batched queries, and attach it as r.target_name.
// Lets the UI render "… to user Test 222" instead of a bare id.
async function attachTargetNames(rows) {
  const byType = { USER: new Set(), STAFF: new Set(), EXECUTIVE: new Set() };
  for (const r of rows) {
    if (r.target_id && byType[r.target_type]) byType[r.target_type].add(String(r.target_id));
  }
  const maps = { USER: {}, STAFF: {}, EXECUTIVE: {} };

  const fill = async (type, sql) => {
    const ids = [...byType[type]];
    if (!ids.length) return;
    try {
      const { rows: got } = await pg.query(sql, [ids]);
      for (const g of got) maps[type][String(g.id)] = g.name;
    } catch (e) { /* missing table/column — leave names unresolved */ }
  };

  await Promise.all([
    fill('USER',      `SELECT id::text AS id, name FROM users      WHERE id::text = ANY($1)`),
    fill('STAFF',     `SELECT id::text AS id, name FROM staff      WHERE id::text = ANY($1)`),
    fill('EXECUTIVE', `SELECT id::text AS id, username AS name FROM executives WHERE id::text = ANY($1)`),
  ]);

  for (const r of rows) {
    r.target_name = (r.target_id && maps[r.target_type]) ? (maps[r.target_type][String(r.target_id)] || null) : null;
  }
  return rows;
}

// Shared mapper for an admin_activity_logs row → API entry shape.
const mapActivityRow = (r) => ({
  id: r.id,
  staffId: r.staff_id,
  executiveId: r.executive_id,
  actorName: r.actor_name,
  actorRole: r.actor_role,
  actorLevel: r.actor_level,
  action: r.action,
  targetType: r.target_type,
  targetId: r.target_id,
  targetName: r.target_name || null,
  details: typeof r.details === 'string' ? safeParse(r.details) : r.details,
  ip: r.ip,
  country: r.country,
  region: r.region,
  city: r.city,
  location: [r.city, r.region, r.country].filter(Boolean).join(', ') || null,
  userAgent: r.user_agent,
  status: r.status,
  errorMessage: r.error_message,
  createdAt: r.created_at,
});

exports.getExecutiveActivity = async (req, res) => {
  try {
    await ensureAccessSchema();
    const { id } = req.params;
    const page  = Math.max(1, +(req.query.page  || 1));
    const limit = Math.min(200, +(req.query.limit || 50));
    const offset = (page - 1) * limit;

    const { rows: [exec] } = await pg.query(
      'SELECT id, parent_staff_id FROM executives WHERE id=$1', [id]
    );
    if (!exec) return res.status(404).json({ status: 'fail', message: 'Executive not found' });
    if (exec.parent_staff_id !== req.staff.id && req.staff.level !== 0)
      return res.status(403).json({ status: 'fail', message: 'Not your executive' });

    const filters = ['executive_id = $1'];
    const params  = [id];
    if (req.query.from) { params.push(new Date(req.query.from)); filters.push(`created_at >= $${params.length}`); }
    if (req.query.to)   { params.push(new Date(req.query.to));   filters.push(`created_at <= $${params.length}`); }
    const whereSql = `WHERE ${filters.join(' AND ')}`;

    const { rows: [{ count }] } = await pg.query(
      `SELECT COUNT(*) FROM admin_activity_logs ${whereSql}`, params
    );

    params.push(limit, offset);
    const { rows } = await pg.query(
      `SELECT * FROM admin_activity_logs
         ${whereSql}
         ORDER BY created_at DESC
         LIMIT $${params.length - 1} OFFSET $${params.length}`,
      params
    );

    await attachTargetNames(rows);
    res.json({
      status: 'success',
      entries: rows.map(mapActivityRow),
      total: Number(count),
      page,
      limit,
      totalPages: Math.max(1, Math.ceil(Number(count) / limit)),
    });
  } catch (e) {
    console.error('[getExecutiveActivity]', e);
    res.status(500).json({ status: 'fail', message: e.message });
  }
};

/* ─── GET /lords/access/activity ─────────────────────────────────
   Hierarchy-scoped global activity log.
   - SuperAdmin (level 0): sees ALL activity.
   - Everyone else: sees their own actions + their entire downline's,
     resolved via the staff_hierarchy closure table.
   Filters: action, status, targetType, staffId, q (actor/target search),
            from, to. Paginated. */
exports.getActivity = async (req, res) => {
  try {
    await ensureAccessSchema();
    const page  = Math.max(1, +(req.query.page  || 1));
    const limit = Math.min(200, +(req.query.limit || 50));
    const offset = (page - 1) * limit;

    const isSuper = req.staff.level === 0;
    const filters = [];
    const params  = [];

    if (!isSuper) {
      // Restrict to self + descendants.
      const { rows } = await pg.query(
        'SELECT descendant_id FROM staff_hierarchy WHERE ancestor_id = $1',
        [req.staff.id]
      );
      const ids = rows.map(r => r.descendant_id);
      if (!ids.includes(req.staff.id)) ids.push(req.staff.id);
      params.push(ids);
      filters.push(`staff_id = ANY($${params.length})`);
    }

    if (req.query.action)     { params.push(req.query.action);     filters.push(`action = $${params.length}`); }
    if (req.query.status)     { params.push(req.query.status);     filters.push(`status = $${params.length}`); }
    if (req.query.targetType) { params.push(req.query.targetType); filters.push(`target_type = $${params.length}`); }
    if (req.query.staffId)    { params.push(+req.query.staffId);   filters.push(`staff_id = $${params.length}`); }
    if (req.query.from) { params.push(new Date(req.query.from)); filters.push(`created_at >= $${params.length}`); }
    if (req.query.to)   { params.push(new Date(req.query.to));   filters.push(`created_at <= $${params.length}`); }
    if (req.query.q) {
      params.push(`%${req.query.q}%`);
      const p = `$${params.length}`;
      filters.push(`(actor_name ILIKE ${p} OR target_id ILIKE ${p} OR ip ILIKE ${p})`);
    }

    const whereSql = filters.length ? `WHERE ${filters.join(' AND ')}` : '';

    const { rows: [{ count }] } = await pg.query(
      `SELECT COUNT(*) FROM admin_activity_logs ${whereSql}`, params
    );

    params.push(limit, offset);
    const { rows } = await pg.query(
      `SELECT * FROM admin_activity_logs
         ${whereSql}
         ORDER BY created_at DESC
         LIMIT $${params.length - 1} OFFSET $${params.length}`,
      params
    );

    await attachTargetNames(rows);
    res.json({
      status: 'success',
      scope: { isSuperAdmin: isSuper, staffId: req.staff.id },
      entries: rows.map(mapActivityRow),
      total: Number(count),
      page,
      limit,
      totalPages: Math.max(1, Math.ceil(Number(count) / limit)),
    });
  } catch (e) {
    console.error('[getActivity]', e);
    res.status(500).json({ status: 'fail', message: e.message });
  }
};

/* ─── GET /lords/access/me/permissions ─── */
exports.getMyPermissions = async (req, res) => {
  try {
    // If the JWT was issued for an executive, protectStaff will need to set
    // req.staff.executive_id (see auth shim below).  Until then, staff get
    // permissions: null and the frontend short-circuits via SUPER_ROLES.
    if (req.staff.executive_id) {
      const { rows: [exec] } = await pg.query(
        `SELECT e.id, e.username, e.permissions, e.status, e.parent_staff_id,
                e.last_login, e.last_login_ip, e.created_at,
                s.name AS parent_username, r.name AS parent_role
           FROM executives e
           LEFT JOIN staff s ON s.id = e.parent_staff_id
           LEFT JOIN roles r ON r.id = s.role_id
           WHERE e.id = $1`,
        [req.staff.executive_id]
      );
      if (!exec)        return res.status(404).json({ status: 'fail', message: 'Executive not found' });
      if (exec.status !== 'active')
        return res.status(403).json({ status: 'fail', message: 'Account is not active' });
      return res.json({
        status: 'success',
        role: 'Executive',
        permissions: typeof exec.permissions === 'string' ? safeParse(exec.permissions) : exec.permissions,
        profile: {
          id: exec.id,
          username: exec.username,
          status: exec.status,
          parentUsername: exec.parent_username,
          parentRole: exec.parent_role,
          lastLogin: exec.last_login,
          lastLoginIp: exec.last_login_ip,
          createdAt: exec.created_at,
        },
      });
    }

    res.json({ status: 'success', role: req.staff?.role || 'Staff', permissions: null });
  } catch (e) {
    console.error('[getMyPermissions]', e);
    res.status(500).json({ status: 'fail', message: e.message });
  }
};

/* ═══════════════════════════════════════════════════════════════
   Marketing accounts
   ───────────────────────────────────────────────────────────────
   Stored in `executives` with kind = 'marketing'. They reuse the executive
   login endpoint and password handling, but carry no page/authority
   permissions: their access is defined entirely by protectMarketing, which
   serves a fixed read-only analytics surface. The permissions column is NOT
   NULL, so we write an empty blob to satisfy the schema and to make it
   obvious that nothing is being granted here.

   Creation is restricted to SuperAdmin (level 0): these accounts see
   platform-wide revenue, so a mid-hierarchy agent must not be able to mint one
   that reads above their own position in the tree.
   ═══════════════════════════════════════════════════════════════ */

const EMPTY_PERMISSIONS = { groups: {}, pages: {}, authority: {} };

const requireSuperAdmin = (req) => {
  if (Number(req.staff?.level) !== 0)
    throw Object.assign(new Error('Only SuperAdmin can manage marketing accounts'), { httpStatus: 403 });
};

const normaliseMarketingRow = (r) => ({
  id: r.id,
  username: r.username,
  status: r.status,
  createdAt: r.created_at,
  lastLogin: r.last_login,
  lastLoginIp: r.last_login_ip,
});

/* ─── GET /lords/access/marketing-users ─── */
exports.listMarketingUsers = async (req, res) => {
  try {
    await ensureAccessSchema();
    requireSuperAdmin(req);

    const page   = Math.max(1, +(req.query.page || 1));
    const limit  = Math.min(100, +(req.query.limit || 25));
    const offset = (page - 1) * limit;
    const search = (req.query.search || '').trim();

    const filters = ["kind = 'marketing'"];
    const params  = [];
    if (search) {
      params.push(`%${search.toLowerCase()}%`);
      filters.push(`lower(username) LIKE $${params.length}`);
    }
    const whereSql = `WHERE ${filters.join(' AND ')}`;

    const { rows: [{ count }] } = await pg.query(
      `SELECT COUNT(*) FROM executives ${whereSql}`, params
    );

    params.push(limit, offset);
    const { rows } = await pg.query(
      `SELECT * FROM executives ${whereSql}
        ORDER BY created_at DESC
        LIMIT $${params.length - 1} OFFSET $${params.length}`,
      params
    );

    res.json({
      status: 'success',
      users: rows.map(normaliseMarketingRow),
      total: Number(count),
      page,
      limit,
      totalPages: Math.max(1, Math.ceil(Number(count) / limit)),
    });
  } catch (e) {
    console.error('[listMarketingUsers]', e);
    res.status(e.httpStatus || 500).json({ status: 'fail', message: e.message });
  }
};

/* ─── POST /lords/access/marketing-users ─── */
exports.createMarketingUser = async (req, res) => {
  await ensureAccessSchema();
  await pg.query('BEGIN');
  try {
    requireSuperAdmin(req);
    const { username, password, transactionPassword } = req.body;

    if (!username || !password) {
      await pg.query('ROLLBACK');
      return res.status(400).json({ status: 'fail', message: 'Username and password required' });
    }
    if (password.length < 6) {
      await pg.query('ROLLBACK');
      return res.status(400).json({ status: 'fail', message: 'Password must be 6+ characters' });
    }

    await validateTransactionPassword(req.staff.id, transactionPassword);

    // UNIQUE is on username across the whole table, so check both kinds.
    const dupe = await pg.query('SELECT 1 FROM executives WHERE username=$1', [username]);
    if (dupe.rowCount) {
      await pg.query('ROLLBACK');
      return res.status(409).json({ status: 'fail', message: 'Username already taken' });
    }

    const hashed = await bcrypt.hash(password, 10);
    const { rows: [created] } = await pg.query(
      `INSERT INTO executives
         (username, password, parent_staff_id, parent_role_snapshot, permissions, status, kind)
       VALUES ($1, $2, $3, 'SuperAdmin', $4::jsonb, 'active', 'marketing')
       RETURNING *`,
      [username, hashed, req.staff.id, JSON.stringify(EMPTY_PERMISSIONS)]
    );

    await pg.query('COMMIT');
    res.status(201).json({ status: 'success', user: normaliseMarketingRow(created) });
  } catch (e) {
    await pg.query('ROLLBACK');
    console.error('[createMarketingUser]', e);
    res.status(e.httpStatus || 500).json({ status: 'fail', message: e.message });
  }
};

/* ─── PATCH /lords/access/marketing-users/:id/password ─── */
exports.resetMarketingPassword = async (req, res) => {
  try {
    requireSuperAdmin(req);
    const { id } = req.params;
    const { newPassword, transactionPassword } = req.body;

    if (!newPassword || newPassword.length < 6)
      return res.status(400).json({ status: 'fail', message: 'New password must be 6+ characters' });

    await validateTransactionPassword(req.staff.id, transactionPassword);

    const { rows: [row] } = await pg.query(
      "SELECT id FROM executives WHERE id=$1 AND kind='marketing'", [id]
    );
    if (!row) return res.status(404).json({ status: 'fail', message: 'Marketing account not found' });

    const hashed = await bcrypt.hash(newPassword, 10);
    await pg.query('UPDATE executives SET password=$1, updated_at=NOW() WHERE id=$2', [hashed, id]);

    res.json({ status: 'success', message: 'Password reset' });
  } catch (e) {
    console.error('[resetMarketingPassword]', e);
    res.status(e.httpStatus || 500).json({ status: 'fail', message: e.message });
  }
};

/* ─── PATCH /lords/access/marketing-users/:id/lock ─── */
exports.lockMarketingUser = async (req, res) => {
  try {
    requireSuperAdmin(req);
    const { id } = req.params;
    const { lock, transactionPassword } = req.body;

    await validateTransactionPassword(req.staff.id, transactionPassword);

    const { rows: [row] } = await pg.query(
      "SELECT id FROM executives WHERE id=$1 AND kind='marketing'", [id]
    );
    if (!row) return res.status(404).json({ status: 'fail', message: 'Marketing account not found' });

    const status = lock ? 'locked' : 'active';
    const { rows: [updated] } = await pg.query(
      'UPDATE executives SET status=$1, updated_at=NOW() WHERE id=$2 RETURNING *',
      [status, id]
    );

    res.json({ status: 'success', user: normaliseMarketingRow(updated) });
  } catch (e) {
    console.error('[lockMarketingUser]', e);
    res.status(e.httpStatus || 500).json({ status: 'fail', message: e.message });
  }
};
