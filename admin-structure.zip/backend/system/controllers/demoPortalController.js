// controllers/demoPortalController.js
// Demo Portal: the owner creates Demo Portal Agents (staff role 'DemoAgent'),
// funds them through the regular /lords/funds/transfer, and each agent logs in
// to mint demo player accounts paid out of its own balance. See
// system/utils/demoUsers.js for what "demo" means everywhere else.
const pg = require('../../General/Model');
const { withTransaction } = require('../../General/Model/pool');
const bcrypt = require('bcrypt');
const _ = require('lodash');
const config = require('../../config');
const { validateTransactionPassword } = require('./lordsController');
const { DEMO_ROLE, ensureDemoSchema, getDemoRoleId, isDemoAgent } = require('../utils/demoUsers');

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}
const fail = (status, message) => { throw new HttpError(status, message); };

const handle = (fn) => async (req, res, next) => {
  try {
    await fn(req, res);
  } catch (err) {
    if (err instanceof HttpError)
      return res.status(err.status).json({ status: 'fail', message: err.message });
    if (err.message === 'Invalid transaction password' || err.message === 'Transaction password is required')
      return res.status(403).json({ status: 'fail', message: err.message });
    next(err);
  }
};

const toAmount = (v, label, { allowZero = true } = {}) => {
  if (v === undefined || v === null || v === '') return 0;
  const n = Number(v);
  if (!Number.isFinite(n) || n < 0 || (!allowZero && n === 0)) fail(400, `${label} must be a positive number`);
  return Math.round(n * 100) / 100;
};

const USERNAME_RE = /^[a-z0-9_]{4,20}$/;

// ─── guards ───────────────────────────────────────────────────────────────────

exports.requireOwner = (req, res, next) => {
  if (req.staff?.level === 0 && !req.staff.executive_id) return next();
  res.status(403).json({ status: 'fail', message: 'Only the super admin can manage demo portal agents' });
};

exports.requireDemoAgent = async (req, res, next) => {
  try {
    if (!req.staff.executive_id && await isDemoAgent(req.staff)) return next();
    res.status(403).json({ status: 'fail', message: 'Demo portal agents only' });
  } catch (e) { next(e); }
};

// ─── owner: demo portal agents ──────────────────────────────────────────────

const AGENT_SELECT = `
  SELECT s.id, s.name, s.email, COALESCE(s.system_locked,false) AS locked,
         s.first_login, s.created_at,
         COALESCE(b.inr,0) AS balance,
         COALESCE(u.users,0) AS demo_users,
         COALESCE(u.user_balance,0) AS demo_users_balance
    FROM staff s
    LEFT JOIN staff_balances b ON b.staff_id = s.id
    LEFT JOIN LATERAL (
      SELECT COUNT(*) AS users, SUM(COALESCE(c.inr,0)) AS user_balance
        FROM users du LEFT JOIN credits c ON c.uid = du.id
       WHERE du.parent_staff_id = s.id AND du.is_demo
    ) u ON true
   WHERE s.role_id = $1`;

// GET /api/demo-portal/agents?search=
exports.listAgents = handle(async (req, res) => {
  const roleId = await getDemoRoleId();
  const search = String(req.query.search || '').trim();
  const { rows } = await pg.query(
    `${AGENT_SELECT}
       AND ($2 = '' OR s.name ILIKE '%' || $2 || '%' OR s.email ILIKE '%' || $2 || '%')
     ORDER BY s.id DESC`,
    [roleId, search]
  );
  res.json({ status: 'success', agents: rows });
});

// POST /api/demo-portal/agents  { name, email, password, transactionPassword }
exports.createAgent = handle(async (req, res) => {
  const name = String(req.body.name || '').trim();
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  if (!name) fail(400, 'Name is required');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) fail(400, 'A valid login email is required');
  if (password.length < 6) fail(400, 'Password must be at least 6 characters');
  await validateTransactionPassword(req.staff.id, req.body.transactionPassword);

  const roleId = await getDemoRoleId();
  const hash = await bcrypt.hash(password, 10);

  const agentId = await withTransaction(async (db) => {
    const dupe = await db.query('SELECT 1 FROM staff WHERE lower(email) = $1', [email]);
    if (dupe.rowCount) fail(400, 'A staff account with this email already exists');

    // agent_code stays NULL-free (unique column) but is never handed out:
    // Rule.createUser refuses to attach self-registered players to a DemoAgent.
    const code = `DM${_.sampleSize('ABCDEFGHJKLMNPQRSTUVWXYZ23456789', 8).join('')}`;
    const { rows: [s] } = await db.query(
      `INSERT INTO staff (name, email, password, password2, role_id, parent_id, percentage, first_login, agent_code)
       VALUES ($1,$2,$3,$4,$5,$6,0,true,$7) RETURNING id`,
      [name, email, hash, password, roleId, req.staff.id, code]
    );
    await db.query('INSERT INTO staff_balances (staff_id, inr) VALUES ($1, 0)', [s.id]);
    await db.query(
      `INSERT INTO staff_hierarchy (ancestor_id, descendant_id, depth) VALUES ($1,$1,0) ON CONFLICT DO NOTHING`,
      [s.id]
    );
    await db.query(
      `INSERT INTO staff_hierarchy (ancestor_id, descendant_id, depth)
         SELECT ancestor_id, $1, depth + 1 FROM staff_hierarchy WHERE descendant_id = $2
       ON CONFLICT DO NOTHING`,
      [s.id, req.staff.id]
    );
    return s.id;
  });

  res.status(201).json({ status: 'success', agentId, message: 'Demo portal agent created' });
});

const assertDemoAgentRow = async (id) => {
  const roleId = await getDemoRoleId();
  const { rowCount } = await pg.query('SELECT 1 FROM staff WHERE id = $1 AND role_id = $2', [id, roleId]);
  if (!rowCount) fail(404, 'Demo portal agent not found');
};

// PATCH /api/demo-portal/agents/:id/lock  { locked, transactionPassword }
exports.setAgentLock = handle(async (req, res) => {
  await validateTransactionPassword(req.staff.id, req.body.transactionPassword);
  await assertDemoAgentRow(req.params.id);
  const locked = !!req.body.locked;
  await pg.query('UPDATE staff SET system_locked = $1 WHERE id = $2', [locked, req.params.id]);
  res.json({ status: 'success', locked });
});

// PATCH /api/demo-portal/agents/:id/password  { password, transactionPassword }
exports.resetAgentPassword = handle(async (req, res) => {
  const password = String(req.body.password || '');
  if (password.length < 6) fail(400, 'Password must be at least 6 characters');
  await validateTransactionPassword(req.staff.id, req.body.transactionPassword);
  await assertDemoAgentRow(req.params.id);
  const hash = await bcrypt.hash(password, 10);
  await pg.query('UPDATE staff SET password = $1, password2 = $2 WHERE id = $3', [hash, password, req.params.id]);
  res.json({ status: 'success', message: 'Password updated' });
});

// ─── demo users (shared by owner view and agent view) ────────────────────────

const listDemoUsers = async (agentId, { search = '', page = 1, limit = 25 }) => {
  const lim = Math.min(Math.max(Number(limit) || 25, 1), 100);
  const off = (Math.max(Number(page) || 1, 1) - 1) * lim;
  const s = String(search || '').trim();
  const where = `u.is_demo AND u.parent_staff_id = $1
                 AND ($2 = '' OR u.name ILIKE '%' || $2 || '%' OR u.id::text LIKE $2 || '%')`;
  const [{ rows }, { rows: [{ total }] }] = await Promise.all([
    pg.query(
      `SELECT u.id::text AS id, u.name AS username, u.password2 AS password,
              COALESCE(c.inr,0) AS balance, u.demo_bet_limit AS casino_limit,
              COALESCE(u.system_locked,false) AS locked,
              u.created, u.last_login_at,
              COALESCE((SELECT SUM(CASE WHEN g.action='bet' THEN -g.amount ELSE g.amount END)
                          FROM gis_transactions g WHERE g.user_id = u.id), 0) AS casino_pnl
         FROM users u LEFT JOIN credits c ON c.uid = u.id
        WHERE ${where}
        ORDER BY u.created DESC NULLS LAST, u.id DESC
        LIMIT ${lim} OFFSET ${off}`,
      [agentId, s]
    ),
    pg.query(`SELECT COUNT(*)::int AS total FROM users u WHERE ${where}`, [agentId, s]),
  ]);
  return { users: rows, total, totalPages: Math.max(Math.ceil(total / lim), 1) };
};

// GET /api/demo-portal/agents/:id/users   (owner)
exports.listAgentUsers = handle(async (req, res) => {
  await assertDemoAgentRow(req.params.id);
  res.json({ status: 'success', ...(await listDemoUsers(req.params.id, req.query)) });
});

// ─── demo agent: own account ────────────────────────────────────────────────

// GET /api/demo-portal/me
exports.me = handle(async (req, res) => {
  await ensureDemoSchema();
  const { rows: [me] } = await pg.query(
    `${AGENT_SELECT} AND s.id = $2`,
    [await getDemoRoleId(), req.staff.id]
  );
  res.json({ status: 'success', agent: me });
});

// GET /api/demo-portal/users?search&page&limit
exports.listMyUsers = handle(async (req, res) => {
  res.json({ status: 'success', ...(await listDemoUsers(req.staff.id, req.query)) });
});

async function generateUserId(db) {
  for (;;) {
    const id = _.random(1_000_000_000, 9_999_999_999);
    if (!(await db.query('SELECT 1 FROM users WHERE id = $1', [id])).rowCount) return id;
  }
}

async function generateUsername(db) {
  for (;;) {
    const name = `demo${_.random(100000, 999999)}`;
    if (!(await db.query('SELECT 1 FROM users WHERE lower(name) = $1', [name])).rowCount) return name;
  }
}

// POST /api/demo-portal/users  { username?, password?, fund, casinoLimit }
// Creates the demo player and moves `fund` from the agent's balance to it.
exports.createDemoUser = handle(async (req, res) => {
  await ensureDemoSchema();
  let username = String(req.body.username || '').trim().toLowerCase();
  if (username && !USERNAME_RE.test(username))
    fail(400, 'Username must be 4-20 characters: letters, numbers or _');
  const password = String(req.body.password || '') || String(_.random(100000, 999999));
  if (password.length < 6) fail(400, 'Password must be at least 6 characters');
  const fund = toAmount(req.body.fund, 'Fund');
  const casinoLimit = toAmount(req.body.casinoLimit, 'Live casino limit');
  const hash = await bcrypt.hash(password, 10);

  const created = await withTransaction(async (db) => {
    if (username) {
      const dupe = await db.query('SELECT 1 FROM users WHERE lower(name) = $1', [username]);
      if (dupe.rowCount) fail(400, 'Username already taken');
    } else {
      username = await generateUsername(db);
    }

    if (fund > 0) {
      const { rows: [bal] } = await db.query(
        'SELECT inr FROM staff_balances WHERE staff_id = $1 FOR UPDATE', [req.staff.id]
      );
      const available = Number(bal?.inr || 0);
      if (fund > available) fail(400, `Insufficient balance (available ${available})`);
      await db.query('UPDATE staff_balances SET inr = inr - $1 WHERE staff_id = $2', [fund, req.staff.id]);
    }

    const id = await generateUserId(db);
    await db.query(
      `INSERT INTO users
         (id, name, password, password2, parent_staff_id, friends, wallet,
          profit_low, profit_high, profit, referalcode, created, is_demo, demo_bet_limit)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$8,$8,$9,NOW(),true,$10)`,
      [
        id, username, hash, password, req.staff.id, 'Support,',
        JSON.stringify(config.WALLET), JSON.stringify(config.BALANCE),
        `DMO${_.sampleSize('ABCDEFGHJKLMNPQRSTUVWXYZ23456789', 7).join('')}`,
        casinoLimit || null,
      ]
    );
    await db.query('INSERT INTO credits (uid, inr) VALUES ($1, $2)', [id, fund]);
    if (fund > 0) {
      await db.query(
        `INSERT INTO staff_transfers (from_type, from_id, to_type, to_id, amount, direction, transfer_type, note)
         VALUES ('staff', $1, 'user', $2, $3, 'deposit', 'transfer', 'Demo account opening fund')`,
        [req.staff.id, id, fund]
      );
    }
    return { id: String(id), username, password, balance: fund, casino_limit: casinoLimit || null };
  });

  res.status(201).json({ status: 'success', user: created, message: 'Demo account created' });
});

const assertMyDemoUser = async (staffId, userId) => {
  const { rowCount } = await pg.query(
    'SELECT 1 FROM users WHERE id::text = $1 AND parent_staff_id = $2 AND is_demo', [String(userId), staffId]
  );
  if (!rowCount) fail(404, 'Demo account not found');
};

// PATCH /api/demo-portal/users/:id  { casinoLimit?, locked? }
exports.updateDemoUser = handle(async (req, res) => {
  await assertMyDemoUser(req.staff.id, req.params.id);
  if (req.body.casinoLimit !== undefined) {
    const limit = toAmount(req.body.casinoLimit, 'Live casino limit');
    await pg.query('UPDATE users SET demo_bet_limit = $1 WHERE id::text = $2', [limit || null, req.params.id]);
  }
  if (req.body.locked !== undefined) {
    await pg.query('UPDATE users SET system_locked = $1 WHERE id::text = $2', [!!req.body.locked, req.params.id]);
  }
  res.json({ status: 'success', message: 'Demo account updated' });
});

exports.DEMO_ROLE = DEMO_ROLE;
