// controllers/lordsController.js
// Lords endpoints: user settings, deposit/withdraw, net exposure, agent listing.
//
// Money model: one real INR wallet per account (staff_balances.inr for agents,
// credits.inr for players). It moves ONLY through deposit/withdraw of actual
// amounts — there are no credit limits and no G/T settlement. "G/T" now means a
// read-only LIFETIME profit/loss figure: users.gt (sports) and users.casino_gt
// (casino) are written by the settlement cron and the casino tx logger, and an
// agent's figure is always computed as the sum over its subtree (see rollupPnl).
// Those columns are player-perspective; everything this API returns is flipped
// to the viewing agent's perspective — see the SIGN CONVENTION note below.
const pg = require('../../General/Model');
const bcrypt = require('bcrypt');
const emailService = require('../../emailservice/controller');

// ─── helpers ──────────────────────────────────────────────────────────────────

const isOwner = (staff) => staff.level === 0;

/** verify that `target` sits somewhere below `ancestor` in closure table */
const assertDescendant = async (ancestorId, targetId) => {
  const ok = (
    await pg.query(
      'SELECT 1 FROM staff_hierarchy WHERE ancestor_id=$1 AND descendant_id=$2',
      [ancestorId, targetId]
    )
  ).rows.length;
  if (!ok) throw new Error('Target is not in your hierarchy');
};

/** Validate the transaction password for the logged-in staff member */
const validateTransactionPassword = async (staffId, transactionPassword) => {
  if (!transactionPassword) throw new Error('Transaction password is required');
  const { rows } = await pg.query(
    'SELECT transaction_password FROM staff WHERE id=$1', [staffId]
  );
  if (!rows.length) throw new Error('Staff not found');
  // transaction_password is stored in plaintext (same as password2)
  if (rows[0].transaction_password !== transactionPassword) {
    throw new Error('Invalid transaction password');
  }
};
exports.validateTransactionPassword = validateTransactionPassword;

/** Resolve table/column depending on user type */
const resolveTarget = (userType) => {
  if (userType === 'STAFF') {
    return { balTable: 'staff_balances', balCol: 'staff_id' };
  }
  return { balTable: 'credits', balCol: 'uid' };
};

const isStaffType = (t) => String(t || '').toUpperCase() === 'STAFF';

/**
 * Assert `targetId` is an IMMEDIATE child of `staffId` — not merely a descendant.
 *
 * Money moves one level at a time. If a SuperAdmin could deposit straight into a
 * grandchild, the amount would leave the SuperAdmin's balance and land in the
 * grandchild's while every agent in between never saw it — their own books would
 * understate what passed through them, and the account statements built from
 * `staff_transfers` would show a gap nobody can explain. Each level settles with
 * the level directly under it, so each ledger stays complete.
 */
const assertDirectChild = async (staffId, targetId, targetIsStaff) => {
  const { rowCount } = targetIsStaff
    ? await pg.query('SELECT 1 FROM staff WHERE id = $1 AND parent_id = $2', [targetId, staffId])
    : await pg.query('SELECT 1 FROM users WHERE id = $1 AND parent_staff_id = $2', [targetId, staffId]);
  // `fail` is declared further down; this only runs per-request, long after the
  // module has finished evaluating.
  if (!rowCount) {
    fail(403, 'You can only deposit to or withdraw from accounts directly under you. '
      + 'Ask their own parent to move these funds.');
  }
};

/** Assert `userId` is a player somewhere below `staffId`. Throws on failure. */
const assertPlayerInTree = async (staffId, userId) => {
  const ok = (await pg.query(
    `SELECT 1 FROM users u
       JOIN staff_hierarchy h ON h.descendant_id = u.parent_staff_id
      WHERE h.ancestor_id = $1 AND u.id = $2`,
    [staffId, userId]
  )).rowCount;
  if (!ok) throw new Error('User not in your hierarchy');
};

/** Read a live INR balance with a row lock (0 when the row does not exist yet). */
const lockedBalance = async (userType, id) => {
  const { balTable, balCol } = resolveTarget(userType);
  const { rows } = await pg.query(
    `SELECT inr FROM ${balTable} WHERE ${balCol} = $1 FOR UPDATE`, [id]
  );
  return Number(rows[0]?.inr || 0);
};

/** Add (or subtract, with a negative delta) INR, creating the row if absent. */
const addBalance = async (userType, id, delta) => {
  const { balTable, balCol } = resolveTarget(userType);
  await pg.query(
    `INSERT INTO ${balTable} (${balCol}, inr) VALUES ($1, $2)
     ON CONFLICT (${balCol}) DO UPDATE SET inr = ${balTable}.inr + EXCLUDED.inr`,
    [id, delta]
  );
};

/** Write a staff_transfers audit row, tolerating a missing `note` column. */
const logTransfer = async ({ fromType, fromId, toType, toId, amount, direction, note }) => {
  try {
    await pg.query(
      `INSERT INTO staff_transfers (from_type, from_id, to_type, to_id, amount, direction, transfer_type, note)
       VALUES ($1,$2,$3,$4,$5,$6,'transfer',$7)`,
      [fromType, fromId, toType, toId, amount, direction, note || null]
    );
  } catch (e) {
    if (e.code !== '42703') throw e;   // undefined_column -> pre-migration schema
    await pg.query(
      `INSERT INTO staff_transfers (from_type, from_id, to_type, to_id, amount, direction, transfer_type)
       VALUES ($1,$2,$3,$4,$5,$6,'transfer')`,
      [fromType, fromId, toType, toId, amount, direction]
    );
  }
};

/**
 * Reject a request with a specific HTTP status.
 *
 * These handlers run BEGIN on a process-wide pg Client, so an early `return`
 * out of a validation branch would leave that transaction open and every
 * subsequent query on the connection would run inside it. Throwing instead
 * routes all failures through the one catch block that issues the ROLLBACK.
 */
class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}
const fail = (status, message) => { throw new HttpError(status, message); };

/* ── SIGN CONVENTION — read this before touching any P&L number ──────────────
 *
 * The stored columns are from the PLAYER's point of view, because they are
 * accumulated straight from the bet ledgers:
 *     users.gt        > 0  ->  the player is up on sports
 *     users.casino_gt > 0  ->  the player is up on casino
 *
 * The admin panel shows the opposite: an agent looking at its downline wants
 * ITS OWN profit and loss, and a player winning is money the house paid out.
 * So every P&L figure leaving this API is NEGATED:
 *     sports_pnl / casino_pnl  > 0  ->  the viewing agent EARNED that much
 *                              < 0  ->  the viewing agent PAID OUT that much
 *
 * That is why these fields are named `sports_pnl` / `casino_pnl` and NOT `gt` /
 * `casino_gt`: a response key that matched a column name while carrying the
 * opposite sign would be a trap for the next person to read it.
 * ────────────────────────────────────────────────────────────────────────── */
const housePnl = (playerPnl) => -Number(playerPnl || 0);

/**
 * Lifetime P&L the staff member has made from every player in its subtree,
 * in the house-perspective sign described above.
 *
 * Agents have no stored P&L column — theirs is always this roll-up, so it can
 * never drift out of sync with the players underneath them. `staff_hierarchy`
 * is a closure table with a depth-0 self row, so this covers the staff member's
 * own direct players as well as the whole downline.
 */
const rollupPnl = async (staffId) => {
  const { rows: [r] } = await pg.query(
    `SELECT COALESCE(SUM(u.gt), 0)        AS gt,
            COALESCE(SUM(u.casino_gt), 0) AS casino_gt
       FROM users u
       JOIN staff_hierarchy h ON h.descendant_id = u.parent_staff_id
      WHERE h.ancestor_id = $1`,
    [staffId]
  );
  return { sports_pnl: housePnl(r?.gt), casino_pnl: housePnl(r?.casino_gt) };
};
exports.rollupPnl = rollupPnl;

// ─── USER SETTINGS ────────────────────────────────────────────────────────────

/**
 * POST /lords/user-setting/update-password
 * Body: { userId, userType, newPassword, transactionPassword }
 */
exports.updatePassword = async (req, res, next) => {
  try {
    const { userId, userType, newPassword, transactionPassword } = req.body;
    if (!userId || !userType || !newPassword)
      return res.status(400).json({ status: 'fail', message: 'Missing required fields' });

    await validateTransactionPassword(req.staff.id, transactionPassword);

    // Verify hierarchy
    if (userType === 'STAFF') {
      await assertDescendant(req.staff.id, userId);
    } else {
      const ok = (await pg.query(
        `SELECT 1 FROM users u
         JOIN staff_hierarchy h ON h.descendant_id = u.parent_staff_id
         WHERE h.ancestor_id = $1 AND u.id = $2`,
        [req.staff.id, userId]
      )).rowCount;
      if (!ok) return res.status(403).json({ status: 'fail', message: 'User not in your hierarchy' });
    }

    const hash = await bcrypt.hash(newPassword, 10);

    if (userType === 'STAFF') {
      await pg.query('UPDATE staff SET password=$1, password2=$2 WHERE id=$3', [hash, newPassword, userId]);
    } else {
      await pg.query('UPDATE users SET password=$1, password2=$2 WHERE id=$3', [hash, newPassword, userId]);
    }

    res.json({ status: 'success', message: 'Password updated' });
  } catch (err) {
    if (err.message === 'Invalid transaction password')
      return res.status(403).json({ status: 'fail', message: err.message });
    next(err);
  }
};

/**
 * POST /lords/user-setting/status
 * Body: { userId, userType, status, betStatus, sportsLocked, casinoLocked, systemLocked, transactionPassword }
 */
exports.updateStatus = async (req, res, next) => {
  try {
    const { userId, userType, status, betStatus,
            sportsLocked, casinoLocked, systemLocked,
            transactionPassword } = req.body;
    if (!userId || !userType)
      return res.status(400).json({ status: 'fail', message: 'Missing required fields' });

    await validateTransactionPassword(req.staff.id, transactionPassword);

    // Verify hierarchy
    if (userType === 'STAFF') {
      await assertDescendant(req.staff.id, userId);
    } else {
      const ok = (await pg.query(
        `SELECT 1 FROM users u
         JOIN staff_hierarchy h ON h.descendant_id = u.parent_staff_id
         WHERE h.ancestor_id = $1 AND u.id = $2`,
        [req.staff.id, userId]
      )).rowCount;
      if (!ok) return res.status(403).json({ status: 'fail', message: 'User not in your hierarchy' });
    }

    const table = userType === 'STAFF' ? 'staff' : 'users';
    const sets = [];
    const vals = [];
    let idx = 1;

    if (status) {
      sets.push(`status = $${idx++}`);
      vals.push(status.toLowerCase());
    }
    if (betStatus) {
      sets.push(`bet_status = $${idx++}`);
      vals.push(betStatus.toLowerCase());
    }

    // 3 lock types
    if (sportsLocked !== undefined) {
      sets.push(`sports_betlocked = $${idx++}`);
      vals.push(!!sportsLocked);
    }
    if (casinoLocked !== undefined) {
      sets.push(`casino_locked = $${idx++}`);
      vals.push(!!casinoLocked);
    }
    if (systemLocked !== undefined) {
      sets.push(`system_locked = $${idx++}`);
      vals.push(!!systemLocked);
    }

    if (!sets.length)
      return res.status(400).json({ status: 'fail', message: 'Nothing to update' });

    vals.push(userId);
    await pg.query(`UPDATE ${table} SET ${sets.join(', ')} WHERE id = $${idx}`, vals);

    res.json({ status: 'success', message: 'Status updated' });
  } catch (err) {
    if (err.message === 'Invalid transaction password')
      return res.status(403).json({ status: 'fail', message: err.message });
    next(err);
  }
};

/**
 * POST /lords/funds/transfer      (Deposit / Withdraw — actual amounts)
 * Body: { userId, userType, amount, direction, note, transactionPassword }
 *
 *   direction 'deposit'  -> the caller pays; the target's wallet grows by `amount`
 *   direction 'withdraw' -> the target pays; the caller's wallet grows by `amount`
 *
 * There is no credit limit and no notion of "available credit": an account can
 * only ever send money it actually holds, and the amount moved is exactly the
 * amount requested. The one exception is the owner (level 0), which is the house
 * source of funds — its side of the movement is minted on deposit and burned on
 * withdrawal. Every movement, owner included, writes a staff_transfers row.
 */
exports.transferFunds = async (req, res, next) => {
  await pg.query('BEGIN');
  try {
    const { userId, userType, amount, note, transactionPassword } = req.body;
    const direction = String(req.body.direction || '').toLowerCase();

    if (!userId || !userType || amount == null)
      fail(400, 'Missing required fields');
    if (direction !== 'deposit' && direction !== 'withdraw')
      fail(400, "direction must be 'deposit' or 'withdraw'");

    await validateTransactionPassword(req.staff.id, transactionPassword);

    const amt = Number(amount);
    if (!Number.isFinite(amt) || amt <= 0)
      fail(400, 'Amount must be greater than zero');

    const targetIsStaff = isStaffType(userType);
    const targetType = targetIsStaff ? 'STAFF' : 'USER';

    // Hierarchy: one level only — the target must sit directly under you, so
    // every agent in the chain settles with the level below it and no ledger is
    // skipped. See assertDirectChild.
    await assertDirectChild(req.staff.id, userId, targetIsStaff);

    const owner = isOwner(req.staff);

    if (direction === 'deposit') {
      // Caller pays. Owner mints instead of being debited.
      if (!owner) {
        const callerBal = await lockedBalance('STAFF', req.staff.id);
        if (amt > callerBal) fail(400, `Insufficient balance (available ${callerBal})`);
        await addBalance('STAFF', req.staff.id, -amt);
      }
      await addBalance(targetType, userId, amt);
    } else {
      // Target pays — always a real balance check, owner or not.
      const targetBal = await lockedBalance(targetType, userId);
      if (amt > targetBal) fail(400, `Insufficient balance on the account (available ${targetBal})`);
      await addBalance(targetType, userId, -amt);
      if (!owner) await addBalance('STAFF', req.staff.id, amt);
    }

    const partyType = targetIsStaff ? 'staff' : 'user';
    await logTransfer({
      fromType:  direction === 'deposit' ? 'staff'      : partyType,
      fromId:    direction === 'deposit' ? req.staff.id : userId,
      toType:    direction === 'deposit' ? partyType    : 'staff',
      toId:      direction === 'deposit' ? userId       : req.staff.id,
      amount:    amt,
      direction,
      note,
    });

    const balance = await lockedBalance(targetType, userId);
    await pg.query('COMMIT');

    res.json({
      status: 'success',
      message: direction === 'deposit' ? 'Deposit completed' : 'Withdrawal completed',
      balance,
    });
  } catch (err) {
    await pg.query('ROLLBACK');
    if (err instanceof HttpError)
      return res.status(err.status).json({ status: 'fail', message: err.message });
    if (err.message === 'Invalid transaction password' ||
        err.message === 'Transaction password is required')
      return res.status(403).json({ status: 'fail', message: err.message });
    if (err.message === 'User not in your hierarchy' ||
        err.message === 'Target is not in your hierarchy')
      return res.status(403).json({ status: 'fail', message: err.message });
    next(err);
  }
};

/* Fire-and-forget admin email after a Staff-Portal wallet refill. Reads the
 * recipient from siteconfig.apaynotificationemail. Never throws. */
async function notifyRefill(staff, userId, amount, note) {
  try {
    const { rows } = await pg.query('SELECT apaynotificationemail FROM siteconfig LIMIT 1');
    const to = rows[0]?.apaynotificationemail;
    if (!to) return;
    const { rows: sRows } = await pg.query('SELECT name, agent_code FROM staff WHERE id=$1', [staff.id]);
    const { rows: uRows } = await pg.query('SELECT name, email FROM users WHERE id=$1', [userId]);
    const by = sRows[0]?.name ? `${sRows[0].name}${sRows[0].agent_code ? ` (${sRows[0].agent_code})` : ''}` : `Staff #${staff.id}`;
    const uName = uRows[0]?.name || String(userId);
    const cell = (k, v) => `<tr><td style="padding:6px 12px;border:1px solid #e2e8f0;background:#f8fafc;font-weight:600;">${k}</td><td style="padding:6px 12px;border:1px solid #e2e8f0;">${v}</td></tr>`;
    const content = `<table style="border-collapse:collapse;width:100%;font-size:14px;">${[
      cell('Amount', `₹${amount}`),
      cell('To user', `${uName} · UID ${userId}`),
      cell('User email', uRows[0]?.email || '—'),
      cell('Done by', by),
      cell('Reference', note || '—'),
      cell('Time', new Date().toISOString()),
    ].join('')}</table>`;
    await emailService.sendGeneralEmail(to, `Wallet refill — ₹${amount} to ${uName}`, {
      title: `Wallet refill — ₹${amount}`,
      content,
    });
  } catch (err) {
    console.error('notifyRefill failed:', err.message);
  }
}

/**
 * POST /lords/quick-refill   (Staff Portal — add INR to a user's wallet)
 * Body: { userId, amount, note, transactionPassword }
 * Adds `amount` (delta) to the user's INR balance, records the reference note
 * on the transfer, and emails the configured admin inbox.
 */
exports.quickRefill = async (req, res, next) => {
  await pg.query('BEGIN');
  try {
    const { userId, amount, note, transactionPassword } = req.body;
    if (!userId || amount == null) fail(400, 'Missing required fields');

    await validateTransactionPassword(req.staff.id, transactionPassword);

    const amt = Number(amount);
    if (!Number.isFinite(amt) || amt <= 0) fail(400, 'Invalid amount');

    // User must be in the caller's hierarchy (owner can refill anyone).
    if (!isOwner(req.staff)) {
      await assertPlayerInTree(req.staff.id, userId);

      // Non-owner funds the refill from their own balance — actual amount, no credit.
      const callerBal = await lockedBalance('STAFF', req.staff.id);
      if (amt > callerBal) fail(400, `Insufficient balance (available ${callerBal})`);
      await addBalance('STAFF', req.staff.id, -amt);
    } else {
      // Owner is the house source of funds — still verify the player exists.
      const exists = (await pg.query('SELECT 1 FROM users WHERE id=$1', [userId])).rowCount;
      if (!exists) fail(404, 'User not found');
    }

    await addBalance('USER', userId, amt);
    await logTransfer({
      fromType: 'staff', fromId: req.staff.id,
      toType: 'user',    toId: userId,
      amount: amt, direction: 'deposit', note,
    });

    const balance = await lockedBalance('USER', userId);
    await pg.query('COMMIT');

    notifyRefill(req.staff, userId, amt, note);   // fire-and-forget

    res.json({ status: 'success', message: 'Wallet refilled', balance });
  } catch (err) {
    await pg.query('ROLLBACK');
    if (err instanceof HttpError)
      return res.status(err.status).json({ status: 'fail', message: err.message });
    if (err.message === 'Invalid transaction password' || err.message === 'Transaction password is required')
      return res.status(403).json({ status: 'fail', message: err.message });
    if (err.message === 'User not in your hierarchy')
      return res.status(403).json({ status: 'fail', message: err.message });
    next(err);
  }
};

/**
 * POST /lords/user-setting/exposure-limit
 * Body: { userId, userType, exposureLimit, transactionPassword }
 */
exports.updateExposureLimit = async (req, res, next) => {
  try {
    const { userId, userType, exposureLimit, transactionPassword } = req.body;
    if (!userId || !userType)
      return res.status(400).json({ status: 'fail', message: 'Missing required fields' });

    await validateTransactionPassword(req.staff.id, transactionPassword);

    // null means unlimited
    const limit = exposureLimit === null || exposureLimit === '' ? null : Number(exposureLimit);
    if (limit !== null && (!Number.isFinite(limit) || limit < 0))
      return res.status(400).json({ status: 'fail', message: 'Invalid exposure limit' });

    if (userType === 'STAFF') {
      await assertDescendant(req.staff.id, userId);
      await pg.query(
        'UPDATE staff_balances SET exposure_limit=$1 WHERE staff_id=$2',
        [limit, userId]
      );
    } else {
      const ok = (await pg.query(
        `SELECT 1 FROM users u
         JOIN staff_hierarchy h ON h.descendant_id = u.parent_staff_id
         WHERE h.ancestor_id = $1 AND u.id = $2`,
        [req.staff.id, userId]
      )).rowCount;
      if (!ok) return res.status(403).json({ status: 'fail', message: 'User not in your hierarchy' });
      await pg.query('UPDATE users SET exposure_limit=$1 WHERE id=$2', [limit, userId]);
    }

    res.json({ status: 'success', message: 'Exposure limit updated' });
  } catch (err) {
    if (err.message === 'Invalid transaction password')
      return res.status(403).json({ status: 'fail', message: err.message });
    next(err);
  }
};

// ─── DEPOSIT / WITHDRAW STATEMENT ────────────────────────────────────────────

/**
 * GET /lords/transfer/statement
 * Query: { page, limit }
 *
 * Every money movement touching this staff member. Legacy rows with
 * transfer_type 'gt'/'casino' (the old settlement model) are still returned so
 * the history stays complete — nothing new is ever written with those types.
 */
exports.transferStatement = async (req, res, next) => {
  try {
    const page = Math.max(1, +(req.query.page || 1));
    const limit = Math.min(100, +(req.query.limit || 25));
    const offset = (page - 1) * limit;

    const { rows } = await pg.query(
      `SELECT t.id, t.from_type, t.from_id, t.to_type, t.to_id,
              t.amount, t.direction, t.transfer_type, t.created_at,
              COALESCE(sf.name, uf.name) AS from_name,
              COALESCE(st.name, ut.name) AS to_name
       FROM staff_transfers t
       LEFT JOIN staff sf ON t.from_type='staff' AND sf.id = t.from_id
       LEFT JOIN staff st ON t.to_type='staff'   AND st.id = t.to_id
       LEFT JOIN users uf ON t.from_type='user'  AND uf.id = t.from_id
       LEFT JOIN users ut ON t.to_type='user'    AND ut.id = t.to_id
       WHERE (t.from_type='staff' AND t.from_id=$1)
          OR (t.to_type='staff'   AND t.to_id=$1)
       ORDER BY t.created_at DESC
       OFFSET $2 LIMIT $3`,
      [req.staff.id, offset, limit]
    );

    const { rows: [{ count }] } = await pg.query(
      `SELECT COUNT(*) FROM staff_transfers
       WHERE (from_type='staff' AND from_id=$1) OR (to_type='staff' AND to_id=$1)`,
      [req.staff.id]
    );

    res.json({
      status: 'success',
      data: rows,
      page,
      limit,
      totalPages: Math.ceil(count / limit)
    });
  } catch (err) { next(err); }
};

// ─── NET EXPOSURE ─────────────────────────────────────────────────────────────

/**
 * GET /lords/net-exposure/sports?userId=X&userType=STAFF|USER
 */
exports.netExposure = async (req, res, next) => {
  try {
    const { userId, userType } = req.query;
    if (!userId) return res.status(400).json({ status: 'fail', message: 'userId required' });

    // Verify hierarchy
    const targetId = Number(userId);
    if (userType === 'STAFF') {
      await assertDescendant(req.staff.id, targetId);
      // For staff, aggregate exposure of all users in their tree
      const { rows: staffIds } = await pg.query(
        `SELECT descendant_id FROM staff_hierarchy WHERE ancestor_id=$1`, [targetId]
      );
      const ids = staffIds.map(r => r.descendant_id);

      const { rows } = await pg.query(
        `SELECT ue.user_id, ue.match_id, ue.match_title, ue.team_name,
                ue.exposure_amount, ue.category, ue.event_id, ue.game_type,
                u.name as user_name
         FROM user_exposures ue
         JOIN users u ON u.id = ue.user_id
         WHERE u.parent_staff_id = ANY($1::bigint[])
         ORDER BY ue.updated_at DESC`,
        [ids]
      );

      // Group by event
      const events = {};
      let totalExposure = 0;
      for (const row of rows) {
        const key = row.match_id || row.event_id;
        if (!events[key]) {
          events[key] = {
            eventId: key,
            eventName: row.match_title || 'Unknown',
            category: row.category || 'sports',
            markets: []
          };
        }
        events[key].markets.push({
          gameType: row.game_type,
          teamName: row.team_name,
          exposure: Number(row.exposure_amount),
          userName: row.user_name,
          userId: row.user_id
        });
        totalExposure += Math.abs(Number(row.exposure_amount));
      }

      res.json({
        status: 'success',
        data: Object.values(events),
        meta: { totalEvents: Object.keys(events).length, totalExposure }
      });

    } else {
      // USER - direct exposure lookup
      const ok = (await pg.query(
        `SELECT 1 FROM users u
         JOIN staff_hierarchy h ON h.descendant_id = u.parent_staff_id
         WHERE h.ancestor_id = $1 AND u.id = $2`,
        [req.staff.id, targetId]
      )).rowCount;
      if (!ok) return res.status(403).json({ status: 'fail', message: 'User not in your hierarchy' });

      const { rows } = await pg.query(
        `SELECT match_id, match_title, team_name, exposure_amount,
                category, event_id, game_type
         FROM user_exposures
         WHERE user_id=$1
         ORDER BY updated_at DESC`,
        [targetId]
      );

      const events = {};
      let totalExposure = 0;
      for (const row of rows) {
        const key = row.match_id || row.event_id;
        if (!events[key]) {
          events[key] = {
            eventId: key,
            eventName: row.match_title || 'Unknown',
            category: row.category || 'sports',
            markets: []
          };
        }
        events[key].markets.push({
          gameType: row.game_type,
          teamName: row.team_name,
          exposure: Number(row.exposure_amount)
        });
        totalExposure += Math.abs(Number(row.exposure_amount));
      }

      res.json({
        status: 'success',
        data: Object.values(events),
        meta: { totalEvents: Object.keys(events).length, totalExposure }
      });
    }
  } catch (err) { next(err); }
};

// ─── ALL DETAILS (Agent Listing with pagination) ──────────────────────────────

/**
 * GET /lords/users/all-details?page=1&limit=25&search=TERM&parentId=ID
 */
exports.allDetails = async (req, res, next) => {
  try {
    const page = Math.max(1, +(req.query.page || 1));
    const limit = Math.min(100, +(req.query.limit || 25));
    const offset = (page - 1) * limit;
    const search = req.query.search || '';
    const parentId = req.query.parentId ? Number(req.query.parentId) : req.staff.id;

    // If drilling into a sub-agent, verify it's in our tree
    if (parentId !== req.staff.id) {
      await assertDescendant(req.staff.id, parentId);
    }

    // Count total
    let countSql, countParams;
    if (search && search.length >= 3) {
      countSql = `
        SELECT COUNT(*) FROM (
          SELECT s.id FROM staff s
          JOIN staff_hierarchy h ON h.descendant_id = s.id
          WHERE h.ancestor_id = $1 AND h.depth = 1 AND lower(s.name) LIKE $2
          UNION ALL
          SELECT u.id FROM users u
          WHERE u.parent_staff_id = $1 AND lower(u.name) LIKE $2
        ) sub`;
      countParams = [parentId, `%${search.toLowerCase()}%`];
    } else {
      countSql = `
        SELECT COUNT(*) FROM (
          SELECT s.id FROM staff s
          JOIN staff_hierarchy h ON h.descendant_id = s.id
          WHERE h.ancestor_id = $1 AND h.depth = 1
          UNION ALL
          SELECT u.id FROM users u
          WHERE u.parent_staff_id = $1
        ) sub`;
      countParams = [parentId];
    }

    const { rows: [{ count }] } = await pg.query(countSql, countParams);

    // Fetch staff children (depth=1 direct children only)
    const searchFilter = search.length >= 3
      ? `AND lower(s.name) LIKE '%${search.toLowerCase()}%'`
      : '';

    const { rows: staffRows } = await pg.query(
      `SELECT s.id, s.name AS username, r.name AS role, s.status, s.bet_status,
              s.percentage, s.sports_betlocked AS bet_locked,
              s.sports_betlocked AS sports_locked, s.casino_locked, s.system_locked,
              COALESCE(sb.inr, 0) AS balance,
              sb.exposure_limit AS exp_limit,
              'STAFF' AS account_type,
              (
                (SELECT COUNT(*) FROM staff_hierarchy sh WHERE sh.ancestor_id = s.id AND sh.depth = 1) +
                (SELECT COUNT(*) FROM users u2 WHERE u2.parent_staff_id = s.id)
              ) > 0 AS has_downline
       FROM staff s
       JOIN roles r ON r.id = s.role_id
       LEFT JOIN staff_balances sb ON sb.staff_id = s.id
       JOIN staff_hierarchy h ON h.descendant_id = s.id
       WHERE h.ancestor_id = $1 AND h.depth = 1 ${searchFilter}
       ORDER BY s.id
       LIMIT $2 OFFSET $3`,
      [parentId, limit, offset]
    );

    // Fetch user/bettor children
    const userSearchFilter = search.length >= 3
      ? `AND lower(u.name) LIKE '%${search.toLowerCase()}%'`
      : '';

    const remainingLimit = Math.max(0, limit - staffRows.length);

    const { rows: userRows } = await pg.query(
      `SELECT u.id, u.name AS username, 'User' AS role, u.status, u.bet_status,
              0 AS percentage, u.sports_betlocked AS bet_locked,
              u.sports_betlocked AS sports_locked, u.casino_locked, u.system_locked,
              COALESCE(c.inr, 0) AS balance,
              u.exposure_limit AS exp_limit,
              -COALESCE(u.gt, 0)        AS sports_pnl,
              -COALESCE(u.casino_gt, 0) AS casino_pnl,
              'USER' AS account_type,
              false AS has_downline,
              COALESCE((SELECT SUM(ABS(exposure_amount)) FROM user_exposures WHERE user_id = u.id), 0) AS exposure,
              COALESCE(u.is_demo, false) AS is_demo
       FROM users u
       LEFT JOIN credits c ON c.uid = u.id
       WHERE u.parent_staff_id = $1 ${userSearchFilter}
       ORDER BY u.id
       LIMIT $2 OFFSET $3`,
      [parentId, remainingLimit > 0 ? remainingLimit : limit, 0]
    );

    // Roll up the whole subtree for each staff row: open exposure, plus the
    // lifetime sports/casino P&L of every player underneath. Agents have no
    // stored gt — theirs is always the sum of their downline.
    for (const row of staffRows) {
      const { rows: [agg] } = await pg.query(
        `SELECT COALESCE(SUM(ABS(ue.exposure_amount)), 0) AS exposure
           FROM user_exposures ue
           JOIN users u ON u.id = ue.user_id
           JOIN staff_hierarchy h ON h.descendant_id = u.parent_staff_id
          WHERE h.ancestor_id = $1`,
        [row.id]
      );
      row.exposure = Number(agg.exposure);

      const pnl = await rollupPnl(row.id);
      row.sports_pnl = pnl.sports_pnl;
      row.casino_pnl = pnl.casino_pnl;
    }

    const users = [...staffRows, ...userRows];

    res.json({
      status: 'success',
      users,
      page,
      limit,
      totalPages: Math.ceil(Number(count) / limit),
      totalCount: Number(count)
    });
  } catch (err) { next(err); }
};

/**
 * POST /lords/update-current
 * Refreshes the logged-in staff's own data
 */
exports.updateCurrent = async (req, res, next) => {
  try {
    const { rows: [staff] } = await pg.query(
      `SELECT s.id, s.name, s.email, r.name AS role, r.level,
              s.status, s.bet_status, s.percentage,
              COALESCE(sb.inr, 0) AS balance, sb.exposure_limit
       FROM staff s
       JOIN roles r ON r.id = s.role_id
       LEFT JOIN staff_balances sb ON sb.staff_id = s.id
       WHERE s.id = $1`,
      [req.staff.id]
    );

    if (!staff) return res.status(404).json({ status: 'fail', message: 'Staff not found' });

    // Lifetime P&L across the whole downline (read-only figure, never settled).
    const pnl = await rollupPnl(req.staff.id);
    staff.sports_pnl = pnl.sports_pnl;
    staff.casino_pnl = pnl.casino_pnl;

    res.json({ status: 'success', data: staff });
  } catch (err) { next(err); }
};
