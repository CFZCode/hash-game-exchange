// controllers/branchController.js
// Branch panel: the super admin creates Branch Admins, each branch admin
// creates Sub Branches, and players who register with a sub branch's code sit
// under it. Everything here is read-only reporting on those players plus
// account management (create / lock / password). See system/utils/branch.js.
//
// Every report takes the same scope: ?staffId= narrows to one branch or sub
// branch (it must be the caller or below the caller), otherwise the caller's
// whole tree — for the super admin, every branch.
//
// Money is INR only, like report/statement.js. Days are India days.
const pg = require('../../General/Model');
const { withTransaction } = require('../../General/Model/pool');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const _ = require('lodash');
const config = require('../../config');
const { validateTransactionPassword } = require('./lordsController');
const { recordActivity } = require('../utils/recordActivity');
const {
  BRANCH_ADMIN_ROLE, SUB_BRANCH_ROLE, BRANCH_ROLES,
  getBranchRoleIds, isLockedInTree,
} = require('../utils/branch');

const TZ = 'Asia/Kolkata';
const LOCKED_MESSAGE = 'This branch account is locked. Contact your administrator.';

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}
const fail = (status, message) => { throw new HttpError(status, message); };

const handle = (fn) => async (req, res, next) => {
  try {
    await fn(req, res);
  } catch (err) {
    if (err instanceof HttpError)
      return res.status(err.status).json({ status: 'fail', message: err.message });
    if (err.message === 'Invalid transaction password' || err.message === 'Transaction password is required')
      return res.status(403).json({ status: 'fail', message: err.message });
    if (err.code === '23505')
      return res.status(400).json({ status: 'fail', message: 'That login ID or code is already in use' });
    next(err);
  }
};

const q = async (sql, params) => (await pg.query(sql, params)).rows;
const num = (v) => { const n = Number(v); return Number.isFinite(n) ? n : 0; };
const round2 = (n) => Math.round(num(n) * 100) / 100;
const cleanDate = (s) => (typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) ? s : null);

const LOGIN_RE = /^[a-z0-9][a-z0-9_.@+-]{3,63}$/;
const CODE_RE = /^[A-Z0-9]{4,12}$/;
const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

// ─── auth ─────────────────────────────────────────────────────────────────────

// POST /api/branch/login  { login, password }
exports.login = handle(async (req, res) => {
  const login = String(req.body.login || req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  if (!login || !password) fail(400, 'Login ID and password are required');

  await getBranchRoleIds();
  const [staff] = await q(
    `SELECT s.id, s.name, s.email, s.password, s.role_id, r.name AS role_name, r.level AS role_level
       FROM staff s JOIN roles r ON r.id = s.role_id
      WHERE lower(s.email) = $1 AND r.name = ANY($2)`,
    [login, BRANCH_ROLES]
  );
  if (!staff || !(await bcrypt.compare(password, staff.password)))
    fail(400, 'Wrong login ID or password');
  if (await isLockedInTree(staff.id)) fail(403, LOCKED_MESSAGE);

  const token = jwt.sign(
    { id: staff.id, name: staff.name, email: staff.email, role_id: staff.role_id, role_name: staff.role_name, role_level: staff.role_level },
    process.env.JWT_SECRET,
    { expiresIn: '12h' }
  );
  res.json({
    status: 'success',
    token,
    user: { id: staff.id, name: staff.name, login: staff.email, role: staff.role_name },
  });

  recordActivity({
    req, action: 'login',
    actor: { staffId: staff.id, name: staff.name, role: staff.role_name, level: staff.role_level },
  });
});

// Runs after protectStaff. Lets in the super admin and the two branch roles,
// and re-checks the lock on every request so locking ends a live session.
exports.access = async (req, res, next) => {
  try {
    const deny = (message, code) => res.status(403).json({ status: 'fail', code, message });
    if (req.staff.executive_id) return deny('Branch panel is not available to executive accounts');
    const ids = await getBranchRoleIds();
    const roleId = Number(req.staff.role_id);
    if (req.staff.level === 0) req.branch = { kind: 'owner' };
    else if (roleId === ids.branchAdmin) req.branch = { kind: 'branch' };
    else if (roleId === ids.subBranch) req.branch = { kind: 'sub' };
    else return deny('Branch panel access only');
    if (req.branch.kind !== 'owner' && await isLockedInTree(req.staff.id))
      return deny(LOCKED_MESSAGE, 'BRANCH_LOCKED');
    next();
  } catch (e) { next(e); }
};

exports.requireOwner = (req, res, next) => {
  if (req.branch.kind === 'owner') return next();
  res.status(403).json({ status: 'fail', message: 'Only the super admin can do this' });
};

// ─── scope ────────────────────────────────────────────────────────────────────

// The staff ids (branch + sub branches) whose players the request may read.
async function resolveScope(req) {
  const ids = await getBranchRoleIds();
  const roleIds = [ids.branchAdmin, ids.subBranch];
  const me = Number(req.staff.id);
  if (req.branch.kind === 'sub') return { rootId: me, staffIds: [me] };

  const raw = req.query.staffId;
  let rootId = req.branch.kind === 'branch' ? me : null;
  if (raw !== undefined && raw !== '') {
    const want = Number(raw);
    if (!Number.isInteger(want)) fail(400, 'Invalid staffId');
    if (req.branch.kind === 'branch' && want !== me) {
      const ok = await q('SELECT 1 FROM staff_hierarchy WHERE ancestor_id = $1 AND descendant_id = $2', [me, want]);
      if (!ok.length) fail(403, 'That sub branch is not under your branch');
    }
    rootId = want;
  }

  if (rootId == null) {
    const rows = await q('SELECT id FROM staff WHERE role_id = ANY($1::int[])', [roleIds]);
    return { rootId: null, staffIds: rows.map(r => Number(r.id)) };
  }
  const rows = await q(
    `SELECT id FROM staff
      WHERE role_id = ANY($2::int[])
        AND (id = $1 OR id IN (SELECT descendant_id FROM staff_hierarchy WHERE ancestor_id = $1))`,
    [rootId, roleIds]
  );
  if (!rows.length) fail(404, 'Branch not found');
  return { rootId, staffIds: rows.map(r => Number(r.id)) };
}

function readPeriod(req) {
  const from = cleanDate(req.query.from);
  const to = cleanDate(req.query.to);
  if (from && to && from > to) fail(400, 'from must not be after to');
  return { from, to };
}

function readPage(req, def = 25, max = 200) {
  const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || def, 1), max);
  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  return { page, limit, offset: (page - 1) * limit };
}

const pages = (total, limit) => Math.max(Math.ceil(total / limit), 1);

/* India-day window on a timestamptz expression. */
function rangeClause(col, { from, to }, params) {
  let sql = '';
  if (from) { params.push(from); sql += ` AND ${col} >= ($${params.length}::date::timestamp AT TIME ZONE '${TZ}')`; }
  if (to) { params.push(to); sql += ` AND ${col} < (($${params.length}::date + 1)::timestamp AT TIME ZONE '${TZ}')`; }
  return sql;
}
const dayOf = (col) => `to_char(${col} AT TIME ZONE '${TZ}', 'YYYY-MM-DD')`;

/* `scope` CTE: the players in view. $1 is always the staff id list; userIds
   narrows to specific players (one player's report, or one page of a list). */
function scopeCte(staffIds, userIds) {
  const params = [staffIds];
  let extra = '';
  if (userIds) { params.push(userIds.map(String)); extra = ` AND u.id::text = ANY($2::text[])`; }
  return {
    params,
    sql: `scope AS (
      SELECT u.id, u.name, u.parent_staff_id FROM users u
       WHERE u.parent_staff_id = ANY($1::bigint[])${extra})`,
  };
}

// ─── deposits & withdrawals, every source in one shape ───────────────────────

const OK = `('approved','success','done','completed','paid')`;
const FAILED = `('failed','rejected','declined','cancelled','canceled','unattempted','expired','refunded')`;
const statusOf = (col, refunded) => `CASE ${refunded ? `WHEN ${refunded} THEN 'failed' ` : ''}WHEN lower(${col}) IN ${OK} THEN 'success' WHEN lower(${col}) IN ${FAILED} THEN 'failed' ELSE 'pending' END`;

// Gateway tables keep `created_at` as a plain UTC timestamp.
const TX_CTE = `tx AS (
    SELECT 'deposit'::text AS type, 'Bank transfer'::text AS method, d.deposit_id::text AS ref,
           d.user_id::bigint AS uid, d.amount::numeric AS amount, d.status::text AS raw_status,
           d.created_at::timestamptz AS ts, ${statusOf('d.status')} AS status
      FROM fiat_deposits d
     WHERE upper(d.currency) = 'INR' AND d.user_id IN (SELECT id FROM scope)
    UNION ALL
    SELECT 'deposit', 'Gateway (A-Pay)', d.order_id::text, d.user_id::bigint,
           (CASE WHEN d.paid_amount > 0 THEN d.paid_amount ELSE d.amount END)::numeric, d.status::text,
           d.created_at AT TIME ZONE 'UTC', ${statusOf('d.status')}
      FROM apaydeposits d
     WHERE upper(d.currency) = 'INR' AND d.user_id IN (SELECT id FROM scope)
    UNION ALL
    SELECT 'deposit', 'Gateway (F2Pay)', d.mch_order_no::text, d.user_id::bigint, d.amount::numeric, d.status::text,
           d.created_at AT TIME ZONE 'UTC', ${statusOf('d.status')}
      FROM f2paydeposits d
     WHERE upper(d.currency) = 'INR' AND d.user_id IN (SELECT id FROM scope)
    UNION ALL
    SELECT 'deposit', 'Agent transfer', t.id::text, t.to_id::bigint, t.amount::numeric, 'Success',
           t.created_at::timestamptz, 'success'
      FROM staff_transfers t
     WHERE t.transfer_type = 'transfer' AND t.to_type = 'user' AND t.to_id IN (SELECT id FROM scope)
    UNION ALL
    SELECT 'withdraw', 'Bank transfer', w.id::text, w.uid::bigint, w.amount::numeric, w.status::text,
           w.date::timestamptz, ${statusOf('w.status')}
      FROM fiat_withdrawals w
     WHERE upper(w.currency) = 'INR' AND w.uid IN (SELECT id FROM scope)
    UNION ALL
    SELECT 'withdraw', 'Gateway (A-Pay)', w.order_id::text, w.user_id::bigint, w.amount::numeric, w.status::text,
           w.created_at AT TIME ZONE 'UTC', ${statusOf('w.status', 'COALESCE(w.refunded,false)')}
      FROM apaywithdrawals w
     WHERE upper(w.currency) = 'INR' AND w.user_id IN (SELECT id::text FROM scope)
    UNION ALL
    SELECT 'withdraw', 'Gateway (F2Pay)', w.mch_order_no::text, w.user_id::bigint, w.amount::numeric, w.status::text,
           w.created_at AT TIME ZONE 'UTC', ${statusOf('w.status', 'COALESCE(w.refunded,false)')}
      FROM f2paywithdrawals w
     WHERE upper(w.currency) = 'INR' AND w.user_id IN (SELECT id FROM scope)
    UNION ALL
    SELECT 'withdraw', 'Agent transfer', t.id::text, t.from_id::bigint, t.amount::numeric, 'Success',
           t.created_at::timestamptz, 'success'
      FROM staff_transfers t
     WHERE t.transfer_type = 'transfer' AND t.from_type = 'user' AND t.from_id IN (SELECT id FROM scope)
  )`;

// ─── aggregation ──────────────────────────────────────────────────────────────

const emptyStats = () => ({
  deposit: 0, deposit_count: 0, deposit_pending: 0, deposit_pending_count: 0, deposit_failed_count: 0,
  withdraw: 0, withdraw_count: 0, withdraw_pending: 0, withdraw_pending_count: 0, withdraw_failed_count: 0,
  sports_bets: 0, sports_stake: 0, sports_open_bets: 0, sports_pnl: 0,
  casino_bets: 0, casino_staked: 0, casino_won: 0, casino_pnl: 0,
});

/* Money + play totals for the scoped players, keyed by `group`:
     'total' one record under key 'all'   'day'   India calendar day
     'user'  player id                    'staff' the player's sub branch id
   P&L is the player's: positive = the player won. */
async function aggregate(staffIds, period, group, userIds) {
  const out = new Map();
  if (!staffIds.length || (userIds && !userIds.length)) return out;
  const rec = (k) => {
    const key = String(k);
    if (!out.has(key)) out.set(key, emptyStats());
    return out.get(key);
  };
  const keyFor = (tsCol, uidCol) => ({
    total: `'all'`,
    day: dayOf(tsCol),
    user: `${uidCol}::text`,
    staff: 'sc.parent_staff_id::text',
  }[group]);
  const scope = () => scopeCte(staffIds, userIds);

  const money = (() => {
    const s = scope();
    return q(
      `WITH ${s.sql}, ${TX_CTE}
       SELECT ${keyFor('tx.ts', 'tx.uid')} AS k, tx.type, tx.status, COUNT(*) AS n, COALESCE(SUM(tx.amount),0) AS amount
         FROM tx JOIN scope sc ON sc.id = tx.uid
        WHERE true ${rangeClause('tx.ts', period, s.params)}
        GROUP BY 1, 2, 3`, s.params);
  })();

  const sportsPlaced = (() => {
    const s = scope();
    return q(
      `WITH ${s.sql}
       SELECT ${keyFor('b.created_at', 'b.user_id')} AS k, COUNT(*) AS n, COALESCE(SUM(b.stake_amount),0) AS stake,
              COUNT(*) FILTER (WHERE b.status IN ('open','manual')) AS open_n
         FROM "SportsBet" b JOIN scope sc ON sc.id = b.user_id
        WHERE true ${rangeClause('b.created_at', period, s.params)}
        GROUP BY 1`, s.params);
  })();

  // credits_ledger is the authoritative settled sports result (netamount is signed).
  const sportsSettled = (() => {
    const s = scope();
    return q(
      `WITH ${s.sql}
       SELECT ${keyFor('cl.created_at', 'cl.user_id')} AS k, COALESCE(SUM(COALESCE(cl.netamount, cl.amount)),0) AS net
         FROM credits_ledger cl JOIN scope sc ON sc.id::text = cl.user_id
        WHERE upper(cl.currency) = 'INR' ${rangeClause('cl.created_at', period, s.params)}
        GROUP BY 1`, s.params);
  })();

  // The casino provider labels the INR wallet 'PKR'.
  const casino = (() => {
    const s = scope();
    const ts = 'COALESCE(g.transaction_datetime, g.created_at)';
    return q(
      `WITH ${s.sql}
       SELECT ${keyFor(ts, 'g.user_id')} AS k,
              COUNT(*) FILTER (WHERE g.action = 'bet') AS bets,
              COALESCE(SUM(g.amount) FILTER (WHERE g.action = 'bet'),0) AS staked,
              COALESCE(SUM(g.amount) FILTER (WHERE g.action <> 'bet'),0) AS won
         FROM gis_transactions g JOIN scope sc ON sc.id = g.user_id
        WHERE upper(g.currency) IN ('INR','PKR') ${rangeClause(ts, period, s.params)}
        GROUP BY 1`, s.params);
  })();

  const [m, sp, ss, c] = await Promise.all([money, sportsPlaced, sportsSettled, casino]);
  for (const r of m) {
    const o = rec(r.k), t = r.type;
    if (r.status === 'success') { o[t] += num(r.amount); o[`${t}_count`] += num(r.n); }
    else if (r.status === 'pending') { o[`${t}_pending`] += num(r.amount); o[`${t}_pending_count`] += num(r.n); }
    else o[`${t}_failed_count`] += num(r.n);
  }
  for (const r of sp) {
    const o = rec(r.k);
    o.sports_bets = num(r.n); o.sports_stake = num(r.stake); o.sports_open_bets = num(r.open_n);
  }
  for (const r of ss) rec(r.k).sports_pnl = num(r.net);
  for (const r of c) {
    const o = rec(r.k);
    o.casino_bets = num(r.bets); o.casino_staked = num(r.staked); o.casino_won = num(r.won);
    o.casino_pnl = num(r.won) - num(r.staked);
  }
  for (const o of out.values()) for (const k of Object.keys(o)) o[k] = round2(o[k]);
  return out;
}

const addStats = (into, from) => { for (const k of Object.keys(from)) into[k] = round2(into[k] + from[k]); };

// ─── profile ──────────────────────────────────────────────────────────────────

// GET /api/branch/me
exports.me = handle(async (req, res) => {
  const [me] = await q(
    `SELECT s.id, s.name, s.email AS login, s.phone,
            CASE WHEN r.name = '${SUB_BRANCH_ROLE}' THEN s.agent_code END AS code, s.created_at,
            r.name AS role, p.name AS parent_name
       FROM staff s JOIN roles r ON r.id = s.role_id LEFT JOIN staff p ON p.id = s.parent_id
      WHERE s.id = $1`, [req.staff.id]);
  res.json({ status: 'success', kind: req.branch.kind, me });
});

// POST /api/branch/me/password  { oldPassword, newPassword }
exports.changeMyPassword = handle(async (req, res) => {
  if (req.branch.kind === 'owner') fail(400, 'Change the super admin password from the admin panel');
  const next = String(req.body.newPassword || '');
  if (next.length < 6) fail(400, 'Password must be at least 6 characters');
  const [row] = await q('SELECT password FROM staff WHERE id = $1', [req.staff.id]);
  if (!row || !(await bcrypt.compare(String(req.body.oldPassword || ''), row.password)))
    fail(400, 'Current password is wrong');
  await pg.query('UPDATE staff SET password = $1, password2 = NULL WHERE id = $2', [await bcrypt.hash(next, 10), req.staff.id]);
  res.json({ status: 'success', message: 'Password updated' });
});

// ─── branches & sub branches ─────────────────────────────────────────────────

// Only a sub branch's code is a signup code, so it is the only one returned.
const STAFF_SELECT = `
  SELECT s.id, s.name, s.email AS login, s.phone,
         CASE WHEN s.role_id = (SELECT id FROM roles WHERE name = '${SUB_BRANCH_ROLE}') THEN s.agent_code END AS code,
         s.parent_id,
         COALESCE(s.system_locked,false) AS locked, s.created_at, p.name AS parent_name,
         COALESCE(p.system_locked,false) AS parent_locked
    FROM staff s LEFT JOIN staff p ON p.id = s.parent_id`;

async function playerCounts(staffIds) {
  const rows = await q(
    `SELECT u.parent_staff_id AS id, COUNT(*) AS players, COALESCE(SUM(c.inr),0) AS wallet
       FROM users u LEFT JOIN credits c ON c.uid = u.id
      WHERE u.parent_staff_id = ANY($1::bigint[]) GROUP BY 1`, [staffIds]);
  return new Map(rows.map(r => [String(r.id), { players: num(r.players), wallet: round2(r.wallet) }]));
}

// GET /api/branch/branches?search&from&to   (super admin)
// One row per branch admin, with its whole tree rolled up.
exports.listBranches = handle(async (req, res) => {
  const ids = await getBranchRoleIds();
  const period = readPeriod(req);
  const search = String(req.query.search || '').trim();
  const branches = await q(
    `${STAFF_SELECT}
      WHERE s.role_id = $1
        AND ($2 = '' OR s.name ILIKE '%' || $2 || '%' OR s.email ILIKE '%' || $2 || '%')
      ORDER BY s.id DESC`, [ids.branchAdmin, search]);
  const subs = await q('SELECT id, parent_id FROM staff WHERE role_id = $1', [ids.subBranch]);
  const allIds = [...branches.map(b => Number(b.id)), ...subs.map(s => Number(s.id))];
  const [stats, counts] = await Promise.all([aggregate(allIds, period, 'staff'), playerCounts(allIds)]);

  const rows = branches.map((b) => {
    const mine = [b.id, ...subs.filter(s => String(s.parent_id) === String(b.id)).map(s => s.id)].map(String);
    const total = emptyStats();
    let players = 0, wallet = 0;
    for (const id of mine) {
      if (stats.has(id)) addStats(total, stats.get(id));
      players += counts.get(id)?.players || 0;
      wallet += counts.get(id)?.wallet || 0;
    }
    return { ...b, sub_branches: mine.length - 1, players, wallet: round2(wallet), ...total };
  });
  res.json({ status: 'success', branches: rows });
});

// GET /api/branch/sub-branches?staffId&search&from&to&onlySubs=1
// The branch accounts in scope, branch admins first. ?onlySubs=1 leaves the
// branch admins out (the Sub Branches page); pickers need them.
exports.listSubBranches = handle(async (req, res) => {
  const scope = await resolveScope(req);
  const period = readPeriod(req);
  const search = String(req.query.search || '').trim();
  const onlySubs = req.query.onlySubs === '1';
  const staff = await q(
    `${STAFF_SELECT} JOIN roles r ON r.id = s.role_id
      WHERE s.id = ANY($1::bigint[])
        ${onlySubs ? `AND r.name = '${SUB_BRANCH_ROLE}'` : ''}
        AND ($2 = '' OR s.name ILIKE '%' || $2 || '%' OR s.email ILIKE '%' || $2 || '%' OR s.agent_code ILIKE '%' || $2 || '%')
      ORDER BY (r.name = '${BRANCH_ADMIN_ROLE}') DESC, s.id DESC`, [scope.staffIds, search]);
  const roleRows = await q('SELECT s.id, r.name AS role FROM staff s JOIN roles r ON r.id = s.role_id WHERE s.id = ANY($1::bigint[])', [scope.staffIds]);
  const roleOf = new Map(roleRows.map(r => [String(r.id), r.role]));
  const [stats, counts] = await Promise.all([aggregate(scope.staffIds, period, 'staff'), playerCounts(scope.staffIds)]);
  res.json({
    status: 'success',
    subBranches: staff.map(s => ({
      ...s,
      role: roleOf.get(String(s.id)),
      players: counts.get(String(s.id))?.players || 0,
      wallet: counts.get(String(s.id))?.wallet || 0,
      ...(stats.get(String(s.id)) || emptyStats()),
    })),
  });
});

async function uniqueCode(db, prefix) {
  for (;;) {
    const code = `${prefix}${_.sampleSize(CODE_CHARS, 6).join('')}`;
    if (!(await db.query('SELECT 1 FROM staff WHERE agent_code = $1', [code])).rowCount) return code;
  }
}

async function createBranchStaff({ roleId, parentId, body, prefix }) {
  const name = String(body.name || '').trim();
  const login = String(body.login || body.email || '').trim().toLowerCase();
  const password = String(body.password || '');
  const phone = String(body.phone || '').trim() || null;
  // Only sub branches take signups. A branch admin still gets an internal code
  // (staffController backfills NULL agent_code at startup) that is never shown
  // and is refused at registration.
  let code = roleId === (await getBranchRoleIds()).subBranch ? String(body.code || '').trim().toUpperCase() : '';
  if (!name) fail(400, 'Name is required');
  if (!LOGIN_RE.test(login)) fail(400, 'Login ID must be 4-64 characters: an email, or letters, numbers, _ . -');
  if (password.length < 6) fail(400, 'Password must be at least 6 characters');
  if (code && !CODE_RE.test(code)) fail(400, 'Code must be 4-12 letters or numbers');
  const hash = await bcrypt.hash(password, 10);

  return withTransaction(async (db) => {
    if ((await db.query('SELECT 1 FROM staff WHERE lower(email) = $1', [login])).rowCount)
      fail(400, 'That login ID is already in use');
    if (code) {
      // A staff code and a player referral code share the signup field.
      const taken = await db.query(
        `SELECT 1 FROM staff WHERE upper(agent_code) = $1
         UNION ALL SELECT 1 FROM users WHERE upper(referalcode) = $1 LIMIT 1`, [code]);
      if (taken.rowCount) fail(400, 'That code is already in use');
    } else {
      code = await uniqueCode(db, prefix);
    }
    const { rows: [s] } = await db.query(
      `INSERT INTO staff (name, email, password, phone, role_id, parent_id, percentage, first_login, agent_code)
       VALUES ($1,$2,$3,$4,$5,$6,0,false,$7) RETURNING id`,
      [name, login, hash, phone, roleId, parentId, code]
    );
    await db.query('INSERT INTO staff_balances (staff_id, inr) VALUES ($1, 0)', [s.id]);
    await db.query(
      `INSERT INTO staff_hierarchy (ancestor_id, descendant_id, depth) VALUES ($1,$1,0) ON CONFLICT DO NOTHING`, [s.id]);
    await db.query(
      `INSERT INTO staff_hierarchy (ancestor_id, descendant_id, depth)
         SELECT ancestor_id, $1, depth + 1 FROM staff_hierarchy WHERE descendant_id = $2
       ON CONFLICT DO NOTHING`, [s.id, parentId]);
    // The parent's own self row is what the copy above relies on.
    await db.query(
      `INSERT INTO staff_hierarchy (ancestor_id, descendant_id, depth) VALUES ($2,$1,1) ON CONFLICT DO NOTHING`,
      [s.id, parentId]);
    return { id: s.id, name, login, code };
  });
}

// POST /api/branch/branches  { name, login, password, phone?, code?, transactionPassword }
exports.createBranch = handle(async (req, res) => {
  await validateTransactionPassword(req.staff.id, req.body.transactionPassword);
  const ids = await getBranchRoleIds();
  const branch = await createBranchStaff({ roleId: ids.branchAdmin, parentId: req.staff.id, body: req.body, prefix: 'BR' });
  res.status(201).json({ status: 'success', branch, message: 'Branch admin created' });
});

// POST /api/branch/sub-branches  { name, login, password, phone?, code?, branchId?, transactionPassword? }
// A branch admin creates under itself; the super admin names the branch.
exports.createSubBranch = handle(async (req, res) => {
  const ids = await getBranchRoleIds();
  let parentId = Number(req.staff.id);
  if (req.branch.kind === 'sub') fail(403, 'A sub branch cannot create sub branches');
  if (req.branch.kind === 'owner') {
    await validateTransactionPassword(req.staff.id, req.body.transactionPassword);
    parentId = Number(req.body.branchId);
    const ok = Number.isInteger(parentId) &&
      (await q('SELECT 1 FROM staff WHERE id = $1 AND role_id = $2', [parentId, ids.branchAdmin])).length;
    if (!ok) fail(404, 'Branch not found');
  }
  const subBranch = await createBranchStaff({ roleId: ids.subBranch, parentId, body: req.body, prefix: 'SB' });
  res.status(201).json({ status: 'success', subBranch, message: 'Sub branch created' });
});

// The super admin manages any branch account; a branch admin its own sub branches.
async function assertManageable(req, targetIdRaw) {
  const ids = await getBranchRoleIds();
  const targetId = Number(targetIdRaw);
  if (!Number.isInteger(targetId)) fail(400, 'Invalid id');
  const [t] = await q('SELECT id, role_id, parent_id FROM staff WHERE id = $1 AND role_id = ANY($2::int[])',
    [targetId, [ids.branchAdmin, ids.subBranch]]);
  if (!t) fail(404, 'Branch account not found');
  if (req.branch.kind === 'owner') {
    await validateTransactionPassword(req.staff.id, req.body.transactionPassword);
    return t;
  }
  if (req.branch.kind === 'branch' && Number(t.role_id) === ids.subBranch && Number(t.parent_id) === Number(req.staff.id))
    return t;
  fail(403, 'You cannot manage this account');
}

// PATCH /api/branch/staff/:id/lock  { locked, transactionPassword? }
exports.setLock = handle(async (req, res) => {
  const t = await assertManageable(req, req.params.id);
  const locked = !!req.body.locked;
  await pg.query('UPDATE staff SET system_locked = $1 WHERE id = $2', [locked, t.id]);
  res.json({ status: 'success', locked });
});

// PATCH /api/branch/staff/:id/password  { password, transactionPassword? }
exports.resetPassword = handle(async (req, res) => {
  const password = String(req.body.password || '');
  if (password.length < 6) fail(400, 'Password must be at least 6 characters');
  const t = await assertManageable(req, req.params.id);
  await pg.query('UPDATE staff SET password = $1, password2 = NULL WHERE id = $2', [await bcrypt.hash(password, 10), t.id]);
  res.json({ status: 'success', message: 'Password updated' });
});

// ─── players created from the panel ─────────────────────────────────────────

// Quick ID: a readable random name such as "luckytiger4821", 5-16 chars to
// match the site's own signup rule.
const ADJ = ['lucky', 'royal', 'swift', 'bold', 'happy', 'golden', 'brave', 'smart', 'cool', 'super', 'magic', 'rapid', 'grand', 'star', 'prime', 'silver'];
const NOUN = ['tiger', 'lion', 'eagle', 'king', 'ace', 'falcon', 'shark', 'wolf', 'cobra', 'hawk', 'rider', 'player', 'champ', 'panther', 'boss', 'star'];
const randomUsername = () => `${_.sample(ADJ)}${_.sample(NOUN)}${_.random(100, 9999)}`.slice(0, 16);
const randomPassword = () => {
  const chars = 'abcdefghjkmnpqrstuvwxyz23456789';
  return `${_.sampleSize(chars, 6).join('')}${_.random(10, 99)}`;
};
const USERNAME_RE = /^[a-z0-9_]{5,16}$/;

async function freeUsername(db) {
  for (let i = 0; i < 50; i++) {
    const name = randomUsername();
    if (USERNAME_RE.test(name) && !(await db.query('SELECT 1 FROM users WHERE lower(name) = $1', [name])).rowCount) return name;
  }
  fail(500, 'Could not generate a free username, try again');
}

// GET /api/branch/players/suggest — a free username + password to prefill.
exports.suggestPlayer = handle(async (req, res) => {
  if (req.branch.kind === 'branch') fail(403, 'Only a sub branch can create players');
  res.json({ status: 'success', username: await freeUsername(pg), password: randomPassword() });
});

// Players only ever sit under a sub branch. A sub branch creates under
// itself; the super admin picks the sub branch; a branch admin cannot.
async function playerParent(req) {
  const me = Number(req.staff.id);
  if (req.branch.kind === 'sub') return me;
  if (req.branch.kind === 'branch') fail(403, 'Only a sub branch can create players');
  const want = req.body.staffId != null && req.body.staffId !== '' ? Number(req.body.staffId) : null;
  const ids = await getBranchRoleIds();
  const ok = want != null && (await q('SELECT 1 FROM staff WHERE id = $1 AND role_id = $2', [want, ids.subBranch])).length;
  if (!ok) fail(400, 'Choose the sub branch for this player');
  return want;
}

async function newUserId(db) {
  for (;;) {
    const id = _.random(1_000_000_000, 9_999_999_999);
    if (!(await db.query('SELECT 1 FROM users WHERE id = $1', [id])).rowCount) return id;
  }
}

// POST /api/branch/players  { username?, password?, phone?, staffId? }
// Empty username / password are generated. The password is returned once so
// it can be handed to the player.
exports.createPlayer = handle(async (req, res) => {
  const parentId = await playerParent(req);
  if (await isLockedInTree(parentId)) fail(403, 'This branch is locked and cannot add players');
  let username = String(req.body.username || '').trim().toLowerCase();
  if (username && !USERNAME_RE.test(username)) fail(400, 'Username must be 5-16 characters: letters, numbers or _');
  const password = String(req.body.password || '') || randomPassword();
  if (password.length < 6) fail(400, 'Password must be at least 6 characters');
  const phone = String(req.body.phone || '').trim() || null;
  const hash = await bcrypt.hash(password, 10);

  const created = await withTransaction(async (db) => {
    if (username) {
      if ((await db.query('SELECT 1 FROM users WHERE lower(name) = $1', [username])).rowCount)
        fail(400, 'Username already taken');
    } else {
      username = await freeUsername(db);
    }
    const id = await newUserId(db);
    const code = `${username.slice(0, 4).toUpperCase()}${_.sampleSize(CODE_CHARS, 6).join('')}`;
    // role_id stays NULL like a self-registered player: role 6 marks guest IDs
    // that maintenance/autoDeleteInactiveGuests.js removes after 3 idle days.
    await db.query(
      `INSERT INTO users
         (id, name, password, phone, parent_staff_id, friends, wallet,
          profit_low, profit_high, profit, referalcode, referral_link, created)
       VALUES ($1,$2,$3,$4,$5,'Support,',$6,$7,$7,$7,$8,$9,NOW())`,
      [id, username, hash, phone, parentId, JSON.stringify(config.WALLET), JSON.stringify(config.BALANCE),
        code, `https://example.com/referal/${code}`]
    );
    await db.query('INSERT INTO credits (uid, inr) VALUES ($1, 0)', [id]);
    await db.query('INSERT INTO house (uid, max) VALUES ($1, 2)', [id]);
    const [{ name: staffName }] = (await db.query('SELECT name FROM staff WHERE id = $1', [parentId])).rows;
    return { id: String(id), username, password, staff_id: parentId, staff_name: staffName };
  });
  res.status(201).json({ status: 'success', player: created, message: 'Player created' });
});

// ─── reports ──────────────────────────────────────────────────────────────────

// GET /api/branch/summary?staffId&from&to
exports.summary = handle(async (req, res) => {
  const scope = await resolveScope(req);
  const period = readPeriod(req);
  const ids = await getBranchRoleIds();
  const rp = [scope.staffIds];
  const [stats, [people], [reg], [staffCount]] = await Promise.all([
    aggregate(scope.staffIds, period, 'total'),
    q(`SELECT COUNT(*) AS players, COALESCE(SUM(c.inr),0) AS wallet
         FROM users u LEFT JOIN credits c ON c.uid = u.id
        WHERE u.parent_staff_id = ANY($1::bigint[])`, [scope.staffIds]),
    q(`SELECT COUNT(*) AS n FROM users u
        WHERE u.parent_staff_id = ANY($1::bigint[]) ${rangeClause('u.created', period, rp)}`, rp),
    q(`SELECT COUNT(*) FILTER (WHERE role_id = $2) AS subs,
              COUNT(*) FILTER (WHERE role_id = $2 AND system_locked) AS subs_locked,
              COUNT(*) FILTER (WHERE role_id = $3) AS branches
         FROM staff WHERE id = ANY($1::bigint[])`, [scope.staffIds, ids.subBranch, ids.branchAdmin]),
  ]);
  res.json({
    status: 'success',
    period,
    summary: {
      players: num(people.players),
      wallet: round2(people.wallet),
      registrations: num(reg.n),
      branches: num(staffCount.branches),
      sub_branches: num(staffCount.subs),
      sub_branches_locked: num(staffCount.subs_locked),
      ...(stats.get('all') || emptyStats()),
    },
  });
});

// GET /api/branch/reports/daily?staffId&userId&from&to
// One row per India day: registrations, deposits, withdrawals, sports, casino.
exports.daily = handle(async (req, res) => {
  const scope = await resolveScope(req);
  const period = readPeriod(req);
  const userId = req.query.userId ? String(req.query.userId) : null;
  if (userId && !/^\d+$/.test(userId)) fail(400, 'Invalid userId');
  const userIds = userId ? [userId] : undefined;

  const rp = [scope.staffIds];
  const [stats, regs] = await Promise.all([
    aggregate(scope.staffIds, period, 'day', userIds),
    userId ? [] : q(
      `SELECT ${dayOf('u.created')} AS k, COUNT(*) AS n FROM users u
        WHERE u.parent_staff_id = ANY($1::bigint[]) AND u.created IS NOT NULL
          ${rangeClause('u.created', period, rp)}
        GROUP BY 1`, rp),
  ]);
  const days = new Map([...stats].map(([k, v]) => [k, { date: k, registrations: 0, ...v }]));
  for (const r of regs) {
    if (!days.has(r.k)) days.set(r.k, { date: r.k, registrations: 0, ...emptyStats() });
    days.get(r.k).registrations = num(r.n);
  }
  const rows = [...days.values()].sort((a, b) => (a.date < b.date ? 1 : -1));
  const totals = { registrations: 0, ...emptyStats() };
  for (const r of rows) { totals.registrations += r.registrations; addStats(totals, r); }
  res.json({ status: 'success', period, rows, totals });
});

// GET /api/branch/players?staffId&search&from&to&page&limit
// Wallet is live; deposit / withdraw / play figures cover the period.
exports.players = handle(async (req, res) => {
  const scope = await resolveScope(req);
  const period = readPeriod(req);
  const { page, limit, offset } = readPage(req);
  const search = String(req.query.search || '').trim();
  const where = `u.parent_staff_id = ANY($1::bigint[])
     AND ($2 = '' OR u.name ILIKE '%' || $2 || '%' OR u.phone ILIKE '%' || $2 || '%'
          OR u.email ILIKE '%' || $2 || '%' OR u.id::text LIKE $2 || '%')`;
  const [rows, [{ total }]] = await Promise.all([
    q(`SELECT u.id::text AS id, u.name AS username, u.email, u.phone, u.created, u.last_login_at,
              COALESCE(u.system_locked,false) AS locked, COALESCE(c.inr,0) AS wallet,
              s.id AS staff_id, s.name AS staff_name, s.agent_code AS staff_code
         FROM users u JOIN staff s ON s.id = u.parent_staff_id LEFT JOIN credits c ON c.uid = u.id
        WHERE ${where}
        ORDER BY u.created DESC NULLS LAST, u.id DESC
        LIMIT ${limit} OFFSET ${offset}`, [scope.staffIds, search]),
    q(`SELECT COUNT(*)::int AS total FROM users u WHERE ${where}`, [scope.staffIds, search]),
  ]);
  const stats = await aggregate(scope.staffIds, period, 'user', rows.map(r => r.id));
  res.json({
    status: 'success',
    players: rows.map(r => ({ ...r, wallet: round2(r.wallet), ...(stats.get(r.id) || emptyStats()) })),
    total, page, totalPages: pages(total, limit),
  });
});

// GET /api/branch/players/:id?from&to
exports.player = handle(async (req, res) => {
  const scope = await resolveScope(req);
  const period = readPeriod(req);
  const id = String(req.params.id);
  if (!/^\d+$/.test(id)) fail(400, 'Invalid player id');
  const [p] = await q(
    `SELECT u.id::text AS id, u.name AS username, u.email, u.phone, u.country, u.created, u.last_login_at,
            COALESCE(u.system_locked,false) AS locked, COALESCE(c.inr,0) AS wallet,
            s.id AS staff_id, s.name AS staff_name, s.agent_code AS staff_code
       FROM users u JOIN staff s ON s.id = u.parent_staff_id LEFT JOIN credits c ON c.uid = u.id
      WHERE u.id::text = $2 AND u.parent_staff_id = ANY($1::bigint[])`, [scope.staffIds, id]);
  if (!p) fail(404, 'Player not found');
  const [inPeriod, lifetime] = await Promise.all([
    aggregate(scope.staffIds, period, 'total', [id]),
    aggregate(scope.staffIds, {}, 'total', [id]),
  ]);
  res.json({
    status: 'success',
    period,
    player: { ...p, wallet: round2(p.wallet) },
    stats: inPeriod.get('all') || emptyStats(),
    lifetime: lifetime.get('all') || emptyStats(),
  });
});

// GET /api/branch/transactions?type=deposit|withdraw&status=success|pending|failed
//       &staffId&userId&search&from&to&page&limit
// Every deposit / withdrawal of the scoped players, with totals per status.
exports.transactions = handle(async (req, res) => {
  const scope = await resolveScope(req);
  const period = readPeriod(req);
  const { page, limit, offset } = readPage(req);
  const type = ['deposit', 'withdraw'].includes(req.query.type) ? req.query.type : null;
  const status = ['success', 'pending', 'failed'].includes(req.query.status) ? req.query.status : null;
  const userId = req.query.userId ? String(req.query.userId) : null;
  if (userId && !/^\d+$/.test(userId)) fail(400, 'Invalid userId');
  const search = String(req.query.search || '').trim();

  const s = scopeCte(scope.staffIds, userId ? [userId] : undefined);
  const params = s.params;
  let where = rangeClause('tx.ts', period, params);
  if (type) { params.push(type); where += ` AND tx.type = $${params.length}`; }
  if (search) {
    params.push(search);
    where += ` AND (sc.name ILIKE '%' || $${params.length} || '%' OR tx.ref ILIKE '%' || $${params.length} || '%' OR tx.uid::text LIKE $${params.length} || '%')`;
  }
  const from = `FROM tx JOIN scope sc ON sc.id = tx.uid JOIN staff st ON st.id = sc.parent_staff_id WHERE true ${where}`;

  const totalRows = await q(
    `WITH ${s.sql}, ${TX_CTE}
     SELECT tx.type, tx.status, COUNT(*)::int AS n, COALESCE(SUM(tx.amount),0) AS amount ${from} GROUP BY 1, 2`, params);

  const listParams = [...params];
  let statusSql = '';
  if (status) { listParams.push(status); statusSql = ` AND tx.status = $${listParams.length}`; }
  const rows = await q(
    `WITH ${s.sql}, ${TX_CTE}
     SELECT tx.type, tx.method, tx.ref, tx.uid::text AS user_id, sc.name AS username,
            tx.amount, tx.status, tx.raw_status, tx.ts, st.id AS staff_id, st.name AS staff_name
       ${from}${statusSql}
      ORDER BY tx.ts DESC NULLS LAST, tx.ref DESC LIMIT ${limit} OFFSET ${offset}`, listParams);

  const blank = () => ({ success: { count: 0, amount: 0 }, pending: { count: 0, amount: 0 }, failed: { count: 0, amount: 0 } });
  const totals = { deposit: blank(), withdraw: blank() };
  let total = 0;
  for (const r of totalRows) {
    totals[r.type][r.status] = { count: r.n, amount: round2(r.amount) };
    if (!status || status === r.status) total += r.n;
  }
  res.json({
    status: 'success',
    period,
    transactions: rows.map(r => ({ ...r, amount: round2(r.amount) })),
    totals,
    total, page, totalPages: pages(total, limit),
  });
});

/* Some bet columns carry the literal string "NULL". */
const text = (...vals) => {
  for (const v of vals) {
    const str = v == null ? '' : String(v).trim();
    if (str && str.toLowerCase() !== 'null' && str.toLowerCase() !== 'undefined') return str;
  }
  return '—';
};

// GET /api/branch/bets?kind=sports|casino&staffId&userId&from&to&page&limit
exports.bets = handle(async (req, res) => {
  const scope = await resolveScope(req);
  const period = readPeriod(req);
  const { page, limit, offset } = readPage(req, 50);
  const kind = req.query.kind === 'casino' ? 'casino' : 'sports';
  const userId = req.query.userId ? String(req.query.userId) : null;
  if (userId && !/^\d+$/.test(userId)) fail(400, 'Invalid userId');
  const s = scopeCte(scope.staffIds, userId ? [userId] : undefined);
  const params = s.params;

  if (kind === 'sports') {
    const where = rangeClause('b.created_at', period, params);
    const base = `FROM "SportsBet" b JOIN scope sc ON sc.id = b.user_id WHERE true ${where}`;
    const [[{ n }], rows] = await Promise.all([
      q(`WITH ${s.sql} SELECT COUNT(*)::int AS n ${base}`, params),
      q(`WITH ${s.sql}
         SELECT b.id, b.created_at, b.user_id, sc.name AS user_name, b.match_title, b.event_name,
                b.selection_name, b.fancy_name, b.market_type, b.bet_type, b.odds, b.stake_amount,
                b.status, b.result_status, b.game_type
           ${base}
          ORDER BY b.created_at DESC NULLS LAST, b.id DESC LIMIT ${limit} OFFSET ${offset}`, params),
    ]);
    return res.json({
      status: 'success', kind,
      rows: rows.map(b => ({
        id: String(b.id), ts: b.created_at, user_id: String(b.user_id), user: text(b.user_name, b.user_id),
        match: text(b.match_title, b.event_name),
        selection: text(b.fancy_name, b.selection_name),
        market: text(b.market_type, b.game_type),
        side: text(b.bet_type), odds: num(b.odds), stake: round2(b.stake_amount),
        status: b.status, result: b.result_status || null,
      })),
      total: n, page, totalPages: pages(n, limit),
    });
  }

  const ts = 'COALESCE(g.transaction_datetime, g.created_at)';
  const where = rangeClause(ts, period, params);
  const base = `FROM gis_transactions g JOIN scope sc ON sc.id = g.user_id
                WHERE upper(g.currency) IN ('INR','PKR') ${where}`;
  const [[{ n }], rows] = await Promise.all([
    q(`WITH ${s.sql} SELECT COUNT(*)::int AS n ${base}`, params),
    q(`WITH ${s.sql}
       SELECT g.id, ${ts} AS ts, g.user_id, sc.name AS user_name, g.action, g.amount, g.round_id,
              g.game_uuid, gg.name AS game_name
         FROM gis_transactions g JOIN scope sc ON sc.id = g.user_id
         LEFT JOIN gis_games gg ON gg.uuid = g.game_uuid
        WHERE upper(g.currency) IN ('INR','PKR') ${where}
        ORDER BY ts DESC NULLS LAST, g.id DESC LIMIT ${limit} OFFSET ${offset}`, params),
  ]);
  res.json({
    status: 'success', kind,
    rows: rows.map(t => ({
      id: String(t.id), ts: t.ts, user_id: String(t.user_id), user: text(t.user_name, t.user_id),
      action: t.action, game: text(t.game_name, t.game_uuid), round: t.round_id || null,
      amount: round2(num(t.amount) * (t.action === 'bet' ? -1 : 1)),
    })),
    total: n, page, totalPages: pages(n, limit),
  });
});

exports.SUB_BRANCH_ROLE = SUB_BRANCH_ROLE;
