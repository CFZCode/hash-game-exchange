const pg     = require('../../General/Model');
const bcrypt = require('bcrypt');
const jwt    = require('jsonwebtoken');
const { recordActivity } = require('../utils/recordActivity');
const { isBranchRoleName } = require('../utils/branch');
const { ensureDemoViewSchema } = require('../utils/demoView');

exports.login = async (req,res,next)=>{
  try{
    const { email,password } = req.body;
    console.log('Login attempt with email:', email);
    console.log('Login attempt with password:', password ? password : 'undefined');
    
    if(!email || !password)
      return res.status(400).json({status:'fail',message:'Email and password are required'});
    if(typeof email!=='string' || typeof password!=='string')
      return res.status(400).json({status:'fail',message:'Email and password must be strings'});
    
    await ensureDemoViewSchema();

    // Updated query to get staff info with role + lock flags + first_login
    const { rows } = await pg.query(`
      SELECT
        s.id,
        s.name,
        s.email,
        s.password,
        s.role_id,
        s.system_locked,
        s.first_login,
        s.transaction_password,
        s.demo_view,
        r.name as role_name,
        r.level as role_level,
        r.responsibilities
      FROM staff s
      LEFT JOIN roles r ON s.role_id = r.id
      WHERE s.email = $1
    `, [email]);

    if(!rows.length)
      return res.status(400).json({status:'fail',message:'Bad email'});

    const staff = rows[0];

    if(!(await bcrypt.compare(password, staff.password)))
      return res.status(400).json({status:'fail',message:'Bad password'});

    // Branch admins / sub branches have their own login (POST /api/branch/login)
    if(isBranchRoleName(staff.role_name))
      return res.status(403).json({status:'fail',message:'This account signs in at the branch panel.'});

    // Check system lock on the staff themselves
    if(staff.system_locked)
      return res.status(403).json({status:'fail',message:'Account is system locked. Contact your upline.'});

    // Check if any ancestor in the hierarchy is system_locked
    const { rows: lockedAncestors } = await pg.query(`
      SELECT 1 FROM staff_hierarchy h
      JOIN staff s ON s.id = h.ancestor_id
      WHERE h.descendant_id = $1
        AND h.ancestor_id <> $1
        AND s.system_locked = true
      LIMIT 1
    `, [staff.id]);
    if(lockedAncestors.length)
      return res.status(403).json({status:'fail',message:'Account is locked by an upline administrator.'});

    // Create JWT token with comprehensive user data
    const tokenPayload = {
      id: staff.id,
      name: staff.name,
      email: staff.email,
      role_id: staff.role_id,
      role_name: staff.role_name,
      role_level: staff.role_level,
      ...(staff.demo_view ? { demo_view: true } : {})
    };

    const token = jwt.sign(tokenPayload, process.env.JWT_SECRET, {expiresIn:'2h'});

    // Send response with token and user data + first_login flag
    res.json({
      status:'success',
      token: token,
      firstLogin: staff.first_login,
      hasTransactionPassword: !!staff.transaction_password,
      user: {
        id: staff.id,
        name: staff.name,
        email: staff.email,
        demoView: !!staff.demo_view,
        role: {
          id: staff.role_id,
          name: staff.role_name,
          level: staff.role_level,
          responsibilities: staff.responsibilities
        }
      }
    });

    // Fire-and-forget login activity (req.staff is not set on the login route).
    recordActivity({
      req,
      action: 'login',
      actor: {
        staffId: staff.id, name: staff.name,
        role: staff.role_name, level: staff.role_level,
      },
    });

  }catch(e){
    if(e.code==='23505') return res.status(400).json({status:'fail',message:'Email already exists'});
    if(e.code==='23502') return res.status(400).json({status:'fail',message:'Email and password are required'});
    if(e.code==='23514') return res.status(400).json({status:'fail',message:'Email must be a valid email address'});
    if(e.code==='23503') return res.status(400).json({status:'fail',message:'Invalid email or password'});
    console.error(e);
    next(e);
  }
};

/**
 * POST /api/staff/auth/executive/login
 * Body: { username, password }
 * Executive accounts have no email — they log in by username.
 */
exports.executiveLogin = async (req, res, next) => {
  try {
    const { username, password } = req.body;
    if (!username || !password)
      return res.status(400).json({ status: 'fail', message: 'Username and password are required' });

    const { rows } = await pg.query(
      `SELECT e.id, e.username, e.password, e.status, e.parent_staff_id, e.kind,
              s.id AS parent_id, s.system_locked AS parent_locked,
              r.id AS role_id, r.name AS role_name, r.level AS role_level
         FROM executives e
         JOIN staff s ON s.id = e.parent_staff_id
         LEFT JOIN roles r ON r.id = s.role_id
         WHERE e.username = $1`,
      [username]
    );

    if (!rows.length)
      return res.status(400).json({ status: 'fail', message: 'Bad username' });

    const exec = rows[0];

    if (!(await bcrypt.compare(password, exec.password)))
      return res.status(400).json({ status: 'fail', message: 'Bad password' });

    if (exec.status !== 'active')
      return res.status(403).json({ status: 'fail', message: `Account is ${exec.status}.` });

    if (exec.parent_locked)
      return res.status(403).json({ status: 'fail', message: 'Parent account is locked. Contact your upline.' });

    // Update last_login + ip
    const ip = (req.headers['x-forwarded-for'] || '').split(',')[0]?.trim()
      || req.socket?.remoteAddress || req.ip || null;
    await pg.query(
      `UPDATE executives SET last_login = NOW(), last_login_ip = $1 WHERE id = $2`,
      [ip, exec.id]
    );

    const tokenPayload = {
      id: exec.parent_id,            // ← hierarchy queries operate as the parent
      executive_id: exec.id,
      name: exec.username,
      role_id: exec.role_id,
      role_name: exec.role_name,
      role_level: exec.role_level,
    };

    const token = jwt.sign(tokenPayload, process.env.JWT_SECRET, { expiresIn: '2h' });

    res.json({
      status: 'success',
      token,
      firstLogin: false,
      hasTransactionPassword: true, // executive uses parent's txn pwd
      user: {
        id: exec.id,
        executiveId: exec.id,
        name: exec.username,
        username: exec.username,
        // 'executive' | 'marketing' — the panel uses this to decide which app
        // shell to mount, and to reject a marketing account signing in at the
        // admin login (and vice versa).
        kind: exec.kind || 'executive',
        role: {
          id: exec.role_id,
          name: exec.kind === 'marketing' ? 'Marketing' : 'Executive',
          level: exec.role_level,
        },
      },
    });

    // Fire-and-forget login activity entry (unified admin activity log).
    recordActivity({
      req,
      action: 'login',
      actor: {
        staffId: exec.parent_id, executiveId: exec.id,
        name: exec.username, role: 'Executive', level: exec.role_level,
      },
    });
  } catch (e) {
    console.error('[executiveLogin]', e);
    next(e);
  }
};

/**
 * POST /api/staff/auth/first-login-password
 * Body: { staffId, newPassword }
 * Called after first login to change the default password.
 * Returns the auto-generated 8-digit transaction password.
 */
exports.firstLoginPassword = async (req, res, next) => {
  try {
    const { staffId, newPassword } = req.body;
    if (!staffId || !newPassword)
      return res.status(400).json({ status: 'fail', message: 'staffId and newPassword required' });
    if (newPassword.length < 6)
      return res.status(400).json({ status: 'fail', message: 'Password must be at least 6 characters' });

    // Verify this staff exists and is first_login
    const { rows } = await pg.query('SELECT id, first_login FROM staff WHERE id=$1', [staffId]);
    if (!rows.length)
      return res.status(404).json({ status: 'fail', message: 'Staff not found' });
    if (!rows[0].first_login)
      return res.status(400).json({ status: 'fail', message: 'Not a first login' });

    // Hash new password
    const hash = await bcrypt.hash(newPassword, 10);

    // Generate 8-digit random transaction password
    const txnPwd = String(Math.floor(10000000 + Math.random() * 90000000));

    // Update staff: set new password, transaction_password, mark first_login = false
    await pg.query(
      `UPDATE staff
       SET password = $1, password2 = $2,
           transaction_password = $3,
           first_login = false
       WHERE id = $4`,
      [hash, newPassword, txnPwd, staffId]
    );

    res.json({
      status: 'success',
      transactionPassword: txnPwd,
      message: 'Password changed. Save your transaction password securely.'
    });
  } catch (e) {
    console.error(e);
    next(e);
  }
};

/**
 * POST /api/staff/auth/logout
 * Token is stateless (JWT) so there's nothing to revoke server-side; this
 * endpoint exists purely to record the logout in the activity log. Requires
 * protectStaff so the actor is known.
 */
exports.logout = async (req, res) => {
  recordActivity({ req, action: 'logout' });
  res.json({ status: 'success' });
};