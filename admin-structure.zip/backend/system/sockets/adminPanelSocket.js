// system/sockets/adminPanelSocket.js
// Socket.IO events for admin panel real-time updates
const jwt = require('jsonwebtoken');
const pg = require('../../General/Model');
const { isBranchRoleName } = require('../utils/branch');
const { rollupPnl } = require('../controllers/lordsController');
const { blank } = require('../utils/demoView');

module.exports = function (io) {
  const adminNsp = io.of('/admin-panel');

  adminNsp.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth?.token?.replace('Bearer ', '') || '';
      if (!token) return next(new Error('No token'));

      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      const { rows } = await pg.query(
        `SELECT s.id, s.role_id, r.level, r.name AS db_role
         FROM staff s JOIN roles r ON r.id = s.role_id
         WHERE s.id = $1`, [decoded.id]
      );
      if (!rows.length) return next(new Error('Staff not found'));
      if (isBranchRoleName(rows[0].db_role)) return next(new Error('Auth failed'));
      socket.staff = rows[0];
      // Demo-view staff (superadmindemo): every payload goes out blanked.
      if (decoded.demo_view === true) {
        const emit = socket.emit.bind(socket);
        socket.emit = (event, ...args) => emit(event, ...args.map((a) => blank(a)));
      }
      next();
    } catch (e) {
      next(new Error('Auth failed'));
    }
  });

  adminNsp.on('connection', (socket) => {
    console.log(`[AdminPanel] Staff ${socket.staff.id} connected`);

    // ─── getAdminProfile ──────────────────────────────────────────
    socket.on('getAdminProfile', async () => {
      try {
        const { rows: [staff] } = await pg.query(
          `SELECT s.id, s.name, s.email, r.name AS role, r.level,
                  s.status, s.bet_status, s.percentage,
                  COALESCE(sb.inr, 0) AS balance, sb.exposure_limit
           FROM staff s
           JOIN roles r ON r.id = s.role_id
           LEFT JOIN staff_balances sb ON sb.staff_id = s.id
           WHERE s.id = $1`,
          [socket.staff.id]
        );
        if (staff) {
          // Lifetime P&L rolled up over the downline (read-only, never settled).
          const pnl = await rollupPnl(socket.staff.id);
          staff.sports_pnl = pnl.sports_pnl;
          staff.casino_pnl = pnl.casino_pnl;
        }
        socket.emit('adminProfileUpdate', staff);
      } catch (e) {
        console.error('[AdminPanel] getAdminProfile error', e.message);
      }
    });

    // ─── getUsersAllDetails ───────────────────────────────────────
    let detailsInterval = null;

    socket.on('getUsersAllDetails', async (params) => {
      // Clear previous subscription
      if (detailsInterval) clearInterval(detailsInterval);

      const fetchAndEmit = async () => {
        try {
          const page = Math.max(1, +(params?.page || 1));
          const limit = Math.min(100, +(params?.limit || 25));
          const offset = (page - 1) * limit;
          const search = params?.search || '';
          const parentId = params?.parentId ? Number(params.parentId) : socket.staff.id;

          // Direct children (staff)
          const searchFilter = search.length >= 3
            ? `AND lower(s.name) LIKE '%${search.toLowerCase().replace(/'/g, "''")}%'`
            : '';

          const { rows: staffRows } = await pg.query(
            `SELECT s.id, s.name AS username, r.name AS role, s.status, s.bet_status,
                    s.percentage, s.sports_betlocked AS bet_locked,
                    COALESCE(sb.inr, 0) AS balance,
                    sb.exposure_limit AS exp_limit,
                    'STAFF' AS account_type,
                    (
                      (SELECT COUNT(*) FROM staff_hierarchy sh WHERE sh.ancestor_id = s.id AND sh.depth = 1) +
                      (SELECT COUNT(*) FROM users u2 WHERE u2.parent_staff_id = s.id)
                    ) > 0 AS has_downline
             FROM staff s
             JOIN roles r ON r.id = s.role_id
             LEFT JOIN staff_balances sb ON sb.staff_id = s.id
             JOIN staff_hierarchy h ON h.descendant_id = s.id
             WHERE h.ancestor_id = $1 AND h.depth = 1 ${searchFilter}
             ORDER BY s.id
             LIMIT $2 OFFSET $3`,
            [parentId, limit, offset]
          );

          const userSearchFilter = search.length >= 3
            ? `AND lower(u.name) LIKE '%${search.toLowerCase().replace(/'/g, "''")}%'`
            : '';

          const { rows: userRows } = await pg.query(
            `SELECT u.id, u.name AS username, 'User' AS role, u.status, u.bet_status,
                    0 AS percentage, u.sports_betlocked AS bet_locked,
                    COALESCE(c.inr, 0) AS balance,
                    u.exposure_limit AS exp_limit,
                    -COALESCE(u.gt, 0)        AS sports_pnl,
                    -COALESCE(u.casino_gt, 0) AS casino_pnl,
                    'USER' AS account_type,
                    false AS has_downline,
                    COALESCE((SELECT SUM(ABS(exposure_amount)) FROM user_exposures WHERE user_id = u.id), 0) AS exposure
             FROM users u
             LEFT JOIN credits c ON c.uid = u.id
             WHERE u.parent_staff_id = $1 ${userSearchFilter}
             ORDER BY u.id
             LIMIT $2 OFFSET $3`,
            [parentId, limit, 0]
          );

          // Agents carry no stored P&L — roll it up from their subtree.
          for (const row of staffRows) {
            const pnl = await rollupPnl(row.id);
            row.sports_pnl = pnl.sports_pnl;
            row.casino_pnl = pnl.casino_pnl;
          }

          // Count total
          const { rows: [{ count }] } = await pg.query(
            `SELECT COUNT(*) FROM (
               SELECT s.id FROM staff s
               JOIN staff_hierarchy h ON h.descendant_id = s.id
               WHERE h.ancestor_id = $1 AND h.depth = 1
               UNION ALL
               SELECT u.id FROM users u WHERE u.parent_staff_id = $1
             ) sub`,
            [parentId]
          );

          socket.emit('usersAllDetailsUpdate', {
            users: [...staffRows, ...userRows],
            page,
            limit,
            totalPages: Math.ceil(Number(count) / limit),
            totalCount: Number(count)
          });
        } catch (e) {
          console.error('[AdminPanel] getUsersAllDetails error', e.message);
        }
      };

      // Emit immediately then every 10 seconds
      fetchAndEmit();
      detailsInterval = setInterval(fetchAndEmit, 10000);
    });

    socket.on('stopUsersAllDetails', () => {
      if (detailsInterval) {
        clearInterval(detailsInterval);
        detailsInterval = null;
      }
    });

    socket.on('disconnect', () => {
      if (detailsInterval) clearInterval(detailsInterval);
      console.log(`[AdminPanel] Staff ${socket.staff.id} disconnected`);
    });
  });
};
