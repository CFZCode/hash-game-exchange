-- Fix transfer_type classification
-- Problem: the earlier casino_settlement.sql migration set DEFAULT 'gt',
-- which caused plain balance transfers (written via transferInr without
-- an explicit transfer_type) to be silently tagged as 'gt' and show up
-- as sports GT settlements in reports.
--
-- New classification:
--   'transfer' -> plain balance movement (top-up / withdraw between staff)
--   'gt'       -> sports GT settlement  (via POST /lords/transfer)
--   'casino'   -> casino GT settlement (via POST /lords/casino-transfer)
--
-- Identification rule for legacy rows:
--   - direction IN ('collect','pay')           -> settlement (leave as-is)
--     - already 'casino'  -> casino GT
--     - anything else     -> sports GT ('gt')
--   - everything else (direction IS NULL or 'deposit'/'withdraw')
--     -> plain balance transfer ('transfer')

ALTER TABLE staff_transfers
  ALTER COLUMN transfer_type SET DEFAULT 'transfer';

UPDATE staff_transfers
SET transfer_type = 'transfer'
WHERE transfer_type IS DISTINCT FROM 'casino'
  AND (direction IS NULL OR direction IN ('deposit', 'withdraw'));

UPDATE staff_transfers
SET transfer_type = 'gt'
WHERE transfer_type IS DISTINCT FROM 'casino'
  AND direction IN ('collect', 'pay');
