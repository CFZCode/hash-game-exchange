-- Backfill signup dates for customers registered before `users.created` was
-- being populated.
--
-- Context: the column had no DEFAULT and the registration INSERT never set it,
-- so it was NULL for every pre-existing row. Those customers could not appear
-- in any date-ranged report.
--
-- The real signup dates are NOT recoverable. These timestamps are ESTIMATES,
-- set to 7 days before the backfill ran, per operator instruction. The
-- `created_estimated` flag below is what keeps them distinguishable from
-- genuine signup dates — without it, a fabricated date is indistinguishable
-- from a real one and acquisition charts would silently present invented
-- history as fact.

ALTER TABLE users
  ADD COLUMN IF NOT EXISTS created_estimated BOOLEAN NOT NULL DEFAULT FALSE;

COMMENT ON COLUMN users.created_estimated IS
  'TRUE when users.created is a backfilled estimate, not the real signup date.';

-- Only touch rows that are still NULL, so re-running is safe and never
-- overwrites a genuine timestamp.
UPDATE users
   SET created = NOW() - INTERVAL '7 days',
       created_estimated = TRUE
 WHERE created IS NULL;

CREATE INDEX IF NOT EXISTS idx_users_created_estimated ON users(created_estimated);
