-- Unattempted-deposit detection (apay/paymentservices.js).
-- A Pending deposit whose player never paid (abandoned the payment page) is
-- marked status = 'Unattempted' and the admin is emailed exactly once; this
-- flag is what makes that email idempotent across the return endpoint, the
-- cron sweeper, and clustered pm2 workers.
--
-- Also applied idempotently at boot by ensureUnattemptSchema() — this file is
-- the record for fresh databases built from migrations.

ALTER TABLE public.apaydeposits
    ADD COLUMN IF NOT EXISTS unattempt_notified boolean NOT NULL DEFAULT false;

-- The sweeper polls "Pending, not yet notified, older than N minutes" every
-- 5 minutes; partial index keeps that scan off the historical rows.
CREATE INDEX IF NOT EXISTS idx_apaydeposits_pending_sweep
    ON public.apaydeposits (created_at)
    WHERE status = 'Pending' AND unattempt_notified = false;
