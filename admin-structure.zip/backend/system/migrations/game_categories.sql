-- Game category tables (Live Casino, Popular Slots, Crash Games)
-- Mirrors the schema of hot_games

CREATE TABLE IF NOT EXISTS live_casino (
  key        TEXT PRIMARY KEY,
  game_uuids TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS popular_slots (
  key        TEXT PRIMARY KEY,
  game_uuids TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS crash_games (
  key        TEXT PRIMARY KEY,
  game_uuids TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
