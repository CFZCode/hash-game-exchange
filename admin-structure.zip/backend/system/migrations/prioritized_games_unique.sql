-- Make vendor unique so admin upserts can use ON CONFLICT (vendor)
ALTER TABLE prioritized_games
  ADD CONSTRAINT prioritized_games_vendor_uniq UNIQUE (vendor);
