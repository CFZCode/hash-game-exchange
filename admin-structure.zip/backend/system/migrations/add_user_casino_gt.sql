-- Add persisted users.casino_gt column to mirror users.gt (sports).
-- Backfill from existing gis_transactions so historical net P&L is preserved.
-- Idempotent: safe to re-run.

ALTER TABLE users
  ADD COLUMN IF NOT EXISTS casino_gt numeric DEFAULT 0;

UPDATE users u
SET casino_gt = COALESCE(t.net, 0)
FROM (
  SELECT user_id,
         SUM(CASE WHEN action IN ('win','refund') THEN amount ELSE 0 END)
       - SUM(CASE WHEN action = 'bet'             THEN amount ELSE 0 END) AS net
  FROM gis_transactions
  WHERE currency = 'INR'
  GROUP BY user_id
) t
WHERE u.id = t.user_id
  AND u.casino_gt = 0;
