-- ─────────────────────────────────────────────────────────────────
-- Admin Activity Log (generalized)
-- Append-only audit trail for EVERY admin-panel action, performed by
-- any actor in the hierarchy: SuperAdmin, agents at every level, and
-- Executives. Supersedes the executive-only executive_activity_logs.
--
-- Run once: psql ... -f admin_activity_logs.sql
-- ─────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS admin_activity_logs (
  id              BIGSERIAL    PRIMARY KEY,
  -- Who performed the action. staff_id is always set (for an executive it
  -- points to the parent staff the executive operates as); executive_id is
  -- set only when the actor logged in as an executive.
  staff_id        INTEGER      NOT NULL REFERENCES staff(id) ON DELETE CASCADE,
  executive_id    INTEGER      REFERENCES executives(id) ON DELETE SET NULL,
  -- Snapshot of the actor at action time (survives later renames/deletes).
  actor_name      VARCHAR(120),
  actor_role      VARCHAR(50),                  -- e.g. SuperAdmin, Agent, Executive
  actor_level     INTEGER,                      -- role hierarchy level (0 = SuperAdmin)

  action          VARCHAR(80)  NOT NULL,        -- dotted key, e.g. user.create, settle.sports
  target_type     VARCHAR(40),                  -- USER | STAFF | EXECUTIVE | MARKET ...
  target_id       VARCHAR(60),
  details         JSONB,                        -- free-form action context

  ip              VARCHAR(64),
  country         VARCHAR(80),
  region          VARCHAR(80),
  city            VARCHAR(120),
  user_agent      VARCHAR(512),

  status          VARCHAR(10)  NOT NULL DEFAULT 'success'
                    CHECK (status IN ('success','failed')),
  error_message   VARCHAR(512),
  created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- Hierarchy-scoped reads filter by staff_id; per-executive reads by executive_id.
CREATE INDEX IF NOT EXISTS idx_admin_activity_staff_created
  ON admin_activity_logs(staff_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_admin_activity_executive_created
  ON admin_activity_logs(executive_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_admin_activity_action
  ON admin_activity_logs(action);
CREATE INDEX IF NOT EXISTS idx_admin_activity_created
  ON admin_activity_logs(created_at DESC);

-- Backfill from the legacy executive-only table if it exists, so historical
-- executive activity remains visible in the unified log. Idempotent-ish:
-- only runs when the new table is still empty.
DO $$
BEGIN
  IF to_regclass('public.executive_activity_logs') IS NOT NULL
     AND NOT EXISTS (SELECT 1 FROM admin_activity_logs LIMIT 1) THEN
    INSERT INTO admin_activity_logs
      (staff_id, executive_id, actor_name, actor_role, action,
       target_type, target_id, details, ip, user_agent, status, error_message, created_at)
    SELECT e.parent_staff_id, l.executive_id, e.username, 'Executive', l.action,
           l.target_type, l.target_id, l.details, l.ip, l.user_agent, l.status,
           l.error_message, l.created_at
      FROM executive_activity_logs l
      JOIN executives e ON e.id = l.executive_id;
  END IF;
END $$;
