-- Add stored gt column to users table
-- gt accumulates signed P/L from sports settlement (+ on win, - on loss)
-- and is decremented toward 0 by admin-management/transfer payouts.

ALTER TABLE users
  ADD COLUMN IF NOT EXISTS gt NUMERIC DEFAULT 0;

UPDATE users
   SET gt = COALESCE(net_win, 0) - COALESCE(net_loss, 0)
 WHERE gt IS NULL OR gt = 0;
