-- Marketing panel — read-only analytics accounts.
--
-- A marketing user is an `executives` row with kind = 'marketing'. It reuses the
-- existing executive auth path (POST /api/staff/auth/executive/login) and the
-- same bcrypt password + status/lock handling; the `kind` column is what keeps
-- marketing accounts out of the Access Management executive list and what
-- protectMarketing checks before serving analytics.

ALTER TABLE executives
  ADD COLUMN IF NOT EXISTS kind VARCHAR(20) NOT NULL DEFAULT 'executive';

-- Existing rows are all classic executives; the DEFAULT above already covers
-- them, but be explicit so a re-run over a partially-migrated table is safe.
UPDATE executives SET kind = 'executive' WHERE kind IS NULL;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'executives_kind_check'
  ) THEN
    ALTER TABLE executives
      ADD CONSTRAINT executives_kind_check CHECK (kind IN ('executive', 'marketing'));
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_executives_kind ON executives(kind);

-- ── users.created ────────────────────────────────────────────────
-- This column had no DEFAULT and the registration INSERT never set it, so it
-- was NULL for every row. Any report filtering on signup date therefore read
-- as zero (including the admin dashboard's "new users today"). Rule.js now
-- passes NOW() explicitly; the DEFAULT below covers every other insert path.
--
-- Historical rows are left NULL on purpose: the true signup date is not
-- recoverable, and backfilling a fabricated timestamp would put invented data
-- into acquisition charts. The analytics endpoints report the NULL count
-- separately so the gap is visible rather than silently rolled into totals.
ALTER TABLE users ALTER COLUMN created SET DEFAULT NOW();

-- Signup-date range scans back every acquisition query.
CREATE INDEX IF NOT EXISTS idx_users_created ON users(created);
CREATE INDEX IF NOT EXISTS idx_users_parent_staff_id ON users(parent_staff_id);
