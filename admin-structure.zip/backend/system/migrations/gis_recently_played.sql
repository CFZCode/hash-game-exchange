-- Per-user recently-played game tracking (capped at 15 rows per user by controller)
-- Written by gis/controller.js initGame and read by getRecentlyPlayed.

CREATE TABLE IF NOT EXISTS gis_recently_played (
  id         SERIAL PRIMARY KEY,
  user_id    BIGINT NOT NULL,
  game_uuid  TEXT   NOT NULL,
  played_at  TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS gis_recently_played_user_game_uniq
  ON gis_recently_played (user_id, game_uuid);

CREATE INDEX IF NOT EXISTS gis_recently_played_user_played_idx
  ON gis_recently_played (user_id, played_at DESC);
