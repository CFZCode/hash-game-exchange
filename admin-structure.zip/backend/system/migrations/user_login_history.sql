-- Track per-login IP/UA history for the user-risk admin tab.
-- Idempotent: safe to re-run.

CREATE TABLE IF NOT EXISTS user_login_history (
  id          bigserial   PRIMARY KEY,
  user_id     bigint      NOT NULL,
  ip_address  text,
  user_agent  text,
  created_at  timestamp   NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_user_login_history_user_created
  ON user_login_history (user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_user_login_history_user_ip
  ON user_login_history (user_id, ip_address);

ALTER TABLE users
  ADD COLUMN IF NOT EXISTS last_ip        text,
  ADD COLUMN IF NOT EXISTS last_login_at  timestamp;
