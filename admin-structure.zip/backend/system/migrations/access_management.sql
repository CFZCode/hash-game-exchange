-- ─────────────────────────────────────────────────────────────────
-- Access Management
-- Run once: psql ... -f access_management.sql
-- ─────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS executives (
  id                    SERIAL       PRIMARY KEY,
  username              VARCHAR(100) NOT NULL UNIQUE,
  password              VARCHAR(255) NOT NULL,             -- bcrypt hash
  parent_staff_id       INTEGER      NOT NULL REFERENCES staff(id) ON DELETE CASCADE,
  parent_role_snapshot  VARCHAR(50),                       -- role name at create time
  permissions           JSONB        NOT NULL,             -- { groups, pages, authority }
  status                VARCHAR(20)  NOT NULL DEFAULT 'active'
                          CHECK (status IN ('active','inactive','locked')),
  last_login            TIMESTAMPTZ,
  last_login_ip         VARCHAR(64),
  created_at            TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_executives_parent_staff_id ON executives(parent_staff_id);
CREATE INDEX IF NOT EXISTS idx_executives_username        ON executives(username);

CREATE TABLE IF NOT EXISTS executive_activity_logs (
  id              SERIAL       PRIMARY KEY,
  executive_id    INTEGER      NOT NULL REFERENCES executives(id) ON DELETE CASCADE,
  action          VARCHAR(80)  NOT NULL,                   -- e.g. transfer.credit, settle.casino
  target_type     VARCHAR(40),
  target_id       VARCHAR(40),
  details         JSONB,
  ip              VARCHAR(64),
  user_agent      VARCHAR(512),
  status          VARCHAR(10)  NOT NULL DEFAULT 'success'
                    CHECK (status IN ('success','failed')),
  error_message   VARCHAR(512),
  created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_exec_activity_executive_created
  ON executive_activity_logs(executive_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_exec_activity_action
  ON executive_activity_logs(action);

-- Maintain updated_at on executives
CREATE OR REPLACE FUNCTION executives_set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS executives_updated_at ON executives;
CREATE TRIGGER executives_updated_at
  BEFORE UPDATE ON executives
  FOR EACH ROW EXECUTE FUNCTION executives_set_updated_at();
