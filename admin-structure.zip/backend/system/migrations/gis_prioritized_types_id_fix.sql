-- Repair gis_prioritized_types.id: ensure the SERIAL sequence exists,
-- is attached as the column default, owned by the column, and bumped
-- past any rows already in the table. Safe to run repeatedly.

CREATE SEQUENCE IF NOT EXISTS gis_prioritized_types_id_seq;

ALTER TABLE gis_prioritized_types
  ALTER COLUMN id SET DEFAULT nextval('gis_prioritized_types_id_seq');

ALTER SEQUENCE gis_prioritized_types_id_seq
  OWNED BY gis_prioritized_types.id;

SELECT setval(
  'gis_prioritized_types_id_seq',
  GREATEST(COALESCE((SELECT MAX(id) FROM gis_prioritized_types), 0), 1)
);

-- Drop the broken UNIQUE ("") constraint if a partial pg_dump reload created it.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_constraint
     WHERE conname = 'gis_prioritized_types_type_uniq'
       AND contype = 'u'
  ) THEN
    ALTER TABLE gis_prioritized_types
      DROP CONSTRAINT gis_prioritized_types_type_uniq;
  END IF;
END$$;

-- Collapse any case/whitespace duplicates before the unique index is created,
-- keeping the most recently updated row for each normalized type.
DELETE FROM gis_prioritized_types a
 USING gis_prioritized_types b
 WHERE LOWER(TRIM(a.type)) = LOWER(TRIM(b.type))
   AND (a.updated_at < b.updated_at
        OR (a.updated_at = b.updated_at AND a.id < b.id));

CREATE UNIQUE INDEX IF NOT EXISTS gis_prioritized_types_type_uniq
  ON gis_prioritized_types (LOWER(TRIM(type)));
