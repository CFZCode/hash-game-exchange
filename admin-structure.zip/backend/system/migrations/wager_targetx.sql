-- Wager target / lock columns used by /api/deposits/admin/all-wagers
-- and the TurnoverReport admin page. Idempotent.

ALTER TABLE users
  ADD COLUMN IF NOT EXISTS wager_multiplier numeric DEFAULT 3,
  ADD COLUMN IF NOT EXISTS lock_targetx     boolean DEFAULT false;

CREATE TABLE IF NOT EXISTS userwager (
  uid    bigint PRIMARY KEY,
  wager  numeric DEFAULT 0
);
