-- Per-user UI/notification preferences. Read by configSocket on identify,
-- written by /siteconfig admin endpoints.

CREATE TABLE IF NOT EXISTS userconfig (
  uid                 bigint      NOT NULL,
  email_notifications boolean     DEFAULT true,
  push_notifications  boolean     DEFAULT true,
  theme               text        DEFAULT 'dark',
  language            text        DEFAULT 'en',
  hide_balance        boolean     DEFAULT false,
  updatedat           timestamptz,
  CONSTRAINT userconfig_pkey PRIMARY KEY (uid),
  CONSTRAINT userconfig_uid_fkey FOREIGN KEY (uid)
    REFERENCES users(id) ON UPDATE CASCADE ON DELETE CASCADE
);
