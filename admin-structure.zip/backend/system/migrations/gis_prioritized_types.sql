-- Per-type game priority (mirrors gis_prioritized_games, keyed on type)
-- gisgamesnew.type values are stored mixed-case with occasional whitespace,
-- so we trim/lower for the unique key.

CREATE TABLE IF NOT EXISTS gis_prioritized_types (
  id          SERIAL PRIMARY KEY,
  type        TEXT NOT NULL,
  game_ids    TEXT NOT NULL,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE UNIQUE INDEX IF NOT EXISTS gis_prioritized_types_type_uniq
  ON gis_prioritized_types (LOWER(TRIM(type)));
