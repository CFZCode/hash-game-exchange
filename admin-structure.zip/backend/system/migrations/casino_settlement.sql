-- Casino Settlement Migration
-- Run once to add casino GT tracking columns

ALTER TABLE staff_balances
  ADD COLUMN IF NOT EXISTS casino_gt NUMERIC DEFAULT 0;

ALTER TABLE staff_transfers
  ADD COLUMN IF NOT EXISTS transfer_type VARCHAR(20) DEFAULT 'gt';

-- Index for faster casino transfer statement queries
CREATE INDEX IF NOT EXISTS idx_staff_transfers_type
  ON staff_transfers (transfer_type);
