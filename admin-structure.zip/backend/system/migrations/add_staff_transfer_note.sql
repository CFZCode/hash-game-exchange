-- Adds an optional free-text reference/note to wallet transfers.
-- Used by the Staff Portal "quick refill" so staff can record WHO requested
-- the top-up ("who gave the shout"), and shown in the per-user balance sheet.
ALTER TABLE staff_transfers ADD COLUMN IF NOT EXISTS note text;
