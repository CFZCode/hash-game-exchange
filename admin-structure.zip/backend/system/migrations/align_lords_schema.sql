-- Align myapp1 schema with lordsController expectations.
-- Idempotent: safe to re-run.

ALTER TABLE staff
  ADD COLUMN IF NOT EXISTS status            text    DEFAULT 'active',
  ADD COLUMN IF NOT EXISTS bet_status        text    DEFAULT 'active',
  ADD COLUMN IF NOT EXISTS sports_betlocked  boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS casino_locked     boolean DEFAULT false;

ALTER TABLE users
  ADD COLUMN IF NOT EXISTS status            text    DEFAULT 'active',
  ADD COLUMN IF NOT EXISTS bet_status        text    DEFAULT 'active',
  ADD COLUMN IF NOT EXISTS sports_betlocked  boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS casino_locked     boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS system_locked     boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS gt                numeric DEFAULT 0,
  ADD COLUMN IF NOT EXISTS exposure_limit    numeric DEFAULT 0;

ALTER TABLE staff_balances
  ADD COLUMN IF NOT EXISTS credit_limit      numeric DEFAULT 0,
  ADD COLUMN IF NOT EXISTS exposure_limit    numeric DEFAULT 0,
  ADD COLUMN IF NOT EXISTS gt                numeric DEFAULT 0,
  ADD COLUMN IF NOT EXISTS casino_gt         numeric DEFAULT 0;

ALTER TABLE staff_transfers
  ADD COLUMN IF NOT EXISTS transfer_type     varchar(20) DEFAULT 'transfer';

CREATE INDEX IF NOT EXISTS idx_staff_transfers_type
  ON staff_transfers (transfer_type);
