-- ═══════════════════════════════════════════════════════════════════════════
--  CASH WALLET MODEL — remove credit limits and GT settlement
-- ═══════════════════════════════════════════════════════════════════════════
--
--  Before: agents handed out a *credit limit*; users bet on it; net P&L piled up
--          in users.gt / users.casino_gt; agents then "settled" that GT by moving
--          real INR again (POST /lords/transfer, /lords/casino-transfer).
--
--  After:  one real INR wallet per account, moved only by deposit / withdraw of
--          actual amounts. GT survives ONLY as a read-only lifetime P&L figure:
--            users.gt        = lifetime sports profit/loss
--            users.casino_gt = lifetime casino profit/loss
--          An agent's P&L is COMPUTED as the sum over its subtree — so the stored
--          staff_balances.gt / casino_gt columns are dropped.
--
--  ⚠ THIS MUTATES MONEY-ADJACENT DATA. Review, run against a restored dump first,
--    then run in production inside the transaction below.
--
--  Idempotent: safe to re-run (drops use IF EXISTS, snapshot is keyed by run).
-- ═══════════════════════════════════════════════════════════════════════════

BEGIN;

-- ───────────────────────────────────────────────────────────────────────────
-- 1. SNAPSHOT — preserve every value we are about to change or drop.
--    Nothing is lost: a pre-migration report stays reproducible forever.
-- ───────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS legacy_credit_gt_snapshot (
  id            bigserial PRIMARY KEY,
  taken_at      timestamptz NOT NULL DEFAULT now(),
  account_type  text        NOT NULL,          -- 'staff' | 'user'
  account_id    bigint      NOT NULL,
  inr           numeric,                       -- balance at cutover (unchanged by this script)
  credit_limit  numeric,                       -- dropped column
  gt            numeric,                       -- pre-recompute sports GT
  casino_gt     numeric                        -- pre-recompute casino GT
);

CREATE INDEX IF NOT EXISTS idx_legacy_snapshot_account
  ON legacy_credit_gt_snapshot (account_type, account_id);

INSERT INTO legacy_credit_gt_snapshot (account_type, account_id, inr, credit_limit, gt, casino_gt)
SELECT 'staff', sb.staff_id, sb.inr, sb.credit_limit, sb.gt, sb.casino_gt
  FROM staff_balances sb;

INSERT INTO legacy_credit_gt_snapshot (account_type, account_id, inr, credit_limit, gt, casino_gt)
SELECT 'user', u.id, c.inr, NULL, u.gt, u.casino_gt
  FROM users u
  LEFT JOIN credits c ON c.uid = u.id;


-- ───────────────────────────────────────────────────────────────────────────
-- 2. RECOMPUTE users.gt = LIFETIME sports P&L.
--
--    The old GT settlements decremented gt toward zero, so for any account that
--    was ever settled the live value is NOT lifetime P&L. credits_ledger is the
--    authoritative per-bet record (voidaftersettlement DELETEs its rows, so it
--    self-corrects on voids) — rebuild from it.
--
--    Users with no ledger rows are reset to 0 rather than left stale.
-- ───────────────────────────────────────────────────────────────────────────
UPDATE users u
   SET gt = COALESCE(l.net, 0)
  FROM (
        SELECT u2.id AS user_id,
               (SELECT SUM(cl.netamount)
                  FROM credits_ledger cl
                 WHERE cl.user_id = u2.id) AS net
          FROM users u2
       ) l
 WHERE u.id = l.user_id
   AND COALESCE(u.gt, 0) IS DISTINCT FROM COALESCE(l.net, 0);


-- ───────────────────────────────────────────────────────────────────────────
-- 3. RECOMPUTE users.casino_gt = LIFETIME casino P&L.
--    Same reasoning: casinoTransfer decremented it toward zero.
--    Source of truth is gis_transactions (INR + PKR, the settled fiat currencies).
-- ───────────────────────────────────────────────────────────────────────────
UPDATE users u
   SET casino_gt = COALESCE(t.net, 0)
  FROM (
        SELECT u2.id AS user_id,
               (SELECT SUM(CASE WHEN g.action IN ('win','refund') THEN  g.amount
                                WHEN g.action  = 'bet'            THEN -g.amount
                                ELSE 0 END)
                  FROM gis_transactions g
                 WHERE g.user_id = u2.id
                   AND upper(g.currency) IN ('INR','PKR')) AS net
          FROM users u2
       ) t
 WHERE u.id = t.user_id
   AND COALESCE(u.casino_gt, 0) IS DISTINCT FROM COALESCE(t.net, 0);


-- ───────────────────────────────────────────────────────────────────────────
-- 4. DROP the credit-limit layer and the stored staff GT columns.
--    Agent P&L is now computed from the hierarchy, so a stored column could only
--    ever go stale and lie in a report.
-- ───────────────────────────────────────────────────────────────────────────
ALTER TABLE staff_balances
  DROP COLUMN IF EXISTS credit_limit,
  DROP COLUMN IF EXISTS gt,
  DROP COLUMN IF EXISTS casino_gt;


-- ───────────────────────────────────────────────────────────────────────────
-- 5. Historical staff_transfers rows tagged 'gt' / 'casino' are LEFT AS-IS —
--    they are a real record of money that moved. No new rows of those types are
--    written after this migration; balancesheet already filters to 'transfer'.
--    Index the remaining hot path.
-- ───────────────────────────────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_staff_transfers_direction
  ON staff_transfers (direction);

COMMIT;


-- ═══════════════════════════════════════════════════════════════════════════
--  POST-RUN SPOT CHECKS (run manually; each should return zero problem rows)
-- ═══════════════════════════════════════════════════════════════════════════
--
-- a) No balance was touched by this migration:
--      SELECT s.account_id, s.inr AS before_inr, c.inr AS after_inr
--        FROM legacy_credit_gt_snapshot s
--        JOIN credits c ON c.uid = s.account_id
--       WHERE s.account_type = 'user'
--         AND COALESCE(s.inr,0) IS DISTINCT FROM COALESCE(c.inr,0);
--
-- b) An agent's rolled-up sports P&L matches its downline (replace :agent_id):
--      SELECT COALESCE(SUM(u.gt),0) AS sports_pl,
--             COALESCE(SUM(u.casino_gt),0) AS casino_pl
--        FROM users u
--        JOIN staff_hierarchy h ON h.descendant_id = u.parent_staff_id
--       WHERE h.ancestor_id = :agent_id;
--
-- c) How much GT was written off by the recompute (informational):
--      SELECT SUM(u.gt - s.gt) AS sports_delta,
--             SUM(u.casino_gt - s.casino_gt) AS casino_delta
--        FROM legacy_credit_gt_snapshot s
--        JOIN users u ON u.id = s.account_id
--       WHERE s.account_type = 'user';
