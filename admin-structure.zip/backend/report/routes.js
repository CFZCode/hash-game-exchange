// routes/report.js — agent settlement report (PDF) + account statement (JSON)
const router = require('express').Router();
const { protectStaff } = require('../system/middleware/auth');
const ctrl = require('./controller');
const statement = require('./statement');
const statementPdf = require('./statementPdf');

// Any authenticated staff member may pull a report for themselves or for an
// agent in their own downline (each handler enforces the hierarchy check).

// On-screen "hisab": opening/closing balance, every deposit & withdrawal with a
// running balance, and the sports/casino profit or loss for the range.
// The literal `/user/` prefix must be declared before the `/:staffId` patterns.
router.get('/user/:userId/statement', protectStaff, statement.getUserStatement);
router.get('/:staffId/statement', protectStaff, statement.getAgentStatement);

// Individual sports bets / casino transactions behind the statement's totals.
// Paginated server-side: a busy tree runs to tens of thousands of rows.
router.get('/user/:userId/bets', protectStaff, statement.getBets);
router.get('/:staffId/bets', protectStaff, statement.getBets);

// Printable form of the statement above — same builder, so print and screen can
// never disagree. Available for players as well as agents.
router.get('/user/:userId/pdf', protectStaff, statementPdf.generateUserStatementPdf);
router.get('/:staffId/pdf', protectStaff, statementPdf.generateAgentStatementPdf);

// Downloadable PDF of the same period.
router.get('/:staffId', protectStaff, ctrl.generateAgentReport);

module.exports = router;
