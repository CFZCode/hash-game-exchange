/* ──────────────────────────────────────────────────────────────────────────
   ACCOUNT STATEMENT  ("hisab")  — JSON

   The on-screen counterpart of the PDF settlement report. Answers the plain
   question every account holder asks: "what did I have, what was done, what did
   the betting do, and what do I have now?"

   GET /api/admin/agent-report/:staffId/statement        -> an agent + its downline
   GET /api/admin/agent-report/user/:userId/statement    -> a single player

     ?from=YYYY-MM-DD &to=YYYY-MM-DD   period (both optional = all time)
     &page= &limit=                    paginate the ledger rows
     &category=all|money|sports|casino filter which rows are listed

   Individual bets and casino transactions are NOT here — they are unbounded,
   so they live on the paginated /bets endpoint below.

   Both shapes are identical so one screen renders either.

   ── THE LEDGER ────────────────────────────────────────────────────────────
   For an AGENT, rows come from `staff_transfers` only — the deposits and
   withdrawals actually performed. Casino/sports play never touches an agent's
   own wallet, so it is reported as profit/loss, not as movement.

   For a PLAYER, rows come from every source that moves the wallet: agent
   deposits/withdrawals, bank + gateway deposits/withdrawals, sports settlement
   and casino bets/wins.

   Running balance is ANCHORED ON THE LIVE WALLET and derived backwards:

       closing  = live_balance − (movements after the period)
       opening  = closing − (movements inside the period)
       row.balance = opening + running sum

   so the last row of an up-to-date period always equals the real wallet. Any
   historical drift (legacy GT settlements, sports settlements that credited a
   parent staff wallet directly) lands in the opening "brought forward" figure
   rather than silently skewing every row — and `balance.unexplained` reports
   that lifetime drift so it stays visible.

   ── SIGNS ─────────────────────────────────────────────────────────────────
       player_pnl  + = the player won
       agent_pnl   + = the agent earned          (agent_pnl = −player_pnl)
   `headline_pnl` is whichever of the two the subject actually keeps, so the
   screen can say "TOTAL PROFIT" / "TOTAL LOSS" without the caller guessing.
   ────────────────────────────────────────────────────────────────────────── */
const pg = require('../General/Model');

const num = (v) => { const n = Number(v); return Number.isFinite(n) ? n : 0; };
const round2 = (n) => Math.round((num(n)) * 100) / 100;
const isDate = (s) => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s);
const cleanDate = (s) => (isDate(s) ? s : null);
const ymd = (d) => new Date(d).toISOString().slice(0, 10);

async function q(sql, params) { return (await pg.query(sql, params)).rows; }

/* Append a date filter on `col` and push the params. Mirrors report/controller.js
   so the PDF and this screen always cover exactly the same window. */
function dateClause(col, from, to, params) {
  let sql = '';
  if (from) { params.push(from); sql += ` AND ${col} >= $${params.length}::date`; }
  if (to) { params.push(to); sql += ` AND ${col} < ($${params.length}::date + INTERVAL '1 day')`; }
  return sql;
}

/** Where a timestamp sits relative to the window: -1 before, 0 inside, 1 after. */
function place(ts, from, to) {
  const d = ymd(ts);
  if (from && d < from) return -1;
  if (to && d > to) return 1;
  return 0;
}

const CATEGORIES = new Set(['all', 'money', 'sports', 'casino']);
const KIND_CATEGORY = {
  DEPOSIT_UPLINE: 'money', WITHDRAW_UPLINE: 'money',
  DEPOSIT_AGENT: 'money', COLLECTED_AGENT: 'money',
  DEPOSIT_PLAYER: 'money', COLLECTED_PLAYER: 'money',
  BANK_DEPOSIT: 'money', GATEWAY_DEPOSIT: 'money',
  BANK_WITHDRAW: 'money', GATEWAY_WITHDRAW: 'money',
  SPORTS: 'sports', CASINO: 'casino',
};

/* Turn a chronological event list into paginated rows carrying a running balance
   anchored on the live wallet. Events must already be sorted oldest-first and
   carry { ts, kind, label, party, note, amount }. */
function buildLedger(events, live, from, to, { page, limit, category }) {
  let lifetimeNet = 0, afterEndNet = 0, periodNet = 0;
  const inside = [];
  for (const e of events) {
    lifetimeNet += e.amount;
    const p = place(e.ts, from, to);
    if (p > 0) { afterEndNet += e.amount; continue; }
    if (p < 0) continue;
    periodNet += e.amount;
    inside.push(e);
  }

  const closing = round2(live - afterEndNet);
  const opening = round2(closing - periodNet);

  let run = opening;
  for (const e of inside) {
    e.amount = round2(e.amount);
    run += e.amount;
    e.balance = round2(run);
    e.direction = e.amount >= 0 ? 'IN' : 'OUT';
  }

  const visible = category === 'all'
    ? inside
    : inside.filter(e => KIND_CATEGORY[e.kind] === category);

  const ordered = visible.slice().reverse();   // newest first for display
  const total = ordered.length;
  return {
    opening, closing, movement: round2(periodNet),
    lifetimeNet: round2(lifetimeNet),
    inside,
    rows: ordered.slice((page - 1) * limit, (page - 1) * limit + limit),
    pagination: { page, limit, total, pages: Math.max(1, Math.ceil(total / limit)) },
  };
}

/* Day-by-day roll-up of money movement, filled in later with gaming P&L. */
function dailyFromEvents(events) {
  const map = new Map();
  const day = (d) => {
    if (!map.has(d)) map.set(d, { date: d, deposit: 0, withdraw: 0, sports_pnl: 0, casino_pnl: 0 });
    return map.get(d);
  };
  for (const e of events) {
    if (KIND_CATEGORY[e.kind] !== 'money') continue;
    const d = day(ymd(e.ts));
    if (e.amount >= 0) d.deposit += e.amount; else d.withdraw += -e.amount;
  }
  return { map, day };
}

function finishDaily(map) {
  return [...map.values()]
    .map(d => ({
      ...d,
      deposit: round2(d.deposit), withdraw: round2(d.withdraw),
      sports_pnl: round2(d.sports_pnl), casino_pnl: round2(d.casino_pnl),
      net: round2(d.deposit - d.withdraw),
    }))
    .sort((a, b) => (a.date < b.date ? 1 : -1));
}

/* Shared query-string handling. */
function readQuery(req) {
  const from = cleanDate(req.query.from);
  const to = cleanDate(req.query.to);
  const category = CATEGORIES.has(req.query.category) ? req.query.category : 'all';
  return {
    from, to, category,
    page: Math.max(1, parseInt(req.query.page, 10) || 1),
    limit: Math.min(500, Math.max(10, parseInt(req.query.limit, 10) || 100)),
    bad: from && to && from > to,
  };
}

/* ══════════════════════════════════════════════════════════════════════════
   AGENT (staff) STATEMENT
   ══════════════════════════════════════════════════════════════════════════ */

/* Label one staff_transfers row from the agent's point of view. `sub` is the set
   of staff ids at or below the agent, so money moving to a downline agent reads
   as "deposit to downline" rather than a generic transfer. */
function classifyStaffRow(t, staffId, sub) {
  const incoming = t.to_type === 'staff' && String(t.to_id) === String(staffId);
  if (incoming) {
    if (t.from_type === 'user') return { kind: 'COLLECTED_PLAYER', label: 'Withdraw from player', party: t.from_name };
    if (sub.has(String(t.from_id))) return { kind: 'COLLECTED_AGENT', label: 'Withdraw from downline', party: t.from_name };
    return { kind: 'DEPOSIT_UPLINE', label: 'Deposit received from upline', party: t.from_name };
  }
  if (t.to_type === 'user') return { kind: 'DEPOSIT_PLAYER', label: 'Deposit to player', party: t.to_name };
  if (sub.has(String(t.to_id))) return { kind: 'DEPOSIT_AGENT', label: 'Deposit to downline', party: t.to_name };
  return { kind: 'WITHDRAW_UPLINE', label: 'Withdrawn by upline', party: t.to_name };
}

/* Build the agent payload. Returns { error: { code, message } } instead of
   touching the response, so the PDF renderer can reuse it verbatim and the two
   outputs can never drift apart. */
async function buildAgentStatement(staffIdRaw, opt, callerId) {
    const staffId = Number(staffIdRaw);
    if (!Number.isInteger(staffId)) return { error: { code: 400, message: 'Invalid staff id' } };
    if (opt.bad) return { error: { code: 400, message: 'from must not be after to' } };
    const { from, to } = opt;

    // Same rule as the PDF: yourself, or somebody inside your hierarchy.
    if (staffId !== callerId) {
      const ok = await q('SELECT 1 FROM staff_hierarchy WHERE ancestor_id=$1 AND descendant_id=$2', [callerId, staffId]);
      if (!ok.length) return { error: { code: 403, message: 'Agent is not in your hierarchy' } };
    }

    const [agent] = await q(`
      SELECT s.id, s.name, s.email, s.agent_code,
             r.name role, r.level, COALESCE(b.inr,0) balance, ps.name parent_name
      FROM staff s
      JOIN roles r ON r.id = s.role_id
      LEFT JOIN staff_balances b ON b.staff_id = s.id
      LEFT JOIN staff ps ON ps.id = s.parent_id
      WHERE s.id = $1`, [staffId]);
    if (!agent) return { error: { code: 404, message: 'Agent not found' } };

    /* ---- subtree ---- */
    const staffTree = await q(`
      SELECT h.depth, s.id, s.name, r.name role, COALESCE(b.inr,0) balance
      FROM staff_hierarchy h
      JOIN staff s ON s.id = h.descendant_id
      JOIN roles r ON r.id = s.role_id
      LEFT JOIN staff_balances b ON b.staff_id = s.id
      WHERE h.ancestor_id = $1
      ORDER BY h.depth, s.id`, [staffId]);
    const staffIds = staffTree.map(s => s.id);
    const sub = new Set(staffIds.map(String));

    const players = await q(`
      SELECT u.id, u.name, u.parent_staff_id, COALESCE(c.inr,0) wallet, ps.name staff_name
      FROM users u
      LEFT JOIN credits c ON c.uid = u.id
      LEFT JOIN staff ps ON ps.id = u.parent_staff_id
      WHERE u.parent_staff_id = ANY($1::bigint[])
      ORDER BY u.parent_staff_id, u.name`, [staffIds]);
    const playerIds = players.map(p => String(p.id));

    /* ---- 1. ledger: every transfer touching this agent's own wallet ---- */
    const xfers = await q(`
      SELECT t.id, t.created_at, t.amount, t.transfer_type, t.note,
             t.from_type, t.from_id, t.to_type, t.to_id,
             COALESCE(sf.name, uf.name) from_name,
             COALESCE(st.name, ut.name) to_name
      FROM staff_transfers t
      LEFT JOIN staff sf ON t.from_type='staff' AND sf.id = t.from_id
      LEFT JOIN staff st ON t.to_type  ='staff' AND st.id = t.to_id
      LEFT JOIN users uf ON t.from_type='user'  AND uf.id = t.from_id
      LEFT JOIN users ut ON t.to_type  ='user'  AND ut.id = t.to_id
      WHERE (t.from_type='staff' AND t.from_id=$1)
         OR (t.to_type  ='staff' AND t.to_id  =$1)
      ORDER BY t.created_at, t.id`, [staffId]);

    const events = xfers.map(t => {
      const incoming = t.to_type === 'staff' && String(t.to_id) === String(staffId);
      const c = classifyStaffRow(t, staffId, sub);
      return {
        id: String(t.id), ts: t.created_at, kind: c.kind, label: c.label,
        party: c.party || String(incoming ? t.from_id : t.to_id),
        note: t.note || null,
        legacy: t.transfer_type !== 'transfer' ? t.transfer_type : null,
        amount: num(t.amount) * (incoming ? 1 : -1),
      };
    });

    const live = round2(agent.balance);
    const ledger = buildLedger(events, live, from, to, opt);

    const bucket = {
      DEPOSIT_UPLINE: 0, WITHDRAW_UPLINE: 0, DEPOSIT_AGENT: 0,
      COLLECTED_AGENT: 0, DEPOSIT_PLAYER: 0, COLLECTED_PLAYER: 0,
    };
    for (const e of ledger.inside) bucket[e.kind] += Math.abs(e.amount);

    /* ---- 2. gaming: the downline's sports & casino ---- */
    const gaming = emptyGaming();
    const { map: dayMap, day: dayOf } = dailyFromEvents(ledger.inside);
    const perPlayer = new Map(players.map(p => [String(p.id), {
      id: String(p.id), name: p.name, staff_name: p.staff_name, wallet: round2(p.wallet),
      funded: 0, collected: 0, sports_pnl: 0, casino_pnl: 0,
      sports_bets: 0, casino_bets: 0, casino_staked: 0,
    }]));

    let sportsDaily = [], casinoDaily = [];

    if (playerIds.length) {
      // Money the tree moved in/out of player wallets, per player.
      const pxp = [playerIds.map(Number)];
      const playerXfers = await q(`
        SELECT t.from_type, t.to_type, t.from_id, t.to_id, t.amount
        FROM staff_transfers t
        WHERE t.transfer_type='transfer'
          AND ((t.to_type='user' AND t.to_id = ANY($1::bigint[]))
            OR (t.from_type='user' AND t.from_id = ANY($1::bigint[])))
          ${dateClause('t.created_at', from, to, pxp)}`, pxp);
      for (const t of playerXfers) {
        const toUser = t.to_type === 'user';
        const rec = perPlayer.get(String(toUser ? t.to_id : t.from_id));
        if (!rec) continue;
        if (toUser) rec.funded += num(t.amount); else rec.collected += num(t.amount);
      }

      const g = await gatherGaming(playerIds, from, to, perPlayer);
      Object.assign(gaming.sports, g.sports);
      Object.assign(gaming.casino, g.casino);
      sportsDaily = g.sportsDaily;
      casinoDaily = g.casinoDaily;
    }

    // Agent-facing: the players' loss is the agent's gain.
    finaliseGaming(gaming, 'AGENT');
    for (const d of sportsDaily) dayOf(d.date).sports_pnl += d.agent_pnl;
    for (const d of casinoDaily) dayOf(d.date).casino_pnl += d.agent_pnl;

    /* ---- 3. roll-up by sub-agent ---- */
    const byStaff = new Map(staffTree.map(s => [String(s.id), {
      id: String(s.id), name: s.name, role: s.role, depth: s.depth,
      balance: round2(s.balance), players: 0, wallet: 0, funded: 0, collected: 0,
      sports_pnl: 0, casino_pnl: 0,
    }]));
    for (const p of players) {
      const b = byStaff.get(String(p.parent_staff_id));
      const rec = perPlayer.get(String(p.id));
      if (!b || !rec) continue;
      b.players++;
      b.wallet += rec.wallet;
      b.funded += rec.funded;
      b.collected += rec.collected;
      b.sports_pnl += -rec.sports_pnl;    // agent-facing sign
      b.casino_pnl += -rec.casino_pnl;
    }

    return {
      status: 'success',
      subject: {
        type: 'STAFF', id: String(agent.id), name: agent.name, email: agent.email,
        role: agent.role, level: agent.level, agent_code: agent.agent_code || null,
        parent_name: agent.parent_name || null,
      },
      period: { from: from || null, to: to || null },
      category: opt.category,
      balance: {
        live, opening: ledger.opening, closing: ledger.closing, movement: ledger.movement,
        deposit_in: round2(bucket.DEPOSIT_UPLINE),
        withdraw_out: round2(bucket.WITHDRAW_UPLINE),
        given_downline: round2(bucket.DEPOSIT_AGENT + bucket.DEPOSIT_PLAYER),
        given_agents: round2(bucket.DEPOSIT_AGENT),
        given_players: round2(bucket.DEPOSIT_PLAYER),
        collected_downline: round2(bucket.COLLECTED_AGENT + bucket.COLLECTED_PLAYER),
        collected_agents: round2(bucket.COLLECTED_AGENT),
        collected_players: round2(bucket.COLLECTED_PLAYER),
        total_in: round2(bucket.DEPOSIT_UPLINE + bucket.COLLECTED_AGENT + bucket.COLLECTED_PLAYER),
        total_out: round2(bucket.WITHDRAW_UPLINE + bucket.DEPOSIT_AGENT + bucket.DEPOSIT_PLAYER),
        open_exposure: 0,
        unexplained: round2(live - ledger.lifetimeNet),
      },
      rows: ledger.rows,
      pagination: ledger.pagination,
      gaming,
      daily: finishDaily(dayMap),
      sports_daily: sportsDaily,
      casino_daily: casinoDaily,
      players: [...perPlayer.values()].map(p => ({
        ...p, funded: round2(p.funded), collected: round2(p.collected),
        player_pnl: round2(p.sports_pnl + p.casino_pnl),
        agent_pnl: round2(-(p.sports_pnl + p.casino_pnl)),
      })),
      downline: [...byStaff.values()].map(s => ({
        ...s, wallet: round2(s.wallet), funded: round2(s.funded),
        collected: round2(s.collected), sports_pnl: round2(s.sports_pnl),
        casino_pnl: round2(s.casino_pnl), agent_pnl: round2(s.sports_pnl + s.casino_pnl),
      })),
    };
}

/* ══════════════════════════════════════════════════════════════════════════
   PLAYER (user) STATEMENT

   Same shape, but the ledger carries every wallet-moving source — agent
   deposits, bank/gateway deposits and withdrawals, sports settlement, casino
   bets and wins — so the running balance reconciles against `credits.inr`.
   ══════════════════════════════════════════════════════════════════════════ */

/** Every INR balance-affecting event for one player, oldest first. */
async function collectUserEvents(userId) {
  const uid = String(userId);
  const events = [];
  const push = (ts, kind, label, party, amount, note, seq) =>
    events.push({ ts, kind, label, party, note: note || null, legacy: null, amount, seq: seq || 0 });

  // 1) Agent deposits / collections. Legacy 'gt'/'casino' settlement rows are
  //    excluded — they would double-count against the per-bet rows below.
  {
    const rows = await q(`
      SELECT t.id, t.created_at, t.amount, t.from_type, t.to_type, t.note,
             COALESCE(sf.name, st.name) staff_name
      FROM staff_transfers t
      LEFT JOIN staff sf ON t.from_type='staff' AND sf.id = t.from_id
      LEFT JOIN staff st ON t.to_type  ='staff' AND st.id = t.to_id
      WHERE t.transfer_type='transfer'
        AND ((t.to_type='user' AND t.to_id=$1) OR (t.from_type='user' AND t.from_id=$1))
      ORDER BY t.created_at, t.id`, [uid]);
    for (const r of rows) {
      const credit = r.to_type === 'user';
      push(r.created_at,
        credit ? 'DEPOSIT_UPLINE' : 'WITHDRAW_UPLINE',
        credit ? 'Deposit from agent' : 'Withdrawn by agent',
        r.staff_name || '—',
        num(r.amount) * (credit ? 1 : -1), r.note);
    }
  }

  // 2) Bank deposits
  {
    const rows = await q(`
      SELECT created_at, amount, transaction_id FROM fiat_deposits
      WHERE user_id = $1 AND upper(currency)='INR'
        AND lower(status) IN ('approved','success','done','completed')`, [uid]);
    for (const r of rows) push(r.created_at, 'BANK_DEPOSIT', 'Bank deposit', 'Bank', num(r.amount), r.transaction_id);
  }

  // 3) Gateway deposits
  {
    const rows = await q(`
      SELECT created_at,
             CASE WHEN paid_amount > 0 THEN paid_amount ELSE amount END AS amount,
             order_id FROM apaydeposits
      WHERE user_id = $1 AND upper(currency)='INR' AND status='Success'`, [uid]);
    for (const r of rows) push(r.created_at, 'GATEWAY_DEPOSIT', 'Gateway deposit', 'Gateway', num(r.amount), r.order_id);
  }

  // 4) Bank withdrawals
  {
    const rows = await q(`
      SELECT date, amount, status FROM fiat_withdrawals
      WHERE uid = $1 AND upper(currency)='INR'
        AND lower(status) NOT IN ('rejected','failed')`, [uid]);
    for (const r of rows) push(r.date, 'BANK_WITHDRAW', `Bank withdrawal (${r.status})`, 'Bank', -num(r.amount));
  }

  // 5) Gateway withdrawals
  {
    const rows = await q(`
      SELECT created_at, amount, status, order_id FROM apaywithdrawals
      WHERE user_id = $1::text AND upper(currency)='INR'
        AND status IN ('Success','Pending') AND COALESCE(refunded,false)=false`, [uid]);
    for (const r of rows) push(r.created_at, 'GATEWAY_WITHDRAW', `Gateway withdrawal (${r.status})`, 'Gateway', -num(r.amount), r.order_id);
  }

  // 6) Sports settlement — netamount is already signed (+win / −loss)
  {
    const rows = await q(`
      SELECT created_at, netamount, amount, description, reason, market_type
      FROM credits_ledger
      WHERE user_id::text = $1 AND upper(currency)='INR'`, [uid]);
    for (const r of rows) {
      const net = r.netamount != null ? num(r.netamount) : num(r.amount);
      push(r.created_at, 'SPORTS',
        net >= 0 ? 'Sports bet won' : 'Sports bet lost',
        r.market_type || 'Sports', net, r.description || r.reason);
    }
  }

  // 7) Casino — the provider labels the INR wallet 'PKR'.
  {
    const rows = await q(`
      SELECT g.id, COALESCE(g.transaction_datetime, g.created_at) ts, g.amount,
             g.action, g.round_id, gg.name game_name
      FROM gis_transactions g
      LEFT JOIN gis_games gg ON gg.uuid = g.game_uuid
      WHERE g.user_id = $1::bigint AND upper(g.currency) IN ('INR','PKR')
      ORDER BY g.id`, [uid]);
    for (const r of rows) {
      const bet = r.action === 'bet';
      const amt = num(r.amount) * (bet ? -1 : 1);
      if (amt === 0) continue;   // zero-value win/refund rows move nothing
      push(r.ts, 'CASINO', `Casino ${r.action}`, r.game_name || '—', amt,
        r.round_id ? `round ${r.round_id}` : null, Number(r.id) || 0);
    }
  }

  events.sort((a, b) => (new Date(a.ts) - new Date(b.ts)) || (a.seq - b.seq));
  events.forEach((e, i) => { e.id = String(i + 1); delete e.seq; });
  return events;
}

/** Build the player payload. Same contract as buildAgentStatement. */
async function buildUserStatement(userIdRaw, opt, callerId) {
    const userId = String(userIdRaw || '');
    if (!/^\d+$/.test(userId)) return { error: { code: 400, message: 'Invalid user id' } };
    if (opt.bad) return { error: { code: 400, message: 'from must not be after to' } };
    const { from, to } = opt;

    // The player must sit under the caller's staff hierarchy.
    const [user] = await q(`
      SELECT u.id, u.name, u.email, u.parent_staff_id, COALESCE(c.inr,0) balance,
             s.name staff_name, r.name staff_role
      FROM users u
      LEFT JOIN credits c ON c.uid = u.id
      LEFT JOIN staff s ON s.id = u.parent_staff_id
      LEFT JOIN roles r ON r.id = s.role_id
      WHERE u.id = $1`, [userId]);
    if (!user) return { error: { code: 404, message: 'Player not found' } };

    const allowed = await q(
      'SELECT 1 FROM staff_hierarchy WHERE ancestor_id=$1 AND descendant_id=$2',
      [callerId, user.parent_staff_id]
    );
    if (!allowed.length) return { error: { code: 403, message: 'Player is not in your hierarchy' } };

    const live = round2(user.balance);
    const events = await collectUserEvents(userId);
    const ledger = buildLedger(events, live, from, to, opt);

    // Money in/out totals for the period (gaming rows are summarised separately).
    let depositIn = 0, withdrawOut = 0, bankIn = 0, bankOut = 0;
    for (const e of ledger.inside) {
      if (KIND_CATEGORY[e.kind] !== 'money') continue;
      if (e.kind === 'DEPOSIT_UPLINE') depositIn += e.amount;
      else if (e.kind === 'WITHDRAW_UPLINE') withdrawOut += -e.amount;
      else if (e.amount >= 0) bankIn += e.amount;
      else bankOut += -e.amount;
    }

    const perPlayer = new Map([[userId, {
      id: userId, name: user.name, staff_name: user.staff_name, wallet: live,
      funded: round2(depositIn + bankIn), collected: round2(withdrawOut + bankOut),
      sports_pnl: 0, casino_pnl: 0, sports_bets: 0, casino_bets: 0, casino_staked: 0,
    }]]);

    const gaming = emptyGaming();
    const g = await gatherGaming([userId], from, to, perPlayer);
    Object.assign(gaming.sports, g.sports);
    Object.assign(gaming.casino, g.casino);
    finaliseGaming(gaming, 'PLAYER');

    const { map: dayMap, day: dayOf } = dailyFromEvents(ledger.inside);
    for (const d of g.sportsDaily) dayOf(d.date).sports_pnl += d.player_pnl;
    for (const d of g.casinoDaily) dayOf(d.date).casino_pnl += d.player_pnl;

    // Unsettled stakes are out of the wallet but have no settlement row yet, so
    // wallet + open_exposure is what the ledger adds up to.
    const [oe] = await q(
      `SELECT COALESCE(SUM(stake_amount),0) s FROM "SportsBet"
        WHERE user_id = $1::bigint AND status IN ('open','manual')`, [userId]);

    return {
      status: 'success',
      subject: {
        type: 'USER', id: userId, name: user.name, email: user.email,
        role: 'User', level: null, agent_code: null,
        parent_name: user.staff_name || null,
      },
      period: { from: from || null, to: to || null },
      category: opt.category,
      balance: {
        live, opening: ledger.opening, closing: ledger.closing, movement: ledger.movement,
        deposit_in: round2(depositIn), withdraw_out: round2(withdrawOut),
        given_downline: 0, given_agents: 0, given_players: 0,
        collected_downline: 0, collected_agents: 0, collected_players: 0,
        bank_in: round2(bankIn), bank_out: round2(bankOut),
        total_in: round2(depositIn + bankIn), total_out: round2(withdrawOut + bankOut),
        open_exposure: round2(oe.s),
        unexplained: round2(live + round2(oe.s) - ledger.lifetimeNet),
      },
      rows: ledger.rows,
      pagination: ledger.pagination,
      gaming,
      daily: finishDaily(dayMap),
      sports_daily: g.sportsDaily,
      casino_daily: g.casinoDaily,
      players: [...perPlayer.values()].map(p => ({
        ...p, player_pnl: round2(p.sports_pnl + p.casino_pnl),
        agent_pnl: round2(-(p.sports_pnl + p.casino_pnl)),
      })),
      downline: [],
    };
}

/* ── express wrappers ─────────────────────────────────────────────────────── */

const sendStatement = (build) => async (req, res, next) => {
  try {
    const id = req.params.userId != null ? req.params.userId : req.params.staffId;
    const out = await build(id, readQuery(req), req.staff.id);
    if (out.error) return res.status(out.error.code).json({ status: 'fail', message: out.error.message });
    res.json(out);
  } catch (err) { next(err); }
};

exports.getAgentStatement = sendStatement(buildAgentStatement);
exports.getUserStatement = sendStatement(buildUserStatement);
exports.buildAgentStatement = buildAgentStatement;
exports.buildUserStatement = buildUserStatement;

/* ══════════════════════════════════════════════════════════════════════════
   SHARED GAMING AGGREGATION
   ══════════════════════════════════════════════════════════════════════════ */

function emptyGaming() {
  return {
    sports: { settled_bets: 0, player_pnl: 0, agent_pnl: 0, placed_bets: 0, turnover: 0, open_bets: 0, open_stake: 0 },
    casino: { txns: 0, bets: 0, staked: 0, wins: 0, won: 0, player_pnl: 0, agent_pnl: 0 },
    total: { player_pnl: 0, agent_pnl: 0, headline_pnl: 0, headline_for: 'AGENT' },
  };
}

/** Fill the sports/casino totals + daily series for a set of player ids, and
 *  attribute per-player numbers into `perPlayer` (keyed by string id). */
async function gatherGaming(playerIds, from, to, perPlayer) {
  const out = {
    sports: { settled_bets: 0, player_pnl: 0, placed_bets: 0, turnover: 0, open_bets: 0, open_stake: 0 },
    casino: { txns: 0, bets: 0, staked: 0, wins: 0, won: 0, player_pnl: 0 },
    sportsDaily: [], casinoDaily: [],
  };
  if (!playerIds.length) return out;
  const asBigint = playerIds.map(Number);

  // ---- sports P&L: credits_ledger is authoritative ----
  const slp = [playerIds];
  for (const r of await q(`
    SELECT cl.user_id, COUNT(*) bets, COALESCE(SUM(cl.netamount),0) net
    FROM credits_ledger cl
    WHERE cl.user_id::text = ANY($1::text[]) AND upper(cl.currency)='INR'
      ${dateClause('cl.created_at', from, to, slp)}
    GROUP BY cl.user_id`, slp)) {
    const rec = perPlayer.get(String(r.user_id));
    if (rec) { rec.sports_pnl = round2(r.net); rec.sports_bets = num(r.bets); }
    out.sports.settled_bets += num(r.bets);
    out.sports.player_pnl += num(r.net);
  }

  const sdp = [playerIds];
  out.sportsDaily = (await q(`
    SELECT cl.created_at::date dt, COUNT(*) bets, COALESCE(SUM(cl.netamount),0) net
    FROM credits_ledger cl
    WHERE cl.user_id::text = ANY($1::text[]) AND upper(cl.currency)='INR'
      ${dateClause('cl.created_at', from, to, sdp)}
    GROUP BY 1 ORDER BY 1`, sdp))
    .map(r => ({ date: ymd(r.dt), bets: num(r.bets), player_pnl: round2(r.net), agent_pnl: round2(-r.net) }));

  // ---- sports stake / open exposure comes from the bet table ----
  const sbp = [asBigint];
  for (const r of await q(`
    SELECT status, COUNT(*) n, COALESCE(SUM(stake_amount),0) stake
    FROM "SportsBet"
    WHERE user_id = ANY($1::bigint[])
      ${dateClause('created_at', from, to, sbp)}
    GROUP BY status`, sbp)) {
    out.sports.placed_bets += num(r.n);
    out.sports.turnover += num(r.stake);
    if (r.status === 'open' || r.status === 'manual') {
      out.sports.open_bets += num(r.n);
      out.sports.open_stake += num(r.stake);
    }
  }

  // ---- casino ----
  const cap = [asBigint];
  const [cAgg] = await q(`
    SELECT COUNT(*) txns,
           COUNT(*) FILTER (WHERE action='bet') bets,
           COALESCE(SUM(amount) FILTER (WHERE action='bet'),0) staked,
           COUNT(*) FILTER (WHERE action<>'bet') wins,
           COALESCE(SUM(amount) FILTER (WHERE action<>'bet'),0) won
    FROM gis_transactions
    WHERE user_id = ANY($1::bigint[]) AND upper(currency) IN ('INR','PKR')
      ${dateClause('COALESCE(transaction_datetime, created_at)', from, to, cap)}`, cap);
  out.casino.txns = num(cAgg.txns);
  out.casino.bets = num(cAgg.bets);
  out.casino.staked = round2(cAgg.staked);
  out.casino.wins = num(cAgg.wins);
  out.casino.won = round2(cAgg.won);
  out.casino.player_pnl = round2(num(cAgg.won) - num(cAgg.staked));

  const cpp = [asBigint];
  for (const r of await q(`
    SELECT user_id,
           COUNT(*) FILTER (WHERE action='bet') bets,
           COALESCE(SUM(amount) FILTER (WHERE action='bet'),0) staked,
           COALESCE(SUM(CASE WHEN action='bet' THEN -amount ELSE amount END),0) net
    FROM gis_transactions
    WHERE user_id = ANY($1::bigint[]) AND upper(currency) IN ('INR','PKR')
      ${dateClause('COALESCE(transaction_datetime, created_at)', from, to, cpp)}
    GROUP BY user_id`, cpp)) {
    const rec = perPlayer.get(String(r.user_id));
    if (!rec) continue;
    rec.casino_pnl = round2(r.net);
    rec.casino_bets = num(r.bets);
    rec.casino_staked = round2(r.staked);
  }

  const cdp = [asBigint];
  out.casinoDaily = (await q(`
    SELECT COALESCE(transaction_datetime, created_at)::date dt,
           COUNT(*) FILTER (WHERE action='bet') bets,
           COALESCE(SUM(amount) FILTER (WHERE action='bet'),0) staked,
           COALESCE(SUM(amount) FILTER (WHERE action<>'bet'),0) won,
           COALESCE(SUM(CASE WHEN action='bet' THEN -amount ELSE amount END),0) net
    FROM gis_transactions
    WHERE user_id = ANY($1::bigint[]) AND upper(currency) IN ('INR','PKR')
      ${dateClause('COALESCE(transaction_datetime, created_at)', from, to, cdp)}
    GROUP BY 1 ORDER BY 1`, cdp))
    .map(r => ({
      date: ymd(r.dt), bets: num(r.bets), staked: round2(r.staked),
      won: round2(r.won), player_pnl: round2(r.net), agent_pnl: round2(-r.net),
    }));

  return out;
}

/** Round the totals and decide which side of the P&L the subject actually keeps. */
function finaliseGaming(gaming, headlineFor) {
  const s = gaming.sports, c = gaming.casino, t = gaming.total;
  s.player_pnl = round2(s.player_pnl);
  s.agent_pnl = round2(-s.player_pnl);
  s.turnover = round2(s.turnover);
  s.open_stake = round2(s.open_stake);
  c.player_pnl = round2(c.player_pnl);
  c.agent_pnl = round2(-c.player_pnl);
  t.player_pnl = round2(s.player_pnl + c.player_pnl);
  t.agent_pnl = round2(-t.player_pnl);
  t.headline_for = headlineFor;
  t.headline_pnl = headlineFor === 'AGENT' ? t.agent_pnl : t.player_pnl;
  t.headline_sports = headlineFor === 'AGENT' ? s.agent_pnl : s.player_pnl;
  t.headline_casino = headlineFor === 'AGENT' ? c.agent_pnl : c.player_pnl;
}


/* ══════════════════════════════════════════════════════════════════════════
   BET / TRANSACTION LISTS  (paginated)

   GET /api/admin/agent-report/:staffId/bets?kind=sports|casino
   GET /api/admin/agent-report/user/:userId/bets?kind=sports|casino
       &from= &to= &page= &limit=

   Split out of the statement because these lists are unbounded — a busy tree
   runs to tens of thousands of rows — so they page on the server instead of
   being capped and silently truncated.
   ══════════════════════════════════════════════════════════════════════════ */

/* Some bet columns carry the literal string "NULL" rather than a real null.
   Reading "NULL" in a Selection column helps nobody — fall through to the dash. */
const text = (...vals) => {
  for (const v of vals) {
    const s = v == null ? '' : String(v).trim();
    if (s && s.toLowerCase() !== 'null' && s.toLowerCase() !== 'undefined') return s;
  }
  return '—';
};

/** Resolve the caller's target into a set of player ids, enforcing hierarchy.
 *  Returns { playerIds } or { error: { code, message } }. */
async function resolvePlayers(req) {
  if (req.params.userId != null) {
    const userId = String(req.params.userId);
    if (!/^\d+$/.test(userId)) return { error: { code: 400, message: 'Invalid user id' } };
    const [u] = await q('SELECT id, parent_staff_id FROM users WHERE id = $1', [userId]);
    if (!u) return { error: { code: 404, message: 'Player not found' } };
    const ok = await q(
      'SELECT 1 FROM staff_hierarchy WHERE ancestor_id=$1 AND descendant_id=$2',
      [req.staff.id, u.parent_staff_id]
    );
    if (!ok.length) return { error: { code: 403, message: 'Player is not in your hierarchy' } };
    return { playerIds: [Number(userId)] };
  }

  const staffId = Number(req.params.staffId);
  if (!Number.isInteger(staffId)) return { error: { code: 400, message: 'Invalid staff id' } };
  if (staffId !== req.staff.id) {
    const ok = await q('SELECT 1 FROM staff_hierarchy WHERE ancestor_id=$1 AND descendant_id=$2',
      [req.staff.id, staffId]);
    if (!ok.length) return { error: { code: 403, message: 'Agent is not in your hierarchy' } };
  }
  const rows = await q(`
    SELECT u.id FROM users u
    WHERE u.parent_staff_id IN (SELECT descendant_id FROM staff_hierarchy WHERE ancestor_id = $1)`,
    [staffId]);
  return { playerIds: rows.map(r => Number(r.id)) };
}

exports.getBets = async (req, res, next) => {
  try {
    const kind = req.query.kind === 'casino' ? 'casino' : 'sports';
    const from = cleanDate(req.query.from);
    const to = cleanDate(req.query.to);
    if (from && to && from > to)
      return res.status(400).json({ status: 'fail', message: 'from must not be after to' });

    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const limit = Math.min(200, Math.max(10, parseInt(req.query.limit, 10) || 50));
    const offset = (page - 1) * limit;

    const resolved = await resolvePlayers(req);
    if (resolved.error)
      return res.status(resolved.error.code).json({ status: 'fail', message: resolved.error.message });

    const ids = resolved.playerIds;
    const empty = { status: 'success', kind, rows: [], pagination: { page, limit, total: 0, pages: 1 } };
    if (!ids.length) return res.json(empty);

    if (kind === 'sports') {
      const cp = [ids];
      const [{ n }] = await q(`
        SELECT COUNT(*)::int n FROM "SportsBet"
        WHERE user_id = ANY($1::bigint[])
          ${dateClause('created_at', from, to, cp)}`, cp);

      const rp = [ids];
      const dc = dateClause('b.created_at', from, to, rp);
      rp.push(limit, offset);
      const rows = await q(`
        SELECT b.id, b.created_at, b.user_id, u.name user_name, b.match_title, b.event_name,
               b.selection_name, b.fancy_name, b.market_type, b.bet_type, b.odds,
               b.stake_amount, b.status, b.result_status, b.game_type
        FROM "SportsBet" b
        LEFT JOIN users u ON u.id = b.user_id
        WHERE b.user_id = ANY($1::bigint[]) ${dc}
        ORDER BY b.created_at DESC NULLS LAST, b.id DESC
        LIMIT $${rp.length - 1} OFFSET $${rp.length}`, rp);

      return res.json({
        status: 'success', kind,
        rows: rows.map(b => ({
          id: String(b.id), ts: b.created_at, user: text(b.user_name, b.user_id),
          match: text(b.match_title, b.event_name),
          selection: text(b.fancy_name, b.selection_name),
          market: text(b.market_type, b.game_type),
          side: text(b.bet_type),
          odds: num(b.odds), stake: round2(b.stake_amount),
          status: b.status, result: b.result_status || null,
        })),
        pagination: { page, limit, total: n, pages: Math.max(1, Math.ceil(n / limit)) },
      });
    }

    const TS = 'COALESCE(transaction_datetime, created_at)';
    const cp = [ids];
    const [{ n }] = await q(`
      SELECT COUNT(*)::int n FROM gis_transactions
      WHERE user_id = ANY($1::bigint[]) AND upper(currency) IN ('INR','PKR')
        ${dateClause(TS, from, to, cp)}`, cp);

    const rp = [ids];
    const dc = dateClause(`COALESCE(g.transaction_datetime, g.created_at)`, from, to, rp);
    rp.push(limit, offset);
    const rows = await q(`
      SELECT g.id, COALESCE(g.transaction_datetime, g.created_at) ts, g.user_id,
             u.name user_name, g.action, g.amount, g.round_id, g.game_uuid, gg.name game_name
      FROM gis_transactions g
      LEFT JOIN users u ON u.id = g.user_id
      LEFT JOIN gis_games gg ON gg.uuid = g.game_uuid
      WHERE g.user_id = ANY($1::bigint[]) AND upper(g.currency) IN ('INR','PKR') ${dc}
      ORDER BY ts DESC NULLS LAST, g.id DESC
      LIMIT $${rp.length - 1} OFFSET $${rp.length}`, rp);

    return res.json({
      status: 'success', kind,
      rows: rows.map(t => ({
        id: String(t.id), ts: t.ts, user: text(t.user_name, t.user_id),
        action: t.action, game: text(t.game_name, t.game_uuid),
        round: t.round_id || null,
        amount: round2(num(t.amount) * (t.action === 'bet' ? -1 : 1)),
      })),
      pagination: { page, limit, total: n, pages: Math.max(1, Math.ceil(n / limit)) },
    });
  } catch (err) { next(err); }
};
