/* ──────────────────────────────────────────────────────────────────────────
   AGENT SETTLEMENT REPORT  (PDF)

   Builds a downloadable settlement report for one agent (staff) and its whole
   downline — capital/remittance flow, per-sub-agent roll-up, per-player P&L
   reconciliation, and per-player transaction detail.

   P&L is reconstructed from the authoritative ledgers (credits_ledger sports +
   gis_transactions casino), NOT the denormalised users columns. Sign: + = player
   won (house pays), − = player lost (house keeps).

   GET /api/admin/agent-report/:staffId
        ?full=1            -> list every casino transaction (else daily summary)
        &from=YYYY-MM-DD    -> only count activity on/after this date (optional)
        &to=YYYY-MM-DD      -> only count activity on/before this date (optional)
        &download=1         -> force attachment (default streams inline-able PDF)

   The agent must be the caller or sit inside the caller's staff_hierarchy.
   Every generated PDF is also persisted under  backend/report/generated/  so
   there is an on-disk archive of what was produced.
   ────────────────────────────────────────────────────────────────────────── */
const fs = require('fs');
const path = require('path');
const PDFDocument = require('pdfkit');
const pg = require('../General/Model');

const SAVE_DIR = path.join(__dirname, 'generated');

const money = (n) =>
  (Number(n) || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

// A bare YYYY-MM-DD passes through; anything else is rejected so we never inject
// junk into the date filters.
const cleanDate = (s) => (typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) ? s : null);

async function q(sql, params) { return (await pg.query(sql, params)).rows; }

/* Build a `created_at`-style date filter fragment + push params. `col` is the
   timestamp column for that source. Returns the SQL string (possibly empty). */
function dateClause(col, from, to, params) {
  let sql = '';
  if (from) { params.push(from); sql += ` AND ${col} >= $${params.length}::date`; }
  if (to)   { params.push(to);   sql += ` AND ${col} < ($${params.length}::date + INTERVAL '1 day')`; }
  return sql;
}

async function gatherData(staffId, from, to) {
  // ---- agent header ----
  const [agent] = await q(`
    SELECT s.id, s.name, s.email, s.agent_code,
           r.name role, r.level, COALESCE(b.inr,0) bank, ps.name parent_name
    FROM staff s JOIN roles r ON r.id = s.role_id
    LEFT JOIN staff_balances b ON b.staff_id = s.id
    LEFT JOIN staff ps ON ps.id = s.parent_id
    WHERE s.id = $1`, [staffId]);
  if (!agent) return null;

  // ---- downline staff (closure table) ----
  const staffTree = await q(`
    SELECT h.depth, s.id, s.name, r.name role, COALESCE(b.inr,0) bank
    FROM staff_hierarchy h JOIN staff s ON s.id = h.descendant_id
    JOIN roles r ON r.id = s.role_id LEFT JOIN staff_balances b ON b.staff_id = s.id
    WHERE h.ancestor_id = $1 ORDER BY h.depth, s.id`, [staffId]);
  const staffIds = staffTree.map(s => s.id);

  // ---- players in tree ----
  const players = await q(`
    SELECT u.id, u.name, u.parent_staff_id, COALESCE(c.inr,0) wallet
    FROM users u LEFT JOIN credits c ON c.uid = u.id
    WHERE u.parent_staff_id = ANY($1::bigint[]) ORDER BY u.parent_staff_id, u.name`, [staffIds]);

  // ---- staff <-> staff transfers (capital / remittance / downline) ----
  const sxParams = [staffIds];
  const sxDate = dateClause('t.created_at', from, to, sxParams);
  const staffXfer = await q(`
    SELECT t.id, t.created_at::date dt,
           COALESCE(sf.name,t.from_id::text) from_name,
           COALESCE(st.name,t.to_id::text) to_name,
           t.amount, COALESCE(t.direction,'') dir
    FROM staff_transfers t
    LEFT JOIN staff sf ON sf.id = t.from_id LEFT JOIN staff st ON st.id = t.to_id
    WHERE t.transfer_type='transfer' AND t.from_type='staff' AND t.to_type='staff'
      AND (t.from_id = ANY($1::bigint[]) OR t.to_id = ANY($1::bigint[]))
      ${sxDate}
    ORDER BY t.created_at`, sxParams);

  // ---- per-player detail ----
  const detail = {};
  for (const p of players) {
    const xp = [String(p.id)];
    const xfers = await q(`
      SELECT t.id, t.created_at::date dt, t.from_type, t.to_type, t.amount,
             CASE WHEN t.to_type='user' AND t.to_id=$1 THEN 'IN (agent funded)'
                  ELSE 'OUT (agent collected)' END label
      FROM staff_transfers t
      WHERE t.transfer_type='transfer'
        AND ((t.to_type='user' AND t.to_id=$1) OR (t.from_type='user' AND t.from_id=$1))
        ${dateClause('t.created_at', from, to, xp)}
      ORDER BY t.created_at`, xp);

    const lp = [String(p.id)];
    const ledger = await q(`
      SELECT id, reason, amount, netamount, closing, created_at::timestamp(0) ts
      FROM credits_ledger WHERE user_id::text=$1 AND upper(currency)='INR'
        ${dateClause('created_at', from, to, lp)}
      ORDER BY created_at`, lp);

    const cp = [String(p.id)];
    const casino = await q(`
      SELECT id, action, amount, round_id,
             COALESCE(transaction_datetime,created_at)::timestamp(0) ts
      FROM gis_transactions WHERE user_id::text=$1
        ${dateClause('COALESCE(transaction_datetime,created_at)', from, to, cp)}
      ORDER BY id`, cp);

    const dp = [String(p.id)];
    const casinoDaily = await q(`
      SELECT COALESCE(transaction_datetime,created_at)::date dt,
             COUNT(*) FILTER (WHERE action='bet') bets,
             COALESCE(SUM(amount) FILTER (WHERE action='bet'),0) staked,
             COUNT(*) FILTER (WHERE action<>'bet') wins,
             COALESCE(SUM(amount) FILTER (WHERE action<>'bet'),0) won,
             COALESCE(SUM(CASE WHEN action='bet' THEN -amount ELSE amount END),0) net
      FROM gis_transactions WHERE user_id::text=$1
        ${dateClause('COALESCE(transaction_datetime,created_at)', from, to, dp)}
      GROUP BY 1 ORDER BY 1`, dp);

    const fundedIn = xfers.filter(x => x.to_type === 'user').reduce((a, x) => a + Number(x.amount), 0);
    const collectedOut = xfers.filter(x => x.from_type === 'user').reduce((a, x) => a + Number(x.amount), 0);
    const sportsPnl = ledger.reduce((a, l) => a + Number(l.netamount), 0);
    const casinoPnl = casino.reduce((a, c) => a + (c.action === 'bet' ? -Number(c.amount) : Number(c.amount)), 0);
    const gamingPnl = sportsPnl + casinoPnl;
    const expected = fundedIn - collectedOut + gamingPnl;
    const diff = Number(p.wallet) - expected;
    const casinoBets = casino.filter(c => c.action === 'bet');
    detail[p.id] = {
      xfers, ledger, casino, casinoDaily,
      casinoCount: casino.length, casinoBetCount: casinoBets.length,
      casinoStaked: casinoBets.reduce((a, c) => a + Number(c.amount), 0),
      casinoWon: casino.filter(c => c.action !== 'bet').reduce((a, c) => a + Number(c.amount), 0),
      fundedIn, collectedOut, sportsPnl, casinoPnl, gamingPnl, expected, diff,
    };
  }

  return { agent, staffTree, players, staffXfer, detail };
}

/* Render the gathered data into a PDFDocument and return it (already piped to
   the given writable streams by the caller). */
function renderPdf(doc, data, opts) {
  const { agent, staffTree, players, staffXfer, detail } = data;
  const { full, from, to, generatedAt } = opts;

  const PAGE_W = doc.page.width, M = 40, CW = PAGE_W - 2 * M;
  const C = { ink: '#1a1a1a', sub: '#555', line: '#cccccc', head: '#0b3d2e', headbg: '#0b3d2e',
    zebra: '#f3f6f4', red: '#b00020', green: '#0a7d3c', amber: '#9a6b00', amberbg: '#fff7e0' };

  let y = M;
  const newPageIf = (need) => { if (y + need > doc.page.height - M) { doc.addPage(); y = M; } };
  const h1 = (t) => { doc.fillColor(C.head).font('Helvetica-Bold').fontSize(18).text(t, M, y); y = doc.y + 4; };
  const h2 = (t) => { newPageIf(40); doc.fillColor(C.head).font('Helvetica-Bold').fontSize(13).text(t, M, y); y = doc.y + 2;
    doc.moveTo(M, y).lineTo(M + CW, y).strokeColor(C.head).lineWidth(1).stroke(); y += 6; };
  const para = (t, o = {}) => { doc.fillColor(o.color || C.ink).font(o.bold ? 'Helvetica-Bold' : 'Helvetica')
    .fontSize(o.size || 9).text(t, M, y, { width: CW }); y = doc.y + (o.gap ?? 4); };

  function table(cols, rows, o = {}) {
    const fs0 = o.fontSize || 8, pad = 4, rh = o.rowH || 14;
    const drawHead = () => {
      newPageIf(rh + 4);
      let x = M; doc.rect(M, y, CW, rh).fill(C.headbg);
      doc.fillColor('#ffffff').font('Helvetica-Bold').fontSize(fs0);
      cols.forEach(c => { doc.text(c.label, x + pad, y + 3, { width: c.w - 2 * pad, align: c.align || 'left', lineBreak: false, height: rh }); x += c.w; });
      y += rh;
    };
    drawHead();
    rows.forEach((row, i) => {
      newPageIf(rh);
      if (y === M) drawHead();
      const bg = i % 2 ? C.zebra : '#ffffff';
      if (bg !== '#ffffff') doc.rect(M, y, CW, rh).fill(bg);
      let x = M;
      cols.forEach((c, ci) => {
        const cell = row[ci];
        const isObj = cell && typeof cell === 'object';
        const col = isObj && cell.color ? cell.color : C.ink;
        const txt = isObj ? cell.t : cell;
        doc.fillColor(col).font(isObj && cell.bold ? 'Helvetica-Bold' : 'Helvetica').fontSize(fs0)
          .text(String(txt), x + pad, y + 3, { width: c.w - 2 * pad, align: c.align || 'left', lineBreak: false, height: rh, ellipsis: true });
        x += c.w;
      });
      doc.moveTo(M, y + rh).lineTo(M + CW, y + rh).strokeColor(C.line).lineWidth(0.4).stroke();
      y += rh;
    });
    y += 6;
  }

  // ---------- header ----------
  doc.rect(0, 0, PAGE_W, 90).fill(C.headbg);
  doc.fillColor('#ffffff').font('Helvetica-Bold').fontSize(22).text('AGENT SETTLEMENT REPORT', M, 26);
  doc.font('Helvetica').fontSize(10).fillColor('#d9e7e0')
    .text(`${agent.name}  ·  Agent code ${agent.agent_code || '-'}  ·  ${agent.role} (level ${agent.level})`, M, 56);
  const scope = (from || to) ? `Period: ${from || 'start'} to ${to || 'now'}` : 'Period: all time';
  doc.fontSize(9).text(`Generated ${generatedAt}  ·  ${scope}  ·  Currency: INR${full ? '  ·  FULL transaction detail' : ''}`, M, 70);
  y = 105;

  table([{ label: 'Field', w: CW * 0.4 }, { label: 'Value', w: CW * 0.6 }], [
    ['Staff ID', String(agent.id)], ['Parent', agent.parent_name || '-'],
    ['Agent bank (staff_balances)', 'Rs ' + money(agent.bank)],
  ], { rowH: 15 });

  para('Profit/Loss is reconstructed from authoritative ledgers (credits_ledger sports + gis_transactions casino), '
    + 'not the denormalised users columns. Sign: minus = player lost (house keeps), plus = player won (house pays).',
    { size: 8, color: C.sub, gap: 8 });

  // ---------- totals ----------
  const netIn = players.reduce((a, p) => a + detail[p.id].fundedIn, 0);
  const netOut = players.reduce((a, p) => a + detail[p.id].collectedOut, 0);
  const totGaming = players.reduce((a, p) => a + detail[p.id].gamingPnl, 0);
  const totWallet = players.reduce((a, p) => a + Number(p.wallet), 0);
  const houseWin = -totGaming;

  h2('1.  Settlement summary');
  table([{ label: 'Line', w: CW * 0.62 }, { label: 'Amount (Rs)', w: CW * 0.38, align: 'right' }], [
    ['Net agent funding into players (In - Out)', money(netIn - netOut)],
    ['Total player gaming P&L', { t: money(totGaming), color: totGaming < 0 ? C.red : C.green, bold: true }],
    [{ t: 'House / agent gross win', bold: true }, { t: money(houseWin), color: C.green, bold: true }],
    ['Current wallet held across all players', money(totWallet)],
  ], { rowH: 15 });

  // ---------- rollup ----------
  h2('2.  Downline roll-up (by sub-agent)');
  const byStaff = {};
  for (const s of staffTree) byStaff[s.id] = { name: s.name, role: s.role, players: 0, in: 0, out: 0, gaming: 0, wallet: 0 };
  for (const p of players) { const b = byStaff[p.parent_staff_id]; if (!b) continue;
    b.players++; b.in += detail[p.id].fundedIn; b.out += detail[p.id].collectedOut; b.gaming += detail[p.id].gamingPnl; b.wallet += Number(p.wallet); }
  const rollRows = staffTree.map(s => { const b = byStaff[s.id];
    return [`${b.name} (${b.role})`, String(b.players), money(b.in), money(b.out),
      { t: money(b.gaming), color: b.gaming < 0 ? C.red : (b.gaming > 0 ? C.green : C.ink) }, money(b.wallet)]; });
  rollRows.push([{ t: 'TREE TOTAL', bold: true }, { t: String(players.length), bold: true }, { t: money(netIn), bold: true },
    { t: money(netOut), bold: true }, { t: money(totGaming), color: C.red, bold: true }, { t: money(totWallet), bold: true }]);
  table([{ label: 'Sub-agent', w: CW * 0.3 }, { label: 'Players', w: CW * 0.1, align: 'right' },
    { label: 'Funded In', w: CW * 0.15, align: 'right' }, { label: 'Collected Out', w: CW * 0.15, align: 'right' },
    { label: 'Gaming P&L', w: CW * 0.15, align: 'right' }, { label: 'Wallet', w: CW * 0.15, align: 'right' }],
    rollRows, { rowH: 15 });

  // ---------- staff transfers ----------
  h2('3.  Capital, remittance & downline transfers (staff <-> staff)');
  if (staffXfer.length) {
    table([{ label: 'Date', w: CW * 0.14 }, { label: 'From', w: CW * 0.26 }, { label: 'To', w: CW * 0.26 },
      { label: 'Amount', w: CW * 0.18, align: 'right' }, { label: 'Type', w: CW * 0.16 }],
      staffXfer.map(t => [t.dt.toISOString().slice(0, 10), t.from_name, t.to_name, money(t.amount), t.dir || '-']),
      { rowH: 14 });
  } else { para('No staff-to-staff transfers in this period.', { size: 8.5, color: C.sub, gap: 8 }); }

  // ---------- per-player recon ----------
  h2('4.  Per-player P&L & reconciliation');
  const reconRows = players.map(p => { const d = detail[p.id];
    const status = Math.abs(d.diff) < 2 ? { t: 'OK', color: C.green } : { t: 'GAP ' + money(d.diff), color: C.red, bold: true };
    return [p.name, money(d.fundedIn), money(d.collectedOut),
      { t: money(d.gamingPnl), color: d.gamingPnl < 0 ? C.red : (d.gamingPnl > 0 ? C.green : C.ink) },
      money(d.expected), money(p.wallet), status]; });
  if (reconRows.length) {
    table([{ label: 'Player', w: CW * 0.18 }, { label: 'Funded In', w: CW * 0.14, align: 'right' },
      { label: 'Collected', w: CW * 0.13, align: 'right' }, { label: 'Gaming P&L', w: CW * 0.15, align: 'right' },
      { label: 'Expected', w: CW * 0.13, align: 'right' }, { label: 'Wallet', w: CW * 0.12, align: 'right' },
      { label: 'Status', w: CW * 0.15 }], reconRows, { rowH: 14 });
    para('Expected wallet = (Funded In - Collected Out) + Gaming P&L.  "GAP" flags wallet not matching the ledger.',
      { size: 7.5, color: C.sub, gap: 8 });
  } else { para('No players in this tree.', { size: 8.5, color: C.sub, gap: 8 }); }

  // ---------- transaction detail ----------
  doc.addPage(); y = M;
  h1('5.  Transaction detail by player'); y += 4;
  for (const p of players) {
    const d = detail[p.id];
    newPageIf(60);
    doc.rect(M, y, CW, 18).fill('#e8efeb');
    doc.fillColor(C.head).font('Helvetica-Bold').fontSize(10)
      .text(`${p.name}   (id ${p.id})   ·   wallet ${money(p.wallet)} INR   ·   gaming P&L ${money(d.gamingPnl)} INR`,
        M + 4, y + 4, { width: CW - 8, lineBreak: false, height: 16 });
    y += 22;
    if (!(d.xfers.length || d.ledger.length || d.casino.length)) { para('No transactions in this period.', { size: 8, color: C.sub, gap: 8 }); continue; }

    if (d.xfers.length) {
      para('Agent transfers', { bold: true, size: 8.5, gap: 2 });
      table([{ label: 'Date', w: CW * 0.16 }, { label: 'Direction', w: CW * 0.34 }, { label: 'Tx id', w: CW * 0.2 }, { label: 'Amount', w: CW * 0.3, align: 'right' }],
        d.xfers.map(x => [x.dt.toISOString().slice(0, 10), x.label, '#' + x.id,
          { t: (x.to_type === 'user' ? '+' : '-') + money(x.amount), color: x.to_type === 'user' ? C.green : C.red }]),
        { rowH: 13, fontSize: 7.5 });
    }
    if (d.ledger.length) {
      para(`Sports/credits ledger  (sports P&L ${money(d.sportsPnl)})`, { bold: true, size: 8.5, gap: 2 });
      table([{ label: 'Date', w: CW * 0.22 }, { label: 'Reason', w: CW * 0.18 }, { label: 'Amount', w: CW * 0.2, align: 'right' },
        { label: 'Net (P&L)', w: CW * 0.2, align: 'right' }, { label: 'Closing', w: CW * 0.2, align: 'right' }],
        d.ledger.map(l => [l.ts.toISOString().slice(0, 10), l.reason || '-', money(l.amount),
          { t: money(l.netamount), color: Number(l.netamount) < 0 ? C.red : C.green }, money(l.closing)]),
        { rowH: 12, fontSize: 7.5 });
    }
    if (d.casino.length) {
      if (full) {
        para(`Casino (gis) - ${d.casinoCount} transactions (${d.casinoBetCount} bets) · staked ${money(d.casinoStaked)} · won ${money(d.casinoWon)} · net ${money(d.casinoPnl)}  [every transaction]`,
          { bold: true, size: 8.5, gap: 2 });
        let run = 0;
        table([{ label: '#', w: CW * 0.07, align: 'right' }, { label: 'Date/Time', w: CW * 0.27 }, { label: 'Action', w: CW * 0.14 },
          { label: 'Round', w: CW * 0.22 }, { label: 'Amount', w: CW * 0.15, align: 'right' }, { label: 'Running net', w: CW * 0.15, align: 'right' }],
          d.casino.map((c, ix) => { const signed = c.action === 'bet' ? -Number(c.amount) : Number(c.amount); run += signed;
            return [String(ix + 1), c.ts.toISOString().slice(0, 19).replace('T', ' '), c.action, c.round_id ? String(c.round_id) : '-',
              { t: (c.action === 'bet' ? '-' : '+') + money(c.amount), color: c.action === 'bet' ? C.red : C.green },
              { t: money(run), color: run < 0 ? C.red : C.green }]; }),
          { rowH: 11, fontSize: 7 });
      } else {
        para(`Casino (gis) - ${d.casinoCount} transactions (${d.casinoBetCount} bets) · staked ${money(d.casinoStaked)} · won ${money(d.casinoWon)} · net ${money(d.casinoPnl)}  [daily summary]`,
          { bold: true, size: 8.5, gap: 2 });
        table([{ label: 'Date', w: CW * 0.2 }, { label: 'Bets', w: CW * 0.1, align: 'right' }, { label: 'Staked', w: CW * 0.2, align: 'right' },
          { label: 'Wins', w: CW * 0.1, align: 'right' }, { label: 'Won', w: CW * 0.2, align: 'right' }, { label: 'Net P&L', w: CW * 0.2, align: 'right' }],
          d.casinoDaily.map(c => [c.dt.toISOString().slice(0, 10), String(c.bets), money(c.staked), String(c.wins),
            money(c.won), { t: money(c.net), color: Number(c.net) < 0 ? C.red : (Number(c.net) > 0 ? C.green : C.ink) }]),
          { rowH: 12, fontSize: 7.5 });
      }
    }
    y += 4;
  }
}

exports.generateAgentReport = async (req, res, next) => {
  try {
    const staffId = Number(req.params.staffId);
    if (!Number.isInteger(staffId)) return res.status(400).json({ status: 'fail', message: 'Invalid staff id' });

    // Security: the target must be the caller or inside the caller's downline.
    const callerId = req.staff.id;
    if (staffId !== callerId) {
      const ok = await q('SELECT 1 FROM staff_hierarchy WHERE ancestor_id=$1 AND descendant_id=$2', [callerId, staffId]);
      if (!ok.length) return res.status(403).json({ status: 'fail', message: 'Agent is not in your hierarchy' });
    }

    const full = req.query.full === '1' || req.query.full === 'true';
    const from = cleanDate(req.query.from);
    const to = cleanDate(req.query.to);

    const data = await gatherData(staffId, from, to);
    if (!data) return res.status(404).json({ status: 'fail', message: 'Agent not found' });

    const generatedAt = new Date().toISOString().slice(0, 10);
    const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const safeName = String(data.agent.name || ('agent' + staffId)).replace(/[^a-zA-Z0-9_-]/g, '_');
    const fileName = `settlement_${safeName}_${full ? 'full' : 'summary'}_${stamp}.pdf`;

    // Persist a copy to disk (best-effort archive) and stream to the client.
    try { fs.mkdirSync(SAVE_DIR, { recursive: true }); } catch (_) {}
    const doc = new PDFDocument({ size: 'A4', margin: 40 });
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
    doc.pipe(res);
    try { doc.pipe(fs.createWriteStream(path.join(SAVE_DIR, fileName))); } catch (_) {}

    renderPdf(doc, data, { full, from, to, generatedAt });
    doc.end();
  } catch (err) {
    if (!res.headersSent) next(err);
    else { try { res.end(); } catch (_) {} }
  }
};
