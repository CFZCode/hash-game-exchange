/* ──────────────────────────────────────────────────────────────────────────
   ACCOUNT STATEMENT  (PDF)  —  the printable form of the on-screen report

   GET /api/admin/agent-report/:staffId/pdf
   GET /api/admin/agent-report/user/:userId/pdf
        ?from=YYYY-MM-DD &to=YYYY-MM-DD

   Rendered from the SAME builder the screen calls (report/statement.js), so a
   printed statement can never disagree with what the operator was looking at.
   Works for agents and players alike — the builder already normalises both into
   one shape and marks which side of the P&L the subject keeps.

   Unlike the screen, the ledger is not paginated: a statement you hand to
   somebody has to carry every row for the period. The bet lists are bounded
   (they can run to tens of thousands of rows) and say so on the page when they
   are cut — a printed report must never look complete when it is not.
   ────────────────────────────────────────────────────────────────────────── */
const fs = require('fs');
const path = require('path');
const PDFDocument = require('pdfkit');
const pg = require('../General/Model');
const { buildAgentStatement, buildUserStatement } = require('./statement');

const SAVE_DIR = path.join(__dirname, 'generated');
const BET_LIMIT = 2000;   // per list; anything beyond is reported, not hidden

const money = (n) =>
  (Number(n) || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const signed = (n) => {
  const v = Number(n) || 0;
  return `${v > 0 ? '+' : v < 0 ? '-' : ''}${money(Math.abs(v))}`;
};
const cleanDate = (s) => (typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) ? s : null);
const dt = (iso) => (iso ? new Date(iso).toISOString().slice(0, 16).replace('T', ' ') : '-');

const C = {
  ink: '#1a1a1a', sub: '#555', line: '#cccccc', head: '#0b3d2e', headbg: '#0b3d2e',
  zebra: '#f3f6f4', red: '#b00020', green: '#0a7d3c', amber: '#9a6b00',
};

/* Small layout kit — same visual language as the agent settlement report. */
function makeCanvas(doc) {
  const M = 40, CW = doc.page.width - 2 * M;
  const s = { y: M };
  const newPageIf = (need) => { if (s.y + need > doc.page.height - M) { doc.addPage(); s.y = M; } };

  const h1 = (t) => {
    newPageIf(46);
    doc.fillColor(C.head).font('Helvetica-Bold').fontSize(16).text(t, M, s.y);
    s.y = doc.y + 4;
  };
  const h2 = (t) => {
    newPageIf(44);
    doc.fillColor(C.head).font('Helvetica-Bold').fontSize(12).text(t, M, s.y);
    s.y = doc.y + 2;
    doc.moveTo(M, s.y).lineTo(M + CW, s.y).strokeColor(C.head).lineWidth(1).stroke();
    s.y += 6;
  };
  const para = (t, o = {}) => {
    doc.fillColor(o.color || C.ink).font(o.bold ? 'Helvetica-Bold' : 'Helvetica')
      .fontSize(o.size || 9).text(t, M, s.y, { width: CW });
    s.y = doc.y + (o.gap == null ? 4 : o.gap);
  };

  function table(cols, rows, o = {}) {
    const fs0 = o.fontSize || 8, pad = 4, rh = o.rowH || 14;
    const drawHead = () => {
      newPageIf(rh + 4);
      let x = M;
      doc.rect(M, s.y, CW, rh).fill(C.headbg);
      doc.fillColor('#ffffff').font('Helvetica-Bold').fontSize(fs0);
      cols.forEach((c) => {
        doc.text(c.label, x + pad, s.y + 3,
          { width: c.w - 2 * pad, align: c.align || 'left', lineBreak: false, height: rh });
        x += c.w;
      });
      s.y += rh;
    };
    drawHead();
    rows.forEach((row, i) => {
      newPageIf(rh);
      if (s.y === M) drawHead();
      if (i % 2) doc.rect(M, s.y, CW, rh).fill(C.zebra);
      let x = M;
      cols.forEach((c, ci) => {
        const cell = row[ci];
        const obj = cell && typeof cell === 'object';
        doc.fillColor(obj && cell.color ? cell.color : C.ink)
          .font(obj && cell.bold ? 'Helvetica-Bold' : 'Helvetica').fontSize(fs0)
          .text(String(obj ? cell.t : cell), x + pad, s.y + 3,
            { width: c.w - 2 * pad, align: c.align || 'left', lineBreak: false, height: rh, ellipsis: true });
        x += c.w;
      });
      doc.moveTo(M, s.y + rh).lineTo(M + CW, s.y + rh).strokeColor(C.line).lineWidth(0.4).stroke();
      s.y += rh;
    });
    s.y += 6;
  }

  return { M, CW, state: s, h1, h2, para, table, newPageIf };
}

function periodText(period) {
  if (!period.from && !period.to) return 'All time';
  if (period.from && period.to && period.from === period.to) return period.from;
  return `${period.from || 'start'} to ${period.to || 'now'}`;
}

function render(doc, data, extra) {
  const { subject, period, balance, gaming, daily, rows } = data;
  const { sportsBets, casinoTxns, sportsTotal, casinoTotal, generatedAt } = extra;
  const isAgent = subject.type === 'STAFF';
  const t = gaming.total;

  const k = makeCanvas(doc);
  const { M, CW } = k;

  /* ---------- header ---------- */
  doc.rect(0, 0, doc.page.width, 86).fill(C.headbg);
  doc.fillColor('#ffffff').font('Helvetica-Bold').fontSize(20)
    .text(isAgent ? 'AGENT ACCOUNT STATEMENT' : 'PLAYER ACCOUNT STATEMENT', M, 24);
  doc.font('Helvetica').fontSize(10).fillColor('#d9e7e0')
    .text(`${subject.name}  ·  ${subject.role}${subject.agent_code ? `  ·  code ${subject.agent_code}` : ''}`
      + `${subject.parent_name ? `  ·  under ${subject.parent_name}` : ''}`, M, 52);
  doc.fontSize(9)
    .text(`Generated ${generatedAt}  ·  Period: ${periodText(period)}  ·  Currency: INR`, M, 66);
  k.state.y = 100;

  /* ---------- 1. result ---------- */
  const profit = t.headline_pnl >= 0;
  k.h2('1.  Result for this period');
  k.table(
    [{ label: 'Line', w: CW * 0.62 }, { label: 'Amount (Rs)', w: CW * 0.38, align: 'right' }],
    [
      [{ t: profit ? 'TOTAL PROFIT' : 'TOTAL LOSS', bold: true },
       { t: money(Math.abs(t.headline_pnl)), color: profit ? C.green : C.red, bold: true }],
      ['Sports', { t: signed(t.headline_sports), color: t.headline_sports >= 0 ? C.green : C.red }],
      ['Casino', { t: signed(t.headline_casino), color: t.headline_casino >= 0 ? C.green : C.red }],
    ],
    { rowH: 16 }
  );
  k.para(isAgent
    ? 'This is what the downline\'s betting earned the agent — a player\'s loss is the agent\'s gain.'
    : 'This is the player\'s own betting result. Positive means the player is ahead.',
    { size: 8, color: C.sub, gap: 8 });

  /* ---------- 2. balance ---------- */
  k.h2('2.  Balance');
  const balRows = [
    ['Previous balance (brought forward)', money(balance.opening)],
    ['Money in', { t: '+ ' + money(balance.total_in), color: C.green }],
    ['Money out', { t: '- ' + money(balance.total_out), color: C.red }],
    [{ t: 'Net change', bold: true },
     { t: signed(balance.movement), color: balance.movement >= 0 ? C.green : C.red, bold: true }],
    [{ t: 'Closing balance', bold: true }, { t: money(balance.closing), bold: true }],
    ['Actual balance now', money(balance.live)],
  ];
  if (!isAgent && balance.open_exposure) {
    balRows.push(['Held in open bets (not yet settled)', { t: money(balance.open_exposure), color: C.amber }]);
  }
  k.table([{ label: 'Line', w: CW * 0.62 }, { label: 'Amount (Rs)', w: CW * 0.38, align: 'right' }],
    balRows, { rowH: 15 });

  /* ---------- 3. what was done ---------- */
  k.h2('3.  Deposits & withdrawals');
  const moveRows = isAgent
    ? [
      ['Deposit received from upline', { t: money(balance.deposit_in), color: C.green }],
      ['Withdrawn by upline', { t: money(balance.withdraw_out), color: C.red }],
      ['Deposits given to players', { t: money(balance.given_players), color: C.red }],
      ['Deposits given to sub-agents', { t: money(balance.given_agents), color: C.red }],
      ['Withdrawals collected from players', { t: money(balance.collected_players), color: C.green }],
      ['Withdrawals collected from sub-agents', { t: money(balance.collected_agents), color: C.green }],
    ]
    : [
      ['Deposit by agent', { t: money(balance.deposit_in), color: C.green }],
      ['Withdrawn by agent', { t: money(balance.withdraw_out), color: C.red }],
      ['Bank / gateway in', { t: money(balance.bank_in || 0), color: C.green }],
      ['Bank / gateway out', { t: money(balance.bank_out || 0), color: C.red }],
    ];
  k.table([{ label: 'Action', w: CW * 0.62 }, { label: 'Amount (Rs)', w: CW * 0.38, align: 'right' }],
    moveRows, { rowH: 15 });

  if (Math.abs(balance.unexplained) >= 1) {
    k.para(`Note: ${money(Math.abs(balance.unexplained))} of the balance predates this ledger and is carried in the `
      + 'previous balance (old settlement postings). The deposits and withdrawals listed here are exact.',
      { size: 7.5, color: C.amber, gap: 8 });
  }

  /* ---------- 4. day by day ---------- */
  k.h2('4.  Day by day');
  if (daily.length) {
    k.table([
      { label: 'Date', w: CW * 0.2 },
      { label: 'Deposits', w: CW * 0.16, align: 'right' },
      { label: 'Withdrawals', w: CW * 0.16, align: 'right' },
      { label: 'Sports', w: CW * 0.16, align: 'right' },
      { label: 'Casino', w: CW * 0.16, align: 'right' },
      { label: 'Day P&L', w: CW * 0.16, align: 'right' },
    ], daily.map((d) => {
      const pnl = d.sports_pnl + d.casino_pnl;
      return [
        d.date, money(d.deposit), money(d.withdraw),
        { t: signed(d.sports_pnl), color: d.sports_pnl >= 0 ? C.green : C.red },
        { t: signed(d.casino_pnl), color: d.casino_pnl >= 0 ? C.green : C.red },
        { t: signed(pnl), color: pnl >= 0 ? C.green : C.red, bold: true },
      ];
    }), { rowH: 13 });
  } else {
    k.para('No activity in this period.', { size: 8.5, color: C.sub, gap: 8 });
  }

  /* ---------- 5. the statement ---------- */
  k.h2('5.  Account statement');
  if (rows.length) {
    k.table([
      { label: 'Date & time', w: CW * 0.16 },
      { label: 'Action', w: CW * 0.22 },
      { label: 'With', w: CW * 0.18 },
      { label: 'In', w: CW * 0.14, align: 'right' },
      { label: 'Out', w: CW * 0.14, align: 'right' },
      { label: 'Balance', w: CW * 0.16, align: 'right' },
    ], rows.map((r) => [
      dt(r.ts), r.label, r.party || '-',
      r.amount >= 0 ? { t: money(r.amount), color: C.green } : '',
      r.amount < 0 ? { t: money(Math.abs(r.amount)), color: C.red } : '',
      { t: money(r.balance), bold: true },
    ]), { rowH: 13 });
    k.table([{ label: 'Previous balance (brought forward)', w: CW * 0.84 },
      { label: money(balance.opening), w: CW * 0.16, align: 'right' }], [], { rowH: 14 });
  } else {
    k.para('Nothing happened on this account in this period.', { size: 8.5, color: C.sub, gap: 8 });
  }

  /* ---------- 6. sports bets ---------- */
  doc.addPage(); k.state.y = M;
  k.h1('6.  Sports bets');
  k.para(`${sportsTotal} bet${sportsTotal === 1 ? '' : 's'} in this period`
    + (sportsBets.length < sportsTotal ? ` — showing the most recent ${sportsBets.length}.` : '.'),
    { size: 8.5, color: sportsBets.length < sportsTotal ? C.amber : C.sub, gap: 6 });
  if (sportsBets.length) {
    k.table([
      { label: 'Placed', w: CW * 0.14 },
      { label: 'Player', w: CW * 0.12 },
      { label: 'Match', w: CW * 0.22 },
      { label: 'Selection', w: CW * 0.18 },
      { label: 'Market', w: CW * 0.11 },
      { label: 'Side', w: CW * 0.06 },
      { label: 'Odds', w: CW * 0.06, align: 'right' },
      { label: 'Stake', w: CW * 0.11, align: 'right' },
    ], sportsBets.map((b) => [
      dt(b.ts), b.user, b.match, b.selection, b.market, b.side, String(b.odds), money(b.stake),
    ]), { rowH: 12, fontSize: 7 });
  }

  /* ---------- 7. casino ---------- */
  k.h1('7.  Casino transactions');
  k.para(`${casinoTotal} transaction${casinoTotal === 1 ? '' : 's'} in this period`
    + (casinoTxns.length < casinoTotal ? ` — showing the most recent ${casinoTxns.length}.` : '.'),
    { size: 8.5, color: casinoTxns.length < casinoTotal ? C.amber : C.sub, gap: 6 });
  if (casinoTxns.length) {
    k.table([
      { label: 'Time', w: CW * 0.18 },
      { label: 'Player', w: CW * 0.16 },
      { label: 'Game', w: CW * 0.28 },
      { label: 'Action', w: CW * 0.1 },
      { label: 'Round', w: CW * 0.16 },
      { label: 'Amount', w: CW * 0.12, align: 'right' },
    ], casinoTxns.map((c) => [
      dt(c.ts), c.user, c.game, c.action, c.round || '-',
      { t: signed(c.amount), color: c.amount >= 0 ? C.green : C.red },
    ]), { rowH: 12, fontSize: 7 });
  }
}

/* Pull the bet lists straight from the DB — the statement payload deliberately
   leaves them out because they are unbounded. */
async function fetchBets(sqlPlayerIds, from, to) {
  if (!sqlPlayerIds.length) return { sportsBets: [], casinoTxns: [], sportsTotal: 0, casinoTotal: 0 };
  const clause = (col) => {
    let s = '';
    if (from) s += ` AND ${col} >= '${from}'::date`;
    if (to) s += ` AND ${col} < ('${to}'::date + INTERVAL '1 day')`;
    return s;
  };
  const ids = sqlPlayerIds;

  const sportsCount = (await pg.query(
    `SELECT COUNT(*)::int n FROM "SportsBet" WHERE user_id = ANY($1::bigint[]) ${clause('created_at')}`,
    [ids])).rows[0].n;
  const sportsBets = (await pg.query(
    `SELECT b.id, b.created_at ts, u.name user_name, b.user_id, b.match_title, b.event_name,
            b.selection_name, b.fancy_name, b.market_type, b.game_type, b.bet_type, b.odds, b.stake_amount
       FROM "SportsBet" b LEFT JOIN users u ON u.id = b.user_id
      WHERE b.user_id = ANY($1::bigint[]) ${clause('b.created_at')}
      ORDER BY b.created_at DESC NULLS LAST, b.id DESC LIMIT ${BET_LIMIT}`, [ids])).rows;

  const TS = 'COALESCE(transaction_datetime, created_at)';
  const casinoCount = (await pg.query(
    `SELECT COUNT(*)::int n FROM gis_transactions
      WHERE user_id = ANY($1::bigint[]) AND upper(currency) IN ('INR','PKR') ${clause(TS)}`, [ids])).rows[0].n;
  const casinoTxns = (await pg.query(
    `SELECT g.id, COALESCE(g.transaction_datetime, g.created_at) ts, u.name user_name, g.user_id,
            g.action, g.amount, g.round_id, g.game_uuid, gg.name game_name
       FROM gis_transactions g
       LEFT JOIN users u ON u.id = g.user_id
       LEFT JOIN gis_games gg ON gg.uuid = g.game_uuid
      WHERE g.user_id = ANY($1::bigint[]) AND upper(g.currency) IN ('INR','PKR')
        ${clause('COALESCE(g.transaction_datetime, g.created_at)')}
      ORDER BY ts DESC NULLS LAST, g.id DESC LIMIT ${BET_LIMIT}`, [ids])).rows;

  const txt = (...v) => {
    for (const x of v) {
      const s = x == null ? '' : String(x).trim();
      if (s && s.toLowerCase() !== 'null') return s;
    }
    return '-';
  };

  return {
    sportsTotal: sportsCount,
    casinoTotal: casinoCount,
    sportsBets: sportsBets.map(b => ({
      ts: b.ts, user: txt(b.user_name, b.user_id),
      match: txt(b.match_title, b.event_name),
      selection: txt(b.fancy_name, b.selection_name),
      market: txt(b.market_type, b.game_type),
      side: txt(b.bet_type), odds: Number(b.odds) || 0, stake: Number(b.stake_amount) || 0,
    })),
    casinoTxns: casinoTxns.map(c => ({
      ts: c.ts, user: txt(c.user_name, c.user_id), action: c.action,
      game: txt(c.game_name, c.game_uuid), round: c.round_id || null,
      amount: (Number(c.amount) || 0) * (c.action === 'bet' ? -1 : 1),
    })),
  };
}

function makeHandler(isUser) {
  return async (req, res, next) => {
    try {
      const from = cleanDate(req.query.from);
      const to = cleanDate(req.query.to);
      // The ledger is not paginated in print — a handed-over statement carries
      // every row for the period.
      const opt = { from, to, category: 'all', page: 1, limit: 100000, bad: !!(from && to && from > to) };

      const id = isUser ? req.params.userId : req.params.staffId;
      const data = isUser
        ? await buildUserStatement(id, opt, req.staff.id)
        : await buildAgentStatement(id, opt, req.staff.id);
      if (data.error) return res.status(data.error.code).json({ status: 'fail', message: data.error.message });

      const playerIds = isUser
        ? [Number(id)]
        : data.players.map(p => Number(p.id));
      const bets = await fetchBets(playerIds, from, to);

      const generatedAt = new Date().toISOString().slice(0, 10);
      const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
      const safe = String(data.subject.name || id).replace(/[^a-zA-Z0-9_-]/g, '_');
      const fileName = `statement_${safe}_${from || 'all'}_${to || 'now'}_${stamp}.pdf`;

      try { fs.mkdirSync(SAVE_DIR, { recursive: true }); } catch (_) { /* archive is best-effort */ }
      const doc = new PDFDocument({ size: 'A4', margin: 40 });
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
      doc.pipe(res);
      try { doc.pipe(fs.createWriteStream(path.join(SAVE_DIR, fileName))); } catch (_) { /* ditto */ }

      render(doc, data, { ...bets, generatedAt });
      doc.end();
    } catch (err) {
      if (!res.headersSent) next(err);
      else { try { res.end(); } catch (_) { /* stream already torn down */ } }
    }
  };
}

exports.generateAgentStatementPdf = makeHandler(false);
exports.generateUserStatementPdf = makeHandler(true);
