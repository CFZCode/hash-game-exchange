module.exports = {
  // apps: [
  //   {
  //     name: "results-cron-fcm",
  //     script: "./job.js",
  //     // run every 5 min internally (we already coded setInterval)
  //     // tune envs as you prefer:
  //     env: {
  //       NODE_ENV: "production",
  //       DEBUG: "1",
  //       RESULTS_API_BASE: "https://api.lagaobet.com",
  //       API_TIMEOUT_MS: "30000",
  //       MAX_CONCURRENT_API: "3",
  //       USER_BATCH_CONCURRENCY: "5",
  //       RESULTS_REQUEUE_MS: "120000",
  //       CRON_INTERVAL_MS: "60000",            // 5 minutes
  //       SUMMARY_KEEP_PER_EVENT: "5",
  //       SUMMARY_RETENTION_DAYS: "7",
  //       BET_CACHE_TTL_DAYS: "14",
  //       RESULTS_CRON_LOG_DIR: "/var/www/html/hellogames/myapp/backend/sportsbet/logs"
  //     },
  //     // optional extras:
  //     instances: 1,           // keep it 1; code is not clustered for concurrency
  //     exec_mode: "fork",
  //     watch: false,
  //     max_restarts: 10,
  //     // PM2 log files (app logs are also written to your own file under LOG_DIR)
  //     error_file: "logs/results-cron-error.log",
  //     out_file: "logs/results-cron-out.log",
  //     time: true
  //   },
  //   {
  //     name: "settlement-worker-fcm",
  //     script: "./settlementWorker.js",
  //     env: {
  //       NODE_ENV: "production",
  //       DEBUG: "1",
  //       RESULTS_API_BASE: "https://api.lagaobet.com",
  //       API_TIMEOUT_MS: "15000",
  //       SETTLE_POLL_MS: "20000",             // 5 minutes
  //       SETTLE_BATCH_LIMIT: "10",
  //       SETTLE_REQUEUE_MS: "10000",
  //       LEDGER_ZERO_ROWS: "0",
  //       SETTLEMENT_LOG_DIR: "/var/www/html/hellogames/myapp/backend/sportsbet/logs"
  //     },
  //     instances: 1,           // keep it 1 to avoid double-settlements
  //     exec_mode: "fork",
  //     watch: false,
  //     max_restarts: 10,
  //     error_file: "logs/settlement-worker-error.log",
  //     out_file: "logs/settlement-worker-out.log",
  //     time: true
  //   }
  // ]
};
