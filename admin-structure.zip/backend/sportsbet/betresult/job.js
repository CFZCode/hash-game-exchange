'use strict';

const fs = require('fs');
const path = require('path');
const db = require('../../General/Model');
const crypto = require('crypto');
const http = require('http');
const https = require('https');
const axios = require('axios');

// ---------- logging ----------
const DEBUG = process.env.DEBUG === '1' || process.env.DEBUG === 'true';
const LOG_DIR = process.env.RESULTS_CRON_LOG_DIR || '/var/www/html/hellogames/myapp/backend/sportsbet/logs';
const LOG_BASENAME = 'results-cron';
function ensureLogDir() { try { fs.mkdirSync(LOG_DIR, { recursive: true }); } catch (_) { } }
ensureLogDir();
function currentLogPath() {
  const d = new Date(), yyyy = d.getFullYear(), mm = String(d.getMonth() + 1).padStart(2, '0'), dd = String(d.getDate()).padStart(2, '0');
  return path.join(LOG_DIR, `${LOG_BASENAME}-${yyyy}-${mm}-${dd}.log`);
}
function writeLog(level, msg, ctx = {}) {
  const ctxStr = Object.keys(ctx).length ? ' ' + JSON.stringify(ctx) : '';
  const line = `[${new Date().toISOString()}] [${level}] ${msg}${ctxStr}\n`;
  if (level === 'ERROR') console.error(msg, ctx); else console.log(msg, ctx);
  try { fs.appendFileSync(currentLogPath(), line, 'utf8'); } catch (e) { console.error('Log write failed:', e.message); }
}
const log = {
  info: (m, c = {}) => writeLog('INFO', m, c),
  error: (m, c = {}) => writeLog('ERROR', m, c),
  debug: (m, c = {}) => { if (DEBUG) writeLog('DEBUG', m, c); },
};

// ---------- env ----------
const RESULTS_API_BASE = process.env.RESULTS_API_BASE || 'https://api.lagaobet.com';
const RESULTS_ENDPOINT = '/sports/event-result?eventid=';
const API_TIMEOUT_MS = +(process.env.API_TIMEOUT_MS || 30000);
const MAX_CONCURRENT_API = +(process.env.MAX_CONCURRENT_API || 3);
const USER_BATCH_CONCURRENCY = +(process.env.USER_BATCH_CONCURRENCY || 5);
const RESULTS_REQUEUE_MS = +(process.env.RESULTS_REQUEUE_MS || 120000);
const CRON_INTERVAL_MS = +(process.env.CRON_INTERVAL_MS || 300000);
const SUMMARY_KEEP_PER_EVENT = +(process.env.SUMMARY_KEEP_PER_EVENT || 5);
const SUMMARY_RETENTION_DAYS = +(process.env.SUMMARY_RETENTION_DAYS || 7);
const BET_CACHE_TTL_DAYS = +(process.env.BET_CACHE_TTL_DAYS || 14);
const RESULTS_MAX_FETCH_RETRIES = +(process.env.RESULTS_MAX_FETCH_RETRIES || 6);
const RESULTS_RETRY_BASE_MS = +(process.env.RESULTS_RETRY_BASE_MS || 500);
const RESULTS_FORCE_IPV4 = process.env.RESULTS_FORCE_IPV4 === '1' || process.env.RESULTS_FORCE_IPV4 === 'true';
const RESULTS_DISABLE_KEEPALIVE = process.env.RESULTS_DISABLE_KEEPALIVE === '1' || process.env.RESULTS_DISABLE_KEEPALIVE === 'true';
const RESULTS_RATE_LIMIT_MS = +(process.env.RESULTS_RATE_LIMIT_MS || 250); // actively used

// ---------- axios client ----------
const httpAgent = new http.Agent({ keepAlive: !RESULTS_DISABLE_KEEPALIVE, family: RESULTS_FORCE_IPV4 ? 4 : undefined });
const httpsAgent = new https.Agent({ keepAlive: !RESULTS_DISABLE_KEEPALIVE, family: RESULTS_FORCE_IPV4 ? 4 : undefined });

const ax = axios.create({
  timeout: API_TIMEOUT_MS,
  httpAgent, httpsAgent,
  validateStatus: () => true,
  headers: {
    'Accept': 'application/json',
    'User-Agent': `results-cron/1.0 (+node ${process.version})`
  }
});

function formatName(name) {
  console.log('Formatting name:', name);

  if (!name || typeof name !== 'string') return '';

  // Remove all spaces and convert to lowercase
  let formatted = name.replace(/\s+/g, '').toLowerCase();

  // Remove trailing period if present
  if (formatted.endsWith('.')) {
    formatted = formatted.slice(0, -1);
  }

  return formatted;
}

function checkExpiration(endTime) {
  const isoEndTime = endTime

  const end = new Date(isoEndTime);
  const now = new Date();

  const expired = now.getTime() > end.getTime();

  let remaining = null;
  if (!expired) {
    let diff = end.getTime() - now.getTime();

    const hours = Math.floor(diff / (1000 * 60 * 60));
    diff -= hours * 1000 * 60 * 60;

    const minutes = Math.floor(diff / (1000 * 60));
    diff -= minutes * 1000 * 60;

    const seconds = Math.floor(diff / 1000);

    remaining = { hours, minutes, seconds };
  }

  return { expired, remaining };
}


// ---------- utils ----------
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function jitter(ms) { return Math.round(ms * (1 + Math.random() * 0.25)); }
function uuidv4() { return crypto.randomUUID ? crypto.randomUUID() : crypto.randomBytes(16).toString('hex'); }
function peekBody(data, max = 200) {
  try {
    const s = typeof data === 'string' ? data : JSON.stringify(data);
    return s.slice(0, max);
  } catch { return ''; }
}
function parseRetryAfter(h) {
  if (!h) return null;
  const n = Number(h);
  if (!Number.isNaN(n)) return Math.max(0, Math.round(n * 1000)); // seconds → ms
  const d = Date.parse(h);
  return Number.isNaN(d) ? null : Math.max(0, d - Date.now());
}
// per-attempt transport fallback: after 3rd attempt, disable keep-alive + force IPv4, add Connection: close
function buildPerAttemptConfig(attempt) {
  if (attempt >= 3) {
    return {
      httpAgent: new http.Agent({ keepAlive: false, family: 4 }),
      httpsAgent: new https.Agent({ keepAlive: false, family: 4 }),
      headers: { 'Connection': 'close' }
    };
  }
  return {};
}

let lastApiCallAt = 0;
async function globalRateLimit() {
  const gap = RESULTS_RATE_LIMIT_MS > 0 ? RESULTS_RATE_LIMIT_MS : 0;
  const now = Date.now();
  const wait = Math.max(0, lastApiCallAt + gap - now);
  if (wait) await sleep(wait);
  lastApiCallAt = Date.now();
}

class AsyncQueue {
  constructor(max) { this.max = max; this.running = 0; this.q = []; }
  push(task) { return new Promise((res, rej) => { this.q.push({ task, res, rej }); this._next(); }); }
  _next() {
    if (this.running >= this.max) return;
    const n = this.q.shift(); if (!n) return;
    this.running++;
    n.task().then(n.res, n.rej).finally(() => { this.running--; this._next(); });
  }
}
const apiQueue = new AsyncQueue(MAX_CONCURRENT_API);

// ---------- schema ----------
async function ensureTables() {
  await db.query(`
    CREATE TABLE IF NOT EXISTS public.sports_event_result_scan(
      user_id TEXT NOT NULL,
      eventid TEXT NOT NULL,
      declared BOOLEAN NOT NULL DEFAULT FALSE,
      counts JSONB NOT NULL DEFAULT '{}'::jsonb,
      checked_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      CONSTRAINT sports_event_result_scan_pk PRIMARY KEY (user_id,eventid)
    );
    CREATE TABLE IF NOT EXISTS public.sports_event_result_summary(
      id BIGSERIAL PRIMARY KEY,
      user_id TEXT NOT NULL,
      eventid TEXT NOT NULL,
      declared BOOLEAN NOT NULL,
      counts JSONB NOT NULL,
      result_meta JSONB NULL,
      sections JSONB NULL,
      recorded_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
    CREATE TABLE IF NOT EXISTS public.sports_event_settlement_jobs(
      job_id UUID PRIMARY KEY,
      user_id TEXT NOT NULL,
      eventid TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'queued',
      priority INT NOT NULL DEFAULT 5,
      run_after TIMESTAMPTZ NOT NULL DEFAULT now(),
      payload JSONB NOT NULL,
      error_msg TEXT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      CONSTRAINT settlement_jobs_unique UNIQUE (user_id,eventid)
    );
    CREATE TABLE IF NOT EXISTS public.sports_bet_result_cache(
      user_id TEXT NOT NULL,
      eventid TEXT NOT NULL,
      match_id TEXT NOT NULL,
      bucket TEXT NOT NULL,
      declared BOOLEAN NOT NULL DEFAULT FALSE,
      is_match_over BOOLEAN NOT NULL DEFAULT FALSE,
      winner_name TEXT NULL,
      winner_id BIGINT NULL,
      market_id TEXT NULL,
      market_name TEXT NULL,
      provider TEXT NULL,
      betting_type TEXT NULL,
      declared_at TIMESTAMPTZ NULL,
      api_snapshot JSONB NULL,
      recorded_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      CONSTRAINT sports_bet_result_cache_pk PRIMARY KEY (user_id,eventid,match_id,bucket)
    );
    ALTER TABLE public.sports_bets ADD COLUMN IF NOT EXISTS job_id UUID NULL;
  `);
  log.info('[ResultCron] tables ensured.');
}

// ---------- fetchers (queued + throttled + retry-after + transport fallback) ----------
async function fetchResultForEvent(eventid, name) {
  console.log('fetchResultForEvent', eventid, name);
  const url = `${RESULTS_API_BASE}${RESULTS_ENDPOINT}${encodeURIComponent(eventid)}`;
  log.debug('[ResultCron] fetchResultForEvent start', { eventid, url });

  const maxAttempts = RESULTS_MAX_FETCH_RETRIES || 6;

  return apiQueue.push(async () => {
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        await globalRateLimit();
        const res = await ax.get(url, buildPerAttemptConfig(attempt));

        log.debug('[ResultCron] event fetch response', {
          eventid, attempt, status: res.status, peek: peekBody(res.data)
        });

        if (res.status === 200) {
          const data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
          const items = Array.isArray(data?.items) ? data.items : [];

          let declared = false;

          for (const item of items) {
            // console.log('Comparing', formatName(item.marketName), 'to', name);
            if (formatName(item.marketName) === name) {
              if (item.resultStatus === 'RESULT_DECLARED') {
                declared = true;
                break;
              }
            }
          }

          log.debug('[ResultCron] event fetch success', {
            eventid, items: items.length, declared
          });

          return { declared, items };
        }

        if (res.status === 429 || (res.status >= 500 && res.status <= 599)) {
          const ra = parseRetryAfter(res.headers?.['retry-after']);
          const wait = ra != null ? ra : jitter(RESULTS_RETRY_BASE_MS * Math.pow(2, attempt - 1));
          log.debug('[ResultCron] event fetch retry backoff', { eventid, attempt, status: res.status, retryAfterMs: ra ?? null, waitMs: wait });
          await sleep(wait);
          continue;
        }

        return { declared: false, items: [] };

      } catch (e) {
        const wait = jitter(RESULTS_RETRY_BASE_MS * Math.pow(2, attempt - 1));
        log.error('[ResultCron] event fetch error', { eventid, attempt, error: e.message, nextWaitMs: wait });
        await sleep(wait);
      }
    }
    log.debug('[ResultCron] event fetch exhausted', { eventid });
    return { declared: false, items: [] };
  });
}

async function fetchMarketOdds(marketId) {
  const url = `${RESULTS_API_BASE}/sports/market-odds?market_id=${encodeURIComponent(marketId)}`;
  log.debug('[ResultCron] fetchMarketOdds start', { marketId, url });

  const maxAttempts = RESULTS_MAX_FETCH_RETRIES || 6;

  return apiQueue.push(async () => {
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        await globalRateLimit();
        const res = await ax.get(url, buildPerAttemptConfig(attempt));

        log.debug('[ResultCron] fetchMarketOdds response', {
          marketId, attempt, status: res.status, peek: peekBody(res.data)
        });

        if (res.status === 200) {
          const market = Array.isArray(res.data) ? res.data[0] : null;
          log.debug('[ResultCron] fetchMarketOdds data', { marketId, statusField: market?.status });
          const closed = (market?.status || '').toUpperCase() === 'CLOSED';
          return { closed, market };
        }

        if (res.status === 429 || (res.status >= 500 && res.status <= 599)) {
          const ra = parseRetryAfter(res.headers?.['retry-after']);
          const wait = ra != null ? ra : jitter(RESULTS_RETRY_BASE_MS * Math.pow(2, attempt - 1));
          log.debug('[ResultCron] fetchMarketOdds retry backoff', { marketId, attempt, status: res.status, retryAfterMs: ra ?? null, waitMs: wait });
          await sleep(wait);
          continue;
        }

        // Other non-200 responses: stop retrying
        return { closed: false, market: null };

      } catch (e) {
        const wait = jitter(RESULTS_RETRY_BASE_MS * Math.pow(2, attempt - 1));
        log.error('[ResultCron] fetchMarketOdds error', { marketId, attempt, error: e.message, nextWaitMs: wait });
        await sleep(wait);
      }
    }
    log.debug('[ResultCron] fetchMarketOdds exhausted', { marketId });
    return { closed: false, market: null };
  });
}

// ---------- queries ----------
async function getUserToken(uid) {
  try {
    const { rows } = await db.query(
      `SELECT key FROM tokens WHERE uid = $1 LIMIT 1`,
      [String(uid)]
    );
    return rows.length ? rows[0].key : null;
  } catch (e) {
    log.error('[ResultCron] getUserToken error', { uid, error: e.message });
    return null;
  }
}
async function getUsersWithOpenBets() {
  const { rows } = await db.query(`
    SELECT DISTINCT user_id::text AS user_id
    FROM public.sports_bets
    WHERE status='open'
      AND game_type IN ('MO','BM','FAN')
      AND eventid IS NOT NULL
  `);
  log.debug('[ResultCron] getUsersWithOpenBets', { count: rows.length });
  return rows || [];
}

async function getOpenBetsForUser(userId) {
  const { rows } = await db.query(`
    SELECT id, user_id::text AS user_id, game_type, bet_type, selection_name,
           odds, stake_amount, match_title, match_id::text AS match_id,fancy_name,
           eventid::text AS eventid, created_at
    FROM public.sports_bets
    WHERE user_id::text=$1
      AND status='open'
      AND game_type IN ('MO','BM','FAN')
      AND eventid IS NOT NULL
  `, [String(userId)]);
  log.debug('[ResultCron] getOpenBetsForUser', { userId, openBets: rows.length });
  return rows || [];
}

// ---------- pruning ----------
async function pruneSummaries() {
  await db.query(`DELETE FROM public.sports_event_result_summary WHERE recorded_at < now() - ($1 || ' days')::interval`, [SUMMARY_RETENTION_DAYS]);
  log.debug('[ResultCron] pruneSummaries done');
}
async function pruneBetCache() {
  await db.query(`DELETE FROM public.sports_bet_result_cache WHERE recorded_at < now() - ($1 || ' days')::interval`, [BET_CACHE_TTL_DAYS]);
  log.debug('[ResultCron] pruneBetCache done');
}

// ---------- main run ----------
// async function runOnce() {
//   log.info('[ResultCron] ===== Run start =====');
//   try {
//     await ensureTables();

//     // Fetch all open bets (one big list)
//     const { rows: allBets } = await db.query(`
//       SELECT id, user_id::text AS user_id, game_type, bet_type, selection_name,
//              odds, stake_amount, match_title, match_id::text AS match_id, fancy_name,status,
//              eventid::text AS eventid, created_at,enddatemax
//       FROM public.sports_bets
//       WHERE status IN ('open', 'manual','refund')
//         AND game_type IN ('MO','BM','FAN')
//         AND eventid IS NOT NULL
//       ORDER BY created_at ASC
//     `);

//     if (!allBets || !allBets.length) {
//       log.info('[ResultCron] no open bets.');
//       return;
//     }
//     log.debug('[ResultCron] fetched open bets', { count: allBets.length });

//     // Process each bet sequentially
//     for (const b of allBets) {
//       try {
//         // Basic sanity checks
//         if (!b.eventid) {
//           log.debug('[ResultCron] skipping bet with no eventid', { betId: b.id });
//           continue;
//         }

//         const userId = b.user_id;
//         const eid = b.eventid;
//         const gameType = (b.game_type || '').toUpperCase();
//         const Status = (b.status || '').toLowerCase();
//         console.log('Processing bet', { betId: b.id, user: userId, eventid: eid, gameType, Status });

//         log.debug('[ResultCron] processing single bet', { betId: b.id, user: userId, eventid: eid, gameType });

//         let declared = false;

//         let result_meta = null;
//         let api = null;

//         if (gameType === 'FAN') {

//           const marketId = b.match_id;
//           const name = b.fancy_name || '';

//           const formattedName = formatName(name);

//           // refund manual logic here
//           if (Status === 'refund') {
//             const amt = b.stake_amount;
//             const res = await db.query(
//               `UPDATE public.credits
//      SET inr = COALESCE(inr, 0) + $1
//      WHERE uid::text = $2
//      RETURNING inr`,
//               [amt, String(userId)]
//             );
//             const rest = await db.query(
//               `UPDATE public.sports_bets
//    SET status = 'closed',
//        result_status = 'refund'
//    WHERE fancy_name = $1
//      AND id = $2
//    RETURNING *`,
//               [name, b.id]


//             );
//             console.log('Refund processed for user:', userId, 'Amount:', amt, 'New Balance:', res.rows[0]?.inr);
//             console.log('Bet updated to closed with refund status:', rest.rows[0]);

//           }


//           else if (Status === 'manual') {

//             declared = true;
//             console.log('[ResultCron] FAN result for bet (manual)', { betId: b.id, declared });
//           }
//           else {
//             api = await fetchResultForEvent(eid, formattedName);
//             declared = api.declared;
//             result_meta = api.items ? api.items.find(x => x?.resultStatus === 'RESULT_DECLARED') || null : null;
//             log.debug('[ResultCron] FAN result for bet', { betId: b.id, declared });
//           }
//           const enddate = b.enddatemax;


//           // need to change as per ust no ist time zone
//           if (!declared) {
//             console.log('not declared checking for expiration', enddate);
//             const response = checkExpiration(enddate);
//             let finalt = response.expired;


//             // credit the user's wallet
//             if (finalt) {
//               const res = await db.query(
//                 `INSERT INTO public.fancyresultsummary (fancyname, eventid, matchid, lastfetchdate)
//                    VALUES ($1, $2, $3, NOW())
//                    ON CONFLICT (eventid, matchid, fancyname)
//                    DO UPDATE SET lastfetchdate = NOW()
//                    RETURNING *`,
//                 [name, eid, marketId]
//               );

//               console.log('Fancy result summary updated:', res.rows[0]);
//             }
//           }


//         } else if (gameType === 'MO' || gameType === 'BM') {
//           const marketId = b.match_id;
//           if (Status === 'manual' || Status === 'refund') {

//             declared = true;
//             console.log('[ResultCron] MO/BM result for bet (manual)', { betId: b.id, marketId, declared });
//           }
//           else {
//             const res = await fetchMarketOdds(marketId);
//             declared = res.closed;
//             log.debug('[ResultCron] MO/BM result for bet', { betId: b.id, marketId, declared });



//             // need to change as per ust no ist time zone



//           }
//         }

//         const counts = { total: 1 };
//         const summary = { user_id: userId, eventid: eid, declared, counts, result_meta, sections: { bets: [b] }, checked_at: new Date() };

//         // upsert scan row for this user+event
//         try {
//           await db.query(
//             `INSERT INTO public.sports_event_result_scan(user_id,eventid,declared,counts,checked_at)
//              VALUES($1,$2,$3,$4::jsonb,now())
//              ON CONFLICT(user_id,eventid) DO UPDATE
//              SET declared=EXCLUDED.declared,counts=EXCLUDED.counts,checked_at=now()`,
//             [userId, eid, declared, JSON.stringify(counts)]
//           );
//           log.debug('[ResultCron] scan upserted (single bet)', { user: userId, eventid: eid, declared, betId: b.id });
//         } catch (e) {
//           log.error('[ResultCron] scan insert fail (single bet)', { betId: b.id, eventid: eid, error: e.message });
//         }

//         // insert a summary row
//         try {
//           await db.query(
//             `INSERT INTO public.sports_event_result_summary(user_id,eventid,declared,counts,result_meta,sections,recorded_at)
//              VALUES($1,$2,$3,$4::jsonb,$5::jsonb,$6::jsonb,now())`,
//             [summary.user_id, summary.eventid, summary.declared, JSON.stringify(counts), result_meta ? JSON.stringify(result_meta) : null, JSON.stringify(summary.sections)]
//           );
//           log.debug('[ResultCron] summary inserted (single bet)', { eventid: eid, betId: b.id });
//         } catch (e) {
//           log.error('[ResultCron] summary insert fail (single bet)', { betId: b.id, eventid: eid, error: e.message });
//         }

//         // If declared, queue a settlement job for this single bet
//         if (declared) {
//           const betIdStr = b.id != null ? String(b.id) : uuidv4();
//           const betType = (b.bet_type || '').toString().toLowerCase() || 'unknown';
//           const payload = { user_id: userId, eventid: eid, bet_id: betIdStr, bet_type: betType, bet: b, match_over: declared };
//           const jobId = uuidv4();
//           const runAfter = new Date();

//           try {
//             await db.query('BEGIN');

//             const upsertSql = `
//               INSERT INTO public.sports_event_settlement_jobs
//                 (job_id,user_id,eventid,bet_id,bet_type,status,priority,run_after,payload,created_at,updated_at)
//               VALUES ($1,$2,$3,$4,$5,'queued',5,$6,$7::jsonb,now(),now())
//               ON CONFLICT(user_id,eventid,bet_id) DO UPDATE
//                 SET payload = EXCLUDED.payload,
//                     run_after = EXCLUDED.run_after,
//                     status = 'queued',
//                     updated_at = now()
//               RETURNING job_id
//             `;
//             const upsertRes = await db.query(upsertSql, [jobId, userId, eid, betIdStr, betType, runAfter, JSON.stringify(payload)]);
//             const realJobId = (upsertRes.rows && upsertRes.rows[0] && upsertRes.rows[0].job_id) ? upsertRes.rows[0].job_id : jobId;

//             // Update only this specific bet row to reference the returned job_id.
//             const updateBetsSql = `
//               UPDATE public.sports_bets
//               SET job_id = $1
//               WHERE id = $2
//                 AND user_id::text = $3
//                 AND eventid::text = $4
//                 AND status IN ('open', 'manual','refund')
//             `;
//             await db.query(updateBetsSql, [realJobId, b.id, userId, eid]);

//             await db.query('COMMIT');
//             log.info('[ResultCron] job queued + single bet updated', { user_id: userId, eventid: eid, betId: betIdStr, betType, jobId: realJobId, declared, runAfter });
//           } catch (e) {
//             await db.query('ROLLBACK').catch(() => { });
//             log.error('[ResultCron] job insert fail for bet (single)', { eventid: eid, betId: b.id, betType, error: e.message });
//           }
//         }

//       } catch (err) {
//         log.error('[ResultCron] error processing single bet', { betId: b.id, error: err.message });
//         // continue to next bet
//       }
//     } // end for each bet

//     // pruning (keep existing behavior)
//     try { await pruneSummaries(); } catch (e) { log.error('prune summaries fail', { error: e.message }); }
//     try { await pruneBetCache(); } catch (e) { log.error('prune cache fail', { error: e.message }); }

//   } catch (e) {
//     log.error('[ResultCron] fatal', { error: e.message });
//   } finally {
//     log.info('[ResultCron] ===== Run end =====');
//   }
// }

//function startCron() { log.info('[ResultCron] Scheduler starting...', { everyMs: CRON_INTERVAL_MS }); runOnce(); setInterval(runOnce, CRON_INTERVAL_MS); }

function startCron() { log.info('[ResultCron] Scheduler starting...', { everyMs: CRON_INTERVAL_MS }); }

if (require.main === module) startCron();
module.exports = { startCron, runOnce };


