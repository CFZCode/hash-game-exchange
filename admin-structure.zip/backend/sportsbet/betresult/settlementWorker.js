'use strict';

const fs = require('fs');
const path = require('path');
const cron = require('node-cron');
const db = require('../../General/Model');
const http = require('http');
const https = require('https');
const { isArrayBuffer } = require('util/types');
const _fetch = (typeof fetch === 'function') ? fetch : require('node-fetch');

// ==== Config ====
const DEBUG = process.env.DEBUG === '1' || process.env.DEBUG === 'true';
const BATCH_LIMIT = +(process.env.SETTLE_BATCH_LIMIT || 10);
const RESULTS_API_BASE = process.env.RESULTS_API_BASE || 'https://api.lagaobet.com';
const RESULTS_ENDPOINT = '/sports/event-result?eventid=';
const API_TIMEOUT_MS = +(process.env.API_TIMEOUT_MS || 15000);
const LEDGER_ZERO_ROWS = process.env.LEDGER_ZERO_ROWS === '1' || process.env.LEDGER_ZERO_ROWS === 'true';

const LOG_DIR = process.env.SETTLEMENT_LOG_DIR || '/var/www/html/hellogames/myapp/backend/sportsbet/logs';
const LOG_BASENAME = 'settlement-worker-v2_3_2'; // unchanged

const DB_SCHEMA = (process.env.DB_SCHEMA ?? 'public'); // set '' to rely on search_path
const T = (t) => (DB_SCHEMA ? `${DB_SCHEMA}.${t}` : t);

const CRON_SCHEDULE = process.env.CRON_SCHEDULE || '*/10 * * * * *';
const CRON_TZ = process.env.CRON_TZ || 'UTC';
const CRON_IMMEDIATE = process.env.CRON_IMMEDIATE === '1' || process.env.CRON_IMMEDIATE === 'true';

// ==== New infra-only knobs (no business logic changed) ====
const MAX_CONCURRENT_API = +(process.env.MAX_CONCURRENT_API || 3);
const RESULTS_RATE_LIMIT_MS = +(process.env.RESULTS_RATE_LIMIT_MS || 300);
const RESULTS_MAX_FETCH_RETRIES = +(process.env.RESULTS_MAX_FETCH_RETRIES || 6);
const RESULTS_RETRY_BASE_MS = +(process.env.RESULTS_RETRY_BASE_MS || 600);
const RESULTS_FORCE_IPV4 = process.env.RESULTS_FORCE_IPV4 === '1' || process.env.RESULTS_FORCE_IPV4 === 'true';
const RESULTS_DISABLE_KEEPALIVE = process.env.RESULTS_DISABLE_KEEPALIVE === '1' || process.env.RESULTS_DISABLE_KEEPALIVE === 'true';
const USER_AGENT = process.env.USER_AGENT || `settlement-worker/2.3.2 (+node ${process.version})`;


// ==== Logging ====
function ensureLogDir() { try { fs.mkdirSync(LOG_DIR, { recursive: true }); } catch (_) { } }
ensureLogDir();
function currentLogPath() {
  const d = new Date(), yyyy = d.getFullYear(), mm = String(d.getMonth() + 1).padStart(2, '0'), dd = String(d.getDate()).padStart(2, '0');
  return path.join(LOG_DIR, `${LOG_BASENAME}-${yyyy}-${mm}-${dd}.log`);
}
function writeLog(level, msg) {
  const line = `[${new Date().toISOString()}] [${level}] ${msg}\n`;
  if (level === 'ERROR') console.error(msg); else console.log(msg);
  try { fs.appendFileSync(currentLogPath(), line, 'utf8'); } catch (e) { console.error('Log write failed:', e.message); }
}
const log = {
  info: (m) => writeLog('INFO', m),
  error: (m) => writeLog('ERROR', m),
  debug: (m) => { if (DEBUG) writeLog('DEBUG', m); },
};

// ==== Utils ====
const nowIso = () => new Date().toISOString();
const lower = (s) => (s || '').toString().trim().toLowerCase();
const norm = (s) => (s || '').toString().toLowerCase().replace(/\s+/g, ' ').replace(/[^\w\s]/g, '').trim();
const num = (x) => { const n = Number(x); return Number.isFinite(n) ? n : 0; };

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function jitter(ms) { return Math.round(ms * (1 + Math.random() * 0.25)); }
function parseRetryAfter(h) {
  if (!h) return null;
  const n = Number(h);
  if (!Number.isNaN(n)) return Math.max(0, Math.round(n * 1000));
  const d = Date.parse(h);
  return Number.isNaN(d) ? null : Math.max(0, d - Date.now());
}

// Global throttle
let lastApiCallAt = 0;
async function globalRateLimit() {
  const gap = RESULTS_RATE_LIMIT_MS > 0 ? RESULTS_RATE_LIMIT_MS : 0;
  const now = Date.now();
  const wait = Math.max(0, lastApiCallAt + gap - now);
  if (wait) await sleep(wait);
  lastApiCallAt = Date.now();
}

// Concurrency queue
class AsyncQueue {
  constructor(max) { this.max = max; this.running = 0; this.q = []; }
  push(task) { return new Promise((res, rej) => { this.q.push({ task, res, rej }); this._next(); }); }
  _next() {
    if (this.running >= this.max) return;
    const n = this.q.shift(); if (!n) return;
    this.running++;
    n.task().then(n.res, n.rej).finally(() => { this.running--; this._next(); });
  }
}
const apiQueue = new AsyncQueue(MAX_CONCURRENT_API);

// Transport agents (for per-attempt fallback)
const defaultHttpAgent = new http.Agent({ keepAlive: !RESULTS_DISABLE_KEEPALIVE, family: RESULTS_FORCE_IPV4 ? 4 : undefined });
const defaultHttpsAgent = new https.Agent({ keepAlive: !RESULTS_DISABLE_KEEPALIVE, family: RESULTS_FORCE_IPV4 ? 4 : undefined });
function perAttemptAgents(attempt) {
  if (attempt >= 3) {
    return {
      // node-fetch supports agent as function(url) => Agent
      agent: (url) => {
        return url.startsWith('https:')
          ? new https.Agent({ keepAlive: false, family: 4 })
          : new http.Agent({ keepAlive: false, family: 4 });
      },
      extraHeaders: { 'Connection': 'close' }
    };
  }
  return {
    agent: (url) => url.startsWith('https:') ? defaultHttpsAgent : defaultHttpAgent,
    extraHeaders: {}
  };
}

// AbortController helper
function withTimeout(abortMs) {
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), abortMs);
  return { controller, clear: () => clearTimeout(t) };
}

// ==== Ensure report + helpers (UNCHANGED business logic) ====
async function ensureTables() {
  await db.query(`
    CREATE TABLE IF NOT EXISTS ${T('sports_settlement_report')}(
      id BIGSERIAL PRIMARY KEY,
      job_id UUID NOT NULL,
      bet_id BIGINT NOT NULL,
      user_id TEXT NOT NULL,
      eventid TEXT NOT NULL,
      match_id TEXT NULL,
      game_type TEXT NOT NULL,     -- MO | BM | FAN
      market_type TEXT NULL,       -- odds | bookmaker | line
      fancy_name TEXT NULL,
      selection_name TEXT NULL,
      user_selection_yn TEXT NULL, -- for FAN
      resolved_winner TEXT NULL,   -- 'team' | 'yes' | 'no'
      resolved_team TEXT NULL,     -- MO/BM human team winner
      actual_numeric NUMERIC NULL, -- FAN numeric outcome
      rule_op TEXT NULL,
      rule_threshold NUMERIC NULL,
      credit_amount NUMERIC NOT NULL DEFAULT 0,
      exposures_map JSONB NULL,
      api_snapshot JSONB NULL,
      decision_path JSONB NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
    CREATE UNIQUE INDEX IF NOT EXISTS ux_settlement_report_bet ON ${T('sports_settlement_report')}(bet_id);

    CREATE TABLE IF NOT EXISTS ${T('line_runner_mapping')}(
      eventid TEXT NOT NULL,
      winner_id BIGINT NOT NULL,
      market_id TEXT NULL,
      outcome TEXT NOT NULL CHECK (lower(outcome) IN ('yes','no')),
      created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      CONSTRAINT line_mapping_pk PRIMARY KEY (eventid, winner_id)
    );

    CREATE TABLE IF NOT EXISTS ${T('sports_event_result_scan')}(
      user_id TEXT NOT NULL,
      eventid TEXT NOT NULL,
      declared BOOLEAN NOT NULL DEFAULT FALSE,
      counts JSONB NOT NULL DEFAULT '{}'::jsonb,
      checked_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      CONSTRAINT sports_event_result_scan_pk PRIMARY KEY (user_id,eventid)
    );
    CREATE TABLE IF NOT EXISTS ${T('sports_event_result_summary')}(
      id BIGSERIAL PRIMARY KEY,
      user_id TEXT NOT NULL,
      eventid TEXT NOT NULL,
      declared BOOLEAN NOT NULL,
      counts JSONB NOT NULL,
      result_meta JSONB NULL,
      sections JSONB NULL,
      recorded_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
  `);
  log.info('[Settlement] tables ensured.');
}

// ==== DB helpers (UNCHANGED business logic) ====
async function getLatestJwt() {
  const { rows } = await db.query(`SELECT key FROM ${T('tokens')} ORDER BY uid DESC LIMIT 1`);
  const k = rows?.[0]?.key || '';
  if (!k) log.error('[Settlement] No JWT found in tokens table!');
  return k;
}
async function insertScanRow({ user_id, eventid, declared, counts }) {
  try {
    await db.query(`
      INSERT INTO ${T('sports_event_result_scan')}(user_id,eventid,declared,counts,checked_at)
      VALUES ($1,$2,$3,$4::jsonb,now())
      ON CONFLICT (user_id,eventid) DO NOTHING
    `, [String(user_id), String(eventid), !!declared, JSON.stringify(counts || {})]);
  } catch (e) { log.error(`[Settlement] scan insert failed: ${e.message}`); }
}
async function insertSummaryRow({ user_id, eventid, declared, counts, result_meta, sections }) {
  try {
    await db.query(`
      INSERT INTO ${T('sports_event_result_summary')}(user_id,eventid,declared,counts,result_meta,sections,recorded_at)
      VALUES ($1,$2,$3,$4::jsonb,$5::jsonb,$6::jsonb,now())
    `, [
      String(user_id), String(eventid), !!declared,
      JSON.stringify(counts || {}),
      result_meta ? JSON.stringify(result_meta) : null,
      sections ? JSON.stringify(sections) : null
    ]);
  } catch (e) { log.error(`[Settlement] summary insert failed: ${e.message}`); }
}
async function creditINRWithLedger({ user_id, eventid, match_id, market_type, amount, description, meta, job_id }) {
  const amt = num(amount);
  if (amt === 0 && !LEDGER_ZERO_ROWS) return { credited: 0 };
  const upd = await db.query(
    `UPDATE ${T('credits')} SET inr = COALESCE(inr,0) + $1 WHERE uid::text=$2 RETURNING inr`,
    [amt, String(user_id)]
  );
  const newBal = upd.rows?.[0]?.inr ?? null;
  await db.query(`
    INSERT INTO ${T('credits_ledger')}(user_id,currency,amount,reason,description,eventid,job_id,match_id,meta,market_type)
    VALUES ($1,'INR',$2,'settlement',$3,$4,$5,$6,$7::jsonb,$8)
  `, [
    String(user_id), amt,
    description || '',
    String(eventid), String(job_id || ''),
    match_id ? String(match_id) : null,
    JSON.stringify(meta || {}),
    market_type
  ]);
  return { credited: amt, newBalance: newBal };
}

// exposures / bets housekeeping (UNCHANGED)
async function getMatchExposures(user_id, match_id) {
  const { rows } = await db.query(`
    SELECT team_name, exposure_amount
    FROM ${T('user_exposures')}
    WHERE user_id::text=$1 AND match_id::text=$2
  `, [String(user_id), String(match_id)]);
  const map = {}; for (const r of rows) { map[(r.team_name || '').toString()] = Number(r.exposure_amount || 0); }
  return map;
}
async function clearExposuresForMatch(user_id, match_id) {
  await db.query(`DELETE FROM ${T('user_exposures')} WHERE user_id::text=$1 AND match_id::text=$2`,
    [String(user_id), String(match_id)]);
}
async function closeBetsForMatch(user_id, match_id, onlyLine = false, resultStatus, job_id) {
  const userStr = String(user_id);
  const matchStr = String(match_id);

  const params = [userStr, matchStr, job_id, resultStatus];

  const lineCondition = onlyLine ? `AND lower(bet_type) IN ('yes','no')` : '';

  const sql = `
    UPDATE ${T('sports_bets')}
    SET status = 'closed',
        result_status = $4,
        updated_at = now()
    WHERE user_id::text = $1
      AND match_id::text = $2
      AND job_id = $3
      AND status IN ('open', 'manual','refund')
      ${lineCondition}
  `;

  return db.query(sql, params);
}


// ==== Robust API layer (ONLY infra changes) ====
function withTimeout(abortMs) {
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), abortMs);
  return { controller, clear: () => clearTimeout(t) };
}

async function apiGET(pathAndQuery, jwt) {
  const url = `${RESULTS_API_BASE}${pathAndQuery}`;
  return apiQueue.push(async () => {
    for (let attempt = 1; attempt <= RESULTS_MAX_FETCH_RETRIES; attempt++) {
      const { controller, clear } = withTimeout(API_TIMEOUT_MS);
      try {
        await globalRateLimit();

        const { agent, extraHeaders } = perAttemptAgents(attempt);
        const res = await _fetch(url, {
          method: 'GET',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'User-Agent': USER_AGENT,
            ...(jwt ? { 'Authorization': `Bearer ${jwt}` } : {}),
            ...extraHeaders
          },
          agent: agent(url), // node-fetch supports function(url)=>Agent
          signal: controller.signal
        });

        if (res.status === 200) {
          const data = await res.json();
          if (DEBUG) log.debug(`[Settlement] apiGET 200 ${url}`);
          return data;
        }

        // Grab small body for diagnosing 503 HTML pages etc.
        let txt = '';
        try { txt = await res.text(); } catch (_) { }
        const status = res.status;

        if (status === 429 || (status >= 500 && status <= 599)) {
          const ra = parseRetryAfter(res.headers.get('retry-after'));
          const wait = ra != null ? ra : jitter(RESULTS_RETRY_BASE_MS * Math.pow(2, attempt - 1));
          if (DEBUG) log.debug(`[Settlement] apiGET retry ${status} attempt=${attempt} waitMs=${wait}`);
          await sleep(wait);
          continue;
        }

        // other non-200 → no more retries
        throw new Error(`HTTP ${status}${txt ? ' - ' + txt.slice(0, 200) : ''}`);

      } catch (e) {
        const wait = jitter(RESULTS_RETRY_BASE_MS * Math.pow(2, attempt - 1));
        if (DEBUG) log.debug(`[Settlement] apiGET error attempt=${attempt} nextWaitMs=${wait} err=${e.message}`);
        await sleep(wait);
      } finally {
        clear();
      }
    }
    throw new Error('apiGET exhausted retries');
  });
}
function formatName(name) {
  console.log('Formatting name:', name);

  if (!name || typeof name !== 'string') return '';

  // Remove all spaces and convert to lowercase
  let formatted = name.replace(/\s+/g, '').toLowerCase();

  // Remove trailing period if present
  if (formatted.endsWith('.')) {
    formatted = formatted.slice(0, -1);
  }

  return formatted;
}


async function fetchMarketOdds(marketId, jwt) {
  const json = await apiGET(`/sports/market-odds?market_id=${encodeURIComponent(marketId)}`, jwt);
  const list = Array.isArray(json) ? json : [json];
  return list?.[0] || null;
}
// async function fetchEventResults(eventid, jwt, fancy_name, bet_type, odds) {
//   console.log('fetchEventResults', eventid, fancy_name, bet_type, odds);
//   const url = `${RESULTS_API_BASE}${RESULTS_ENDPOINT}${encodeURIComponent(eventid)}`;
//   log.debug('[settlementjob] fetchEventResults start', { eventid, url, fancy_name, bet_type, odds });

//   const maxAttempts = RESULTS_MAX_FETCH_RETRIES || 6;

//   return apiQueue.push(async () => {
//     for (let attempt = 1; attempt <= maxAttempts; attempt++) {
//       try {
//         await globalRateLimit();

//         const cfg = buildPerAttemptConfig ? buildPerAttemptConfig(attempt) : {};
//         if (jwt) {
//           cfg.headers = Object.assign({}, cfg.headers, { Authorization: `Bearer ${jwt}` });
//         }

//         const res = await ax.get(url, cfg);

//         log.debug('[settlementjob] event fetch response', {
//           eventid, attempt, status: res.status, peek: peekBody(res.data)
//         });

//         if (res.status === 200) {
//           const data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
//           const items = Array.isArray(data?.items) ? data.items : [];

//           let declared = false;
//           let winner = false;

//           for (const item of items) {
//             // find the matching market by fancy_name (both normalized by formatName)
//             if (formatName(item.marketName) === formatName(fancy_name)) {
//               if (item.resultStatus === 'RESULT_DECLARED') {
//                 const winnerid = item?.payload?.marketResultSummary?.winnerId;
//                 console.log('found matching market', item.marketName, 'winnerId=', winnerid);

//                 if (winnerid != null && Number.isFinite(Number(winnerid))) {
//                   const betTypeNormalized = formatName(bet_type);
//                       console.log('betTypeNormalized', betTypeNormalized);

//                   if (betTypeNormalized === 'yes') {
//                     if (Number(odds) >= Number(winnerid)) {
//                       console.log('yes wins');
//                       console.log('odds', odds, 'winnerid', winnerid);
//                       declared = true;
//                       winner = true;
//                     } else {
//                       declared = true;
//                       winner = false;
//                     }
//                   } else if (betTypeNormalized === 'no') {
//                     if (Number(odds) < Number(winnerid)) {
//                         console.log('no wins');
//                       console.log('odds', odds, 'winnerid', winnerid);
//                       declared = true;
//                       winner = true;
//                     } else {
//                       declared = true;
//                       winner = false;
//                     }
//                   } else {
//                     // bet_type not 'yes' or 'no' — keep declared true, winner false
//                     declared = true;
//                     winner = false;
//                   }
//                 } else {
//                   // winnerid missing or not finite — treat as declared but not winner
//                   declared = true;
//                   winner = false;
//                 }
//               }
//               // matched the market; no need to continue looping
//               break;
//             }
//           }

//           log.debug('[settlementjob] event fetch success', {
//             eventid, items: items.length, declared, winner
//           });

//           return { declared, winner, items };
//         }

//         // handle retryable statuses (rate-limited / server errors)
//         if (res.status === 429 || (res.status >= 500 && res.status <= 599)) {
//           const ra = parseRetryAfter ? parseRetryAfter(res.headers?.['retry-after']) : null;
//           const wait = ra != null ? ra : jitter(RESULTS_RETRY_BASE_MS * Math.pow(2, attempt - 1));
//           log.debug('[settlementjob] event fetch retry backoff', { eventid, attempt, status: res.status, retryAfterMs: ra ?? null, waitMs: wait });
//           await sleep(wait);
//           continue;
//         }

//         return { declared: false, winner: false, items: [] };

//       } catch (e) {
//         const wait = jitter(RESULTS_RETRY_BASE_MS * Math.pow(2, attempt - 1));
//         log.error('[settlementjob] event fetch error', { eventid, attempt, error: e?.message ?? e, nextWaitMs: wait });
//         await sleep(wait);
//       }
//     }

//     log.debug('[settlementjob] event fetch exhausted', { eventid });
//     return { declared: false, winner: false, items: [] };
//   });
// }



// ==== Winner resolution (UNCHANGED business logic) ====

// Replace the existing fetchEventResults function with this:
async function fetchEventResults(eventid, jwt, fancy_name, bet_type, odds) {
  log.debug('[settlementjob] fetchEventResults start', { eventid, fancy_name, bet_type, odds });
  console.log('fetchEventResults', eventid, fancy_name, bet_type, odds);
  try {
    // fetch the event-result payload using the existing apiGET helper
    const data = await apiGET(`${RESULTS_ENDPOINT}${encodeURIComponent(eventid)}`, jwt);

    // normalize data -> items array
    const items = Array.isArray(data) ? data : (Array.isArray(data.items) ? data.items : (data.items ? [data.items] : []));

    let declared = false;
    let winner = false;

    for (const item of items) {
      // item.marketName may be undefined — safe-guard
      if (!item || !item.marketName) continue;

      if (formatName(item.marketName) === formatName(fancy_name)) {
        console.log('match found', item.marketName, 'vs', fancy_name);
        console.log('found matching market', item.marketName, 'resultStatus=', item.resultStatus);
        // treated as matched market
        if (item.resultStatus === 'RESULT_DECLARED' || item.resultStatus === 'DECLARED' || lower(item.resultStatus) === 'result_declared') {
          const winnerid = item?.payload?.marketResultSummary?.winnerId ?? item?.payload?.winnerId ?? item?.winnerId;
          console.log('winnerid=', winnerid);
          if (winnerid != null && Number.isFinite(Number(winnerid))) {
            console.log('valid winnerid--entered', winnerid);
            const betTypeNormalized = formatName(bet_type || '');
            console.log('betTypeNormalized', betTypeNormalized);
            if (betTypeNormalized === 'yes') {
              console.log('betTypeNormalized', betTypeNormalized);

              if (Number(odds) <= Number(winnerid)) {
                console.log('yes wins');
                declared = true; winner = true;
              } else {
                declared = true; winner = false;
              }
            } else if (betTypeNormalized === 'no') {
              if (Number(odds) > Number(winnerid)) {
                console.log('no wins');
                declared = true; winner = true;
              } else {
                declared = true; winner = false;
              }
            } else {
              console.log('bet_type not yes/no');
              declared = true; winner = false;
            }
          } else {
            // declared but winner id missing / non-numeric
            declared = true; winner = false;
          }
        } else {
          // matched market but not declared
          declared = false; winner = false;
        }
        break; // stop scanning items after match
      }
    }

    log.debug('[settlementjob] event fetch success', { eventid, items: items.length, declared, winner });
    return { declared, winner, items };
  } catch (e) {
    // surface useful error message to logs
    log.error('[settlementjob] event fetch error', { eventid, error: e?.message ?? e });
    return { declared: false, winner: false, items: [] }; // caller treats as requeue
  }
}

async function fetchmanualFancyResults(eventid, fancy_name, bet_type, bet_id) {
  console.log('fetchmanualFancyResults', eventid, fancy_name, bet_type, bet_id);
  const { rows } = await db.query(
    `SELECT selection 
       FROM fancymanualsettlement
      WHERE eventid = $1 
        AND fancy_name = $2
        AND bet_id = $3
      LIMIT 1`,
    [eventid, fancy_name, bet_id]
  );
  console.log("rows", rows);
  let declared = true;
  let winner = false;
  // manual setup — assign to shared winnerName
  const winnerselection = rows.length > 0 ? rows[0].selection : null;
  console.log("manual gets", winnerselection);
  if (winnerselection === bet_type) {
    winner = true;
  }
  else { winner = false; }
  log.info(`[Settlement] FAN manual selection="${winnerselection}" event=${eventid} fancy=${fancy_name} bet_type=${bet_type}`);

  return { declared, winner };

}


function resolveMobmWinner({ market, team_one, team_two }) {
  if (!market || !Array.isArray(market.runners) || market.runners.length < 1) {
    return { winnerName: '', reason: 'no/insufficient runners' };
  }
  const getName = (r) => {
    const n = r?.name || r?.runnerName || r?.selectionName || r?.label || r?.title || r?.runner;
    if (n && String(n).trim()) return String(n).trim();
    for (const v of Object.values(r || {})) {
      if (typeof v === 'string' && /draw/i.test(v)) return 'The Draw';
    }
    return '';
  };

  const winners = market.runners.map((r, i) => ({ r, i })).filter(x => x.r?.status === 'WINNER');
  if (winners.length === 1) {
    const { r, i } = winners[0];
    let wn = getName(r);
    if (!wn || !wn.trim()) {
      if (i === 0) wn = team_one || '';
      else if (i === 1) wn = team_two || '';
      else if (i === 2) wn = 'The Draw';
    }
    return { winnerName: wn, reason: `runner index ${i} status=WINNER` };
  }

  if (market.runners.length >= 2) {
    const r1 = market.runners[0], r2 = market.runners[1];
    if (r1?.status === 'LOSER' && r2?.status !== 'LOSER') return { winnerName: getName(r2) || team_two || '', reason: 'r1=LOSER -> r2 wins' };
    if (r2?.status === 'LOSER' && r1?.status !== 'LOSER') return { winnerName: getName(r1) || team_one || '', reason: 'r2=LOSER -> r1 wins' };
  }

  return { winnerName: team_one || '', reason: 'ambiguous; fallback team_one' };
}

function normalizeOdds(odds) {
  let newodds;
  if (odds > 100) {
    // Positive American odds → decimal
    newodds = (odds / 100) + 1;       // e.g. 150 → 2.50
  } else if (odds < 100) {
    // Small odds → scale down close to 1.0
    newodds = 1 + (odds / 100);       // e.g. 2.75 → 1.0275
  } else {
    newodds = 2.0;                    // exactly 100 → 2.0
  }

  // Floor to 2 decimal places (no rounding up)
  return Math.floor(newodds * 100) / 100;
}
// ==== Per-bet credit (UNCHANGED business logic) ====
function getOdds(b) {
  // Raw odds value from various possible fields
  const raw = b.odds ?? b.price ?? b.rate ?? b.odd ?? 0;
  const o = Number(raw);
  const gameType = String(b.game_type || '').toUpperCase();

  // === BM-specific normalization ===
  if (gameType === 'BM') {
    return normalizeOdds(o);
  }
  // 1.37 - > 0.63 * stake *100 = 63 
  // Non-BM: keep numeric value as-is (or 0)
  return Number.isFinite(o) ? o : 0;
}
function getStake(b) { return num(b.stake_amount ?? b.stake ?? b.amount ?? b.stakeValue ?? b.size); }
function isBack(b) { return lower(b.bet_type) === 'back'; }
function isLay(b) { return lower(b.bet_type) === 'lay'; }
function moBmBetWinCredit(bet, winnerTeam) {

  const sel = bet.selection_name || '';
  const selIsWinner = norm(sel) === norm(winnerTeam);
  const stake = getStake(bet);
  const odds = getOdds(bet);
  if (isBack(bet)) return selIsWinner ? Math.max(0, (odds - 1) * stake) : 0;  // 1.80 → 0.80 * stake *100 = 80 final result +100= 180 
  if (isLay(bet)) return selIsWinner ? 0 : Math.max(0, (odds) * stake);
  return 0;
}

// ==== FAN helpers (UNCHANGED business logic) ====
function parseFancyRule(fancy) {
  const s = (fancy || '').toString().toLowerCase();
  const sym = s.match(/(>=|<=|>|<)\s*(\d+(?:\.\d+)?)/);
  if (sym) return { op: sym[1], threshold: Number(sym[2]) };
  const kw = s.match(/\b(over|under|exact(?:ly)?)\s*(\d+(?:\.\d+)?)/);
  if (kw) {
    const word = kw[1], th = Number(kw[2]);
    if (word.startsWith('over')) return { op: '>', threshold: th };
    if (word.startsWith('under')) return { op: '<', threshold: th };
    return { op: '==', threshold: th };
  }
  const plus = s.match(/(\d+(?:\.\d+)?)\s*\+/);
  if (plus) return { op: '>=', threshold: Number(plus[1]) };
  return null;
}
function yesWins(actual, rule) {
  if (!rule) return null;
  const a = Number(actual), x = Number(rule.threshold);
  switch (rule.op) {
    case '>': return a > x;
    case '<': return a < x;
    case '==': return a === x;
    case '>=': return a >= x;
    case '<=': return a <= x;
    default: return null;
  }
}
function settleFancyLine(exposuresMap, winnerYN) {
  const key = winnerYN === 'yes' ? 'Yes' : (winnerYN === 'no' ? 'No' : winnerYN);
  const exp = Number(exposuresMap[key] ?? 0);
  if (!exp) return { credit: 0, note: `fancy winner=${key}; exposure=0` };
  return { credit: 2 * Math.abs(exp), note: `fancy credit 2x abs(${exp})` };
}

// ==== Detailed report (UNCHANGED business logic) ====
async function writeReport(r) {
  await db.query(`
    INSERT INTO ${T('sports_settlement_report')}(
      job_id, bet_id, user_id, eventid, match_id,
      game_type, market_type, fancy_name, selection_name, user_selection_yn,
      resolved_winner, resolved_team, actual_numeric, rule_op, rule_threshold,
      credit_amount, exposures_map, api_snapshot, decision_path
    )
    VALUES (
      $1,$2,$3,$4,$5,
      $6,$7,$8,$9,$10,
      $11,$12,$13,$14,$15,
      $16,$17::jsonb,$18::jsonb,$19::jsonb
    )
    ON CONFLICT (bet_id) DO NOTHING
  `, [
    r.job_id, r.bet_id, r.user_id, r.eventid, r.match_id,
    r.game_type, r.market_type, r.fancy_name || null, r.selection_name || null, r.user_selection_yn || null,
    r.resolved_winner || null, r.resolved_team || null, (r.actual_numeric != null ? r.actual_numeric : null), r.rule_op || null, (r.rule_threshold != null ? r.rule_threshold : null),
    Number(r.credit_amount || 0), JSON.stringify(r.exposures_map || {}), JSON.stringify(r.api_snapshot || {}), JSON.stringify(r.decision_path || [])
  ]);
}

function normalizeExposure(value) {
  return Math.abs(value);
}

// ==== MO/BM: process one (UNCHANGED business logic) ====
async function processMobmGroup({ job_id, user_id, eventid, match_id, bets, jwt }) {
  const any = bets[0] || {};
  const betsStatus = any.status;
  let winnerName = null; // shared variable for both branches

  console.log("cskc", betsStatus);

  if (betsStatus !== 'open') {
    console.log("manual enter");

    const { rows } = await db.query(
      `SELECT winner_name 
       FROM manual_settle
      WHERE eventid = $1 
        AND match_id = $2
      LIMIT 1`,
      [eventid, match_id]
    );

    console.log("rows", rows);

    // manual setup — assign to shared winnerName
    winnerName = rows.length > 0 ? rows[0].winner_name : null;
    console.log("manual gets", winnerName);

    log.info(`[Settlement] MO/BM manual winner="${winnerName}" match=${match_id} event=${eventid} bets=${bets.length}`);

    await insertScanRow({
      user_id,
      eventid,
      declared: 'CLOSED',
      counts: { total: bets.length }
    });

    await insertSummaryRow({
      user_id,
      eventid,
      declared: true,
      counts: { total: bets.length },
      result_meta: { manual: true, winnerName },
      sections: { bet_ids: bets.map(b => b.id) }
    });

  } else {
    const market = await fetchMarketOdds(match_id, jwt);
    if (!market) {
      log.error(`[Settlement] MO/BM group user=${user_id} match=${match_id} market fetch empty`);
      return { settled: false, requeue: true };
    }

    await insertScanRow({
      user_id,
      eventid,
      declared: 'CLOSED',
      counts: { total: bets.length }
    });

    await insertSummaryRow({
      user_id,
      eventid,
      declared: (market.status === 'CLOSED'),
      counts: { total: bets.length },
      result_meta: market,
      sections: { bet_ids: bets.map(b => b.id) }
    });

    if (market.status !== 'CLOSED') return { settled: false, requeue: true };

    const { winnerName: resolvedWinnerName, reason } = resolveMobmWinner({
      market,
      team_one: any.team_one,
      team_two: any.team_two
    });

    // assign resolved winner to the same shared variable
    winnerName = resolvedWinnerName;

    log.info(`[Settlement] MO/BM winner="${winnerName}" (${reason}) match=${match_id} event=${eventid} bets=${bets.length}`);
  }

  console.log("Final winnerName:", winnerName);


  // any in the bet handle according to winner name declared by data and api 


  const exposuresMap = await getMatchExposures(user_id, match_id).catch(() => ({}));
  let creditnew = 0;
  for (const bet of bets) {
    console.log("winner name ", winnerName);
    const market_type = (String(bet.game_type || 'MO').toUpperCase() === 'BM' ? 'bookmaker' : 'odds');
    let credit = moBmBetWinCredit(bet, winnerName);
    const stake = getStake(bet);
    const selIsWinner = norm(bet.selection_name) === norm(winnerName);

    const { rows: oldExpRows } = await db.query(
      `SELECT team_name, exposure_amount
         FROM user_exposures
        WHERE user_id = $1 AND match_id = $2
        FOR UPDATE`,
      [user_id, match_id]
    );
    const oldExposures = {};
    oldExpRows.forEach(r => { oldExposures[r.team_name] = Number(r.exposure_amount); });
    console.log('OLD EXPOSURES:', oldExposures);

    let team1 = oldExposures[bet.team_one] || 0;
    console.log('TEAM 1 EXPOSURE:', team1);
    let team2 = oldExposures[bet.team_two] || 0;
    let draw = oldExposures['The Draw'] || 0;
    console.log("the draw value ", draw);
    console.log('TEAM 2 EXPOSURE:', team2);
    let mostNeg = Math.min(...Object.values(oldExposures).filter(x => x < 0));
    console.log(' EXPOSURE highest:', mostNeg);

    let finalcredit = 0;
    if (bet.counts == 2) {
      if (bet.team_one === winnerName) {
        if (team1 < 0) {
          finalcredit = 0;
          console.log('FINAL CREDIT IF TEAM 1 WIN AND EXPOSURE <0:', finalcredit);
        }
        else {
          finalcredit = normalizeExposure(team1) + normalizeExposure(team2);
          console.log('FINAL CREDIT IF TEAM 1 WIN AND EXPOSURE >0:', finalcredit);
        }

      }
      else if (bet.team_two === winnerName) {
        if (team2 < 0) {
          finalcredit = 0;
          console.log('FINAL CREDIT IF TEAM 2 WIN AND EXPOSURE <0:', finalcredit);
        }
        else {
          finalcredit = normalizeExposure(team1) + normalizeExposure(team2);
          console.log('FINAL CREDIT IF TEAM 2 WIN AND EXPOSURE >0:', finalcredit);
        }

      }
      else if (winnerName === 'refund') {
        finalcredit = normalizeExposure(mostNeg);
        console.log('FINAL CREDIT IF REFUND :', finalcredit);
      }
    }
    else {
      if (bet.team_one === winnerName) {
        if (team1 < 0) {
          finalcredit = normalizeExposure(mostNeg) - normalizeExposure(team1);
        }
        else {
          finalcredit = normalizeExposure(mostNeg) + normalizeExposure(team1);
        }
      }
      else if (bet.team_two === winnerName) {
        if (team2 < 0) {
          finalcredit = normalizeExposure(mostNeg) - normalizeExposure(team2);
        }
        else {
          finalcredit = normalizeExposure(mostNeg) + normalizeExposure(team2);
        }
      }
      else if (winnerName === 'refund') {
        finalcredit = normalizeExposure(mostNeg);
        console.log('FINAL CREDIT IF REFUND :', finalcredit);
      }
      else {
        if (draw < 0) {
          finalcredit = normalizeExposure(mostNeg) - normalizeExposure(draw);
        }
        else {
          finalcredit = normalizeExposure(mostNeg) + normalizeExposure(draw);
        }
      }
    }
    if (selIsWinner && isBack(bet)) {
      credit += stake;
    }
    const desc = `MO/BM per-bet; winner="${winnerName}"; bet_type=${bet.bet_type}; selection="${bet.selection_name}"; credit=${credit}`;
    const meta = { api: { type: 'market-odds', marketId: match_id, status: 'closed' }, runners: 'hello' || [], winnerName, bet_id: bet.id };
    creditnew += credit;
    let matchname = `${bet.team_one} vs ${bet.team_two}`;
    console.log("bet fixed value ", bet.fixed);
    if (bet.fixed == 0) {

      const { rows } = await db.query(
        `SELECT COUNT(id) AS bet_count
   FROM ${T('sports_bets')}
   WHERE eventid = $1
     AND match_id = $2
     AND game_type = 'MO'
     AND user_id = $3`,
        [eventid, match_id, user_id]
      );

      let totalbets = rows[0].bet_count || 0;
      let drawex = 0;
      if (bet.counts == 3) {
        drawex = draw;
      }
      console.log('total bets placed by user ', totalbets);

      await db.query(
        `INSERT INTO ${T('marketwins')} 
   (totalbets, matchid, eventid, team1ex, team2ex, drawex, winteam, matchname, payout, user_id, created_at)
   VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, now())
   RETURNING *`,
        [totalbets, match_id, eventid, team1, team2, drawex, winnerName, matchname, finalcredit, user_id]
      );
      console.log('marketwins table updated');

    }
    if (bet.fixed == 1) {
      finalcredit = 0;
    }

    if (finalcredit !== 0) {
      const r = await creditINRWithLedger({
        user_id, eventid, match_id, market_type,
        amount: finalcredit, description: desc, meta, job_id
      });
      log.info(`[Settlement] MO/BM credited bet_id=${bet.id} user=${user_id} credit=${finalcredit} bal=${r.newBalance}`);
    } else {
      log.info(`[Settlement] MO/BM no credit bet_id=${bet.id} (${desc})`);
    }

    await writeReport({
      job_id, bet_id: bet.id, user_id, eventid, match_id,
      game_type: String(bet.game_type || 'MO').toUpperCase(),
      market_type,
      selection_name: bet.selection_name,
      resolved_winner: 'team', resolved_team: winnerName || null,
      credit_amount: finalcredit,
      exposures_map: exposuresMap,
      api_snapshot: {},
      decision_path: desc
    });
  }

  const resultStatus =
    String(winnerName).toLowerCase() === 'refund'
      ? 'refund'
      : creditnew > 0
        ? 'won'
        : 'loss';
  console.log('db cchanges ffor fixed');
  await db.query(
    `UPDATE ${T('sports_bets')}
     SET fixed =1,
         updated_at=now()
     WHERE match_id=$1 
       AND user_id=$2`,
    [match_id, user_id]
  );
  console.log('db cchanges done for fixed');
  await closeBetsForMatch(user_id, match_id, false, resultStatus, job_id);
  await clearExposuresForMatch(user_id, match_id);

  return { settled: true, requeue: false };
}

// ==== FAN: per bet (UNCHANGED business logic) ====
async function processFanBet({ job_id, bet, jwt }) {
  const { id: bet_id, user_id, eventid, match_id, fancy_name, selection_name, bet_type, game_type, odds, stake_amount } = bet;
  let api = null;
  if (bet.status !== 'open') {
    console.log("manual enter");
    api = await fetchmanualFancyResults(eventid, fancy_name, bet_type, bet_id);
  }
  else {
    console.log("api enter");
    api = await fetchEventResults(eventid, jwt, fancy_name, bet_type, odds);
    console.log('api - winner is ', api.winner);
  }



  const exposuresMap = await getMatchExposures(user_id, match_id);
  //  const exp = Number(exposuresMap[key] ?? 0);
  // const out = settleFancyLine(exposuresMap, resolvedYN);
  // const userPickedYN = lower(selection_name || bet_type || '');
  // const userWon = (userPickedYN === resolvedYN);
  let credit = 0;
  if (api.winner) {
    // credit += 2*getStake(bet);
    credit += 2 * Number(stake_amount || 0);
    console.log('user won, credit is ', credit);
  }
  let market_type = "Fancy"
  await db.query(
    `INSERT INTO ${T('fanwins')} 
   (userid, fancyname, selection, runsodds, payout, eventid, matchid, created_at)
   VALUES ($1, $2, $3, $4, $5, $6, $7, now())
   RETURNING *`,
    [user_id, fancy_name, bet_type, odds, credit, eventid, match_id]
  );
  console.log('wating period  is waiting');
  const desc = `FAN per-bet; fancy="${fancy_name}" selection=${selection_name}; iswinner="${api.winner}"  credit=${credit}`;
  const meta = { api: { type: 'event-result', eventid, marketName: fancy_name, winnerId: api.winner, bettingType: selection_name || 'LINE' }, bet_id };
  const target = { declared: api.declared, winner: api.winner, eventid, marketName: fancy_name, winnerId: api.winner, bettingType: selection_name };
  const actual = api.items?.[0]?.payload?.marketResultSummary?.winnerId ?? null;
  const rule = parseFancyRule(fancy_name);


  if (credit !== 0 || LEDGER_ZERO_ROWS) {
    const r = await creditINRWithLedger({ user_id, eventid, match_id, market_type, amount: credit, description: desc, meta, job_id });
    log.info(`[Settlement] FAN credited bet_id=${bet_id} user=${user_id} credit=${credit} bal=${r.newBalance}`);
  } else {
    log.info(`[Settlement] FAN no credit bet_id=${bet_id} user=${user_id} (${desc})`);
  }
  console.log('wating period  is done');

  await writeReport({
    job_id, bet_id, user_id, eventid, match_id,
    game_type: String(game_type || 'FAN').toUpperCase(),
    market_type,
    fancy_name, selection_name,
    user_selection_yn: lower(selection_name || bet_type || '') || null,
    resolved_winner: bet_type,
    actual_numeric: Number.isFinite(actual) ? actual : null,
    rule_op: rule ? rule.op : null,
    rule_threshold: rule ? rule.threshold : null,
    credit_amount: credit,
    exposures_map: exposuresMap,
    api_snapshot: target,
    decision_path: [desc]
  });
  console.log('final period  is done');
  const result = api.winner ? 'won' : 'loss';

  await db.query(
    `UPDATE ${T('sports_bets')}
   SET status='closed',
       result_status=$3,
       updated_at=now()
   WHERE id=$1 
     AND job_id=$2
     AND status IN ('open', 'manual')`,
    [bet_id, job_id, result]
  );

  return { settled: true, requeue: false };
}

// ==== Job processor (UNCHANGED business logic) ====
async function processJob(job) {
  const { job_id, user_id, eventid } = job;
  log.info(`[Settlement] Processing job job_id=${job_id} user=${user_id} event=${eventid}`);

  const jwt = await getLatestJwt();
  if (!jwt) {
    await db.query(`UPDATE ${T('sports_event_settlement_jobs')} SET status='queued', updated_at=now(), error_msg='missing jwt' WHERE job_id=$1`, [job_id]);
    log.error('[Settlement] JWT missing; job kept queued');
    return;
  }

  const { rows: bets } = await db.query(`
  SELECT * FROM ${T('sports_bets')}
  WHERE job_id = $1 
    AND status IN ('open', 'manual','refund')
  ORDER BY created_at
`, [String(job_id)]);

  if (!bets.length) {
    log.info(`[Settlement] No open bets for job_id=${job_id}; marking done.`);
    await db.query(`UPDATE ${T('sports_event_settlement_jobs')} SET status='done', updated_at=now(), error_msg=NULL WHERE job_id=$1`, [job_id]);
    return;
  }

  const moBmByMatch = new Map();
  const fanBets = [];
  for (const b of bets) {
    const gt = (b.game_type || '').toUpperCase();
    if (gt === 'MO' || gt === 'BM' || gt === 'BO') {
      const k = `${b.user_id}::${b.match_id}`;
      if (!moBmByMatch.has(k)) moBmByMatch.set(k, []);
      moBmByMatch.get(k).push(b);
    } else if (gt === 'FAN') {
      fanBets.push(b);
    } else {
      log.error(`[Settlement] Unknown game_type="${b.game_type}" bet_id=${b.id}`);
    }
  }

  let anyRequeue = false;

  for (const [, group] of moBmByMatch.entries()) {
    const any = group[0];
    try {
      const res = await processMobmGroup({
        job_id, user_id: any.user_id, eventid: any.eventid, match_id: any.match_id, bets: group, jwt
      });
      if (res.requeue) anyRequeue = true;
    } catch (e) {
      anyRequeue = true;
      log.error(`[Settlement] MO/BM group match=${any.match_id} failed: ${e.message}`);
    }
  }

  for (const b of fanBets) {
    try {
      const res = await processFanBet({ job_id, bet: b, jwt });
      if (res.requeue) anyRequeue = true;
    } catch (e) {
      anyRequeue = true;
      log.error(`[Settlement] FAN bet ${b.id} failed: ${e.message}`);
    }
  }

  if (anyRequeue) {
    await db.query(`UPDATE ${T('sports_event_settlement_jobs')} SET status='queued', updated_at=now(), error_msg=NULL WHERE job_id=$1`, [job_id]);
    log.info(`[Settlement] job_id=${job_id} kept queued for next tick`);
  } else {
    await db.query(`UPDATE ${T('sports_event_settlement_jobs')} SET status='done', updated_at=now(), error_msg=NULL WHERE job_id=$1`, [job_id]);
    log.info(`[Settlement] job_id=${job_id} DONE`);
  }
}

// ==== One-shot poll (cron tick) (UNCHANGED business logic) ====
async function pollOnce() {
  log.info(`[Settlement] ===== Poll start ${nowIso()} =====`);
  try {
    const { rows } = await db.query(`
      SELECT job_id, user_id, eventid, payload
      FROM ${T('sports_event_settlement_jobs')}
      WHERE status='queued'
      ORDER BY created_at
      LIMIT $1
    `, [BATCH_LIMIT]);

    log.info(`[Settlement] Picked ${rows.length} queued job(s).`);

    for (const job of rows) {
      try {
        const { rowCount } = await db.query(`
          UPDATE ${T('sports_event_settlement_jobs')}
          SET status='processing', updated_at=now()
          WHERE job_id=$1 AND status='queued'
        `, [job.job_id]);
        if (!rowCount) continue;

        job.user_id = job.user_id ?? job.payload?.user_id;
        job.eventid = job.eventid ?? job.payload?.eventid;
        if (!job.user_id || !job.eventid) throw new Error('job missing userId/eventId');

        await processJob(job);
      } catch (e) {
        log.error(`[Settlement] Job ${job.job_id} failed: ${e.message}`);
        await db.query(`
          UPDATE ${T('sports_event_settlement_jobs')}
          SET status='failed', error_msg=$2, updated_at=now()
          WHERE job_id=$1
        `, [job.job_id, e.message]);
      }
    }

    const qs = await db.query(`
      SELECT
        COUNT(*) FILTER (WHERE status='queued')     AS queued,
        COUNT(*) FILTER (WHERE status='processing') AS processing,
        COUNT(*) FILTER (WHERE status='done')       AS done,
        COUNT(*) FILTER (WHERE status='failed')     AS failed
      FROM ${T('sports_event_settlement_jobs')}
    `);
    const s = qs.rows?.[0] || {};
    log.info(`[Settlement] queue stats => queued:${s.queued || 0} processing:${s.processing || 0} done:${s.done || 0} failed:${s.failed || 0}`);
  } finally {
    log.info(`[Settlement] ===== Poll end ${nowIso()} =====`);
  }
}

// ==== Scheduler (UNCHANGED business logic) ====
let running = false;
function startScheduler() {
  log.info(`[Settlement] Scheduler starting (cron="${CRON_SCHEDULE}", tz="${CRON_TZ}") ...`);
  cron.schedule(CRON_SCHEDULE, async () => {
    if (running) { log.info('[Settlement] tick skipped (previous run still executing)'); return; }
    running = true;
    try { await pollOnce(); }
    catch (e) { log.error('[Settlement] tick error: ' + e.message); }
    finally { running = false; }
  }, { timezone: CRON_TZ });
  if (CRON_IMMEDIATE) {
    (async () => {
      if (running) return;
      running = true;
      try { await pollOnce(); }
      catch (e) { log.error('[Settlement] immediate run error: ' + e.message); }
      finally { running = false; }
    })();
  }
}

// ==== Entry (UNCHANGED) ====
async function start() {
  log.info('[Settlement] Worker v2.3.2 starting...');
  await ensureTables();
  startScheduler();
}

if (require.main === module) {
  start().catch(e => {
    log.error('[Settlement] Fatal: ' + e.message);
    process.exit(1);
  });
}

module.exports = { start, pollOnce };
