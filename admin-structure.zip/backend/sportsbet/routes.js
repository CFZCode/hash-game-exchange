const express = require('express');
const router = express.Router();
const controller = require('./sportbetscontroller');
const db = require('../General/Model');
const axios = require('axios');
const bcrypt = require('bcrypt');




function normalizeExposure(value) {
  return Math.abs(Number(value || 0));
}


router.post('/place', controller.placeBet);
router.get('/exposures/:user_id', controller.getUserExposures);
// routes/sportsBetRoutes.js
// routes/sportsBetRoutes.js
router.get('/wallet/:uuid', controller.getWalletBalance);
// GET /open/:userId/:matchId
// 1) Existing: open bets for a single match
router.get('/open/:userUuid/:matchId', async (req, res) => {
  const { userUuid, matchId } = req.params;
  try {

    const uid = userUuid;

    // fetch only open bets for that match
    const { rows: bets } = await db.query(
      `SELECT
         id,
         selection_name,
         odds,
         stake_amount AS stake,
         liability,
         bet_type AS type
       FROM "SportsBet"
       WHERE user_id = $1
         AND match_id = $2
         AND status   = 'open'`,
      [uid, matchId]
    );

    return res.json({ success: true, bets });
  } catch (err) {
    console.error('Error fetching open bets by match:', err);
    return res.status(500).json({ success: false, error: 'Could not fetch open bets' });
  }
});

// 2) get ALL open bets for that user
//    GET /sportsbetting/open/:userUuid
router.get('/history/:userUuid', async (req, res) => {
  const { userUuid } = req.params;
  try {

    const uid = userUuid;

    // fetch only open bets across all matches
    const { rows: bets } = await db.query(
      `SELECT
  id, match_id, selection_name, odds, stake_amount AS stake, status,match_title,bet_type,game_type,
  liability, created_at, updated_at,result_status
FROM "SportsBet"
WHERE user_id = $1
ORDER BY created_at DESC;`,
      [uid]
    );

    return res.json({ success: true, bets });
  } catch (err) {
    console.error('Error fetching all open bets:', err);
    return res.status(500).json({ success: false, error: 'Could not fetch open bets' });
  }
});

// GET /sportsbetting/open/count/:userUuid
router.get('/opencount/:userUuid', async (req, res) => {
  const { userUuid } = req.params;
  console.log(userUuid);
  try {
    // look up internal users.id by uuid
    const { rows: uRows } = await db.query(
      `SELECT id FROM users WHERE uuid = $1 LIMIT 1`,
      [userUuid]
    );
    console.log(uRows);
    if (!uRows.length) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }
    const uid = uRows[0].id;

    // 2) Count open bets
    const { rows } = await db.query(
      `SELECT COUNT(*) AS count
         FROM "SportsBet"
         WHERE user_id = $1
           AND status  = 'open'`,
      [uid]
    );
    const count = parseInt(rows[0].count, 10);
    console.log(count);
    return res.json({ success: true, count });
  } catch (err) {
    console.error('Error fetching open bets count:', err);
    return res.status(500).json({ success: false, error: 'Could not fetch count' });
  }
});

// GET /sportsbetting/transfers/:userUuid
router.get('/transfers/:userUuid', async (req, res) => {
  const { userUuid } = req.params;
  try {
    // 1) resolve internal user.id from uuid
    const { rows: uRows } = await db.query(
      `SELECT id FROM users WHERE uuid = $1 LIMIT 1`,
      [userUuid]
    );
    if (!uRows.length) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }
    const uid = uRows[0].id;

    // 2) fetch all transfers involving that user
    //    if they are the “to” → credit; if they are the “from” → debit
    const { rows: transfers } = await db.query(
      `SELECT
         id,
         amount,
         created_at AS date,
         CASE
           WHEN from_type = 'staff' AND to_type = 'user' AND to_id = $1 THEN 'credit'
           WHEN from_type = 'user'  AND to_type = 'staff' AND from_id = $1 THEN 'debit'
           ELSE direction  -- fallback to whatever is in your 'direction' column
         END AS type
       FROM staff_transfers
       WHERE
         (to_type   = 'user' AND to_id   = $1)
         OR
         (from_type = 'user' AND from_id = $1)
       ORDER BY created_at DESC`,
      [uid]
    );

    return res.json({ success: true, transfers });
  } catch (err) {
    console.error('Error fetching transfers:', err);
    return res.status(500).json({ success: false, error: 'Could not fetch transfers' });
  }
});
router.put('/password/:userUuid', async (req, res) => {
  const { userUuid } = req.params;
  const { oldPassword, newPassword } = req.body;

  if (!oldPassword || !newPassword) {
    return res.status(400).json({
      success: false,
      error: 'Both oldPassword and newPassword are required'
    });
  }

  try {
    // 1) lookup internal ID + current hash
    const { rows: uRows } = await db.query(
      `SELECT id, password FROM users WHERE uuid = $1 LIMIT 1`,
      [userUuid]
    );
    if (!uRows.length) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }
    const { id: uid, password: currentHash } = uRows[0];

    // 2) verify old password
    const matches = await bcrypt.compare(oldPassword, currentHash);
    if (!matches) {
      return res.status(401).json({ success: false, error: 'Old password incorrect' });
    }

    // 3) hash + update new password in Postgres (and store plaintext in password2)
    const newHash = await bcrypt.hash(newPassword, 10);
    await db.query(
      `UPDATE users
          SET password  = $1,
              password2 = $2
        WHERE uuid = $3`,
      [newHash, newPassword, userUuid]
    );

    // 4) propagate to Mongo via your /profile/:id endpoint
    try {
      await axios.put(
        `https://apisky.codefactory.games/users/profile/${userUuid}`,
        {
          password: newPassword,
          password2: newPassword,
          updatedAt: new Date()
        },
        { timeout: 5000 }
      );
    } catch (err) {
      console.error('Failed to update Mongo profile:', err.message);
      // choosing to log & continue
    }

    return res.json({ success: true });
  } catch (err) {
    console.error('Error changing password:', err);
    return res.status(500).json({ success: false, error: 'Server error' });
  }
});

const getTreeIdsSql = `
WITH RECURSIVE tree AS (
  SELECT id FROM staff WHERE id = $1
  UNION ALL
  SELECT s.id
  FROM staff s
  JOIN tree t ON s.parent_id = t.id
)
SELECT array_agg(id) AS ids FROM tree
`;
async function visibleIds(staffId) {
  const { rows: [{ ids }] } = await db.query(getTreeIdsSql, [staffId]);
  return ids;
}
const getAdminBets = async (req, res) => {
  try {
    console.log("Filters from frontend:", req.query);

    // parse & sanitize pagination
    let page = Number(req.query.page || 1);
    let limit = Number(req.query.limit || 10);
    if (!Number.isInteger(page) || page < 1) page = 1;
    if (!Number.isInteger(limit) || limit < 1) limit = 10;

    const {
      search,
      status,
      gameResult,
      betType,
      startDate,
      endDate,
      currency = "usd",
      userIds,
    } = req.query;

    // staff visibility
    let ids = await visibleIds(req.headers["x-staff-id"]);
    ids = (Array.isArray(ids) ? ids : ids).map((x) => Number(x)); // ensure numbers

    let where = "WHERE 1=1";
    const params = [];

    // Staff visibility filter (supports super-admin id === 1)
    if (ids.includes(1)) {
      where +=
        " AND (u.parent_staff_id = ANY($" +
        (params.length + 1) +
        "::bigint[]) OR u.parent_staff_id IS NULL)";
    } else {
      where += " AND u.parent_staff_id = ANY($" + (params.length + 1) + "::bigint[])";
    }
    params.push(ids);

    // status filter
    if (status) {
      where += " AND sb.status = $" + (params.length + 1);
      params.push(status);
    }

    // ----------------------------
    // SIMPLE gameResult filter (case-insensitive exact)
    // ----------------------------
    if (gameResult) {
      // ensure we use the exact value the frontend sent, lowercased
      const val = String(gameResult).toLowerCase();
      where += " AND LOWER(sb.result_status) = $" + (params.length + 1);
      params.push(val);
    }

    // betType filter
    if (betType) {
      where += " AND sb.bet_type = $" + (params.length + 1);
      params.push(betType);
    }

    // date filters — compare against match_start_time
    if (startDate) {
      where += " AND sb.match_start_time >= $" + (params.length + 1);
      params.push(String(startDate) + " 00:00:00");
    }
    if (endDate) {
      where += " AND sb.match_start_time <= $" + (params.length + 1);
      params.push(String(endDate) + " 23:59:59");
    }

    // search across multiple columns (ILIKE)
    if (search) {
      const searchLike = `%${search}%`;
      where +=
        " AND (sb.match_title ILIKE $" +
        (params.length + 1) +
        " OR sb.team_one ILIKE $" +
        (params.length + 2) +
        " OR sb.team_two ILIKE $" +
        (params.length + 3) +
        " OR sb.selection_name ILIKE $" +
        (params.length + 4) +
        " OR u.name ILIKE $" +
        (params.length + 5) +
        ")";
      params.push(searchLike, searchLike, searchLike, searchLike, searchLike);
    }

    // userIds filter (comma separated or array)
    if (userIds) {
      const idsArr = Array.isArray(userIds) ? userIds : String(userIds).split(",");
      const placeholders = idsArr.map((_, i) => `$${params.length + i + 1}`).join(", ");
      where += ` AND sb.user_id IN (${placeholders})`;
      params.push(...idsArr.map((v) => Number(v)));
    }

    const offset = (page - 1) * limit;

    const query = `
      SELECT sb.*, u.name as username, COALESCE(sc.game_name, 'Unknown') as game_name
      FROM "SportsBet" sb
      LEFT JOIN users u ON sb.user_id = u.id
      LEFT JOIN sports_config sc ON sb.category::integer = sc.game_id
      ${where}
      ORDER BY sb.stake_amount DESC, sb.created_at DESC
      LIMIT $${params.length + 1} OFFSET $${params.length + 2}
    `;

    const paramsForQuery = params.slice();
    paramsForQuery.push(limit, offset);

    // LOGGING: show the built where clause, the final query and params used
    console.log("Built WHERE:", where);
    console.log("Final SQL (preview):", query.replace(/\s+/g, " "));
    console.log("Params for main query:", paramsForQuery);
    console.log("Params for count query:", params);

    const { rows } = await db.query(query, paramsForQuery);

    const countQuery = `
      SELECT COUNT(*) as total
      FROM "SportsBet" sb
      LEFT JOIN users u ON sb.user_id = u.id
      LEFT JOIN sports_config sc ON sb.category::integer = sc.game_id
      ${where}
    `;
    const { rows: countRows } = await db.query(countQuery, params);
    const total = Number(countRows[0].total || 0);

    res.json({
      success: true,
      bets: rows,
      pagination: {
        total,
        totalPages: Math.ceil(total / limit),
        page: page,
        limit: limit,
      },
    });
  } catch (err) {
    console.error("getAdminBets error:", err);
    res.status(500).json({ success: false, error: err.message || String(err) });
  }
};




const updateBetStatus = async (req, res) => {
  const { id } = req.params;
  const { status, resultDeclaredTime } = req.body;

  if (!['open', 'closed'].includes(status)) {
    return res.status(400).json({ success: false, error: 'Invalid status' });
  }

  const query = `
    UPDATE "SportsBet"
    SET status = $1, match_end_time = $2
    WHERE id = $3
  `;

  try {
    await db.query(query, [status, resultDeclaredTime, id]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};
router.get('/', async (req, res) => {
  try {
    // ---- Parse & sanitize pagination ----
    const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 10, 1), 100);
    const offset = (page - 1) * limit;

    // ---- Filters ----
    const search = (req.query.search || '').trim();
    const userId = (req.query.userId || '').trim();

    // ---- WHERE builder ----
    const whereParts = [];
    const params = [];

    if (search) {
      // Search across text fields and cast IDs to text
      params.push(`%${search}%`);
      whereParts.push(
        `(matchname ILIKE $${params.length}
           OR winteam ILIKE $${params.length}
           OR CAST(eventid AS TEXT) ILIKE $${params.length}
           OR CAST(matchid AS TEXT) ILIKE $${params.length})`
      );
    }

    if (userId) {
      params.push(userId);
      whereParts.push(`user_id = $${params.length}`);
    }

    const whereSql = whereParts.length ? `WHERE ${whereParts.join(' AND ')}` : '';

    // ---- Count total ----
    const countSql = `
      SELECT COUNT(*)::BIGINT AS count
      FROM marketwins
      ${whereSql};
    `;
    const { rows: countRows } = await db.query(countSql, params);
    const totalCount = Number(countRows?.[0]?.count || 0);
    const totalPages = Math.max(Math.ceil(totalCount / limit), 1);

    // ---- Fetch page ----
    const dataSql = `
      SELECT
        id,
        totalbets,
        matchid,
        eventid,
        team1ex,
        team2ex,
        drawex,
        winteam,
        matchname,
        payout,
        user_id,
        created_at
      FROM marketwins
      ${whereSql}
      ORDER BY created_at DESC, id DESC
      LIMIT $${params.length + 1}
      OFFSET $${params.length + 2};
    `;
    const dataParams = [...params, limit, offset];
    const { rows } = await db.query(dataSql, dataParams);

    return res.json({
      data: rows, // Your MarketHistory.tsx reads `data` (and also tolerates `transactions`)
      pagination: {
        totalCount,
        totalPages,
        currentPage: page,
        limit
      }
    });
  } catch (err) {
    console.error('GET /marketwins failed:', err);
    return res.status(500).json({ success: false, error: 'Internal server error' });
  }
});

/**
 * GET /marketwins/:id
 * Fetch a single record by id
 */
router.get('/marketwins', async (req, res) => {
  try {
    const staffIdHeader = req.get('x-staff-id');

    // ---- Hierarchy: who can I see? ----
    let tree = await visibleIds(staffIdHeader);
    if (!Array.isArray(tree)) tree = [];
    tree = tree.map(Number).filter(Number.isInteger);

    // Superadmin logic (ID = 1 can see all)
    const restrictByTree = !tree.includes(1);

    // ---- Parse & sanitize pagination ----
    const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 10, 1), 100);
    const offset = (page - 1) * limit;

    // ---- Filters ----
    const search = (req.query.search || '').trim();
    const userIdFilter = (req.query.userId || '').trim();

    // ---- WHERE builder ----
    const whereParts = [];
    const params = [];

    // When restricting by tree, we join `users u` and filter by u.creator_id ∈ tree.
    // NOTE: if your users table uses a different staff foreign key (e.g., u.assigned_staff_id),
    // change `u.creator_id` below accordingly.
    if (restrictByTree) {
      params.push(tree);
      whereParts.push(`u.parent_staff_id = ANY($${params.length}::bigint[])`);
    }

    if (search) {
      params.push(`%${search}%`);
      const p = `$${params.length}`;
      // Use mw.* because we’ll alias marketwins as mw
      whereParts.push(
        `(mw.matchname ILIKE ${p}
           OR mw.winteam ILIKE ${p}
           OR CAST(mw.eventid AS TEXT) ILIKE ${p}
           OR CAST(mw.matchid AS TEXT) ILIKE ${p})`
      );
    }

    if (userIdFilter) {
      params.push(userIdFilter);
      whereParts.push(`mw.user_id = $${params.length}`);
    }

    const whereSql = whereParts.length ? `WHERE ${whereParts.join(' AND ')}` : '';

    // ---- FROM / JOIN pieces (only join users when we need hierarchy restriction) ----
    const fromSql = restrictByTree
      ? `FROM marketwins mw
         JOIN users u ON u.id = mw.user_id`
      : `FROM marketwins mw`;

    // ---- Count total ----
    const countSql = `
      SELECT COUNT(*)::BIGINT AS count
      ${fromSql}
      ${whereSql};
    `;
    const { rows: countRows } = await db.query(countSql, params);
    const totalCount = Number(countRows?.[0]?.count || 0);
    const totalPages = Math.max(Math.ceil(totalCount / limit), 1);

    // ---- Fetch page ----
    const dataSql = `
      SELECT
        mw.id,
        mw.totalbets,
        mw.matchid,
        mw.eventid,
        mw.team1ex,
        mw.team2ex,
        mw.drawex,
        mw.winteam,
        mw.matchname,
        mw.payout,
        mw.user_id,
        mw.created_at
      ${fromSql}
      ${whereSql}
      ORDER BY mw.created_at DESC, mw.id DESC
      LIMIT $${params.length + 1}
      OFFSET $${params.length + 2};
    `;
    const dataParams = [...params, limit, offset];
    const { rows } = await db.query(dataSql, dataParams);

    return res.json({
      data: rows,
      pagination: {
        totalCount,
        totalPages,
        currentPage: page,
        limit
      }
    });
  } catch (err) {
    console.error('GET /marketwins failed:', err);
    return res.status(500).json({ success: false, error: 'Internal server error' });
  }
});
router.get('/MO/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const q = `
      SELECT
        id,
        totalbets,
        matchid,
        eventid,
        team1ex,
        team2ex,
        drawex,
        winteam,
        matchname,
        payout,
        user_id,
        created_at
      FROM marketwins
      WHERE user_id = $1;
    `;
    const { rows } = await db.query(q, [id]);
    if (!rows.length) {
      return res.status(404).json({ success: false, error: 'Not found' });
    }
    return res.json({ data: rows });
  } catch (err) {
    console.error('GET /marketwins/:id failed:', err);
    return res.status(500).json({ success: false, error: 'Internal server error' });
  }
});
router.get('/FAN/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const q = `
      SELECT id, userid, fancyname, selection, runsodds, payout, created_at
      FROM fanwins
      WHERE userid = $1
    `;
    const { rows } = await db.query(q, [id]);
    if (!rows.length) return res.status(404).json({ success: false, error: 'Not found' });
    return res.json({ data: rows });
  } catch (err) {
    console.error('GET /fanwins/:id failed:', err);
    return res.status(500).json({ success: false, error: 'Internal server error' });
  }
});
router.get('/fanwins', async (req, res) => {
  try {
    const staffIdHeader = req.get('x-staff-id');

    // ---- Hierarchy scope ----
    let tree = await visibleIds(staffIdHeader);
    if (!Array.isArray(tree)) tree = [];
    tree = tree.map(Number).filter(Number.isInteger);

    // Superadmin (ID=1) can see all
    const restrictByTree = !tree.includes(1);

    // ---- Pagination ----
    const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 10, 1), 100);
    const offset = (page - 1) * limit;

    // ---- Filters ----
    const search = (req.query.search || '').trim();
    const userIdFilter = (req.query.userId || '').trim();

    // ---- WHERE builder ----
    const whereParts = [];
    const params = [];

    // hierarchy filter: join users and require users.creator_id ∈ tree
    if (restrictByTree) {
      params.push(tree);
      whereParts.push(`u.parent_staff_id = ANY($${params.length}::bigint[])`);
    }

    if (search) {
      params.push(`%${search}%`);
      const p = `$${params.length}`;
      whereParts.push(
        `(fw.fancyname ILIKE ${p}
          OR fw.selection ILIKE ${p}
          OR CAST(fw.eventid AS TEXT) ILIKE ${p}
          OR CAST(fw.matchid AS TEXT) ILIKE ${p})`
      );
    }

    if (userIdFilter) {
      params.push(userIdFilter);
      whereParts.push(`fw.userid = $${params.length}`);
    }

    const whereSql = whereParts.length ? `WHERE ${whereParts.join(' AND ')}` : '';

    // ---- FROM/JOIN (only join users when restricting by tree) ----
    const fromSql = restrictByTree
      ? `FROM fanwins fw
         JOIN users u ON u.id = fw.userid`
      : `FROM fanwins fw`;

    // ---- Count ----
    const countSql = `
      SELECT COUNT(*)::BIGINT AS count
      ${fromSql}
      ${whereSql};
    `;
    const { rows: crows } = await db.query(countSql, params);
    const totalCount = Number(crows?.[0]?.count || 0);
    const totalPages = Math.max(Math.ceil(totalCount / limit), 1);

    // ---- Data page ----
    const dataSql = `
      SELECT
        fw.id,
        fw.userid,
        fw.fancyname,
        fw.selection,
        fw.runsodds,
        fw.payout,
        fw.eventid,
        fw.matchid,
        fw.created_at
      ${fromSql}
      ${whereSql}
      ORDER BY fw.created_at DESC, fw.id DESC
      LIMIT $${params.length + 1}
      OFFSET $${params.length + 2};
    `;
    const { rows } = await db.query(dataSql, [...params, limit, offset]);

    return res.json({
      data: rows,
      pagination: { totalCount, totalPages, currentPage: page, limit }
    });
  } catch (err) {
    console.error('GET /fanwins failed:', err);
    return res.status(500).json({ success: false, error: 'Internal server error' });
  }
});

const deleteBet = async (req, res) => {
  const { id } = req.params;

  const query = `DELETE FROM "SportsBet" WHERE id = $1`;

  try {
    await db.query(query, [id]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};
const getMoMatches = async (req, res) => {
  const limit = parseInt(req.query.limit, 10) || 100;
  const offset = parseInt(req.query.offset, 10) || 0;

  const sql = `
    SELECT
      match_id,
      eventid,
      MAX(match_title)      AS match_title,
      MAX(team_one)         AS team_one,
      MAX(team_two)         AS team_two,
      COUNT(*)              AS totalbets,
      MAX(counts)           AS counts
    FROM "SportsBet"
    WHERE game_type = $1
      AND status = $2
      AND match_id IS NOT NULL
      AND eventid IS NOT NULL
    GROUP BY match_id, eventid
    ORDER BY MAX(created_at) DESC
    LIMIT $3 OFFSET $4
  `;

  try {
    const { rows } = await db.query(sql, ['MO', 'open', limit, offset]);

    const payload = rows.map(r => ({
      matchId: r.match_id,
      eventId: r.eventid,
      matchTitle: r.match_title,
      teamOne: r.team_one,
      teamTwo: r.team_two,
      totalBets: parseInt(r.totalbets, 10),
      counts: r.counts !== null ? Number(r.counts) : null
    }));

    return res.json({ success: true, data: payload });
  } catch (err) {
    console.error('getMoMatches error:', err);
    return res.status(500).json({ success: false, error: err.message });
  }
};


const calculateMatchPayouts = async (req, res) => {
  try {
    const { matchId, eventId, winnerName, teamOne, teamTwo, counts } = req.body;
    console.log('calculateMatchPayouts called with:', req.body);

    if (!matchId || !eventId) {
      return res.status(400).json({ success: false, error: 'matchId and eventId are required' });
    }

    // determine refund mode
    const isRefund = String(winnerName).toLowerCase() === 'refund';

    // 1) get distinct user ids who have bets on this match/event where game_type=MO and status=open
    const usersQuery = `
      SELECT DISTINCT user_id
      FROM "SportsBet"
      WHERE match_id = $1
        AND eventid = $2
        AND game_type = 'MO'
        AND status = 'open'
    `;
    console.log('Executing usersQuery with:', [String(matchId), String(eventId)]);
    const usersResult = await db.query(usersQuery, [String(matchId), String(eventId)]);
    const userRows = usersResult.rows || [];
    const userIds = userRows.map(r => r.user_id);

    let total_credit = 0;      // sum of finalcredit for each user (will remain 0 for refund)
    let total_lability = 0;    // sum of normalizeExposure(mostNeg) for each user
    const perUser = [];        // optional detail list (remove if not needed)

    // iterate users sequentially (if many users, consider batching/concurrency limits)
    for (const user_id of userIds) {
      // get exposures map for this user and this match
      console.log(`Fetching exposures for user_id=${user_id}, matchId=${matchId}`);
      const { rows: oldExpRows } = await db.query(
        `SELECT team_name, exposure_amount
           FROM user_exposures
          WHERE user_id = $1 AND match_id = $2
          FOR UPDATE`,
        [user_id, matchId]
      );
      const oldExposures = {};
      oldExpRows.forEach(r => { oldExposures[r.team_name] = Number(r.exposure_amount); });
      console.log('OLD EXPOSURES:', oldExposures);

      // ensure keys exist (default 0)
      const team1 = Number(oldExposures[teamOne] || 0);
      const team2 = Number(oldExposures[teamTwo] || 0);
      const draw = Number(oldExposures['The Draw'] || 0);

      // find most negative exposure (i.e. the largest liability negative number)
      const negatives = Object.values(oldExposures)
        .map(v => Number(v || 0))
        .filter(x => x < 0);

      // if no negative exposures, set mostNeg = 0
      const mostNeg = negatives.length ? Math.min(...negatives) : 0;

      // If refund mode: finalcredit is always 0, but we still count liability
      let finalcredit = 0;
      if (isRefund) {
        finalcredit = 0;
        total_lability += normalizeExposure(mostNeg);
      } else {
        // compute finalcredit per your logic
        const c = Number(counts);

        if (c === 2) {
          if (teamOne === winnerName) {
            if (team1 < 0) {
              finalcredit = 0;
            } else {
              finalcredit = normalizeExposure(team1) + normalizeExposure(team2);
            }
          } else if (teamTwo === winnerName) {
            if (team2 < 0) {
              finalcredit = 0;
            } else {
              finalcredit = normalizeExposure(team1) + normalizeExposure(team2);
            }
          } else {
            // winnerName not equal teamOne or teamTwo — in MO with counts==2 unclear, default 0
            finalcredit = 0;
          }
        } else {
          // counts != 2 branch
          if (teamOne === winnerName) {
            if (team1 < 0) {
              finalcredit = normalizeExposure(mostNeg) - normalizeExposure(team1);
            } else {
              finalcredit = normalizeExposure(mostNeg) + normalizeExposure(team1);
            }
          } else if (teamTwo === winnerName) {
            if (team2 < 0) {
              finalcredit = normalizeExposure(mostNeg) - normalizeExposure(team2);
            } else {
              finalcredit = normalizeExposure(mostNeg) + normalizeExposure(team2);
            }
          } else {
            // draw or other winner case
            if (draw < 0) {
              finalcredit = normalizeExposure(mostNeg) - normalizeExposure(draw);
            } else {
              finalcredit = normalizeExposure(mostNeg) + normalizeExposure(draw);
            }
          }
        }

        // accumulate liability in non-refund flow as well
        total_lability += normalizeExposure(mostNeg);
      }

      // Normalize finalcredit to number (avoid NaN)
      finalcredit = Number(finalcredit || 0);

      // accumulate total credit (will be 0 if refund mode)
      total_credit += finalcredit;

      perUser.push({
        user_id,
        finalcredit,
        mostNeg,
        normalizedMostNeg: normalizeExposure(mostNeg),
        exposures: oldExposures
      });
    }

    // If refund mode, ensure total_credit is exactly 0 (defensive)
    if (isRefund) total_credit = 0;

    const result = {
      success: true,
      totalusers: userIds.length,
      total_credit: Number(total_credit.toFixed(2)),
      total_lability: Number(total_lability.toFixed(2)),
      // optional details for inspection (remove in production if sensitive)
      details: perUser
    };

    return res.json(result);
  } catch (err) {
    console.error('calculateMatchPayouts error:', err);
    return res.status(500).json({ success: false, error: err.message });
  }
};

const createManualSettlement = async (req, res) => {
  const { matchId, eventId, winnerName, teamOne, teamTwo, counts } = req.body;

  if (!matchId || !eventId || !winnerName) {
    return res.status(400).json({ success: false, error: 'matchId, eventId and winnerName are required' });
  }

  // Normalize and detect refund (handle common typo "reffund" too)
  const winnerNorm = String(winnerName).trim();
  const winLower = winnerNorm.toLowerCase();
  const isRefund = winLower === 'refund' || winLower === 'reffund';

  try {
    await db.query('BEGIN');

    // Insert into manual_settle table
    const insertSql = `
      INSERT INTO manual_settle (
        match_id,
        eventid,
        winner_name,
        team_one,
        team_two,
        counts,
        created_at
      ) VALUES ($1,$2,$3,$4,$5,$6,NOW())
      RETURNING id
    `;
    const insertVals = [
      String(matchId),
      String(eventId),
      isRefund ? 'refund' : winnerNorm,
      teamOne || null,
      teamTwo || null,
      Number(counts) || 0
    ];

    const insertRes = await db.query(insertSql, insertVals);
    const insertedId = insertRes.rows[0] ? insertRes.rows[0].id : null;

    // Update "SportsBet" rows
    const updateSql = `
      UPDATE "SportsBet"
      SET status = $3,
          updated_at = NOW()
      WHERE match_id = $1
        AND eventid = $2
        AND game_type = 'MO'
    `;
    const newStatus = isRefund ? 'refund' : 'manual';
    const updateVals = [String(matchId), String(eventId), newStatus];

    const updateRes = await db.query(updateSql, updateVals);

    await db.query('COMMIT');

    return res.json({
      success: true,
      manualSettleId: insertedId,
      updatedBetsCount: updateRes.rowCount,
      status: newStatus
    });
  } catch (err) {
    await db.query('ROLLBACK');
    console.error('createManualSettlement error:', err);
    return res.status(500).json({ success: false, error: err.message });
  } finally {
    if (typeof db.release === 'function') {
      try { db.release(); } catch (e) { /* ignore */ }
    }
  }
};



const getFanOpenBets = async (req, res) => {
  const limit = parseInt(req.query.limit, 10) || 100;
  const offset = parseInt(req.query.offset, 10) || 0;

  try {
    // 1) get aggregated fancys (same as before)
    const groupsSql = `
      SELECT
        match_id,
        eventid,
        MAX(match_title)    AS match_title,
        MAX(fancy_name)     AS fancy_name,
        COUNT(*)            AS totalbets
      FROM "SportsBet"
      WHERE game_type = $1
        AND status = $2
        AND match_id IS NOT NULL
        AND eventid IS NOT NULL
        AND fancy_name IS NOT NULL
      GROUP BY match_id, eventid, fancy_name
      ORDER BY MAX(created_at) DESC
      LIMIT $3 OFFSET $4
    `;
    const groupsRes = await db.query(groupsSql, ['FAN', 'open', limit, offset]);
    const groups = groupsRes.rows || [];

    if (groups.length === 0) {
      return res.json({ success: true, data: [] });
    }

    // 2) build tuple list for WHERE ... IN ((m,e,f), (m,e,f), ...)
    // We'll create parameters for each value to keep it safe.
    const tuples = [];
    const params = [];
    let paramIdx = 1;

    for (const g of groups) {
      tuples.push(`($${paramIdx++}, $${paramIdx++}, $${paramIdx++})`);
      params.push(String(g.match_id), String(g.eventid), g.fancy_name);
    }

    const betsSql = `
      SELECT
        id,
        user_id,
        match_id,
        eventid,
        fancy_name,
        match_title,
        team_one,
        team_two,
        selection_name,
        bet_type,
        odds,
        stake_amount,
        original_currency,
        original_amount,
        usd_amount,
        liability,
        status,
        created_at
      FROM "SportsBet"
      WHERE game_type = 'FAN'
        AND status = 'open'
        AND (match_id, eventid, fancy_name) IN (${tuples.join(',')})
      ORDER BY created_at ASC
    `;

    const betsRes = await db.query(betsSql, params);
    const bets = betsRes.rows || [];

    // 3) group bets by composite key (match_id|eventid|fancy_name)
    const groupMap = new Map(); // key -> { matchId,eventId,fancyName, totalBets, bets:[] }

    for (const g of groups) {
      const key = `${g.match_id}||${g.eventid}||${g.fancy_name}`;
      groupMap.set(key, {
        matchId: g.match_id,
        eventId: g.eventid,
        matchTitle: g.match_title,
        fancyName: g.fancy_name,
        totalBets: Number(g.totalbets || 0),
        bets: []
      });
    }

    // normalize/shape each bet and attach
    for (const b of bets) {
      const key = `${b.match_id}||${b.eventid}||${b.fancy_name}`;
      const bucket = groupMap.get(key);
      if (!bucket) continue; // defensive

      bucket.bets.push({
        id: b.id,
        userId: b.user_id,
        betType: b.bet_type,
        selectionName: b.selection_name,
        teamOne: b.team_one,
        teamTwo: b.team_two,
        odds: b.odds !== null ? Number(b.odds) : null,
        stakeAmount: b.stake_amount !== null ? Number(b.stake_amount) : null,
        originalCurrency: b.original_currency,
        originalAmount: b.original_amount !== null ? Number(b.original_amount) : null,
        usdAmount: b.usd_amount !== null ? Number(b.usd_amount) : null,
        liability: b.liability !== null ? Number(b.liability) : null,
        status: b.status,
        createdAt: b.created_at
      });
    }

    // 4) result array in same order as groups
    const payload = groups.map(g => {
      const key = `${g.match_id}||${g.eventid}||${g.fancy_name}`;
      const entry = groupMap.get(key);
      // If bets array is large and you want only unique-by-user or dedup, adjust here.
      return entry;
    });

    return res.json({ success: true, data: payload });
  } catch (err) {
    console.error('getFanOpenBets error:', err);
    return res.status(500).json({ success: false, error: err.message });
  }
};

const getFanPayoutsByFancy = async (req, res) => {
  try {
    const { matchId, eventId, fancyName, selectionType } = req.body;

    if (!matchId || !eventId || !fancyName || !selectionType) {
      return res.status(400).json({ success: false, error: 'matchId, eventId, fancyName and selectionType are required' });
    }

    const sel = String(selectionType).toLowerCase();
    if (!['yes', 'no'].includes(sel)) {
      return res.status(400).json({ success: false, error: "selectionType must be 'yes' or 'no'" });
    }

    const sql = `
      SELECT
        COUNT(DISTINCT user_id) AS totalusers,
        COALESCE(SUM(CASE WHEN LOWER(bet_type) = $4 THEN stake_amount ELSE 0 END), 0) * 2 AS total_credit,
        COALESCE(SUM(stake_amount), 0) AS total_lability
      FROM "SportsBet"
      WHERE match_id = $1
        AND eventid = $2
        AND game_type = 'FAN'
        AND status = 'open'
        AND fancy_name = $3
    `;

    const { rows } = await db.query(sql, [String(matchId), String(eventId), fancyName, sel]);
    const r = rows[0] || { totalusers: 0, total_credit: 0, total_lability: 0 };

    return res.json({
      success: true,
      matchId: String(matchId),
      eventId: String(eventId),
      fancyName,
      selectionType: sel,
      totalusers: Number(r.totalusers || 0),
      total_credit: Number(r.total_credit || 0),
      total_lability: Number(r.total_lability || 0)
    });
  } catch (err) {
    console.error('getFanPayoutsByFancy error:', err);
    return res.status(500).json({ success: false, error: err.message });
  }
};

const createFancyManualSettlement = async (req, res) => {
  const {
    matchId,
    eventId,
    fancyName,
    selection,
    betId,
    userId,
    performedBy = null,
    notes = null,
  } = req.body;

  if (!matchId || !eventId || !fancyName || !selection || !betId || !userId) {
    return res.status(400).json({
      success: false,
      error: "matchId, eventId, fancyName, selection, betId, and userId are required",
    });
  }


  try {
    await db.query("BEGIN");

    // ✅ Insert into fancymanualsettlement with bet & user
    const insertSql = `
      INSERT INTO fancymanualsettlement
        (match_id, eventid, fancy_name, selection, bet_id, user_id, performed_by, notes, created_at, updated_at)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,NOW(),NOW())
      RETURNING id
    `;
    const insertVals = [
      String(matchId),
      String(eventId),
      fancyName,
      String(selection).toLowerCase(),
      Number(betId),
      Number(userId),
      performedBy ? Number(performedBy) : null,
      notes,
    ];

    const insertRes = await db.query(insertSql, insertVals);
    const insertedId = insertRes.rows[0]?.id || null;

    // ✅ Update "SportsBet" to mark this bet as manual
    const updateSql = `
      UPDATE "SportsBet"
      SET status = 'manual',
          updated_at = NOW()
      WHERE id = $1
        AND user_id = $2
        AND match_id = $3
        AND eventid = $4
        AND fancy_name = $5
        AND game_type = 'FAN'
    `;
    const updateVals = [Number(betId), Number(userId), String(matchId), String(eventId), fancyName];
    const updateRes = await db.query(updateSql, updateVals);

    await db.query("COMMIT");

    return res.json({
      success: true,
      fancymanualId: insertedId,
      updatedBetsCount: updateRes.rowCount,
    });
  } catch (err) {
    await db.query("ROLLBACK");

    if (err.code === "23505") {
      return res.status(409).json({
        success: false,
        error: "Manual settlement for this fancy already exists",
      });
    }

    console.error("createFancyManualSettlement error:", err);
    return res.status(500).json({ success: false, error: err.message });
  } finally {
    // db.release();
    console.log("createFancyManualSettlement finished");
  }
};
const createFancyRefundSettlement = async (req, res) => {
  const {
    matchId,
    eventId,
    fancyName,

  } = req.body;

  if (!matchId || !eventId || !fancyName) {
    return res.status(400).json({
      success: false,
      error: "matchId, eventId, fancyName, selection, betId, and userId are required",
    });
  }

  try {
    await db.query("BEGIN");

    // ✅ Insert into fancyrefundsettlement table


    // ✅ Update "SportsBet" to mark this bet as refund
    const updateSql = `
      UPDATE "SportsBet"
      SET status = 'refund',
          updated_at = NOW()
      WHERE 
        match_id = $1
        AND eventid = $2
        AND fancy_name = $3
        AND game_type = 'FAN'
    `;
    const updateVals = [String(matchId), String(eventId), fancyName];
    const updateRes = await db.query(updateSql, updateVals);

    await db.query("COMMIT");

    return res.json({
      success: true,
      updatedBetsCount: updateRes.rowCount,
    });
  } catch (err) {
    await db.query("ROLLBACK");

    if (err.code === "23505") {
      return res.status(409).json({
        success: false,
        error: "Refund settlement for this fancy already exists",
      });
    }

    console.error("createFancyRefundSettlement error:", err);
    return res.status(500).json({ success: false, error: err.message });
  } finally {
    console.log("createFancyRefundSettlement finished");
  }
};

const fetchFancyResults = async (req, res) => {
  try {
    // pagination
    let page = Number(req.query.page || 1);
    let limit = Number(req.query.limit || 20);
    if (!Number.isInteger(page) || page < 1) page = 1;
    if (!Number.isInteger(limit) || limit < 1) limit = 20;

    const offset = (page - 1) * limit;

    // main query: all columns
    const query = `
      SELECT *
      FROM public.fancyresultsummary
      ORDER BY id DESC
      LIMIT $1 OFFSET $2
    `;
    const { rows } = await db.query(query, [limit, offset]);

    // count for pagination
    const { rows: countRows } = await db.query(
      `SELECT COUNT(*) AS total FROM public.fancyresultsummary`
    );
    const total = Number(countRows[0]?.total || 0);

    res.json({
      success: true,
      results: rows,
      pagination: {
        total,
        totalPages: Math.ceil(total / limit),
        page,
        limit,
      },
    });
  } catch (err) {
    console.error("fetchFancyResults error:", err);
    res.status(500).json({ success: false, error: err.message || String(err) });
  }
};

router.get('/fancynotsettle', fetchFancyResults);
router.post('/fancyrefundsettle', createFancyRefundSettlement);
router.post('/fancymanualsettle', createFancyManualSettlement);
router.post('/fanpayouts', getFanPayoutsByFancy);
router.get('/fanmatches', getFanOpenBets);
router.post('/manual-settlement', createManualSettlement);

router.post('/calculate-payouts', calculateMatchPayouts);
router.get('/momatches', getMoMatches);

router.get('/admin/bets', getAdminBets);
router.put('/admin/bets/:id/status', updateBetStatus);
router.delete('/admin/bets/:id', deleteBet);
router.get('/settle', controller.settleBets);
module.exports = router;
