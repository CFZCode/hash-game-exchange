const lib = require('xss-clean');
const db = require('../General/Model');
const fetch = require('node-fetch');

let cachedUsdRate = 0;
let cachedAt = 0;

function normalizeOdds(odds) {
  let newodds;
  if (odds > 100) {
    // Positive American odds → decimal
    newodds = (odds / 100) + 1;       // e.g. 150 → 2.50
  } else if (odds < 100) {
    // Small odds → scale down close to 1.0
    newodds = 1 + (odds / 100);       // e.g. 2.75 → 1.0275
  } else {
    newodds = 2.0;                    // exactly 100 → 2.0
  }

  // Floor to 2 decimal places (no rounding up)
  return Math.floor(newodds * 100) / 100;
}
async function inrToUsd(inrAmount = 0) {
  const FIVE_MIN = 5 * 60 * 1000;
  const now = Date.now();
  if (!cachedUsdRate || now - cachedAt > FIVE_MIN) {
    try {
      const r = await fetch('https://api.exchangerate.host/latest?base=INR&symbols=USD');
      const j = await r.json();
      cachedUsdRate = 1 / j.rates.USD;
      cachedAt = now;
    } catch (e) {
      console.error('FX fetch failed, using fallback 83:', e.message);
      cachedUsdRate = 1 / 83;
    }
  }
  return +(inrAmount * cachedUsdRate).toFixed(2);
}

const liabilityOf = (gameType, betType, stake, odds) => {
  if (gameType === 'FAN') return stake * odds / 100;
  return betType === 'lay' ? stake * (odds - 1) : stake;
};
exports.placeBet = async (req, res) => {
  const {
    user_id, game_type, match_id, match_title, selection_name,
    bet_type, odds, stake_amount, team_one, team_two,
    category, original_currency, original_amount, usd_amount, match_start_time,eventid,
    marketname ,count
  } = req.body;
  console.log('PLACE BET:', {
    user_id, game_type, match_id, match_title, selection_name,
    bet_type, odds, stake_amount, team_one, team_two,
    category, original_currency, original_amount, usd_amount, match_start_time,eventid,marketname,count
  });

  const ip_address =
    req.headers['x-forwarded-for']?.split(',')[0] || req.connection.remoteAddress || req.ip;

  const stake = Number(stake_amount);
  const oddN  = Number(odds);

  const betTypeLower = (bet_type || '').toString().trim().toLowerCase();
  const isYesNo = betTypeLower === 'yes' || betTypeLower === 'no';
  const isFancy = (game_type === 'FAN') || (game_type === 'MO' && isYesNo);
  const isBookmaker = game_type === 'BM';

  if (stake <= 0) {
    return res.status(400).json({ success: false, error: 'Invalid stake' });
  }
  if (isFancy) {
    if (!Number.isFinite(oddN) || oddN <= 0) {
      return res.status(400).json({ success: false, error: 'Invalid fancy odds' });
    }
    if (!isYesNo) {
      return res.status(400).json({ success: false, error: 'Fancy bet must be YES or NO' });
    }
  } else {
    if (!Number.isFinite(oddN) || oddN <= 1) {
      return res.status(400).json({ success: false, error: 'Invalid odds' });
    }
  }

  const startTime = match_start_time || new Date().toISOString();

  try {
    await db.query('BEGIN');

    if (!user_id) return res.status(400).json({ success: false, error: 'User ID is required' });
    const uid = String(user_id);

    /* ── Sports / System lock check ──────────────────────────────── */
    const { rows: [lockUser] } = await db.query(
      'SELECT sports_betlocked, system_locked, parent_staff_id FROM users WHERE id = $1', [uid]
    );
    if (lockUser) {
      if (lockUser.system_locked)
        return res.status(403).json({ success: false, error: 'Account is system locked' });
      if (lockUser.sports_betlocked)
        return res.status(403).json({ success: false, error: 'Sports betting is locked for this account' });

      // Check parent staff hierarchy for sports/system lock
      if (lockUser.parent_staff_id) {
        const { rows: lockedStaff } = await db.query(`
          SELECT 1 FROM staff_hierarchy h
          JOIN staff s ON s.id = h.ancestor_id
          WHERE h.descendant_id = $1
            AND (s.sports_betlocked = true OR s.system_locked = true)
          LIMIT 1
        `, [lockUser.parent_staff_id]);
        if (lockedStaff.length)
          return res.status(403).json({ success: false, error: 'Sports betting is locked by an administrator' });
      }
    }
    /* ── End lock check ──────────────────────────────────────────── */

    console.log('PLACE BET: resolved user_id:', uid);

    const { rows: cRows } = await db.query(`SELECT inr FROM credits WHERE uid = $1`, [uid]);
    if (!cRows[0]) throw new Error('Wallet not found');
    const currentInr = Number(cRows[0].inr);
    console.log('Current wallet balance:', currentInr);

    const { rows: oldExpRows } = await db.query(
      `SELECT team_name, exposure_amount
         FROM user_exposures
        WHERE user_id = $1 AND match_id = $2
        FOR UPDATE`,
      [uid, match_id]
    );
    const oldExposures = {};
    oldExpRows.forEach(r => { oldExposures[r.team_name] = Number(r.exposure_amount); });
    console.log('OLD EXPOSURES:', oldExposures);

    const newExposures = { ...oldExposures };

    const normGameType =
      isFancy ? 'FAN'
      : (game_type === 'BM' ? 'BM' : 'MO');

    const sel = (selection_name || '').toString();
    const selLower = sel.trim().toLowerCase();
    const isDrawSel = (selLower === 'the draw' || selLower === 'draw');

    if (isFancy) {
      // ===== FANCY / LINE (Yes/No) =====
      // if (betTypeLower === 'no') {
      //   const key = 'No';
      //   newExposures[key] = (oldExposures[key] || 0) - stake;   // NO => negative by odds
      // } else {
      //   const key = 'Yes';
      //   newExposures[key] = (oldExposures[key] || 0) - stake;  // YES => negative by stake
      // }
      console.log("[FANCY] Bet disabled for exposer");

    } else if (normGameType === 'MO') {
      // ===== MATCH ODDS (three-way, supports Draw explicitly) =====
      const profit = stake * (oddN - 1);
      const layLiab = stake * (oddN - 1);

      if (isDrawSel) {
        if (betTypeLower === 'back') {
          // BACK on Draw: Draw +profit, both teams -stake
          if(count == 3){

          
          newExposures['The Draw']     = (oldExposures['The Draw'] || 0) + profit;
          }
          newExposures[team_one]       = (oldExposures[team_one]   || 0) - stake;
          newExposures[team_two]       = (oldExposures[team_two]   || 0) - stake;
        } else {
          // LAY on Draw: Draw -liability, both teams +stake
              if(count == 3){
          newExposures['The Draw']     = (oldExposures['The Draw'] || 0) - layLiab;
              }
          newExposures[team_one]       = (oldExposures[team_one]   || 0) + stake;
          newExposures[team_two]       = (oldExposures[team_two]   || 0) + stake;
        }
      } else {
        // selection is one of the teams
        const otherTeam = sel === team_one ? team_two : team_one;

        if (betTypeLower === 'back') {
          // Team BACK: selected +profit, both others -stake
          newExposures[sel]            = (oldExposures[sel]        || 0) + profit;
          newExposures[otherTeam]      = (oldExposures[otherTeam]  || 0) - stake;
              if(count == 3){
          newExposures['The Draw']     = (oldExposures['The Draw'] || 0) - stake;
              }
        } else {
          // Team LAY: selected -liability, both others +stake
          newExposures[sel]            = (oldExposures[sel]        || 0) - layLiab;
          newExposures[otherTeam]      = (oldExposures[otherTeam]  || 0) + stake;
              if(count == 3){
          newExposures['The Draw']     = (oldExposures['The Draw'] || 0) + stake;
              }
        }
      }

    } else if (normGameType === 'BM') {
  // ===== BOOKMAKER (two-way) using same MO-style logic but with normalized odds =====
  const newodds = normalizeOdds(oddN);
  console.log(`Normalized BM odds: ${oddN} → ${newodds}`);

  // use normalized odds to compute profit / lay liability
  const profit = stake * (newodds - 1);
  const layLiab = stake * (newodds - 1);

  // determine the other team (BM is two-way so no draw)
  const otherTeam = sel === team_one ? team_two : team_one;

  if (betTypeLower === 'back') {
    // BACK on selected team: selected +profit, other team -stake
    newExposures[sel] = (oldExposures[sel] || 0) + profit;
    newExposures[otherTeam] = (oldExposures[otherTeam] || 0) - stake;
  } else {
    // LAY on selected team: selected -liability, other team +stake
    newExposures[sel] = (oldExposures[sel] || 0) - layLiab;
    newExposures[otherTeam] = (oldExposures[otherTeam] || 0) + stake;
  }
  
}else {
      throw new Error(`Unknown game_type: ${game_type}`);
    }

    console.log('NEW EXPOSURES:', newExposures);

    // ===== WALLET BLOCK =====
    let balanceChange = 0; // +deduct, -release

    if (isFancy) {
      balanceChange =  stake;
      if (currentInr < balanceChange) throw new Error('Insufficient balance');
      console.log('[FANCY] Fixed deduction:', balanceChange);
    } else {
      // ✅ Normalize BM odds if they look like integer odds (e.g., 50 → 1.50, 236 → 2.36)
 

      // MO/BM — max negative liability delta
      const oldNegs = Object.values(oldExposures).filter(x => x < 0);
      const newNegs = Object.values(newExposures).filter(x => x < 0);
      const oldMax  = oldNegs.length ? Math.abs(Math.min(...oldNegs)) : 0;
      const newMax  = newNegs.length ? Math.abs(Math.min(...newNegs)) : 0;
      const liabInc = newMax - oldMax;

      console.log('LIABILITY CALCULATION (MO/BM):');
      console.log('- Old liabilities:', oldNegs);
      console.log('- New liabilities:', newNegs);
      console.log('- Old total liability (blocked):', oldMax);
      console.log('- New total liability (to block):', newMax);
      console.log('- Liability change:', liabInc);

      if (Object.keys(oldExposures).length === 0) balanceChange = newMax;
      else if (liabInc > 0) balanceChange = liabInc;
      else if (liabInc < 0) balanceChange = liabInc; // negative → release

      if (balanceChange > 0 && currentInr < balanceChange) throw new Error('Insufficient balance');
    }

    console.log('FINAL BALANCE CHANGE:', balanceChange, '(+deduct, -release)');

    // upsert exposures
    for (const [name, amt] of Object.entries(newExposures)) {
      await db.query(`
        INSERT INTO user_exposures
          (user_id, match_id, team_name, exposure_amount, match_title)
        VALUES ($1,$2,$3,$4,$5)
        ON CONFLICT (user_id,match_id,team_name)
        DO UPDATE SET exposure_amount = EXCLUDED.exposure_amount,
                      updated_at = NOW()
      `, [uid, match_id, name, amt, match_title]);
    }

    // liability to store on the bet row
    let singleBetLiability;
    if (isFancy) {
      singleBetLiability =  stake;
    } else if (normGameType === 'MO') {
      singleBetLiability = (betTypeLower === 'back') ? stake : stake * (oddN - 1);
    } else {
       const newodds = normalizeOdds(oddN);
      singleBetLiability = (betTypeLower === 'back') ? stake : stake * (newodds - 1);
    }
     
 let fixed = 0;

// if (balanceChange < 0) {
//   fixed = 1;
// }

     await db.query(`
      INSERT INTO sports_bets
       (user_id,game_type,match_id,match_title,team_one,team_two,
        selection_name,category,bet_type,odds,stake_amount,
        original_currency,original_amount,usd_amount,liability,
        match_start_time,exposure_after_bet,status,eventid,ip_address,fancy_name,fixed,counts)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23)
    `, [
      uid, normGameType, match_id, match_title, team_one, team_two,
      selection_name, category || 1, bet_type, oddN, stake,
      original_currency || 'INR', original_amount || stake, usd_amount || await inrToUsd(stake),
      singleBetLiability, startTime,
      Math.max(0, ...Object.values(newExposures).filter(v => v < 0).map(v => Math.abs(v)), 0),
      'open', eventid,ip_address,marketname || 'NULL',fixed,count
    ]);

    if (balanceChange !== 0) {
      await db.query(`UPDATE credits SET inr = inr - $1 WHERE uid = $2`, [balanceChange, uid]);
      console.log('Wallet updated. Balance change:', balanceChange);
    } else {
      console.log('No wallet update needed');
    }

    await db.query('COMMIT');

    const { rows: updatedRows } = await db.query(`SELECT inr FROM credits WHERE uid = $1`, [uid]);
    const newBalance = Number(updatedRows[0].inr);

    console.log('Transaction completed successfully');
    console.log('Old balance:', currentInr);
    console.log('New balance:', newBalance);
    console.log('Actual balance delta:', newBalance - currentInr);

    return res.json({
      success: true,
      exposure: { [match_id]: { match_title, teams: newExposures } },
      balanceDelta: newBalance - currentInr
    });

  } catch (err) {
    await db.query('ROLLBACK');
    console.error('PLACE BET ERROR:', err.message);
    return res.status(400).json({ success:false, error:err.message });
  }
};




// exports.placeBet = async (req, res) => {
//   const {
//     user_id, game_type, match_id, match_title, selection_name,
//     bet_type, odds, stake_amount, team_one, team_two,
//     category, original_currency, original_amount, usd_amount, match_start_time
//   } = req.body;
//   console.log('PLACE BET:', {
//     user_id, game_type, match_id, match_title, selection_name,
//     bet_type, odds, stake_amount, team_one, team_two,
//     category, original_currency, original_amount, usd_amount, match_start_time
//   });

//   const stake = Number(stake_amount);
//   const oddN  = Number(odds);

//   // classify: FAN when explicit OR MO with yes/no
//   const betTypeLower = (bet_type || '').toString().trim().toLowerCase();
//   const isYesNo = betTypeLower === 'yes' || betTypeLower === 'no';
//   const isFancy = (game_type === 'FAN') || (game_type === 'MO' && isYesNo);

//   // input checks
//   if (stake <= 0) {
//     return res.status(400).json({ success: false, error: 'Invalid stake' });
//   }
//   if (isFancy) {
//     if (!Number.isFinite(oddN) || oddN <= 0) {
//       return res.status(400).json({ success: false, error: 'Invalid fancy odds' });
//     }
//     if (!isYesNo) {
//       return res.status(400).json({ success: false, error: 'Fancy bet must be YES or NO' });
//     }
//   } else {
//     // MO/BM must have decimal odds > 1
//     if (!Number.isFinite(oddN) || oddN <= 1) {
//       return res.status(400).json({ success: false, error: 'Invalid odds' });
//     }
//   }

//   const startTime = match_start_time || new Date().toISOString();

//   try {
//     await db.query('BEGIN');

//     if (!user_id) return res.status(400).json({ success: false, error: 'User ID is required' });
//     const uid = String(user_id);
//     console.log('PLACE BET: resolved user_id:', uid);

//     // wallet
//     const { rows: cRows } = await db.query(`SELECT inr FROM credits WHERE uid = $1`, [uid]);
//     if (!cRows[0]) throw new Error('Wallet not found');
//     const currentInr = Number(cRows[0].inr);
//     console.log('Current wallet balance:', currentInr);

//     // lock current exposures for this match
//     const { rows: oldExpRows } = await db.query(
//       `SELECT team_name, exposure_amount
//          FROM user_exposures
//         WHERE user_id = $1 AND match_id = $2
//         FOR UPDATE`,
//       [uid, match_id]
//     );

//     const oldExposures = {};
//     oldExpRows.forEach(r => { oldExposures[r.team_name] = Number(r.exposure_amount); });
//     console.log('OLD EXPOSURES:', oldExposures);

//     // compute new exposures
//     const newExposures = { ...oldExposures };

//     // Normalized game_type for storage
//     const normalizedGameType =
//       isFancy ? 'FAN'
//       : (game_type === 'BM' ? 'BM' : 'MO');

//     if (isFancy) {
//       // ===== FANCY / LINE: fixed per-bet deduction (NO: odds, YES: stake) =====
//       if (betTypeLower === 'no') {
//         const key = 'No';
//         newExposures[key] = (oldExposures[key] || 0) - oddN;
//       } else {
//         const key = 'Yes';
//         newExposures[key] = (oldExposures[key] || 0) - stake;
//       }
//       // do NOT touch teams or draw for fancy
//     } else if (normalizedGameType === 'MO') {
//       // ===== Match Odds (three-way) using back/lay exposure math =====
//       const otherTeam = selection_name === team_one ? team_two : team_one;
//       if ((bet_type || '').toLowerCase() === 'back') {
//         const profit = stake * (oddN - 1);
//         newExposures[selection_name] = (oldExposures[selection_name] || 0) + profit;
//         newExposures[otherTeam]      = (oldExposures[otherTeam]        || 0) - stake;
//         newExposures['The Draw']     = (oldExposures['The Draw']       || 0) - stake;
//       } else {
//         const layLiab = stake * (oddN - 1);
//         newExposures[selection_name] = (oldExposures[selection_name] || 0) - layLiab;
//         newExposures[otherTeam]      = (oldExposures[otherTeam]      || 0) + stake;
//         newExposures['The Draw']     = (oldExposures['The Draw']     || 0) + stake;
//       }
//     } else if (normalizedGameType === 'BM') {
//       // ===== Bookmaker (two-way) =====
//       const delta = stake * (oddN - 1);
//       newExposures[selection_name] =
//         (oldExposures[selection_name] || 0) + (((bet_type || '').toLowerCase() === 'back') ? delta : -delta);
//     } else {
//       throw new Error(`Unknown game_type: ${game_type}`);
//     }

//     console.log('NEW EXPOSURES:', newExposures);

//     // ===== Wallet block logic =====
//     let balanceChange = 0; // +deduct, -release

//     if (isFancy) {
//       // *** FANCY: fixed deduction — do not use max-liability delta ***
//       balanceChange = (betTypeLower === 'no') ? oddN : stake;

//       if (currentInr < balanceChange) {
//         throw new Error('Insufficient balance');
//       }
//       console.log('[FANCY] Fixed deduction:', balanceChange);
//     } else {
//       // *** MO/BM: use your existing "max liability delta" logic ***
//       const oldVals = Object.values(oldExposures);
//       const newVals = Object.values(newExposures);
//       const oldNegs = oldVals.filter(x => x < 0);
//       const newNegs = newVals.filter(x => x < 0);
//       const oldMaxLiab = oldNegs.length ? Math.abs(Math.min(...oldNegs)) : 0;
//       const newMaxLiab = newNegs.length ? Math.abs(Math.min(...newNegs)) : 0;
//       const liabilityIncrease = newMaxLiab - oldMaxLiab;

//       console.log('LIABILITY CALCULATION (MO/BM):');
//       console.log('- Old liabilities:', oldNegs);
//       console.log('- New liabilities:', newNegs);
//       console.log('- Old total liability (blocked):', oldMaxLiab);
//       console.log('- New total liability (to block):', newMaxLiab);
//       console.log('- Liability change:', liabilityIncrease);

//       if (Object.keys(oldExposures).length === 0) {
//         balanceChange = newMaxLiab;
//         console.log('- First bet for match, deducting:', balanceChange);
//       } else if (liabilityIncrease > 0) {
//         balanceChange = liabilityIncrease;
//         console.log('- Liability increased, deducting:', balanceChange);
//       } else if (liabilityIncrease < 0) {
//         balanceChange = liabilityIncrease; // negative -> add back
//         console.log('- Liability decreased, adding back:', Math.abs(liabilityIncrease));
//       } else {
//         balanceChange = 0;
//         console.log('- Liability unchanged, no wallet change');
//       }

//       if (balanceChange > 0 && currentInr < balanceChange) {
//         throw new Error('Insufficient balance');
//       }
//     }

//     console.log('FINAL BALANCE CHANGE:', balanceChange, '(+deduct, -release)');

//     // upsert exposures
//     for (const [teamName, expoAmt] of Object.entries(newExposures)) {
//       await db.query(`
//         INSERT INTO user_exposures
//           (user_id, match_id, team_name, exposure_amount, match_title)
//         VALUES ($1,$2,$3,$4,$5)
//         ON CONFLICT (user_id,match_id,team_name)
//         DO UPDATE SET exposure_amount = EXCLUDED.exposure_amount,
//                       updated_at = NOW()
//       `, [uid, match_id, teamName, expoAmt, match_title]);
//     }

//     // single-bet liability to store in sports_bets
//     let singleBetLiability;
//     if (isFancy) {
//       singleBetLiability = (betTypeLower === 'no') ? oddN : stake; // NO->odds, YES->stake
//     } else if (normalizedGameType === 'MO') {
//       singleBetLiability =
//         (betTypeLower === 'back') ? stake : stake * (oddN - 1);
//     } else {
//       // BM
//       singleBetLiability = Math.max(stake, stake * (oddN - 1));
//     }

//     // record bet
//     await db.query(`
//       INSERT INTO sports_bets
//        (user_id,game_type,match_id,match_title,team_one,team_two,
//         selection_name,category,bet_type,odds,stake_amount,
//         original_currency,original_amount,usd_amount,liability,
//         match_start_time,exposure_after_bet,status)
//       VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18)
//     `, [
//       uid, normalizedGameType, match_id, match_title, team_one, team_two,
//       selection_name, category || 1, bet_type, oddN, stake,
//       original_currency || 'INR', original_amount || stake, usd_amount || await inrToUsd(stake),
//       singleBetLiability, startTime,
//       // keep this as “current max negative” for MO/BM; for Fancy it’s informational only
//       Math.max(
//         0,
//         ...Object.values(newExposures).filter(v => v < 0).map(v => Math.abs(v)),
//         0
//       ),
//       'open'
//     ]);

//     // wallet update
//     if (balanceChange !== 0) {
//       await db.query(`UPDATE credits SET inr = inr - $1 WHERE uid = $2`, [balanceChange, uid]);
//       console.log('Wallet updated. Balance change:', balanceChange);
//     } else {
//       console.log('No wallet update needed');
//     }

//     await db.query('COMMIT');

//     // respond with updated balance
//     const { rows: updatedRows } = await db.query(`SELECT inr FROM credits WHERE uid = $1`, [uid]);
//     const newBalance = Number(updatedRows[0].inr);

//     console.log('Transaction completed successfully');
//     console.log('Old balance:', currentInr);
//     console.log('New balance:', newBalance);
//     console.log('Actual balance delta:', newBalance - currentInr);

//     return res.json({
//       success: true,
//       exposure: {
//         [match_id]: { match_title, teams: newExposures }
//       },
//       balanceDelta: newBalance - currentInr
//     });

//   } catch (err) {
//     await db.query('ROLLBACK');
//     console.error('PLACE BET ERROR:', err.message);
//     return res.status(400).json({ success:false, error:err.message });
//   }
// };

exports.getUserExposures = async (req,res) => {
  const { user_id } = req.params;
  try {
    const { rows:u } = await db.query(
      `SELECT id FROM users WHERE id=$1`, [user_id]
    );
    if (!u.length) return res.status(404).json({ success:false, error:'User not found' });
    const uid = u[0].id;

    const { rows } = await db.query(`
      SELECT ue.match_id, ue.team_name, ue.exposure_amount,
             (
               SELECT sb.match_title
                 FROM sports_bets sb
                WHERE sb.match_id=ue.match_id
                LIMIT 1
             ) AS match_title
        FROM user_exposures ue
       WHERE ue.user_id=$1
    `, [uid]);

    const out = {};
    for (const r of rows) {
      out[r.match_id] = out[r.match_id]||{match_title:r.match_title,teams:{}};
      out[r.match_id].teams[r.team_name] = +r.exposure_amount;
    }
    return res.json({ success:true, exposures: out });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success:false, error:'Could not fetch exposures' });
  }
};

// GET /sportsbetting/open/:user_id/:match_id



exports.getOpenBets = async (req,res) => {
  const { user_id, match_id } = req.params;
  try {
    const { rows:u } = await db.query(`SELECT id FROM users WHERE uuid=$1`, [user_id]);
    if (!u.length) return res.status(404).json({ success:false, error:'User not found' });
    const uid = u[0].id;

   const { rows: bets } = await db.query(
  `SELECT
     id,
     user_id,
     game_type,
     match_title,
     team_one,
     team_two,
     selection_name,
     category,
     bet_type,
     odds,
     stake_amount,
     original_currency,
     original_amount,
     usd_amount,
     liability,
     match_start_time,
     match_end_time,
     created_at,
     updated_at,
     match_id,
     exposure_after_bet,
     status
   FROM sports_bets
   WHERE user_id    = $1
     AND match_id   = $2
     AND status     = 'open'`,
  [uid, match_id]
);


    return res.json({ success:true, bets });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success:false, error:'Could not fetch open bets' });
  }
};


exports.getWalletBalance = async (req, res) => {
  const { uuid } = req.params;
  try {
    const { rows: uRows } = await db.query(`SELECT id FROM users WHERE id = $1 LIMIT 1`, [uuid]);
    if (!uRows.length) return res.status(404).json({ success: false, error: 'User not found' });

    const uid = uRows[0].id;
    const { rows: cRows } = await db.query(`SELECT inr FROM credits WHERE uid = $1 LIMIT 1`, [uid]);
    if (!cRows.length) return res.status(404).json({ success: false, error: 'Wallet not found' });

    return res.json({ success: true, balance: +cRows[0].inr });
  } catch (e) {
    console.error('getWalletBalance error:', e);
    res.status(500).json({ success: false, error: 'Server error' });
  }
};

exports.settleBets = async () => {
  try {
    // Fetch matches with declared results that haven't been settled
    const { rows: matches } = await db.query(`
      SELECT id, result, team_one, team_two
      FROM matches
      WHERE result IS NOT NULL AND result_declared_at IS NOT NULL
    `);

    for (const match of matches){
      const { id: match_id, result, team_one, team_two } = match;

      // Fetch all open bets for this match
      const { rows: bets } = await db.query(`
        SELECT id, user_id, game_type, bet_type, odds, stake_amount, selection_name, team_one, team_two, liability
        FROM sports_bets
        WHERE match_id = $1 AND status = 'open'
      `, [match_id]);

      for (const bet of bets) {
        await db.query('BEGIN');
        try {
          const { user_id, game_type, bet_type, odds, stake_amount, selection_name, liability } = bet;
          let payout = 0;

          if (game_type === 'MO') {
            if (bet_type === 'back' && selection_name === result) {
              payout = stake_amount * odds; // Win: stake * odds
            } else if (bet_type === 'lay' && selection_name !== result) {
              payout = stake_amount; // Win: return stake
            } else {
              payout = 0; // Loss
            }
          } else if (game_type === 'BM') {
            if (bet_type === 'back' && selection_name === result) {
              payout = stake_amount * (odds - 1); // Win: profit only
            } else if (bet_type === 'lay' && selection_name !== result) {
              payout = stake_amount; // Win: return stake
            } else {
              payout = 0; // Loss
            }
          } else if (game_type === 'FAN') {
            if (bet_type === 'back' && selection_name === result) {
              payout = stake_amount * odds / 100; // Win: stake * odds/100
            } else if (bet_type === 'lay' && selection_name !== result) {
              payout = stake_amount; // Win: return stake
            } else {
              payout = 0; // Loss
            }
          }

          // Update user balance
          if (payout > 0) {
            await db.query(`UPDATE credits SET inr = inr + $1 WHERE uid = $2`, [payout, user_id]);
            await fetch(`https://apisky.codefactory.games/users/balance/${user_id}`, {
              method: 'PUT',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ type: 'deposit', amount: payout })
            }).catch(err => console.error('Mongo sync failed:', err));
          }

          // Mark bet as settled
          await db.query(`UPDATE sports_bets SET status = 'settled', updated_at = NOW() WHERE id = $1`, [bet.id]);

          // Clear exposures for this user and match
          await db.query(`
            DELETE FROM user_exposures
            WHERE user_id = $1 AND match_id = $2
          `, [user_id, match_id]);

          await db.query('COMMIT');
        } catch (err) {
          await db.query('ROLLBACK');
          console.error(`Failed to settle bet ${bet.id}:`, err.message);
        }
      }
      
      // Update match to mark as settled
      await db.query(`UPDATE matches SET updated_at = NOW() WHERE id = $1`, [match_id]);
    }
  } catch (err) {
    console.error('settleBets error:', err);
  }
};
