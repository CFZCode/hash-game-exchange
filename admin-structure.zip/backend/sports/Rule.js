const _ = require('lodash');
const axios = require('axios');
const Queue = require('../General/Queue');
const UserRule = require('../Users/Rule');
const H = require('../General/Helper');
const config = require('../config')

const TOKEN = config.SPORT_API;

//Decelare Rule Object
const Rule = {};

/*
 * Sport Event
 */
Rule.SportEvent = function(game, callback) {

    let sportId;

    switch(game){
        case 'soccer':
            sportId = 1;
        break;
        case 'ice-hockey':
            sportId = 17;
        break;
        case 'american-football':
            sportId = 12;
        break;
        case 'basketball':
            sportId = 18;
        break;
        case 'volleyball':
            sportId = 91;
        break;
    }
    axios({  headers:{
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods":"*"
  },
        // url: `http://api.b365api.com/v3/events/inplay?&token=${TOKEN}&sport_id=${sportId}`,
        url: `http://localhost/inplay_event.json`,
    })
    .then(function(req){
        let response = req.data;
        callback(response)
    })
}

//Export Rule Module
module.exports = Rule;