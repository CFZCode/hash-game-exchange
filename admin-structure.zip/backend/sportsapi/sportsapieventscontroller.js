const axios = require('axios');
const db = require('../General/Model');

const API_KEY = process.env.SCORESWIFT_KEY || 'REMOVED_SECRET';

/* ─────────────────────────────────────────────
   Validate Series ID
───────────────────────────────────────────── */
const validateSeriesId = async (seriesId) => {
  try {
    const seriesQuery = await db.query(
      `SELECT 
         id,
         game_id,
         game_name,
         enabled,
         created_at,
         updated_at
       FROM sports_config
       WHERE game_id = $1
         AND enabled = true`,
      [seriesId]
    );

    return seriesQuery.rows.length > 0;
  } catch (error) {
    console.error('Series ID validation error:', error);
    throw error;
  }
};

/* ─────────────────────────────────────────────
   GET EVENT LIST BY SERIES ID
───────────────────────────────────────────── */
const getEventListBySeriesId = async (req, res) => {
  try {
    const { sid: seriesId } = req.query;

    if (!seriesId) {
      return res.status(400).json({ error: 'Series ID is required' });
    }

    const isValid = await validateSeriesId(seriesId);
    if (!isValid) {
      console.warn(`Series ID ${seriesId} is not valid or enabled`);
      return res.status(403).json({
        error: 'Invalid or disabled series ID',
        id: seriesId
      });
    }

    const apiResponse = await axios.get(
      `http://46.202.164.63:6565/api/result/event-list?sid=${seriesId}&key=${API_KEY}`,
      {
        headers: {
          'X-ScoreSwift-Key': API_KEY
        }
      }
    );

    console.log('Fetched Events:', apiResponse.data);
    res.json(apiResponse.data);

  } catch (error) {
    console.error('Error fetching events:', error);

    if (error.response) {
      console.error('Error Response Data:', error.response.data);
      console.error('Error Response Status:', error.response.status);
      return res.status(error.response.status).json(error.response.data);
    }

    res.status(500).json({
      error: 'Internal server error',
      details: error.message
    });
  }
};

/* ─────────────────────────────────────────────
   GET EVENT DETAILS BY EVENT ID
───────────────────────────────────────────── */
const getEventDetailsByEventId = async (req, res) => {
  try {
    const { eventid: eventId } = req.query;

    if (!eventId) {
      return res.status(400).json({ error: 'Event ID is required' });
    }

    const apiResponse = await axios.get(
      `http://46.202.164.63:6565/api/result/event-result?eventid=${eventId}&key=${API_KEY}`,
      {
        headers: {
          'X-ScoreSwift-Key': API_KEY
        }
      }
    );

    console.log('Fetched Event Details:', apiResponse.data);
    res.json(apiResponse.data);

  } catch (error) {
    console.error('Error fetching event details:', error);

    if (error.response) {
      console.error('Error Response Data:', error.response.data);
      console.error('Error Response Status:', error.response.status);
      return res.status(error.response.status).json(error.response.data);
    }

    res.status(500).json({
      error: 'Internal server error',
      details: error.message
    });
  }
};

module.exports = {
  getEventListBySeriesId,
  getEventDetailsByEventId
};
