const axios = require('axios');
const { filterEnabledGames } = require('./gamefilter');
const db = require('../General/Model');

console.log('Loading sportsapiinplaycontroller...');

const API_KEY = process.env.SCORESWIFT_KEY || 'REMOVED_SECRET';
const BASE_URL = 'http://46.202.164.63:6565/api';

/* ─────────────────────────────────────────────
   INPLAY DATA
───────────────────────────────────────────── */
const getInplayData = async (req, res) => {
  try {
    console.log('Inplay Data Request Received:');
    console.log('Request Body:', req.body);

    const response = await axios.get(
      `${BASE_URL}/inplay?key=${API_KEY}`,
      {
        headers: {
          'X-ScoreSwift-Key': API_KEY
        }
      }
    );

    console.log('API Response:');
    console.log('Total Items:', response.data.length);
    console.log('First Few Items:', response.data.slice(0, 3));

    // If a specific gameId is provided
    if (req.body.gameId) {
      console.log('Filtering for specific gameId:', req.body.gameId);

      const filteredData = response.data.filter(
        item => item.id.toString() === req.body.gameId.toString()
      );

      if (filteredData.length === 0) {
        return res.status(404).json({
          error: 'No data found for the specified game',
          requestedGameId: req.body.gameId
        });
      }

      return res.json(filteredData[0]);
    }

    const filteredGames = await filterEnabledGames(response.data);
    res.json(filteredGames);

  } catch (error) {
    console.error('Inplay data fetch error:', error);

    if (error.response) {
      console.error('Error Response Data:', error.response.data);
      console.error('Error Response Status:', error.response.status);
    }

    res.status(500).json({
      error: 'Error fetching inplay data',
      details: error.message
    });
  }
};

/* ─────────────────────────────────────────────
   ALL ENABLED GAMES
───────────────────────────────────────────── */
const getAllEnabledGames = async (req, res) => {
  try {
    const response = await axios.get(
      `${BASE_URL}/inplay?key=${API_KEY}`,
      {
        headers: {
          'X-ScoreSwift-Key': API_KEY
        }
      }
    );

    const filteredGames = await filterEnabledGames(response.data);
    res.json(filteredGames);

  } catch (error) {
    console.error('All games fetch error:', error);
    res.status(500).json({
      error: 'Error fetching games'
    });
  }
};

/* ─────────────────────────────────────────────
   INPLAY BY GAME ID
───────────────────────────────────────────── */
const getInPlayByGameId = async (req, res) => {
  try {
    const { gameId } = req.params;

    if (!gameId) {
      return res.status(400).json({
        error: 'Game ID parameter is required'
      });
    }

    const gameConfigQuery = await db.query(
      `SELECT id, game_id, game_name, enabled, created_at, updated_at
       FROM sports_config
       WHERE game_id = $1 AND enabled = true`,
      [gameId]
    );

    if (gameConfigQuery.rows.length === 0) {
      return res.status(404).json({
        error: 'Game not found or not enabled',
        gameId
      });
    }

    const response = await axios.get(
      `${BASE_URL}/inplay?key=${API_KEY}`,
      {
        headers: {
          'X-ScoreSwift-Key': API_KEY
        }
      }
    );

    const filteredGames = response.data.filter(
      game => game.id.toString() === gameId.toString()
    );

    res.json({
      gameConfig: {
        id: gameConfigQuery.rows[0].id,
        gameId: gameConfigQuery.rows[0].game_id,
        gameName: gameConfigQuery.rows[0].game_name,
        enabled: gameConfigQuery.rows[0].enabled
      },
      games: filteredGames,
      totalGames: filteredGames.length
    });

  } catch (error) {
    console.error('Game ID fetch error:', error);
    res.status(500).json({
      error: 'Error fetching games for game ID',
      gameId: req.params.gameId
    });
  }
};

/* ─────────────────────────────────────────────
   HOME + INPLAY MARKETS
───────────────────────────────────────────── */
const getAllSportsdata = async (req, res) => {
  try {
    const homeRes = await axios.get(
      `${BASE_URL}/home?key=${API_KEY}`,
      {
        headers: {
          'X-ScoreSwift-Key': API_KEY
        }
      }
    );

    const inplayRes = await axios.get(
      `${BASE_URL}/inplay?key=${API_KEY}`,
      {
        headers: {
          'X-ScoreSwift-Key': API_KEY
        }
      }
    );

    const homeGames = await filterEnabledGames(homeRes.data);
    const inplayGames = await filterEnabledGames(inplayRes.data);

    const maxMarkets = 5;

    const flattenMarkets = (games) =>
      games.flatMap(sport =>
        (sport.markets || []).map(market => ({
          ...market,
          categoryId: sport.id,
          categoryName: sport.name
        }))
      );

    const mergedMarkets = [
      ...flattenMarkets(inplayGames).slice(0, maxMarkets),
      ...flattenMarkets(homeGames).slice(0, maxMarkets)
    ];

    res.json(mergedMarkets);

  } catch (error) {
    console.error(error);
    res.status(500).json({
      error: 'Error fetching matches'
    });
  }
};

/* ───────────────────────────────────────────── */
module.exports = {
  getInplayData,
  getAllEnabledGames,
  getInPlayByGameId,
  getAllSportsdata
};
