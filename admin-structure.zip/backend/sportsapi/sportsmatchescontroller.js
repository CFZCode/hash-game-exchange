const axios = require('axios');
const db = require('../General/Model');

const API_KEY = process.env.SCORESWIFT_KEY || 'REMOVED_SECRET';

/* ─────────────────────────────────────────────
   GET EVENTS BY SPORTS ID
───────────────────────────────────────────── */
const getEventsBySportsID = async (req, res) => {
  try {
    console.log('Requested Sports ID:', req.query.id);

    if (!req.query.id) {
      return res.status(400).json({
        error: 'Sports ID is required'
      });
    }

    // Check if the requested sports is enabled
    const enabledSportsQuery = await db.query(
      `SELECT
         id,
         game_id,
         game_name,
         enabled,
         created_at,
         updated_at
       FROM sports_config
       WHERE game_id = $1
         AND enabled = true`,
      [req.query.id]
    );

    if (enabledSportsQuery.rows.length === 0) {
      console.warn(`Sports ID ${req.query.id} is not enabled`);
      return res.status(403).json({
        error: 'Game not enabled',
        id: req.query.id
      });
    }

    const response = await axios.get(
      `http://46.202.164.63:6565/api/getEventsBySportsID?id=${req.query.id}&key=${API_KEY}`,
      {
        headers: {
          'X-ScoreSwift-Key': API_KEY
        }
      }
    );

    console.log('Fetched Events:', response.data);
    res.json(response.data);

  } catch (error) {
    console.error('Events by Sports ID fetch error:', error);

    if (error.response) {
      console.error('Error Response Data:', error.response.data);
      console.error('Error Response Status:', error.response.status);
      return res.status(error.response.status).json(error.response.data);
    }

    res.status(500).json({
      error: 'Error fetching events by sports ID',
      details: error.message
    });
  }
};

/* ─────────────────────────────────────────────
   VALIDATE SPORTS CONFIG
───────────────────────────────────────────── */
const validateSportsConfig = async (sportId) => {
  try {
    const enabledSportsQuery = await db.query(
      `SELECT
         id,
         game_id,
         game_name,
         enabled,
         created_at,
         updated_at
       FROM sports_config
       WHERE game_id = $1
         AND enabled = true`,
      [sportId]
    );

    return enabledSportsQuery.rows.length > 0;
  } catch (error) {
    console.error('Sports config validation error:', error);
    throw error;
  }
};

/* ─────────────────────────────────────────────
   GET EVENTS BY SERIES + SPORTS ID
───────────────────────────────────────────── */
const getEventsBySeriesAndSportsID = async (req, res) => {
  try {
    const { sid: seriesId, sportid: sportId } = req.query;

    if (!seriesId || !sportId) {
      return res.status(400).json({
        error: 'Series ID and Sports ID are required'
      });
    }

    const isEnabled = await validateSportsConfig(sportId);
    if (!isEnabled) {
      console.warn(`Sports ID ${sportId} is not enabled`);
      return res.status(403).json({
        error: 'Game not enabled',
        id: sportId
      });
    }

    const response = await axios.get(
      `http://46.202.164.63:6565/api/getEvents?sid=${seriesId}&sportid=${sportId}&key=${API_KEY}`,
      {
        headers: {
          'X-ScoreSwift-Key': API_KEY
        }
      }
    );

    console.log('Fetched Events by Series and Sports ID:', response.data);
    res.json(response.data);

  } catch (error) {
    console.error('Events by Series and Sports ID fetch error:', error);

    if (error.response) {
      console.error('Error Response Data:', error.response.data);
      console.error('Error Response Status:', error.response.status);
      return res.status(error.response.status).json(error.response.data);
    }

    res.status(500).json({
      error: 'Error fetching events by series and sports ID',
      details: error.message
    });
  }
};

module.exports = {
  getEventsBySportsID,
  getEventsBySeriesAndSportsID
};
