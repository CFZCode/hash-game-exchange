// ==================== FANCY CONTROL CONTROLLER ====================
// sportsapi/fancyControlController.js

const db = require('../General/Model');

// 1. Get all fancy controls (optional - for admin panel listing)
const getAllFancyControls = async (req, res) => {
  try {
    const query = `
      SELECT
        event_id,
        event_name,
        market_id,
        market_name,
        show_fancy,
        created_at
      FROM admin_fancy_control
      ORDER BY created_at DESC
    `;

    const result = await db.query(query);

    console.log('Fancy Controls:', result.rows);

    res.json({
      success: true,
      data: result.rows
    });
  } catch (error) {
    console.error('Fancy controls fetch error:', error);
    res.status(500).json({
      error: 'Error fetching fancy controls',
      details: error.message
    });
  }
};

// 2. Get fancy controls for a specific event
const getFancyControlsByEvent = async (req, res) => {
  try {
    const { eventId } = req.params;

    if (!eventId) {
      return res.status(400).json({ error: 'Event ID is required' });
    }

    const query = `
      SELECT
        event_id,
        event_name,
        market_id,
        market_name,
        show_fancy,
        created_at
      FROM admin_fancy_control
      WHERE event_id = $1
      ORDER BY created_at DESC
    `;

    const result = await db.query(query, [eventId]);

    res.json({
      success: true,
      data: result.rows
    });
  } catch (error) {
    console.error('Fancy controls fetch error:', error);
    res.status(500).json({
      error: 'Error fetching fancy controls',
      details: error.message
    });
  }
};

// 3. Update fancy status (Active/Inactive) - UPSERT operation
const updateFancyStatus = async (req, res) => {
  try {
    const { eventId, eventName, marketId, marketName, showFancy } = req.body;

    // Validate required fields
    if (!marketId) {
      return res.status(400).json({ error: 'Market ID is required' });
    }

    if (typeof showFancy !== 'boolean') {
      return res.status(400).json({ error: 'showFancy must be a boolean value' });
    }

    // Convert IDs to strings to handle decimal values like "1.251415586"
    const marketIdStr = String(marketId).trim();
    const eventIdStr = String(eventId).trim();

    console.log('Updating fancy status:', {
      eventId: eventIdStr,
      marketId: marketIdStr,
      showFancy
    });

    // Upsert query (INSERT or UPDATE if market_id exists)
    const query = `
      INSERT INTO admin_fancy_control
        (event_id, event_name, market_id, market_name, show_fancy, created_at)
      VALUES ($1, $2, $3, $4, $5, NOW())
      ON CONFLICT (market_id)
      DO UPDATE SET
        event_id = EXCLUDED.event_id,
        event_name = EXCLUDED.event_name,
        market_name = EXCLUDED.market_name,
        show_fancy = EXCLUDED.show_fancy,
        created_at = NOW()
      RETURNING *;
    `;

    const values = [eventIdStr, eventName, marketIdStr, marketName, showFancy];
    const result = await db.query(query, values);

    console.log('Fancy status updated:', result.rows[0]);

    res.json({
      success: true,
      message: 'Fancy status updated successfully',
      data: result.rows[0]
    });
  } catch (error) {
    console.error('Update fancy status error:', error);
    res.status(500).json({
      error: 'Error updating fancy status',
      details: error.message
    });
  }
};

// const updateFancyStatus = async (req, res) => {
//   try {
//     const { eventId, eventName, marketId, marketName, showFancy } = req.body;

//     // Validate required fields
//     if (!marketId) {
//       return res.status(400).json({ error: 'Market ID is required' });
//     }

//     if (typeof showFancy !== 'boolean') {
//       return res.status(400).json({ error: 'showFancy must be a boolean value' });
//     }

//     // Upsert query (INSERT or UPDATE if market_id exists)
//     const query = `
//       INSERT INTO admin_fancy_control
//         (event_id, event_name, market_id, market_name, show_fancy, created_at)
//       VALUES ($1, $2, $3, $4, $5, NOW())
//       ON CONFLICT (market_id)
//       DO UPDATE SET
//         event_id = EXCLUDED.event_id,
//         event_name = EXCLUDED.event_name,
//         market_name = EXCLUDED.market_name,
//         show_fancy = EXCLUDED.show_fancy,
//         created_at = NOW()
//       RETURNING *;
//     `;

//     const values = [eventId, eventName, marketId, marketName, showFancy];
//     const result = await db.query(query, values);

//     console.log('Fancy status updated:', result.rows[0]);

//     res.json({
//       success: true,
//       message: 'Fancy status updated successfully',
//       data: result.rows[0]
//     });
//   } catch (error) {
//     console.error('Update fancy status error:', error);
//     res.status(500).json({
//       error: 'Error updating fancy status',
//       details: error.message
//     });
//   }
// };

// 4. Bulk update fancy status
const bulkUpdateFancyStatus = async (req, res) => {
  try {
    const { updates } = req.body;

    if (!Array.isArray(updates) || updates.length === 0) {
      return res.status(400).json({ error: 'Updates array is required' });
    }

    // Validate each update has required fields
    for (const update of updates) {
      if (!update.marketId || typeof update.showFancy !== 'boolean') {
        return res.status(400).json({
          error: 'Each update must have marketId and showFancy (boolean)'
        });
      }
    }

    // Begin transaction
    await db.query('BEGIN');

    const results = [];

    for (const update of updates) {
      const query = `
        INSERT INTO admin_fancy_control
          (event_id, event_name, market_id, market_name, show_fancy, created_at)
        VALUES ($1, $2, $3, $4, $5, NOW())
        ON CONFLICT (market_id)
        DO UPDATE SET
          event_id = EXCLUDED.event_id,
          event_name = EXCLUDED.event_name,
          market_name = EXCLUDED.market_name,
          show_fancy = EXCLUDED.show_fancy,
          created_at = NOW()
        RETURNING *;
      `;

      const values = [
        update.eventId || null,
        update.eventName || null,
        update.marketId,
        update.marketName || null,
        update.showFancy
      ];

      const result = await db.query(query, values);
      results.push(result.rows[0]);
    }

    // Commit transaction
    await db.query('COMMIT');

    console.log(`Bulk updated ${results.length} fancy controls`);

    res.json({
      success: true,
      message: `Updated ${results.length} fancy controls`,
      data: results
    });
  } catch (error) {
    // Rollback on error
    await db.query('ROLLBACK');
    console.error('Bulk update fancy status error:', error);
    res.status(500).json({
      error: 'Error bulk updating fancy status',
      details: error.message
    });
  }
};

// 5. Delete fancy control
const deleteFancyControl = async (req, res) => {
  try {
    const { marketId } = req.params;

    if (!marketId) {
      return res.status(400).json({ error: 'Market ID is required' });
    }

    const query = 'DELETE FROM admin_fancy_control WHERE market_id = $1 RETURNING *';
    const result = await db.query(query, [marketId]);

    if (result.rowCount === 0) {
      return res.status(404).json({ error: 'Fancy control not found' });
    }

    res.json({
      success: true,
      message: 'Fancy control deleted successfully',
      data: result.rows[0]
    });
  } catch (error) {
    console.error('Delete fancy control error:', error);
    res.status(500).json({
      error: 'Error deleting fancy control',
      details: error.message
    });
  }
};

// ==================== HELPER FUNCTION FOR FILTERING FANCY DATA ====================
// This is used in the getBookmakerFancy controller

const getDeactivatedMarketIds = async (marketIds) => {
  try {
    if (!marketIds || marketIds.length === 0) {
      return new Set();
    }

    const query = `
      SELECT market_id
      FROM admin_fancy_control
      WHERE market_id = ANY($1::bigint[])
        AND show_fancy = false
    `;

    const result = await db.query(query, [marketIds]);

    return new Set(result.rows.map(row => String(row.market_id)));
  } catch (error) {
    console.error('Error fetching deactivated market IDs:', error);
    throw error;
  }
};

module.exports = {
  getAllFancyControls,
  getFancyControlsByEvent,
  updateFancyStatus,
  bulkUpdateFancyStatus,
  deleteFancyControl,
  getDeactivatedMarketIds
};
