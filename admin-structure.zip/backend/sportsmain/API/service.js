const { getCommonData } = require('../../General/Model/RedisMiddleware')
const axios = require('axios')
const pg = require('../../General/Model')

module.exports.getAllSportsData = async (sid) => {
    let key = "alleventsData:" + sid
    const data = await getCommonData(key)
    // console.log("data", data);
    return data;
}


module.exports.getSportsDataById = async (gmid, sid) => {
    const key = `oddsData:${gmid}`;
    const data = await getCommonData(key)
    return { success: true, data: data };
}


module.exports.isBettingAllowed = async (userId) => {
    try {
        // 1. Check User first
        const userRes = await pg.query(
            `SELECT user_id, bet_locked, parent_staff_id, parent_owner_id
             FROM users
             WHERE user_id = $1
             LIMIT 1`,
            [userId]
        );

        const user = userRes.rows[0];

        if (!user) {
            console.error(`BetLock: User ${userId} not found`);
            return false; // Fail safe
        }

        if (user.bet_locked) {
            console.log(`BetLock: User ${userId} is directly locked.`);
            return false;
        }

        // If directly under owner
        if (user.parent_owner_id) {
            return true;
        }

        // 2. Check Staff Hierarchy
        let currentStaffId = user.parent_staff_id;

        while (currentStaffId) {
            const staffRes = await pg.query(
                `SELECT staff_id, bet_locked, parent_id, parent_owner_id
                 FROM staff
                 WHERE staff_id = $1
                 LIMIT 1`,
                [currentStaffId]
            );

            const staff = staffRes.rows[0];

            if (!staff) {
                // Broken hierarchy reference, allow by default (same as your logic)
                break;
            }

            if (staff.bet_locked) {
                console.log(`BetLock: User ${userId} blocked by Staff ${currentStaffId}`);
                return false;
            }

            // Reached top (owner)
            if (staff.parent_owner_id) {
                return true;
            }

            // Move up the chain
            currentStaffId = staff.parent_id;
        }

        return true;
    } catch (err) {
        console.error('BetLock Error:', err);
        return false; // Fail safe for betting systems
    }
};


module.exports.checkUserBetLock = async (user_id, game_type, event_id = null, transaction = null) => {
    try {
        if (!user_id || !game_type) {
            return {
                allowed: false,
                message: "Missing required parameters: user_id or game_type.",
            };
        }

        // Use transaction client if provided, else default pg pool
        const db = transaction || pg;

        // 1. Check Global Lock (betlock table)
        const betLockRes = await db.query(
            `SELECT "MatchOdds", "OtherMarkets"
       FROM betlock
       WHERE user_id = $1
       LIMIT 1`,
            [user_id]
        );

        const betLock = betLockRes.rows[0];

        if (betLock) {
            const gameType = game_type.trim().toUpperCase();

            // 🔒 If Match Odds market
            if (gameType === "MO") {
                if (betLock.MatchOdds === true) {
                    return {
                        allowed: false,
                        message: "Bet not allowed, contact admin (MatchOdds locked).",
                    };
                }
            }
            // 🔒 Any other market type
            else {
                if (betLock.OtherMarkets === true) {
                    return {
                        allowed: false,
                        message: "Bet not allowed, contact admin (OtherMarkets locked).",
                    };
                }
            }
        }

        // 2. Check Match-Specific Lock (user_match_locks table)
        if (event_id) {
            const matchLockRes = await db.query(
                `SELECT 1
         FROM user_match_locks
         WHERE user_id = $1
           AND event_id = $2
           AND is_locked = true
         LIMIT 1`,
                [user_id, String(event_id)]
            );

            if (matchLockRes.rows.length > 0) {
                return {
                    allowed: false,
                    message: "Bet not allowed, this match is locked for you.",
                };
            }
        }

        // ✅ If no restrictions
        return { allowed: true };

    } catch (error) {
        console.error("Error checking user bet lock:", error);
        return {
            allowed: false,
            message: "Internal server error while checking bet lock.",
        };
    }
};

// Helper to get all ancestor staff IDs (upline)
const getAllAncestorStaffIds = async (userId, transaction = null) => {
    const db = transaction || pg;
    const ancestors = [];

    // 1. Get user's parent_staff_id
    const userRes = await db.query(
        `SELECT parent_staff_id
     FROM users
     WHERE user_id = $1
     LIMIT 1`,
        [userId]
    );

    const currentUser = userRes.rows[0];

    // Direct under owner or invalid user
    if (!currentUser || !currentUser.parent_staff_id) {
        return [];
    }

    let currentStaffId = currentUser.parent_staff_id;

    // 2. Traverse staff hierarchy (upline)
    while (currentStaffId) {
        ancestors.push(currentStaffId);

        const staffRes = await db.query(
            `SELECT parent_id
       FROM staff
       WHERE staff_id = $1
       LIMIT 1`,
            [currentStaffId]
        );

        const staff = staffRes.rows[0];

        if (!staff || !staff.parent_id) {
            break; // reached top or invalid hierarchy
        }

        currentStaffId = staff.parent_id;
    }

    return ancestors;
};

module.exports.checkPlatformBetLock = async (
    sportsId,
    game_type,
    user_id,
    transaction = null
) => {
    console.log("check platform betlock ===> for ", { sportsId, game_type, user_id });

    try {
        if (!sportsId || !game_type || !user_id) {
            return {
                allowed: false,
                message: "Missing required parameters: sportsId, game_type or user_id."
            };
        }

        // Use transaction client if provided, else default pg
        const db = transaction || pg;

        // 1. Get Upline (Ancestors) + Owner (null)
        const ancestors = await getAllAncestorStaffIds(user_id, transaction);
        const staffIdsToCheck = [null, ...ancestors]; // null = Owner

        // Normalize market key
        let key = game_type.trim();
        if (key === "MO") {
            key = "Match_Odds";
        }

        // 2. Raw query for platform_lock (instead of Sequelize findAll)
        const lockRes = await db.query(
            `
      SELECT staff_id, market_name
      FROM platform_lock
      WHERE game_id = $1
        AND is_locked = true
        AND market_name = ANY($2)
        AND (
          staff_id = ANY($3)
          OR (staff_id IS NULL AND $4 = true)
        )
      LIMIT 1
      `,
            [
                sportsId,
                [key, 'ALL'],                 // market_name OR condition
                ancestors.length ? ancestors : [0], // avoid empty ANY()
                true                          // allow NULL (Owner)
            ]
        );

        const lock = lockRes.rows[0];

        if (lock) {
            const lockType =
                lock.market_name === 'ALL'
                    ? 'ALL markets'
                    : `${key} market`;

            const locker =
                lock.staff_id !== null
                    ? 'upline staff'
                    : 'Owner';

            return {
                allowed: false,
                message: `Bet not allowed, ${lockType} is locked by ${locker}.`
            };
        }

        return { allowed: true };

    } catch (err) {
        console.error("Error checking platform bet lock:", err);
        return {
            allowed: false,
            message: "Internal server error while checking platform lock."
        };
    }
};


module.exports.getMarketNameFromGtype = ({ mname, gtype, nat, section }) => {


    console.log("market name from gtype", { mname, gtype, nat, section })
    if (!mname || !gtype) return null;

    /* =======================
       1️⃣ MATCH / MATCH1
       section se "vs" banta hai
    ======================= */
    if (gtype === "match" || gtype === "match1") {
        let sections = [];

        if (Array.isArray(section)) {
            sections = section;
        } else if (typeof section === "string") {
            try {
                sections = JSON.parse(section);
            } catch (e) {
                sections = [];
            }
        }


        const runnerNames = sections
            .map((s) => s?.nat?.trim())
            .filter(Boolean);

        if (runnerNames.length === 0) return null;

        const marketName =
            runnerNames.length > 1
                ? runnerNames.join(" vs ")
                : runnerNames[0];

        return {
            mname,
            gtype,
            marketName,
        };
    }

    /* =======================
       2️⃣ ALL OTHER TYPES
       nat is single string
       section ignored
    ======================= */
    if (!nat || typeof nat !== "string") return null;

    return {
        mname,
        gtype,
        marketName: nat.trim(),
    };
};
