const service = require('./service')
const pg = require('../../General/Model')
const axios = require('axios')
const ENV = require("../config/env");
const { verifyBetAgainstLiveOdds } = require('../helper/oddsGuard')
const SPORTS_BASE_URL = 'http://159.198.77.241:8100'// 'http://159.198.77.241:8100/'

const getAllSportsData = async (req, res) => {
    try {
        const { sid } = req.body
        if (!sid) return res.status(400).json({ success: false, error: "ID is required to fetch cricket data" })

        let data = await service.getAllSportsData(sid)
        if (!data) return res.status(400).json({ success: false, error: "ID is required to fetch cricket data" })

        data = JSON.parse(data)
        let parsedData = { t1: [], t2: [] }

        if (data && typeof data === "object" && !Array.isArray(data) && Array.isArray(data.t1)) {
            parsedData.t1 = data.t1
            parsedData.t2 = data.t2
        }

        return res.status(200).json({
            list: parsedData,
            message: "list Fetch successfully."
        });
    } catch (error) {
        console.error('Error fetching  all sports data:', error);
        return res.status(500).json({ error: 'Failed to fetch all sports data reports' });
    }
};

const getSportsDataById = async (req, res) => {
    try {
        const { sid, gmid } = req.body
        if (!sid || !gmid) return res.status(400).json({ success: false, error: "sid Or gmid required to fetch cricket data" })

        let list = await service.getSportsDataById(gmid, sid)
        if (!list) return res.status(400).json({ success: false, error: "ID is required to fetch cricket data" })

        list = JSON.parse(list?.data)
        return res.status(200).json({
            success: true,
            data: list
        });
    } catch (error) {
        console.error('Error fetching  all sports data:', error);
        return res.status(500).json({ error: 'Failed to fetch all sports data reports' });
    }
};


function normalizeOdds(odds) {
    if (odds > 100) return Math.floor(((odds / 100) + 1) * 100) / 100;
    if (odds < 100) return Math.floor((1 + (odds / 100)) * 100) / 100;
    return 2.0;
}



//------------------------Live Stream--------------------------
const getLiveStream = async (req, res) => {
    try {
        const { gmid, sid } = req.body
        if (!gmid) return res.status(400).json({ success: false, error: "sid Or gmid required to fetch cricket data" })

        let url = `https://diamond-sports-api-demo-s2.avrkhub.in/sports_stream?id=${gmid}&key=${ENV.SPORTS_API_KEY}`

        let response = await axios.request({
            method: "GET",
            url: url,
            // headers: {
            //     "x-turnkeyxgaming-key": ENV.SPORTS_API_KEY,
            // },
            timeout: 5000
        });



        return res.status(200).json({
            success: true,
            data: response?.data
        });
    } catch (error) {
        console.error('Error fetching  all live stream data:', error);
        return res.status(500).json({ error: 'Failed to fetch Live stream', message: error.message });
    }
}
const getScorecard = async (req, res) => {
    try {
        const { gmid, sid } = req.body
        if (!gmid) return res.status(400).json({ success: false, error: "sid Or gmid required to fetch cricket data" })

        let url = `https://diamond-sports-api-demo-s2.avrkhub.in/scorecard?etid=${sid}&gmid=${gmid}&key=${ENV.SPORTS_API_KEY}`

        let response = await axios.request({
            method: "GET",
            url: url,
            timeout: 5000
        });



        return res.status(200).json({
            success: true,
            data: response?.data
        });
    } catch (error) {
        console.error('Error fetching  all score card data:', error);
        return res.status(500).json({ error: 'Failed to fetch score card', message: error.message });
    }
}



const placeBet = async (req, res) => {
    try {

        await pg.query('BEGIN');

        //  const user_id = req.user.account.id; //set in auth middleware
        //if (!user_id) return res.status(400).json({ success: false, error: "User ID is required" });

        let { game_type, match_id, match_title, selection_name, bet_type, odds, stake_amount, team_one, team_two, category, original_currency,
            original_amount, usd_amount, match_start_time, eventid, fancy_name, count, sid, market_type, unmatched, unmatched_odds, size, runners
            , lay_size, back_size, runner_odds, mname, gtype, nat, section,
            event_name, user_id, market_id, selection_id
        } = req.body;

        console.log("placedata");

        count = runners?.length;


        //=============================================================================================
        // ✅ STEP 2:                 COMMON VALIDATIONS
        //=============================================================================================


        //Temporary block bet place FAN : not accepting bettype/gametype normal
        // if( bet_type.toLowerCase() === "normal" || game_type || game_type.toLowerCase() === "fan") {

        //     return res.status(403).json({ success: false, message: "market Suspended." });
        // }

        // ✅ Sports Bet Lock Check (user + staff upline hierarchy)
        const userLock = await pg.query(
            `SELECT sports_betlocked, parent_staff_id FROM users WHERE id = $1 LIMIT 1`,
            [user_id]
        );
        if (userLock.rowCount === 0) {
            await pg.query('ROLLBACK');
            return res.status(400).json({ success: false, message: "User not found" });
        }
        if (userLock.rows[0].sports_betlocked) {
            await pg.query('ROLLBACK');
            return res.status(403).json({ success: false, message: "Betting is locked for your account." });
        }
        // Check staff upline chain
        let _staffId = userLock.rows[0].parent_staff_id;
        while (_staffId) {
            const staffCheck = await pg.query(
                `SELECT id, sports_betlocked, parent_id FROM staff WHERE id = $1 LIMIT 1`,
                [_staffId]
            );
            if (staffCheck.rowCount === 0) break;
            if (staffCheck.rows[0].sports_betlocked) {
                await pg.query('ROLLBACK');
                return res.status(403).json({ success: false, message: "Betting is locked by your upline." });
            }
            _staffId = staffCheck.rows[0].parent_id;
        }


        console.log('PLACE BET PAYLOAD RECEIVED:', req.body);
        const ip_address = req.headers["x-forwarded-for"]?.split(",")[0] || req?.connection?.remoteAddress || req.ip;
        console.log('IP ADDRESS:', ip_address);


        // ✅ Live odds guard — the client-side check in BetSlip is advisory only.
        // Re-verify against the cached feed (oddsData:<gmid>, refreshed every 2s)
        // that the market is open and the submitted price is still the live one.
        const guard = await verifyBetAgainstLiveOdds({
            gmid: eventid,
            market_id,
            mname,
            gtype,
            selection_sid: selection_id,
            selection_name: selection_name || nat,
            bet_type,
            odds,
            // fancy run line: `size` is only resolved from back_size/lay_size further down
            size: size || (['lay', 'no'].includes(String(bet_type || '').toLowerCase()) ? lay_size : back_size),
            // an unmatched bet is deliberately priced away from the live book
            allowWorseOdds: !!unmatched,
        });

        if (!guard.ok) {
            await pg.query('ROLLBACK');
            console.warn('[betGuard] rejected', {
                user_id, eventid, market_id, selection_name, bet_type, odds,
                code: guard.code, liveOdds: guard.liveOdds,
            });
            return res.status(403).json({ success: false, code: guard.code, message: guard.message });
        }

        console.log('[betGuard] passed', guard.live);

        // ✅ Max odds on "match" markets (admin: Site Config → Sports Bet Limits).
        // Prefer the feed's gtype over the client's so a bet can't be relabelled
        // to dodge the limit. match1 is bookmaker-style pricing and not covered.
        const marketGtype = String(guard.live?.gtype || gtype || '').trim().toLowerCase();
        if (marketGtype === 'match') {
            const { rows: [limits] } = await pg.query(
                `SELECT sports_match_odds_limit_enabled, sports_match_max_odds FROM siteconfig LIMIT 1`
            );
            const maxOdds = Number(limits?.sports_match_max_odds);
            if (limits?.sports_match_odds_limit_enabled && maxOdds > 0 && Number(odds) > maxOdds) {
                await pg.query('ROLLBACK');
                console.warn('[oddsLimit] rejected', { user_id, eventid, market_id, mname, bet_type, odds, maxOdds });
                return res.status(403).json({
                    success: false,
                    code: 'ODDS_LIMIT_EXCEEDED',
                    message: `Bets above ${maxOdds} odds are not allowed on this market.`,
                });
            }
        }


        // // Dynamic Sport ID Lookup
        // let sportsId = null;
        // if (sid) {
        //     // If sid is provided, try to find the game by sport_id
        //     if (sid) {
        //         const result = await pg.query(
        //             `SELECT id FROM platform_games WHERE sport_id = $1 LIMIT 1`, [sid]);

        //         if (result.rows.length > 0) {
        //             sportsId = result.rows[0].id;
        //         }
        //     }
        // }


        // const lockStatus = await service.checkUserBetLock(user_id, game_type, eventid, transaction);
        // if (!lockStatus.allowed) {
        //     return res.status(403).json({
        //         success: false,
        //         message: lockStatus.message,
        //     });
        // }

        // // Fallback or additional check if needed (e.g. using category/game_type)
        // if (!sportsId) {
        //     console.warn(`Could not resolve PlatformGame for sid: ${sid}`);
        // }


        // // ✅ checking platform bet lock status
        // if (sportsId) {
        //     const platformlockStatus = await service.checkPlatformBetLock(sportsId, game_type, user_id, transaction);
        //     if (!platformlockStatus.allowed) {
        //         return res.status(403).json({
        //             success: false,
        //             message: platformlockStatus.message,
        //         });
        //     }
        // }




        //=============================================================================================
        // ✅ STEP 3:                   PLATFORM SPECIFIC VALIDATIONS LORDS
        //=============================================================================================


        //==========================================================================================
        // ✅ STEP 4: Call external API first   [SELECT ONE OPTION ONLY - COMMENT OUT THE OTHER OPTION] 
        // =========================================================================================

        const placedata = service.getMarketNameFromGtype({ mname, gtype, nat, section });

        console.log("placedata", placedata);

        // if (placedata) {
        //     const apiPayload = {
        //         sportsid: sid,
        //         gmid: eventid,
        //         marketName: placedata.marketName,
        //         mname: placedata.mname,
        //         gtype: placedata.gtype,

        //     };

        //     if (gtype == "match" || gtype == "bookmaker" || gtype == "bookmaker2" || gtype == "match1") {
        //         match_title = placedata.marketName;
        //     }


        //     //---------------------------------------------------------------------------------------
        //     // [ PROCEEDING BET PLACEMENT ] :  despite external API failure with warning logs 
        //     //-------------------------------------------------------------------------------------

        //     let apiResponse;
        //     const placedBetsUrl = "http://primarydiamondfeeds.turnkeyxgaming.com:8000/api/v1/post-market";

        //     console.log("External API URL:", placedBetsUrl);
        //     console.log("External API Payload:", apiPayload);

        //     try {
        //         apiResponse = await axios.request({
        //             method: "POST",
        //             url: placedBetsUrl,
        //             headers: {
        //                 "x-turnkeyxgaming-key": "REMOVED_SECRET",
        //             },
        //             data: apiPayload,
        //             timeout: 5000
        //         });

        //         console.log("External API Response:", apiResponse?.data);

        //         if (!apiResponse.data || apiResponse.status !== 200) {
        //             throw new Error("External API rejected the bet");
        //         }

        //     } catch (apiErr) {
        //         console.warn(
        //             "External API Warning (Non-blocking):",
        //             apiErr?.response?.data || apiErr.message
        //         );
        //     }
        // } else {
        //     console.warn("Skipping external API call: placedata is null (Market info missing or format invalid).");
        // }




        //=============================================================================================
        // ✅ STEP 5:                   EXPOSURE CALCULATION & WALLET VALIDATION
        //=============================================================================================

        const stake = Number(stake_amount);
        const oddN = Number(odds);
        let betTypeLower = (bet_type || "").toLowerCase().trim();
        console.log('Bet details:', { stake, oddN, betTypeLower, game_type });
        if (game_type === "BOOKMAKER") {
            game_type = "BM"
        }
        if (game_type === "FANCY") {
            game_type = "FAN"
        }
        console.log('Normalized game_type:', game_type);



        const isYesNo = betTypeLower === 'yes' || betTypeLower === 'no';
        const isFancy = game_type === "FAN" || (game_type === "MO" && isYesNo);
        const isBookmaker = game_type === 'BM';

        // Validation
        if (stake <= 0) throw new Error("Invalid stake");
        if (isFancy) {
            if (!Number.isFinite(oddN) || oddN <= 0) throw new Error("Invalid fancy odds");
            // if (!isYesNo) throw new Error("Fancy bet must be YES or NO");
        } else {
            if (!Number.isFinite(oddN) || oddN <= 1) throw new Error("Invalid odds");
        }

      if (lay_size && back_size) {
         const bt = (bet_type || '').toLowerCase();
         size = (bt === 'lay' || bt === 'no') ? lay_size : back_size;
        }

        // Wallet
        // const wallet = await Wallet.findOne({ where: { user_id }, transaction, lock: transaction.LOCK.UPDATE });
        // if (!wallet) throw new Error("Wallet not found");

        const { rows } = await pg.query(
            `SELECT * FROM credits 
             WHERE uid = $1 
             FOR UPDATE`,
            [user_id]
        );

        const wallet = rows[0];

        if (!wallet) throw new Error("Wallet not found");
        //  const currentInr = Number(wallet.credit);
        const currentInr = Number(wallet.inr);

        console.log('Current wallet balance:', currentInr);

        const exposureGameType = market_type;

        // Exposures
        let oldExposuresRows = await pg.query(
            `SELECT *
            FROM user_exposures
            WHERE user_id = $1
            AND match_id = $2
            AND game_type = $3
            FOR UPDATE
            `,
            [user_id, match_id, exposureGameType]
        );

        oldExposuresRows = oldExposuresRows.rows;


        console.log('OoldExposuresRowsS:>>>>>>>>>>>>>>>');



        const oldExposures = {};
        oldExposuresRows.forEach((r) => (oldExposures[r.team_name] = Number(r.exposure_amount)));
        console.log('OLD EXPOSURES:', oldExposures);

        let newExposures = { ...oldExposures };

        const sel = (selection_name || "").toString();
        const selLower = sel.trim().toLowerCase();
        const isDrawSel = selLower === "the draw" || selLower === "draw";
        const normGameType = isFancy ? "FAN" : game_type === "BM" ? "BM" : "MO";

        const marketsfornonfancy = [
            'Game Winner 1/2',
            'OVER_UNDER_55',
            'OVER_UNDER_45',
            'OVER_UNDER_35',
            'OVER_UNDER_25',
            'OVER_UNDER_15',
            'OVER_UNDER_05',
            'OVER_UNDER_10',

            '2nd Period Winner',
            '1st Period Winner',
            '3rd Period Winner',
            'Both Teams To Score',
            'DRAW_NO_BET',
            'Draw No Bet',

            'HALF_TIME',
            'Match Time Result 70:00',
            'Match Time Result 10:00',
            'Match Time Result 30:00',
            'Match Time Result 20:00',
            'Match Time Result 40:00',
            'Match Time Result 60:00',
            'Match Time Result 50:00',
            'Match Time Result 70:00',
            'Match Time Result 80:00',
            'Match Time Result 90:00',
            'Game Winner 1/1',
            'Game Winner 1/2',
            'Game Winner 1/3',
            'Game Winner 1/4',
            'Game Winner 1/5',
            'Game Winner 1/6',
            'Game Winner 1/7',
            'Game Winner 1/8',
            'Game Winner 1/9',
            'Game Winner 1/10',
            'Game Winner 1/11',
            'Game Winner 1/12',
            'Game Winner 1/13',
            'Game Winner 1/14',
            'Game Winner 1/15',
            'Game Winner 1/16',
            'Game Winner 1/17',
            'Game Winner 1/18',
            'Game Winner 1/19',
            'Game Winner 1/20',
            'Game Winner 2/2',
            'Game Winner 2/3',
            'Game Winner 2/4',
            'Game Winner 2/5',
            'Game Winner 2/6',
            'Game Winner 2/7',
            'Game Winner 2/8',
            'Game Winner 2/9',
            'Game Winner 2/10',
            'Game Winner 2/11',
            'Game Winner 2/12',
            'Game Winner 2/13',
            'Game Winner 2/14',
            'Game Winner 2/15',
            'Game Winner 2/16',
            'Game Winner 2/17',
            'Game Winner 2/18',
            'Game Winner 2/19',
            'Game Winner 2/20',
            'Game Winner 3/1',
            'Game Winner 3/2',
            'Game Winner 3/3',
            'Game Winner 3/4',
            'Game Winner 3/5',
            'Game Winner 3/6',
            'Game Winner 3/7',
            'Game Winner 3/8',
            'Game Winner 3/9',
            'Game Winner 3/10',
            'Game Winner 3/11',
            'Game Winner 3/12',
            'Game Winner 3/13',
            'Game Winner 3/14',
            'Game Winner 3/15',
            'Game Winner 3/16',
            'Game Winner 3/17',
            'Game Winner 3/18',
            'Game Winner 3/19',
            'Game Winner 3/20',
            'Game Winner 4/1',
            'Game Winner 4/2',
            'Game Winner 4/3',
            'Game Winner 4/4',
            'Game Winner 4/5',
            'Game Winner 4/6',
            'Game Winner 4/7',
            'Game Winner 4/8',
            'Game Winner 4/9',
            'Game Winner 4/10',
            'Game Winner 4/11',
            'Game Winner 4/12',
            'Game Winner 4/13',
            'Game Winner 4/14',
            'Game Winner 4/15',
            'Game Winner 4/16',
            'Game Winner 4/17',
            'Game Winner 4/18',
            'Game Winner 4/19',
            'Game Winner 4/20',
            'Game Winner 5/1',
            'Game Winner 5/2',
            'Game Winner 5/3',
            'Game Winner 5/4',
            'Game Winner 5/5',
            'Game Winner 5/6',
            'Game Winner 5/7',
            'Game Winner 5/8',
            'Game Winner 5/9',
            'Game Winner 5/10',
            'Game Winner 5/11',
            'Game Winner 5/12',
            'Game Winner 5/13',
            'Game Winner 5/14',
            'Game Winner 5/15',
            'Game Winner 5/16',
            'Game Winner 5/17',
            'Game Winner 5/18',
            'Game Winner 5/19',
            'Game Winner 5/20',
            'Game Winner 6/1',
            'Game Winner 6/2',
            'Game Winner 6/3',
            'Game Winner 6/4',
            'Game Winner 6/5',
            'Game Winner 6/6',
            'Game Winner 6/7',
            'Game Winner 6/8',
            'Game Winner 6/9',
            'Game Winner 6/10',
            'Game Winner 7/1',
            'Game Winner 7/2',
            'Game Winner 7/3',
            'Game Winner 7/4',
            'Game Winner 7/5',
            'Game Winner 7/6',
            'Game Winner 7/7',
            'Game Winner 2/7',
            'Game Winner 3/7',
            'Game Winner 4/7',
            'Game Winner 5/7',
            'Game Winner 6/7',
            'Game Winner 7/7',
            '1st Set Winner Home/Away',
            '2nd Set Winner Home/Away',
            '3rd Set Winner Home/Away',
            '4th Set Winner Home/Away',
            '5th Set Winner Home/Away',
            '1st Set Winner',
            '2nd Set Winner',
            '3rd Set Winner',
            '4th Set Winner',
            '5th Set Winner',
            '6th Set Winner',
            '1st Half Winner',
            '2nd Half Winner',
            '3rd Half Winner',
            '4th Half Winner',
            '5th Half Winner',
            '6th Half Winner',
            '1st Quarter Winner',
            '2nd Quarter Winner',
            '3rd Quarter Winner',
            '4th Quarter Winner',
            '5th Quarter Winner',
            '6th Quarter Winner',
            '1st Set Race To 1.0',
            '1st Set Race To 2.0',
            '1st Set Race To 3.0',
            '1st Set Race To 4.0',
            '1st Set Race To 5.0',
            '1st Set Race To 6.0',
            '1st Set Race To 7.0',
            '1st Set Race To 8.0',
            '1st Set Race To 9.0',
            '1st Set Race To 10.0',
            '1st Set Race To 11.0',
            '1st Set Race To 12.0',
            '1st Set Race To 13.0',
            '1st Set Race To 14.0',
            '1st Set Race To 15.0',
            '2nd Set Race To 1.0',
            '2nd Set Race To 2.0',
            '2nd Set Race To 3.0',
            '2nd Set Race To 4.0',
            '2nd Set Race To 5.0',
            '2nd Set Race To 6.0',
            '2nd Set Race To 7.0',
            '2nd Set Race To 8.0',
            '2nd Set Race To 9.0',
            '2nd Set Race To 10.0',
            '2nd Set Race To 11.0',
            '2nd Set Race To 12.0',
            '2nd Set Race To 13.0',
            '2nd Set Race To 14.0',
            '2nd Set Race To 15.0',
            '3rd Set Race To 1.0',
            '3rd Set Race To 2.0',
            '3rd Set Race To 3.0',
            '3rd Set Race To 4.0',
            '3rd Set Race To 5.0',
            '3rd Set Race To 6.0',
            '3rd Set Race To 7.0',
            '3rd Set Race To 8.0',
            '3rd Set Race To 9.0',
            '3rd Set Race To 10.0',
            '3rd Set Race To 11.0',
            '3rd Set Race To 12.0',
            '3rd Set Race To 13.0',
            '3rd Set Race To 14.0',
            '3rd Set Race To 15.0',
            '4th Set Race To 1.0',
            '4th Set Race To 2.0',
            '4th Set Race To 3.0',
            '4th Set Race To 4.0',
            '4th Set Race To 5.0',
            '4th Set Race To 6.0',
            '4th Set Race To 7.0',
            '4th Set Race To 8.0',
            '4th Set Race To 9.0',
            '4th Set Race To 10.0',
            '4th Set Race To 11.0',
            '4th Set Race To 12.0',
            '4th Set Race To 13.0',
            '4th Set Race To 14.0',
            '4th Set Race To 15.0',
            'Point Winner 1/1/1',
            'Point Winner 1/1/1',
            'Point Winner 1/1/2',
            'Point Winner 1/1/3',
            'Point Winner 1/1/4',
            'Point Winner 1/1/5',
            'Point Winner 1/1/6',
            'Point Winner 1/1/7',
            'Point Winner 1/1/8',
            'Point Winner 1/1/9',
            'Point Winner 1/1/10',
            'Point Winner 1/1/11',
            'Point Winner 1/1/12',
            'Point Winner 1/1/13',
            'Point Winner 1/1/14',
            'Point Winner 1/1/15',
            'Point Winner 1/1/16',
            'Point Winner 1/1/17',
            'Point Winner 1/1/18',
            'Point Winner 1/1/19',
            'Point Winner 1/1/20',
            'Point Winner 1/2/1',
            'Point Winner 1/2/2',
            'Point Winner 1/2/3',
            'Point Winner 1/2/4',
            'Point Winner 1/2/5',
            'Point Winner 1/2/6',
            'Point Winner 1/2/7',
            'Point Winner 1/2/8',
            'Point Winner 1/2/9',
            'Point Winner 1/2/10',
            'Point Winner 1/2/11',
            'Point Winner 1/2/12',
            'Point Winner 1/2/13',
            'Point Winner 1/2/14',
            'Point Winner 1/2/15',
            'Point Winner 1/2/16',
            'Point Winner 1/2/17',
            'Point Winner 1/2/18',
            'Point Winner 1/2/19',
            'Point Winner 1/2/20',
            'Point Winner 1/3/1',
            'Point Winner 1/3/2',
            'Point Winner 1/3/3',
            'Point Winner 1/3/4',
            'Point Winner 1/3/5',
            'Point Winner 1/3/6',
            'Point Winner 1/3/7',
            'Point Winner 1/3/8',
            'Point Winner 1/3/9',
            'Point Winner 1/3/10',
            'Point Winner 1/3/11',
            'Point Winner 1/3/12',
            'Point Winner 1/3/13',
            'Point Winner 1/3/14',
            'Point Winner 1/3/15',
            'Point Winner 1/3/16',
            'Point Winner 1/3/17',
            'Point Winner 1/3/18',
            'Point Winner 1/3/19',
            'Point Winner 1/3/20',
            'Point Winner 1/4/1',
            'Point Winner 1/4/2',
            'Point Winner 1/4/3',
            'Point Winner 1/4/4',
            'Point Winner 1/4/5',
            'Point Winner 1/4/6',
            'Point Winner 1/4/7',
            'Point Winner 1/4/8',
            'Point Winner 1/4/9',
            'Point Winner 1/5/1',
            'Point Winner 1/5/2',
            'Point Winner 1/5/3',
            'Point Winner 1/5/4',
            'Point Winner 1/5/5',
            'Point Winner 1/5/6',
            'Point Winner 1/5/7',
            'Point Winner 1/5/8',
            'Point Winner 1/5/9',
            'Point Winner 1/6/1',
            'Point Winner 1/6/2',
            'Point Winner 1/6/3',
            'Point Winner 1/6/4',
            'Point Winner 1/6/5',
            'Point Winner 1/6/6',
            'Point Winner 1/6/7',
            'Point Winner 1/6/8',
            'Point Winner 1/6/9',
            'Point Winner 1/7/1',
            'Point Winner 1/7/2',
            'Point Winner 1/7/3',
            'Point Winner 1/7/4',
            'Point Winner 1/7/5',
            'Point Winner 1/7/6',
            'Point Winner 1/7/7',
            'Point Winner 1/7/8',
            'Point Winner 1/7/9',
            'Point Winner 1/8/1',
            'Point Winner 1/8/2',
            'Point Winner 1/8/3',
            'Point Winner 1/8/4',
            'Point Winner 1/8/5',
            'Point Winner 1/8/6',
            'Point Winner 1/8/7',
            'Point Winner 1/8/8',
            'Point Winner 1/8/9',
            'Point Winner 1/9/1',
            'Point Winner 1/9/2',
            'Point Winner 1/9/3',
            'Point Winner 1/9/4',
            'Point Winner 1/9/5',
            'Point Winner 1/9/6',
            'Point Winner 1/9/7',
            'Point Winner 1/9/8',
            'Point Winner 1/9/9',


            'Point Winner 2/1/1',
            'Point Winner 2/1/2',
            'Point Winner 2/1/3',
            'Point Winner 2/1/4',
            'Point Winner 2/1/5',
            'Point Winner 2/1/6',
            'Point Winner 2/1/7',
            'Point Winner 2/1/8',
            'Point Winner 2/1/9',
            'Point Winner 2/2/1',
            'Point Winner 2/2/2',
            'Point Winner 2/2/3',
            'Point Winner 2/2/4',
            'Point Winner 2/2/5',
            'Point Winner 2/2/6',
            'Point Winner 2/2/7',
            'Point Winner 2/2/8',
            'Point Winner 2/2/9',
            'Point Winner 2/3/1',
            'Point Winner 2/3/2',
            'Point Winner 2/3/3',
            'Point Winner 2/3/4',
            'Point Winner 2/3/5',
            'Point Winner 2/3/6',
            'Point Winner 2/3/7',
            'Point Winner 2/3/8',
            'Point Winner 2/3/9',
            'Point Winner 2/4/1',
            'Point Winner 2/4/2',
            'Point Winner 2/4/3',
            'Point Winner 2/4/4',
            'Point Winner 2/4/5',
            'Point Winner 2/4/6',
            'Point Winner 2/4/7',
            'Point Winner 2/4/8',
            'Point Winner 2/4/9',
            'Point Winner 2/5/1',
            'Point Winner 2/5/2',
            'Point Winner 2/5/3',
            'Point Winner 2/5/4',
            'Point Winner 2/5/5',
            'Point Winner 2/5/6',
            'Point Winner 2/5/7',
            'Point Winner 2/5/8',
            'Point Winner 2/5/9',
            'Point Winner 2/6/1',
            'Point Winner 2/6/2',
            'Point Winner 2/6/3',
            'Point Winner 2/6/4',
            'Point Winner 2/6/5',
            'Point Winner 2/6/6',
            'Point Winner 2/6/7',
            'Point Winner 2/6/8',
            'Point Winner 2/6/9',
            'Point Winner 2/7/1',
            'Point Winner 2/7/2',
            'Point Winner 2/7/3',
            'Point Winner 2/7/4',
            'Point Winner 2/7/5',
            'Point Winner 2/7/6',
            'Point Winner 2/7/7',
            'Point Winner 2/7/8',
            'Point Winner 2/7/9',
            'Point Winner 2/8/1',
            'Point Winner 2/8/2',
            'Point Winner 2/8/3',
            'Point Winner 2/8/4',
            'Point Winner 2/8/5',
            'Point Winner 2/8/6',
            'Point Winner 2/8/7',
            'Point Winner 2/8/8',
            'Point Winner 2/8/9',
            'Point Winner 2/9/1',
            'Point Winner 2/9/2',
            'Point Winner 2/9/3',
            'Point Winner 2/9/4',
            'Point Winner 2/9/5',
            'Point Winner 2/9/6',
            'Point Winner 2/9/7',
            'Point Winner 2/9/8',
            'Point Winner 2/9/9',

            'Point Winner 3/1/1',
            'Point Winner 3/1/2',
            'Point Winner 3/1/3',
            'Point Winner 3/1/4',
            'Point Winner 3/1/5',
            'Point Winner 3/1/6',
            'Point Winner 3/1/7',
            'Point Winner 3/1/8',
            'Point Winner 3/1/9',
            'Point Winner 3/2/1',
            'Point Winner 3/2/2',
            'Point Winner 3/2/3',
            'Point Winner 3/2/4',
            'Point Winner 3/2/5',
            'Point Winner 3/2/6',
            'Point Winner 3/2/7',
            'Point Winner 3/2/8',
            'Point Winner 3/2/9',
            'Point Winner 3/3/1',
            'Point Winner 3/3/2',
            'Point Winner 3/3/3',
            'Point Winner 3/3/4',
            'Point Winner 3/3/5',
            'Point Winner 3/3/6',
            'Point Winner 3/3/7',
            'Point Winner 3/3/8',
            'Point Winner 3/3/9',
            'Point Winner 3/4/1',
            'Point Winner 3/4/2',
            'Point Winner 3/4/3',
            'Point Winner 3/4/4',
            'Point Winner 3/4/5',
            'Point Winner 3/4/6',
            'Point Winner 3/4/7',
            'Point Winner 3/4/8',
            'Point Winner 3/4/9',
            'Point Winner 3/5/1',
            'Point Winner 3/5/2',
            'Point Winner 3/5/3',
            'Point Winner 3/5/4',
            'Point Winner 3/5/5',
            'Point Winner 3/5/6',
            'Point Winner 3/5/7',
            'Point Winner 3/5/8',
            'Point Winner 3/5/9',
            'Point Winner 3/6/1',
            'Point Winner 3/6/2',
            'Point Winner 3/6/3',
            'Point Winner 3/6/4',
            'Point Winner 3/6/5',
            'Point Winner 3/6/6',
            'Point Winner 3/6/7',
            'Point Winner 3/6/8',
            'Point Winner 3/6/9',
            'Point Winner 3/7/1',
            'Point Winner 3/7/2',
            'Point Winner 3/7/3',
            'Point Winner 3/7/4',
            'Point Winner 3/7/5',
            'Point Winner 3/7/6',
            'Point Winner 3/7/7',
            'Point Winner 3/7/8',
            'Point Winner 3/7/9',
            'Point Winner 3/8/1',
            'Point Winner 3/8/2',
            'Point Winner 3/8/3',
            'Point Winner 3/8/4',
            'Point Winner 3/8/5',
            'Point Winner 3/8/6',
            'Point Winner 3/8/7',
            'Point Winner 3/8/8',
            'Point Winner 3/8/9',
            'Point Winner 3/9/1',
            'Point Winner 3/9/2',
            'Point Winner 3/9/3',
            'Point Winner 3/9/4',
            'Point Winner 3/9/5',
            'Point Winner 3/9/6',
            'Point Winner 3/9/7',
            'Point Winner 3/9/8',
            'Point Winner 3/9/9',

            'Point Winner 4/1/1',
            'Point Winner 4/1/2',
            'Point Winner 4/1/3',
            'Point Winner 4/1/4',
            'Point Winner 4/1/5',
            'Point Winner 4/1/6',
            'Point Winner 4/1/7',
            'Point Winner 4/1/8',
            'Point Winner 4/1/9',
            'Point Winner 4/2/1',
            'Point Winner 4/2/2',
            'Point Winner 4/2/3',
            'Point Winner 4/2/4',
            'Point Winner 4/2/5',
            'Point Winner 4/2/6',
            'Point Winner 4/2/7',
            'Point Winner 4/2/8',
            'Point Winner 4/2/9',
            'Point Winner 4/3/1',
            'Point Winner 4/3/2',
            'Point Winner 4/3/3',
            'Point Winner 4/3/4',
            'Point Winner 4/3/5',
            'Point Winner 4/3/6',
            'Point Winner 4/3/7',
            'Point Winner 4/3/8',
            'Point Winner 4/3/9',
            'Point Winner 4/4/1',
            'Point Winner 4/4/2',
            'Point Winner 4/4/3',
            'Point Winner 4/4/4',
            'Point Winner 4/4/5',
            'Point Winner 4/4/6',
            'Point Winner 4/4/7',
            'Point Winner 4/4/8',
            'Point Winner 4/4/9',
            'Point Winner 4/5/1',
            'Point Winner 4/5/2',
            'Point Winner 4/5/3',
            'Point Winner 4/5/4',
            'Point Winner 4/5/5',
            'Point Winner 4/5/6',
            'Point Winner 4/5/7',
            'Point Winner 4/5/8',
            'Point Winner 4/5/9',
            'Point Winner 4/6/1',
            'Point Winner 4/6/2',
            'Point Winner 4/6/3',
            'Point Winner 4/6/4',
            'Point Winner 4/6/5',
            'Point Winner 4/6/6',
            'Point Winner 4/6/7',
            'Point Winner 4/6/8',
            'Point Winner 4/6/9',
            'Point Winner 4/7/1',
            'Point Winner 4/7/2',
            'Point Winner 4/7/3',
            'Point Winner 4/7/4',
            'Point Winner 4/7/5',
            'Point Winner 4/7/6',
            'Point Winner 4/7/7',
            'Point Winner 4/7/8',
            'Point Winner 4/7/9',
            'Point Winner 4/8/1',
            'Point Winner 4/8/2',
            'Point Winner 4/8/3',
            'Point Winner 4/8/4',
            'Point Winner 4/8/5',
            'Point Winner 4/8/6',
            'Point Winner 4/8/7',
            'Point Winner 4/8/8',
            'Point Winner 4/8/9',
            'Point Winner 4/9/1',
            'Point Winner 4/9/2',
            'Point Winner 4/9/3',
            'Point Winner 4/9/4',
            'Point Winner 4/9/5',
            'Point Winner 4/9/6',
            'Point Winner 4/9/7',
            'Point Winner 4/9/8',
            'Point Winner 4/9/9',


            'Under/Over 5.5',
            'Under/Over 0.5',
            'Under/Over 1.5',
            'Under/Over 2.5',
            'Under/Over 3.5',
            'Under/Over 4.5',
            'Under/Over 6.5',
            // 'BM 1st Set Winner',
            // 'BM 2nd Set Winner',
            // 'BM 3rd Set Winner',
            // 'BM 4th Set Winner',
            // 'BM 5th Set Winner',
            '1st Set Race To 10.0',
            '1st Set Race To 9.0',
            '1st Set Race To 8.0',
            '1st Set Race To 7.0',
            '1st Set Race To 6.0',
            '1st Set Race To 5.0',
            '1st Set Race To 4.0',
            '1st Set Race To 3.0',
            '1st Set Race To 2.0',
            '1st Set Race To 1.0',
            '2nd Set Race To 10.0',
            '2nd Set Race To 9.0',
            '2nd Set Race To 8.0',
            '2nd Set Race To 7.0',
            '2nd Set Race To 6.0',
            '2nd Set Race To 5.0',
            '2nd Set Race To 4.0',
            '2nd Set Race To 3.0',
            '2nd Set Race To 2.0',
            '2nd Set Race To 1.0',
            '3rd Set Race To 10.0',
            '3rd Set Race To 9.0',
            '3rd Set Race To 8.0',
            '3rd Set Race To 7.0',
            '3rd Set Race To 6.0',
            '3rd Set Race To 5.0',
            '3rd Set Race To 4.0',
            '3rd Set Race To 3.0',
            '3rd Set Race To 2.0',
            '3rd Set Race To 1.0',
            '4th Set Race To 10.0',
            '4th Set Race To 9.0',
            '4th Set Race To 8.0',
            '4th Set Race To 7.0',
            '4th Set Race To 6.0',
            '4th Set Race To 5.0',
            '4th Set Race To 4.0',
            '4th Set Race To 3.0',
            '4th Set Race To 2.0',
            '4th Set Race To 1.0',
            '5th Set Race To 4.0',
            '5th Set Race To 3.0',
            '5th Set Race To 2.0',
            '5th Set Race To 1.0',
            'Total Tie Break in the Match 0.5',
            'Total Tie Break in the Match 1.0',
            'Total Tie Break in the Match 1.5',
            'Total Tie Break in the Match 2.0',
            'Total Tie Break in the Match 2.5',
            'Total Tie Break in the Match 3.5',
            'Game To Deuce 1/1',
            'Game To Deuce 1/2',
            'Game To Deuce 1/3',
            'Game To Deuce 1/4',
            'Game To Deuce 1/5',
            'Game To Deuce 1/6',
            'Game To Deuce 1/7',
            'Game To Deuce 1/8',
            'Game To Deuce 1/9',
            'Game To Deuce 1/10',
            'Game To Deuce 1/11',
            'Game To Deuce 1/12',
            'Game To Deuce 1/13',
            'Game To Deuce 1/14',
            'Game To Deuce 1/15',
            'Game To Deuce 1/16',
            'Game To Deuce 1/17',
            'Game To Deuce 1/18',
            'Game To Deuce 1/19',
            'Game To Deuce 1/20',
            'Game To Deuce 2/1',
            'Game To Deuce 2/2',
            'Game To Deuce 2/3',
            'Game To Deuce 2/4',
            'Game To Deuce 2/5',
            'Game To Deuce 2/6',
            'Game To Deuce 2/7',
            'Game To Deuce 2/8',
            'Game To Deuce 2/9',
            'Game To Deuce 2/10',
            'Game To Deuce 2/11',
            'Game To Deuce 2/12',
            'Game To Deuce 2/13',
            'Game To Deuce 2/14',
            'Game To Deuce 2/15',
            'Game To Deuce 2/16',
            'Game To Deuce 2/17',
            'Game To Deuce 2/18',
            'Game To Deuce 2/19',
            'Game To Deuce 2/20',

            'Game To Deuce 3/1',
            'Game To Deuce 3/2',
            'Game To Deuce 3/3',
            'Game To Deuce 3/4',
            'Game To Deuce 3/5',
            'Game To Deuce 3/6',
            'Game To Deuce 3/7',
            'Game To Deuce 3/8',
            'Game To Deuce 3/9',
            'Game To Deuce 3/10',
            'Game To Deuce 3/11',
            'Game To Deuce 3/12',
            'Game To Deuce 3/13',
            'Game To Deuce 3/14',
            'Game To Deuce 3/15',
            'Game To Deuce 3/16',
            'Game To Deuce 3/17',
            'Game To Deuce 3/18',
            'Game To Deuce 3/19',
            'Game To Deuce 3/20',

            'Game To Deuce 4/1',
            'Game To Deuce 4/2',
            'Game To Deuce 4/3',
            'Game To Deuce 4/4',
            'Game To Deuce 4/5',
            'Game To Deuce 4/6',
            'Game To Deuce 4/7',
            'Game To Deuce 4/8',
            'Game To Deuce 4/9',
            'Game To Deuce 4/10',
            'Game To Deuce 4/11',
            'Game To Deuce 4/12',
            'Game To Deuce 4/13',
            'Game To Deuce 4/14',
            'Game To Deuce 4/15',
            'Game To Deuce 4/16',
            'Game To Deuce 4/17',
            'Game To Deuce 4/18',
            'Game To Deuce 4/19',
            'Game To Deuce 4/20',

            'Game To Deuce 5/1',
            'Game To Deuce 5/2',
            'Game To Deuce 5/3',
            'Game To Deuce 5/4',
            'Game To Deuce 5/5',
            'Game To Deuce 5/6',
            'Game To Deuce 5/7',
            'Game To Deuce 5/8',
            'Game To Deuce 5/9',
            'Game To Deuce 5/10',
            'Game To Deuce 5/11',
            'Game To Deuce 5/12',
            'Game To Deuce 5/13',
            'Game To Deuce 5/14',
            'Game To Deuce 5/15',
            'Game To Deuce 5/16',
            'Game To Deuce 5/17',
            'Game To Deuce 5/18',
            'Game To Deuce 5/19',
            'Game To Deuce 5/20',

            'Game To Deuce 6/1',
            'Game To Deuce 6/2',
            'Game To Deuce 6/3',
            'Game To Deuce 6/4',
            'Game To Deuce 6/5',
            'Game To Deuce 6/6',
            'Game To Deuce 6/7',
            'Game To Deuce 6/8',
            'Game To Deuce 6/9',
            'Game To Deuce 6/10',
            'Game To Deuce 6/11',
            'Game To Deuce 6/12',
            'Game To Deuce 6/13',
            'Game To Deuce 6/14',
            'Game To Deuce 6/15',
            'Game To Deuce 6/16',
            'Game To Deuce 6/17',
            'Game To Deuce 6/18',
            'Game To Deuce 6/19',
            'Game To Deuce 6/20',

            'Game To Deuce 7/1',
            'Game To Deuce 7/2',
            'Game To Deuce 7/3',
            'Game To Deuce 7/4',
            'Game To Deuce 7/5',
            'Game To Deuce 7/6',
            'Game To Deuce 7/7',
            'Game To Deuce 7/8',
            'Game To Deuce 7/9',
            'Game To Deuce 7/10',

            'Game To Deuce 8/1',
            'Game To Deuce 8/2',
            'Game To Deuce 8/3',
            'Game To Deuce 8/4',
            'Game To Deuce 8/5',
            'Game To Deuce 8/6',
            'Game To Deuce 8/7',
            'Game To Deuce 8/8',
            'Game To Deuce 8/9',
            'Game To Deuce 8/10',

            'Game To Deuce 9/1',
            'Game To Deuce 9/2',
            'Game To Deuce 9/3',
            'Game To Deuce 9/4',
            'Game To Deuce 9/5',
            'Game To Deuce 9/6',
            'Game To Deuce 9/7',
            'Game To Deuce 9/8',
            'Game To Deuce 9/9',
            'Under/Over 180s 0.5',
            'Under/Over 180s 1.0',
            'Under/Over 180s 1.5',
            'Under/Over 180s 2.0',
            'Under/Over 180s 2.5',
            'Under/Over 180s 3.0',
            'Under/Over 180s 3.5',
            'Under/Over 180s 4.0',



            'Tied Match',
            "TIED_MATCH"



        ];
        function isNonFancyMarket(market_type) {

            // 1️⃣ fixed names
            if (fixedNonFancyMarkets.includes(market_type)) {
                return true;
            }

            // 2️⃣ Game Winner X/Y
            if (/^Game Winner\s+(?:[1-9]|1\d|20)\/(?:[1-9]|1\d|20)$/.test(market_type)) {
                return true;
            }

            // 3️⃣ Match Time Result 10:00, 70:00, etc
            if (/^Match Time Result\s+\d{2}:\d{2}$/.test(market_type)) {
                return true;
            }

            // 4️⃣ Set Race To 1.0 – 15.0 (all sets)
            if (/^\d+(?:st|nd|rd|th)\s+Set Race To\s+(?:[1-9]|1[0-5])\.0$/.test(market_type)) {
                return true;
            }

            // 5️⃣ Under/Over 0.5 , 1.5 , 180s etc
            if (/^Under\/Over(?: 180s)?\s+\d+(\.\d)?$/.test(market_type)) {
                return true;
            }

            // 6️⃣ Total Tie Break in the Match X.X
            if (/^Total Tie Break in the Match\s+\d+(\.\d)?$/.test(market_type)) {
                return true;
            }

            // 7️⃣ Point Winner A/B/C
            if (/^Point Winner\s+(?:[1-9]|1\d|20)\/(?:[1-9]|1\d|20)\/(?:[1-9]|1\d|20)$/.test(market_type)) {
                return true;
            }

            // 8️⃣ Game To Deuce A/B   (your current list)
            if (/^Game To Deuce\s+(?:[1-9]|1\d|20)\/(?:[1-9]|1\d|20)$/.test(market_type)) {
                return true;
            }

            // 9️⃣ Game To Deuce A/B/C (future support – as you mentioned before)
            if (/^Game To Deuce\s+(?:[1-9]|1\d|20)\/(?:[1-9]|1\d|20)\/(?:[1-9]|1\d|20)$/.test(market_type)) {
                return true;
            }

            return false;
        }

        const fixedNonFancyMarkets = [
            'OVER_UNDER_55',
            'OVER_UNDER_45',
            'OVER_UNDER_35',
            'OVER_UNDER_25',
            'OVER_UNDER_15',
            'OVER_UNDER_05',
            'OVER_UNDER_10',

            '2nd Period Winner',
            '1st Period Winner',
            '3rd Period Winner',

            'Both Teams To Score',

            'DRAW_NO_BET',
            'Draw No Bet',

            'HALF_TIME',

            '1st Set Winner Home/Away',
            '2nd Set Winner Home/Away',
            '3rd Set Winner Home/Away',
            '4th Set Winner Home/Away',
            '5th Set Winner Home/Away',

            '1st Set Winner',
            '2nd Set Winner',
            '3rd Set Winner',
            '4th Set Winner',
            '5th Set Winner',
            '6th Set Winner',

            '1st Half Winner',
            '2nd Half Winner',
            '3rd Half Winner',
            '4th Half Winner',
            '5th Half Winner',
            '6th Half Winner',

            '1st Quarter Winner',
            '2nd Quarter Winner',
            '3rd Quarter Winner',
            '4th Quarter Winner',
            '5th Quarter Winner',
            '6th Quarter Winner',

            'Tied Match',
            'TIED_MATCH'
        ];

        const marketsforfancy = [
            '1st Innings 6 Overs Line',
            '2nd Innings 6 Overs Line',
            '3rd Innings 6 Overs Line',
            '1st Innings 50 Overs Line',
            '2nd Innings 50 Overs Line',
            '3rd Innings 50 Overs Line',
            '1st Innings 40 Overs Line',
            '2nd Innings 40 Overs Line',
            '3rd Innings 40 Overs Line',
            '1st Innings 30 Overs Line',
            '2nd Innings 30 Overs Line',
            '3rd Innings 30 Overs Line',
            '1st Innings 20 Overs Line',
            '2nd Innings 20 Overs Line',
            '3rd Innings 20 Overs Line',
            '1st Innings 10 Overs Line',
            '2nd Innings 10 Overs Line',
            '3rd Innings 10 Overs Line',
            'Over By Over',
            'Ball By Ball',
            'Normal',
            'khado',
            'meter',
            'fancy1',
            'oddeven'
        ];
        const marketsforBMfancy = [
            'BM 1st Set Winner',
            'BM 2nd Set Winner',
            'BM 3rd Set Winner',
            'BM 4th Set Winner',
            'BM 5th Set Winner',
        ]
        const marketforfancywithbigrunners = [
            '2ND INN 30 OVER',
            '2ND INN 35 OVER',
            '1ST INN 20 OVER',
            '2ND INN 50 OVER',
            'TOURNAMENT_WINNER',
            'Next Goal 1.0',
            'Next Goal 2.0',
            'Next Goal 3.0',
            'Next Goal 4.0',
            'Next Goal 5.0',
            'Next Goal 6.0',
            'Next Goal 7.0',
            'Next Goal 8.0',
            'Next Goal 9.0',
            'Next Goal 10.0',
            'Match Result/Both Teams to score',
            'Correct Score 1st Set',
            'Correct Score 2nd Set',
            'Correct Score 3rd Set',
            'Correct Score 4th Set',
            'Correct Score 5th Set',
            'Correct Score 6th Set',
            'HT/FT'

            // 'oddeven'

        ];

        function calculateRunnerExposure({
            runners,
            selectedRunner,
            stake,
            odd,
            betType,
            oldExposures = {}
        }) {
            let newExposures = { ...oldExposures };

            const profit = stake * (odd - 1);
            const liability = stake * (odd - 1);

            const isBack = betType === 'back' || betType === 'yes';
            const isLay = betType === 'lay' || betType === 'no';

            for (const runner of runners) {
                const prev = oldExposures[runner] || 0;

                if (runner === selectedRunner) {
                    newExposures[runner] = isBack
                        ? prev + profit
                        : prev - liability;
                } else {
                    newExposures[runner] = isBack
                        ? prev - stake
                        : prev + stake;
                }
            }

            return newExposures;
        }
        function isFancyMatch(gameType = '', matchList = []) {
            const normalized = gameType.toUpperCase();

            return matchList.some(item =>
                normalized.includes(item.toUpperCase())
            );
        }


        if (marketsforfancy.includes(market_type)) {
            console.log("marketsforfancy", marketsforfancy);
            console.log("market_type", market_type);

            const S = Number(stake);        // 100
            let L = Number(lay_size);     // 110
            let B = Number(back_size);    // 90
            if (market_type === 'fancy1' || market_type === 'oddeven') {
                const backOdds = runner_odds.find(o => o.oname === "back1")?.odds ?? null;
                const layOdds = runner_odds.find(o => o.oname === "lay1")?.odds ?? null;
                L = (layOdds - 1) * 100
                B = (backOdds - 1) * 100
            }

            // const L = 110;     // 110
            // const B = 90;
            let layword = sel + 'lay';
            let backword = sel + 'back';
            if (L === B || market_type === '1st Innings 6 Overs Line' || market_type === '2nd Innings 6 Overs Line' || market_type === '3rd Innings 6 Overs Line' || market_type === '1st Innings 10 Overs Line' || market_type === '2nd Innings 10 Overs Line' || market_type === '3rd Innings 10 Overs Line' || market_type === '1st Innings 20 Overs Line' || market_type === '2nd Innings 20 Overs Line' || market_type === '3rd Innings 20 Overs Line'
                || market_type === '1st Innings 50 Overs Line' || market_type === '2nd Innings 50 Overs Line' || market_type === '3rd Innings 50 Overs Line' || market_type === '1st Innings 30 Overs Line' || market_type === '2nd Innings 30 Overs Line' || market_type === '3rd Innings 30 Overs Line' || market_type === '1st Innings 40 Overs Line' || market_type === '2nd Innings 40 Overs Line' || market_type === '3rd Innings 40 Overs Line'
                || market_type === '1st Innings 10 Overs Line' || market_type === '2nd Innings 10 Overs Line' || market_type === '3rd Innings 10 Overs Line' || market_type === '1st Innings 20 Overs Line' || market_type === '2nd Innings 20 Overs Line' || market_type === '3rd Innings 20 Overs Line'
            ) {
                newExposures[sel] = (oldExposures[sel] || 0) - stake;
                newExposures[layword] = (oldExposures[layword] || 0) + stake;
                newExposures[backword] = (oldExposures[backword] || 0) - stake;

            }
            else {


                // Previous exposures
                console.log("oldExposures", oldExposures);
                let layExp = Number(oldExposures?.[layword] || 0);
                let backExp = Number(oldExposures?.[backword] || 0);

                console.log("layExp", layExp);
                console.log("backExp", backExp);

                // Previous stored worst exposure for this selection
                let worstExp = Number(oldExposures?.[sel] || 0);

                const layRisk = (S * L) / 100;   // 110
                const backWin = (S * B) / 100;  // 90

                if (betTypeLower === 'lay') {

                    // LAY impact
                    layExp += S;        // +100
                    backExp -= layRisk; // -110

                } else if (betTypeLower === 'back') {

                    // BACK impact
                    layExp -= S;        // -100
                    backExp += backWin; // +90
                }
                console.log("layExp", layExp);
                console.log("backExp", backExp);
                // Current worst exposure after this bet
                const currentWorst = Math.min(layExp, backExp);



                // Store exposures
                newExposures[layword] = layExp;
                newExposures[backword] = backExp;
                newExposures[sel] = currentWorst;


                console.log('[FANCY EXPOSURE TRACK]', {
                    selection: sel,
                    betType: betTypeLower,
                    stake: S,
                    layBhav: L,
                    backBhav: B,
                    layExposure: layExp,
                    backExposure: backExp,
                    currentWorst,
                    storedWorst: worstExp
                });
            }
        }




        else if (normGameType === 'MO') {

            newExposures = calculateRunnerExposure({
                runners,
                selectedRunner: sel,
                stake,
                odd: oddN,
                betType: betTypeLower,
                oldExposures
            });
        } else if (normGameType === 'BM') {
            // BOOKMAKER (two-way) using normalized odds
            const newodds = normalizeOdds(oddN);
            console.log(`Normalized BM odds: ${oddN} → ${newodds}`);


            newExposures = calculateRunnerExposure({
                runners,
                selectedRunner: sel,
                stake,
                odd: newodds,
                betType: betTypeLower,
                oldExposures
            });
        } else if (isNonFancyMarket(market_type)) {
            let profit = 0
            let layLiab = 0
            if (market_type === 'Tied Match') {
                let new_odds = oddN / 100
                profit = stake * (new_odds);
                layLiab = stake * (new_odds);

            } else {
                profit = stake * (oddN - 1);
                layLiab = stake * (oddN - 1);

            }


            // ✅ If Draw is selected, ALWAYS update Draw exposure (regardless of count)
            if (isDrawSel) {

                if (betTypeLower === 'back' || betTypeLower === 'yes' || betTypeLower === 'Yes') {
                    newExposures['The Draw'] = (oldExposures['The Draw'] || 0) + profit;
                    newExposures[team_one] = (oldExposures[team_one] || 0) - stake;
                    newExposures[team_two] = (oldExposures[team_two] || 0) - stake;
                } else {
                    newExposures['The Draw'] = (oldExposures['The Draw'] || 0) - layLiab;
                    newExposures[team_one] = (oldExposures[team_one] || 0) + stake;
                    newExposures[team_two] = (oldExposures[team_two] || 0) + stake;
                }
            } else {
                // selection is one of the teams
                const otherTeam = sel === team_one ? team_two : team_one;

                if (betTypeLower === 'back') {
                    newExposures[sel] = (oldExposures[sel] || 0) + profit;
                    newExposures[otherTeam] = (oldExposures[otherTeam] || 0) - stake;
                    // Update Draw if it exists in oldExposures OR if count is 3
                    if (count == 3 || oldExposures['The Draw'] !== undefined) {
                        newExposures['The Draw'] = (oldExposures['The Draw'] || 0) - stake;
                    }
                } else {
                    newExposures[sel] = (oldExposures[sel] || 0) - layLiab;
                    newExposures[otherTeam] = (oldExposures[otherTeam] || 0) + stake;
                    if (count == 3 || oldExposures['The Draw'] !== undefined) {
                        newExposures['The Draw'] = (oldExposures['The Draw'] || 0) + stake;
                    }
                }
            }
        }
        else if (isFancyMatch(market_type, marketsforBMfancy)) {
            const newodds = normalizeOdds(oddN);
            console.log(`Normalized BM odds: ${oddN} → ${newodds}`);
            newExposures = calculateRunnerExposure({
                runners,
                selectedRunner: sel,
                stake,
                odd: newodds,
                betType: betTypeLower,
                oldExposures
            });
        }
        else if (isFancyMatch(market_type, marketforfancywithbigrunners)) {

            newExposures = calculateRunnerExposure({
                runners,
                selectedRunner: sel,
                stake,
                odd: oddN,
                betType: betTypeLower,
                oldExposures
            });
        }
        else {
            throw new Error(`bet is closed for this market`);
        }

        console.log('NEW EXPOSURES:', newExposures);

        // WALLET BLOCK - Calculate balance change
        let balanceChange = 0; // +deduct, -release


        //   if (market_type === 'fancy1') {
        //   balanceChange = stake;
        //   if (currentInr < balanceChange) throw new Error('Insufficient balance');
        //   console.log('[FANCY] Fixed deduction:', balanceChange);
        // } else
        if (marketsforfancy.includes(market_type)) {
            const oldNegs = Object.entries(oldExposures)
                .filter(([key, val]) => key === sel && val < 0)
                .map(([, val]) => val);

            const newNegs = Object.entries(newExposures)
                .filter(([key, val]) => key === sel && val < 0)
                .map(([, val]) => val);
            const oldMax = oldNegs.length ? Math.abs(Math.min(...oldNegs)) : 0;
            const newMax = newNegs.length ? Math.abs(Math.min(...newNegs)) : 0;
            const liabInc = newMax - oldMax;

            console.log('LIABILITY CALCULATION (MO/BM):');
            console.log('- Old liabilities:', oldNegs);
            console.log('- New liabilities:', newNegs);
            console.log('- Old total liability (blocked):', oldMax);
            console.log('- New total liability (to block):', newMax);
            console.log('- Liability change:', liabInc);

            if (Object.keys(oldExposures).length === 0) balanceChange = newMax;
            else if (liabInc > 0) balanceChange = liabInc;
            else if (liabInc < 0) balanceChange = liabInc; // negative → release

            if (balanceChange > 0 && currentInr < balanceChange) throw new Error('Insufficient balance');

        }
        else {
            // MO/BM — max negative liability delta
            const oldNegs = Object.values(oldExposures).filter(x => x < 0);
            const newNegs = Object.values(newExposures).filter(x => x < 0);
            const oldMax = oldNegs.length ? Math.abs(Math.min(...oldNegs)) : 0;
            const newMax = newNegs.length ? Math.abs(Math.min(...newNegs)) : 0;
            const liabInc = newMax - oldMax;

            console.log('LIABILITY CALCULATION (MO/BM):');
            console.log('- Old liabilities:', oldNegs);
            console.log('- New liabilities:', newNegs);
            console.log('- Old total liability (blocked):', oldMax);
            console.log('- New total liability (to block):', newMax);
            console.log('- Liability change:', liabInc);

            if (Object.keys(oldExposures).length === 0) balanceChange = newMax;
            else if (liabInc > 0) balanceChange = liabInc;
            else if (liabInc < 0) balanceChange = liabInc; // negative → release

            if (balanceChange > 0 && currentInr < balanceChange) throw new Error('Insufficient balance');
        }

        console.log('FINAL BALANCE CHANGE:', balanceChange, '(+deduct, -release)');



        //=============================================================================================
        // ✅ STEP 6:                    UPSERT MARKET EXPOSURE OF THE USER
        //============================================================================================
        for (const [name, amt] of Object.entries(newExposures)) {
            // await UserExposure.upsert(
            //     {
            //         user_id,
            //         match_id,
            //         team_name: name,
            //         exposure_amount: amt,
            //         match_title,
            //         game_type: exposureGameType,
            //         event_id: eventid,
            //         category: "sports"
            //     },
            //     { transaction }
            // );

            await pg.query(`
  INSERT INTO user_exposures (
      user_id,
      match_id,
      team_name,
      exposure_amount,
      match_title,
      game_type,
      event_id,
      category
  )
  VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
  ON CONFLICT (user_id, match_id, team_name, game_type)
  DO UPDATE SET
      exposure_amount = EXCLUDED.exposure_amount,
      match_title = EXCLUDED.match_title,
      event_id = EXCLUDED.event_id,
      category = EXCLUDED.category
  `,
                [
                    user_id,
                    match_id,
                    name,
                    amt,
                    match_title,
                    exposureGameType,
                    eventid,
                    "sports"
                ]
            );
        }

        console.log("het");

        // Calculate single bet liability for record keeping
        let singleBetLiability;
        if (market_type === 'fancy1' || market_type === 'oddeven') {
            singleBetLiability = (betTypeLower === 'back') ? stake : ((oddN - 1) * stake);
        }
        else if (market_type === 'Tied Match') {
            let new_odds = oddN / 100
            singleBetLiability = (betTypeLower === 'back') ? stake : stake * new_odds;

        }
        else if (normGameType === 'MO' || marketsfornonfancy.includes(market_type)) {
            singleBetLiability = (betTypeLower === 'back') ? stake : stake * (oddN - 1);
        } else if ((normGameType === 'MO') || (normGameType === 'BM')) {
            const newodds = normalizeOdds(oddN);
            singleBetLiability = (betTypeLower === 'back') ? stake : stake * (newodds - 1);
        } else {
            singleBetLiability = (betTypeLower === 'back') ? stake : (size * stake) / 100;
        }
        console.log("tesr", singleBetLiability);

        let fixed = 0;
        // if (balanceChange < 0) {
        //   fixed = 1;
        // }

        if (!marketsforfancy.includes(market_type)) {
            size = 0;
        }
        if (market_type === '1st Innings 6 Overs Line' || market_type === '2nd Innings 6 Overs Line' || market_type === '3rd Innings 6 Overs Line' || market_type === '1st Innings 10 Overs Line' || market_type === '2nd Innings 10 Overs Line' || market_type === '3rd Innings 10 Overs Line' || market_type === '1st Innings 20 Overs Line' || market_type === '2nd Innings 20 Overs Line' || market_type === '3rd Innings 20 Overs Line'
            || market_type === '1st Innings 50 Overs Line' || market_type === '2nd Innings 50 Overs Line' || market_type === '3rd Innings 50 Overs Line' || market_type === '1st Innings 30 Overs Line' || market_type === '2nd Innings 30 Overs Line' || market_type === '3rd Innings 30 Overs Line' || market_type === '1st Innings 40 Overs Line' || market_type === '2nd Innings 40 Overs Line' || market_type === '3rd Innings 40 Overs Line'
            || market_type === '1st Innings 10 Overs Line' || market_type === '2nd Innings 10 Overs Line' || market_type === '3rd Innings 10 Overs Line' || market_type === '1st Innings 20 Overs Line' || market_type === '2nd Innings 20 Overs Line' || market_type === '3rd Innings 20 Overs Line') {
            size = 0;
        }

        // Insert bet (use converted bet_type for fancy)
        const finalBetType = (game_type === "FAN" && bet_type)
            ? (bet_type.toLowerCase() === "back" ? "yes" : bet_type.toLowerCase() === "lay" ? "no" : bet_type)
            : bet_type;

        //=============================================================================================
        // ✅ STEP 7:                  SAVING BET TO DATABASE
        //=============================================================================================   

        const startTime = match_start_time || new Date();

        // const newBet = await SportsBet.create(
        //     {
        //         user_id,
        //         game_type: normGameType,
        //         match_id,
        //         match_title,
        //         team_one,
        //         team_two,
        //         selection_name,
        //         category: category || "1",
        //         bet_type: finalBetType,
        //         odds: oddN,
        //         stake_amount: stake,
        //         original_currency: original_currency || "INR",
        //         original_amount: original_amount || stake,
        //         usd_amount: usd_amount || (await inrToUsd(stake)),
        //         liability: singleBetLiability,
        //         match_start_time: startTime,
        //         exposure_after_bet: Math.max(0, ...Object.values(newExposures).filter(v => v < 0).map(v => Math.abs(v)), 0),
        //         status: "open",
        //         eventid,
        //         ip_address,
        //         fancy_name: fancy_name || "NULL",
        //         fixed: fixed,
        //         counts: count,
        //         sport_id: sid,
        //         fancy_name: fancy_name || "NULL",
        //         fixed: fixed,
        //         counts: count,
        //         sport_id: sid,
        //         market_type: market_type,
        //         unmatched: unmatched || false,
        //         unmatched_odds: unmatched_odds || null,
        //         size: size,
        //         runners: runners,
        //         event_name: event_name,
        //     },
        //     { transaction }
        // );



        //         let newBet = await pg.query(
        //             `INSERT INTO "SportsBet" (
        //       user_id,
        //     game_type,
        //     match_id,
        //     match_title,
        //     team_one,
        //     team_two,
        //     selection_name,
        //     category,
        //     bet_type,
        //     odds,
        //     stake_amount,
        //     original_currency,
        //     original_amount,
        //     usd_amount,
        //     liability,
        //     match_start_time,
        //     exposure_after_bet,
        //     status,
        //     eventid,
        //     ip_address,
        //     fancy_name,
        //     fixed,
        //     counts,
        //     sport_id,
        //     market_type,
        //     unmatched,
        //     unmatched_odds,
        //     size,
        //     runners,
        //     event_name
        // )
        // VALUES (
        //     $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,
        //     $11,$12,$13,$14,$15,$16,$17,$18,$19,$20,
        //     $21,$22,$23,$24,$25,$26,$27,$28,$29,$30
        // )
        // RETURNING *
        // `,
        //             [user_id, normGameType, match_id, match_title, team_one, team_two, selection_name, category || "1", finalBetType, oddN, stake, original_currency || "INR",
        //                 original_amount || stake, usd_amount || (await inrToUsd(stake)), singleBetLiability, startTime,
        //                 Math.max(0, ...Object.values(newExposures).filter(v => v < 0).map(v => Math.abs(v)), 0), "open", eventid, ip_address,
        //                 fancy_name || "NULL", fixed, count, sid, market_type, unmatched || false, unmatched_odds || null, size, runners, event_name
        //             ]
        //         );

        //         newBet = newBet.rows[0];

        const query = `
INSERT INTO "SportsBet" (
    user_id,
    game_type,
    match_id,
    match_title,
    team_one,
    team_two,
    selection_name,
    category,
    bet_type,
    odds,
    stake_amount,
    original_currency,
    original_amount,
    usd_amount,
    liability,
    match_start_time,
    exposure_after_bet,
    status,
    eventid,
    ip_address,
    fancy_name,
    fixed,
    counts,
    sport_id,
    market_type,
    unmatched,
    unmatched_odds,
    size,
    runners,
    event_name,
    lay_size,
    back_size,
    created_at,
    updated_at
)
VALUES (
    $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,
    $11,$12,$13,$14,$15,$16,$17,$18,$19,$20,
    $21,$22,$23,$24,$25,$26,$27,$28,$29,$30,
    $31,$32,
    NOW(), NOW()
)
RETURNING *
`;
        const values = [
            user_id,
            normGameType,
            match_id,
            match_title,
            team_one,
            team_two,
            selection_name,
            category + "1",
            finalBetType,
            oddN,
            stake,
            original_currency || "INR",
            original_amount || stake,
            usd_amount || (await inrToUsd(stake)),
            singleBetLiability,
            startTime,
            Math.max(0, ...Object.values(newExposures).filter(v => v < 0).map(v => Math.abs(v)), 0),
            "open",
            eventid,
            ip_address,
            fancy_name || "NULL",
            fixed,
            count,
            sid,
            market_type,
            unmatched || false,
            unmatched_odds || null,
            size,
            JSON.stringify(runners),   // ✅ FIX
            event_name,
            lay_size || null,
            back_size || null
        ];

        try {

            console.log("Running Query:");

            let newBet = await pg.query(query, values);
            newBet = newBet.rows[0];

            console.log("Inserted Row:");

        } catch (err) {
            console.error("Query Failed ❌");
            console.error("Error Message:", err.message);
            console.error("Error Stack:", err.stack);

            values.forEach((v, i) => {
                console.log(`$${i + 1}:`, v);
            });

            throw new Error("Erro in insert sports bet.");

        }


        //=============================================================================================
        // ✅ STEP 8: [PLATFORM SPECIFIC: LORDS] WALLET UPDATE : Deduct or Release
        //=============================================================================================
        if (balanceChange !== 0) {
            // wallet.credit = currentInr - balanceChange;
            // await wallet.save({ transaction });
            await pg.query(
                `UPDATE credits 
                 SET inr = inr - $1 
                 WHERE uid = $2`,
                [balanceChange, user_id]
            );
            console.log('Wallet updated. Balance change:', balanceChange);
        } else {
            console.log('No wallet update needed');
        }

        // ========================================================================================
        // ✅ STEP 9:  CALCULATE NET EXPOSURE OF THIS BET (most negative among 2-3 outcomes)
        // ========================================================================================
        // Get all exposures for this match from newExposures
        const betExposureValues = Object.values(newExposures);
        console.log('NEW EXPOSURES FOR THIS BET:', newExposures);
        console.log('EXPOSURE VALUES:', betExposureValues);

        // Find the net exposure of this bet: pick the most negative (minimum value)
        let betNetExposure = 0;
        if (betExposureValues.length > 0) {
            // Get the minimum value (most negative = highest liability)
            const minValue = Math.min(...betExposureValues);
            // Take absolute value to represent liability magnitude
            betNetExposure = minValue < 0 ? Math.abs(minValue) : 0;
        }
        console.log('NET EXPOSURE OF THIS BET:', betNetExposure);

        // ========================================================================================
        // ✅ STEP 10:              UPSERT TOTAL EXPOSURE RECORD
        // ========================================================================================
        let totalUserExposure = 0;

        // const matchExposures = await UserExposure.findAll({
        //     where: { user_id },
        //     transaction
        // });

        const matchExposuresResult = await pg.query(`
            SELECT *
            FROM user_exposures
            WHERE user_id = $1
            `,
            [user_id]
        );

        const matchExposures = matchExposuresResult.rows;

        console.log(`Found ${matchExposures.length} exposure records`);

        // Group by match_id (+ game_type if you want stricter separation)
        const exposureMap = {};

        for (const exp of matchExposures) {
            const key = `${exp.match_id}`; // or `${exp.match_id}_${exp.game_type}`

            const amount = Number(exp.exposure_amount) || 0;

            if (!exposureMap[key]) {
                exposureMap[key] = 0;
            }

            // Only count negative exposure (liability)
            if (amount < 0) {
                exposureMap[key] += Math.abs(amount);
            }
        }

        // Sum all match liabilities
        for (const matchKey in exposureMap) {
            totalUserExposure += exposureMap[matchKey];
        }

        console.log("Total User Exposure:", totalUserExposure);



        // await TotalExposure.upsert(
        //     {
        //         user_id,
        //         total_exposure: totalUserExposure
        //     },
        //     { transaction }
        // );
        console.log(`✅ TotalExposure upserted for user ${user_id}: ${totalUserExposure}`);

        const newBalance = balanceChange !== 0 ? currentInr - balanceChange : currentInr;

        console.log('Transaction completed successfully');
        console.log('Old balance:', currentInr);
        console.log('New balance:', newBalance);
        console.log('Actual balance delta:', newBalance - currentInr);

        await pg.query('COMMIT'); // 🔥 One central commit


        return res.status(200).json({
            success: true,
            exposure: { [match_id]: { match_title, teams: newExposures } },
            balanceDelta: newBalance - currentInr,
            oldBalance: currentInr,
            newBalance: newBalance,
            totalExposure: totalUserExposure
        });


    } catch (error) {
        await pg.query('ROLLBACK'); // 🔥 One central rollback
        return res.status(400).json({
            success: false,
            message: error.message
        });
        // console.error('Error fetching  all sports data:', error);
        // return res.status(500).json({ error: 'Failed to placeBet.' });
    }
}


//---------------------exposures-----------------------

const getUserExposures = async (req, res) => {
    try {
        const { user_id } = req.params;
        // const exposures = await UserExposure.findAll({ where: { user_id } });

        let exposures = await pg.query(
            `SELECT * FROM user_exposures WHERE user_id = $1`,
            [user_id]
        );


        exposures = exposures?.rows

        const out = {};
        exposures.forEach((e) => {
            if (!out[e.match_id]) out[e.match_id] = { match_title: e.match_title, teams: {} };
            out[e.match_id].teams[e.team_name] = Number(e.exposure_amount);
        });

        return res.json({ success: true, exposures: out });
    } catch (err) {
        console.error(err);
        return res.status(500).json({ success: false, error: "Could not fetch exposures" });
    }
};

const sportsDataSet = [
    { sid: 4, ename: "Cricket" },
    { sid: 1, ename: "Football" },
    { sid: 2, ename: "Tennis" },
    { sid: 8, ename: "Table Tennis" },
    { sid: 68, ename: "Esoccer" },
    { sid: 10, ename: "Horse Racing" },
    { sid: 65, ename: "Greyhound Racing" },
    { sid: 15, ename: "Basketball" },
    { sid: 69, ename: "Wrestling" },
    { sid: 18, ename: "Volleyball" },
    { sid: 22, ename: "Badminton" },
    { sid: 59, ename: "Snooker" },
    { sid: 57, ename: "Darts" },
    { sid: 6, ename: "Boxing" },
    { sid: 3, ename: "Mixed Martial Arts" },
    { sid: 58, ename: "American Football" },
    { sid: 11, ename: "E Games" },
    { sid: 19, ename: "Ice Hockey" },
    { sid: 9, ename: "Futsal" },
    { sid: 40, ename: "Politics" },
    { sid: 67, ename: "Boat Racing" },
    { sid: 52, ename: "Motor Sports" },
    { sid: 12, ename: "Greyhounds" },
    { sid: 66, ename: "Kabaddi" },
    { sid: 5, ename: "Golf" },
    { sid: 55, ename: "Rugby League" },
    { sid: 7, ename: "Beach Volleyball" },
    { sid: 13, ename: "Trotting" },
    { sid: 39, ename: "Handball" },
    { sid: 14, ename: "Speedway" },
    { sid: 16, ename: "MotoGP" },
    { sid: 17, ename: "Chess" },
    { sid: 20, ename: "Equine Sports" },
    { sid: 21, ename: "Australian Rules" },
    { sid: 23, ename: "Formula 1" },
    { sid: 24, ename: "Nascar" },
    { sid: 25, ename: "Hockey" },
    { sid: 26, ename: "Supercars" },
    { sid: 27, ename: "Netball" },
    { sid: 28, ename: "Surfing" },
    { sid: 29, ename: "Cycling" },
    { sid: 30, ename: "Gaelic Sports" },
    { sid: 31, ename: "Biathlon" },
    { sid: 32, ename: "Motorbikes" },
    { sid: 33, ename: "Athletics" },
    { sid: 34, ename: "Squash" },
    { sid: 35, ename: "Basketball 3X3" },
    { sid: 36, ename: "Floorball" },
    { sid: 37, ename: "Sumo" },
    { sid: 38, ename: "Virtual sports" },
    { sid: 41, ename: "Weather" }
];
const sportsMap = sportsDataSet.reduce((acc, item) => {
    acc[item.sid] = item.ename;
    return acc;
}, {});
const getUserBets = async (req, res) => {
    const { user_id } = req.params;

    try {
        const bets = (await pg.query(
            `SELECT 
          sport_id,
          match_title AS event_name,
          market_type AS match_name,
          match_id,
          COUNT(id) AS trade
       FROM "SportsBet"
       WHERE user_id = $1
         AND status = 'open'
       GROUP BY sport_id, match_title, market_type, match_id
       ORDER BY MAX(created_at) DESC`,
            [user_id]
        )).rows;

        const response = bets.map(bet => {
            const sportId = Number(bet.sport_id);

            return {
                event_type: sportsMap[sportId] || "Unknown",
                event_name: bet.event_name,
                match_name: bet.match_name,
                match_id: bet.match_id,
                sportId: sportId,
                trade: Number(bet.trade)
            };
        });

        return res.status(200).json({
            success: true,
            data: response
        });

    } catch (error) {
        console.error("Get User Bets Error:", error);
        return res.status(500).json({
            success: false,
            message: "Failed to fetch user bets"
        });
    }
};




// async function getexpossurebyid(user_id, match_id) {
//     console.log("Fetching exposure for user_id:", user_id, "and match_id:", match_id);
//     const exposures = (await pool.query(
//         `SELECT *
//         FROM user_exposures
//         WHERE user_id = $1
//         AND event_id = $2`,
//         [user_id, match_id]
//     )).rows;

//     return exposures;
// }

const getExposureById = async (req, res) => {
    try {
        const { user_id, match_id } = req.body; // or req.query if you prefer

        if (!user_id || !match_id) {
            return res.status(400).json({
                success: false,
                error: 'user_id and match_id are required',
            });
        }

        const exposureData = (await pg.query(
            `SELECT *
        FROM user_exposures
        WHERE user_id = $1
        AND event_id = $2`,
            [user_id, match_id]
        )).rows;

        return res.status(200).json({
            success: true,
            message: 'Exposure data fetched successfully',
            data: exposureData,
        });

    } catch (error) {
        console.error('❌ Get exposure error:', error);
        return res.status(500).json({
            success: false,
            error: error.message,
        });
    }
}

const openBetsByMatch = async (req, res) => {
    const { user_id, match_id } = req.params;
    try {

        if (!user_id || !match_id) {
            return res.status(400).json({
                success: false,
                error: 'user_id and match_id are required',
            });
        }
        // fetch only open bets for that match
        const { rows: bets } = await pg.query(
            `SELECT
         id,
         selection_name,
         odds,
         stake_amount AS stake,
         liability,
         bet_type AS type
       FROM "SportsBet"
       WHERE user_id = $1
         AND match_id = $2
         AND status   = 'open'`,
            [user_id, match_id]
        );

        return res.json({ success: true, bets });
    } catch (err) {
        console.error('Error fetching open bets by match:', err);
        return res.status(500).json({ success: false, error: 'Could not fetch open bets' });
    }
}

const historyBetByMatch = async (req, res) => {
    const { user_id, match_id } = req.params;
    try {


        if (!user_id || !match_id) {
            return res.status(400).json({
                success: false,
                error: 'user_id and match_id are required',
            });
        }

        // fetch only open bets for that match
        const { rows: bets } = await pg.query(
            `SELECT
         id,
         selection_name,
         odds,
         stake_amount AS stake,
         liability,
         bet_type AS type
       FROM "SportsBet"
       WHERE user_id = $1
         AND match_id = $2
         AND status   = 'open'`,
            [user_id, match_id]
        );

        return res.json({ success: true, bets });
    } catch (err) {
        console.error('Error fetching open bets by match:', err);
        return res.status(500).json({ success: false, error: 'Could not fetch open bets' });
    }
}

const opencount = async (req, res) => {
    const { user_id } = req.params;
    try {

        if (!user_id) {
            return res.status(400).json({
                success: false,
                error: 'user_id is required',
            });
        }
        // look up internal users.id by uuid
        const { rows: uRows } = await pg.query(
            `SELECT id FROM users WHERE id = $1 LIMIT 1`,
            [user_id]
        );
        console.log(uRows);
        if (!uRows.length) {
            return res.status(404).json({ success: false, error: 'User not found' });
        }
        const uid = uRows[0].id;

        // 2) Count open bets
        const { rows } = await pg.query(
            `SELECT COUNT(*) AS count
         FROM "SportsBet"
         WHERE user_id = $1
           AND status  = 'open'`,
            [uid]
        );
        const count = parseInt(rows[0].count, 10);
        console.log(count);
        return res.json({ success: true, count });
    } catch (err) {
        console.error('Error fetching open bets count:', err);
        return res.status(500).json({ success: false, error: 'Could not fetch count' });
    }
}


const getResult = async (req, res) => {
    const { event_id, sid } = req.body;
    console.log("::::::::::?????????????????????hoytttt:::::::>", { event_id, sid })


    if (!event_id) {
        return res.status(400).json({ error: 'Missing required fields' });
    }
    try {
        const apiUrl = `${SPORTS_BASE_URL}/get_result?sid=${sid}&gmid=${event_id}`;

        const response = await axios.get(apiUrl, {
            //     headers: {
            //         "x-turnkeyxgaming-key": ENV.SPORTS_API_KEY,
            //     },
            timeout: 60000,
            validateStatus: () => true
        });

        console.log("::::::::::getResult:::::::>", event_id, response?.status)


        return res.status(response.status).json(response.data);
    } catch (error) {
        console.error('[get-result] fetch error', error);
        return res.status(500).json({ error: error.message || 'Unknown error' });
    }
}


const getUserSportsOpenBets = async (req, res) => {
    try {
        // User ID from query or auth middleware (preferred)
        const user_id = req.query?.user_id;

        if (!user_id) {
            return res.status(400).json({
                success: false,
                error: 'User ID is required',
            });
        }

        console.log('getUserSportsCasinoOpenBets called for user:', user_id);

        const query = `
     SELECT *
     FROM "SportsBet"
     WHERE user_id = $1
     AND status IN ('open', 'pending')
     ORDER BY created_at DESC
 `;

        const values = [user_id.toString()];

        const { rows: sportsBets } = await pg.query(query, values);


        // 3. Process and Separate Data

        // Standardize fields for frontend compatibility if needed, using helper
        const formatSportBet = (bet) => ({
            ...bet,
            type: 'sport',
            bet_type: bet.bet_type, // 'back' or 'lay'
            status: bet.status,
            stake: parseFloat(bet.stake_amount || 0),
            odds: parseFloat(bet.odds || 0),
            selection: bet.selection_name,
            game_name: bet.match_title,
            market_name: bet.market_name,
            created_at: bet.created_at,
            is_matched: !bet.unmatched, // Derived matched status
            unmatched: !!bet.unmatched
        });


        const processedSports = sportsBets.map(formatSportBet);

        // Filter Unmatched Sports Bets
        // Definition of unmatched: unmatched flag is true OR status is explicitly unmatched
        const unmatchedBets = processedSports.filter(b => b.unmatched === true || b.status === 'unmatched');

        // Matched Sports Bets
        const matchedSportsBets = processedSports.filter(b => b.unmatched !== true && b.status !== 'unmatched');

        // Combine Matched Sports + Casino (Casino are typically matched immediately)
        // Or keep them separate as per requirement "gives user open bets from casinobet and sportbet table"
        // The prompt said "also group unmatched bets", implying a specific group for them.

        // We will return structured data
        return res.status(200).json({
            success: true,
            sportsBets: processedSports, // Full list if needed

            // Grouped for easy UI consumption
            unmatchedBets: unmatchedBets,
            matchedBets: [...matchedSportsBets].sort((a, b) => new Date(b.created_at) - new Date(a.created_at)),

            totalCount: processedSports.length,
            unmatchedCount: unmatchedBets.length,
            matchedCount: matchedSportsBets.length,

            meta: {
                user_id,
                generated_at: new Date().toISOString()
            }
        });

    } catch (error) {
        console.error('Error in getUserSportsCasinoOpenBets:', error?.message);
        return res.status(500).json({
            success: false,
            error: error.message || 'Internal server error',
        });
    }
}


const userOpenBets = async (req, res) => {
    try {

        const { eventid, user_id } = req.query;

        console.log('getUserOpenBetsForEvent called with:', { eventid, user_id });

        if (!eventid || !user_id) {
            return res.status(400).json({
                success: false,
                error: 'Both eventid and user_id are required',
            });
        }

        const query = `
    SELECT *
    FROM "SportsBet" sb
    LEFT JOIN users u 
        ON u.id = sb.user_id
    WHERE sb.eventid = $1
      AND sb.user_id = $2
      AND sb.status = 'open'
      AND (sb.unmatched = false OR sb.unmatched IS NULL)
    ORDER BY sb.created_at DESC
`;

        const values = [
            eventid.toString(),
            user_id.toString()
        ];

        const { rows: bets } = await pg.query(query, values);

        const formattedBets = bets.map(bet => ({
            ...bet,
            username: bet['user.username'] || "Unknown",
            stake_amount: parseFloat(bet.stake_amount).toFixed(2),
            odds: parseFloat(bet.odds).toFixed(4),
            liability: bet.liability ? parseFloat(bet.liability).toFixed(2) : null,
            usd_amount: bet.usd_amount ? parseFloat(bet.usd_amount).toFixed(2) : null,
        }));

        return res.status(200).json({
            success: true,
            data: formattedBets,
            meta: {
                eventid,
                user_id,
                filter: 'fresh_open_bets_only',
                generated_at: new Date().toISOString(),
            },
        });



    } catch (error) {
        console.error('Error in getUserSportsCasinoOpenBets:', error?.message);
        return res.status(500).json({
            success: false,
            error: error.message || 'Internal server error',
        });
    }
}



// ==================== ADMIN PANEL APIs ====================

const safeInt = (val, fallback = 1) => {
    if (val == null || val === '') return fallback;
    const n = parseInt(val, 10);
    return isNaN(n) ? fallback : Math.max(1, n);
};

/**
 * GET /admin/bet-list?type=current|past&page=1&limit=50&search=&username=&sport=
 */
const getBetList = async (req, res) => {
    try {
        const { type, from, to, search, username, sport } = req.query;
        const pageNum = safeInt(req.query.page, 1);
        const limitNum = safeInt(req.query.limit, 50);
        const offset = (pageNum - 1) * limitNum;

        if (!type || (type !== 'current' && type !== 'past')) {
            return res.status(400).json({ success: false, message: "Invalid type. Must be 'current' or 'past'." });
        }

        // Staff visibility filter (null = no filter / super admin, [] = no users, [ids] = filter)
        const _staffId = req.headers['x-staff-id'];
        let visibleUids = null;
        if (_staffId) {
            const { visibleStaffIds } = require('../../system/helpers/staffTree');
            const sids = (await visibleStaffIds(_staffId)).map(Number);
            if (!sids.includes(1)) {
                const uRes = await pg.query(
                    `SELECT array_agg(id) AS uids FROM users WHERE parent_staff_id = ANY($1::bigint[])`,
                    [sids]
                );
                visibleUids = uRes.rows[0]?.uids || [-1]; // [-1] = no real user, guarantees empty result
            }
        }

        let whereClause;
        if (type === 'current') {
            whereClause = `WHERE sb.status IN ('OPEN', 'PENDING', 'open', 'matched', 'Match') AND sb.result_status = 'pending'`;
        } else {
            whereClause = `WHERE sb.result_status != 'pending' AND sb.status NOT IN ('open', 'OPEN', 'pending', 'PENDING', 'matched', 'Match', 'MATCHED')`;
        }

        if (visibleUids && visibleUids.length > 0) {
            whereClause += ` AND sb.user_id = ANY(ARRAY[${visibleUids.map(id => `'${id}'`).join(',')}]::bigint[])`;
        }

        // Date filter (past only) - use updated_at as fallback since created_at can be NULL
        if (type === 'past' && from && to) {
            const fromStr = new Date(from).toISOString();
            const toStr = new Date(new Date(to).setHours(23, 59, 59, 999)).toISOString();
            whereClause += ` AND COALESCE(sb.created_at, sb.updated_at) BETWEEN '${fromStr}' AND '${toStr}'`;
        }

        // Search filter
        if (search) {
            whereClause += ` AND (sb.match_title ILIKE '%${search}%' OR sb.market_type ILIKE '%${search}%' OR sb.selection_name ILIKE '%${search}%')`;
        }

        // Username filter
        if (username) {
            whereClause += ` AND u.name ILIKE '%${username}%'`;
        }

        // Sport filter
        if (sport && sport !== 'All') {
            const isNumeric = /^\d+$/.test(sport);
            if (isNumeric) {
                whereClause += ` AND sb.sport_id = '${sport}'`;
            } else {
                whereClause += ` AND (sb.game_type ILIKE '%${sport}%' OR sb.match_title ILIKE '%${sport}%')`;
            }
        }

        const countQuery = `SELECT COUNT(*) as total FROM "SportsBet" sb LEFT JOIN users u ON sb.user_id = u.id ${whereClause}`;
        const dataQuery = `
            SELECT
                sb.id::text as id, sb.user_id, u.name as username,
                COALESCE(sb.created_at, sb.updated_at) as created_at,
                COALESCE(sb.match_title, sb.game_type) as description,
                sb.selection_name as selection, sb.game_type, sb.bet_type,
                sb.odds, sb.stake_amount as amount, sb.liability,
                sb.status, sb.result_status, 'sport' as source,
                COALESCE(u.is_demo, false) AS is_demo
            FROM "SportsBet" sb
            LEFT JOIN users u ON sb.user_id = u.id
            ${whereClause}
            ORDER BY COALESCE(sb.created_at, sb.updated_at) DESC
            LIMIT ${limitNum} OFFSET ${offset}
        `;

        console.log('getBetList query:', dataQuery);
        const totalResult = (await pg.query(countQuery)).rows;
        const rows = (await pg.query(dataQuery)).rows;
        console.log('getBetList results:', totalResult[0]?.total, 'rows:', rows.length);

        return res.status(200).json({
            success: true,
            data: rows,
            pagination: {
                total: parseInt(totalResult[0]?.total || 0),
                page: pageNum,
                limit: limitNum,
                totalPages: Math.ceil(parseInt(totalResult[0]?.total || 0) / limitNum)
            }
        });

    } catch (error) {
        console.error('Error in getBetList:', error);
        return res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};

/**
 * GET /admin/bet-ticker?sport=
 * Returns latest 100 open/pending sports bets
 */
const getBetTicker = async (req, res) => {
    try {
        const { sport } = req.query;

        // Staff visibility filter (null = no filter / super admin, [] = no users, [ids] = filter)
        const _staffId = req.headers['x-staff-id'];
        let visibleUids = null;
        if (_staffId) {
            const { visibleStaffIds } = require('../../system/helpers/staffTree');
            const sids = (await visibleStaffIds(_staffId)).map(Number);
            if (!sids.includes(1)) {
                const uRes = await pg.query(
                    `SELECT array_agg(id) AS uids FROM users WHERE parent_staff_id = ANY($1::bigint[])`,
                    [sids]
                );
                visibleUids = uRes.rows[0]?.uids || [-1]; // [-1] = no real user, guarantees empty result
            }
        }

        let whereClause = `WHERE sb.status IN ('OPEN', 'PENDING', 'open', 'matched', 'Match') AND sb.result_status = 'pending'`;

        if (visibleUids && visibleUids.length > 0) {
            whereClause += ` AND sb.user_id = ANY(ARRAY[${visibleUids.map(id => `'${id}'`).join(',')}]::bigint[])`;
        }

        if (sport && sport !== 'All') {
            const isNumeric = /^\d+$/.test(sport);
            if (isNumeric) {
                whereClause += ` AND sb.sport_id = '${sport}'`;
            } else {
                whereClause += ` AND (sb.game_type ILIKE '%${sport}%' OR sb.match_title ILIKE '%${sport}%')`;
            }
        }

        const query = `
            SELECT
                sb.id::text as id, sb.user_id, u.name as username, sb.created_at,
                COALESCE(sb.match_title, sb.game_type) as description,
                sb.selection_name as selection, sb.game_type, sb.bet_type,
                sb.odds, sb.stake_amount as amount, sb.liability,
                sb.status, 'sport' as source
            FROM "SportsBet" sb
            LEFT JOIN users u ON sb.user_id = u.id
            ${whereClause}
            ORDER BY sb.created_at DESC
            LIMIT 100
        `;

        const rows = (await pg.query(query)).rows;
        return res.status(200).json({ success: true, data: rows });

    } catch (error) {
        console.error('Error in getBetTicker:', error);
        return res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};

/**
 * GET /admin/bet-list-by-user?user_id=123&type=current|past&page=1&limit=50
 */
const getBetListByUser = async (req, res) => {
    try {
        const { user_id, type } = req.query;
        const pageNum = safeInt(req.query.page, 1);
        const limitNum = safeInt(req.query.limit, 50);
        const offset = (pageNum - 1) * limitNum;

        if (!user_id) {
            return res.status(400).json({ success: false, message: 'user_id is required' });
        }

        let whereClause;
        if (type === 'current') {
            whereClause = `WHERE sb.user_id = $1 AND sb.status IN ('OPEN', 'PENDING', 'open', 'matched', 'Match') AND sb.result_status = 'pending'`;
        } else {
            whereClause = `WHERE sb.user_id = $1 AND sb.result_status != 'pending' AND sb.status NOT IN ('open', 'OPEN', 'pending', 'PENDING', 'matched', 'Match', 'MATCHED')`;
        }

        const countQuery = `SELECT COUNT(*) as total FROM "SportsBet" sb ${whereClause}`;
        const dataQuery = `
            SELECT
                sb.id, sb.user_id, u.name as username, sb.created_at,
                sb.match_title, sb.selection_name, sb.game_type, sb.bet_type,
                sb.market_type, sb.odds, sb.stake_amount, sb.liability,
                sb.status, sb.result_status, sb.match_id, sb.sport_id
            FROM "SportsBet" sb
            LEFT JOIN users u ON sb.user_id = u.id
            ${whereClause}
            ORDER BY sb.created_at DESC
            LIMIT $2 OFFSET $3
        `;

        const countResult = (await pg.query(countQuery, [user_id])).rows;
        const rows = (await pg.query(dataQuery, [user_id, limitNum, offset])).rows;

        return res.status(200).json({
            success: true,
            data: rows,
            pagination: {
                total: parseInt(countResult[0]?.total || 0),
                page: pageNum,
                limit: limitNum,
                totalPages: Math.ceil(parseInt(countResult[0]?.total || 0) / limitNum)
            }
        });

    } catch (error) {
        console.error('Error in getBetListByUser:', error);
        return res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};

/**
 * GET /admin/net-exposure?matchId=optional
 * Returns aggregated exposure data grouped by event/match
 */
const getNetExposureSports = async (req, res) => {
    try {
        const { matchId } = req.query;

        // Staff visibility filter (null = no filter / super admin, [] = no users, [ids] = filter)
        const _staffId = req.headers['x-staff-id'];
        let visibleUids = null;
        if (_staffId) {
            const { visibleStaffIds } = require('../../system/helpers/staffTree');
            const sids = (await visibleStaffIds(_staffId)).map(Number);
            if (!sids.includes(1)) {
                const uRes = await pg.query(
                    `SELECT array_agg(id) AS uids FROM users WHERE parent_staff_id = ANY($1::bigint[])`,
                    [sids]
                );
                visibleUids = uRes.rows[0]?.uids || [-1]; // [-1] = no real user, guarantees empty result
            }
        }

        let whereClause = `WHERE category = 'sports'`;
        const values = [];

        if (visibleUids && visibleUids.length > 0) {
            values.push(visibleUids);
            whereClause += ` AND user_id = ANY($${values.length}::bigint[])`;
        }

        if (matchId) {
            values.push(matchId);
            whereClause += ` AND event_id = $${values.length}`;
        }

        const exposures = (await pg.query(
            `SELECT id, user_id, match_id, event_id, team_name, exposure_amount,
                    match_title, game_type, category, created_at
             FROM user_exposures
             ${whereClause}
             ORDER BY created_at DESC`,
            values
        )).rows;

        // Aggregate by event
        const eventsMap = new Map();

        for (const exp of exposures) {
            const eventId = exp.event_id || exp.match_id;
            const matchIdVal = exp.match_id;
            const gameType = exp.game_type || 'match_odds';
            const teamName = exp.team_name;
            const amount = parseFloat(exp.exposure_amount) || 0;

            if (!eventsMap.has(eventId)) {
                eventsMap.set(eventId, {
                    eventId,
                    eventName: exp.match_title || `Match ${matchIdVal}`,
                    eventDate: exp.created_at,
                    category: 'sports',
                    markets: new Map()
                });
            }

            const event = eventsMap.get(eventId);
            const marketKey = `${matchIdVal}_${gameType}`;

            if (!event.markets.has(marketKey)) {
                event.markets.set(marketKey, {
                    id: marketKey,
                    marketName: exp.match_title || 'Market',
                    matchId: matchIdVal,
                    gameType,
                    selections: {},
                    runners: new Set(),
                    totalStake: 0,
                    totalPL: 0
                });
            }

            const market = event.markets.get(marketKey);
            if (!market.selections[teamName]) {
                market.selections[teamName] = 0;
                market.runners.add(teamName);
            }
            market.selections[teamName] += amount;
            if (amount < 0) market.totalStake += Math.abs(amount);
            if (amount > 0) market.totalPL += amount;
        }

        // Format response
        const data = [];
        let totalExposure = 0;

        for (const [eventId, event] of eventsMap) {
            const marketsArray = [];
            for (const [, market] of event.markets) {
                marketsArray.push({
                    id: market.id,
                    marketName: market.marketName,
                    matchId: market.matchId,
                    gameType: market.gameType,
                    selections: market.selections,
                    runners: Array.from(market.runners),
                    stake: Math.abs(market.totalStake),
                    pl: market.totalPL
                });
                totalExposure += Math.abs(market.totalStake);
            }

            data.push({
                id: eventId,
                eventId,
                eventName: event.eventName,
                eventDate: event.eventDate,
                category: 'sports',
                markets: marketsArray
            });
        }

        return res.status(200).json({
            success: true,
            data,
            meta: {
                totalEvents: eventsMap.size,
                totalExposure: parseFloat(totalExposure.toFixed(2))
            }
        });

    } catch (error) {
        console.error('Error in getNetExposureSports:', error);
        return res.status(500).json({ success: false, message: 'Failed to fetch sports net exposure data' });
    }
};

/**
 * GET /admin/net-exposure/market-book/:matchId?marketType=match_odds
 * Returns per-user exposure book for a specific match/market
 */
const getMarketUserBook = async (req, res) => {
    try {
        const { matchId } = req.params;
        const { marketType } = req.query;

        if (!matchId) {
            return res.status(400).json({ success: false, message: 'Missing matchId' });
        }

        // Staff visibility filter (null = no filter / super admin, [] = no users, [ids] = filter)
        const _staffId = req.headers['x-staff-id'];
        let visibleUids = null;
        if (_staffId) {
            const { visibleStaffIds } = require('../../system/helpers/staffTree');
            const sids = (await visibleStaffIds(_staffId)).map(Number);
            if (!sids.includes(1)) {
                const uRes = await pg.query(
                    `SELECT array_agg(id) AS uids FROM users WHERE parent_staff_id = ANY($1::bigint[])`,
                    [sids]
                );
                visibleUids = uRes.rows[0]?.uids || [-1]; // [-1] = no real user, guarantees empty result
            }
        }

        let whereClause = `WHERE ue.match_id = $1`;
        const values = [matchId];

        if (visibleUids && visibleUids.length > 0) {
            values.push(visibleUids);
            whereClause += ` AND ue.user_id = ANY($${values.length}::bigint[])`;
        }

        if (marketType) {
            values.push(marketType);
            whereClause += ` AND ue.game_type = $${values.length}`;
        }

        // Fetch exposures with username
        const exposures = (await pg.query(
            `SELECT ue.user_id, u.name as username, ue.team_name, ue.exposure_amount, ue.game_type
             FROM user_exposures ue
             LEFT JOIN users u ON ue.user_id = u.id
             ${whereClause}`,
            values
        )).rows;

        // Pivot: group by user
        const bookMap = new Map();

        for (const exp of exposures) {
            const uid = exp.user_id;
            if (!bookMap.has(uid)) {
                bookMap.set(uid, {
                    userId: uid,
                    username: exp.username,
                    runners: {}
                });
            }
            const entry = bookMap.get(uid);
            if (!entry.runners[exp.team_name]) {
                entry.runners[exp.team_name] = 0;
            }
            entry.runners[exp.team_name] += parseFloat(exp.exposure_amount || 0);
        }

        return res.status(200).json({
            success: true,
            data: Array.from(bookMap.values())
        });

    } catch (error) {
        console.error('Error in getMarketUserBook:', error);
        return res.status(500).json({ success: false, message: error.message });
    }
};

/**
 * POST /admin/game-report
 * P&L report using credits_ledger joined with SportsBet
 * Body: { fromDate, toDate, event?, search?, limit?, offset? }
 */
const getGameReport = async (req, res) => {
    try {
        const {
            event = "ALL",
            fromDate,
            toDate,
            limit = 50,
            offset = 0,
            search
        } = req.body;

        if (!fromDate || !toDate) {
            return res.status(400).json({ success: false, message: 'fromDate and toDate are required' });
        }

        // If search is provided, look up user by name
        let searchUserId = null;
        if (search && search.trim()) {
            const userResult = (await pg.query(
                `SELECT id FROM users WHERE name ILIKE $1 LIMIT 1`,
                [search.trim()]
            )).rows;
            if (!userResult.length) {
                return res.status(200).json({ success: true, count: 0, data: [], message: "User not found" });
            }
            searchUserId = userResult[0].id;
        }

        let whereClause = `WHERE sb.status = 'closed'
            AND cl.created_at BETWEEN $1 AND $2`;
        const values = [fromDate, new Date(new Date(toDate).setHours(23, 59, 59, 999)).toISOString()];
        let idx = 3;

        // Filter by specific user
        if (searchUserId) {
            whereClause += ` AND cl.user_id = $${idx}::text`;
            values.push(String(searchUserId));
            idx++;
        }

        // Filter by sport_id
        if (event && event !== 'ALL' && event !== 'All') {
            whereClause += ` AND sb.sport_id = $${idx}`;
            values.push(event);
            idx++;
        }

        const query = `
            SELECT
                sb.id AS bet_id,
                cl.user_id,
                u.name as username,
                'sport' AS category,
                sb.sport_id AS event,
                sb.game_type,
                sb.market_type AS market,
                sb.selection_name AS selection,
                sb.match_title,
                sb.bet_type,
                sb.stake_amount AS stake,
                sb.odds,
                cl.amount AS ledger_amount,
                cl.profit,
                cl.loss,
                cl.netamount,
                cl.commission,
                cl.closing,
                cl.created_at AS settled_at,
                COALESCE(u.is_demo, false) AS is_demo
            FROM "SportsBet" sb
            INNER JOIN credits_ledger cl ON cl.bet_id::bigint = sb.id AND cl.user_id = sb.user_id::text
            LEFT JOIN users u ON sb.user_id::text = u.id::text
            ${whereClause}
            ORDER BY cl.created_at DESC
            LIMIT $${idx} OFFSET $${idx + 1}
        `;

        values.push(parseInt(limit), parseInt(offset));

        console.log('getGameReport query:', query);
        console.log('getGameReport values:', values);

        const rows = (await pg.query(query, values)).rows;

        return res.status(200).json({
            success: true,
            count: rows.length,
            data: rows
        });

    } catch (error) {
        console.error('Error in getGameReport:', error);
        return res.status(500).json({ success: false, message: error.message });
    }
};

module.exports = {
    getAllSportsData,
    getSportsDataById,
    placeBet,
    getLiveStream,
    getScorecard,
    getUserExposures,
    getUserBets,
    getExposureById,
    openBetsByMatch,
    historyBetByMatch,
    opencount,
    getResult,
    getUserSportsOpenBets,
    userOpenBets,
    getBetList,
    getBetTicker,
    getBetListByUser,
    getNetExposureSports,
    getMarketUserBook,
    getGameReport,
}