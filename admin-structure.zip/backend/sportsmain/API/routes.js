const { getSportsDataById, getAllSportsData, placeBet, getLiveStream, getScorecard, getUserExposures, getUserBets, getExposureById,
    openBetsByMatch, historyBetByMatch, opencount, getResult, getUserSportsOpenBets, userOpenBets,
    getBetList, getBetTicker, getBetListByUser, getNetExposureSports, getMarketUserBook, getGameReport
} = require('./controller');
const express = require('express');
const router = express.Router();





router.post('/get-all-sports-data', getAllSportsData);
router.post('/get-sports-data-id', getSportsDataById)
router.post('/place-bet', placeBet)
router.post('/get-live-stream', getLiveStream)
router.post('/get-scorecard', getScorecard)
router.get('/exposures/:user_id', getUserExposures)

router.get('/bets/exposure/:user_id', getUserBets);
router.post('/matchexposures/match', /* authMiddleware, */ getExposureById);

router.get('/open/:user_id/:match_id', openBetsByMatch)
router.get('/history/:user_id/:match_id', historyBetByMatch)

router.get('/opencount/:user_id', opencount)

router.post('/get-result', getResult)

router.get('/user-sports-open-bets', getUserSportsOpenBets)

router.get('/user-open-bets', userOpenBets)

// Admin Panel Routes
router.get('/admin/bet-list', getBetList);
router.get('/admin/bet-ticker', getBetTicker);
router.get('/admin/bet-list-by-user', getBetListByUser);
router.get('/admin/net-exposure', getNetExposureSports);
router.get('/admin/net-exposure/market-book/:matchId', getMarketUserBook);
router.post('/admin/game-report', getGameReport);

// ── Bet Lock Management ──
router.get('/admin/betlock/users', async (req, res) => {
    try {
        const staffId = req.headers['x-staff-id'];
        if (!staffId) return res.status(400).json({ error: 'Staff ID required' });

        const { visibleStaffIds } = require('../../system/helpers/staffTree');
        const ids = await visibleStaffIds(staffId);
        const numIds = (ids || []).map(Number);
        const isSuperAdmin = numIds.includes(1);

        const result = await require('../../General/Model').query(`
            SELECT u.id, u.name, u.email, u.sports_betlocked, u.parent_staff_id,
                   s.name AS staff_name
            FROM users u
            LEFT JOIN staff s ON s.id = u.parent_staff_id
            WHERE u.parent_staff_id = ANY($1::bigint[])
               ${isSuperAdmin ? 'OR u.parent_staff_id IS NULL' : ''}
            ORDER BY u.id DESC
        `, [numIds]);
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.post('/admin/betlock/user/toggle', async (req, res) => {
    try {
        const { user_id, locked } = req.body;
        if (!user_id) return res.status(400).json({ error: 'user_id required' });
        await require('../../General/Model').query(
            `UPDATE users SET sports_betlocked = $1 WHERE id = $2`,
            [locked, user_id]
        );
        res.json({ message: `User bet ${locked ? 'locked' : 'unlocked'}` });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.get('/admin/betlock/staff', async (req, res) => {
    try {
        const staffId = req.headers['x-staff-id'];
        if (!staffId) return res.status(400).json({ error: 'Staff ID required' });

        const { visibleStaffIds } = require('../../system/helpers/staffTree');
        const ids = await visibleStaffIds(staffId);

        const result = await require('../../General/Model').query(`
            SELECT id, name, email, sports_betlocked, parent_id
            FROM staff
            WHERE id = ANY($1::bigint[])
            ORDER BY id ASC
        `, [ids]);
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.post('/admin/betlock/staff/toggle', async (req, res) => {
    try {
        const { staff_id, locked } = req.body;
        if (!staff_id) return res.status(400).json({ error: 'staff_id required' });
        await require('../../General/Model').query(
            `UPDATE staff SET sports_betlocked = $1 WHERE id = $2`,
            [locked, staff_id]
        );
        res.json({ message: `Staff bet ${locked ? 'locked' : 'unlocked'}` });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;