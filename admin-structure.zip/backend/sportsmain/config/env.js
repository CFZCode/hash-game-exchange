module.exports = {

    SPORTS_BASE_URL: `http://68.183.90.58:9000/`,
    SPORTS_API_KEY: "REMOVED_SECRET"
    // SPORTS_BASE_URL: "http://68.183.90.58:9000/",
    // SPORTS_API_KEY: "KX9F2A8Q7ZP1"
};

//http://159.198.77.241:8100
//http://cloud.turnkeyxgaming.com:8086
//http://5.182.208.160:9000
//https://demo45api.filmywap.space/
//http://local.turnkeyxgaming.com:8086
//http://primarydiamondfeeds.turnkeyxgaming.com:8000/
