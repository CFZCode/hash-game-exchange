/*
 * Manual check for the live-odds bet guard.
 *   node sportsmain/helper/oddsGuard.test.js
 *
 * Picks real markets out of the `oddsData:<gmid>` cache and runs the guard
 * against them, then prints a ready-to-send place-bet payload.
 */
const { verifyBetAgainstLiveOdds } = require('./oddsGuard')
const Redis = require('ioredis')

const line = (label, res) => {
  const tag = res.ok ? 'PASS ' : `BLOCK(${res.code})`
  console.log(`  ${label.padEnd(26)} ${tag}`, res.ok ? '' : `- ${res.message}`)
}

;(async () => {
  const r = new Redis({
    host: process.env.REDIS_HOST || '127.0.0.1',
    port: process.env.REDIS_PORT || 6379,
  })

  const keys = await r.keys('oddsData:*')
  let open = null, suspended = null, fancy = null

  for (const k of keys) {
    const gmid = k.split(':')[1]
    let markets = []
    try { markets = JSON.parse((await r.get(k)) || '[]') } catch { continue }

    for (const m of markets) {
      for (const s of m.section || []) {
        const p = (s.odds || []).find((o) => o.otype === 'back' && o.odds > 0)
        if (!p) continue
        const c = {
          gmid, market_id: m.mid, mname: m.mname, gtype: m.gtype,
          selection_sid: s.sid, selection_name: s.nat,
          bet_type: 'back', odds: p.odds, size: p.size,
        }
        const isFancy = String(m.gtype || '').startsWith('fancy')
        if (m.status === 'OPEN' && s.gstatus === 'OPEN') {
          if (!isFancy && !open) open = c
          if (isFancy && !fancy) fancy = c
        } else if (m.status === 'SUSPENDED' && !suspended) suspended = c
      }
    }
  }

  if (open) {
    console.log(`\nOPEN market: ${open.mname} / ${open.nat || open.selection_name} @ ${open.odds}`)
    line('exact live odds', await verifyBetAgainstLiveOdds(open))
    line('odds inflated +0.5', await verifyBetAgainstLiveOdds({ ...open, odds: open.odds + 0.5 }))
    line('odds lowered -0.5', await verifyBetAgainstLiveOdds({ ...open, odds: open.odds - 0.5 }))
    line('lowered + unmatched', await verifyBetAgainstLiveOdds({ ...open, odds: open.odds - 0.5, allowWorseOdds: true }))
    line('bogus selection', await verifyBetAgainstLiveOdds({ ...open, selection_sid: 99999999, selection_name: 'Nobody' }))
    line('stale matched volume', await verifyBetAgainstLiveOdds({ ...open, size: 1 }))
  } else console.log('\nno OPEN non-fancy selection cached right now')

  if (fancy) {
    console.log(`\nFANCY market: ${fancy.mname} / ${fancy.selection_name} @ ${fancy.odds}`)
    line('exact live line', await verifyBetAgainstLiveOdds(fancy))
    line('line moved +7', await verifyBetAgainstLiveOdds({ ...fancy, size: Number(fancy.size) + 7 }))
    line('sent as "yes"', await verifyBetAgainstLiveOdds({ ...fancy, bet_type: 'yes' }))
  } else console.log('\nno OPEN fancy selection cached right now')

  if (suspended) {
    console.log(`\nSUSPENDED market: ${suspended.mname}`)
    line('any price', await verifyBetAgainstLiveOdds(suspended))
  } else console.log('\nno SUSPENDED market cached right now')

  console.log('\nUNKNOWN game')
  line('gmid not in cache', await verifyBetAgainstLiveOdds({
    gmid: '000000', market_id: 1, bet_type: 'back', odds: 2, selection_name: 'x',
  }))

  if (open) {
    console.log('\n--- sample place-bet body (edit user_id, then POST to /api/sportsmain/place-bet) ---')
    console.log(JSON.stringify({
      user_id: 'REPLACE_ME',
      eventid: String(open.gmid), market_id: open.market_id, match_id: String(open.market_id),
      mname: open.mname, gtype: open.gtype, market_type: open.mname,
      selection_id: open.selection_sid, selection_name: open.selection_name, nat: open.selection_name,
      bet_type: 'back', odds: open.odds, stake_amount: 100,
    }, null, 2))
  }

  r.disconnect()
  process.exit(0)
})()
