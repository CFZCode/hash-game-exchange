-- RESTORE SNAPSHOT (BEFORE fix) — Rajnesh 6816840483 — 2026-07-17
-- Ye file exact current values rakhti hai. Revert ke liye ye statements chalao.
-- ================================================================

-- 1. Wallet balance restore
-- current inr = 267740
UPDATE credits SET inr = 267740 WHERE uid = '6816840483';

-- 2. users net_win / net_loss / total_profit restore
UPDATE users SET net_win = 324644.999999999996, net_loss = -304510, total_profit = 20134.999999999996 WHERE id = '6816840483';

-- 3. SportsBet size restore (10 affected bets — sab abhi size=0)
UPDATE "SportsBet" SET size = 0, status = 'closed', result_status = 'won' WHERE id = 346;
UPDATE "SportsBet" SET size = 0, status = 'closed', result_status = 'won' WHERE id = 348;
UPDATE "SportsBet" SET size = 0, status = 'closed', result_status = 'won' WHERE id = 583;
UPDATE "SportsBet" SET size = 0, status = 'closed', result_status = 'won' WHERE id = 584;
UPDATE "SportsBet" SET size = 0, status = 'closed', result_status = 'won' WHERE id = 766;
UPDATE "SportsBet" SET size = 0, status = 'closed', result_status = 'won' WHERE id = 767;
UPDATE "SportsBet" SET size = 0, status = 'closed', result_status = 'won' WHERE id = 772;
UPDATE "SportsBet" SET size = 0, status = 'closed', result_status = 'won' WHERE id = 773;
UPDATE "SportsBet" SET size = 0, status = 'closed', result_status = 'won' WHERE id = 778;
UPDATE "SportsBet" SET size = 0, status = 'closed', result_status = 'won' WHERE id = 781;

-- 4. Original credit_ledger rows (amount 0) — ye pehle se the, DELETE mat karna.
--    (reference only — inhe chhedना nahi hai)
--   ledger id 333 bet 346 amount 0
--   ledger id 336 bet 348 amount 0
--   ledger id 550 bet 583 amount 0
--   ledger id 551 bet 584 amount 0
--   ledger id 748 bet 766 amount 0
--   ledger id 749 bet 767 amount 0
--   ledger id 753 bet 772 amount 0
--   ledger id 754 bet 773 amount 0
--   ledger id 759 bet 778 amount 0
--   ledger id 760 bet 781 amount 0

-- NOTE: Fix ke baad jo NAYE ledger/fanwins rows banenge unhe hi delete karna revert me.
