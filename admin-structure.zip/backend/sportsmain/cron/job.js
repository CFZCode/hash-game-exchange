// Global error handlers
process.on('uncaughtException', err => {
    console.error('[ResultCron] Uncaught Exception:', err);
});
process.on('unhandledRejection', err => {
    console.error('[ResultCron] Unhandled Rejection:', err);
});

require("dotenv").config();

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const http = require('http');
const https = require('https');
const axios = require('axios');
const { pool: pg } = require('../../General/Model/pool'); // self-healing Pool: a bare Client dies permanently if Postgres restarts (see 2026-08-24 outage)
const console = require("console");


const RESULTS_FORCE_IPV4 = process.env.RESULTS_FORCE_IPV4 === '1' || process.env.RESULTS_FORCE_IPV4 === 'true';
const RESULTS_DISABLE_KEEPALIVE = process.env.RESULTS_DISABLE_KEEPALIVE === '1' || process.env.RESULTS_DISABLE_KEEPALIVE === 'true';
const RESULTS_RATE_LIMIT_MS = +(process.env.RESULTS_RATE_LIMIT_MS || 250); // actively used

// ---------- axios client ----------
const httpAgent = new http.Agent({ keepAlive: !RESULTS_DISABLE_KEEPALIVE, family: RESULTS_FORCE_IPV4 ? 4 : undefined });
const httpsAgent = new https.Agent({ keepAlive: !RESULTS_DISABLE_KEEPALIVE, family: RESULTS_FORCE_IPV4 ? 4 : undefined });



console.log('[ResultCron] Process started');


// ---------- logging ----------

const DEBUG = process.env.DEBUG === '1' || process.env.DEBUG === 'true';
const LOG_DIR = process.env.RESULTS_CRON_LOG_DIR || path.join(process.cwd(), 'sportsbet/betresult/logs');
const LOG_BASENAME = 'results-cron';

function ensureLogDir() {
    try { fs.mkdirSync(LOG_DIR, { recursive: true }); }
    catch (_) { }
}

ensureLogDir();

function currentLogPath() {
    const d = new Date()
    const yyyy = d.getFullYear()
    const mm = String(d.getMonth() + 1).padStart(2, '0')
    const dd = String(d.getDate()).padStart(2, '0')

    return path.join(LOG_DIR, `${LOG_BASENAME}-${yyyy}-${mm}-${dd}.log`)
}

function writeLog(level, msg, ctx = {}) {

    const ctxStr = Object.keys(ctx).length ? ' ' + JSON.stringify(ctx) : ''
    const line = `[${new Date().toISOString()}] [${level}] ${msg}${ctxStr}\n`

    if (level === 'ERROR') console.error(msg, ctx)
    else console.log(msg, ctx)

    try {
        fs.appendFileSync(currentLogPath(), line, 'utf8')
    } catch (e) {
        console.error('Log write failed:', e.message)
    }

}

const log = {
    info: (m, c = {}) => writeLog('INFO', m, c),
    error: (m, c = {}) => writeLog('ERROR', m, c),
    debug: (m, c = {}) => { if (DEBUG) writeLog('DEBUG', m, c) },
}


// ---------- ENV ----------

const RESULTS_API_BASE = process.env.RESULTS_API_BASE || 'https://diamond-result-v2.avrkhub.in/get_result'

const API_TIMEOUT_MS = +(process.env.API_TIMEOUT_MS || 60000)
const CRON_INTERVAL_MS = 60000
const RESULTS_MAX_FETCH_RETRIES = 6
const RESULTS_RETRY_BASE_MS = 500

const SUMMARY_RETENTION_DAYS = 7
const BET_CACHE_TTL_DAYS = 14


// ---------- AXIOS CLIENT ----------

// const httpAgent = new http.Agent({ keepAlive: true })
// const httpsAgent = new https.Agent({ keepAlive: true })

const ax = axios.create({
    timeout: API_TIMEOUT_MS,
    httpAgent,
    httpsAgent,
    validateStatus: () => true,
    headers: {
        'Accept': 'application/json',
        'User-Agent': `results-cron/1.0`
    }
})


// ---------- UTILS ----------

function sleep(ms) {
    return new Promise(r => setTimeout(r, ms))
}

function uuidv4() {
    return crypto.randomUUID ? crypto.randomUUID() : crypto.randomBytes(16).toString('hex')
}

function jitter(ms) {
    return Math.round(ms * (1 + Math.random() * 0.25))
}

// Parse a Retry-After header (seconds or HTTP-date) into milliseconds.
function parseRetryAfter(h) {
    if (!h) return null
    const n = Number(h)
    if (!Number.isNaN(n)) return Math.max(0, Math.round(n * 1000))
    const d = Date.parse(h)
    return Number.isNaN(d) ? null : Math.max(0, d - Date.now())
}

function formatName(name) {
    return name.replace(/\s+/g, '').toLowerCase()
}

function normalizeText(v) {
    if (!v) return ''

    return String(v)
        .replace(/\s+/g, ' ')
        .replace(/[^a-zA-Z0-9 ]/g, '')
        .trim()
        .toUpperCase()
}

function normalizeMarketType(v) {
    if (!v) return ''

    return String(v)
        .replace(/\s+/g, ' ')
        .trim()
        .toUpperCase()
}


// per-attempt transport fallback: after 3rd attempt, disable keep-alive + force IPv4, add Connection: close
function buildPerAttemptConfig(attempt) {
    if (attempt >= 3) {
        return {
            httpAgent: new http.Agent({ keepAlive: false, family: 4 }),
            httpsAgent: new https.Agent({ keepAlive: false, family: 4 }),
            headers: { 'Connection': 'close' }
        };
    }
    return {};
}

// ---------- RESULT API ----------

// async function fetchResultForEvent(eventid, eventName, marketId, marketName, sport_id, market_type, gameType) {

//     const url = `${RESULTS_API_BASE}/sportsmain/get-result`

//     for (let attempt = 1; attempt <= RESULTS_MAX_FETCH_RETRIES; attempt++) {

//         try {

//             const res = await axios.post("https://api.cryptmet.com/api/sportsmain/get-result", {
//                 event_id: eventid,
//                 sid: sport_id
//             })
//             console.log(":::::::111111111::::::res.staus:eventid::market_type,::", eventid, eventName, res.status, market_type)



//             if (res.status === 200) {

//                 const data = typeof res.data === "string" ? JSON.parse(res.data) : res.data

//                 const markets = Array.isArray(data?.data?.markets) ? data.data.markets : []

//                 const inputMarketName = normalizeText(marketName)
//                 const inputMarketType = normalizeMarketType(market_type)

//                 let matchedMarket

//                 if (market_type === 'TIED_MATCH' || market_type === 'Tied Match') {

//                     matchedMarket = markets.find(m =>
//                         normalizeMarketType(m?.mname) === inputMarketType
//                     )

//                 }
//                 else {
//                     // console.log("::::::22222::::::::::under::else :::", eventName)
//                     const inputEventName = normalizeText(eventName)

//                     console.log(":::::>>>>22222>>>>>>>>>::::::++++++::::", inputEventName, ",   ", inputMarketType)


//                     matchedMarket = markets.find(m =>
//                         normalizeText(m?.marketName) === inputEventName &&
//                         normalizeMarketType(m?.mname) === inputMarketType
//                     )

//                     console.log("::::::::+++++++3333333++++++++++++++::matchedMarkete::::", matchedMarket)

//                 }

//                 const declared = matchedMarket?.status === 'SETTLE'

//                 return {
//                     declared,
//                     items: matchedMarket ? [matchedMarket] : [],
//                     meta: data
//                 }

//             }


//         } catch (e) {

//             const wait = jitter(RESULTS_RETRY_BASE_MS * Math.pow(2, attempt - 1))
//             await sleep(wait)

//         }

//     }

//     return { declared: false, items: [] }

// }


async function fetchResultForEvent(eventid, eventName, marketId, marketName, sport_id, market_type, gameType) {

    // console.log('[ResultCron] START', {
    //     eventid,
    //     eventName,
    //     marketId,
    //     marketName,
    //     sport_id,
    //     market_type,
    //     gameType
    // });

    const maxAttempts = RESULTS_MAX_FETCH_RETRIES || 6;
    const url = `https://diamond-result-v2.avrkhub.in/get_result`;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        try {

            const requestUrl = `${url}?sid=${encodeURIComponent(sport_id)}&gmid=${encodeURIComponent(eventid)}`;

            console.log('[ResultCron] API REQUEST', {
                attempt,
                url: requestUrl
            });

            const res = await axios.get(
                requestUrl,
                {
                    timeout: API_TIMEOUT_MS,
                    // Don't throw on non-2xx; we handle statuses (404/429/5xx) explicitly below.
                    validateStatus: () => true,
                    ...buildPerAttemptConfig(attempt)
                }
            );

            // console.log('[ResultCron] API RESPONSE', {
            //     attempt,
            //     status: res.status,
            //     data: res.data
            // });

            if (res.status === 200) {

                const data = typeof res?.data === 'string'
                    ? JSON.parse(res.data)
                    : res.data;

                const markets = Array.isArray(data?.markets) ? data.markets : [];

                console.log('Markets received:', markets.length);
                // console.log('Markets:', markets);
                console.log("sport_id", sport_id);

                let matchedMarket;

                const inputMarketName = normalizeText(marketName);
                const inputMarketType = normalizeMarketType(market_type);

                console.log('Normalized Input Market Name:', inputMarketName);
                console.log('Normalized Input Market Type:', inputMarketType);

                // Print all markets normalized
                markets.forEach(m => {
                    console.log('API Market:', {
                        marketName: normalizeText(m?.marketName),
                        marketType: normalizeMarketType(m?.mname)
                    });
                });

                if (market_type === 'TIED_MATCH' || market_type === 'Tied Match') {

                    console.log('Matching TIED_MATCH');

                    matchedMarket = markets.find(m => {
                        const marketType = normalizeMarketType(m?.mname);

                        console.log('Compare Type:', marketType, inputMarketType);

                        return marketType === inputMarketType;
                    });

                }
                else if (gameType === 'FAN' && (Number(sport_id) === 1 || Number(sport_id) === 2)) {
                    console.log('gameType === FAN && (sport_id === 1 || sport_id === 2)');
                    console.log('gameType', gameType);

                    const inputEventName = normalizeText(eventName);
                    const inputMname = normalizeMarketType(market_type);
                    console.log('inputEventName', inputEventName);
                    console.log('inputMname', inputMname);

                    // Match on event name (ename) + market type (mname). marketName here
                    // is the market description (e.g. "UNDER 0.5 GOALS VS OVER 0.5 GOALS"),
                    // NOT the event name, so comparing it to inputEventName never matched.
                    matchedMarket = markets.find(m =>
                        normalizeText(m?.ename) === inputEventName &&
                        normalizeMarketType(m?.mname) === inputMname
                    );
                }
                else if (gameType === 'FAN') {

                    console.log('Matching FAN market');

                    matchedMarket = markets.find(m => {

                        const apiMarketName = normalizeText(m?.marketName);
                        const apiMarketType = normalizeMarketType(m?.mname);

                        console.log('Compare:', {
                            apiMarketName,
                            inputMarketName,
                            apiMarketType,
                            inputMarketType
                        });

                        return (
                            apiMarketName === inputMarketName &&
                            apiMarketType === inputMarketType
                        );
                    });

                }
                else {

                    console.log('Matching DEFAULT market');

                    const inputEventName = normalizeText(eventName);
                    const inputMname = normalizeMarketType(market_type);

                    matchedMarket = markets.find(m => {

                        const apiMarketName = normalizeText(m?.ename); // natname
                        const apiMarketType = normalizeMarketType(m?.mname);

                        console.log('Compare Default:', {
                            apiMarketName,
                            inputEventName,
                            apiMarketType,
                            inputMname
                        });

                        return (
                            apiMarketName === inputEventName &&
                            apiMarketType === inputMname
                        );
                    });
                }

                console.log('Matched Market:', matchedMarket);

                const declared = matchedMarket?.status === 'SETTLE';

                return {
                    declared,
                    items: matchedMarket ? [matchedMarket] : [],
                    meta: {
                        success: data?.success,
                        total: data?.total,
                        page: data?.page,
                        limit: data?.limit,
                        pages: data?.pages
                    }
                };
            }

            // 404 => result not published yet. Don't retry; treat as not declared
            // (the cron will re-check next cycle).
            if (res.status === 404) {
                console.log('[ResultCron] 404 - result not declared yet', { eventid });
                return { declared: false, items: [] };
            }

            if (res.status === 429 || (res.status >= 500 && res.status <= 599)) {

                const ra = parseRetryAfter(res.headers?.['retry-after']);
                const wait = ra != null
                    ? ra
                    : jitter(RESULTS_RETRY_BASE_MS * Math.pow(2, attempt - 1));

                console.log('[ResultCron] RETRY BACKOFF', {
                    attempt,
                    status: res.status,
                    waitMs: wait
                });

                await sleep(wait);
                continue;
            }

            return { declared: false, items: [] };

        } catch (e) {

            const wait = jitter(RESULTS_RETRY_BASE_MS * Math.pow(2, attempt - 1));

            console.log('[ResultCron] ERROR', {
                attempt,
                error: e.message,
                nextWaitMs: wait
            });

            await sleep(wait);
        }
    }

    console.log('[ResultCron] MAX RETRIES EXHAUSTED', { eventid });

    return { declared: false, items: [] };
}

// ---------- CLEANUP ----------

async function pruneSummaries() {

    await pg.query(`
        DELETE FROM sports_event_result_summary
        WHERE recorded_at < NOW() - INTERVAL '${SUMMARY_RETENTION_DAYS} days'
    `)

}

async function pruneBetCache() {

    await pg.query(`
        DELETE FROM sports_bet_result_cache
        WHERE recorded_at < NOW() - INTERVAL '${BET_CACHE_TTL_DAYS} days'
    `)

}


// ---------- MAIN RUN ----------

async function runOnce() {

    log.info('[ResultCron] ===== Run start =====')
    console.log("hellotest start");

    try {

        const { rows: allBets } = await pg.query(`
            SELECT 
            id,user_id,game_type,bet_type,selection_name,odds,stake_amount,
            match_title,match_id,fancy_name,eventid,created_at,
            sport_id,market_type,status
            FROM "SportsBet"
            WHERE status IN ('open','manual')
            AND game_type IN ('MO','BM','FAN')
            AND eventid IS NOT NULL
            ORDER BY created_at ASC
        `)

        if (!allBets.length) {
            log.info('[ResultCron] no open bets.')
            return
        }

        // console.log("rows", rows);
        //console.log("allbets>>>>>>>>>>>>>>", allBets);

        for (const b of allBets) {

            try {


                const userId = b.user_id
                const eid = b.eventid
                const eventName = b.match_title || ''
                const gameType = (b.game_type || '').toUpperCase()

                const sport_id = b.sport_id
                const market_type = b.market_type

                let marketName = b.selection_name || ''

                if (gameType === "MO") marketName = "Match_Odds"
                if (gameType === "BM") marketName = "BookMaker"

                let declared = false
                let result_meta = null

                if (b.status === "manual") {

                    declared = true

                } else {

                    const res = await fetchResultForEvent(
                        eid,
                        eventName,
                        b.match_id,
                        marketName,
                        sport_id,
                        market_type,
                        gameType
                    )

                    declared = res?.declared
                    result_meta = res?.meta

                    console.log("declared", declared);

                }

                const counts = { total: 1 }

                await pg.query(`
                    INSERT INTO sports_event_result_scan
                    (user_id,eventid,declared,counts,checked_at)
                    VALUES ($1,$2,$3,$4,$5)
                    ON CONFLICT (user_id,eventid)
                    DO UPDATE SET
                    declared=EXCLUDED.declared,
                    counts=EXCLUDED.counts,
                    checked_at=EXCLUDED.checked_at
                `, [
                    userId,
                    eid,
                    declared,
                    JSON.stringify(counts),
                    new Date()
                ])


                await pg.query(`
                    INSERT INTO sports_event_result_summary
                    (user_id,eventid,declared,counts,result_meta,sections,recorded_at)
                    VALUES ($1,$2,$3,$4,$5,$6,$7)
                `, [
                    userId,
                    eid,
                    declared,
                    JSON.stringify(counts),
                    result_meta ? JSON.stringify(result_meta) : null,
                    JSON.stringify({ bets: [b] }),
                    new Date()
                ])


                if (declared) {

                    const betIdStr = String(b.id)
                    const betType = (b.bet_type || '').toLowerCase()

                    const payload = {
                        user_id: userId,
                        eventid: eid,
                        bet_id: betIdStr,
                        bet_type: betType,
                        bet: b
                    }

                    const jobId = uuidv4()

                    const { rows } = await pg.query(`
                        INSERT INTO sports_event_settlement_jobs
                        (job_id,user_id,eventid,bet_id,bet_type,status,priority,run_after,payload,created_at,updated_at)
                        VALUES ($1,$2,$3,$4,$5,'queued',5,NOW(),$6,NOW(),NOW())
                        ON CONFLICT (user_id,eventid,bet_id)
                        DO UPDATE SET updated_at=NOW()
                        RETURNING job_id
                    `, [
                        jobId,
                        userId,
                        eid,
                        betIdStr,
                        betType,
                        JSON.stringify(payload)
                    ])

                    const realJobId = rows[0].job_id


                    await pg.query(`
                        UPDATE "SportsBet"
                        SET job_id=$1
                        WHERE id=$2
                        AND user_id=$3
                        AND eventid=$4
                        AND status IN ('open','manual')
                    `, [
                        realJobId,
                        b.id,
                        userId,
                        eid
                    ])

                }

            } catch (err) {

                log.error('[ResultCron] error processing bet', {
                    betId: b.id,
                    error: err.message
                })

            }

        }

        await pruneSummaries()
        await pruneBetCache()

    } catch (e) {

        log.error('[ResultCron] fatal', { error: e.message })

    }

    log.info('[ResultCron] ===== Run end =====')

}


// ---------- CRON ----------

function startCron() {

    log.info('[ResultCron] Scheduler starting...')

    runOnce()

    setInterval(runOnce, CRON_INTERVAL_MS)

}


// start automatically
startCron()


module.exports = {
    startCron,
    runOnce
}