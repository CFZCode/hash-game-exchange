const { sidArray } = require("../config/sid");
const { fetchSportsData } = require("../helper/apihelper");
const { set, getCommonData, setCommonData } = require('../../General/Model/RedisMiddleware')

const ENV = require("../config/env");

const SPORTS_API_KEY = ENV.SPORTS_API_KEY


const INTERVAL_SECONDS = 2;
const REDIS_TTL = 5;

let isRunning = false;


const runAllEventsCron = async () => {
    if (isRunning) return;

    const startTime = Date.now();
    isRunning = true;

    try {
        const activeSports = sidArray.filter((sport) => sport.active);

        const getMatchesPromises = activeSports.map(async (sport) => {
            const sportId = sport.eid;

            try {
                const cached = await getCommonData(`alleventsData:${sportId}`);

                if (!cached) return { sportId, gmids: [] };

                const parsed = JSON.parse(cached);

                const allMatches = [
                    ...(Array.isArray(parsed?.t1) ? parsed.t1 : []),
                    ...(Array.isArray(parsed?.t2) ? parsed.t2 : [])
                ];

                const gmids = [
                    ...new Set(
                        allMatches
                            .filter(m => m && m.gmid)
                            .map(m => m.gmid)
                    )
                ];

                return { sportId, gmids };

            } catch (err) {
                console.error(`❌ Redis get failed for sport ${sportId}:`, err.message);
                return { sportId, gmids: [] };
            }
        });

        const sportsWithGmids = await Promise.all(getMatchesPromises);

        const allOddsPromises = [];

        for (const { sportId, gmids } of sportsWithGmids) {
            if (!gmids || gmids.length === 0) continue;

            for (const gmid of gmids) {

                const promise = (async () => {

                    const endpoint = `gamedataPrivate?gmid=${gmid}&etid=${sportId}&key=${SPORTS_API_KEY}`;

                    try {
                        const response = await fetchSportsData(endpoint);

                        // console.log("::::::::::;>>>>>>>>>>>::", response)

                        //const oddsData = response?.data?.data?.odds?.[gmid];
                        const oddsData = response?.data?.data;


                        if (Array.isArray(oddsData) && oddsData.length > 0) {

                            await setCommonData(
                                `oddsData:${gmid}`,
                                REDIS_TTL,
                                JSON.stringify(oddsData)
                            );

                            return {
                                sportId,
                                gmid,
                                success: true,
                                hasData: true
                            };
                        }

                        return {
                            sportId,
                            gmid,
                            success: true,
                            hasData: false
                        };

                    } catch (err) {

                        console.error(
                            `❌ Odds API failed for ${sportId} gmid ${gmid}:`,
                            err.message
                        );

                        return {
                            sportId,
                            gmid,
                            success: false
                        };
                    }

                })();

                allOddsPromises.push(promise);
            }
        }

        const oddsResults = await Promise.allSettled(allOddsPromises);

        const totalCalls = allOddsPromises.length;

        const successful = oddsResults.filter(
            r => r.status === "fulfilled" && r.value?.success
        );

        const withData = oddsResults.filter(
            r => r.status === "fulfilled" && r.value?.hasData
        );

        const failed = oddsResults.filter(
            r => r.status === "rejected" || !r.value?.success
        );

        const processingTime = Date.now() - startTime;

        console.log(
            `⚡ ${totalCalls} API calls | ${processingTime}ms | ` +
            `✅ ${successful.length} success (${withData.length} with odds) | ` +
            `❌ ${failed.length} failed`
        );

        if (processingTime > 2500) {
            console.warn(
                `⚠️ Processing took ${processingTime}ms - slower than interval!`
            );
        }

    } catch (err) {
        console.error("❌ Cron error:", err.message);
    } finally {
        isRunning = false;
    }
};


runAllEventsCron();
setInterval(runAllEventsCron, INTERVAL_SECONDS * 1000);
