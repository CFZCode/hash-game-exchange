
// Global error handlers
process.on('uncaughtException', (err) => {
    console.error('[Settlement] Uncaught Exception:', err);
    process.exit(1);
});

process.on('unhandledRejection', (err) => {
    console.error('[Settlement] Unhandled Rejection:', err);
    process.exit(1);
});
const fs = require('fs');
const path = require('path');
const cron = require('node-cron');
const http = require('http');
const https = require('https');
const axios = require('axios');
const { pool: pg } = require('../../General/Model/pool'); // self-healing Pool: a bare Client dies permanently if Postgres restarts (see 2026-08-24 outage)



//const sequelize = require('../../config/db');


console.log('[Settlement] Process started');

// ==== Config ====
const DEBUG = process.env.DEBUG === '1' || process.env.DEBUG === 'true';
const BATCH_LIMIT = +(process.env.SETTLE_BATCH_LIMIT || 10);
const RESULTS_API_BASE = process.env.RESULTS_API_BASE || 'https://diamond-result-v2.avrkhub.in/get_result' //'https://apilords.codefactory.games/api';
const API_TIMEOUT_MS = +(process.env.API_TIMEOUT_MS || 30000);
const LEDGER_ZERO_ROWS = process.env.LEDGER_ZERO_ROWS === '1' || process.env.LEDGER_ZERO_ROWS === 'true';
const LOG_DIR = process.env.SETTLEMENT_LOG_DIR || path.join(process.cwd(), 'sportsbet/betresult/logs');
const LOG_BASENAME = 'settlement-worker-v2_3_2';
const CRON_SCHEDULE = process.env.CRON_SCHEDULE || '*/1 * * * *';
const CRON_TZ = process.env.CRON_TZ || 'UTC';
const CRON_IMMEDIATE = process.env.CRON_IMMEDIATE === '1' || process.env.CRON_IMMEDIATE === 'true';
const MAX_CONCURRENT_API = +(process.env.MAX_CONCURRENT_API || 3);
// Jobs left in 'processing' longer than this (worker crash/restart mid-run) are
// reclaimed by pollOnce instead of being orphaned forever.
const STALE_PROCESSING_MIN = +(process.env.SETTLE_STALE_PROCESSING_MIN || 5);
const RESULTS_RATE_LIMIT_MS = +(process.env.RESULTS_RATE_LIMIT_MS || 250);
const RESULTS_MAX_FETCH_RETRIES = +(process.env.RESULTS_MAX_FETCH_RETRIES || 6);
const RESULTS_RETRY_BASE_MS = +(process.env.RESULTS_RETRY_BASE_MS || 500);
const RESULTS_FORCE_IPV4 = process.env.RESULTS_FORCE_IPV4 === '1' || process.env.RESULTS_FORCE_IPV4 === 'true';
const RESULTS_DISABLE_KEEPALIVE = process.env.RESULTS_DISABLE_KEEPALIVE === '1' || process.env.RESULTS_DISABLE_KEEPALIVE === 'true';
const USER_AGENT = process.env.USER_AGENT || `settlement-worker/2.3.2 (+node ${process.version})`;

const marketsfornonfancy = [
    'Game Winner 1/2',
    'OVER_UNDER_35',
    'OVER_UNDER_25',
    'OVER_UNDER_15',
    'OVER_UNDER_05',
    'Under/Over 5.5',
    'Under/Over 0.5',
    'Under/Over 1.5',
    'Under/Over 2.5',
    'Under/Over 3.5',
    'Under/Over 4.5',
    'Under/Over 6.5',
    '2nd Period Winner',
    '1st Period Winner',
    '3rd Period Winner',
    'Next Goal 1.0',
    'Next Goal 2.0',
    'Next Goal 3.0',
    'Next Goal 4.0',
    'Next Goal 5.0',
    'Next Goal 6.0',
    'Next Goal 7.0',
    'Next Goal 8.0',
    'Next Goal 9.0',
    'Next Goal 10.0',
    'HALF_TIME',
    'Match Time Result 70:00',
    'Match Time Result 10:00',
    'Match Time Result 30:00',
    'Match Time Result 20:00',
    'Match Time Result 40:00',
    'Match Time Result 60:00',
    'Match Time Result 50:00',
    'Match Time Result 70:00',
    'Match Time Result 80:00',
    'Match Time Result 90:00',
    'Game Winner 1/1',
    'Game Winner 1/2',
    'Game Winner 1/3',
    'Game Winner 1/4',
    'Game Winner 2/2',
    'Game Winner 2/3',
    'Game Winner 2/4',
    'Game Winner 3/3',
    'Game Winner 3/4',
    'Game Winner 4/4',
    'Game Winner 2/7',
    'Game Winner 3/7',
    'Game Winner 4/7',
    'Game Winner 5/7',
    'Game Winner 6/7',
    'Game Winner 7/7',
    '1st Set Winner Home/Away',
    '2nd Set Winner Home/Away',
    '3rd Set Winner Home/Away',
    '4th Set Winner Home/Away',
    '5th Set Winner Home/Away',
    '1st Set Race To 4.0',
    '2nd Set Race To 4.0',
    '3rd Set Race To 4.0',
    '4th Set Race To 4.0',
    '5th Set Race To 4.0',
    'Point Winner 1/3/1',
    'Point Winner 1/3/2',
    'Point Winner 1/3/3',
    'Point Winner 1/2/1',
    'Point Winner 1/1/1',
    'Point Winner 2/3/1',
    'Point Winner 2/3/2',
    'Point Winner 2/3/3',
    'Point Winner 2/2/1',
    'Point Winner 2/2/2',
    'Point Winner 2/1/1',
    'Point Winner 3/3/1',
    'Point Winner 3/3/2',
    'Point Winner 3/3/3',
    'Point Winner 3/2/1',
    'Point Winner 3/2/2',
    'Point Winner 3/2/3',
    'Point Winner 3/1/1',
    'Point Winner 3/1/2',
    'Point Winner 3/1/3',
    'Point Winner 4/4/1',
    'Point Winner 4/4/2',
    'Point Winner 4/4/3',
    'Point Winner 4/4/4',
    'Point Winner 4/3/1',
    'Point Winner 4/3/2',
    'Point Winner 4/3/3',
    'Point Winner 4/3/4',
    'Point Winner 4/2/1',
    'Point Winner 4/2/2',
    'Point Winner 4/2/3',
    'Point Winner 4/2/4',
    'Point Winner 4/1/1',
    'Point Winner 4/1/2',
    'Point Winner 4/1/3',
    'Point Winner 4/1/4',
];

function isNonFancyMarket(market_type) {

    // 1️⃣ fixed names
    if (fixedNonFancyMarkets.includes(market_type)) {
        return true;
    }

    // 2️⃣ Game Winner X/Y
    if (/^Game Winner\s+(?:[1-9]|1\d|20)\/(?:[1-9]|1\d|20)$/.test(market_type)) {
        return true;
    }

    // 3️⃣ Match Time Result 10:00, 70:00, etc
    if (/^Match Time Result\s+\d{2}:\d{2}$/.test(market_type)) {
        return true;
    }

    // 4️⃣ Set Race To 1.0 – 15.0 (all sets)
    if (/^\d+(?:st|nd|rd|th)\s+Set Race To\s+(?:[1-9]|1[0-5])\.0$/.test(market_type)) {
        return true;
    }
    if (/^TEAM_[A-Z]+_\d+$/.test(market_type)) {
        return true;
    }

    // 5️⃣ Under/Over 0.5 , 1.5 , 180s etc
    if (/^Under\/Over(?: 180s)?\s+\d+(\.\d)?$/.test(market_type)) {
        return true;
    }

    // 6️⃣ Total Tie Break in the Match X.X
    if (/^Total Tie Break in the Match\s+\d+(\.\d)?$/.test(market_type)) {
        return true;
    }

    // 7️⃣ Point Winner A/B/C
    if (/^Point Winner\s+(?:[1-9]|1\d|20)\/(?:[1-9]|1\d|20)\/(?:[1-9]|1\d|20)$/.test(market_type)) {
        return true;
    }

    // 8️⃣ Game To Deuce A/B   (your current list)
    if (/^Game To Deuce\s+(?:[1-9]|1\d|20)\/(?:[1-9]|1\d|20)$/.test(market_type)) {
        return true;
    }

    // 9️⃣ Game To Deuce A/B/C (future support – as you mentioned before)
    if (/^Game To Deuce\s+(?:[1-9]|1\d|20)\/(?:[1-9]|1\d|20)\/(?:[1-9]|1\d|20)$/.test(market_type)) {
        return true;
    }

    // 🔟 Next Goal X.0
    if (/^Next Goal\s+\d+(\.\d)?$/.test(market_type)) {
        return true;
    }

    return false;
}
async function updateStaffParentBalUp(staffId, amount, transaction = null) {
    if (!staffId) return;

    console.log(`[DEBUG] updateStaffParentBalUp called for staffId: ${staffId}, amount: ${amount}`);

    // Staff balances live in staff_balances (inr), keyed by staff_id — NOT in the
    // staff table (which has neither staff_id nor a balance column).
    const query = `
        UPDATE staff_balances
        SET inr = inr + $1
        WHERE staff_id = $2
    `;

    if (transaction) {
        await transaction.query(query, [amount, staffId]);
    } else {
        await pg.query(query, [amount, staffId]);
    }
}

const fixedNonFancyMarkets = [
    'OVER_UNDER_55',
    'OVER_UNDER_45',
    'OVER_UNDER_35',
    'OVER_UNDER_25',
    'OVER_UNDER_15',
    'OVER_UNDER_05',
    'OVER_UNDER_10',
    'Match Result/Both Teams to score',
    'HT/FT',
    '1X2 Corners',
    'CORRECT_SCORE',

    '2nd Period Winner',
    'BOTH_TEAMS_TO_SCORE',
    '1st Period Winner',


    '3rd Period Winner',

    'Both Teams To Score',

    'DRAW_NO_BET',
    'Draw No Bet',

    'HALF_TIME',

    '1st Set Winner Home/Away',
    '2nd Set Winner Home/Away',
    '3rd Set Winner Home/Away',
    '4th Set Winner Home/Away',
    '5th Set Winner Home/Away',

    '1st Set Winner',
    '2nd Set Winner',
    '3rd Set Winner',
    '4th Set Winner',
    '5th Set Winner',
    '6th Set Winner',

    '1st Half Winner',
    '2nd Half Winner',
    '3rd Half Winner',
    '4th Half Winner',
    '5th Half Winner',
    '6th Half Winner',

    '1st Quarter Winner',
    '2nd Quarter Winner',
    '3rd Quarter Winner',
    '4th Quarter Winner',
    '5th Quarter Winner',
    '6th Quarter Winner',

    'Tied Match',
    'TIED_MATCH'
];

const marketsfor01fancy = [
    'TIED_MATCH',
    'Tied Match',
    'Game To Deuce 1/1',
    'Game To Deuce 1/2',
    'Game To Deuce 1/3',
    'Game To Deuce 1/4',
    'Game To Deuce 2/1',
    'Game To Deuce 2/2',
    'Game To Deuce 2/3',
    'Game To Deuce 2/4',
    'Game To Deuce 3/1',
    'Game To Deuce 3/2',
    'Game To Deuce 3/3',
    'Game To Deuce 3/4',
    'Game To Deuce 4/1',
    'Game To Deuce 4/2',
    'Game To Deuce 4/3',
    'Game To Deuce 4/4',
    'Both Teams To Score',
    'Match Result/Both Teams to score'

];

// ==== Logging ====
function ensureLogDir() {
    try {
        fs.mkdirSync(LOG_DIR, { recursive: true });
        console.log('[Settlement] Log directory ensured:', LOG_DIR);
    } catch (e) {
        console.error('[Settlement] Failed to create log directory:', e.message);
    }
}
ensureLogDir();
function currentLogPath() {
    const d = new Date(), yyyy = d.getFullYear(), mm = String(d.getMonth() + 1).padStart(2, '0'), dd = String(d.getDate()).padStart(2, '0');
    return path.join(LOG_DIR, `${LOG_BASENAME}-${yyyy}-${mm}-${dd}.log`);
}
function writeLog(level, msg, ctx = {}) {
    const ctxStr = Object.keys(ctx).length ? ' ' + JSON.stringify(ctx) : '';
    const line = `[${new Date().toISOString()}] [${level}] ${msg}${ctxStr}\n`;
    if (level === 'ERROR') console.error(msg, ctx); else console.log(msg, ctx);
    try {
        fs.appendFileSync(currentLogPath(), line, 'utf8');
    } catch (e) {
        console.error('[Settlement] Log write failed:', e.message);
    }
}
const log = {
    info: (m, c = {}) => writeLog('INFO', m, c),
    error: (m, c = {}) => writeLog('ERROR', m, c),
    debug: (m, c = {}) => { if (DEBUG) writeLog('DEBUG', m, c); },
};

// ==== Utils ====
const nowIso = () => new Date().toISOString();
const lower = (s) => (s || '').toString().trim().toLowerCase();
const norm = (s) => (s || '').toString().toLowerCase().replace(/\s+/g, ' ').replace(/[^\w\s]/g, '').trim();
const num = (x) => { const n = Number(x); return Number.isFinite(n) ? n : 0; };

// The SAME runner reaches us under three different spellings:
//   event title (team_one/team_two) : "Struff"            / "Alek Shevchenko"
//   result feed (winnerName)        : "Jan-Lennard Struff "
//   bet row (selection_name/runners): "Jan-Lennard Struff " / "Alexander Shevchenko"
// Comparing those with `norm(a) === norm(b)` makes selIsWinner false for BOTH sides,
// which silently settles the whole market inverted (backs lose, lays win) and makes
// the exposure lookup return 0 so nothing is credited back to the wallet.
// Every winner<->selection / winner<->team comparison must go through these helpers.
function namesMatch(a, b) {
    const x = norm(a), y = norm(b);
    if (!x || !y) return false;
    if (x === y) return true;
    if (x.startsWith(y) || y.startsWith(x)) return true;
    return x.includes(y) || y.includes(x);
}
function matchesAny(names, target) {
    const list = Array.isArray(names) ? names : [names];
    return list.some(n => namesMatch(n, target));
}
// `runners` is a jsonb array of the exact names the bets were placed on.
function runnerList(bet) {
    let r = bet?.runners;
    if (typeof r === 'string') { try { r = JSON.parse(r); } catch (e) { r = null; } }
    return Array.isArray(r) ? r.filter(x => typeof x === 'string' && x.trim()) : [];
}
// Best runner for `name`: exact beats prefix beats substring, so a generic
// fragment can't steal the wrong runner when a closer one exists.
function pickRunner(runners, name) {
    const t = norm(name);
    if (!t || !runners.length) return null;
    for (const r of runners) if (norm(r) === t) return r;
    for (const r of runners) { const n = norm(r); if (n.startsWith(t) || t.startsWith(n)) return r; }
    for (const r of runners) { const n = norm(r); if (n.includes(t) || t.includes(n)) return r; }
    return null;
}
// All the aliases each side of a two-way market is known by, so exposure keys
// (written under the runner name) resolve from a bet row that only carries the
// short title name — and vice versa.
function sideAliases(bet) {
    const runners = runnerList(bet);
    const one = [bet?.team_one].filter(Boolean);
    const two = [bet?.team_two].filter(Boolean);
    if (runners.length === 2) {
        const r1 = pickRunner(runners, bet.team_one);
        const r2 = pickRunner(runners, bet.team_two);
        if (r1) one.push(r1);
        if (r2 && r2 !== r1) two.push(r2);
        // Only one side matched by name ("Alek Shevchenko" vs "Alexander Shevchenko"
        // matches nothing) — the leftover runner has to be the other side.
        if (r1 && !r2) { const rest = runners.find(r => r !== r1); if (rest) two.push(rest); }
        if (!r1 && r2) { const rest = runners.find(r => r !== r2); if (rest) one.push(rest); }
    }
    return { one, two, runners };
}
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function jitter(ms) { return Math.round(ms * (1 + Math.random() * 0.25)); }
function peekBody(data, max = 200) {
    try {
        const s = typeof data === 'string' ? data : JSON.stringify(data);
        return s.slice(0, max);
    } catch { return ''; }
}
function parseRetryAfter(h) {
    if (!h) return null;
    const n = Number(h);
    if (!Number.isNaN(n)) return Math.max(0, Math.round(n * 1000));
    const d = Date.parse(h);
    return Number.isNaN(d) ? null : Math.max(0, d - Date.now());
}
function formatName(name) {
    return (name || '').replace(/\s+/g, '').toLowerCase();
}

// ==== API Setup ====
const httpAgent = new http.Agent({ keepAlive: !RESULTS_DISABLE_KEEPALIVE, family: RESULTS_FORCE_IPV4 ? 4 : undefined });
const httpsAgent = new https.Agent({ keepAlive: !RESULTS_DISABLE_KEEPALIVE, family: RESULTS_FORCE_IPV4 ? 4 : undefined });
const ax = axios.create({
    timeout: API_TIMEOUT_MS,
    httpAgent, httpsAgent,
    validateStatus: () => true,
    headers: {
        'Accept': 'application/json',
        'User-Agent': USER_AGENT
    }
});
let lastApiCallAt = 0;
async function globalRateLimit() {
    const gap = RESULTS_RATE_LIMIT_MS > 0 ? RESULTS_RATE_LIMIT_MS : 0;
    const now = Date.now();
    const wait = Math.max(0, lastApiCallAt + gap - now);
    if (wait) await sleep(wait);
    lastApiCallAt = Date.now();
}
class AsyncQueue {
    constructor(max) { this.max = max; this.running = 0; this.q = []; }
    push(task) { return new Promise((res, rej) => { this.q.push({ task, res, rej }); this._next(); }); }
    _next() {
        if (this.running >= this.max) return;
        const n = this.q.shift(); if (!n) return;
        this.running++;
        n.task().then(n.res, n.rej).finally(() => { this.running--; this._next(); });
    }
}


const apiQueue = new AsyncQueue(MAX_CONCURRENT_API);
function buildPerAttemptConfig(attempt) {
    if (attempt >= 3) {
        return {
            httpAgent: new http.Agent({ keepAlive: false, family: 4 }),
            httpsAgent: new https.Agent({ keepAlive: false, family: 4 }),
            headers: { 'Connection': 'close' }
        };
    }
    return {};
}

// helper 

function normalizeText(v) {
    if (!v) return '';
    return String(v)
        .trim()
        .toUpperCase()
        .replace(/\s+/g, ' ');
}
function normalizeMarketType(v) {
    if (!v) return '';
    return String(v).trim().toUpperCase();
}

// ==== API Layer ====
async function fetchResultForEvent(eventid, eventName, marketId, marketName, sport_id, market_type, gameType) {
    log.debug('[Settlement] fetchResultForEvent start', { eventid, eventName, marketId, marketName });
    const maxAttempts = RESULTS_MAX_FETCH_RETRIES || 6;
    const url = RESULTS_API_BASE;

    return apiQueue.push(async () => {
        for (let attempt = 1; attempt <= maxAttempts; attempt++) {
            try {
                await globalRateLimit();

                const res = await ax.get(
                    url,
                    {
                        params: { sid: sport_id, gmid: eventid },
                        ...buildPerAttemptConfig(attempt)
                    }
                );

                log.debug('[ResultCron] fetchResultForEvent response', {
                    eventid,
                    attempt,
                });

                if (res.status === 200) {
                    const data = typeof res?.data === 'string'
                        ? JSON.parse(res.data)
                        : res.data;

                    const markets = Array.isArray(data?.markets) ? data.markets : [];


                    let matchedMarket;

                    const inputMarketName = normalizeText(marketName);
                    const inputMarketType = normalizeMarketType(market_type);


                    const inputEventName = normalizeText(eventName);
                    const inputMname = normalizeMarketType(market_type);

                    matchedMarket = markets.find(m =>

                        normalizeMarketType(m?.mname) === inputMname
                    );




                    const declared = matchedMarket?.status === 'SETTLE';

                    return {
                        declared,
                        items: matchedMarket ? [matchedMarket] : [],
                        meta: {
                            success: data?.success,
                            total: data?.total,
                            page: data?.page,
                            limit: data?.limit,
                            pages: data?.pages
                        }
                    };

                }

                // Retry only on rate-limit or server errors
                if (res.status === 429 || (res.status >= 500 && res.status <= 599)) {
                    const ra = parseRetryAfter(res.headers?.['retry-after']);
                    const wait = ra != null ? ra : jitter(RESULTS_RETRY_BASE_MS * Math.pow(2, attempt - 1));
                    log.debug('[ResultCron] fetchResultForEvent retry backoff', {
                        eventid,
                        attempt,
                        status: res.status,
                        waitMs: wait,
                    });
                    await sleep(wait);
                    continue;
                }

                return { declared: false, items: [] };
            } catch (e) {
                const wait = jitter(RESULTS_RETRY_BASE_MS * Math.pow(2, attempt - 1));
                log.error('[ResultCron] fetchResultForEvent error', {
                    eventid,
                    attempt,
                    error: e.message,
                    nextWaitMs: wait,
                });
                await sleep(wait);
            }
        }

        log.debug('[ResultCron] fetchResultForEvent exhausted', { eventid });
        return { declared: false, items: [] };
    });
}

// api layer for events but fancy 
async function fetchResultForEventFancy(eventid, eventName, marketId, selection_name, sport_id, market_type) {
    log.debug('[Settlement] fetchResultForEvent start', { eventid, eventName, marketId, selection_name });
    const maxAttempts = RESULTS_MAX_FETCH_RETRIES || 6;
    const url = RESULTS_API_BASE;

    return apiQueue.push(async () => {
        for (let attempt = 1; attempt <= maxAttempts; attempt++) {
            try {
                await globalRateLimit();

                const res = await ax.get(
                    url,
                    {
                        params: { sid: sport_id, gmid: eventid },
                        ...buildPerAttemptConfig(attempt)
                    }
                );

                log.debug('[ResultCron] fetchResultForEvent response', {
                    eventid,
                    attempt,
                });

                if (res.status === 200) {
                    const data = typeof res?.data === 'string'
                        ? JSON.parse(res.data)
                        : res.data;

                    const markets = Array.isArray(data?.markets) ? data.markets : [];

                    // console.log('markets', markets);

                    let matchedMarket;

                    const inputMarketName = normalizeText(selection_name);
                    const inputMarketType = normalizeMarketType(market_type);
                    if (market_type === 'TIED_MATCH' || market_type === 'Tied Match') {
                        matchedMarket = markets.find(m =>
                            normalizeMarketType(m?.mname) === inputMarketType
                        );

                    }
                    else if (Number(sport_id) === 1 || Number(sport_id) === 2) {
                        console.log('gameType === FAN && (sport_id === 1 || sport_id === 2)');


                        const inputEventName = normalizeText(eventName);
                        const inputMname = normalizeMarketType(market_type);
                        console.log('inputEventName', inputEventName);
                        console.log('inputMname', inputMname);

                        // Match on event name (ename) + market type (mname). marketName
                        // is the market description (e.g. "UNDER 0.5 GOALS VS OVER 0.5 GOALS"),
                        // NOT the event name, so comparing it to inputEventName never matched.
                        matchedMarket = markets.find(m =>
                            normalizeText(m?.ename) === inputEventName &&
                            normalizeMarketType(m?.mname) === inputMname
                        );
                    }
                    else {
                        matchedMarket = markets.find(m =>
                            normalizeText(m?.marketName) === inputMarketName &&
                            normalizeMarketType(m?.mname) === inputMarketType
                        );
                    }





                    const declared = matchedMarket?.status === 'SETTLE';

                    return {
                        declared,
                        items: matchedMarket ? [matchedMarket] : [],
                        meta: {
                            success: data?.success,
                            total: data?.total,
                            page: data?.page,
                            limit: data?.limit,
                            pages: data?.pages
                        }
                    };

                }

                // Retry only on rate-limit or server errors
                if (res.status === 429 || (res.status >= 500 && res.status <= 599)) {
                    const ra = parseRetryAfter(res.headers?.['retry-after']);
                    const wait = ra != null ? ra : jitter(RESULTS_RETRY_BASE_MS * Math.pow(2, attempt - 1));
                    log.debug('[ResultCron] fetchResultForEvent retry backoff', {
                        eventid,
                        attempt,
                        status: res.status,
                        waitMs: wait,
                    });
                    await sleep(wait);
                    continue;
                }

                return { declared: false, items: [] };
            } catch (e) {
                const wait = jitter(RESULTS_RETRY_BASE_MS * Math.pow(2, attempt - 1));
                log.error('[ResultCron] fetchResultForEvent error', {
                    eventid,
                    attempt,
                    error: e.message,
                    nextWaitMs: wait,
                });
                await sleep(wait);
            }
        }

        log.debug('[ResultCron] fetchResultForEvent exhausted', { eventid });
        return { declared: false, items: [] };
    });
}

// Helper to fetch manual result from DB
async function fetchManualResult(eventid, match_id, game_type, market_type, selection_name, transaction = null) {
    log.debug('[Settlement] fetchManualResult start', { eventid, match_id, game_type, market_type, selection_name });

    console.log("::::::::::::::::::::>>MAnual Settttt>>>>>>>>>>>>>", { eventid, match_id, game_type, market_type, selection_name })

    try {
        let params = [
            String(eventid),
            String(match_id),
            String(game_type),
            String(market_type)
        ];

        let query = `
            SELECT *
            FROM mannual_result
            WHERE eventid = $1
            AND match_id = $2
            AND game_type = $3
            AND market_type = $4
        `;

        const marketsforfancyCheck = [
            '1st Innings 6 Overs Line',
            '2nd Innings 6 Overs Line',
            '3rd Innings 6 Overs Line',
            '1st Innings 50 Overs Line',
            '2nd Innings 50 Overs Line',
            '3rd Innings 50 Overs Line',
            '1st Innings 40 Overs Line',
            '2nd Innings 40 Overs Line',
            '3rd Innings 40 Overs Line',
            '1st Innings 30 Overs Line',
            '2nd Innings 30 Overs Line',
            '3rd Innings 30 Overs Line',
            '1st Innings 20 Overs Line',
            '2nd Innings 20 Overs Line',
            '3rd Innings 20 Overs Line',
            '1st Innings 10 Overs Line',
            '2nd Innings 10 Overs Line',
            '3rd Innings 10 Overs Line',
            'Over By Over',
            'Ball By Ball',
            'Normal',
            'khado',
            'meter',
            'fancy1',
            'oddeven'
        ];

        if (game_type === 'FAN') {
            if (marketsforfancyCheck.includes(market_type) && selection_name) {
                query += ` AND "fancyName" = $5`;
                params.push(selection_name);
            }
        }

        query += ` ORDER BY created_at DESC LIMIT 1`;

        let result;

        result = await pg.query(query, params);

        console.log("::::::::::::::::::::>>MAnual result>>>>>>>>>>>>>", result)


        const manualRes = result?.rows?.[0];
        console.log("::::::::::::::::::::>>MAnual 2222222222>>>>>>>>>>>>>", manualRes)


        if (!manualRes) {
            log.info('[Settlement] Manual result not found', { eventid, match_id, game_type, market_type });
            return { declared: false, items: [] };
        }

        log.debug('[Settlement] Manual result found', {
            id: manualRes.id,
            winnerName: manualRes.winnerName,
            winnerId: manualRes.winnerId,
            final_result: manualRes.winnerName
        });

        const item = {
            winnerName: manualRes.winnerName,
            winnerId: manualRes.winnerId,
            final_result: manualRes.winnerName
        };

        return {
            declared: true,
            items: [item],
            meta: { source: 'manual', manual_result_id: manualRes.id }
        };

    } catch (e) {
        log.error('[Settlement] fetchManualResult error', { eventid, error: e.message });
        return { declared: false, items: [] };
    }
}





async function getMatchExposures(user_id, match_id, market_type) {
    try {
        // const exposures = await UserExposure.findAll({
        //     where: { user_id: String(user_id), match_id: String(match_id), game_type: market_type },
        //     attributes: ['team_name', 'exposure_amount']
        // });

        const query = `
    SELECT team_name, exposure_amount
    FROM user_exposures
    WHERE user_id = $1
    AND match_id = $2
    AND game_type = $3
`;

        const values = [String(user_id), String(match_id), market_type];

        const { rows: exposures } = await pg.query(query, values);

        const map = {};
        for (const r of exposures) {
            map[(r.team_name || '').toString()] = Number(r.exposure_amount || 0);
        }
        return map;
    } catch (e) {
        log.error('[Settlement] getMatchExposures failed', { user_id, match_id, error: e.message });
        return {};
    }
}

// Robust exposure lookup: matches keys ignoring case / trailing-leading / inner whitespace
// (exposure keys + result winnerName often differ only by a trailing space, e.g. 'The Draw ').
// Returns the matched exposure value, or `fallback` when no name matches.
function findExposureValue(map, names, fallback = undefined) {
    const list = Array.isArray(names) ? names : [names];
    for (const name of list) {
        const target = norm(name);
        if (!target) continue;
        for (const key of Object.keys(map || {})) {
            if (norm(key) === target) return map[key];
        }
    }
    return fallback;
}
async function clearExposuresForMatch(user_id, match_id, market_type, transaction = null) {
    try {
        // await UserExposure.destroy({
        //     where: { user_id: String(user_id), match_id: String(match_id), game_type: market_type },
        //     ...(transaction ? { transaction } : {})
        // });

        const query = `
    DELETE FROM user_exposures
    WHERE user_id = $1
    AND match_id = $2
    AND game_type = $3
`;

        const values = [String(user_id), String(match_id), market_type];

        if (transaction) {
            await transaction.query(query, values);
        } else {
            await pg.query(query, values);
        }
        log.debug('[Settlement] Exposures cleared', { user_id, match_id, market_type });
    } catch (e) {
        log.error('[Settlement] clearExposuresForMatch failed', { user_id, match_id, error: e.message });
        if (transaction) throw e;
    }
}
async function closeBetsForMatch(user_id, match_id, onlyLine = false, resultStatus, job_id, transaction = null) {
    try {
        let params = [
            String(user_id),
            String(match_id),
            String(job_id),
            resultStatus
        ];

        let query = `
            UPDATE "SportsBet"
            SET status = 'closed',
                result_status = $4,
                updated_at = NOW()
            WHERE user_id = $1
            AND match_id = $2
            AND job_id = $3
            AND status IN ('open', 'manual')
        `;

        if (onlyLine) {
            query += ` AND bet_type IN ('yes','no')`;
        }

        if (transaction) {
            await transaction.query(query, params);
        } else {
            await pg.query(query, params);
        }

        log.debug('[Settlement] Bets closed', { user_id, match_id, onlyLine, resultStatus });

    } catch (e) {
        log.error('[Settlement] closeBetsForMatch failed', { user_id, match_id, error: e.message });
        if (transaction) throw e;
    }
}


function normalize(str) {
    return (str || '').toString().toLowerCase().replace(/\s+/g, ' ').replace(/[^\w\s]/g, '').trim();
}

function resolveMobmWinner({ result, team_one, team_two, runners = [] }) {
    console.log("inside resolveMobmWinner", result, team_one, team_two, result);
    let final_result = result.items[0].winnerName;
    console.log("final_result", final_result);
    const items = result?.items || [];
    // if (!items.length && !final_result) {
    //     log.debug('[Settlement] resolveMobmWinner: no result items or final_result');
    //     return { winnerName: '', reason: 'no result items or final_result' };
    // }

    // Use final_result parameter directly if provided, otherwise fall back to item
    const item = items[0];
    const resultStr = final_result || item?.final_result || '';
    const finalResult = normalize(resultStr);

    // Normalize team names
    const teamOneNorm = normalize(team_one);
    const teamTwoNorm = normalize(team_two);

    // 1. Check for SUSPENDED or CANCELLED
    if (['suspended', 'cancelled'].includes(finalResult)) {
        log.debug('[Settlement] resolveMobmWinner: result is SUSPENDED or CANCELLED', { finalResult, resultStr });
        return { winnerName: 'SUSPENDED', reason: `final_result is ${finalResult.toUpperCase()}` };
    }

    // 2. Check for draw/tie/abandoned/no result
    // 2. Draw cases
    if (['draw', 'the draw', 'abandoned', 'no result'].some(term => finalResult.toLowerCase().includes(term))) {
        log.debug('[Settlement] resolveMobmWinner: draw or no result', { finalResult, team_one, team_two });

        let winner = finalResult.toLowerCase().includes('the draw') ? 'The Draw' : 'Draw';

        return { winnerName: winner, reason: 'final_result indicates draw/tie/abandoned/no result' };
    }

    if (['No Goal', 'no goal', 'nogoal'].some(term => finalResult.includes(term))) {
        log.debug('[Settlement] resolveMobmWinner: draw or no result', { finalResult, team_one, team_two });
        return { winnerName: 'No Goal', reason: 'final_result indicates draw/tie/abandoned/no result' };
    }

    // 3. Runner match FIRST — the bets carry the runner name, the event title does not.
    // Returning "Struff" here when the bet says "Jan-Lennard Struff " inverts the market.
    if (finalResult && runners.length) {
        const runner = pickRunner(runners, resultStr);
        if (runner) {
            return { winnerName: runner, reason: `matched runner "${runner}"` };
        }
    }

    // 4. String matching for winner (markets with no runners list)
    if (finalResult) {
        // Exact match
        if (finalResult === teamOneNorm) {
            return { winnerName: team_one, reason: 'exact match to team_one' };
        }
        if (finalResult === teamTwoNorm) {
            return { winnerName: team_two, reason: 'exact match to team_two' };
        }

        // Starts with (e.g., "Australia won by...")
        if (finalResult.startsWith(teamOneNorm)) {
            return { winnerName: team_one, reason: 'startsWith team_one' };
        }
        if (finalResult.startsWith(teamTwoNorm)) {
            return { winnerName: team_two, reason: 'startsWith team_two' };
        }

        // Contains (e.g., "defeated Australia")
        if (finalResult.includes(teamOneNorm)) {
            return { winnerName: team_one, reason: 'contains team_one' };
        }
        if (finalResult.includes(teamTwoNorm)) {
            return { winnerName: team_two, reason: 'contains team_two' };
        }

        // First 3 characters (legacy fallback)
        if (finalResult.substring(0, 3) === teamOneNorm.substring(0, 3)) {
            return { winnerName: team_one, reason: 'first 3 letters match team_one' };
        }
        if (finalResult.substring(0, 3) === teamTwoNorm.substring(0, 3)) {
            return { winnerName: team_two, reason: 'first 3 letters match team_two' };
        }

        log.debug('[Settlement] resolveMobmWinner: no string match', { finalResult, team_one, team_two, resultStr });
    }

    // 4. WinnerId fallback
    // const winnerId = item?.payload?.marketResultSummary?.winnerId ?? item?.winnerId;
    // if (winnerId != null && Number.isFinite(Number(winnerId))) {
    //   if (Number(winnerId) === 1) return { winnerName: team_one, reason: 'winnerId=1 maps to team_one' };
    //   if (Number(winnerId) === 2) return { winnerName: team_two, reason: 'winnerId=2 maps to team_two' };
    //   if (Number(winnerId) === 0) return { winnerName: 'The Draw', reason: 'winnerId=0 maps to draw' };
    // }

    // 5. Fallback to team_one
    log.debug('[Settlement] resolveMobmWinner: ambiguous result', { finalResult, team_one, team_two });
    return { winnerName: "SUSPENDED" || '', reason: 'ambiguous; fallback SUSPENDED' };
}
function resolveFanWinner({ result, runners = [] }) {

    const items = result?.items || [];
    const final_result = items?.[0]?.winnerName || '';

    const resultStr = final_result || '';
    const finalResult = normalize(resultStr);

    if (!finalResult) {
        return { winnerName: '', reason: 'no result string' };
    }

    // Suspended / Cancelled
    if (['suspended', 'cancelled'].includes(finalResult)) {
        return { winnerName: 'SUSPENDED', reason: 'match suspended/cancelled' };
    }

    // Draw / Abandoned
    if (['draw', 'the draw', 'abandoned', 'no result'].some(term => finalResult.includes(term))) {
        return { winnerName: 'Draw', reason: 'draw or abandoned' };
    }

    // No Goal
    if (['no goal', 'nogoal'].some(term => finalResult.includes(term))) {
        return { winnerName: 'No Goal', reason: 'no goal result' };
    }

    // 🔥 Dynamic runner matching
    for (const runner of runners) {

        const runnerNorm = normalize(runner);

        if (finalResult === runnerNorm) {
            return { winnerName: runner, reason: 'exact runner match' };
        }

        if (finalResult.startsWith(runnerNorm)) {
            return { winnerName: runner, reason: 'startsWith runner match' };
        }

        if (finalResult.includes(runnerNorm)) {
            return { winnerName: runner, reason: 'contains runner match' };
        }
    }

    return { winnerName: "SUSPENDED", reason: 'no runner matched' };
}

function calculateFinalCredit({ bet, oldExposures, winnerName }) {

    const exposures = Object.values(oldExposures);
    const negExposures = exposures.filter(x => x < 0);
    const mostNeg = negExposures.length ? Math.min(...negExposures) : 0;

    const winnerExposure = findExposureValue(oldExposures, winnerName, 0);

    let finalcredit = 0;

    // REFUND
    if (winnerName === "refund") {
        finalcredit = normalizeExposure(mostNeg);
        console.log("FINAL CREDIT REFUND:", finalcredit);
        return finalcredit;
    }

    // If all exposures are positive
    const allPositive = exposures.every(x => x > 0);

    if (allPositive) {
        finalcredit = winnerExposure;
        console.log("ALL POSITIVE → winner exposure:", finalcredit);
        return finalcredit;
    }

    // If winner exposure negative
    if (winnerExposure < 0) {
        finalcredit = normalizeExposure(mostNeg) - normalizeExposure(winnerExposure);
        console.log("WINNER NEGATIVE:", finalcredit);
        return finalcredit;
    }

    // Normal case
    finalcredit = normalizeExposure(mostNeg) + normalizeExposure(winnerExposure);

    console.log("NORMAL CASE FINAL CREDIT:", finalcredit);

    return finalcredit;
}


function resolveFancyWinner({ result, fancy_name, selection_name, team_one, team_two, bet_type, market_type, odds }) {

    console.log("result", result);
    let final_result = result.winnerId || result.winnerName;
    console.log("market_type", market_type);
    console.log("final_result", final_result);
    console.log("odds", odds);
    console.log("selection_name", selection_name);
    console.log("team_one", team_one);
    console.log("team_two", team_two);
    console.log("bet_type", bet_type);

    if (['suspended', 'cancelled', 'your_request_is_invalid'].includes(lower(final_result))) {
        log.debug('[Settlement] resolveFancyWinner: result is SUSPENDED or CANCELLED or request_is_invalid', { final_result });
        return { type: 'suspended', reason: `final_result is ${final_result.toUpperCase()}` };
    }
    let winnerName = '';
    const lowerMarket = lower(fancy_name);
    team_one = lower(team_one);
    team_two = lower(team_two);
    const finalwinningdata = normalize(final_result || '');

    // cricket 
    if (market_type === 'oddeven') {

        if (bet_type === 'yes' && final_result % 2 === 0) {
            winnerName = 'won';
        }
        else if (bet_type === 'no' && final_result % 2 !== 0) {
            winnerName = 'won';
        }
        else {
            winnerName = 'loss';
        }
        return { type: 'string', winnerName, reason: 'determined from final_result string for oddeven' };

    }
    else if (market_type === 'fancy1') {
        // special condition
        final_result = result.winnerName?.toLowerCase();
        let bet = bet_type?.toLowerCase();
        if (final_result === bet) {
            winnerName = 'won';
        } else {
            winnerName = 'loss';
        }
        return { type: 'string', winnerName, reason: 'determined from final_result string for fancy1' };
    }

    else if (market_type === 'TIED_MATCH') {
        if (final_result === '0' && selection_name === 'No') {
            winnerName = 'won';
        }
        else if (final_result === '1' && selection_name === 'Yes') {
            winnerName = 'won';
        }
        else {
            winnerName = 'loss';
        }
        return { type: 'string', winnerName, reason: 'determined from final_result string for tied match' };


    }
    else if (market_type === 'Tied Match') {
        if (final_result === '0' && selection_name === 'No' || selection_name === "NO") {
            winnerName = 'won';
        }
        else if (final_result === '1' && selection_name === 'Yes' || selection_name === "YES") {
            winnerName = 'won';
        }
        else {
            winnerName = 'loss';
        }
        return { type: 'string', winnerName, reason: 'determined from final_result string for tied match' };


    }

    else if (market_type === 'Over By Over') {
        if (bet_type === 'yes') {
            if (final_result >= odds) {
                winnerName = 'won';
            }
            else {
                winnerName = 'loss';
            }
            return { type: 'string', winnerName, reason: 'determined from final_result string for over by over' };
        }
        else if (bet_type === 'no') {
            if (final_result < odds) {
                winnerName = 'won';
            }
            else {
                winnerName = 'loss';
            }
            return { type: 'string', winnerName, reason: 'determined from final_result string for over by over' };
        }

    }
    else if (market_type === '2nd Period Winner' || market_type === '1st Period Winner' || market_type === '3rd Period Winner') {
        if (bet_type === 'yes' && final_result === selection_name) {
            winnerName = 'won';
        }
        else if (bet_type === 'no' && final_result !== selection_name) {
            winnerName = 'won';
        }
        else {
            winnerName = 'loss';
        }
        return { type: 'string', winnerName, reason: 'determined from final_result string for tied match' };


    }

    else if (market_type === '1st Innings 6 Overs Line' || market_type === '2nd Innings 6 Overs Line' || market_type === '3rd Innings 6 Overs Line' || market_type === 'Over By Over' || market_type === 'Normal' || market_type === '1st Innings 20 Overs Line' || market_type === 'khado' || market_type === 'meters' || market_type === 'Ball By Ball') {
        if (bet_type === 'yes') {
            if (final_result >= odds) {
                winnerName = 'won';
            }
            else {
                winnerName = 'loss';
            }
            return { type: 'string', winnerName, reason: 'determined from final_result string for 1st innings 6 overs line' };
        }
        else if (bet_type === 'no') {
            if (final_result < odds) {
                winnerName = 'won';
            }
            else {
                winnerName = 'loss';
            }
            return { type: 'string', winnerName, reason: 'determined from final_result string for 1st innings 6 overs line' };
        }
    }
    // else if (market_type === 'Ball By Ball') {
    //     if (bet_type === 'yes') {
    //         if (final_result === 1) {
    //             winnerName = 'won';
    //         }
    //         else {
    //             winnerName = 'loss';
    //         }
    //         return { type: 'string', winnerName, reason: 'determined from final_result Ball By Ball' };
    //     }
    //     else if (bet_type === 'no') {
    //         if (final_result === 0) {
    //             winnerName = 'won';
    //         }
    //         else {
    //             winnerName = 'loss';
    //         }
    //         return { type: 'string', winnerName, reason: 'determined from final_result Ball By Ball' };
    //     }
    // }
    //// football need to go till 55
    else if (market_type === 'OVER_UNDER_35' || market_type === 'OVER_UNDER_25' || market_type === 'OVER_UNDER_15' || market_type === 'OVER_UNDER_05') {

        const isUnderSelection = selection_name.includes('Under');
        const isOverSelection = selection_name.includes('Over');

        const isUnderResult = final_result === 'Under';
        const isOverResult = final_result === 'Over';

        let isWin = false;

        if (bet_type === 'yes') {
            isWin = (isUnderSelection && isUnderResult) ||
                (isOverSelection && isOverResult);
        } else if (bet_type === 'no') {
            isWin = (isUnderSelection && isOverResult) ||
                (isOverSelection && isUnderResult);
        }

        winnerName = isWin ? 'won' : 'loss';

        console.log("winnerName", winnerName);
        console.log("market_type", market_type);
        console.log("final_result", final_result);
        console.log("selection_name", selection_name);
        console.log("bet_type", bet_type);

        return {
            type: 'string',
            winnerName,
            reason: 'derived using over/under + yes/no logic'
        };
    }
    else if (market_type === 'Next Goal 1.0' || market_type === 'Next Goal 2.0' || market_type === 'Next Goal 3.0' || market_type === 'Next Goal 4.0' || market_type === 'Next Goal 5.0' || market_type === 'Next Goal 6.0' || market_type === 'Next Goal 7.0' || market_type === 'Next Goal 8.0' || market_type === 'Next Goal 9.0' || market_type === 'Next Goal 10.0') {
        if (final_result === selection_name && bet_type === 'yes') {
            winnerName = 'won';
        }
        else if (final_result !== selection_name && bet_type === 'no') {
            winnerName = 'won';
        }
        else {
            winnerName = 'loss';
        }
        return { type: 'string', winnerName, reason: 'determined from final_result string for tied match' };
    }
    else if (market_type === '1st Innings 50 Overs Line' || market_type === '2nd Innings 50 Overs Line') {
        if (bet_type === 'yes') {
            if (final_result > odds) {
                winnerName = 'won';
            }
            else {
                winnerName = 'loss';
            }
            return { type: 'string', winnerName, reason: 'determined from final_result string for innings 50 overs line' };
        }
        else if (bet_type === 'no') {
            if (final_result < odds) {
                winnerName = 'won';
            }
            else {
                winnerName = 'loss';
            }
            return { type: 'string', winnerName, reason: 'determined from final_result string for  innings 50 overs line' };
        }

    }
    else if (market_type === 'Game To Deuce 1/1' || market_type === 'Game To Deuce 1/2' || market_type === 'Game To Deuce 1/3' || market_type === 'Game To Deuce 1/4' || market_type === 'Game To Deuce 2/1' || market_type === 'Game To Deuce 2/2' || market_type === 'Game To Deuce 2/3' || market_type === 'Game To Deuce 2/4' || market_type === 'Game To Deuce 3/1' || market_type === 'Game To Deuce 3/2' || market_type === 'Game To Deuce 3/3' || market_type === 'Game To Deuce 3/4') {
        if (final_result === '0' && selection_name === 'No' || selection_name === "NO") {
            winnerName = 'won';
        }
        else if (final_result === '1' && selection_name === 'Yes' || selection_name === "YES") {
            winnerName = 'won';
        }
        else {
            winnerName = 'loss';
        }
        return { type: 'string', winnerName, reason: 'determined from final_result string for game deuce' };
    }
    else if (market_type === 'HALF_TIME' || market_type === 'Match Time Result 70:00' || market_type === 'Match Time Result 10:00' || market_type === 'Match Time Result 20:00' || market_type === 'Match Time Result 30:00' || market_type === 'Match Time Result 40:00' || market_type === 'Match Time Result 50:00' || market_type === 'Match Time Result 60:00' || market_type === 'Match Time Result 80:00' || market_type === 'Match Time Result 90:00') {
        if (final_result === selection_name && bet_type === 'yes') {
            winnerName = 'won';
        }
        else if (final_result !== selection_name && bet_type === 'no') {
            winnerName = 'won';
        }
        else {
            winnerName = 'loss';
        }
        return { type: 'string', winnerName, reason: 'determined from final_result string for half time' };
    }
    else if (market_type === 'Both Teams To Score') {
        if (final_result === 0 && selection_name === 'No' || selection_name === "NO") {
            winnerName = 'won';
        }
        else if (final_result > 0 && selection_name === 'Yes' || selection_name === "YES") {
            winnerName = 'won';
        }
        else {
            winnerName = 'loss';
        }
        return { type: 'string', winnerName, reason: 'determined from final_result string for both teams to score' };
    }

    /// tenis
    else if (market_type === 'Game Winner 1/2' || market_type === 'Game Winner 1/3' || market_type === 'Game Winner 1/4' || market_type === 'Game Winner 2/2' || market_type === 'Game Winner 2/3' || market_type === 'Game Winner 2/4' || market_type === 'Game Winner 3/2' || market_type === 'Game Winner 3/3' || market_type === 'Game Winner 3/4' || market_type === 'Game Winner 2/7') {
        if (final_result === selection_name && bet_type === 'yes') {
            winnerName = 'won';
        }
        else if (final_result !== selection_name && bet_type === 'no') {
            winnerName = 'won';
        }
        else {
            winnerName = 'loss';
        }
        return { type: 'string', winnerName, reason: 'determined from final_result string for tied match' };

    }
    else if (market_type === '1st Set Winner Home/Away' || market_type === '2nd Set Winner Home/Away' || market_type === '3rd Set Winner Home/Away' || market_type === '1st Set Race To 4.0' || market_type === '2nd Set Race To 4.0' || market_type === '3rd Set Race To 4.0') {
        if (final_result === selection_name && bet_type === 'yes') {
            winnerName = 'won';
        }
        else if (final_result !== selection_name && bet_type === 'no') {
            winnerName = 'won';
        }
        else {
            winnerName = 'loss';
        }
        return { type: 'string', winnerName, reason: 'determined from final_result string for tied match' };

    }
    else if (market_type === 'Correct Score' || market_type === "Correct Score 1st Set" || market_type === 'Correct Score 2nd Set' || market_type === 'Coreect Score 3rd Set') {
        if (bet_type === 'yes' && final_result === 1) {
            winnerName = 'won';
        }
        else if (bet_type === 'no' && final_result === 0) {
            winnerName = 'won';
        }

        else {
            winnerName = 'loss';
        }
        return { type: 'string', winnerName, reason: 'determined from final_result string for tied match' };
    }
    else if (market_type === 'Point Winner 1/3/1' || market_type === 'Point Winner 1/2/1' || market_type === 'Point Winner 1/1/1' || market_type === 'Point Winner 2/3/1' || market_type === 'Point Winner 2/2/1' || market_type === 'Point Winner 2/1/1' || market_type === 'Point Winner 3/3/1' || market_type === 'Point Winner 3/2/1' || market_type === 'Point Winner 3/1/1' || market_type === 'Point Winner 1/2/1') {
        if (final_result === selection_name && bet_type === 'yes') {
            winnerName = 'won';
        }
        else if (final_result !== selection_name && bet_type === 'no') {
            winnerName = 'won';
        }
        else {
            winnerName = 'loss';
        } 8
        return { type: 'string', winnerName, reason: 'determined from final_result string for tied match' };
    }
    else if (market_type === 'Match Result/Both Teams to score') {
        if (final_result === 0 && selection_name === 'No' || selection_name === "NO") {
            winnerName = 'won';
        }
        else if (final_result > 0 && selection_name === 'Yes' || selection_name === "YES") {
            winnerName = 'won';
        }
        else {
            winnerName = 'loss';
        }
        return { type: 'string', winnerName, reason: 'determined from final_result string for tied match' };
    }

}



// Refund function to handle SUSPENDED bets

async function initiateRefund({ job_id, user_id, eventid, match_id, bet, market_type }) {
    const { id: bet_id, stake_amount } = bet;
    const stake = num(stake_amount);
    const desc = `Refund for SUSPENDED MO/BM bet; bet_id=${bet_id}; stake=${stake}`;
    const meta = { api: { type: 'result', eventid, match_id, status: 'suspended' }, bet_id };

    try {

        // Find wallet
        const walletRes = await pg.query(
            `SELECT inr FROM credits WHERE uid = $1 LIMIT 1`,
            [user_id]
        );

        const wallet = walletRes.rows[0];

        if (!wallet) {
            log.error('[Settlement] No wallet found for user', { bet_id, user_id });
            throw new Error(`No wallet found for user_id=${user_id}`);
        }

        // Update wallet balance
        const newBalance = (wallet.inr || 0) + stake;

        await pg.query(
            `UPDATE credits SET inr = $1 WHERE uid = $2`,
            [newBalance, user_id]
        );

        // Insert ledger entry
        await pg.query(
            `INSERT INTO credits_ledger
            (user_id, currency, amount, reason, description, eventid, job_id, match_id, meta, market_type)
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
            [
                String(user_id),
                'INR',
                stake,
                'refund',
                desc,
                String(eventid),
                String(job_id || ''),
                match_id ? String(match_id) : null,
                JSON.stringify(meta || {}),
                market_type
            ]
        );

        log.info(`[Settlement] Refund credited`, { bet_id, user_id, credit: stake, balance: newBalance });

        // Update sports bet
        await pg.query(
            `UPDATE "SportsBet"
             SET status = 'closed',
                 result_status = 'refund',
                 updated_at = NOW()
             WHERE id = $1
             AND job_id = $2
             AND status IN ('open','manual')`,
            [bet_id, String(job_id)]
        );

        log.debug('[Settlement] Bet marked as refunded', { bet_id, user_id });

        // Write report
        await writeReport({
            job_id,
            bet_id,
            user_id,
            eventid,
            match_id,
            game_type: String(bet.game_type || 'MO').toUpperCase(),
            market_type,
            selection_name: bet.selection_name,
            resolved_winner: null,
            resolved_team: null,
            credit_amount: stake,
            exposures_map: {},
            api_snapshot: { status: 'refund due to SUSPENDED' },
            decision_path: ['refund due to SUSPENDED status', desc]
        });

    } catch (e) {

        log.error('[Settlement] Refund failed', { bet_id, user_id, error: e.message });

        await writeReport({
            job_id,
            bet_id,
            user_id,
            eventid,
            match_id,
            game_type: String(bet.game_type || 'MO').toUpperCase(),
            market_type,
            selection_name: bet.selection_name,
            resolved_winner: null,
            resolved_team: null,
            credit_amount: stake,
            exposures_map: {},
            api_snapshot: { status: 'refund failed SUSPENDED', bet_id, user_id, eventid, match_id },
            decision_path: ['[Settlement] Refund failed', { bet_id, user_id, error: e.message }]
        });

        throw e;
    }
}






// ==== Commission & Credit Logic ====
const PLATFORM_COMMISSION_PERCENT = 2; // 2% platform commission on winning amount default value if percentage not set

// function calculateCommission(winningAmount, percentage) {
//   const commPercent = percentage !== undefined && percentage !== null ? Number(percentage) : 2;
//   const commission = winningAmount * (commPercent / 100);
//   const finalAmount = winningAmount - commission;
//   return {
//     winningAmount: Math.floor(winningAmount * 100) / 100,
//     commission: Math.floor(commission * 100) / 100,
//     finalAmount: Math.floor(finalAmount * 100) / 100
//   };
// }

function normalizeOdds(odds) {
    let newodds;
    if (odds > 100) {
        newodds = (odds / 100) + 1;
    } else if (odds < 100) {
        newodds = 1 + (odds / 100);
    } else {
        newodds = 2.0;
    }
    return Math.floor(newodds * 100) / 100;
}
function getOdds(b) {
    const raw = b.odds ?? b.price ?? b.rate ?? b.odd ?? 0;
    const o = Number(raw);
    const gameType = String(b.game_type || '').toUpperCase();
    if (gameType === 'BM') return normalizeOdds(o);
    return Number.isFinite(o) ? o : 0;
}
function getStake(b) { return num(b.stake_amount ?? b.stake ?? b.amount ?? b.stakeValue ?? b.size); }
function isBack(b) { return lower(b.bet_type) === 'back'; }
function isLay(b) { return lower(b.bet_type) === 'lay'; }
function isYes(b) { return lower(b.bet_type) === 'yes'; }
function isNo(b) { return lower(b.bet_type) === 'no'; }

function moBmBetWinCredit(bet, winnerName, market_type) {
    const sel = bet.selection_name || '';
    const selIsWinner = namesMatch(sel, winnerName);
    const stake = getStake(bet);
    let odds = getOdds(bet);
    if (market_type == 'Tied Match') {
        odds = odds / 100;
    }
    if (isBack(bet)) return selIsWinner ? Math.max(0, (odds - 1) * stake) : 0;
    if (isLay(bet)) return selIsWinner ? 0 : stake;
    if (isYes(bet)) return selIsWinner ? Math.max(0, (odds - 1) * stake) : 0;
    if (isNo(bet)) return selIsWinner ? 0 : stake;
    return 0;
}
function normalizeExposure(value) {
    return Math.abs(value);
}

// ==== Report Writer ====

async function writeReport(r, transaction = null) {
    try {

        const query = `
        INSERT INTO sports_settlement_report (
            job_id,
            bet_id,
            user_id,
            eventid,
            match_id,
            game_type,
            market_type,
            fancy_name,
            selection_name,
            user_selection_yn,
            resolved_winner,
            resolved_team,
            actual_numeric,
            rule_op,
            rule_threshold,
            credit_amount,
            exposures_map,
            api_snapshot,
            decision_path,
            created_at
        )
        VALUES (
            $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20
        )
        ON CONFLICT (bet_id) DO NOTHING
        `;

        const params = [
            r.job_id,
            r.bet_id,
            r.user_id,
            r.eventid,
            r.match_id,
            r.game_type,
            r.market_type,
            r.fancy_name || null,
            r.selection_name || null,
            r.user_selection_yn || null,
            r.resolved_winner || null,
            r.resolved_team || null,
            r.actual_numeric != null ? r.actual_numeric : null,
            r.rule_op || null,
            r.rule_threshold != null ? r.rule_threshold : null,
            Number(r.credit_amount || 0),
            JSON.stringify(r.exposures_map || {}),
            JSON.stringify(r.api_snapshot || {}),
            JSON.stringify(r.decision_path || []),
            new Date()
        ];

        let result;

        if (transaction) {
            result = await transaction.query(query, params);
        } else {
            result = await pg.query(query, params);
        }

        if (result.rowCount === 0) {
            log.debug('[Settlement] Report already exists, skipping', { bet_id: r.bet_id });
        }

    } catch (e) {
        log.error('[Settlement] writeReport failed', { bet_id: r.bet_id, error: e.message });
    }
}







async function processMobmGroup({ job_id, user_id, eventid, match_id, bets, eventName, marketId, marketName, market_type, game_type, team_one, team_two, sport_id }) {
    log.info('[Settlement] Processing MO/BM group', { user_id, eventid, match_id, bets: bets.length });

    let result;
    const any = bets[0] || {};

    console.log("::::::::::::::::::::fffffffffffffffffff", any)

    if (any.status == 'manual') {
        console.log("test enter for manual");

        result = await fetchManualResult(eventid, match_id, game_type, market_type);
    } else {
        result = await fetchResultForEvent(eventid, eventName, marketId, marketName, sport_id, market_type);
    }


    if (!result.declared) {
        log.info('[Settlement] MO/BM group not declared, requeue', { user_id, match_id, eventid });
        return { settled: false, requeue: true };
    }




    const { winnerName, reason } = resolveMobmWinner({ result, team_one, team_two, runners: runnerList(any) });

    log.info(`[Settlement] MO/BM WINNER NAME or STATUS="${winnerName}" (${reason})`, { match_id, eventid, bets: bets.length });

    console.log("step donw 22");

    // Check if winner is SUSPENDED
    if (winnerName.toUpperCase() === 'SUSPENDED') {
        log.info('[Settlement] MO/BM group SUSPENDED, initiating refunds', { user_id, match_id, eventid });
        // const market_type = (String(any.game_type || 'MO').toUpperCase() === 'BM' ? 'bookmaker' : 'odds');

        for (const bet of bets) {
            await initiateRefund({ job_id, user_id, eventid, match_id, bet, game_type });
        }

        // Clear exposures and mark job as done
        await clearExposuresForMatch(user_id, match_id, market_type);
        return { settled: true, requeue: false };
    }

    let totalCredit = 0;
    console.log("step donw exposure");
    console.log("market_type", market_type);
    const exposuresMap = await getMatchExposures(user_id, match_id, market_type);
    console.log("exposuresMap", exposuresMap);

    // Fetch User to get percentage
    // const user = await User.findByPk(user_id);

    const res = await pg.query(
        `SELECT *
 FROM users
 WHERE id = $1
 LIMIT 1`,
        [user_id]
    );

    const user = res.rows[0] || null;
    const userPercentage = user ? user.percentage : 2;

    for (const bet of bets) {

        let credit = moBmBetWinCredit(bet, winnerName, market_type);
        console.log("credit test BM", credit);
        const stake = getStake(bet);
        const selIsWinner = namesMatch(bet.selection_name, winnerName);
        const oldExposures = await getMatchExposures(user_id, match_id, market_type);
        // Exposures are keyed by the name the bet was PLACED under (the runner name),
        // not by the short event-title name on the bet row — look up under both.
        const sides = sideAliases(bet);
        const team1 = findExposureValue(oldExposures, sides.one, 0);
        const team2 = findExposureValue(oldExposures, sides.two, 0);
        const draw = findExposureValue(oldExposures, ['The Draw', 'Draw', 'No Goal', 'Goal'], 0);
        const negExposures = Object.values(oldExposures).filter(x => x < 0);
        const mostNeg = negExposures.length > 0 ? Math.min(...negExposures) : 0;

        let finalcredit = 0;
        if (bet.counts == 2) {
            if (matchesAny(sides.one, winnerName)) {
                if (team1 > 0 && team2 > 0) {
                    finalcredit = team1;
                    console.log('FINAL CREDIT IF TEAM 1 WIN AND EXPOSURE <0:', finalcredit);
                }
                else if (team1 < 0 && team2 < 0) {
                    finalcredit = normalizeExposure(team2) - normalizeExposure(team1);
                    console.log('FINAL CREDIT IF TEAM 1 WIN AND BOTH EXPOSURE <0:', finalcredit);
                }
                else if (team1 <= 0) {
                    finalcredit = 0;
                    console.log('FINAL CREDIT IF TEAM 1 WIN AND EXPOSURE <0:', finalcredit);
                }
                else {
                    finalcredit = normalizeExposure(team1) + normalizeExposure(team2);
                    console.log('FINAL CREDIT IF TEAM 1 WIN AND EXPOSURE >0:', finalcredit);
                }

            }
            else if (matchesAny(sides.two, winnerName)) {

                if (team1 > 0 && team2 > 0) {
                    finalcredit = team2;
                    console.log('FINAL CREDIT IF TEAM 1 WIN AND EXPOSURE <0:', finalcredit);
                }
                else if (team1 < 0 && team2 < 0) {
                    finalcredit = normalizeExposure(team1) - normalizeExposure(team2);
                    console.log('FINAL CREDIT IF TEAM 2 WIN AND BOTH EXPOSURE <0:', finalcredit);
                }
                else if (team2 <= 0) {
                    finalcredit = 0;
                    console.log('FINAL CREDIT IF TEAM 2 WIN AND EXPOSURE <0:', finalcredit);
                }
                else {
                    finalcredit = normalizeExposure(team1) + normalizeExposure(team2);
                    console.log('FINAL CREDIT IF TEAM 2 WIN AND EXPOSURE >0:', finalcredit);
                }

            }
            else if (winnerName === 'refund') {
                finalcredit = normalizeExposure(mostNeg);
                console.log('FINAL CREDIT IF REFUND :', finalcredit);
            }
            else {
                // 2-runner market whose runners are NOT the two team names:
                // Under/Over, Odd/Even, Game Winner, etc. `winnerName` is a runner
                // label ("Under 2.5"), so it matches neither sides.one nor sides.two.
                // Without this branch finalcredit stayed at its initial 0 while
                // totalCredit (derived from selection_name) was still positive — so the
                // bet was closed as 'won' and a credits_ledger row was written, but the
                // wallet was never credited and the blocked liability never released.
                // Cost pawan31 26,930 on Broadmeadow Magic - Maitland FC (bets
                // 1141-1149, 2026-09-06). Exposures here are keyed by RUNNER name, so
                // resolve both sides from bet.runners and apply the same shape as the
                // team branches above.
                const runners = sides.runners || [];
                const winnerRunner = runners.find(r => namesMatch(r, winnerName));
                const otherRunner = runners.find(r => r !== winnerRunner);
                const winExp = num(findExposureValue(oldExposures, winnerRunner || winnerName, 0));
                const otherExp = num(findExposureValue(oldExposures, otherRunner, 0));

                if (winExp > 0 && otherExp > 0) {
                    finalcredit = winExp;
                }
                else if (winExp < 0 && otherExp < 0) {
                    finalcredit = normalizeExposure(otherExp) - normalizeExposure(winExp);
                }
                else if (winExp <= 0) {
                    finalcredit = 0;
                }
                else {
                    finalcredit = normalizeExposure(winExp) + normalizeExposure(otherExp);
                }
                console.log('FINAL CREDIT 2-RUNNER NON-TEAM MARKET:', finalcredit,
                    { winnerRunner, otherRunner, winExp, otherExp });
            }
        }
        else {
            if (matchesAny(sides.one, winnerName)) {
                if (team1 > 0 && team2 > 0 && draw > 0) {
                    finalcredit = team1;

                }
                else if (team1 < 0) {
                    finalcredit = normalizeExposure(mostNeg) - normalizeExposure(team1);
                }
                else {
                    finalcredit = normalizeExposure(mostNeg) + normalizeExposure(team1);
                }
            }
            else if (matchesAny(sides.two, winnerName)) {

                if (team1 > 0 && team2 > 0 && draw > 0) {
                    finalcredit = team2;

                }
                else if (team2 < 0) {
                    finalcredit = normalizeExposure(mostNeg) - normalizeExposure(team2);
                }
                else {
                    finalcredit = normalizeExposure(mostNeg) + normalizeExposure(team2);
                }
            }
            else if (winnerName === 'refund') {
                finalcredit = normalizeExposure(mostNeg);
                console.log('FINAL CREDIT IF REFUND :', finalcredit);
            }
            else {
                if (team1 > 0 && team2 > 0 && draw > 0) {
                    finalcredit = draw;

                }
                else if (draw < 0) {
                    finalcredit = normalizeExposure(mostNeg) - normalizeExposure(draw);
                }
                else {
                    finalcredit = normalizeExposure(mostNeg) + normalizeExposure(draw);
                }
            }
        }

        // if (selIsWinner && isBack(bet)) {
        //   credit += stake;
        // }
        totalCredit += credit;

        // Get odds information
        const rawOdds = getOdds(bet);
        const normalizedOddsValue = normalizeOdds(rawOdds);

        // Guard: a credit is always a finite, non-negative payout. A non-finite value
        // (e.g. NaN from a missing exposure) used to leak into the ledger as `credit=NaN`;
        // the wallet was protected by num() but the description/row was not. Clamp here so
        // the row, the description and the wallet all agree.
        finalcredit = Math.max(0, num(finalcredit));

        const desc = `MO/BM per-bet; winner="${winnerName}"; bet_type=${bet.bet_type}; selection="${bet.selection_name}"; odds=${rawOdds}; normalized_odds=${normalizedOddsValue}; stake=${stake}; credit=${finalcredit}`;
        const meta = { api: { type: 'result', eventid, marketId, marketName, status: result.declared }, winnerName, reason, bet_id: bet.id, odds: rawOdds, normalized_odds: normalizedOddsValue };

        if (bet.fixed == 0) {

            //let totalbets = await SportsBet.count({ where: { eventid, match_id, game_type: 'MO', user_id } });

            const res = await pg.query(
                `SELECT COUNT(*) AS totalbets
 FROM "SportsBet"
 WHERE eventid = $1
   AND match_id = $2
   AND game_type = $3
   AND user_id = $4`,
                [eventid, match_id, 'MO', user_id]
            );

            let totalbets = Number(res.rows[0].totalbets);
            let drawex = bet.counts == 3 ? draw : 0;
            // await MarketWin.create({
            //     totalbets, matchid: match_id, eventid, team1ex: team1, team2ex: team2, drawex,
            //     winteam: winnerName, matchname: `${bet.team_one} vs ${bet.team_two}`, payout: finalcredit, user_id, created_at: new Date()
            // });

            await pg.query(
                `INSERT INTO "marketwins"
(totalbets, matchid, eventid, team1ex, team2ex, drawex, winteam, matchname, payout, user_id, created_at)
VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
                [
                    totalbets,
                    match_id,
                    eventid,
                    team1,
                    team2,
                    drawex,
                    winnerName,
                    `${bet.team_one} vs ${bet.team_two}`,
                    finalcredit,
                    user_id,
                    new Date()
                ]
            );


        }

        if (bet.fixed == 1) {
            finalcredit = 0;
        }

        // Calculate cost (liability/stake) for stats
        let cost = 0;
        if (isBack(bet) || bet.bet_type === "Yes" || bet.bet_type === "yes") {
            cost = stake;
        } else if (isLay(bet) || bet.bet_type === "No" || bet.bet_type === "no") {
            cost = (rawOdds - 1) * stake;
        }
        cost = cost > 0 ? cost : 0;

        if (finalcredit !== 0 || LEDGER_ZERO_ROWS) {
            // Apply dynamic platform commission on winning amount
            const creditAmount = finalcredit
            const amt = num(creditAmount);
            // if (amt === 0 && !LEDGER_ZERO_ROWS) return { credited: 0 };
            try {
                //const creditRecord = await Wallet.findOne({ where: { user_id: String(user_id) } });
                const res = await pg.query(
                    `SELECT * 
 FROM credits
 WHERE uid = $1
 LIMIT 1`,
                    [String(user_id)]
                );

                const creditRecord = res.rows[0] || null;
                //const user = await User.findByPk(String(user_id));

                const userRes = await pg.query(
                    `SELECT * FROM users WHERE id = $1 LIMIT 1`,
                    [String(user_id)]
                );

                const user = userRes.rows[0] || null;
                let newBal = null;
                if (creditRecord) {
                    const currentBal = Number(creditRecord.inr || 0);
                    const addAmt = Number(amt);
                    console.log('currentBal', currentBal);
                    console.log('addAmt', addAmt);

                    newBal = currentBal + addAmt;

                    // await creditRecord.update({ credit: newBal });

                    await pg.query(
                        `UPDATE credits SET inr = $1 WHERE uid = $2`,
                        [newBal, user_id]
                    );
                    console.log('newBal', newBal);
                } else {
                    log.error('[Settlement] No credit record for user', { user_id });
                }
            } catch (err) {
                log.error('[Settlement] Error updating credit record', { user_id, error: err.message });
            }

        }
        let profit = 0;
        let loss = 0;
        let netamount = 0;

        if (totalCredit > 0) {
            profit = totalCredit;
            netamount = totalCredit;
        } else {
            if (isBack(bet) || bet.bet_type === "Yes" || bet.bet_type === "yes") {
                loss = -stake;
                netamount = -stake;
            } else if (isLay(bet) || bet.bet_type === "No" || bet.bet_type === "no") {
                loss = - bet.liability;
                netamount = - bet.liability;
            }
        }
        // Guard: liability can be null/undefined for some lay/no bets, which would make
        // netamount NaN. That column is summed by the balance sheet and added to
        // users.total_profit / staff_balances — a single NaN breaks the whole ledger total.
        // Keep all three finite (0 floor) so a missing-liability data gap never propagates.
        profit = num(profit);
        loss = num(loss);
        netamount = num(netamount);
        console.log("netamount", netamount);
        console.log("profit", profit);
        console.log("loss", loss);

        // await Credit.create({
        //   user_id, match_id, eventid, game_type, market_type, selection_name, bet_type, stake, credit, profit, loss, netamount
        // });
        // await User.increment(
        //     {
        //         net_win: profit,     // can be +10, 0, +40
        //         net_loss: loss,      // can be -30, 0, -40
        //         profit: netamount    // can be -10, +40, +30, -100
        //     },
        //     {
        //         where: { user_id }
        //     }
        // );
        // const Usersdata = await User.findOne({ where: { user_id } });

        await pg.query(
            `UPDATE users
 SET net_win = net_win + $1,
     net_loss = net_loss + $2,
     total_profit = total_profit + $3,
     gt = COALESCE(gt, 0) + $5
 WHERE id = $4`,
            [profit, loss, netamount, user_id, netamount]
        );

        const UsersdataRes = await pg.query(
            `SELECT * FROM users WHERE id = $1 LIMIT 1`,
            [user_id]
        );

        const Usersdata = UsersdataRes.rows[0] || null;
        let closing = Usersdata.total_profit;

        // Up line
        // if (Usersdata.parent_staff_id) {
        //     await updateStaffParentBalUp(Usersdata.parent_staff_id, netamount, null);
        // }

        try {
            // await CreditsLedger.create({
            //     user_id,
            //     currency: "INR",

            //     amount: totalCredit,        // REQUIRED (raw +win / -loss)
            //     reason: "test",        // REQUIRED (ex: BET_WIN, BET_LOSS)

            //     description: desc || null,

            //     eventid: eventid || null,
            //     match_id: match_id || null,
            //     job_id: job_id || null,

            //     market_type: market_type || null,
            //     sport_id: bet.sport_id || null,

            //     meta: meta || null,

            //     commission: null,
            //     netamount: netamount || null,

            //     profit: profit || 0,
            //     loss: loss || null,
            //     bet_id: bet.id || null,
            //     closing: closing || null,
            // });

            await pg.query(
                `INSERT INTO credits_ledger
(user_id, currency, amount, reason, description, eventid, match_id, job_id, market_type, sport_id, meta, commission, netamount, profit, loss, bet_id, closing)
VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17)`,
                [
                    user_id,
                    "INR",
                    totalCredit,
                    "test",
                    desc || null,
                    eventid || null,
                    match_id || null,
                    job_id || null,
                    market_type || null,
                    bet.sport_id || null,
                    meta ? JSON.stringify(meta) : null,
                    null,
                    netamount || null,
                    profit || 0,
                    loss || null,
                    bet.id || null,
                    closing || null
                ]
            );
        } catch (err) {
            console.error('[Settlement] CreditsLedger create failed:', err);
            if (err.errors) {
                console.error('[Settlement] Validation errors:', err.errors.map(e => e.message));
            }
            throw err;
        }





        await writeReport({
            job_id, bet_id: bet.id, user_id, eventid, match_id,
            game_type: String(bet.game_type || 'MO').toUpperCase(),
            market_type, selection_name: bet.selection_name,
            resolved_winner: winnerName || null, resolved_team: winnerName || null,
            credit_amount: finalcredit, exposures_map: exposuresMap,
            api_snapshot: result.meta, decision_path: [reason, desc]
        });
    }

    const resultStatus = totalCredit > 0 ? 'won' : 'loss';
    // await SportsBet.update({ fixed: 1, updated_at: new Date() }, { where: { match_id, user_id, game_type, market_type } });

    await pg.query(
        `UPDATE "SportsBet"
 SET fixed = $1,
     updated_at = NOW()
 WHERE match_id = $2
   AND user_id = $3
   AND game_type = $4
   AND market_type = $5`,
        [1, match_id, user_id, game_type, market_type]
    );
    await closeBetsForMatch(user_id, match_id, false, resultStatus, job_id);
    await clearExposuresForMatch(user_id, match_id, market_type);
    return { settled: true, requeue: false };
}

async function processnonfancy({ job_id, user_id, eventid, match_id, bet, eventName, marketId, marketName, market_type, game_type, team_one, team_two, result }) {
    console.log("result", result);
    console.log("entered nonfancysettlement");




    // const { winnerName, reason } = resolveMobmWinner({ result, team_one, team_two, final_result: result.final_result });
    const { winnerName, reason } = resolveFanWinner({ result, runners: runnerList(bet) })

    log.info(`[Settlement] FAN/non-FAN WINNER NAME or STATUS="${winnerName}" (${reason})`, { match_id, eventid, marketId, marketName });

    console.log("step donw fan -non fan 22");

    // Check if winner is SUSPENDED
    if (winnerName.toUpperCase() === 'SUSPENDED') {
        log.info('[Settlement] MO/BM group SUSPENDED, initiating refunds', { user_id, match_id, eventid });

        // await sequelize.transaction(async (transaction) => {
        //     await initiateRefund({ job_id, user_id, eventid, match_id, bet, game_type });
        //     await clearExposuresForMatch(user_id, match_id, market_type, transaction);
        // });

        // const transaction = await pg.begin();
        await pg.query('BEGIN');



        try {

            await initiateRefund({ job_id, user_id, eventid, match_id, bet, game_type });

            await clearExposuresForMatch(user_id, match_id, market_type, pg);

            await pg.query('COMMIT');

        } catch (err) {

            await pg.query('ROLLBACK');
            throw err;

        }



        return { settled: true, requeue: false };
    }

    // ---- Read-only calculations (outside transaction) ----
    let totalCredit = 0;
    console.log("step donw exposure");
    console.log("market_type", market_type);
    const exposuresMap = await getMatchExposures(user_id, match_id, market_type);
    console.log("exposuresMap", exposuresMap);

    // Fetch User to get percentage
    // const user = await User.findByPk(user_id);
    const userRes = await pg.query(
        `SELECT * FROM users WHERE id = $1 LIMIT 1`,
        [user_id]
    );

    const user = userRes.rows[0] || null;
    const userPercentage = user ? user.percentage : 2;



    let credit = moBmBetWinCredit(bet, winnerName, market_type);
    console.log("credit test BM", credit);
    const stake = getStake(bet);
    const selIsWinner = namesMatch(bet.selection_name, winnerName);
    const oldExposures = await getMatchExposures(user_id, match_id, market_type);
    // FAN (soccer over/under, etc.) bets are single-selection yes/no/back/lay bets.
    // At placement the worst-case liability was blocked from the wallet and stored
    // as the negative exposure on the bet's OWN selection key (`sel`); see
    // API/controller.js marketsforfancy block. At settlement we release that block
    // and add the winnings on a win — on a loss the block is forfeited, so nothing
    // is returned.
    //
    // We must NOT use calculateFinalCredit() here: it looks the *winner name* up in
    // the exposure map, but fancy exposures are keyed by the bet's selection
    // (sel / sel+'back' / sel+'lay'), never the API winner name. That made a losing
    // bet fall through to |mostNeg| and get wrongly refunded its full stake (live
    // wallet ended above the ledger), and made a winning bet match the negative
    // `sel` value and get paid 0. Derive the credit from the bet's own outcome
    // instead — `credit` is the per-bet winnings (>0 only when this bet won).
    const selExposure = findExposureValue(oldExposures, bet.selection_name, 0);
    const blockedLiability = selExposure < 0 ? Math.abs(selExposure) : 0;
    let finalcredit = credit > 0 ? blockedLiability + credit : 0;
    // const team1 = oldExposures[bet.team_one] || 0;
    // const team2 = oldExposures[bet.team_two] || 0;
    // const draw = oldExposures['The Draw'] || oldExposures['Draw'] || oldExposures['No Goal'] || oldExposures['Goal'];
    // const negExposures = Object.values(oldExposures).filter(x => x < 0);
    // const mostNeg = negExposures.length > 0 ? Math.min(...negExposures) : 0;

    // let finalcredit = 0;
    // if (bet.counts == 2) {
    //     if (bet.team_one === winnerName) {
    //         if (team1 > 0 && team2 > 0) {
    //             finalcredit = team1;
    //             console.log('FINAL CREDIT IF TEAM 1 WIN AND EXPOSURE <0:', finalcredit);
    //         }
    //         else if (team1 < 0) {
    //             finalcredit = 0;
    //             console.log('FINAL CREDIT IF TEAM 1 WIN AND EXPOSURE <0:', finalcredit);
    //         }
    //         else {
    //             finalcredit = normalizeExposure(team1) + normalizeExposure(team2);
    //             console.log('FINAL CREDIT IF TEAM 1 WIN AND EXPOSURE >0:', finalcredit);
    //         }

    //     }
    //     else if (bet.team_two === winnerName) {

    //         if (team1 > 0 && team2 > 0) {
    //             finalcredit = team2;
    //             console.log('FINAL CREDIT IF TEAM 1 WIN AND EXPOSURE <0:', finalcredit);
    //         }
    //         else if (team2 < 0) {
    //             finalcredit = 0;
    //             console.log('FINAL CREDIT IF TEAM 2 WIN AND EXPOSURE <0:', finalcredit);
    //         }
    //         else {
    //             finalcredit = normalizeExposure(team1) + normalizeExposure(team2);
    //             console.log('FINAL CREDIT IF TEAM 2 WIN AND EXPOSURE >0:', finalcredit);
    //         }

    //     }
    //     else if (winnerName === 'refund') {
    //         finalcredit = normalizeExposure(mostNeg);
    //         console.log('FINAL CREDIT IF REFUND :', finalcredit);
    //     }
    // }
    // else {
    //     if (bet.team_one === winnerName) {
    //         if (team1 > 0 && team2 > 0 && draw > 0) {
    //             finalcredit = team1;

    //         }
    //         else if (team1 < 0) {
    //             finalcredit = normalizeExposure(mostNeg) - normalizeExposure(team1);
    //         }
    //         else {
    //             finalcredit = normalizeExposure(mostNeg) + normalizeExposure(team1);
    //         }
    //     }
    //     else if (bet.team_two === winnerName) {

    //         if (team1 > 0 && team2 > 0 && draw > 0) {
    //             finalcredit = team2;

    //         }
    //         else if (team2 < 0) {
    //             finalcredit = normalizeExposure(mostNeg) - normalizeExposure(team2);
    //         }
    //         else {
    //             finalcredit = normalizeExposure(mostNeg) + normalizeExposure(team2);
    //         }
    //     }
    //     else if (winnerName === 'refund') {
    //         finalcredit = normalizeExposure(mostNeg);
    //         console.log('FINAL CREDIT IF REFUND :', finalcredit);
    //     }
    //     else {
    //         if (team1 > 0 && team2 > 0 && draw > 0) {
    //             finalcredit = draw;

    //         }
    //         else if (draw < 0) {
    //             finalcredit = normalizeExposure(mostNeg) - normalizeExposure(draw);
    //         }
    //         else {
    //             finalcredit = normalizeExposure(mostNeg) + normalizeExposure(draw);
    //         }
    //     }
    // }

    // if (selIsWinner && isBack(bet)) {
    //   credit += stake;
    // }
    totalCredit += credit;

    // Get odds information
    const rawOdds = getOdds(bet);
    const normalizedOddsValue = normalizeOdds(rawOdds);

    // Guard: a credit is always a finite, non-negative payout. A non-finite value
    // (e.g. NaN from a missing exposure) used to leak into the ledger as `credit=NaN`;
    // the wallet was protected by num() but the description/row was not. Clamp here so
    // the row, the description and the wallet all agree.
    finalcredit = Math.max(0, num(finalcredit));

    const desc = `FAN per-bet; winner="${winnerName}"; bet_type=${bet.bet_type}; selection="${bet.selection_name}"; odds=${rawOdds}; normalized_odds=${normalizedOddsValue}; stake=${stake}; credit=${finalcredit}`;
    const meta = { api: { type: 'result', eventid, marketId, marketName, status: result.declared }, winnerName, reason, bet_id: bet.id, odds: rawOdds, normalized_odds: normalizedOddsValue };

    if (bet.fixed == 1) {
        finalcredit = 0;
    }

    // Calculate cost (liability/stake) for stats
    let cost = 0;
    if (isBack(bet)) {
        cost = stake;
    } else if (isLay(bet)) {
        cost = (rawOdds - 1) * stake;
    }
    cost = cost > 0 ? cost : 0;

    let profit = 0;
    let loss = 0;
    let netamount = 0;

    if (totalCredit > 0) {
        profit = totalCredit;
        netamount = totalCredit;
    } else {
        if (isBack(bet) || bet.bet_type === "Yes" || bet.bet_type === "yes") {
            loss = -stake;
            netamount = -stake;
        } else if (isLay(bet) || bet.bet_type === "No" || bet.bet_type === "no") {
            loss = - bet.liability;
            netamount = - bet.liability;
        }
    }
    // Guard: liability can be null/undefined for some lay/no bets, which would make
    // netamount NaN. That column is summed by the balance sheet and added to
    // users.total_profit / staff_balances — a single NaN breaks the whole ledger total.
    // Keep all three finite (0 floor) so a missing-liability data gap never propagates.
    profit = num(profit);
    loss = num(loss);
    netamount = num(netamount);
    console.log("netamount", netamount);
    console.log("profit", profit);
    console.log("loss", loss);

    // ---- All DB writes inside a single transaction ----
    // await sequelize.transaction(async (transaction) => {

    //     // MarketWin record (only for non-fixed bets)


    //     // Wallet credit/debit with row-level lock
    //     if (finalcredit !== 0 || LEDGER_ZERO_ROWS) {
    //         const creditAmount = finalcredit;
    //         const amt = num(creditAmount);
    //         console.log("finalcredit", creditAmount);

    //         const creditRecord = await Wallet.findOne({
    //             where: { user_id: String(user_id) },
    //             transaction,
    //             lock: transaction.LOCK.UPDATE
    //         });

    //         if (creditRecord) {
    //             const currentBal = Number(creditRecord.credit || 0);
    //             const addAmt = Number(amt);
    //             console.log('currentBal', currentBal);
    //             console.log('addAmt', addAmt);

    //             const newBal = currentBal + addAmt;
    //             await creditRecord.update({ credit: newBal }, { transaction });
    //             console.log('newBal', newBal);
    //         } else {
    //             log.error('[Settlement] No credit record for user', { user_id });
    //         }
    //     }

    //     // User profit/loss stats
    //     await User.increment(
    //         {
    //             net_win: profit,     // can be +10, 0, +40
    //             net_loss: loss,      // can be -30, 0, -40
    //             profit: netamount    // can be -10, +40, +30, -100
    //         },
    //         {
    //             where: { user_id },
    //             transaction
    //         }
    //     );

    //     const Usersdata = await User.findOne({ where: { user_id }, transaction });
    //     let closing = Usersdata.profit;

    //     // Upline staff balance
    //     if (Usersdata.parent_staff_id) {
    //         await updateStaffParentBalUp(Usersdata.parent_staff_id, netamount, transaction);
    //     }

    //     // Credits ledger
    //     await CreditsLedger.create({
    //         user_id,
    //         currency: "INR",

    //         amount: totalCredit,        // REQUIRED (raw +win / -loss)
    //         reason: "test",        // REQUIRED (ex: BET_WIN, BET_LOSS)

    //         description: desc || null,

    //         eventid: eventid || null,
    //         match_id: match_id || null,
    //         job_id: job_id || null,

    //         market_type: market_type || null,
    //         sport_id: bet.sport_id || null,

    //         meta: meta || null,

    //         commission: null,
    //         netamount: netamount || null,

    //         profit: profit || 0,
    //         loss: loss || null,
    //         bet_id: bet.id || null,
    //         closing: closing || null,
    //     }, { transaction });

    //     // Write report
    //     await writeReport({
    //         job_id, bet_id: bet.id, user_id, eventid, match_id,
    //         game_type: String(bet.game_type || 'MO').toUpperCase(),
    //         market_type, selection_name: bet.selection_name,
    //         resolved_winner: winnerName || null, resolved_team: winnerName || null,
    //         credit_amount: finalcredit, exposures_map: exposuresMap,
    //         api_snapshot: result.meta, decision_path: [reason, desc]
    //     }, transaction);

    //     // Mark bets as fixed and close
    //     const resultStatus = totalCredit > 0 ? 'won' : 'loss';
    //     await SportsBet.update({ fixed: 1, updated_at: new Date() }, { where: { match_id, user_id, game_type, market_type }, transaction });
    //     await closeBetsForMatch(user_id, match_id, false, resultStatus, job_id, transaction);
    //     await clearExposuresForMatch(user_id, match_id, market_type, transaction);
    // });

    //const transaction = await pg.begin();

    await pg.query('BEGIN');

    try {

        /* WALLET LOCK + UPDATE */

        if (finalcredit !== 0 || LEDGER_ZERO_ROWS) {

            const creditAmount = finalcredit;
            const amt = num(creditAmount);

            const walletRes = await pg.query(
                `SELECT inr
             FROM credits
             WHERE uid = $1
             FOR UPDATE`,
                [String(user_id)]
            );

            const creditRecord = walletRes.rows[0];

            if (creditRecord) {

                const currentBal = Number(creditRecord.inr || 0);
                const addAmt = Number(amt);
                const newBal = currentBal + addAmt;

                await pg.query(
                    `UPDATE credits
                 SET inr = $1
                 WHERE uid = $2`,
                    [newBal, user_id]
                );

            } else {
                log.error('[Settlement] No credit record for user', { user_id });
            }
        }


        /* USER PROFIT / LOSS */

        await pg.query(
            `UPDATE users
         SET net_win = net_win + $1,
             net_loss = net_loss + $2,
             total_profit = total_profit + $3,
             gt = COALESCE(gt, 0) + $5
         WHERE id = $4`,
            [profit, loss, netamount, user_id, netamount]
        );


        /* FETCH USER */

        const userRes = await pg.query(
            `SELECT profit, parent_staff_id,total_profit,total_profit
         FROM users
         WHERE id = $1`,
            [user_id]
        );

        const Usersdata = userRes.rows[0];
        let closing = Usersdata?.total_profit;


        /* STAFF UPLINE — intentionally does NOT move staff_balances.
           Agent cash moves only through deposit/withdraw (staff_transfers).
           Agent P&L is the read-only roll-up of users.gt / users.casino_gt
           (see lordsController.rollupPnl). Removed 2026-08-10. */


        /* CREDITS LEDGER */

        await pg.query(
            `INSERT INTO credits_ledger
        (user_id,currency,amount,reason,description,eventid,match_id,job_id,
         market_type,sport_id,meta,commission,netamount,profit,loss,bet_id,closing)
        VALUES
        ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17)`,
            [
                user_id,
                "INR",
                totalCredit,
                "test",
                desc || null,
                eventid || null,
                match_id || null,
                job_id || null,
                market_type || null,
                bet.sport_id || null,
                JSON.stringify(meta || {}),
                null,
                netamount || null,
                profit || 0,
                loss || null,
                bet.id || null,
                closing || null
            ]
        );


        /* REPORT */

        await writeReport({
            job_id,
            bet_id: bet.id,
            user_id,
            eventid,
            match_id,
            game_type: String(bet.game_type || 'MO').toUpperCase(),
            market_type,
            selection_name: bet.selection_name,
            resolved_winner: winnerName || null,
            resolved_team: winnerName || null,
            credit_amount: finalcredit,
            exposures_map: exposuresMap,
            api_snapshot: result.meta,
            decision_path: [reason, desc]
        }, pg);


        /* MARK BETS FIXED */

        const resultStatus = totalCredit > 0 ? 'won' : 'loss';

        await pg.query(
            `UPDATE "SportsBet"
         SET fixed = 1,
             updated_at = NOW()
         WHERE match_id = $1
         AND user_id = $2
         AND game_type = $3
         AND market_type = $4`,
            [match_id, user_id, game_type, market_type]
        );


        await closeBetsForMatch(
            user_id,
            match_id,
            false,
            resultStatus,
            job_id,
            pg
        );

        await clearExposuresForMatch(
            user_id,
            match_id,
            market_type,
            pg
        );


        await pg.query('COMMIT');

    } catch (err) {

        await pg.query('ROLLBACK');
        throw err;

    }

    return { settled: true, requeue: false };
}





async function processFanBet({ job_id, bet, eventName, marketId, marketName }) {
    const { id: bet_id, user_id, eventid, match_id, fancy_name, selection_name, bet_type, game_type, odds, stake_amount, market_type, team_one, team_two, runners, size, sport_id, status } = bet;
    log.info('[Settlement] Processing FAN bet', { bet_id, user_id, eventid, fancy_name, match_id, bet_type, sport_id, market_type, status });

    let result;
    if (status === 'manual') {
        // For FAN bets, we pass fancy_name as the selection identifier for the manual table lookup
        result = await fetchManualResult(eventid, match_id, game_type, market_type, selection_name);
    } else {
        result = await fetchResultForEventFancy(eventid, eventName, marketId, selection_name, sport_id, market_type);
    }

    log.debug('[Settlement] FAN result', { bet_id, eventid, declared: result.declared });
    console.log(" FAN result'", { bet_id, eventid, declared: result.declared });

    // Fetch User
    //const user = await User.findByPk(user_id);
    const userRes = await pg.query(
        `SELECT * FROM users WHERE id = $1 LIMIT 1`,
        [user_id]
    );

    const user = userRes.rows[0] || null;
    const userPercentage = user ? user.percentage : 2;

    const exposuresMap = await getMatchExposures(user_id, match_id, market_type);

    // await insertScanRow({ user_id, eventid, declared: result.declared, final_result: result.final_result, counts: { total: 1 } });
    // await insertSummaryRow({
    //     user_id, eventid, declared: result.declared, counts: { total: 1 },
    //     result_meta: result.meta, sections: { bet_ids: [bet_id] }
    // });

    if (!result.declared) {
        log.info('[Settlement] FAN bet not declared, requeue', { bet_id, user_id, eventid });
        return { settled: false, requeue: true };
    }
    console.log("done1");
    // what team one and team two
    console.log("team_one", team_one);
    console.log("team_two", team_two);
    log.info('[Settlement] calling resolveFancyWinner with data : ', { result, fancy_name, final_result: result.items, selection_name, team_one, team_two, bet_type });

    if (isNonFancyMarket(market_type)) {
        return await processnonfancy({ job_id, user_id, eventid, match_id, bet, eventName, marketId, marketName, market_type, game_type, team_one, team_two, result })
    }
    else {


        const resolve = resolveFancyWinner({ result: result.items[0], fancy_name, selection_name, team_one, team_two, bet_type, market_type, odds });
        let credit = 0;
        let winner = false;
        let netamount = 0;
        let resolved_winner = null;
        let desc = null;
        let meta = null;
        // const market_type = 'Fancy';
        const decision_path = [resolve.reason];

        console.log("step after resolver ")
        console.log(resolve);
        console.log("step after resolver ")

        if (resolve.type === 'suspended') {
            await initiateRefund({ job_id, user_id, eventid, match_id, bet, market_type });
            await clearExposuresForMatch(user_id, match_id, market_type);
            return { settled: true, requeue: false };
        } else if (resolve.type === 'string') {
            winner = resolve.winnerName === 'won';
            if (market_type === 'TIED_MATCH' || market_type === 'OVER_UNDER_35' || market_type === 'OVER_UNDER_25' || market_type === 'OVER_UNDER_15' || market_type === 'OVER_UNDER_05' || market_type === 'Tied Match'
                || market_type === 'Game Winner 1/2' || market_type === 'Game Winner 1/3' || market_type === '1st Set Winner Home/Away' || market_type === '2nd Set Winner Home/Away' || market_type === '3rd Set Winner Home/Away'
                || market_type === 'Next Goal 1.0' || market_type === 'Next Goal 2.0' || market_type === 'Next Goal 3.0' || market_type === 'Next Goal 4.0' || market_type === 'Next Goal 5.0' || market_type === 'Next Goal 6.0'
                || market_type === 'Game Winner 2/2' || market_type === 'Game Winner 2/3' || market_type === 'Game Winner 2/4' || market_type === 'Game Winner 3/2' || market_type === 'Game Winner 3/3' || market_type === 'Game Winner 3/4' || market_type === 'Game Winner 2/7' || market_type === 'Game Winner 4/3' || market_type === 'Game Winner 4/4'
                || market_type === '1st Period Winner' || market_type === '2nd Period Winner' || market_type === '3rd Period Winner' || market_type === 'Game To Deuce 1/1' || market_type === 'Game To Deuce 1/2' || market_type === 'Game To Deuce 1/3' || market_type === 'Game To Deuce 1/4' || market_type === 'Game To Deuce 2/1' || market_type === 'Game To Deuce 2/2' || market_type === 'Game To Deuce 2/3' || market_type === 'Game To Deuce 2/4' || market_type === 'Game To Deuce 3/1' || market_type === 'Game To Deuce 3/2' || market_type === 'Game To Deuce 3/3' || market_type === 'Game To Deuce 3/4'
                || market_type === 'Correct Score' || market_type === 'Correct Score1' || market_type === 'Correct Score 1st Set' || market_type === 'Correct Score 2nd Set' || market_type === 'Correct Score 3rd Set'
                || market_type === '1st Set Race To 4.0' || market_type === '2nd Set Race To 4.0' || market_type === '3rd Set Race To 4.0' || market_type === 'Point Winner 1/3/1' || market_type === 'Point Winner 1/2/1' || market_type === 'Point Winner 1/1/1' || market_type === 'Point Winner 2/3/1' || market_type === 'Point Winner 2/2/1' || market_type === 'Point Winner 2/1/1' || market_type === 'Point Winner 3/3/1' || market_type === 'Point Winner 3/2/1' || market_type === 'Point Winner 3/1/1'
                || market_type === 'Point Winner 1/3/2' || market_type === 'Point Winner 1/2/2' || market_type === 'Point Winner 1/1/2' || market_type === 'Point Winner 2/3/2' || market_type === 'Point Winner 2/2/2' || market_type === 'Point Winner 2/1/2' || market_type === 'Point Winner 3/3/2' || market_type === 'Point Winner 3/2/2' || market_type === 'Point Winner 3/1/2' || market_type === 'Point Winner 1/2/1' || market_type === 'HALF_TIME'
                || market_type === 'Match Result/Both Teams to score' || market_type === 'Both Teams To Score' || market_type === 'Match Time Result 70:00' || market_type === 'Match Time Result 10:00' || market_type === 'Match Time Result 20:00' || market_type === 'Match Time Result 30:00' || market_type === 'Match Time Result 40:00' || market_type === 'Match Time Result 50:00' || market_type === 'Match Time Result 60:00' || market_type === 'Match Time Result 80:00' || market_type === 'Match Time Result 90:00'
                || market_type === 'oddeven' || market_type === 'fancy1'
            ) {
                //fancy
                if (winner) {
                    credit = bet_type === 'yes' || bet_type === 'YES' ? stake_amount * (odds - 1) : stake_amount;
                    netamount = bet_type === 'yes' || bet_type === 'YES' ? stake_amount * (odds - 1) : stake_amount;
                }
                else {
                    credit = 0;
                    netamount = bet_type === 'yes' || bet_type === 'YES' ? -stake_amount : -stake_amount * (odds - 1);
                }
            } else {
                //normal
                console.log("size", bet.size);
                if (winner) {
                    credit = bet_type === 'yes' || bet_type === 'YES' ? stake_amount * (bet.size / 100) : stake_amount;
                    netamount = bet_type === 'yes' || bet_type === 'YES' ? stake_amount * (bet.size / 100) : stake_amount;
                }
                else {
                    credit = 0;
                    netamount = bet_type === 'yes' || bet_type === 'YES' ? -stake_amount : - stake_amount * (bet.size / 100);
                }
            }
            resolved_winner = winner ? selection_name : null;
            decision_path.push(`string match: selection=${selection_name} winnerName=${resolve.winnerName}`);
        } else {
            log.info('[Settlement] Unknown resolve type for FAN bet, requeue', { bet_id, type: resolve.type });
            return { settled: false, requeue: true };
        }
        // await sequelize.transaction(async (transaction) => {

        //     const oldExposuresRows = await UserExposure.findAll({
        //         where: {
        //             user_id,
        //             match_id,
        //             game_type: market_type,
        //             team_name: selection_name
        //         },
        //         transaction,
        //         lock: transaction.LOCK.UPDATE,
        //     });



        //     const oldExposure = oldExposuresRows[0]
        //         ? Number(oldExposuresRows[0].exposure_amount)
        //         : 0;
        //     console.log('OLD EXPOSURES:', oldExposure);
        //     let releaseexposure = Math.abs(oldExposure);
        //     if (releaseexposure > 0) {

        //         const creditRecord = await Wallet.findOne({
        //             where: { user_id: String(user_id) },
        //             transaction,
        //             lock: transaction.LOCK.UPDATE
        //         });

        //         if (!creditRecord) {
        //             console.log('{exposure release} No credit record for user', { user_id });
        //         } else {

        //             const currentBal = Number(creditRecord.credit || 0);
        //             const addAmt = Number(releaseexposure);

        //             const newBal = currentBal + addAmt;

        //             await creditRecord.update(
        //                 { credit: newBal },
        //                 { transaction }
        //             );

        //             console.log('newBal after exposure release', newBal);
        //         }
        //     }
        //     console.log("step after credit or reffund ")
        //     console.log("amount ", credit);
        //     console.log("winner ", winner);
        //     console.log("netamount ", netamount);


        //     desc = `FAN per-bet; fancy="${fancy_name}" selection=${selection_name}; iswinner="${winner}"; stake=${getStake(bet)}; credit=${credit}`;
        //     meta = { api: { type: 'result', eventid, marketName: fancy_name, bettingType: bet_type }, bet_id };

        //     await FanWin.create({
        //         user_id, fancyname: fancy_name, selection: selection_name, runsodds: odds, payout: credit,
        //         eventid, matchid: match_id, created_at: new Date()
        //     }, { transaction }); // Add transaction here too if possible, but the original code didn't

        //     if (Number(netamount) !== 0) {

        //         const amt = Number(num(netamount)); // signed net amount (+ / -)

        //         try {

        //             const creditRecord = await Wallet.findOne({
        //                 where: { user_id: String(user_id) },
        //                 transaction,
        //                 lock: transaction.LOCK.UPDATE
        //             });

        //             if (!creditRecord) {
        //                 log.error('[Settlement] No credit record for user', { user_id });
        //                 return;
        //             }

        //             const currentBal = Number(creditRecord.credit || 0);

        //             const newBal = currentBal + amt;   // ✅ works for both + and -

        //             await creditRecord.update(
        //                 { credit: newBal },
        //                 { transaction }
        //             );

        //             console.log('[Settlement wallet]');
        //             console.log('currentBal:', currentBal);
        //             console.log('netamount :', amt);
        //             console.log('newBal    :', newBal);

        //         } catch (err) {
        //             log.error('[Settlement] Error updating credit record', {
        //                 user_id,
        //                 error: err.message
        //             });
        //             // Let transaction finish or catch rollback
        //             throw err; // Ensure rollback on failure
        //         }
        //     }
        //     await UserExposure.destroy({
        //         where: {
        //             user_id,
        //             match_id,
        //             game_type: market_type,
        //             [Op.or]: [
        //                 { team_name: selection_name },
        //                 { team_name: `${selection_name}lay` },
        //                 { team_name: `${selection_name}back` }
        //             ]
        //         },
        //         transaction
        //     });

        //     //-----------------New changes done by harman-----------------
        //     await user.increment('net_win', { by: winner ? netamount : 0, transaction });
        //     await user.increment('profit', { by: netamount, transaction });
        //     await user.increment('net_loss', { by: winner ? 0 : netamount, transaction });

        //     console.log("user", user);

        //     const Usersdata = await User.findOne({ where: { user_id } });
        //     let closing = Usersdata.profit;

        //     // UPLINE
        //     if (Usersdata.parent_staff_id) {
        //         await updateStaffParentBalUp(Usersdata.parent_staff_id, netamount, transaction);
        //     }

        //     await CreditsLedger.create({
        //         user_id,
        //         currency: "INR",

        //         amount: credit,        // REQUIRED (raw +win / -loss)
        //         reason: "test",        // REQUIRED (ex: BET_WIN, BET_LOSS)

        //         description: desc || null,

        //         eventid: eventid || null,
        //         match_id: match_id || null,
        //         job_id: job_id || null,

        //         market_type: market_type || null,
        //         sport_id: bet.sport_id || null,

        //         meta: meta || null,

        //         commission: null,
        //         netamount: netamount || null,

        //         profit: winner ? netamount : null,
        //         loss: winner ? null : netamount,
        //         bet_id: bet.id || null,
        //         closing: closing || null
        //     }, { transaction });

        //     console.log("teset credit ledger");
        //     const fanStake = getStake(bet);
        //     const fanNetPL = credit - fanStake;

        //     if (fanNetPL !== 0) {
        //         try {
        //             await UplineService.processUplineDistribution(user_id, fanNetPL, {
        //                 match_id,
        //                 market_id: marketId, // fan bets might not have standard marketId?
        //                 bet_id: bet_id
        //             });
        //         } catch (err) {
        //             log.error(`[Settlement] Upline FAN distribution failed`, { bet_id, error: err.message });
        //         }
        //     }

        //     await writeReport({
        //         job_id, bet_id, user_id, eventid, match_id,
        //         game_type: String(game_type || 'FAN').toUpperCase(),
        //         market_type, fancy_name, selection_name,
        //         user_selection_yn: lower(bet_type || '') || null,
        //         resolved_winner,
        //         actual_numeric: null,
        //         rule_op: null,
        //         rule_threshold: null,
        //         credit_amount: credit,
        //         exposures_map: exposuresMap,
        //         api_snapshot: result.meta,
        //         decision_path
        //     }, transaction);

        //     const resultStatus = winner ? 'won' : 'loss';
        //     // await clearExposuresForMatch(user_id, match_id, market_type);
        //     await SportsBet.update(
        //         { status: 'closed', result_status: resultStatus, updated_at: new Date() },
        //         { where: { id: bet_id, job_id: String(job_id), status: { [Op.in]: ['open', 'manual'] } }, transaction }
        //     );

        // });

        //const transaction = await pg.begin();

        try {
            await pg.query('BEGIN');



            /* -----------------------------
            GET OLD EXPOSURE
            ----------------------------- */

            const oldExposureRes = await pg.query(
                `SELECT exposure_amount 
             FROM user_exposures
             WHERE user_id=$1 AND match_id=$2 AND game_type=$3 AND team_name=$4
             FOR UPDATE`,
                [user_id, match_id, market_type, selection_name]
            );

            const oldExposure =
                oldExposureRes.rows.length > 0
                    ? Number(oldExposureRes.rows[0].exposure_amount)
                    : 0;

            let releaseexposure = Math.abs(oldExposure);

            /* -----------------------------
            RELEASE EXPOSURE TO WALLET
            ----------------------------- */

            if (releaseexposure > 0) {

                const walletRes = await pg.query(
                    `SELECT inr 
                 FROM credits 
                 WHERE uid=$1 
                 FOR UPDATE`,
                    [String(user_id)]
                );

                if (walletRes.rows.length > 0) {

                    const currentBal = Number(walletRes.rows[0].inr || 0);
                    const newBal = currentBal + releaseexposure;

                    await pg.query(
                        `UPDATE credits 
                     SET inr=$1 
                     WHERE uid=$2`,
                        [newBal, String(user_id)]
                    );

                }
            }

            /* -----------------------------
            FAN WIN RECORD
            ----------------------------- */

            await pg.query(
                `INSERT INTO fanwins
            (userid,fancyname,selection,runsodds,payout,eventid,matchid,created_at)
            VALUES ($1,$2,$3,$4,$5,$6,$7,NOW())`,
                [
                    user_id,
                    fancy_name,
                    selection_name,
                    odds,
                    credit,
                    eventid,
                    match_id
                ]
            );

            /* -----------------------------
            WALLET CREDIT / DEBIT
            ----------------------------- */

            if (Number(netamount) !== 0) {

                const walletRes = await pg.query(
                    `SELECT inr 
                 FROM credits
                 WHERE uid=$1
                 FOR UPDATE`,
                    [String(user_id)]
                );

                if (walletRes.rows.length === 0) {
                    throw new Error("Wallet not found");
                }

                const currentBal = Number(walletRes.rows[0].inr || 0);
                const newBal = currentBal + Number(netamount);

                await pg.query(
                    `UPDATE credits 
                 SET inr=$1 
                 WHERE uid=$2`,
                    [newBal, String(user_id)]
                );
            }

            /* -----------------------------
            DELETE USER EXPOSURES
            ----------------------------- */

            await pg.query(
                `DELETE FROM user_exposures
             WHERE user_id=$1
             AND match_id=$2
             AND game_type=$3
             AND (
                 team_name=$4
                 OR team_name=$5
                 OR team_name=$6
             )`,
                [
                    user_id,
                    match_id,
                    market_type,
                    selection_name,
                    `${selection_name}lay`,
                    `${selection_name}back`
                ]
            );

            /* -----------------------------
            UPDATE USER PROFIT / LOSS
            ----------------------------- */

            await pg.query(
                `UPDATE users
             SET
                net_win = net_win + $1,
                 total_profit = total_profit + $2,
                net_loss = net_loss + $3,
                gt = COALESCE(gt, 0) + $5
             WHERE id=$4`,
                [
                    winner ? netamount : 0,
                    netamount,
                    winner ? 0 : netamount,
                    user_id,
                    netamount
                ]
            );

            /* -----------------------------
            FETCH USER DATA
            ----------------------------- */

            const userRes = await pg.query(
                `SELECT profit,parent_staff_id,total_profit
             FROM users 
             WHERE id=$1 
             LIMIT 1`,
                [user_id]
            );

            const Usersdata = userRes.rows[0];
            const closing = Usersdata.total_profit;

            /* -----------------------------
            UPDATE STAFF UPLINE — intentionally does NOT move staff_balances.
            Agent cash moves only through deposit/withdraw (staff_transfers).
            Agent P&L is the read-only roll-up of users.gt / users.casino_gt
            (see lordsController.rollupPnl). Removed 2026-08-10.
            ----------------------------- */

            /* -----------------------------
            CREDIT LEDGER
            ----------------------------- */

            await pg.query(
                `INSERT INTO credits_ledger
            (user_id,currency,amount,reason,description,eventid,match_id,job_id,
            market_type,sport_id,meta,commission,netamount,profit,loss,bet_id,closing)
            VALUES
            ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17)`,
                [
                    user_id,
                    "INR",
                    credit,
                    "test",
                    null,
                    eventid,
                    match_id,
                    job_id,
                    market_type,
                    bet.sport_id,
                    JSON.stringify(result.meta),
                    null,
                    netamount,
                    winner ? netamount : null,
                    winner ? null : netamount,
                    bet.id,
                    closing
                ]
            );

            /* -----------------------------
            CLOSE BET
            ----------------------------- */

            const resultStatus = winner ? "won" : "loss";

            await pg.query(
                `UPDATE "SportsBet"
             SET status='closed',
                 result_status=$1,
                 updated_at=NOW()
             WHERE id=$2
             AND job_id=$3
             AND status IN ('open','manual')`,
                [resultStatus, bet_id, String(job_id)]
            );

            /* -----------------------------
            COMMIT
            ----------------------------- */

            await pg.query('COMMIT');

            return { success: true };

        } catch (err) {

            await pg.query('ROLLBACK');
            console.error("Settlement failed:", err);

            throw err;
        }
        // Add the below data in above transaction
        // await user.increment('net_win', { by: winner ? netamount : 0 });
        // await user.increment('profit', { by: netamount });
        // await user.increment('net_loss', { by: winner ? 0 : netamount });

        // console.log("user", user);

        // const Usersdata = await User.findOne({ where: { user_id } });
        // let closing = Usersdata.profit;

        // // UPLINE
        // if (Usersdata.parent_staff_id) {
        //     await updateStaffParentBalUp(Usersdata.parent_staff_id, netamount, null);
        // }

        // await CreditsLedger.create({
        //     user_id,
        //     currency: "INR",

        //     amount: credit,        // REQUIRED (raw +win / -loss)
        //     reason: "test",        // REQUIRED (ex: BET_WIN, BET_LOSS)

        //     description: desc || null,

        //     eventid: eventid || null,
        //     match_id: match_id || null,
        //     job_id: job_id || null,

        //     market_type: market_type || null,
        //     sport_id: bet.sport_id || null,

        //     meta: meta || null,

        //     commission: null,
        //     netamount: netamount || null,

        //     profit: winner ? netamount : null,
        //     loss: winner ? null : netamount,
        //     bet_id: bet.id || null,
        //     closing: closing || null
        // });

        // console.log("teset credit ledger");
        // const fanStake = getStake(bet);
        // const fanNetPL = credit - fanStake;

        // if (fanNetPL !== 0) {
        //     try {
        //         await UplineService.processUplineDistribution(user_id, fanNetPL, {
        //             match_id,
        //             market_id: marketId, // fan bets might not have standard marketId?
        //             bet_id: bet_id
        //         });
        //     } catch (err) {
        //         log.error(`[Settlement] Upline FAN distribution failed`, { bet_id, error: err.message });
        //     }
        // }

        // await writeReport({
        //     job_id, bet_id, user_id, eventid, match_id,
        //     game_type: String(game_type || 'FAN').toUpperCase(),
        //     market_type, fancy_name, selection_name,
        //     user_selection_yn: lower(bet_type || '') || null,
        //     resolved_winner,
        //     actual_numeric: null,
        //     rule_op: null,
        //     rule_threshold: null,
        //     credit_amount: credit,
        //     exposures_map: exposuresMap,
        //     api_snapshot: result.meta,
        //     decision_path
        // });

        // const resultStatus = winner ? 'won' : 'loss';
        // // await clearExposuresForMatch(user_id, match_id, market_type);
        // await SportsBet.update(
        //     { status: 'closed', result_status: resultStatus, updated_at: new Date() },
        //     { where: { id: bet_id, job_id: String(job_id), status: { [Op.in]: ['open', 'manual'] } } }
        // );
    }

    return { settled: true, requeue: false };
}



// ==== Job Processor ====
async function processJob(job) {
    const { job_id, user_id, eventid } = job;
    log.info(`[Settlement] Processing job job_id=${job_id} user=${user_id} event=${eventid}`, { job_id });
    // const bets = await SportsBet.findAll({
    //     where: { job_id: String(job_id), status: { [Op.in]: ['open', 'manual'] } },
    //     order: [['created_at', 'ASC']]
    // });

    const res = await pg.query(
        `SELECT *
 FROM "SportsBet"
 WHERE job_id = $1
   AND status IN ('open','manual')
 ORDER BY created_at ASC`,
        [String(job_id)]
    );

    const bets = res.rows;
    if (!bets.length) {
        log.info(`[Settlement] No open bets for job_id=${job_id}; marking done`, { job_id });
        // await SportsEventSettlementJob.update(
        //     { status: 'done', updated_at: new Date(), error_msg: null },
        //     { where: { job_id: String(job_id) } }
        // );

        await pg.query(
            `UPDATE sports_event_settlement_jobs
 SET status = $1,
     updated_at = NOW(),
     error_msg = NULL
 WHERE job_id = $2`,
            ['done', String(job_id)]
        );
        return;
    }
    log.debug('[Settlement] Found bets', { job_id, bet_count: bets.length });
    const moBmByMatch = new Map();
    const fanBets = [];
    for (const b of bets) {
        const gt = (b?.game_type).toUpperCase();
        if (gt === 'MO' || gt === 'BM' || gt === 'BO') {
            const k = `${b.user_id}::${b.match_id}`;
            if (!moBmByMatch.has(k)) moBmByMatch.set(k, []);
            moBmByMatch.get(k).push(b);
        } else if (gt === 'FAN') {
            fanBets.push(b);
        } else {
            log.error(`[Settlement] Unknown game_type="${b.game_type}"`, { bet_id: b.id });
        }
    }
    let anyRequeue = false;
    for (const [, group] of moBmByMatch.entries()) {
        const any = group[0];
        try {
            const res = await processMobmGroup({
                job_id, user_id: any.user_id, eventid: any.eventid, match_id: any.match_id, bets: group,
                eventName: any.match_title || '', marketId: any.match_id, marketName: any.selection_name || '', market_type: any.market_type, game_type: any.game_type, team_one: any.team_one, team_two: any.team_two,
                sport_id: any.sport_id, market_type: any.market_type, game_type: any.game_type
            });
            if (res.requeue) anyRequeue = true;
        } catch (e) {
            anyRequeue = true;
            log.error(`[Settlement] MO/BM group failed`, { match_id: any.match_id, error: e.message });
        }
    }
    for (const b of fanBets) {
        try {
            const res = await processFanBet({
                job_id, bet: b, eventName: b.match_title || '', marketId: b.match_id, marketName: b.fancy_name || ''
            });
            if (res.requeue) anyRequeue = true;
        } catch (e) {
            anyRequeue = true;
            log.error(`[Settlement] FAN bet failed`, { bet_id: b.id, error: e.message });
        }
    }
    // if (anyRequeue) {
    //     await SportsEventSettlementJob.update(
    //         { status: 'queued', updated_at: new Date(), error_msg: null },
    //         { where: { job_id: String(job_id) } }
    //     );
    //     log.info(`[Settlement] job_id=${job_id} kept queued for next tick`, { job_id });
    // } else {
    //     await SportsEventSettlementJob.update(
    //         { status: 'done', updated_at: new Date(), error_msg: null },
    //         { where: { job_id: String(job_id) } }
    //     );
    //     log.info(`[Settlement] job_id=${job_id} DONE`, { job_id });
    // }

    if (anyRequeue) {

        await pg.query(
            `UPDATE sports_event_settlement_jobs
         SET status = $1,
             updated_at = NOW(),
             error_msg = NULL
         WHERE job_id = $2`,
            ['queued', String(job_id)]
        );

        log.info(`[Settlement] job_id=${job_id} kept queued for next tick`, { job_id });

    } else {

        await pg.query(
            `UPDATE sports_event_settlement_jobs
         SET status = $1,
             updated_at = NOW(),
             error_msg = NULL
         WHERE job_id = $2`,
            ['done', String(job_id)]
        );

        log.info(`[Settlement] job_id=${job_id} DONE`, { job_id });

    }
}
//=================================================================================================================================
// ==== Poll Once ============================================================================================================
//=================================================================================================================================
async function pollOnce() {
    log.info(`[Settlement] ===== Poll start ${nowIso()} =====`);
    try {
        // const rows = await SportsEventSettlementJob.findAll({
        //     where: { status: 'queued' },
        //     order: [['created_at', 'ASC']],
        //     limit: BATCH_LIMIT,
        //     attributes: ['job_id', 'user_id', 'eventid', 'payload']
        // });

        // Pick queued jobs, plus jobs stranded in 'processing' (e.g. by a worker
        // crash/restart mid-run) longer than STALE_PROCESSING_MIN minutes so they
        // are never orphaned. pollOnce previously only selected 'queued', leaving
        // such jobs stuck forever.
        const res = await pg.query(
            `SELECT job_id, user_id, eventid, payload
 FROM sports_event_settlement_jobs
 WHERE status = 'queued'
    OR (status = 'processing' AND updated_at < NOW() - ($1 || ' minutes')::interval)
 ORDER BY created_at ASC
 LIMIT $2`,
            [String(STALE_PROCESSING_MIN), BATCH_LIMIT]
        );

        const rows = res.rows;
        log.info(`[Settlement] Picked ${rows.length} job(s) (queued + stale-processing)`, { job_count: rows.length });
        for (const job of rows) {
            try {
                // const updatedCount = await SportsEventSettlementJob.update(
                //     { status: 'processing', updated_at: new Date() },
                //     { where: { job_id: job.job_id, status: 'queued' } }
                // );

                // Claim the job: accept either a 'queued' job or one stranded in
                // 'processing' past the stale threshold (recovery after a crash).
                const res = await pg.query(
                    `UPDATE sports_event_settlement_jobs
 SET status = 'processing',
     updated_at = NOW()
 WHERE job_id = $1
 AND (status = 'queued'
      OR (status = 'processing' AND updated_at < NOW() - ($2 || ' minutes')::interval))
 RETURNING job_id`,
                    [job.job_id, String(STALE_PROCESSING_MIN)]
                );

                const updatedCount = res.rowCount;
                if (updatedCount[0] === 0) {
                    log.debug('[Settlement] Job already taken', { job_id: job.job_id });
                    continue;
                }
                let user_id = job?.user_id;
                let eventid = job?.eventid;
                if (!user_id || !eventid) {
                    log.error('[Settlement] Job missing userId/eventId', { job_id: job.job_id });
                    // await SportsEventSettlementJob.update(
                    //     { status: 'failed', error_msg: 'Missing userId/eventId', updated_at: new Date() },
                    //     { where: { job_id: job.job_id } }
                    // );
                    await pg.query(
                        `UPDATE sports_event_settlement_jobs
 SET status = $1,
     error_msg = $2,
     updated_at = NOW()
 WHERE job_id = $3`,
                        ['failed', 'Missing userId/eventId', job.job_id]
                    );
                    continue;
                }
                await processJob(job);
            } catch (e) {
                log.error(`[Settlement] Job failed`, { job_id: job.job_id, user_id, error: e.message });
                // await SportsEventSettlementJob.update(
                //     { status: 'failed', error_msg: e.message, updated_at: new Date() },
                //     { where: { job_id: job.job_id } }
                // );

                await pg.query(
                    `UPDATE sports_event_settlement_jobs
 SET status = $1,
     error_msg = $2,
     updated_at = NOW()
 WHERE job_id = $3`,
                    ['failed', e.message, job.job_id]
                );
            }
        }
        // const queued = await SportsEventSettlementJob.count({ where: { status: 'queued' } });
        // const processing = await SportsEventSettlementJob.count({ where: { status: 'processing' } });
        // const done = await SportsEventSettlementJob.count({ where: { status: 'done' } });
        // const failed = await SportsEventSettlementJob.count({ where: { status: 'failed' } });
        const resData = await pg.query(
            `SELECT
 COUNT(*) FILTER (WHERE status='queued') AS queued,
 COUNT(*) FILTER (WHERE status='processing') AS processing,
 COUNT(*) FILTER (WHERE status='done') AS done,
 COUNT(*) FILTER (WHERE status='failed') AS failed
 FROM sports_event_settlement_jobs`
        );

        const queued = Number(resData.rows[0].queued);
        const processing = Number(resData.rows[0].processing);
        const done = Number(resData.rows[0].done);
        const failed = Number(resData.rows[0].failed);
        log.info(`[Settlement] queue stats => queued:${queued || 0} processing:${processing || 0} done:${done || 0} failed:${failed || 0}`);
    } catch (e) {
        log.error('[Settlement] pollOnce failed', { error: e.message });
    } finally {
        log.info(`[Settlement] ===== Poll end ${nowIso()} =====`);
    }
}

// ==== Scheduler ====
let running = false;
function startScheduler() {
    log.info(`[Settlement] Scheduler starting (cron="${CRON_SCHEDULE}", tz="${CRON_TZ}")`);
    cron.schedule(CRON_SCHEDULE, async () => {
        if (running) {
            log.info('[Settlement] tick skipped (previous run still executing)');
            return;
        }
        running = true;
        try {
            await pollOnce();
        } catch (e) {
            log.error('[Settlement] tick error', { error: e.message });
        } finally {
            running = false;
        }
    }, { timezone: CRON_TZ });
    if (CRON_IMMEDIATE) {
        log.info('[Settlement] Running immediate poll');
        (async () => {
            if (running) return;
            running = true;
            try {
                await pollOnce();
            } catch (e) {
                log.error('[Settlement] immediate run error', { error: e.message });
            } finally {
                running = false;
            }
        })();
    }
}

// ==== Entry ====
async function start() {
    try {
        log.info('[Settlement] Worker v2.3.2 starting...');
        // Test database connection
        // await SportsEventSettlementJob.count();
        await pg.query('SELECT 1');

        log.info('[Settlement] Database connection verified');
        startScheduler();
    } catch (e) {
        log.error('[Settlement] Startup failed', { error: e.message });
        process.exit(1);
    }
}

// Run immediately for testing
start().catch(e => {
    log.error('[Settlement] Fatal', { error: e.message });
    process.exit(1);
});

module.exports = { start, pollOnce };


