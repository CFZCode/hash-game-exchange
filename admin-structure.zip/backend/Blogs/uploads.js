const multer = require('multer');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

/*
 * Blog image storage on local disk at backend/uploads/blogs/, served by the
 * static mount in index.js at /uploads/blogs. The DB stores only the relative
 * path (/uploads/blogs/<file>); clients prefix the API host.
 */
const UPLOAD_DIR = path.join(__dirname, '..', 'uploads', 'blogs');
const PUBLIC_PREFIX = '/uploads/blogs';
const MAX_BYTES = 10 * 1024 * 1024;

const EXT_BY_MIME = {
    'image/png': '.png',
    'image/jpeg': '.jpg',
    'image/jpg': '.jpg',
    'image/webp': '.webp',
    'image/gif': '.gif',
};

if (!fs.existsSync(UPLOAD_DIR)) {
    fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

const upload = multer({
    storage: multer.diskStorage({
        destination: (req, file, cb) => cb(null, UPLOAD_DIR),
        /* Extension from the checked MIME type, never from the client's file
           name, so "x.html" sent as image/png is still saved as .png. */
        filename: (req, file, cb) =>
            cb(null, `blog-${Date.now()}-${crypto.randomBytes(6).toString('hex')}${EXT_BY_MIME[file.mimetype]}`),
    }),
    limits: { fileSize: MAX_BYTES, files: 1 },
    fileFilter: (req, file, cb) => {
        if (!EXT_BY_MIME[file.mimetype]) {
            const err = new multer.MulterError('LIMIT_UNEXPECTED_FILE', file.fieldname);
            err.message = 'Only images are allowed (.png, .jpg, .jpeg, .webp, .gif)';
            return cb(err);
        }
        cb(null, true);
    },
});

const publicPath = (file) => (file ? `${PUBLIC_PREFIX}/${file.filename}` : null);

/** Delete a stored image. Only ever touches files inside the blog folder. */
function removeImage(relativePath) {
    try {
        if (!relativePath || !relativePath.startsWith(`${PUBLIC_PREFIX}/`)) return;
        const full = path.join(UPLOAD_DIR, path.basename(relativePath));
        if (fs.existsSync(full)) fs.unlinkSync(full);
    } catch (e) {
        console.error('Blog image delete error:', e.message);
    }
}

/**
 * Run multer for one `image` field and turn its errors into a JSON 400, so a
 * too-large or wrong-type file never falls through to Express's HTML 500 page.
 */
const singleImage = (req, res, next) =>
    upload.single('image')(req, res, (err) => {
        if (!err) return next();
        const message =
            err.code === 'LIMIT_FILE_SIZE'
                ? `Image is larger than ${MAX_BYTES / 1024 / 1024} MB`
                : err.message || 'Upload failed';
        return res.status(400).json({ status: 'error', message });
    });

module.exports = { UPLOAD_DIR, PUBLIC_PREFIX, singleImage, publicPath, removeImage };
