-- Blogs table
-- image: relative path served by the backend's static /uploads mount
--        (e.g. /uploads/blogs/blog-1714000000000-123456789.jpg)
CREATE TABLE IF NOT EXISTS blogs (
    id          SERIAL PRIMARY KEY,
    slug        VARCHAR(255) NOT NULL UNIQUE,
    title       VARCHAR(512) NOT NULL,
    subheading  TEXT,
    description TEXT NOT NULL,
    author      VARCHAR(255) DEFAULT 'Anonymous',
    date        TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    category    VARCHAR(128) DEFAULT 'Uncategorized',
    image       TEXT,
    created_at  TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Added later; blogController.js applies these on boot as well.
ALTER TABLE blogs ADD COLUMN IF NOT EXISTS status VARCHAR(16) NOT NULL DEFAULT 'published';
ALTER TABLE blogs ADD COLUMN IF NOT EXISTS meta_title VARCHAR(255);
ALTER TABLE blogs ADD COLUMN IF NOT EXISTS meta_description VARCHAR(512);
CREATE INDEX IF NOT EXISTS idx_blogs_status_date ON blogs (status, date DESC);

CREATE INDEX IF NOT EXISTS idx_blogs_slug ON blogs (slug);
CREATE INDEX IF NOT EXISTS idx_blogs_category ON blogs (LOWER(category));
CREATE INDEX IF NOT EXISTS idx_blogs_created_at ON blogs (created_at DESC);
