const express = require('express');
const BlogDatabase = require('./blogController');

/*
 * Public blog routes, mounted at /api/getblog. Only published posts whose date
 * has arrived are ever returned; drafts and scheduled posts stay invisible.
 */
const router = express.Router();

const serverError = (res, label, error) => {
    console.error(`Error fetching ${label}:`, error);
    res.status(500).json({ status: 'error', message: 'Failed to load blogs' });
};

/* Lists change when an admin publishes; a short cache keeps the site fast
   without making a new post wait long to appear. */
const cacheShort = (res) => res.set('Cache-Control', 'public, max-age=60');

// GET /all?page=1&limit=12&category=news&search=teen
router.get('/all', async (req, res) => {
    try {
        await BlogDatabase.ready();
        const { page, limit, category, search } = req.query;
        const result = await BlogDatabase.listBlogs({
            status: 'published',
            page,
            limit,
            category: category ? String(category) : undefined,
            search: search ? String(search).slice(0, 100) : undefined,
        });
        cacheShort(res);
        res.json({ status: 'success', ...result });
    } catch (error) {
        serverError(res, 'blogs', error);
    }
});

// GET /categories -> [{ category, count }]
router.get('/categories', async (req, res) => {
    try {
        await BlogDatabase.ready();
        cacheShort(res);
        res.json({ status: 'success', categories: await BlogDatabase.getCategories() });
    } catch (error) {
        serverError(res, 'blog categories', error);
    }
});

// GET /by-slug?slug=teen-patti-rules -> { blog, related }
router.get('/by-slug', async (req, res) => {
    try {
        await BlogDatabase.ready();
        const slug = req.query.slug;
        if (!slug) return res.status(400).json({ status: 'error', message: 'slug is required' });
        const blog = await BlogDatabase.getBlogBySlug(String(slug));
        if (!blog) return res.status(404).json({ status: 'error', message: 'Blog not found' });
        const related = await BlogDatabase.getRelated(blog);
        cacheShort(res);
        res.json({ status: 'success', blog, related });
    } catch (error) {
        serverError(res, 'blog by slug', error);
    }
});

// GET /by-id?id=5 (published only; the admin reads drafts from /api/blogs/admin/all)
router.get('/by-id', async (req, res) => {
    try {
        await BlogDatabase.ready();
        const id = parseInt(req.query.id, 10);
        if (!id) return res.status(400).json({ status: 'error', message: 'id is required' });
        const blog = await BlogDatabase.getBlogById(id);
        if (!blog || blog.status !== 'published' || new Date(blog.date) > new Date()) {
            return res.status(404).json({ status: 'error', message: 'Blog not found' });
        }
        res.json({ status: 'success', blog });
    } catch (error) {
        serverError(res, 'blog by id', error);
    }
});

// GET /by-category?category=news (kept for older callers; same as /all?category=)
router.get('/by-category', async (req, res) => {
    try {
        await BlogDatabase.ready();
        const category = req.query.category;
        if (!category) return res.status(400).json({ status: 'error', message: 'category is required' });
        const result = await BlogDatabase.listBlogs({ status: 'published', category: String(category), limit: 100 });
        res.json({ status: 'success', blogs: result.blogs });
    } catch (error) {
        serverError(res, 'blogs by category', error);
    }
});

module.exports = router;
