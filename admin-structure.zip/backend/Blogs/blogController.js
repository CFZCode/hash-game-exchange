const pg = require('../General/Model');

/*
 * Blog storage.
 *
 * The table is created on boot if missing, and the columns added after the
 * first version (status, meta_title, meta_description) are added with
 * ADD COLUMN IF NOT EXISTS, so an existing production table is upgraded in
 * place without a migration step. Every statement is idempotent.
 *
 * Existing rows get status 'published', so nothing already live disappears.
 */
const ENSURE_SCHEMA = `
    CREATE TABLE IF NOT EXISTS blogs (
        id          SERIAL PRIMARY KEY,
        slug        VARCHAR(255) NOT NULL UNIQUE,
        title       VARCHAR(512) NOT NULL,
        subheading  TEXT,
        description TEXT NOT NULL,
        author      VARCHAR(255) DEFAULT 'Anonymous',
        date        TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        category    VARCHAR(128) DEFAULT 'Uncategorized',
        image       TEXT,
        created_at  TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        updated_at  TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
    );
    ALTER TABLE blogs ADD COLUMN IF NOT EXISTS status VARCHAR(16) NOT NULL DEFAULT 'published';
    ALTER TABLE blogs ADD COLUMN IF NOT EXISTS meta_title VARCHAR(255);
    ALTER TABLE blogs ADD COLUMN IF NOT EXISTS meta_description VARCHAR(512);
    CREATE INDEX IF NOT EXISTS idx_blogs_slug ON blogs (slug);
    CREATE INDEX IF NOT EXISTS idx_blogs_category ON blogs (LOWER(category));
    CREATE INDEX IF NOT EXISTS idx_blogs_created_at ON blogs (created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_blogs_status_date ON blogs (status, date DESC);
`;

const ready = pg.query(ENSURE_SCHEMA).catch((err) => {
    console.error('Failed to ensure blogs table:', err.message);
});

/* Columns a caller may write. Anything else in an update object is ignored, so
   a field name can never reach the SQL text from request input. */
const WRITABLE = [
    'slug', 'title', 'subheading', 'description', 'author', 'date',
    'category', 'image', 'status', 'meta_title', 'meta_description',
];

/* The list view never needs the full body. An excerpt is cut from it in SQL so
   a page of posts does not ship every article in full. */
const LIST_COLUMNS = `
    id, slug, title, subheading, author, date, category, image, status,
    meta_title, meta_description, created_at, updated_at,
    LEFT(btrim(regexp_replace(regexp_replace(description, '<[^>]*>', ' ', 'g'), '\\s+', ' ', 'g')), 260) AS excerpt,
    GREATEST(1, CEIL(array_length(regexp_split_to_array(trim(regexp_replace(description, '<[^>]*>', ' ', 'g')), '\\s+'), 1) / 200.0))::int AS read_minutes
`;

class BlogDatabase {
    static ready() {
        return ready;
    }

    static async createBlog(fields) {
        const cols = WRITABLE.filter((c) => fields[c] !== undefined);
        const values = cols.map((c) => fields[c]);
        const placeholders = cols.map((_, i) => `$${i + 1}`);
        const result = await pg.query(
            `INSERT INTO blogs (${cols.join(', ')}) VALUES (${placeholders.join(', ')}) RETURNING *;`,
            values
        );
        return result.rows[0];
    }

    /**
     * Paged list.
     *   status   'published' for the public site, null for the admin (everything)
     *   category optional, case-insensitive
     *   search   optional, matches title or subheading
     */
    static async listBlogs({ status = 'published', category, search, page = 1, limit = 12 } = {}) {
        const where = [];
        const values = [];
        if (status) {
            values.push(status);
            where.push(`status = $${values.length}`);
            /* A post dated in the future is scheduled, not live. */
            if (status === 'published') where.push('date <= NOW()');
        }
        if (category) {
            values.push(category);
            where.push(`LOWER(category) = LOWER($${values.length})`);
        }
        if (search) {
            values.push(`%${search}%`);
            where.push(`(title ILIKE $${values.length} OR subheading ILIKE $${values.length})`);
        }
        const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';

        const safeLimit = Math.min(Math.max(parseInt(limit, 10) || 12, 1), 100);
        const safePage = Math.max(parseInt(page, 10) || 1, 1);
        const offset = (safePage - 1) * safeLimit;

        const [rows, count] = await Promise.all([
            pg.query(
                `SELECT ${LIST_COLUMNS} FROM blogs ${whereSql}
                 ORDER BY date DESC, id DESC
                 LIMIT ${safeLimit} OFFSET ${offset};`,
                values
            ),
            pg.query(`SELECT COUNT(*)::int AS total FROM blogs ${whereSql};`, values),
        ]);

        const total = count.rows[0].total;
        return {
            blogs: rows.rows,
            total,
            page: safePage,
            limit: safeLimit,
            pages: Math.max(1, Math.ceil(total / safeLimit)),
        };
    }

    /** Full rows, every status — the admin list needs the body to edit it. */
    static async getAllBlogsAdmin() {
        const result = await pg.query(`SELECT * FROM blogs ORDER BY date DESC, id DESC;`);
        return result.rows;
    }

    static async getCategories() {
        const result = await pg.query(
            `SELECT category, COUNT(*)::int AS count
               FROM blogs
              WHERE status = 'published' AND date <= NOW()
              GROUP BY category
              ORDER BY count DESC, category ASC;`
        );
        return result.rows;
    }

    static async getBlogById(id) {
        const result = await pg.query(`SELECT * FROM blogs WHERE id = $1;`, [id]);
        return result.rows[0] || null;
    }

    static async getBlogBySlug(slug, { publishedOnly = true } = {}) {
        const result = await pg.query(
            publishedOnly
                ? `SELECT * FROM blogs WHERE slug = $1 AND status = 'published' AND date <= NOW();`
                : `SELECT * FROM blogs WHERE slug = $1;`,
            [slug]
        );
        return result.rows[0] || null;
    }

    /** Other published posts, same category first, for "Read next". */
    static async getRelated(blog, limit = 3) {
        const result = await pg.query(
            `SELECT ${LIST_COLUMNS} FROM blogs
              WHERE id <> $1 AND status = 'published' AND date <= NOW()
              ORDER BY (LOWER(category) = LOWER($2)) DESC, date DESC
              LIMIT $3;`,
            [blog.id, blog.category || '', limit]
        );
        return result.rows;
    }

    static async slugExists(slug, exceptId = null) {
        const result = exceptId
            ? await pg.query(`SELECT 1 FROM blogs WHERE slug = $1 AND id <> $2 LIMIT 1;`, [slug, exceptId])
            : await pg.query(`SELECT 1 FROM blogs WHERE slug = $1 LIMIT 1;`, [slug]);
        return result.rowCount > 0;
    }

    static async updateBlog(id, updates) {
        const cols = WRITABLE.filter((c) => updates[c] !== undefined);
        if (cols.length === 0) throw new Error('No valid fields to update.');
        const values = cols.map((c) => updates[c]);
        const sets = cols.map((c, i) => `${c} = $${i + 1}`);
        values.push(id);
        const result = await pg.query(
            `UPDATE blogs SET ${sets.join(', ')}, updated_at = CURRENT_TIMESTAMP
              WHERE id = $${values.length} RETURNING *;`,
            values
        );
        return result.rows[0] || null;
    }

    static async deleteBlog(slug) {
        const result = await pg.query(`DELETE FROM blogs WHERE slug = $1 RETURNING *;`, [slug]);
        return result.rows[0] || null;
    }

    static async deleteBlogById(id) {
        const result = await pg.query(`DELETE FROM blogs WHERE id = $1 RETURNING *;`, [id]);
        return result.rows[0] || null;
    }
}

module.exports = BlogDatabase;
