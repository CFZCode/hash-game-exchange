const express = require('express');
const BlogDatabase = require('./blogController');
const { singleImage, publicPath, removeImage } = require('./uploads');

/*
 * Admin blog routes, mounted at /api/blogs behind protectStaff in index.js.
 * Every route here needs a valid staff Bearer token.
 *
 * Bodies are multipart/form-data (create, update, uploadImage) or JSON
 * (delete). The body HTML is stored as written; the site sanitises it when it
 * renders, so a hostile <script> never runs on a player's page.
 */
const router = express.Router();

const STATUSES = ['published', 'draft'];

/* "Teen Patti: Rules & Tips!" -> "teen-patti-rules-tips". Readable, stable
   URLs: the old version appended Date.now(), so every edit of a title moved
   the post to a new address and broke every link to it. */
function slugify(text) {
    return String(text || '')
        .normalize('NFKD')
        .replace(/[̀-ͯ]/g, '')
        .toLowerCase()
        .trim()
        .replace(/[^a-z0-9\s-]/g, '')
        .replace(/[\s_]+/g, '-')
        .replace(/-+/g, '-')
        .replace(/^-+|-+$/g, '')
        .slice(0, 120);
}

/* First free slug: base, base-2, base-3 ... A title in a script slugify cannot
   keep (Hindi, Urdu) falls back to "post". */
async function uniqueSlug(base, exceptId = null) {
    const root = base || 'post';
    let candidate = root;
    for (let n = 2; await BlogDatabase.slugExists(candidate, exceptId); n++) {
        candidate = `${root}-${n}`;
    }
    return candidate;
}

/* Normalise the text fields in a form body. Missing fields stay undefined so
   an update leaves them alone; a field sent empty clears it (subheading, meta). */
function readFields(body) {
    const pick = (k) => (body[k] === undefined ? undefined : String(body[k]).trim());
    return {
        title: pick('title'),
        slug: pick('slug'),
        subheading: pick('subheading'),
        description: body.description === undefined ? undefined : String(body.description),
        author: pick('author'),
        category: pick('category'),
        date: pick('date'),
        status: pick('status'),
        meta_title: pick('meta_title'),
        meta_description: pick('meta_description'),
    };
}

/* Empty-looking editor output ("<p><br></p>") is not content; an image is. */
const isBlankHtml = (html) => {
    const s = String(html || '');
    return !/<img\s/i.test(s) && !s.replace(/<[^>]*>/g, '').replace(/&nbsp;/g, ' ').trim();
};

function validate(f, { creating }) {
    if (creating || f.title !== undefined) {
        if (!f.title) return 'Title is required';
        if (f.title.length > 512) return 'Title is too long (max 512 characters)';
    }
    if ((creating || f.description !== undefined) && isBlankHtml(f.description)) {
        return 'Content is required';
    }
    if (f.date && Number.isNaN(Date.parse(f.date))) return 'Invalid date';
    if (f.status && !STATUSES.includes(f.status)) return 'Status must be published or draft';
    if (f.meta_title && f.meta_title.length > 255) return 'Meta title is too long (max 255)';
    if (f.meta_description && f.meta_description.length > 512) return 'Meta description is too long (max 512)';
    return null;
}

const fail = (res, code, message, file) => {
    if (file) removeImage(publicPath(file));
    return res.status(code).json({ status: 'error', message });
};

// -------------------------------------------------------
// GET /admin/all — every post, drafts included, full body for editing
// -------------------------------------------------------
router.get('/admin/all', async (req, res) => {
    try {
        await BlogDatabase.ready();
        const blogs = await BlogDatabase.getAllBlogsAdmin();
        res.json({ status: 'success', blogs });
    } catch (error) {
        console.error('Error listing blogs (admin):', error);
        res.status(500).json({ status: 'error', message: 'Failed to load blogs' });
    }
});

// -------------------------------------------------------
// POST /uploadImage — an image for inside the post body (editor toolbar)
// multipart: image (file)  ->  { status, url: '/uploads/blogs/<file>' }
// -------------------------------------------------------
router.post('/uploadImage', singleImage, (req, res) => {
    if (!req.file) return fail(res, 400, 'No image provided');
    res.json({ status: 'success', url: publicPath(req.file) });
});

// -------------------------------------------------------
// POST /createBlog
// multipart: title*, description*, slug, subheading, author, category, date,
//            status, meta_title, meta_description, image (file) | imageUrl
// -------------------------------------------------------
router.post('/createBlog', singleImage, async (req, res) => {
    try {
        await BlogDatabase.ready();
        const f = readFields(req.body);
        const error = validate(f, { creating: true });
        if (error) return fail(res, 400, error, req.file);

        const blog = await BlogDatabase.createBlog({
            ...f,
            slug: await uniqueSlug(slugify(f.slug || f.title)),
            subheading: f.subheading || null,
            author: f.author || 'MyApp',
            category: f.category || 'Uncategorized',
            date: f.date ? new Date(f.date).toISOString() : new Date().toISOString(),
            status: f.status || 'published',
            meta_title: f.meta_title || null,
            meta_description: f.meta_description || null,
            image: req.file ? publicPath(req.file) : (req.body.imageUrl || null),
        });

        res.status(201).json({ status: 'success', data: { blog } });
    } catch (error) {
        console.error('Error creating blog:', error);
        fail(res, 500, error.message || 'Failed to create blog', req.file);
    }
});

// -------------------------------------------------------
// POST /updateBlog
// multipart: id* + any field from createBlog. Fields left out are unchanged.
//   image (file)       replaces the cover; the old file is deleted
//   removeImage=true   clears the cover and deletes the file
//   slug               changes the URL only when sent; a title edit keeps it
// -------------------------------------------------------
router.post('/updateBlog', singleImage, async (req, res) => {
    try {
        await BlogDatabase.ready();
        const id = parseInt(req.query.id || req.body.id, 10);
        if (!id) return fail(res, 400, 'Blog ID is required', req.file);

        const existing = await BlogDatabase.getBlogById(id);
        if (!existing) return fail(res, 404, 'Blog not found', req.file);

        const f = readFields(req.body);
        const error = validate(f, { creating: false });
        if (error) return fail(res, 400, error, req.file);

        const updates = { ...f };
        if (f.slug !== undefined) {
            const wanted = slugify(f.slug || f.title || existing.title);
            updates.slug = wanted === existing.slug ? undefined : await uniqueSlug(wanted, id);
        }
        if (f.date !== undefined) updates.date = f.date ? new Date(f.date).toISOString() : undefined;
        if (f.author !== undefined) updates.author = f.author || 'MyApp';
        if (f.category !== undefined) updates.category = f.category || 'Uncategorized';
        ['subheading', 'meta_title', 'meta_description'].forEach((k) => {
            if (f[k] !== undefined) updates[k] = f[k] || null;
        });

        const removing = String(req.body.removeImage) === 'true';
        if (req.file) updates.image = publicPath(req.file);
        else if (removing) updates.image = null;
        else if (req.body.imageUrl) updates.image = req.body.imageUrl;

        const updated = await BlogDatabase.updateBlog(id, updates);
        if (!updated) return fail(res, 500, 'Update failed', req.file);

        /* The DB now points elsewhere; drop the old cover file. */
        if ((req.file || removing) && existing.image && existing.image !== updated.image) {
            removeImage(existing.image);
        }

        res.json({ status: 'success', data: updated });
    } catch (error) {
        console.error('Error updating blog:', error);
        fail(res, 500, error.message || 'Failed to update blog', req.file);
    }
});

// -------------------------------------------------------
// POST /deleteBlog — JSON { slug }
// POST /deleteBlogById?id=5
// -------------------------------------------------------
async function deleteAndRespond(res, finder) {
    try {
        const blog = await finder();
        if (!blog) return res.status(404).json({ status: 'error', message: 'Blog not found' });
        if (blog.image) removeImage(blog.image);
        res.json({ status: 'success', message: 'Blog deleted successfully' });
    } catch (error) {
        console.error('Error deleting blog:', error);
        res.status(500).json({ status: 'error', message: error.message || 'Failed to delete' });
    }
}

router.post('/deleteBlog', (req, res) => {
    const { slug } = req.body || {};
    if (!slug) return res.status(400).json({ status: 'error', message: 'Slug is required' });
    deleteAndRespond(res, () => BlogDatabase.deleteBlog(slug));
});

router.post('/deleteBlogById', (req, res) => {
    const id = parseInt(req.query.id || (req.body && req.body.id), 10);
    if (!id) return res.status(400).json({ status: 'error', message: 'id is required' });
    deleteAndRespond(res, () => BlogDatabase.deleteBlogById(id));
});

module.exports = router;
module.exports.slugify = slugify;
