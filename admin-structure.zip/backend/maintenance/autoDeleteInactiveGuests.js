/* ──────────────────────────────────────────────────────────────────────────
   Auto-delete inactive, manually-credited guest IDs.

   Business rule (confirmed with the owner):
     A guest ID (role_id = 6) is permanently deleted when ALL of these hold:
       • created more than 3 days ago
       • received at least one MANUAL agent credit (staff_transfers 'transfer')
       • NO payment-gateway / bank deposit of any kind   ← gateway deposits exempt
       • NO activity at all: no login, no sports bet, no casino, no legacy bet,
         games_played = 0
     The credited balance is discarded with the account (no refund), and the
     user row + every related row is hard-deleted (same cascade as deletePlayer).

   Runs daily. Never throws — failures are logged so the server stays up.
   ────────────────────────────────────────────────────────────────────────── */
const cron = require('node-cron');
const pg = require('../General/Model');
const emailService = require('../emailservice/controller');

// Selects every guest ID that currently qualifies for deletion. All id columns
// are bigint except ccdeposit.userid (varchar) — hence the ::text compare there.
const CANDIDATE_SQL = `
  SELECT u.id, u.name, u.email, u.created
    FROM users u
   WHERE u.role_id = 6
     AND u.created IS NOT NULL
     AND u.created < now() - interval '3 days'
     AND COALESCE(u.games_played, 0) = 0
     AND EXISTS (SELECT 1 FROM staff_transfers st
                  WHERE st.to_type = 'user' AND st.to_id = u.id
                    AND st.transfer_type = 'transfer')
     AND NOT EXISTS (SELECT 1 FROM user_login_history l WHERE l.user_id = u.id)
     AND NOT EXISTS (SELECT 1 FROM "SportsBet" sb       WHERE sb.user_id = u.id)
     AND NOT EXISTS (SELECT 1 FROM gis_transactions g   WHERE g.user_id = u.id)
     AND NOT EXISTS (SELECT 1 FROM bets b               WHERE b.uid = u.id)
     AND NOT EXISTS (SELECT 1 FROM apaydeposits d       WHERE d.user_id = u.id)
     AND NOT EXISTS (SELECT 1 FROM fiat_deposits d      WHERE d.user_id = u.id)
     AND NOT EXISTS (SELECT 1 FROM pay_in_transactions d WHERE d.user_id = u.id)
     AND NOT EXISTS (SELECT 1 FROM ccdeposit d          WHERE d.userid = u.id::text)
   ORDER BY u.created ASC
   LIMIT 500`;

// Hard-delete a user and every row that references them. Mirrors
// staffController.deletePlayer but uses ::text compares so it works whether a
// referencing column is bigint or varchar. Uses the shared client with a
// transaction (same pattern as lordsController).
async function deleteUserCascade(userId) {
  try {
    await pg.query('BEGIN');
    const possCols = ['user_id', 'userid', 'uid', 'id_user', 'user'];
    const { rows: tbls } = await pg.query(
      `SELECT table_name, column_name FROM information_schema.columns
        WHERE table_schema = 'public' AND table_name <> 'users'
          AND lower(column_name) = ANY($1)`,
      [possCols]
    );
    for (const { table_name, column_name } of tbls) {
      await pg.query(
        `DELETE FROM "${table_name}" WHERE "${column_name}"::text = $1`,
        [String(userId)]
      );
    }
    await pg.query('DELETE FROM credits WHERE uid = $1', [userId]);
    await pg.query('DELETE FROM users WHERE id = $1', [userId]);
    await pg.query('COMMIT');
    return true;
  } catch (err) {
    await pg.query('ROLLBACK').catch(() => {});
    console.error(`[autoDeleteGuests] failed to delete user ${userId}:`, err.message);
    return false;
  }
}

async function notifyDeleted(deleted) {
  try {
    const { rows } = await pg.query('SELECT apaynotificationemail FROM siteconfig LIMIT 1');
    const to = rows[0]?.apaynotificationemail;
    if (!to) return;
    const cell = (v) => `<td style="padding:6px 12px;border:1px solid #e2e8f0;">${v}</td>`;
    const body = deleted.map(d =>
      `<tr>${cell(d.id)}${cell(d.name || '—')}${cell(d.email || '—')}${cell(new Date(d.created).toISOString())}</tr>`
    ).join('');
    const content = `
      <p>${deleted.length} inactive guest ID(s) with manual credit only were auto-deleted (3+ days, no login/play, no gateway deposit).</p>
      <table style="border-collapse:collapse;width:100%;font-size:14px;">
        <tr><th style="padding:6px 12px;border:1px solid #e2e8f0;text-align:left;">UID</th>
            <th style="padding:6px 12px;border:1px solid #e2e8f0;text-align:left;">Name</th>
            <th style="padding:6px 12px;border:1px solid #e2e8f0;text-align:left;">Email</th>
            <th style="padding:6px 12px;border:1px solid #e2e8f0;text-align:left;">Created</th></tr>
        ${body}
      </table>`;
    await emailService.sendGeneralEmail(to, `Auto-deleted ${deleted.length} inactive guest ID(s)`, {
      title: 'Inactive guest IDs removed',
      content,
    });
  } catch (err) {
    console.error('[autoDeleteGuests] notify failed:', err.message);
  }
}

// One pass. Returns the list of deleted users. Safe to call manually.
async function runOnce() {
  const deleted = [];
  try {
    const { rows: candidates } = await pg.query(CANDIDATE_SQL);
    if (!candidates.length) {
      console.log('[autoDeleteGuests] no candidates');
      return deleted;
    }
    console.log(`[autoDeleteGuests] ${candidates.length} candidate(s) to remove`);
    for (const u of candidates) {
      const ok = await deleteUserCascade(u.id);
      if (ok) {
        deleted.push(u);
        console.log(`[autoDeleteGuests] deleted guest ${u.id} (${u.name || ''})`);
      }
    }
    if (deleted.length) await notifyDeleted(deleted);
  } catch (err) {
    console.error('[autoDeleteGuests] run failed:', err.message);
  }
  return deleted;
}

// Schedule a daily run at 03:30 server time.
function schedule() {
  cron.schedule('30 3 * * *', () => {
    console.log('[autoDeleteGuests] daily run starting…');
    runOnce();
  });
  console.log('[autoDeleteGuests] scheduled (daily 03:30)');
}

module.exports = { schedule, runOnce, deleteUserCascade, CANDIDATE_SQL };

// Allow manual one-off run: `node maintenance/autoDeleteInactiveGuests.js --run`
if (require.main === module && process.argv.includes('--run')) {
  runOnce().then(d => { console.log(`Done. Deleted ${d.length}.`); process.exit(0); });
}
