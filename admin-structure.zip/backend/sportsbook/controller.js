const axios = require('axios');
const crypto = require('crypto');
const { v4: uuid } = require('uuid');
const Big = require('big.js');
const db = require('../General/Model');

/* ────────── Slotegrator Betting Aggregator credentials ────────── */
const BASE = 'https://gis-betting-stage.stgr.pw/api/v1';
const M_ID = 'REMOVED_SECRET';
const M_KEY = 'REMOVED_SECRET';

/* ────────── helpers (reuse same signing as GIS) ────────────────── */
const log = (...a) => console.log(new Date().toISOString(), '[sportsbook]', ...a);

const canon = v =>
  v === null || v === undefined ? '' :
    typeof v === 'number' || typeof v === 'bigint'
      ? Big(v).toString()
      : String(v);

const flatten = (obj, prefix = '') => {
  const out = [];
  if (Array.isArray(obj)) {
    obj.forEach((v, i) => out.push(...flatten(v, `${prefix}[${i}]`)));
  } else if (obj && typeof obj === 'object') {
    Object.keys(obj).forEach(k =>
      out.push(...flatten(obj[k], prefix ? `${prefix}[${k}]` : k)));
  } else {
    out.push([prefix, canon(obj)]);
  }
  return out;
};

const asciiSort = ([a], [b]) => (a < b ? -1 : a > b ? 1 : 0);

const baseHdr = () => ({
  'X-Merchant-Id': M_ID,
  'X-Timestamp': Math.floor(Date.now() / 1000).toString(),
  'X-Nonce': crypto.randomBytes(16).toString('hex')
});

const sign = (params, hdr) => {
  const merged = {
    'X-Merchant-Id': hdr['X-Merchant-Id'],
    'X-Timestamp': hdr['X-Timestamp'],
    'X-Nonce': hdr['X-Nonce'],
    ...params
  };
  const qs = flatten(merged)
    .sort(asciiSort)
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
    .join('&');
  return crypto.createHmac('sha1', M_KEY).update(qs).digest('hex');
};

const fail = (r, s, m) => r.status(s).json({ name: 'Error', message: m, code: 0, status: s });

/* ────────── GET /sportsbooks ──────────────────────────────────── */
async function getSportsbooks(req, res) {
  try {
    const hdr = { ...baseHdr() };
    hdr['X-Sign'] = sign({}, hdr);

    const response = await axios.get(`${BASE}/sportsbooks`, { headers: hdr });
    res.json({ success: true, data: response.data });
  } catch (e) {
    log('getSportsbooks error:', e.response?.data || e.message);
    fail(res, 500, e.response?.data?.message || 'Failed to fetch sportsbooks');
  }
}

/* ────────── POST /sportsbooks/init ────────────────────────────── */
async function initSportsbook(req, res) {
  const { sportsbook_uuid, player_id, player_name, currency, language, return_url, email } = req.body;

  if (!sportsbook_uuid) return fail(res, 422, 'sportsbook_uuid is required');
  if (!currency) return fail(res, 422, 'currency is required');

  try {
    const session_id = uuid();

    const hdr = {
      ...baseHdr(),
      'Content-Type': 'application/json'
    };

    const params = {
      sportsbook_uuid,
      currency: currency.toLowerCase() === 'usdt' ? 'USD' : currency,
      session_id,
    };

    // Add optional fields
    if (player_id) params.player_id = String(player_id);
    if (player_name) params.player_name = player_name;
    if (return_url) params.return_url = return_url;
    if (language) params.language = language;
    if (email) params.email = email;

    hdr['X-Sign'] = sign(params, hdr);

    log('POST /sportsbooks/init →', params);

    const response = await axios.post(`${BASE}/sportsbooks/init`, params, {
      headers: hdr
    });

    // Response contains { url: "https://..." } or HTML content
    res.json({
      success: true,
      url: response.data.url,
      session_id,
      token: response.data.token
    });
  } catch (e) {
    log('initSportsbook error:', e.response?.data || e.message);
    fail(res, 500, e.response?.data?.message || 'Failed to init sportsbook');
  }
}

/* ────────── GET /sportsbooks/launch ───────────────────────────── */
async function launchSportsbook(req, res) {
  const { url } = req.query;

  if (!url) return fail(res, 422, 'launch url is required');

  try {
    const clientIp = req.headers['x-forwarded-for']?.split(',')[0]?.trim()
      || req.connection?.remoteAddress;

    const headers = {};
    if (clientIp) headers['X-Client-Ip'] = clientIp;

    const response = await axios.get(url, {
      headers,
      maxRedirects: 0,
      validateStatus: (status) => status < 400
    });

    // BetBy returns HTML with initialization script
    const contentType = response.headers['content-type'] || '';
    if (contentType.includes('text/html') || typeof response.data === 'string') {
      res.json({ success: true, type: 'html', html: response.data });
    } else {
      // JSON response or redirect
      res.json({ success: true, type: 'redirect', data: response.data });
    }
  } catch (e) {
    // Handle 303 redirect (Atlas)
    if (e.response?.status === 303) {
      return res.json({
        success: true,
        type: 'redirect',
        url: e.response.headers.location
      });
    }
    log('launchSportsbook error:', e.response?.data || e.message);
    fail(res, 500, e.response?.data?.message || 'Failed to launch sportsbook');
  }
}

/* ────────── POST /sportsbooks/logout ──────────────────────────── */
async function logoutSportsbook(req, res) {
  const { token } = req.body;
  if (!token) return fail(res, 422, 'token is required');

  try {
    const hdr = {
      ...baseHdr(),
      'Content-Type': 'application/json'
    };
    hdr['X-Sign'] = sign({ token }, hdr);

    await axios.post(`${BASE}/sportsbooks/logout`, { token }, { headers: hdr });
    res.json({ success: true });
  } catch (e) {
    log('logoutSportsbook error:', e.response?.data || e.message);
    fail(res, 500, e.response?.data?.message || 'Failed to logout sportsbook');
  }
}

/* ────────── Token refresh endpoint for BetBy ──────────────────── */
async function refreshToken(req, res) {
  const { session_id, sportsbook_uuid, player_id, currency } = req.body;

  if (!sportsbook_uuid || !currency) {
    return fail(res, 422, 'sportsbook_uuid and currency are required');
  }

  try {
    // Re-init to get a fresh token
    const newSessionId = session_id || uuid();

    const hdr = {
      ...baseHdr(),
      'Content-Type': 'application/json'
    };

    const params = {
      sportsbook_uuid,
      currency: currency.toLowerCase() === 'usdt' ? 'USD' : currency,
      session_id: newSessionId,
    };
    if (player_id) params.player_id = String(player_id);

    hdr['X-Sign'] = sign(params, hdr);

    const response = await axios.post(`${BASE}/sportsbooks/init`, params, {
      headers: hdr
    });

    res.json({
      success: true,
      token: response.data.token,
      url: response.data.url,
      session_id: newSessionId
    });
  } catch (e) {
    log('refreshToken error:', e.response?.data || e.message);
    fail(res, 500, e.response?.data?.message || 'Failed to refresh token');
  }
}

module.exports = {
  getSportsbooks,
  initSportsbook,
  launchSportsbook,
  logoutSportsbook,
  refreshToken
};
