const express = require('express');
const router = express.Router();
const ctr = require('./controller');

/* ───── Sportsbook (Betting Aggregator) endpoints ──────────────── */
router.get('/sportsbooks', ctr.getSportsbooks);
router.post('/sportsbooks/init', ctr.initSportsbook);
router.get('/sportsbooks/launch', ctr.launchSportsbook);
router.post('/sportsbooks/logout', ctr.logoutSportsbook);
router.post('/sportsbooks/refresh-token', ctr.refreshToken);

module.exports = router;
