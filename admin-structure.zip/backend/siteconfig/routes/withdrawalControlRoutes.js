// Admin → Users → Financial → Withdrawal.
// Global withdrawal ON/OFF (siteconfig.withdrawals), per-player locks
// (users.withdrawal_locked) and the deposit-multiple cap for every player
// (siteconfig.withdrawal_limit_enabled + withdrawal_deposit_multiplier), plus
// the wagering bonus that raises that cap by the amount the player has bet
// (siteconfig.withdrawal_wager_bonus_enabled + withdrawal_wager_multiplier).
// Enforcement is in system/utils/withdrawalLocks.js.
module.exports = (io) => {
  const express = require('express');
  const pg = require('../../General/Model');
  const site = require('../model/siteconfigmodels');
  const { protectStaff } = require('../../system/middleware/auth');
  const { selfServeSql } = require('../../system/utils/branch');
  const { withActivity } = require('../../system/utils/recordActivity');
  const { validateTransactionPassword } = require('../../system/controllers/lordsController');
  const {
    DEFAULT_MULTIPLIER, DEFAULT_WAGER_MULTIPLIER, ensureWithdrawalLockColumns,
    getFunding, getWagered, computeLimit, getWithdrawalStatus,
  } = require('../../system/utils/withdrawalLocks');
  const MULTIPLIER_MIN = 0.1;
  const MULTIPLIER_MAX = 100;

  ensureWithdrawalLockColumns().catch(e =>
    console.error('[withdrawalControl] column setup failed:', e.message));

  const admin = express.Router();
  const pub = express.Router();

  const superAdminOnly = (req, res, next) => (
    Number(req.staff && req.staff.level) === 0
      ? next()
      : res.status(403).json({ success: false, message: 'Only SuperAdmin can manage withdrawal controls' })
  );
  admin.use(protectStaff, superAdminOnly);

  // GET /api/admin/withdrawal-control/summary
  admin.get('/summary', async (_req, res) => {
    try {
      await ensureWithdrawalLockColumns();
      const { rows } = await pg.query(`
        SELECT COALESCE((SELECT withdrawals FROM siteconfig LIMIT 1), true) AS withdrawals_enabled,
               COALESCE((SELECT withdrawal_limit_enabled FROM siteconfig LIMIT 1), true) AS limit_enabled,
               COALESCE((SELECT withdrawal_deposit_multiplier FROM siteconfig LIMIT 1), $1)::float AS deposit_multiplier,
               COALESCE((SELECT withdrawal_wager_bonus_enabled FROM siteconfig LIMIT 1), true) AS wager_bonus_enabled,
               COALESCE((SELECT withdrawal_wager_multiplier FROM siteconfig LIMIT 1), $2)::float AS wager_multiplier,
               (SELECT updatedat FROM siteconfig LIMIT 1) AS config_updated_at,
               (SELECT COUNT(*)::int FROM users u WHERE ${selfServeSql('u')}) AS direct_users,
               (SELECT COUNT(*)::int FROM users u WHERE ${selfServeSql('u')} AND u.withdrawal_locked) AS locked_direct_users
      `, [DEFAULT_MULTIPLIER, DEFAULT_WAGER_MULTIPLIER]);
      res.json({ success: true, ...rows[0] });
    } catch (e) {
      console.error('[withdrawalControl] summary failed:', e);
      res.status(500).json({ success: false, message: 'Failed to load withdrawal settings' });
    }
  });

  // PUT /api/admin/withdrawal-control/global  { enabled, transactionPassword }
  admin.put('/global',
    withActivity({
      action: 'withdrawals.global',
      describe: req => ({ targetType: 'SITECONFIG', details: { enabled: req.body && req.body.enabled } }),
    }),
    async (req, res) => {
      const { enabled, transactionPassword } = req.body || {};
      if (typeof enabled !== 'boolean') {
        return res.status(400).json({ success: false, message: 'enabled must be true or false' });
      }
      try {
        await validateTransactionPassword(req.staff.id, transactionPassword);
      } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
      }
      try {
        await ensureWithdrawalLockColumns();
        const cfg = await site.update({ withdrawals: enabled });
        if (!cfg) {
          return res.status(500).json({ success: false, message: 'siteconfig row is missing' });
        }
        io.to('room:global').emit('siteConfigUpdated', cfg);
        res.json({ success: true, withdrawals_enabled: cfg.withdrawals, config_updated_at: cfg.updatedat });
      } catch (e) {
        console.error('[withdrawalControl] global update failed:', e);
        res.status(500).json({ success: false, message: 'Failed to update withdrawals' });
      }
    });

  // PUT /api/admin/withdrawal-control/limit
  //   { enabled?, multiplier?, wager_enabled?, wager_multiplier?, transactionPassword }
  admin.put('/limit',
    withActivity({
      action: 'withdrawals.deposit_limit',
      describe: req => ({
        targetType: 'SITECONFIG',
        details: {
          enabled: req.body && req.body.enabled,
          multiplier: req.body && req.body.multiplier,
          wager_enabled: req.body && req.body.wager_enabled,
          wager_multiplier: req.body && req.body.wager_multiplier,
        },
      }),
    }),
    async (req, res) => {
      const { transactionPassword } = req.body || {};
      const fields = {};
      const switches = [
        ['enabled', 'withdrawal_limit_enabled'],
        ['wager_enabled', 'withdrawal_wager_bonus_enabled'],
      ];
      for (const [key, column] of switches) {
        const value = req.body && req.body[key];
        if (value === undefined) continue;
        if (typeof value !== 'boolean') {
          return res.status(400).json({ success: false, message: `${key} must be true or false` });
        }
        fields[column] = value;
      }
      const multipliers = [
        ['multiplier', 'withdrawal_deposit_multiplier', 'Multiplier'],
        ['wager_multiplier', 'withdrawal_wager_multiplier', 'Wagering bonus multiplier'],
      ];
      for (const [key, column, label] of multipliers) {
        if (!req.body || req.body[key] === undefined) continue;
        const multiplier = Math.round(Number(req.body[key]) * 100) / 100;
        if (!Number.isFinite(multiplier) || multiplier < MULTIPLIER_MIN || multiplier > MULTIPLIER_MAX) {
          return res.status(400).json({ success: false, message: `${label} must be between ${MULTIPLIER_MIN} and ${MULTIPLIER_MAX}` });
        }
        fields[column] = multiplier;
      }
      if (!Object.keys(fields).length) {
        return res.status(400).json({ success: false, message: 'Nothing to update' });
      }
      try {
        await validateTransactionPassword(req.staff.id, transactionPassword);
      } catch (e) {
        return res.status(400).json({ success: false, message: e.message });
      }
      try {
        await ensureWithdrawalLockColumns();
        const cfg = await site.update(fields);
        if (!cfg) {
          return res.status(500).json({ success: false, message: 'siteconfig row is missing' });
        }
        res.json({
          success: true,
          limit_enabled: cfg.withdrawal_limit_enabled,
          deposit_multiplier: Number(cfg.withdrawal_deposit_multiplier),
          wager_bonus_enabled: cfg.withdrawal_wager_bonus_enabled,
          wager_multiplier: Number(cfg.withdrawal_wager_multiplier),
          config_updated_at: cfg.updatedat,
        });
      } catch (e) {
        console.error('[withdrawalControl] limit update failed:', e);
        res.status(500).json({ success: false, message: 'Failed to update withdrawal limit' });
      }
    });

  // GET /api/admin/withdrawal-control/users?search=&status=all|locked&page=1&limit=20
  // deposited_inr / withdrawn_inr / wagered_inr and the resulting cap use the
  // same rules as the enforcement check.
  // Direct users only (no parent staff); agent-system players are locked from
  // their Risk Management dialog.
  admin.get('/users', async (req, res) => {
    const search = String(req.query.search || '').trim().slice(0, 100);
    const lockedOnly = req.query.status === 'locked';
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 100);
    const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
    const like = `%${search.replace(/[\\%_]/g, '\\$&')}%`;
    try {
      await ensureWithdrawalLockColumns();
      const { rows } = await pg.query(
        `SELECT u.id::text AS id, u.name, u.email, u.phone, u.country, u.created,
                COALESCE(c.inr, 0) AS inr_balance,
                COALESCE(u.withdrawal_locked, false) AS withdrawal_locked,
                COALESCE(u.system_locked, false) AS system_locked,
                COUNT(*) OVER()::int AS total
           FROM users u
           LEFT JOIN credits c ON c.uid = u.id
          WHERE ${selfServeSql('u')}
            AND ($1 = '' OR u.id::text = $1 OR u.name ILIKE $2 OR u.email ILIKE $2 OR u.phone ILIKE $2)
            AND (NOT $3::boolean OR COALESCE(u.withdrawal_locked, false))
          ORDER BY u.id DESC
          LIMIT $4 OFFSET $5`,
        [search, like, lockedOnly, limit, (page - 1) * limit]
      );
      const { rows: [cfg] } = await pg.query(
        `SELECT COALESCE((SELECT withdrawal_deposit_multiplier FROM siteconfig LIMIT 1), $1)::float AS multiplier,
                COALESCE((SELECT withdrawal_wager_bonus_enabled FROM siteconfig LIMIT 1), true) AS wager_bonus_enabled,
                COALESCE((SELECT withdrawal_wager_multiplier FROM siteconfig LIMIT 1), $2)::float AS wager_multiplier`,
        [DEFAULT_MULTIPLIER, DEFAULT_WAGER_MULTIPLIER]
      );
      // Page is at most 100 rows, so per-user funding lookups are cheap enough.
      const users = await Promise.all(rows.map(async ({ total, ...u }) => {
        const [f, wagered] = await Promise.all([getFunding(u.id, 'INR'), getWagered(u.id, 'INR')]);
        const l = computeLimit({
          currency: 'INR', ...f, wagered,
          multiplier: cfg.multiplier,
          wagerBonusEnabled: cfg.wager_bonus_enabled,
          wagerMultiplier: cfg.wager_multiplier,
        });
        return {
          ...u,
          deposited_inr: f.deposited,
          withdrawn_inr: f.withdrawn,
          wagered_inr: l.wagered,
          wager_bonus_inr: l.wager_bonus_unlocked,
          max_withdrawable_inr: l.max_withdrawable,
        };
      }));
      res.json({
        success: true,
        total: rows.length ? rows[0].total : 0,
        page,
        limit,
        users,
      });
    } catch (e) {
      console.error('[withdrawalControl] users failed:', e);
      res.status(500).json({ success: false, message: 'Failed to load users' });
    }
  });

  // PUT /api/admin/withdrawal-control/users/:id  { locked }
  admin.put('/users/:id',
    withActivity({
      action: 'user.withdrawal_lock',
      describe: req => ({
        targetType: 'USER', targetId: req.params.id,
        details: { withdrawal_locked: req.body && req.body.locked },
      }),
    }),
    async (req, res) => {
      const { locked } = req.body || {};
      if (!/^\d+$/.test(req.params.id)) {
        return res.status(400).json({ success: false, message: 'Invalid user id' });
      }
      if (typeof locked !== 'boolean') {
        return res.status(400).json({ success: false, message: 'locked must be true or false' });
      }
      try {
        await ensureWithdrawalLockColumns();
        const { rows } = await pg.query(
          `UPDATE users SET withdrawal_locked = $1 WHERE id = $2
           RETURNING id::text AS id, withdrawal_locked`,
          [locked, req.params.id]
        );
        if (!rows.length) return res.status(404).json({ success: false, message: 'User not found' });
        res.json({ success: true, user: rows[0] });
      } catch (e) {
        console.error('[withdrawalControl] user lock failed:', e);
        res.status(500).json({ success: false, message: 'Failed to update withdrawal lock' });
      }
    });

  // GET /api/withdrawal-status/:uid?currency=INR — lets the player wallet show
  // why withdrawals are unavailable (and how much the cap still allows)
  // before the player fills in the form.
  pub.get('/:uid', async (req, res) => {
    if (!/^\d+$/.test(req.params.uid)) {
      return res.status(400).json({ success: false, message: 'Invalid user id' });
    }
    try {
      const currency = /^[A-Za-z]{2,10}$/.test(req.query.currency || '') ? req.query.currency : undefined;
      const s = await getWithdrawalStatus(req.params.uid, currency);
      res.json({ success: true, ...s });
    } catch (e) {
      console.error('[withdrawalControl] status failed:', e.message);
      res.status(500).json({ success: false, message: 'Failed to load withdrawal status' });
    }
  });

  return { admin, public: pub };
};
