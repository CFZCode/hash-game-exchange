module.exports = io=>{
  const r=require('express').Router();
const { protectStaff } = require('../../system/middleware/auth');
  const c   =require('../controllers/adminConfigController')(io);

  /* Public bootstrap used by the frontend before the socket connects. */
  r.get('/global/public', c.getGlobal);

  r.get('/global',protectStaff,c.getGlobal);
  r.put('/global',protectStaff,c.updateGlobal);

  r.get('/user/:uid', protectStaff, c.getUser);
  r.put('/user/:uid', protectStaff, c.updateUser);
  return r;
};
