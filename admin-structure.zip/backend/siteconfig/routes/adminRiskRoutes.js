module.exports = () => {
  const r = require("express").Router();
  const pg = require("../../General/Model");
  const { protectStaff } = require("../../system/middleware/auth");
  const { withActivity } = require("../../system/utils/recordActivity");
  const { permittedIds } = require("../model/hierarchyModel");

  const safeQuery = async (sql, params = []) => {
    try {
      const { rows } = await pg.query(sql, params);
      return rows;
    } catch (e) {
      console.warn('[adminRisk] query failed:', e.message);
      return [];
    }
  };

  const sumDeposits = async (userId) => {
    const rows = await safeQuery(
      `SELECT COALESCE(SUM(amount::numeric),0) AS total, COUNT(*)::int AS cnt
         FROM fiat_deposits
        WHERE user_id = $1 AND status = 'approved' AND currency = 'INR'`,
      [userId]
    );
    return rows[0] || { total: 0, cnt: 0 };
  };

  const sumWithdrawals = async (userId) => {
    const rows = await safeQuery(
      `SELECT COALESCE(SUM(amount::numeric),0) AS total, COUNT(*)::int AS cnt
         FROM fiat_withdrawals
        WHERE uid = $1 AND status = 'Done' AND currency = 'INR'`,
      [userId]
    );
    return rows[0] || { total: 0, cnt: 0 };
  };

  // GET /api/admin/agent-users
  r.get('/agent-users', protectStaff, async (req, res) => {
    try {
      const ids = await permittedIds(req.staff.id, req.staff.level);
      const isSuper = req.staff.level === 0;
      const staffIdsOnly = ids.filter(x => x !== null);

      // Deposits/withdrawals must count EVERY way money reaches an agent-system
      // player, not just the bank rail. These accounts are funded by their agent
      // through `staff_transfers`, so a fiat-only total reads 0.00 for all of
      // them. Status filters mirror balancesheet/controller.js so this page, the
      // balance sheet and the account report always agree.
      //
      // PNL is the player's actual betting result (sports ledger + casino), NOT
      // deposits minus withdrawals — those are funding, not profit.
      const users = await safeQuery(
        `WITH scoped AS (
           SELECT u.id FROM users u
            WHERE u.parent_staff_id IS NOT NULL AND u.parent_staff_id = ANY($1)
            ORDER BY u.id DESC LIMIT 1000
         ),
         agent_mv AS (
           SELECT s.id AS uid,
                  COALESCE(SUM(t.amount) FILTER (WHERE t.to_type='user'),0)   AS in_amt,
                  COALESCE(SUM(t.amount) FILTER (WHERE t.from_type='user'),0) AS out_amt
             FROM scoped s
             JOIN staff_transfers t
               ON t.transfer_type='transfer'
              AND ((t.to_type='user' AND t.to_id = s.id) OR (t.from_type='user' AND t.from_id = s.id))
            GROUP BY s.id
         ),
         bank_in AS (
           SELECT s.id AS uid, COALESCE(SUM(d.amount::numeric),0) AS amt
             FROM scoped s JOIN fiat_deposits d ON d.user_id = s.id
            WHERE upper(d.currency)='INR'
              AND lower(d.status) IN ('approved','success','done','completed')
            GROUP BY s.id
         ),
         gw_in AS (
           SELECT s.id AS uid, COALESCE(SUM((CASE WHEN d.paid_amount > 0 THEN d.paid_amount ELSE d.amount END)::numeric),0) AS amt
             FROM scoped s JOIN apaydeposits d ON d.user_id = s.id
            WHERE upper(d.currency)='INR' AND d.status='Success'
            GROUP BY s.id
         ),
         bank_out AS (
           SELECT s.id AS uid, COALESCE(SUM(w.amount::numeric),0) AS amt
             FROM scoped s JOIN fiat_withdrawals w ON w.uid = s.id
            WHERE upper(w.currency)='INR' AND lower(w.status) NOT IN ('rejected','failed')
            GROUP BY s.id
         ),
         gw_out AS (
           SELECT s.id AS uid, COALESCE(SUM(w.amount::numeric),0) AS amt
             FROM scoped s JOIN apaywithdrawals w ON w.user_id = s.id::text
            WHERE upper(w.currency)='INR' AND w.status IN ('Success','Pending')
              AND COALESCE(w.refunded,false) = false
            GROUP BY s.id
         ),
         sports AS (
           SELECT s.id AS uid, COALESCE(SUM(cl.netamount),0) AS pnl
             FROM scoped s JOIN credits_ledger cl ON cl.user_id::text = s.id::text
            WHERE upper(cl.currency)='INR'
            GROUP BY s.id
         ),
         casino AS (
           SELECT s.id AS uid,
                  COALESCE(SUM(CASE WHEN g.action='bet' THEN -g.amount ELSE g.amount END),0) AS pnl
             FROM scoped s JOIN gis_transactions g ON g.user_id = s.id
            WHERE upper(g.currency) IN ('INR','PKR')
            GROUP BY s.id
         )
         SELECT u.id::text AS id, u.name, u.email, u.country, u.phone,
                COALESCE(u.system_locked,false) AS is_locked,
                COALESCE(u.sports_betlocked,false) AS sports_betlocked,
                u.parent_staff_id,
                COALESCE(u.is_demo,false) AS is_demo,
                ps.name AS staff_name, ps.email AS staff_email,
                COALESCE(am.in_amt,0)  + COALESCE(bi.amt,0) + COALESCE(gi.amt,0) AS total_deposit_inr,
                COALESCE(am.out_amt,0) + COALESCE(bo.amt,0) + COALESCE(go.amt,0) AS total_withdrawal_inr,
                COALESCE(sp.pnl,0) AS sports_pnl_inr,
                COALESCE(cs.pnl,0) AS casino_pnl_inr,
                COALESCE(sp.pnl,0) + COALESCE(cs.pnl,0) AS pnl_inr
           FROM scoped s
           JOIN users u ON u.id = s.id
           LEFT JOIN staff ps  ON ps.id = u.parent_staff_id
           LEFT JOIN agent_mv am ON am.uid = s.id
           LEFT JOIN bank_in  bi ON bi.uid = s.id
           LEFT JOIN gw_in    gi ON gi.uid = s.id
           LEFT JOIN bank_out bo ON bo.uid = s.id
           LEFT JOIN gw_out   go ON go.uid = s.id
           LEFT JOIN sports   sp ON sp.uid = s.id
           LEFT JOIN casino   cs ON cs.uid = s.id
          ORDER BY u.id DESC`,
        [staffIdsOnly]
      );

      const staffIdsForList = staffIdsOnly.filter(x => x !== req.staff.id);
      const staff = staffIdsForList.length
        ? await safeQuery(
            `SELECT s.id::text AS id, s.name, s.email, s.country, s.phone,
                    s.role_id, r.name AS role_name, r.level AS role_level,
                    s.parent_id::text AS parent_id, ps.name AS parent_name,
                    COALESCE(s.system_locked,false) AS system_locked,
                    COALESCE(s.sports_betlocked,false) AS sports_betlocked,
                    s.created_at
               FROM staff s
               JOIN roles r ON r.id = s.role_id
               LEFT JOIN staff ps ON ps.id = s.parent_id
              WHERE s.id = ANY($1)
              ORDER BY r.level ASC, s.id`,
            [staffIdsForList]
          )
        : [];

      res.json({
        currency: 'INR',
        scope: { isSuperAdmin: isSuper, staffId: req.staff.id },
        count: users.length + staff.length,
        users,
        staff,
      });
    } catch (err) {
      console.error('[agent-users] failed:', err);
      res.status(500).json({ status: 'fail', message: 'Failed to load agent users' });
    }
  });

  // GET /api/admin/user-risk/:userId
  r.get('/user-risk/:userId', protectStaff, async (req, res) => {
    try {
      const userId = req.params.userId;
      const ids = await permittedIds(req.staff.id, req.staff.level);
      const isSuper = req.staff.level === 0;

      const userRows = await safeQuery(
        `SELECT u.id::text AS id, u.name, u.email, u.country, u.phone,
                u.created, u.updated_at, u.level, u.games_played,
                COALESCE(u.two_fa_status,false) AS two_fa_status,
                u.parent_staff_id,
                ps.name AS staff_name, ps.email AS staff_email,
                COALESCE(u.system_locked,false) AS is_locked,
                COALESCE(u.lock_targetx,false) AS lock_targetx,
                COALESCE(u.sports_betlocked,false) AS sports_betlocked,
                COALESCE(u.casino_locked,false) AS casino_locked,
                COALESCE(u.withdrawal_locked,false) AS withdrawal_locked,
                COALESCE(u.is_demo,false) AS is_demo
           FROM users u
           LEFT JOIN staff ps ON ps.id = u.parent_staff_id
          WHERE u.id::text = $1`,
        [userId]
      );

      if (!userRows.length) {
        return res.status(404).json({ status: 'fail', message: 'User not found' });
      }
      const u = userRows[0];

      const inScope =
        isSuper ||
        (u.parent_staff_id != null && ids.includes(Number(u.parent_staff_id)));
      if (!inScope) {
        return res.status(403).json({ status: 'fail', message: 'Out of scope' });
      }

      const dep = await sumDeposits(userId);
      const wdr = await sumWithdrawals(userId);

      const recentLogins = await safeQuery(
        `SELECT id, ip_address, user_agent, created_at
           FROM user_login_history
          WHERE user_id::text = $1
          ORDER BY created_at DESC
          LIMIT 15`,
        [userId]
      );

      const lastLogin = recentLogins[0] || null;

      const ipBreakdownRaw = await safeQuery(
        `SELECT ip_address,
                COUNT(*)::int AS uses,
                MIN(created_at) AS first_seen,
                MAX(created_at) AS last_seen
           FROM user_login_history
          WHERE user_id::text = $1 AND ip_address IS NOT NULL
          GROUP BY ip_address
          ORDER BY last_seen DESC
          LIMIT 25`,
        [userId]
      );

      const recentBets = await safeQuery(
        `SELECT sb.id, sb.ip_address,
                COALESCE(sb.created_at, sb.updated_at) AS created_at,
                sb.stake_amount,
                COALESCE(sb.original_currency,'INR') AS original_currency,
                sb.status, sb.result_status
           FROM "SportsBet" sb
          WHERE sb.user_id::text = $1
          ORDER BY COALESCE(sb.created_at, sb.updated_at) DESC
          LIMIT 10`,
        [userId]
      );

      const distinctIps = ipBreakdownRaw.map(r => r.ip_address);
      const netInr = Number(dep.total) - Number(wdr.total);

      res.json({
        currency: 'INR',
        user: {
          id: u.id,
          name: u.name || '',
          email: u.email || '',
          country: u.country || '',
          phone: u.phone || '',
          created: u.created,
          updated_at: u.updated_at,
          level: Number(u.level || 0),
          games_played: Number(u.games_played || 0),
          two_fa_status: !!u.two_fa_status,
          parent_staff_id: u.parent_staff_id,
          staff_name: u.staff_name,
          staff_email: u.staff_email,
          is_demo: !!u.is_demo,
          is_direct: u.parent_staff_id != null && Number(u.parent_staff_id) === Number(req.staff.id),
          last_ip: lastLogin ? (lastLogin.ip_address || null) : null,
          last_login_at: lastLogin ? (lastLogin.created_at || null) : null,
        },
        locks: {
          is_locked: !!u.is_locked,
          lock_targetx: !!u.lock_targetx,
          sports_betlocked: !!u.sports_betlocked,
          casino_locked: !!u.casino_locked,
          withdrawal_locked: !!u.withdrawal_locked,
        },
        financials: {
          total_deposit_inr: String(dep.total || 0),
          total_withdrawal_inr: String(wdr.total || 0),
          net_inr: String(netInr),
          deposit_count: Number(dep.cnt || 0),
          withdrawal_count: Number(wdr.cnt || 0),
        },
        activity: {
          source: 'user_login_history + SportsBet',
          distinct_ip_count: distinctIps.length,
          distinct_ips: distinctIps,
          ip_breakdown: ipBreakdownRaw,
          recent_logins: recentLogins,
          recent_bets: recentBets,
        },
        risk_flags: {
          multiple_ips: distinctIps.length > 1,
          two_fa_disabled: !u.two_fa_status,
          high_withdrawal_ratio: Number(dep.total) > 0 && Number(wdr.total) / Number(dep.total) > 0.9,
          no_activity: distinctIps.length === 0 && recentBets.length === 0,
        },
        timestamp: new Date().toISOString(),
      });
    } catch (err) {
      console.error('[user-risk] failed:', err);
      res.status(500).json({ status: 'fail', message: 'Failed to load risk data' });
    }
  });

  // POST /api/admin/user-lock
  r.post('/user-lock', protectStaff,
    withActivity({
      action: 'user.lock',
      describe: req => ({
        targetType: 'USER', targetId: req.body && req.body.user_id,
        details: req.body ? {
          is_locked: req.body.is_locked,
          sports_betlocked: req.body.sports_betlocked,
          casino_locked: req.body.casino_locked,
          lock_targetx: req.body.lock_targetx,
          withdrawal_locked: req.body.withdrawal_locked,
        } : undefined,
      }),
    }),
    async (req, res) => {
    try {
      const { user_id, is_locked, sports_betlocked, lock_targetx, casino_locked, withdrawal_locked } = req.body || {};
      if (!user_id) {
        return res.status(400).json({ status: 'fail', message: 'user_id required' });
      }

      const ids = await permittedIds(req.staff.id, req.staff.level);
      const isSuper = req.staff.level === 0;

      const userRows = await safeQuery(
        `SELECT id, parent_staff_id FROM users WHERE id::text = $1`,
        [String(user_id)]
      );
      if (!userRows.length) {
        return res.status(404).json({ status: 'fail', message: 'User not found' });
      }
      const u = userRows[0];
      const inScope =
        isSuper ||
        (u.parent_staff_id != null && ids.includes(Number(u.parent_staff_id)));
      if (!inScope) {
        return res.status(403).json({ status: 'fail', message: 'Out of scope' });
      }

      const sets = [];
      const vals = [];
      let idx = 1;
      if (is_locked !== undefined) { sets.push(`system_locked = $${idx++}`); vals.push(!!is_locked); }
      if (sports_betlocked !== undefined) { sets.push(`sports_betlocked = $${idx++}`); vals.push(!!sports_betlocked); }
      if (casino_locked !== undefined) { sets.push(`casino_locked = $${idx++}`); vals.push(!!casino_locked); }
      if (lock_targetx !== undefined) { sets.push(`lock_targetx = $${idx++}`); vals.push(!!lock_targetx); }
      if (withdrawal_locked !== undefined) { sets.push(`withdrawal_locked = $${idx++}`); vals.push(!!withdrawal_locked); }
      if (!sets.length) {
        return res.status(400).json({ status: 'fail', message: 'No lock fields provided' });
      }
      vals.push(String(user_id));
      const { rows } = await pg.query(
        `UPDATE users SET ${sets.join(', ')}
          WHERE id::text = $${idx}
        RETURNING COALESCE(system_locked,false) AS is_locked,
                  COALESCE(sports_betlocked,false) AS sports_betlocked,
                  COALESCE(casino_locked,false) AS casino_locked,
                  COALESCE(lock_targetx,false) AS lock_targetx,
                  COALESCE(withdrawal_locked,false) AS withdrawal_locked`,
        vals
      );

      res.json({ success: true, user: rows[0] });
    } catch (err) {
      console.error('[user-lock] failed:', err);
      res.status(500).json({ status: 'fail', message: 'Failed to update lock' });
    }
  });

  return r;
};
