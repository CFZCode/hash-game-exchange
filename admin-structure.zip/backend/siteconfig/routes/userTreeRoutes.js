module.exports = () => {
  const r   = require("express").Router();
  const { protectStaff } = require("../../system/middleware/auth");
  const { listUsersTree } = require("../model/hierarchyModel");

  // GET /api/admin/users/tree
  r.get("/tree", protectStaff, async (req,res) => {
    console.log(req.staff);
    const data = await listUsersTree(req.staff.id, req.staff.level);
    res.json(data);
  });

  return r;
};
