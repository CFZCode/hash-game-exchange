/**
 * Site Config + Providers — idempotent schema migration.
 * Run with: node siteconfig/migration.js
 *
 * Adds missing boolean columns to `siteconfig` for sidebar + home-page
 * sections, and adds an `enabled` column to `gis_providers_new`.
 */
const pg = require('../General/Model');

/* Columns controlled by the admin Site Config panel.
 * Only sections that actually render in the sidebar + home page are listed —
 * unused flags (sports, livecasino, providers, blog, esports, promotions,
 * home_categorybanner, home_livesports, home_hotgames, home_providers) have
 * been removed so the admin panel doesn't expose toggles that don't do
 * anything. The columns may still exist in older DBs from prior migrations;
 * they're harmless and ignored by the app. */
const SITECONFIG_COLUMNS = [
  /* sidebar / top-level features */
  'casino', 'wheelspin', 'welcomepack', 'provablyfair', 'vipclub',
  'bonus', 'affiliate', 'giftcards', 'withdrawals',

  /* sports module toggles */
  'sports', 'home_livesports',

  /* home page sections */
  'home_heroSection',
  'home_welcomebanner',
  'home_latestwins',
  'home_livecasino',
  'home_gamingcards',
  'home_popularslots',
  'home_bonus500banner',
  'home_crashgames',
  'home_paymentbanner',
  'home_leaderboard',
  'home_promocards',
];

/* Columns that were previously created but are no longer used by the app.
 * Dropped during migration to keep the DB clean. */
const DEPRECATED_COLUMNS = [
  'livecasino', 'providers', 'blog', 'esports', 'promotions',
  'home_categorybanner', 'home_hotgames', 'home_providers',
  'home_indiangames',
];

async function ensureSiteConfigColumns() {
  const existing = await pg.query(`
    SELECT column_name FROM information_schema.columns
    WHERE table_schema='public' AND table_name='siteconfig'
  `);
  const have = new Set(existing.rows.map(r => r.column_name.toLowerCase()));

  for (const col of SITECONFIG_COLUMNS) {
    if (have.has(col.toLowerCase())) continue;
    console.log(`ALTER TABLE siteconfig ADD COLUMN "${col}" boolean DEFAULT true NOT NULL`);
    await pg.query(
      `ALTER TABLE siteconfig ADD COLUMN "${col}" boolean DEFAULT true NOT NULL`
    );
  }
}

async function ensureSiteConfigRow() {
  const { rows } = await pg.query('SELECT COUNT(*)::int AS c FROM siteconfig');
  if (!rows[0].c) {
    await pg.query(`
      INSERT INTO siteconfig (registerbonus, affiliatebonus, comissionpercent, createdat, updatedat)
      VALUES (100, 10, 5, NOW(), NOW())
    `);
    console.log('Inserted default siteconfig row');
  }
}

async function dropDeprecatedColumns() {
  const existing = await pg.query(`
    SELECT column_name FROM information_schema.columns
    WHERE table_schema='public' AND table_name='siteconfig'
  `);
  const have = new Set(existing.rows.map(r => r.column_name.toLowerCase()));

  for (const col of DEPRECATED_COLUMNS) {
    if (!have.has(col.toLowerCase())) continue;
    console.log(`ALTER TABLE siteconfig DROP COLUMN "${col}"`);
    await pg.query(`ALTER TABLE siteconfig DROP COLUMN "${col}"`);
  }
}

async function ensureProvidersEnabledColumn() {
  const { rows } = await pg.query(`
    SELECT column_name FROM information_schema.columns
    WHERE table_schema='public' AND table_name='gis_providers_new' AND column_name='enabled'
  `);
  if (!rows.length) {
    console.log('ALTER TABLE gis_providers_new ADD COLUMN enabled boolean DEFAULT true NOT NULL');
    await pg.query(
      'ALTER TABLE gis_providers_new ADD COLUMN enabled boolean DEFAULT true NOT NULL'
    );
  }
}

/* Sports bet limits — not booleans-defaulting-true, so they live outside
 * SITECONFIG_COLUMNS. Enforced in sportsmain/API/controller.js placeBet. */
async function ensureSportsBetLimitColumns() {
  await pg.query(
    `ALTER TABLE siteconfig ADD COLUMN IF NOT EXISTS sports_match_odds_limit_enabled boolean DEFAULT true NOT NULL`
  );
  await pg.query(
    `ALTER TABLE siteconfig ADD COLUMN IF NOT EXISTS sports_match_max_odds numeric DEFAULT 4 NOT NULL`
  );
}

async function run() {
  try {
    await ensureSiteConfigColumns();
    await ensureSportsBetLimitColumns();
    await dropDeprecatedColumns();
    await ensureSiteConfigRow();
    await ensureProvidersEnabledColumn();
    console.log('Site config migration complete.');
  } catch (e) {
    console.error('Migration failed:', e);
    process.exit(1);
  } finally {
    process.exit(0);
  }
}

if (require.main === module) run();
module.exports = {
  SITECONFIG_COLUMNS,
  DEPRECATED_COLUMNS,
  ensureSiteConfigColumns,
  ensureSportsBetLimitColumns,
  dropDeprecatedColumns,
  ensureProvidersEnabledColumn,
};
