module.exports = io => {
  const site = require("../model/siteconfigmodels");
  const user = require("../model/userconfigmodel");
  const { permittedIds } = require("../model/hierarchyModel");
  const { validateTransactionPassword } = require("../../system/controllers/lordsController");

  const ROOM = { g:"room:global", u:id=>`room:user:${id}` };

  const emitGlobal = cfg       => io.to(ROOM.g).emit("siteConfigUpdated", cfg);
  const emitUser   = (id,cfg)  => io.to(ROOM.u(id)).emit("userConfigUpdated", cfg);

  /* Sports bet limits apply platform-wide, so unlike the feature toggles they
   * are SuperAdmin-only; an executive of a SuperAdmin also needs the
   * canEditSportsBetLimits authority. */
  const SPORTS_LIMIT_FIELDS = ["sports_match_odds_limit_enabled", "sports_match_max_odds"];

  const WITHDRAWAL_FIELDS = [
    "withdrawals", "withdrawal_limit_enabled", "withdrawal_deposit_multiplier",
    "withdrawal_wager_bonus_enabled", "withdrawal_wager_multiplier",
  ];

  const checkSportsLimitFields = (staff, fields) => {
    if (!SPORTS_LIMIT_FIELDS.some(k => k in fields)) return null;

    const execAllowed = !staff.executive_id ||
      !!staff.executive_permissions?.authority?.canEditSportsBetLimits;
    if (Number(staff.level) !== 0 || !execAllowed) {
      return { status: 403, message: "Only SuperAdmin can change sports bet limits" };
    }

    if ("sports_match_odds_limit_enabled" in fields) {
      fields.sports_match_odds_limit_enabled = fields.sports_match_odds_limit_enabled === true;
    }
    if ("sports_match_max_odds" in fields) {
      const n = Number(fields.sports_match_max_odds);
      if (!Number.isFinite(n) || n <= 1 || n > 1000) {
        return { status: 400, message: "Max odds must be between 1.01 and 1000" };
      }
      fields.sports_match_max_odds = Math.round(n * 100) / 100;
    }
    return null;
  };

  return {
    async getGlobal(_req,res){ res.json(await site.get()); },

    async updateGlobal(req,res){
      try {
        const { transactionPassword, ...fields } = req.body || {};
        const limitErr = checkSportsLimitFields(req.staff, fields);
        if (limitErr) return res.status(limitErr.status).json({ message: limitErr.message });
        /* Withdrawal controls are SuperAdmin-only (see withdrawalControlRoutes). */
        if (WITHDRAWAL_FIELDS.some(k => k in fields) && Number(req.staff.level) !== 0) {
          return res.status(403).json({ message: "Only SuperAdmin can change withdrawal controls" });
        }
        await validateTransactionPassword(req.staff.id, transactionPassword);
        if (!Object.keys(fields).length) {
          return res.status(400).json({ message: "Nothing to update" });
        }
        const up = await site.update(fields);
        emitGlobal(up);
        res.json(up);
      } catch (e) {
        return res.status(400).json({ message: e.message || "Update failed" });
      }
    },

    async getUser(req,res){
      const uid = req.params.uid;
      const ids = await permittedIds(req.staff.id, req.staff.level);
      if (!ids.includes(req.staff.level === 0 ? uid : req.staff.id) &&
          !ids.includes(req.staff.level === 0 ? null : uid))
        return res.sendStatus(403);
      res.json(await user.get(uid));
    },

    async updateUser(req,res){
      const uid = req.params.uid;
      const ids = await permittedIds(req.staff.id, req.staff.level);
      if (!ids.includes(req.staff.level === 0 ? uid : req.staff.id) &&
          !ids.includes(req.staff.level === 0 ? null : uid))
        return res.sendStatus(403);
      const up = await user.update(uid, req.body);
      emitUser(uid, up);
      res.json(up);
    }
  };
};
