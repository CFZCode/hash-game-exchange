const pg = require('../../General/Model');
function buildUpdate(obj, start=1){
  const k=Object.keys(obj);
  return { clause:k.map((c,i)=>`"${c}"=$${i+start}`).join(','),
           values:k.map(c=>obj[c]) };
}
module.exports={
  async get(){
    const {rows}=await pg.query('SELECT * FROM siteconfig LIMIT 1');
    return rows[0] || {
      /* sidebar / top-level features */
      casino: true,
      wheelspin: true,
      welcomepack: true,
      provablyfair: true,
      vipclub: true,
      bonus: true,
      affiliate: true,
      giftcards: true,
      withdrawals: true,

      /* home page sections */
      home_heroSection: true,
      home_welcomebanner: true,
      home_latestwins: true,
      home_livecasino: true,
      home_gamingcards: true,
      home_popularslots: true,
      home_bonus500banner: true,
      home_crashgames: true,
      home_paymentbanner: true,
      home_leaderboard: true,
      home_promocards: true,
    };
  },
  async update(f){ const {clause,values}=buildUpdate(f);
    const {rows}=await pg.query(`UPDATE siteconfig SET ${clause},updatedat=now() RETURNING *`,values);
    return rows[0]; }
};
module.exports.buildUpdate=buildUpdate;
