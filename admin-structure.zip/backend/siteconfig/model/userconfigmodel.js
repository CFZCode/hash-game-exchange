const pg=require('../../General/Model');
const {buildUpdate}=require('./siteconfigmodels');
module.exports={
  async get(uid){
    const {rows}=await pg.query('SELECT * FROM userconfig WHERE uid=$1',[uid]);
    return rows[0] || {
      uid: uid,
      // Add default user config values here
    };
  },
  async update(uid,f){const {clause,values}=buildUpdate(f);values.push(uid);
    const {rows}=await pg.query(`UPDATE userconfig SET ${clause},updatedat=now() WHERE uid=$${values.length} RETURNING *`,values);
    return rows[0];}
};
