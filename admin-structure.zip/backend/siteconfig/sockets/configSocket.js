const ROOM = { g: 'room:global', u: id => `room:user:${id}` };
const siteModel = require('../model/siteconfigmodels');
const userModel = require('../model/userconfigmodel');
const gisCtr = require('../../gis/controller');
const db = require('../../General/Model');

async function fetchProviders() {
  try {
    const { rows } = await db.query(
      'SELECT name, enabled FROM gis_providers_new ORDER BY name'
    );
    return rows;
  } catch (e) {
    return [];
  }
}

module.exports = io => {
  /* let the gis controller broadcast provider toggles through us */
  if (gisCtr.setProvidersEmitter) {
    gisCtr.setProvidersEmitter(rows => {
      io.to(ROOM.g).emit('providersConfigUpdated', rows);
    });
  }

  io.on('connection', async socket => {
    /* everyone joins the global room right away */
    socket.join(ROOM.g);
    socket.emit('siteConfigUpdated', await siteModel.get());
    socket.emit('providersConfigUpdated', await fetchProviders());

    /* ① wait for the client to tell us its uid */
   socket.on("identify", async (raw, ack) => {
  const uid = Number(raw);
  console.log('identity uid',uid);
  if (!uid || isNaN(uid)) {
    socket.emit("identify-error", "uid must be a number");
    return;
  }
  socket.userid = uid;
  socket.join(ROOM.u(uid));

  const cfg = await userModel.get(uid);
  socket.emit("userConfigUpdated", cfg);

  /* optional: acknowledge */
  if (typeof ack === "function") ack({ ok: true });
});


    /* optional: allow re-subscribing to another uid (admin preview) */
    socket.on('subscribeUserConfig', id => socket.join(ROOM.u(id)));
  });
};
