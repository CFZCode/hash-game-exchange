// controllers/exchangeRateController.js

const pg = require('../General/Model');

const exchangeRateController = {
    // Get all exchange rates
    getAllRates: async (req, res) => {
        try {
            const query = 'SELECT currency, usd_rate, last_updated FROM exchangerate ORDER BY currency';
            const result = await pg.query(query);
            
            res.status(200).json({
                success: true,
                data: result.rows
            });
        } catch (error) {
            res.status(500).json({
                success: false,
                message: 'Error fetching exchange rates',
                error: error.message
            });
        }
    },

    // Get rate by currency
    getRateByCurrency: async (req, res) => {
        try {
            const { currency } = req.params;
            const query = 'SELECT currency, usd_rate, last_updated FROM exchangerate WHERE UPPER(currency) = UPPER($1)';
            const result = await pg.query(query, [currency]);

            if (result.rows.length === 0) {
                return res.status(404).json({
                    success: false,
                    message: 'Currency not found'
                });
            }

            res.status(200).json({
                success: true,
                data: result.rows[0]
            });
        } catch (error) {
            res.status(500).json({
                success: false,
                message: 'Error fetching exchange rate',
                error: error.message
            });
        }
    },

    // Add new currency and rate
    addRate: async (req, res) => {
        try {
            const { currency, usd_rate } = req.body;

            // Validation
            if (!currency || !usd_rate) {
                return res.status(400).json({
                    success: false,
                    message: 'Currency and rate are required'
                });
            }

            if (usd_rate <= 0) {
                return res.status(400).json({
                    success: false,
                    message: 'Rate must be greater than 0'
                });
            }

            const query = `
                INSERT INTO exchangerate (currency, usd_rate)
                VALUES (UPPER($1), $2)
                RETURNING currency, usd_rate, last_updated
            `;
            const result = await pg.query(query, [currency, usd_rate]);

            res.status(201).json({
                success: true,
                message: 'Exchange rate added successfully',
                data: result.rows[0]
            });
        } catch (error) {
            if (error.constraint === 'unique_currency') {
                return res.status(409).json({
                    success: false,
                    message: 'Currency already exists'
                });
            }

            res.status(500).json({
                success: false,
                message: 'Error adding exchange rate',
                error: error.message
            });
        }
    },

    // Update rate for a currency
    updateRate: async (req, res) => {
        try {
            const { currency } = req.params;
            const { usd_rate } = req.body;

            // Validation
            if (!usd_rate) {
                return res.status(400).json({
                    success: false,
                    message: 'Rate is required'
                });
            }

            if (usd_rate <= 0) {
                return res.status(400).json({
                    success: false,
                    message: 'Rate must be greater than 0'
                });
            }

            const query = `
                UPDATE exchangerate 
                SET usd_rate = $1, last_updated = CURRENT_TIMESTAMP
                WHERE UPPER(currency) = UPPER($2)
                RETURNING currency, usd_rate, last_updated
            `;
            const result = await pg.query(query, [usd_rate, currency]);

            if (result.rows.length === 0) {
                return res.status(404).json({
                    success: false,
                    message: 'Currency not found'
                });
            }

            res.status(200).json({
                success: true,
                message: 'Exchange rate updated successfully',
                data: result.rows[0]
            });
        } catch (error) {
            res.status(500).json({
                success: false,
                message: 'Error updating exchange rate',
                error: error.message
            });
        }
    },

    // Delete a currency
    deleteRate: async (req, res) => {
        try {
            const { currency } = req.params;
            const query = 'DELETE FROM exchangerate WHERE UPPER(currency) = UPPER($1) RETURNING currency';
            const result = await pg.query(query, [currency]);

            if (result.rows.length === 0) {
                return res.status(404).json({
                    success: false,
                    message: 'Currency not found'
                });
            }

            res.status(200).json({
                success: true,
                message: 'Exchange rate deleted successfully',
                data: result.rows[0]
            });
        } catch (error) {
            res.status(500).json({
                success: false,
                message: 'Error deleting exchange rate',
                error: error.message
            });
        }
    },

    // Convert an amount between currencies using usd_rate as the bridge.
    // usd_rate = value of 1 unit of that currency in USD; USD itself = 1.
    // GET /exchangeRate/convert?from=EUR&to=INR&amount=100
    // GET /exchangeRate/convert/EUR/INR/100
    convertCurrency: async (req, res) => {
        try {
            const from = String(req.query.from ?? req.params.from ?? '').toUpperCase().trim();
            const to = String(req.query.to ?? req.params.to ?? '').toUpperCase().trim();
            const rawAmount = req.query.amount ?? req.params.amount ?? 1;
            const amount = parseFloat(rawAmount);

            if (!from || !to) {
                return res.status(400).json({ success: false, message: 'from and to currencies are required' });
            }
            if (isNaN(amount)) {
                return res.status(400).json({ success: false, message: 'amount must be a number' });
            }

            // Resolve the USD rate for a currency. USD is the base unit (rate = 1).
            const getRate = async (cur) => {
                if (cur === 'USD') return 1;
                const r = await pg.query(
                    'SELECT usd_rate FROM exchangerate WHERE UPPER(currency) = UPPER($1) LIMIT 1',
                    [cur]
                );
                return r.rows.length === 0 ? null : parseFloat(r.rows[0].usd_rate);
            };

            const fromRate = await getRate(from);
            const toRate = await getRate(to);

            if (fromRate === null) {
                return res.status(404).json({ success: false, message: `Unknown currency: ${from}` });
            }
            if (toRate === null) {
                return res.status(404).json({ success: false, message: `Unknown currency: ${to}` });
            }
            if (!toRate) {
                return res.status(400).json({ success: false, message: `No valid rate available for ${to}` });
            }

            const rate = fromRate / toRate;            // 1 `from` = rate `to`
            const convertedAmount = amount * rate;     // amount `from` in `to`

            res.status(200).json({
                success: true,
                data: {
                    from,
                    to,
                    amount,
                    rate: Number(rate.toFixed(8)),
                    converted_amount: Number(convertedAmount.toFixed(8))
                }
            });
        } catch (error) {
            res.status(500).json({
                success: false,
                message: 'Error converting currency',
                error: error.message
            });
        }
    }
};

module.exports = exchangeRateController;