const crypto = require('crypto');
const axios = require('axios');
const pg = require('../General/Model');
const { withTransaction } = require('../General/Model/pool');
const { rsaSign, rsaVerify, notifyAdmin } = require('./controller');
const { assertWithdrawalAllowed } = require('../system/utils/withdrawalLocks');

const MERCHANT_ID = process.env.F2PAY_MERCHANT_ID || 'F2_6300';
const F2PAYURL = process.env.F2PAY_URL || 'https://api.f2pay.com';
const PAYOUT_NOTIFY_URL = 'https://example.com/f2pay/payout-notify';

// Merchant F2_6300 ke BANK_INR limits (f2pay dashboard, 2026-08).
const MIN_WITHDRAWAL = 100;
const MAX_WITHDRAWAL = 30000;
const IFSC_RE = /^[A-Z]{4}0[A-Z0-9]{6}$/;

// User direct payout — koi admin approval nahi. Balance pehle debit hota hai,
// f2pay fail kare to refundOnce() wapas kar deta hai.
module.exports.request = async (req, res) => {
    try {
        const { user_id } = req.body;
        if (!user_id) return res.status(400).json({ success: false, message: 'user_id is required' });

        const amount = Number(req.body.amount);
        if (!Number.isFinite(amount) || amount <= 0) {
            return res.status(400).json({ success: false, message: 'Invalid amount' });
        }
        if (amount < MIN_WITHDRAWAL || amount > MAX_WITHDRAWAL) {
            return res.status(400).json({ success: false, message: `Amount must be between ${MIN_WITHDRAWAL} and ${MAX_WITHDRAWAL}` });
        }

        try {
            await assertWithdrawalAllowed(user_id, { amount, currency: 'INR' });
        } catch (e) {
            return res.status(403).json({ success: false, message: e.message, code: e.code || 'WITHDRAWAL_BLOCKED' });
        }

        const accountNumber = String(req.body.accountNumber || '').trim();
        const ifsc = String(req.body.ifsc || '').trim().toUpperCase();
        const accountHolderName = String(req.body.accountHolderName || '').trim();
        const customerPhone = String(req.body.customerPhone || '').trim();
        const customerEmail = String(req.body.customerEmail || '').trim();

        if (!accountNumber || !accountHolderName) {
            return res.status(400).json({ success: false, message: 'Account number and account holder name are required' });
        }
        if (!IFSC_RE.test(ifsc)) {
            return res.status(400).json({ success: false, message: 'Invalid IFSC code' });
        }
        if (!customerPhone || !customerEmail) {
            return res.status(400).json({ success: false, message: 'Phone number and email are required' });
        }

        const mchOrderNo = 'F2W_' + Date.now() + '_' + crypto.randomBytes(4).toString('hex');

        // Balance check + debit + Pending row — sab ek transaction me, row lock ke saath,
        // taaki do parallel withdrawals balance overdraw na kar saken.
        try {
            await withTransaction(async (client) => {
                const bal = await client.query(
                    `SELECT COALESCE(inr, 0) AS balance FROM credits WHERE uid = $1 FOR UPDATE`,
                    [user_id]
                );
                if (bal.rows.length === 0) throw new Error('User not found');
                if (Number(bal.rows[0].balance) < amount) throw new Error('Insufficient balance');

                await client.query(
                    `UPDATE credits SET inr = COALESCE(inr, 0) - $1 WHERE uid = $2`,
                    [amount, user_id]
                );
                await client.query(
                    `INSERT INTO f2paywithdrawals
                        (mch_order_no, user_id, amount, currency, status,
                         account_number, ifsc, account_holder_name, customer_phone, customer_email)
                     VALUES ($1, $2, $3, 'INR', 'Pending', $4, $5, $6, $7, $8)`,
                    [mchOrderNo, user_id, amount, accountNumber, ifsc, accountHolderName, customerPhone, customerEmail]
                );
            });
        } catch (e) {
            return res.status(400).json({ success: false, message: e.message });
        }

        // Ab f2pay ko payout bhejo.
        const bizContent = JSON.stringify({
            amount: amount.toFixed(2),
            mchOrderNo,
            methodCode: 'BANK_INR',
            notifyUrl: PAYOUT_NOTIFY_URL,
            customerAccountNum: accountNumber,
            customerName: accountHolderName,
            ifsc,
            customerPhone,
            customerEmail,
        });
        const payload = {
            traceId: mchOrderNo,
            merchantId: MERCHANT_ID,
            signType: 'RSA',
            bizContent,
            sign: rsaSign(bizContent),
        };

        let resp;
        try {
            const r = await axios.post(`${F2PAYURL}/payout/inr/order/create`, payload, {
                headers: { 'Content-Type': 'application/json' },
                timeout: 30000,
            });
            resp = r.data;
        } catch (e) {
            await refundOnce(mchOrderNo, `gateway error: ${e.message}`);
            return res.status(502).json({ success: false, message: 'Withdrawal could not be sent. Amount refunded to your balance.' });
        }

        console.log(`F2Pay payout ${mchOrderNo} response:`, JSON.stringify(resp));

        if (resp.bizContent && resp.sign && !rsaVerify(resp.bizContent, resp.sign)) {
            await refundOnce(mchOrderNo, 'response signature invalid');
            return res.status(502).json({ success: false, message: 'Withdrawal could not be verified. Amount refunded to your balance.' });
        }

        if (resp.code !== '0000') {
            await refundOnce(mchOrderNo, resp.msg || `f2pay code ${resp.code}`);
            notifyAdmin(`F2Pay withdrawal FAILED — INR ${amount}`, [
                ['Status', 'Failed (gateway rejected — balance refunded)'],
                ['Reason', resp.msg || `f2pay code ${resp.code}`],
                ['User ID', user_id],
                ['Amount', `${amount} INR`],
                ['Order No', mchOrderNo],
                ['Failed at', new Date().toISOString()],
            ]);
            return res.status(400).json({ success: false, message: resp.msg || 'Withdrawal rejected. Amount refunded to your balance.' });
        }

        const biz = resp.bizContent ? JSON.parse(resp.bizContent) : {};
        await pg.query(
            `UPDATE f2paywithdrawals
                SET status = 'Processing', plat_no = $2, payment_details = $3, updated_at = CURRENT_TIMESTAMP
              WHERE mch_order_no = $1`,
            [mchOrderNo, biz.platNo || biz.orderNo || null, JSON.stringify(resp)]
        );

        notifyAdmin(`F2Pay withdrawal request created — INR ${amount}`, [
            ['Status', 'Processing (sent to gateway — balance debited)'],
            ['User ID', user_id],
            ['Amount', `${amount} INR`],
            ['Account', `${accountHolderName} / ${accountNumber} / ${ifsc}`],
            ['Order No', mchOrderNo],
            ['F2Pay Order', biz.platNo || biz.orderNo],
            ['Created at', new Date().toISOString()],
        ]);

        return res.json({
            success: true,
            mchOrderNo,
            amount,
            status: 'Processing',
            message: 'Withdrawal is on its way to your bank account.',
        });
    } catch (error) {
        console.error('F2Pay withdrawal request error:', error.message);
        return res.status(500).json({ success: false, message: error.message });
    }
};

// Refund sirf EK baar — row lock + refunded flag. Duplicate webhook ya
// double-call par dusri baar kuch nahi hota.
async function refundOnce(mchOrderNo, reason) {
    return withTransaction(async (client) => {
        const r = await client.query(
            `SELECT user_id, amount, refunded FROM f2paywithdrawals
              WHERE mch_order_no = $1 FOR UPDATE`,
            [mchOrderNo]
        );
        if (r.rows.length === 0) return false;
        if (r.rows[0].refunded) return false;

        await client.query(
            `UPDATE credits SET inr = COALESCE(inr, 0) + $1 WHERE uid = $2`,
            [r.rows[0].amount, r.rows[0].user_id]
        );
        await client.query(
            `UPDATE f2paywithdrawals
                SET status = 'Failed', refunded = TRUE, error_reason = $2, updated_at = CURRENT_TIMESTAMP
              WHERE mch_order_no = $1`,
            [mchOrderNo, reason]
        );
        console.log(`F2Pay ${mchOrderNo} refunded (${reason})`);
        return true;
    });
}

// f2pay payout webhook — RSA verified.
module.exports.payoutNotify = async (req, res) => {
    try {
        const data = req.body;
        console.log('F2Pay payout callback:', JSON.stringify(data));

        if (!data || !data.bizContent || !data.sign) return res.status(400).send('fail');
        if (!rsaVerify(data.bizContent, data.sign)) {
            console.error('F2Pay payout-notify: invalid signature');
            return res.status(400).send('fail');
        }

        let biz;
        try { biz = JSON.parse(data.bizContent); } catch { return res.status(400).send('fail'); }

        const mchOrderNo = biz.mchOrderNo;
        const state = biz.status || biz.state;
        if (!mchOrderNo) return res.status(400).send('fail');

        if (state === 'Completed') {
            // WHERE status se duplicate webhook no-op ban jata hai.
            const { rows } = await pg.query(
                `UPDATE f2paywithdrawals
                    SET status = 'Success', plat_no = COALESCE($2, plat_no),
                        webhook_response = $3, updated_at = CURRENT_TIMESTAMP
                  WHERE mch_order_no = $1 AND status IN ('Pending', 'Processing')
                  RETURNING user_id, amount`,
                [mchOrderNo, biz.platNo || null, JSON.stringify(data)]
            );
            if (rows.length > 0) {
                notifyAdmin(`F2Pay withdrawal SUCCESS — INR ${rows[0].amount}`, [
                    ['Status', 'Success (paid out)'],
                    ['User ID', rows[0].user_id],
                    ['Amount', `${rows[0].amount} INR`],
                    ['Order No', mchOrderNo],
                    ['Confirmed at', new Date().toISOString()],
                ]);
            }
            return res.send('success');
        }

        if (state === 'Failed') {
            await pg.query(
                `UPDATE f2paywithdrawals
                    SET webhook_response = $2, updated_at = CURRENT_TIMESTAMP
                  WHERE mch_order_no = $1`,
                [mchOrderNo, JSON.stringify(data)]
            );
            const refunded = await refundOnce(mchOrderNo, 'payout failed at f2pay');
            const { rows } = await pg.query(
                `SELECT user_id, amount FROM f2paywithdrawals WHERE mch_order_no = $1`,
                [mchOrderNo]
            );
            if (rows.length > 0) {
                notifyAdmin(`F2Pay withdrawal FAILED — INR ${rows[0].amount}`, [
                    ['Status', `Failed${refunded ? ' (balance refunded)' : ' (already refunded)'}`],
                    ['User ID', rows[0].user_id],
                    ['Amount', `${rows[0].amount} INR`],
                    ['Order No', mchOrderNo],
                    ['Failed at', new Date().toISOString()],
                ]);
            }
            return res.send('success');
        }

        console.log(`F2Pay payout ${mchOrderNo} unhandled state: ${state}`);
        return res.send('success');
    } catch (error) {
        console.error('F2Pay payout-notify error:', error.message);
        return res.status(500).send('fail');
    }
};

module.exports.history = async (req, res) => {
    try {
        const { user_id } = req.query;
        if (!user_id) return res.status(400).json({ success: false, message: 'user_id is required' });

        const { rows } = await pg.query(
            `SELECT mch_order_no, amount, currency, status, ifsc, account_holder_name, created_at
               FROM f2paywithdrawals
              WHERE user_id = $1
              ORDER BY id DESC
              LIMIT 200`,
            [user_id]
        );
        return res.json({ success: true, withdrawals: rows });
    } catch (error) {
        return res.status(500).json({ success: false, message: error.message });
    }
};
