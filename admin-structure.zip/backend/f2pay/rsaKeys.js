module.exports = {
    public_key: `-----BEGIN PUBLIC KEY-----
REMOVED_SECRET
-----END PUBLIC KEY-----`,
    private_key: `-----BEGIN PRIVATE KEY-----
REMOVED_SECRET
-----END PRIVATE KEY-----`
}