const axios = require('axios');
const crypto = require('crypto');
const pg = require('../General/Model');
const { withTransaction } = require('../General/Model/pool');
const emailService = require('../emailservice/controller');
const { public_key, private_key } = require('./rsaKeys');

const MERCHANT_ID = process.env.F2PAY_MERCHANT_ID || 'F2_6300';
const F2PAYURL = process.env.F2PAY_URL || 'https://api.f2pay.com';

// f2pay inhe internet se call karta hai — domain badle to sirf ye 2 line badalna.
const NOTIFY_URL = 'https://example.com/f2pay/notify';
const RETURN_URL = 'https://example.com';

// Admin email siteconfig.apaynotificationemail se aata hai (apay wala hi).
const FALLBACK_NOTIFICATION_EMAIL = ''

// Merchant F2_6300 ke UpiMixed limits (f2pay dashboard, 2026-08).
const MIN_DEPOSIT = 500;
const MAX_DEPOSIT = 30000;

// ---------- shared helpers (withdrawalController bhi inhe use karta hai) ----------

function rsaSign(dataString) {
    const signer = crypto.createSign('RSA-SHA256');
    signer.update(dataString, 'utf8');
    signer.end();
    return signer.sign(private_key, 'base64');
}

function rsaVerify(dataString, signatureBase64) {
    const verifier = crypto.createVerify('RSA-SHA256');
    verifier.update(dataString, 'utf8');
    verifier.end();
    return verifier.verify(public_key, signatureBase64, 'base64');
}

// Fire-and-forget — email fail ho to payment flow nahi rukna chahiye.
function notifyAdmin(subject, rows) {
    const cells = rows
        .filter(([, v]) => v !== undefined && v !== null && v !== '')
        .map(([k, v]) => `
            <tr>
                <td style="padding:6px 12px;border:1px solid #e2e8f0;background:#f8fafc;font-weight:600;">${k}</td>
                <td style="padding:6px 12px;border:1px solid #e2e8f0;">${v}</td>
            </tr>
        `).join('');
    const content = `<table style="border-collapse:collapse;width:100%;font-size:14px;">${cells}</table>`;

    pg.query('SELECT apaynotificationemail FROM siteconfig LIMIT 1')
        .then(({ rows: r }) => r[0]?.apaynotificationemail || FALLBACK_NOTIFICATION_EMAIL)
        .catch(() => FALLBACK_NOTIFICATION_EMAIL)
        .then(to => emailService.sendGeneralEmail(to, subject, { title: subject, content }))
        .catch(err => console.error('F2Pay admin notify failed:', err.message));
}

module.exports.rsaSign = rsaSign;
module.exports.rsaVerify = rsaVerify;
module.exports.notifyAdmin = notifyAdmin;

// ---------- deposit ----------

module.exports.createOrder = async (req, res) => {
    try {
        const { user_id, amount, customerName, customerPhone, customerEmail } = req.body;
        if (!user_id || !amount || !customerName || !customerPhone || !customerEmail) {
            return res.status(400).json({ success: false, message: 'user_id, amount, customerName, customerPhone, customerEmail are required' });
        }

        const amt = Number(amount);
        if (!Number.isFinite(amt) || amt <= 0) {
            return res.status(400).json({ success: false, message: 'Invalid amount' });
        }
        if (amt < MIN_DEPOSIT || amt > MAX_DEPOSIT) {
            return res.status(400).json({ success: false, message: `Deposit amount must be between ${MIN_DEPOSIT} and ${MAX_DEPOSIT} INR` });
        }

        const u = await pg.query('SELECT uid FROM credits WHERE uid = $1', [user_id]);
        if (u.rows.length === 0) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }

        const mchOrderNo = 'F2D_' + Date.now() + '_' + crypto.randomBytes(4).toString('hex');

        const bizContent = JSON.stringify({
            amount: amt.toFixed(2),
            body: 'Account deposit',
            customerEmail,
            customerIpAddress: req.ip,
            customerName,
            customerPhone,
            mchOrderNo,
            methodCode: 'UpiMixed',
            notifyUrl: NOTIFY_URL,
            returnUrl: RETURN_URL,
            subject: 'Wallet top-up',
        });

        const payload = {
            traceId: mchOrderNo,
            merchantId: MERCHANT_ID,
            signType: 'RSA',
            bizContent,
            sign: rsaSign(bizContent),
        };

        const { data: resp } = await axios.post(`${F2PAYURL}/payin/inr/order/create`, payload, {
            headers: { 'Content-Type': 'application/json' },
            timeout: 30000,
        });

        if (!rsaVerify(resp.bizContent, resp.sign)) {
            return res.status(400).json({ success: false, message: 'Response signature invalid' });
        }
        if (resp.code !== '0000') {
            return res.status(400).json({ success: false, message: resp.msg || 'Deposit request failed' });
        }

        const biz = JSON.parse(resp.bizContent); // { mchOrderNo, payUrl, platNo, upi }
        const paymentUrl = biz.payUrl;

        await pg.query(
            `INSERT INTO f2paydeposits
                (mch_order_no, plat_no, user_id, amount, currency, status, payment_url, payment_details)
             VALUES ($1, $2, $3, $4, 'INR', 'Pending', $5, $6)`,
            [mchOrderNo, biz.platNo || null, user_id, amt, paymentUrl, JSON.stringify(biz)]
        );

        notifyAdmin(`F2Pay deposit request created — INR ${amt}`, [
            ['Status', 'Pending (request created)'],
            ['User ID', user_id],
            ['Amount', `${amt} INR`],
            ['Order No', mchOrderNo],
            ['F2Pay Order', biz.platNo],
            ['Created at', new Date().toISOString()],
        ]);

        return res.json({ success: true, mchOrderNo, paymentUrl });
    } catch (error) {
        console.error('F2Pay createOrder error:', error.response?.data || error.message);
        return res.status(500).json({ success: false, message: error.response?.data?.msg || error.message });
    }
};

// f2pay deposit webhook — RSA verified. Yahi ek jagah hai jahan balance credit hota hai.
module.exports.notify = async (req, res) => {
    try {
        const data = req.body;
        console.log('F2Pay deposit callback:', JSON.stringify(data));

        if (!data || !data.bizContent || !data.sign) return res.status(400).send('fail');
        if (!rsaVerify(data.bizContent, data.sign)) {
            console.error('F2Pay notify: invalid signature');
            return res.status(400).send('fail');
        }

        let biz;
        try { biz = JSON.parse(data.bizContent); } catch { return res.status(400).send('fail'); }

        const { mchOrderNo, state, platNo } = biz;
        if (!mchOrderNo) return res.status(400).send('fail');

        if (state === 'Paid' || state === 'UnequalPaid') {
            // UnequalPaid = user ne alag amount bheja; jo actually aaya wahi credit hota hai.
            const paidAmount = Number(biz.actualAmount || biz.amount);

            // Row claim + credit ek hi transaction me. WHERE credited=FALSE ki wajah se
            // duplicate webhook par claim 0 row dega aur balance dobara credit NAHI hoga.
            const credited = await withTransaction(async (client) => {
                const claim = await client.query(
                    `UPDATE f2paydeposits
                        SET status = 'Success', credited = TRUE, amount = $2,
                            plat_no = COALESCE($3, plat_no),
                            webhook_response = $4, updated_at = CURRENT_TIMESTAMP
                      WHERE mch_order_no = $1 AND status = 'Pending' AND credited = FALSE
                      RETURNING user_id, amount`,
                    [mchOrderNo, paidAmount, platNo || null, JSON.stringify(data)]
                );
                if (claim.rows.length === 0) return null;

                const row = claim.rows[0];
                await client.query(
                    `UPDATE credits SET inr = COALESCE(inr, 0) + $1 WHERE uid = $2`,
                    [row.amount, row.user_id]
                );
                return row;
            });

            if (credited) {
                notifyAdmin(`F2Pay deposit SUCCESS — INR ${credited.amount}`, [
                    ['Status', 'Success (credited)'],
                    ['User ID', credited.user_id],
                    ['Amount', `${credited.amount} INR`],
                    ['Order No', mchOrderNo],
                    ['F2Pay Order', platNo],
                    ['Confirmed at', new Date().toISOString()],
                ]);
            } else {
                console.log(`F2Pay ${mchOrderNo} already settled — duplicate webhook ignored`);
            }
            return res.send('success');
        }

        if (state === 'Failed' || state === 'Closed') {
            const { rows } = await pg.query(
                `UPDATE f2paydeposits
                    SET status = 'Failed', error_reason = $2,
                        webhook_response = $3, updated_at = CURRENT_TIMESTAMP
                  WHERE mch_order_no = $1 AND status = 'Pending'
                  RETURNING user_id, amount`,
                [mchOrderNo, `f2pay state: ${state}`, JSON.stringify(data)]
            );
            if (rows.length > 0) {
                notifyAdmin(`F2Pay deposit FAILED — INR ${rows[0].amount}`, [
                    ['Status', state],
                    ['User ID', rows[0].user_id],
                    ['Amount', `${rows[0].amount} INR`],
                    ['Order No', mchOrderNo],
                    ['Failed at', new Date().toISOString()],
                ]);
            }
            return res.send('success');
        }

        console.log(`F2Pay ${mchOrderNo} unhandled state: ${state}`);
        return res.send('success');
    } catch (error) {
        console.error('F2Pay notify error:', error.message);
        return res.status(500).send('fail');
    }
};

module.exports.returnUrl = async (req, res) => {
    return res.redirect(RETURN_URL);
};
