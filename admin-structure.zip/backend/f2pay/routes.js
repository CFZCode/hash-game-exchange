const express = require('express');
const { rejectDemoUser } = require('../system/utils/demoUsers');
const controller = require('./controller');
const withdrawal = require('./withdrawalController');
const router = express.Router();

// Deposit
router.post('/createOrder', rejectDemoUser, controller.createOrder);
router.post('/notify', controller.notify);          // f2pay callback — RSA verified, no auth
router.get('/returnUrl', controller.returnUrl);

// Withdrawal — user direct payout, no admin approval
router.post('/withdrawal/request', withdrawal.request);
router.get('/withdrawal/history', withdrawal.history);
router.post('/payout-notify', withdrawal.payoutNotify); // f2pay callback — RSA verified, no auth

module.exports = router;
