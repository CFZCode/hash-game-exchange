# F2Pay — INR deposit + direct user payout

UPI deposit (payin) and bank payout (withdrawal) via f2pay. Everything is INR-only.
Mounted at `/f2pay` in `index.js`. No admin approval anywhere — the user requests a
withdrawal and it goes straight to f2pay, same model as `apay/`.

## Merchant / keys

- Merchant `F2_6300` on `https://api.f2pay.com` (override both together via
  `F2PAY_MERCHANT_ID` + `F2PAY_URL` for the test merchant).
- `rsaKeys.js` holds this project's RSA keypair. Every request body (`bizContent`,
  a JSON string) is signed RSA-SHA256; every f2pay response/callback is verified
  with the same keys. Callbacks have **no auth token** — the signature IS the auth.
- Callback URLs are hardcoded in `controller.js` (`NOTIFY_URL`, `RETURN_URL`) and
  `withdrawalController.js` (`PAYOUT_NOTIFY_URL`). If the API domain changes,
  change those three constants — a wrong notify URL means payments succeed at
  f2pay but the user is never credited.

## Tables

`f2paydeposits` and `f2paywithdrawals` (SQL was run manually, 2026-08-22 — the
CREATE TABLE statements are in the session notes / can be reconstructed from the
column lists below). Key columns beyond the obvious:

- `mch_order_no` — our unique order id (`F2D_...` / `F2W_...`), the idempotency key.
- `plat_no` — f2pay's own order number.
- `credited` (deposits) / `refunded` (withdrawals) — one-shot flags, see below.

## Deposit flow

1. `POST /f2pay/createOrder` — body: `user_id, amount, customerName, customerPhone,
   customerEmail`. Creates the f2pay payin order (`methodCode: UpiMixed`), inserts a
   Pending `f2paydeposits` row, emails the admin, returns `paymentUrl` (hosted
   cashier page).
2. `POST /f2pay/notify` — f2pay's webhook, the **only** place balance is credited.
   On `Paid`/`UnequalPaid`, one DB transaction claims the row
   (`WHERE status='Pending' AND credited=FALSE`) and adds the paid amount to
   `credits.inr`. A repeated webhook claims 0 rows and does nothing — no double
   credit. `UnequalPaid` credits `actualAmount` (what the user really sent).
3. `Failed`/`Closed` states mark the row Failed + email the admin.

## Withdrawal flow (direct user payout)

1. `POST /f2pay/withdrawal/request` — body: `user_id, amount, accountNumber, ifsc,
   accountHolderName, customerPhone, customerEmail`. Limits 100–30000 INR
   (merchant F2_6300's BANK_INR range; deposits are 500–30000 via UpiMixed).
2. One DB transaction with `FOR UPDATE` on the user's `credits` row: balance check,
   debit, insert Pending row. Two parallel requests can't overdraw.
3. Payout is sent to f2pay (`methodCode: BANK_INR`). Gateway error / rejection /
   bad response signature → `refundOnce()` returns the money and marks Failed.
   Accepted → status Processing, admin emailed.
4. `POST /f2pay/payout-notify` — webhook. `Completed` → Success (claim via
   `WHERE status IN ('Pending','Processing')`, so repeats are no-ops).
   `Failed` → `refundOnce()`.

`refundOnce()` takes a row lock and checks the `refunded` flag, so no matter how
many times a failure path fires, the user gets the money back exactly once.

`GET /f2pay/withdrawal/history?user_id=X` — last 200 withdrawals (account number
not returned).

## Admin notifications

Same channel as apay: `siteconfig.apaynotificationemail` (fallback
`salvin.dev.cfz@gmail.com`), via `emailservice`. Emails fire on: deposit created,
deposit success, deposit failed, withdrawal created, withdrawal success,
withdrawal failed. Fire-and-forget — an email failure never blocks a payment.

## Known gaps

- The admin **balancesheet** reconciles from apay/fiat tables only; f2pay
  deposits/withdrawals are not included yet, so f2pay users will show drift there
  until `balancesheet/controller.js` learns these two tables.
- Endpoints follow the apay trust model: `user_id` comes from the request body,
  no JWT.
