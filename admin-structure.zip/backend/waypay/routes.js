const express = require('express');
const { rejectDemoUser } = require('../system/utils/demoUsers');
const router = express.Router();
const PaymentController = require('./controller');



router.post('/payin/initiate', rejectDemoUser, PaymentController.initiatePayIn);
router.post('/payin/callback', PaymentController.handlePayInCallback);
router.get('/payin/status/:out_trade_no',  PaymentController.getTransactionStatus);


router.post('/payout/initiate', rejectDemoUser, PaymentController.initiatePayOut);
router.post('/payout/callback', PaymentController.handlePayOutCallback);
router.get('/payout/status/:out_trade_no',  PaymentController.getTransactionStatus);


router.post('/utr/repair',  PaymentController.utrRepair);

module.exports = router;