var NodeUglifier = require("node-uglifier");
var nodeUglifier = new NodeUglifier("./index.js");
nodeUglifier.merge().uglify();

//exporting
nodeUglifier.exportToFile("./t5.js");