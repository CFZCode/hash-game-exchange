const cron = require('node-cron');
const pg = require('../General/Model');

console.log("Vault Worker Started...");

// =============================
// Interest Calculation Function
// =============================
const runVaultInterest = async () => {

    console.log("Running vault interest cron:", new Date());

    try {

        // Get all active deposits (not withdrawn, with balance > 0)
        const data = await pg.query(`
            SELECT
                vp.id,
                vp.userid,
                vp.coin,
                vp."vaultBalance",
                vp.interest_rate,
                vp.lock_period
            FROM vault_pro vp
            WHERE vp."vaultBalance" > 0
              AND vp.status != 'withdrawn'
        `);

        if (data.rowCount === 0) {
            console.log("No active deposits found");
            return;
        }

        for (const row of data.rows) {

            const {
                id,
                userid,
                coin,
                vaultBalance,
                interest_rate
            } = row;

            if (!interest_rate || interest_rate <= 0) continue;

            // =============================
            // Daily Interest Formula
            // =============================
            const interest =
                (vaultBalance * interest_rate / 100) / 365;

            if (interest <= 0) continue;

            // =============================
            // DB Transaction
            // =============================
            await pg.query('BEGIN');

            try {

                // Update vault balance
                await pg.query(`
                    UPDATE vault_pro
                    SET "vaultBalance" = "vaultBalance" + $1,
                        "updatedAt" = NOW()
                    WHERE id = $2
                `, [interest, id]);

                // Insert history
                await pg.query(`
                    INSERT INTO vault_interest_history
                    (userid, coin, principal, interest, rate, deposit_id)
                    VALUES ($1, $2, $3, $4, $5, $6)
                `, [userid, coin, vaultBalance, interest, interest_rate, id]);

                await pg.query('COMMIT');

            } catch (err) {

                await pg.query('ROLLBACK');
                console.error("Transaction error for deposit", id, ":", err);

            }

        }

        console.log("Vault interest cron completed");

    } catch (error) {

        console.error("Cron Error:", error);

    }

};


// =============================
// CRON SCHEDULE (12:00 AM IST)
// =============================
cron.schedule('0 0 * * *', runVaultInterest, {
    timezone: "Asia/Kolkata"
});


// =============================
// Manual Run (Optional)
// =============================
if (process.env.RUN_MANUAL === "true") {
    runVaultInterest();
}
