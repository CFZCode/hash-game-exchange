var express = require('express');
var router = express.Router();
var vault = require('./controller');


router.get('/lock-options', vault.getLockOptions);

router.post('/transfer-in', vault.transferIn);
router.post('/transfer-out', vault.transferOut);
router.post('/vault-data', vault.getVaultData);

router.post('/history', vault.userInterestHistory);
router.post('/transactions', vault.userTransactions);

router.post('/admin/update-interest', vault.updateInterestRate);
router.post('/admin/add-lock-period', vault.addLockPeriod);
router.post('/admin/delete-lock-period', vault.deleteLockPeriod);

router.get('/admin/vault/users', vault.adminVaultUsers);
router.get('/admin/vault/stats', vault.adminStats);
router.get('/admin/vault/interest-history', vault.adminInterestHistory);

module.exports = router;
