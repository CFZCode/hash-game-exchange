const pg = require('../General/Model');

// =============================
// Helpers
// =============================
const getEndTime = (days) => {
    const date = new Date();
    date.setDate(date.getDate() + days);
    return date;
};

const getTimeRemaining = (endTime) => {
    const now = new Date();
    const end = new Date(endTime);
    const diff = end - now;

    if (diff <= 0) return { locked: false, remaining: null };

    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diff % (1000 * 60)) / 1000);

    return {
        locked: true,
        remaining: { days, hours, minutes, seconds, total_ms: diff }
    };
};

// Fetch lock config from DB
const getLockConfig = async (lockPeriod) => {
    const result = await pg.query(
        `SELECT lock_period, label, days, rate FROM vault_lock_rates WHERE lock_period = $1`,
        [lockPeriod]
    );
    return result.rows[0] || null;
};

module.exports = {

    // =============================
    // Get Lock Options (from DB)
    // =============================
    getLockOptions: async (req, res) => {
        try {
            const result = await pg.query(
                `SELECT lock_period AS value, label, days, rate FROM vault_lock_rates ORDER BY days ASC`
            );
            res.json(result.rows);
        } catch (err) {
            res.status(500).json({ error: err.message });
        }
    },


    // =============================
    // Transfer IN (with lock period)
    // =============================
    transferIn: async (req, res) => {

        const { uid, coin, amount, lock_period } = req.body;

        if (!uid || !coin || amount <= 0) {
            return res.status(400).json({ error: 'Invalid data' });
        }

        if (!lock_period) {
            return res.status(400).json({ error: 'Lock period is required' });
        }

        try {

            // Get lock config from DB
            const lockConfig = await getLockConfig(lock_period);
            if (!lockConfig) {
                return res.status(400).json({ error: 'Invalid lock period' });
            }

            await pg.query('BEGIN');

            // Check wallet balance
            const wallet = await pg.query(
                `SELECT ${coin} FROM credits WHERE uid=$1`,
                [uid]
            );

            if (wallet.rowCount === 0)
                throw new Error('Wallet not found');

            if (wallet.rows[0][coin] < amount)
                throw new Error('Insufficient wallet balance');

            // Deduct wallet
            await pg.query(
                `UPDATE credits SET ${coin}=${coin}-$1 WHERE uid=$2`,
                [amount, uid]
            );

            // Create new deposit
            const endTime = getEndTime(lockConfig.days);

            const deposit = await pg.query(`
                INSERT INTO vault_pro
                (userid, coin, "vaultBalance", "createdAt", "updatedAt", lock_period, interest_rate, "startTime", "endTime", status)
                VALUES ($1, $2, $3, NOW(), NOW(), $4, $5, NOW(), $6, 'locked')
                RETURNING id
            `, [uid, coin, amount, lock_period, lockConfig.rate, endTime]);

            const depositId = deposit.rows[0].id;

            // Insert transaction log
            await pg.query(`
                INSERT INTO vault_transactions
                (userid, coin, amount, type, deposit_id)
                VALUES ($1, $2, $3, 'transfer_in', $4)
            `, [uid, coin, amount, depositId]);

            await pg.query('COMMIT');

            res.json({
                message: 'Transfer successful',
                deposit: {
                    id: depositId,
                    lock_period: lock_period,
                    interest_rate: lockConfig.rate,
                    endTime: endTime,
                    ...getTimeRemaining(endTime)
                }
            });

        } catch (err) {

            await pg.query('ROLLBACK');
            res.status(500).json({ error: err.message });

        }
    },


    // =============================
    // Transfer OUT (with lock check)
    // =============================
    transferOut: async (req, res) => {

        const { uid, coin, deposit_id } = req.body;

        if (!uid || !coin || !deposit_id) {
            return res.status(400).json({ error: 'Invalid data. Provide uid, coin, deposit_id' });
        }

        try {

            await pg.query('BEGIN');

            const vault = await pg.query(
                `SELECT id, "vaultBalance", "endTime", status FROM vault_pro WHERE id=$1 AND userid=$2 AND coin=$3`,
                [deposit_id, uid, coin]
            );

            if (vault.rowCount === 0)
                throw new Error('Deposit not found');

            const deposit = vault.rows[0];

            // Check lock period
            const timeInfo = getTimeRemaining(deposit.endTime);
            if (timeInfo.locked) {
                await pg.query('ROLLBACK');
                return res.status(400).json({
                    error: 'Deposit is still locked',
                    endTime: deposit.endTime,
                    ...timeInfo
                });
            }

            const amount = deposit.vaultBalance;

            if (amount <= 0) {
                throw new Error('No balance to withdraw');
            }

            await pg.query(`
                UPDATE vault_pro
                SET "vaultBalance" = 0,
                    "updatedAt" = NOW(),
                    status = 'withdrawn'
                WHERE id = $1
            `, [deposit_id]);

            await pg.query(`
                UPDATE credits
                SET ${coin} = ${coin} + $1
                WHERE uid = $2
            `, [amount, uid]);

            await pg.query(`
                INSERT INTO vault_transactions
                (userid, coin, amount, type, deposit_id)
                VALUES ($1, $2, $3, 'transfer_out', $4)
            `, [uid, coin, amount, deposit_id]);

            await pg.query('COMMIT');

            res.json({ message: 'Transfer out successful', amount });

        } catch (err) {

            await pg.query('ROLLBACK');
            res.status(500).json({ error: err.message });

        }
    },


    // =============================
    // Get Vault Data (all deposits)
    // =============================
    getVaultData: async (req, res) => {

        const { uid, coin } = req.body;

        try {

            const result = await pg.query(`
                SELECT id, "vaultBalance", lock_period, interest_rate,
                       "startTime", "endTime", status, "createdAt"
                FROM vault_pro
                WHERE userid = $1 AND coin = $2 AND status != 'withdrawn'
                ORDER BY "createdAt" DESC
            `, [uid, coin]);

            const deposits = result.rows.map(row => ({
                ...row,
                ...getTimeRemaining(row.endTime)
            }));

            const totalBalance = deposits.reduce((sum, d) => sum + parseFloat(d.vaultBalance), 0);

            res.json({ totalBalance, deposits });

        } catch (err) {

            res.status(500).json({ error: err.message });

        }
    },


    // =============================
    // User Interest History
    // =============================
    userInterestHistory: async (req, res) => {

        const { uid } = req.body;

        try {

            const result = await pg.query(`
                SELECT *
                FROM vault_interest_history
                WHERE userid=$1
                ORDER BY id DESC
            `, [uid]);

            res.json(result.rows);

        } catch (err) {

            res.status(500).json({ error: err.message });

        }
    },


    // =============================
    // User Transactions
    // =============================
    userTransactions: async (req, res) => {

        const { uid } = req.body;

        try {

            const result = await pg.query(`
                SELECT *
                FROM vault_transactions
                WHERE userid=$1
                ORDER BY id DESC
            `, [uid]);

            res.json(result.rows);

        } catch (err) {

            res.status(500).json({ error: err.message });

        }
    },


    // =============================
    // Admin: Update Lock Period Rate (DB)
    // =============================
    updateInterestRate: async (req, res) => {

        const { lock_period, rate } = req.body;

        if (!lock_period) {
            return res.status(400).json({ error: 'Lock period is required' });
        }

        if (rate === undefined || rate === null || rate < 0) {
            return res.status(400).json({ error: 'Invalid rate' });
        }

        try {

            const result = await pg.query(`
                UPDATE vault_lock_rates
                SET rate = $1, "updatedAt" = NOW()
                WHERE lock_period = $2
                RETURNING lock_period, label, days, rate
            `, [rate, lock_period]);

            if (result.rowCount === 0) {
                return res.status(404).json({ error: 'Lock period not found' });
            }

            const updated = result.rows[0];

            res.json({
                message: `Rate updated for ${updated.label}`,
                lock_period: updated.lock_period,
                label: updated.label,
                days: updated.days,
                new_rate: updated.rate
            });

        } catch (err) {

            res.status(500).json({ error: err.message });

        }
    },


    // =============================
    // Admin: Add New Lock Period
    // =============================
    addLockPeriod: async (req, res) => {

        const { lock_period, label, days, rate } = req.body;

        if (!lock_period || !label || !days || days <= 0) {
            return res.status(400).json({ error: 'Provide lock_period, label, days' });
        }

        try {

            const result = await pg.query(`
                INSERT INTO vault_lock_rates (lock_period, label, days, rate)
                VALUES ($1, $2, $3, $4)
                RETURNING lock_period, label, days, rate
            `, [lock_period, label, days, rate || 0]);

            res.json({
                message: `Lock period "${label}" added`,
                ...result.rows[0]
            });

        } catch (err) {

            if (err.code === '23505') {
                return res.status(400).json({ error: 'Lock period already exists' });
            }
            res.status(500).json({ error: err.message });

        }
    },


    // =============================
    // Admin: Delete Lock Period
    // =============================
    deleteLockPeriod: async (req, res) => {

        const { lock_period } = req.body;

        if (!lock_period) {
            return res.status(400).json({ error: 'Lock period is required' });
        }

        try {

            // Check if any active deposits use this lock period
            const active = await pg.query(
                `SELECT COUNT(*) as count FROM vault_pro WHERE lock_period = $1 AND status != 'withdrawn'`,
                [lock_period]
            );

            if (parseInt(active.rows[0].count) > 0) {
                return res.status(400).json({
                    error: `Cannot delete: ${active.rows[0].count} active deposits use this lock period`
                });
            }

            const result = await pg.query(
                `DELETE FROM vault_lock_rates WHERE lock_period = $1 RETURNING label`,
                [lock_period]
            );

            if (result.rowCount === 0) {
                return res.status(404).json({ error: 'Lock period not found' });
            }

            res.json({ message: `Lock period "${result.rows[0].label}" deleted` });

        } catch (err) {

            res.status(500).json({ error: err.message });

        }
    },


    // =============================
    // Admin Vault Users
    // =============================
    adminVaultUsers: async (req, res) => {

        try {

            const result = await pg.query(`
                SELECT vp.*, u.name
                FROM vault_pro vp
                JOIN users u ON u.id = vp.userid
                WHERE vp.status != 'withdrawn'
                ORDER BY vp."vaultBalance" DESC
            `);

            const rows = result.rows.map(row => ({
                ...row,
                ...getTimeRemaining(row.endTime)
            }));

            res.json(rows);

        } catch (err) {

            res.status(500).json({ error: err.message });

        }
    },


    // =============================
    // Admin Stats
    // =============================
    adminStats: async (req, res) => {

        try {

            const stats = await pg.query(`
                SELECT
                    COUNT(DISTINCT userid) total_users,
                    SUM("vaultBalance") total_balance
                FROM vault_pro
                WHERE status != 'withdrawn'
            `);

            const today = await pg.query(`
                SELECT SUM(interest) today_interest
                FROM vault_interest_history
                WHERE DATE("createdAt") = CURRENT_DATE
            `);

            res.json({
                totalUsers: stats.rows[0].total_users,
                totalBalance: stats.rows[0].total_balance,
                todayInterest: today.rows[0].today_interest || 0
            });

        } catch (err) {

            res.status(500).json({ error: err.message });

        }
    },


    // =============================
    // Admin Interest History
    // =============================
    adminInterestHistory: async (req, res) => {

        try {

            const result = await pg.query(`
                SELECT vih.*, u.name
                FROM vault_interest_history vih
                JOIN users u ON u.id = vih.userid
                ORDER BY vih.id DESC
            `);

            res.json(result.rows);

        } catch (err) {

            res.status(500).json({ error: err.message });

        }
    }

};
