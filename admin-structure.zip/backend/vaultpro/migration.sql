-- =============================
-- VaultPro Lock System Migration
-- =============================

-- Add lock system columns to vault_pro
ALTER TABLE vault_pro ADD COLUMN IF NOT EXISTS lock_period VARCHAR(10);
ALTER TABLE vault_pro ADD COLUMN IF NOT EXISTS interest_rate NUMERIC DEFAULT 0;
ALTER TABLE vault_pro ADD COLUMN IF NOT EXISTS "startTime" TIMESTAMP DEFAULT NOW();
ALTER TABLE vault_pro ADD COLUMN IF NOT EXISTS "endTime" TIMESTAMP;
ALTER TABLE vault_pro ADD COLUMN IF NOT EXISTS status VARCHAR(20) DEFAULT 'locked';

-- Drop unique constraint on (userid, coin) if exists, since now each deposit is a separate row
-- Run this manually if you have a unique constraint:
-- ALTER TABLE vault_pro DROP CONSTRAINT IF EXISTS vault_pro_userid_coin_key;

-- Add deposit_id reference to vault_transactions
ALTER TABLE vault_transactions ADD COLUMN IF NOT EXISTS deposit_id INTEGER;

-- Add deposit_id reference to vault_interest_history
ALTER TABLE vault_interest_history ADD COLUMN IF NOT EXISTS deposit_id INTEGER;

-- Update existing rows (if any) to mark them as matured so they can be withdrawn
UPDATE vault_pro SET status = 'matured', lock_period = '30d', "startTime" = "createdAt", "endTime" = "createdAt" WHERE status IS NULL;
