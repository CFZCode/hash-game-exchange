// services/branchApi.ts
// Branch panel: super admin -> branch admin -> sub branch -> players.
//
// The same screens run in two places:
//   /branch/*             the branch panel, signed in at /branch/login. Its
//                         session lives under its own keys so it never shares
//                         or clobbers an admin session in the same browser.
//   /branch-management/*  inside the admin panel, for the super admin, using
//                         the normal admin `token`.
// Which session a request uses is decided from the current URL.

const BASE = 'https://example.com';

export const BRANCH_TOKEN_KEY = 'branchToken';
export const BRANCH_USER_KEY = 'branchUser';

export type BranchKind = 'owner' | 'branch' | 'sub';

export interface BranchSessionUser {
  id: number;
  name: string;
  login: string;
  role: 'BranchAdmin' | 'SubBranch';
}

export const inBranchPanel = () => /^\/branch(\/|$)/.test(window.location.pathname);

export const getBranchToken = () => localStorage.getItem(BRANCH_TOKEN_KEY);

export const getBranchUser = (): BranchSessionUser | null => {
  try { return JSON.parse(localStorage.getItem(BRANCH_USER_KEY) || 'null'); }
  catch { return null; }
};

export const clearBranchSession = () => {
  localStorage.removeItem(BRANCH_TOKEN_KEY);
  localStorage.removeItem(BRANCH_USER_KEY);
};

export const kindOfRole = (role?: string): BranchKind => (role === 'SubBranch' ? 'sub' : 'branch');

async function branchFetch<T = any>(path: string, options: RequestInit = {}): Promise<T> {
  const panel = inBranchPanel();
  const token = panel ? getBranchToken() : localStorage.getItem('token');
  const res = await fetch(`${BASE}/api/branch${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers as any),
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
  });
  const body = await res.json().catch(() => ({} as any));

  // Expired session, or the account was locked while signed in.
  if (res.status === 401 || (res.status === 403 && body?.code === 'BRANCH_LOCKED')) {
    if (panel) {
      clearBranchSession();
      window.location.href = res.status === 403 ? '/branch/login?locked=1' : '/branch/login';
    } else {
      localStorage.clear();
      window.location.href = '/login';
    }
    throw new Error(body?.message || 'Unauthorized');
  }
  if (!res.ok) throw new Error(body?.message || `Error ${res.status}`);
  return body as T;
}

const json = (method: string, body: unknown) => ({ method, body: JSON.stringify(body) });

export const qs = (params: Record<string, string | number | undefined | null>) => {
  const s = Object.entries(params)
    .filter(([, v]) => v !== undefined && v !== null && v !== '')
    .map(([k, v]) => `${k}=${encodeURIComponent(String(v))}`)
    .join('&');
  return s ? `?${s}` : '';
};

/* ─── auth ───────────────────────────────────────────────────── */

export async function branchLogin(login: string, password: string) {
  const res = await fetch(`${BASE}/api/branch/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ login, password }),
  });
  const body = await res.json().catch(() => ({} as any));
  if (!res.ok) throw new Error(body?.message || 'Login failed');
  localStorage.setItem(BRANCH_TOKEN_KEY, body.token);
  localStorage.setItem(BRANCH_USER_KEY, JSON.stringify(body.user));
  return body.user as BranchSessionUser;
}

/* ─── shapes ─────────────────────────────────────────────────── */

export interface Stats {
  deposit: number; deposit_count: number; deposit_pending: number; deposit_pending_count: number; deposit_failed_count: number;
  withdraw: number; withdraw_count: number; withdraw_pending: number; withdraw_pending_count: number; withdraw_failed_count: number;
  sports_bets: number; sports_stake: number; sports_open_bets: number; sports_pnl: number;
  casino_bets: number; casino_staked: number; casino_won: number; casino_pnl: number;
}

export interface BranchStaff extends Stats {
  id: number;
  name: string;
  login: string;
  phone: string | null;
  code: string | null;
  parent_id: number;
  parent_name: string | null;
  parent_locked: boolean;
  locked: boolean;
  created_at: string | null;
  role?: 'BranchAdmin' | 'SubBranch';
  players: number;
  wallet: number;
  sub_branches?: number;
}

export interface Summary extends Stats {
  players: number; wallet: number; registrations: number;
  branches: number; sub_branches: number; sub_branches_locked: number;
}

export interface DailyRow extends Stats { date: string; registrations: number }

export interface Player extends Stats {
  id: string; username: string; email: string | null; phone: string | null; country?: string | null;
  created: string | null; last_login_at: string | null; locked: boolean; wallet: number;
  staff_id: number; staff_name: string; staff_code: string | null;
}

export type TxStatus = 'success' | 'pending' | 'failed';
export interface Transaction {
  type: 'deposit' | 'withdraw'; method: string; ref: string; user_id: string; username: string;
  amount: number; status: TxStatus; raw_status: string; ts: string; staff_id: number; staff_name: string;
}
type Bucket = Record<TxStatus, { count: number; amount: number }>;
export interface TxTotals { deposit: Bucket; withdraw: Bucket }

export interface SportsBetRow {
  id: string; ts: string; user_id: string; user: string; match: string; selection: string; market: string;
  side: string; odds: number; stake: number; status: string; result: string | null;
}
export interface CasinoRow {
  id: string; ts: string; user_id: string; user: string; action: string; game: string; round: string | null; amount: number;
}

export interface Filters { staffId?: string; from?: string; to?: string }

/* ─── calls ──────────────────────────────────────────────────── */

export const getMe = () =>
  branchFetch<{ kind: BranchKind; me: { id: number; name: string; login: string; phone: string | null; code: string | null; role: string; parent_name: string | null; created_at: string } }>('/me');

export const changeMyPassword = (oldPassword: string, newPassword: string) =>
  branchFetch('/me/password', json('POST', { oldPassword, newPassword }));

export const listBranches = (p: { search?: string; from?: string; to?: string }) =>
  branchFetch<{ branches: BranchStaff[] }>(`/branches${qs(p)}`);

export const createBranch = (p: { name: string; login: string; password: string; phone?: string; code?: string; transactionPassword: string }) =>
  branchFetch<{ branch: { id: number; name: string; login: string; code: string } }>('/branches', json('POST', p));

export const listSubBranches = (p: Filters & { search?: string; onlySubs?: 1 }) =>
  branchFetch<{ subBranches: BranchStaff[] }>(`/sub-branches${qs({ ...p })}`);

export const createSubBranch = (p: { name: string; login: string; password: string; phone?: string; code?: string; branchId?: number; transactionPassword?: string }) =>
  branchFetch<{ subBranch: { id: number; name: string; login: string; code: string } }>('/sub-branches', json('POST', p));

export const setLock = (id: number, locked: boolean, transactionPassword?: string) =>
  branchFetch(`/staff/${id}/lock`, json('PATCH', { locked, transactionPassword }));

export const resetPassword = (id: number, password: string, transactionPassword?: string) =>
  branchFetch(`/staff/${id}/password`, json('PATCH', { password, transactionPassword }));

export const getSummary = (f: Filters) =>
  branchFetch<{ summary: Summary }>(`/summary${qs({ ...f })}`);

export const getDaily = (f: Filters & { userId?: string }) =>
  branchFetch<{ rows: DailyRow[]; totals: DailyRow }>(`/reports/daily${qs({ ...f })}`);

export const listPlayers = (f: Filters & { search?: string; page?: number; limit?: number }) =>
  branchFetch<{ players: Player[]; total: number; page: number; totalPages: number }>(`/players${qs({ ...f })}`);

export const suggestPlayer = () =>
  branchFetch<{ username: string; password: string }>('/players/suggest');

export interface CreatedPlayer { id: string; username: string; password: string; staff_id: number; staff_name: string }
export const createPlayer = (p: { username?: string; password?: string; phone?: string; staffId?: number }) =>
  branchFetch<{ player: CreatedPlayer }>('/players', json('POST', p));

export const getPlayer = (id: string, f: Filters) =>
  branchFetch<{ player: Player; stats: Stats; lifetime: Stats }>(`/players/${id}${qs({ ...f })}`);

export const listTransactions = (f: Filters & { type?: 'deposit' | 'withdraw'; status?: TxStatus | ''; userId?: string; search?: string; page?: number; limit?: number }) =>
  branchFetch<{ transactions: Transaction[]; totals: TxTotals; total: number; page: number; totalPages: number }>(`/transactions${qs({ ...f })}`);

export const listBets = <T = SportsBetRow | CasinoRow>(f: Filters & { kind: 'sports' | 'casino'; userId?: string; page?: number; limit?: number }) =>
  branchFetch<{ rows: T[]; total: number; page: number; totalPages: number }>(`/bets${qs({ ...f })}`);

/** Where a player signs up with a code: the site prefills it from ?ref=. */
export const signupLink = (code: string | null | undefined) =>
  code ? `https://example.com/?modalType=auth-signup&ref=${encodeURIComponent(code)}` : '';
