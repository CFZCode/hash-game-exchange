// services/demoPortalApi.ts
// Demo Portal: the SuperAdmin manages Demo Portal Agents; each agent logs in
// (role 'DemoAgent') and creates demo player accounts. Demo accounts can play
// but have no deposit/withdraw on the site and are marked DEMO in reports.
//
// Deposit / withdraw between SuperAdmin <-> agent and agent <-> demo account
// both go through lordsApi.transferFunds (STAFF / USER respectively).
import { apiFetch } from '../utils/api';

export const DEMO_AGENT_ROLE = 'DemoAgent';

export interface DemoAgent {
  id: number | string;
  name: string;
  email: string;
  locked: boolean;
  first_login: boolean | null;
  created_at: string | null;
  balance: number;
  demo_users: number;
  demo_users_balance: number;
}

export interface DemoUser {
  id: string;
  username: string;
  password: string | null;
  balance: number;
  casino_limit: number | null;
  locked: boolean;
  created: string | null;
  last_login_at: string | null;
  casino_pnl: number;
}

export interface DemoUserPage {
  users: DemoUser[];
  total: number;
  totalPages: number;
}

const json = (method: string, body: unknown) => ({
  method,
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(body),
});

const qs = (params: Record<string, string | number | undefined>) =>
  Object.entries(params)
    .filter(([, v]) => v !== undefined && v !== '')
    .map(([k, v]) => `${k}=${encodeURIComponent(String(v))}`)
    .join('&');

// ─── SuperAdmin ────────────────────────────────────────────────
export const listAgents = (search = '') =>
  apiFetch<{ agents: DemoAgent[] }>(`/api/demo-portal/agents?${qs({ search })}`);

export const createAgent = (payload: { name: string; email: string; password: string; transactionPassword: string }) =>
  apiFetch<{ agentId: number }>('/api/demo-portal/agents', json('POST', payload));

export const setAgentLock = (id: DemoAgent['id'], locked: boolean, transactionPassword: string) =>
  apiFetch(`/api/demo-portal/agents/${id}/lock`, json('PATCH', { locked, transactionPassword }));

export const resetAgentPassword = (id: DemoAgent['id'], password: string, transactionPassword: string) =>
  apiFetch(`/api/demo-portal/agents/${id}/password`, json('PATCH', { password, transactionPassword }));

export const listAgentUsers = (id: DemoAgent['id'], params: { search?: string; page?: number; limit?: number }) =>
  apiFetch<DemoUserPage>(`/api/demo-portal/agents/${id}/users?${qs(params)}`);

// ─── Demo Portal Agent ─────────────────────────────────────────
export const getMe = () => apiFetch<{ agent: DemoAgent }>('/api/demo-portal/me');

export const listMyUsers = (params: { search?: string; page?: number; limit?: number }) =>
  apiFetch<DemoUserPage>(`/api/demo-portal/users?${qs(params)}`);

export const createDemoUser = (payload: { username?: string; password?: string; fund: number; casinoLimit: number }) =>
  apiFetch<{ user: { id: string; username: string; password: string; balance: number; casino_limit: number | null } }>(
    '/api/demo-portal/users', json('POST', payload));

export const updateDemoUser = (id: string, payload: { casinoLimit?: number; locked?: boolean }) =>
  apiFetch(`/api/demo-portal/users/${id}`, json('PATCH', payload));
