// services/threeDGamesApi.ts
// Admin "3D Games" page (Teen Patti, Zhandu, Flipper, Variation).
// The game server owns the data; our backend forwards these calls to it
// (GET /api/3dgame/admin/:report, SuperAdmin only).
import { apiFetch } from '../utils/api';

export type GameKey = 'teenpatti' | 'zhandu' | 'flipper' | 'variation';

export const GAME_OPTIONS: { key: GameKey; name: string }[] = [
  { key: 'teenpatti', name: 'Teen Patti' },
  { key: 'zhandu', name: 'Zhandu' },
  { key: 'flipper', name: 'Flipper' },
  { key: 'variation', name: 'Variation' },
];

/** Money for a set of rounds. collection = commission + payout. */
export interface Money {
  rounds: number;
  /** everything players put into the pots (boot + bets) */
  totalCollection: number;
  /** the house cut, taken from the winners' pots */
  commission: number;
  /** what went back to the winners */
  payout: number;
  draws: number;
}

export interface LiveCounts {
  runningTables: number;
  waitingTables: number;
  players: number;
  watchers: number;
  potOnTables: number;
}

export interface TierRow extends Money { tier: string; bootAmount: number }

export interface GameSummary extends Money {
  game: GameKey;
  name: string;
  uniquePlayers: number;
  lastPlayedAt: string | null;
  live: LiveCounts;
  tiers: TierRow[];
}

export interface DailyRow {
  date: string;
  rounds: number;
  totalCollection: number;
  commission: number;
  payout: number;
}

export interface Dashboard {
  commissionPercent: number;
  totals: Money & { uniquePlayers: number };
  today: Money;
  live: LiveCounts;
  games: GameSummary[];
  daily: DailyRow[];
}

export interface RoundPlayer {
  sessionId: string;
  userId: string | null;
  name: string | null;
  seat: number;
  totalBet: number;
  /** credited after commission */
  won: number;
  commission: number;
  profitLoss: number;
  isWinner: boolean;
  isPacked: boolean;
  isSeen: boolean;
  isAllIn: boolean;
  cards: string[];
}

export interface Round {
  matchId: string;
  game: GameKey;
  gameName: string;
  /** the variant actually dealt — differs from `game` in the Variation room */
  gameType: string;
  roomId: string;
  tier: string;
  bootAmount: number;
  totalCollection: number;
  commission: number;
  payout: number;
  isDraw: boolean;
  playerCount: number;
  winners: { userId: string | null; name: string | null; won: number }[];
  players: RoundPlayer[];
  playedAt: string;
}

export interface PlayerRow {
  userId: string;
  name: string | null;
  sessions: number;
  rounds: number;
  wins: number;
  losses: number;
  totalBet: number;
  won: number;
  profitLoss: number;
  /** house commission taken from this player's winnings */
  commission: number;
  games: GameKey[];
  lastPlayed: string;
}

export interface LiveTable {
  matchId: string;
  game: GameKey;
  gameName: string;
  gameType: string;
  tier: string;
  bootAmount: number;
  status: 'running' | 'waiting';
  pot: number;
  watchers: number;
  players: {
    sessionId: string;
    userId: string | null;
    name: string | null;
    totalBet: number;
    isPacked: boolean;
    isTurn: boolean;
  }[];
}

export interface Paged<T> { total: number; limit: number; offset: number; list: T[] }

export interface Filters { from?: string; to?: string; game?: string }

type Params = Record<string, string | number | undefined>;

async function report<T>(name: string, params: Params): Promise<T> {
  const q = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => { if (v !== undefined && v !== '') q.set(k, String(v)); });
  try {
    const res = await apiFetch<{ success: boolean; message?: string; data: T }>(`/api/3dgame/admin/${name}?${q}`);
    if (!res.success) throw new Error(res.message || 'Failed to load');
    return res.data;
  } catch (e) {
    // apiFetch throws the raw response body; show its `message` when it is JSON.
    const raw = e instanceof Error ? e.message : '';
    let message = raw || 'Failed to load';
    try { message = JSON.parse(raw)?.message || message; } catch { /* plain text */ }
    throw new Error(message);
  }
}

export const getDashboard = (f: Filters) => report<Dashboard>('dashboard', { ...f });

export const getGameplay = (f: Filters & { userId?: string; limit: number; offset: number }) =>
  report<Paged<Round>>('gameplay', { ...f });

export const getPlayers = (f: Filters & { search?: string; sortBy?: string; limit: number; offset: number }) =>
  report<Paged<PlayerRow>>('users', { ...f });

export const getLive = (game?: string) => report<{ total: number; list: LiveTable[] }>('live', { game });
