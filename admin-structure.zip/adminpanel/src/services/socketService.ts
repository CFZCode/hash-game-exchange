// services/socketService.ts
import { io, Socket } from 'socket.io-client';
import type { StaffPermissions } from '../constants/permissions';

const SOCKET_URL = 'https://example.com/admin-panel';

let socket: Socket | null = null;

export const socketService = {
  connect(token: string) {
    if (socket?.connected) return socket;
    socket = io(SOCKET_URL, {
      auth: { token: `Bearer ${token}` },
      reconnectionAttempts: 5,
      transports: ['websocket', 'polling'],
    });
    socket.on('connect', () => console.log('[Socket] Connected'));
    socket.on('disconnect', () => console.log('[Socket] Disconnected'));
    socket.on('connect_error', (e) => console.error('[Socket] Error', e.message));
    return socket;
  },

  disconnect() {
    if (socket) {
      socket.disconnect();
      socket = null;
    }
  },

  getSocket() {
    return socket;
  },

  // ─── Admin Profile ─────────────────────────────────────
  getAdminProfile(callback: (data: any) => void) {
    if (!socket) return;
    socket.emit('getAdminProfile');
    socket.on('adminProfileUpdate', callback);
  },

  // ─── Users All Details (real-time agent listing) ──────
  subscribeToUsersAllDetails(
    params: { page?: number; limit?: number; search?: string; parentId?: number },
    callback: (data: any) => void
  ) {
    if (!socket) return;
    socket.emit('getUsersAllDetails', params);
    socket.on('usersAllDetailsUpdate', callback);
  },

  unsubscribeFromUsersAllDetails() {
    if (!socket) return;
    socket.emit('stopUsersAllDetails');
    socket.off('usersAllDetailsUpdate');
  },

  // ─── Executive List (Access Management) ───────────────
  subscribeToExecutiveList(
    params: { page?: number; limit?: number; search?: string },
    callback: (data: { executives: Executive[]; totalPages?: number }) => void
  ) {
    if (!socket) return;
    socket.emit('getExecutiveList', params);
    socket.on('executiveListUpdate', callback);
  },

  unsubscribeFromExecutiveList() {
    if (!socket) return;
    socket.emit('stopExecutiveList');
    socket.off('executiveListUpdate');
  },

  // ─── Executive Activity Log (live) ────────────────────
  subscribeToExecutiveActivity(
    params: { executiveId: number; page?: number; limit?: number },
    callback: (data: { entries: ExecutiveActivity[]; totalPages?: number }) => void
  ) {
    if (!socket) return;
    socket.emit('getExecutiveActivity', params);
    socket.on('executiveActivityUpdate', callback);
  },

  unsubscribeFromExecutiveActivity() {
    if (!socket) return;
    socket.emit('stopExecutiveActivity');
    socket.off('executiveActivityUpdate');
  },

  // ─── My effective permissions ─────────────────────────
  subscribeToMyPermissions(
    callback: (data: { permissions: StaffPermissions; role: string }) => void
  ) {
    if (!socket) return;
    socket.emit('getMyPermissions');
    socket.on('myPermissionsUpdate', callback);
  },

  unsubscribeFromMyPermissions() {
    if (!socket) return;
    socket.off('myPermissionsUpdate');
  },

  // ─── Executive mutations (ack via socket) ─────────────
  emitUpdateExecutivePermissions(
    payload: { executiveId: number; permissions: StaffPermissions; transactionPassword: string },
    ack?: (res: { success: boolean; message?: string }) => void
  ) {
    if (!socket) return;
    socket.emit('updateExecutivePermissions', payload, ack);
  },

  emitLockExecutive(
    payload: { executiveId: number; lock: boolean; transactionPassword: string },
    ack?: (res: { success: boolean; message?: string }) => void
  ) {
    if (!socket) return;
    socket.emit('lockExecutive', payload, ack);
  },

  emitResetExecutivePassword(
    payload: { executiveId: number; newPassword: string; transactionPassword: string },
    ack?: (res: { success: boolean; message?: string }) => void
  ) {
    if (!socket) return;
    socket.emit('resetExecutivePassword', payload, ack);
  },

  emitCreateExecutive(
    payload: {
      username: string;
      password: string;
      permissions: StaffPermissions;
      transactionPassword: string;
    },
    ack?: (res: { success: boolean; message?: string; executiveId?: number }) => void
  ) {
    if (!socket) return;
    socket.emit('createExecutive', payload, ack);
  },
};

/* ── Shared types ───────────────────────────────────────────── */
export interface Executive {
  id: number;
  username: string;
  status: 'active' | 'inactive' | 'locked';
  parentUserId?: number;
  parentUsername?: string;
  parentRole?: string;
  createdAt?: string;
  lastLogin?: string;
  permissions: StaffPermissions;
}

export interface ExecutiveActivity {
  id: number;
  executiveId: number;
  action: string;        // e.g. "transfer.credit", "user.password.reset"
  targetType?: string;   // "user" | "agent" | "settlement" ...
  targetId?: number | string;
  details?: Record<string, any>;
  ip?: string;
  userAgent?: string;
  createdAt: string;
}
