// services/lordsApi.ts
// API calls for the Lords endpoints (user settings, deposit/withdraw, exposure).
//
// Money moves only via `transferFunds` — actual amounts, no credit limits and no
// G/T settlement. "G/T" on an account is now a read-only lifetime profit/loss
// figure returned by getAllDetails / updateCurrent.
import { apiFetch, apiDownload } from '../utils/api';
import type { StaffPermissions } from '../constants/permissions';
import type {
  AgentStatement, BetPage, CasinoTxnRow, SportsBetRow,
} from '../components/agent-statement/types';

// ─── Account Statement ("hisab") ────────────────────────────────
//   On-screen report for one agent (whole downline) or one player:
//   opening/closing balance, every deposit & withdrawal with a running
//   balance, and the sports/casino profit or loss for the period.

export interface StatementParams {
  from?: string;          // YYYY-MM-DD, inclusive
  to?: string;            // YYYY-MM-DD, inclusive
  page?: number;
  limit?: number;
  category?: 'all' | 'money' | 'sports' | 'casino';
}

const statementQuery = (p: Record<string, string | number | undefined>) => {
  const qs = new URLSearchParams();
  Object.entries(p).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== '' && !(k === 'category' && v === 'all')) {
      qs.set(k, String(v));
    }
  });
  const q = qs.toString();
  return q ? `?${q}` : '';
};

/** Base path for one subject — agents and players share every report route. */
const subjectPath = (subjectType: 'STAFF' | 'USER', id: number | string) =>
  subjectType === 'USER'
    ? `/api/admin/agent-report/user/${id}`
    : `/api/admin/agent-report/${id}`;

export const getAccountStatement = (
  subjectType: 'STAFF' | 'USER',
  id: number | string,
  params: StatementParams = {}
) => apiFetch<AgentStatement>(`${subjectPath(subjectType, id)}/statement${statementQuery(params as any)}`);

/** Individual sports bets / casino transactions, paginated server-side —
 *  these lists are unbounded, so they are never bundled into the statement. */
export const getAccountBets = <K extends 'sports' | 'casino'>(
  subjectType: 'STAFF' | 'USER',
  id: number | string,
  params: { kind: K; from?: string; to?: string; page?: number; limit?: number }
) => apiFetch<BetPage<K extends 'sports' ? SportsBetRow : CasinoTxnRow>>(
  `${subjectPath(subjectType, id)}/bets${statementQuery(params as any)}`
);

/** Printable statement — the same report the screen shows, rendered server-side
 *  from the same builder. Works for agents and players alike. */
export const downloadAccountStatementPdf = (
  subjectType: 'STAFF' | 'USER',
  id: number | string,
  params: { from?: string; to?: string } = {}
): Promise<Blob> =>
  apiDownload(`${subjectPath(subjectType, id)}/pdf${statementQuery(params as any)}`);

// ─── Agent Settlement Report (PDF) ──────────────────────────────
// Returns the generated PDF as a Blob. `full` lists every casino transaction;
// otherwise a per-day casino summary is used. Optional from/to (YYYY-MM-DD)
// restrict the report to a date range.
export const downloadAgentReport = (
  staffId: number | string,
  params: { full?: boolean; from?: string; to?: string } = {}
): Promise<Blob> => {
  const qs = new URLSearchParams();
  if (params.full) qs.set('full', '1');
  if (params.from) qs.set('from', params.from);
  if (params.to) qs.set('to', params.to);
  const q = qs.toString();
  return apiDownload(`/api/admin/agent-report/${staffId}${q ? `?${q}` : ''}`);
};

// ─── User Settings ──────────────────────────────────────────────

export const updatePassword = (payload: {
  userId: number | string;
  userType: 'STAFF' | 'USER';
  newPassword: string;
  transactionPassword: string;
}) => apiFetch('/lords/user-setting/update-password', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(payload),
});

export const updateStatus = (payload: {
  userId: number | string;
  userType: 'STAFF' | 'USER';
  status?: string;
  betStatus?: string;
  sportsLocked?: boolean;
  casinoLocked?: boolean;
  systemLocked?: boolean;
  transactionPassword: string;
}) => apiFetch('/lords/user-setting/status', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(payload),
});

export const updateExposureLimit = (payload: {
  userId: number | string;
  userType: 'STAFF' | 'USER';
  exposureLimit: number | null;
  transactionPassword: string;
}) => apiFetch('/lords/user-setting/exposure-limit', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(payload),
});

// ─── Quick Wallet Refill (Staff Portal) ─────────────────────────

export const quickRefill = (payload: {
  userId: number | string;
  amount: number;
  note?: string;
  transactionPassword: string;
}) => apiFetch('/lords/quick-refill', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(payload),
});

// ─── Balance Sheet (SuperAdmin only) ────────────────────────────

export interface BalanceSheetRow {
  ts: string;
  type: 'CREDIT' | 'DEBIT';
  category: string;
  description: string;
  amount: number;
  balance: number;
  currency: string;
}
export interface BalanceSheetResponse {
  status: string;
  user: { id: string; name: string; email: string; staff_name: string | null; live_balance: number };
  currency: string;
  summary: { total_credit: number; total_debit: number; net: number; ledger_balance: number; open_exposure: number; reconciled: boolean; event_count: number };
  pagination: { page: number; limit: number; total: number; pages: number };
  rows: BalanceSheetRow[];
}

export const getBalanceSheet = (
  userId: number | string,
  params: { currency?: string; page?: number; limit?: number } = {}
) => {
  const qs = new URLSearchParams();
  if (params.currency) qs.set('currency', params.currency);
  if (params.page) qs.set('page', String(params.page));
  if (params.limit) qs.set('limit', String(params.limit));
  return apiFetch<BalanceSheetResponse>(`/api/admin/balance-sheet/${userId}?${qs.toString()}`);
};

// ─── Deposit / Withdraw ─────────────────────────────────────────
//   The only way money moves between accounts. `amount` is always a
//   positive number — `direction` decides which way it flows:
//     deposit  → caller pays, target's balance grows
//     withdraw → target pays, caller's balance grows
//   Both sides are checked against real balances; there is no credit.

export interface TransferFundsResponse {
  status: string;
  message: string;
  balance: number;
}

export const transferFunds = (payload: {
  userId: number | string;
  userType: 'STAFF' | 'USER';
  amount: number;
  direction: 'deposit' | 'withdraw';
  note?: string;
  transactionPassword: string;
}) => apiFetch<TransferFundsResponse>('/lords/funds/transfer', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(payload),
});

export const getTransferStatement = (params: { page?: number; limit?: number }) =>
  apiFetch(`/lords/transfer/statement?page=${params.page || 1}&limit=${params.limit || 25}`);

// ─── Net Exposure ───────────────────────────────────────────────

export const getNetExposure = (userId: number | string, userType: 'STAFF' | 'USER') =>
  apiFetch(`/lords/net-exposure/sports?userId=${userId}&userType=${userType}`);

// ─── Agent Listing ──────────────────────────────────────────────

export const getAllDetails = (params: {
  page?: number;
  limit?: number;
  search?: string;
  parentId?: number;
}) => {
  const qs = new URLSearchParams();
  if (params.page) qs.set('page', String(params.page));
  if (params.limit) qs.set('limit', String(params.limit));
  if (params.search) qs.set('search', params.search);
  if (params.parentId) qs.set('parentId', String(params.parentId));
  return apiFetch(`/lords/users/all-details?${qs.toString()}`);
};

// ─── Current User ───────────────────────────────────────────────

export const updateCurrent = () => apiFetch('/lords/update-current', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({}),
});

// ─── Create Staff (with transaction password) ───────────────────

/** `initialBalance` is a real opening deposit funded from the creator's own
 *  balance — not a credit line. Pass 0 to create an unfunded account. */
export const createStaff = (payload: {
  username: string;
  email: string;
  password: string;
  role: string;
  initialBalance: number;
  percentage: number;
  transactionPassword: string;
}) => apiFetch('/api/staff', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    name: payload.username,
    email: payload.email,
    password: payload.password,
    role_name: payload.role,
    initial_balance: payload.initialBalance,
    percentage: payload.percentage,
    transactionPassword: payload.transactionPassword,
  }),
});

export const createUser = (payload: {
  username: string;
  email: string;
  password: string;
  initialBalance: number;
  percentage: number;
  transactionPassword: string;
}) => apiFetch('/api/staff/players', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    username: payload.username,
    email: payload.email,
    password: payload.password,
    initial_balance: payload.initialBalance,
    transactionPassword: payload.transactionPassword,
  }),
});

// ─── First Login ────────────────────────────────────────────────

export const firstLoginPassword = (staffId: number | string, newPassword: string) =>
  apiFetch('/api/staff/auth/first-login-password', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ staffId, newPassword }),
  });

// ─── Access Management (Executives) ─────────────────────────────
//   Every hierarchy member can create Executives that work on
//   their behalf. Role is always "Executive".

export const listExecutives = (params: { page?: number; limit?: number; search?: string }) => {
  const qs = new URLSearchParams();
  if (params.page)   qs.set('page', String(params.page));
  if (params.limit)  qs.set('limit', String(params.limit));
  if (params.search) qs.set('search', params.search);
  return apiFetch(`/lords/access/executives?${qs.toString()}`);
};

export const createExecutive = (payload: {
  username: string;
  password: string;
  permissions: StaffPermissions;
  transactionPassword: string;
}) => apiFetch('/lords/access/executives', {
  method: 'POST',
  body: JSON.stringify(payload),
});

export const updateExecutive = (
  executiveId: number | string,
  payload: { permissions: StaffPermissions; transactionPassword: string }
) => apiFetch(`/lords/access/executives/${executiveId}`, {
  method: 'PATCH',
  body: JSON.stringify(payload),
});

export const resetExecutivePassword = (
  executiveId: number | string,
  payload: { newPassword: string; transactionPassword: string }
) => apiFetch(`/lords/access/executives/${executiveId}/password`, {
  method: 'PATCH',
  body: JSON.stringify(payload),
});

export const lockExecutive = (
  executiveId: number | string,
  payload: { lock: boolean; transactionPassword: string }
) => apiFetch(`/lords/access/executives/${executiveId}/lock`, {
  method: 'PATCH',
  body: JSON.stringify(payload),
});

export const getExecutiveActivity = (
  executiveId: number | string,
  params: { page?: number; limit?: number; from?: string; to?: string } = {}
) => {
  const qs = new URLSearchParams();
  if (params.page)  qs.set('page',  String(params.page));
  if (params.limit) qs.set('limit', String(params.limit));
  if (params.from)  qs.set('from',  params.from);
  if (params.to)    qs.set('to',    params.to);
  return apiFetch(`/lords/access/executives/${executiveId}/activity?${qs.toString()}`);
};

/** Global hierarchy-scoped activity log. SuperAdmin sees all; others see
 *  their own actions + their downline's. */
export const getActivity = (
  params: {
    page?: number; limit?: number;
    action?: string; status?: string; targetType?: string;
    staffId?: number | string; q?: string; from?: string; to?: string;
  } = {}
) => {
  const qs = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== '') qs.set(k, String(v));
  });
  return apiFetch<ActivityLogResponse>(`/lords/access/activity?${qs.toString()}`);
};

export interface ActivityEntry {
  id: number;
  staffId: number;
  executiveId: number | null;
  actorName: string | null;
  actorRole: string | null;
  actorLevel: number | null;
  action: string;
  targetType: string | null;
  targetId: string | null;
  targetName: string | null;
  details: any;
  ip: string | null;
  country: string | null;
  region: string | null;
  city: string | null;
  location: string | null;
  userAgent: string | null;
  status: 'success' | 'failed';
  errorMessage: string | null;
  createdAt: string;
}

export interface ActivityLogResponse {
  status: string;
  scope?: { isSuperAdmin: boolean; staffId: number };
  entries: ActivityEntry[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

export const getMyPermissions = () =>
  apiFetch<{ permissions: StaffPermissions; role: string }>('/lords/access/me/permissions');

/** Verify an executive's password without taking over the session.
 *  Uses raw fetch so a 400/401 here doesn't clobber the parent admin's token. */
export const testExecutiveLogin = async (payload: { username: string; password: string }) => {
  const res = await fetch('https://example.com/api/staff/auth/executive/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  let body: any = {};
  try { body = await res.json(); } catch { /* swallow */ }
  return { ok: res.ok && body?.status === 'success', status: res.status, body };
};

// ─── Marketing accounts ─────────────────────────────────────────
//   Read-only analytics logins for the marketing team, created by
//   SuperAdmin only. They sign in at /marketing/login and share the
//   executive auth path, but carry no page/authority permissions —
//   their access is fixed server-side by protectMarketing.

export const listMarketingUsers = (params: { page?: number; limit?: number; search?: string }) => {
  const qs = new URLSearchParams();
  if (params.page)   qs.set('page', String(params.page));
  if (params.limit)  qs.set('limit', String(params.limit));
  if (params.search) qs.set('search', params.search);
  return apiFetch(`/lords/access/marketing-users?${qs.toString()}`);
};

export const createMarketingUser = (payload: {
  username: string;
  password: string;
  transactionPassword: string;
}) => apiFetch('/lords/access/marketing-users', {
  method: 'POST',
  body: JSON.stringify(payload),
});

export const resetMarketingPassword = (
  id: number | string,
  payload: { newPassword: string; transactionPassword: string }
) => apiFetch(`/lords/access/marketing-users/${id}/password`, {
  method: 'PATCH',
  body: JSON.stringify(payload),
});

export const lockMarketingUser = (
  id: number | string,
  payload: { lock: boolean; transactionPassword: string }
) => apiFetch(`/lords/access/marketing-users/${id}/lock`, {
  method: 'PATCH',
  body: JSON.stringify(payload),
});
