// src/utils/api.ts
const BASE = "https://example.com";

export async function apiFetch<T = any>(
  path: string,
  options: RequestInit = {}
): Promise<T> {
  const token = localStorage.getItem("token");
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...(options.headers as any),
    ...(token ? { Authorization: `Bearer ${token}` } : {})
  };

  const res = await fetch(`${BASE}${path}`, {
    ...options,
    headers
  });

  if (res.status === 401) {
    const errorData = await res.json().catch(() => ({}));
    if (errorData.code === 'TOKEN_EXPIRED') {
      // Show a nicer message to user
      console.log('Session expired, redirecting to login...');
    }
    localStorage.clear();
    window.location.href = "/login";
    throw new Error("Unauthorized");
  }
  if (!res.ok) {
    const text = await res.text();
    const err = new Error(text || `Error ${res.status}`) as Error & { status?: number };
    err.status = res.status;
    throw err;
  }
  return (res.status === 204 ? ({} as T) : (await res.json())) as T;
}

/**
 * Fetch a binary response (e.g. a generated PDF) and return it as a Blob.
 * Mirrors apiFetch's auth + 401 handling, but never JSON-parses the body.
 */
export async function apiDownload(
  path: string,
  options: RequestInit = {}
): Promise<Blob> {
  const token = localStorage.getItem("token");
  const headers: Record<string, string> = {
    ...(options.headers as any),
    ...(token ? { Authorization: `Bearer ${token}` } : {})
  };

  const res = await fetch(`${BASE}${path}`, { ...options, headers });

  if (res.status === 401) {
    localStorage.clear();
    window.location.href = "/login";
    throw new Error("Unauthorized");
  }
  if (!res.ok) {
    // Error bodies are JSON; surface the message if present.
    const text = await res.text();
    let msg = text || `Error ${res.status}`;
    try { msg = JSON.parse(text)?.message || msg; } catch { /* keep raw text */ }
    const err = new Error(msg) as Error & { status?: number };
    err.status = res.status;
    throw err;
  }
  return await res.blob();
}

/**
 * POST a FormData body (file uploads) and parse the JSON reply.
 * Mirrors apiFetch's auth + 401 handling. It cannot reuse apiFetch because that
 * forces Content-Type: application/json; a multipart body needs the browser to
 * set the header itself, boundary included.
 */
export async function apiUpload<T = any>(path: string, body: FormData): Promise<T> {
  const token = localStorage.getItem("token");
  const res = await fetch(`${BASE}${path}`, {
    method: "POST",
    body,
    headers: token ? { Authorization: `Bearer ${token}` } : {},
  });

  if (res.status === 401) {
    localStorage.clear();
    window.location.href = "/login";
    throw new Error("Unauthorized");
  }
  const text = await res.text();
  let data: any = {};
  try { data = text ? JSON.parse(text) : {}; } catch { /* non-JSON error page */ }
  if (!res.ok) {
    const err = new Error(data?.message || text || `Error ${res.status}`) as Error & { status?: number };
    err.status = res.status;
    throw err;
  }
  return data as T;
}
