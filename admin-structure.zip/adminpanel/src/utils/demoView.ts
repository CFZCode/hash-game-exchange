// Demo-view login (e.g. superadmindemo): a SuperAdmin that sees every screen
// but no data. Installed once at startup; it reads the flag on every call so it
// switches on/off right after login/logout without a reload.
//
//  • Writes (non-GET) to the API are never sent — they resolve with a stub.
//  • Every API reply is blanked (arrays emptied, numbers zeroed, text cleared)
//    keeping its shape, so screens render empty instead of crashing.
//
// The backend enforces the same thing for any request carrying the demo token
// (myapp/backend/system/utils/demoView.js); this side also covers screens
// that call the API without a token.
import axios from "axios";

export const DEMO_VIEW_KEY = "demoView";

const API_HOST = "example.com";
const PASSTHROUGH = [/\/api\/staff\/auth\/(login|logout)$/];
const KEEP_KEYS = new Set(["status", "success", "message", "msg", "code", "error", "ok"]);

export const WRITE_STUB = {
  status: "success",
  success: true,
  message: "Demo account — no changes were saved",
  data: [],
};

export const isDemoView = () => {
  try { return localStorage.getItem(DEMO_VIEW_KEY) === "1"; } catch { return false; }
};

export function blank(value: any, key?: string): any {
  if (key && KEEP_KEYS.has(key)) return value;
  if (Array.isArray(value)) return [];
  if (value === null || value === undefined) return value;
  if (typeof value === "number") return 0;
  if (typeof value === "boolean") return value;
  if (typeof value === "string")
    return value.trim() !== "" && !isNaN(Number(value)) ? "0" : "";
  if (typeof value === "object") {
    const out: Record<string, any> = {};
    for (const k of Object.keys(value)) out[k] = blank(value[k], k);
    return out;
  }
  return value;
}

const isApiUrl = (url: string) => {
  try {
    return new URL(url, window.location.origin).host === API_HOST;
  } catch {
    return false;
  }
};
const isPassthrough = (url: string) => {
  const path = url.split("?")[0];
  return PASSTHROUGH.some((re) => re.test(path));
};
const isWrite = (method?: string) =>
  !!method && !["GET", "HEAD", "OPTIONS"].includes(method.toUpperCase());

const jsonResponse = (body: any) =>
  new Response(JSON.stringify(body), {
    status: 200,
    headers: { "Content-Type": "application/json" },
  });

let installed = false;

export function installDemoView() {
  if (installed) return;
  installed = true;

  const realFetch = window.fetch.bind(window);
  window.fetch = async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = typeof input === "string" ? input : input instanceof URL ? input.href : input.url;
    if (!isDemoView() || !isApiUrl(url) || isPassthrough(url)) return realFetch(input, init);

    const method = init?.method || (input instanceof Request ? input.method : "GET");
    if (isWrite(method)) return jsonResponse(WRITE_STUB);

    const res = await realFetch(input, init);
    const type = res.headers.get("Content-Type") || "";
    if (!type.includes("application/json")) {
      // Files / CSV / images: hand back nothing.
      return new Response(type.includes("text") ? "" : new Blob([]), {
        status: res.status,
        headers: { "Content-Type": type },
      });
    }
    const body = await res.json().catch(() => ({}));
    return new Response(JSON.stringify(blank(body)), {
      status: res.status,
      statusText: res.statusText,
      headers: { "Content-Type": "application/json" },
    });
  };

  // Default axios instance (axios.get / axios.post …). Instances made with
  // axios.create() need installDemoViewAxios() themselves.
  installDemoViewAxios(axios);
}

export function installDemoViewAxios(instance: typeof axios | ReturnType<typeof axios.create>) {
  instance.interceptors.request.use((config) => {
    const url = axios.getUri(config);
    if (isDemoView() && isApiUrl(url) && !isPassthrough(url) && isWrite(config.method)) {
      // Short-circuit: never send the write, answer with the stub instead.
      config.adapter = async () => ({
        data: WRITE_STUB,
        status: 200,
        statusText: "OK",
        headers: {},
        config,
        request: {},
      });
    }
    return config;
  });
  instance.interceptors.response.use((response) => {
    const url = axios.getUri(response.config);
    if (isDemoView() && isApiUrl(url) && !isPassthrough(url)) {
      const d = response.data;
      response.data =
        d && typeof d === "object" && !(d instanceof Blob) && !(d instanceof ArrayBuffer)
          ? blank(d)
          : d instanceof Blob ? new Blob([]) : typeof d === "string" ? "" : d;
    }
    return response;
  });
}
