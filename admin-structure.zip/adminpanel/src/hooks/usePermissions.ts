import { useEffect, useState, useCallback } from 'react';
import {
  StaffPermissions,
  buildFullPermissions,
  buildEmptyPermissions,
  SUPER_ROLES,
} from '../constants/permissions';
import { socketService } from '../services/socketService';
import * as lordsApi from '../services/lordsApi';

const CACHE_KEY = 'myPermissions';

function loadCache(): StaffPermissions | null {
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    return raw ? (JSON.parse(raw) as StaffPermissions) : null;
  } catch {
    return null;
  }
}

function saveCache(p: StaffPermissions) {
  try {
    localStorage.setItem(CACHE_KEY, JSON.stringify(p));
  } catch {}
}

interface UsePermissionsResult {
  permissions: StaffPermissions;
  role: string;
  isSuper: boolean;
  loading: boolean;
  can: (key: string) => boolean;
  /** True when ANY of the keys is granted — used where a capability was
   *  renamed and older accounts still carry the legacy key. */
  canAny: (keys: readonly string[]) => boolean;
  pageVisible: (path: string) => boolean;
  groupVisible: (title: string) => boolean;
  refresh: () => Promise<void>;
}

export function usePermissions(): UsePermissionsResult {
  const role = localStorage.getItem('userRole') || 'Guest';
  const isSuper = (SUPER_ROLES as readonly string[]).includes(role);
  // Demo Portal Agents have a fixed menu and no staff permissions row to fetch.
  const noFetch = isSuper || role === 'DemoAgent';

  const [permissions, setPermissions] = useState<StaffPermissions>(() => {
    if (isSuper) return buildFullPermissions();
    return loadCache() ?? buildEmptyPermissions();
  });
  const [loading, setLoading] = useState(!noFetch && loadCache() === null);

  const refresh = useCallback(async () => {
    if (noFetch) return;
    try {
      const data = await lordsApi.getMyPermissions();
      if (data?.permissions) {
        setPermissions(data.permissions);
        saveCache(data.permissions);
      }
    } catch (e) {
      console.error('[Permissions] refresh failed', e);
    } finally {
      setLoading(false);
    }
  }, [noFetch]);

  useEffect(() => {
    if (noFetch) return;

    const token = localStorage.getItem('token');
    if (!token) return;

    socketService.connect(token);
    socketService.subscribeToMyPermissions((data) => {
      if (data?.permissions) {
        setPermissions(data.permissions);
        saveCache(data.permissions);
        setLoading(false);
      }
    });

    refresh();

    return () => {
      socketService.unsubscribeFromMyPermissions();
    };
  }, [noFetch, refresh]);

  const can = useCallback(
    (key: string) => {
      if (isSuper) return true;
      return Boolean(permissions.authority?.[key]);
    },
    [isSuper, permissions]
  );

  const canAny = useCallback(
    (keys: readonly string[]) => {
      if (isSuper) return true;
      return keys.some((k) => Boolean(permissions.authority?.[k]));
    },
    [isSuper, permissions]
  );

  const groupVisible = useCallback(
    (title: string) => {
      if (isSuper) return true;
      return Boolean(permissions.groups?.[title]);
    },
    [isSuper, permissions]
  );

  const pageVisible = useCallback(
    (path: string) => {
      if (isSuper) return true;
      return Boolean(permissions.pages?.[path]);
    },
    [isSuper, permissions]
  );

  return { permissions, role, isSuper, loading, can, canAny, pageVisible, groupVisible, refresh };
}
