import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, Outlet, useLocation } from 'react-router-dom';
import Layout from './components/Layout';
import Users from './components/Users';
import Settings from './components/Settings';
import AdminDashboard from './components/AdminDashboard';
import LoginPage from './components/Login';
import Wallet from './components/WalletUpdate';
import DepositPage from './components/DepositPage';
import WithdrawPage from './components/WithdrawPage';
import House from './components/House'
import History from './components/History';
import Game from './components/Games';
import GamesLog from './components/WinSetting';
import SEO from './components/SeoManager';
import Referal from './components/Refrel';
import Bonus from './components/Bonus';
import NotificationSettings from './components/NotificationSettings';
import WinSettings from './components/WinSetting';
import ClubMemberShip from './components/ClubMembership';
import Banner from './components/Banner';
import BankDetails from './components/BankDetails';
import { Buffer } from 'buffer';
import SportsBetting from './components/SportsBetting';
import RedeemCode from './components/RedeemCode';
import ExchangeRate from './components/ExchangeRate';
import PaymentMethodsStatus from './components/PaymentMethodsStatus';
import Notification from './components/notification';
import SwapHistory from './components/SwapHistory';
import Reports from './components/Reports';
import KYC from './components/UserKyc';
import AdminManagementLayout from './components/AdminManagement';
import DashboardTab from './components/admin-management/DashboardTab';

import SettingsTab from './components/admin-management/SettingsTab';
import MyAccountTab from './components/admin-management/MyAccountTab';
import StaffPortalTab from './components/admin-management/StaffPortalTab';
import BetListTab from './components/admin-management/BetListTab';
import BetListLiveTab from './components/admin-management/BetListLiveTab';

import CasinoTab from './components/admin-management/CasinoTab';
import RiskManagementTab from './components/admin-management/RiskManagementTab';
import ImportTab from './components/admin-management/ImportTab';
import MessageTab from './components/admin-management/MessageTab';
import GameCenterTab from './components/admin-management/GameCenterTab';
import AgentListingTab from './components/admin-management/AgentListingTab';
import TransferTab from './components/admin-management/TransferTab';
import AccessManagementTab from './components/admin-management/AccessManagementTab';
import ActivityLogTab from './components/admin-management/ActivityLogTab';
import RequirePermission from './components/RequirePermission';
import GameWinLossToggle from './components/GameWinLossToggle';
import UserConfig from './components/UserConfig';
import SiteConfig from './components/SiteConfig';
import PercentageHierarchyPage from './components/PercentageHierarchyPage';
import MarketHistory from './components/MarketWins';
import FanWins from './components/FanwinsHistory';
import MarketInternalSettle from './components/matchsettlement';
import FanInternalSettle from './components/FanmanualSettle';
import FancyResultNotShowingFromApi from './components/FancyResult';
import GiftCardAdmin from './components/AdminGiftcards';
import TurnoverReport from './components/TurnoverReport';
import ThreeDGames from './components/three-d-games/ThreeDGames';
import VaultPro from './components/vaultpro';
import PeerTrade from './components/PeerTrade';
import SportsDashboard from './components/sportsbetStats';
import FancySettlement from './components/FancySettlement';
import SportsConfigSection from './components/SportsConfig';
import SpinWheel from './components/spinWheel';
import BlogAdmin from './components/Blog';
import AccountStatement from './components/AccountStatement';
import AccountReport from './components/agent-statement/AccountReport';
import ProvidersPriority from './components/ProvidersPriority';
import VendorPriority from './components/VendorPriority';
import TypePriority from './components/TypePriority';
import MarketingLogin from './components/marketing/MarketingLogin';
import MarketingLayout from './components/marketing/MarketingLayout';
import MarketingDashboard from './components/marketing/MarketingDashboard';
import MarketingCustomers from './components/marketing/MarketingCustomers';
import MarketingUsersTab from './components/admin-management/MarketingUsersTab';
import NotFound from './components/NotFound';
import HomeRedirect from './components/HomeRedirect';
import DemoPortal from './components/demo-portal/DemoPortal';
import { DEMO_AGENT_ROLE } from './services/demoPortalApi';
import BranchLogin from './components/branch/BranchLogin';
import { BranchLayout, AdminBranchShell } from './components/branch/BranchLayout';
import BranchDashboard from './components/branch/BranchDashboard';
import { BranchesPage, SubBranchesPage } from './components/branch/BranchStaffPages';
import BranchPlayersPage from './components/branch/PlayersPage';
import BranchPlayerReport from './components/branch/PlayerReport';
import BranchTransactionsPage from './components/branch/TransactionsPage';
import BranchDailyReport from './components/branch/DailyReport';
import BranchBetsPage from './components/branch/BetsPage';
import BranchAccountPage from './components/branch/AccountPage';

/* Pages shared by the branch panel (/branch) and the super admin's Branch
   Management (/branch-management). Each page hides what the viewer's role
   cannot use; the API enforces it. */
const branchPages = (
  <>
    <Route index element={<BranchDashboard />} />
    <Route path="branches" element={<BranchesPage />} />
    <Route path="sub-branches" element={<SubBranchesPage />} />
    <Route path="players" element={<BranchPlayersPage />} />
    <Route path="players/:id" element={<BranchPlayerReport />} />
    <Route path="deposits" element={<BranchTransactionsPage key="deposit" type="deposit" />} />
    <Route path="withdrawals" element={<BranchTransactionsPage key="withdraw" type="withdraw" />} />
    <Route path="daily" element={<BranchDailyReport />} />
    <Route path="bets" element={<BranchBetsPage />} />
  </>
);


function App() {
  window.Buffer = Buffer;
  const [token, setToken] = useState(localStorage.getItem('token'));

  useEffect(() => {
    const handleStorageChange = () => {
      setToken(localStorage.getItem('token'));
    };

    // Listen for changes in localStorage
    window.addEventListener('storage', handleStorageChange);

    // Initial check in case the value is set before the listener is attached
    handleStorageChange();

    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);

  const ProtectedRoutes = () => {
    // Re-check token on each render of ProtectedRoutes
    const currentToken = localStorage.getItem('token');
    return currentToken ? <Outlet /> : <Navigate to="/login" replace />;
  };

  // A Demo Portal Agent only ever sees /demo-portal.
  const DemoAgentGate = () => {
    const location = useLocation();
    if (localStorage.getItem('userRole') === DEMO_AGENT_ROLE && location.pathname !== '/demo-portal')
      return <Navigate to="/demo-portal" replace />;
    return <Outlet />;
  };

  return (
    <BrowserRouter>
      <Routes>
        {/*  ───────── public page ───────── */}
        <Route path="/login" element={<LoginPage />} />

        {/*  ───────── marketing panel ─────────
            Separate login + shell from the admin app. Guarded by
            MarketingLayout, which redirects to /marketing/login when the
            marketing session is missing. Sits outside ProtectedRoutes because
            it uses its own session keys, not `token`. */}
        <Route path="/marketing/login" element={<MarketingLogin />} />
        <Route path="/marketing" element={<MarketingLayout />}>
          <Route index element={<MarketingDashboard />} />
          <Route path="direct-users" element={<MarketingCustomers channel="direct" />} />
          <Route path="agent-users" element={<MarketingCustomers channel="agent" />} />
        </Route>

        {/*  ───────── branch panel ─────────
            Own login + shell + session keys (branchToken), like the marketing
            panel. Branch Admins and Sub Branches only ever see this. */}
        <Route path="/branch/login" element={<BranchLogin />} />
        <Route path="/branch" element={<BranchLayout />}>
          {branchPages}
          <Route path="account" element={<BranchAccountPage />} />
        </Route>

        {/*  ───────── protected part ────── */}
        <Route element={<ProtectedRoutes />}>
          <Route element={<DemoAgentGate />}>
          <Route path="/" element={<Layout />}>

            {/* ↓↓↓  HOME → first page the account is allowed to see  ↓↓↓ */}
            <Route index element={<HomeRedirect />} />

            {/*  ───── separate top-level dashboard if you still need it ─────  */}
            <Route path="admin-dashboard" element={<AdminDashboard />} />

            {/*  ───── client-management group ─────  */}
            <Route path="admin-management" element={<AdminManagementLayout />}>
              <Route index element={<DashboardTab />} />
              <Route path="dashboard" element={<DashboardTab />} />

              <Route path="setting" element={<SettingsTab />} />
              <Route path="myaccount" element={<MyAccountTab />} />
              <Route path="staff-portal" element={<StaffPortalTab />} />
              <Route path="betlist" element={<BetListTab />} />
              <Route path="betlistlive" element={<BetListLiveTab />} />
              <Route path="casino" element={<CasinoTab />} />
              <Route path="riskmanagement" element={<RiskManagementTab />} />
              <Route path="import" element={<ImportTab />} />
              <Route path="message" element={<MessageTab />} />
              <Route path="gamecenter" element={<GameCenterTab />} />
              <Route path="agents" element={<AgentListingTab />} />
              <Route path="transfer" element={<TransferTab />} />
              <Route path="access" element={<AccessManagementTab />} />
              <Route path="marketing-users" element={<MarketingUsersTab />} />
            </Route>

            {/*  ───── Activity Log (top-level sidebar page) ───── */}
            <Route path="activity-log" element={<ActivityLogTab />} />

            {/*  ───── everything else (each route gated via RequirePermission) ───── */}
            <Route path="withdraw" element={<RequirePermission authority="canApproveWithdraw"><WithdrawPage /></RequirePermission>} />
            <Route path="users" element={<RequirePermission><Users /></RequirePermission>} />
            <Route path="settings" element={<RequirePermission><Settings /></RequirePermission>} />
            <Route path="deposit" element={<RequirePermission authority="canApproveDeposit"><DepositPage /></RequirePermission>} />
            <Route path="account-statement" element={<RequirePermission><AccountStatement /></RequirePermission>} />
            {/* Per-account "hisab" — opened in its own tab from the agent listing.
                `subject` is 'staff' (agent + downline) or 'user' (one player).
                Gated on Client Management, since that is where it is launched
                from; the API re-checks the hierarchy on every request anyway. */}
            <Route
              path="account-report/:subject/:id"
              element={<RequirePermission page="/admin-management"><AccountReport /></RequirePermission>}
            />
            <Route path="games" element={<RequirePermission><Game /></RequirePermission>} />
            <Route path="win-settings" element={<RequirePermission><WinSettings /></RequirePermission>} />
            <Route path="house" element={<RequirePermission><House /></RequirePermission>} />
            <Route path="wallet" element={<RequirePermission><Wallet /></RequirePermission>} />
            <Route path="history" element={<RequirePermission><History /></RequirePermission>} />
            <Route path="seo-manager" element={<RequirePermission><SEO /></RequirePermission>} />
            <Route path="affiliate" element={localStorage.getItem('userRole') === 'SuperAdmin' ? <Referal /> : <Navigate to="/admin-dashboard" replace />} />
            {/* Platform-wide house figures: super admin only (the API enforces it too). */}
            <Route path="3d-games" element={localStorage.getItem('userRole') === 'SuperAdmin' ? <ThreeDGames /> : <Navigate to="/admin-dashboard" replace />} />
            <Route path='marketwins' element={<RequirePermission><MarketHistory /></RequirePermission>} />
            <Route path='MOsettle' element={<RequirePermission authority="canSettleSports"><MarketInternalSettle /></RequirePermission>} />
            <Route path='Fansettle' element={<RequirePermission authority="canSettleFancy"><FancySettlement /></RequirePermission>} />
            <Route path='fancyreport' element={<RequirePermission><FancyResultNotShowingFromApi /></RequirePermission>} />
            <Route path='fanwins' element={<RequirePermission><FanWins /></RequirePermission>} />
            <Route path="bonus" element={<RequirePermission authority="canIssueBonus"><Bonus /></RequirePermission>} />
            <Route path="club" element={<RequirePermission><ClubMemberShip /></RequirePermission>} />
            <Route path="banner" element={<RequirePermission><Banner /></RequirePermission>} />
            <Route path="bankdetails" element={<RequirePermission><BankDetails /></RequirePermission>} />
            <Route path="redeemcode" element={<RequirePermission authority="canCreateRedeemCode"><RedeemCode /></RequirePermission>} />
            <Route path="sportsbeting" element={<RequirePermission><SportsBetting /></RequirePermission>} />
            <Route path="exchangerate" element={<RequirePermission><ExchangeRate /></RequirePermission>} />
            <Route path="payment-methods" element={<RequirePermission><PaymentMethodsStatus /></RequirePermission>} />
            <Route path="notification" element={<RequirePermission authority="canSendNotification"><Notification /></RequirePermission>} />
            <Route path="swaphistory" element={<RequirePermission><SwapHistory /></RequirePermission>} />
            <Route path="reports" element={<RequirePermission authority="canViewReports"><Reports /></RequirePermission>} />
            <Route path="kyc" element={<RequirePermission authority="canManageKYC"><KYC /></RequirePermission>} />
            <Route path="siteconfig" element={<RequirePermission authority="canEditSiteConfig"><SiteConfig /></RequirePermission>} />
            <Route path="providers-priority" element={<RequirePermission authority="canEditPriorities"><ProvidersPriority /></RequirePermission>} />
            <Route path="vendor-priority" element={<RequirePermission authority="canEditPriorities"><VendorPriority /></RequirePermission>} />
            <Route path="type-priority" element={<RequirePermission authority="canEditPriorities"><TypePriority /></RequirePermission>} />
            <Route path="userconfig" element={<RequirePermission><UserConfig /></RequirePermission>} />
            <Route path="winloss" element={<RequirePermission><GameWinLossToggle /></RequirePermission>} />
            <Route path="notification-settings" element={<RequirePermission><NotificationSettings /></RequirePermission>} />
            <Route path="/percentage-hierarchy" element={<RequirePermission><PercentageHierarchyPage /></RequirePermission>} />
            <Route path="giftcard-admin" element={<RequirePermission authority="canIssueGiftCard"><GiftCardAdmin /></RequirePermission>} />
            <Route path="turnover-report" element={<RequirePermission authority="canViewReports"><TurnoverReport /></RequirePermission>} />
            <Route path="vaultpro" element={<RequirePermission><VaultPro /></RequirePermission>} />
            <Route path="peer-trade" element={<RequirePermission><PeerTrade /></RequirePermission>} />
            <Route path="sports-dashboard" element={<RequirePermission><SportsDashboard /></RequirePermission>} />
            <Route path="sports-lock" element={<RequirePermission><SportsDashboard /></RequirePermission>} />
            <Route path="sports-config" element={<RequirePermission authority="canEditSiteConfig"><SportsConfigSection /></RequirePermission>} />
            <Route path="spinwheel" element={<RequirePermission><SpinWheel /></RequirePermission>} />
            <Route path="blog" element={<RequirePermission><BlogAdmin /></RequirePermission>} />
            <Route path="demo-portal" element={<DemoPortal />} />
            <Route path="branch-management" element={<AdminBranchShell />}>
              {branchPages}
            </Route>
          </Route>
          </Route>
        </Route>

        {/*  ───────── catch-all ─────────
            Must stay last. Without it an unmatched URL rendered nothing at
            all, which reads as a blank page rather than a missing route. */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
