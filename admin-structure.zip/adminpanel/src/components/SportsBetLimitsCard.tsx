import { Alert, Box, Chip, Paper, TextField, Typography } from "@mui/material";
import { ShieldAlert } from "lucide-react";
import DarkSwitch from "./DarkSwitch";

interface SportsBetLimitsCardProps {
  enabled: boolean;
  maxOdds: string;
  enabledDirty: boolean;
  maxOddsDirty: boolean;
  maxOddsError: string | null;
  canEdit: boolean;
  onToggle: () => void;
  onMaxOddsChange: (value: string) => void;
}

const cardSx = { bgcolor: "#0E1831", border: "1px solid #1E2D55", borderRadius: 2 };

const rowSx = (dirty: boolean) => ({
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  gap: 2,
  flexWrap: "wrap" as const,
  px: 1.5,
  py: 1.25,
  borderRadius: 1.5,
  border: "1px solid",
  borderColor: dirty ? "rgba(255,194,63,0.4)" : "transparent",
  bgcolor: dirty ? "rgba(255,194,63,0.06)" : "transparent",
});

export default function SportsBetLimitsCard({
  enabled,
  maxOdds,
  enabledDirty,
  maxOddsDirty,
  maxOddsError,
  canEdit,
  onToggle,
  onMaxOddsChange,
}: SportsBetLimitsCardProps) {
  return (
    <Paper sx={{ ...cardSx, overflow: "hidden" }}>
      <Box
        sx={{
          px: 3,
          py: 2,
          bgcolor: "#0B1427",
          borderBottom: "1px solid #1E2D55",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 2,
          flexWrap: "wrap",
        }}
      >
        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
          <ShieldAlert size={18} color="#FFC23F" />
          <Box>
            <Typography sx={{ color: "#F9F9F9", fontWeight: 700, fontSize: "0.95rem" }}>
              Sports Bet Limits
            </Typography>
            <Typography variant="caption" sx={{ color: "#8384A5" }}>
              Applies to every user on match-type markets (Match Odds, Game Winner, Correct Score…).
              Bookmaker and fancy markets are not affected.
            </Typography>
          </Box>
        </Box>
        <Chip
          label={enabled ? `Max odds ${maxOdds || "—"}` : "No limit"}
          size="small"
          sx={{
            bgcolor: enabled ? "rgba(14,204,104,0.12)" : "rgba(131,132,165,0.12)",
            color: enabled ? "#0ECC68" : "#8384A5",
            fontWeight: 600,
            fontSize: "0.7rem",
          }}
        />
      </Box>

      <Box sx={{ p: 2, display: "flex", flexDirection: "column", gap: 1 }}>
        {!canEdit && (
          <Alert
            severity="info"
            sx={{
              bgcolor: "rgba(85,129,247,0.1)",
              color: "#5581F7",
              border: "1px solid rgba(85,129,247,0.3)",
              "& .MuiAlert-icon": { color: "#5581F7" },
            }}
          >
            Only SuperAdmin can change sports bet limits.
          </Alert>
        )}

        <Box sx={rowSx(enabledDirty)}>
          <Box>
            <Typography sx={{ color: "#F9F9F9", fontSize: "0.85rem", fontWeight: 500 }}>
              Restrict max odds on match markets
            </Typography>
            <Typography variant="caption" sx={{ color: "#8384A5" }}>
              When off, users can back or lay at any price the feed offers.
            </Typography>
          </Box>
          <DarkSwitch checked={enabled} onChange={onToggle} disabled={!canEdit} />
        </Box>

        <Box sx={rowSx(maxOddsDirty)}>
          <Box>
            <Typography sx={{ color: enabled ? "#F9F9F9" : "#8384A5", fontSize: "0.85rem", fontWeight: 500 }}>
              Max odds
            </Typography>
            <Typography variant="caption" sx={{ color: "#8384A5" }}>
              Back and lay bets priced above this are rejected at placement.
            </Typography>
          </Box>
          <TextField
            size="small"
            type="number"
            value={maxOdds}
            onChange={(e) => onMaxOddsChange(e.target.value)}
            disabled={!canEdit || !enabled}
            error={!!maxOddsError}
            helperText={maxOddsError || " "}
            inputProps={{ min: 1.01, max: 1000, step: 0.01 }}
            sx={{
              width: 160,
              "& .MuiOutlinedInput-root": {
                bgcolor: "#0B1427",
                "& fieldset": { borderColor: "#1E2D55" },
                "&:hover fieldset": { borderColor: "#2B6EF5" },
                "&.Mui-focused fieldset": { borderColor: "#2B6EF5" },
              },
              "& input": { color: "#F9F9F9" },
              "& .MuiFormHelperText-root": { mx: 0 },
            }}
          />
        </Box>
      </Box>
    </Paper>
  );
}
