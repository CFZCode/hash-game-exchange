import React from "react";
import { Navigate } from "react-router-dom";
import { DEMO_AGENT_ROLE } from "../../services/demoPortalApi";
import DemoAgentsAdmin from "./DemoAgentsAdmin";
import DemoAgentPortal from "./DemoAgentPortal";

/** /demo-portal — SuperAdmin manages agents; a DemoAgent manages its demo accounts. */
const DemoPortal: React.FC = () => {
  const role = localStorage.getItem("userRole");
  if (role === DEMO_AGENT_ROLE) return <DemoAgentPortal />;
  if (role === "SuperAdmin" && !localStorage.getItem("executiveId")) return <DemoAgentsAdmin />;
  return <Navigate to="/admin-management" replace />;
};

export default DemoPortal;
