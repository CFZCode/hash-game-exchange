import React, { useState } from "react";
import {
  Box, Chip, IconButton, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, Tooltip, Typography,
} from "@mui/material";
import {
  AddCircle, RemoveCircle, Edit, Visibility, VisibilityOff, ContentCopy, Block, CheckCircle,
} from "@mui/icons-material";
import type { DemoUser } from "../../services/demoPortalApi";
import { cellSx, fmt, fmtDate, headCellSx } from "./shared";

export interface DemoUserActions {
  onDeposit: (u: DemoUser) => void;
  onWithdraw: (u: DemoUser) => void;
  onEditLimit: (u: DemoUser) => void;
  onToggleLock: (u: DemoUser) => void;
}

const PasswordCell: React.FC<{ password: string | null }> = ({ password }) => {
  const [show, setShow] = useState(false);
  if (!password) return <>—</>;
  return (
    <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
      <span style={{ fontFamily: "monospace" }}>{show ? password : "••••••"}</span>
      <IconButton size="small" onClick={() => setShow((s) => !s)} sx={{ color: "#8384A5" }}>
        {show ? <VisibilityOff fontSize="inherit" /> : <Visibility fontSize="inherit" />}
      </IconButton>
    </Box>
  );
};

const DemoUsersTable: React.FC<{
  users: DemoUser[];
  loading?: boolean;
  actions?: DemoUserActions;   // omitted = read-only (SuperAdmin view)
  onCopy?: (text: string) => void;
}> = ({ users, loading, actions, onCopy }) => (
  <TableContainer sx={{ overflowX: "auto" }}>
    <Table size="small">
      <TableHead>
        <TableRow>
          {["User ID", "Username", "Password", "Balance", "Live Casino Limit", "Casino P/L", "Status", "Created", "Last Login"]
            .map((h) => <TableCell key={h} sx={headCellSx}>{h}</TableCell>)}
          {actions && <TableCell sx={headCellSx} align="right">Actions</TableCell>}
        </TableRow>
      </TableHead>
      <TableBody>
        {!loading && users.length === 0 && (
          <TableRow>
            <TableCell colSpan={actions ? 10 : 9} sx={{ ...cellSx, textAlign: "center", color: "#8384A5", py: 4 }}>
              No demo accounts yet
            </TableCell>
          </TableRow>
        )}
        {users.map((u) => (
          <TableRow key={u.id} hover>
            <TableCell sx={cellSx}>
              <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                <span style={{ fontFamily: "monospace" }}>{u.id}</span>
                {onCopy && (
                  <IconButton size="small" sx={{ color: "#8384A5" }}
                    onClick={() => onCopy(`Username: ${u.username}\nPassword: ${u.password ?? ""}\nUser ID: ${u.id}`)}>
                    <ContentCopy fontSize="inherit" />
                  </IconButton>
                )}
              </Box>
            </TableCell>
            <TableCell sx={cellSx}>
              <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                {u.username}
                <Chip label="DEMO" size="small"
                  sx={{ height: 18, fontSize: 10, fontWeight: 700, bgcolor: "rgba(255,194,63,0.15)", color: "#FFC23F" }} />
              </Box>
            </TableCell>
            <TableCell sx={cellSx}><PasswordCell password={u.password} /></TableCell>
            <TableCell sx={{ ...cellSx, fontWeight: 600 }}>{fmt(u.balance)}</TableCell>
            <TableCell sx={cellSx}>
              {u.casino_limit ? `${fmt(u.casino_limit)} / bet` : <Typography component="span" sx={{ color: "#8384A5", fontSize: 13 }}>No limit</Typography>}
            </TableCell>
            <TableCell sx={{ ...cellSx, color: Number(u.casino_pnl) >= 0 ? "#0ECC68" : "#E01B4F" }}>{fmt(u.casino_pnl)}</TableCell>
            <TableCell sx={cellSx}>
              <Chip size="small" label={u.locked ? "Betting blocked" : "Active"}
                sx={{
                  height: 20, fontSize: 11,
                  bgcolor: u.locked ? "rgba(224,27,79,0.12)" : "rgba(14,204,104,0.12)",
                  color: u.locked ? "#E01B4F" : "#0ECC68",
                }} />
            </TableCell>
            <TableCell sx={{ ...cellSx, whiteSpace: "nowrap" }}>{fmtDate(u.created)}</TableCell>
            <TableCell sx={{ ...cellSx, whiteSpace: "nowrap" }}>{fmtDate(u.last_login_at)}</TableCell>
            {actions && (
              <TableCell sx={{ ...cellSx, whiteSpace: "nowrap" }} align="right">
                <Tooltip title="Deposit"><IconButton size="small" sx={{ color: "#0ECC68" }} onClick={() => actions.onDeposit(u)}><AddCircle fontSize="small" /></IconButton></Tooltip>
                <Tooltip title="Withdraw"><IconButton size="small" sx={{ color: "#E01B4F" }} onClick={() => actions.onWithdraw(u)}><RemoveCircle fontSize="small" /></IconButton></Tooltip>
                <Tooltip title="Edit live casino limit"><IconButton size="small" sx={{ color: "#5581F7" }} onClick={() => actions.onEditLimit(u)}><Edit fontSize="small" /></IconButton></Tooltip>
                <Tooltip title={u.locked ? "Allow betting" : "Block betting"}>
                  <IconButton size="small" sx={{ color: u.locked ? "#0ECC68" : "#FFC23F" }} onClick={() => actions.onToggleLock(u)}>
                    {u.locked ? <CheckCircle fontSize="small" /> : <Block fontSize="small" />}
                  </IconButton>
                </Tooltip>
              </TableCell>
            )}
          </TableRow>
        ))}
      </TableBody>
    </Table>
  </TableContainer>
);

export default DemoUsersTable;
