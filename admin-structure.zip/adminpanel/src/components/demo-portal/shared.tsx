import React, { useEffect, useState } from "react";
import {
  Box, Button, CircularProgress, Dialog, DialogActions, DialogContent,
  DialogTitle, TextField, Typography,
} from "@mui/material";
import { AddCircle, RemoveCircle } from "@mui/icons-material";
import * as lordsApi from "../../services/lordsApi";

export const fmt = (n: number | string | null | undefined) =>
  `₹${Number(n || 0).toLocaleString("en-IN", { maximumFractionDigits: 2 })}`;

export const fmtDate = (d: string | null | undefined) =>
  d ? new Date(d).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" }) : "—";

/** apiFetch throws the raw response body; pull out the server's message. */
export const errMsg = (e: any) => {
  try {
    const body = JSON.parse(e?.message);
    return body.message || body.error || "Request failed";
  } catch {
    return e?.message || "Request failed";
  }
};

export const inputSx = { "& .MuiInputBase-root": { bgcolor: "#10182E" } };

export const dialogPaper = {
  sx: { bgcolor: "#0E1831", border: "1px solid #1E2D55", borderRadius: 2 },
};

export const cardSx = {
  bgcolor: "#0E1831", border: "1px solid #1E2D55", borderRadius: 2, p: 2.5,
};

export const headCellSx = {
  color: "#8384A5", fontSize: 12, fontWeight: 600, borderBottom: "1px solid #1E2D55",
  whiteSpace: "nowrap" as const,
};
export const cellSx = { color: "#F9F9F9", fontSize: 13, borderBottom: "1px solid #1E2D55" };

export type SnackFn = (msg: string, severity?: "success" | "error") => void;

export const StatCard: React.FC<{ label: string; value: React.ReactNode; accent?: string }> = ({ label, value, accent }) => (
  <Box sx={{ ...cardSx, p: 2, flex: "1 1 180px", minWidth: 0 }}>
    <Typography sx={{ color: "#8384A5", fontSize: 12, mb: 0.5 }}>{label}</Typography>
    <Typography sx={{ color: accent || "#F9F9F9", fontWeight: 700, fontSize: 22 }}>{value}</Typography>
  </Box>
);

/**
 * Deposit / withdraw between the caller and a direct child through
 * /lords/funds/transfer. `myBalance` is null for the SuperAdmin (house funds).
 */
export const FundsDialog: React.FC<{
  target: { id: number | string; name: string; balance: number; type: "STAFF" | "USER" } | null;
  mode: "deposit" | "withdraw";
  myBalance: number | null;
  onClose: () => void;
  onDone: () => void;
  snack: SnackFn;
}> = ({ target, mode, myBalance, onClose, onDone, snack }) => {
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [txnPwd, setTxnPwd] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => { setAmount(""); setNote(""); setTxnPwd(""); }, [target, mode]);

  if (!target) return null;
  const isDeposit = mode === "deposit";
  const amt = Number(amount) || 0;
  const accent = isDeposit ? "#0ECC68" : "#E01B4F";
  const overdrawn = isDeposit ? myBalance != null && amt > myBalance : amt > Number(target.balance || 0);

  const submit = async () => {
    if (amt <= 0) return snack("Enter a valid amount", "error");
    if (!txnPwd) return snack("Transaction password required", "error");
    setSaving(true);
    try {
      await lordsApi.transferFunds({
        userId: target.id, userType: target.type, amount: amt, direction: mode,
        note: note || undefined, transactionPassword: txnPwd,
      });
      snack(`${fmt(amt)} ${isDeposit ? "deposited to" : "withdrawn from"} ${target.name}`);
      onDone();
      onClose();
    } catch (e) {
      snack(errMsg(e), "error");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open onClose={onClose} maxWidth="xs" fullWidth PaperProps={dialogPaper}>
      <DialogTitle sx={{ color: "#F9F9F9", borderBottom: "1px solid #1E2D55" }}>
        {isDeposit
          ? <AddCircle sx={{ mr: 1, verticalAlign: "middle", color: accent }} />
          : <RemoveCircle sx={{ mr: 1, verticalAlign: "middle", color: accent }} />}
        {isDeposit ? "Deposit" : "Withdraw"} — {target.name}
      </DialogTitle>
      <DialogContent sx={{ pt: "20px !important", display: "flex", flexDirection: "column", gap: 2 }}>
        <Box sx={{ bgcolor: "#10182E", border: "1px solid #1E2D55", borderRadius: 1.5, p: 2 }}>
          <Typography sx={{ color: "#8384A5", fontSize: 12 }}>{target.name}&rsquo;s balance</Typography>
          <Typography sx={{ color: "#F9F9F9", fontWeight: 700, fontSize: 20 }}>{fmt(target.balance)}</Typography>
          {myBalance != null && (
            <Typography sx={{ color: "#8384A5", fontSize: 11, mt: 0.5 }}>Your balance: {fmt(myBalance)}</Typography>
          )}
        </Box>
        <TextField autoFocus type="number" label={`Amount to ${mode}`} value={amount}
          onChange={(e) => setAmount(e.target.value)} error={overdrawn}
          helperText={overdrawn ? (isDeposit ? "More than you hold" : `More than ${target.name} holds`) : " "}
          sx={inputSx} />
        <TextField label="Reference / Note" value={note} onChange={(e) => setNote(e.target.value)} sx={inputSx} />
        <TextField label="Transaction Password" type="password" value={txnPwd}
          onChange={(e) => setTxnPwd(e.target.value)} sx={inputSx} />
      </DialogContent>
      <DialogActions sx={{ borderTop: "1px solid #1E2D55", p: 2 }}>
        <Button onClick={onClose} sx={{ color: "#8384A5" }}>Cancel</Button>
        <Button variant="contained" onClick={submit} disabled={saving || overdrawn}
          sx={{ bgcolor: accent, "&:hover": { bgcolor: accent, filter: "brightness(1.1)" } }}>
          {saving ? <CircularProgress size={20} /> : isDeposit ? "Deposit" : "Withdraw"}
        </Button>
      </DialogActions>
    </Dialog>
  );
};
