import React, { useCallback, useEffect, useState } from "react";
import {
  Alert, Box, Button, CircularProgress, Dialog, DialogActions, DialogContent,
  DialogTitle, InputAdornment, Pagination, Snackbar, TextField, Typography,
} from "@mui/material";
import { PersonAdd, Refresh, Search, ContentCopy } from "@mui/icons-material";
import * as api from "../../services/demoPortalApi";
import type { DemoAgent, DemoUser } from "../../services/demoPortalApi";
import DemoUsersTable from "./DemoUsersTable";
import {
  FundsDialog, StatCard, cardSx, dialogPaper, errMsg, fmt, inputSx,
} from "./shared";

const LIMIT = 25;

type Created = { id: string; username: string; password: string; balance: number; casino_limit: number | null };

/** Quick-create form: username/password optional (auto-generated when blank). */
const CreateDemoUser: React.FC<{
  myBalance: number;
  onCreated: (u: Created) => void;
  snack: (m: string, s?: "success" | "error") => void;
}> = ({ myBalance, onCreated, snack }) => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [fund, setFund] = useState("");
  const [limit, setLimit] = useState("");
  const [saving, setSaving] = useState(false);
  const fundNum = Number(fund) || 0;
  const overdrawn = fundNum > myBalance;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (overdrawn) return snack("Fund is more than your balance", "error");
    setSaving(true);
    try {
      const res = await api.createDemoUser({
        username: username.trim() || undefined,
        password: password || undefined,
        fund: fundNum,
        casinoLimit: Number(limit) || 0,
      });
      onCreated(res.user);
      setUsername(""); setPassword(""); setFund(""); setLimit("");
    } catch (err) {
      snack(errMsg(err), "error");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Box component="form" onSubmit={submit} sx={cardSx}>
      <Typography sx={{ color: "#F9F9F9", fontWeight: 700, mb: 0.5 }}>Quick Demo Account</Typography>
      <Typography sx={{ color: "#8384A5", fontSize: 12, mb: 2 }}>
        Leave username / password blank to auto-generate. The fund is taken from your balance.
      </Typography>
      <Box sx={{ display: "grid", gap: 2, gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr", lg: "repeat(4, 1fr) auto" } }}>
        <TextField size="small" label="Username (optional)" value={username}
          onChange={(e) => setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ""))}
          inputProps={{ maxLength: 20 }} sx={inputSx} />
        <TextField size="small" label="Password (optional)" value={password}
          onChange={(e) => setPassword(e.target.value)} sx={inputSx} />
        <TextField size="small" type="number" label="Fund" value={fund}
          onChange={(e) => setFund(e.target.value)} error={overdrawn}
          helperText={overdrawn ? `Max ${fmt(myBalance)}` : undefined}
          InputProps={{ startAdornment: <InputAdornment position="start">₹</InputAdornment> }} sx={inputSx} />
        <TextField size="small" type="number" label="Live casino limit (max bet)" value={limit}
          onChange={(e) => setLimit(e.target.value)} helperText="0 / blank = no limit"
          InputProps={{ startAdornment: <InputAdornment position="start">₹</InputAdornment> }} sx={inputSx} />
        <Button type="submit" variant="contained" disabled={saving || overdrawn}
          startIcon={saving ? <CircularProgress size={16} /> : <PersonAdd />}
          sx={{ height: 40, whiteSpace: "nowrap" }}>
          Create ID
        </Button>
      </Box>
    </Box>
  );
};

const CredentialsDialog: React.FC<{ user: Created | null; onClose: () => void; onCopy: (t: string) => void }> = ({ user, onClose, onCopy }) => {
  if (!user) return null;
  const text = `Site: https://example.com\nUsername: ${user.username}\nPassword: ${user.password}`;
  return (
    <Dialog open onClose={onClose} maxWidth="xs" fullWidth PaperProps={dialogPaper}>
      <DialogTitle sx={{ color: "#0ECC68", borderBottom: "1px solid #1E2D55" }}>Demo account created</DialogTitle>
      <DialogContent sx={{ pt: "20px !important" }}>
        <Box sx={{ bgcolor: "#10182E", border: "1px solid #1E2D55", borderRadius: 1.5, p: 2, fontFamily: "monospace", color: "#F9F9F9", fontSize: 14, lineHeight: 1.9 }}>
          <div>User ID: {user.id}</div>
          <div>Username: <b>{user.username}</b></div>
          <div>Password: <b>{user.password}</b></div>
          <div>Balance: {fmt(user.balance)}</div>
          <div>Live casino limit: {user.casino_limit ? `${fmt(user.casino_limit)} / bet` : "No limit"}</div>
        </Box>
        <Typography sx={{ color: "#8384A5", fontSize: 12, mt: 1.5 }}>
          This account can log in on the site and play. It has no deposit or withdraw option.
        </Typography>
      </DialogContent>
      <DialogActions sx={{ borderTop: "1px solid #1E2D55", p: 2 }}>
        <Button startIcon={<ContentCopy />} onClick={() => onCopy(text)}>Copy login</Button>
        <Button variant="contained" onClick={onClose}>Done</Button>
      </DialogActions>
    </Dialog>
  );
};

const LimitDialog: React.FC<{
  user: DemoUser | null; onClose: () => void; onDone: () => void;
  snack: (m: string, s?: "success" | "error") => void;
}> = ({ user, onClose, onDone, snack }) => {
  const [limit, setLimit] = useState("");
  const [saving, setSaving] = useState(false);
  useEffect(() => { setLimit(user?.casino_limit ? String(user.casino_limit) : ""); }, [user]);
  if (!user) return null;
  const save = async () => {
    setSaving(true);
    try {
      await api.updateDemoUser(user.id, { casinoLimit: Number(limit) || 0 });
      snack("Live casino limit updated");
      onDone(); onClose();
    } catch (e) {
      snack(errMsg(e), "error");
    } finally {
      setSaving(false);
    }
  };
  return (
    <Dialog open onClose={onClose} maxWidth="xs" fullWidth PaperProps={dialogPaper}>
      <DialogTitle sx={{ color: "#F9F9F9", borderBottom: "1px solid #1E2D55" }}>Live casino limit — {user.username}</DialogTitle>
      <DialogContent sx={{ pt: "20px !important" }}>
        <TextField fullWidth autoFocus type="number" label="Max single bet" value={limit}
          onChange={(e) => setLimit(e.target.value)} helperText="Applies to slot / live casino games. 0 or blank = no limit"
          InputProps={{ startAdornment: <InputAdornment position="start">₹</InputAdornment> }} sx={inputSx} />
      </DialogContent>
      <DialogActions sx={{ borderTop: "1px solid #1E2D55", p: 2 }}>
        <Button onClick={onClose} sx={{ color: "#8384A5" }}>Cancel</Button>
        <Button variant="contained" onClick={save} disabled={saving}>{saving ? <CircularProgress size={20} /> : "Save"}</Button>
      </DialogActions>
    </Dialog>
  );
};

const DemoAgentPortal: React.FC = () => {
  const [me, setMe] = useState<DemoAgent | null>(null);
  const [users, setUsers] = useState<DemoUser[]>([]);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [created, setCreated] = useState<Created | null>(null);
  const [funds, setFunds] = useState<{ user: DemoUser; mode: "deposit" | "withdraw" } | null>(null);
  const [limitUser, setLimitUser] = useState<DemoUser | null>(null);
  const [snack, setSnack] = useState<{ msg: string; severity: "success" | "error" } | null>(null);
  const notify = (msg: string, severity: "success" | "error" = "success") => setSnack({ msg, severity });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [m, list] = await Promise.all([
        api.getMe(),
        api.listMyUsers({ search: query, page, limit: LIMIT }),
      ]);
      setMe(m.agent);
      setUsers(list.users);
      setTotal(list.total);
      setTotalPages(list.totalPages);
    } catch (e) {
      notify(errMsg(e), "error");
    } finally {
      setLoading(false);
    }
  }, [query, page]);

  useEffect(() => { load(); }, [load]);

  // Debounce the search box.
  useEffect(() => {
    const t = setTimeout(() => { setPage(1); setQuery(search.trim()); }, 400);
    return () => clearTimeout(t);
  }, [search]);

  const copy = (text: string) => {
    navigator.clipboard?.writeText(text).then(() => notify("Copied"), () => notify("Copy failed", "error"));
  };

  const toggleLock = async (u: DemoUser) => {
    try {
      await api.updateDemoUser(u.id, { locked: !u.locked });
      notify(u.locked ? `Betting allowed for ${u.username}` : `Betting blocked for ${u.username}`);
      load();
    } catch (e) {
      notify(errMsg(e), "error");
    }
  };

  const myBalance = Number(me?.balance || 0);

  return (
    <Box sx={{ p: { xs: 2, md: 3 }, display: "flex", flexDirection: "column", gap: 2.5 }}>
      <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 2, flexWrap: "wrap" }}>
        <Box>
          <Typography variant="h5" sx={{ color: "#F9F9F9", fontWeight: 700 }}>Demo Portal</Typography>
          <Typography sx={{ color: "#8384A5", fontSize: 13 }}>Create demo IDs with a fund and a live casino limit</Typography>
        </Box>
        <Button startIcon={<Refresh />} onClick={load} disabled={loading} sx={{ color: "#8384A5" }}>Refresh</Button>
      </Box>

      <Box sx={{ display: "flex", gap: 2, flexWrap: "wrap" }}>
        <StatCard label="My Balance" value={fmt(myBalance)} accent="#0ECC68" />
        <StatCard label="Demo Accounts" value={me?.demo_users ?? "—"} />
        <StatCard label="Balance in Demo Accounts" value={fmt(me?.demo_users_balance)} />
      </Box>

      <CreateDemoUser myBalance={myBalance} snack={notify}
        onCreated={(u) => { setCreated(u); load(); }} />

      <Box sx={cardSx}>
        <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 2, flexWrap: "wrap", mb: 2 }}>
          <Typography sx={{ color: "#F9F9F9", fontWeight: 700 }}>My Demo Accounts ({total})</Typography>
          <TextField size="small" placeholder="Search username or ID" value={search}
            onChange={(e) => setSearch(e.target.value)}
            InputProps={{ startAdornment: <InputAdornment position="start"><Search sx={{ color: "#8384A5" }} fontSize="small" /></InputAdornment> }}
            sx={{ ...inputSx, width: { xs: "100%", sm: 260 } }} />
        </Box>
        <DemoUsersTable users={users} loading={loading} onCopy={copy}
          actions={{
            onDeposit: (u) => setFunds({ user: u, mode: "deposit" }),
            onWithdraw: (u) => setFunds({ user: u, mode: "withdraw" }),
            onEditLimit: setLimitUser,
            onToggleLock: toggleLock,
          }} />
        {totalPages > 1 && (
          <Box sx={{ display: "flex", justifyContent: "center", mt: 2 }}>
            <Pagination count={totalPages} page={page} onChange={(_, p) => setPage(p)} color="primary" />
          </Box>
        )}
      </Box>

      <CredentialsDialog user={created} onClose={() => setCreated(null)} onCopy={copy} />
      <LimitDialog user={limitUser} onClose={() => setLimitUser(null)} onDone={load} snack={notify} />
      {funds && (
        <FundsDialog
          target={{ id: funds.user.id, name: funds.user.username, balance: Number(funds.user.balance), type: "USER" }}
          mode={funds.mode} myBalance={myBalance}
          onClose={() => setFunds(null)} onDone={load} snack={notify} />
      )}

      <Snackbar open={!!snack} autoHideDuration={4000} onClose={() => setSnack(null)}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}>
        {snack ? <Alert severity={snack.severity} variant="filled" onClose={() => setSnack(null)}>{snack.msg}</Alert> : undefined}
      </Snackbar>
    </Box>
  );
};

export default DemoAgentPortal;
