import React, { useCallback, useEffect, useState } from "react";
import {
  Alert, Box, Button, Chip, CircularProgress, Dialog, DialogActions, DialogContent,
  DialogTitle, IconButton, InputAdornment, Pagination, Snackbar, Table, TableBody,
  TableCell, TableContainer, TableHead, TableRow, TextField, Tooltip, Typography,
} from "@mui/material";
import {
  Add, AddCircle, RemoveCircle, Lock, LockOpen, Key, Groups, Refresh, Search,
} from "@mui/icons-material";
import * as api from "../../services/demoPortalApi";
import type { DemoAgent, DemoUser } from "../../services/demoPortalApi";
import DemoUsersTable from "./DemoUsersTable";
import {
  FundsDialog, StatCard, cardSx, cellSx, dialogPaper, errMsg, fmt, fmtDate, headCellSx, inputSx,
} from "./shared";

type Notify = (msg: string, severity?: "success" | "error") => void;

const CreateAgentDialog: React.FC<{ open: boolean; onClose: () => void; onDone: () => void; notify: Notify }> = ({ open, onClose, onDone, notify }) => {
  const [form, setForm] = useState({ name: "", email: "", password: "", txn: "" });
  const [saving, setSaving] = useState(false);
  useEffect(() => { if (open) setForm({ name: "", email: "", password: "", txn: "" }); }, [open]);
  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async () => {
    setSaving(true);
    try {
      await api.createAgent({ name: form.name.trim(), email: form.email.trim(), password: form.password, transactionPassword: form.txn });
      notify(`Demo portal agent ${form.name} created`);
      onDone(); onClose();
    } catch (e) {
      notify(errMsg(e), "error");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="xs" fullWidth PaperProps={dialogPaper}>
      <DialogTitle sx={{ color: "#F9F9F9", borderBottom: "1px solid #1E2D55" }}>New Demo Portal Agent</DialogTitle>
      <DialogContent sx={{ pt: "20px !important", display: "flex", flexDirection: "column", gap: 2 }}>
        <TextField label="Name" value={form.name} onChange={set("name")} sx={inputSx} autoFocus />
        <TextField label="Login email" type="email" value={form.email} onChange={set("email")} sx={inputSx}
          helperText="The agent logs in to this admin panel with this email" />
        <TextField label="Password" value={form.password} onChange={set("password")} sx={inputSx}
          helperText="Min 6 characters. The agent must change it on first login." />
        <TextField label="Your Transaction Password" type="password" value={form.txn} onChange={set("txn")} sx={inputSx} />
      </DialogContent>
      <DialogActions sx={{ borderTop: "1px solid #1E2D55", p: 2 }}>
        <Button onClick={onClose} sx={{ color: "#8384A5" }}>Cancel</Button>
        <Button variant="contained" onClick={submit}
          disabled={saving || !form.name.trim() || !form.email.trim() || form.password.length < 6 || !form.txn}>
          {saving ? <CircularProgress size={20} /> : "Create"}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

/** Lock/unlock and reset-password both just need the owner's transaction password (+ new password). */
const AgentActionDialog: React.FC<{
  action: { agent: DemoAgent; kind: "lock" | "password" } | null;
  onClose: () => void; onDone: () => void; notify: Notify;
}> = ({ action, onClose, onDone, notify }) => {
  const [password, setPassword] = useState("");
  const [txn, setTxn] = useState("");
  const [saving, setSaving] = useState(false);
  useEffect(() => { setPassword(""); setTxn(""); }, [action]);
  if (!action) return null;
  const { agent, kind } = action;
  const title = kind === "password" ? `Reset password — ${agent.name}` : `${agent.locked ? "Unlock" : "Lock"} — ${agent.name}`;

  const submit = async () => {
    setSaving(true);
    try {
      if (kind === "password") {
        await api.resetAgentPassword(agent.id, password, txn);
        notify("Password updated");
      } else {
        await api.setAgentLock(agent.id, !agent.locked, txn);
        notify(agent.locked ? `${agent.name} unlocked` : `${agent.name} locked`);
      }
      onDone(); onClose();
    } catch (e) {
      notify(errMsg(e), "error");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open onClose={onClose} maxWidth="xs" fullWidth PaperProps={dialogPaper}>
      <DialogTitle sx={{ color: "#F9F9F9", borderBottom: "1px solid #1E2D55" }}>{title}</DialogTitle>
      <DialogContent sx={{ pt: "20px !important", display: "flex", flexDirection: "column", gap: 2 }}>
        {kind === "lock" && (
          <Typography sx={{ color: "#8384A5", fontSize: 13 }}>
            {agent.locked
              ? "The agent will be able to log in again."
              : "The agent will not be able to log in. Existing demo accounts keep working."}
          </Typography>
        )}
        {kind === "password" && (
          <TextField autoFocus label="New password" value={password} onChange={(e) => setPassword(e.target.value)} sx={inputSx} />
        )}
        <TextField label="Your Transaction Password" type="password" value={txn} onChange={(e) => setTxn(e.target.value)} sx={inputSx} />
      </DialogContent>
      <DialogActions sx={{ borderTop: "1px solid #1E2D55", p: 2 }}>
        <Button onClick={onClose} sx={{ color: "#8384A5" }}>Cancel</Button>
        <Button variant="contained" onClick={submit} disabled={saving || !txn || (kind === "password" && password.length < 6)}>
          {saving ? <CircularProgress size={20} /> : "Confirm"}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

const AgentUsersDialog: React.FC<{ agent: DemoAgent | null; onClose: () => void; notify: Notify }> = ({ agent, onClose, notify }) => {
  const [users, setUsers] = useState<DemoUser[]>([]);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(false);

  useEffect(() => { setPage(1); }, [agent]);
  useEffect(() => {
    if (!agent) return;
    setLoading(true);
    api.listAgentUsers(agent.id, { page, limit: 25 })
      .then((r) => { setUsers(r.users); setTotalPages(r.totalPages); })
      .catch((e) => notify(errMsg(e), "error"))
      .finally(() => setLoading(false));
  }, [agent, page, notify]);

  if (!agent) return null;
  return (
    <Dialog open onClose={onClose} maxWidth="lg" fullWidth PaperProps={dialogPaper}>
      <DialogTitle sx={{ color: "#F9F9F9", borderBottom: "1px solid #1E2D55" }}>
        Demo accounts — {agent.name}
      </DialogTitle>
      <DialogContent sx={{ pt: "16px !important" }}>
        {loading ? <Box sx={{ textAlign: "center", py: 4 }}><CircularProgress size={28} /></Box>
          : <DemoUsersTable users={users} />}
        {totalPages > 1 && (
          <Box sx={{ display: "flex", justifyContent: "center", mt: 2 }}>
            <Pagination count={totalPages} page={page} onChange={(_, p) => setPage(p)} color="primary" />
          </Box>
        )}
      </DialogContent>
      <DialogActions sx={{ borderTop: "1px solid #1E2D55", p: 2 }}>
        <Button onClick={onClose}>Close</Button>
      </DialogActions>
    </Dialog>
  );
};

const DemoAgentsAdmin: React.FC = () => {
  const [agents, setAgents] = useState<DemoAgent[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [query, setQuery] = useState("");
  const [createOpen, setCreateOpen] = useState(false);
  const [funds, setFunds] = useState<{ agent: DemoAgent; mode: "deposit" | "withdraw" } | null>(null);
  const [action, setAction] = useState<{ agent: DemoAgent; kind: "lock" | "password" } | null>(null);
  const [viewing, setViewing] = useState<DemoAgent | null>(null);
  const [snack, setSnack] = useState<{ msg: string; severity: "success" | "error" } | null>(null);
  const notify = useCallback<Notify>((msg, severity = "success") => setSnack({ msg, severity }), []);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      setAgents((await api.listAgents(query)).agents);
    } catch (e) {
      notify(errMsg(e), "error");
    } finally {
      setLoading(false);
    }
  }, [query, notify]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    const t = setTimeout(() => setQuery(search.trim()), 400);
    return () => clearTimeout(t);
  }, [search]);

  const totals = agents.reduce(
    (acc, a) => ({
      balance: acc.balance + Number(a.balance || 0),
      users: acc.users + Number(a.demo_users || 0),
      userBalance: acc.userBalance + Number(a.demo_users_balance || 0),
    }),
    { balance: 0, users: 0, userBalance: 0 }
  );

  return (
    <Box sx={{ p: { xs: 2, md: 3 }, display: "flex", flexDirection: "column", gap: 2.5 }}>
      <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 2, flexWrap: "wrap" }}>
        <Box>
          <Typography variant="h5" sx={{ color: "#F9F9F9", fontWeight: 700 }}>Demo Portal Agents</Typography>
          <Typography sx={{ color: "#8384A5", fontSize: 13 }}>
            Agents who can only create demo accounts. Demo accounts can play but cannot deposit or withdraw.
          </Typography>
        </Box>
        <Box sx={{ display: "flex", gap: 1 }}>
          <Button startIcon={<Refresh />} onClick={load} disabled={loading} sx={{ color: "#8384A5" }}>Refresh</Button>
          <Button variant="contained" startIcon={<Add />} onClick={() => setCreateOpen(true)}>New Agent</Button>
        </Box>
      </Box>

      <Box sx={{ display: "flex", gap: 2, flexWrap: "wrap" }}>
        <StatCard label="Agents" value={agents.length} />
        <StatCard label="Agents' Balance" value={fmt(totals.balance)} accent="#0ECC68" />
        <StatCard label="Demo Accounts" value={totals.users} />
        <StatCard label="Balance in Demo Accounts" value={fmt(totals.userBalance)} />
      </Box>

      <Box sx={cardSx}>
        <Box sx={{ display: "flex", justifyContent: "flex-end", mb: 2 }}>
          <TextField size="small" placeholder="Search name or email" value={search}
            onChange={(e) => setSearch(e.target.value)}
            InputProps={{ startAdornment: <InputAdornment position="start"><Search sx={{ color: "#8384A5" }} fontSize="small" /></InputAdornment> }}
            sx={{ ...inputSx, width: { xs: "100%", sm: 260 } }} />
        </Box>
        <TableContainer sx={{ overflowX: "auto" }}>
          <Table size="small">
            <TableHead>
              <TableRow>
                {["Agent", "Login Email", "Balance", "Demo Accounts", "Demo Balance", "Status", "Created"]
                  .map((h) => <TableCell key={h} sx={headCellSx}>{h}</TableCell>)}
                <TableCell sx={headCellSx} align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading && agents.length === 0 && (
                <TableRow><TableCell colSpan={8} sx={{ ...cellSx, textAlign: "center", py: 4 }}><CircularProgress size={24} /></TableCell></TableRow>
              )}
              {!loading && agents.length === 0 && (
                <TableRow><TableCell colSpan={8} sx={{ ...cellSx, textAlign: "center", color: "#8384A5", py: 4 }}>No demo portal agents yet</TableCell></TableRow>
              )}
              {agents.map((a) => (
                <TableRow key={a.id} hover>
                  <TableCell sx={{ ...cellSx, fontWeight: 600 }}>{a.name}</TableCell>
                  <TableCell sx={cellSx}>{a.email}</TableCell>
                  <TableCell sx={{ ...cellSx, fontWeight: 600 }}>{fmt(a.balance)}</TableCell>
                  <TableCell sx={cellSx}>{a.demo_users}</TableCell>
                  <TableCell sx={cellSx}>{fmt(a.demo_users_balance)}</TableCell>
                  <TableCell sx={cellSx}>
                    <Chip size="small" label={a.locked ? "Locked" : a.first_login ? "Pending first login" : "Active"}
                      sx={{
                        height: 20, fontSize: 11,
                        bgcolor: a.locked ? "rgba(224,27,79,0.12)" : a.first_login ? "rgba(255,194,63,0.12)" : "rgba(14,204,104,0.12)",
                        color: a.locked ? "#E01B4F" : a.first_login ? "#FFC23F" : "#0ECC68",
                      }} />
                  </TableCell>
                  <TableCell sx={{ ...cellSx, whiteSpace: "nowrap" }}>{fmtDate(a.created_at)}</TableCell>
                  <TableCell sx={{ ...cellSx, whiteSpace: "nowrap" }} align="right">
                    <Tooltip title="Deposit"><IconButton size="small" sx={{ color: "#0ECC68" }} onClick={() => setFunds({ agent: a, mode: "deposit" })}><AddCircle fontSize="small" /></IconButton></Tooltip>
                    <Tooltip title="Withdraw"><IconButton size="small" sx={{ color: "#E01B4F" }} onClick={() => setFunds({ agent: a, mode: "withdraw" })}><RemoveCircle fontSize="small" /></IconButton></Tooltip>
                    <Tooltip title="Demo accounts"><IconButton size="small" sx={{ color: "#5581F7" }} onClick={() => setViewing(a)}><Groups fontSize="small" /></IconButton></Tooltip>
                    <Tooltip title="Reset password"><IconButton size="small" sx={{ color: "#8384A5" }} onClick={() => setAction({ agent: a, kind: "password" })}><Key fontSize="small" /></IconButton></Tooltip>
                    <Tooltip title={a.locked ? "Unlock" : "Lock"}>
                      <IconButton size="small" sx={{ color: a.locked ? "#0ECC68" : "#FFC23F" }} onClick={() => setAction({ agent: a, kind: "lock" })}>
                        {a.locked ? <LockOpen fontSize="small" /> : <Lock fontSize="small" />}
                      </IconButton>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Box>

      <CreateAgentDialog open={createOpen} onClose={() => setCreateOpen(false)} onDone={load} notify={notify} />
      <AgentActionDialog action={action} onClose={() => setAction(null)} onDone={load} notify={notify} />
      <AgentUsersDialog agent={viewing} onClose={() => setViewing(null)} notify={notify} />
      {funds && (
        <FundsDialog
          target={{ id: funds.agent.id, name: funds.agent.name, balance: Number(funds.agent.balance), type: "STAFF" }}
          mode={funds.mode} myBalance={null}
          onClose={() => setFunds(null)} onDone={load} snack={notify} />
      )}

      <Snackbar open={!!snack} autoHideDuration={4000} onClose={() => setSnack(null)}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}>
        {snack ? <Alert severity={snack.severity} variant="filled" onClose={() => setSnack(null)}>{snack.msg}</Alert> : undefined}
      </Snackbar>
    </Box>
  );
};

export default DemoAgentsAdmin;
