import React, { useCallback, useEffect, useMemo, useState } from "react";
import {
  Box,
  Paper,
  Typography,
  Tabs,
  Tab,
  Button,
  Stack,
  IconButton,
  Tooltip,
  Avatar,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  CircularProgress,
  Snackbar,
  Alert,
  Pagination,
  InputAdornment,
  Checkbox,
} from "@mui/material";
import {
  Trophy,
  ArrowUp,
  ArrowDown,
  Image as ImageIcon,
  Save,
  RefreshCw,
  Pencil,
  Plus,
  Search,
  Trash2,
} from "lucide-react";
import { apiFetch } from "../utils/api";

type CategoryKey = "livecasino" | "popularslots" | "crashgames" | "hotgames" | "indiangames";

interface CategoryDef {
  key: CategoryKey;
  label: string;
  getPath: string;
  setPath: string;
}

const CATEGORIES: CategoryDef[] = [
  { key: "livecasino",   label: "Live Casino",    getPath: "/api/gis/livecasino",   setPath: "/api/gis/admin/gis/livecasino"   },
  { key: "popularslots", label: "Popular Slots",  getPath: "/api/gis/popularslots", setPath: "/api/gis/admin/gis/popularslots" },
  { key: "crashgames",   label: "Crash Games",    getPath: "/api/gis/crashgames",   setPath: "/api/gis/admin/gis/crashgames"   },
  { key: "hotgames",     label: "Hot Games",      getPath: "/api/gis/hotgames",     setPath: "/api/gis/admin/gis/hotgames"     },
  { key: "indiangames",  label: "Indian Games",   getPath: "/api/gis/indiangames",  setPath: "/api/gis/admin/gis/indiangames"  },
];

interface Game {
  uuid: string;
  name: string;
  provider?: string;
  image?: string;
  type?: string;
}

interface ListResponse {
  success: boolean;
  data: Game[];
  pagination: {
    currentPage: number;
    totalPages: number;
    totalItems: number;
    itemsPerPage: number;
  };
}

const PAGE_SIZE = 50;

const cardSx = { bgcolor: "#0E1831", border: "1px solid #1E2D55", borderRadius: 2 };

const inputSx = {
  "& .MuiOutlinedInput-root": {
    bgcolor: "#0B1427",
    "& fieldset": { borderColor: "#1E2D55" },
    "&:hover fieldset": { borderColor: "#2B6EF5" },
    "&.Mui-focused fieldset": { borderColor: "#2B6EF5" },
  },
  "& input": { color: "#F9F9F9" },
  "& label": { color: "#8384A5" },
};

const thSx = {
  bgcolor: "#0B1427",
  color: "#8384A5",
  fontWeight: 700,
  fontSize: "0.72rem",
  textTransform: "uppercase" as const,
  letterSpacing: "0.06em",
  borderBottom: "1px solid #1E2D55",
  whiteSpace: "nowrap" as const,
};

const tdSx = {
  color: "#C8CAE5",
  borderBottom: "1px solid #1E2D55",
  fontSize: "0.82rem",
  py: 1.25,
};

const ProvidersPriorityPage: React.FC = () => {
  const [tabIdx, setTabIdx] = useState(0);
  const [games, setGames] = useState<Game[]>([]);
  const [originalCSV, setOriginalCSV] = useState("");
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [page, setPage] = useState(1);

  const [editing, setEditing] = useState<Game | null>(null);
  const [editImage, setEditImage] = useState("");
  const [savingImage, setSavingImage] = useState(false);

  // ── picker state ──
  const [pickerOpen, setPickerOpen] = useState(false);
  const [pickerQ, setPickerQ] = useState("");
  const [pickerLoading, setPickerLoading] = useState(false);
  const [pickerResults, setPickerResults] = useState<Game[]>([]);
  const [pickerSelected, setPickerSelected] = useState<Set<string>>(new Set());

  const [toast, setToast] = useState<{ msg: string; sev: "success" | "error" } | null>(null);

  const active = CATEGORIES[tabIdx];

  const loadList = useCallback(async (cat: CategoryDef) => {
    setLoading(true);
    try {
      // Fetch full curated list — pagination is client-side so reorder/save
      // always operate on the entire list, not just the visible page.
      const res = await apiFetch<ListResponse>(
        `${cat.getPath}?page=1&limit=5000`
      );
      const list = res?.data ?? [];
      setGames(list);
      setOriginalCSV(list.map((g) => g.uuid).join(","));
    } catch (e: any) {
      setToast({ msg: e?.message || "Failed to load list", sev: "error" });
      setGames([]);
      setOriginalCSV("");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadList(active);
    setPage(1);
  }, [active, loadList]);

  const dirty = useMemo(
    () => games.map((g) => g.uuid).join(",") !== originalCSV,
    [games, originalCSV]
  );

  const move = (idx: number, dir: -1 | 1) => {
    setGames((prev) => {
      const next = [...prev];
      const j = idx + dir;
      if (j < 0 || j >= next.length) return prev;
      [next[idx], next[j]] = [next[j], next[idx]];
      return next;
    });
  };

  const moveTo = (idx: number, target: "top" | "bottom") => {
    setGames((prev) => {
      if (idx < 0 || idx >= prev.length) return prev;
      const next = [...prev];
      const [item] = next.splice(idx, 1);
      if (target === "top") next.unshift(item);
      else next.push(item);
      return next;
    });
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await apiFetch(active.setPath, {
        method: "POST",
        body: JSON.stringify({ uuids: games.map((g) => g.uuid) }),
      });
      setOriginalCSV(games.map((g) => g.uuid).join(","));
      setToast({ msg: "Priority saved", sev: "success" });
    } catch (e: any) {
      setToast({ msg: e?.message || "Save failed", sev: "error" });
    } finally {
      setSaving(false);
    }
  };

  const openEdit = (g: Game) => {
    setEditing(g);
    setEditImage(g.image || "");
  };

  const closeEdit = () => {
    if (savingImage) return;
    setEditing(null);
    setEditImage("");
  };

  const removeAt = (idx: number) => {
    setGames((prev) => prev.filter((_, i) => i !== idx));
  };

  // ── picker ──
  const openPicker = () => {
    setPickerOpen(true);
    setPickerQ("");
    setPickerResults([]);
    setPickerSelected(new Set());
  };

  const closePicker = () => {
    if (pickerLoading) return;
    setPickerOpen(false);
  };

  // debounced search
  useEffect(() => {
    if (!pickerOpen) return;
    const term = pickerQ.trim();
    if (!term) {
      setPickerResults([]);
      return;
    }
    let cancelled = false;
    setPickerLoading(true);
    const handle = setTimeout(async () => {
      try {
        const res = await apiFetch<{ data: Game[] }>(
          `/api/gis/admin/gis/games/search?q=${encodeURIComponent(term)}&limit=50`
        );
        if (!cancelled) setPickerResults(res?.data ?? []);
      } catch (e: any) {
        if (!cancelled) {
          setPickerResults([]);
          setToast({ msg: e?.message || "Search failed", sev: "error" });
        }
      } finally {
        if (!cancelled) setPickerLoading(false);
      }
    }, 300);
    return () => {
      cancelled = true;
      clearTimeout(handle);
    };
  }, [pickerQ, pickerOpen]);

  const togglePick = (uuid: string) => {
    setPickerSelected((prev) => {
      const next = new Set(prev);
      if (next.has(uuid)) next.delete(uuid);
      else next.add(uuid);
      return next;
    });
  };

  const addSelected = () => {
    if (pickerSelected.size === 0) return;
    const existing = new Set(games.map((g) => g.uuid));
    const toAdd = pickerResults.filter(
      (g) => pickerSelected.has(g.uuid) && !existing.has(g.uuid)
    );
    const skipped = pickerSelected.size - toAdd.length;
    if (toAdd.length === 0) {
      setToast({ msg: "All selected games are already in the list", sev: "error" });
      return;
    }
    setGames((prev) => [...prev, ...toAdd]);
    setPickerOpen(false);
    setToast({
      msg: skipped > 0
        ? `Added ${toAdd.length} (skipped ${skipped} duplicate${skipped === 1 ? "" : "s"}). Click Save Priority to persist.`
        : `Added ${toAdd.length} game${toAdd.length === 1 ? "" : "s"}. Click Save Priority to persist.`,
      sev: "success",
    });
  };

  const saveImage = async () => {
    if (!editing) return;
    if (!editImage.trim()) {
      setToast({ msg: "Image URL is required", sev: "error" });
      return;
    }
    setSavingImage(true);
    try {
      await apiFetch(`/api/gis/admin/gis/games/${encodeURIComponent(editing.uuid)}/image`, {
        method: "PUT",
        body: JSON.stringify({ image: editImage.trim() }),
      });
      setGames((prev) =>
        prev.map((g) => (g.uuid === editing.uuid ? { ...g, image: editImage.trim() } : g))
      );
      setToast({ msg: "Image updated in gisgamesnew", sev: "success" });
      setEditing(null);
      setEditImage("");
    } catch (e: any) {
      setToast({ msg: e?.message || "Update failed", sev: "error" });
    } finally {
      setSavingImage(false);
    }
  };

  const totalItems = games.length;
  const totalPages = Math.max(1, Math.ceil(totalItems / PAGE_SIZE));
  const baseRank = (page - 1) * PAGE_SIZE;
  const pagedGames = games.slice(baseRank, baseRank + PAGE_SIZE);

  // Clamp page when items shrink (e.g. after remove)
  useEffect(() => {
    if (page > totalPages) setPage(totalPages);
  }, [page, totalPages]);

  return (
    <Box sx={{ p: 3, maxWidth: 1400, mx: "auto" }}>
      {/* Header */}
      <Box sx={{ display: "flex", alignItems: "center", gap: 1.5, mb: 3 }}>
        <Box sx={{ p: 1, bgcolor: "rgba(43,110,245,0.15)", borderRadius: 2, display: "flex" }}>
          <Trophy size={22} color="#2B6EF5" />
        </Box>
        <Box>
          <Typography variant="h5" sx={{ color: "#F9F9F9", fontWeight: 700 }}>
            Providers Priority
          </Typography>
          <Typography variant="caption" sx={{ color: "#8384A5" }}>
            Order home-page game lists and edit thumbnails (writes to{" "}
            <Box component="span" sx={{ color: "#5581F7", fontFamily: "monospace" }}>
              gisgamesnew
            </Box>
            )
          </Typography>
        </Box>
      </Box>

      {/* Tabs */}
      <Paper sx={{ ...cardSx, mb: 2 }}>
        <Tabs
          value={tabIdx}
          onChange={(_, v) => setTabIdx(v)}
          variant="scrollable"
          scrollButtons="auto"
          sx={{
            px: 2,
            "& .MuiTab-root": {
              color: "#8384A5",
              textTransform: "none",
              fontWeight: 600,
              fontSize: "0.85rem",
              minHeight: 48,
            },
            "& .Mui-selected": { color: "#2B6EF5 !important" },
            "& .MuiTabs-indicator": { backgroundColor: "#2B6EF5" },
          }}
        >
          {CATEGORIES.map((c) => (
            <Tab key={c.key} label={c.label} />
          ))}
        </Tabs>
      </Paper>

      {/* Toolbar */}
      <Paper sx={{ ...cardSx, p: 2, mb: 2 }}>
        <Stack direction={{ xs: "column", sm: "row" }} spacing={1.5} alignItems={{ sm: "center" }}>
          <Typography sx={{ color: "#8384A5", fontSize: "0.85rem", flex: 1 }}>
            {totalItems} game{totalItems === 1 ? "" : "s"} in <b style={{ color: "#F9F9F9" }}>{active.label}</b>
            {dirty && (
              <Box component="span" sx={{ color: "#FFC23F", ml: 1, fontWeight: 600 }}>
                · unsaved order
              </Box>
            )}
          </Typography>
          <Button
            variant="outlined"
            size="small"
            startIcon={<Plus size={14} />}
            onClick={openPicker}
            disabled={loading}
            sx={{
              textTransform: "none",
              borderColor: "#0ECC68",
              color: "#0ECC68",
              "&:hover": { borderColor: "#0ECC68", bgcolor: "rgba(14,204,104,0.08)" },
            }}
          >
            Add Games
          </Button>
          <Button
            variant="outlined"
            size="small"
            startIcon={<RefreshCw size={14} />}
            onClick={() => loadList(active)}
            disabled={loading}
            sx={{
              textTransform: "none",
              borderColor: "#1E2D55",
              color: "#8384A5",
              "&:hover": { borderColor: "#2B6EF5", color: "#5581F7" },
            }}
          >
            Reload
          </Button>
          <Button
            variant="contained"
            size="small"
            startIcon={saving ? <CircularProgress size={14} sx={{ color: "#fff" }} /> : <Save size={14} />}
            onClick={handleSave}
            disabled={!dirty || saving || loading}
            sx={{
              textTransform: "none",
              bgcolor: "#2B6EF5",
              "&:hover": { bgcolor: "#4A85F7" },
              "&.Mui-disabled": { bgcolor: "#1E2D55", color: "#8384A5" },
            }}
          >
            Save Priority
          </Button>
        </Stack>
      </Paper>

      {/* Table */}
      <Paper sx={{ ...cardSx, overflow: "hidden" }}>
        <TableContainer sx={{ maxHeight: "65vh" }}>
          <Table size="small" stickyHeader>
            <TableHead>
              <TableRow>
                <TableCell sx={{ ...thSx, width: 70 }}>#</TableCell>
                <TableCell sx={thSx}>Game</TableCell>
                <TableCell sx={thSx}>Provider</TableCell>
                <TableCell sx={{ ...thSx, textAlign: "center", width: 220 }}>Priority</TableCell>
                <TableCell sx={{ ...thSx, textAlign: "center", width: 160 }}>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={5} sx={{ textAlign: "center", py: 6, borderBottom: "none" }}>
                    <CircularProgress size={26} sx={{ color: "#2B6EF5" }} />
                  </TableCell>
                </TableRow>
              ) : games.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} sx={{ textAlign: "center", py: 6, borderBottom: "none" }}>
                    <Trophy size={40} color="#1E2D55" />
                    <Typography sx={{ color: "#8384A5", mt: 1 }}>
                      No games configured for this list yet.
                    </Typography>
                  </TableCell>
                </TableRow>
              ) : (
                pagedGames.map((g, i) => {
                  const absIdx = baseRank + i;
                  return (
                  <TableRow
                    key={g.uuid}
                    sx={{
                      "&:hover": { bgcolor: "rgba(43,110,245,0.04)" },
                      transition: "background 150ms",
                    }}
                  >
                    <TableCell sx={{ ...tdSx, color: "#8384A5", fontFamily: "monospace" }}>
                      {absIdx + 1}
                    </TableCell>
                    <TableCell sx={tdSx}>
                      <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
                        <Avatar
                          src={g.image}
                          variant="rounded"
                          sx={{
                            width: 40,
                            height: 40,
                            bgcolor: "#0B1427",
                            border: "1px solid #1E2D55",
                            color: "#5581F7",
                          }}
                        >
                          {g.name?.charAt(0) || "?"}
                        </Avatar>
                        <Box sx={{ minWidth: 0 }}>
                          <Typography
                            sx={{
                              color: "#F9F9F9",
                              fontSize: "0.85rem",
                              fontWeight: 600,
                              whiteSpace: "nowrap",
                              overflow: "hidden",
                              textOverflow: "ellipsis",
                              maxWidth: 320,
                            }}
                            title={g.name}
                          >
                            {g.name}
                          </Typography>
                          <Typography
                            variant="caption"
                            sx={{ color: "#8384A5", fontFamily: "monospace" }}
                            title={g.uuid}
                          >
                            {g.uuid.slice(0, 8)}…
                          </Typography>
                        </Box>
                      </Box>
                    </TableCell>
                    <TableCell sx={{ ...tdSx, color: "#8384A5" }}>{g.provider || "—"}</TableCell>
                    <TableCell sx={{ ...tdSx, textAlign: "center" }}>
                      <Stack direction="row" spacing={0.5} justifyContent="center">
                        <Tooltip title="Move to top">
                          <span>
                            <Button
                              size="small"
                              disabled={absIdx === 0}
                              onClick={() => moveTo(absIdx, "top")}
                              sx={{
                                minWidth: 0,
                                px: 1,
                                color: "#8384A5",
                                fontSize: "0.7rem",
                                textTransform: "none",
                                "&:hover": { color: "#2B6EF5", bgcolor: "rgba(43,110,245,0.08)" },
                              }}
                            >
                              Top
                            </Button>
                          </span>
                        </Tooltip>
                        <Tooltip title="Move up">
                          <span>
                            <IconButton
                              size="small"
                              disabled={absIdx === 0}
                              onClick={() => move(absIdx, -1)}
                              sx={{
                                color: "#8384A5",
                                "&:hover": { color: "#2B6EF5", bgcolor: "rgba(43,110,245,0.08)" },
                              }}
                            >
                              <ArrowUp size={15} />
                            </IconButton>
                          </span>
                        </Tooltip>
                        <Tooltip title="Move down">
                          <span>
                            <IconButton
                              size="small"
                              disabled={absIdx === games.length - 1}
                              onClick={() => move(absIdx, 1)}
                              sx={{
                                color: "#8384A5",
                                "&:hover": { color: "#2B6EF5", bgcolor: "rgba(43,110,245,0.08)" },
                              }}
                            >
                              <ArrowDown size={15} />
                            </IconButton>
                          </span>
                        </Tooltip>
                        <Tooltip title="Move to bottom">
                          <span>
                            <Button
                              size="small"
                              disabled={absIdx === games.length - 1}
                              onClick={() => moveTo(absIdx, "bottom")}
                              sx={{
                                minWidth: 0,
                                px: 1,
                                color: "#8384A5",
                                fontSize: "0.7rem",
                                textTransform: "none",
                                "&:hover": { color: "#2B6EF5", bgcolor: "rgba(43,110,245,0.08)" },
                              }}
                            >
                              Bottom
                            </Button>
                          </span>
                        </Tooltip>
                      </Stack>
                    </TableCell>
                    <TableCell sx={{ ...tdSx, textAlign: "center" }}>
                      <Stack direction="row" spacing={0.5} justifyContent="center">
                        <Tooltip title="Edit image URL">
                          <IconButton
                            size="small"
                            onClick={() => openEdit(g)}
                            sx={{
                              color: "#5581F7",
                              border: "1px solid #1E2D55",
                              "&:hover": { borderColor: "#2B6EF5", bgcolor: "rgba(43,110,245,0.08)" },
                            }}
                          >
                            <Pencil size={14} />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Remove from list">
                          <IconButton
                            size="small"
                            onClick={() => removeAt(absIdx)}
                            sx={{
                              color: "#E01B4F",
                              border: "1px solid #1E2D55",
                              "&:hover": { borderColor: "#E01B4F", bgcolor: "rgba(224,27,79,0.08)" },
                            }}
                          >
                            <Trash2 size={14} />
                          </IconButton>
                        </Tooltip>
                      </Stack>
                    </TableCell>
                  </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </TableContainer>
        {totalItems > PAGE_SIZE && (
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              flexWrap: "wrap",
              gap: 1,
              py: 1.5,
              px: 2,
              borderTop: "1px solid #1E2D55",
            }}
          >
            <Typography sx={{ color: "#8384A5", fontSize: "0.78rem" }}>
              Showing <b style={{ color: "#F9F9F9" }}>{baseRank + 1}</b>–
              <b style={{ color: "#F9F9F9" }}>{Math.min(baseRank + PAGE_SIZE, totalItems)}</b>{" "}
              of <b style={{ color: "#F9F9F9" }}>{totalItems}</b>
            </Typography>
            <Pagination
              count={totalPages}
              page={page}
              onChange={(_, v) => setPage(v)}
              size="small"
              showFirstButton
              showLastButton
              siblingCount={1}
              sx={{
                "& .MuiPaginationItem-root": {
                  color: "#8384A5",
                  borderColor: "#1E2D55",
                },
                "& .MuiPaginationItem-root:hover": {
                  bgcolor: "rgba(43,110,245,0.08)",
                  color: "#5581F7",
                },
                "& .Mui-selected": {
                  bgcolor: "rgba(43,110,245,0.18) !important",
                  color: "#5581F7 !important",
                  borderColor: "#2B6EF5 !important",
                },
              }}
            />
          </Box>
        )}
      </Paper>

      {/* Add-games picker dialog */}
      <Dialog
        open={pickerOpen}
        onClose={closePicker}
        maxWidth="md"
        fullWidth
        PaperProps={{ sx: { ...cardSx, bgcolor: "#0E1831" } }}
      >
        <DialogTitle sx={{ color: "#F9F9F9", borderBottom: "1px solid #1E2D55", display: "flex", alignItems: "center", gap: 1 }}>
          <Plus size={18} color="#0ECC68" /> Add Games to {active.label}
        </DialogTitle>
        <DialogContent sx={{ pt: 3 }}>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField
              autoFocus
              size="small"
              fullWidth
              value={pickerQ}
              onChange={(e) => setPickerQ(e.target.value)}
              placeholder="Search by name or uuid…"
              sx={inputSx}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <Search size={15} color="#8384A5" />
                  </InputAdornment>
                ),
                endAdornment: pickerLoading ? (
                  <InputAdornment position="end">
                    <CircularProgress size={14} sx={{ color: "#5581F7" }} />
                  </InputAdornment>
                ) : null,
              }}
            />
            <Box
              sx={{
                border: "1px solid #1E2D55",
                borderRadius: 1.5,
                bgcolor: "#0B1427",
                maxHeight: 420,
                overflowY: "auto",
              }}
            >
              {!pickerQ.trim() ? (
                <Box sx={{ textAlign: "center", py: 6, color: "#8384A5", fontSize: "0.85rem" }}>
                  Type a game name or uuid to search.
                </Box>
              ) : pickerLoading ? (
                <Box sx={{ textAlign: "center", py: 6 }}>
                  <CircularProgress size={22} sx={{ color: "#2B6EF5" }} />
                </Box>
              ) : pickerResults.length === 0 ? (
                <Box sx={{ textAlign: "center", py: 6, color: "#8384A5", fontSize: "0.85rem" }}>
                  No matches.
                </Box>
              ) : (
                <Table size="small">
                  <TableBody>
                    {pickerResults.map((g) => {
                      const checked = pickerSelected.has(g.uuid);
                      const alreadyIn = games.some((x) => x.uuid === g.uuid);
                      return (
                        <TableRow
                          key={g.uuid}
                          hover
                          onClick={() => !alreadyIn && togglePick(g.uuid)}
                          sx={{
                            cursor: alreadyIn ? "not-allowed" : "pointer",
                            opacity: alreadyIn ? 0.5 : 1,
                            "&:hover": {
                              bgcolor: alreadyIn ? "transparent" : "rgba(43,110,245,0.06)",
                            },
                          }}
                        >
                          <TableCell sx={{ ...tdSx, width: 50, py: 1 }}>
                            <Checkbox
                              size="small"
                              checked={checked && !alreadyIn}
                              disabled={alreadyIn}
                              onChange={() => togglePick(g.uuid)}
                              onClick={(e) => e.stopPropagation()}
                              sx={{
                                color: "#1E2D55",
                                "&.Mui-checked": { color: "#2B6EF5" },
                              }}
                            />
                          </TableCell>
                          <TableCell sx={{ ...tdSx, py: 1 }}>
                            <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
                              <Avatar
                                src={g.image}
                                variant="rounded"
                                sx={{
                                  width: 36,
                                  height: 36,
                                  bgcolor: "#0E1831",
                                  border: "1px solid #1E2D55",
                                  color: "#5581F7",
                                  fontSize: "0.8rem",
                                }}
                              >
                                {g.name?.charAt(0) || "?"}
                              </Avatar>
                              <Box sx={{ minWidth: 0 }}>
                                <Typography
                                  sx={{
                                    color: "#F9F9F9",
                                    fontSize: "0.85rem",
                                    fontWeight: 600,
                                    whiteSpace: "nowrap",
                                    overflow: "hidden",
                                    textOverflow: "ellipsis",
                                    maxWidth: 360,
                                  }}
                                  title={g.name}
                                >
                                  {g.name}
                                  {alreadyIn && (
                                    <Box component="span" sx={{ ml: 1, color: "#FFC23F", fontSize: "0.7rem", fontWeight: 700 }}>
                                      · already in list
                                    </Box>
                                  )}
                                </Typography>
                                <Typography
                                  variant="caption"
                                  sx={{ color: "#8384A5", fontFamily: "monospace" }}
                                  title={g.uuid}
                                >
                                  {g.uuid}
                                </Typography>
                              </Box>
                            </Box>
                          </TableCell>
                          <TableCell sx={{ ...tdSx, color: "#8384A5", textAlign: "right", py: 1 }}>
                            {g.provider || "—"}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              )}
            </Box>
          </Stack>
        </DialogContent>
        <DialogActions sx={{ borderTop: "1px solid #1E2D55", px: 3, py: 2, justifyContent: "space-between" }}>
          <Typography sx={{ color: "#8384A5", fontSize: "0.8rem" }}>
            {pickerSelected.size} selected
          </Typography>
          <Stack direction="row" spacing={1}>
            <Button onClick={closePicker} sx={{ textTransform: "none", color: "#8384A5" }}>
              Cancel
            </Button>
            <Button
              variant="contained"
              onClick={addSelected}
              disabled={pickerSelected.size === 0}
              startIcon={<Plus size={14} />}
              sx={{
                textTransform: "none",
                bgcolor: "#0ECC68",
                "&:hover": { bgcolor: "#0BAA56" },
                "&.Mui-disabled": { bgcolor: "#1E2D55", color: "#8384A5" },
              }}
            >
              Add Selected
            </Button>
          </Stack>
        </DialogActions>
      </Dialog>

      {/* Edit-image dialog */}
      <Dialog
        open={!!editing}
        onClose={closeEdit}
        maxWidth="sm"
        fullWidth
        PaperProps={{ sx: { ...cardSx, bgcolor: "#0E1831" } }}
      >
        <DialogTitle sx={{ color: "#F9F9F9", borderBottom: "1px solid #1E2D55", display: "flex", alignItems: "center", gap: 1 }}>
          <ImageIcon size={18} color="#2B6EF5" /> Edit Game Image
        </DialogTitle>
        <DialogContent sx={{ pt: 3 }}>
          {editing && (
            <Stack spacing={2} sx={{ mt: 1 }}>
              <Stack direction="row" spacing={2} alignItems="center">
                <Avatar
                  src={editImage || editing.image}
                  variant="rounded"
                  sx={{
                    width: 80,
                    height: 80,
                    bgcolor: "#0B1427",
                    border: "1px solid #1E2D55",
                    color: "#5581F7",
                  }}
                >
                  {editing.name?.charAt(0) || "?"}
                </Avatar>
                <Box sx={{ minWidth: 0 }}>
                  <Typography sx={{ color: "#F9F9F9", fontWeight: 600 }}>
                    {editing.name}
                  </Typography>
                  <Typography variant="caption" sx={{ color: "#8384A5", fontFamily: "monospace", wordBreak: "break-all" }}>
                    {editing.uuid}
                  </Typography>
                </Box>
              </Stack>
              <TextField
                label="Image URL"
                value={editImage}
                onChange={(e) => setEditImage(e.target.value)}
                fullWidth
                size="small"
                sx={inputSx}
                placeholder="https://…"
                helperText="Updates gisgamesnew.image for this uuid"
                FormHelperTextProps={{ sx: { color: "#8384A5" } }}
              />
            </Stack>
          )}
        </DialogContent>
        <DialogActions sx={{ borderTop: "1px solid #1E2D55", px: 3, py: 2 }}>
          <Button
            onClick={closeEdit}
            disabled={savingImage}
            sx={{ textTransform: "none", color: "#8384A5" }}
          >
            Cancel
          </Button>
          <Button
            variant="contained"
            onClick={saveImage}
            disabled={savingImage}
            startIcon={savingImage ? <CircularProgress size={14} sx={{ color: "#fff" }} /> : <Save size={14} />}
            sx={{
              textTransform: "none",
              bgcolor: "#2B6EF5",
              "&:hover": { bgcolor: "#4A85F7" },
            }}
          >
            Save
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar
        open={!!toast}
        autoHideDuration={3500}
        onClose={() => setToast(null)}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        {toast ? (
          <Alert
            severity={toast.sev}
            onClose={() => setToast(null)}
            variant="filled"
            sx={{ fontWeight: 600 }}
          >
            {toast.msg}
          </Alert>
        ) : undefined}
      </Snackbar>
    </Box>
  );
};

export default ProvidersPriorityPage;
