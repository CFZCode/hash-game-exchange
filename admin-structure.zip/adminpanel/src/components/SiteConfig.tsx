import { useEffect, useState } from "react";
import {
  Box,
  Paper,
  Typography,
  Button,
  TextField,
  Stack,
  Chip,
  InputAdornment,
  IconButton,
  Skeleton,
  Alert,
  Snackbar,
  CircularProgress,
  Tooltip,
} from "@mui/material";
import {
  Settings,
  Save,
  Lock,
  Eye,
  EyeOff,
  XCircle,
  RefreshCw,
  Search,
} from "lucide-react";
import { apiFetch } from "../utils/api";
import { BOOLEAN_KEYS } from "../constants/booleanKeys";
import { usePermissions } from "../hooks/usePermissions";
import DarkSwitch from "./DarkSwitch";
import SportsBetLimitsCard from "./SportsBetLimitsCard";

type BoolKey = typeof BOOLEAN_KEYS[number];
type Config = Record<string, any>;
type Draft = Partial<Record<BoolKey, boolean>> & {
  sports_match_odds_limit_enabled?: boolean;
  sports_match_max_odds?: string;
};

type Provider = { id: number; name: string; enabled: boolean; created_at?: string };

type SportItem = { id: number; game_id: number; game_name: string; enabled: boolean };

/* Grouped toggles — keys must exist as columns in siteconfig.
 * Mirrors what's actually rendered in myapp sidebar + home page. */
const GROUPED_KEYS: Record<string, string[]> = {
  "Site Features (sidebar)": [
    "casino", "wheelspin", "welcomepack", "provablyfair", "vipclub",
    "bonus", "affiliate", "giftcards",
  ],
  "Sports Module": [
    "sports", "home_livesports",
  ],
  "Home Page Sections": [
    "home_heroSection",
    "home_welcomebanner",
    "home_latestwins",
    "home_livecasino",
    "home_gamingcards",
    "home_popularslots",
    "home_bonus500banner",
    "home_crashgames",
    "home_paymentbanner",
    "home_leaderboard",
    "home_promocards",
  ],
};

const cardSx = { bgcolor: "#0E1831", border: "1px solid #1E2D55", borderRadius: 2 };

const LABEL_OVERRIDES: Record<string, string> = {
  welcomepack: "Welcome Pack",
  wheelspin: "Wheel Spin",
  provablyfair: "Provably Fair",
  vipclub: "VIP Club",
  giftcards: "Gift Cards",
  sports: "Sports / Exchange",
  home_heroSection: "Hero Section",
  home_welcomebanner: "Welcome Banner",
  home_latestwins: "Latest Wins",
  home_paymentbanner: "Payment Banner",
  home_livecasino: "Live Casino",
  home_livesports: "Live Sports Section",
  home_popularslots: "Popular Slots",
  home_crashgames: "Crash Games",
  home_leaderboard: "Leaderboard",
  home_gamingcards: "Gaming Cards (BC Originals)",
  home_bonus500banner: "Bonus 500 Banner",
  home_promocards: "Sidebar Promo Cards",
};

const prettifyLabel = (s: string) => {
  if (LABEL_OVERRIDES[s]) return LABEL_OVERRIDES[s];
  return s
    .replace(/^home_/, "")
    .replace(/_/g, " ")
    .replace(/([A-Z])/g, " $1")
    .replace(/\b\w/g, (c) => c.toUpperCase())
    .trim();
};

const MAX_ODDS_FLOOR = 1;
const MAX_ODDS_CEIL = 1000;

export default function SiteConfig() {
  const { role, can } = usePermissions();
  /* Mirrors the server gate in adminConfigController.checkSportsLimitFields. */
  const canEditBetLimits =
    role === "SuperAdmin" || (role === "Executive" && can("canEditSportsBetLimits"));

  const [cfg, setCfg] = useState<Config | null>(null);
  const [draft, setDraft] = useState<Draft>({});
  const [busy, setBusy] = useState(false);

  /* Providers */
  const [providers, setProviders] = useState<Provider[] | null>(null);
  const [providerDraft, setProviderDraft] = useState<Record<string, boolean>>({});
  const [providerSearch, setProviderSearch] = useState("");
  const [refreshing, setRefreshing] = useState(false);

  /* Per-sport toggles (lives in example.com/sports/sports) */
  const [sports, setSports] = useState<SportItem[] | null>(null);
  const [sportTogglingId, setSportTogglingId] = useState<number | null>(null);

  /* Transaction password — verified server-side on every save */
  const [txnPwd, setTxnPwd] = useState("");
  const [showPwd, setShowPwd] = useState(false);

  /* Snackbar */
  const [snack, setSnack] = useState<{ open: boolean; msg: string; sev: "success" | "error" }>({
    open: false,
    msg: "",
    sev: "success",
  });

  const notify = (msg: string, sev: "success" | "error" = "success") =>
    setSnack({ open: true, msg, sev });

  useEffect(() => {
    apiFetch<Config>("/api/admin/config/global").then(setCfg).catch((e) =>
      notify(e?.message || "Failed to load config", "error")
    );
    loadProviders();
    loadSports();
  }, []);

  const loadSports = async () => {
    try {
      const res = await fetch("https://example.com/sports/sports");
      const data = await res.json();
      setSports(data?.data || []);
    } catch {
      setSports([]);
    }
  };

  const toggleSport = async (s: SportItem) => {
    setSportTogglingId(s.id);
    try {
      const res = await fetch(`https://example.com/sports/sports/${s.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ enabled: !s.enabled }),
      });
      const data = await res.json();
      if (data?.success) {
        setSports((prev) =>
          (prev || []).map((it) => (it.id === s.id ? { ...it, enabled: !s.enabled } : it))
        );
        notify(`${s.game_name} ${!s.enabled ? "enabled" : "disabled"}.`);
      } else {
        notify(`Failed to toggle ${s.game_name}.`, "error");
      }
    } catch (e: any) {
      notify(e?.message || "Failed to toggle sport.", "error");
    } finally {
      setSportTogglingId(null);
    }
  };

  const loadProviders = async () => {
    try {
      const res = await apiFetch<{ data: Provider[] }>("/api/gis/admin/providers");
      setProviders(res.data || []);
      setProviderDraft({});
    } catch (e: any) {
      /* fall through to empty state so user can hit Refresh */
      setProviders([]);
      setProviderDraft({});
      notify(
        e?.message?.includes("enabled")
          ? "Run siteconfig/migration.js first — gis_providers_new.enabled column missing."
          : e?.message || "Failed to load providers",
        "error"
      );
    }
  };

  const refreshFromDb = async () => {
    setRefreshing(true);
    try {
      const res = await apiFetch<{ added: number; removed: number; providers_count: number }>(
        "/api/gis/sync/providersnew"
      );
      notify(
        `Refreshed: ${res.providers_count} providers (+${res.added} / -${res.removed})`,
        "success"
      );
      await loadProviders();
    } catch (e: any) {
      notify(e?.message || "Refresh failed", "error");
    } finally {
      setRefreshing(false);
    }
  };

  const toggleFeature = (k: BoolKey) => {
    if (!cfg) return;
    setCfg({ ...cfg, [k]: !cfg[k] });
    setDraft({ ...draft, [k]: !cfg[k] });
  };

  const toggleMatchOddsLimit = () => {
    if (!cfg || !canEditBetLimits) return;
    const next = !cfg.sports_match_odds_limit_enabled;
    setCfg({ ...cfg, sports_match_odds_limit_enabled: next });
    setDraft({ ...draft, sports_match_odds_limit_enabled: next });
  };

  const changeMatchMaxOdds = (value: string) => {
    if (!cfg || !canEditBetLimits) return;
    setCfg({ ...cfg, sports_match_max_odds: value });
    setDraft({ ...draft, sports_match_max_odds: value });
  };

  const toggleProvider = (name: string) => {
    if (!providers) return;
    const cur = providerDraft[name] !== undefined
      ? providerDraft[name]
      : providers.find((p) => p.name === name)?.enabled ?? true;
    setProviderDraft({ ...providerDraft, [name]: !cur });
    setProviders(providers.map((p) => (p.name === name ? { ...p, enabled: !cur } : p)));
  };

  const clearPassword = () => {
    setTxnPwd("");
    setShowPwd(false);
  };

  const save = async () => {
    if (!txnPwd) {
      notify("Enter your transaction password.", "error");
      return;
    }

    const hasFeatureChanges = Object.keys(draft).length > 0;
    const hasProviderChanges = Object.keys(providerDraft).length > 0;
    if (!hasFeatureChanges && !hasProviderChanges) return;

    setBusy(true);
    try {
      if (hasFeatureChanges) {
        const upd = await apiFetch<Config>("/api/admin/config/global", {
          method: "PUT",
          body: JSON.stringify({ ...draft, transactionPassword: txnPwd }),
        });
        setCfg(upd);
        setDraft({});
      }

      if (hasProviderChanges) {
        const updates = Object.entries(providerDraft).map(([name, enabled]) => ({ name, enabled }));
        const res = await apiFetch<{ data: Provider[] }>("/api/gis/admin/providers", {
          method: "PUT",
          body: JSON.stringify({ updates, transactionPassword: txnPwd }),
        });
        setProviders(res.data || []);
        setProviderDraft({});
      }

      notify("Configuration saved.");
      clearPassword();
    } catch (e: any) {
      notify(e?.message || "Failed to save configuration.", "error");
    } finally {
      setBusy(false);
    }
  };

  const featureDraftCount = Object.keys(draft).length;
  const providerDraftCount = Object.keys(providerDraft).length;
  const draftCount = featureDraftCount + providerDraftCount;
  const draftMaxOdds = draft.sports_match_max_odds;
  const maxOddsError =
    draftMaxOdds !== undefined &&
    !(Number(draftMaxOdds) > MAX_ODDS_FLOOR && Number(draftMaxOdds) <= MAX_ODDS_CEIL)
      ? "Enter odds between 1.01 and 1000"
      : null;
  const canSave = !!txnPwd && draftCount > 0 && !busy && !maxOddsError;

  const filteredProviders = (providers ?? []).filter((p) =>
    p.name.toLowerCase().includes(providerSearch.trim().toLowerCase())
  );

  if (!cfg) {
    return (
      <Box sx={{ p: 3, maxWidth: 1400, mx: "auto" }}>
        <Skeleton variant="rectangular" height={80} sx={{ bgcolor: "#162140", borderRadius: 2, mb: 3 }} />
        <Skeleton variant="rectangular" height={100} sx={{ bgcolor: "#162140", borderRadius: 2, mb: 2 }} />
        <Skeleton variant="rectangular" height={300} sx={{ bgcolor: "#162140", borderRadius: 2 }} />
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3, maxWidth: 1400, mx: "auto" }}>
      {/* Header */}
      <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mb: 3, flexWrap: "wrap", gap: 2 }}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
          <Box sx={{ p: 1, bgcolor: "rgba(43,110,245,0.15)", borderRadius: 2, display: "flex" }}>
            <Settings size={22} color="#2B6EF5" />
          </Box>
          <Box>
            <Typography variant="h5" sx={{ color: "#F9F9F9", fontWeight: 700 }}>
              Global Configuration
            </Typography>
            <Typography variant="caption" sx={{ color: "#8384A5" }}>
              Sidebar features, home sections, sports bet limits, and game providers
            </Typography>
          </Box>
        </Box>

        <Stack direction="row" spacing={1.5} alignItems="center">
          {draftCount > 0 && (
            <Chip
              label={`${draftCount} unsaved change${draftCount > 1 ? "s" : ""}`}
              size="small"
              sx={{ bgcolor: "rgba(255,194,63,0.12)", color: "#FFC23F", fontWeight: 600 }}
            />
          )}
          <Button
            onClick={save}
            disabled={!canSave}
            variant="contained"
            startIcon={busy ? <CircularProgress size={14} sx={{ color: "#fff" }} /> : <Save size={15} />}
            sx={{
              bgcolor: "#2B6EF5",
              textTransform: "none",
              fontWeight: 600,
              "&:hover": { bgcolor: "#4A85F7" },
              "&:disabled": { bgcolor: "#162140", color: "#8384A5" },
            }}
          >
            {busy ? "Saving..." : "Save Changes"}
          </Button>
        </Stack>
      </Box>

      {/* Master Password Card */}
      <Paper
        sx={{
          ...cardSx,
          p: 2.5,
          mb: 3,
        }}
      >
        <Stack direction={{ xs: "column", sm: "row" }} spacing={2} alignItems={{ sm: "center" }}>
          <Box sx={{ display: "flex", alignItems: "center", gap: 1.5, flex: 1 }}>
            <Box sx={{ p: 1, bgcolor: "rgba(255,194,63,0.15)", borderRadius: 2, display: "flex" }}>
              <Lock size={20} color="#FFC23F" />
            </Box>
            <Box>
              <Typography sx={{ color: "#F9F9F9", fontSize: "0.9rem", fontWeight: 600 }}>
                Transaction Password Required
              </Typography>
              <Typography variant="caption" sx={{ color: "#8384A5" }}>
                Your staff transaction password is verified on each save.
              </Typography>
            </Box>
          </Box>

          <TextField
            size="small"
            type={showPwd ? "text" : "password"}
            placeholder="Transaction password"
            value={txnPwd}
            onChange={(e) => setTxnPwd(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && canSave) save(); }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Lock size={14} color="#8384A5" />
                </InputAdornment>
              ),
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton size="small" onClick={() => setShowPwd(!showPwd)} sx={{ color: "#8384A5" }}>
                    {showPwd ? <EyeOff size={14} /> : <Eye size={14} />}
                  </IconButton>
                </InputAdornment>
              ),
            }}
            sx={{
              minWidth: 260,
              "& .MuiOutlinedInput-root": {
                bgcolor: "#0B1427",
                "& fieldset": { borderColor: "#1E2D55" },
                "&:hover fieldset": { borderColor: "#2B6EF5" },
                "&.Mui-focused fieldset": { borderColor: "#2B6EF5" },
              },
              "& input": { color: "#F9F9F9" },
            }}
          />
        </Stack>
      </Paper>

      {/* Missing password warning */}
      {!txnPwd && draftCount > 0 && (
        <Alert
          severity="warning"
          icon={<XCircle size={18} color="#FFC23F" />}
          sx={{
            mb: 2,
            bgcolor: "rgba(255,194,63,0.1)",
            color: "#FFC23F",
            border: "1px solid rgba(255,194,63,0.3)",
            "& .MuiAlert-icon": { color: "#FFC23F" },
          }}
        >
          You have {draftCount} unsaved change{draftCount > 1 ? "s" : ""}. Enter your transaction password to save.
        </Alert>
      )}

      {/* Config groups */}
      <Stack spacing={2.5}>
        {Object.entries(GROUPED_KEYS).map(([group, keys]) => {
          const enabledCount = keys.filter((k) => !!cfg[k]).length;
          return (
            <Paper key={group} sx={{ ...cardSx, overflow: "hidden" }}>
              <Box
                sx={{
                  px: 3,
                  py: 2,
                  bgcolor: "#0B1427",
                  borderBottom: "1px solid #1E2D55",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                }}
              >
                <Typography sx={{ color: "#F9F9F9", fontWeight: 700, fontSize: "0.95rem" }}>
                  {group}
                </Typography>
                <Chip
                  label={`${enabledCount} / ${keys.length} enabled`}
                  size="small"
                  sx={{
                    bgcolor: "rgba(43,110,245,0.12)",
                    color: "#5581F7",
                    fontWeight: 600,
                    fontSize: "0.7rem",
                  }}
                />
              </Box>

              <Box
                sx={{
                  p: 2,
                  display: "grid",
                  gridTemplateColumns: {
                    xs: "1fr",
                    sm: "repeat(2, 1fr)",
                    md: "repeat(3, 1fr)",
                    lg: "repeat(4, 1fr)",
                  },
                  gap: 1,
                }}
              >
                {keys.map((k) => {
                  const checked = !!cfg[k];
                  const isDraft = draft[k as BoolKey] !== undefined;
                  return (
                    <Box
                      key={k}
                      onClick={() => toggleFeature(k as BoolKey)}
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        px: 1.5,
                        py: 1,
                        borderRadius: 1.5,
                        cursor: "pointer",
                        border: "1px solid",
                        borderColor: isDraft ? "rgba(255,194,63,0.4)" : "transparent",
                        bgcolor: isDraft ? "rgba(255,194,63,0.06)" : "transparent",
                        transition: "all 150ms",
                        "&:hover": { bgcolor: "#162140" },
                      }}
                    >
                      <Typography
                        sx={{
                          color: checked ? "#F9F9F9" : "#8384A5",
                          fontSize: "0.82rem",
                          fontWeight: checked ? 500 : 400,
                        }}
                      >
                        {prettifyLabel(k)}
                      </Typography>
                      <DarkSwitch checked={checked} onChange={() => toggleFeature(k as BoolKey)} />
                    </Box>
                  );
                })}
              </Box>
            </Paper>
          );
        })}

        <SportsBetLimitsCard
          enabled={!!cfg.sports_match_odds_limit_enabled}
          maxOdds={String(cfg.sports_match_max_odds ?? "")}
          enabledDirty={draft.sports_match_odds_limit_enabled !== undefined}
          maxOddsDirty={draftMaxOdds !== undefined}
          maxOddsError={maxOddsError}
          canEdit={canEditBetLimits}
          onToggle={toggleMatchOddsLimit}
          onMaxOddsChange={changeMatchMaxOdds}
        />

        {/* Per-sport toggles */}
        <Paper sx={{ ...cardSx, overflow: "hidden" }}>
          <Box
            sx={{
              px: 3,
              py: 2,
              bgcolor: "#0B1427",
              borderBottom: "1px solid #1E2D55",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <Box>
              <Typography sx={{ color: "#F9F9F9", fontWeight: 700, fontSize: "0.95rem" }}>
                Per-Sport Toggles
              </Typography>
              <Typography variant="caption" sx={{ color: "#8384A5" }}>
                Enable or disable individual sports on the sportsbook (Cricket, Football, Tennis…).
              </Typography>
            </Box>
            {sports && (
              <Chip
                label={`${sports.filter((s) => s.enabled).length} / ${sports.length} enabled`}
                size="small"
                sx={{
                  bgcolor: "rgba(43,110,245,0.12)",
                  color: "#5581F7",
                  fontWeight: 600,
                  fontSize: "0.7rem",
                }}
              />
            )}
          </Box>

          <Box
            sx={{
              p: 2,
              display: "grid",
              gridTemplateColumns: {
                xs: "1fr",
                sm: "repeat(2, 1fr)",
                md: "repeat(3, 1fr)",
                lg: "repeat(4, 1fr)",
              },
              gap: 1,
            }}
          >
            {!sports ? (
              <Skeleton
                variant="rectangular"
                height={120}
                sx={{ gridColumn: "1 / -1", bgcolor: "#162140", borderRadius: 1 }}
              />
            ) : sports.length === 0 ? (
              <Typography
                sx={{ gridColumn: "1 / -1", color: "#8384A5", textAlign: "center", py: 4 }}
              >
                No sports configured
              </Typography>
            ) : (
              sports.map((s) => (
                <Box
                  key={s.id}
                  onClick={() => sportTogglingId !== s.id && toggleSport(s)}
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    px: 1.5,
                    py: 1,
                    borderRadius: 1.5,
                    cursor: sportTogglingId === s.id ? "wait" : "pointer",
                    border: "1px solid transparent",
                    transition: "all 150ms",
                    opacity: sportTogglingId === s.id ? 0.6 : 1,
                    "&:hover": { bgcolor: "#162140" },
                  }}
                >
                  <Typography
                    sx={{
                      color: s.enabled ? "#F9F9F9" : "#8384A5",
                      fontSize: "0.82rem",
                      fontWeight: s.enabled ? 500 : 400,
                    }}
                  >
                    {s.game_name}
                  </Typography>
                  <DarkSwitch
                    checked={s.enabled}
                    disabled={sportTogglingId === s.id}
                    onChange={() => toggleSport(s)}
                  />
                </Box>
              ))
            )}
          </Box>
        </Paper>

        {/* Providers section */}
        <Paper sx={{ ...cardSx, overflow: "hidden" }}>
          <Box
            sx={{
              px: 3,
              py: 2,
              bgcolor: "#0B1427",
              borderBottom: "1px solid #1E2D55",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              gap: 2,
              flexWrap: "wrap",
            }}
          >
            <Box>
              <Typography sx={{ color: "#F9F9F9", fontWeight: 700, fontSize: "0.95rem" }}>
                GIS Providers
              </Typography>
              <Typography variant="caption" sx={{ color: "#8384A5" }}>
                Synced from distinct providers in gisgamesnew. Disable to hide from the frontend.
              </Typography>
            </Box>
            <Stack direction="row" spacing={1.5} alignItems="center">
              {providers && (
                <Chip
                  label={`${providers.filter((p) => p.enabled).length} / ${providers.length} enabled`}
                  size="small"
                  sx={{
                    bgcolor: "rgba(43,110,245,0.12)",
                    color: "#5581F7",
                    fontWeight: 600,
                    fontSize: "0.7rem",
                  }}
                />
              )}
              <Tooltip title="Re-scan gisgamesnew for distinct providers">
                <span>
                  <Button
                    onClick={refreshFromDb}
                    disabled={refreshing}
                    variant="outlined"
                    size="small"
                    startIcon={
                      refreshing ? (
                        <CircularProgress size={14} sx={{ color: "#2B6EF5" }} />
                      ) : (
                        <RefreshCw size={14} />
                      )
                    }
                    sx={{
                      textTransform: "none",
                      fontWeight: 600,
                      color: "#F9F9F9",
                      borderColor: "#1E2D55",
                      "&:hover": { borderColor: "#2B6EF5", bgcolor: "rgba(43,110,245,0.08)" },
                    }}
                  >
                    {refreshing ? "Refreshing..." : "Refresh from DB"}
                  </Button>
                </span>
              </Tooltip>
            </Stack>
          </Box>

          <Box sx={{ px: 3, pt: 2 }}>
            <TextField
              size="small"
              fullWidth
              placeholder="Search providers"
              value={providerSearch}
              onChange={(e) => setProviderSearch(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <Search size={14} color="#8384A5" />
                  </InputAdornment>
                ),
              }}
              sx={{
                "& .MuiOutlinedInput-root": {
                  bgcolor: "#0B1427",
                  "& fieldset": { borderColor: "#1E2D55" },
                  "&:hover fieldset": { borderColor: "#2B6EF5" },
                  "&.Mui-focused fieldset": { borderColor: "#2B6EF5" },
                },
                "& input": { color: "#F9F9F9" },
              }}
            />
          </Box>

          <Box
            sx={{
              p: 2,
              display: "grid",
              gridTemplateColumns: {
                xs: "1fr",
                sm: "repeat(2, 1fr)",
                md: "repeat(3, 1fr)",
                lg: "repeat(4, 1fr)",
              },
              gap: 1,
              maxHeight: 480,
              overflow: "auto",
            }}
          >
            {!providers ? (
              <Skeleton variant="rectangular" height={120} sx={{ gridColumn: "1 / -1", bgcolor: "#162140", borderRadius: 1 }} />
            ) : filteredProviders.length === 0 ? (
              <Typography sx={{ gridColumn: "1 / -1", color: "#8384A5", textAlign: "center", py: 4 }}>
                No providers {providerSearch ? `match "${providerSearch}"` : "synced yet — click Refresh from DB"}
              </Typography>
            ) : (
              filteredProviders.map((p) => {
                const isDraft = providerDraft[p.name] !== undefined;
                return (
                  <Box
                    key={p.name}
                    onClick={() => toggleProvider(p.name)}
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      px: 1.5,
                      py: 1,
                      borderRadius: 1.5,
                      cursor: "pointer",
                      border: "1px solid",
                      borderColor: isDraft ? "rgba(255,194,63,0.4)" : "transparent",
                      bgcolor: isDraft ? "rgba(255,194,63,0.06)" : "transparent",
                      transition: "all 150ms",
                      "&:hover": { bgcolor: "#162140" },
                    }}
                  >
                    <Typography
                      sx={{
                        color: p.enabled ? "#F9F9F9" : "#8384A5",
                        fontSize: "0.82rem",
                        fontWeight: p.enabled ? 500 : 400,
                      }}
                    >
                      {p.name}
                    </Typography>
                    <DarkSwitch
                      checked={p.enabled}
                      onChange={() => toggleProvider(p.name)}
                    />
                  </Box>
                );
              })
            )}
          </Box>
        </Paper>
      </Stack>

      {/* Snackbar */}
      <Snackbar
        open={snack.open}
        autoHideDuration={3500}
        onClose={() => setSnack({ ...snack, open: false })}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert
          onClose={() => setSnack({ ...snack, open: false })}
          severity={snack.sev}
          sx={{
            bgcolor: snack.sev === "success" ? "rgba(14,204,104,0.15)" : "rgba(224,27,79,0.15)",
            color: snack.sev === "success" ? "#0ECC68" : "#E01B4F",
            border: `1px solid ${snack.sev === "success" ? "#0ECC68" : "#E01B4F"}44`,
            "& .MuiAlert-icon": { color: snack.sev === "success" ? "#0ECC68" : "#E01B4F" },
          }}
        >
          {snack.msg}
        </Alert>
      </Snackbar>
    </Box>
  );
}
