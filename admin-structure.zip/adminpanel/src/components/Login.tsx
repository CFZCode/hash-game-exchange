import React, { useState } from "react";
import { useNavigate } from 'react-router-dom';
import {
  Alert,
  AlertColor,
  Box,
  Button,
  Card,
  CircularProgress,
  Container,
  IconButton,
  InputAdornment,
  Snackbar,
  TextField,
  Typography,
  Chip,
} from "@mui/material";
import { Eye, EyeOff, Lock, Mail, Shield, Key, Copy, CheckCircle } from "lucide-react";
import { apiFetch } from "../utils/api";
import { DEMO_VIEW_KEY } from "../utils/demoView";
import * as lordsApi from "../services/lordsApi";
import { DEMO_AGENT_ROLE } from "../services/demoPortalApi";

interface FormData {
  email: string;
  password: string;
}

interface FormErrors {
  email?: string;
  password?: string;
}

interface SnackbarState {
  open: boolean;
  message: string;
  severity: AlertColor;
}

const LoginPage = () => {
  const [formData, setFormData] = useState<FormData>({ email: "", password: "" });
  const [errors, setErrors] = useState<FormErrors>({});
  const [snackbar, setSnackbar] = useState<SnackbarState>({ severity: "success", message: "", open: false });
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  // First-login flow states
  const [stage, setStage] = useState<"login" | "change-password" | "show-txn-password">("login");
  const [firstLoginStaffId, setFirstLoginStaffId] = useState<number | null>(null);
  const [firstLoginToken, setFirstLoginToken] = useState("");
  const [firstLoginUser, setFirstLoginUser] = useState<any>(null);
  const [newPassword, setNewPassword] = useState("");
  const [confirmNewPassword, setConfirmNewPassword] = useState("");
  const [txnPassword, setTxnPassword] = useState("");
  const [copied, setCopied] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prevFormData => ({ ...prevFormData, [name]: value }));
    // Clear errors when user starts typing
    if (errors[name as keyof FormErrors]) {
      setErrors(prev => ({ ...prev, [name]: undefined }));
    }
  };

  const validateForm = (): boolean => {
    let valid = true;
    let errors: FormErrors = {};

    if (!formData.email) {
      valid = false;
      errors.email = "Email or username is required";
    } else if (formData.email.includes('@') && !/\S+@\S+\.\S+/.test(formData.email)) {
      // Only validate email format if the input contains @ symbol
      valid = false;
      errors.email = "Please enter a valid email";
    }

    if (!formData.password) {
      valid = false;
      errors.password = "Password is required";
    } else if (formData.password.length < 6) {
      valid = false;
      errors.password = "Password must be at least 6 characters";
    }

    setErrors(errors);
    return valid;
  };

  const handleCloseSnackbar = (_event?: React.SyntheticEvent | Event, reason?: string) => {
    if (reason === 'clickaway') {
      return;
    }
    setSnackbar(prev => ({ ...prev, open: false }));
  };

  const loginClick = async () => {
    // 1. basic front-end validation
    if (!validateForm()) return;

    setLoading(true);
    const loginIdentifier = formData.email.trim().toLowerCase();
    const pwd = formData.password;

    try {
      /* ───────────────────────────────────────────────
         2. Online login.
         The identifier's shape only decides which endpoint to TRY FIRST.
         Staff log in by email; executives log in by username and may have an
         email-shaped username (e.g. "blog@manager.com"). So if the first
         endpoint rejects the account we fall back to the other one before
         giving up — otherwise an executive with an email-like username can
         never sign in (the staff lookup just returns "Bad email").
         ─────────────────────────────────────────────── */
      type LoginRes = {
        status: string;
        token: string;
        firstLogin?: boolean;
        hasTransactionPassword?: boolean;
        user: {
          id: number;
          executiveId?: number;
          name: string;
          email?: string;
          username?: string;
          demoView?: boolean;
          role: { name: string };
        };
      };

      const staffAttempt = {
        endpoint: "/api/staff/auth/login",
        body: { email: loginIdentifier, password: pwd },
      };
      const executiveAttempt = {
        endpoint: "/api/staff/auth/executive/login",
        body: { username: loginIdentifier, password: pwd },
      };

      const isEmail = /\S+@\S+\.\S+/.test(loginIdentifier);
      const attempts = isEmail
        ? [staffAttempt, executiveAttempt]
        : [executiveAttempt, staffAttempt];

      let res: LoginRes | null = null;
      let lastErr: any = null;
      for (const attempt of attempts) {
        try {
          res = await apiFetch<LoginRes>(attempt.endpoint, {
            method: "POST",
            body: JSON.stringify(attempt.body),
          });
          break;
        } catch (err) {
          lastErr = err;
        }
      }
      if (!res) throw lastErr;

      const roleName = res.user.role.name;       // e.g. "SuperAdmin", "Admin", "Executive", …

      if (roleName === "User") {
        setSnackbar({ severity: "error", message: "Users can't access the admin panel.", open: true });
        setLoading(false);
        return;
      }

      // Check if first login — force password change
      if (res.firstLogin) {
        setFirstLoginStaffId(res.user.id);
        setFirstLoginToken(res.token);
        setFirstLoginUser(res.user);
        setStage("change-password");
        setLoading(false);
        return;
      }

      // 3. persist auth
      localStorage.setItem("token", res.token);
      localStorage.setItem("userRole", roleName);
      localStorage.setItem("userEmail", res.user.email || res.user.username || "");
      localStorage.setItem("userName", res.user.name);
      localStorage.setItem("currentUserId", String(res.user.id));
      if (res.user.demoView) localStorage.setItem(DEMO_VIEW_KEY, "1");
      else localStorage.removeItem(DEMO_VIEW_KEY);
      if (res.user.executiveId) {
        localStorage.setItem("executiveId", String(res.user.executiveId));
      } else {
        localStorage.removeItem("executiveId");
      }

      setSnackbar({ severity: "success", message: `Welcome ${res.user.name}!`, open: true });
      // "/" routes through HomeRedirect, which sends each account to the first
      // page its permissions allow (super admins still land on admin-management).
      navigate(roleName === DEMO_AGENT_ROLE ? "/demo-portal" : "/", { replace: true });
      return;                               // stop here on success
    } catch (apiErr: any) {
      // Login is server-only. The old offline fallbacks ("static-demo" /
      // "local-admin") were removed: they stored fake tokens the backend's
      // guardAdmin rejects, and let anyone in via client-side credential
      // checks. On any API failure we simply show an error.
      console.warn("API login failed", apiErr);
    }

    /* ───────────────────────────────────────────────
       If the API login did not succeed
       ─────────────────────────────────────────────── */
    setSnackbar({ severity: "error", message: "Invalid email/username or password", open: true });
    setLoading(false);
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    loginClick();
  };

  /* ─── Shared sx tokens ─── */
  const inputSx = {
    '& .MuiOutlinedInput-root': {
      backgroundColor: '#10182E',
      borderRadius: '12px',
      color: '#F9F9F9',
      '& fieldset': {
        borderColor: '#1E2D55',
      },
      '&:hover fieldset': {
        borderColor: '#2B6EF5',
      },
      '&.Mui-focused fieldset': {
        borderColor: '#2B6EF5',
      },
    },
    '& .MuiInputLabel-root': {
      color: '#8384A5',
      '&.Mui-focused': {
        color: '#5581F7',
      },
    },
    '& .MuiFormHelperText-root': {
      color: '#E01B4F',
    },
  };

  return (
    <>
      {/* Full-page background */}
      <Box
        sx={{
          minHeight: '100vh',
          background: 'linear-gradient(135deg, #0C0D1D 0%, #0E1831 50%, #172244 100%)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          position: 'relative',
          overflow: 'hidden',
          px: 2,
        }}
      >
        {/* Decorative glow orbs */}
        <Box
          sx={{
            position: 'absolute',
            top: '20%',
            left: '20%',
            width: 380,
            height: 380,
            borderRadius: '50%',
            background: 'rgba(43, 110, 245, 0.12)',
            filter: 'blur(100px)',
            pointerEvents: 'none',
          }}
        />
        <Box
          sx={{
            position: 'absolute',
            bottom: '15%',
            right: '18%',
            width: 340,
            height: 340,
            borderRadius: '50%',
            background: 'rgba(85, 129, 247, 0.10)',
            filter: 'blur(100px)',
            pointerEvents: 'none',
          }}
        />

        <Container maxWidth="sm" sx={{ position: 'relative', zIndex: 1 }}>
          <Card
            elevation={0}
            sx={{
              backgroundColor: 'rgba(14, 24, 49, 0.8)',
              backdropFilter: 'blur(24px)',
              border: '1px solid rgba(30, 45, 85, 0.5)',
              borderRadius: '20px',
              p: { xs: 4, sm: 5 },
              maxWidth: 440,
              mx: 'auto',
            }}
          >
            {/* ════════════════ STAGE: LOGIN ════════════════ */}
            {stage === "login" && (
              <>
                <Box sx={{ textAlign: 'center', mb: 4 }}>
                  <Box sx={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', background: 'linear-gradient(135deg, #2B6EF5, #5581F7)', borderRadius: '14px', width: 56, height: 56, mb: 2 }}>
                    <Shield size={28} color="#fff" />
                  </Box>
                  <Typography variant="h4" sx={{ fontWeight: 700, color: '#F9F9F9', mb: 0.5 }}>Admin Portal</Typography>
                  <Typography variant="body2" sx={{ color: '#8384A5' }}>Secure access to administrative dashboard</Typography>
                </Box>
                <Box component="form" onSubmit={handleSubmit} noValidate>
                  <TextField fullWidth name="email" id="email" label="Email" placeholder="Enter your email or username" autoComplete="email"
                    value={formData.email} onChange={handleChange} error={!!errors.email} helperText={errors.email}
                    sx={{ ...inputSx, mb: 3 }}
                    InputProps={{ startAdornment: <InputAdornment position="start"><Mail size={20} color="#8384A5" /></InputAdornment> }} />
                  <TextField fullWidth name="password" id="password" label="Password" placeholder="Enter your password"
                    type={showPassword ? 'text' : 'password'} autoComplete="current-password"
                    value={formData.password} onChange={handleChange} error={!!errors.password} helperText={errors.password}
                    sx={{ ...inputSx, mb: 3.5 }}
                    InputProps={{
                      startAdornment: <InputAdornment position="start"><Lock size={20} color="#8384A5" /></InputAdornment>,
                      endAdornment: <InputAdornment position="end"><IconButton onClick={() => setShowPassword(!showPassword)} edge="end" sx={{ color: '#8384A5' }}>{showPassword ? <EyeOff size={20} /> : <Eye size={20} />}</IconButton></InputAdornment>,
                    }} />
                  <Button type="submit" variant="contained" fullWidth disabled={loading}
                    sx={{ background: 'linear-gradient(135deg, #2B6EF5, #5581F7)', borderRadius: '12px', textTransform: 'none', fontWeight: 600, fontSize: '0.95rem', py: 1.5,
                      boxShadow: '0 4px 20px rgba(43, 110, 245, 0.35)', '&:hover': { background: 'linear-gradient(135deg, #2460D9, #4A74E0)', transform: 'scale(1.02)' },
                      '&.Mui-disabled': { background: 'linear-gradient(135deg, #2B6EF5, #5581F7)', opacity: 0.7, color: '#fff' } }}>
                    {loading ? <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}><CircularProgress size={20} sx={{ color: '#fff' }} /><span>Signing in...</span></Box> : 'Sign in to Dashboard'}
                  </Button>
                </Box>
              </>
            )}

            {/* ════════════════ STAGE: CHANGE PASSWORD ════════════════ */}
            {stage === "change-password" && (
              <>
                <Box sx={{ textAlign: 'center', mb: 4 }}>
                  <Box sx={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', background: 'linear-gradient(135deg, #FFC23F, #FF9800)', borderRadius: '14px', width: 56, height: 56, mb: 2 }}>
                    <Key size={28} color="#fff" />
                  </Box>
                  <Typography variant="h5" sx={{ fontWeight: 700, color: '#F9F9F9', mb: 0.5 }}>First Login — Set New Password</Typography>
                  <Typography variant="body2" sx={{ color: '#8384A5' }}>
                    Welcome! For security, please set a new password to continue.
                  </Typography>
                </Box>
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2.5 }}>
                  <TextField fullWidth label="New Password" placeholder="Enter a strong password" type="password"
                    value={newPassword} onChange={(e) => setNewPassword(e.target.value)}
                    sx={inputSx}
                    InputProps={{ startAdornment: <InputAdornment position="start"><Lock size={20} color="#8384A5" /></InputAdornment> }} />
                  <TextField fullWidth label="Confirm New Password" placeholder="Repeat your new password" type="password"
                    value={confirmNewPassword} onChange={(e) => setConfirmNewPassword(e.target.value)}
                    error={confirmNewPassword.length > 0 && newPassword !== confirmNewPassword}
                    helperText={confirmNewPassword.length > 0 && newPassword !== confirmNewPassword ? "Passwords do not match" : ""}
                    sx={inputSx}
                    InputProps={{ startAdornment: <InputAdornment position="start"><Lock size={20} color="#8384A5" /></InputAdornment> }} />
                  <Button variant="contained" fullWidth disabled={loading || !newPassword || newPassword !== confirmNewPassword || newPassword.length < 6}
                    onClick={async () => {
                      setLoading(true);
                      try {
                        const res = await lordsApi.firstLoginPassword(firstLoginStaffId!, newPassword);
                        setTxnPassword(res.transactionPassword);
                        setStage("show-txn-password");
                      } catch (e: any) {
                        setSnackbar({ severity: "error", message: e?.message || "Failed to change password", open: true });
                      } finally {
                        setLoading(false);
                      }
                    }}
                    sx={{ background: 'linear-gradient(135deg, #FFC23F, #FF9800)', borderRadius: '12px', textTransform: 'none', fontWeight: 600, fontSize: '0.95rem', py: 1.5, color: '#0C0D1D',
                      '&:hover': { background: 'linear-gradient(135deg, #FFB300, #E68900)' },
                      '&.Mui-disabled': { opacity: 0.5, color: '#0C0D1D' } }}>
                    {loading ? <CircularProgress size={20} /> : 'Set Password & Continue'}
                  </Button>
                </Box>
              </>
            )}

            {/* ════════════════ STAGE: SHOW TRANSACTION PASSWORD ════════════════ */}
            {stage === "show-txn-password" && (
              <>
                <Box sx={{ textAlign: 'center', mb: 4 }}>
                  <Box sx={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', background: 'linear-gradient(135deg, #0ECC68, #0BB858)', borderRadius: '14px', width: 56, height: 56, mb: 2 }}>
                    <CheckCircle size={28} color="#fff" />
                  </Box>
                  <Typography variant="h5" sx={{ fontWeight: 700, color: '#F9F9F9', mb: 0.5 }}>Your Transaction Password</Typography>
                  <Typography variant="body2" sx={{ color: '#8384A5' }}>
                    This 8-digit password is required for all sensitive operations (transfers, credit changes, status updates). Save it securely — it will not be shown again.
                  </Typography>
                </Box>

                <Box sx={{ bgcolor: '#10182E', border: '2px solid #0ECC68', borderRadius: '16px', p: 3, textAlign: 'center', mb: 3 }}>
                  <Typography sx={{ color: '#8384A5', fontSize: 12, mb: 1, textTransform: 'uppercase', letterSpacing: 1 }}>Transaction Password</Typography>
                  <Typography sx={{ color: '#0ECC68', fontSize: 36, fontWeight: 800, fontFamily: 'monospace', letterSpacing: 6 }}>
                    {txnPassword}
                  </Typography>
                  <Button size="small" startIcon={copied ? <CheckCircle size={16} /> : <Copy size={16} />}
                    onClick={() => { navigator.clipboard.writeText(txnPassword); setCopied(true); setTimeout(() => setCopied(false), 2000); }}
                    sx={{ mt: 1, color: copied ? '#0ECC68' : '#8384A5', textTransform: 'none' }}>
                    {copied ? 'Copied!' : 'Copy to clipboard'}
                  </Button>
                </Box>

                <Box sx={{ bgcolor: 'rgba(255,194,63,0.08)', border: '1px solid rgba(255,194,63,0.3)', borderRadius: '12px', p: 2, mb: 3 }}>
                  <Typography sx={{ color: '#FFC23F', fontSize: 13, fontWeight: 600, mb: 0.5 }}>Important</Typography>
                  <Typography sx={{ color: '#8384A5', fontSize: 12 }}>
                    Write down this password and keep it safe. You will need it to perform transfers, change credit limits, update user status, and other administrative actions.
                  </Typography>
                </Box>

                <Button variant="contained" fullWidth
                  onClick={() => {
                    // Now complete the login
                    localStorage.setItem("token", firstLoginToken);
                    localStorage.setItem("userRole", firstLoginUser.role.name);
                    localStorage.setItem("userEmail", firstLoginUser.email);
                    localStorage.setItem("userName", firstLoginUser.name);
                    localStorage.setItem("currentUserId", String(firstLoginUser.id));
                    navigate(firstLoginUser.role.name === DEMO_AGENT_ROLE ? "/demo-portal" : "/", { replace: true });
                  }}
                  sx={{ background: 'linear-gradient(135deg, #0ECC68, #0BB858)', borderRadius: '12px', textTransform: 'none', fontWeight: 600, fontSize: '0.95rem', py: 1.5, color: '#fff',
                    '&:hover': { background: 'linear-gradient(135deg, #0BB858, #099E4A)' } }}>
                  I've saved my password — Continue to Dashboard
                </Button>
              </>
            )}
          </Card>

          <Typography variant="body2" sx={{ textAlign: 'center', mt: 3, color: '#8384A5' }}>
            &copy; 2026 MyApp Admin Portal. All rights reserved.
          </Typography>
        </Container>
      </Box>

      <Snackbar open={snackbar.open} autoHideDuration={3000} onClose={handleCloseSnackbar}>
        <Alert onClose={handleCloseSnackbar} severity={snackbar.severity} sx={{ width: '100%' }}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </>
  );
};

export default LoginPage;
