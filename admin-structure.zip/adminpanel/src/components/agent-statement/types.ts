/* Shapes returned by GET /api/admin/agent-report/:staffId/statement
   and             GET /api/admin/agent-report/user/:userId/statement.

   Both endpoints return this exact shape so one screen renders either.

   Sign conventions that matter when reading these numbers:
     • ledger rows  — `amount` is signed: + into the wallet, − out of it.
     • player_pnl   — + means the players won.
     • agent_pnl    — + means the agent earned (always −player_pnl).
     • headline_*   — whichever of the two the subject actually keeps, so the
                      screen can say "TOTAL PROFIT"/"TOTAL LOSS" directly. */

export type SubjectType = "STAFF" | "USER";
export type Category = "all" | "money" | "sports" | "casino";

export type LedgerKind =
  | "DEPOSIT_UPLINE" | "WITHDRAW_UPLINE"
  | "DEPOSIT_AGENT" | "COLLECTED_AGENT"
  | "DEPOSIT_PLAYER" | "COLLECTED_PLAYER"
  | "BANK_DEPOSIT" | "GATEWAY_DEPOSIT"
  | "BANK_WITHDRAW" | "GATEWAY_WITHDRAW"
  | "SPORTS" | "CASINO";

export interface LedgerRow {
  id: string;
  ts: string;
  kind: LedgerKind;
  label: string;
  party: string;
  direction: "IN" | "OUT";
  note: string | null;
  /** Legacy transfer_type ('gt'/'casino') on pre-cash-wallet rows, else null. */
  legacy: string | null;
  amount: number;
  balance: number;
}

export interface StatementBalance {
  live: number;
  /** Previous balance carried into the period. */
  opening: number;
  closing: number;
  movement: number;
  deposit_in: number;
  withdraw_out: number;
  given_downline: number;
  given_agents: number;
  given_players: number;
  collected_downline: number;
  collected_agents: number;
  collected_players: number;
  /** Players only: bank + gateway movement. */
  bank_in?: number;
  bank_out?: number;
  total_in: number;
  total_out: number;
  /** Players only: stake held in unsettled bets, out of the wallet. */
  open_exposure: number;
  /** Lifetime gap between the wallet and what the ledger explains. */
  unexplained: number;
}

export interface Gaming {
  sports: {
    settled_bets: number; player_pnl: number; agent_pnl: number;
    placed_bets: number; turnover: number; open_bets: number; open_stake: number;
  };
  casino: {
    txns: number; bets: number; staked: number; wins: number; won: number;
    player_pnl: number; agent_pnl: number;
  };
  total: {
    player_pnl: number; agent_pnl: number;
    headline_pnl: number; headline_sports: number; headline_casino: number;
    headline_for: "AGENT" | "PLAYER";
  };
}

export interface DailyRow {
  date: string; deposit: number; withdraw: number;
  sports_pnl: number; casino_pnl: number; net: number;
}

export interface SportsDailyRow {
  date: string; bets: number; player_pnl: number; agent_pnl: number;
}

export interface CasinoDailyRow {
  date: string; bets: number; staked: number; won: number;
  player_pnl: number; agent_pnl: number;
}

export interface PlayerRow {
  id: string; name: string; staff_name: string | null; wallet: number;
  funded: number; collected: number;
  sports_pnl: number; casino_pnl: number; sports_bets: number;
  casino_bets: number; casino_staked: number;
  agent_pnl: number; player_pnl: number;
}

export interface DownlineRow {
  id: string; name: string; role: string; depth: number; balance: number;
  players: number; wallet: number; funded: number; collected: number;
  sports_pnl: number; casino_pnl: number; agent_pnl: number;
}

export interface SportsBetRow {
  id: string; ts: string; user: string; match: string; selection: string;
  market: string; side: string; odds: number; stake: number;
  status: string; result: string | null;
}

export interface CasinoTxnRow {
  id: string; ts: string; user: string; action: string;
  game: string; round: string | null; amount: number;
}

export interface Pagination { page: number; limit: number; total: number; pages: number }

/** One page of the /bets endpoint. */
export interface BetPage<T> {
  status: string;
  kind: "sports" | "casino";
  rows: T[];
  pagination: Pagination;
}

export interface AgentStatement {
  status: string;
  subject: {
    type: SubjectType; id: string; name: string; email: string;
    role: string; level: number | null; agent_code: string | null;
    parent_name: string | null;
  };
  period: { from: string | null; to: string | null };
  category: Category;
  balance: StatementBalance;
  rows: LedgerRow[];
  pagination: Pagination;
  gaming: Gaming;
  daily: DailyRow[];
  sports_daily: SportsDailyRow[];
  casino_daily: CasinoDailyRow[];
  players: PlayerRow[];
  downline: DownlineRow[];
}
