
import React, { useEffect, useState } from "react";
import { NavLink, useNavigate, useLocation } from "react-router-dom";
import {
  Drawer,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Collapse,
  Avatar,
  Divider,
  Typography,
  IconButton,
  Box,
  useMediaQuery,
  useTheme,
} from "@mui/material";
import {
  LayoutDashboard,
  Users,
  CreditCard,
  Wallet,
  History,
  LogOut,
  ArrowUpCircle,
  ArrowDownCircle,
  Bell,
  Gift,
  ChevronsRight,
  Shield,
  File,
  Gamepad2,
  ArrowBigUpIcon,
  BookOpen,
  X,
  Percent,
  Gamepad,
  Settings,
  Settings2,
  Image,
  Trophy,
  BellRing,
  Search,
  TrendingUp,
  BarChart3,
  Target,
  ScrollText,
  Link as LinkIcon,
  UserCog,
  Network,
} from "lucide-react";
import { usePermissions } from "../hooks/usePermissions";

/* ------------------------------------------------------------------
   Sidebar role gating
   ------------------------------------------------------------------ */
const GROUP_ACCESS: Record<string, string[]> = {
  SuperAdmin: ["Main", "Admin", "Demo Portal", "Branch Panel", /*"Cash Flow",*/ "History", "Sports Exchange", "Gaming", "Transactions", "Marketing", "Settings", "Services"],
  Admin: ["Agent Panel", "Admin", "History", "Sports Analytics", "Gaming", "Transactions", ],
  SubAdmin: ["Agent Panel", "Admin","Sports Analytics","History", "Gaming", "Transactions"],
  Master: ["Agent Panel", "Admin","Sports Analytics", "History", "Gaming", "Transactions"],
  Agent: ["Agent Panel", "Admin","Sports Analytics", "History", "Gaming", "Transactions"],
  SubAgent: ["Agent Panel", "Admin","Sports Analytics", "History", "Gaming", "Transactions"],
  // Executives don't sit in the legacy whitelist — usePermissions() drives their menu.
  Executive: [],
  // Demo Portal Agents only create demo accounts.
  DemoAgent: ["Demo Portal"],
};

interface SidebarProps {
  isOpen: boolean;
  toggleSidebar: () => void;
}

interface MenuItem {
  path: string;
  label: string;
  icon: React.ReactNode;
  requireRole?: string;
}

interface MenuGroup {
  title: string;
  items: MenuItem[];
}

const SIDEBAR_WIDTH = 256;

const drawerPaperSx = {
  width: SIDEBAR_WIDTH,
  bgcolor: "#0E1831",
  borderRight: "1px solid #1E2D55",
  color: "#F9F9F9",
  display: "flex",
  flexDirection: "column",
  overflowX: "hidden",
  "&::-webkit-scrollbar": { width: 4 },
  "&::-webkit-scrollbar-thumb": {
    bgcolor: "#1E2D55",
    borderRadius: 2,
  },
} as const;

/* ------------------------------------------------------------------
   Component
   ------------------------------------------------------------------ */
const Sidebar: React.FC<SidebarProps> = ({ isOpen, toggleSidebar }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});
  const theme = useTheme();
  const isDesktop = useMediaQuery(theme.breakpoints.up("lg"));

  const userRole = localStorage.getItem("userRole") || "Guest";
  const userName = localStorage.getItem("userName") || "Admin";
  const allowedGroups = GROUP_ACCESS[userRole as keyof typeof GROUP_ACCESS] ?? [];

  const { isSuper, pageVisible, groupVisible } = usePermissions();
  // DemoAgent is not a hierarchy role but its menu is still the fixed whitelist.
  const fixedMenu = isSuper || userRole === "DemoAgent";

  /* -------- menu definition -------- */
  const menuGroups: MenuGroup[] = [
    {
      title: "Main",
      items: [
        { path: "/admin-dashboard", label: "Dashboard", icon: <LayoutDashboard size={18} /> },
        { path: "/users", label: "Users", icon: <Users size={18} /> },
        { path: "/reports", label: "User Reports", icon: <File size={18} /> },
        { path: "/kyc", label: "User KYC", icon: <Shield size={18} /> },
        { path: "/wallet", label: "Wallet", icon: <Wallet size={18} /> },
        // { path: "/swaphistory", label: "Swap History", icon: <ArrowLeftRight size={18} /> },
        { path: "/affiliate", label: "Affiliate", icon: <LinkIcon size={18} />, requireRole: "SuperAdmin" },
        { path: "/redeemcode", label: "Redeem Codes", icon: <Gift size={18} /> },
         { path: "/turnover-report", label: "Turnover Report", icon: <BarChart3 size={18} /> },
        // { path: "/3d-games", label: "3D Games", icon: <Dices size={18} />, requireRole: "SuperAdmin" },
        // { path: "/exchangerate", label: "Exchange Rate", icon: <TrendingUp size={18} /> },
      ],
    },
    {
      title: "Agent Panel",
      items: [
        { path: "/admin-dashboard", label: "Dashboard", icon: <LayoutDashboard size={18} /> },
        { path: "/users", label: "Users", icon: <Users size={18} /> },
        // { path: "/reports", label: "User Reports", icon: <File size={18} /> },
        // { path: "/kyc", label: "User KYC", icon: <Shield size={18} /> },
        // { path: "/wallet", label: "Wallet", icon: <Wallet size={18} /> },
        // // { path: "/swaphistory", label: "Swap History", icon: <ArrowLeftRight size={18} /> },
        // // { path: "/affiliate", label: "Affiliate", icon: <LinkIcon size={18} /> },
        // { path: "/redeemcode", label: "Redeem Codes", icon: <Gift size={18} /> },
        //  { path: "/turnover-report", label: "Turnover Report", icon: <BarChart3 size={18} /> },
        // { path: "/exchangerate", label: "Exchange Rate", icon: <TrendingUp size={18} /> },
      ],
    },
    {
      title: "Admin",
      items: [
        { path: "/admin-management", label: "Client Management", icon: <Shield size={18} /> },
        { path: "/activity-log", label: "Activity Log", icon: <ScrollText size={18} /> },
        { path: "/percentage-hierarchy", label: "Percentage Hierarchy", icon: <ArrowBigUpIcon size={18} /> },
       
      ],
    },
    {
      title: "Demo Portal",
      items: [
        { path: "/demo-portal", label: "Demo Portal Agent", icon: <UserCog size={18} /> },
      ],
    },
    {
      title: "Branch Panel",
      items: [
        { path: "/branch-management", label: "Branch Management", icon: <Network size={18} />, requireRole: "SuperAdmin" },
      ],
    },
    // {
    //   title: "Cash Flow",
    //   items: [
    //     { path: "/vaultpro", label: "Vault Pro", icon: <Landmark size={18} /> },
    //     { path: "/peer-trade", label: "P2P Trading", icon: <ArrowLeftRight size={18} /> },
    //   ],
    // },
    {
      title: "History",
      items: [
        { path: "/history", label: "Bet History", icon: <History size={18} /> },
        // { path: "/sportsbeting", label: "Sports Betting", icon: <Gamepad size={18} /> },
      ],
    },
    {
      title: "Sports Exchange",
      items: [
        { path: "/sports-dashboard", label: "Sports Dashboard", icon: <BarChart3 size={18} /> },
        { path: "/sportsbeting", label: "Sports Betting", icon: <Gamepad size={18} /> },
        { path: "/MOsettle", label: "Market Settlement", icon: <Target size={18} /> },
        { path: "/Fansettle", label: "Fancy Settlement", icon: <Target size={18} /> },
        // { path: "/fancyreport", label: "Fancy Report", icon: <File size={18} /> },
        // { path: "/marketwins", label: "Market Wins", icon: <Trophy size={18} /> },
        // { path: "/fanwins", label: "Fancy Wins", icon: <Trophy size={18} /> },
        // { path: "/sports-lock", label: "Sports Lock", icon: <Shield size={18} /> },
        // { path: "/sports-config", label: "Sports Config", icon: <Settings size={18} /> },
      ],
    },
    {
      title: "Sports Analytics",
      items: [
        { path: "/sports-dashboard", label: "Sports Dashboard", icon: <BarChart3 size={18} /> },
     
      ],
    },
    // {
    //   title: "Gaming",
    //   items: [
    //     { path: "/games", label: "Games", icon: <Gamepad2 size={18} /> },
    //     { path: "/house", label: "House Edge", icon: <Percent size={18} /> },
    //     { path: "/win-settings", label: "Win Settings", icon: <Dices size={18} /> },
    //     { path: "/winloss", label: "Win/Loss Toggle", icon: <Settings2 size={18} /> },
    //     { path: "/club", label: "Club Membership", icon: <Users size={18} /> },
    //     { path: "/bonus", label: "Bonus", icon: <Gift size={18} /> },
    //   ],
    // },
    {
      title: "Transactions",
      items: [
        { path: "/deposit", label: "Deposit", icon: <ArrowUpCircle size={18} /> },
        { path: "/withdraw", label: "Withdraw", icon: <ArrowDownCircle size={18} /> },
        { path: "/account-statement", label: "Account Statement", icon: <File size={18} /> },
      ],
    },
    {
      title: "Marketing",
      items: [
        { path: "/giftcard-admin", label: "Gift Cards", icon: <Gift size={18} /> },
        { path: "/spinwheel", label: "Spin Wheel", icon: <Gamepad2 size={18} /> },
        { path: "/blog", label: "Blog", icon: <BookOpen size={18} /> },
        // { path: "/banner", label: "Asset Management", icon: <Image size={18} /> },
        // { path: "/seo-manager", label: "SEO Manager", icon: <Search size={18} /> },
      ],
    },
    {
      title: "Settings",
      items: [
        // { path: "/bankdetails", label: "Bank Details", icon: <CreditCard size={18} /> },
        { path: "/payment-methods", label: "Payment Methods", icon: <CreditCard size={18} /> },
        { path: "/siteconfig", label: "Site Config", icon: <Settings size={18} /> },
        { path: "/providers-priority", label: "Providers Priority", icon: <Trophy size={18} /> },
        { path: "/vendor-priority", label: "Vendor Priority", icon: <ArrowBigUpIcon size={18} /> },
        { path: "/type-priority", label: "Type Priority", icon: <Gamepad2 size={18} /> },
        // { path: "/userconfig", label: "User Config", icon: <Settings2 size={18} /> },
        // { path: "/settings", label: "General Settings", icon: <Settings size={18} /> },
      ],
    },
    {
      title: "Services",
      items: [
        { path: "/notification", label: "Notification", icon: <Bell size={18} /> },
        // { path: "/notification-settings", label: "Notification Settings", icon: <BellRing size={18} /> },
      ],
    },
  ];

  /* -------- apply role + permission filter --------
     Super roles see the legacy GROUP_ACCESS list.
     Sub-admins see only what their permissions grant
     (groupVisible AND pageVisible from usePermissions). */
  const filteredMenuGroups = menuGroups
    .filter((g) => {
      if (fixedMenu) return allowedGroups.includes(g.title);
      // Show the group when its group flag is on OR any of its pages is
      // individually granted. The Access Management per-page toggle grants a
      // page without flipping the group master flag, so relying on
      // groupVisible alone used to hide granted pages (e.g. a blog-only
      // executive losing the Blog link). Page-level filtering + the
      // empty-group filter below still decide which items actually appear.
      return groupVisible(g.title) || g.items.some((i) => pageVisible(i.path));
    })
    .map((g) => ({
      ...g,
      items: g.items.filter((i) => {
        if (i.requireRole && i.requireRole !== userRole) return false;
        if (fixedMenu) return true;
        return pageVisible(i.path);
      }),
    }))
    .filter((g) => g.items.length > 0);

  /* -------- auto-expand active group -------- */
  useEffect(() => {
    filteredMenuGroups.forEach((group) => {
      const activeInside = group.items.some((item) => item.path === location.pathname);
      if (activeInside) {
        setCollapsed((prev) => ({ ...prev, [group.title]: false }));
      }
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.pathname]);

  /* -------- helpers -------- */
  const toggleGroup = (title: string) =>
    setCollapsed((prev) => ({ ...prev, [title]: !prev[title] }));

  const handleLogout = () => {
    // Record the logout in the activity log before clearing the token.
    // Fire-and-forget — never block sign-out on the log call.
    const token = localStorage.getItem("token");
    if (token) {
      fetch("https://example.com/api/staff/auth/logout", {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        keepalive: true,
      }).catch(() => {});
    }
    const admins = localStorage.getItem("adminUsers");
    localStorage.clear();
    if (admins) localStorage.setItem("adminUsers", admins);
    navigate("/login");
    toggleSidebar();
  };

  const handleItemClick = () => {
    if (!isDesktop) toggleSidebar();
  };

  /* -------- drawer content -------- */
  const drawerContent = (
    <Box sx={{ display: "flex", flexDirection: "column", height: "100%" }}>
      {/* ---- Logo / top bar ---- */}
      <Box
        sx={{
          p: 2,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          borderBottom: "1px solid #1E2D55",
          minHeight: 56,
        }}
      >
        <Typography
          variant="h6"
          sx={{
            fontWeight: 700,
            background: "linear-gradient(135deg, #2B6EF5 0%, #7B5EF5 100%)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            fontSize: "1.1rem",
            letterSpacing: "0.5px",
          }}
        >
          MyApp
        </Typography>
        {!isDesktop && (
          <IconButton onClick={toggleSidebar} sx={{ color: "#8384A5", "&:hover": { color: "#F9F9F9" } }}>
            <X size={20} />
          </IconButton>
        )}
      </Box>

      {/* ---- User badge ---- */}
      <Box sx={{ p: 2, borderBottom: "1px solid #1E2D55" }}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
          <Avatar
            sx={{
              width: 40,
              height: 40,
              bgcolor: "#2B6EF5",
              fontSize: "1rem",
              fontWeight: 600,
            }}
          >
            {userName.charAt(0).toUpperCase()}
          </Avatar>
          <Box>
            <Typography variant="body2" sx={{ color: "#F9F9F9", fontWeight: 600 }}>
              {userName}
            </Typography>
            <Typography variant="caption" sx={{ color: "#8384A5" }}>
              {userRole}
            </Typography>
          </Box>
        </Box>
      </Box>

      {/* ---- Menu groups ---- */}
      <Box sx={{ flex: 1, overflowY: "auto", py: 1, px: 1 }}>
        {filteredMenuGroups.map((group) => (
          <Box key={group.title} sx={{ mb: 0.5 }}>
            {/* Group header */}
            <ListItemButton
              onClick={() => toggleGroup(group.title)}
              sx={{
                px: 1.5,
                py: 0.75,
                borderRadius: 1,
                "&:hover": { bgcolor: "transparent" },
              }}
            >
              <Typography
                variant="caption"
                sx={{
                  flex: 1,
                  color: "#878AA2",
                  fontWeight: 700,
                  textTransform: "uppercase",
                  letterSpacing: "0.08em",
                  fontSize: "0.65rem",
                }}
              >
                {group.title}
              </Typography>
              <ChevronsRight
                size={14}
                color="#878AA2"
                style={{
                  transition: "transform 250ms cubic-bezier(0.4, 0, 0.2, 1)",
                  transform: !collapsed[group.title] ? "rotate(90deg)" : "rotate(0deg)",
                }}
              />
            </ListItemButton>

            {/* Collapsible items */}
            <Collapse in={!collapsed[group.title]} timeout={250} unmountOnExit>
              <List disablePadding sx={{ mt: 0.25 }}>
                {group.items.map((item) => (
                  <ListItem key={item.path} disablePadding sx={{ mb: "1px" }}>
                    <NavLink
                      to={item.path}
                      onClick={handleItemClick}
                      style={{ width: "100%", textDecoration: "none" }}
                    >
                      {({ isActive }) => (
                        <ListItemButton
                          selected={isActive}
                          sx={{
                            borderRadius: 1.5,
                            py: 0.85,
                            px: 1.5,
                            transition: "all 150ms ease",
                            color: isActive ? "#2B6EF5" : "#8384A5",
                            bgcolor: isActive ? "rgba(43, 110, 245, 0.12)" : "transparent",
                            "&:hover": {
                              bgcolor: isActive ? "rgba(43, 110, 245, 0.18)" : "#162140",
                              color: isActive ? "#2B6EF5" : "#F9F9F9",
                            },
                            "&.Mui-selected": {
                              bgcolor: "rgba(43, 110, 245, 0.12)",
                              "&:hover": { bgcolor: "rgba(43, 110, 245, 0.18)" },
                            },
                          }}
                        >
                          <ListItemIcon
                            sx={{
                              minWidth: 32,
                              color: "inherit",
                            }}
                          >
                            {item.icon}
                          </ListItemIcon>
                          <ListItemText
                            primary={item.label}
                            primaryTypographyProps={{
                              fontSize: "0.82rem",
                              fontWeight: isActive ? 600 : 400,
                            }}
                          />
                          {isActive && (
                            <Box
                              sx={{
                                width: 3,
                                height: 20,
                                borderRadius: 2,
                                bgcolor: "#2B6EF5",
                                position: "absolute",
                                right: 0,
                              }}
                            />
                          )}
                        </ListItemButton>
                      )}
                    </NavLink>
                  </ListItem>
                ))}
              </List>
            </Collapse>
          </Box>
        ))}
      </Box>

      {/* ---- Logout ---- */}
      <Divider sx={{ borderColor: "#1E2D55" }} />
      <Box sx={{ p: 1.5 }}>
        <ListItemButton
          onClick={handleLogout}
          sx={{
            borderRadius: 1.5,
            py: 1,
            px: 1.5,
            color: "#8384A5",
            transition: "all 150ms ease",
            "&:hover": {
              bgcolor: "rgba(239, 68, 68, 0.1)",
              color: "#EF4444",
            },
          }}
        >
          <ListItemIcon sx={{ minWidth: 32, color: "inherit" }}>
            <LogOut size={18} />
          </ListItemIcon>
          <ListItemText
            primary="Log Out"
            primaryTypographyProps={{ fontSize: "0.85rem", fontWeight: 500 }}
          />
        </ListItemButton>
      </Box>
    </Box>
  );

  return (
    <>
      {/* Desktop: permanent drawer */}
      {isDesktop && (
        <Drawer
          variant="permanent"
          open
          sx={{
            width: SIDEBAR_WIDTH,
            flexShrink: 0,
            "& .MuiDrawer-paper": drawerPaperSx,
          }}
        >
          {drawerContent}
        </Drawer>
      )}

      {/* Mobile: temporary drawer with backdrop */}
      {!isDesktop && (
        <Drawer
          variant="temporary"
          open={isOpen}
          onClose={toggleSidebar}
          ModalProps={{ keepMounted: true }}
          sx={{
            "& .MuiDrawer-paper": drawerPaperSx,
            "& .MuiBackdrop-root": {
              bgcolor: "rgba(0, 0, 0, 0.6)",
              backdropFilter: "blur(4px)",
            },
          }}
        >
          {drawerContent}
        </Drawer>
      )}
    </>
  );
};

export default Sidebar;
