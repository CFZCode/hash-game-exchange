import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {
  Box,
  Card,
  Typography,
  TextField,
  InputAdornment,
  Avatar,
  Chip,
  IconButton,
  Tooltip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Skeleton,
  Dialog,
  DialogTitle,
  DialogContent,
  Button,
  LinearProgress,
  Divider,
  CircularProgress,
} from '@mui/material';
import {
  Search,
  Download,
  Refresh,
  Visibility,
  Close,
  EmojiEvents,
  Person,
  AccountBalanceWallet,
  SearchOff,
} from '@mui/icons-material';
import { Star } from 'lucide-react';
import DemoChip from './common/DemoChip';

const BASE_URL = 'https://example.com/reports';

interface User {
  id: string;
  name: string;
  avatar?: string;
  wager: string | number;
  games_played: number;
  vipDetails?: {
    vipLevel: string;
    previousVipLevel: string;
    currentWager: string;
    wagerNeededForNextLevel: string;
    completionPercentage: string;
    card: string;
  };
  level?: number;
  referalcode?: string;
  is_demo?: boolean;
}

interface UserDetails {
  user?: User;
  vipDetails?: {
    vipLevel: string;
    previousVipLevel: string;
    currentWager: string;
    wagerNeededForNextLevel: number;
    completionPercentage: number;
    card: string;
  };
  wager: string | number;
  credits?: Record<string, string | number>;
}

interface ApiResponse {
  users: User[];
  pagination: { pages: number; current: number; total: number };
}

const getVipTier = (level?: string) => {
  const n =
    typeof level === 'string' && level.includes('VIP')
      ? parseInt(level.replace('VIP', '').trim())
      : parseInt(level || '0') || 0;
  if (n >= 50) return { label: 'Platinum', color: '#E5E4E2', bg: 'rgba(229,228,226,0.15)' };
  if (n >= 30) return { label: 'Gold', color: '#FFD700', bg: 'rgba(255,215,0,0.15)' };
  if (n >= 10) return { label: 'Silver', color: '#C0C0C0', bg: 'rgba(192,192,192,0.15)' };
  return { label: 'Bronze', color: '#CD7F32', bg: 'rgba(205,127,50,0.15)' };
};

const avatarColor = (name: string) => {
  const colors = ['#2B6EF5', '#7B5EF5', '#0ECC68', '#FFC23F', '#E01B4F', '#5581F7'];
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
  return colors[Math.abs(hash) % colors.length];
};

const HEADER_CELLS = ['#', 'User', 'Wager (INR)', 'Games Played', 'VIP Level', 'Actions'];

const Reports: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedUser, setSelectedUser] = useState<UserDetails | null>(null);
  const [userDetailsLoading, setUserDetailsLoading] = useState(false);
  const [exportLoading, setExportLoading] = useState(false);

  useEffect(() => { fetchUsers(); }, [currentPage, searchTerm]);

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const res = await axios.get<ApiResponse>(`${BASE_URL}/users`, {
        params: { page: currentPage, limit: 15, search: searchTerm },
      });
      setUsers(res.data.users);
      setTotalPages(res.data.pagination.pages);
    } catch {
      setUsers([]);
    } finally {
      setLoading(false);
    }
  };

  const handleViewUserDetails = async (userId: string) => {
    setUserDetailsLoading(true);
    setSelectedUser({} as UserDetails);
    try {
      const res = await axios.get<UserDetails>(`${BASE_URL}/user/${userId}`);
      setSelectedUser(res.data);
    } catch {
      setSelectedUser(null);
    } finally {
      setUserDetailsLoading(false);
    }
  };

  const exportReports = async () => {
    setExportLoading(true);
    try {
      const date = new Date().toISOString().split('T')[0];
      const res = await axios.get(`${BASE_URL}/export`, {
        params: { search: searchTerm },
        responseType: 'blob',
      });
      const url = window.URL.createObjectURL(new Blob([res.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `user_reports_${date}.csv`);
      document.body.appendChild(link);
      link.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(link);
    } catch {
      // silent
    } finally {
      setExportLoading(false);
    }
  };

  return (
    <Box sx={{ p: { xs: 1.5, sm: 2, md: 2.5 } }}>
      <Card sx={{ bgcolor: '#0E1831', border: '1px solid #1E2D55', borderRadius: 2 }}>

        {/* Toolbar */}
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', p: 2, gap: 2, flexWrap: 'wrap' }}>
          <Box>
            <Typography sx={{ color: '#F9F9F9', fontWeight: 700, fontSize: '1rem' }}>
              User Reports
            </Typography>
            <Typography sx={{ color: '#8384A5', fontSize: '0.75rem', mt: 0.25 }}>
              VIP levels, wager history &amp; balances
            </Typography>
          </Box>

          <Box sx={{ display: 'flex', gap: 1, alignItems: 'center', flexWrap: 'wrap' }}>
            <TextField
              size="small"
              placeholder="Search by username or referral code…"
              value={searchTerm}
              onChange={e => { setSearchTerm(e.target.value); setCurrentPage(1); }}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <Search sx={{ color: '#8384A5', fontSize: 18 }} />
                  </InputAdornment>
                ),
              }}
              sx={{
                width: { xs: '100%', sm: 260 },
                '& .MuiOutlinedInput-root': {
                  bgcolor: '#0C0D1D',
                  borderRadius: 1.5,
                  '& fieldset': { borderColor: '#1E2D55' },
                  '&:hover fieldset': { borderColor: '#2B6EF5' },
                  '&.Mui-focused fieldset': { borderColor: '#2B6EF5' },
                },
                '& input': { color: '#F9F9F9', fontSize: '0.85rem' },
              }}
            />
            <Tooltip title="Refresh">
              <IconButton
                onClick={fetchUsers}
                sx={{ color: '#8384A5', border: '1px solid #1E2D55', borderRadius: 1.5, '&:hover': { color: '#2B6EF5', borderColor: '#2B6EF5' } }}
              >
                <Refresh fontSize="small" />
              </IconButton>
            </Tooltip>
            <Button
              variant="outlined"
              size="small"
              startIcon={exportLoading ? <CircularProgress size={14} /> : <Download fontSize="small" />}
              onClick={exportReports}
              disabled={exportLoading}
              sx={{
                borderColor: '#1E2D55',
                color: '#8384A5',
                borderRadius: 1.5,
                fontSize: '0.8rem',
                '&:hover': { borderColor: '#2B6EF5', color: '#2B6EF5', bgcolor: 'rgba(43,110,245,0.06)' },
              }}
            >
              Export CSV
            </Button>
          </Box>
        </Box>

        {/* Table */}
        <TableContainer sx={{ borderTop: '1px solid #1E2D55' }}>
          <Table size="small">
            <TableHead>
              <TableRow sx={{ bgcolor: '#0C0D1D' }}>
                {HEADER_CELLS.map((h, i) => (
                  <TableCell
                    key={i}
                    sx={{
                      color: '#8384A5',
                      fontSize: '0.7rem',
                      fontWeight: 700,
                      textTransform: 'uppercase',
                      letterSpacing: '0.07em',
                      borderBottom: '1px solid #1E2D55',
                      py: 1.5,
                      whiteSpace: 'nowrap',
                    }}
                  >
                    {h}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>

            <TableBody>
              {loading
                ? Array.from({ length: 8 }).map((_, i) => (
                    <TableRow key={i}>
                      {HEADER_CELLS.map((_, j) => (
                        <TableCell key={j} sx={{ borderBottom: '1px solid #1E2D5533', py: 1.5 }}>
                          <Skeleton variant="text" sx={{ bgcolor: '#1E2D55' }} />
                        </TableCell>
                      ))}
                    </TableRow>
                  ))
                : users.map((user, idx) => {
                    const tier = getVipTier(user.vipDetails?.previousVipLevel);
                    const initials = user.name ? user.name.slice(0, 2).toUpperCase() : '??';
                    return (
                      <TableRow
                        key={user.id}
                        sx={{ '&:hover': { bgcolor: '#121E38' }, '& td': { borderBottom: '1px solid #1E2D5533' } }}
                      >
                        {/* # */}
                        <TableCell sx={{ color: '#8384A5', fontSize: '0.78rem', py: 1.5 }}>
                          {(currentPage - 1) * 15 + idx + 1}
                        </TableCell>

                        {/* User */}
                        <TableCell sx={{ py: 1.5 }}>
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                            <Avatar sx={{ width: 34, height: 34, fontSize: '0.72rem', fontWeight: 700, bgcolor: avatarColor(user.name), flexShrink: 0 }}>
                              {initials}
                            </Avatar>
                            <Typography sx={{ color: '#F9F9F9', fontSize: '0.82rem', fontWeight: 600 }}>
                              {user.name}
                              <DemoChip show={user.is_demo} />
                            </Typography>
                          </Box>
                        </TableCell>

                        {/* Wager */}
                        <TableCell sx={{ py: 1.5 }}>
                          <Typography sx={{ color: '#FFC23F', fontSize: '0.82rem', fontWeight: 600 }}>
                            ₹{Number(user.wager ?? 0).toFixed(2)}
                          </Typography>
                        </TableCell>

                        {/* Games */}
                        <TableCell sx={{ color: '#8384A5', fontSize: '0.82rem', py: 1.5 }}>
                          {user.games_played?.toLocaleString() ?? '—'}
                        </TableCell>

                        {/* VIP */}
                        <TableCell sx={{ py: 1.5 }}>
                          <Chip
                            icon={<Star size={12} color={tier.color} />}
                            label={user.vipDetails?.previousVipLevel || 'VIP 00'}
                            size="small"
                            sx={{
                              bgcolor: tier.bg,
                              color: tier.color,
                              fontWeight: 700,
                              fontSize: '0.72rem',
                              height: 22,
                              border: `1px solid ${tier.color}44`,
                              '& .MuiChip-icon': { ml: '6px' },
                            }}
                          />
                        </TableCell>

                        {/* Action */}
                        <TableCell sx={{ py: 1.5 }}>
                          <Button
                            size="small"
                            variant="outlined"
                            startIcon={<Visibility sx={{ fontSize: '14px !important' }} />}
                            onClick={() => handleViewUserDetails(user.id)}
                            sx={{
                              borderColor: '#1E2D55',
                              color: '#8384A5',
                              fontSize: '0.72rem',
                              borderRadius: 1.5,
                              py: 0.4,
                              '&:hover': { borderColor: '#2B6EF5', color: '#2B6EF5', bgcolor: 'rgba(43,110,245,0.06)' },
                            }}
                          >
                            View
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })}

              {!loading && users.length === 0 && (
                <TableRow>
                  <TableCell colSpan={6} sx={{ py: 6, borderBottom: 'none' }}>
                    <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1 }}>
                      <SearchOff sx={{ fontSize: 40, color: '#1E2D55' }} />
                      <Typography sx={{ color: '#8384A5', fontSize: '0.85rem' }}>No users found</Typography>
                    </Box>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>

        {/* Pagination */}
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', px: 2, py: 1.5, borderTop: '1px solid #1E2D55', gap: 1 }}>
          <Typography sx={{ color: '#8384A5', fontSize: '0.78rem', mr: 'auto' }}>
            Page {currentPage} of {totalPages}
          </Typography>
          <Button
            size="small"
            disabled={currentPage === 1}
            onClick={() => setCurrentPage(p => p - 1)}
            sx={{ color: '#8384A5', borderColor: '#1E2D55', minWidth: 0, px: 1.5, '&:hover': { color: '#F9F9F9' }, '&.Mui-disabled': { color: '#1E2D5566' } }}
          >
            ← Prev
          </Button>
          <Button
            size="small"
            disabled={currentPage >= totalPages}
            onClick={() => setCurrentPage(p => p + 1)}
            sx={{ color: '#8384A5', borderColor: '#1E2D55', minWidth: 0, px: 1.5, '&:hover': { color: '#F9F9F9' }, '&.Mui-disabled': { color: '#1E2D5566' } }}
          >
            Next →
          </Button>
        </Box>
      </Card>

      {/* ── User Detail Dialog ── */}
      <Dialog
        open={!!selectedUser}
        onClose={() => setSelectedUser(null)}
        maxWidth="sm"
        fullWidth
        PaperProps={{
          sx: {
            bgcolor: '#0E1831',
            border: '1px solid #1E2D55',
            borderRadius: 2,
            backgroundImage: 'linear-gradient(135deg, rgba(43,110,245,0.06) 0%, rgba(123,94,245,0.06) 100%)',
          },
        }}
      >
        <DialogTitle sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', pb: 1 }}>
          <Typography sx={{ color: '#F9F9F9', fontWeight: 700, fontSize: '1rem' }}>User Details</Typography>
          <IconButton size="small" onClick={() => setSelectedUser(null)} sx={{ color: '#8384A5', '&:hover': { color: '#F9F9F9' } }}>
            <Close fontSize="small" />
          </IconButton>
        </DialogTitle>

        <DialogContent>
          {userDetailsLoading ? (
            <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', py: 5, gap: 2 }}>
              <CircularProgress sx={{ color: '#2B6EF5' }} />
              <Typography sx={{ color: '#8384A5', fontSize: '0.85rem' }}>Loading details…</Typography>
            </Box>
          ) : selectedUser?.user ? (
            <>
              {/* VIP Banner */}
              {selectedUser.vipDetails && (() => {
                const tier = getVipTier(selectedUser.vipDetails?.vipLevel);
                const pct = Number(selectedUser.vipDetails?.completionPercentage) || 0;
                return (
                  <Box
                    sx={{
                      bgcolor: '#0C0D1D',
                      border: `1px solid ${tier.color}44`,
                      borderRadius: 2,
                      p: 2.5,
                      mb: 2,
                      position: 'relative',
                      overflow: 'hidden',
                    }}
                  >
                    <Box sx={{ position: 'absolute', top: -20, right: -20, width: 120, height: 120, borderRadius: '50%', bgcolor: tier.color, opacity: 0.06 }} />
                    <Box sx={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', mb: 2 }}>
                      <Box>
                        <Typography sx={{ color: '#8384A5', fontSize: '0.72rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.07em' }}>
                          VIP Status
                        </Typography>
                        <Typography sx={{ color: tier.color, fontSize: '1.6rem', fontWeight: 800, lineHeight: 1.2 }}>
                          {selectedUser.vipDetails.previousVipLevel || 'VIP 0'}
                        </Typography>
                      </Box>
                      <Box sx={{ bgcolor: tier.bg, border: `1px solid ${tier.color}44`, borderRadius: 2, p: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <EmojiEvents sx={{ color: tier.color, fontSize: 28 }} />
                      </Box>
                    </Box>

                    <Box sx={{ mb: 0.75, display: 'flex', justifyContent: 'space-between' }}>
                      <Typography sx={{ color: '#8384A5', fontSize: '0.72rem' }}>Progress to next level</Typography>
                      <Typography sx={{ color: tier.color, fontSize: '0.72rem', fontWeight: 700 }}>{pct}%</Typography>
                    </Box>
                    <LinearProgress
                      variant="determinate"
                      value={Math.min(pct, 100)}
                      sx={{
                        height: 6,
                        borderRadius: 3,
                        bgcolor: '#1E2D55',
                        '& .MuiLinearProgress-bar': { bgcolor: tier.color, borderRadius: 3 },
                      }}
                    />
                    <Box sx={{ mt: 1.5, display: 'flex', gap: 2 }}>
                      <Box>
                        <Typography sx={{ color: '#8384A5', fontSize: '0.65rem' }}>Current Wager</Typography>
                        <Typography sx={{ color: '#F9F9F9', fontSize: '0.82rem', fontWeight: 600 }}>
                          ₹{Number(selectedUser.wager ?? 0).toFixed(2)}
                        </Typography>
                      </Box>
                      {selectedUser.vipDetails.wagerNeededForNextLevel > 0 && (
                        <Box>
                          <Typography sx={{ color: '#8384A5', fontSize: '0.65rem' }}>Needed for next</Typography>
                          <Typography sx={{ color: '#F9F9F9', fontSize: '0.82rem', fontWeight: 600 }}>
                            ₹{Number(selectedUser.vipDetails.wagerNeededForNextLevel).toLocaleString()}
                          </Typography>
                        </Box>
                      )}
                    </Box>
                  </Box>
                );
              })()}

              {/* User Info */}
              <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 2 }}>
                {/* User Info card */}
                <Box sx={{ bgcolor: '#0C0D1D', border: '1px solid #1E2D55', borderRadius: 2, p: 2, gridColumn: '1 / -1' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1.5 }}>
                    <Person sx={{ color: '#2B6EF5', fontSize: 16 }} />
                    <Typography sx={{ color: '#8384A5', fontSize: '0.7rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.07em' }}>
                      User Information
                    </Typography>
                  </Box>
                  <Divider sx={{ borderColor: '#1E2D55', mb: 1.5 }} />
                  {[
                    { label: 'Username', value: selectedUser.user?.name },
                    { label: 'User ID', value: selectedUser.user?.id, mono: true },
                    { label: 'Referral Code', value: selectedUser.user?.referalcode || 'N/A', mono: true },
                  ].map(row => (
                    <Box key={row.label} sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', py: 0.75 }}>
                      <Typography sx={{ color: '#8384A5', fontSize: '0.78rem' }}>{row.label}</Typography>
                      <Typography
                        sx={{
                          color: row.mono ? '#5581F7' : '#F9F9F9',
                          fontSize: '0.78rem',
                          fontWeight: 600,
                          fontFamily: row.mono ? 'monospace' : 'inherit',
                          bgcolor: row.mono ? 'rgba(43,110,245,0.08)' : 'transparent',
                          px: row.mono ? 1 : 0,
                          borderRadius: 1,
                        }}
                      >
                        {row.value}
                      </Typography>
                    </Box>
                  ))}
                </Box>

                {/* Balance card */}
                {selectedUser.credits && Object.keys(selectedUser.credits).filter(k => k !== 'uid').length > 0 && (
                  <Box sx={{ bgcolor: '#0C0D1D', border: '1px solid #1E2D55', borderRadius: 2, p: 2, gridColumn: '1 / -1' }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1.5 }}>
                      <AccountBalanceWallet sx={{ color: '#FFC23F', fontSize: 16 }} />
                      <Typography sx={{ color: '#8384A5', fontSize: '0.7rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.07em' }}>
                        Balance Information
                      </Typography>
                    </Box>
                    <Divider sx={{ borderColor: '#1E2D55', mb: 1.5 }} />
                    {Object.entries(selectedUser.credits)
                      .filter(([k]) => k !== 'uid')
                      .map(([key, value]) => (
                        <Box key={key} sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', py: 0.75 }}>
                          <Typography sx={{ color: '#8384A5', fontSize: '0.78rem', textTransform: 'uppercase', fontFamily: 'monospace' }}>
                            {key}
                          </Typography>
                          <Typography sx={{ color: '#0ECC68', fontSize: '0.78rem', fontWeight: 600 }}>
                            {Number(value ?? 0).toFixed(8)}
                          </Typography>
                        </Box>
                      ))}
                  </Box>
                )}
              </Box>
            </>
          ) : null}
        </DialogContent>
      </Dialog>
    </Box>
  );
};

export default Reports;
