import React, { useState, useEffect } from "react";
import axios from "axios";
import { ChevronLeft, ChevronRight } from "lucide-react";

const PAGE_SIZE = 10;
const CURRENCY_TABS = ["BDT", "NPR", "INR", "PKR"];

// Group the raw DB statuses (Done / Success / In Queue / ...) into the
// buckets offered by the status filter dropdown.
const statusGroup = (status: string) => {
  switch (String(status || "").toLowerCase()) {
    case "success": case "done": case "completed": case "approved": return "success";
    case "processing": case "pending": case "in queue": return "processing";
    case "failed": return "failed";
    case "rejected": case "wager not completed": return "rejected";
    default: return "other";
  }
};

interface WithdrawItem {
  id: string;
  uid: string;
  date: string;
  wallet: string;
  amount: number;
  coin: string;
  name: string;
  amount_usdt: number;
  status: string;
  chain: string;
}

interface FiatWithdrawItem {
  id: string;
  uid: string;
  date: string;
  amount: number;
  currency: string;
  bank_name: string | null;
  account_number: string | null;
  account_holder_name: string | null;
  ifsc_code: string | null;
  upi_id: string | null;
  status: string;
  name: string | null;
  // extra context from getFiatWithdrawData (apay / f2pay rows)
  source?: string;
  payment_system?: string | null;
  order_id?: string | null;
  error_reason?: string | null;
  refunded?: boolean;
}

const getStatusColor = (status: string) => {
  switch (String(status || "").toLowerCase()) {
    case "success":
    case "done":
    case "completed":
    case "approved":
      return "bg-green-100 text-green-800";
    case "processing":
    case "pending":
    case "in queue":
      return "bg-yellow-100 text-yellow-800";
    case "failed":
    case "rejected":
    case "wager not completed":
      return "bg-red-100 text-red-800";
    default:
      return "bg-[#121E38] text-[#F9F9F9]";
  }
};

const Pagination = ({
  currentPage,
  totalPages,
  onPageChange,
}: {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}) => (
  <div className="flex items-center justify-between px-4 py-3 border-t border-[#1E2D55]">
    <p className="text-sm text-[#8384A5]">Showing page {currentPage} of {totalPages}</p>
    <div className="flex items-center space-x-2">
      <button
        onClick={() => onPageChange(currentPage - 1)}
        disabled={currentPage === 1}
        className="p-2 rounded-md disabled:opacity-50 disabled:cursor-not-allowed hover:bg-[#121E38]"
      >
        <ChevronLeft className="w-5 h-5" />
      </button>
      {[...Array(Math.min(5, totalPages))].map((_, idx) => {
        let pageNumber;
        if (totalPages <= 5 || currentPage <= 3) pageNumber = idx + 1;
        else if (currentPage >= totalPages - 2) pageNumber = totalPages - (4 - idx);
        else pageNumber = currentPage - 2 + idx;
        return (
          <button
            key={idx}
            onClick={() => onPageChange(pageNumber)}
            className={`px-3 py-1 rounded-md ${currentPage === pageNumber ? "bg-[#2B6EF5] text-[#F9F9F9]" : "hover:bg-[#121E38]"}`}
          >
            {pageNumber}
          </button>
        );
      })}
      <button
        onClick={() => onPageChange(currentPage + 1)}
        disabled={currentPage === totalPages}
        className="p-2 rounded-md disabled:opacity-50 disabled:cursor-not-allowed hover:bg-[#121E38]"
      >
        <ChevronRight className="w-5 h-5" />
      </button>
    </div>
  </div>
);

const WithdrawSelf = () => {
  const [withdrawData, setWithdrawData] = useState<WithdrawItem[]>([]);
  const [fiatWithdrawData, setFiatWithdrawData] = useState<FiatWithdrawItem[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [currencyFilter, setCurrencyFilter] = useState("INR");
  const [activeTab, setActiveTab] = useState<"crypto" | "fiat">("crypto");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const staffId = localStorage.getItem("currentUserId");
  // Staff JWT for the backend's guardAdmin auth. Sent alongside x-staff-id
  // (which the backend still reads for activity logging).
  const authHeaders = (): Record<string, string> => {
    const token = localStorage.getItem("token");
    return {
      "x-staff-id": staffId ?? "",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    };
  };

  useEffect(() => {
    if (activeTab === "crypto") fetchWithdrawData();
    else fetchFiatWithdrawData();
  }, [activeTab]);

  const fetchWithdrawData = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await axios.get("https://example.com/getWithdrawData", {
        headers: authHeaders(),
      });
      const data = response.data;
      if (Array.isArray(data)) {
        setWithdrawData(data.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
      } else {
        console.error("Unexpected response structure:", data);
        setWithdrawData([]);
      }
    } catch (err) {
      console.error("Failed to fetch withdrawal data:", err);
      setError("Failed to fetch crypto withdrawal data");
      setWithdrawData([]);
    } finally {
      setLoading(false);
    }
  };

  const fetchFiatWithdrawData = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await axios.get("https://example.com/getFiatWithdrawData", {
        headers: authHeaders(),
      });
      const data = response.data;
      if (Array.isArray(data)) {
        setFiatWithdrawData(data.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
      } else {
        console.error("Unexpected response structure:", data);
        setFiatWithdrawData([]);
      }
    } catch (err) {
      console.error("Failed to fetch fiat withdrawal data:", err);
      setError("Failed to fetch fiat withdrawal data");
      setFiatWithdrawData([]);
    } finally {
      setLoading(false);
    }
  };

  const term = searchTerm.toLowerCase();
  const resetPage = () => setCurrentPage(1);
  const handleClearFilters = () => {
    setSearchTerm("");
    setStatusFilter("");
    setStartDate("");
    setEndDate("");
    // Currency is selected via the top tabs — don't clear it from here
    resetPage();
  };

  // Shared status + date-range filter (client-side; the APIs return full lists).
  const matchesCommon = (status: string, date: string) => {
    if (statusFilter && statusGroup(status) !== statusFilter) return false;
    const d = new Date(date);
    if (startDate && d < new Date(`${startDate}T00:00:00`)) return false;
    if (endDate && d > new Date(`${endDate}T23:59:59.999`)) return false;
    return true;
  };

  const filteredWithdrawData = withdrawData.filter(
    (w) =>
      matchesCommon(w.status, w.date) &&
      (!searchTerm || String(w.uid).includes(searchTerm) || (w.name || "").toLowerCase().includes(term))
  );

  const filteredFiatWithdrawData = fiatWithdrawData.filter(
    (w) =>
      String(w.currency || "INR").toUpperCase() === currencyFilter &&
      matchesCommon(w.status, w.date) &&
      (!searchTerm ||
        String(w.uid).includes(searchTerm) ||
        (w.name || "").toLowerCase().includes(term) ||
        String(w.order_id || w.id || "").toLowerCase().includes(term))
  );

  const activeList = activeTab === "crypto" ? filteredWithdrawData : filteredFiatWithdrawData;
  const totalPages = Math.max(1, Math.ceil(activeList.length / PAGE_SIZE));
  const pageStart = (currentPage - 1) * PAGE_SIZE;
  const pagedWithdrawData = filteredWithdrawData.slice(pageStart, pageStart + PAGE_SIZE);
  const pagedFiatWithdrawData = filteredFiatWithdrawData.slice(pageStart, pageStart + PAGE_SIZE);

  const thClass = "px-4 py-2 text-left text-xs font-medium text-[#878AA2] uppercase";

  const renderTableState = (colSpan: number, count: number, emptyText: string) => {
    if (loading) return <tr><td colSpan={colSpan} className="text-center py-4">Loading...</td></tr>;
    if (error) return <tr><td colSpan={colSpan} className="text-center py-4 text-[#E01B4F]">{error}</td></tr>;
    if (count === 0) return <tr><td colSpan={colSpan} className="text-center py-4">{emptyText}</td></tr>;
    return null;
  };

  return (
    <div className="p-4 text-[#F9F9F9]">
      {/* Crypto / Fiat tab switcher */}
      <div className="bg-[#0E1831] border border-[#1E2D55] rounded-lg mb-6 overflow-x-auto">
        <div className="flex">
          {(["crypto", "fiat"] as const).map((t) => {
            const active = activeTab === t;
            return (
              <button
                key={t}
                onClick={() => {
                  if (t === activeTab) return;
                  setActiveTab(t);
                  handleClearFilters();
                }}
                className={`px-5 py-2.5 text-sm font-medium whitespace-nowrap transition-colors border-b-2 ${
                  active
                    ? "text-[#2B6EF5] border-[#2B6EF5] bg-[rgba(43,110,245,0.08)]"
                    : "text-[#8384A5] border-transparent hover:text-[#F9F9F9] hover:bg-[#162140]"
                }`}
              >
                {t === "crypto" ? "Crypto" : "Fiat"}
              </button>
            );
          })}
        </div>
      </div>

      {/* Currency tabs — fiat only */}
      {activeTab === "fiat" && (
        <div className="bg-[#0E1831] border border-[#1E2D55] rounded-lg mb-6 overflow-x-auto">
          <div className="flex">
            {CURRENCY_TABS.map((c) => {
              const active = currencyFilter === c;
              return (
                <button
                  key={c}
                  onClick={() => { setCurrencyFilter(c); resetPage(); }}
                  className={`px-5 py-2.5 text-sm font-medium whitespace-nowrap transition-colors border-b-2 ${
                    active
                      ? "text-[#2B6EF5] border-[#2B6EF5] bg-[rgba(43,110,245,0.08)]"
                      : "text-[#8384A5] border-transparent hover:text-[#F9F9F9] hover:bg-[#162140]"
                  }`}
                >
                  {c}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="bg-[#0E1831] p-4 rounded-lg shadow mb-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label className="block text-sm font-medium text-[#8384A5] mb-1">Search</label>
            <input
              type="text"
              placeholder="Search by User ID, name or order id"
              value={searchTerm}
              onChange={(e) => { setSearchTerm(e.target.value); resetPage(); }}
              className="w-full p-2 border rounded-lg bg-white text-black"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-[#8384A5] mb-1">Status</label>
            <select
              value={statusFilter}
              onChange={(e) => { setStatusFilter(e.target.value); resetPage(); }}
              className="w-full p-2 border rounded-lg bg-white text-black"
            >
              <option value="">All</option>
              <option value="success">Success</option>
              <option value="processing">Processing</option>
              <option value="failed">Failed</option>
              <option value="rejected">Rejected</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-[#8384A5] mb-1">Start Date</label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => { setStartDate(e.target.value); resetPage(); }}
              className="w-full p-2 border rounded-lg bg-white text-black"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-[#8384A5] mb-1">End Date</label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => { setEndDate(e.target.value); resetPage(); }}
              className="w-full p-2 border rounded-lg bg-white text-black"
            />
          </div>
        </div>
        <div className="mt-4">
          <button
            onClick={handleClearFilters}
            className="px-4 py-2 bg-[#162140] text-[#8384A5] rounded-lg hover:bg-[#1E2D55]"
          >
            Clear Filters
          </button>
        </div>
      </div>

      {activeTab === "crypto" && (
        <div className="bg-[#0E1831] rounded-lg shadow overflow-x-auto">
          <table className="min-w-full">
            <thead>
              <tr className="bg-[#0E1831]">
                <th className={thClass}>User ID</th>
                <th className={thClass}>User Name</th>
                <th className={thClass}>Chain</th>
                <th className={thClass}>Coin</th>
                <th className={thClass}>Amount</th>
                <th className={thClass}>Wallet</th>
                <th className={thClass}>Status</th>
                <th className={thClass}>Created At</th>
              </tr>
            </thead>
            <tbody>
              {renderTableState(8, filteredWithdrawData.length, "No cryptocurrency withdrawal records found") ||
                pagedWithdrawData.map((w) => (
                  <tr key={w.id} className="border-t border-[#1E2D55]">
                    <td className="px-4 py-2">{w.uid}</td>
                    <td className="px-4 py-2">{w.name}</td>
                    <td className="px-4 py-2">{w.chain}</td>
                    <td className="px-4 py-2">{w.coin}</td>
                    <td className="px-4 py-2">
                      {w.amount}
                      {w.amount_usdt != null && (
                        <div className="text-xs text-[#878AA2]">≈ {Number(w.amount_usdt).toFixed(2)} USDT</div>
                      )}
                    </td>
                    <td className="px-4 py-2"><span className="text-xs break-all">{w.wallet}</span></td>
                    <td className="px-4 py-2">
                      <span className={`inline-flex px-2 py-1 text-xs rounded-full ${getStatusColor(w.status)}`}>
                        {w.status}
                      </span>
                    </td>
                    <td className="px-4 py-2">{new Date(w.date).toLocaleString()}</td>
                  </tr>
                ))}
            </tbody>
          </table>
          {!loading && !error && activeList.length > 0 && (
            <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={setCurrentPage} />
          )}
        </div>
      )}

      {activeTab === "fiat" && (
        <div className="bg-[#0E1831] rounded-lg shadow overflow-x-auto">
          <table className="min-w-full">
            <thead>
              <tr className="bg-[#0E1831]">
                <th className={thClass}>User ID</th>
                <th className={thClass}>User Name</th>
                <th className={thClass}>Currency</th>
                <th className={thClass}>Amount</th>
                <th className={thClass}>Provider</th>
                <th className={thClass}>Order Id</th>
                <th className={thClass}>Account Details</th>
                <th className={thClass}>Status</th>
                <th className={thClass}>Created At</th>
              </tr>
            </thead>
            <tbody>
              {renderTableState(9, filteredFiatWithdrawData.length, "No fiat withdrawal records found") ||
                pagedFiatWithdrawData.map((w) => (
                  <tr key={`${w.source || "fiat"}-${w.id}`} className="border-t border-[#1E2D55]">
                    <td className="px-4 py-2">{w.uid}</td>
                    <td className="px-4 py-2">{w.name}</td>
                    <td className="px-4 py-2">{w.currency}</td>
                    <td className="px-4 py-2">{Number(w.amount).toFixed(2)}</td>
                    <td className="px-4 py-2">
                      {w.payment_system || w.bank_name || "-"}
                      {w.source && <div className="text-xs text-[#878AA2] uppercase">{w.source}</div>}
                    </td>
                    <td className="px-4 py-2"><span className="text-xs break-all">{w.order_id || w.id}</span></td>
                    <td className="px-4 py-2 text-xs text-[#8384A5]">
                      {w.account_holder_name && <div>{w.account_holder_name}</div>}
                      {w.account_number && <div>A/C: {w.account_number}</div>}
                      {w.ifsc_code && <div>IFSC: {w.ifsc_code}</div>}
                      {w.upi_id && <div>UPI: {w.upi_id}</div>}
                    </td>
                    <td className="px-4 py-2">
                      <span className={`inline-flex px-2 py-1 text-xs rounded-full ${getStatusColor(w.status)}`}>
                        {w.status}
                      </span>
                      {w.refunded && <div className="text-xs text-[#878AA2] mt-1">Refunded</div>}
                      {w.error_reason && <div className="text-xs text-[#E01B4F] mt-1">{w.error_reason}</div>}
                    </td>
                    <td className="px-4 py-2">{new Date(w.date).toLocaleString()}</td>
                  </tr>
                ))}
            </tbody>
          </table>
          {!loading && !error && activeList.length > 0 && (
            <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={setCurrentPage} />
          )}
        </div>
      )}
    </div>
  );
};

export default WithdrawSelf;
