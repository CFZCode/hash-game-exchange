import React from 'react';
import { Navigate } from 'react-router-dom';
import { Box, CircularProgress } from '@mui/material';
import { usePermissions } from '../hooks/usePermissions';
import { PAGE_GROUPS } from '../constants/permissions';

/**
 * Landing redirect for the app home ("/").
 *
 * Super roles keep the Client Management overview as their home. Everyone
 * else (executives) is sent to the FIRST page their permissions actually
 * grant — so a blog-only executive lands on /blog instead of the ungated
 * /admin-management overview (which would otherwise expose downline balances
 * they have no permission to see).
 */
const HomeRedirect: React.FC = () => {
  const { isSuper, loading, pageVisible } = usePermissions();

  // Super admins: unchanged behaviour.
  if (isSuper) return <Navigate to="/admin-management" replace />;

  // Wait until the permission set has been fetched before deciding, otherwise
  // we could redirect to the fallback before the real permissions arrive.
  if (loading) {
    return (
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '60vh' }}>
        <CircularProgress sx={{ color: '#2B6EF5' }} />
      </Box>
    );
  }

  // First page (in sidebar order) this account is allowed to open.
  for (const group of PAGE_GROUPS) {
    for (const p of group.pages) {
      if (pageVisible(p.path)) return <Navigate to={p.path} replace />;
    }
  }

  // No page permissions at all — nothing meaningful to show.
  return <Navigate to="/admin-management" replace />;
};

export default HomeRedirect;
