import React from 'react';
import { Chip, Tooltip } from '@mui/material';
import type { SxProps, Theme } from '@mui/material';

const AMBER = '#FFC23F';

interface DemoChipProps {
  /** Renders nothing unless truthy, so callers can pass `row.is_demo` directly. */
  show?: boolean | null;
  sx?: SxProps<Theme>;
}

/** Small amber "DEMO" badge shown next to a demo account's username. */
const DemoChip: React.FC<DemoChipProps> = ({ show = true, sx }) => {
  if (!show) return null;
  return (
    <Tooltip title="Demo account — balance is not real money">
      <Chip
        label="DEMO"
        size="small"
        sx={{
          bgcolor: `${AMBER}22`,
          color: AMBER,
          border: `1px solid ${AMBER}55`,
          fontWeight: 700,
          fontSize: '0.62rem',
          letterSpacing: '0.04em',
          height: 18,
          ml: 0.75,
          verticalAlign: 'middle',
          '& .MuiChip-label': { px: 0.75 },
          ...(sx as object),
        }}
      />
    </Tooltip>
  );
};

export default DemoChip;
