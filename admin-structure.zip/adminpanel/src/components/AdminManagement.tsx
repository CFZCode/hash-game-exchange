import React, { useState, useEffect } from 'react';
import {
  Box,
  Card,
  Typography,
  TextField,
  InputAdornment,
  Avatar,
  Chip,
  IconButton,
  Tooltip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Switch,
  Snackbar,
  Alert,
  Divider,
} from '@mui/material';
import {
  Search,
  FilterList,
  PersonAdd,
  Edit,
  Delete,
  Shield,
  CheckCircle,
  Cancel,
  Close,
  Visibility,
  VisibilityOff,
  BarChart,
  AccountCircle,
  Warning,
  ListAlt,
  AdminPanelSettings,
  Insights,
} from '@mui/icons-material';
import { NavLink, Outlet } from 'react-router-dom';

interface Admin {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  username: string;
  role: 'MotherAdmin' | 'Admin' | 'SubAdmin' | 'Master' | 'Agent' | 'SubAgent' | 'User';
  password: string;
  status: 'active' | 'inactive';
  createdAt: string;
  lastLogin?: string;
}

interface FormData {
  firstName: string;
  lastName: string;
  email: string;
  username: string;
  role: Admin['role'];
  password: string;
  confirmPassword: string;
}

interface FormErrors { [key: string]: string }

const ROLE_HIERARCHY: Record<string, { level: number; color: string; bg: string }> = {
  MotherAdmin: { level: 0, color: '#F9F9F9', bg: '#0C0D1D' },
  Admin:       { level: 1, color: '#E01B4F', bg: 'rgba(224,27,79,0.12)' },
  SubAdmin:    { level: 2, color: '#FFC23F', bg: 'rgba(255,194,63,0.12)' },
  Master:      { level: 3, color: '#2B6EF5', bg: 'rgba(43,110,245,0.12)' },
  Agent:       { level: 4, color: '#0ECC68', bg: 'rgba(14,204,104,0.12)' },
  SubAgent:    { level: 5, color: '#7B5EF5', bg: 'rgba(123,94,245,0.12)' },
  User:        { level: 6, color: '#8384A5', bg: 'rgba(131,132,165,0.12)' },
};

const avatarColor = (name: string) => {
  const colors = ['#2B6EF5','#7B5EF5','#0ECC68','#FFC23F','#E01B4F'];
  let h = 0;
  for (let i = 0; i < name.length; i++) h = name.charCodeAt(i) + ((h << 5) - h);
  return colors[Math.abs(h) % colors.length];
};

const inputSx = (focusColor = '#2B6EF5') => ({
  '& .MuiOutlinedInput-root': {
    bgcolor: '#0C0D1D', borderRadius: 1.5,
    '& fieldset': { borderColor: '#1E2D55' },
    '&:hover fieldset': { borderColor: focusColor },
    '&.Mui-focused fieldset': { borderColor: focusColor },
  },
  '& input': { color: '#F9F9F9', fontSize: '0.85rem' },
  '& .MuiInputLabel-root': { color: '#8384A5', '&.Mui-focused': { color: focusColor } },
});

const SAMPLE_ADMINS: Admin[] = [
  { id: '1', firstName: 'John', lastName: 'Smith', email: 'john.smith@example.com', username: 'jsmith', role: 'Admin', password: 'Admin@123', status: 'active', createdAt: '2024-01-15', lastLogin: '2024-01-20' },
  { id: '2', firstName: 'Sarah', lastName: 'Johnson', email: 'sarah.johnson@example.com', username: 'sjohnson', role: 'SubAdmin', password: 'SubAdmin@123', status: 'active', createdAt: '2024-01-16', lastLogin: '2024-01-19' },
  { id: '3', firstName: 'Mike', lastName: 'Davis', email: 'mike.davis@example.com', username: 'mdavis', role: 'User', password: 'User@123', status: 'active', createdAt: '2024-01-17', lastLogin: '2024-01-18' },
];

/* ══════════════════════════════════════════════
   User Management Tab
══════════════════════════════════════════════ */
const UserManagementTab = () => {
  const [admins, setAdmins] = useState<Admin[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editingAdmin, setEditingAdmin] = useState<Admin | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Admin | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [snack, setSnack] = useState<{ open: boolean; msg: string; severity: 'success' | 'error' }>({ open: false, msg: '', severity: 'success' });
  const [formData, setFormData] = useState<FormData>({ firstName: '', lastName: '', email: '', username: '', role: 'User', password: '', confirmPassword: '' });
  const [errors, setErrors] = useState<FormErrors>({});

  const notify = (msg: string, severity: 'success' | 'error' = 'success') => setSnack({ open: true, msg, severity });

  useEffect(() => {
    const stored = localStorage.getItem('adminUsers');
    setAdmins(stored ? JSON.parse(stored) : SAMPLE_ADMINS);
    if (!stored) localStorage.setItem('adminUsers', JSON.stringify(SAMPLE_ADMINS));
  }, []);

  useEffect(() => {
    if (admins.length > 0) localStorage.setItem('adminUsers', JSON.stringify(admins));
  }, [admins]);

  useEffect(() => {
    const onEsc = (e: KeyboardEvent) => { if (e.key === 'Escape') resetForm(); };
    document.addEventListener('keydown', onEsc);
    return () => document.removeEventListener('keydown', onEsc);
  }, [showForm]);

  const userRole = localStorage.getItem('userRole') || '';
  const currentLevel = ROLE_HIERARCHY[userRole]?.level ?? 999;
  const manageableRoles = Object.keys(ROLE_HIERARCHY).filter(r => ROLE_HIERARCHY[r].level > currentLevel);

  const filteredAdmins = admins
    .filter(a => manageableRoles.includes(a.role))
    .filter(a => {
      const q = searchTerm.toLowerCase();
      const match = [a.firstName, a.lastName, a.email, a.username].some(s => s.toLowerCase().includes(q));
      return match && (roleFilter === 'all' || a.role === roleFilter) && (statusFilter === 'all' || a.status === statusFilter);
    });

  const validate = (): boolean => {
    const e: FormErrors = {};
    if (!formData.firstName.trim()) e.firstName = 'Required';
    if (!formData.lastName.trim()) e.lastName = 'Required';
    if (!formData.email.trim()) e.email = 'Required';
    else if (!/\S+@\S+\.\S+/.test(formData.email)) e.email = 'Invalid email';
    if (!formData.username.trim()) e.username = 'Required';
    if (!formData.password) e.password = 'Required';
    else if (formData.password.length < 6) e.password = 'Min 6 characters';
    if (formData.password !== formData.confirmPassword) e.confirmPassword = 'Passwords do not match';
    const dup = admins.some(a => (a.email === formData.email || a.username === formData.username) && a.id !== editingAdmin?.id);
    if (dup) { e.email = 'Already exists'; e.username = 'Already exists'; }
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const doSubmit = () => {
    e.preventDefault();
    if (!validate()) return;
    const admin: Admin = { id: editingAdmin?.id || Date.now().toString(), ...formData, status: 'active', createdAt: editingAdmin?.createdAt || new Date().toISOString().split('T')[0], lastLogin: editingAdmin?.lastLogin };
    if (editingAdmin) {
      setAdmins(p => p.map(a => a.id === editingAdmin.id ? admin : a));
      notify('Client updated successfully!');
    } else {
      setAdmins(p => [...p, admin]);
      notify('Client added successfully!');
    }
    resetForm();
  };

  const resetForm = () => {
    setFormData({ firstName: '', lastName: '', email: '', username: '', role: 'User', password: '', confirmPassword: '' });
    setErrors({}); setShowForm(false); setEditingAdmin(null); setShowPassword(false); setShowConfirmPassword(false);
  };

  const handleEdit = (a: Admin) => {
    setFormData({ firstName: a.firstName, lastName: a.lastName, email: a.email, username: a.username, role: a.role, password: a.password, confirmPassword: a.password });
    setEditingAdmin(a); setShowForm(true);
  };

  const confirmDelete = () => {
    if (!deleteTarget) return;
    setAdmins(p => p.filter(a => a.id !== deleteTarget.id));
    notify('Client deleted successfully!');
    setDeleteTarget(null);
  };

  const toggleStatus = (id: string) => {
    setAdmins(p => p.map(a => a.id === id ? { ...a, status: a.status === 'active' ? 'inactive' : 'active' } : a));
  };

  if (manageableRoles.length === 0) {
    return (
      <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', py: 10, gap: 1.5 }}>
        <Shield sx={{ fontSize: 48, color: '#1E2D55' }} />
        <Typography sx={{ color: '#F9F9F9', fontWeight: 600 }}>No Management Access</Typography>
        <Typography sx={{ color: '#8384A5', fontSize: '0.85rem' }}>Your role ({userRole}) cannot manage other users.</Typography>
      </Box>
    );
  }

  const HEADER_CELLS = ['Client', 'Role', 'Status', 'Last Login', 'Actions'];

  return (
    <Box sx={{ p: { xs: 1.5, sm: 2 } }}>

      {/* Toolbar */}
      <Card sx={{ bgcolor: '#0E1831', border: '1px solid #1E2D55', borderRadius: 2, mb: 2 }}>
        <Box sx={{ p: 2, display: 'flex', flexWrap: 'wrap', gap: 1.5, alignItems: 'center', justifyContent: 'space-between' }}>
          <Box sx={{ display: 'flex', gap: 1.5, flexWrap: 'wrap', flex: 1 }}>
            <TextField size="small" placeholder="Search clients…" value={searchTerm} onChange={e => setSearchTerm(e.target.value)}
              InputProps={{ startAdornment: <InputAdornment position="start"><Search sx={{ color: '#8384A5', fontSize: 18 }} /></InputAdornment> }}
              sx={{ ...inputSx(), minWidth: 200, '& input': { color: '#F9F9F9', fontSize: '0.85rem' } }}
            />
            <FormControl size="small" sx={{ minWidth: 130 }}>
              <Select value={roleFilter} onChange={e => setRoleFilter(e.target.value)}
                displayEmpty
                startAdornment={<FilterList sx={{ color: '#8384A5', fontSize: 18, mr: 0.5 }} />}
                sx={{ bgcolor: '#0C0D1D', color: '#F9F9F9', fontSize: '0.82rem', borderRadius: 1.5, '& .MuiOutlinedInput-notchedOutline': { borderColor: '#1E2D55' }, '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: '#2B6EF5' }, '& .MuiSvgIcon-root': { color: '#8384A5' } }}
                MenuProps={{ PaperProps: { sx: { bgcolor: '#0E1831', border: '1px solid #1E2D55', '& .MuiMenuItem-root': { color: '#F9F9F9', fontSize: '0.82rem', '&:hover': { bgcolor: '#121E38' } } } } }}
              >
                <MenuItem value="all">All Roles</MenuItem>
                {manageableRoles.map(r => <MenuItem key={r} value={r}>{r}</MenuItem>)}
              </Select>
            </FormControl>
            <FormControl size="small" sx={{ minWidth: 130 }}>
              <Select value={statusFilter} onChange={e => setStatusFilter(e.target.value)}
                displayEmpty
                sx={{ bgcolor: '#0C0D1D', color: '#F9F9F9', fontSize: '0.82rem', borderRadius: 1.5, '& .MuiOutlinedInput-notchedOutline': { borderColor: '#1E2D55' }, '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: '#2B6EF5' }, '& .MuiSvgIcon-root': { color: '#8384A5' } }}
                MenuProps={{ PaperProps: { sx: { bgcolor: '#0E1831', border: '1px solid #1E2D55', '& .MuiMenuItem-root': { color: '#F9F9F9', fontSize: '0.82rem', '&:hover': { bgcolor: '#121E38' } } } } }}
              >
                <MenuItem value="all">All Status</MenuItem>
                <MenuItem value="active">Active</MenuItem>
                <MenuItem value="inactive">Inactive</MenuItem>
              </Select>
            </FormControl>
          </Box>
          <Button variant="contained" startIcon={<PersonAdd />} onClick={() => setShowForm(true)}
            sx={{ bgcolor: '#2B6EF5', '&:hover': { bgcolor: '#1A5CE0' }, borderRadius: 1.5, fontWeight: 700, whiteSpace: 'nowrap' }}>
            Add Client
          </Button>
        </Box>
      </Card>

      {/* Table */}
      <Card sx={{ bgcolor: '#0E1831', border: '1px solid #1E2D55', borderRadius: 2 }}>
        <TableContainer>
          <Table size="small">
            <TableHead>
              <TableRow sx={{ bgcolor: '#0C0D1D' }}>
                {HEADER_CELLS.map(h => (
                  <TableCell key={h} sx={{ color: '#8384A5', fontSize: '0.7rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.07em', borderBottom: '1px solid #1E2D55', py: 1.5, whiteSpace: 'nowrap' }}>
                    {h}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredAdmins.map(admin => {
                const roleCfg = ROLE_HIERARCHY[admin.role];
                return (
                  <TableRow key={admin.id} sx={{ '&:hover': { bgcolor: '#121E38' }, '& td': { borderBottom: '1px solid #1E2D5533' } }}>
                    {/* Client */}
                    <TableCell sx={{ py: 1.5 }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                        <Avatar sx={{ width: 34, height: 34, fontSize: '0.72rem', fontWeight: 700, bgcolor: avatarColor(`${admin.firstName} ${admin.lastName}`), flexShrink: 0 }}>
                          {`${admin.firstName[0]}${admin.lastName[0]}`.toUpperCase()}
                        </Avatar>
                        <Box>
                          <Typography sx={{ color: '#F9F9F9', fontSize: '0.82rem', fontWeight: 600 }}>{admin.firstName} {admin.lastName}</Typography>
                          <Typography sx={{ color: '#8384A5', fontSize: '0.68rem' }}>{admin.email}</Typography>
                          <Typography sx={{ color: '#5581F7', fontSize: '0.65rem', fontFamily: 'monospace' }}>@{admin.username}</Typography>
                        </Box>
                      </Box>
                    </TableCell>

                    {/* Role */}
                    <TableCell sx={{ py: 1.5 }}>
                      <Chip label={admin.role} size="small"
                        sx={{ bgcolor: roleCfg.bg, color: roleCfg.color, fontWeight: 700, fontSize: '0.7rem', height: 22, border: `1px solid ${roleCfg.color}33` }}
                      />
                    </TableCell>

                    {/* Status */}
                    <TableCell sx={{ py: 1.5 }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75, cursor: 'pointer' }} onClick={() => toggleStatus(admin.id)}>
                        <Switch checked={admin.status === 'active'} size="small"
                          sx={{ '& .MuiSwitch-switchBase.Mui-checked': { color: '#0ECC68' }, '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': { bgcolor: '#0ECC68' }, '& .MuiSwitch-track': { bgcolor: '#1E2D55' } }}
                        />
                        <Chip
                          label={admin.status}
                          size="small"
                          icon={admin.status === 'active' ? <CheckCircle sx={{ fontSize: '13px !important' }} /> : <Cancel sx={{ fontSize: '13px !important' }} />}
                          sx={{
                            bgcolor: admin.status === 'active' ? 'rgba(14,204,104,0.12)' : 'rgba(224,27,79,0.12)',
                            color: admin.status === 'active' ? '#0ECC68' : '#E01B4F',
                            fontWeight: 700, fontSize: '0.68rem', height: 20, textTransform: 'capitalize',
                            border: `1px solid ${admin.status === 'active' ? 'rgba(14,204,104,0.3)' : 'rgba(224,27,79,0.3)'}`,
                            '& .MuiChip-icon': { color: 'inherit', ml: '4px' },
                          }}
                        />
                      </Box>
                    </TableCell>

                    {/* Last Login */}
                    <TableCell sx={{ color: '#8384A5', fontSize: '0.75rem', py: 1.5, whiteSpace: 'nowrap' }}>
                      {admin.lastLogin || 'Never'}
                    </TableCell>

                    {/* Actions */}
                    <TableCell sx={{ py: 1.5 }}>
                      <Box sx={{ display: 'flex', gap: 0.75 }}>
                        <Tooltip title="Edit">
                          <IconButton size="small" onClick={() => handleEdit(admin)}
                            sx={{ color: '#2B6EF5', bgcolor: 'rgba(43,110,245,0.08)', borderRadius: 1, '&:hover': { bgcolor: 'rgba(43,110,245,0.18)' } }}>
                            <Edit sx={{ fontSize: 15 }} />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Delete">
                          <IconButton size="small" onClick={() => setDeleteTarget(admin)}
                            sx={{ color: '#E01B4F', bgcolor: 'rgba(224,27,79,0.08)', borderRadius: 1, '&:hover': { bgcolor: 'rgba(224,27,79,0.18)' } }}>
                            <Delete sx={{ fontSize: 15 }} />
                          </IconButton>
                        </Tooltip>
                      </Box>
                    </TableCell>
                  </TableRow>
                );
              })}
              {filteredAdmins.length === 0 && (
                <TableRow>
                  <TableCell colSpan={5} sx={{ py: 6, borderBottom: 'none' }}>
                    <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1 }}>
                      <Shield sx={{ fontSize: 40, color: '#1E2D55' }} />
                      <Typography sx={{ color: '#8384A5', fontSize: '0.85rem' }}>No clients found</Typography>
                    </Box>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Card>

      {/* ── Add / Edit Dialog ── */}
      <Dialog open={showForm} onClose={resetForm} maxWidth="sm" fullWidth
        PaperProps={{ sx: { bgcolor: '#0E1831', border: '1px solid #1E2D55', borderRadius: 2 } }}>
        <DialogTitle sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid #1E2D55', pb: 1.5 }}>
          <Typography sx={{ color: '#F9F9F9', fontWeight: 700 }}>{editingAdmin ? 'Edit Client' : 'Add New Client'}</Typography>
          <IconButton size="small" onClick={resetForm} sx={{ color: '#8384A5', '&:hover': { color: '#F9F9F9' } }}><Close fontSize="small" /></IconButton>
        </DialogTitle>
        <DialogContent sx={{ pt: 2.5 }}>
          <Box component="form" onSubmit={(e: React.FormEvent) => { e.preventDefault(); doSubmit(); }} sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 2 }}>
            {[
              { name: 'firstName', label: 'First Name', type: 'text' },
              { name: 'lastName', label: 'Last Name', type: 'text' },
              { name: 'email', label: 'Email', type: 'email', span: true },
              { name: 'username', label: 'Username', type: 'text' },
            ].map(f => (
              <TextField key={f.name} label={f.label} type={f.type} size="small" fullWidth
                value={(formData as any)[f.name]} onChange={e => setFormData(p => ({ ...p, [f.name]: e.target.value }))}
                error={!!errors[f.name]} helperText={errors[f.name]}
                sx={{ ...inputSx(), gridColumn: f.span ? '1 / -1' : undefined, '& .MuiFormHelperText-root': { color: '#E01B4F' } }}
              />
            ))}

            {/* Role */}
            <FormControl size="small" sx={{ gridColumn: '1 / -1' }}>
              <InputLabel sx={{ color: '#8384A5', '&.Mui-focused': { color: '#2B6EF5' } }}>Role</InputLabel>
              <Select value={formData.role} label="Role" onChange={e => setFormData(p => ({ ...p, role: e.target.value as Admin['role'] }))}
                sx={{ bgcolor: '#0C0D1D', color: '#F9F9F9', fontSize: '0.85rem', borderRadius: 1.5, '& .MuiOutlinedInput-notchedOutline': { borderColor: '#1E2D55' }, '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: '#2B6EF5' }, '& .MuiSvgIcon-root': { color: '#8384A5' } }}
                MenuProps={{ PaperProps: { sx: { bgcolor: '#0E1831', border: '1px solid #1E2D55', '& .MuiMenuItem-root': { color: '#F9F9F9', fontSize: '0.82rem', '&:hover': { bgcolor: '#121E38' } } } } }}
              >
                {manageableRoles.map(r => <MenuItem key={r} value={r}>{r}</MenuItem>)}
              </Select>
            </FormControl>

            {/* Password */}
            <TextField label="Password" size="small" type={showPassword ? 'text' : 'password'}
              value={formData.password} onChange={e => setFormData(p => ({ ...p, password: e.target.value }))}
              error={!!errors.password} helperText={errors.password}
              InputProps={{ endAdornment: <InputAdornment position="end"><IconButton size="small" onClick={() => setShowPassword(p => !p)} sx={{ color: '#8384A5' }}>{showPassword ? <VisibilityOff fontSize="small" /> : <Visibility fontSize="small" />}</IconButton></InputAdornment> }}
              sx={{ ...inputSx(), '& .MuiFormHelperText-root': { color: '#E01B4F' } }}
            />
            <TextField label="Confirm Password" size="small" type={showConfirmPassword ? 'text' : 'password'}
              value={formData.confirmPassword} onChange={e => setFormData(p => ({ ...p, confirmPassword: e.target.value }))}
              error={!!errors.confirmPassword} helperText={errors.confirmPassword}
              InputProps={{ endAdornment: <InputAdornment position="end"><IconButton size="small" onClick={() => setShowConfirmPassword(p => !p)} sx={{ color: '#8384A5' }}>{showConfirmPassword ? <VisibilityOff fontSize="small" /> : <Visibility fontSize="small" />}</IconButton></InputAdornment> }}
              sx={{ ...inputSx(), '& .MuiFormHelperText-root': { color: '#E01B4F' } }}
            />
          </Box>
        </DialogContent>
        <DialogActions sx={{ px: 3, py: 2, borderTop: '1px solid #1E2D55', gap: 1 }}>
          <Button onClick={resetForm} sx={{ color: '#8384A5', borderColor: '#1E2D55', '&:hover': { bgcolor: '#162140' } }}>Cancel</Button>
          <Button type="submit" variant="contained" onClick={doSubmit}
            sx={{ bgcolor: '#2B6EF5', '&:hover': { bgcolor: '#1A5CE0' }, fontWeight: 700 }}>
            {editingAdmin ? 'Update Client' : 'Add Client'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* ── Delete Confirm Dialog ── */}
      <Dialog open={!!deleteTarget} onClose={() => setDeleteTarget(null)} maxWidth="xs" fullWidth
        PaperProps={{ sx: { bgcolor: '#0E1831', border: '1px solid #1E2D55', borderRadius: 2 } }}>
        <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1.5, borderBottom: '1px solid #1E2D55', pb: 1.5 }}>
          <Box sx={{ width: 36, height: 36, borderRadius: 1.5, bgcolor: 'rgba(224,27,79,0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <Delete sx={{ color: '#E01B4F', fontSize: 20 }} />
          </Box>
          <Typography sx={{ color: '#F9F9F9', fontWeight: 700 }}>Delete Client</Typography>
        </DialogTitle>
        <DialogContent sx={{ pt: 2 }}>
          <Typography sx={{ color: '#8384A5', fontSize: '0.9rem', mb: 2 }}>
            Are you sure you want to delete <strong style={{ color: '#F9F9F9' }}>{deleteTarget?.firstName} {deleteTarget?.lastName}</strong>? This action cannot be undone.
          </Typography>
          <Box sx={{ bgcolor: 'rgba(224,27,79,0.08)', border: '1px solid rgba(224,27,79,0.3)', borderRadius: 1.5, p: 1.5, display: 'flex', gap: 1 }}>
            <Warning sx={{ color: '#E01B4F', fontSize: 18, flexShrink: 0, mt: 0.1 }} />
            <Typography sx={{ color: '#E01B4F', fontSize: '0.78rem' }}>This will permanently remove the client and all associated data.</Typography>
          </Box>
        </DialogContent>
        <DialogActions sx={{ px: 3, py: 2, borderTop: '1px solid #1E2D55', gap: 1 }}>
          <Button onClick={() => setDeleteTarget(null)} sx={{ color: '#8384A5', '&:hover': { bgcolor: '#162140' } }}>Cancel</Button>
          <Button variant="contained" onClick={confirmDelete}
            sx={{ bgcolor: '#E01B4F', '&:hover': { bgcolor: '#C0153F' }, fontWeight: 700 }}>
            Delete
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar open={snack.open} autoHideDuration={3000} onClose={() => setSnack(s => ({ ...s, open: false }))} anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}>
        <Alert severity={snack.severity} sx={{ bgcolor: snack.severity === 'success' ? '#0E2B1F' : '#2B0E1A', color: snack.severity === 'success' ? '#0ECC68' : '#E01B4F', border: `1px solid ${snack.severity === 'success' ? '#0ECC68' : '#E01B4F'}` }}>
          {snack.msg}
        </Alert>
      </Snackbar>
    </Box>
  );
};

/* ══════════════════════════════════════════════
   Tabs definition
══════════════════════════════════════════════ */
const tabs = [
  { id: 'dashboard',         label: 'Dashboard',         icon: <BarChart sx={{ fontSize: 16 }} /> },
  { id: 'agents',            label: 'Agent Listing',     icon: <ListAlt sx={{ fontSize: 16 }} /> },
  { id: 'staff-portal',      label: 'Staff Portal',      icon: <PersonAdd sx={{ fontSize: 16 }} /> },
  { id: 'myaccount',         label: 'My Account',        icon: <AccountCircle sx={{ fontSize: 16 }} /> },
  { id: 'access',            label: 'Executives',        icon: <AdminPanelSettings sx={{ fontSize: 16 }} /> },
  // SuperAdmin-only; the tab renders its own access message for everyone else,
  // matching how the Executives tab gates itself.
  { id: 'marketing-users',   label: 'Marketing',         icon: <Insights sx={{ fontSize: 16 }} /> },
];

/* ══════════════════════════════════════════════
   Layout
══════════════════════════════════════════════ */
const AdminManagementLayout = () => {
  return (
    <Box sx={{ width: '100%' }}>
      {/* Tab bar */}
      <Box sx={{ bgcolor: '#0E1831', borderBottom: '1px solid #1E2D55', overflowX: 'auto', '&::-webkit-scrollbar': { display: 'none' } }}>
        <Box sx={{ display: 'flex' }}>
          {tabs.map(tab => (
            <NavLink key={tab.id} to={tab.id} end style={{ textDecoration: 'none' }}>
              {({ isActive }) => (
                <Box
                  sx={{
                    display: 'flex', alignItems: 'center', gap: 0.75,
                    px: 2.5, py: 1.5, whiteSpace: 'nowrap', cursor: 'pointer',
                    color: isActive ? '#2B6EF5' : '#8384A5',
                    bgcolor: isActive ? 'rgba(43,110,245,0.08)' : 'transparent',
                    borderBottom: isActive ? '2px solid #2B6EF5' : '2px solid transparent',
                    fontSize: '0.8rem', fontWeight: isActive ? 700 : 400,
                    transition: 'all 150ms ease',
                    '&:hover': { color: isActive ? '#2B6EF5' : '#F9F9F9', bgcolor: isActive ? 'rgba(43,110,245,0.08)' : '#162140' },
                  }}
                >
                  {tab.icon}
                  <Typography sx={{ fontSize: '0.8rem', fontWeight: 'inherit', color: 'inherit' }}>{tab.label}</Typography>
                </Box>
              )}
            </NavLink>
          ))}
        </Box>
      </Box>

      {/* Content */}
      <Box sx={{ bgcolor: '#0C0D1D', minHeight: '100vh' }}>
        <Outlet />
      </Box>
    </Box>
  );
};

export default AdminManagementLayout;
