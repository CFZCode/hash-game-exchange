import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Box, Tab, Tabs } from '@mui/material';
import { C } from '../admin-dashboard/shared';
import * as api from '../../services/branchApi';
import type { CasinoRow, SportsBetRow } from '../../services/branchApi';
import { DataTable, ErrorBox, FilterBar, PageTitle, Pager, StatusChip, fmt, fmtDate, useFilters, useLoad } from './ui';
import type { Col } from './ui';

type Kind = 'sports' | 'casino';

const resultStatus = (r: SportsBetRow) => {
  const v = (r.result || '').toLowerCase();
  if (v === 'won' || v === 'win') return 'success';
  if (v === 'lost' || v === 'lose' || v === 'loss') return 'failed';
  if (v.startsWith('refund') || v.startsWith('void')) return 'refund';
  return 'pending';
};

/** Individual sports bets or casino transactions, newest first. */
export const BetsList: React.FC<{ kind: Kind; userId?: string }> = ({ kind, userId }) => {
  const { filters } = useFilters();
  const [page, setPage] = useState(1);
  useEffect(() => setPage(1), [filters, kind]);
  const list = useLoad(() => api.listBets<SportsBetRow | CasinoRow>({ ...filters, kind, userId, page, limit: 50 }), [filters, kind, userId, page]);
  const player = (r: { user: string; user_id: string }) => <Box><Box sx={{ fontWeight: 700 }}>{r.user}</Box><Box sx={{ color: '#8384A5', fontSize: 11 }}>ID {r.user_id}</Box></Box>;

  const sportsCols: Col<SportsBetRow>[] = [
    { label: 'Placed', render: (r) => fmtDate(r.ts) },
    ...(!userId ? [{ label: 'Player', render: player }] : []),
    { label: 'Match', render: (r) => <Box sx={{ whiteSpace: 'normal', minWidth: 180 }}>{r.match}</Box> },
    { label: 'Market', render: (r) => r.market },
    { label: 'Selection', render: (r) => <Box sx={{ whiteSpace: 'normal', minWidth: 120 }}>{r.selection}</Box> },
    { label: 'Side', render: (r) => <Box sx={{ textTransform: 'uppercase', fontWeight: 700, color: /lay|no/i.test(r.side) ? '#F99BB0' : '#8EC5FF' }}>{r.side}</Box> },
    { label: 'Odds', align: 'right', render: (r) => r.odds },
    { label: 'Stake', align: 'right', render: (r) => <b>{fmt(r.stake)}</b> },
    { label: 'Status', render: (r) => r.status === 'closed' ? <StatusChip status={resultStatus(r)} label={r.result || 'settled'} /> : <StatusChip status="pending" label={r.status} /> },
  ];
  const casinoCols: Col<CasinoRow>[] = [
    { label: 'Time', render: (r) => fmtDate(r.ts) },
    ...(!userId ? [{ label: 'Player', render: player }] : []),
    { label: 'Game', render: (r) => <Box sx={{ maxWidth: 260, overflow: 'hidden', textOverflow: 'ellipsis' }}>{r.game}</Box> },
    { label: 'Action', render: (r) => <Box sx={{ textTransform: 'capitalize' }}>{r.action}</Box> },
    { label: 'Round', render: (r) => <Box sx={{ fontFamily: 'monospace', fontSize: 11 }}>{r.round || '—'}</Box> },
    { label: 'Amount', align: 'right', render: (r) => <Box sx={{ fontWeight: 700, color: r.amount > 0 ? C.success : r.amount < 0 ? C.error : C.textSecondary }}>{r.amount > 0 ? '+' : ''}{fmt(r.amount)}</Box> },
  ];

  const rows = list.data?.rows || [];
  return (
    <Box>
      <ErrorBox error={list.error} onRetry={list.reload} />
      {kind === 'sports'
        ? <DataTable cols={sportsCols} rows={rows as SportsBetRow[]} loading={list.loading} rowKey={(r) => r.id} empty="No sports bets in this period" />
        : <DataTable cols={casinoCols} rows={rows as CasinoRow[]} loading={list.loading} rowKey={(r) => r.id} empty="No casino play in this period" />}
      <Pager page={page} totalPages={list.data?.totalPages || 1} total={list.data?.total} onChange={setPage} />
    </Box>
  );
};

const BetsPage: React.FC = () => {
  const [sp, setSp] = useSearchParams();
  const kind: Kind = sp.get('kind') === 'casino' ? 'casino' : 'sports';
  const setKind = (k: Kind) => { const n = new URLSearchParams(sp); n.set('kind', k); setSp(n, { replace: true }); };
  return (
    <Box>
      <PageTitle title="Sports & Casino" subtitle="Every bet placed by your players in the selected period" />
      <FilterBar />
      <Tabs value={kind} onChange={(_, v) => setKind(v)} sx={{ mb: 1.5, '& .MuiTab-root': { textTransform: 'none', fontWeight: 700 } }}>
        <Tab value="sports" label="Sports bets" />
        <Tab value="casino" label="Casino" />
      </Tabs>
      <BetsList kind={kind} />
    </Box>
  );
};

export default BetsPage;
