import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Box, Button, InputAdornment, TextField } from '@mui/material';
import { PersonAdd, Search } from '@mui/icons-material';
import * as api from '../../services/branchApi';
import type { Player } from '../../services/branchApi';
import {
  DataTable, ErrorBox, FilterBar, LockedChip, PageTitle, Pager, Pnl, fmt, fmtDate, fmtInt, useBranch, useFilters, useLoad,
} from './ui';
import type { Col } from './ui';
import { CreatePlayerDialog } from './dialogs';

const PlayersPage: React.FC = () => {
  const { base, kind } = useBranch();
  const navigate = useNavigate();
  const { filters, sp } = useFilters();
  const [search, setSearch] = useState('');
  const [query, setQuery] = useState('');
  const [page, setPage] = useState(1);
  const [creating, setCreating] = useState(false);

  // Debounce the search box.
  useEffect(() => { const t = setTimeout(() => { setQuery(search.trim()); setPage(1); }, 350); return () => clearTimeout(t); }, [search]);
  useEffect(() => setPage(1), [filters]);

  const list = useLoad(() => api.listPlayers({ ...filters, search: query, page, limit: 25 }), [filters, query, page]);
  const open = (p: Player) => navigate(`${base}/players/${p.id}?${sp}`);

  const cols: Col<Player>[] = [
    { label: 'Player', render: (p) => <Box><Box sx={{ fontWeight: 700 }}>{p.username}</Box><Box sx={{ color: '#8384A5', fontSize: 11 }}>ID {p.id}</Box></Box> },
    ...(kind !== 'sub' ? [{ label: 'Sub branch', render: (p: Player) => <Box><Box>{p.staff_name}</Box><Box sx={{ color: '#8384A5', fontSize: 11 }}>{p.staff_code}</Box></Box> }] : []),
    { label: 'Status', render: (p) => <LockedChip locked={p.locked} /> },
    { label: 'Wallet', align: 'right', render: (p) => fmt(p.wallet) },
    { label: 'Deposit', align: 'right', render: (p) => <Box><Box>{fmt(p.deposit)}</Box><Box sx={{ color: '#8384A5', fontSize: 11 }}>{fmtInt(p.deposit_count)} txns{p.deposit_pending_count ? ` · ${p.deposit_pending_count} pending` : ''}</Box></Box> },
    { label: 'Withdraw', align: 'right', render: (p) => <Box><Box>{fmt(p.withdraw)}</Box><Box sx={{ color: '#8384A5', fontSize: 11 }}>{fmtInt(p.withdraw_count)} txns{p.withdraw_pending_count ? ` · ${p.withdraw_pending_count} pending` : ''}</Box></Box> },
    { label: 'Sports', align: 'right', render: (p) => <Box><Pnl v={p.sports_pnl} /><Box sx={{ color: '#8384A5', fontSize: 11 }}>{fmtInt(p.sports_bets)} bets · {fmt(p.sports_stake)}</Box></Box> },
    { label: 'Casino', align: 'right', render: (p) => <Box><Pnl v={p.casino_pnl} /><Box sx={{ color: '#8384A5', fontSize: 11 }}>{fmtInt(p.casino_bets)} bets · {fmt(p.casino_staked)}</Box></Box> },
    { label: 'Joined', render: (p) => fmtDate(p.created) },
    { label: 'Last login', render: (p) => fmtDate(p.last_login_at) },
  ];

  return (
    <Box>
      <PageTitle title="Players" subtitle="Deposit, withdraw and play figures cover the selected period · P/L is the player's (+ = player won)"
        action={kind !== 'branch' && <Button variant="contained" startIcon={<PersonAdd />} onClick={() => setCreating(true)}>New Player</Button>} />
      <FilterBar>
        <TextField size="small" placeholder="Search username / ID / phone" value={search} onChange={(e) => setSearch(e.target.value)}
          InputProps={{ startAdornment: <InputAdornment position="start"><Search fontSize="small" /></InputAdornment> }} />
      </FilterBar>
      <ErrorBox error={list.error} onRetry={list.reload} />
      <DataTable cols={cols} rows={list.data?.players || []} loading={list.loading} onRowClick={open} rowKey={(p) => p.id} empty="No players found" />
      <Pager page={page} totalPages={list.data?.totalPages || 1} total={list.data?.total} onChange={setPage} />
      {kind !== 'branch' && <CreatePlayerDialog open={creating} onClose={() => setCreating(false)} onDone={list.reload} />}
    </Box>
  );
};

export default PlayersPage;
