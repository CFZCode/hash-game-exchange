import React, { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Box, Button, Paper, Tab, Tabs, Typography } from '@mui/material';
import { ArrowBack } from '@mui/icons-material';
import { C } from '../admin-dashboard/shared';
import * as api from '../../services/branchApi';
import type { Stats } from '../../services/branchApi';
import { ErrorBox, FilterBar, LockedChip, Pnl, Tile, Tiles, fmt, fmtDate, fmtInt, useBranch, useFilters, useLoad } from './ui';
import { DailyTable } from './DailyReport';
import { TransactionsList } from './TransactionsPage';
import { BetsList } from './BetsPage';

type TabKey = 'daily' | 'deposit' | 'withdraw' | 'sports' | 'casino';

const Lifetime: React.FC<{ s: Stats }> = ({ s }) => (
  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 3, color: C.textSecondary, fontSize: 12.5 }}>
    <span>Lifetime deposit <b style={{ color: C.text }}>{fmt(s.deposit)}</b></span>
    <span>Lifetime withdraw <b style={{ color: C.text }}>{fmt(s.withdraw)}</b></span>
    <span>Sports P/L <Pnl v={s.sports_pnl} /></span>
    <span>Casino P/L <Pnl v={s.casino_pnl} /></span>
    <span>Total bets <b style={{ color: C.text }}>{fmtInt(s.sports_bets + s.casino_bets)}</b></span>
  </Box>
);

/** Full report for one player: period totals, day-wise, money and bets. */
const PlayerReport: React.FC = () => {
  const { id = '' } = useParams();
  const { base } = useBranch();
  const navigate = useNavigate();
  const { filters, sp } = useFilters();
  const [tab, setTab] = useState<TabKey>('daily');
  const d = useLoad(() => api.getPlayer(id, filters), [id, filters]);
  const p = d.data?.player;
  const s = d.data?.stats;

  return (
    <Box>
      <Button startIcon={<ArrowBack />} onClick={() => navigate(`${base}/players?${sp}`)} sx={{ mb: 1, color: C.textSecondary, textTransform: 'none' }}>
        All players
      </Button>
      <ErrorBox error={d.error} onRetry={d.reload} />

      <Paper elevation={0} sx={{ p: 2, mb: 2, bgcolor: C.card, border: `1px solid ${C.border}`, borderRadius: 2 }}>
        <Box sx={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: 1.5, mb: 1 }}>
          <Typography sx={{ color: C.text, fontWeight: 800, fontSize: '1.3rem' }}>{p?.username || '…'}</Typography>
          {p && <LockedChip locked={p.locked} />}
          <Typography sx={{ color: C.textSecondary, fontSize: 13, ml: { md: 'auto' } }}>
            Wallet <b style={{ color: C.text, fontSize: 16 }}>{fmt(p?.wallet)}</b>
          </Typography>
        </Box>
        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 3, color: C.textSecondary, fontSize: 12.5, mb: 1.5 }}>
          <span>ID <b style={{ color: C.text }}>{p?.id}</b></span>
          <span>Sub branch <b style={{ color: C.text }}>{p?.staff_name}</b> {p?.staff_code ? `(${p.staff_code})` : ''}</span>
          {p?.phone && <span>Phone <b style={{ color: C.text }}>{p.phone}</b></span>}
          {p?.email && <span>Email <b style={{ color: C.text }}>{p.email}</b></span>}
          <span>Joined <b style={{ color: C.text }}>{fmtDate(p?.created)}</b></span>
          <span>Last login <b style={{ color: C.text }}>{fmtDate(p?.last_login_at)}</b></span>
        </Box>
        {d.data?.lifetime && <Lifetime s={d.data.lifetime} />}
      </Paper>

      <FilterBar scope={false} />

      <Tiles>
        <Tile label="Deposited" accent={C.success} loading={d.loading} value={fmt(s?.deposit)}
          sub={`${fmtInt(s?.deposit_count)} ok · ${fmtInt(s?.deposit_pending_count)} pending · ${fmtInt(s?.deposit_failed_count)} failed`} onClick={() => setTab('deposit')} />
        <Tile label="Withdrawn" accent={C.error} loading={d.loading} value={fmt(s?.withdraw)}
          sub={`${fmtInt(s?.withdraw_count)} ok · ${fmtInt(s?.withdraw_pending_count)} pending · ${fmtInt(s?.withdraw_failed_count)} failed`} onClick={() => setTab('withdraw')} />
        <Tile label="Sports P/L" accent={C.info} loading={d.loading} value={<Pnl v={s?.sports_pnl || 0} />}
          sub={`${fmtInt(s?.sports_bets)} bets · stake ${fmt(s?.sports_stake)} · ${fmtInt(s?.sports_open_bets)} open`} onClick={() => setTab('sports')} />
        <Tile label="Casino P/L" accent="#7B5EF5" loading={d.loading} value={<Pnl v={s?.casino_pnl || 0} />}
          sub={`${fmtInt(s?.casino_bets)} bets · staked ${fmt(s?.casino_staked)} · won ${fmt(s?.casino_won)}`} onClick={() => setTab('casino')} />
      </Tiles>

      <Tabs value={tab} onChange={(_, v) => setTab(v)} variant="scrollable" sx={{ mb: 1.5, '& .MuiTab-root': { textTransform: 'none', fontWeight: 700 } }}>
        <Tab value="daily" label="Day-wise" />
        <Tab value="deposit" label="Deposits" />
        <Tab value="withdraw" label="Withdrawals" />
        <Tab value="sports" label="Sports bets" />
        <Tab value="casino" label="Casino" />
      </Tabs>
      {tab === 'daily' && <DailyTable userId={id} />}
      {(tab === 'deposit' || tab === 'withdraw') && <TransactionsList key={tab} type={tab} userId={id} />}
      {(tab === 'sports' || tab === 'casino') && <BetsList kind={tab} userId={id} />}
    </Box>
  );
};

export default PlayerReport;
