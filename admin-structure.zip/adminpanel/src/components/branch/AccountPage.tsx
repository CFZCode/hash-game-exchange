import React, { useState } from 'react';
import { Alert, Box, Button, CircularProgress, Paper, TextField, Typography } from '@mui/material';
import { C } from '../admin-dashboard/shared';
import * as api from '../../services/branchApi';
import { CopyText, ErrorBox, PageTitle, fmtDate, useLoad } from './ui';

/** Own profile, signup code / link, and password change. */
const AccountPage: React.FC = () => {
  const me = useLoad(() => api.getMe(), []);
  const [pw, setPw] = useState({ old: '', next: '', again: '' });
  const [saving, setSaving] = useState(false);
  const [result, setResult] = useState<{ ok: boolean; msg: string } | null>(null);
  const m = me.data?.me;

  const change = async () => {
    if (pw.next !== pw.again) { setResult({ ok: false, msg: 'New passwords do not match' }); return; }
    setSaving(true); setResult(null);
    try {
      await api.changeMyPassword(pw.old, pw.next);
      setResult({ ok: true, msg: 'Password updated' });
      setPw({ old: '', next: '', again: '' });
    } catch (e) {
      setResult({ ok: false, msg: e instanceof Error ? e.message : 'Failed' });
    } finally { setSaving(false); }
  };

  const row = (k: string, v: React.ReactNode) => (
    <Box sx={{ display: 'flex', gap: 2, py: 0.75, borderBottom: `1px solid ${C.border}` }}>
      <Typography sx={{ color: C.textSecondary, fontSize: 13, width: 130, flexShrink: 0 }}>{k}</Typography>
      <Typography component="div" sx={{ color: C.text, fontSize: 13, fontWeight: 600, wordBreak: 'break-all' }}>{v}</Typography>
    </Box>
  );

  return (
    <Box sx={{ maxWidth: 640 }}>
      <PageTitle title="My Account" />
      <ErrorBox error={me.error} onRetry={me.reload} />
      <Paper elevation={0} sx={{ p: 2.5, mb: 2, bgcolor: C.card, border: `1px solid ${C.border}`, borderRadius: 2 }}>
        {row('Name', m?.name)}
        {row('Login ID', m?.login)}
        {row('Role', m?.role === 'SubBranch' ? 'Sub Branch' : 'Branch Admin')}
        {row('Under', m?.parent_name)}
        {m?.code && row('Signup code', <CopyText text={m.code} />)}
        {m?.code && row('Signup link', <CopyText text={api.signupLink(m.code)} />)}
        {row('Created', fmtDate(m?.created_at))}
        <Typography sx={{ color: C.textSecondary, fontSize: 12, mt: 1.5 }}>
          {m?.code
            ? 'Players who register on the site with your code are added under you automatically.'
            : 'Players join through your sub branches\' signup codes. Create a sub branch to get a code.'}
        </Typography>
      </Paper>
      <Paper elevation={0} sx={{ p: 2.5, bgcolor: C.card, border: `1px solid ${C.border}`, borderRadius: 2, display: 'flex', flexDirection: 'column', gap: 2 }}>
        <Typography sx={{ color: C.text, fontWeight: 700 }}>Change password</Typography>
        {result && <Alert severity={result.ok ? 'success' : 'error'}>{result.msg}</Alert>}
        <TextField type="password" label="Current password" value={pw.old} onChange={(e) => setPw({ ...pw, old: e.target.value })} />
        <TextField type="password" label="New password" value={pw.next} onChange={(e) => setPw({ ...pw, next: e.target.value })} helperText="Min 6 characters" />
        <TextField type="password" label="Repeat new password" value={pw.again} onChange={(e) => setPw({ ...pw, again: e.target.value })} />
        <Button variant="contained" onClick={change} disabled={saving || !pw.old || pw.next.length < 6} sx={{ alignSelf: 'flex-start' }}>
          {saving ? <CircularProgress size={20} /> : 'Update password'}
        </Button>
      </Paper>
    </Box>
  );
};

export default AccountPage;
