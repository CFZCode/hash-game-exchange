import React, { useEffect, useState } from 'react';
import { Outlet, Navigate, NavLink, useNavigate, useLocation } from 'react-router-dom';
import { Box, AppBar, Toolbar, Typography, Button, Avatar, Chip, alpha } from '@mui/material';
import {
  AccountTreeOutlined, LogoutOutlined, DashboardOutlined, HubOutlined, GroupsOutlined,
  SouthWestOutlined, NorthEastOutlined, CalendarMonthOutlined, SportsSoccerOutlined, PersonOutline, ApartmentOutlined,
} from '@mui/icons-material';
import { C } from '../admin-dashboard/shared';
import { BranchContext } from './ui';
import type { BranchKind } from '../../services/branchApi';
import { getBranchToken, getBranchUser, clearBranchSession, kindOfRole } from '../../services/branchApi';

interface NavItem { to: string; label: string; icon: React.ReactNode; kinds: BranchKind[]; panelOnly?: boolean }

const ALL: BranchKind[] = ['owner', 'branch', 'sub'];
const NAV: NavItem[] = [
  { to: '', label: 'Dashboard', icon: <DashboardOutlined sx={{ fontSize: 18 }} />, kinds: ALL },
  { to: 'branches', label: 'Branches', icon: <ApartmentOutlined sx={{ fontSize: 18 }} />, kinds: ['owner'] },
  { to: 'sub-branches', label: 'Sub Branches', icon: <HubOutlined sx={{ fontSize: 18 }} />, kinds: ['owner', 'branch'] },
  { to: 'players', label: 'Players', icon: <GroupsOutlined sx={{ fontSize: 18 }} />, kinds: ALL },
  { to: 'deposits', label: 'Deposits', icon: <SouthWestOutlined sx={{ fontSize: 18 }} />, kinds: ALL },
  { to: 'withdrawals', label: 'Withdrawals', icon: <NorthEastOutlined sx={{ fontSize: 18 }} />, kinds: ALL },
  { to: 'daily', label: 'Day-wise Report', icon: <CalendarMonthOutlined sx={{ fontSize: 18 }} />, kinds: ALL },
  { to: 'bets', label: 'Sports & Casino', icon: <SportsSoccerOutlined sx={{ fontSize: 18 }} />, kinds: ALL },
  { to: 'account', label: 'My Account', icon: <PersonOutline sx={{ fontSize: 18 }} />, kinds: ['branch', 'sub'], panelOnly: true },
];

const SIDEBAR_W = 220;

const NavList: React.FC<{ base: string; kind: BranchKind; panel: boolean; horizontal?: boolean }> = ({ base, kind, panel, horizontal }) => {
  const { search } = useLocation();
  // Carry the period/scope across pages, but not page-specific filters.
  const keep = new URLSearchParams(search);
  const carry = new URLSearchParams();
  ['from', 'to', 'staffId'].forEach((k) => { if (keep.has(k)) carry.set(k, keep.get(k) || ''); });
  const q = carry.toString() ? `?${carry}` : '';
  return (
    <>
      {NAV.filter((n) => n.kinds.includes(kind) && (panel || !n.panelOnly)).map((item) => (
        <NavLink key={item.to} to={`${base}${item.to ? `/${item.to}` : ''}${q}`} end={!item.to} style={{ textDecoration: 'none' }}>
          {({ isActive }) => (
            <Box sx={{
              display: 'flex', alignItems: 'center', gap: 1.2, px: 1.75, py: 1.1, borderRadius: 2, whiteSpace: 'nowrap',
              color: isActive ? C.primaryLight : C.textSecondary,
              bgcolor: isActive ? alpha(C.primary, 0.14) : 'transparent',
              borderLeft: horizontal ? 'none' : { xs: 'none', md: `2px solid ${isActive ? C.primary : 'transparent'}` },
              borderBottom: horizontal ? `2px solid ${isActive ? C.primary : 'transparent'}` : 'none',
              '&:hover': { bgcolor: isActive ? alpha(C.primary, 0.18) : C.cardHover, color: isActive ? C.primaryLight : C.text },
            }}>
              {item.icon}
              <Typography sx={{ fontSize: '0.83rem', fontWeight: isActive ? 700 : 600 }}>{item.label}</Typography>
            </Box>
          )}
        </NavLink>
      ))}
    </>
  );
};

/** Branch panel shell at /branch — its own session, top bar and sidebar. */
export const BranchLayout: React.FC = () => {
  const navigate = useNavigate();
  const user = getBranchUser();
  if (!getBranchToken() || !user) return <Navigate to="/branch/login" replace />;
  const kind = kindOfRole(user.role);

  const logout = () => { clearBranchSession(); navigate('/branch/login', { replace: true }); };

  return (
    <BranchContext.Provider value={{ base: '/branch', kind }}>
      <Box sx={{ minHeight: '100vh', bgcolor: C.bg }}>
        <AppBar position="sticky" elevation={0} sx={{ bgcolor: C.card, borderBottom: `1px solid ${C.border}` }}>
          <Toolbar sx={{ gap: 1.5, flexWrap: 'wrap', py: 1 }}>
            <Avatar sx={{ bgcolor: alpha(C.success, 0.15), color: C.success, width: 38, height: 38 }}>
              <AccountTreeOutlined fontSize="small" />
            </Avatar>
            <Box sx={{ mr: 'auto', minWidth: 0 }}>
              <Typography sx={{ color: C.text, fontWeight: 800, fontSize: '1rem', lineHeight: 1.2 }}>Branch Panel</Typography>
              <Typography noWrap sx={{ color: C.textSecondary, fontSize: '0.72rem' }}>Signed in as {user.name}</Typography>
            </Box>
            <Chip size="small" label={kind === 'sub' ? 'Sub Branch' : 'Branch Admin'}
              sx={{ bgcolor: alpha(C.info, 0.14), color: C.info, fontWeight: 700, fontSize: '0.7rem' }} />
            <Button onClick={logout} startIcon={<LogoutOutlined />}
              sx={{ color: C.textSecondary, textTransform: 'none', fontWeight: 600, '&:hover': { color: C.error, bgcolor: alpha(C.error, 0.08) } }}>
              Sign out
            </Button>
          </Toolbar>
        </AppBar>
        <Box sx={{ display: { xs: 'block', md: 'flex' }, alignItems: 'flex-start' }}>
          <Box component="nav" sx={{
            width: { xs: '100%', md: SIDEBAR_W }, flexShrink: 0, position: { xs: 'static', md: 'sticky' }, top: 64,
            borderRight: { xs: 'none', md: `1px solid ${C.border}` }, borderBottom: { xs: `1px solid ${C.border}`, md: 'none' },
            bgcolor: C.card, minHeight: { md: 'calc(100vh - 64px)' }, p: 1.5, display: 'flex',
            flexDirection: { xs: 'row', md: 'column' }, gap: 0.5, overflowX: { xs: 'auto', md: 'visible' },
          }}>
            <NavList base="/branch" kind={kind} panel />
          </Box>
          <Box sx={{ flex: 1, minWidth: 0, p: { xs: 2, md: 3 } }}>
            <Outlet />
          </Box>
        </Box>
      </Box>
    </BranchContext.Provider>
  );
};

/** Super admin's Branch Management inside the admin panel at /branch-management. */
export const AdminBranchShell: React.FC = () => {
  const [role] = useState(() => localStorage.getItem('userRole'));
  const [execId] = useState(() => localStorage.getItem('executiveId'));
  useEffect(() => { document.title = 'Branch Management'; }, []);
  if (role !== 'SuperAdmin' || execId) return <Navigate to="/admin-management" replace />;
  return (
    <BranchContext.Provider value={{ base: '/branch-management', kind: 'owner' }}>
      <Box sx={{ p: { xs: 1, md: 2 } }}>
        <Box component="nav" sx={{ display: 'flex', gap: 0.5, overflowX: 'auto', mb: 2, borderBottom: `1px solid ${C.border}` }}>
          <NavList base="/branch-management" kind="owner" panel={false} horizontal />
        </Box>
        <Outlet />
      </Box>
    </BranchContext.Provider>
  );
};
