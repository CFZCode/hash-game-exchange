// Shared pieces for the branch screens (branch panel + super admin's Branch
// Management). Filters live in the URL (?staffId&from&to) so every page,
// refresh and copied link keeps the same scope and period.
import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  Box, Button, Chip, IconButton, MenuItem, Pagination, Paper, Skeleton, Table, TableBody,
  TableCell, TableContainer, TableHead, TableRow, TextField, Tooltip, Typography, alpha,
} from '@mui/material';
import { ContentCopy } from '@mui/icons-material';
import { C } from '../admin-dashboard/shared';
import * as api from '../../services/branchApi';
import type { BranchKind, BranchStaff } from '../../services/branchApi';

/* ─── context ─────────────────────────────────────────────────── */

export interface BranchCtx {
  /** '/branch' in the branch panel, '/branch-management' in the admin panel */
  base: string;
  kind: BranchKind;
}
export const BranchContext = createContext<BranchCtx>({ base: '/branch', kind: 'branch' });
export const useBranch = () => useContext(BranchContext);

/* ─── formatting ──────────────────────────────────────────────── */

export const fmt = (n: number | string | null | undefined) =>
  `₹${Number(n || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;
export const fmtInt = (n: number | null | undefined) => Number(n || 0).toLocaleString('en-IN');
export const fmtDate = (d: string | null | undefined) =>
  d ? new Date(d).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }) : '—';
export const fmtDay = (d: string) =>
  new Date(`${d}T00:00:00`).toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });

/** Signed amount, green when positive. */
export const Pnl: React.FC<{ v: number; bold?: boolean }> = ({ v, bold }) => (
  <Box component="span" sx={{ color: v > 0 ? C.success : v < 0 ? C.error : C.textSecondary, fontWeight: bold ? 700 : 500, whiteSpace: 'nowrap' }}>
    {v > 0 ? '+' : ''}{fmt(v)}
  </Box>
);

/* ─── filters ─────────────────────────────────────────────────── */

const ymd = (d: Date) => d.toLocaleDateString('en-CA');
const daysAgo = (n: number) => { const d = new Date(); d.setDate(d.getDate() - n); return ymd(d); };

const PRESETS: { key: string; label: string; range: () => [string, string] }[] = [
  { key: 'today', label: 'Today', range: () => [daysAgo(0), daysAgo(0)] },
  { key: 'yesterday', label: 'Yesterday', range: () => [daysAgo(1), daysAgo(1)] },
  { key: '7d', label: '7 days', range: () => [daysAgo(6), daysAgo(0)] },
  { key: '30d', label: '30 days', range: () => [daysAgo(29), daysAgo(0)] },
  { key: 'month', label: 'This month', range: () => { const d = new Date(); return [ymd(new Date(d.getFullYear(), d.getMonth(), 1)), daysAgo(0)]; } },
  { key: 'all', label: 'All time', range: () => ['', ''] },
];

/** Period + scope from the URL. No period in the URL = last 7 days. */
export function useFilters() {
  const [sp, setSp] = useSearchParams();
  const hasPeriod = sp.has('from') || sp.has('to');
  const from = hasPeriod ? sp.get('from') || '' : daysAgo(6);
  const to = hasPeriod ? sp.get('to') || '' : daysAgo(0);
  const staffId = sp.get('staffId') || '';
  const update = (patch: Record<string, string>) => {
    const next = new URLSearchParams(sp);
    if (!hasPeriod && !('from' in patch)) { next.set('from', from); next.set('to', to); }
    for (const [k, v] of Object.entries(patch)) next.set(k, v);
    if (!next.get('staffId')) next.delete('staffId');
    setSp(next, { replace: true });
  };
  const filters = useMemo(() => ({ from, to, staffId: staffId || undefined }), [from, to, staffId]);
  return { filters, from, to, staffId, update, sp, setSp };
}

let scopeCache: { key: string; rows: BranchStaff[] } | null = null;

/** Branch / sub branch picker. Hidden for a sub branch (it only sees itself). */
const ScopeSelect: React.FC<{ value: string; onChange: (v: string) => void }> = ({ value, onChange }) => {
  const { kind } = useBranch();
  const cacheKey = `${kind}`;
  const [rows, setRows] = useState<BranchStaff[]>(scopeCache?.key === cacheKey ? scopeCache.rows : []);
  useEffect(() => {
    if (kind === 'sub') return;
    api.listSubBranches({ from: '', to: '' }).then((r) => {
      scopeCache = { key: cacheKey, rows: r.subBranches };
      setRows(r.subBranches);
    }).catch(() => {});
  }, [kind, cacheKey]);
  if (kind === 'sub') return null;
  const branches = rows.filter(r => r.role === 'BranchAdmin');
  const subsOf = (id: number) => rows.filter(r => r.role === 'SubBranch' && r.parent_id === id);
  return (
    <TextField select size="small" label="Branch" value={value} onChange={(e) => onChange(e.target.value)} sx={{ minWidth: 220 }}
      SelectProps={{ displayEmpty: true }} InputLabelProps={{ shrink: true }}>
      <MenuItem value="">{kind === 'owner' ? 'All branches' : 'My whole branch'}</MenuItem>
      {branches.flatMap((b) => [
        // A branch admin's own id is the same scope as "My whole branch".
        ...(kind === 'owner' ? [
          <MenuItem key={b.id} value={String(b.id)} sx={{ fontWeight: 700 }}>
            {b.name} — whole branch{b.locked ? ' (locked)' : ''}
          </MenuItem>,
        ] : []),
        ...subsOf(b.id).map((s) => (
          <MenuItem key={s.id} value={String(s.id)} sx={{ pl: 4 }}>
            {s.name} · {s.code}{s.locked ? ' (locked)' : ''}
          </MenuItem>
        )),
      ])}
    </TextField>
  );
};

export const FilterBar: React.FC<{ scope?: boolean; children?: React.ReactNode }> = ({ scope = true, children }) => {
  const { from, to, staffId, update } = useFilters();
  const active = PRESETS.find((p) => { const [f, t] = p.range(); return f === from && t === to; })?.key;
  return (
    <Paper elevation={0} sx={{ p: 1.5, mb: 2, bgcolor: C.card, border: `1px solid ${C.border}`, borderRadius: 2, display: 'flex', flexWrap: 'wrap', gap: 1.25, alignItems: 'center' }}>
      <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.75 }}>
        {PRESETS.map((p) => (
          <Chip key={p.key} label={p.label} size="small" clickable
            onClick={() => { const [f, t] = p.range(); update({ from: f, to: t }); }}
            sx={{
              fontWeight: 600, fontSize: '0.74rem',
              bgcolor: active === p.key ? alpha(C.primary, 0.22) : C.cardLight,
              color: active === p.key ? C.primaryLight : C.textSecondary,
              border: `1px solid ${active === p.key ? C.primary : C.border}`,
            }} />
        ))}
      </Box>
      <TextField size="small" type="date" label="From" value={from} InputLabelProps={{ shrink: true }}
        onChange={(e) => update({ from: e.target.value })} sx={{ width: 160 }} />
      <TextField size="small" type="date" label="To" value={to} InputLabelProps={{ shrink: true }}
        onChange={(e) => update({ to: e.target.value })} sx={{ width: 160 }} />
      {scope && <ScopeSelect value={staffId} onChange={(v) => update({ staffId: v })} />}
      {children}
    </Paper>
  );
};

/* ─── layout bits ─────────────────────────────────────────────── */

export const PageTitle: React.FC<{ title: string; subtitle?: string; action?: React.ReactNode }> = ({ title, subtitle, action }) => (
  <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2, flexWrap: 'wrap' }}>
    <Box sx={{ mr: 'auto' }}>
      <Typography sx={{ color: C.text, fontWeight: 800, fontSize: '1.3rem' }}>{title}</Typography>
      {subtitle && <Typography sx={{ color: C.textSecondary, fontSize: '0.8rem' }}>{subtitle}</Typography>}
    </Box>
    {action}
  </Box>
);

export const Tile: React.FC<{ label: string; value: React.ReactNode; sub?: React.ReactNode; accent?: string; loading?: boolean; onClick?: () => void }> = ({ label, value, sub, accent = C.primary, loading, onClick }) => (
  <Paper elevation={0} onClick={onClick}
    sx={{
      p: 2, flex: '1 1 200px', minWidth: 0, bgcolor: C.card, border: `1px solid ${C.border}`, borderRadius: 2,
      borderTop: `3px solid ${accent}`, cursor: onClick ? 'pointer' : 'default',
      '&:hover': onClick ? { borderColor: accent } : undefined,
    }}>
    <Typography sx={{ color: C.textSecondary, fontSize: '0.75rem', fontWeight: 600, mb: 0.5 }}>{label}</Typography>
    {loading
      ? <Skeleton width="60%" height={32} sx={{ bgcolor: C.cardHover }} />
      : <Typography component="div" sx={{ color: C.text, fontWeight: 800, fontSize: '1.35rem', lineHeight: 1.25 }}>{value}</Typography>}
    {sub && !loading && <Typography component="div" sx={{ color: C.textMuted, fontSize: '0.72rem', mt: 0.5 }}>{sub}</Typography>}
  </Paper>
);

export const Tiles: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1.5, mb: 2 }}>{children}</Box>
);

export const headSx = { color: C.textSecondary, fontSize: 12, fontWeight: 700, borderBottom: `1px solid ${C.border}`, whiteSpace: 'nowrap' as const, bgcolor: C.cardLight };
export const cellSx = { color: C.text, fontSize: 13, borderBottom: `1px solid ${C.border}`, whiteSpace: 'nowrap' as const };

export interface Col<T> { label: string; render: (r: T) => React.ReactNode; align?: 'left' | 'right' | 'center' }

export function DataTable<T>({ cols, rows, loading, empty = 'Nothing to show for this period', onRowClick, footer, rowKey }: {
  cols: Col<T>[]; rows: T[]; loading?: boolean; empty?: string; onRowClick?: (r: T) => void;
  footer?: React.ReactNode; rowKey: (r: T, i: number) => string;
}) {
  return (
    <TableContainer component={Paper} elevation={0} sx={{ bgcolor: C.card, border: `1px solid ${C.border}`, borderRadius: 2 }}>
      <Table size="small" stickyHeader>
        <TableHead>
          <TableRow>{cols.map((c) => <TableCell key={c.label} align={c.align} sx={headSx}>{c.label}</TableCell>)}</TableRow>
        </TableHead>
        <TableBody>
          {loading && [0, 1, 2, 3].map((i) => (
            <TableRow key={`s${i}`}>{cols.map((c) => <TableCell key={c.label} sx={cellSx}><Skeleton sx={{ bgcolor: C.cardHover }} /></TableCell>)}</TableRow>
          ))}
          {!loading && rows.length === 0 && (
            <TableRow><TableCell colSpan={cols.length} sx={{ ...cellSx, color: C.textSecondary, textAlign: 'center', py: 4 }}>{empty}</TableCell></TableRow>
          )}
          {!loading && rows.map((r, i) => (
            <TableRow key={rowKey(r, i)} hover={!!onRowClick} onClick={onRowClick ? () => onRowClick(r) : undefined}
              sx={{ cursor: onRowClick ? 'pointer' : 'default', '&:hover td': onRowClick ? { bgcolor: C.cardHover } : undefined }}>
              {cols.map((c) => <TableCell key={c.label} align={c.align} sx={cellSx}>{c.render(r)}</TableCell>)}
            </TableRow>
          ))}
          {!loading && footer}
        </TableBody>
      </Table>
    </TableContainer>
  );
}

export const Pager: React.FC<{ page: number; totalPages: number; total?: number; onChange: (p: number) => void }> = ({ page, totalPages, total, onChange }) => (
  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mt: 1.5, flexWrap: 'wrap', gap: 1 }}>
    <Typography sx={{ color: C.textSecondary, fontSize: 12 }}>{total != null ? `${fmtInt(total)} records` : ''}</Typography>
    {totalPages > 1 && <Pagination page={page} count={totalPages} onChange={(_, p) => onChange(p)} size="small" color="primary" />}
  </Box>
);

const STATUS_COLOR: Record<string, string> = { success: C.success, pending: C.warning, failed: C.error };
export const StatusChip: React.FC<{ status: string; label?: string }> = ({ status, label }) => (
  <Chip size="small" label={label || status}
    sx={{ height: 22, fontSize: 11, fontWeight: 700, textTransform: 'capitalize', bgcolor: alpha(STATUS_COLOR[status] || C.info, 0.15), color: STATUS_COLOR[status] || C.info }} />
);

export const LockedChip: React.FC<{ locked: boolean; viaParent?: boolean }> = ({ locked, viaParent }) =>
  locked || viaParent
    ? <Chip size="small" label={locked ? 'Locked' : 'Branch locked'} sx={{ height: 22, fontSize: 11, fontWeight: 700, bgcolor: alpha(C.error, 0.15), color: C.error }} />
    : <Chip size="small" label="Active" sx={{ height: 22, fontSize: 11, fontWeight: 700, bgcolor: alpha(C.success, 0.15), color: C.success }} />;

export const CopyText: React.FC<{ text: string; label?: React.ReactNode; title?: string }> = ({ text, label, title = 'Copy' }) => {
  const [done, setDone] = useState(false);
  if (!text) return <>—</>;
  return (
    <Box component="span" sx={{ display: 'inline-flex', alignItems: 'center', gap: 0.5 }}>
      {label ?? text}
      <Tooltip title={done ? 'Copied' : title}>
        <IconButton size="small" sx={{ color: C.textSecondary }}
          onClick={(e) => { e.stopPropagation(); navigator.clipboard?.writeText(text); setDone(true); setTimeout(() => setDone(false), 1500); }}>
          <ContentCopy sx={{ fontSize: 14 }} />
        </IconButton>
      </Tooltip>
    </Box>
  );
};

export const ErrorBox: React.FC<{ error: string | null; onRetry?: () => void }> = ({ error, onRetry }) =>
  error ? (
    <Paper elevation={0} sx={{ p: 2, mb: 2, bgcolor: alpha(C.error, 0.1), border: `1px solid ${alpha(C.error, 0.4)}`, borderRadius: 2, display: 'flex', alignItems: 'center', gap: 2 }}>
      <Typography sx={{ color: C.text, fontSize: 13, flex: 1 }}>{error}</Typography>
      {onRetry && <Button size="small" onClick={onRetry}>Retry</Button>}
    </Paper>
  ) : null;

/** Load-on-change helper: re-runs `load` whenever `deps` change. */
export function useLoad<T>(load: () => Promise<T>, deps: React.DependencyList) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [tick, setTick] = useState(0);
  useEffect(() => {
    let live = true;
    setLoading(true); setError(null);
    load().then((d) => { if (live) setData(d); })
      .catch((e) => { if (live) setError(e?.message || 'Failed to load'); })
      .finally(() => { if (live) setLoading(false); });
    return () => { live = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, tick]);
  return { data, loading, error, reload: () => setTick((t) => t + 1) };
}
