import React, { useEffect, useState } from 'react';
import {
  Alert, Box, Button, CircularProgress, Dialog, DialogActions, DialogContent, DialogTitle,
  IconButton, InputAdornment, MenuItem, TextField, Tooltip, Typography,
} from '@mui/material';
import { Casino, ContentCopy } from '@mui/icons-material';
import { C } from '../admin-dashboard/shared';
import * as api from '../../services/branchApi';
import type { BranchStaff, CreatedPlayer } from '../../services/branchApi';
import { useBranch } from './ui';

export type Notify = (msg: string, severity?: 'success' | 'error') => void;

const paper = { sx: { bgcolor: C.card, border: `1px solid ${C.border}`, borderRadius: 2 } };
const titleSx = { color: C.text, borderBottom: `1px solid ${C.border}` };
const contentSx = { pt: '20px !important', display: 'flex', flexDirection: 'column', gap: 2 };
const msg = (e: unknown) => (e instanceof Error ? e.message : 'Request failed');

/** Credentials shown once after creating an account, with copy-all. */
const Credentials: React.FC<{ rows: [string, string][] }> = ({ rows }) => {
  const all = rows.map(([k, v]) => `${k}: ${v}`).join('\n');
  return (
    <Box sx={{ bgcolor: '#10182E', border: `1px solid ${C.border}`, borderRadius: 1.5, p: 2 }}>
      {rows.map(([k, v]) => (
        <Box key={k} sx={{ display: 'flex', gap: 1, py: 0.4, alignItems: 'baseline' }}>
          <Typography sx={{ color: C.textSecondary, fontSize: 12, width: 110, flexShrink: 0 }}>{k}</Typography>
          <Typography sx={{ color: C.text, fontSize: 13, fontWeight: 700, wordBreak: 'break-all' }}>{v}</Typography>
        </Box>
      ))}
      <Button size="small" startIcon={<ContentCopy sx={{ fontSize: 14 }} />} sx={{ mt: 1 }}
        onClick={() => navigator.clipboard?.writeText(all)}>Copy all</Button>
    </Box>
  );
};

/* ─── create branch admin / sub branch ───────────────────────────── */

export const CreateStaffDialog: React.FC<{
  open: boolean; level: 'branch' | 'sub'; defaultBranchId?: number;
  onClose: () => void; onDone: () => void;
}> = ({ open, level, defaultBranchId, onClose, onDone }) => {
  const { kind } = useBranch();
  const [branches, setBranches] = useState<BranchStaff[]>([]);
  useEffect(() => {
    if (open && level === 'sub' && kind === 'owner') api.listBranches({}).then((r) => setBranches(r.branches)).catch(() => {});
  }, [open, level, kind]);
  const blank = { name: '', login: '', password: '', phone: '', code: '', branchId: defaultBranchId ? String(defaultBranchId) : '', txn: '' };
  const [f, setF] = useState(blank);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState<{ name: string; login: string; code: string } | null>(null);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => { if (open) { setF(blank); setError(null); setDone(null); } }, [open]);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF((p) => ({ ...p, [k]: e.target.value }));
  const owner = kind === 'owner';
  const what = level === 'branch' ? 'Branch Admin' : 'Sub Branch';

  const submit = async () => {
    setSaving(true); setError(null);
    try {
      const payload = {
        name: f.name.trim(), login: f.login.trim(), password: f.password, phone: f.phone.trim() || undefined,
        code: f.code.trim() || undefined, transactionPassword: owner ? f.txn : undefined,
      };
      const r = level === 'branch'
        ? (await api.createBranch({ ...payload, transactionPassword: f.txn })).branch
        : (await api.createSubBranch({ ...payload, branchId: owner ? Number(f.branchId) : undefined })).subBranch;
      setDone({ name: r.name, login: r.login, code: r.code });
      onDone();
    } catch (e) { setError(msg(e)); } finally { setSaving(false); }
  };

  const valid = f.name.trim() && f.login.trim().length >= 4 && f.password.length >= 6 && (!owner || f.txn) && (level === 'branch' || !owner || f.branchId);

  return (
    <Dialog open={open} onClose={onClose} maxWidth="xs" fullWidth PaperProps={paper}>
      <DialogTitle sx={titleSx}>New {what}</DialogTitle>
      <DialogContent sx={contentSx}>
        {done ? (
          <>
            <Alert severity="success">{what} created. Share these details — the password is not shown again.</Alert>
            <Credentials rows={[
              ['Name', done.name], ['Login ID', done.login], ['Password', f.password],
              ['Panel', `${window.location.origin}/branch/login`],
              ...(level === 'sub' ? [['Signup code', done.code], ['Signup link', api.signupLink(done.code)]] as [string, string][] : []),
            ]} />
          </>
        ) : (
          <>
            {error && <Alert severity="error">{error}</Alert>}
            {level === 'sub' && owner && (
              <TextField select label="Branch" value={f.branchId} onChange={set('branchId')}>
                {branches.map((b) => <MenuItem key={b.id} value={String(b.id)}>{b.name}</MenuItem>)}
              </TextField>
            )}
            <TextField label="Name" value={f.name} onChange={set('name')} autoFocus />
            <TextField label="Login ID" value={f.login} onChange={set('login')}
              helperText="Email or username used at the branch panel login" />
            <TextField label="Password" value={f.password} onChange={set('password')} helperText="Min 6 characters" />
            <TextField label="Phone (optional)" value={f.phone} onChange={set('phone')} />
            {level === 'sub' && <TextField label="Signup code (optional)" value={f.code}
              onChange={(e) => setF((p) => ({ ...p, code: e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '') }))}
              helperText="Players registering with this code join this sub branch. Leave empty to generate one." />}
            {owner && <TextField label="Your Transaction Password" type="password" value={f.txn} onChange={set('txn')} />}
          </>
        )}
      </DialogContent>
      <DialogActions sx={{ borderTop: `1px solid ${C.border}`, p: 2 }}>
        <Button onClick={onClose} sx={{ color: C.textSecondary }}>{done ? 'Close' : 'Cancel'}</Button>
        {!done && (
          <Button variant="contained" onClick={submit} disabled={saving || !valid}>
            {saving ? <CircularProgress size={20} /> : 'Create'}
          </Button>
        )}
      </DialogActions>
    </Dialog>
  );
};

/* ─── lock / unlock and reset password ───────────────────────────── */

export const StaffActionDialog: React.FC<{
  action: { staff: BranchStaff; kind: 'lock' | 'password' } | null;
  onClose: () => void; onDone: () => void; notify: Notify;
}> = ({ action, onClose, onDone, notify }) => {
  const { kind: me } = useBranch();
  const [password, setPassword] = useState('');
  const [txn, setTxn] = useState('');
  const [saving, setSaving] = useState(false);
  useEffect(() => { setPassword(''); setTxn(''); }, [action]);
  if (!action) return null;
  const { staff, kind } = action;
  const owner = me === 'owner';
  const locking = !staff.locked;

  const submit = async () => {
    setSaving(true);
    try {
      if (kind === 'password') {
        await api.resetPassword(staff.id, password, owner ? txn : undefined);
        notify(`Password updated for ${staff.name}`);
      } else {
        await api.setLock(staff.id, locking, owner ? txn : undefined);
        notify(`${staff.name} ${locking ? 'locked' : 'unlocked'}`);
      }
      onDone(); onClose();
    } catch (e) { notify(msg(e), 'error'); } finally { setSaving(false); }
  };

  return (
    <Dialog open onClose={onClose} maxWidth="xs" fullWidth PaperProps={paper}>
      <DialogTitle sx={titleSx}>
        {kind === 'password' ? `Reset password — ${staff.name}` : `${locking ? 'Lock' : 'Unlock'} — ${staff.name}`}
      </DialogTitle>
      <DialogContent sx={contentSx}>
        {kind === 'lock' && (
          <Typography sx={{ color: C.textSecondary, fontSize: 13 }}>
            {locking
              ? `${staff.name} will be signed out and cannot log in. Its signup code (${staff.code || '—'}) stops taking new registrations${staff.role === 'BranchAdmin' ? ', and every sub branch under it is locked too' : ''}. Existing players keep playing.`
              : `${staff.name} can sign in again and its signup code takes registrations again.`}
          </Typography>
        )}
        {kind === 'password' && (
          <TextField label="New password" value={password} onChange={(e) => setPassword(e.target.value)} autoFocus helperText="Min 6 characters" />
        )}
        {owner && <TextField label="Your Transaction Password" type="password" value={txn} onChange={(e) => setTxn(e.target.value)} />}
      </DialogContent>
      <DialogActions sx={{ borderTop: `1px solid ${C.border}`, p: 2 }}>
        <Button onClick={onClose} sx={{ color: C.textSecondary }}>Cancel</Button>
        <Button variant="contained" color={kind === 'lock' && locking ? 'error' : 'primary'} onClick={submit}
          disabled={saving || (kind === 'password' && password.length < 6) || (owner && !txn)}>
          {saving ? <CircularProgress size={20} /> : kind === 'password' ? 'Update' : locking ? 'Lock' : 'Unlock'}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

/* ─── create player with quick ID ─────────────────────────────────── */

export const CreatePlayerDialog: React.FC<{ open: boolean; onClose: () => void; onDone: () => void }> = ({ open, onClose, onDone }) => {
  const { kind } = useBranch();
  const [f, setF] = useState({ username: '', password: '', phone: '', staffId: '' });
  const [targets, setTargets] = useState<BranchStaff[]>([]);
  const [busy, setBusy] = useState<'gen' | 'save' | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState<CreatedPlayer | null>(null);

  const generate = async () => {
    setBusy('gen'); setError(null);
    try {
      const s = await api.suggestPlayer();
      setF((p) => ({ ...p, username: s.username, password: s.password }));
    } catch (e) { setError(msg(e)); } finally { setBusy(null); }
  };

  useEffect(() => {
    if (!open) return;
    setF({ username: '', password: '', phone: '', staffId: '' }); setError(null); setDone(null);
    generate();
    // Only the super admin picks; players always go under a sub branch.
    if (kind === 'owner') api.listSubBranches({ onlySubs: 1 }).then((r) => setTargets(r.subBranches.filter((s) => !s.locked && !s.parent_locked))).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, kind]);

  const submit = async () => {
    setBusy('save'); setError(null);
    try {
      const r = await api.createPlayer({
        username: f.username.trim() || undefined, password: f.password || undefined,
        phone: f.phone.trim() || undefined, staffId: f.staffId ? Number(f.staffId) : undefined,
      });
      setDone(r.player);
      onDone();
    } catch (e) { setError(msg(e)); } finally { setBusy(null); }
  };

  const needTarget = kind === 'owner' && !f.staffId;

  return (
    <Dialog open={open} onClose={onClose} maxWidth="xs" fullWidth PaperProps={paper}>
      <DialogTitle sx={titleSx}>New Player</DialogTitle>
      <DialogContent sx={contentSx}>
        {done ? (
          <>
            <Alert severity="success">Player created under {done.staff_name}. Share the login — the password is not shown again.</Alert>
            <Credentials rows={[['Player ID', done.id], ['Username', done.username], ['Password', done.password], ['Login at', 'https://example.com']]} />
          </>
        ) : (
          <>
            {error && <Alert severity="error">{error}</Alert>}
            {kind === 'owner' && (
              <TextField select label="Sub branch" value={f.staffId} onChange={(e) => setF((p) => ({ ...p, staffId: e.target.value }))}>
                {targets.map((t) => (
                  <MenuItem key={t.id} value={String(t.id)}>{t.name} · {t.parent_name}{t.code ? ` · ${t.code}` : ''}</MenuItem>
                ))}
              </TextField>
            )}
            <TextField label="Username" value={f.username}
              onChange={(e) => setF((p) => ({ ...p, username: e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, '') }))}
              helperText="5-16 letters, numbers or _"
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <Tooltip title="Generate a new random ID">
                      <span>
                        <IconButton onClick={generate} disabled={busy !== null} size="small" sx={{ color: C.primaryLight }}>
                          {busy === 'gen' ? <CircularProgress size={18} /> : <Casino fontSize="small" />}
                        </IconButton>
                      </span>
                    </Tooltip>
                  </InputAdornment>
                ),
              }} />
            <TextField label="Password" value={f.password} onChange={(e) => setF((p) => ({ ...p, password: e.target.value }))} helperText="Min 6 characters" />
            <TextField label="Phone (optional)" value={f.phone} onChange={(e) => setF((p) => ({ ...p, phone: e.target.value }))} />
          </>
        )}
      </DialogContent>
      <DialogActions sx={{ borderTop: `1px solid ${C.border}`, p: 2, gap: 1 }}>
        {!done && (
          <Button onClick={generate} startIcon={<Casino />} disabled={busy !== null} sx={{ mr: 'auto' }}>Quick ID</Button>
        )}
        <Button onClick={onClose} sx={{ color: C.textSecondary }}>{done ? 'Close' : 'Cancel'}</Button>
        {done ? (
          <Button variant="contained" onClick={() => { setDone(null); setF((p) => ({ ...p, username: '', password: '', phone: '' })); generate(); }}>Create another</Button>
        ) : (
          <Button variant="contained" onClick={submit} disabled={busy !== null || needTarget || f.password.length < 6 || f.username.length < 5}>
            {busy === 'save' ? <CircularProgress size={20} /> : 'Create'}
          </Button>
        )}
      </DialogActions>
    </Dialog>
  );
};
