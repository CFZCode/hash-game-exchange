// "Branches" (super admin) and "Sub Branches" (super admin + branch admin):
// the accounts, their signup codes and period totals, plus create / lock /
// password actions.
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Box, Button, IconButton, InputAdornment, Snackbar, Alert, TextField, Tooltip } from '@mui/material';
import { Add, Key, Lock, LockOpen, Search, Visibility } from '@mui/icons-material';
import * as api from '../../services/branchApi';
import type { BranchStaff } from '../../services/branchApi';
import {
  CopyText, DataTable, ErrorBox, FilterBar, LockedChip, PageTitle, Pnl, fmt, fmtDate, fmtInt, useBranch, useFilters, useLoad,
} from './ui';
import type { Col } from './ui';
import { CreateStaffDialog, StaffActionDialog } from './dialogs';

function useSnack() {
  const [snack, setSnack] = useState<{ msg: string; severity: 'success' | 'error' } | null>(null);
  const el = (
    <Snackbar open={!!snack} autoHideDuration={3500} onClose={() => setSnack(null)} anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}>
      <Alert severity={snack?.severity || 'success'} onClose={() => setSnack(null)}>{snack?.msg}</Alert>
    </Snackbar>
  );
  return { notify: (msg: string, severity: 'success' | 'error' = 'success') => setSnack({ msg, severity }), el };
}

const StaffTable: React.FC<{ rows: BranchStaff[]; loading: boolean; level: 'branch' | 'sub'; reload: () => void; notify: (m: string, s?: 'success' | 'error') => void }> = ({ rows, loading, level, reload, notify }) => {
  const { base, kind } = useBranch();
  const navigate = useNavigate();
  const { sp } = useFilters();
  const [action, setAction] = useState<{ staff: BranchStaff; kind: 'lock' | 'password' } | null>(null);
  const open = (r: BranchStaff) => {
    const q = new URLSearchParams(sp);
    q.set('staffId', String(r.id));
    navigate(`${base}/players?${q}`);
  };
  // Only the super admin manages branch admins; branch admins manage their sub branches.
  const manageable = (r: BranchStaff) => kind === 'owner' || r.role === 'SubBranch';

  const cols: Col<BranchStaff>[] = [
    { label: 'Name', render: (r) => <Box><Box sx={{ fontWeight: 700 }}>{r.name}</Box><Box sx={{ color: '#8384A5', fontSize: 11 }}>{r.login}</Box></Box> },
    ...(level === 'sub' && kind === 'owner' ? [{ label: 'Branch', render: (r: BranchStaff) => (r.role === 'SubBranch' ? r.parent_name : '—') }] : []),
    // Only sub branches take signups, so only they have a code / link.
    ...(level === 'sub' ? [
      { label: 'Signup code', render: (r: BranchStaff) => <CopyText text={r.code || ''} label={<b>{r.code}</b>} title="Copy code" /> },
      { label: 'Signup link', render: (r: BranchStaff) => <CopyText text={api.signupLink(r.code)} label="Copy link" title="Copy registration link" /> },
    ] : []),
    { label: 'Status', render: (r) => <LockedChip locked={r.locked} viaParent={r.role === 'SubBranch' && r.parent_locked} /> },
    ...(level === 'branch' ? [{ label: 'Sub branches', align: 'right' as const, render: (r: BranchStaff) => fmtInt(r.sub_branches) }] : []),
    { label: 'Players', align: 'right', render: (r) => fmtInt(r.players) },
    { label: 'Wallet', align: 'right', render: (r) => fmt(r.wallet) },
    { label: 'Deposit', align: 'right', render: (r) => fmt(r.deposit) },
    { label: 'Withdraw', align: 'right', render: (r) => fmt(r.withdraw) },
    { label: 'Pending', align: 'right', render: (r) => `${fmtInt(r.deposit_pending_count)} / ${fmtInt(r.withdraw_pending_count)}` },
    { label: 'Sports P/L', align: 'right', render: (r) => <Pnl v={r.sports_pnl} /> },
    { label: 'Casino P/L', align: 'right', render: (r) => <Pnl v={r.casino_pnl} /> },
    { label: 'Created', render: (r) => fmtDate(r.created_at) },
    {
      label: 'Actions', render: (r) => (
        <Box sx={{ display: 'flex' }} onClick={(e) => e.stopPropagation()}>
          <Tooltip title="View players"><IconButton size="small" onClick={() => open(r)}><Visibility fontSize="small" /></IconButton></Tooltip>
          {manageable(r) && (
            <>
              <Tooltip title={r.locked ? 'Unlock' : 'Lock'}>
                <IconButton size="small" color={r.locked ? 'success' : 'error'} onClick={() => setAction({ staff: r, kind: 'lock' })}>
                  {r.locked ? <LockOpen fontSize="small" /> : <Lock fontSize="small" />}
                </IconButton>
              </Tooltip>
              <Tooltip title="Reset password"><IconButton size="small" onClick={() => setAction({ staff: r, kind: 'password' })}><Key fontSize="small" /></IconButton></Tooltip>
            </>
          )}
        </Box>
      ),
    },
  ];
  return (
    <>
      <DataTable cols={cols} rows={rows} loading={loading} onRowClick={open} rowKey={(r) => String(r.id)}
        empty={level === 'branch' ? 'No branch admins yet' : 'No sub branches yet'} />
      <StaffActionDialog action={action} onClose={() => setAction(null)} onDone={reload} notify={notify} />
    </>
  );
};

export const BranchesPage: React.FC = () => {
  const { from, to } = useFilters();
  const [search, setSearch] = useState('');
  const [creating, setCreating] = useState(false);
  const { notify, el } = useSnack();
  const list = useLoad(() => api.listBranches({ search, from, to }), [search, from, to]);
  return (
    <Box>
      <PageTitle title="Branches" subtitle="Branch admins and everything under each one, for the selected period"
        action={<Button variant="contained" startIcon={<Add />} onClick={() => setCreating(true)}>New Branch Admin</Button>} />
      <FilterBar scope={false}>
        <TextField size="small" placeholder="Search name / login" value={search} onChange={(e) => setSearch(e.target.value)}
          InputProps={{ startAdornment: <InputAdornment position="start"><Search fontSize="small" /></InputAdornment> }} />
      </FilterBar>
      <ErrorBox error={list.error} onRetry={list.reload} />
      <StaffTable rows={list.data?.branches || []} loading={list.loading} level="branch" reload={list.reload} notify={notify} />
      <CreateStaffDialog open={creating} level="branch" onClose={() => setCreating(false)} onDone={list.reload} />
      {el}
    </Box>
  );
};

export const SubBranchesPage: React.FC = () => {
  const { kind } = useBranch();
  const { filters } = useFilters();
  const [search, setSearch] = useState('');
  const [creating, setCreating] = useState(false);
  const { notify, el } = useSnack();
  const list = useLoad(() => api.listSubBranches({ ...filters, search, onlySubs: 1 }), [filters, search]);
  const rows = list.data?.subBranches || [];
  return (
    <Box>
      <PageTitle title="Sub Branches"
        subtitle="Each sub branch has its own signup code — players who register with it join that sub branch"
        action={<Button variant="contained" startIcon={<Add />} onClick={() => setCreating(true)}>New Sub Branch</Button>} />
      <FilterBar>
        <TextField size="small" placeholder="Search name / login / code" value={search} onChange={(e) => setSearch(e.target.value)}
          InputProps={{ startAdornment: <InputAdornment position="start"><Search fontSize="small" /></InputAdornment> }} />
      </FilterBar>
      <ErrorBox error={list.error} onRetry={list.reload} />
      <StaffTable rows={rows} loading={list.loading} level="sub" reload={list.reload} notify={notify} />
      <CreateStaffDialog open={creating} level="sub"
        defaultBranchId={kind === 'owner' && filters.staffId ? Number(filters.staffId) : undefined}
        onClose={() => setCreating(false)} onDone={list.reload} />
      {el}
    </Box>
  );
};
