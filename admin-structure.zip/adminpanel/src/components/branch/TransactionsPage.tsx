import React, { useEffect, useState } from 'react';
import { Box, InputAdornment, Tab, Tabs, TextField } from '@mui/material';
import { Search } from '@mui/icons-material';
import { C } from '../admin-dashboard/shared';
import * as api from '../../services/branchApi';
import type { Transaction, TxStatus } from '../../services/branchApi';
import { DataTable, ErrorBox, FilterBar, PageTitle, Pager, StatusChip, Tile, Tiles, fmt, fmtDate, fmtInt, useBranch, useFilters, useLoad } from './ui';
import type { Col } from './ui';

type Type = 'deposit' | 'withdraw';
const STATUSES: ('' | TxStatus)[] = ['', 'success', 'pending', 'failed'];

/** Deposits or withdrawals with per-status totals. `userId` pins it to one player. */
export const TransactionsList: React.FC<{ type?: Type; userId?: string }> = ({ type, userId }) => {
  const { kind } = useBranch();
  const { filters } = useFilters();
  const [status, setStatus] = useState<'' | TxStatus>('');
  const [search, setSearch] = useState('');
  const [query, setQuery] = useState('');
  const [page, setPage] = useState(1);
  useEffect(() => { const t = setTimeout(() => { setQuery(search.trim()); setPage(1); }, 350); return () => clearTimeout(t); }, [search]);
  useEffect(() => setPage(1), [filters, status, type]);

  const list = useLoad(() => api.listTransactions({ ...filters, type, status, userId, search: query, page, limit: 25 }),
    [filters, type, status, userId, query, page]);
  const t = list.data?.totals;
  const bucket = (s: TxStatus) => type
    ? t?.[type][s]
    : t && { count: t.deposit[s].count + t.withdraw[s].count, amount: t.deposit[s].amount + t.withdraw[s].amount };
  const label = type === 'withdraw' ? 'Withdrawals' : type === 'deposit' ? 'Deposits' : 'Transactions';

  const cols: Col<Transaction>[] = [
    { label: 'Date', render: (r) => fmtDate(r.ts) },
    ...(!type ? [{ label: 'Type', render: (r: Transaction) => <Box sx={{ color: r.type === 'deposit' ? C.success : C.error, fontWeight: 700, textTransform: 'capitalize' }}>{r.type}</Box> }] : []),
    ...(!userId ? [{ label: 'Player', render: (r: Transaction) => <Box><Box sx={{ fontWeight: 700 }}>{r.username}</Box><Box sx={{ color: '#8384A5', fontSize: 11 }}>ID {r.user_id}</Box></Box> }] : []),
    ...(!userId && kind !== 'sub' ? [{ label: 'Sub branch', render: (r: Transaction) => r.staff_name }] : []),
    { label: 'Method', render: (r) => r.method },
    { label: 'Reference', render: (r) => <Box sx={{ fontFamily: 'monospace', fontSize: 12 }}>{r.ref}</Box> },
    { label: 'Amount', align: 'right', render: (r) => <b>{fmt(r.amount)}</b> },
    { label: 'Status', render: (r) => <StatusChip status={r.status} label={r.raw_status || r.status} /> },
  ];

  return (
    <Box>
      <Tiles>
        <Tile label={`${label} succeeded`} accent={C.success} loading={list.loading} value={fmt(bucket('success')?.amount)} sub={`${fmtInt(bucket('success')?.count)} transactions`} onClick={() => setStatus('success')} />
        <Tile label="Pending" accent={C.warning} loading={list.loading} value={fmt(bucket('pending')?.amount)} sub={`${fmtInt(bucket('pending')?.count)} transactions`} onClick={() => setStatus('pending')} />
        <Tile label="Failed / rejected" accent={C.error} loading={list.loading} value={fmt(bucket('failed')?.amount)} sub={`${fmtInt(bucket('failed')?.count)} transactions`} onClick={() => setStatus('failed')} />
      </Tiles>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 1.5, flexWrap: 'wrap' }}>
        <Tabs value={status} onChange={(_, v) => setStatus(v)} sx={{ minHeight: 36, '& .MuiTab-root': { minHeight: 36, textTransform: 'none', fontWeight: 600 } }}>
          {STATUSES.map((s) => <Tab key={s || 'all'} value={s} label={s ? s[0].toUpperCase() + s.slice(1) : 'All'} />)}
        </Tabs>
        {!userId && (
          <TextField size="small" placeholder="Search player / reference" value={search} onChange={(e) => setSearch(e.target.value)} sx={{ ml: 'auto' }}
            InputProps={{ startAdornment: <InputAdornment position="start"><Search fontSize="small" /></InputAdornment> }} />
        )}
      </Box>
      <ErrorBox error={list.error} onRetry={list.reload} />
      <DataTable cols={cols} rows={list.data?.transactions || []} loading={list.loading} rowKey={(r, i) => `${r.type}-${r.method}-${r.ref}-${i}`} />
      <Pager page={page} totalPages={list.data?.totalPages || 1} total={list.data?.total} onChange={setPage} />
    </Box>
  );
};

const TransactionsPage: React.FC<{ type: Type }> = ({ type }) => (
  <Box>
    <PageTitle title={type === 'deposit' ? 'Deposits' : 'Withdrawals'}
      subtitle="Bank, gateway and agent transfers for your players — every status, with totals" />
    <FilterBar />
    <TransactionsList type={type} />
  </Box>
);

export default TransactionsPage;
