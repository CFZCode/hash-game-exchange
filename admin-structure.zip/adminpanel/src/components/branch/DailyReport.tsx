import React from 'react';
import { Box, TableCell, TableRow } from '@mui/material';
import { C } from '../admin-dashboard/shared';
import * as api from '../../services/branchApi';
import type { DailyRow } from '../../services/branchApi';
import { DataTable, ErrorBox, FilterBar, PageTitle, Pnl, cellSx, fmt, fmtDay, fmtInt, useFilters, useLoad } from './ui';
import type { Col } from './ui';

const sub = (t: React.ReactNode) => <Box sx={{ color: '#8384A5', fontSize: 11 }}>{t}</Box>;

/** One row per day: registrations, money in/out, sports and casino. */
export const DailyTable: React.FC<{ userId?: string }> = ({ userId }) => {
  const { filters } = useFilters();
  const d = useLoad(() => api.getDaily({ ...filters, userId }), [filters, userId]);
  const cols: Col<DailyRow>[] = [
    { label: 'Date', render: (r) => <b>{fmtDay(r.date)}</b> },
    ...(!userId ? [{ label: 'New players', align: 'right' as const, render: (r: DailyRow) => fmtInt(r.registrations) }] : []),
    { label: 'Deposit', align: 'right', render: (r) => <Box><Box sx={{ color: C.success }}>{fmt(r.deposit)}</Box>{sub(`${fmtInt(r.deposit_count)} ok${r.deposit_pending_count ? ` · ${r.deposit_pending_count} pending` : ''}${r.deposit_failed_count ? ` · ${r.deposit_failed_count} failed` : ''}`)}</Box> },
    { label: 'Withdraw', align: 'right', render: (r) => <Box><Box sx={{ color: C.error }}>{fmt(r.withdraw)}</Box>{sub(`${fmtInt(r.withdraw_count)} ok${r.withdraw_pending_count ? ` · ${r.withdraw_pending_count} pending` : ''}${r.withdraw_failed_count ? ` · ${r.withdraw_failed_count} failed` : ''}`)}</Box> },
    { label: 'Net', align: 'right', render: (r) => <Pnl v={r.deposit - r.withdraw} /> },
    { label: 'Sports bets', align: 'right', render: (r) => <Box>{fmtInt(r.sports_bets)}{sub(fmt(r.sports_stake))}</Box> },
    { label: 'Sports P/L', align: 'right', render: (r) => <Pnl v={r.sports_pnl} /> },
    { label: 'Casino bets', align: 'right', render: (r) => <Box>{fmtInt(r.casino_bets)}{sub(fmt(r.casino_staked))}</Box> },
    { label: 'Casino P/L', align: 'right', render: (r) => <Pnl v={r.casino_pnl} /> },
    { label: 'Player P/L', align: 'right', render: (r) => <Pnl v={r.sports_pnl + r.casino_pnl} bold /> },
  ];
  const t = d.data?.totals;
  const foot = { ...cellSx, fontWeight: 800, bgcolor: '#121E38' };
  const footer = t && (d.data?.rows.length || 0) > 0 ? (
    <TableRow>
      <TableCell sx={foot}>Total</TableCell>
      {!userId && <TableCell align="right" sx={foot}>{fmtInt(t.registrations)}</TableCell>}
      <TableCell align="right" sx={{ ...foot, color: C.success }}>{fmt(t.deposit)}</TableCell>
      <TableCell align="right" sx={{ ...foot, color: C.error }}>{fmt(t.withdraw)}</TableCell>
      <TableCell align="right" sx={foot}><Pnl v={t.deposit - t.withdraw} bold /></TableCell>
      <TableCell align="right" sx={foot}>{fmtInt(t.sports_bets)}</TableCell>
      <TableCell align="right" sx={foot}><Pnl v={t.sports_pnl} bold /></TableCell>
      <TableCell align="right" sx={foot}>{fmtInt(t.casino_bets)}</TableCell>
      <TableCell align="right" sx={foot}><Pnl v={t.casino_pnl} bold /></TableCell>
      <TableCell align="right" sx={foot}><Pnl v={t.sports_pnl + t.casino_pnl} bold /></TableCell>
    </TableRow>
  ) : null;
  return (
    <>
      <ErrorBox error={d.error} onRetry={d.reload} />
      <DataTable cols={cols} rows={d.data?.rows || []} loading={d.loading} rowKey={(r) => r.date} footer={footer} />
    </>
  );
};

const DailyReport: React.FC = () => (
  <Box>
    <PageTitle title="Day-wise Report" subtitle="Per day (India time) · P/L is the players' (+ = players won, − = house won)" />
    <FilterBar />
    <DailyTable />
  </Box>
);

export default DailyReport;
