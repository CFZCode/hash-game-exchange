import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Box, Paper, Typography } from '@mui/material';
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { C } from '../admin-dashboard/shared';
import * as api from '../../services/branchApi';
import { ErrorBox, FilterBar, PageTitle, Pnl, Tile, Tiles, fmt, fmtInt, useBranch, useFilters, useLoad } from './ui';

const BranchDashboard: React.FC = () => {
  const { base, kind } = useBranch();
  const navigate = useNavigate();
  const { filters, sp } = useFilters();
  const summary = useLoad(() => api.getSummary(filters), [filters]);
  const daily = useLoad(() => api.getDaily(filters), [filters]);
  const s = summary.data?.summary;
  const loading = summary.loading;
  const go = (path: string, extra: Record<string, string> = {}) => {
    const q = new URLSearchParams(sp);
    Object.entries(extra).forEach(([k, v]) => q.set(k, v));
    navigate(`${base}/${path}?${q}`);
  };
  const housePnl = s ? -(s.sports_pnl + s.casino_pnl) : 0;
  const chart = (daily.data?.rows || []).slice().reverse().map((r) => ({
    date: r.date.slice(5), Deposits: r.deposit, Withdrawals: r.withdraw,
  }));

  return (
    <Box>
      <PageTitle title="Dashboard" subtitle={kind === 'sub' ? 'Your players, money and play' : 'Everything under your branches'} />
      <FilterBar />
      <ErrorBox error={summary.error} onRetry={summary.reload} />

      <Tiles>
        <Tile label="Players" loading={loading} value={fmtInt(s?.players)} sub={`${fmtInt(s?.registrations)} new in period · wallet ${fmt(s?.wallet)}`} onClick={() => go('players')} />
        {kind !== 'sub' && (
          <Tile label="Sub branches" loading={loading} accent={C.info} value={fmtInt(s?.sub_branches)}
            sub={`${fmtInt(s?.sub_branches_locked)} locked${kind === 'owner' ? ` · ${fmtInt(s?.branches)} branches` : ''}`}
            onClick={() => go(kind === 'owner' ? 'branches' : 'sub-branches')} />
        )}
        <Tile label="Deposits (success)" loading={loading} accent={C.success} value={fmt(s?.deposit)}
          sub={`${fmtInt(s?.deposit_count)} txns · ${fmtInt(s?.deposit_pending_count)} pending ${fmt(s?.deposit_pending)}`}
          onClick={() => go('deposits')} />
        <Tile label="Withdrawals (success)" loading={loading} accent={C.error} value={fmt(s?.withdraw)}
          sub={`${fmtInt(s?.withdraw_count)} txns · ${fmtInt(s?.withdraw_pending_count)} pending ${fmt(s?.withdraw_pending)}`}
          onClick={() => go('withdrawals')} />
        <Tile label="Net deposit" loading={loading} accent={C.warning} value={<Pnl v={(s?.deposit || 0) - (s?.withdraw || 0)} />} sub="Deposits − withdrawals" />
      </Tiles>

      <Tiles>
        <Tile label="Sports" loading={loading} accent={C.info} value={fmtInt(s?.sports_bets)}
          sub={<>bets · stake {fmt(s?.sports_stake)} · player P/L <Pnl v={s?.sports_pnl || 0} /></>}
          onClick={() => go('bets', { kind: 'sports' })} />
        <Tile label="Casino" loading={loading} accent="#7B5EF5" value={fmtInt(s?.casino_bets)}
          sub={<>bets · staked {fmt(s?.casino_staked)} · player P/L <Pnl v={s?.casino_pnl || 0} /></>}
          onClick={() => go('bets', { kind: 'casino' })} />
        <Tile label="House P/L (sports + casino)" loading={loading} accent={housePnl >= 0 ? C.success : C.error}
          value={<Pnl v={housePnl} />} sub="+ = players lost, − = players won" />
      </Tiles>

      <Paper elevation={0} sx={{ p: 2, bgcolor: C.card, border: `1px solid ${C.border}`, borderRadius: 2 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
          <Typography sx={{ color: C.text, fontWeight: 700, mr: 'auto' }}>Deposits vs withdrawals by day</Typography>
          <Typography onClick={() => go('daily')} sx={{ color: C.primaryLight, fontSize: 13, cursor: 'pointer' }}>Full day-wise report →</Typography>
        </Box>
        {chart.length === 0 ? (
          <Typography sx={{ color: C.textSecondary, fontSize: 13, py: 6, textAlign: 'center' }}>
            {daily.loading ? 'Loading…' : 'No activity in this period'}
          </Typography>
        ) : (
          <Box sx={{ height: 280 }}>
            <ResponsiveContainer>
              <BarChart data={chart}>
                <CartesianGrid stroke={C.border} vertical={false} />
                <XAxis dataKey="date" stroke={C.textSecondary} fontSize={11} />
                <YAxis stroke={C.textSecondary} fontSize={11} tickFormatter={(v) => (v >= 1000 ? `${Math.round(v / 1000)}k` : v)} />
                <Tooltip formatter={(v: number) => fmt(v)} contentStyle={{ background: C.cardLight, border: `1px solid ${C.border}`, color: C.text }} />
                <Legend />
                <Bar dataKey="Deposits" fill={C.success} radius={[3, 3, 0, 0]} />
                <Bar dataKey="Withdrawals" fill={C.error} radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </Box>
        )}
      </Paper>
    </Box>
  );
};

export default BranchDashboard;
