import { useState, useEffect } from "react";
import axios from "axios";
import {
    Activity, DollarSign,
    Search, RefreshCw, ChevronLeft, ChevronRight,
    Trophy, Users, BarChart3, Calendar, X, Filter,
    ArrowUpRight, ArrowDownRight,
} from "lucide-react";

import DemoChip from "./common/DemoChip";

const API_BASE = "https://example.com";

interface Transaction {
    id: string;
    transaction_id: string;
    user_name: string;
    user_id: string;
    game_title?: string;
    transaction_type: string;
    amount: number;
    currency_code: string;
    transaction_timestamp: string;
    is_demo?: boolean;
}

interface PaginationState {
    totalCount: number;
    totalPages: number;
    currentPage: number;
    limit: number;
}

interface Analytics {
    totals: {
        total: number;
        total_bets: number;
        total_wins: number;
        total_losses: number;
        total_wagered: number;
        total_payouts: number;
        total_losses_amt: number;
    };
    today: {
        today_total: number;
        today_bets: number;
        today_wins: number;
        today_wagered: number;
    };
    typeBreakdown: { transaction_type: string; count: number; total_amount: number }[];
    topUsers: { user_id: string; user_name: string; bet_count: number; wagered: number; won: number }[];
}

const fmtNum = (n: number) =>
    Number(n || 0).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

const fmtDate = (d: string) =>
    new Date(d).toLocaleString("en-IN", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });

const TYPE_COLORS: Record<string, string> = {
    BET: "bg-[#2B6EF5]/20 text-[#4A85F7]",
    WIN: "bg-emerald-500/20 text-emerald-400",
    LOSS: "bg-[#E01B4F]/20 text-[#E01B4F]",
    ROLLBACK: "bg-[#FFC23F]/20 text-[#FFC23F]",
    bet: "bg-[#2B6EF5]/20 text-[#4A85F7]",
    win: "bg-emerald-500/20 text-emerald-400",
    loss: "bg-[#E01B4F]/20 text-[#E01B4F]",
    rollback: "bg-[#FFC23F]/20 text-[#FFC23F]",
};

const History: React.FC = () => {
    const staffId = localStorage.getItem("currentUserId");
    const token = localStorage.getItem("token");

    const headers: Record<string, string> = {
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        ...(staffId ? { "x-staff-id": staffId } : {}),
    };

    const [transactions, setTransactions] = useState<Transaction[]>([]);
    const [analytics, setAnalytics] = useState<Analytics | null>(null);
    const [searchTerm, setSearchTerm] = useState("");
    const [userId, setUserId] = useState<string | null>(null);
    const [pagination, setPagination] = useState<PaginationState>({ totalCount: 0, totalPages: 0, currentPage: 1, limit: 15 });
    const [loading, setLoading] = useState(false);
    const [analyticsLoading, setAnalyticsLoading] = useState(false);
    const [activeTab, setActiveTab] = useState<"overview" | "transactions">("overview");

    // Fetch analytics
    const fetchAnalytics = async () => {
        setAnalyticsLoading(true);
        try {
            const { data } = await axios.get(`${API_BASE}/betHistory/admin/analytics`, { headers });
            setAnalytics(data);
        } catch (e) { console.error(e); }
        finally { setAnalyticsLoading(false); }
    };

    // Normalize transaction shape from different API responses
    const normalizeTx = (tx: any): Transaction => ({
        id: tx.id || tx.transaction_id || "",
        transaction_id: tx.transaction_id || String(tx.id || ""),
        user_name: tx.user_name || tx.name || "",
        user_id: String(tx.user_id || tx.uid || ""),
        game_title: tx.game_title || tx.match_title || tx.game || null,
        transaction_type: tx.transaction_type || (tx.profit > 0 ? "WIN" : tx.profit < 0 ? "LOSS" : tx.reason || tx.bet_type || "BET"),
        amount: Math.abs(parseFloat(tx.amount) || 0),
        currency_code: tx.currency_code || tx.currency || tx.coin || "",
        transaction_timestamp: tx.transaction_timestamp || tx.created_at || tx.created || tx.timestamp || "",
        is_demo: tx.is_demo === true,
    });

    // Fetch transactions
    const fetchTransactions = async () => {
        setLoading(true);
        try {
            let url = `${API_BASE}/betHistory/transactions?page=${pagination.currentPage}&limit=${pagination.limit}`;
            if (userId) url = `${API_BASE}/betHistory/transactions/user/${encodeURIComponent(userId)}?page=${pagination.currentPage}&limit=${pagination.limit}&game_type=all`;
            if (searchTerm) url += `&search=${encodeURIComponent(searchTerm)}`;

            const { data } = await axios.get(url, { headers });
            const raw = data.transactions || [];
            setTransactions(raw.map(normalizeTx));
            setPagination(data.pagination || pagination);
        } catch (e) { console.error(e); }
        finally { setLoading(false); }
    };

    useEffect(() => { fetchAnalytics(); }, []);
    useEffect(() => { fetchTransactions(); }, [pagination.currentPage, userId]);

    // Debounced search
    useEffect(() => {
        const t = setTimeout(() => {
            setPagination(p => ({ ...p, currentPage: 1 }));
            fetchTransactions();
        }, 500);
        return () => clearTimeout(t);
    }, [searchTerm]);

    const handleClear = () => { setSearchTerm(""); setUserId(null); setPagination(p => ({ ...p, currentPage: 1 })); };

    const statCards = analytics ? [
        { label: "Total Transactions", value: Number(analytics.totals.total).toLocaleString(), icon: <Activity size={22} />, gradient: "from-[#2B6EF5] to-[#8B5CF6]", glow: "shadow-[0_0_30px_rgba(100,110,205,0.3)]" },
        { label: "Total Bets", value: Number(analytics.totals.total_bets).toLocaleString(), icon: <BarChart3 size={22} />, gradient: "from-[#0EA5E9] to-[#06B6D4]", glow: "shadow-[0_0_30px_rgba(14,165,233,0.3)]" },
        { label: "Total Wins", value: Number(analytics.totals.total_wins).toLocaleString(), icon: <Trophy size={22} />, gradient: "from-[#10B981] to-[#059669]", glow: "shadow-[0_0_30px_rgba(16,185,129,0.3)]" },
        { label: "Total Wagered", value: `₹${fmtNum(analytics.totals.total_wagered)}`, icon: <DollarSign size={22} />, gradient: "from-[#F59E0B] to-[#EF4444]", glow: "shadow-[0_0_30px_rgba(245,158,11,0.3)]" },
    ] : [];

    const todayCards = analytics ? [
        { label: "Today Bets", value: analytics.today.today_bets, color: "text-[#4A85F7]" },
        { label: "Today Wins", value: analytics.today.today_wins, color: "text-emerald-400" },
        { label: "Today Wagered", value: `₹${fmtNum(analytics.today.today_wagered)}`, color: "text-amber-400" },
        { label: "Today Total", value: analytics.today.today_total, color: "text-purple-400" },
    ] : [];

    return (
        <div className="p-4 md:p-6 min-h-screen text-[#F9F9F9] space-y-6">

            {/* Header */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                <div>
                    <h1 className="text-2xl font-bold tracking-tight">Bet History & Analytics</h1>
                    <p className="text-[#878AA2] text-sm mt-1">Transaction history, analytics &amp; user insights</p>
                </div>
                <button onClick={() => { fetchAnalytics(); fetchTransactions(); }}
                    className="flex items-center gap-2 px-4 py-2 bg-[#0E1831] hover:bg-[#162140] border border-[#1E2D55] rounded-lg text-sm transition-all">
                    <RefreshCw size={14} className={loading || analyticsLoading ? "animate-spin" : ""} /> Refresh
                </button>
            </div>

            {/* Stat Cards */}
            {analytics && (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {statCards.map((c, i) => (
                        <div key={i} className={`relative overflow-hidden rounded-xl bg-gradient-to-br ${c.gradient} ${c.glow} p-5 transition-transform hover:scale-[1.02]`}>
                            <div className="absolute -right-6 -top-6 w-24 h-24 rounded-full bg-white/10" />
                            <div className="absolute -right-3 -top-3 w-16 h-16 rounded-full bg-white/10" />
                            <div className="flex justify-between items-start relative z-10">
                                <div>
                                    <p className="text-[#F9F9F9]/70 text-xs uppercase tracking-wider font-medium">{c.label}</p>
                                    <p className="text-3xl font-extrabold mt-2 tracking-tight">{c.value}</p>
                                </div>
                                <div className="bg-white/20 p-2.5 rounded-lg backdrop-blur-sm">{c.icon}</div>
                            </div>
                        </div>
                    ))}
                </div>
            )}

            {/* Tabs */}
            <div className="flex gap-1 bg-[#0E1831] rounded-lg p-1 border border-[#1E2D55] w-fit">
                {([
                    { key: "overview" as const, label: "Overview", icon: <BarChart3 size={14} /> },
                    { key: "transactions" as const, label: "Transactions", icon: <Activity size={14} /> },
                ]).map(tab => (
                    <button key={tab.key} onClick={() => setActiveTab(tab.key)}
                        className={`flex items-center gap-2 px-5 py-2.5 rounded-md text-sm font-medium transition-all ${activeTab === tab.key
                            ? "bg-[#2B6EF5] text-[#F9F9F9] shadow-lg shadow-[#2B6EF5]/20"
                            : "text-[#878AA2] hover:text-[#F9F9F9] hover:bg-[#162140]"}`}>
                        {tab.icon} {tab.label}
                    </button>
                ))}
            </div>

            {/* ── OVERVIEW TAB ── */}
            {activeTab === "overview" && analytics && (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

                    {/* Today's Stats */}
                    <div className="bg-[#0E1831] rounded-xl border border-[#1E2D55] p-5">
                        <div className="flex items-center gap-2 mb-4">
                            <Calendar size={16} className="text-[#2B6EF5]" />
                            <h3 className="font-semibold">Today's Activity</h3>
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                            {todayCards.map((c, i) => (
                                <div key={i} className="bg-[#0C0D1D] rounded-lg border border-[#1E2D55] p-4">
                                    <p className="text-[#878AA2] text-xs uppercase tracking-wider">{c.label}</p>
                                    <p className={`text-2xl font-bold mt-1 ${c.color}`}>{c.value}</p>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Type Breakdown */}
                    <div className="bg-[#0E1831] rounded-xl border border-[#1E2D55] p-5">
                        <div className="flex items-center gap-2 mb-4">
                            <Filter size={16} className="text-[#2B6EF5]" />
                            <h3 className="font-semibold">Transaction Breakdown</h3>
                        </div>
                        <div className="space-y-3">
                            {analytics.typeBreakdown.map((t, i) => {
                                const pct = analytics.totals.total > 0 ? (Number(t.count) / Number(analytics.totals.total)) * 100 : 0;
                                return (
                                    <div key={i} className="flex items-center gap-3">
                                        <span className={`text-xs font-semibold px-2 py-0.5 rounded ${TYPE_COLORS[t.transaction_type] || "bg-[#1E2D55]/20 text-[#878AA2]"}`}>
                                            {t.transaction_type}
                                        </span>
                                        <div className="flex-1 bg-[#0C0D1D] rounded-full h-2 overflow-hidden">
                                            <div className="h-full bg-[#2B6EF5] rounded-full transition-all" style={{ width: `${pct}%` }} />
                                        </div>
                                        <span className="text-xs text-[#878AA2] w-16 text-right">{Number(t.count).toLocaleString()}</span>
                                        <span className="text-xs text-[#878AA2] w-20 text-right">₹{fmtNum(t.total_amount)}</span>
                                    </div>
                                );
                            })}
                        </div>
                    </div>

                    {/* P&L Summary */}
                    <div className="bg-[#0E1831] rounded-xl border border-[#1E2D55] p-5">
                        <div className="flex items-center gap-2 mb-4">
                            <DollarSign size={16} className="text-[#2B6EF5]" />
                            <h3 className="font-semibold">P&L Summary</h3>
                        </div>
                        <div className="space-y-4">
                            <div className="flex justify-between items-center">
                                <span className="text-[#878AA2] text-sm">Total Wagered</span>
                                <span className="text-lg font-bold text-[#4A85F7]">₹{fmtNum(analytics.totals.total_wagered)}</span>
                            </div>
                            <div className="flex justify-between items-center">
                                <span className="text-[#878AA2] text-sm">Total Payouts</span>
                                <span className="text-lg font-bold text-emerald-400 flex items-center gap-1"><ArrowUpRight size={16} />₹{fmtNum(analytics.totals.total_payouts)}</span>
                            </div>
                            <div className="flex justify-between items-center">
                                <span className="text-[#878AA2] text-sm">Total Losses</span>
                                <span className="text-lg font-bold text-[#E01B4F] flex items-center gap-1"><ArrowDownRight size={16} />₹{fmtNum(analytics.totals.total_losses_amt)}</span>
                            </div>
                            <div className="border-t border-[#1E2D55] pt-3 flex justify-between items-center">
                                <span className="text-[#8384A5] text-sm font-semibold">House Edge</span>
                                <span className={`text-lg font-bold ${Number(analytics.totals.total_wagered) - Number(analytics.totals.total_payouts) >= 0 ? "text-emerald-400" : "text-[#E01B4F]"}`}>
                                    ₹{fmtNum(Math.abs(Number(analytics.totals.total_wagered) - Number(analytics.totals.total_payouts)))}
                                </span>
                            </div>
                        </div>
                    </div>

                    {/* Top Users */}
                    <div className="bg-[#0E1831] rounded-xl border border-[#1E2D55] p-5">
                        <div className="flex items-center gap-2 mb-4">
                            <Users size={16} className="text-[#2B6EF5]" />
                            <h3 className="font-semibold">Top Users by Bets</h3>
                        </div>
                        <div className="overflow-x-auto">
                            <table className="w-full text-sm">
                                <thead>
                                    <tr className="text-[#878AA2] text-xs uppercase border-b border-[#1E2D55]">
                                        <th className="pb-2 text-left">#</th>
                                        <th className="pb-2 text-left">User</th>
                                        <th className="pb-2 text-right">Bets</th>
                                        <th className="pb-2 text-right">Wagered</th>
                                        <th className="pb-2 text-right">Won</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {analytics.topUsers.map((u, i) => (
                                        <tr key={u.user_id} className="border-b border-[#1E2D55]/50 hover:bg-[#0E1831] transition cursor-pointer"
                                            onClick={() => { setUserId(u.user_id); setActiveTab("transactions"); }}>
                                            <td className="py-2 text-[#878AA2] text-xs">{i + 1}</td>
                                            <td className="py-2">
                                                <span className="font-medium">{u.user_name || "—"}</span>
                                                <span className="text-[#878AA2] text-xs ml-2">#{u.user_id}</span>
                                            </td>
                                            <td className="py-2 text-right font-mono text-[#8384A5]">{Number(u.bet_count).toLocaleString()}</td>
                                            <td className="py-2 text-right font-mono text-[#4A85F7]">₹{fmtNum(u.wagered)}</td>
                                            <td className="py-2 text-right font-mono text-emerald-400">₹{fmtNum(u.won)}</td>
                                        </tr>
                                    ))}
                                    {analytics.topUsers.length === 0 && (
                                        <tr><td colSpan={5} className="text-center py-8 text-[#878AA2]">No data yet</td></tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            )}

            {/* ── TRANSACTIONS TAB ── */}
            {activeTab === "transactions" && (
                <div className="bg-[#0E1831] rounded-xl border border-[#1E2D55] overflow-hidden">
                    {/* Filters */}
                    <div className="p-4 border-b border-[#1E2D55] flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
                        <h2 className="text-lg font-semibold">
                            Transactions
                            <span className="text-sm text-[#878AA2] font-normal ml-2">({pagination.totalCount || 0} total)</span>
                        </h2>
                        <div className="flex flex-wrap gap-3 items-center">
                            <div className="relative">
                                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#878AA2]" />
                                <input value={searchTerm} onChange={e => setSearchTerm(e.target.value)}
                                    placeholder="Search name, game..."
                                    className="bg-[#0C0D1D] border border-[#1E2D55] rounded-lg pl-9 pr-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-[#2B6EF5] text-[#F9F9F9] placeholder-[#878AA2] w-52" />
                            </div>
                            <div className="relative">
                                <Users size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#878AA2]" />
                                <input value={userId || ""} onChange={e => { setUserId(e.target.value || null); setPagination(p => ({ ...p, currentPage: 1 })); }}
                                    placeholder="User ID"
                                    className="bg-[#0C0D1D] border border-[#1E2D55] rounded-lg pl-9 pr-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-[#2B6EF5] text-[#F9F9F9] placeholder-[#878AA2] w-40" />
                            </div>
                            {(searchTerm || userId) && (
                                <button onClick={handleClear}
                                    className="flex items-center gap-1 text-xs text-[#878AA2] hover:text-[#F9F9F9] bg-[#162140] px-3 py-2 rounded-lg transition">
                                    <X size={12} /> Clear
                                </button>
                            )}
                        </div>
                    </div>

                    {/* Table */}
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                            <thead>
                                <tr className="text-left text-[#878AA2] text-xs uppercase tracking-wider bg-[#0C0D1D]">
                                    <th className="px-4 py-3">User</th>
                                    <th className="px-4 py-3">Game</th>
                                    <th className="px-4 py-3">Coin</th>
                                    <th className="px-4 py-3">Type</th>
                                    <th className="px-4 py-3 text-right">Amount</th>
                                    <th className="px-4 py-3">Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                {loading ? (
                                    <tr><td colSpan={6} className="text-center py-12 text-[#878AA2]">Loading...</td></tr>
                                ) : transactions.length === 0 ? (
                                    <tr><td colSpan={6} className="text-center py-12 text-[#878AA2]">No transactions found</td></tr>
                                ) : (
                                    transactions.map((tx, idx) => (
                                        <tr key={tx.id} className={`border-t border-[#1E2D55] hover:bg-[#0E1831] transition ${idx % 2 === 0 ? "bg-[#0E1831]" : "bg-[#0E1831]"}`}>
                                            <td className="px-4 py-3">
                                                <span className="font-medium">{tx.user_name}</span>
                                                <DemoChip show={tx.is_demo} />
                                                <span className="text-[#878AA2] text-xs block">#{tx.user_id}</span>
                                            </td>
                                            <td className="px-4 py-3 text-[#8384A5]">{tx.game_title || "—"}</td>
                                            <td className="px-4 py-3">
                                                <span className="bg-[#2B6EF5]/20 text-[#2B6EF5] text-xs font-semibold px-2 py-0.5 rounded">{tx.currency_code || "—"}</span>
                                            </td>
                                            <td className="px-4 py-3">
                                                <span className={`text-xs font-semibold px-2 py-0.5 rounded ${TYPE_COLORS[tx.transaction_type] || "bg-[#1E2D55]/20 text-[#878AA2]"}`}>
                                                    {tx.transaction_type}
                                                </span>
                                            </td>
                                            <td className="px-4 py-3 text-right font-mono">
                                                <span className={(tx.transaction_type || "").toLowerCase() === "win" ? "text-emerald-400" : (tx.transaction_type || "").toLowerCase() === "loss" ? "text-[#E01B4F]" : "text-[#8384A5]"}>
                                                    {(tx.transaction_type || "").toLowerCase() === "win" ? "+" : (tx.transaction_type || "").toLowerCase() === "loss" ? "-" : ""}
                                                    ₹{fmtNum(Math.abs(tx.amount))}
                                                </span>
                                            </td>
                                            <td className="px-4 py-3 text-[#878AA2] text-xs">{fmtDate(tx.transaction_timestamp)}</td>
                                        </tr>
                                    ))
                                )}
                            </tbody>
                        </table>
                    </div>

                    {/* Pagination */}
                    {pagination.totalPages > 1 && (
                        <div className="flex items-center justify-between px-4 py-3 border-t border-[#1E2D55]">
                            <span className="text-xs text-[#878AA2]">
                                Page {pagination.currentPage} of {pagination.totalPages}
                            </span>
                            <div className="flex gap-2">
                                <button onClick={() => setPagination(p => ({ ...p, currentPage: Math.max(1, p.currentPage - 1) }))}
                                    disabled={pagination.currentPage <= 1}
                                    className="flex items-center gap-1 px-3 py-1.5 bg-[#162140] hover:bg-[#1E2D55] rounded-lg text-xs transition disabled:opacity-40">
                                    <ChevronLeft size={14} /> Prev
                                </button>
                                <button onClick={() => setPagination(p => ({ ...p, currentPage: Math.min(p.totalPages, p.currentPage + 1) }))}
                                    disabled={pagination.currentPage >= pagination.totalPages}
                                    className="flex items-center gap-1 px-3 py-1.5 bg-[#162140] hover:bg-[#1E2D55] rounded-lg text-xs transition disabled:opacity-40">
                                    Next <ChevronRight size={14} />
                                </button>
                            </div>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};

export default History;
