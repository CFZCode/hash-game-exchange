import React, { useState, useEffect, useRef } from 'react';
import {
  Box,
  Card,
  Typography,
  TextField,
  InputAdornment,
  Avatar,
  Chip,
  IconButton,
  Tooltip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Skeleton,
  Button,
  Paper,
  Snackbar,
  Alert,
  CircularProgress,
} from '@mui/material';
import {
  Search,
  PersonAdd,
  Refresh,
  CheckCircle,
  HourglassEmpty,
  Cancel,
  CardGiftcard,
  CurrencyRupee,
  CalendarToday,
} from '@mui/icons-material';

interface User {
  id: string;
  name: string;
}

interface RedeemBonus {
  userid: string;
  code: string;
  amount: number;
  status: string;
  createdat: string;
  updatedat: string;
}

const ROLE_KEY = "3c95e1f2a6b8d740c9e3812f5d7694b0a2c8157e943fd6802b5e9c71m4a3h8p9";
const API_BASE = "https://example.com/bonus";

const STATUS_CFG: Record<string, { color: string; bg: string; border: string; icon: React.ReactNode }> = {
  pending:   { color: '#FFC23F', bg: 'rgba(255,194,63,0.12)',  border: 'rgba(255,194,63,0.3)',  icon: <HourglassEmpty sx={{ fontSize: 13 }} /> },
  completed: { color: '#0ECC68', bg: 'rgba(14,204,104,0.12)', border: 'rgba(14,204,104,0.3)', icon: <CheckCircle sx={{ fontSize: 13 }} /> },
  failed:    { color: '#E01B4F', bg: 'rgba(224,27,79,0.12)',  border: 'rgba(224,27,79,0.3)',  icon: <Cancel sx={{ fontSize: 13 }} /> },
};

const getStatus = (s: string) => STATUS_CFG[s.toLowerCase()] ?? { color: '#8384A5', bg: 'rgba(131,132,165,0.12)', border: 'rgba(131,132,165,0.3)', icon: <HourglassEmpty sx={{ fontSize: 13 }} /> };

const avatarColor = (name: string) => {
  const colors = ['#2B6EF5','#7B5EF5','#0ECC68','#FFC23F','#E01B4F'];
  let h = 0;
  for (let i = 0; i < name.length; i++) h = name.charCodeAt(i) + ((h << 5) - h);
  return colors[Math.abs(h) % colors.length];
};

const fmt = (d: string) => new Date(d).toLocaleString('en-US', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });

const BonusRedemption: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [redeemList, setRedeemList] = useState<RedeemBonus[]>([]);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [amount, setAmount] = useState('');
  const [loading, setLoading] = useState(false);
  const [createLoading, setCreateLoading] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);
  const [snack, setSnack] = useState<{ open: boolean; msg: string; severity: 'success' | 'error' }>({ open: false, msg: '', severity: 'success' });
  const dropdownRef = useRef<HTMLDivElement>(null);

  const headers = { "role-key": ROLE_KEY, "Content-Type": "application/json" };
  const notify = (msg: string, severity: 'success' | 'error') => setSnack({ open: true, msg, severity });

  const fetchUsers = async () => {
    try {
      const res = await fetch(`${API_BASE}/users`, { headers });
      setUsers(await res.json());
    } catch { notify('Failed to load users', 'error'); }
  };

  const fetchRedeemList = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/redeem-bonus`, { headers });
      const data: RedeemBonus[] = await res.json();
      setRedeemList([...data].sort((a, b) => new Date(b.createdat).getTime() - new Date(a.createdat).getTime()));
    } catch { notify('Failed to load redemption list', 'error'); }
    finally { setLoading(false); }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUser || !amount) return;
    setCreateLoading(true);
    try {
      await fetch(`${API_BASE}/redeem-bonus/create`, {
        method: 'POST', headers,
        body: JSON.stringify({ userid: selectedUser.id, amount: Number(amount) }),
      });
      setAmount(''); setSelectedUser(null); setSearchTerm(''); setShowDropdown(false);
      notify('Bonus redemption created successfully!', 'success');
      fetchRedeemList();
    } catch { notify('Failed to create bonus redemption', 'error'); }
    finally { setCreateLoading(false); }
  };

  useEffect(() => { fetchUsers(); fetchRedeemList(); }, []);

  // Close dropdown on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) setShowDropdown(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const filteredUsers = users.filter(u => u.name.toLowerCase().includes(searchTerm.toLowerCase()));

  const HEADER_CELLS = ['User ID', 'Code', 'Amount', 'Status', 'Created', 'Updated'];

  return (
    <Box sx={{ p: { xs: 1.5, sm: 2, md: 2.5 }, display: 'flex', flexDirection: 'column', gap: 2 }}>

      {/* ── Create Form ── */}
      <Card sx={{ bgcolor: '#0E1831', border: '1px solid #1E2D55', borderRadius: 2 }}>
        <Box sx={{ px: 2.5, py: 2, borderBottom: '1px solid #1E2D55', display: 'flex', alignItems: 'center', gap: 1.5 }}>
          <Box sx={{ width: 36, height: 36, borderRadius: 1.5, bgcolor: 'rgba(43,110,245,0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <CardGiftcard sx={{ color: '#2B6EF5', fontSize: 20 }} />
          </Box>
          <Box>
            <Typography sx={{ color: '#F9F9F9', fontWeight: 700, fontSize: '0.95rem' }}>Create New Redemption</Typography>
            <Typography sx={{ color: '#8384A5', fontSize: '0.72rem' }}>Assign bonus redemption to a user</Typography>
          </Box>
        </Box>

        <Box component="form" onSubmit={handleSubmit} sx={{ p: 2.5 }}>
          <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: '5fr 4fr 3fr' }, gap: 2, alignItems: 'flex-end' }}>

            {/* User search */}
            <Box ref={dropdownRef} sx={{ position: 'relative' }}>
              <Typography sx={{ color: '#8384A5', fontSize: '0.72rem', fontWeight: 600, mb: 0.75, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                Select User
              </Typography>
              <TextField
                size="small"
                fullWidth
                placeholder="Search users…"
                value={searchTerm}
                onChange={e => { setSearchTerm(e.target.value); setSelectedUser(null); setShowDropdown(e.target.value.length > 0); }}
                InputProps={{
                  startAdornment: <InputAdornment position="start"><Search sx={{ color: '#8384A5', fontSize: 18 }} /></InputAdornment>,
                }}
                sx={{
                  '& .MuiOutlinedInput-root': {
                    bgcolor: '#0C0D1D', borderRadius: 1.5,
                    '& fieldset': { borderColor: selectedUser ? '#0ECC68' : '#1E2D55' },
                    '&:hover fieldset': { borderColor: '#2B6EF5' },
                    '&.Mui-focused fieldset': { borderColor: '#2B6EF5' },
                  },
                  '& input': { color: '#F9F9F9', fontSize: '0.85rem' },
                }}
              />
              {/* Dropdown */}
              {showDropdown && filteredUsers.length > 0 && (
                <Paper
                  elevation={8}
                  sx={{
                    position: 'absolute', top: '100%', left: 0, right: 0, zIndex: 50, mt: 0.5,
                    bgcolor: '#0E1831', border: '1px solid #1E2D55', borderRadius: 1.5,
                    maxHeight: 240, overflowY: 'auto',
                    '&::-webkit-scrollbar': { width: 4 },
                    '&::-webkit-scrollbar-thumb': { bgcolor: '#1E2D55', borderRadius: 2 },
                  }}
                >
                  {filteredUsers.map(user => (
                    <Box
                      key={user.id}
                      onClick={() => { setSelectedUser(user); setSearchTerm(user.name); setShowDropdown(false); }}
                      sx={{
                        px: 2, py: 1.25, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 1.5,
                        borderBottom: '1px solid #1E2D5533',
                        '&:hover': { bgcolor: '#121E38' },
                        '&:last-child': { borderBottom: 'none' },
                      }}
                    >
                      <Avatar sx={{ width: 28, height: 28, fontSize: '0.65rem', fontWeight: 700, bgcolor: avatarColor(user.name), flexShrink: 0 }}>
                        {user.name.slice(0, 2).toUpperCase()}
                      </Avatar>
                      <Box>
                        <Typography sx={{ color: '#F9F9F9', fontSize: '0.82rem', fontWeight: 600 }}>{user.name}</Typography>
                        <Typography sx={{ color: '#8384A5', fontSize: '0.68rem' }}>ID: {user.id}</Typography>
                      </Box>
                    </Box>
                  ))}
                </Paper>
              )}
              {/* Selected badge */}
              {selectedUser && (
                <Box sx={{ mt: 1, display: 'flex', alignItems: 'center', gap: 1, bgcolor: 'rgba(14,204,104,0.08)', border: '1px solid rgba(14,204,104,0.25)', borderRadius: 1.5, px: 1.5, py: 0.75 }}>
                  <CheckCircle sx={{ color: '#0ECC68', fontSize: 14 }} />
                  <Typography sx={{ color: '#0ECC68', fontSize: '0.75rem', fontWeight: 600 }}>{selectedUser.name}</Typography>
                  <Typography sx={{ color: '#8384A5', fontSize: '0.68rem', ml: 0.5 }}>· {selectedUser.id}</Typography>
                </Box>
              )}
            </Box>

            {/* Amount */}
            <Box>
              <Typography sx={{ color: '#8384A5', fontSize: '0.72rem', fontWeight: 600, mb: 0.75, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                Amount
              </Typography>
              <TextField
                size="small"
                fullWidth
                type="number"
                placeholder="0.00"
                value={amount}
                onChange={e => setAmount(e.target.value)}
                InputProps={{
                  startAdornment: <InputAdornment position="start"><CurrencyRupee sx={{ color: '#FFC23F', fontSize: 18 }} /></InputAdornment>,
                }}
                sx={{
                  '& .MuiOutlinedInput-root': {
                    bgcolor: '#0C0D1D', borderRadius: 1.5,
                    '& fieldset': { borderColor: '#1E2D55' },
                    '&:hover fieldset': { borderColor: '#2B6EF5' },
                    '&.Mui-focused fieldset': { borderColor: '#2B6EF5' },
                  },
                  '& input': { color: '#F9F9F9', fontSize: '0.85rem' },
                }}
              />
            </Box>

            {/* Submit */}
            <Button
              type="submit"
              variant="contained"
              fullWidth
              disabled={!selectedUser || !amount || createLoading}
              startIcon={createLoading ? <CircularProgress size={16} sx={{ color: '#fff' }} /> : <PersonAdd />}
              sx={{
                bgcolor: '#2B6EF5', '&:hover': { bgcolor: '#1A5CE0' },
                '&.Mui-disabled': { bgcolor: '#1E2D55', color: '#8384A5' },
                borderRadius: 1.5, fontWeight: 700, py: 1.1,
              }}
            >
              Create Redemption
            </Button>
          </Box>
        </Box>
      </Card>

      {/* ── Redemption list ── */}
      <Card sx={{ bgcolor: '#0E1831', border: '1px solid #1E2D55', borderRadius: 2 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 2.5, py: 2, borderBottom: '1px solid #1E2D55', flexWrap: 'wrap', gap: 1 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
            <CardGiftcard sx={{ color: '#7B5EF5', fontSize: 20 }} />
            <Typography sx={{ color: '#F9F9F9', fontWeight: 700, fontSize: '0.95rem' }}>
              Redemption History
              <Typography component="span" sx={{ ml: 1, color: '#8384A5', fontWeight: 400, fontSize: '0.78rem' }}>
                ({redeemList.length} records)
              </Typography>
            </Typography>
          </Box>
          <Tooltip title="Refresh">
            <IconButton onClick={fetchRedeemList} disabled={loading} sx={{ color: '#8384A5', border: '1px solid #1E2D55', borderRadius: 1.5, '&:hover': { color: '#2B6EF5', borderColor: '#2B6EF5' } }}>
              <Refresh fontSize="small" sx={{ animation: loading ? 'spin 1s linear infinite' : 'none', '@keyframes spin': { from: { transform: 'rotate(0deg)' }, to: { transform: 'rotate(360deg)' } } }} />
            </IconButton>
          </Tooltip>
        </Box>

        <TableContainer>
          <Table size="small">
            <TableHead>
              <TableRow sx={{ bgcolor: '#0C0D1D' }}>
                {HEADER_CELLS.map(h => (
                  <TableCell key={h} sx={{ color: '#8384A5', fontSize: '0.7rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.07em', borderBottom: '1px solid #1E2D55', py: 1.5, whiteSpace: 'nowrap' }}>
                    {h}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>

            <TableBody>
              {loading
                ? Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={i}>
                      {HEADER_CELLS.map((_, j) => (
                        <TableCell key={j} sx={{ borderBottom: '1px solid #1E2D5533', py: 1.5 }}>
                          <Skeleton variant="text" sx={{ bgcolor: '#1E2D55' }} />
                        </TableCell>
                      ))}
                    </TableRow>
                  ))
                : redeemList.length === 0
                ? (
                  <TableRow>
                    <TableCell colSpan={6} sx={{ py: 6, borderBottom: 'none' }}>
                      <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1 }}>
                        <CardGiftcard sx={{ fontSize: 40, color: '#1E2D55' }} />
                        <Typography sx={{ color: '#8384A5', fontSize: '0.85rem' }}>No redemption records found</Typography>
                      </Box>
                    </TableCell>
                  </TableRow>
                )
                : redeemList.map((item, idx) => {
                    const cfg = getStatus(item.status);
                    return (
                      <TableRow key={idx} sx={{ '&:hover': { bgcolor: '#121E38' }, '& td': { borderBottom: '1px solid #1E2D5533' } }}>
                        {/* User ID */}
                        <TableCell sx={{ py: 1.5 }}>
                          <Typography sx={{ color: '#5581F7', fontSize: '0.72rem', fontFamily: 'monospace', bgcolor: 'rgba(43,110,245,0.08)', px: 1, py: 0.25, borderRadius: 1, display: 'inline-block' }}>
                            {item.userid}
                          </Typography>
                        </TableCell>

                        {/* Code */}
                        <TableCell sx={{ py: 1.5 }}>
                          <Typography sx={{ color: '#FFC23F', fontSize: '0.75rem', fontFamily: 'monospace', fontWeight: 700, bgcolor: 'rgba(255,194,63,0.08)', px: 1, py: 0.25, borderRadius: 1, display: 'inline-block', letterSpacing: '0.05em' }}>
                            {item.code}
                          </Typography>
                        </TableCell>

                        {/* Amount */}
                        <TableCell sx={{ py: 1.5 }}>
                          <Typography sx={{ color: '#0ECC68', fontSize: '0.82rem', fontWeight: 700 }}>
                            ₹{item.amount}
                          </Typography>
                        </TableCell>

                        {/* Status */}
                        <TableCell sx={{ py: 1.5 }}>
                          <Chip
                            icon={<Box sx={{ color: `${cfg.color} !important`, display: 'flex', ml: '6px' }}>{cfg.icon}</Box>}
                            label={item.status}
                            size="small"
                            sx={{ bgcolor: cfg.bg, color: cfg.color, fontWeight: 700, fontSize: '0.7rem', height: 22, border: `1px solid ${cfg.border}`, textTransform: 'capitalize' }}
                          />
                        </TableCell>

                        {/* Created */}
                        <TableCell sx={{ py: 1.5 }}>
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
                            <CalendarToday sx={{ color: '#8384A5', fontSize: 13 }} />
                            <Typography sx={{ color: '#8384A5', fontSize: '0.75rem', whiteSpace: 'nowrap' }}>{fmt(item.createdat)}</Typography>
                          </Box>
                        </TableCell>

                        {/* Updated */}
                        <TableCell sx={{ py: 1.5 }}>
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
                            <CalendarToday sx={{ color: '#8384A5', fontSize: 13 }} />
                            <Typography sx={{ color: '#8384A5', fontSize: '0.75rem', whiteSpace: 'nowrap' }}>{fmt(item.updatedat)}</Typography>
                          </Box>
                        </TableCell>
                      </TableRow>
                    );
                  })}
            </TableBody>
          </Table>
        </TableContainer>
      </Card>

      {/* Snackbar */}
      <Snackbar open={snack.open} autoHideDuration={3000} onClose={() => setSnack(s => ({ ...s, open: false }))} anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}>
        <Alert severity={snack.severity} sx={{ bgcolor: snack.severity === 'success' ? '#0E2B1F' : '#2B0E1A', color: snack.severity === 'success' ? '#0ECC68' : '#E01B4F', border: `1px solid ${snack.severity === 'success' ? '#0ECC68' : '#E01B4F'}` }}>
          {snack.msg}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default BonusRedemption;
