import React, { useEffect, useMemo, useState } from 'react';
import { toast, Toaster } from 'sonner';
import { apiFetch, apiUpload } from '../utils/api';
import BlogForm from './blog/BlogForm';
import {
  Blog,
  BlogListResponse,
  BlogSaveResponse,
  BlogStatus,
  SITE_URL,
  errorMessage,
  inputCls,
  isScheduled,
  resolveImage,
  stripHtml,
} from './blog/blogShared';

type Filter = 'all' | BlogStatus;

/**
 * Blog management — list, search, publish/unpublish, delete.
 * Create and edit happen in BlogForm. Every call goes to the staff-only
 * /api/blogs/* routes; published posts appear at SITE_URL/blog/<slug>.
 */
export default function BlogAdmin() {
  const [blogs, setBlogs] = useState<Blog[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<Filter>('all');
  /* undefined: dialog closed; null: creating; a Blog: editing it. */
  const [editing, setEditing] = useState<Blog | null | undefined>(undefined);
  const [busyId, setBusyId] = useState<number | null>(null);

  const fetchBlogs = async () => {
    setLoading(true);
    setLoadError('');
    try {
      const res = await apiFetch<BlogListResponse>('/api/blogs/admin/all');
      setBlogs(res.blogs || []);
    } catch (err) {
      setLoadError(errorMessage(err, 'Failed to load blogs'));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBlogs();
  }, []);

  const categories = useMemo(() => Array.from(new Set(blogs.map((b) => b.category).filter(Boolean))).sort(), [blogs]);

  const counts = useMemo(
    () => ({
      all: blogs.length,
      published: blogs.filter((b) => b.status === 'published').length,
      draft: blogs.filter((b) => b.status === 'draft').length,
    }),
    [blogs]
  );

  const visible = useMemo(() => {
    const q = search.trim().toLowerCase();
    return blogs.filter(
      (b) =>
        (filter === 'all' || b.status === filter) &&
        (!q || [b.title, b.category, b.author].some((v) => (v || '').toLowerCase().includes(q)))
    );
  }, [blogs, search, filter]);

  const handleDelete = async (blog: Blog) => {
    if (!window.confirm(`Delete "${blog.title}"? This cannot be undone.`)) return;
    setBusyId(blog.id);
    try {
      await apiFetch(`/api/blogs/deleteBlogById?id=${blog.id}`, { method: 'POST', body: '{}' });
      toast.success('Post deleted');
      setBlogs((prev) => prev.filter((b) => b.id !== blog.id));
    } catch (err) {
      toast.error(errorMessage(err, 'Failed to delete post'));
    } finally {
      setBusyId(null);
    }
  };

  const toggleStatus = async (blog: Blog) => {
    const next: BlogStatus = blog.status === 'published' ? 'draft' : 'published';
    setBusyId(blog.id);
    try {
      const fd = new FormData();
      fd.append('id', String(blog.id));
      fd.append('status', next);
      const res = await apiUpload<BlogSaveResponse>('/api/blogs/updateBlog', fd);
      const saved = res.data as Blog;
      setBlogs((prev) => prev.map((b) => (b.id === blog.id ? saved : b)));
      toast.success(next === 'published' ? 'Published' : 'Moved to drafts');
    } catch (err) {
      toast.error(errorMessage(err, 'Failed to change status'));
    } finally {
      setBusyId(null);
    }
  };

  const badge = (b: Blog) =>
    b.status === 'draft'
      ? { text: 'Draft', cls: 'bg-[#FFC23F]/20 text-[#FFC23F]' }
      : isScheduled(b)
        ? { text: 'Scheduled', cls: 'bg-[#5581F7]/20 text-[#5581F7]' }
        : { text: 'Published', cls: 'bg-[#0ECC68]/20 text-[#0ECC68]' };

  return (
    <div className="p-4 md:p-6 min-h-screen text-[#F9F9F9] space-y-6">
      <Toaster richColors position="top-right" />

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">Blog Management</h1>
          <p className="text-[#878AA2] text-sm mt-1">
            {counts.published} published · {counts.draft} draft{counts.draft !== 1 ? 's' : ''}
          </p>
        </div>
        <button onClick={() => setEditing(null)} className="bg-[#2B6EF5] hover:bg-[#4A85F7] px-4 py-2 rounded-lg text-sm font-medium transition self-start sm:self-auto">
          + New Post
        </button>
      </div>

      <div className="flex flex-col md:flex-row gap-3">
        <input
          type="search"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search title, category or author"
          className={`${inputCls} md:max-w-sm`}
        />
        <div className="flex gap-2">
          {(['all', 'published', 'draft'] as const).map((s) => (
            <button
              key={s}
              onClick={() => setFilter(s)}
              className={`px-3 py-2 rounded-lg text-sm capitalize border transition ${
                filter === s ? 'bg-[#2B6EF5] border-[#2B6EF5]' : 'border-[#1E2D55] text-[#878AA2] hover:text-[#F9F9F9]'
              }`}
            >
              {s} ({counts[s]})
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-48 text-[#878AA2]">Loading...</div>
      ) : loadError ? (
        <div className="flex flex-col items-center justify-center h-48 gap-3 text-[#878AA2]">
          <p>{loadError}</p>
          <button onClick={fetchBlogs} className="text-[#2B6EF5] underline text-sm">Try again</button>
        </div>
      ) : visible.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-48 text-[#878AA2] gap-2">
          <p>{blogs.length === 0 ? 'No blog posts yet.' : 'No posts match this filter.'}</p>
          {blogs.length === 0 && (
            <button onClick={() => setEditing(null)} className="text-[#2B6EF5] underline text-sm">Create your first post</button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {visible.map((blog) => (
            <div key={blog.id} className="bg-[#0E1831] border border-[#1E2D55] rounded-xl overflow-hidden flex flex-col">
              <div className="relative h-40 bg-[#10182E]">
                {blog.image ? (
                  <img src={resolveImage(blog.image)} alt={blog.title} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-[#878AA2] text-xs">No cover image</div>
                )}
                <span className={`absolute top-2 left-2 text-xs px-2 py-0.5 rounded font-semibold ${badge(blog).cls}`}>{badge(blog).text}</span>
              </div>
              <div className="p-4 flex flex-col flex-1">
                <div className="flex items-center gap-2 mb-2">
                  {blog.category && <span className="text-xs bg-[#2B6EF5]/20 text-[#2B6EF5] px-2 py-0.5 rounded font-medium">{blog.category}</span>}
                  <span className="text-xs text-[#878AA2] ml-auto truncate">
                    {blog.author} · {blog.date ? new Date(blog.date).toLocaleDateString() : ''}
                  </span>
                </div>
                <h3 className="font-semibold text-base leading-tight mb-1 line-clamp-2">{blog.title}</h3>
                <p className="text-[#878AA2] text-xs mb-1 truncate">/blog/{blog.slug}</p>
                <p className="text-[#878AA2] text-xs flex-1 line-clamp-3">{blog.subheading || stripHtml(blog.description || '').slice(0, 140)}</p>
                <div className="flex flex-wrap items-center justify-end gap-2 mt-4 pt-3 border-t border-[#1E2D55]">
                  {blog.status === 'published' && !isScheduled(blog) && (
                    <a href={`${SITE_URL}/blog/${blog.slug}`} target="_blank" rel="noopener noreferrer" className="text-xs text-[#2B6EF5] hover:underline px-1 mr-auto">
                      View
                    </a>
                  )}
                  <button
                    onClick={() => toggleStatus(blog)}
                    disabled={busyId === blog.id}
                    className="text-xs border border-[#1E2D55] hover:border-[#2B6EF5] px-3 py-1.5 rounded transition disabled:opacity-50"
                  >
                    {blog.status === 'published' ? 'Unpublish' : 'Publish'}
                  </button>
                  <button onClick={() => setEditing(blog)} className="text-xs bg-[#1E2D55] hover:bg-[#162140] px-3 py-1.5 rounded transition">
                    Edit
                  </button>
                  <button
                    onClick={() => handleDelete(blog)}
                    disabled={busyId === blog.id}
                    className="text-xs bg-[#E01B4F]/20 hover:bg-[#E01B4F]/40 text-[#E01B4F] px-3 py-1.5 rounded transition disabled:opacity-50"
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {editing !== undefined && (
        <BlogForm
          key={editing ? editing.id : 'new'}
          blog={editing}
          categories={categories}
          onClose={() => setEditing(undefined)}
          onSaved={() => {
            setEditing(undefined);
            fetchBlogs();
          }}
        />
      )}
    </div>
  );
}
