import React, { useState } from 'react';
import { Box, Tabs, Tab, Typography } from '@mui/material';
import { Person, Groups, AccountBalance } from '@mui/icons-material';
import DirectUsersTab from './users/DirectUsersTab';
import AgentSystemTab from './users/AgentSystemTab';
import FinancialTab from './users/FinancialTab';
import RiskManagementDialog from './users/RiskManagementDialog';
import StaffRiskDialog from './users/StaffRiskDialog';
import BalanceSheetDialog from './users/BalanceSheetDialog';
import PlayerReportDialog from './users/PlayerReportDialog';
import SessionReportDialog, { ReportKind } from './users/SessionReportDialog';

const C = {
  bg: '#0C0D1D', card: '#0E1831', border: '#1E2D55',
  primary: '#2B6EF5', text: '#F9F9F9', textMuted: '#878AA2',
};

// Only SuperAdmin / MotherAdmin see the "Direct Users" and "Financial" tabs —
// every other staff role sees the Agent System view scoped to their own downline.
const DIRECT_TAB_ROLES = new Set(['SuperAdmin', 'MotherAdmin']);

const Users: React.FC = () => {
  const userRole = localStorage.getItem('userRole') || 'Guest';
  const canSeeDirect = DIRECT_TAB_ROLES.has(userRole);
  const [tab, setTab] = useState<'direct' | 'agent' | 'financial'>(canSeeDirect ? 'direct' : 'agent');
  const [riskUserId, setRiskUserId] = useState<string | null>(null);
  const [riskStaffId, setRiskStaffId] = useState<string | null>(null);
  const [balanceUserId, setBalanceUserId] = useState<string | null>(null);
  const [reportTarget, setReportTarget] = useState<{ id: string; name: string } | null>(null);
  // Casino / sports dispute reports share one dialog — `kind` picks which.
  const [sessionReport, setSessionReport] = useState<{ kind: ReportKind; id: string; name: string } | null>(null);
  // Balance sheet is available to the whole staff hierarchy, but only for users
  // (UsersTable rows) — never for staff/agent rows.
  const openBalanceSheet = setBalanceUserId;
  const openReport = (id: string, name: string) => setReportTarget({ id, name });
  const openCasinoReport = (id: string, name: string) => setSessionReport({ kind: 'casino', id, name });
  const openSportsReport = (id: string, name: string) => setSessionReport({ kind: 'sports', id, name });

  return (
    <Box sx={{ p: { xs: 1.5, sm: 2, md: 2.5 } }}>
      <Box sx={{ mb: 2 }}>
        <Typography sx={{ color: C.text, fontWeight: 800, fontSize: { xs: '1.3rem', sm: '1.5rem' }, lineHeight: 1.2 }}>
          Users
        </Typography>
        <Typography sx={{ color: C.textMuted, fontSize: '0.78rem', mt: 0.25 }}>
          Manage direct users and agent-system accounts with per-user risk controls
        </Typography>
      </Box>

      {canSeeDirect && (
        <Box sx={{ borderBottom: `1px solid ${C.border}`, mb: 2.5 }}>
          <Tabs
            value={tab}
            onChange={(_, v) => setTab(v)}
            variant="scrollable"
            scrollButtons={false}
            sx={{
              minHeight: 42,
              '& .MuiTab-root': {
                color: C.textMuted,
                textTransform: 'none',
                fontWeight: 600,
                fontSize: '0.88rem',
                minHeight: 42,
                gap: 0.75,
                '&.Mui-selected': { color: C.primary },
              },
              '& .MuiTabs-indicator': { bgcolor: C.primary, height: 3, borderRadius: '3px 3px 0 0' },
            }}
          >
            <Tab value="direct" label="Direct Users" icon={<Person sx={{ fontSize: 18 }} />} iconPosition="start" />
            <Tab value="agent" label="Agent System" icon={<Groups sx={{ fontSize: 18 }} />} iconPosition="start" />
            <Tab value="financial" label="Financial" icon={<AccountBalance sx={{ fontSize: 18 }} />} iconPosition="start" />
          </Tabs>
        </Box>
      )}

      {tab === 'direct' && canSeeDirect && (
        <DirectUsersTab
          onOpenRisk={setRiskUserId}
          onOpenBalanceSheet={openBalanceSheet}
          onOpenReport={openReport}
          onOpenCasinoReport={openCasinoReport}
          onOpenSportsReport={openSportsReport}
        />
      )}
      {(tab === 'agent' || !canSeeDirect) && (
        <AgentSystemTab
          onOpenRisk={setRiskUserId}
          onOpenStaffRisk={setRiskStaffId}
          onOpenBalanceSheet={openBalanceSheet}
          onOpenReport={openReport}
          onOpenCasinoReport={openCasinoReport}
          onOpenSportsReport={openSportsReport}
        />
      )}
      {tab === 'financial' && canSeeDirect && <FinancialTab />}

      <RiskManagementDialog
        open={riskUserId !== null}
        userId={riskUserId}
        onClose={() => setRiskUserId(null)}
      />

      <StaffRiskDialog
        open={riskStaffId !== null}
        staffId={riskStaffId}
        onClose={() => setRiskStaffId(null)}
      />

      <BalanceSheetDialog
        open={balanceUserId !== null}
        userId={balanceUserId}
        onClose={() => setBalanceUserId(null)}
      />

      <PlayerReportDialog
        open={reportTarget !== null}
        userId={reportTarget?.id ?? null}
        userName={reportTarget?.name ?? null}
        onClose={() => setReportTarget(null)}
      />

      <SessionReportDialog
        open={sessionReport !== null}
        kind={sessionReport?.kind ?? 'casino'}
        userId={sessionReport?.id ?? null}
        userName={sessionReport?.name ?? null}
        onClose={() => setSessionReport(null)}
      />
    </Box>
  );
};

export default Users;
