import React, { useCallback, useEffect, useState } from 'react';
import type { AxiosInstance } from 'axios';

// ─── Types ───
interface AffiliateRow {
  id: number;
  name: string;
  referalcode: string;
  withdrawal_locked: boolean;
  members: number;
  usdt: number;
  bjb: number;
  commission_paid: number;
  expected_commission: number;
  overpaid: number;
  duplicate_events: number;
  pool_remaining: number;
  unclaimed: number;
  claimed: number;
  members_wager: number;
  flags: string[];
}

interface Member {
  id: number;
  name: string;
  created: string;
  last_ip: string | null;
  withdrawal_locked: boolean;
  inr: number;
  wager: number;
  deposited: number;
  withdrawn: number;
  commission_paid: number;
  expected_commission: number;
  same_bank: boolean;
  same_device: boolean;
  shared_ip: boolean;
}

interface Detail {
  owner: { id: number; name: string; referalcode: string; withdrawal_locked: boolean; usdt: number; bjb: number; inr: number };
  commissionRate: number;
  members: Member[];
  commissionHistory: { membername: string; createdAt: string; amount: number; times: number }[];
  pools: { id: number; membername: string; amount: number; referalmount: number; createdAt: string }[];
  unlockedRewards: { id: number; membername: string; amount: number; wager_amount: number; claimed: boolean; createdAt: string }[];
  adjustments: { id: number; currency: string; amount: number; reason: string; description: string; created_at: string }[];
}

interface ActivityRow {
  id: number;
  actor_name: string | null;
  action: string;
  target_type: string | null;
  target_id: string | null;
  details: Record<string, unknown> | null;
  status: string;
  created_at: string;
}

const FLAG_LABELS: Record<string, { label: string; cls: string }> = {
  overpaid: { label: 'Overpaid', cls: 'bg-[#E01B4F]/15 text-[#E01B4F] border-[#E01B4F]/40' },
  duplicate_commission: { label: 'Duplicate commission', cls: 'bg-[#E01B4F]/15 text-[#E01B4F] border-[#E01B4F]/40' },
  same_bank: { label: 'Same bank account', cls: 'bg-[#E01B4F]/15 text-[#E01B4F] border-[#E01B4F]/40' },
  same_device: { label: 'Same device + IP', cls: 'bg-[#FFC23F]/15 text-[#FFC23F] border-[#FFC23F]/40' },
  shared_ip: { label: 'Shared IP (weak)', cls: 'text-[#8384A5] border-[#1E2D55]' },
  rapid_signups: { label: 'Rapid signups', cls: 'bg-[#FFC23F]/15 text-[#FFC23F] border-[#FFC23F]/40' },
  withdrawal_locked: { label: 'Withdraw locked', cls: 'bg-[#5581F7]/15 text-[#5581F7] border-[#5581F7]/40' },
};

const num = (v: number | string, d = 2) => {
  const n = Number(v) || 0;
  return n.toLocaleString('en-IN', { minimumFractionDigits: d, maximumFractionDigits: d });
};
const when = (d: string) => new Date(d).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' });
const errMsg = (e: any) => e?.response?.data?.message || e?.message || 'Request failed';

const card = 'bg-[#0E1831] border border-[#1E2D55] rounded-xl';
const th = 'px-3 py-2 text-left text-xs font-medium text-[#8384A5] uppercase whitespace-nowrap';
const td = 'px-3 py-2 text-sm text-[#F9F9F9] whitespace-nowrap';
const btn = 'px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed';
const btnPrimary = `${btn} bg-[#2B6EF5] text-[#F9F9F9] hover:bg-[#2B6EF5]/80`;
const btnDanger = `${btn} bg-[#E01B4F] text-[#F9F9F9] hover:bg-[#E01B4F]/80`;
const btnGhost = `${btn} border border-[#1E2D55] text-[#F9F9F9] hover:bg-[#1E2D55]`;

const Flags: React.FC<{ flags: string[] }> = ({ flags }) => (
  <div className="flex flex-wrap gap-1">
    {flags.map(f => (
      <span key={f} className={`px-2 py-0.5 text-[11px] rounded-full border ${FLAG_LABELS[f]?.cls || 'text-[#8384A5] border-[#1E2D55]'}`}>
        {FLAG_LABELS[f]?.label || f}
      </span>
    ))}
  </div>
);

// ─── Affiliates tab ───
export const AffiliatesPanel: React.FC<{ api: AxiosInstance }> = ({ api }) => {
  const [rows, setRows] = useState<AffiliateRow[]>([]);
  const [rate, setRate] = useState(0);
  const [search, setSearch] = useState('');
  const [flaggedOnly, setFlaggedOnly] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [selected, setSelected] = useState<number | null>(null);

  const load = useCallback(async () => {
    try {
      setLoading(true);
      setError('');
      const res = await api.get('/affiliates', { params: { search: search.trim(), flagged: flaggedOnly ? '1' : undefined } });
      setRows(res.data.data);
      setRate(res.data.commissionRate);
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setLoading(false);
    }
  }, [api, search, flaggedOnly]);

  useEffect(() => { load(); }, [flaggedOnly]); // eslint-disable-line react-hooks/exhaustive-deps

  if (selected !== null) {
    return <AffiliateDetail api={api} uid={selected} onBack={() => { setSelected(null); load(); }} />;
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <input
          type="text"
          placeholder="Search username, UID or referral code..."
          className="w-full md:w-80 px-4 py-2 bg-[#0C0D1D] border border-[#1E2D55] rounded-lg text-[#F9F9F9] focus:outline-none focus:ring-2 focus:ring-[#2B6EF5]"
          value={search}
          onChange={e => setSearch(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter') load(); }}
        />
        <button className={btnPrimary} onClick={load}>Search</button>
        <label className="flex items-center gap-2 text-sm text-[#F9F9F9] cursor-pointer">
          <input type="checkbox" checked={flaggedOnly} onChange={e => setFlaggedOnly(e.target.checked)} />
          Flagged only
        </label>
        <span className="text-xs text-[#8384A5] ml-auto">
          Commission rate: {(rate * 100).toFixed(4)}% of wager · Expected = members' wager × rate
        </span>
      </div>

      {error && <div className="text-sm text-[#E01B4F]">{error}</div>}

      <div className={`${card} overflow-x-auto`}>
        <table className="min-w-full divide-y divide-[#1E2D55]">
          <thead>
            <tr>
              <th className={th}>Referrer</th>
              <th className={th}>Members</th>
              <th className={`${th} text-right`}>USDT</th>
              <th className={`${th} text-right`}>Commission paid</th>
              <th className={`${th} text-right`}>Expected</th>
              <th className={`${th} text-right`}>Overpaid</th>
              <th className={`${th} text-right`}>Pool left</th>
              <th className={`${th} text-right`}>Unclaimed</th>
              <th className={th}>Flags</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#1E2D55]">
            {loading ? (
              <tr><td colSpan={9} className="px-3 py-8 text-center text-[#8384A5]">Loading...</td></tr>
            ) : rows.length === 0 ? (
              <tr><td colSpan={9} className="px-3 py-8 text-center text-[#8384A5]">No affiliates found</td></tr>
            ) : rows.map(r => (
              <tr key={r.id} className="hover:bg-[#1E2D55]/40 cursor-pointer" onClick={() => setSelected(r.id)}>
                <td className={td}>
                  <div className="font-semibold">{r.name}</div>
                  <div className="text-xs text-[#8384A5]">{r.id} · {r.referalcode}</div>
                </td>
                <td className={td}>{r.members}</td>
                <td className={`${td} text-right`}>{num(r.usdt, 4)}</td>
                <td className={`${td} text-right`}>{num(r.commission_paid, 4)}</td>
                <td className={`${td} text-right text-[#8384A5]`}>{num(r.expected_commission, 4)}</td>
                <td className={`${td} text-right ${r.overpaid > 0.01 ? 'text-[#E01B4F] font-semibold' : 'text-[#8384A5]'}`}>{num(r.overpaid, 4)}</td>
                <td className={`${td} text-right`}>{num(r.pool_remaining)}</td>
                <td className={`${td} text-right`}>{num(r.unclaimed)}</td>
                <td className={td}><Flags flags={r.flags} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="text-xs text-[#8384A5]">
        Same bank account = a member withdraws to the referrer's bank account (strong). Same device = same IP and same browser within an hour.
        Shared IP is only a hint: Jio mobile IPs (152.56–152.59.x.x) and IPs used by more than 3 accounts are ignored, and it does not count for "Flagged only".
      </p>
    </div>
  );
};

// ─── Detail + actions ───
const AffiliateDetail: React.FC<{ api: AxiosInstance; uid: number; onBack: () => void }> = ({ api, uid, onBack }) => {
  const [data, setData] = useState<Detail | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [adjCoin, setAdjCoin] = useState<'usdt' | 'bjb'>('usdt');
  const [adjAmount, setAdjAmount] = useState('');
  const [includeMembers, setIncludeMembers] = useState(true);

  const load = useCallback(async () => {
    try {
      setLoading(true);
      const res = await api.get(`/affiliates/${uid}`);
      setData(res.data.data);
    } catch (e) {
      setMsg({ ok: false, text: errMsg(e) });
    } finally {
      setLoading(false);
    }
  }, [api, uid]);

  useEffect(() => { load(); }, [load]);

  // Har action: confirm + reason, phir reload.
  const act = async (question: string, url: string, body: Record<string, unknown> = {}) => {
    const reason = window.prompt(`${question}\n\nReason (required, saved in activity log):`);
    if (!reason || !reason.trim()) return;
    try {
      setBusy(true);
      setMsg(null);
      const res = await api.post(url, { ...body, reason: reason.trim() });
      setMsg({ ok: true, text: res.data.message || 'Done' });
      await load();
    } catch (e) {
      setMsg({ ok: false, text: errMsg(e) });
    } finally {
      setBusy(false);
    }
  };

  if (loading && !data) return <div className="py-12 text-center text-[#8384A5]">Loading...</div>;
  if (!data) return (
    <div className="space-y-3">
      <button className={btnGhost} onClick={onBack}>← Back</button>
      {msg && <div className="text-sm text-[#E01B4F]">{msg.text}</div>}
    </div>
  );

  const { owner } = data;
  const paid = data.members.reduce((s, m) => s + Number(m.commission_paid), 0);
  const expected = data.members.reduce((s, m) => s + Number(m.expected_commission), 0);
  const duplicates = data.commissionHistory.filter(h => h.times > 1).length;
  const adjValue = Number(adjAmount);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-3">
        <button className={btnGhost} onClick={onBack}>← Back</button>
        <h2 className="text-xl font-bold text-[#F9F9F9]">{owner.name}</h2>
        <span className="text-sm text-[#8384A5]">UID {owner.id} · code {owner.referalcode}</span>
        <span className={`px-2 py-0.5 text-xs rounded-full border ${owner.withdrawal_locked ? FLAG_LABELS.withdrawal_locked.cls : 'text-[#0ECC68] border-[#0ECC68]/40'}`}>
          {owner.withdrawal_locked ? 'Withdrawals locked' : 'Withdrawals open'}
        </span>
        <button className={btnGhost} onClick={load} disabled={loading}>Refresh</button>
      </div>

      {msg && (
        <div className={`text-sm px-4 py-2 rounded-lg border ${msg.ok ? 'text-[#0ECC68] border-[#0ECC68]/40' : 'text-[#E01B4F] border-[#E01B4F]/40'}`}>
          {msg.text}
        </div>
      )}

      {/* Summary */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {[
          ['USDT balance', num(owner.usdt, 4)],
          ['BJB balance', num(owner.bjb, 4)],
          ['INR balance', num(owner.inr)],
          ['Commission paid', num(paid, 4)],
          ['Expected', num(expected, 4)],
          ['Overpaid', num(Math.max(paid - expected, 0), 4)],
        ].map(([label, value]) => (
          <div key={label} className={`${card} p-3`}>
            <div className="text-xs text-[#8384A5]">{label}</div>
            <div className={`text-lg font-bold ${label === 'Overpaid' && paid - expected > 0.01 ? 'text-[#E01B4F]' : 'text-[#F9F9F9]'}`}>{value}</div>
          </div>
        ))}
      </div>

      {/* Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className={`${card} p-4 space-y-3`}>
          <h3 className="text-sm font-semibold text-[#F9F9F9]">Withdrawal lock</h3>
          <label className="flex items-center gap-2 text-sm text-[#F9F9F9]">
            <input type="checkbox" checked={includeMembers} onChange={e => setIncludeMembers(e.target.checked)} />
            Include all {data.members.length} referred member(s)
          </label>
          <div className="flex gap-2">
            <button className={btnDanger} disabled={busy}
              onClick={() => act(`Lock withdrawals for ${owner.name}${includeMembers ? ' and members' : ''}?`,
                `/affiliates/${owner.id}/withdrawal-lock`, { locked: true, includeMembers })}>
              Lock
            </button>
            <button className={btnGhost} disabled={busy}
              onClick={() => act(`Unlock withdrawals for ${owner.name}${includeMembers ? ' and members' : ''}?`,
                `/affiliates/${owner.id}/withdrawal-lock`, { locked: false, includeMembers })}>
              Unlock
            </button>
          </div>
        </div>

        <div className={`${card} p-4 space-y-3`}>
          <h3 className="text-sm font-semibold text-[#F9F9F9]">Adjust affiliate balance</h3>
          <div className="flex gap-2">
            <select value={adjCoin} onChange={e => setAdjCoin(e.target.value as 'usdt' | 'bjb')}
              className="px-2 py-1.5 bg-[#0C0D1D] border border-[#1E2D55] rounded-lg text-sm text-[#F9F9F9]">
              <option value="usdt">USDT</option>
              <option value="bjb">BJB</option>
            </select>
            <input type="number" step="any" placeholder="-5 to remove, 5 to add" value={adjAmount}
              onChange={e => setAdjAmount(e.target.value)}
              className="flex-1 px-3 py-1.5 bg-[#0C0D1D] border border-[#1E2D55] rounded-lg text-sm text-[#F9F9F9]" />
          </div>
          <div className="flex flex-wrap gap-2">
            <button className={btnPrimary} disabled={busy || !adjValue}
              onClick={() => act(`${adjValue > 0 ? 'Add' : 'Remove'} ${Math.abs(adjValue)} ${adjCoin.toUpperCase()} for ${owner.name}?`,
                `/affiliates/${owner.id}/adjust`, { coin: adjCoin, amount: adjValue })}>
              Apply
            </button>
            <button className={btnDanger} disabled={busy || !(Number(owner[adjCoin]) > 0)}
              onClick={() => act(`Remove ALL ${num(owner[adjCoin], 4)} ${adjCoin.toUpperCase()} from ${owner.name}?`,
                `/affiliates/${owner.id}/adjust`, { coin: adjCoin, amount: -Number(owner[adjCoin]) })}>
              Remove all {adjCoin.toUpperCase()}
            </button>
          </div>
          <p className="text-xs text-[#8384A5]">Removals stop at 0. Every change is written to the ledger.</p>
        </div>

        <div className={`${card} p-4 space-y-3`}>
          <h3 className="text-sm font-semibold text-[#F9F9F9]">Commission records</h3>
          <p className="text-xs text-[#8384A5]">
            {duplicates > 0 ? `${duplicates} payment(s) were recorded more than once.` : 'No duplicate commission records.'}
          </p>
          <button className={btnDanger} disabled={busy || duplicates === 0}
            onClick={() => act(`Delete duplicate commission rows for ${owner.name}? The wallet is NOT changed; use "Adjust" to recover money.`,
              `/affiliates/${owner.id}/dedupe-commission`)}>
            Remove duplicate rows
          </button>
        </div>
      </div>

      {/* Members */}
      <Section title={`Referred members (${data.members.length})`}>
        <table className="min-w-full divide-y divide-[#1E2D55]">
          <thead><tr>
            <th className={th}>Member</th><th className={th}>Joined</th><th className={th}>Last IP</th>
            <th className={`${th} text-right`}>Wager (USD)</th><th className={`${th} text-right`}>Deposited ₹</th>
            <th className={`${th} text-right`}>Withdrawn ₹</th><th className={`${th} text-right`}>INR bal</th>
            <th className={`${th} text-right`}>Commission paid</th><th className={`${th} text-right`}>Expected</th><th className={th}>Flags</th>
          </tr></thead>
          <tbody className="divide-y divide-[#1E2D55]">
            {data.members.map(m => (
              <tr key={m.id}>
                <td className={td}><div className="font-semibold">{m.name}</div><div className="text-xs text-[#8384A5]">{m.id}</div></td>
                <td className={td}>{when(m.created)}</td>
                <td className={td}>{m.last_ip || '-'}</td>
                <td className={`${td} text-right`}>{num(m.wager)}</td>
                <td className={`${td} text-right`}>{num(m.deposited)}</td>
                <td className={`${td} text-right ${Number(m.withdrawn) > Number(m.deposited) * 3 ? 'text-[#E01B4F] font-semibold' : ''}`}>{num(m.withdrawn)}</td>
                <td className={`${td} text-right`}>{num(m.inr)}</td>
                <td className={`${td} text-right`}>{num(m.commission_paid, 4)}</td>
                <td className={`${td} text-right text-[#8384A5]`}>{num(m.expected_commission, 4)}</td>
                <td className={td}><Flags flags={[
                  ...(m.same_bank ? ['same_bank'] : []),
                  ...(m.same_device ? ['same_device'] : []),
                  ...(m.shared_ip ? ['shared_ip'] : []),
                  ...(m.withdrawal_locked ? ['withdrawal_locked'] : []),
                ]} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Section>

      {/* Pools */}
      <Section title="Referral bonus pools (locked)">
        <table className="min-w-full divide-y divide-[#1E2D55]">
          <thead><tr>
            <th className={th}>Member</th><th className={`${th} text-right`}>Original</th>
            <th className={`${th} text-right`}>Remaining</th><th className={th}>Created</th><th className={th}></th>
          </tr></thead>
          <tbody className="divide-y divide-[#1E2D55]">
            {data.pools.length === 0 ? <Empty cols={5} /> : data.pools.map(p => (
              <tr key={p.id}>
                <td className={td}>{p.membername}</td>
                <td className={`${td} text-right`}>{num(p.referalmount)}</td>
                <td className={`${td} text-right`}>{num(p.amount)}</td>
                <td className={td}>{when(p.createdAt)}</td>
                <td className={`${td} text-right`}>
                  <button className={btnDanger} disabled={busy || Number(p.amount) === 0}
                    onClick={() => act(`Void the ${num(p.amount)} pool for member ${p.membername}? Unclaimed unlocked rewards for this member are cancelled too.`,
                      `/pools/${p.id}/void`)}>
                    Void
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Section>

      {/* Unlocked rewards */}
      <Section title="Unlocked referral rewards">
        <table className="min-w-full divide-y divide-[#1E2D55]">
          <thead><tr>
            <th className={th}>Member</th><th className={`${th} text-right`}>Tier wager</th>
            <th className={`${th} text-right`}>Amount (BJB)</th><th className={th}>Status</th><th className={th}>Date</th><th className={th}></th>
          </tr></thead>
          <tbody className="divide-y divide-[#1E2D55]">
            {data.unlockedRewards.length === 0 ? <Empty cols={6} /> : data.unlockedRewards.map(u => (
              <tr key={u.id}>
                <td className={td}>{u.membername}</td>
                <td className={`${td} text-right`}>{num(u.wager_amount, 0)}</td>
                <td className={`${td} text-right`}>{num(u.amount)}</td>
                <td className={td}>{u.claimed ? <span className="text-[#0ECC68]">Claimed</span> : <span className="text-[#FFC23F]">Unclaimed</span>}</td>
                <td className={td}>{when(u.createdAt)}</td>
                <td className={`${td} text-right`}>
                  {!u.claimed && (
                    <button className={btnDanger} disabled={busy}
                      onClick={() => act(`Cancel unclaimed reward of ${num(u.amount)} for ${u.membername}?`, `/unlocked/${u.id}/cancel`)}>
                      Cancel
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Section>

      {/* Commission history */}
      <Section title="Commission history (latest 200 events)">
        <table className="min-w-full divide-y divide-[#1E2D55]">
          <thead><tr>
            <th className={th}>Date</th><th className={th}>Member</th>
            <th className={`${th} text-right`}>Amount (USDT)</th><th className={`${th} text-right`}>Times recorded</th>
          </tr></thead>
          <tbody className="divide-y divide-[#1E2D55]">
            {data.commissionHistory.length === 0 ? <Empty cols={4} /> : data.commissionHistory.map((h, i) => (
              <tr key={i}>
                <td className={td}>{when(h.createdAt)}</td>
                <td className={td}>{h.membername}</td>
                <td className={`${td} text-right`}>{num(h.amount, 6)}</td>
                <td className={`${td} text-right ${h.times > 1 ? 'text-[#E01B4F] font-semibold' : ''}`}>{h.times}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Section>

      {/* Adjustments */}
      <Section title="Balance corrections">
        <table className="min-w-full divide-y divide-[#1E2D55]">
          <thead><tr>
            <th className={th}>Date</th><th className={th}>Coin</th><th className={`${th} text-right`}>Amount</th><th className={th}>Note</th>
          </tr></thead>
          <tbody className="divide-y divide-[#1E2D55]">
            {data.adjustments.length === 0 ? <Empty cols={4} /> : data.adjustments.map(a => (
              <tr key={a.id}>
                <td className={td}>{when(a.created_at)}</td>
                <td className={td}>{a.currency}</td>
                <td className={`${td} text-right ${Number(a.amount) < 0 ? 'text-[#E01B4F]' : 'text-[#0ECC68]'}`}>{num(a.amount, 6)}</td>
                <td className={`${td} whitespace-normal text-[#8384A5]`}>{a.description}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Section>
    </div>
  );
};

const Section: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className={card}>
    <h3 className="px-4 pt-4 pb-2 text-sm font-semibold text-[#F9F9F9]">{title}</h3>
    <div className="overflow-x-auto">{children}</div>
  </div>
);

const Empty: React.FC<{ cols: number }> = ({ cols }) => (
  <tr><td colSpan={cols} className="px-3 py-6 text-center text-sm text-[#8384A5]">Nothing here</td></tr>
);

// ─── Activity tab ───
export const AffiliateActivityPanel: React.FC<{ api: AxiosInstance }> = ({ api }) => {
  const [rows, setRows] = useState<ActivityRow[]>([]);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get('/activity')
      .then(res => setRows(res.data.data))
      .catch(e => setError(errMsg(e)));
  }, [api]);

  return (
    <div className={`${card} overflow-x-auto`}>
      {error && <div className="px-4 pt-3 text-sm text-[#E01B4F]">{error}</div>}
      <table className="min-w-full divide-y divide-[#1E2D55]">
        <thead><tr>
          <th className={th}>Date</th><th className={th}>By</th><th className={th}>Action</th>
          <th className={th}>Target</th><th className={th}>Reason</th><th className={th}>Status</th>
        </tr></thead>
        <tbody className="divide-y divide-[#1E2D55]">
          {rows.length === 0 ? <Empty cols={6} /> : rows.map(r => (
            <tr key={r.id}>
              <td className={td}>{when(r.created_at)}</td>
              <td className={td}>{r.actor_name || '-'}</td>
              <td className={td}>{r.action.replace('affiliate.', '').replace(/_/g, ' ')}</td>
              <td className={td}>{r.target_type} {r.target_id}</td>
              <td className={`${td} whitespace-normal text-[#8384A5]`}>{String(r.details?.reason ?? '')}</td>
              <td className={`${td} ${r.status === 'success' ? 'text-[#0ECC68]' : 'text-[#E01B4F]'}`}>{r.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
