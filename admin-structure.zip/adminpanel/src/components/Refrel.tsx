import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { installDemoViewAxios } from '../utils/demoView';
import { AffiliatesPanel, AffiliateActivityPanel } from './AffiliateManage';

const API_BASE_URL = 'https://example.com/affiliateAdmin';

// /affiliateAdmin routes staff token maangte hain (guardAdmin).
const api = axios.create({ baseURL: API_BASE_URL });
installDemoViewAxios(api);
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// ─── Interfaces ───
interface DashboardStats {
  totalTeams: number;
  totalReferrals: number;
  totalLocked: number;
  totalDistributed: number;
  totalCommission: number;
  totalRewardRecords: number;
  totalClaimed: number;
  totalUnclaimed: number;
  claimedCount: number;
  unclaimedCount: number;
}

interface AffiliateSettings {
  affiliatebonus: number;
  comissionpercent: number;
  registerbonus: number;
}

interface TeamMember {
  id: number;
  name: string;
  email: string;
  avatar: string;
  level: number;
  balance: number | null;
  games_played: number;
}

interface Team {
  ownername: string;
  referalCode: string;
  createdAt: string;
  updatedAt: string;
  owner_id: number;
  owner_name: string;
  owner_email: string;
  owner_avatar: string;
  owner_level: number;
  members: TeamMember[];
}

interface RewardRecord {
  ownername: string;
  membername: string;
  referalCode: string;
  amount: number;
  coin: string;
  type: string;
  locked: boolean;
  referalmount: number;
  createdAt: string;
  member_email: string;
  member_level: number;
}

interface TopAffiliate {
  ownername: string;
  referral_count: string;
  email: string;
  level: number;
  total_earned: string;
}

// ─── Tabs ───
type TabId = 'affiliates' | 'dashboard' | 'settings' | 'teams' | 'rewards' | 'activity';

const Referal: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabId>('affiliates');
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saveMsg, setSaveMsg] = useState('');

  // Dashboard
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [topAffiliates, setTopAffiliates] = useState<TopAffiliate[]>([]);

  // Settings
  const [settings, setSettings] = useState<AffiliateSettings>({ affiliatebonus: 0, comissionpercent: 0, registerbonus: 0 });

  // Teams
  const [teams, setTeams] = useState<Team[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedTeam, setExpandedTeam] = useState<string | null>(null);

  // Rewards
  const [rewards, setRewards] = useState<RewardRecord[]>([]);
  const [rewardsPage, setRewardsPage] = useState(1);
  const [rewardsTotalPages, setRewardsTotalPages] = useState(1);

  // ─── Fetch Functions ───
  const fetchDashboard = async () => {
    try {
      setLoading(true);
      const [statsRes, topRes] = await Promise.all([
        api.get(`/dashboard-stats`),
        api.get(`/top-affiliates?limit=10`)
      ]);
      if (statsRes.data.success) setStats(statsRes.data.data);
      if (topRes.data.success) setTopAffiliates(topRes.data.data);
    } catch (e) { console.error('Dashboard fetch error:', e); }
    finally { setLoading(false); }
  };

  const fetchSettings = async () => {
    try {
      setLoading(true);
      const res = await api.get(`/settings`);
      if (res.data.success) setSettings(res.data.data);
    } catch (e) { console.error('Settings fetch error:', e); }
    finally { setLoading(false); }
  };

  const fetchTeams = async () => {
    try {
      setLoading(true);
      const res = await api.get(`/teams`);
      if (res.data.success) setTeams(res.data.data);
    } catch (e) { console.error('Teams fetch error:', e); }
    finally { setLoading(false); }
  };

  const fetchRewards = async (page = 1) => {
    try {
      setLoading(true);
      const res = await api.get(`/rewards-list?page=${page}&limit=30`);
      if (res.data.success) {
        setRewards(res.data.data);
        setRewardsTotalPages(res.data.pagination.totalPages);
        setRewardsPage(page);
      }
    } catch (e) { console.error('Rewards fetch error:', e); }
    finally { setLoading(false); }
  };

  useEffect(() => {
    if (activeTab === 'dashboard') fetchDashboard();
    if (activeTab === 'settings') fetchSettings();
    if (activeTab === 'teams') fetchTeams();
    if (activeTab === 'rewards') fetchRewards(1);
  }, [activeTab]);

  // ─── Save Settings ───
  const handleSaveSettings = async () => {
    try {
      setSaving(true);
      setSaveMsg('');
      const res = await api.put(`/settings`, settings);
      if (res.data.success) {
        setSettings(res.data.data);
        setSaveMsg('Settings saved successfully!');
        setTimeout(() => setSaveMsg(''), 3000);
      }
    } catch (e: any) {
      console.error('Save error:', e);
      setSaveMsg(e?.response?.data?.message || 'Failed to save settings');
    } finally { setSaving(false); }
  };

  // ─── Helpers ───
  const formatDate = (d: string) => new Date(d).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
  const formatAmount = (n: number | string) => parseFloat(String(n)).toFixed(2);

  const filteredTeams = teams.filter(t =>
    t.members.length > 0 && (
      (t.owner_name || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (t.referalCode || '').toLowerCase().includes(searchTerm.toLowerCase())
    )
  );

  const stringToColor = (s: string): string => {
    let hash = 0;
    for (let i = 0; i < s.length; i++) hash = s.charCodeAt(i) + ((hash << 5) - hash);
    let color = '#';
    for (let i = 0; i < 3; i++) { const hex = ('00' + ((hash >> (i * 8)) & 0xFF).toString(16)); color += hex.slice(-2); }
    return color;
  };

  // ─── Tab Navigation ───
  const tabs: { id: TabId; label: string }[] = [
    { id: 'affiliates', label: 'Affiliates' },
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'settings', label: 'Settings' },
    { id: 'teams', label: 'Teams' },
    { id: 'rewards', label: 'Rewards Log' },
    { id: 'activity', label: 'Activity' },
  ];

  return (
    <div>
      <div className="min-h-screen bg-[#0C0D1D] p-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <h1 className="text-2xl font-bold text-[#F9F9F9] mb-6">Affiliate Management</h1>

          {/* Tab Navigation */}
          <div className="border-b border-[#1E2D55] mb-6">
            <nav className="flex space-x-8">
              {tabs.map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`py-2 px-1 border-b-2 font-medium text-sm transition-colors ${activeTab === tab.id
                    ? 'border-indigo-500 text-indigo-600'
                    : 'border-transparent text-[#878AA2] hover:text-[#878AA2] hover:border-[#1E2D55]'
                    }`}
                >
                  {tab.label}
                </button>
              ))}
            </nav>
          </div>

          {loading && (
            <div className="flex justify-center items-center h-32">
              <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-indigo-500"></div>
            </div>
          )}

          {activeTab === 'affiliates' && <AffiliatesPanel api={api} />}
          {activeTab === 'activity' && <AffiliateActivityPanel api={api} />}

          {/* ═══ Dashboard Tab ═══ */}
          {activeTab === 'dashboard' && !loading && stats && (
            <div className="space-y-6">
              {/* Stat Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <StatCard label="Total Teams" value={stats.totalTeams} color="indigo" />
                <StatCard label="Total Referrals" value={stats.totalReferrals} color="blue" />
                <StatCard label="Total Paid Out" value={`$${formatAmount(stats.totalDistributed)}`} color="green" />
                <StatCard label="Commission Paid" value={`$${formatAmount(stats.totalCommission)}`} color="emerald" />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <StatCard label="Total Locked" value={`$${formatAmount(stats.totalLocked)}`} color="yellow" />
                <StatCard label="Total Unclaimed" value={`$${formatAmount(stats.totalUnclaimed)}`} color="orange" />
                <StatCard label="Referral Claimed" value={`$${formatAmount(stats.totalClaimed)}`} color="teal" />
                <StatCard label="Unclaimed Count" value={stats.unclaimedCount} color="red" />
              </div>

              {/* Top Affiliates */}
              <div className="bg-white rounded-xl shadow-md p-6">
                <h2 className="text-lg font-semibold text-[#F9F9F9] mb-4">Top Affiliates</h2>
                {topAffiliates.length > 0 ? (
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-[#1E2D55]">
                      <thead className="bg-[#0C0D1D]">
                        <tr>
                          <th className="px-4 py-3 text-left text-xs font-medium text-[#878AA2] uppercase">#</th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-[#878AA2] uppercase">Username</th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-[#878AA2] uppercase">Email</th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-[#878AA2] uppercase">Level</th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-[#878AA2] uppercase">Referrals</th>
                          <th className="px-4 py-3 text-right text-xs font-medium text-[#878AA2] uppercase">Total Earned</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-[#1E2D55]">
                        {topAffiliates.map((a, i) => (
                          <tr key={a.ownername} className="hover:bg-[#0C0D1D]">
                            <td className="px-4 py-3 text-sm text-[#878AA2]">{i + 1}</td>
                            <td className="px-4 py-3 text-sm font-medium text-[#F9F9F9]">{a.ownername}</td>
                            <td className="px-4 py-3 text-sm text-[#878AA2]">{a.email || '-'}</td>
                            <td className="px-4 py-3">
                              <span className="px-2 py-1 text-xs rounded bg-green-100 text-green-800">
                                Lv {a.level || 1}
                              </span>
                            </td>
                            <td className="px-4 py-3 text-sm font-semibold text-indigo-600">{a.referral_count}</td>
                            <td className="px-4 py-3 text-sm text-right font-medium text-green-600">${formatAmount(a.total_earned)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <p className="text-[#878AA2] text-center py-8">No affiliates found</p>
                )}
              </div>
            </div>
          )}

          {/* ═══ Settings Tab ═══ */}
          {activeTab === 'settings' && !loading && (
            <div className="max-w-2xl">
              <div className="bg-white rounded-xl shadow-md p-6 space-y-6">
                <h2 className="text-lg font-semibold text-[#F9F9F9]">Affiliate Reward Settings</h2>
                <p className="text-sm text-[#878AA2]">Configure the rewards and commission rates for the affiliate program. Changes take effect immediately for new registrations.</p>

                <div className="space-y-4">
                  <SettingField
                    label="Joining Reward (Referral Bonus)"
                    description="Locked pool created for the referrer when someone signs up with their code. It unlocks in tiers as the member bets (0.5 at $1,000 wager, 2.5 at $5,000, …) and is claimed as BJB. Max 1000."
                    value={settings.affiliatebonus}
                    onChange={(v) => setSettings({ ...settings, affiliatebonus: v })}
                    suffix="USDT"
                  />

                  <SettingField
                    label="Commission Percentage"
                    description="Referrer earns this % of 1% of the member's wager, paid in USDT (25 = 0.25% of wager). Max 100."
                    value={settings.comissionpercent}
                    onChange={(v) => setSettings({ ...settings, comissionpercent: v })}
                    suffix="%"
                  />

                  <SettingField
                    label="Registration Bonus"
                    description="USDT credited to every new account at signup, including fake ones. Max 100."
                    value={settings.registerbonus}
                    onChange={(v) => setSettings({ ...settings, registerbonus: v })}
                    suffix="USDT"
                  />
                </div>

                <div className="flex items-center gap-4 pt-4 border-t border-[#1E2D55]">
                  <button
                    onClick={handleSaveSettings}
                    disabled={saving}
                    className="px-6 py-2.5 bg-indigo-600 text-[#F9F9F9] rounded-lg font-semibold hover:bg-indigo-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {saving ? 'Saving...' : 'Save Settings'}
                  </button>
                  {saveMsg && (
                    <span className={`text-sm font-medium ${saveMsg.includes('success') ? 'text-green-600' : 'text-red-600'}`}>
                      {saveMsg}
                    </span>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* ═══ Teams Tab ═══ */}
          {activeTab === 'teams' && !loading && (
            <div>
              <div className="mb-4">
                <input
                  type="text"
                  placeholder="Search by owner name or referral code..."
                  className="w-full md:w-80 pl-4 pr-4 py-2 border border-[#1E2D55] rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>

              <div className="bg-white rounded-xl shadow-md overflow-hidden">
                {filteredTeams.length > 0 ? (
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-[#1E2D55]">
                      <thead className="bg-[#0C0D1D]">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-[#878AA2] uppercase">Owner</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-[#878AA2] uppercase">Email</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-[#878AA2] uppercase">Referral Code</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-[#878AA2] uppercase">Members</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-[#878AA2] uppercase">Created</th>
                          <th className="px-6 py-3 text-right text-xs font-medium text-[#878AA2] uppercase">Details</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-[#1E2D55]">
                        {filteredTeams.map((team) => (
                          <React.Fragment key={team.ownername}>
                            <tr
                              className="hover:bg-[#0C0D1D] cursor-pointer transition-colors"
                              onClick={() => setExpandedTeam(expandedTeam === team.ownername ? null : team.ownername)}
                            >
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="flex items-center">
                                  <div
                                    className="h-8 w-8 rounded-full flex items-center justify-center text-[#F9F9F9] font-bold text-sm"
                                    style={{ backgroundColor: stringToColor(team.owner_name || '') }}
                                  >
                                    {(team.owner_name || '?').charAt(0).toUpperCase()}
                                  </div>
                                  <span className="ml-3 text-sm font-medium text-[#F9F9F9]">{team.owner_name || 'Unknown'}</span>
                                </div>
                              </td>
                              <td className="px-6 py-4 text-sm text-[#878AA2]">{team.owner_email || '-'}</td>
                              <td className="px-6 py-4">
                                <span className="px-3 py-1 text-xs font-semibold rounded-full bg-indigo-100 text-indigo-800">
                                  {team.referalCode || 'N/A'}
                                </span>
                              </td>
                              <td className="px-6 py-4 text-sm font-semibold text-[#878AA2]">{team.members.length}</td>
                              <td className="px-6 py-4 text-sm text-[#878AA2]">{formatDate(team.createdAt)}</td>
                              <td className="px-6 py-4 text-right">
                                <svg
                                  className={`h-5 w-5 text-indigo-600 inline-block transition-transform ${expandedTeam === team.ownername ? 'rotate-180' : ''}`}
                                  xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"
                                >
                                  <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                                </svg>
                              </td>
                            </tr>
                            {expandedTeam === team.ownername && (
                              <tr>
                                <td colSpan={6} className="px-6 py-4 bg-[#0C0D1D]">
                                  <h4 className="text-sm font-medium text-[#878AA2] mb-3">Team Members ({team.members.length})</h4>
                                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                                    {team.members.map(m => (
                                      <div key={m.id} className="bg-white p-3 rounded-lg border border-[#1E2D55] flex items-center gap-3">
                                        <div
                                          className="h-9 w-9 rounded-full flex items-center justify-center text-[#F9F9F9] font-bold text-sm flex-shrink-0"
                                          style={{ backgroundColor: stringToColor(m.name || '') }}
                                        >
                                          {(m.name || '?').charAt(0).toUpperCase()}
                                        </div>
                                        <div className="min-w-0">
                                          <div className="text-sm font-medium text-[#F9F9F9] truncate">{m.name || 'Unknown'}</div>
                                          <div className="text-xs text-[#878AA2] truncate">{m.email || '-'}</div>
                                          <span className="px-2 py-0.5 text-xs bg-green-100 text-green-800 rounded">Lv {m.level || 1}</span>
                                        </div>
                                      </div>
                                    ))}
                                  </div>
                                </td>
                              </tr>
                            )}
                          </React.Fragment>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <p className="p-8 text-center text-[#878AA2]">No teams found</p>
                )}
              </div>
            </div>
          )}

          {/* ═══ Rewards Tab ═══ */}
          {activeTab === 'rewards' && !loading && (
            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-[#1E2D55]">
                  <thead className="bg-[#0C0D1D]">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-[#878AA2] uppercase">Referrer</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-[#878AA2] uppercase">Member</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-[#878AA2] uppercase">Code</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-[#878AA2] uppercase">Type</th>
                      <th className="px-4 py-3 text-right text-xs font-medium text-[#878AA2] uppercase">Original</th>
                      <th className="px-4 py-3 text-right text-xs font-medium text-[#878AA2] uppercase">Remaining</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-[#878AA2] uppercase">Status</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-[#878AA2] uppercase">Date</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-[#1E2D55]">
                    {rewards.length > 0 ? rewards.map((r, i) => (
                      <tr key={i} className="hover:bg-[#0C0D1D]">
                        <td className="px-4 py-3 text-sm font-medium text-[#F9F9F9]">{r.ownername}</td>
                        <td className="px-4 py-3 text-sm text-[#878AA2]">{r.membername}</td>
                        <td className="px-4 py-3">
                          <span className="px-2 py-0.5 text-xs rounded bg-indigo-100 text-indigo-700">{r.referalCode}</span>
                        </td>
                        <td className="px-4 py-3 text-sm text-[#878AA2] capitalize">{r.type}</td>
                        <td className="px-4 py-3 text-sm text-right text-[#878AA2]">${formatAmount(r.referalmount || 0)}</td>
                        <td className="px-4 py-3 text-sm text-right font-medium text-[#F9F9F9]">${formatAmount(r.amount || 0)}</td>
                        <td className="px-4 py-3">
                          <span className={`px-2 py-0.5 text-xs rounded-full font-medium ${r.locked ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800'
                            }`}>
                            {r.locked ? 'Locked' : 'Unlocked'}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-sm text-[#878AA2]">{formatDate(r.createdAt)}</td>
                      </tr>
                    )) : (
                      <tr>
                        <td colSpan={8} className="px-4 py-8 text-center text-[#878AA2]">No reward records found</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* Pagination */}
              {rewardsTotalPages > 1 && (
                <div className="flex items-center justify-between px-4 py-3 border-t border-[#1E2D55]">
                  <span className="text-sm text-[#878AA2]">Page {rewardsPage} of {rewardsTotalPages}</span>
                  <div className="flex gap-2">
                    <button
                      onClick={() => fetchRewards(rewardsPage - 1)}
                      disabled={rewardsPage <= 1}
                      className="px-3 py-1 text-sm border rounded-md hover:bg-[#0C0D1D] disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      Previous
                    </button>
                    <button
                      onClick={() => fetchRewards(rewardsPage + 1)}
                      disabled={rewardsPage >= rewardsTotalPages}
                      className="px-3 py-1 text-sm border rounded-md hover:bg-[#0C0D1D] disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      Next
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// ─── Sub-components ───

const StatCard: React.FC<{ label: string; value: string | number; color: string }> = ({ label, value, color }) => {
  const colorMap: Record<string, string> = {
    indigo: 'bg-indigo-50 text-indigo-700 border-indigo-200',
    blue: 'bg-blue-50 text-blue-700 border-blue-200',
    green: 'bg-green-50 text-green-700 border-green-200',
    emerald: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    yellow: 'bg-yellow-50 text-yellow-700 border-yellow-200',
    orange: 'bg-orange-50 text-orange-700 border-orange-200',
    teal: 'bg-teal-50 text-teal-700 border-teal-200',
    red: 'bg-red-50 text-red-700 border-red-200',
  };
  return (
    <div className={`rounded-xl border p-5 ${colorMap[color] || colorMap.indigo}`}>
      <div className="text-sm font-medium opacity-80">{label}</div>
      <div className="text-2xl font-bold mt-1">{value}</div>
    </div>
  );
};

const SettingField: React.FC<{
  label: string;
  description: string;
  value: number;
  onChange: (v: number) => void;
  suffix: string;
}> = ({ label, description, value, onChange, suffix }) => (
  <div className="p-4 bg-[#0C0D1D] rounded-lg border border-[#1E2D55]">
    <label className="block text-sm font-semibold text-[#F9F9F9] mb-1">{label}</label>
    <p className="text-xs text-[#878AA2] mb-3">{description}</p>
    <div className="flex items-center gap-2">
      <input
        type="number"
        step="0.01"
        min="0"
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value) || 0)}
        className="w-40 px-3 py-2 border border-[#1E2D55] rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
      />
      <span className="text-sm font-medium text-[#878AA2]">{suffix}</span>
    </div>
  </div>
);

export default Referal;
