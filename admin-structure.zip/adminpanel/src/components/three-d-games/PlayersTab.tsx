import React, { useEffect, useState } from 'react';
import { Box, MenuItem, TextField } from '@mui/material';
import { C } from '../admin-dashboard/shared';
import * as api from '../../services/threeDGamesApi';
import { GAME_OPTIONS } from '../../services/threeDGamesApi';
import type { Filters, PlayerRow } from '../../services/threeDGamesApi';
import { DataTable, ErrorBox, Pager, Pnl, fmt, fmtDate, fmtInt, useLoad } from '../branch/ui';
import type { Col } from '../branch/ui';

const PAGE_SIZE = 20;

const SORTS = [
  { key: 'totalBet', label: 'Highest bet' },
  { key: 'profitLoss', label: 'Highest profit' },
  { key: 'commission', label: 'Most inhouse earned' },
  { key: 'rounds', label: 'Most rounds' },
  { key: 'lastPlayed', label: 'Recently played' },
];

const gameName = (key: string) => GAME_OPTIONS.find((g) => g.key === key)?.name || key;

interface Props {
  filters: Filters;
  /** open the Game Play tab for one player */
  onOpenPlayer: (userId: string) => void;
}

const PlayersTab: React.FC<Props> = ({ filters, onOpenPlayer }) => {
  const [page, setPage] = useState(1);
  const [typed, setTyped] = useState('');
  const [search, setSearch] = useState('');
  const [sortBy, setSortBy] = useState('totalBet');

  // Search as the admin pauses typing, not on every keystroke.
  useEffect(() => {
    const id = setTimeout(() => setSearch(typed.trim()), 400);
    return () => clearTimeout(id);
  }, [typed]);
  useEffect(() => setPage(1), [filters, search, sortBy]);

  const { data, loading, error, reload } = useLoad(
    () => api.getPlayers({ ...filters, search, sortBy, limit: PAGE_SIZE, offset: (page - 1) * PAGE_SIZE }),
    [filters, search, sortBy, page],
  );

  const cols: Col<PlayerRow>[] = [
    { label: 'Player', render: (r) => <Box><Box sx={{ fontWeight: 700 }}>{r.name || 'Unknown'}</Box><Box sx={{ color: C.textSecondary, fontSize: 11 }}>ID {r.userId}</Box></Box> },
    { label: 'Games', render: (r) => r.games.map(gameName).join(', ') },
    { label: 'Rounds', align: 'right', render: (r) => fmtInt(r.rounds) },
    { label: 'Won / lost', align: 'right', render: (r) => `${fmtInt(r.wins)} / ${fmtInt(r.losses)}` },
    { label: 'Total bet', align: 'right', render: (r) => fmt(r.totalBet) },
    { label: 'Won', align: 'right', render: (r) => fmt(r.won) },
    { label: 'Profit / loss', align: 'right', render: (r) => <Pnl v={r.profitLoss} bold /> },
    { label: 'Inhouse earned', align: 'right', render: (r) => <Box component="b" sx={{ color: C.success }}>{fmt(r.commission)}</Box> },
    { label: 'Last played', render: (r) => fmtDate(r.lastPlayed) },
  ];

  return (
    <Box>
      <ErrorBox error={error} onRetry={reload} />
      <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1.25, mb: 1.5 }}>
        <TextField size="small" label="Search player" placeholder="Name or user ID" value={typed}
          onChange={(e) => setTyped(e.target.value)} InputLabelProps={{ shrink: true }} sx={{ width: 240 }} />
        <TextField select size="small" label="Sort by" value={sortBy} onChange={(e) => setSortBy(e.target.value)} sx={{ width: 220 }}>
          {SORTS.map((s) => <MenuItem key={s.key} value={s.key}>{s.label}</MenuItem>)}
        </TextField>
      </Box>
      <DataTable cols={cols} rows={data?.list || []} loading={loading} rowKey={(r) => r.userId} onRowClick={(r) => onOpenPlayer(r.userId)}
        empty="Nobody played in this period" />
      <Pager page={page} totalPages={Math.max(1, Math.ceil((data?.total || 0) / PAGE_SIZE))} total={data?.total} onChange={setPage} />
    </Box>
  );
};

export default PlayersTab;
