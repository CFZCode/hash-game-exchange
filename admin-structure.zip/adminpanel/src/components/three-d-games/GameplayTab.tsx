import React, { useEffect, useState } from 'react';
import { Box, Chip, Dialog, DialogContent, DialogTitle, IconButton, Typography, alpha } from '@mui/material';
import { X } from 'lucide-react';
import { C } from '../admin-dashboard/shared';
import * as api from '../../services/threeDGamesApi';
import type { Filters, Round, RoundPlayer } from '../../services/threeDGamesApi';
import { DataTable, ErrorBox, Pager, Pnl, fmt, fmtDate, useLoad } from '../branch/ui';
import type { Col } from '../branch/ui';

const PAGE_SIZE = 20;

const SUITS: Record<string, { symbol: string; red: boolean }> = {
  H: { symbol: '♥', red: true }, D: { symbol: '♦', red: true },
  S: { symbol: '♠', red: false }, C: { symbol: '♣', red: false },
};

/** "QD" -> Q♦ */
const Card: React.FC<{ id: string }> = ({ id }) => {
  const suit = SUITS[id.slice(-1)];
  return (
    <Box component="span" sx={{
      display: 'inline-block', minWidth: 30, px: 0.5, py: 0.25, mr: 0.5, textAlign: 'center', borderRadius: 1,
      border: `1px solid ${C.border}`, bgcolor: C.cardLight, fontWeight: 700, fontSize: 12,
      color: suit?.red ? C.error : C.text,
    }}>
      {suit ? `${id.slice(0, -1)}${suit.symbol}` : id}
    </Box>
  );
};

const who = (p: { name: string | null; userId: string | null }) => (
  <Box>
    <Box sx={{ fontWeight: 700 }}>{p.name || 'Unknown'}</Box>
    <Box sx={{ color: C.textSecondary, fontSize: 11 }}>ID {p.userId || '—'}</Box>
  </Box>
);

const playerState = (p: RoundPlayer) => {
  if (p.isWinner) return { label: 'Won', color: C.success };
  if (p.isPacked) return { label: 'Packed', color: C.textSecondary };
  return { label: 'Lost', color: C.error };
};

const variantOf = (r: Round) => (r.gameType !== r.game ? ` · ${r.gameType}` : '');

const RoundDialog: React.FC<{ round: Round | null; onClose: () => void }> = ({ round, onClose }) => {
  const cols: Col<RoundPlayer>[] = [
    { label: 'Seat', render: (p) => p.seat },
    { label: 'Player', render: who },
    { label: 'Cards', render: (p) => <>{p.cards.map((c) => <Card key={c} id={c} />)}</> },
    { label: 'Play', render: (p) => [p.isSeen ? 'Seen' : 'Blind', p.isAllIn ? 'All-in' : ''].filter(Boolean).join(' · ') },
    { label: 'Bet', align: 'right', render: (p) => fmt(p.totalBet) },
    { label: 'Won', align: 'right', render: (p) => (p.won ? fmt(p.won) : '—') },
    { label: 'Inhouse cut', align: 'right', render: (p) => (p.commission ? fmt(p.commission) : '—') },
    { label: 'Profit / loss', align: 'right', render: (p) => <Pnl v={p.profitLoss} bold /> },
    { label: 'Result', render: (p) => { const s = playerState(p); return <Chip size="small" label={s.label} sx={{ height: 22, fontSize: 11, fontWeight: 700, bgcolor: alpha(s.color, 0.15), color: s.color }} />; } },
  ];
  return (
    <Dialog open={!!round} onClose={onClose} maxWidth="lg" fullWidth PaperProps={{ sx: { bgcolor: C.bg, backgroundImage: 'none', border: `1px solid ${C.border}` } }}>
      {round && (
        <>
          <DialogTitle sx={{ display: 'flex', alignItems: 'flex-start', gap: 2 }}>
            <Box sx={{ mr: 'auto' }}>
              <Typography sx={{ color: C.text, fontWeight: 800 }}>{round.gameName}{variantOf(round)} · {round.tier} table</Typography>
              <Typography sx={{ color: C.textSecondary, fontSize: 12 }}>
                {fmtDate(round.playedAt)} · Round {round.matchId} · Collection {fmt(round.totalCollection)} · Inhouse {fmt(round.commission)}
                {round.isDraw ? ' · Draw' : ''}
              </Typography>
            </Box>
            <IconButton aria-label="Close" onClick={onClose} sx={{ color: C.textSecondary }}><X size={18} /></IconButton>
          </DialogTitle>
          <DialogContent>
            <DataTable cols={cols} rows={round.players} rowKey={(p) => p.sessionId} />
          </DialogContent>
        </>
      )}
    </Dialog>
  );
};

interface Props {
  filters: Filters;
  /** show only rounds this player sat in */
  userId?: string;
  onClearUser: () => void;
}

const GameplayTab: React.FC<Props> = ({ filters, userId, onClearUser }) => {
  const [page, setPage] = useState(1);
  const [open, setOpen] = useState<Round | null>(null);
  useEffect(() => setPage(1), [filters, userId]);
  const { data, loading, error, reload } = useLoad(
    () => api.getGameplay({ ...filters, userId, limit: PAGE_SIZE, offset: (page - 1) * PAGE_SIZE }),
    [filters, userId, page],
  );

  const cols: Col<Round>[] = [
    { label: 'Played', render: (r) => fmtDate(r.playedAt) },
    { label: 'Game', render: (r) => <><b>{r.gameName}</b><Box component="span" sx={{ color: C.textSecondary, textTransform: 'capitalize' }}>{variantOf(r)}</Box></> },
    { label: 'Table', render: (r) => `${r.tier} · boot ${fmt(r.bootAmount)}` },
    { label: 'Players', align: 'right', render: (r) => r.playerCount },
    { label: 'Collection', align: 'right', render: (r) => fmt(r.totalCollection) },
    { label: 'Inhouse', align: 'right', render: (r) => <Box component="b" sx={{ color: C.success }}>{fmt(r.commission)}</Box> },
    { label: 'Winner', render: (r) => (r.winners.length ? r.winners.map((w) => `${w.name || w.userId || 'Unknown'} (${fmt(w.won)})`).join(', ') : '—') },
  ];

  return (
    <Box>
      <ErrorBox error={error} onRetry={reload} />
      {userId && (
        <Chip label={`Player ID ${userId}`} onDelete={onClearUser} size="small"
          sx={{ mb: 1.5, fontWeight: 700, bgcolor: alpha(C.primary, 0.2), color: C.primaryLight, border: `1px solid ${C.primary}` }} />
      )}
      <DataTable cols={cols} rows={data?.list || []} loading={loading} rowKey={(r) => r.matchId} onRowClick={setOpen}
        empty="No rounds played in this period" />
      <Pager page={page} totalPages={Math.max(1, Math.ceil((data?.total || 0) / PAGE_SIZE))} total={data?.total} onChange={setPage} />
      <RoundDialog round={open} onClose={() => setOpen(null)} />
    </Box>
  );
};

export default GameplayTab;
