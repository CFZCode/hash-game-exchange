import React from 'react';
import { Box, Paper, TableCell, TableRow, Typography } from '@mui/material';
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { C } from '../admin-dashboard/shared';
import * as api from '../../services/threeDGamesApi';
import type { Filters, GameSummary, TierRow } from '../../services/threeDGamesApi';
import { DataTable, ErrorBox, Tile, Tiles, cellSx, fmt, fmtDate, fmtInt, useLoad } from '../branch/ui';
import type { Col } from '../branch/ui';

interface Props {
  filters: Filters;
  /** open the Game Play tab narrowed to one game */
  onOpenGame: (game: string) => void;
}

type TierWithGame = TierRow & { gameName: string };

const sectionTitle = { color: C.text, fontWeight: 700, mb: 1, mt: 2.5 };

const DashboardTab: React.FC<Props> = ({ filters, onOpenGame }) => {
  const { data, loading, error, reload } = useLoad(() => api.getDashboard(filters), [filters]);
  const t = data?.totals;
  const pct = data?.commissionPercent ?? 5;
  const games = data?.games || [];
  const tiers: TierWithGame[] = games.flatMap((g) => g.tiers.map((x) => ({ ...x, gameName: g.name })));
  const chart = (data?.daily || []).map((d) => ({ date: d.date.slice(5), Commission: d.commission }));

  const gameCols: Col<GameSummary>[] = [
    { label: 'Game', render: (g) => <b>{g.name}</b> },
    { label: 'Rounds', align: 'right', render: (g) => fmtInt(g.rounds) },
    { label: 'Players', align: 'right', render: (g) => fmtInt(g.uniquePlayers) },
    { label: 'Total collection', align: 'right', render: (g) => fmt(g.totalCollection) },
    { label: `Inhouse ${pct}%`, align: 'right', render: (g) => <Box component="b" sx={{ color: C.success }}>{fmt(g.commission)}</Box> },
    { label: 'Paid to winners', align: 'right', render: (g) => fmt(g.payout) },
    { label: 'Live now', align: 'right', render: (g) => (g.live.players ? `${fmtInt(g.live.players)} players · ${fmtInt(g.live.runningTables)} running` : '—') },
    { label: 'Last played', render: (g) => fmtDate(g.lastPlayedAt) },
  ];
  const tierCols: Col<TierWithGame>[] = [
    { label: 'Game', render: (r) => r.gameName },
    { label: 'Table', render: (r) => r.tier },
    { label: 'Boot', align: 'right', render: (r) => fmt(r.bootAmount) },
    { label: 'Rounds', align: 'right', render: (r) => fmtInt(r.rounds) },
    { label: 'Total collection', align: 'right', render: (r) => fmt(r.totalCollection) },
    { label: `Inhouse ${pct}%`, align: 'right', render: (r) => <Box component="b" sx={{ color: C.success }}>{fmt(r.commission)}</Box> },
  ];

  const totalSx = { ...cellSx, fontWeight: 800, bgcolor: C.cardLight };

  return (
    <Box>
      <ErrorBox error={error} onRetry={reload} />

      <Tiles>
        <Tile label="Total collection" loading={loading} value={fmt(t?.totalCollection)} sub="Everything players put into the pots" />
        <Tile label={`Inhouse earning (${pct}%)`} loading={loading} accent={C.success} value={fmt(t?.commission)} sub="House cut from the winners' pots" />
        <Tile label="Paid to winners" loading={loading} accent={C.warning} value={fmt(t?.payout)} sub="Collection − inhouse" />
        <Tile label="Rounds played" loading={loading} accent={C.info} value={fmtInt(t?.rounds)} sub={`${fmtInt(t?.uniquePlayers)} players · ${fmtInt(t?.draws)} draws`} />
      </Tiles>
      <Tiles>
        <Tile label="Today" loading={loading} accent={C.success} value={fmt(data?.today.commission)}
          sub={`inhouse · ${fmtInt(data?.today.rounds)} rounds · collection ${fmt(data?.today.totalCollection)}`} />
        <Tile label="Live right now" loading={loading} accent={C.info} value={`${fmtInt(data?.live.players)} players`}
          sub={`${fmtInt(data?.live.runningTables)} tables running · ${fmtInt(data?.live.waitingTables)} waiting · ${fmt(data?.live.potOnTables)} in pots`} />
      </Tiles>

      <Typography sx={{ ...sectionTitle, mt: 1 }}>Game wise</Typography>
      <DataTable cols={gameCols} rows={games} loading={loading} rowKey={(g) => g.game} onRowClick={(g) => onOpenGame(g.game)}
        footer={games.length > 1 && t ? (
          <TableRow>
            <TableCell sx={totalSx}>All games</TableCell>
            <TableCell sx={totalSx} align="right">{fmtInt(t.rounds)}</TableCell>
            <TableCell sx={totalSx} align="right">{fmtInt(t.uniquePlayers)}</TableCell>
            <TableCell sx={totalSx} align="right">{fmt(t.totalCollection)}</TableCell>
            <TableCell sx={{ ...totalSx, color: C.success }} align="right">{fmt(t.commission)}</TableCell>
            <TableCell sx={totalSx} align="right">{fmt(t.payout)}</TableCell>
            <TableCell sx={totalSx} colSpan={2} />
          </TableRow>
        ) : undefined} />

      <Typography sx={sectionTitle}>Inhouse earning by day</Typography>
      <Paper elevation={0} sx={{ p: 2, bgcolor: C.card, border: `1px solid ${C.border}`, borderRadius: 2 }}>
        {chart.length === 0 ? (
          <Typography sx={{ color: C.textSecondary, fontSize: 13, py: 6, textAlign: 'center' }}>
            {loading ? 'Loading…' : 'No rounds played in this period'}
          </Typography>
        ) : (
          <Box sx={{ height: 260 }}>
            <ResponsiveContainer>
              <BarChart data={chart}>
                <CartesianGrid stroke={C.border} vertical={false} />
                <XAxis dataKey="date" stroke={C.textSecondary} fontSize={11} />
                <YAxis stroke={C.textSecondary} fontSize={11} tickFormatter={(v: number) => (v >= 1000 ? `${Math.round(v / 1000)}k` : String(v))} />
                <Tooltip cursor={{ fill: C.cardHover }} formatter={(v: number) => fmt(v)}
                  contentStyle={{ background: C.cardLight, border: `1px solid ${C.border}`, color: C.text }} />
                <Bar dataKey="Commission" name="Inhouse" fill={C.primary} radius={[4, 4, 0, 0]} maxBarSize={36} />
              </BarChart>
            </ResponsiveContainer>
          </Box>
        )}
      </Paper>

      <Typography sx={sectionTitle}>Table wise</Typography>
      <DataTable cols={tierCols} rows={tiers} loading={loading} rowKey={(r) => `${r.gameName}-${r.tier}`} empty="No rounds played in this period" />
    </Box>
  );
};

export default DashboardTab;
