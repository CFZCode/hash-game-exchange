// Admin "3D Games" page: collection, the house (inhouse) cut, round-by-round
// game play and who played, for Teen Patti, Zhandu, Flipper and Variation.
// Period, game, tab and player all live in the URL so a refresh or a copied
// link opens the same view.
import React, { useMemo } from 'react';
import { Box, MenuItem, Tab, Tabs, TextField } from '@mui/material';
import { GAME_OPTIONS } from '../../services/threeDGamesApi';
import { FilterBar, PageTitle, useFilters } from '../branch/ui';
import DashboardTab from './DashboardTab';
import GameplayTab from './GameplayTab';
import PlayersTab from './PlayersTab';
import LiveTab from './LiveTab';

type TabKey = 'dashboard' | 'gameplay' | 'players' | 'live';
const TABS: { key: TabKey; label: string }[] = [
  { key: 'dashboard', label: 'Dashboard' },
  { key: 'gameplay', label: 'Game play' },
  { key: 'players', label: 'Players' },
  { key: 'live', label: 'Live tables' },
];

const ThreeDGames: React.FC = () => {
  const { from, to, sp, setSp, update } = useFilters();
  const game = sp.get('game') || '';
  const userId = sp.get('userId') || '';
  const tab: TabKey = TABS.find((t) => t.key === sp.get('tab'))?.key || 'dashboard';
  const filters = useMemo(() => ({ from, to, game }), [from, to, game]);

  const clearUser = () => {
    const next = new URLSearchParams(sp);
    next.delete('userId');
    setSp(next, { replace: true });
  };

  return (
    <Box>
      <PageTitle title="3D Games" subtitle="Collection, inhouse earning and game play — Teen Patti, Zhandu, Flipper, Variation" />
      <FilterBar scope={false}>
        <TextField select size="small" label="Game" value={game} onChange={(e) => update({ game: e.target.value })}
          sx={{ minWidth: 170 }} SelectProps={{ displayEmpty: true }} InputLabelProps={{ shrink: true }}>
          <MenuItem value="">All games</MenuItem>
          {GAME_OPTIONS.map((g) => <MenuItem key={g.key} value={g.key}>{g.name}</MenuItem>)}
        </TextField>
      </FilterBar>

      <Tabs value={tab} onChange={(_, v: TabKey) => update({ tab: v })} variant="scrollable"
        sx={{ mb: 2, '& .MuiTab-root': { textTransform: 'none', fontWeight: 700 } }}>
        {TABS.map((t) => <Tab key={t.key} value={t.key} label={t.label} />)}
      </Tabs>

      {tab === 'dashboard' && <DashboardTab filters={filters} onOpenGame={(g) => update({ game: g, tab: 'gameplay' })} />}
      {tab === 'gameplay' && <GameplayTab filters={filters} userId={userId || undefined} onClearUser={clearUser} />}
      {tab === 'players' && <PlayersTab filters={filters} onOpenPlayer={(id) => update({ userId: id, tab: 'gameplay' })} />}
      {tab === 'live' && <LiveTab game={game || undefined} />}
    </Box>
  );
};

export default ThreeDGames;
