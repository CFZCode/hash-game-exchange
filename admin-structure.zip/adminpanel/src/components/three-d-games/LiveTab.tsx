import React, { useEffect } from 'react';
import { Box, Chip, Typography, alpha } from '@mui/material';
import { C } from '../admin-dashboard/shared';
import * as api from '../../services/threeDGamesApi';
import type { LiveTable } from '../../services/threeDGamesApi';
import { DataTable, ErrorBox, StatusChip, fmt, useLoad } from '../branch/ui';
import type { Col } from '../branch/ui';

const REFRESH_MS = 10000;

/** Tables with players seated right now. Cards are never sent for a live round. */
const LiveTab: React.FC<{ game?: string }> = ({ game }) => {
  const { data, loading, error, reload } = useLoad(() => api.getLive(game), [game]);

  useEffect(() => {
    const id = setInterval(reload, REFRESH_MS);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [game]);

  const cols: Col<LiveTable>[] = [
    { label: 'Game', render: (r) => <><b>{r.gameName}</b>{r.gameType !== r.game && <Box component="span" sx={{ color: C.textSecondary, textTransform: 'capitalize' }}> · {r.gameType}</Box>}</> },
    { label: 'Table', render: (r) => `${r.tier} · boot ${fmt(r.bootAmount)}` },
    { label: 'Status', render: (r) => <StatusChip status={r.status === 'running' ? 'success' : 'pending'} label={r.status === 'running' ? 'Running' : 'Waiting for players'} /> },
    { label: 'Pot', align: 'right', render: (r) => <b>{fmt(r.pot)}</b> },
    {
      label: 'Players',
      render: (r) => (
        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, whiteSpace: 'normal' }}>
          {r.players.map((p) => (
            <Chip key={p.sessionId} size="small"
              label={`${p.name || p.userId || 'Unknown'}${p.totalBet ? ` · ${fmt(p.totalBet)}` : ''}${p.isPacked ? ' · packed' : ''}${p.isTurn ? ' · turn' : ''}`}
              sx={{
                height: 22, fontSize: 11, fontWeight: 600,
                bgcolor: p.isTurn ? alpha(C.primary, 0.22) : C.cardLight,
                color: p.isPacked ? C.textSecondary : C.text,
                border: `1px solid ${p.isTurn ? C.primary : C.border}`,
              }} />
          ))}
        </Box>
      ),
    },
    { label: 'Watching', align: 'right', render: (r) => r.watchers },
  ];

  return (
    <Box>
      <ErrorBox error={error} onRetry={reload} />
      <Typography sx={{ color: C.textSecondary, fontSize: 12, mb: 1 }}>Refreshes every 10 seconds</Typography>
      {/* Skeleton only on first load — a background refresh must not blank the table. */}
      <DataTable cols={cols} rows={data?.list || []} loading={loading && !data} rowKey={(r) => r.matchId}
        empty="No one is at a table right now" />
    </Box>
  );
};

export default LiveTab;
