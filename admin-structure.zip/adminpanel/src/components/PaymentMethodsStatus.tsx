import React, { useState, useEffect, useCallback } from 'react';
import {
  Card,
  CardContent,
  CardHeader,
  Typography,
  Button,
  CircularProgress,
  Alert,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Box,
  Stack,
} from '@mui/material';
import { Refresh as RefreshIcon } from '@mui/icons-material';

/**
 * Payment Methods — live status page.
 *
 * Shows every payment system A-Pay (Paykassma) currently has for our project,
 * grouped per currency in business order (INR, PKR, NPR, BDT), each currency's
 * methods in the gateway's own sequence. The backend reads this live from
 * A-Pay's payment-systems-info, so when Paykassma enables/disables a method it
 * changes here (and on the site) with no deploy.
 *
 * "On site" can differ from "Gateway": imps is deposit-enabled at the gateway
 * but hidden on the site (it is our withdrawal channel), and FTD-restricted
 * methods are only shown to users with a successful deposit behind them.
 */

interface MethodInfo {
  name: string;
  label: string;
  deposit: {
    gateway_enabled: boolean;
    site_offered: boolean;
    min: number;
    max: number;
  };
  withdrawal: {
    gateway_enabled: boolean;
    min: number;
    max: number;
  };
  notes: string[];
}

interface CurrencyBlock {
  currency: string;
  methods: MethodInfo[];
}

interface Overview {
  success: boolean;
  project_id: string;
  fetched_at: string | null;
  cache_age_seconds: number | null;
  currencies: CurrencyBlock[];
}

const CURRENCY_TITLES: Record<string, string> = {
  INR: 'INR — India',
  PKR: 'PKR — Pakistan',
  NPR: 'NPR — Nepal',
  BDT: 'BDT — Bangladesh',
};

const fmtRange = (min: number, max: number) =>
  min || max ? `${min.toLocaleString()} – ${max.toLocaleString()}` : '—';

const OnOff: React.FC<{ on: boolean; onLabel?: string; offLabel?: string }> = ({
  on,
  onLabel = 'Enabled',
  offLabel = 'Disabled',
}) => (
  <Chip
    label={on ? onLabel : offLabel}
    color={on ? 'success' : 'default'}
    size="small"
    variant={on ? 'filled' : 'outlined'}
  />
);

const PaymentMethodsStatus: React.FC = () => {
  const [data, setData] = useState<Overview | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchOverview = useCallback(async (fresh: boolean) => {
    try {
      setLoading(true);
      setError(null);
      const response = await fetch(
        `https://example.com/remotes/payment-systems-overview${fresh ? '?fresh=1' : ''}`
      );
      const json = await response.json();
      if (json.success) {
        setData(json);
      } else {
        setError(json.message || 'Failed to fetch payment systems');
      }
    } catch (err) {
      setError('Error connecting to server');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchOverview(false);
    // The gateway list changes without notice — keep the page current while
    // it is open (same 60s cadence support watches the technical chat with).
    const timer = setInterval(() => fetchOverview(false), 60_000);
    return () => clearInterval(timer);
  }, [fetchOverview]);

  return (
    <Box sx={{ p: 2 }}>
      <Card>
        <CardHeader
          title="Payment Methods — Live Status"
          subheader={
            data?.fetched_at
              ? `Read live from A-Pay (Paykassma), project ${data.project_id}. Gateway data as of ${new Date(
                  data.fetched_at
                ).toLocaleString()} (cache ${data.cache_age_seconds ?? '?'}s, refreshes every 5 min).`
              : 'Read live from A-Pay (Paykassma).'
          }
          action={
            <Button
              variant="outlined"
              startIcon={loading ? <CircularProgress size={16} /> : <RefreshIcon />}
              onClick={() => fetchOverview(true)}
              disabled={loading}
            >
              Refresh from gateway
            </Button>
          }
        />
        <CardContent>
          {error && (
            <Alert severity="error" sx={{ mb: 2 }}>
              {error}
            </Alert>
          )}

          {loading && !data && (
            <Box sx={{ display: 'flex', justifyContent: 'center', py: 6 }}>
              <CircularProgress />
            </Box>
          )}

          {data?.currencies.map((block) => (
            <Box key={block.currency} sx={{ mb: 4 }}>
              <Typography variant="h6" sx={{ mb: 1 }}>
                {CURRENCY_TITLES[block.currency] || block.currency}
              </Typography>

              {block.methods.length === 0 ? (
                <Alert severity="warning">
                  No payment systems are configured for {block.currency} right now.
                </Alert>
              ) : (
                <TableContainer component={Paper} variant="outlined">
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>Method</TableCell>
                        <TableCell>System name</TableCell>
                        <TableCell>Deposit (gateway)</TableCell>
                        <TableCell>Deposit (on site)</TableCell>
                        <TableCell>Deposit limits</TableCell>
                        <TableCell>Withdrawal</TableCell>
                        <TableCell>Withdrawal limits</TableCell>
                        <TableCell>Notes</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {block.methods.map((m) => (
                        <TableRow key={m.name} hover>
                          <TableCell>
                            <Typography variant="body2" fontWeight={600}>
                              {m.label}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            <Typography variant="body2" color="text.secondary">
                              {m.name}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            <OnOff on={m.deposit.gateway_enabled} />
                          </TableCell>
                          <TableCell>
                            <OnOff
                              on={m.deposit.site_offered}
                              onLabel="Shown"
                              offLabel="Hidden"
                            />
                          </TableCell>
                          <TableCell>
                            {m.deposit.gateway_enabled
                              ? fmtRange(m.deposit.min, m.deposit.max)
                              : '—'}
                          </TableCell>
                          <TableCell>
                            <OnOff on={m.withdrawal.gateway_enabled} />
                          </TableCell>
                          <TableCell>
                            {m.withdrawal.gateway_enabled
                              ? fmtRange(m.withdrawal.min, m.withdrawal.max)
                              : '—'}
                          </TableCell>
                          <TableCell>
                            <Stack direction="column" spacing={0.5}>
                              {m.notes.length === 0 ? (
                                <Typography variant="caption" color="text.secondary">
                                  —
                                </Typography>
                              ) : (
                                m.notes.map((n) => (
                                  <Typography key={n} variant="caption" color="warning.main">
                                    {n}
                                  </Typography>
                                ))
                              )}
                            </Stack>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              )}
            </Box>
          ))}
        </CardContent>
      </Card>
    </Box>
  );
};

export default PaymentMethodsStatus;
