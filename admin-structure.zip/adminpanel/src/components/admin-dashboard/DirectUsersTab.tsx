import React, { useState, useEffect, useMemo } from 'react';
import {
  Box, Paper, Typography, Grid, Avatar, Chip, Divider,
  IconButton, Tooltip as MuiTooltip, alpha,
} from '@mui/material';
import {
  PeopleAlt, AccountBalanceWallet, TrendingUp, TrendingDown,
  ArrowUpward, ArrowDownward, Refresh, VerifiedUser,
  CurrencyExchange, CalendarToday, ShowChart, PieChartOutline,
  AssessmentOutlined, AccountBalance, Savings, Receipt,
} from '@mui/icons-material';
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from 'recharts';
import { C, CHART_COLORS, StatCard, ChartCard, CustomTooltip, fmtCurrency, fmtNum, pct } from './shared';
import { apiFetch } from '../../utils/api';

interface Breakdown { crypto: string; fiat: string; upi?: string; payIn?: string; }
interface TransactionBreakdown {
  crypto: { amount: string; count: number };
  fiat: { amount: string; count: number };
  upi?: { amount: string; count: number };
  payIn?: { amount: string; count: number };
}
interface Deposits {
  total: string; previousTotal: string; breakdown: Breakdown;
  today: { amount: string; count: number; breakdown: TransactionBreakdown };
}
interface Withdrawals {
  total: string; previousTotal: string; breakdown: Partial<Breakdown>;
  today: { amount: string; count: number; breakdown: Partial<TransactionBreakdown> };
}
interface Financials { netBalance: string; previousNetBalance: string; todayNetBalance: string; }
interface DashboardData {
  totalUsers: number; previousTotalUsers: number; newUsersToday: number;
  deposits: Deposits; withdrawals: Withdrawals; financials: Financials;
  timestamp: string; date: string;
}
interface RegistrationTrendItem { date: string; count: number; }
interface CountryItem { country: string; count: number; }
interface UserStats {
  totalUsers: number; previousTotalUsers: number; newUsersToday: number;
  activeUsers30d: number; previousActiveUsers30d: number;
  verifiedUsers: number; previousVerifiedUsers: number;
  topCountries: CountryItem[]; registrationTrend: RegistrationTrendItem[];
  timestamp: string;
}

const DirectUsersTab: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const [dashboardData, setDashboardData] = useState<DashboardData>({
    totalUsers: 0, previousTotalUsers: 0, newUsersToday: 0,
    deposits: {
      total: "0", previousTotal: "0",
      breakdown: { crypto: "0", fiat: "0", upi: "0", payIn: "0" },
      today: { amount: "0", count: 0, breakdown: { crypto: { amount: "0", count: 0 }, fiat: { amount: "0", count: 0 }, upi: { amount: "0", count: 0 }, payIn: { amount: "0", count: 0 } } }
    },
    withdrawals: {
      total: "0", previousTotal: "0", breakdown: { crypto: "0", fiat: "0" },
      today: { amount: "0", count: 0, breakdown: { crypto: { amount: "0", count: 0 }, fiat: { amount: "0", count: 0 } } }
    },
    financials: { netBalance: "0", previousNetBalance: "0", todayNetBalance: "0" },
    timestamp: "", date: ""
  });
  const [userStats, setUserStats] = useState<UserStats>({
    totalUsers: 0, previousTotalUsers: 0, newUsersToday: 0,
    activeUsers30d: 0, previousActiveUsers30d: 0,
    verifiedUsers: 0, previousVerifiedUsers: 0,
    topCountries: [], registrationTrend: [], timestamp: ""
  });

  const fetchAll = async () => {
    setLoading(true);
    try {
      const [dashRes, statsRes] = await Promise.allSettled([
        apiFetch<DashboardData>('/api/admin/dashboard'),
        apiFetch<UserStats>('/api/admin/user-stats'),
      ]);
      if (dashRes.status === 'fulfilled') setDashboardData(dashRes.value);
      if (statsRes.status === 'fulfilled') setUserStats(statsRes.value);
    } catch (e) { /* silent */ }
    setLoading(false);
  };

  useEffect(() => { fetchAll(); const i = setInterval(fetchAll, 300000); return () => clearInterval(i); }, []);

  const depositPie = useMemo(() => [
    { name: 'Crypto', value: parseFloat(dashboardData.deposits.breakdown.crypto || "0") },
    { name: 'Fiat', value: parseFloat(dashboardData.deposits.breakdown.fiat || "0") },
  ], [dashboardData]);

  const withdrawPie = useMemo(() => [
    { name: 'Crypto', value: parseFloat(dashboardData.withdrawals.breakdown.crypto || "0") },
    { name: 'Fiat', value: parseFloat(dashboardData.withdrawals.breakdown.fiat || "0") },
  ], [dashboardData]);

  const trendData = useMemo(() =>
    userStats.registrationTrend.map(item => ({
      date: new Date(item.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      users: item.count,
    })),
    [userStats]
  );

  const countryData = useMemo(() => userStats.topCountries.slice(0, 8), [userStats]);
  const netBal = parseFloat(dashboardData.financials.netBalance);
  const todayNet = parseFloat(dashboardData.financials.todayNetBalance);

  return (
    <Box>
      {/* Header */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Box>
          <Typography sx={{ color: C.text, fontWeight: 800, fontSize: { xs: '1.3rem', sm: '1.5rem' }, lineHeight: 1.2 }}>
            Direct Users Overview
          </Typography>
          <Typography sx={{ color: C.textMuted, fontSize: '0.78rem', mt: 0.25 }}>
            Registrations, deposits & withdrawals for direct platform users
          </Typography>
        </Box>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <Chip
            icon={<CalendarToday sx={{ fontSize: 14 }} />}
            label={new Date().toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
            size="small"
            sx={{ bgcolor: C.cardLight, color: C.textMuted, border: `1px solid ${C.border}`, fontWeight: 500, '& .MuiChip-icon': { color: C.textSecondary } }}
          />
          <MuiTooltip title="Refresh data">
            <IconButton onClick={fetchAll} size="small" sx={{ color: C.textSecondary, bgcolor: C.cardLight, border: `1px solid ${C.border}`, '&:hover': { bgcolor: C.cardHover, borderColor: C.primary } }}>
              <Refresh fontSize="small" />
            </IconButton>
          </MuiTooltip>
        </Box>
      </Box>

      {/* Row 1: Main Stats */}
      <Grid container spacing={2} sx={{ mb: 2.5 }}>
        <Grid item xs={12} sm={6} lg={3}>
          <StatCard loading={loading} icon={<PeopleAlt />} iconBg={C.primaryLight} title="Total Users" value={fmtNum(dashboardData.totalUsers)} subtitle={`New today: ${fmtNum(dashboardData.newUsersToday)}`} change={pct(dashboardData.totalUsers, dashboardData.previousTotalUsers)} />
        </Grid>
        <Grid item xs={12} sm={6} lg={3}>
          <StatCard loading={loading} icon={<Savings />} iconBg={C.success} title="Total Deposits" value={fmtCurrency(dashboardData.deposits.total)} subtitle={`Today: ${fmtCurrency(dashboardData.deposits.today.amount)}`} change={pct(parseFloat(dashboardData.deposits.total), parseFloat(dashboardData.deposits.previousTotal))} />
        </Grid>
        <Grid item xs={12} sm={6} lg={3}>
          <StatCard loading={loading} icon={<AccountBalanceWallet />} iconBg={C.error} title="Total Withdrawals" value={fmtCurrency(dashboardData.withdrawals.total)} subtitle={`Today: ${fmtCurrency(dashboardData.withdrawals.today.amount)}`} change={pct(parseFloat(dashboardData.withdrawals.total), parseFloat(dashboardData.withdrawals.previousTotal))} />
        </Grid>
        <Grid item xs={12} sm={6} lg={3}>
          <StatCard loading={loading} icon={<CurrencyExchange />} iconBg="#7B5EF5" title="Net Balance" value={fmtCurrency(dashboardData.financials.netBalance)} subtitle={`Today: ${fmtCurrency(dashboardData.financials.todayNetBalance)}`} change={pct(parseFloat(dashboardData.financials.netBalance), parseFloat(dashboardData.financials.previousNetBalance))} />
        </Grid>
      </Grid>

      {/* Row 2: Secondary Stats */}
      <Grid container spacing={2} sx={{ mb: 2.5 }}>
        <Grid item xs={12} sm={6} lg={3}>
          <StatCard loading={loading} icon={<VerifiedUser />} iconBg={C.info} title="Active Users (30d)" value={fmtNum(userStats.activeUsers30d)} subtitle={`Verification: ${userStats.totalUsers > 0 ? ((userStats.verifiedUsers / userStats.totalUsers) * 100).toFixed(1) : '0'}%`} change={pct(userStats.activeUsers30d, userStats.previousActiveUsers30d)} />
        </Grid>
        <Grid item xs={12} sm={6} lg={3}>
          <StatCard loading={loading} icon={<ArrowUpward />} iconBg={C.success} title="Today's Deposits" value={fmtCurrency(dashboardData.deposits.today.amount)} subtitle={`${dashboardData.deposits.today.count} transactions`} change={0} />
        </Grid>
        <Grid item xs={12} sm={6} lg={3}>
          <StatCard loading={loading} icon={<ArrowDownward />} iconBg={C.error} title="Today's Withdrawals" value={fmtCurrency(dashboardData.withdrawals.today.amount)} subtitle={`${dashboardData.withdrawals.today.count} transactions`} change={0} />
        </Grid>
        <Grid item xs={12} sm={6} lg={3}>
          <StatCard loading={loading} icon={<Receipt />} iconBg={C.warning} title="Verified Users" value={fmtNum(userStats.verifiedUsers)} subtitle={`KYC: ${userStats.totalUsers > 0 ? ((userStats.verifiedUsers / userStats.totalUsers) * 100).toFixed(1) : '0'}%`} change={pct(userStats.verifiedUsers, userStats.previousVerifiedUsers)} />
        </Grid>
      </Grid>

      {/* Row 3: Charts */}
      <Grid container spacing={2} sx={{ mb: 2.5 }}>
        <Grid item xs={12} lg={8}>
          <ChartCard title="User Registration Trend" icon={<ShowChart sx={{ fontSize: 18 }} />} height={300}>
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trendData}>
                <defs>
                  <linearGradient id="colorUsers" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={C.primary} stopOpacity={0.4} />
                    <stop offset="100%" stopColor={C.primary} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke={C.border} />
                <XAxis dataKey="date" tick={{ fill: C.textMuted, fontSize: 11 }} axisLine={{ stroke: C.border }} tickLine={false} />
                <YAxis tick={{ fill: C.textMuted, fontSize: 11 }} axisLine={{ stroke: C.border }} tickLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Area type="monotone" dataKey="users" name="New Users" stroke={C.primary} strokeWidth={2.5} fill="url(#colorUsers)" dot={false} activeDot={{ r: 5, fill: C.primary, stroke: C.text, strokeWidth: 2 }} />
              </AreaChart>
            </ResponsiveContainer>
          </ChartCard>
        </Grid>
        <Grid item xs={12} lg={4}>
          <ChartCard title="Top Countries" icon={<AssessmentOutlined sx={{ fontSize: 18 }} />} height={300}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={countryData} layout="vertical" margin={{ left: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={C.border} horizontal={false} />
                <XAxis type="number" tick={{ fill: C.textMuted, fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis dataKey="country" type="category" tick={{ fill: C.textMuted, fontSize: 11 }} axisLine={false} tickLine={false} width={70} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="count" name="Users" radius={[0, 6, 6, 0]} barSize={18}>
                  {countryData.map((_, i) => (
                    <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        </Grid>
      </Grid>

      {/* Row 4: Pie Charts */}
      <Grid container spacing={2} sx={{ mb: 2.5 }}>
        <Grid item xs={12} md={6}>
          <ChartCard title="Deposit Distribution" icon={<PieChartOutline sx={{ fontSize: 18 }} />} height={240}>
            <Box sx={{ display: 'flex', height: '100%' }}>
              <Box sx={{ flex: 1 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={depositPie} cx="50%" cy="50%" innerRadius={55} outerRadius={85} paddingAngle={4} dataKey="value" stroke="none">
                      {depositPie.map((_, i) => <Cell key={i} fill={['#2B6EF5', '#7B5EF5'][i]} />)}
                    </Pie>
                    <Tooltip content={<CustomTooltip />} />
                  </PieChart>
                </ResponsiveContainer>
              </Box>
              <Box sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 1.5, minWidth: 140 }}>
                {[{ label: 'Crypto', val: dashboardData.deposits.breakdown.crypto, color: '#2B6EF5' }, { label: 'Fiat', val: dashboardData.deposits.breakdown.fiat, color: '#7B5EF5' }].map(item => (
                  <Box key={item.label} sx={{ bgcolor: C.cardHover, borderRadius: 2, p: 1.5 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75, mb: 0.25 }}>
                      <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: item.color }} />
                      <Typography sx={{ color: C.textMuted, fontSize: '0.7rem' }}>{item.label}</Typography>
                    </Box>
                    <Typography sx={{ color: C.text, fontWeight: 700, fontSize: '0.85rem' }}>{fmtCurrency(item.val)}</Typography>
                  </Box>
                ))}
              </Box>
            </Box>
          </ChartCard>
        </Grid>
        <Grid item xs={12} md={6}>
          <ChartCard title="Withdrawal Distribution" icon={<PieChartOutline sx={{ fontSize: 18 }} />} height={240}>
            <Box sx={{ display: 'flex', height: '100%' }}>
              <Box sx={{ flex: 1 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={withdrawPie} cx="50%" cy="50%" innerRadius={55} outerRadius={85} paddingAngle={4} dataKey="value" stroke="none">
                      {withdrawPie.map((_, i) => <Cell key={i} fill={[C.error, '#FF6B8A'][i]} />)}
                    </Pie>
                    <Tooltip content={<CustomTooltip />} />
                  </PieChart>
                </ResponsiveContainer>
              </Box>
              <Box sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 1.5, minWidth: 140 }}>
                {[{ label: 'Crypto', val: dashboardData.withdrawals.breakdown.crypto, color: C.error }, { label: 'Fiat', val: dashboardData.withdrawals.breakdown.fiat, color: '#FF6B8A' }].map(item => (
                  <Box key={item.label} sx={{ bgcolor: C.cardHover, borderRadius: 2, p: 1.5 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75, mb: 0.25 }}>
                      <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: item.color }} />
                      <Typography sx={{ color: C.textMuted, fontSize: '0.7rem' }}>{item.label}</Typography>
                    </Box>
                    <Typography sx={{ color: C.text, fontWeight: 700, fontSize: '0.85rem' }}>{fmtCurrency(item.val)}</Typography>
                  </Box>
                ))}
              </Box>
            </Box>
          </ChartCard>
        </Grid>
      </Grid>

      {/* Row 5: Today's Activity */}
      <Grid container spacing={2} sx={{ mb: 2.5 }}>
        <Grid item xs={12} lg={8}>
          <Paper elevation={0} sx={{ p: 3, borderRadius: 3, bgcolor: C.card, border: `1px solid ${C.border}` }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2.5 }}>
              <Avatar sx={{ bgcolor: alpha(C.info, 0.12), color: C.info, width: 32, height: 32 }}>
                <AssessmentOutlined sx={{ fontSize: 18 }} />
              </Avatar>
              <Typography sx={{ color: C.text, fontWeight: 700, fontSize: '0.95rem' }}>Today's Activity</Typography>
            </Box>
            <Grid container spacing={2}>
              <Grid item xs={12} md={6}>
                <Box sx={{ bgcolor: C.cardHover, borderRadius: 2, p: 2, border: `1px solid ${alpha(C.success, 0.2)}` }}>
                  <Typography sx={{ color: C.success, fontWeight: 700, fontSize: '0.85rem', mb: 1.5 }}>Deposits</Typography>
                  <Grid container spacing={1.5}>
                    {[
                      { label: 'Crypto', amount: dashboardData.deposits.today.breakdown.crypto?.amount, count: dashboardData.deposits.today.breakdown.crypto?.count },
                      { label: 'Fiat', amount: dashboardData.deposits.today.breakdown.fiat?.amount, count: dashboardData.deposits.today.breakdown.fiat?.count },
                    ].map(item => (
                      <Grid item xs={6} key={item.label}>
                        <Typography sx={{ color: C.textMuted, fontSize: '0.7rem' }}>{item.label}</Typography>
                        <Typography sx={{ color: C.text, fontWeight: 700, fontSize: '0.9rem' }}>{fmtCurrency(item.amount)}</Typography>
                        <Typography sx={{ color: C.textSecondary, fontSize: '0.65rem' }}>{item.count || 0} txns</Typography>
                      </Grid>
                    ))}
                  </Grid>
                  <Divider sx={{ my: 1.5, borderColor: C.border }} />
                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                    <Typography sx={{ color: C.textSecondary, fontSize: '0.78rem' }}>Total</Typography>
                    <Typography sx={{ color: C.success, fontWeight: 800, fontSize: '0.9rem' }}>{fmtCurrency(dashboardData.deposits.today.amount)}</Typography>
                  </Box>
                </Box>
              </Grid>
              <Grid item xs={12} md={6}>
                <Box sx={{ bgcolor: C.cardHover, borderRadius: 2, p: 2, border: `1px solid ${alpha(C.error, 0.2)}` }}>
                  <Typography sx={{ color: C.error, fontWeight: 700, fontSize: '0.85rem', mb: 1.5 }}>Withdrawals</Typography>
                  <Grid container spacing={1.5}>
                    {[
                      { label: 'Crypto', amount: dashboardData.withdrawals.today.breakdown.crypto?.amount, count: dashboardData.withdrawals.today.breakdown.crypto?.count },
                      { label: 'Fiat', amount: dashboardData.withdrawals.today.breakdown.fiat?.amount, count: dashboardData.withdrawals.today.breakdown.fiat?.count },
                    ].map(item => (
                      <Grid item xs={6} key={item.label}>
                        <Typography sx={{ color: C.textMuted, fontSize: '0.7rem' }}>{item.label}</Typography>
                        <Typography sx={{ color: C.text, fontWeight: 700, fontSize: '0.9rem' }}>{fmtCurrency(item.amount)}</Typography>
                        <Typography sx={{ color: C.textSecondary, fontSize: '0.65rem' }}>{item.count || 0} txns</Typography>
                      </Grid>
                    ))}
                  </Grid>
                  <Divider sx={{ my: 1.5, borderColor: C.border }} />
                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                    <Typography sx={{ color: C.textSecondary, fontSize: '0.78rem' }}>Total</Typography>
                    <Typography sx={{ color: C.error, fontWeight: 800, fontSize: '0.9rem' }}>{fmtCurrency(dashboardData.withdrawals.today.amount)}</Typography>
                  </Box>
                </Box>
              </Grid>
            </Grid>
          </Paper>
        </Grid>
        <Grid item xs={12} lg={4}>
          <Paper elevation={0} sx={{ p: 3, borderRadius: 3, bgcolor: C.card, border: `1px solid ${C.border}`, height: '100%' }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2.5 }}>
              <Avatar sx={{ bgcolor: alpha('#7B5EF5', 0.12), color: '#7B5EF5', width: 32, height: 32 }}>
                <AccountBalance sx={{ fontSize: 18 }} />
              </Avatar>
              <Typography sx={{ color: C.text, fontWeight: 700, fontSize: '0.95rem' }}>Financial Summary</Typography>
            </Box>
            <Box sx={{ bgcolor: C.cardHover, borderRadius: 2, p: 2, mb: 1.5, border: `1px solid ${C.border}` }}>
              <Typography sx={{ color: C.textMuted, fontSize: '0.7rem', mb: 0.5 }}>All-time Net Balance</Typography>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <Typography sx={{ color: netBal >= 0 ? C.success : C.error, fontWeight: 800, fontSize: '1.3rem' }}>
                  {fmtCurrency(dashboardData.financials.netBalance)}
                </Typography>
                {netBal >= 0 ? <TrendingUp sx={{ color: C.success, fontSize: 28 }} /> : <TrendingDown sx={{ color: C.error, fontSize: 28 }} />}
              </Box>
            </Box>
            <Box sx={{ bgcolor: C.cardHover, borderRadius: 2, p: 2, border: `1px solid ${C.border}` }}>
              <Typography sx={{ color: C.textMuted, fontSize: '0.7rem', mb: 0.5 }}>Today's Net Balance</Typography>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <Typography sx={{ color: todayNet >= 0 ? C.success : C.error, fontWeight: 800, fontSize: '1.3rem' }}>
                  {fmtCurrency(dashboardData.financials.todayNetBalance)}
                </Typography>
                {todayNet >= 0 ? <TrendingUp sx={{ color: C.success, fontSize: 28 }} /> : <TrendingDown sx={{ color: C.error, fontSize: 28 }} />}
              </Box>
            </Box>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default DirectUsersTab;
