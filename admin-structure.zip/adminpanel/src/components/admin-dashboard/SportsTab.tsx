import React, { useEffect, useMemo, useState } from 'react';
import {
  Box, Paper, Typography, Grid, Avatar, Chip, Divider,
  IconButton, Tooltip as MuiTooltip, alpha,
} from '@mui/material';
import {
  SportsCricket, ListAlt, Timeline, Warning, Refresh, CalendarToday,
  ShowChart, Equalizer, AssessmentOutlined, AccountBalance,
} from '@mui/icons-material';
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, Cell,
} from 'recharts';
import { C, CHART_COLORS, StatCard, ChartCard, CustomTooltip, fmtCurrency, fmtNum } from './shared';

const API_BASE = 'https://example.com';

interface BetRow {
  id: string; user_id: number; username: string; created_at: string;
  description: string; selection: string; game_type: string;
  bet_type: string | null; odds: number; amount: number; liability: number;
  status: string; result_status: string;
}

interface ReportRow {
  bet_id: number; user_id: number; username: string; event: string;
  game_type: string; market: string; selection: string; match_title: string;
  bet_type: string; stake: number; odds: number; ledger_amount: number;
  profit: number; loss: number; netamount: number; commission: number;
  closing: number; settled_at: string;
}

const SPORT_NAME: Record<string, string> = {
  '4': 'Cricket', '1': 'Football', '2': 'Tennis',
  '8': 'Table Tennis', '15': 'Basketball', '66': 'Kabaddi',
};

const todayIso = () => new Date().toISOString().split('T')[0];
const isoNDaysAgo = (n: number) => {
  const d = new Date(); d.setDate(d.getDate() - n);
  return d.toISOString().split('T')[0];
};

const SportsTab: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const [openBets, setOpenBets] = useState<BetRow[]>([]);
  const [settledToday, setSettledToday] = useState<ReportRow[]>([]);
  const [settled7d, setSettled7d] = useState<ReportRow[]>([]);

  const staffId = localStorage.getItem('currentUserId') || '';

  // Demo accounts play with fake money — keep them out of dashboard totals.
  const nonDemo = (rows: any): any[] => (Array.isArray(rows) ? rows : []).filter((r: any) => !r?.is_demo);

  const fetchAll = async () => {
    setLoading(true);
    try {
      const headers: Record<string, string> = staffId ? { 'x-staff-id': staffId } : {};
      const [openRes, todayRes, weekRes] = await Promise.allSettled([
        fetch(`${API_BASE}/api/sportsmain/admin/bet-list?type=current&page=1&limit=200`, { headers }),
        fetch(`${API_BASE}/api/sportsmain/admin/game-report`, {
          method: 'POST',
          headers: { ...headers, 'Content-Type': 'application/json' },
          body: JSON.stringify({ event: 'ALL', fromDate: todayIso(), toDate: todayIso(), limit: 500, offset: 0 }),
        }),
        fetch(`${API_BASE}/api/sportsmain/admin/game-report`, {
          method: 'POST',
          headers: { ...headers, 'Content-Type': 'application/json' },
          body: JSON.stringify({ event: 'ALL', fromDate: isoNDaysAgo(6), toDate: todayIso(), limit: 1000, offset: 0 }),
        }),
      ]);
      if (openRes.status === 'fulfilled' && openRes.value.ok) {
        const j = await openRes.value.json();
        setOpenBets(nonDemo(j?.data));
      }
      if (todayRes.status === 'fulfilled' && todayRes.value.ok) {
        const j = await todayRes.value.json();
        setSettledToday(nonDemo(j?.data));
      }
      if (weekRes.status === 'fulfilled' && weekRes.value.ok) {
        const j = await weekRes.value.json();
        setSettled7d(nonDemo(j?.data));
      }
    } catch { /* silent */ }
    setLoading(false);
  };

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => { fetchAll(); const i = setInterval(fetchAll, 60000); return () => clearInterval(i); }, []);

  /* ── Aggregates ── */
  const totals = useMemo(() => {
    const totalLiability = openBets.reduce((s, b) => s + Number(b.liability || 0), 0);
    const totalStakeOpen = openBets.reduce((s, b) => s + Number(b.amount || 0), 0);
    const totalUsersOpen = new Set(openBets.map(b => b.user_id)).size;

    const stakeToday = settledToday.reduce((s, r) => s + Number(r.stake || 0), 0);
    const profitToday = settledToday.reduce((s, r) => s + Number(r.profit || 0), 0);
    const lossToday = settledToday.reduce((s, r) => s + Number(r.loss || 0), 0);
    const ggrToday = lossToday - profitToday; /* operator GGR */
    const commToday = settledToday.reduce((s, r) => s + Number(r.commission || 0), 0);

    return {
      openCount: openBets.length, totalLiability, totalStakeOpen, totalUsersOpen,
      stakeToday, profitToday, lossToday, ggrToday, commToday,
    };
  }, [openBets, settledToday]);

  /* ── 7-day GGR trend ── */
  const trendData = useMemo(() => {
    const buckets: Record<string, { ggr: number; turnover: number }> = {};
    for (let i = 6; i >= 0; i--) {
      const d = new Date(); d.setDate(d.getDate() - i);
      const key = d.toISOString().split('T')[0];
      buckets[key] = { ggr: 0, turnover: 0 };
    }
    settled7d.forEach(r => {
      const day = (r.settled_at || '').split('T')[0];
      if (!buckets[day]) return;
      buckets[day].turnover += Number(r.stake || 0);
      buckets[day].ggr += Number(r.loss || 0) - Number(r.profit || 0);
    });
    return Object.entries(buckets).map(([day, v]) => ({
      date: new Date(day).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      ggr: Number(v.ggr.toFixed(2)),
      turnover: Number(v.turnover.toFixed(2)),
    }));
  }, [settled7d]);

  /* ── Open bets by sport ── */
  const sportData = useMemo(() => {
    const map: Record<string, number> = {};
    openBets.forEach(b => {
      const name = b.game_type || 'Other';
      map[name] = (map[name] || 0) + Number(b.amount || 0);
    });
    return Object.entries(map)
      .map(([name, value]) => ({ name, value: Number(value.toFixed(2)) }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 8);
  }, [openBets]);

  /* ── Top users by liability ── */
  const topUsers = useMemo(() => {
    const map: Record<string, { name: string; liability: number; bets: number }> = {};
    openBets.forEach(b => {
      const k = String(b.user_id);
      if (!map[k]) map[k] = { name: b.username || `#${b.user_id}`, liability: 0, bets: 0 };
      map[k].liability += Number(b.liability || 0);
      map[k].bets += 1;
    });
    return Object.values(map).sort((a, b) => b.liability - a.liability).slice(0, 6);
  }, [openBets]);

  /* ── Top sports by 7-day turnover ── */
  const topSports = useMemo(() => {
    const map: Record<string, { stake: number; ggr: number; bets: number }> = {};
    settled7d.forEach(r => {
      const key = SPORT_NAME[String(r.event)] || r.game_type || `Sport ${r.event}`;
      if (!map[key]) map[key] = { stake: 0, ggr: 0, bets: 0 };
      map[key].stake += Number(r.stake || 0);
      map[key].ggr += Number(r.loss || 0) - Number(r.profit || 0);
      map[key].bets += 1;
    });
    return Object.entries(map)
      .map(([name, v]) => ({ name, ...v }))
      .sort((a, b) => b.stake - a.stake)
      .slice(0, 5);
  }, [settled7d]);

  return (
    <Box>
      {/* Header */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Box>
          <Typography sx={{ color: C.text, fontWeight: 800, fontSize: { xs: '1.3rem', sm: '1.5rem' }, lineHeight: 1.2 }}>
            Sports Overview
          </Typography>
          <Typography sx={{ color: C.textMuted, fontSize: '0.78rem', mt: 0.25 }}>
            Live exposure, settled GGR and per-sport turnover (G/T)
          </Typography>
        </Box>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <Chip
            icon={<CalendarToday sx={{ fontSize: 14 }} />}
            label={new Date().toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
            size="small"
            sx={{ bgcolor: C.cardLight, color: C.textMuted, border: `1px solid ${C.border}`, fontWeight: 500, '& .MuiChip-icon': { color: C.textSecondary } }}
          />
          <MuiTooltip title="Refresh">
            <IconButton onClick={fetchAll} size="small" sx={{ color: C.textSecondary, bgcolor: C.cardLight, border: `1px solid ${C.border}`, '&:hover': { bgcolor: C.cardHover, borderColor: C.primary } }}>
              <Refresh fontSize="small" />
            </IconButton>
          </MuiTooltip>
        </Box>
      </Box>

      {/* Row 1: Live exposure */}
      <Grid container spacing={2} sx={{ mb: 2.5 }}>
        <Grid item xs={12} sm={6} lg={3}>
          <StatCard loading={loading} icon={<ListAlt />} iconBg={C.primaryLight} title="Open Bets" value={fmtNum(totals.openCount)} subtitle={`Users in play: ${fmtNum(totals.totalUsersOpen)}`} />
        </Grid>
        <Grid item xs={12} sm={6} lg={3}>
          <StatCard loading={loading} icon={<Warning />} iconBg={C.warning} title="Live Liability" value={fmtCurrency(totals.totalLiability)} subtitle="Sum across all open positions" />
        </Grid>
        <Grid item xs={12} sm={6} lg={3}>
          <StatCard loading={loading} icon={<Timeline />} iconBg={C.info} title="Open Stake" value={fmtCurrency(totals.totalStakeOpen)} subtitle="Stake locked in open bets" />
        </Grid>
        <Grid item xs={12} sm={6} lg={3}>
          <StatCard loading={loading} icon={<AccountBalance />} iconBg={totals.ggrToday >= 0 ? C.success : C.error} title="GGR Today" value={fmtCurrency(totals.ggrToday)} subtitle={`Settled stake: ${fmtCurrency(totals.stakeToday)}`} />
        </Grid>
      </Grid>

      {/* Row 2: Settled today summary */}
      <Grid container spacing={2} sx={{ mb: 2.5 }}>
        <Grid item xs={12} sm={6} lg={3}>
          <StatCard loading={loading} icon={<SportsCricket />} iconBg={C.success} title="Player Profit Today" value={fmtCurrency(totals.profitToday)} subtitle={`${settledToday.length} settled bets`} />
        </Grid>
        <Grid item xs={12} sm={6} lg={3}>
          <StatCard loading={loading} icon={<Equalizer />} iconBg={C.error} title="Player Loss Today" value={fmtCurrency(totals.lossToday)} subtitle="Losses across all sports" />
        </Grid>
        <Grid item xs={12} sm={6} lg={3}>
          <StatCard loading={loading} icon={<AssessmentOutlined />} iconBg="#7B5EF5" title="Commission Today" value={fmtCurrency(totals.commToday)} subtitle="Operator commission collected" />
        </Grid>
        <Grid item xs={12} sm={6} lg={3}>
          <StatCard loading={loading} icon={<ShowChart />} iconBg={C.primary} title="7d Turnover" value={fmtCurrency(settled7d.reduce((s, r) => s + Number(r.stake || 0), 0))} subtitle={`${settled7d.length} bets settled`} />
        </Grid>
      </Grid>

      {/* Row 3: Charts */}
      <Grid container spacing={2} sx={{ mb: 2.5 }}>
        <Grid item xs={12} lg={8}>
          <ChartCard title="GGR & Turnover (last 7 days)" icon={<ShowChart sx={{ fontSize: 18 }} />} height={300}>
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trendData}>
                <defs>
                  <linearGradient id="colorGgr" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={C.primary} stopOpacity={0.4} />
                    <stop offset="100%" stopColor={C.primary} stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorTurnover" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#7B5EF5" stopOpacity={0.3} />
                    <stop offset="100%" stopColor="#7B5EF5" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke={C.border} />
                <XAxis dataKey="date" tick={{ fill: C.textMuted, fontSize: 11 }} axisLine={{ stroke: C.border }} tickLine={false} />
                <YAxis tick={{ fill: C.textMuted, fontSize: 11 }} axisLine={{ stroke: C.border }} tickLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Area type="monotone" dataKey="turnover" name="Turnover" stroke="#7B5EF5" strokeWidth={2} fill="url(#colorTurnover)" dot={false} />
                <Area type="monotone" dataKey="ggr" name="GGR" stroke={C.primary} strokeWidth={2.5} fill="url(#colorGgr)" dot={false} activeDot={{ r: 5, fill: C.primary, stroke: C.text, strokeWidth: 2 }} />
              </AreaChart>
            </ResponsiveContainer>
          </ChartCard>
        </Grid>
        <Grid item xs={12} lg={4}>
          <ChartCard title="Open Stake by Sport" icon={<AssessmentOutlined sx={{ fontSize: 18 }} />} height={300}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={sportData} layout="vertical" margin={{ left: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={C.border} horizontal={false} />
                <XAxis type="number" tick={{ fill: C.textMuted, fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis dataKey="name" type="category" tick={{ fill: C.textMuted, fontSize: 11 }} axisLine={false} tickLine={false} width={90} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="value" name="Stake" radius={[0, 6, 6, 0]} barSize={18}>
                  {sportData.map((_, i) => (
                    <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        </Grid>
      </Grid>

      {/* Row 4: Top users + top sports */}
      <Grid container spacing={2} sx={{ mb: 2.5 }}>
        <Grid item xs={12} lg={6}>
          <Paper elevation={0} sx={{ p: 3, borderRadius: 3, bgcolor: C.card, border: `1px solid ${C.border}` }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2.5 }}>
              <Avatar sx={{ bgcolor: alpha(C.warning, 0.12), color: C.warning, width: 32, height: 32 }}>
                <Warning sx={{ fontSize: 18 }} />
              </Avatar>
              <Typography sx={{ color: C.text, fontWeight: 700, fontSize: '0.95rem' }}>Top Users by Live Liability</Typography>
            </Box>
            {topUsers.length === 0 ? (
              <Typography sx={{ color: C.textMuted, fontSize: '0.85rem', textAlign: 'center', py: 4 }}>
                No open exposure
              </Typography>
            ) : (
              topUsers.map((u, i) => (
                <Box key={`${u.name}-${i}`}>
                  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', py: 1.25 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.25 }}>
                      <Avatar sx={{ bgcolor: alpha(C.primary, 0.15), color: C.primary, width: 30, height: 30, fontSize: '0.8rem', fontWeight: 700 }}>
                        {String(i + 1)}
                      </Avatar>
                      <Box>
                        <Typography sx={{ color: C.text, fontSize: '0.85rem', fontWeight: 600 }}>{u.name}</Typography>
                        <Typography sx={{ color: C.textMuted, fontSize: '0.7rem' }}>{u.bets} open bets</Typography>
                      </Box>
                    </Box>
                    <Typography sx={{ color: C.warning, fontWeight: 800, fontSize: '0.9rem' }}>{fmtCurrency(u.liability)}</Typography>
                  </Box>
                  {i < topUsers.length - 1 && <Divider sx={{ borderColor: C.border }} />}
                </Box>
              ))
            )}
          </Paper>
        </Grid>
        <Grid item xs={12} lg={6}>
          <Paper elevation={0} sx={{ p: 3, borderRadius: 3, bgcolor: C.card, border: `1px solid ${C.border}` }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2.5 }}>
              <Avatar sx={{ bgcolor: alpha(C.info, 0.12), color: C.info, width: 32, height: 32 }}>
                <SportsCricket sx={{ fontSize: 18 }} />
              </Avatar>
              <Typography sx={{ color: C.text, fontWeight: 700, fontSize: '0.95rem' }}>Top Sports (7d Turnover)</Typography>
            </Box>
            {topSports.length === 0 ? (
              <Typography sx={{ color: C.textMuted, fontSize: '0.85rem', textAlign: 'center', py: 4 }}>
                No settled bets in the last 7 days
              </Typography>
            ) : (
              topSports.map((s, i) => (
                <Box key={`${s.name}-${i}`}>
                  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', py: 1.25 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.25 }}>
                      <Box sx={{ width: 8, height: 32, borderRadius: 1, bgcolor: CHART_COLORS[i % CHART_COLORS.length] }} />
                      <Box>
                        <Typography sx={{ color: C.text, fontSize: '0.85rem', fontWeight: 600 }}>{s.name}</Typography>
                        <Typography sx={{ color: C.textMuted, fontSize: '0.7rem' }}>{s.bets} bets · GGR {fmtCurrency(s.ggr)}</Typography>
                      </Box>
                    </Box>
                    <Typography sx={{ color: C.text, fontWeight: 800, fontSize: '0.9rem' }}>{fmtCurrency(s.stake)}</Typography>
                  </Box>
                  {i < topSports.length - 1 && <Divider sx={{ borderColor: C.border }} />}
                </Box>
              ))
            )}
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default SportsTab;
