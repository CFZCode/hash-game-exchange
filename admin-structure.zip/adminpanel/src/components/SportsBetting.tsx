import React, { useState, useEffect } from "react";
import {
  Box,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Button,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Typography,
  IconButton,
  Alert,
  Stack,
  Chip,
  TablePagination,
  Skeleton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  InputAdornment,
  Tooltip,
  SelectChangeEvent,
} from "@mui/material";
import { Gamepad, Search, Trash2, RefreshCw } from "lucide-react";

interface SportsBet {
  id: number;
  username: string;
  user_id: number;
  match_title: string;
  team_one: string;
  team_two: string;
  game_type: string;
  selection_name: string;
  category: string;
  bet_type: string;
  odds: number;
  stake_amount: number;
  usd_amount: number;
  status: string;
  result_status: string;
  match_start_time: string;
  match_end_time: string;
}

interface ApiResponse {
  success: boolean;
  bets: SportsBet[];
  pagination: { total: number; totalPages: number; page: number; limit: number };
  error?: string;
}

interface Filters {
  status: string;
  gameResult: string;
  startDate: string;
  endDate: string;
  currency: string;
}

const Result_TYPES = [
  { value: "won", label: "Won" },
  { value: "loss", label: "Loss" },
  { value: "pending", label: "Pending" },
];

const STATUS_TYPES = [
  { value: "open", label: "Open" },
  { value: "closed", label: "Closed" },
];

const cardSx = { bgcolor: "#0E1831", border: "1px solid #1E2D55", borderRadius: 2 };

const inputSx = {
  "& .MuiOutlinedInput-root": {
    bgcolor: "#0B1427",
    "& fieldset": { borderColor: "#1E2D55" },
    "&:hover fieldset": { borderColor: "#2B6EF5" },
    "&.Mui-focused fieldset": { borderColor: "#2B6EF5" },
  },
  "& input": { color: "#F9F9F9" },
  "& .MuiInputLabel-root": { color: "#8384A5" },
  "& .MuiInputLabel-root.Mui-focused": { color: "#2B6EF5" },
};

const selectSx = {
  bgcolor: "#0B1427",
  color: "#F9F9F9",
  "& .MuiOutlinedInput-notchedOutline": { borderColor: "#1E2D55" },
  "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "#2B6EF5" },
  "&.Mui-focused .MuiOutlinedInput-notchedOutline": { borderColor: "#2B6EF5" },
  "& .MuiSvgIcon-root": { color: "#8384A5" },
};

const thSx = {
  bgcolor: "#0B1427",
  color: "#8384A5",
  fontWeight: 700,
  fontSize: "0.72rem",
  textTransform: "uppercase" as const,
  letterSpacing: "0.06em",
  borderBottom: "1px solid #1E2D55",
  whiteSpace: "nowrap" as const,
};

const tdSx = {
  color: "#C8CAE5",
  borderBottom: "1px solid #1E2D55",
  fontSize: "0.82rem",
  py: 1.5,
};

const getResultChip = (status: string) => {
  const s = status?.toLowerCase();
  if (s === "won") return { bgcolor: "rgba(14,204,104,0.12)", color: "#0ECC68" };
  if (s === "loss" || s === "lost") return { bgcolor: "rgba(224,27,79,0.12)", color: "#E01B4F" };
  return { bgcolor: "rgba(255,194,63,0.12)", color: "#FFC23F" };
};

const getStatusChip = (status: string) => {
  const s = status?.toLowerCase();
  if (s === "open") return { bgcolor: "rgba(43,110,245,0.12)", color: "#5581F7" };
  if (s === "closed") return { bgcolor: "rgba(131,132,165,0.12)", color: "#8384A5" };
  return { bgcolor: "rgba(255,194,63,0.12)", color: "#FFC23F" };
};

const SportsBetting = () => {
  const [bets, setBets] = useState<SportsBet[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [totalCount, setTotalCount] = useState(0);
  const [searchTerm, setSearchTerm] = useState("");
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedBetId, setSelectedBetId] = useState<number | null>(null);
  const staffId = localStorage.getItem("currentUserId");
  const [filters, setFilters] = useState<Filters>({
    status: "",
    gameResult: "",
    startDate: "",
    endDate: "",
    currency: "usd",
  });

  const getBetTime = (bet: SportsBet): number => {
    const tCandidates = [bet.match_start_time, bet.match_end_time];
    for (const t of tCandidates) {
      if (t) { const ts = Date.parse(t); if (!isNaN(ts)) return ts; }
    }
    return bet.id || 0;
  };

  const fetchBets = async () => {
    try {
      setLoading(true);
      setError(null);
      const searchParams = new URLSearchParams({
        page: (page + 1).toString(),
        limit: rowsPerPage.toString(),
        ...(filters.status && { status: filters.status }),
        ...(filters.gameResult && { gameResult: filters.gameResult }),
        ...(filters.startDate && { startDate: filters.startDate }),
        ...(filters.endDate && { endDate: filters.endDate }),
        ...(searchTerm && { search: searchTerm }),
        currency: filters.currency,
      });

      const response = await fetch(
        `https://example.com/sportsbetting/admin/bets?${searchParams.toString()}`,
        { headers: { "x-staff-id": staffId ?? "" } }
      );
      const data: ApiResponse = await response.json();

      if (data.success) {
        const sorted = (data.bets || []).slice().sort((a, b) => getBetTime(b) - getBetTime(a));
        setBets(sorted);
        setTotalCount(data.pagination?.total || 0);
      } else {
        setError(data.error || "Failed to fetch bets");
        setBets([]);
        setTotalCount(0);
      }
    } catch {
      setError("Failed to fetch bets");
      setBets([]);
      setTotalCount(0);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBets();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page, rowsPerPage, filters, searchTerm]);

  const handleDelete = async () => {
    if (selectedBetId) {
      try {
        const response = await fetch(
          `https://example.com/sportsbetting/admin/bets/${selectedBetId}`,
          { method: "DELETE", headers: { "x-staff-id": staffId ?? "" } }
        );
        const data = await response.json();
        if (data.success) { fetchBets(); setDeleteDialogOpen(false); }
        else setError(data.error || "Failed to delete bet");
      } catch { setError("Failed to delete bet"); }
    }
  };

  const handleStatusUpdate = async (betId: number, newStatus: string) => {
    try {
      const response = await fetch(
        `https://example.com/sportsbetting/admin/bets/${betId}/status`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json", "x-staff-id": staffId ?? "" },
          body: JSON.stringify({ status: newStatus, resultDeclaredTime: new Date().toISOString() }),
        }
      );
      const data = await response.json();
      if (data.success) fetchBets();
      else setError(data.error || "Failed to update bet status");
    } catch { setError("Failed to update bet status"); }
  };

  const handleStatusChange = (event: SelectChangeEvent<string>, betId: number) => {
    handleStatusUpdate(betId, event.target.value);
  };

  return (
    <Box sx={{ p: 3, maxWidth: 1400, mx: "auto" }}>
      {/* Header */}
      <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mb: 3 }}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
          <Box sx={{ p: 1, bgcolor: "rgba(43,110,245,0.15)", borderRadius: 2, display: "flex" }}>
            <Gamepad size={22} color="#2B6EF5" />
          </Box>
          <Box>
            <Typography variant="h5" sx={{ color: "#F9F9F9", fontWeight: 700 }}>
              Sports Betting
            </Typography>
            <Typography variant="caption" sx={{ color: "#8384A5" }}>
              {totalCount} total bets
            </Typography>
          </Box>
        </Box>
        <Button
          startIcon={<RefreshCw size={15} />}
          onClick={fetchBets}
          disabled={loading}
          variant="outlined"
          size="small"
          sx={{ borderColor: "#1E2D55", color: "#8384A5", textTransform: "none", "&:hover": { borderColor: "#2B6EF5", color: "#2B6EF5" } }}
        >
          Refresh
        </Button>
      </Box>

      {/* Filters */}
      <Paper sx={{ ...cardSx, p: 2, mb: 2 }}>
        <Stack direction={{ xs: "column", md: "row" }} spacing={2} alignItems={{ md: "center" }} flexWrap="wrap">
          <TextField
            size="small"
            placeholder="Search bets…"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start"><Search size={15} color="#8384A5" /></InputAdornment>
              ),
            }}
            sx={{ ...inputSx, flex: 1, minWidth: 200 }}
          />
          <FormControl size="small" sx={{ minWidth: 130 }}>
            <InputLabel sx={{ color: "#8384A5", "&.Mui-focused": { color: "#2B6EF5" } }}>Status</InputLabel>
            <Select
              value={filters.status}
              label="Status"
              onChange={(e) => setFilters({ ...filters, status: e.target.value })}
              sx={selectSx}
            >
              <MenuItem value="" sx={{ color: "#F9F9F9" }}>All Status</MenuItem>
              {STATUS_TYPES.map(s => (
                <MenuItem key={s.value} value={s.value} sx={{ color: "#F9F9F9" }}>{s.label}</MenuItem>
              ))}
            </Select>
          </FormControl>
          <FormControl size="small" sx={{ minWidth: 140 }}>
            <InputLabel sx={{ color: "#8384A5", "&.Mui-focused": { color: "#2B6EF5" } }}>Result</InputLabel>
            <Select
              value={filters.gameResult}
              label="Result"
              onChange={(e) => setFilters({ ...filters, gameResult: e.target.value })}
              sx={selectSx}
            >
              <MenuItem value="" sx={{ color: "#F9F9F9" }}>All Results</MenuItem>
              {Result_TYPES.map(r => (
                <MenuItem key={r.value} value={r.value} sx={{ color: "#F9F9F9" }}>{r.label}</MenuItem>
              ))}
            </Select>
          </FormControl>
          <TextField
            type="date"
            label="Start Date"
            value={filters.startDate}
            onChange={(e) => setFilters({ ...filters, startDate: e.target.value })}
            InputLabelProps={{ shrink: true }}
            size="small"
            sx={{ ...inputSx, minWidth: 150 }}
          />
          <TextField
            type="date"
            label="End Date"
            value={filters.endDate}
            onChange={(e) => setFilters({ ...filters, endDate: e.target.value })}
            InputLabelProps={{ shrink: true }}
            size="small"
            sx={{ ...inputSx, minWidth: 150 }}
          />
        </Stack>
      </Paper>

      {error && (
        <Alert severity="error" sx={{ mb: 2, bgcolor: "rgba(224,27,79,0.1)", color: "#E01B4F", border: "1px solid rgba(224,27,79,0.3)", "& .MuiAlert-icon": { color: "#E01B4F" } }}>
          {error}
        </Alert>
      )}

      {/* Table */}
      <Paper sx={{ ...cardSx, overflow: "hidden" }}>
        <TableContainer>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell sx={thSx}>User</TableCell>
                <TableCell sx={thSx}>Match</TableCell>
                <TableCell sx={thSx}>Type</TableCell>
                <TableCell sx={thSx}>Selection</TableCell>
                <TableCell sx={{ ...thSx, textAlign: "right" }}>Odds</TableCell>
                <TableCell sx={{ ...thSx, textAlign: "right" }}>Stake</TableCell>
                <TableCell sx={thSx}>Status</TableCell>
                <TableCell sx={thSx}>Result</TableCell>
                <TableCell sx={{ ...thSx, textAlign: "center" }}>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                [...Array(6)].map((_, i) => (
                  <TableRow key={i}>
                    {[...Array(9)].map((_, j) => (
                      <TableCell key={j} sx={tdSx}>
                        <Skeleton variant="text" width={j === 1 ? 140 : 80} sx={{ bgcolor: "#162140" }} />
                      </TableCell>
                    ))}
                  </TableRow>
                ))
              ) : bets.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={9} sx={{ textAlign: "center", py: 6, borderBottom: "none" }}>
                    <Gamepad size={40} color="#1E2D55" />
                    <Typography sx={{ color: "#8384A5", mt: 1 }}>No bets found.</Typography>
                  </TableCell>
                </TableRow>
              ) : (
                bets.map((bet) => {
                  const rc = getResultChip(bet.result_status);
                  return (
                    <TableRow key={bet.id} sx={{ "&:hover": { bgcolor: "rgba(43,110,245,0.04)" }, transition: "background 150ms" }}>
                      <TableCell sx={tdSx}>
                        <Typography sx={{ color: "#F9F9F9", fontSize: "0.82rem", fontWeight: 500 }}>{bet.username}</Typography>
                        <Typography variant="caption" sx={{ color: "#5581F7" }}>#{bet.user_id}</Typography>
                      </TableCell>
                      <TableCell sx={tdSx}>
                        <Typography sx={{ color: "#F9F9F9", fontSize: "0.82rem", fontWeight: 500 }}>{bet.match_title}</Typography>
                        <Typography variant="caption" sx={{ color: "#8384A5" }}>{bet.team_one} vs {bet.team_two}</Typography>
                      </TableCell>
                      <TableCell sx={tdSx}>
                        <Typography sx={{ color: "#C8CAE5", fontSize: "0.82rem" }}>{bet.game_type}</Typography>
                        <Typography variant="caption" sx={{ color: "#8384A5" }}>{bet.category}</Typography>
                      </TableCell>
                      <TableCell sx={tdSx}>
                        <Typography sx={{ color: "#C8CAE5", fontSize: "0.82rem" }}>{bet.selection_name}</Typography>
                        <Typography variant="caption" sx={{ color: "#8384A5" }}>{bet.bet_type}</Typography>
                      </TableCell>
                      <TableCell sx={{ ...tdSx, textAlign: "right", fontFamily: "monospace" }}>{bet.odds}</TableCell>
                      <TableCell sx={{ ...tdSx, textAlign: "right" }}>
                        <Chip
                          label={`₹ ${bet.stake_amount.toFixed(2)}`}
                          size="small"
                          sx={{ bgcolor: "rgba(43,110,245,0.12)", color: "#5581F7", fontWeight: 600, fontSize: "0.72rem", fontFamily: "monospace" }}
                        />
                      </TableCell>
                      <TableCell sx={tdSx}>
                        <FormControl size="small" sx={{ minWidth: 100 }}>
                          <Select
                            value={bet.status}
                            onChange={(e) => handleStatusChange(e, bet.id)}
                            sx={{
                              ...selectSx,
                              fontSize: "0.78rem",
                              "& .MuiSelect-select": { py: 0.5, px: 1 },
                            }}
                            renderValue={(value) => (
                              <Chip label={value} size="small" sx={{ ...getStatusChip(value), fontWeight: 600, fontSize: "0.7rem", height: 22 }} />
                            )}
                          >
                            {STATUS_TYPES.map(s => (
                              <MenuItem key={s.value} value={s.value} sx={{ color: "#F9F9F9", "&:hover": { bgcolor: "#162140" } }}>
                                {s.label}
                              </MenuItem>
                            ))}
                          </Select>
                        </FormControl>
                      </TableCell>
                      <TableCell sx={tdSx}>
                        <Chip
                          label={bet.result_status || "pending"}
                          size="small"
                          sx={{ ...rc, fontWeight: 600, fontSize: "0.7rem", height: 22 }}
                        />
                      </TableCell>
                      <TableCell sx={{ ...tdSx, textAlign: "center" }}>
                        <Tooltip title="Delete bet">
                          <IconButton
                            size="small"
                            onClick={() => { setSelectedBetId(bet.id); setDeleteDialogOpen(true); }}
                            sx={{ color: "#8384A5", "&:hover": { color: "#E01B4F", bgcolor: "rgba(224,27,79,0.1)" } }}
                          >
                            <Trash2 size={15} />
                          </IconButton>
                        </Tooltip>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </TableContainer>

        <TablePagination
          component="div"
          count={totalCount}
          page={page}
          onPageChange={(_, newPage) => setPage(newPage)}
          rowsPerPage={rowsPerPage}
          onRowsPerPageChange={(e) => { setRowsPerPage(parseInt(e.target.value, 10)); setPage(0); }}
          sx={{
            borderTop: "1px solid #1E2D55",
            color: "#8384A5",
            "& .MuiTablePagination-selectIcon": { color: "#8384A5" },
            "& .MuiTablePagination-select": { color: "#F9F9F9" },
            "& .MuiIconButton-root": { color: "#8384A5" },
            "& .MuiIconButton-root.Mui-disabled": { color: "#1E2D55" },
          }}
        />
      </Paper>

      {/* Delete Dialog */}
      <Dialog
        open={deleteDialogOpen}
        onClose={() => setDeleteDialogOpen(false)}
        PaperProps={{ sx: { bgcolor: "#0E1831", border: "1px solid #1E2D55", borderRadius: 3, minWidth: 360 } }}
      >
        <DialogTitle sx={{ color: "#F9F9F9", borderBottom: "1px solid #1E2D55", display: "flex", alignItems: "center", gap: 1 }}>
          <Trash2 size={18} color="#E01B4F" />
          Confirm Delete
        </DialogTitle>
        <DialogContent sx={{ pt: 2.5 }}>
          <Typography sx={{ color: "#8384A5" }}>
            Are you sure you want to delete this bet? This action cannot be undone.
          </Typography>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2.5, gap: 1 }}>
          <Button
            onClick={() => setDeleteDialogOpen(false)}
            sx={{ flex: 1, color: "#8384A5", border: "1px solid #1E2D55", textTransform: "none", "&:hover": { borderColor: "#8384A5" } }}
          >
            Cancel
          </Button>
          <Button
            onClick={handleDelete}
            variant="contained"
            sx={{ flex: 1, bgcolor: "#E01B4F", textTransform: "none", "&:hover": { bgcolor: "#c4164a" } }}
          >
            Delete
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default SportsBetting;
