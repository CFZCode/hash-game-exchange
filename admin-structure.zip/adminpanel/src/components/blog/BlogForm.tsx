import React, { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { toast } from 'sonner';
import { apiUpload } from '../../utils/api';
import BlogEditor from './BlogEditor';
import BlogFormSide, { BlogFormState } from './BlogFormSide';
import {
  Blog,
  BlogSaveResponse,
  errorMessage,
  inputCls,
  isBlankHtml,
  labelCls,
  normalizeSpaces,
  resolveImage,
  slugify,
  today,
} from './blogShared';

interface BlogFormProps {
  /** The post being edited, or null to create one. */
  blog: Blog | null;
  categories: string[];
  onClose: () => void;
  onSaved: () => void;
}

const fromBlog = (blog: Blog | null): BlogFormState => ({
  title: blog?.title || '',
  slug: blog?.slug || '',
  subheading: blog?.subheading || '',
  description: blog?.description || '',
  author: blog?.author || '',
  category: blog?.category || '',
  date: blog?.date ? blog.date.slice(0, 10) : today(),
  status: blog?.status || 'published',
  meta_title: blog?.meta_title || '',
  meta_description: blog?.meta_description || '',
  image: null,
  removeImage: false,
});

/** Create / edit dialog. Sends multipart to /api/blogs/createBlog|updateBlog. */
export default function BlogForm({ blog, categories, onClose, onSaved }: BlogFormProps) {
  const [form, setForm] = useState<BlogFormState>(() => fromBlog(blog));
  /* A new post's slug follows the title until someone edits the slug. */
  const [slugTouched, setSlugTouched] = useState(Boolean(blog));
  const [coverPreview, setCoverPreview] = useState(resolveImage(blog?.image));
  const [submitting, setSubmitting] = useState(false);
  const [uploadingInline, setUploadingInline] = useState(false);

  const patch = (changes: Partial<BlogFormState>) => setForm((f) => ({ ...f, ...changes }));

  /* Free a local object URL when the preview changes or the dialog closes. */
  useEffect(
    () => () => {
      if (coverPreview.startsWith('blob:')) URL.revokeObjectURL(coverPreview);
    },
    [coverPreview]
  );

  const close = () => {
    if (!submitting) onClose();
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title.trim()) {
      toast.error('Title is required');
      return;
    }
    if (isBlankHtml(form.description)) {
      toast.error('Content is required');
      return;
    }

    const fd = new FormData();
    fd.append('title', form.title.trim());
    fd.append('slug', slugify(form.slug || form.title));
    fd.append('subheading', form.subheading.trim());
    fd.append('description', normalizeSpaces(form.description));
    fd.append('author', form.author.trim());
    fd.append('category', form.category.trim());
    fd.append('status', form.status);
    fd.append('meta_title', form.meta_title.trim());
    fd.append('meta_description', form.meta_description.trim());
    /* Send the date only when it changed, so an edit keeps the original publish
       time. Today means "now"; another day means that day's local midnight. */
    if (form.date && form.date !== blog?.date?.slice(0, 10)) {
      const when = form.date === today() ? new Date() : new Date(`${form.date}T00:00:00`);
      fd.append('date', when.toISOString());
    }
    if (form.image) fd.append('image', form.image);
    if (form.removeImage) fd.append('removeImage', 'true');
    if (blog) fd.append('id', String(blog.id));

    setSubmitting(true);
    try {
      await apiUpload<BlogSaveResponse>(blog ? '/api/blogs/updateBlog' : '/api/blogs/createBlog', fd);
      toast.success(blog ? 'Post updated' : form.status === 'draft' ? 'Draft saved' : 'Post published');
      setSubmitting(false);
      onSaved();
    } catch (err) {
      toast.error(errorMessage(err, 'Failed to save post'));
      setSubmitting(false);
    }
  };

  const slugChanged = Boolean(blog && form.slug && slugify(form.slug) !== blog.slug);

  /* Portalled to <body>: rendered in place, the layout's sidebar painted over
     the left of the dialog. */
  return createPortal(
    <div
      className="fixed inset-0 bg-black/70 flex items-start md:items-center justify-center p-2 md:p-4"
      style={{ zIndex: 1400 }}
      role="dialog"
      aria-modal="true"
      onKeyDown={(e) => {
        if (e.key === 'Escape') close();
      }}
    >
      <div className="bg-[#0E1831] border border-[#1E2D55] rounded-xl w-full max-w-5xl max-h-[96vh] overflow-y-auto">
        <div className="flex items-center justify-between p-5 border-b border-[#1E2D55] sticky top-0 bg-[#0E1831] z-10">
          <h2 className="text-lg font-semibold">{blog ? 'Edit Post' : 'New Blog Post'}</h2>
          <button onClick={close} className="text-[#878AA2] hover:text-[#F9F9F9] text-2xl leading-none" aria-label="Close">
            &times;
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 grid grid-cols-1 lg:grid-cols-3 gap-5">
          <div className="lg:col-span-2 flex flex-col gap-4">
            <div>
              <label className={labelCls}>
                Title <span className="text-[#E01B4F]">*</span>
              </label>
              <input
                type="text"
                value={form.title}
                onChange={(e) => {
                  const title = e.target.value;
                  patch(slugTouched ? { title } : { title, slug: slugify(title) });
                }}
                placeholder="Post title"
                maxLength={512}
                className={inputCls}
                required
              />
            </div>

            <div>
              <label className={labelCls}>URL slug</label>
              <div className="flex items-center rounded-lg overflow-hidden border border-[#1E2D55] focus-within:border-[#2B6EF5]">
                <span className="bg-[#10182E] text-[#878AA2] text-sm px-3 py-2 border-r border-[#1E2D55] whitespace-nowrap">/blog/</span>
                <input
                  type="text"
                  value={form.slug}
                  onChange={(e) => {
                    setSlugTouched(true);
                    patch({ slug: e.target.value });
                  }}
                  onBlur={() => patch({ slug: slugify(form.slug || form.title) })}
                  placeholder="auto-from-title"
                  className="flex-1 min-w-0 bg-[#10182E] px-3 py-2 text-sm text-[#F9F9F9] focus:outline-none"
                />
              </div>
              {slugChanged && (
                <p className="text-xs text-[#FFC23F] mt-1">Changing the slug changes the post URL. Old links will stop working.</p>
              )}
            </div>

            <div>
              <label className={labelCls}>Subheading</label>
              <input
                type="text"
                value={form.subheading}
                onChange={(e) => patch({ subheading: e.target.value })}
                placeholder="One-line summary shown under the title and on the blog list"
                className={inputCls}
              />
            </div>

            <div>
              <label className={labelCls}>
                Content <span className="text-[#E01B4F]">*</span>
              </label>
              <BlogEditor
                value={form.description}
                onChange={(html) => patch({ description: html })}
                onUploadingChange={setUploadingInline}
              />
            </div>
          </div>

          <BlogFormSide
            form={form}
            patch={patch}
            categories={categories}
            coverPreview={coverPreview}
            setCoverPreview={setCoverPreview}
            hadImage={Boolean(blog?.image)}
          />

          <div className="lg:col-span-3 flex justify-end gap-3 pt-3 border-t border-[#1E2D55]">
            <button
              type="button"
              onClick={close}
              disabled={submitting}
              className="px-4 py-2 text-sm text-[#878AA2] hover:text-[#F9F9F9] border border-[#1E2D55] rounded-lg transition disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting || uploadingInline}
              className="px-5 py-2 text-sm bg-[#2B6EF5] hover:bg-[#4A85F7] rounded-lg font-medium transition disabled:opacity-50"
            >
              {submitting ? 'Saving...' : blog ? 'Update Post' : form.status === 'draft' ? 'Save Draft' : 'Publish Post'}
            </button>
          </div>
        </form>
      </div>
    </div>,
    document.body
  );
}
