import React, { useRef } from 'react';
import { toast } from 'sonner';
import { BlogStatus, IMAGE_TYPES, MAX_IMAGE_MB, checkImage, inputCls, labelCls } from './blogShared';

export interface BlogFormState {
  title: string;
  slug: string;
  subheading: string;
  description: string;
  author: string;
  category: string;
  date: string;
  status: BlogStatus;
  meta_title: string;
  meta_description: string;
  image: File | null;
  removeImage: boolean;
}

interface BlogFormSideProps {
  form: BlogFormState;
  patch: (changes: Partial<BlogFormState>) => void;
  categories: string[];
  coverPreview: string;
  setCoverPreview: (url: string) => void;
  /** Whether the saved post already has a cover, so removing it must be sent. */
  hadImage: boolean;
}

/** Right-hand column of the post form: publishing, cover image and SEO. */
export default function BlogFormSide({ form, patch, categories, coverPreview, setCoverPreview, hadImage }: BlogFormSideProps) {
  const coverInput = useRef<HTMLInputElement>(null);

  const onCoverChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    const problem = checkImage(file);
    if (problem) {
      toast.error(problem);
      return;
    }
    patch({ image: file, removeImage: false });
    setCoverPreview(URL.createObjectURL(file));
  };

  const removeCover = () => {
    patch({ image: null, removeImage: hadImage });
    setCoverPreview('');
  };

  const metaTitleLen = (form.meta_title || form.title).length;
  const metaDescLen = form.meta_description.length;

  return (
    <div className="flex flex-col gap-4">
      <div>
        <label className={labelCls}>Status</label>
        <select value={form.status} onChange={(e) => patch({ status: e.target.value as BlogStatus })} className={inputCls}>
          <option value="published">Published</option>
          <option value="draft">Draft (hidden from site)</option>
        </select>
      </div>

      <div>
        <label className={labelCls}>Publish date</label>
        <input type="date" value={form.date} onChange={(e) => patch({ date: e.target.value })} className={inputCls} />
        <p className="text-xs text-[#878AA2] mt-1">A future date keeps the post hidden until that day.</p>
      </div>

      <div>
        <label className={labelCls}>Category</label>
        <input
          type="text"
          list="blog-categories"
          value={form.category}
          onChange={(e) => patch({ category: e.target.value })}
          placeholder="e.g. Teen Patti"
          className={inputCls}
        />
        <datalist id="blog-categories">
          {categories.map((c) => (
            <option key={c} value={c} />
          ))}
        </datalist>
      </div>

      <div>
        <label className={labelCls}>Author</label>
        <input
          type="text"
          value={form.author}
          onChange={(e) => patch({ author: e.target.value })}
          placeholder="MyApp"
          className={inputCls}
        />
      </div>

      <div>
        <label className={labelCls}>Cover image</label>
        {coverPreview && (
          <div className="relative mb-2">
            <img src={coverPreview} alt="Cover preview" className="w-full aspect-[16/9] object-cover rounded-lg" />
            <button
              type="button"
              onClick={removeCover}
              className="absolute top-2 right-2 bg-black/70 hover:bg-[#E01B4F] text-xs px-2 py-1 rounded"
            >
              Remove
            </button>
          </div>
        )}
        <input type="file" accept={IMAGE_TYPES.join(',')} ref={coverInput} onChange={onCoverChange} className="hidden" />
        <button
          type="button"
          onClick={() => coverInput.current?.click()}
          className="w-full border border-dashed border-[#1E2D55] hover:border-[#2B6EF5] rounded-lg px-4 py-3 text-sm text-[#878AA2] hover:text-[#F9F9F9] transition text-center"
        >
          {form.image ? form.image.name : coverPreview ? 'Replace image' : `Upload image (max ${MAX_IMAGE_MB} MB)`}
        </button>
        <p className="text-xs text-[#878AA2] mt-1">16:9 works best, e.g. 1600 × 900.</p>
      </div>

      <div className="border-t border-[#1E2D55] pt-4 flex flex-col gap-4">
        <p className="text-sm font-semibold">Search engine (SEO)</p>
        <div>
          <div className="flex justify-between">
            <label className={labelCls}>Meta title</label>
            <span className={`text-xs ${metaTitleLen > 60 ? 'text-[#FFC23F]' : 'text-[#878AA2]'}`}>{metaTitleLen}/60</span>
          </div>
          <input
            type="text"
            value={form.meta_title}
            onChange={(e) => patch({ meta_title: e.target.value })}
            placeholder="Defaults to the post title"
            maxLength={255}
            className={inputCls}
          />
        </div>
        <div>
          <div className="flex justify-between">
            <label className={labelCls}>Meta description</label>
            <span className={`text-xs ${metaDescLen > 160 ? 'text-[#FFC23F]' : 'text-[#878AA2]'}`}>{metaDescLen}/160</span>
          </div>
          <textarea
            value={form.meta_description}
            onChange={(e) => patch({ meta_description: e.target.value })}
            placeholder="Defaults to the subheading"
            maxLength={512}
            rows={3}
            className={`${inputCls} resize-y`}
          />
        </div>
      </div>
    </div>
  );
}
