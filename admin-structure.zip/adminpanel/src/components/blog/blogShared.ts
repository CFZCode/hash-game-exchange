/*
 * Shared types and helpers for the Blog admin screens.
 *
 * Backend: /api/blogs/* (staff-only, protectStaff) for everything here;
 * the public site reads /api/getblog/*. Published posts live at
 * SITE_URL/blog/<slug>.
 */

export const API_BASE = 'https://example.com';
export const SITE_URL = 'https://example.com';
export const MAX_IMAGE_MB = 10;
export const IMAGE_TYPES = ['image/png', 'image/jpeg', 'image/webp', 'image/gif'];

export type BlogStatus = 'published' | 'draft';

export interface Blog {
  id: number;
  slug: string;
  title: string;
  subheading: string | null;
  description: string;
  author: string;
  date: string;
  category: string;
  image: string | null;
  status: BlogStatus;
  meta_title: string | null;
  meta_description: string | null;
  created_at: string;
  updated_at: string;
}

export interface BlogListResponse {
  status: string;
  blogs: Blog[];
}

export interface BlogSaveResponse {
  status: string;
  data: Blog | { blog: Blog };
}

export interface UploadResponse {
  status: string;
  url: string;
}

/* Stored paths look like /uploads/blogs/<file>; the API host serves them. */
export const resolveImage = (img: string | null | undefined): string => {
  if (!img) return '';
  if (/^https?:\/\//i.test(img)) return img;
  return `${API_BASE}${img.startsWith('/') ? '' : '/'}${img}`;
};

/* Mirrors slugify() in the backend so the URL preview matches what is saved. */
export const slugify = (text: string): string =>
  text
    .normalize('NFKD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/[\s_]+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 120);

export const isBlankHtml = (html: string): boolean =>
  !/<img\s/i.test(html) && !html.replace(/<[^>]*>/g, '').replace(/&nbsp;/g, ' ').trim();

/* Quill 2.0.3's semantic HTML turns every space into &nbsp;, which stops the
   text from wrapping on the site. Store plain spaces instead. */
export const normalizeSpaces = (html: string): string => html.replace(/&nbsp;/g, ' ');

/*
 * Text copied from Docs or Word brings its own black ink and white paper,
 * which vanish on the dark theme. A colour is kept only if it can be read on
 * the background it sits on, so a deliberate dark-on-highlight still works.
 * The site applies the same rule (sanitizeBlogHtml) to posts already saved.
 */
type Rgb = [number, number, number];

const DARK_PAGE = 0.008; /* luminance of the editor and site backgrounds */
const MIN_CONTRAST = 3;

const parseColour = (value: unknown): Rgb | null => {
  if (typeof value !== 'string') return null;
  const v = value.trim().toLowerCase();
  if (v === 'black' || v === 'windowtext') return [0, 0, 0];
  if (v === 'white') return [255, 255, 255];
  const hex = v.match(/^#([0-9a-f]{3}|[0-9a-f]{6})$/);
  if (hex) {
    const h = hex[1].length === 3 ? hex[1].replace(/./g, '$&$&') : hex[1];
    return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
  }
  const rgb = v.match(/^rgba?\(\s*(\d+)[\s,]+(\d+)[\s,]+(\d+)(?:[\s,/]+([\d.]+))?/);
  if (!rgb || (rgb[4] !== undefined && Number(rgb[4]) === 0)) return null;
  return [Number(rgb[1]), Number(rgb[2]), Number(rgb[3])];
};

const luminance = (rgb: Rgb): number => {
  const [r, g, b] = rgb.map((c) => {
    const s = c / 255;
    return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
};

const isPaper = (rgb: Rgb): boolean => rgb.every((c) => c >= 235);

const unreadable = (ink: Rgb, backdrop: number): boolean => {
  const l = luminance(ink);
  return (Math.max(l, backdrop) + 0.05) / (Math.min(l, backdrop) + 0.05) < MIN_CONTRAST;
};

interface ColouredDelta {
  ops: { attributes?: Record<string, unknown> }[];
}

/* Quill clipboard matcher: runs on pasted HTML and on a saved post being
   loaded into the editor. */
export const readableColours = <T extends ColouredDelta>(_node: unknown, delta: T): T => {
  delta.ops.forEach((op) => {
    const attrs = op.attributes;
    if (!attrs) return;
    const paper = parseColour(attrs.background);
    if (paper && isPaper(paper)) delete attrs.background;
    const ink = parseColour(attrs.color);
    const behind = parseColour(attrs.background);
    if (ink && unreadable(ink, behind ? luminance(behind) : DARK_PAGE)) delete attrs.color;
    if (!Object.keys(attrs).length) delete op.attributes;
  });
  return delta;
};

export const stripHtml = (html: string): string =>
  html.replace(/<[^>]*>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim();

export const today = (): string => new Date().toISOString().slice(0, 10);

export const isScheduled = (b: Blog): boolean => b.status === 'published' && new Date(b.date) > new Date();

export const checkImage = (file: File): string | null => {
  if (!IMAGE_TYPES.includes(file.type)) return 'Only PNG, JPG, WEBP or GIF images are allowed';
  if (file.size > MAX_IMAGE_MB * 1024 * 1024) return `Image must be under ${MAX_IMAGE_MB} MB`;
  return null;
};

/* apiFetch throws the raw response text; the backend sends { message }. */
export const errorMessage = (err: unknown, fallback: string): string => {
  const raw = err instanceof Error ? err.message : '';
  try {
    return JSON.parse(raw)?.message || fallback;
  } catch {
    return raw && raw.length < 200 ? raw : fallback;
  }
};

export const inputCls =
  'w-full bg-[#10182E] border border-[#1E2D55] rounded-lg px-3 py-2 text-[#F9F9F9] text-sm focus:outline-none focus:border-[#2B6EF5]';
export const labelCls = 'block text-sm text-[#8384A5] mb-1';
