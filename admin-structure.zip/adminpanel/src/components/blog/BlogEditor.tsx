import React, { useMemo, useRef, useState } from 'react';
import { Box } from '@mui/material';
import { toast } from 'sonner';
import ReactQuill from 'react-quill-new';
import 'react-quill-new/dist/quill.snow.css';
import { apiUpload } from '../../utils/api';
import {
  IMAGE_TYPES,
  UploadResponse,
  checkImage,
  errorMessage,
  readableColours,
  resolveImage,
} from './blogShared';

interface BlogEditorProps {
  value: string;
  onChange: (html: string) => void;
  onUploadingChange?: (uploading: boolean) => void;
}

/* Quill's snow theme is built for a white page; this fits it to the admin's
   dark palette. Kept in sx rather than a stylesheet, per the panel's rules. */
const editorSx = {
  '& .ql-toolbar.ql-snow': {
    bgcolor: '#10182E',
    border: '1px solid #1E2D55',
    borderRadius: '8px 8px 0 0',
    position: 'sticky',
    top: 0,
    zIndex: 1,
  },
  '& .ql-container.ql-snow': {
    bgcolor: '#10182E',
    border: '1px solid #1E2D55',
    borderTop: 0,
    borderRadius: '0 0 8px 8px',
    color: '#F9F9F9',
    fontFamily: 'inherit',
    fontSize: 15,
  },
  '& .ql-editor': { minHeight: 360, lineHeight: 1.7 },
  '& .ql-editor.ql-blank::before': { color: '#878AA2', fontStyle: 'normal' },
  '& .ql-editor img': { maxWidth: '100%', borderRadius: '8px' },
  '& .ql-editor a': { color: '#4A85F7' },
  '& .ql-editor blockquote': { borderLeft: '4px solid #2B6EF5', color: '#C9CBE0' },
  '& .ql-snow .ql-stroke': { stroke: '#C9CBE0' },
  '& .ql-snow .ql-fill, & .ql-snow .ql-stroke.ql-fill': { fill: '#C9CBE0' },
  '& .ql-snow .ql-picker': { color: '#C9CBE0' },
  '& .ql-snow button:hover .ql-stroke, & .ql-snow button.ql-active .ql-stroke, & .ql-snow .ql-picker-label:hover .ql-stroke, & .ql-snow .ql-picker-label.ql-active .ql-stroke':
    { stroke: '#4A85F7' },
  '& .ql-snow button:hover .ql-fill, & .ql-snow button.ql-active .ql-fill': { fill: '#4A85F7' },
  '& .ql-snow .ql-picker-label:hover, & .ql-snow .ql-picker-label.ql-active, & .ql-snow .ql-picker-item:hover, & .ql-snow .ql-picker-item.ql-selected':
    { color: '#4A85F7' },
  '& .ql-snow .ql-picker-options': { bgcolor: '#0E1831', borderColor: '#1E2D55 !important' },
  '& .ql-snow .ql-tooltip': {
    bgcolor: '#0E1831',
    borderColor: '#1E2D55',
    color: '#F9F9F9',
    boxShadow: '0 4px 16px rgba(0,0,0,0.5)',
    zIndex: 2,
  },
  '& .ql-snow .ql-tooltip input[type=text]': { bgcolor: '#10182E', borderColor: '#1E2D55', color: '#F9F9F9' },
} as const;

/**
 * Rich text editor for a post body. The toolbar's image button uploads the
 * file to /api/blogs/uploadImage first and inserts the hosted URL; inserting
 * the file as base64 would bloat every post and the database with it.
 */
export default function BlogEditor({ value, onChange, onUploadingChange }: BlogEditorProps) {
  const quillRef = useRef<ReactQuill>(null);
  const [uploading, setUploading] = useState(false);

  const setBusy = (busy: boolean) => {
    setUploading(busy);
    onUploadingChange?.(busy);
  };

  const insertImage = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = IMAGE_TYPES.join(',');
    input.onchange = async () => {
      const file = input.files?.[0];
      if (!file) return;
      const problem = checkImage(file);
      if (problem) {
        toast.error(problem);
        return;
      }
      const editor = quillRef.current?.getEditor();
      if (!editor) return;
      setBusy(true);
      try {
        const fd = new FormData();
        fd.append('image', file);
        const res = await apiUpload<UploadResponse>('/api/blogs/uploadImage', fd);
        const range = editor.getSelection(true);
        const at = range ? range.index : editor.getLength();
        editor.insertEmbed(at, 'image', resolveImage(res.url), 'user');
        editor.setSelection(at + 1, 0, 'silent');
      } catch (err) {
        toast.error(errorMessage(err, 'Image upload failed'));
      } finally {
        setBusy(false);
      }
    };
    input.click();
  };

  /* Stable across renders: Quill re-initialises if `modules` changes identity.
     The handler reads the editor through a ref, so it never goes stale. */
  const modules = useMemo(
    () => ({
      toolbar: {
        container: [
          [{ header: [2, 3, 4, false] }],
          ['bold', 'italic', 'underline', 'strike'],
          [{ color: [] }, { background: [] }],
          [{ list: 'ordered' }, { list: 'bullet' }],
          [{ align: [] }],
          ['blockquote', 'code-block'],
          ['link', 'image', 'video'],
          ['clean'],
        ],
        handlers: { image: () => insertImage() },
      },
      clipboard: { matchVisual: false, matchers: [[Node.ELEMENT_NODE, readableColours]] },
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  return (
    <Box sx={editorSx}>
      {uploading && <p className="text-xs text-[#2B6EF5] mb-1">Uploading image...</p>}
      <ReactQuill
        ref={quillRef}
        theme="snow"
        value={value}
        onChange={onChange}
        modules={modules}
        placeholder="Write the post. Use the toolbar for headings, lists, links and images."
      />
    </Box>
  );
}
