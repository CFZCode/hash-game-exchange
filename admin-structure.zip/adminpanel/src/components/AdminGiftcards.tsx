import React, { useEffect, useMemo, useState, useCallback } from "react";
import { apiFetch } from "../utils/api";
import { format } from "date-fns";
import {
  Gift,
  Plus,
  RefreshCw,
  ChevronLeft,
  ChevronRight,
  Search,
  Trash2,
  X,
  TrendingUp,
  Users,
  CheckCircle,
  IndianRupee,
  CreditCard,
} from "lucide-react";

/* ─── types ─── */
interface GiftCard {
  id: number;
  uniqueKey: string;
  description: string | null;
  periodDays: number | null;
  endDate: string | null;
  depositStatus: boolean;
  depositAmount: number | null;
  wagerStatus: boolean;
  wagerTimes: number | null;
  allUserStatus: boolean;
  amount: number | null;
  currency: string | null;
  rewardType: RewardType | null;
  rewardPercent: number | null;
  maxReward: number | null;
  firstDepositOnly: boolean | null;
  createdAt: string;
}

type RewardType = "fixed" | "percent";

interface AnalyticsStats {
  total_cards: number;
  total_activations: number;
  total_claimed: number;
  total_activated: number;
  total_claimed_amount: number;
}

interface AnalyticsCard {
  id: number;
  unique_key: string;
  amount: number | null;
  currency: string | null;
  reward_type: RewardType | null;
  reward_percent: number | null;
  max_reward: number | null;
  created_at: string;
  activations: number;
  claims: number;
}

interface Record {
  id: number;
  user_id: number;
  gift_card_id: number;
  status: string;
  start_date: string;
  updated_at: string;
  unique_key: string;
  description: string | null;
  amount: number | null;
  currency: string | null;
  reward_type: RewardType | null;
  reward_percent: number | null;
  claimed_amount: number | null;
  deposit_status: boolean;
  deposit_amount: number | null;
  wager_status: boolean;
  wager_times: number | null;
}

type Tab = "cards" | "records" | "analytics";

const PERCENT_PRESETS = [10, 25, 50, 100];

const EMPTY_FORM = {
  uniqueKey: "", description: "", periodDays: "", endDate: "",
  depositStatus: false, depositAmount: "", wagerStatus: false,
  wagerTimes: "", allUserStatus: false, amount: "",
  rewardType: "fixed" as RewardType, rewardPercent: "", maxReward: "",
  firstDepositOnly: false,
};

/* legacy cards were created in USD; everything new is INR */
const money = (v: number | string | null | undefined, currency?: string | null) => {
  if (v == null || v === "") return "-";
  const n = Number(v);
  return currency === "USD"
    ? `$${n.toFixed(2)}`
    : `₹${n.toLocaleString("en-IN", { maximumFractionDigits: 2 })}`;
};

const rewardLabel = (
  type: RewardType | null, amount: number | null, pct: number | null,
  max: number | null, currency: string | null,
) =>
  type === "percent"
    ? `${Number(pct)}% of deposit${max != null ? ` (max ${money(max, currency)})` : ""}`
    : money(amount, currency);

const fmt = (iso: string) => {
  try { return format(new Date(iso), "yyyy-MM-dd HH:mm"); }
  catch { return iso; }
};

/* ─── component ─── */
export default function GiftCardAdmin() {
  const [tab, setTab] = useState<Tab>("cards");

  /* cards */
  const [cards, setCards] = useState<GiftCard[]>([]);
  const [cardsLoading, setCardsLoading] = useState(false);

  /* analytics */
  const [stats, setStats] = useState<AnalyticsStats | null>(null);
  const [analyticsCards, setAnalyticsCards] = useState<AnalyticsCard[]>([]);
  const [analyticsLoading, setAnalyticsLoading] = useState(false);

  /* records */
  const [records, setRecords] = useState<Record[]>([]);
  const [recordsLoading, setRecordsLoading] = useState(false);
  const [recordsTotal, setRecordsTotal] = useState(0);
  const [recordPage, setRecordPage] = useState(1);
  const [recordStatus, setRecordStatus] = useState("all");
  const [recordSearch, setRecordSearch] = useState("");

  /* create modal */
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState<any>(EMPTY_FORM);

  /* ─── fetchers ─── */
  const fetchCards = useCallback(async () => {
    setCardsLoading(true);
    try {
      const data = await apiFetch<GiftCard[]>("/giftcard/admin/list");
      setCards(data || []);
    } catch { /* */ }
    finally { setCardsLoading(false); }
  }, []);

  const fetchAnalytics = useCallback(async () => {
    setAnalyticsLoading(true);
    try {
      const data = await apiFetch<{ stats: AnalyticsStats; cards: AnalyticsCard[] }>("/giftcard/admin/analytics");
      setStats(data.stats);
      setAnalyticsCards(data.cards);
    } catch { /* */ }
    finally { setAnalyticsLoading(false); }
  }, []);

  const fetchRecords = useCallback(async () => {
    setRecordsLoading(true);
    try {
      const qs = new URLSearchParams({
        page: String(recordPage), limit: "25",
        ...(recordStatus !== "all" ? { status: recordStatus } : {}),
        ...(recordSearch ? { search: recordSearch } : {}),
      }).toString();
      const data = await apiFetch<{ total: number; data: Record[] }>(`/giftcard/admin/records?${qs}`);
      setRecords(data.data);
      setRecordsTotal(data.total);
    } catch { /* */ }
    finally { setRecordsLoading(false); }
  }, [recordPage, recordStatus, recordSearch]);

  useEffect(() => { fetchCards(); fetchAnalytics(); }, []);
  useEffect(() => { if (tab === "records") fetchRecords(); }, [tab, recordPage, recordStatus]);

  /* ─── actions ─── */
  const isPercent = form.rewardType === "percent";

  const setFirstDepositOnly = (firstDepositOnly: boolean) =>
    // judged on the first deposit's amount, so it always needs a minimum deposit
    setForm({ ...form, firstDepositOnly, ...(firstDepositOnly ? { depositStatus: true } : {}) });

  const setRewardType = (rewardType: RewardType) =>
    // a % reward is paid on the deposit, so it always needs a minimum deposit
    setForm({ ...form, rewardType, ...(rewardType === "percent" ? { depositStatus: true } : {}) });

  const createGiftCard = async () => {
    if (!form.uniqueKey.trim()) return alert("Gift code is required");
    if (isPercent) {
      const pct = Number(form.rewardPercent);
      if (!(pct > 0 && pct <= 500)) return alert("Enter a reward percentage between 1 and 500");
      if (!(Number(form.depositAmount) > 0)) return alert("Minimum deposit (₹) is required for a % reward");
    } else if (!(Number(form.amount) > 0)) {
      return alert("Enter the claim amount (₹)");
    }
    if (form.depositStatus && !(Number(form.depositAmount) > 0)) return alert("Enter the minimum deposit (₹)");
    if (form.wagerStatus && !(Number(form.wagerTimes) > 0)) return alert("Enter the wager multiplier");

    try {
      await apiFetch("/giftcard/admin/create", {
        method: "POST",
        body: JSON.stringify({
          ...form,
          currency: "INR",
          periodDays: form.periodDays || null,
          endDate: form.endDate || null,
          depositAmount: form.depositAmount || null,
          wagerTimes: form.wagerTimes || null,
          amount: isPercent ? null : form.amount || null,
          rewardPercent: isPercent ? form.rewardPercent : null,
          maxReward: isPercent ? form.maxReward || null : null,
        }),
      });
      setShowCreate(false);
      setForm(EMPTY_FORM);
      fetchCards();
      fetchAnalytics();
    } catch (e: any) {
      alert(e.message || "Failed to create gift card");
    }
  };

  const deleteGiftCard = async (id: number) => {
    if (!window.confirm("Delete this gift card?")) return;
    await apiFetch(`/giftcard/admin/delete/${id}`, { method: "DELETE" });
    fetchCards();
    fetchAnalytics();
  };

  const searchRecords = () => { setRecordPage(1); fetchRecords(); };

  const totalPages = Math.ceil(recordsTotal / 25) || 1;

  /* ─── tab button helper ─── */
  const tabBtn = (t: Tab, label: string, Icon: any) => (
    <button
      key={t}
      onClick={() => setTab(t)}
      className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium rounded-lg transition-all ${
        tab === t
          ? "bg-[#2B6EF5] text-[#F9F9F9] shadow-lg shadow-[#2B6EF5]/25"
          : "text-[#878AA2] hover:text-[#F9F9F9] hover:bg-[#0E1831]"
      }`}
    >
      <Icon size={16} />
      {label}
    </button>
  );

  /* ─── stat card helper ─── */
  const statCard = (label: string, value: string | number, Icon: any, color: string) => (
    <div className="bg-[#0E1831] border border-[#1E2D55] rounded-xl p-5">
      <div className="flex items-center justify-between mb-3">
        <span className="text-[#878AA2] text-sm">{label}</span>
        <div className={`w-10 h-10 rounded-lg flex items-center justify-center`} style={{ backgroundColor: `${color}20` }}>
          <Icon size={18} style={{ color }} />
        </div>
      </div>
      <div className="text-2xl font-bold text-[#F9F9F9]">{value}</div>
    </div>
  );

  /* ─── render ─── */
  return (
    <div className="p-4 space-y-6 min-h-screen" style={{ backgroundColor: "#0C0D1D" }}>

      {/* header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl font-semibold text-[#F9F9F9] flex items-center gap-2">
            <Gift size={22} /> Gift Cards
          </h1>
          <p className="text-sm text-[#878AA2] mt-1">Manage gift cards, track claims & analytics</p>
        </div>
        <button
          onClick={() => setShowCreate(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-[#2B6EF5] hover:bg-[#4A85F7] text-[#F9F9F9] rounded-lg text-sm font-medium transition-all shadow-lg shadow-[#2B6EF5]/25"
        >
          <Plus size={16} /> Create Gift Card
        </button>
      </div>

      {/* tabs */}
      <div className="flex gap-2 bg-[#0C0D1D] p-1.5 rounded-xl w-fit border border-[#1E2D55]">
        {tabBtn("cards", "Gift Cards", CreditCard)}
        {tabBtn("records", "Records", Users)}
        {tabBtn("analytics", "Analytics", TrendingUp)}
      </div>

      {/* ═══════════ ANALYTICS SECTION (always visible as summary) ═══════════ */}
      {stats && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {statCard("Total Cards", stats.total_cards, CreditCard, "#6366f1")}
          {statCard("Total Activated", stats.total_activated, Users, "#f59e0b")}
          {statCard("Total Claimed", stats.total_claimed, CheckCircle, "#10b981")}
          {statCard("Claimed Amount", money(stats.total_claimed_amount, "INR"), IndianRupee, "#ef4444")}
        </div>
      )}

      {/* ═══════════ CARDS TAB ═══════════ */}
      {tab === "cards" && (
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <span className="text-sm text-[#878AA2]">{cards.length} gift cards</span>
            <button onClick={fetchCards} className="flex items-center gap-1 text-xs text-[#878AA2] hover:text-[#8384A5]">
              <RefreshCw size={14} /> Refresh
            </button>
          </div>

          {cardsLoading ? (
            <div className="text-center py-16 text-[#878AA2]">Loading...</div>
          ) : cards.length === 0 ? (
            <div className="bg-[#0E1831] border border-[#1E2D55] rounded-xl p-12 text-center">
              <Gift size={48} className="mx-auto text-[#878AA2] mb-3" />
              <p className="text-[#878AA2]">No gift cards created yet</p>
            </div>
          ) : (
            <div className="bg-[#0E1831] border border-[#1E2D55] rounded-xl overflow-hidden">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-[#1E2D55]">
                    {["Code", "Description", "Reward", "Period", "End Date", "Deposit", "First Deposit", "Wager", "Users", "Created", ""].map(h => (
                      <th key={h} className="px-4 py-3 text-left text-xs font-medium text-[#878AA2] uppercase tracking-wider">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {cards.map(g => (
                    <tr key={g.id} className="border-b border-[#1E2D55] hover:bg-[#162140] transition-colors">
                      <td className="px-4 py-3">
                        <span className="text-[#F9F9F9] font-medium">{g.uniqueKey}</span>
                      </td>
                      <td className="px-4 py-3 text-[#8384A5] max-w-[200px] truncate">
                        {g.description || "-"}
                      </td>
                      <td className="px-4 py-3">
                        <span className="text-[#0ECC68] font-semibold whitespace-nowrap">
                          {rewardLabel(g.rewardType, g.amount, g.rewardPercent, g.maxReward, g.currency)}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-[#8384A5]">
                        {g.periodDays ? `${g.periodDays}d` : "-"}
                      </td>
                      <td className="px-4 py-3 text-[#8384A5]">
                        {g.endDate ? fmt(g.endDate) : "-"}
                      </td>
                      <td className="px-4 py-3">
                        {g.depositStatus ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs bg-[#FFC23F]/10 text-[#FFC23F]">
                            Min {money(g.depositAmount, g.currency)}
                          </span>
                        ) : (
                          <span className="text-[#878AA2] text-xs">None</span>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        {g.firstDepositOnly ? (
                          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs bg-[#0ECC68]/10 text-[#0ECC68]">
                            Only first
                          </span>
                        ) : (
                          <span className="text-[#878AA2] text-xs">Any</span>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        {g.wagerStatus ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs bg-[#2B6EF5]/10 text-[#4A85F7]">
                            {g.wagerTimes}x
                          </span>
                        ) : (
                          <span className="text-[#878AA2] text-xs">None</span>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs ${
                          g.allUserStatus
                            ? "bg-[#0ECC68]/10 text-[#0ECC68]"
                            : "bg-[#1E2D55]/10 text-[#878AA2]"
                        }`}>
                          {g.allUserStatus ? "All" : "Selected"}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-[#878AA2] text-xs">{fmt(g.createdAt)}</td>
                      <td className="px-4 py-3">
                        <button
                          onClick={() => deleteGiftCard(g.id)}
                          className="p-1.5 rounded-lg text-[#878AA2] hover:text-[#E01B4F] hover:bg-[#E01B4F]/10 transition-colors"
                        >
                          <Trash2 size={15} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ═══════════ RECORDS TAB ═══════════ */}
      {tab === "records" && (
        <div className="space-y-4">
          {/* filters */}
          <div className="bg-[#0E1831] border border-[#1E2D55] rounded-xl p-4">
            <div className="flex flex-wrap items-center gap-3">
              <div className="relative flex-1 min-w-[200px]">
                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#878AA2]" />
                <input
                  className="w-full pl-9 pr-3 py-2 bg-[#0C0D1D] border border-[#1E2D55] rounded-lg text-sm text-[#F9F9F9] placeholder-[#878AA2] focus:outline-none focus:border-[#2B6EF5]"
                  placeholder="Search by User ID or Gift Code"
                  value={recordSearch}
                  onChange={e => setRecordSearch(e.target.value)}
                  onKeyDown={e => e.key === "Enter" && searchRecords()}
                />
              </div>
              <select
                className="px-3 py-2 bg-[#0C0D1D] border border-[#1E2D55] rounded-lg text-sm text-[#F9F9F9] focus:outline-none focus:border-[#2B6EF5]"
                value={recordStatus}
                onChange={e => { setRecordStatus(e.target.value); setRecordPage(1); }}
              >
                <option value="all">All Status</option>
                <option value="Activated">Activated</option>
                <option value="Claimed">Claimed</option>
              </select>
              <button
                onClick={searchRecords}
                className="px-4 py-2 bg-[#2B6EF5] hover:bg-[#4A85F7] text-[#F9F9F9] rounded-lg text-sm font-medium transition-all"
              >
                Search
              </button>
              <button
                onClick={() => { setRecordSearch(""); setRecordStatus("all"); setRecordPage(1); fetchRecords(); }}
                className="px-4 py-2 bg-[#162140] hover:bg-[#1E2D55] text-[#8384A5] rounded-lg text-sm transition-all"
              >
                Clear
              </button>
            </div>
          </div>

          {/* table */}
          <div className="bg-[#0E1831] border border-[#1E2D55] rounded-xl overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[#1E2D55]">
                  {["ID", "User ID", "Gift Code", "Amount", "Status", "Activated", "Updated"].map(h => (
                    <th key={h} className="px-4 py-3 text-left text-xs font-medium text-[#878AA2] uppercase tracking-wider">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {recordsLoading ? (
                  <tr><td colSpan={7} className="py-12 text-center text-[#878AA2]">Loading...</td></tr>
                ) : records.length === 0 ? (
                  <tr><td colSpan={7} className="py-12 text-center text-[#878AA2]">No records found</td></tr>
                ) : records.map(r => (
                  <tr key={r.id} className="border-b border-[#1E2D55] hover:bg-[#162140] transition-colors">
                    <td className="px-4 py-3 text-[#878AA2]">#{r.id}</td>
                    <td className="px-4 py-3 text-[#F9F9F9] font-mono text-xs">{r.user_id}</td>
                    <td className="px-4 py-3 text-[#F9F9F9] font-medium">{r.unique_key}</td>
                    <td className="px-4 py-3">
                      {r.claimed_amount != null ? (
                        <span className="text-[#0ECC68] font-semibold">{money(r.claimed_amount, r.currency)}</span>
                      ) : r.reward_type === "percent" ? (
                        <span className="text-[#8384A5]">{Number(r.reward_percent)}% of deposit</span>
                      ) : r.amount != null ? (
                        <span className="text-[#0ECC68] font-semibold">{money(r.amount, r.currency)}</span>
                      ) : (
                        <span className="text-[#878AA2]">-</span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${
                        r.status === "Claimed"
                          ? "bg-[#0ECC68]/10 text-[#0ECC68]"
                          : "bg-[#FFC23F]/10 text-[#FFC23F]"
                      }`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${
                          r.status === "Claimed" ? "bg-[#0ECC68]" : "bg-[#FFC23F]"
                        }`} />
                        {r.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-[#878AA2] text-xs">{fmt(r.start_date)}</td>
                    <td className="px-4 py-3 text-[#878AA2] text-xs">{fmt(r.updated_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            {/* pagination */}
            <div className="flex items-center justify-between px-4 py-3 border-t border-[#1E2D55]">
              <span className="text-xs text-[#878AA2]">{recordsTotal} total records</span>
              <div className="flex items-center gap-2">
                <button
                  disabled={recordPage === 1}
                  onClick={() => setRecordPage(p => p - 1)}
                  className="p-1.5 rounded-lg text-[#878AA2] hover:bg-[#162140] disabled:opacity-30 transition-colors"
                >
                  <ChevronLeft size={18} />
                </button>
                <span className="text-sm text-[#8384A5] min-w-[80px] text-center">
                  Page {recordPage} / {totalPages}
                </span>
                <button
                  disabled={recordPage >= totalPages}
                  onClick={() => setRecordPage(p => p + 1)}
                  className="p-1.5 rounded-lg text-[#878AA2] hover:bg-[#162140] disabled:opacity-30 transition-colors"
                >
                  <ChevronRight size={18} />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ═══════════ ANALYTICS TAB ═══════════ */}
      {tab === "analytics" && (
        <div className="space-y-6">
          <div className="flex items-center gap-3">
            <span className="text-sm text-[#878AA2]">Per-card breakdown</span>
            <button onClick={fetchAnalytics} className="flex items-center gap-1 text-xs text-[#878AA2] hover:text-[#8384A5]">
              <RefreshCw size={14} /> Refresh
            </button>
          </div>

          {analyticsLoading ? (
            <div className="text-center py-16 text-[#878AA2]">Loading...</div>
          ) : (
            <div className="bg-[#0E1831] border border-[#1E2D55] rounded-xl overflow-hidden">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-[#1E2D55]">
                    {["Gift Code", "Reward", "Activations", "Claims", "Conversion", "Created"].map(h => (
                      <th key={h} className="px-4 py-3 text-left text-xs font-medium text-[#878AA2] uppercase tracking-wider">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {analyticsCards.map(c => {
                    const rate = c.activations > 0 ? ((c.claims / c.activations) * 100).toFixed(1) : "0.0";
                    return (
                      <tr key={c.id} className="border-b border-[#1E2D55] hover:bg-[#162140] transition-colors">
                        <td className="px-4 py-3 text-[#F9F9F9] font-medium">{c.unique_key}</td>
                        <td className="px-4 py-3">
                          <span className="text-[#0ECC68] font-semibold whitespace-nowrap">
                            {rewardLabel(c.reward_type, c.amount, c.reward_percent, c.max_reward, c.currency)}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-[#FFC23F]/10 text-[#FFC23F]">
                            {c.activations}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-[#0ECC68]/10 text-[#0ECC68]">
                            {c.claims}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <div className="flex-1 h-2 bg-[#1E2D55] rounded-full max-w-[80px]">
                              <div
                                className="h-2 bg-[#2B6EF5] rounded-full transition-all"
                                style={{ width: `${Math.min(Number(rate), 100)}%` }}
                              />
                            </div>
                            <span className="text-[#8384A5] text-xs">{rate}%</span>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-[#878AA2] text-xs">{fmt(c.created_at)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ═══════════ CREATE MODAL ═══════════ */}
      {showCreate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setShowCreate(false)} />
          <div className="relative bg-[#0C0D1D] border border-[#1E2D55] rounded-2xl shadow-2xl w-full max-w-2xl p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold text-[#F9F9F9]">Create Gift Card</h2>
              <button onClick={() => setShowCreate(false)} className="p-1.5 rounded-lg text-[#878AA2] hover:bg-[#162140]">
                <X size={18} />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs text-[#878AA2] mb-1.5">Unique Gift Code</label>
                <input
                  className="w-full p-2.5 bg-[#0C0D1D] border border-[#1E2D55] rounded-lg text-sm text-[#F9F9F9] placeholder-[#878AA2] focus:outline-none focus:border-[#2B6EF5]"
                  placeholder="e.g. WELCOME100"
                  value={form.uniqueKey}
                  onChange={e => setForm({ ...form, uniqueKey: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-xs text-[#878AA2] mb-1.5">Description</label>
                <textarea
                  rows={3}
                  className="w-full p-2.5 bg-[#0C0D1D] border border-[#1E2D55] rounded-lg text-sm text-[#F9F9F9] placeholder-[#878AA2] resize-none focus:outline-none focus:border-[#2B6EF5]"
                  placeholder="Gift card description"
                  value={form.description}
                  onChange={e => setForm({ ...form, description: e.target.value })}
                />
              </div>

              <div className="bg-[#0C0D1D] border border-[#1E2D55] rounded-lg p-4 space-y-4">
                <p className="text-xs text-[#878AA2] font-medium uppercase tracking-wider">Reward (INR)</p>

                <div className="grid grid-cols-2 gap-2">
                  {([["fixed", "Fixed Amount (₹)"], ["percent", "% of Deposit"]] as [RewardType, string][]).map(([t, label]) => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => setRewardType(t)}
                      className={`py-2 rounded-lg text-sm font-medium border transition-all ${
                        form.rewardType === t
                          ? "bg-[#2B6EF5] border-[#2B6EF5] text-[#F9F9F9]"
                          : "border-[#1E2D55] text-[#8384A5] hover:bg-[#162140]"
                      }`}
                    >
                      {label}
                    </button>
                  ))}
                </div>

                {!isPercent ? (
                  <div>
                    <label className="block text-xs text-[#878AA2] mb-1.5">Claim Amount (₹)</label>
                    <input
                      type="number"
                      min="0"
                      className="w-full p-2.5 bg-[#0C0D1D] border border-[#1E2D55] rounded-lg text-sm text-[#F9F9F9] placeholder-[#878AA2] focus:outline-none focus:border-[#2B6EF5]"
                      placeholder="Amount credited to user on claim, e.g. 100"
                      value={form.amount}
                      onChange={e => setForm({ ...form, amount: e.target.value })}
                    />
                  </div>
                ) : (
                  <>
                    <div>
                      <label className="block text-xs text-[#878AA2] mb-1.5">Reward Percentage</label>
                      <div className="flex flex-wrap gap-2 mb-2">
                        {PERCENT_PRESETS.map(p => (
                          <button
                            key={p}
                            type="button"
                            onClick={() => setForm({ ...form, rewardPercent: String(p) })}
                            className={`px-3 py-1.5 rounded-lg text-sm border transition-all ${
                              Number(form.rewardPercent) === p
                                ? "bg-[#0ECC68]/10 border-[#0ECC68] text-[#0ECC68]"
                                : "border-[#1E2D55] text-[#8384A5] hover:bg-[#162140]"
                            }`}
                          >
                            {p}%
                          </button>
                        ))}
                      </div>
                      <div className="relative">
                        <input
                          type="number"
                          min="0"
                          className="w-full p-2.5 bg-[#0C0D1D] border border-[#1E2D55] rounded-lg text-sm text-[#F9F9F9] placeholder-[#878AA2] focus:outline-none focus:border-[#2B6EF5] pr-8"
                          placeholder="Custom %, e.g. 10"
                          value={form.rewardPercent}
                          onChange={e => setForm({ ...form, rewardPercent: e.target.value })}
                        />
                        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-[#878AA2]">%</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs text-[#878AA2] mb-1.5">Minimum Deposit (₹)</label>
                        <input
                          type="number"
                          min="0"
                          className="w-full p-2.5 bg-[#0C0D1D] border border-[#1E2D55] rounded-lg text-sm text-[#F9F9F9] placeholder-[#878AA2] focus:outline-none focus:border-[#2B6EF5]"
                          placeholder="e.g. 500"
                          value={form.depositAmount}
                          onChange={e => setForm({ ...form, depositAmount: e.target.value })}
                        />
                      </div>
                      <div>
                        <label className="block text-xs text-[#878AA2] mb-1.5">Max Reward (₹)</label>
                        <input
                          type="number"
                          min="0"
                          className="w-full p-2.5 bg-[#0C0D1D] border border-[#1E2D55] rounded-lg text-sm text-[#F9F9F9] placeholder-[#878AA2] focus:outline-none focus:border-[#2B6EF5]"
                          placeholder="Leave empty = no cap"
                          value={form.maxReward}
                          onChange={e => setForm({ ...form, maxReward: e.target.value })}
                        />
                      </div>
                    </div>

                    {Number(form.rewardPercent) > 0 && Number(form.depositAmount) > 0 && (() => {
                      const dep = Number(form.depositAmount);
                      const raw = (dep * Number(form.rewardPercent)) / 100;
                      const reward = Number(form.maxReward) > 0 ? Math.min(raw, Number(form.maxReward)) : raw;
                      return (
                        <p className="text-xs text-[#8384A5]">
                          Example: user deposits {money(dep, "INR")} → gets{" "}
                          <span className="text-[#0ECC68] font-semibold">{money(reward, "INR")}</span>.
                          Paid on the first single deposit ≥ {money(dep, "INR")} after activation.
                        </p>
                      );
                    })()}
                  </>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-[#878AA2] mb-1.5">Period (days)</label>
                  <input
                    type="number"
                    className="w-full p-2.5 bg-[#0C0D1D] border border-[#1E2D55] rounded-lg text-sm text-[#F9F9F9] placeholder-[#878AA2] focus:outline-none focus:border-[#2B6EF5]"
                    placeholder="Leave empty = unlimited"
                    value={form.periodDays}
                    onChange={e => setForm({ ...form, periodDays: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-xs text-[#878AA2] mb-1.5">End Date</label>
                  <input
                    type="date"
                    className="w-full p-2.5 bg-[#0C0D1D] border border-[#1E2D55] rounded-lg text-sm text-[#F9F9F9] placeholder-[#878AA2] focus:outline-none focus:border-[#2B6EF5]"
                    value={form.endDate}
                    onChange={e => setForm({ ...form, endDate: e.target.value })}
                  />
                </div>
              </div>

              <div className="bg-[#0C0D1D] border border-[#1E2D55] rounded-lg p-4 space-y-4">
                <p className="text-xs text-[#878AA2] font-medium uppercase tracking-wider">Conditions</p>

                <div className="space-y-3">
                  <label className="flex items-center gap-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      className="w-4 h-4 rounded border-[#1E2D55] text-[#2B6EF5] focus:ring-[#2B6EF5] bg-[#0C0D1D]"
                      checked={form.depositStatus}
                      disabled={isPercent || form.firstDepositOnly}
                      onChange={e => setForm({ ...form, depositStatus: e.target.checked })}
                    />
                    <span className="text-sm text-[#8384A5]">
                      Deposit Condition{isPercent && " (required for % reward — set minimum above)"}
                    </span>
                  </label>

                  <label className="flex items-start gap-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      className="mt-0.5 w-4 h-4 rounded border-[#1E2D55] text-[#2B6EF5] focus:ring-[#2B6EF5] bg-[#0C0D1D]"
                      checked={form.firstDepositOnly}
                      onChange={e => setFirstDepositOnly(e.target.checked)}
                    />
                    <span className="text-sm text-[#8384A5]">
                      First Deposit Only
                      <span className="block text-xs text-[#878AA2]">
                        Works only on the user's first-ever successful deposit (any gateway — F2Pay, Paykassma,
                        OkPay, CricPay, Fiat, Crypto), made after this card is created. Second or later deposits never qualify.
                      </span>
                    </span>
                  </label>
                  {form.depositStatus && !isPercent && (
                    <input
                      type="number"
                      className="w-full p-2.5 bg-[#0C0D1D] border border-[#1E2D55] rounded-lg text-sm text-[#F9F9F9] placeholder-[#878AA2] focus:outline-none focus:border-[#2B6EF5]"
                      placeholder="Min deposit amount (₹)"
                      value={form.depositAmount}
                      onChange={e => setForm({ ...form, depositAmount: e.target.value })}
                    />
                  )}

                  <label className="flex items-center gap-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      className="w-4 h-4 rounded border-[#1E2D55] text-[#2B6EF5] focus:ring-[#2B6EF5] bg-[#0C0D1D]"
                      checked={form.wagerStatus}
                      onChange={e => setForm({ ...form, wagerStatus: e.target.checked })}
                    />
                    <span className="text-sm text-[#8384A5]">Wager Condition</span>
                  </label>
                  {form.wagerStatus && (
                    <input
                      type="number"
                      className="w-full p-2.5 bg-[#0C0D1D] border border-[#1E2D55] rounded-lg text-sm text-[#F9F9F9] placeholder-[#878AA2] focus:outline-none focus:border-[#2B6EF5]"
                      placeholder="Wager multiplier × min deposit (e.g. 2, 3)"
                      value={form.wagerTimes}
                      onChange={e => setForm({ ...form, wagerTimes: e.target.value })}
                    />
                  )}
                </div>
              </div>

              <label className="flex items-center gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  className="w-4 h-4 rounded border-[#1E2D55] text-[#2B6EF5] focus:ring-[#2B6EF5] bg-[#0C0D1D]"
                  checked={form.allUserStatus}
                  onChange={e => setForm({ ...form, allUserStatus: e.target.checked })}
                />
                <span className="text-sm text-[#8384A5]">Applicable to all users</span>
              </label>
            </div>

            <div className="flex justify-end gap-3 mt-6 pt-4 border-t border-[#1E2D55]">
              <button
                onClick={() => setShowCreate(false)}
                className="px-4 py-2.5 bg-[#162140] hover:bg-[#1E2D55] text-[#8384A5] rounded-lg text-sm transition-all"
              >
                Cancel
              </button>
              <button
                onClick={createGiftCard}
                className="px-5 py-2.5 bg-[#2B6EF5] hover:bg-[#4A85F7] text-[#F9F9F9] rounded-lg text-sm font-medium transition-all shadow-lg shadow-[#2B6EF5]/25"
              >
                Create Gift Card
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
