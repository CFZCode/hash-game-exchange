import React, { useEffect, useState } from 'react';
import { Alert, Box, ToggleButton, ToggleButtonGroup } from '@mui/material';
import { People, Groups } from '@mui/icons-material';
import { apiFetch } from '../../utils/api';
import UsersTable, { UsersTableUser } from './UsersTable';
import StaffTable, { StaffRow } from './StaffTable';

interface Props {
  onOpenRisk: (userId: string) => void;
  onOpenStaffRisk: (staffId: string) => void;
  onOpenBalanceSheet?: (userId: string) => void;
  onOpenReport?: (userId: string, userName: string) => void;
  onOpenCasinoReport?: (userId: string, userName: string) => void;
  onOpenSportsReport?: (userId: string, userName: string) => void;
}

interface AgentUsersResponse {
  currency?: string;
  scope?: { isSuperAdmin: boolean; staffId: number | null };
  count?: number;
  users: any[];
  staff: any[];
}

const C = { border: '#1E2D55', primary: '#2B6EF5', textMuted: '#878AA2', cardLight: '#121E38' };

const AgentSystemTab: React.FC<Props> = ({ onOpenRisk, onOpenStaffRisk, onOpenBalanceSheet, onOpenReport, onOpenCasinoReport, onOpenSportsReport }) => {
  const [view, setView] = useState<'users' | 'staff'>('users');
  const [users, setUsers] = useState<UsersTableUser[]>([]);
  const [staff, setStaff] = useState<StaffRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchAll = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await apiFetch<AgentUsersResponse>('/api/admin/agent-users');
      setUsers((res.users ?? []).map((u: any) => ({
        id: String(u.id ?? ''),
        name: String(u.name ?? '—'),
        email: String(u.email ?? '—'),
        country: String(u.country ?? ''),
        phone: String(u.phone ?? ''),
        total_deposit_inr: Number(u.total_deposit_inr ?? 0) || 0,
        total_withdrawal_inr: Number(u.total_withdrawal_inr ?? 0) || 0,
        pnl_inr: Number(u.pnl_inr ?? 0) || 0,
        is_locked: u.is_locked === true || u.is_locked === 't',
        sports_betlocked: u.sports_betlocked === true || u.sports_betlocked === 't',
        staff_name: u.staff_name ?? null,
        staff_email: u.staff_email ?? null,
        is_demo: u.is_demo === true || u.is_demo === 't',
      })));
      setStaff((res.staff ?? []).map((s: any) => ({
        id: String(s.id ?? ''),
        name: String(s.name ?? '—'),
        email: String(s.email ?? '—'),
        country: String(s.country ?? ''),
        phone: String(s.phone ?? ''),
        role_id: Number(s.role_id ?? 0),
        role_name: s.role_name ?? '—',
        role_level: Number(s.role_level ?? 0),
        parent_id: s.parent_id ? String(s.parent_id) : null,
        parent_name: s.parent_name ?? null,
        system_locked: s.system_locked === true || s.system_locked === 't',
        sports_betlocked: s.sports_betlocked === true || s.sports_betlocked === 't',
        created_at: s.created_at,
      })));
    } catch (e: any) {
      console.error('[AgentSystemTab] /api/admin/agent-users failed:', e);
      setError(e?.message || 'Failed to load agent users');
      setUsers([]);
      setStaff([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchAll(); }, []);

  return (
    <Box>
      {error && (
        <Alert severity="error" onClose={() => setError(null)}
          sx={{ mb: 2, bgcolor: 'rgba(224,27,79,0.12)', color: '#E01B4F', border: '1px solid rgba(224,27,79,0.3)' }}>
          /api/admin/agent-users failed: {error}
        </Alert>
      )}
      <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 2 }}>
        <ToggleButtonGroup
          value={view}
          exclusive
          onChange={(_, v) => { if (v) setView(v); }}
          size="small"
          sx={{
            bgcolor: C.cardLight, borderRadius: 1.5,
            '& .MuiToggleButton-root': {
              color: C.textMuted, textTransform: 'none', border: `1px solid ${C.border}`, px: 2, py: 0.5, fontWeight: 600, fontSize: '0.82rem',
              '&.Mui-selected': { color: '#fff', bgcolor: C.primary, '&:hover': { bgcolor: C.primary } },
              '& svg': { mr: 0.75, fontSize: 16 },
            },
          }}
        >
          <ToggleButton value="users"><People />Users ({users.length})</ToggleButton>
          <ToggleButton value="staff"><Groups />Staff ({staff.length})</ToggleButton>
        </ToggleButtonGroup>
      </Box>

      {view === 'users' ? (
        <UsersTable
          users={users}
          loading={loading}
          title="Agent System — Users"
          onRefresh={fetchAll}
          onOpenRisk={onOpenRisk}
          onOpenBalanceSheet={onOpenBalanceSheet}
          onOpenReport={onOpenReport}
          onOpenCasinoReport={onOpenCasinoReport}
          onOpenSportsReport={onOpenSportsReport}
          showStaffColumn
        />
      ) : (
        <StaffTable
          staff={staff}
          loading={loading}
          title="Agent System — Downline Staff"
          onRefresh={fetchAll}
          onOpenRisk={onOpenStaffRisk}
        />
      )}
    </Box>
  );
};

export default AgentSystemTab;
