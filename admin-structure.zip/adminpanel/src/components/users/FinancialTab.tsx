import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert, Box, Button, Card, Chip, CircularProgress, Dialog, DialogActions, DialogContent,
  DialogTitle, IconButton, InputAdornment, Skeleton, Snackbar, Switch, Tab, Table, TableBody,
  TableCell, TableContainer, TableHead, TableRow, TablePagination, Tabs, TextField,
  ToggleButton, ToggleButtonGroup, Tooltip, Typography,
} from '@mui/material';
import {
  AccountBalanceWallet, Block, Casino, CheckCircle, Lock, LockOpen, People, Refresh, Search, Speed,
} from '@mui/icons-material';
import { apiFetch } from '../../utils/api';

const C = {
  bg: '#0C0D1D', card: '#0E1831', cardLight: '#121E38', cardHover: '#162140',
  border: '#1E2D55', primary: '#2B6EF5', text: '#F9F9F9',
  textMuted: '#878AA2', textSecondary: '#8384A5',
  success: '#0ECC68', error: '#E01B4F', warning: '#FFC23F', info: '#5581F7',
};

const API = '/api/admin/withdrawal-control';

// Mirrors MULTIPLIER_MIN / MULTIPLIER_MAX in withdrawalControlRoutes.js.
const MULTIPLIER_MIN = 0.1;
const MULTIPLIER_MAX = 100;

interface Summary {
  withdrawals_enabled: boolean;
  limit_enabled: boolean;
  deposit_multiplier: number;
  wager_bonus_enabled: boolean;
  wager_multiplier: number;
  config_updated_at: string | null;
  direct_users: number;
  locked_direct_users: number;
}

// A SuperAdmin change waiting for transaction-password confirmation.
type PendingChange =
  | { kind: 'global'; enabled: boolean }
  | { kind: 'limit'; enabled?: boolean; multiplier?: number }
  | { kind: 'wager'; enabled?: boolean; multiplier?: number };

interface LimitResponse {
  limit_enabled: boolean;
  deposit_multiplier: number;
  wager_bonus_enabled: boolean;
  wager_multiplier: number;
  config_updated_at: string;
}

interface LockUser {
  id: string;
  name: string | null;
  email: string | null;
  phone: string | null;
  country: string | null;
  created: string | null;
  inr_balance: number | string;
  withdrawal_locked: boolean;
  system_locked: boolean;
  deposited_inr: number;
  withdrawn_inr: number;
  wagered_inr: number;
  wager_bonus_inr: number;
  max_withdrawable_inr: number;
}

// apiFetch throws the raw response body; pull the backend's message out of it.
const errMsg = (e: any, fallback: string) => {
  const raw = e?.message;
  if (!raw) return fallback;
  try {
    const j = JSON.parse(raw);
    return j.message || j.error || fallback;
  } catch {
    return raw;
  }
};

const fmtDate = (s?: string | null) =>
  s ? new Date(s).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }) : '—';

const fmtInr = (n: number | string) =>
  `₹${(Number(n) || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;

const fmtMult = (n: number) => `${Number(n).toLocaleString('en-IN', { maximumFractionDigits: 2 })}×`;

const switchColor = (color: string) => ({
  '& .MuiSwitch-switchBase.Mui-checked': { color },
  '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': { bgcolor: color, opacity: 0.6 },
});

const headCell = {
  color: C.textSecondary, fontWeight: 700, fontSize: '0.72rem', textTransform: 'uppercase' as const,
  letterSpacing: '0.06em', bgcolor: C.cardLight, borderBottom: `1px solid ${C.border}`, whiteSpace: 'nowrap' as const,
};
const bodyCell = { color: C.text, borderBottom: `1px solid ${C.border}`, fontSize: '0.82rem' };

const StatCard: React.FC<{ label: string; value: React.ReactNode; icon: React.ReactNode; color: string; loading?: boolean }> = ({ label, value, icon, color, loading }) => (
  <Card sx={{ bgcolor: C.card, border: `1px solid ${C.border}`, borderRadius: 2, p: 2.5, display: 'flex', alignItems: 'center', gap: 2, flex: '1 1 220px', minWidth: 0 }}>
    <Box sx={{ width: 48, height: 48, borderRadius: 2, bgcolor: `${color}22`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, color }}>
      {icon}
    </Box>
    <Box sx={{ minWidth: 0 }}>
      <Typography sx={{ color: C.textSecondary, fontSize: '0.72rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em' }}>{label}</Typography>
      {loading
        ? <Skeleton variant="text" width={80} sx={{ bgcolor: C.border }} />
        : <Typography sx={{ color: C.text, fontSize: '1.25rem', fontWeight: 700, lineHeight: 1.3 }}>{value}</Typography>}
    </Box>
  </Card>
);

const COLS = 9;

const WithdrawalControl: React.FC = () => {
  const [summary, setSummary] = useState<Summary | null>(null);
  const [summaryLoading, setSummaryLoading] = useState(true);
  const [summaryError, setSummaryError] = useState<string | null>(null);

  const [pending, setPending] = useState<PendingChange | null>(null);
  const [multiplierInput, setMultiplierInput] = useState('');
  const [wagerInput, setWagerInput] = useState('');
  const [txnPwd, setTxnPwd] = useState('');
  const [savingGlobal, setSavingGlobal] = useState(false);
  const [confirmError, setConfirmError] = useState<string | null>(null);

  const [users, setUsers] = useState<LockUser[]>([]);
  const [total, setTotal] = useState(0);
  const [usersLoading, setUsersLoading] = useState(true);
  const [usersError, setUsersError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [status, setStatus] = useState<'all' | 'locked'>('all');
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(20);
  const [togglingId, setTogglingId] = useState<string | null>(null);

  const [snack, setSnack] = useState<{ open: boolean; msg: string; severity: 'success' | 'error' }>({ open: false, msg: '', severity: 'success' });
  const notify = (msg: string, severity: 'success' | 'error' = 'success') => setSnack({ open: true, msg, severity });

  const loadSummary = useCallback(async () => {
    setSummaryLoading(true);
    setSummaryError(null);
    try {
      const res = await apiFetch<Summary>(`${API}/summary`);
      setSummary(res);
      setMultiplierInput(String(res.deposit_multiplier));
      setWagerInput(String(res.wager_multiplier));
    } catch (e) {
      setSummaryError(errMsg(e, 'Failed to load withdrawal settings'));
    } finally {
      setSummaryLoading(false);
    }
  }, []);

  const loadUsers = useCallback(async () => {
    setUsersLoading(true);
    setUsersError(null);
    try {
      const params = new URLSearchParams({
        search: debouncedSearch,
        status,
        page: String(page + 1),
        limit: String(rowsPerPage),
      });
      const res = await apiFetch<{ users: LockUser[]; total: number }>(`${API}/users?${params}`);
      setUsers(res.users || []);
      setTotal(res.total || 0);
    } catch (e) {
      setUsersError(errMsg(e, 'Failed to load users'));
      setUsers([]);
      setTotal(0);
    } finally {
      setUsersLoading(false);
    }
  }, [debouncedSearch, status, page, rowsPerPage]);

  useEffect(() => { loadSummary(); }, [loadSummary]);
  useEffect(() => { loadUsers(); }, [loadUsers]);

  useEffect(() => {
    const t = setTimeout(() => {
      setDebouncedSearch(search.trim());
      setPage(0);
    }, 400);
    return () => clearTimeout(t);
  }, [search]);

  const closeConfirm = () => {
    if (savingGlobal) return;
    setPending(null);
    setTxnPwd('');
    setConfirmError(null);
  };

  const savePending = async () => {
    if (!pending) return;
    if (!txnPwd) {
      setConfirmError('Enter your transaction password.');
      return;
    }
    setSavingGlobal(true);
    setConfirmError(null);
    try {
      if (pending.kind === 'global') {
        const res = await apiFetch<{ withdrawals_enabled: boolean; config_updated_at: string }>(`${API}/global`, {
          method: 'PUT',
          body: JSON.stringify({ enabled: pending.enabled, transactionPassword: txnPwd }),
        });
        setSummary(s => s && { ...s, withdrawals_enabled: res.withdrawals_enabled, config_updated_at: res.config_updated_at });
        notify(res.withdrawals_enabled ? 'Withdrawals turned ON for all players.' : 'Withdrawals turned OFF for all players.');
      } else {
        const res = await apiFetch<LimitResponse>(`${API}/limit`, {
          method: 'PUT',
          body: JSON.stringify(pending.kind === 'wager'
            ? { wager_enabled: pending.enabled, wager_multiplier: pending.multiplier, transactionPassword: txnPwd }
            : { enabled: pending.enabled, multiplier: pending.multiplier, transactionPassword: txnPwd }),
        });
        setSummary(s => s && {
          ...s,
          limit_enabled: res.limit_enabled,
          deposit_multiplier: res.deposit_multiplier,
          wager_bonus_enabled: res.wager_bonus_enabled,
          wager_multiplier: res.wager_multiplier,
          config_updated_at: res.config_updated_at,
        });
        setMultiplierInput(String(res.deposit_multiplier));
        setWagerInput(String(res.wager_multiplier));
        if (pending.kind === 'wager') {
          notify(pending.enabled === undefined
            ? `Wagering bonus set to up to ${fmtMult(res.wager_multiplier)} total deposits.`
            : res.wager_bonus_enabled
              ? `Wagering bonus ON: bets unlock up to ${fmtMult(res.wager_multiplier)} total deposits extra.`
              : 'Wagering bonus OFF.');
        } else {
          notify(pending.enabled === undefined
            ? `Withdrawal limit set to ${fmtMult(res.deposit_multiplier)} total deposits.`
            : res.limit_enabled
              ? `Withdrawal limit ON: every player capped at ${fmtMult(res.deposit_multiplier)} total deposits.`
              : 'Withdrawal limit OFF.');
        }
        // The per-user caps in the table depend on these settings.
        loadUsers();
      }
      setSavingGlobal(false);
      closeConfirm();
    } catch (e) {
      setConfirmError(errMsg(e, 'Failed to save the change'));
      setSavingGlobal(false);
    }
  };

  const toggleUser = async (u: LockUser) => {
    const locked = !u.withdrawal_locked;
    setTogglingId(u.id);
    try {
      await apiFetch(`${API}/users/${u.id}`, { method: 'PUT', body: JSON.stringify({ locked }) });
      if (status === 'locked' && !locked) {
        setUsers(list => list.filter(x => x.id !== u.id));
        setTotal(t => Math.max(t - 1, 0));
      } else {
        setUsers(list => list.map(x => (x.id === u.id ? { ...x, withdrawal_locked: locked } : x)));
      }
      setSummary(s => s && { ...s, locked_direct_users: Math.max(s.locked_direct_users + (locked ? 1 : -1), 0) });
      notify(`${u.name || `User ${u.id}`}: withdrawals ${locked ? 'locked' : 'unlocked'}.`);
    } catch (e) {
      notify(errMsg(e, 'Failed to update withdrawal lock'), 'error');
    } finally {
      setTogglingId(null);
    }
  };

  const multiplier = summary?.deposit_multiplier ?? 3;
  const limitOn = summary?.limit_enabled ?? true;
  const multiplierValue = Number(multiplierInput);
  const multiplierError = multiplierInput.trim() === ''
    || !Number.isFinite(multiplierValue)
    || multiplierValue < MULTIPLIER_MIN
    || multiplierValue > MULTIPLIER_MAX
    ? `Enter a value between ${MULTIPLIER_MIN} and ${MULTIPLIER_MAX}`
    : null;
  const multiplierDirty = !!summary && !multiplierError
    && Math.round(multiplierValue * 100) / 100 !== Number(summary.deposit_multiplier);

  const wagerMultiplier = summary?.wager_multiplier ?? 5;
  const wagerOn = summary?.wager_bonus_enabled ?? true;
  // The bonus only raises the deposit cap, so it does nothing while that is off.
  const wagerActive = limitOn && wagerOn;
  const wagerValue = Number(wagerInput);
  const wagerError = wagerInput.trim() === ''
    || !Number.isFinite(wagerValue)
    || wagerValue < MULTIPLIER_MIN
    || wagerValue > MULTIPLIER_MAX
    ? `Enter a value between ${MULTIPLIER_MIN} and ${MULTIPLIER_MAX}`
    : null;
  const wagerDirty = !!summary && !wagerError
    && Math.round(wagerValue * 100) / 100 !== Number(summary.wager_multiplier);

  const enabled = summary?.withdrawals_enabled ?? true;

  // Wording for the transaction-password dialog.
  const confirm = ((): { title: string; body: string; action: string; tone: string } | null => {
    if (!pending) return null;
    const onOff = { action: pending.enabled ? 'Turn ON' : 'Turn OFF', tone: pending.enabled ? C.success : C.error };
    if (pending.kind === 'global') {
      return pending.enabled
        ? { ...onOff, title: 'Turn withdrawals back ON?', body: 'Players can withdraw again through every method. Players with a per-user lock stay blocked.' }
        : { ...onOff, title: 'Turn withdrawals OFF for all players?', body: 'Every new withdrawal request (F2Pay, Paykassma, bank/UPI queue and crypto) will be rejected until you switch this back on. Requests already in progress are not affected.' };
    }
    if (pending.kind === 'wager') {
      const next = pending.multiplier ?? wagerMultiplier;
      if (pending.enabled === undefined) {
        return {
          title: `Change the wagering bonus to up to ${fmtMult(next)}?`,
          body: `On top of ${fmtMult(multiplier)} their deposits, players will unlock what they have wagered, up to ${fmtMult(next)} their deposits instead of ${fmtMult(wagerMultiplier)}. Requests already in progress are not affected.`,
          action: 'Save bonus', tone: C.primary,
        };
      }
      return pending.enabled
        ? { ...onOff, title: 'Turn the wagering bonus ON for all players?', body: `On top of ${fmtMult(multiplier)} their deposits, players will be able to withdraw what they have wagered, up to ${fmtMult(next)} their deposits.` }
        : { ...onOff, title: 'Turn the wagering bonus OFF?', body: `Every player will be capped at ${fmtMult(multiplier)} their total deposits, however much they have wagered. Players already past that are blocked from new withdrawals until they deposit more.` };
    }
    if (pending.enabled === undefined) {
      return {
        title: `Change withdrawal limit to ${fmtMult(pending.multiplier ?? multiplier)}?`,
        body: `Every player will be able to withdraw up to ${fmtMult(pending.multiplier ?? multiplier)} their total deposits, instead of ${fmtMult(multiplier)}${wagerOn ? ', plus their wagering bonus' : ''}. Requests already in progress are not affected.`,
        action: 'Save limit', tone: C.primary,
      };
    }
    return pending.enabled
      ? { ...onOff, title: 'Turn the withdrawal limit ON for all players?', body: `Every player will be able to withdraw at most ${fmtMult(multiplier)} their total deposits${wagerOn ? `, plus what they have wagered up to ${fmtMult(wagerMultiplier)} their deposits` : ''}. Players already past that are blocked from new withdrawals until they deposit or wager more.` }
      : { ...onOff, title: 'Turn the withdrawal limit OFF?', body: 'Players will be able to withdraw any amount up to their balance, with no deposit-based cap and no wagering bonus.' };
  })();

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
      {summaryError && (
        <Alert severity="error" action={<Button color="inherit" size="small" onClick={loadSummary}>Retry</Button>}
          sx={{ bgcolor: 'rgba(224,27,79,0.12)', color: C.error, border: '1px solid rgba(224,27,79,0.3)' }}>
          {summaryError}
        </Alert>
      )}

      {/* Global switch */}
      <Card sx={{
        bgcolor: C.card, borderRadius: 2, p: { xs: 2, md: 2.5 },
        border: `1px solid ${!summaryLoading && !enabled ? `${C.error}88` : C.border}`,
      }}>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 2, flexWrap: 'wrap' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, minWidth: 0, flex: '1 1 320px' }}>
            <Box sx={{
              width: 52, height: 52, borderRadius: 2, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
              bgcolor: `${enabled ? C.success : C.error}22`, color: enabled ? C.success : C.error,
            }}>
              {enabled ? <CheckCircle /> : <Block />}
            </Box>
            <Box sx={{ minWidth: 0 }}>
              <Typography sx={{ color: C.text, fontWeight: 700, fontSize: '1rem' }}>Global Withdrawals</Typography>
              <Typography sx={{ color: C.textMuted, fontSize: '0.78rem', mt: 0.25 }}>
                Applies to every player and every method: F2Pay, Paykassma (A-Pay), bank/UPI queue and crypto.
              </Typography>
              <Typography sx={{ color: C.textSecondary, fontSize: '0.7rem', mt: 0.5 }}>
                Last config change: {summaryLoading ? '…' : fmtDate(summary?.config_updated_at)}
              </Typography>
            </Box>
          </Box>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
            {summaryLoading ? (
              <CircularProgress size={22} />
            ) : (
              <>
                <Chip
                  label={enabled ? 'ON' : 'OFF'}
                  size="small"
                  sx={{
                    fontWeight: 800, letterSpacing: '0.08em', minWidth: 52,
                    bgcolor: `${enabled ? C.success : C.error}22`, color: enabled ? C.success : C.error,
                    border: `1px solid ${enabled ? C.success : C.error}55`,
                  }}
                />
                <Switch
                  checked={enabled}
                  disabled={!summary}
                  onChange={() => setPending({ kind: 'global', enabled: !enabled })}
                  inputProps={{ 'aria-label': 'Global withdrawals' }}
                  sx={switchColor(C.success)}
                />
              </>
            )}
          </Box>
        </Box>
      </Card>

      {!summaryLoading && summary && !enabled && (
        <Alert severity="error" sx={{ bgcolor: 'rgba(224,27,79,0.12)', color: C.error, border: '1px solid rgba(224,27,79,0.3)' }}>
          Withdrawals are OFF. No player can withdraw by any method until this is switched back on.
        </Alert>
      )}

      {/* Deposit-based withdrawal limit */}
      <Card sx={{ bgcolor: C.card, border: `1px solid ${C.border}`, borderRadius: 2, p: { xs: 2, md: 2.5 } }}>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 2, flexWrap: 'wrap' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, minWidth: 0, flex: '1 1 320px' }}>
            <Box sx={{
              width: 52, height: 52, borderRadius: 2, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
              bgcolor: `${limitOn ? C.warning : C.textMuted}22`, color: limitOn ? C.warning : C.textMuted,
            }}>
              <Speed />
            </Box>
            <Box sx={{ minWidth: 0 }}>
              <Typography sx={{ color: C.text, fontWeight: 700, fontSize: '1rem' }}>
                Withdrawal limit: {summaryLoading ? '…' : limitOn ? `${fmtMult(multiplier)} total deposits` : 'off'}
              </Typography>
              <Typography sx={{ color: C.textMuted, fontSize: '0.78rem', mt: 0.25 }}>
                Every player can withdraw at most this many times what they have deposited, in each currency,
                plus the wagering bonus below. Agent transfers count as INR deposits, and pending withdrawals
                count toward the limit.
              </Typography>
            </Box>
          </Box>
          <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1.5, flexWrap: 'wrap' }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, height: 40 }}>
              {summaryLoading ? (
                <CircularProgress size={22} />
              ) : (
                <>
                  <Chip
                    label={limitOn ? 'ON' : 'OFF'}
                    size="small"
                    sx={{
                      fontWeight: 800, letterSpacing: '0.08em', minWidth: 52,
                      bgcolor: `${limitOn ? C.warning : C.textMuted}22`, color: limitOn ? C.warning : C.textMuted,
                      border: `1px solid ${limitOn ? C.warning : C.textMuted}55`,
                    }}
                  />
                  <Switch
                    checked={limitOn}
                    disabled={!summary}
                    onChange={() => setPending({ kind: 'limit', enabled: !limitOn })}
                    inputProps={{ 'aria-label': 'Deposit-based withdrawal limit' }}
                    sx={switchColor(C.warning)}
                  />
                </>
              )}
            </Box>
            <TextField
              size="small"
              type="number"
              label="Multiplier"
              value={multiplierInput}
              disabled={!summary}
              onChange={e => setMultiplierInput(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter' && multiplierDirty) setPending({ kind: 'limit', multiplier: multiplierValue }); }}
              error={!!summary && !!multiplierError}
              helperText={summary && multiplierError ? multiplierError : ' '}
              inputProps={{ min: MULTIPLIER_MIN, max: MULTIPLIER_MAX, step: 0.5 }}
              InputProps={{ endAdornment: <InputAdornment position="end">×</InputAdornment> }}
              sx={{ width: 150, '& .MuiOutlinedInput-root': { bgcolor: C.cardLight, color: C.text } }}
            />
            <Button
              variant="contained"
              disabled={!multiplierDirty}
              onClick={() => setPending({ kind: 'limit', multiplier: multiplierValue })}
              sx={{ textTransform: 'none', fontWeight: 700, height: 40 }}
            >
              Save
            </Button>
          </Box>
        </Box>
      </Card>

      {/* Wagering bonus on top of the deposit limit */}
      <Card sx={{ bgcolor: C.card, border: `1px solid ${C.border}`, borderRadius: 2, p: { xs: 2, md: 2.5 } }}>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 2, flexWrap: 'wrap' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, minWidth: 0, flex: '1 1 320px' }}>
            <Box sx={{
              width: 52, height: 52, borderRadius: 2, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
              bgcolor: `${wagerActive ? C.info : C.textMuted}22`, color: wagerActive ? C.info : C.textMuted,
            }}>
              <Casino />
            </Box>
            <Box sx={{ minWidth: 0 }}>
              <Typography sx={{ color: C.text, fontWeight: 700, fontSize: '1rem' }}>
                Wagering bonus: {summaryLoading ? '…' : wagerOn ? `up to ${fmtMult(wagerMultiplier)} total deposits` : 'off'}
              </Typography>
              <Typography sx={{ color: C.textMuted, fontSize: '0.78rem', mt: 0.25 }}>
                Added on top of the withdrawal limit. It unlocks rupee for rupee with the amount the player has bet
                (casino and settled sports bets, refunds excluded) and stops at this many times their deposits.
              </Typography>
              {!summaryLoading && summary && (
                <Typography sx={{ color: C.textSecondary, fontSize: '0.72rem', mt: 0.5 }}>
                  {!limitOn
                    ? 'No effect while the withdrawal limit is off.'
                    : wagerOn
                      ? `Example: ₹1,000 deposited and ₹1,000 wagered → ${fmtInr(1000 * multiplier)} + ${fmtInr(1000)} = ${fmtInr(1000 * multiplier + 1000)}. `
                        + `With ${fmtInr(1000 * wagerMultiplier)} or more wagered → ${fmtInr(1000 * multiplier)} + ${fmtInr(1000 * wagerMultiplier)} = ${fmtInr(1000 * (multiplier + wagerMultiplier))}.`
                      : `Every player is capped at ${fmtMult(multiplier)} their deposits, however much they wager.`}
                </Typography>
              )}
            </Box>
          </Box>
          <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1.5, flexWrap: 'wrap' }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, height: 40 }}>
              {summaryLoading ? (
                <CircularProgress size={22} />
              ) : (
                <>
                  <Chip
                    label={wagerOn ? 'ON' : 'OFF'}
                    size="small"
                    sx={{
                      fontWeight: 800, letterSpacing: '0.08em', minWidth: 52,
                      bgcolor: `${wagerActive ? C.info : C.textMuted}22`, color: wagerActive ? C.info : C.textMuted,
                      border: `1px solid ${wagerActive ? C.info : C.textMuted}55`,
                    }}
                  />
                  <Switch
                    checked={wagerOn}
                    disabled={!summary}
                    onChange={() => setPending({ kind: 'wager', enabled: !wagerOn })}
                    inputProps={{ 'aria-label': 'Wagering bonus' }}
                    sx={switchColor(C.info)}
                  />
                </>
              )}
            </Box>
            <TextField
              size="small"
              type="number"
              label="Bonus up to"
              value={wagerInput}
              disabled={!summary}
              onChange={e => setWagerInput(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter' && wagerDirty) setPending({ kind: 'wager', multiplier: wagerValue }); }}
              error={!!summary && !!wagerError}
              helperText={summary && wagerError ? wagerError : ' '}
              inputProps={{ min: MULTIPLIER_MIN, max: MULTIPLIER_MAX, step: 0.5 }}
              InputProps={{ endAdornment: <InputAdornment position="end">×</InputAdornment> }}
              sx={{ width: 150, '& .MuiOutlinedInput-root': { bgcolor: C.cardLight, color: C.text } }}
            />
            <Button
              variant="contained"
              disabled={!wagerDirty}
              onClick={() => setPending({ kind: 'wager', multiplier: wagerValue })}
              sx={{ textTransform: 'none', fontWeight: 700, height: 40 }}
            >
              Save
            </Button>
          </Box>
        </Box>
      </Card>

      <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
        <StatCard label="Direct users" value={(summary?.direct_users ?? 0).toLocaleString('en-IN')}
          icon={<People />} color={C.primary} loading={summaryLoading} />
        <StatCard label="Withdrawal locked" value={(summary?.locked_direct_users ?? 0).toLocaleString('en-IN')}
          icon={<Lock />} color={C.error} loading={summaryLoading} />
      </Box>

      {/* Per-user locks */}
      <Card sx={{ bgcolor: C.card, border: `1px solid ${C.border}`, borderRadius: 2, overflow: 'hidden' }}>
        <Box sx={{ p: { xs: 2, md: 2.5 }, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 2, flexWrap: 'wrap' }}>
          <Box sx={{ minWidth: 0, flex: '1 1 260px' }}>
            <Typography sx={{ color: C.text, fontWeight: 700, fontSize: '1rem' }}>Per-user withdrawal lock</Typography>
            <Typography sx={{ color: C.textMuted, fontSize: '0.78rem', mt: 0.25 }}>
              A locked player is rejected on every withdrawal method, even while withdrawals are ON globally.
            </Typography>
          </Box>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
            <TextField
              size="small"
              placeholder="Search name, email, phone or ID"
              value={search}
              onChange={e => setSearch(e.target.value)}
              InputProps={{
                startAdornment: <InputAdornment position="start"><Search sx={{ color: C.textMuted, fontSize: 18 }} /></InputAdornment>,
              }}
              sx={{ width: { xs: '100%', sm: 280 }, '& .MuiOutlinedInput-root': { bgcolor: C.cardLight, color: C.text } }}
            />
            <ToggleButtonGroup
              size="small"
              exclusive
              value={status}
              onChange={(_, v) => { if (v) { setStatus(v); setPage(0); } }}
              sx={{
                '& .MuiToggleButton-root': { color: C.textMuted, borderColor: C.border, textTransform: 'none', fontWeight: 600, px: 1.5 },
                '& .Mui-selected': { color: `${C.text} !important`, bgcolor: `${C.primary}33 !important` },
              }}
            >
              <ToggleButton value="all">All</ToggleButton>
              <ToggleButton value="locked">Locked</ToggleButton>
            </ToggleButtonGroup>
            <Tooltip title="Refresh">
              <IconButton onClick={() => { loadUsers(); loadSummary(); }} sx={{ color: C.textMuted }}>
                <Refresh />
              </IconButton>
            </Tooltip>
          </Box>
        </Box>

        {usersError && (
          <Alert severity="error" sx={{ mx: 2.5, mb: 2, bgcolor: 'rgba(224,27,79,0.12)', color: C.error, border: '1px solid rgba(224,27,79,0.3)' }}>
            {usersError}
          </Alert>
        )}

        <TableContainer sx={{ overflowX: 'auto' }}>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell sx={headCell}>User</TableCell>
                <TableCell sx={headCell}>Phone</TableCell>
                <TableCell sx={headCell} align="right">INR balance</TableCell>
                <TableCell sx={headCell} align="right">Deposited</TableCell>
                <TableCell sx={headCell} align="right">Wagered</TableCell>
                <TableCell sx={headCell} align="right">Withdrawn / max</TableCell>
                <TableCell sx={headCell}>Joined</TableCell>
                <TableCell sx={headCell}>Withdrawals</TableCell>
                <TableCell sx={headCell} align="center">Lock</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {usersLoading ? (
                Array.from({ length: 6 }).map((_, i) => (
                  <TableRow key={i}>
                    {Array.from({ length: COLS }).map((__, j) => (
                      <TableCell key={j} sx={bodyCell}><Skeleton variant="text" sx={{ bgcolor: C.border }} /></TableCell>
                    ))}
                  </TableRow>
                ))
              ) : users.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={COLS} sx={{ ...bodyCell, textAlign: 'center', py: 5, color: C.textMuted }}>
                    {status === 'locked' ? 'No direct users are withdrawal-locked.' : 'No users match your search.'}
                  </TableCell>
                </TableRow>
              ) : (
                users.map(u => {
                  const max = u.max_withdrawable_inr;
                  const overLimit = limitOn && u.withdrawn_inr >= max;
                  return (
                  <TableRow key={u.id} hover sx={{ '&:hover': { bgcolor: `${C.cardHover} !important` } }}>
                    <TableCell sx={bodyCell}>
                      <Typography sx={{ color: C.text, fontWeight: 600, fontSize: '0.84rem' }}>{u.name || '—'}</Typography>
                      <Typography sx={{ color: C.textMuted, fontSize: '0.72rem' }}>{u.email || '—'} · ID {u.id}</Typography>
                    </TableCell>
                    <TableCell sx={bodyCell}>{u.phone || '—'}</TableCell>
                    <TableCell sx={{ ...bodyCell, fontVariantNumeric: 'tabular-nums' }} align="right">{fmtInr(u.inr_balance)}</TableCell>
                    <TableCell sx={{ ...bodyCell, fontVariantNumeric: 'tabular-nums' }} align="right">{fmtInr(u.deposited_inr)}</TableCell>
                    <TableCell sx={{ ...bodyCell, fontVariantNumeric: 'tabular-nums' }} align="right">{fmtInr(u.wagered_inr)}</TableCell>
                    <TableCell sx={{ ...bodyCell, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }} align="right">
                      <Typography component="span" sx={{ fontSize: 'inherit', color: overLimit ? C.error : C.text, fontWeight: overLimit ? 700 : 400 }}>
                        {fmtInr(u.withdrawn_inr)}
                      </Typography>
                      <Tooltip
                        title={limitOn
                          ? `${fmtMult(multiplier)} deposits = ${fmtInr(u.deposited_inr * multiplier)}`
                            + (wagerOn ? ` + ${fmtInr(u.wager_bonus_inr)} wagering bonus` : '')
                          : ''}
                      >
                        <Typography component="span" sx={{ fontSize: '0.72rem', color: C.textMuted }}>
                          {' / '}{limitOn ? fmtInr(max) : 'no limit'}
                        </Typography>
                      </Tooltip>
                    </TableCell>
                    <TableCell sx={{ ...bodyCell, whiteSpace: 'nowrap', color: C.textMuted }}>{fmtDate(u.created)}</TableCell>
                    <TableCell sx={bodyCell}>
                      <Chip
                        size="small"
                        icon={u.withdrawal_locked ? <Lock sx={{ fontSize: 14 }} /> : <LockOpen sx={{ fontSize: 14 }} />}
                        label={u.withdrawal_locked ? 'Locked' : 'Allowed'}
                        sx={{
                          fontWeight: 700,
                          bgcolor: `${u.withdrawal_locked ? C.error : C.success}1f`,
                          color: u.withdrawal_locked ? C.error : C.success,
                          '& .MuiChip-icon': { color: 'inherit' },
                        }}
                      />
                    </TableCell>
                    <TableCell sx={bodyCell} align="center">
                      {togglingId === u.id ? (
                        <CircularProgress size={20} />
                      ) : (
                        <Switch
                          checked={u.withdrawal_locked}
                          onChange={() => toggleUser(u)}
                          disabled={togglingId !== null}
                          inputProps={{ 'aria-label': `Withdrawal lock for ${u.name || u.id}` }}
                          sx={switchColor(C.error)}
                        />
                      )}
                    </TableCell>
                  </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </TableContainer>
        <TablePagination
          component="div"
          count={total}
          page={page}
          onPageChange={(_, p) => setPage(p)}
          rowsPerPage={rowsPerPage}
          onRowsPerPageChange={e => { setRowsPerPage(parseInt(e.target.value, 10)); setPage(0); }}
          rowsPerPageOptions={[20, 50, 100]}
          sx={{ color: C.textMuted, borderTop: `1px solid ${C.border}` }}
        />
      </Card>

      <Dialog open={pending !== null} onClose={closeConfirm} maxWidth="xs" fullWidth
        PaperProps={{ sx: { bgcolor: C.card, border: `1px solid ${C.border}`, color: C.text } }}>
        <DialogTitle sx={{ fontWeight: 700 }}>{confirm?.title}</DialogTitle>
        <DialogContent>
          <Typography sx={{ color: C.textMuted, fontSize: '0.85rem', mb: 2 }}>{confirm?.body}</Typography>
          <TextField
            autoFocus
            fullWidth
            size="small"
            type="password"
            label="Transaction password"
            value={txnPwd}
            onChange={e => setTxnPwd(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter') savePending(); }}
            error={!!confirmError}
            helperText={confirmError || ' '}
            autoComplete="off"
          />
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={closeConfirm} disabled={savingGlobal} sx={{ color: C.textMuted, textTransform: 'none' }}>Cancel</Button>
          <Button
            variant="contained"
            onClick={savePending}
            disabled={savingGlobal}
            startIcon={savingGlobal ? <CircularProgress size={16} color="inherit" /> : undefined}
            sx={{ textTransform: 'none', fontWeight: 700, bgcolor: confirm?.tone, '&:hover': { bgcolor: confirm?.tone, filter: 'brightness(0.9)' } }}
          >
            {confirm?.action}
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar open={snack.open} autoHideDuration={3500} onClose={() => setSnack(s => ({ ...s, open: false }))}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}>
        <Alert severity={snack.severity} variant="filled" onClose={() => setSnack(s => ({ ...s, open: false }))}>
          {snack.msg}
        </Alert>
      </Snackbar>
    </Box>
  );
};

// Financial controls for direct users. Sub-tabs leave room for more
// (deposit limits, etc.); Withdrawal is the only one today.
const FinancialTab: React.FC = () => {
  const [section, setSection] = useState<'withdrawal'>('withdrawal');

  return (
    <Box>
      <Tabs
        value={section}
        onChange={(_, v) => setSection(v)}
        sx={{
          minHeight: 36, mb: 2,
          '& .MuiTabs-indicator': { display: 'none' },
          '& .MuiTab-root': {
            minHeight: 36, textTransform: 'none', fontWeight: 600, fontSize: '0.82rem', gap: 0.5,
            color: C.textMuted, borderRadius: 1.5, border: `1px solid ${C.border}`, px: 2,
            '&.Mui-selected': { color: C.text, bgcolor: `${C.primary}33`, borderColor: `${C.primary}88` },
          },
        }}
      >
        <Tab value="withdrawal" label="Withdrawal" icon={<AccountBalanceWallet sx={{ fontSize: 16 }} />} iconPosition="start" />
      </Tabs>
      {section === 'withdrawal' && <WithdrawalControl />}
    </Box>
  );
};

export default FinancialTab;
