import React, { useEffect, useMemo, useState } from 'react';
import {
  Dialog, DialogContent, Box, Typography, IconButton, Button, TextField,
  Stack, CircularProgress, Chip,
} from '@mui/material';
import { Casino, SportsCricket, Close, Download } from '@mui/icons-material';

const C = {
  card: '#0E1831', border: '#1E2D55', primary: '#2B6EF5', primaryHover: '#4A85F7',
  text: '#F9F9F9', textMuted: '#8384A5', input: '#10182E', error: '#E01B4F',
};
const BASE = 'https://example.com';

export type ReportKind = 'casino' | 'sports';

type Preset = 'today' | 'yesterday' | '24h' | 'custom';

/** Operators pick wall-clock IST regardless of where their browser sits, so the
 *  picked value is pinned to +05:30 and converted to a real instant here. */
const IST_OFFSET_MIN = 330;
const toUtcIso = (local: string) => new Date(`${local}:00+05:30`).toISOString();

/** `YYYY-MM-DDTHH:mm` for *IST*, shifted off the given instant. `toISOString`
 *  already renders UTC, so the browser's own offset must NOT be added here —
 *  doing so double-corrects and skews every preset by 5:30 on an IST machine. */
const istLocalValue = (d: Date) =>
  new Date(d.getTime() + IST_OFFSET_MIN * 60000).toISOString().slice(0, 16);

const istToday = () => istLocalValue(new Date()).slice(0, 10);
const shiftDays = (ymd: string, days: number) => {
  const d = new Date(`${ymd}T00:00:00+05:30`);
  d.setUTCDate(d.getUTCDate() + days);
  return istLocalValue(d).slice(0, 10);
};

interface Props {
  open: boolean;
  kind: ReportKind;
  userId: string | null;
  userName: string | null;
  onClose: () => void;
}

const META: Record<ReportKind, { title: string; icon: React.ReactNode; blurb: string; path: string; file: string }> = {
  casino: {
    title: 'Casino Game Report',
    icon: <Casino sx={{ color: C.primary, fontSize: 20 }} />,
    blurb: 'Every casino round in the chosen window — game name, session ID, round ID, stake, payout, win or loss, running balance, plus every provider callback and the integrity checks over them.',
    path: 'casino',
    file: 'Casino',
  },
  sports: {
    title: 'Sports Bet Report',
    icon: <SportsCricket sx={{ color: C.primary, fontSize: 20 }} />,
    blurb: 'Every sports bet in the chosen window — match, selection, market, odds, stake, result and the settled amount written to the wallet, broken down by market and by match.',
    path: 'sports',
    file: 'Sports',
  },
};

const SessionReportDialog: React.FC<Props> = ({ open, kind, userId, userName, onClose }) => {
  const [preset, setPreset] = useState<Preset>('today');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const meta = META[kind];

  // Seed the custom fields with today 00:00 → now (IST) whenever the dialog opens.
  useEffect(() => {
    if (!open) return;
    const today = istToday();
    setFrom(`${today}T00:00`);
    setTo(istLocalValue(new Date()));
    setPreset('today');
    setError(null);
  }, [open]);

  const range = useMemo((): { from: string; to: string } | null => {
    const today = istToday();
    switch (preset) {
      case 'today': return { from: `${today}T00:00`, to: istLocalValue(new Date()) };
      case 'yesterday': { const y = shiftDays(today, -1); return { from: `${y}T00:00`, to: `${y}T23:59` }; }
      case '24h': { const now = new Date(); return { from: istLocalValue(new Date(now.getTime() - 86400000)), to: istLocalValue(now) }; }
      case 'custom': return from && to ? { from, to } : null;
    }
  }, [preset, from, to]);

  const invalid = !range || new Date(`${range.from}:00+05:30`) >= new Date(`${range.to}:00+05:30`);

  const download = async () => {
    if (!userId || !range || invalid) return;
    setLoading(true);
    setError(null);
    try {
      const qs = new URLSearchParams({ from: toUtcIso(range.from), to: toUtcIso(range.to) });
      const token = localStorage.getItem('token');
      const res = await fetch(`${BASE}/api/report/${meta.path}/${userId}?${qs.toString()}`, {
        headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      });
      if (!res.ok) {
        let msg = `Failed (${res.status})`;
        try { msg = (await res.json()).error || msg; } catch { /* non-json */ }
        throw new Error(msg);
      }
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      const safe = (userName || 'player').replace(/[^a-z0-9]+/gi, '_');
      a.download = `${meta.file}_${safe}_${userId}_${range.from.slice(0, 10)}.pdf`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
      onClose();
    } catch (e: any) {
      setError(e?.message || 'Could not generate the report');
    } finally {
      setLoading(false);
    }
  };

  const presets: { key: Preset; label: string }[] = [
    { key: 'today', label: 'Today' },
    { key: 'yesterday', label: 'Yesterday' },
    { key: '24h', label: 'Last 24 hours' },
    { key: 'custom', label: 'Custom date & time' },
  ];

  const inputSx = {
    '& .MuiInputBase-root': { bgcolor: C.input, color: C.text, fontSize: '0.82rem' },
    '& .MuiOutlinedInput-notchedOutline': { borderColor: C.border },
    '& .MuiInputLabel-root': { color: C.textMuted, fontSize: '0.82rem' },
    '& .MuiSvgIcon-root': { color: C.textMuted },
  };

  return (
    <Dialog open={open} onClose={loading ? undefined : onClose} maxWidth="xs" fullWidth
      PaperProps={{ sx: { bgcolor: C.card, border: `1px solid ${C.border}`, borderRadius: 2 } }}>
      <DialogContent sx={{ p: 0 }}>
        <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ px: 2.5, py: 1.75, borderBottom: `1px solid ${C.border}` }}>
          <Stack direction="row" alignItems="center" gap={1}>
            {meta.icon}
            <Box>
              <Typography sx={{ color: C.text, fontSize: '0.95rem', fontWeight: 700, lineHeight: 1.2 }}>{meta.title}</Typography>
              {userName && <Typography sx={{ color: C.textMuted, fontSize: '0.72rem' }}>{userName} · UID {userId}</Typography>}
            </Box>
          </Stack>
          <IconButton size="small" onClick={onClose} disabled={loading} sx={{ color: C.textMuted }}>
            <Close fontSize="small" />
          </IconButton>
        </Stack>

        <Box sx={{ px: 2.5, py: 2 }}>
          <Typography sx={{ color: C.textMuted, fontSize: '0.72rem', textTransform: 'uppercase', letterSpacing: '0.05em', mb: 1 }}>
            Report period (IST)
          </Typography>
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 2 }}>
            {presets.map(p => (
              <Chip key={p.key} label={p.label} onClick={() => setPreset(p.key)}
                sx={{
                  bgcolor: preset === p.key ? C.primary : C.input,
                  color: preset === p.key ? '#fff' : C.textMuted,
                  border: `1px solid ${preset === p.key ? C.primary : C.border}`,
                  fontSize: '0.75rem', fontWeight: 600, cursor: 'pointer',
                  '&:hover': { bgcolor: preset === p.key ? C.primaryHover : '#162140' },
                }} />
            ))}
          </Box>

          <Stack gap={1.25} sx={{ mb: 2 }}>
            <TextField type="datetime-local" size="small" label="From" value={range?.from ?? from}
              onChange={e => { setFrom(e.target.value); setPreset('custom'); }}
              InputLabelProps={{ shrink: true }} sx={inputSx} />
            <TextField type="datetime-local" size="small" label="To" value={range?.to ?? to}
              onChange={e => { setTo(e.target.value); setPreset('custom'); }}
              InputLabelProps={{ shrink: true }} sx={inputSx} />
          </Stack>

          <Typography sx={{ color: C.textMuted, fontSize: '0.72rem', mb: 2 }}>
            {meta.blurb}
          </Typography>

          {invalid && !error && (
            <Typography sx={{ color: C.error, fontSize: '0.75rem', mb: 1.5 }}>
              “From” must be earlier than “to”.
            </Typography>
          )}

          {error && (
            <Box sx={{ mb: 1.5, p: 1.25, bgcolor: '#2B0E1A', border: `1px solid ${C.error}`, borderRadius: 1 }}>
              <Typography sx={{ color: C.error, fontSize: '0.78rem' }}>{error}</Typography>
            </Box>
          )}

          <Button fullWidth variant="contained" onClick={download} disabled={loading || invalid}
            startIcon={loading ? <CircularProgress size={16} sx={{ color: '#fff' }} /> : <Download />}
            sx={{ bgcolor: C.primary, textTransform: 'none', fontWeight: 700, fontSize: '0.85rem', py: 1, '&:hover': { bgcolor: C.primaryHover } }}>
            {loading ? 'Generating…' : 'Download PDF'}
          </Button>
        </Box>
      </DialogContent>
    </Dialog>
  );
};

export default SessionReportDialog;
