import { Switch } from "@mui/material";

interface DarkSwitchProps {
  checked: boolean;
  onChange: () => void;
  disabled?: boolean;
}

const DarkSwitch = ({ checked, onChange, disabled = false }: DarkSwitchProps) => (
  <Switch
    checked={checked}
    onChange={onChange}
    disabled={disabled}
    size="small"
    sx={{
      width: 38,
      height: 22,
      padding: 0,
      "& .MuiSwitch-switchBase": {
        padding: 0,
        margin: "2px",
        transitionDuration: "250ms",
        "&.Mui-checked": {
          transform: "translateX(16px)",
          color: "#fff",
          "& + .MuiSwitch-track": { bgcolor: "#2B6EF5", opacity: 1, border: 0 },
        },
      },
      "& .MuiSwitch-thumb": {
        boxSizing: "border-box",
        width: 18,
        height: 18,
        bgcolor: "#F9F9F9",
      },
      "& .MuiSwitch-track": { borderRadius: 11, bgcolor: "#162140", opacity: 1 },
    }}
  />
);

export default DarkSwitch;
