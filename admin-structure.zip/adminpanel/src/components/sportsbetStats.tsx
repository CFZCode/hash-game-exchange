import React, { useEffect, useState, useMemo } from "react";
import { useLocation } from "react-router-dom";
import {
    Activity,
    TrendingUp,
    ArrowDownCircle,
    Layers,
    Wallet,
    DollarSign,
    Search,
    BarChart3,
    PieChart,
    LayoutDashboard,
    ListOrdered,
    RefreshCw,
    Eye,
    ArrowLeft,
    Lock,
    Unlock,
    Shield,
    Users,
    XCircle,
    AlertTriangle,
} from "lucide-react";

const API_BASE = "https://example.com";

// ==================== TYPES ====================
interface Bet {
    id: number;
    user_id: number;
    match_title: string;
    selection_name: string;
    bet_type: string;
    market_type: string;
    odds: number;
    stake_amount: number;
    liability: number;
    match_start_time: string;
    status: string;
    result_status: string;
    original_currency: string;
    original_amount: number;
    usd_amount: number;
}

interface Stats {
    totalBets: number;
    totalWins: number;
    totalLosses: number;
    totalPending: number;
}

interface TickerBet {
    id: string;
    user_id: number;
    username: string;
    created_at: string;
    description: string;
    selection: string;
    game_type: string;
    bet_type: string | null;
    odds: number;
    amount: number;
    liability: number;
    status: string;
    source: string;
}

interface BetListItem {
    id: number;
    user_id: number;
    game_type: string;
    match_title: string;
    selection_name: string;
    bet_type: string;
    market_type: string;
    odds: number;
    stake_amount: number;
    liability: number;
    status: string;
    result_status: string;
    sport_id: string;
    event_name: string;
    updated_at: string;
    created_at: string | null;
    fancy_name: string;
}

interface ExposureMarket {
    id: string;
    marketName: string;
    matchId: string;
    gameType: string;
    selections: Record<string, number>;
    runners: string[];
    stake: number;
    pl: number;
}

interface ExposureEvent {
    id: string;
    eventId: string;
    eventName: string;
    eventDate: string;
    category: string;
    markets: ExposureMarket[];
}

interface MarketBookEntry {
    userId: number;
    username: string;
    runners: Record<string, number>;
}

interface SettledMarket {
    matchId: string;
    marketType: string;
    sportId: string;
    eventId: string;
    description: string;
    matchTitle: string;
    teamOne: string;
    teamTwo: string;
    gameType: string;
    totalEntries: number;
    totalUsers: number;
    totalNetAmount: number;
    lastSettledAt: string;
}

interface SettledBet {
    ledgerId: number;
    betId: number;
    userId: number;
    username: string;
    amount: number;
    netamount: number;
    profit: number;
    loss: number;
    commission: number;
    description: string;
    marketType: string;
    sportId: string;
    matchId: string;
    eventId: string;
    jobId: string;
    createdAt: string;
    betType: string;
    selectionName: string;
    odds: number | null;
    stakeAmount: number | null;
    gameType: string;
    resultStatus: string;
}

type Tab = "dashboard" | "ticker" | "profitloss" | "market" | "betlock" | "settledvoid";

const TABS: { key: Tab; label: string; icon: React.ReactNode }[] = [
    { key: "dashboard", label: "Dashboard", icon: <LayoutDashboard size={16} /> },
    { key: "ticker", label: "Bet Ticker", icon: <ListOrdered size={16} /> },
    { key: "profitloss", label: "Profit & Loss", icon: <BarChart3 size={16} /> },
    { key: "market", label: "Net Exposure", icon: <PieChart size={16} /> },
    { key: "betlock", label: "Bet Lock", icon: <Lock size={16} /> },
    { key: "settledvoid", label: "Settled Void", icon: <XCircle size={16} /> },
];

const SPORT_LIST = [
    { value: "All", label: "All" },
    { value: "4", label: "Cricket" },
    { value: "1", label: "Football" },
    { value: "2", label: "Tennis" },
    { value: "8", label: "Table Tennis" },
    { value: "15", label: "Basketball" },
    { value: "66", label: "Kabaddi" },
];

// ==================== MAIN COMPONENT ====================
const SportsDashboard: React.FC = () => {
    const staffId = localStorage.getItem("currentUserId");
    const location = useLocation();
    const [activeTab, setActiveTab] = useState<Tab>(
        location.pathname === "/sports-lock" ? "betlock" : "dashboard"
    );

    useEffect(() => {
        if (location.pathname === "/sports-lock") setActiveTab("betlock");
    }, [location.pathname]);

    // ===== DASHBOARD STATE =====
    const [bets, setBets] = useState<Bet[]>([]);
    const [stats, setStats] = useState<Stats>({ totalBets: 0, totalWins: 0, totalLosses: 0, totalPending: 0 });
    const [page, setPage] = useState(1);
    const [limit, setLimit] = useState(10);

    // User lookup
    const [userId, setUserId] = useState("");
    const [userBets, setUserBets] = useState<Bet[]>([]);
    const [userStats, setUserStats] = useState<Stats>({ totalBets: 0, totalWins: 0, totalLosses: 0, totalPending: 0 });
    const [userPage, setUserPage] = useState(1);
    const [userLimit] = useState(10);
    const [userLoading, setUserLoading] = useState(false);
    const [userSearched, setUserSearched] = useState(false);

    // ===== BET LOCK STATE =====
    const [lockUsers, setLockUsers] = useState<any[]>([]);
    const [lockStaff, setLockStaff] = useState<any[]>([]);
    const [lockSubTab, setLockSubTab] = useState<"users" | "staff">("users");
    const [lockSearch, setLockSearch] = useState("");
    const [lockLoading, setLockLoading] = useState(false);
    const [togglingId, setTogglingId] = useState<number | null>(null);

    // ===== BET TICKER STATE =====
    const [tickerData, setTickerData] = useState<TickerBet[]>([]);
    const [tickerLoading, setTickerLoading] = useState(false);
    const [tickerSport, setTickerSport] = useState("All");
    const [tickerSearch, setTickerSearch] = useState("");
    const [tickerTimer, setTickerTimer] = useState(10);

    // ===== PROFIT & LOSS STATE =====
    const [plData, setPlData] = useState<BetListItem[]>([]);
    const [plLoading, setPlLoading] = useState(false);
    const [plSport, setPlSport] = useState("All");
    const [plSearch, setPlSearch] = useState("");
    const [plFromDate, setPlFromDate] = useState(() => {
        const d = new Date(); d.setDate(d.getDate() - 7);
        return d.toISOString().split("T")[0];
    });
    const [plToDate, setPlToDate] = useState(() => new Date().toISOString().split("T")[0]);
    const [plPage, setPlPage] = useState(1);
    const [plLimit, setPlLimit] = useState(50);
    const [plTotal, setPlTotal] = useState(0);
    const [plSelectedBets, setPlSelectedBets] = useState<BetListItem[] | null>(null);
    const [plSelectedName, setPlSelectedName] = useState("");

    // ===== NET EXPOSURE STATE =====
    const [exposureData, setExposureData] = useState<ExposureEvent[]>([]);
    const [exposureLoading, setExposureLoading] = useState(false);
    const [exposureMeta, setExposureMeta] = useState({ totalEvents: 0, totalExposure: 0 });
    const [exposureTimer, setExposureTimer] = useState(10);
    const [marketBook, setMarketBook] = useState<MarketBookEntry[] | null>(null);
    const [marketBookTitle, setMarketBookTitle] = useState("");
    const [marketBookLoading, setMarketBookLoading] = useState(false);

    // ===== SETTLED VOID STATE =====
    const [svMarkets, setSvMarkets] = useState<SettledMarket[]>([]);
    const [svLoading, setSvLoading] = useState(false);
    const [svSearch, setSvSearch] = useState("");
    const [svSelectedMarket, setSvSelectedMarket] = useState<SettledMarket | null>(null);
    const [svBets, setSvBets] = useState<SettledBet[]>([]);
    const [svBetsLoading, setSvBetsLoading] = useState(false);
    const [svVoidingMarket, setSvVoidingMarket] = useState(false);
    const [svVoidingBetId, setSvVoidingBetId] = useState<number | null>(null);

    const formatCurrency = (num: number) =>
        num.toLocaleString("en-IN", { style: "currency", currency: "INR" });

    // ==================== DASHBOARD FETCHES ====================
    useEffect(() => {
        const fetchData = async () => {
            try {
                const res = await fetch(
                    `${API_BASE}/betHistory/admin/bet-history?page=${page}&limit=${limit}&type=sports`,
                    { headers: { "x-staff-id": staffId ?? "" } }
                );
                const data = await res.json();
                setBets(data.list || []);
                setStats(data.stats || {});
            } catch (err) { console.error("API Error:", err); }
        };
        fetchData();
    }, [page, limit]);

    const fetchUserBets = async (p = userPage, l = userLimit) => {
        if (!userId.trim()) return;
        setUserLoading(true);
        setUserSearched(true);
        try {
            const res = await fetch(
                `${API_BASE}/betHistory/user/bet-history?page=${p}&limit=${l}&type=sports&user_id=${userId.trim()}`,
                { headers: { "x-staff-id": staffId ?? "" } }
            );
            const data = await res.json();
            setUserBets(data.list || []);
            setUserStats(data.stats || {});
        } catch (err) { console.error("User API Error:", err); }
        finally { setUserLoading(false); }
    };

    useEffect(() => {
        if (userSearched) fetchUserBets(userPage, userLimit);
    }, [userPage, userLimit]);

    const totalStake = bets.reduce((s, b) => s + b.stake_amount, 0);
    const totalLiability = bets.reduce((s, b) => s + b.liability, 0);
    const userTotalStake = userBets.reduce((s, b) => s + b.stake_amount, 0);
    const userTotalLiability = userBets.reduce((s, b) => s + b.liability, 0);

    // ==================== BET TICKER FETCHES ====================
    const fetchTicker = async (silent = false) => {
        if (!silent) setTickerLoading(true);
        try {
            const params = new URLSearchParams();
            if (tickerSport !== "All") params.append("sport", tickerSport);
            const res = await fetch(`${API_BASE}/api/sportsmain/admin/bet-ticker?${params}`, {
                headers: { "x-staff-id": staffId ?? "" },
            });
            const data = await res.json();
            if (data.success) setTickerData(data.data || []);
        } catch (err) { console.error("Ticker Error:", err); }
        finally { if (!silent) setTickerLoading(false); }
    };

    useEffect(() => {
        if (activeTab === "ticker") fetchTicker();
    }, [activeTab, tickerSport]);

    // Auto-refresh ticker
    useEffect(() => {
        if (activeTab !== "ticker") return;
        const interval = setInterval(() => {
            setTickerTimer((prev) => {
                if (prev <= 1) { fetchTicker(true); return 10; }
                return prev - 1;
            });
        }, 1000);
        return () => clearInterval(interval);
    }, [activeTab, tickerSport]);

    const filteredTicker = useMemo(() => {
        if (!tickerSearch.trim()) return tickerData;
        const term = tickerSearch.toLowerCase();
        return tickerData.filter(
            (b) =>
                (b.username || "").toLowerCase().includes(term) ||
                (b.description || "").toLowerCase().includes(term) ||
                (b.selection || "").toLowerCase().includes(term)
        );
    }, [tickerData, tickerSearch]);

    // ==================== PROFIT & LOSS FETCHES ====================
    const fetchPL = async () => {
        setPlLoading(true);
        try {
            const res = await fetch(
                `${API_BASE}/betHistory/admin/bet-history?page=${plPage}&limit=${plLimit}&type=sports`,
                { headers: { "x-staff-id": staffId ?? "" } }
            );
            const data = await res.json();
            // Filter only closed/settled bets
            const allBets: BetListItem[] = (data.list || []).filter(
                (b: BetListItem) => b.status === "closed" && b.result_status !== "pending"
            );
            setPlData(allBets);
            setPlTotal(allBets.length);
        } catch (err) { console.error("P&L Error:", err); }
        finally { setPlLoading(false); }
    };

    useEffect(() => {
        if (activeTab === "profitloss") fetchPL();
    }, [activeTab, plPage, plLimit]);

    // Calculate P&L for a single bet
    const calcBetPL = (bet: BetListItem): number => {
        const stake = parseFloat(String(bet.stake_amount || 0));
        const odds = parseFloat(String(bet.odds || 0));
        if (bet.result_status === "won") {
            if (bet.bet_type === "back" || bet.bet_type === "yes") {
                return stake * (odds - 1); // profit = stake * (odds - 1)
            } else if (bet.bet_type === "lay" || bet.bet_type === "no") {
                return stake; // lay win = stake
            }
            return stake * (odds - 1);
        } else if (bet.result_status === "loss" || bet.result_status === "lost") {
            if (bet.bet_type === "back" || bet.bet_type === "yes") {
                return -stake; // back loss = -stake
            } else if (bet.bet_type === "lay" || bet.bet_type === "no") {
                return -(stake * (odds - 1)); // lay loss = -stake * (odds-1)
            }
            return -stake;
        } else if (bet.result_status === "refund") {
            return 0;
        }
        return 0;
    };

    // Filter P&L data by search and sport
    const plFiltered = useMemo(() => {
        let filtered = plData;
        if (plSport !== "All") {
            filtered = filtered.filter((b) => b.sport_id === plSport);
        }
        if (plSearch.trim()) {
            const term = plSearch.toLowerCase();
            filtered = filtered.filter((b) =>
                String(b.user_id).includes(term) ||
                (b.match_title || "").toLowerCase().includes(term) ||
                (b.event_name || "").toLowerCase().includes(term)
            );
        }
        return filtered;
    }, [plData, plSport, plSearch]);

    // Group P&L data by date -> event -> market
    const plGrouped = useMemo(() => {
        const grouped: Record<string, Record<string, { marketName: string; pl: number; bets: BetListItem[] }[]>> = {};
        plFiltered.forEach((bet) => {
            const dateStr = bet.updated_at || bet.created_at;
            const date = dateStr ? new Date(dateStr).toLocaleDateString() : "Unknown";
            const eventName = (bet.match_title || bet.event_name || "Unknown Event").trim();
            const marketName = bet.market_type || bet.game_type || "Unknown Market";

            if (!grouped[date]) grouped[date] = {};
            if (!grouped[date][eventName]) grouped[date][eventName] = [];

            const existing = grouped[date][eventName].find((m) => m.marketName === marketName);
            const plAmount = calcBetPL(bet);

            if (existing) {
                existing.pl += plAmount;
                existing.bets.push(bet);
            } else {
                grouped[date][eventName].push({ marketName, pl: plAmount, bets: [bet] });
            }
        });
        return grouped;
    }, [plFiltered]);

    const plGrandTotal = useMemo(() => {
        let total = 0;
        Object.values(plGrouped).forEach((events) => {
            Object.values(events).forEach((markets) => {
                markets.forEach((m) => { total += m.pl; });
            });
        });
        return total;
    }, [plGrouped]);

    // ==================== NET EXPOSURE FETCHES ====================
    const fetchExposure = async (silent = false) => {
        if (!silent) setExposureLoading(true);
        try {
            const res = await fetch(`${API_BASE}/api/sportsmain/admin/net-exposure`, {
                headers: { "x-staff-id": staffId ?? "" },
            });
            const data = await res.json();
            if (data.success) {
                setExposureData(data.data || []);
                setExposureMeta(data.meta || { totalEvents: 0, totalExposure: 0 });
            }
        } catch (err) { console.error("Exposure Error:", err); }
        finally { if (!silent) setExposureLoading(false); }
    };

    useEffect(() => {
        if (activeTab === "market") fetchExposure();
    }, [activeTab]);

    // Auto-refresh exposure
    useEffect(() => {
        if (activeTab !== "market") return;
        const interval = setInterval(() => {
            setExposureTimer((prev) => {
                if (prev <= 1) { fetchExposure(true); return 10; }
                return prev - 1;
            });
        }, 1000);
        return () => clearInterval(interval);
    }, [activeTab]);

    const fetchMarketBook = async (matchId: string, marketName: string, marketType?: string) => {
        setMarketBookLoading(true);
        setMarketBookTitle(marketName);
        try {
            const params = marketType ? `?marketType=${marketType}` : "";
            const res = await fetch(`${API_BASE}/api/sportsmain/admin/net-exposure/market-book/${matchId}${params}`, {
                headers: { "x-staff-id": staffId ?? "" },
            });
            const data = await res.json();
            if (data.success) setMarketBook(data.data || []);
        } catch (err) { console.error("Market Book Error:", err); }
        finally { setMarketBookLoading(false); }
    };

    const formatExposure = (value: number) => {
        const num = Number(value) || 0;
        return num < 0 ? Math.abs(num).toFixed(2) : num.toFixed(2);
    };

    const getStandardRunners = (market: ExposureMarket) => {
        const runners = market.runners || [];
        const name = market.marketName || "";
        if (!runners.length) return runners;

        const parts = name.split(/\s+v\s+|\s+vs\s+/i);
        if (parts.length < 2) return runners;

        const home = parts[0].trim();
        const away = parts[1].trim();
        let homeRunner: string | null = null;
        let awayRunner: string | null = null;
        let drawRunner: string | null = null;

        runners.forEach((r) => {
            const lower = r.toLowerCase();
            if (lower.includes("draw") || lower === "x") { drawRunner = r; return; }
            if (!homeRunner && (r.includes(home) || home.includes(r))) { homeRunner = r; return; }
            if (!awayRunner && (r.includes(away) || away.includes(r))) { awayRunner = r; return; }
        });

        const ordered: string[] = [];
        if (homeRunner) ordered.push(homeRunner);
        if (drawRunner) ordered.push(drawRunner);
        if (awayRunner) ordered.push(awayRunner);
        return ordered.length ? ordered : runners;
    };

    // ===== BET LOCK FETCHERS =====
    const fetchLockUsers = async () => {
        try {
            const res = await fetch(`${API_BASE}/api/sportsmain/admin/betlock/users`, {
                headers: { "x-staff-id": staffId ?? "" },
            });
            const data = await res.json();
            if (Array.isArray(data)) setLockUsers(data);
        } catch (e) { console.error(e); }
    };

    const fetchLockStaff = async () => {
        try {
            const res = await fetch(`${API_BASE}/api/sportsmain/admin/betlock/staff`, {
                headers: { "x-staff-id": staffId ?? "" },
            });
            const data = await res.json();
            if (Array.isArray(data)) setLockStaff(data);
        } catch (e) { console.error(e); }
    };

    useEffect(() => {
        if (activeTab === "betlock") {
            setLockLoading(true);
            Promise.all([fetchLockUsers(), fetchLockStaff()]).finally(() => setLockLoading(false));
        }
    }, [activeTab]);

    const toggleUserLock = async (userId: number, locked: boolean) => {
        setTogglingId(userId);
        try {
            await fetch(`${API_BASE}/api/sportsmain/admin/betlock/user/toggle`, {
                method: "POST",
                headers: { "Content-Type": "application/json", "x-staff-id": staffId ?? "" },
                body: JSON.stringify({ user_id: userId, locked }),
            });
            setLockUsers(prev => prev.map(u => u.id === userId ? { ...u, sports_betlocked: locked } : u));
        } catch (e) { console.error(e); }
        finally { setTogglingId(null); }
    };

    const toggleStaffLock = async (sid: number, locked: boolean) => {
        setTogglingId(sid);
        try {
            await fetch(`${API_BASE}/api/sportsmain/admin/betlock/staff/toggle`, {
                method: "POST",
                headers: { "Content-Type": "application/json", "x-staff-id": staffId ?? "" },
                body: JSON.stringify({ staff_id: sid, locked }),
            });
            setLockStaff(prev => prev.map(s => s.id === sid ? { ...s, sports_betlocked: locked } : s));
        } catch (e) { console.error(e); }
        finally { setTogglingId(null); }
    };

    const filteredLockUsers = lockUsers.filter(u => {
        const q = lockSearch.toLowerCase();
        return String(u.id).includes(q) || u.name?.toLowerCase().includes(q) || u.email?.toLowerCase().includes(q);
    });

    const filteredLockStaff = lockStaff.filter(s => {
        const q = lockSearch.toLowerCase();
        return String(s.id).includes(q) || s.name?.toLowerCase().includes(q) || s.email?.toLowerCase().includes(q);
    });

    // ==================== SETTLED VOID FETCHES ====================
    const fetchSettledMarkets = async () => {
        setSvLoading(true);
        try {
            const params = new URLSearchParams({ limit: "100", offset: "0" });
            if (svSearch.trim()) params.append("search", svSearch.trim());
            const res = await fetch(`${API_BASE}/api/internalsettle/settled-markets?${params}`, {
                headers: { "x-staff-id": staffId ?? "" },
            });
            const data = await res.json();
            if (data.success) setSvMarkets(data.data || []);
        } catch (err) { console.error("Settled Markets Error:", err); }
        finally { setSvLoading(false); }
    };

    const fetchSettledBets = async (matchId: string, marketType: string) => {
        setSvBetsLoading(true);
        try {
            const params = new URLSearchParams({ match_id: matchId, market_type: marketType });
            const res = await fetch(`${API_BASE}/api/internalsettle/settled-bets?${params}`, {
                headers: { "x-staff-id": staffId ?? "" },
            });
            const data = await res.json();
            if (data.success) setSvBets(data.data || []);
        } catch (err) { console.error("Settled Bets Error:", err); }
        finally { setSvBetsLoading(false); }
    };

    const voidMarketAfterSettlement = async (matchId: string, marketType: string) => {
        if (!window.confirm(`Are you sure you want to void the entire market "${marketType}" for match "${matchId}"? This will reverse all settlements.`)) return;
        setSvVoidingMarket(true);
        try {
            const res = await fetch(`${API_BASE}/api/internalsettle/void-market-after-settlement`, {
                method: "POST",
                headers: { "Content-Type": "application/json", "x-staff-id": staffId ?? "" },
                body: JSON.stringify({ match_id: matchId, market_type: marketType }),
            });
            const data = await res.json();
            if (data.success) {
                alert(`Market voided successfully. ${data.processedEntries} entries reversed, ${data.affectedUsers} users affected.`);
                fetchSettledMarkets();
                setSvSelectedMarket(null);
                setSvBets([]);
            } else {
                alert(`Failed to void market: ${data.error}`);
            }
        } catch (err) { console.error("Void Market Error:", err); alert("Error voiding market"); }
        finally { setSvVoidingMarket(false); }
    };

    const voidSingleBetAfterSettlement = async (ledgerId: number) => {
        if (!window.confirm(`Are you sure you want to void bet (ledger #${ledgerId})? This will reverse the settlement for this bet.`)) return;
        setSvVoidingBetId(ledgerId);
        try {
            const res = await fetch(`${API_BASE}/api/internalsettle/void-bet-after-settlement`, {
                method: "POST",
                headers: { "Content-Type": "application/json", "x-staff-id": staffId ?? "" },
                body: JSON.stringify({ ledger_id: ledgerId }),
            });
            const data = await res.json();
            if (data.success) {
                alert(`Bet voided successfully. Bet #${data.betId} for user ${data.userId}.`);
                if (svSelectedMarket) {
                    fetchSettledBets(svSelectedMarket.matchId, svSelectedMarket.marketType);
                }
            } else {
                alert(`Failed to void bet: ${data.error}`);
            }
        } catch (err) { console.error("Void Bet Error:", err); alert("Error voiding bet"); }
        finally { setSvVoidingBetId(null); }
    };

    useEffect(() => {
        if (activeTab === "settledvoid") fetchSettledMarkets();
    }, [activeTab]);

    // Group settled markets by market type
    const svGrouped = useMemo(() => {
        const grouped: Record<string, SettledMarket[]> = {};
        svMarkets.forEach((m) => {
            const key = m.marketType || "Unknown";
            if (!grouped[key]) grouped[key] = [];
            grouped[key].push(m);
        });
        return grouped;
    }, [svMarkets]);

    // ==================== RENDER ====================
    return (
        <div className="bg-[#0C0D1D] text-[#F9F9F9] min-h-screen p-6">
            <div className="">
                <h1 className="text-3xl font-bold mb-6">Sports Analytics</h1>

                {/* TABS */}
                <div className="flex gap-1 mb-8 border-b border-[#1E2D55]">
                    {TABS.map((tab) => (
                        <button
                            key={tab.key}
                            onClick={() => setActiveTab(tab.key)}
                            className={`flex items-center gap-2 px-5 py-3 text-sm font-medium transition-all ${activeTab === tab.key
                                ? "bg-[#0E1831] text-[#F9F9F9] border-b-2 border-indigo-500"
                                : "text-[#878AA2] hover:text-[#F9F9F9] hover:bg-[#0E1831]/50"
                                }`}
                        >
                            {tab.icon} {tab.label}
                        </button>
                    ))}
                </div>

                {/* ==================== DASHBOARD TAB ==================== */}
                {activeTab === "dashboard" && (
                    <>
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                            <Card title="Total Bets" value={stats.totalBets} icon={<Activity />} />
                            <Card title="Wins" value={stats.totalWins} icon={<TrendingUp />} color="green" />
                            <Card title="Losses" value={stats.totalLosses} icon={<ArrowDownCircle />} color="red" />
                            <Card title="Pending" value={stats.totalPending} icon={<Layers />} color="yellow" />
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                            <Card title="Total Stake" value={formatCurrency(totalStake)} icon={<Wallet />} />
                            <Card title="Liability" value={formatCurrency(totalLiability)} icon={<DollarSign />} />
                        </div>

                        {/* All Bets Table */}
                        <div className="bg-[#0E1831]/60 backdrop-blur rounded-xl border border-[#1E2D55]/50 mb-8">
                            <div className="p-5 border-b border-[#1E2D55]/50 flex items-center justify-between">
                                <h2 className="text-xl font-semibold">All Bets</h2>
                                <select
                                    value={limit}
                                    onChange={(e) => { setLimit(Number(e.target.value)); setPage(1); }}
                                    className="bg-[#162140]/50 border border-[#1E2D55] px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-indigo-500"
                                >
                                    <option value={10}>10 per page</option>
                                    <option value={25}>25 per page</option>
                                    <option value={50}>50 per page</option>
                                </select>
                            </div>
                            <div className="overflow-x-auto">
                                <table className="w-full text-sm">
                                    <thead>
                                        <tr className="border-b border-[#1E2D55]/50 text-[#878AA2] text-xs uppercase tracking-wider">
                                            <th className="px-4 py-3 text-left">User ID</th>
                                            <th className="px-4 py-3 text-left">Match</th>
                                            <th className="px-4 py-3 text-left">Selection</th>
                                            <th className="px-4 py-3 text-center">Type</th>
                                            <th className="px-4 py-3 text-center">Market</th>
                                            <th className="px-4 py-3 text-center">Odds</th>
                                            <th className="px-4 py-3 text-center">Stake</th>
                                            <th className="px-4 py-3 text-center">Liability</th>
                                            <th className="px-4 py-3 text-center">Status</th>
                                            <th className="px-4 py-3 text-center">Result</th>
                                            <th className="px-4 py-3 text-center">Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {bets.length === 0 ? (
                                            <tr><td colSpan={11} className="px-4 py-8 text-center text-[#878AA2]">No bets found</td></tr>
                                        ) : (
                                            bets.map((b, idx) => (
                                                <tr key={b.id} className={`border-b border-[#1E2D55]/30 hover:bg-[#162140]/20 transition-colors ${idx % 2 === 0 ? "bg-[#0E1831]/30" : ""}`}>
                                                    <td className="px-4 py-3 font-mono text-xs">{b.user_id}</td>
                                                    <td className="px-4 py-3 max-w-[200px] truncate" title={b.match_title}>{b.match_title}</td>
                                                    <td className="px-4 py-3">{b.selection_name}</td>
                                                    <td className="px-4 py-3 text-center">
                                                        <span className={`px-2 py-1 rounded text-xs font-medium capitalize ${["back", "yes"].includes((b.bet_type || "").toLowerCase())
                                                            ? "bg-blue-400/20 text-blue-300"
                                                            : ["lay", "no"].includes((b.bet_type || "").toLowerCase())
                                                                ? "bg-pink-400/20 text-pink-300"
                                                                : "bg-[#1E2D55]/30 text-[#8384A5]"
                                                            }`}>{b.bet_type}</span>
                                                    </td>
                                                    <td className="px-4 py-3 text-center text-xs text-[#8384A5]">{b.market_type}</td>
                                                    <td className="px-4 py-3 text-center font-bold">{b.odds}</td>
                                                    <td className="px-4 py-3 text-center">{formatCurrency(b.stake_amount)}</td>
                                                    <td className="px-4 py-3 text-center">{formatCurrency(b.liability)}</td>
                                                    <td className="px-4 py-3 text-center">
                                                        <span className={`px-2 py-1 text-xs rounded ${b.status === "closed" ? "bg-[#1E2D55]/30 text-[#8384A5]" :
                                                            b.status === "open" ? "bg-[#FFC23F]/20 text-yellow-300" :
                                                                b.status === "manual" ? "bg-orange-500/20 text-orange-300" : "bg-[#1E2D55]/30 text-[#878AA2]"
                                                            }`}>{b.status}</span>
                                                    </td>
                                                    <td className="px-4 py-3 text-center">
                                                        <span className={`px-2 py-1 text-xs rounded ${b.result_status === "won" ? "bg-[#0ECC68]/20 text-green-300" :
                                                            b.result_status === "lost" || b.result_status === "loss" ? "bg-[#E01B4F]/20 text-red-300" :
                                                                b.result_status === "refund" ? "bg-[#2B6EF5]/20 text-blue-300" :
                                                                    b.result_status === "pending" ? "bg-[#FFC23F]/20 text-yellow-300" : "bg-[#1E2D55]/30 text-[#878AA2]"
                                                            }`}>{b.result_status}</span>
                                                    </td>
                                                    <td className="px-4 py-3 text-center text-xs text-[#878AA2] whitespace-nowrap">
                                                        {new Date(b.match_start_time).toLocaleString()}
                                                    </td>
                                                </tr>
                                            ))
                                        )}
                                    </tbody>
                                </table>
                            </div>
                            <div className="p-4 border-t border-[#1E2D55]/50">
                                <Pagination page={page} setPage={setPage} />
                            </div>
                        </div>

                        {/* User Lookup */}
                        <div className="bg-[#0E1831]/60 backdrop-blur p-6 rounded-xl border border-[#1E2D55]/50">
                            <h2 className="text-xl font-semibold mb-4">User Bet Lookup</h2>
                            <div className="flex gap-4 mb-6">
                                <input
                                    type="text"
                                    value={userId}
                                    onChange={(e) => setUserId(e.target.value)}
                                    onKeyDown={(e) => { if (e.key === "Enter") { setUserPage(1); fetchUserBets(1, userLimit); } }}
                                    placeholder="Enter User ID"
                                    className="bg-[#162140]/50 border border-[#1E2D55] p-3 rounded-lg flex-1 text-[#F9F9F9] placeholder-[#878AA2] focus:outline-none focus:border-indigo-500 transition-colors"
                                />
                                <button
                                    onClick={() => { setUserPage(1); fetchUserBets(1, userLimit); }}
                                    className="bg-indigo-600 hover:bg-indigo-700 px-6 py-3 rounded-lg flex items-center gap-2 font-medium transition-colors"
                                >
                                    <Search size={16} /> Search
                                </button>
                            </div>

                            {userSearched && (
                                userLoading ? (
                                    <p className="text-[#878AA2] text-center py-8">Loading...</p>
                                ) : (
                                    <>
                                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                                            <Card title="Total Bets" value={userStats.totalBets} icon={<Activity />} />
                                            <Card title="Wins" value={userStats.totalWins} icon={<TrendingUp />} color="green" />
                                            <Card title="Losses" value={userStats.totalLosses} icon={<ArrowDownCircle />} color="red" />
                                            <Card title="Pending" value={userStats.totalPending} icon={<Layers />} color="yellow" />
                                        </div>
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                                            <Card title="Total Stake" value={formatCurrency(userTotalStake)} icon={<Wallet />} />
                                            <Card title="Liability" value={formatCurrency(userTotalLiability)} icon={<DollarSign />} />
                                        </div>
                                        <DashboardBetTable bets={userBets} formatCurrency={formatCurrency} emptyMessage="No bets found for this user" />
                                        <Pagination page={userPage} setPage={setUserPage} />
                                    </>
                                )
                            )}
                        </div>
                    </>
                )}

                {/* ==================== BET TICKER TAB ==================== */}
                {activeTab === "ticker" && (
                    <div className="bg-[#0E1831]/60 backdrop-blur rounded-xl border border-[#1E2D55]/50">
                        {/* Ticker Header */}
                        <div className="p-5 border-b border-[#1E2D55]/50">
                            <div className="flex items-center justify-between mb-4">
                                <h2 className="text-xl font-semibold">Bet Ticker</h2>
                                <div className="flex items-center gap-3">
                                    <span className="bg-indigo-600/30 text-indigo-300 px-3 py-1 rounded-full text-sm font-mono">
                                        {tickerTimer}s
                                    </span>
                                    <button
                                        onClick={() => { setTickerTimer(10); fetchTicker(); }}
                                        disabled={tickerLoading}
                                        className="bg-[#162140] hover:bg-[#1E2D55] px-4 py-2 rounded-lg flex items-center gap-2 text-sm transition-colors"
                                    >
                                        <RefreshCw size={14} className={tickerLoading ? "animate-spin" : ""} />
                                        {tickerLoading ? "Refreshing..." : "Refresh"}
                                    </button>
                                </div>
                            </div>

                            {/* Filters */}
                            <div className="flex flex-wrap items-center gap-3">
                                <select
                                    value={tickerSport}
                                    onChange={(e) => setTickerSport(e.target.value)}
                                    className="bg-[#162140]/50 border border-[#1E2D55] px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-indigo-500"
                                >
                                    {SPORT_LIST.map((s) => (
                                        <option key={s.value} value={s.value}>{s.label}</option>
                                    ))}
                                </select>
                                <div className="relative flex-1 max-w-xs">
                                    <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#878AA2]" />
                                    <input
                                        type="text"
                                        value={tickerSearch}
                                        onChange={(e) => setTickerSearch(e.target.value)}
                                        placeholder="Search member, event, selection..."
                                        className="bg-[#162140]/50 border border-[#1E2D55] pl-9 pr-3 py-2 rounded-lg text-sm w-full focus:outline-none focus:border-indigo-500 placeholder-[#878AA2]"
                                    />
                                </div>
                            </div>
                        </div>

                        {/* Ticker Table */}
                        <div className="overflow-x-auto">
                            <table className="w-full text-sm">
                                <thead>
                                    <tr className="border-b border-[#1E2D55]/50 text-[#878AA2] text-xs uppercase tracking-wider">
                                        <th className="px-4 py-3 text-left">Member</th>
                                        <th className="px-4 py-3 text-left">Event Name</th>
                                        <th className="px-4 py-3 text-left">Market</th>
                                        <th className="px-4 py-3 text-left">Selection</th>
                                        <th className="px-4 py-3 text-center">Odds</th>
                                        <th className="px-4 py-3 text-center">Matched</th>
                                        <th className="px-4 py-3 text-center">Liability</th>
                                        <th className="px-4 py-3 text-center">Source</th>
                                        <th className="px-4 py-3 text-center">Last Update</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {filteredTicker.length === 0 ? (
                                        <tr><td colSpan={9} className="px-4 py-8 text-center text-[#878AA2]">No bets found</td></tr>
                                    ) : (
                                        filteredTicker.map((bet, idx) => (
                                            <tr key={bet.id} className={`border-b border-[#1E2D55]/30 hover:bg-[#162140]/20 transition-colors ${idx % 2 === 0 ? "bg-[#0E1831]/30" : ""}`}>
                                                <td className="px-4 py-3 font-medium">{bet.username || bet.user_id}</td>
                                                <td className="px-4 py-3 text-[#8384A5] max-w-[200px] truncate">{bet.description}</td>
                                                <td className="px-4 py-3">
                                                    <span className="font-semibold capitalize">{bet.bet_type || "-"}</span>
                                                </td>
                                                <td className="px-4 py-3">
                                                    <span className={`px-2 py-1 rounded text-xs font-medium ${["back", "yes"].includes((bet.bet_type || "").toLowerCase())
                                                        ? "bg-blue-400/20 text-blue-300"
                                                        : ["lay", "no"].includes((bet.bet_type || "").toLowerCase())
                                                            ? "bg-pink-400/20 text-pink-300"
                                                            : "bg-[#1E2D55]/30 text-[#8384A5]"
                                                        }`}>
                                                        {bet.selection}
                                                    </span>
                                                </td>
                                                <td className="px-4 py-3 text-center font-bold">{parseFloat(String(bet.odds || 0)).toFixed(2)}</td>
                                                <td className="px-4 py-3 text-center font-bold">{formatCurrency(bet.amount || 0)}</td>
                                                <td className="px-4 py-3 text-center text-[#0ECC68] font-bold">
                                                    {parseFloat(String(bet.liability || 0)).toFixed(2)}
                                                </td>
                                                <td className="px-4 py-3 text-center">
                                                    <span className={`px-2 py-1 rounded text-xs ${bet.source === "sport" ? "bg-emerald-500/20 text-emerald-300" : "bg-purple-500/20 text-purple-300"}`}>
                                                        {bet.source}
                                                    </span>
                                                </td>
                                                <td className="px-4 py-3 text-center text-[#878AA2] text-xs whitespace-nowrap">
                                                    {bet.created_at ? new Date(bet.created_at).toLocaleString() : "-"}
                                                </td>
                                            </tr>
                                        ))
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                )}

                {/* ==================== PROFIT & LOSS TAB ==================== */}
                {activeTab === "profitloss" && (
                    <div className="bg-[#0E1831]/60 backdrop-blur rounded-xl border border-[#1E2D55]/50">
                        {/* P&L Header */}
                        <div className="p-5 border-b border-[#1E2D55]/50">
                            <h2 className="text-xl font-semibold mb-4">P&L Report by Market</h2>

                            {/* Filters */}
                            <div className="flex flex-wrap items-end gap-3">
                                <div className="flex flex-col gap-1">
                                    <label className="text-[#878AA2] text-xs font-medium">Sport</label>
                                    <select value={plSport} onChange={(e) => setPlSport(e.target.value)}
                                        className="bg-[#162140]/50 border border-[#1E2D55] px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-indigo-500">
                                        {SPORT_LIST.map((s) => (
                                            <option key={s.value} value={s.value}>{s.label}</option>
                                        ))}
                                    </select>
                                </div>
                                <div className="flex flex-col gap-1">
                                    <label className="text-[#878AA2] text-xs font-medium">From</label>
                                    <input type="date" value={plFromDate} onChange={(e) => setPlFromDate(e.target.value)}
                                        className="bg-[#162140]/50 border border-[#1E2D55] px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-indigo-500" />
                                </div>
                                <div className="flex flex-col gap-1">
                                    <label className="text-[#878AA2] text-xs font-medium">To</label>
                                    <input type="date" value={plToDate} onChange={(e) => setPlToDate(e.target.value)}
                                        className="bg-[#162140]/50 border border-[#1E2D55] px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-indigo-500" />
                                </div>
                                <div className="flex flex-col gap-1">
                                    <label className="text-[#878AA2] text-xs font-medium">Search User</label>
                                    <input type="text" value={plSearch} onChange={(e) => setPlSearch(e.target.value)}
                                        placeholder="Username"
                                        className="bg-[#162140]/50 border border-[#1E2D55] px-3 py-2 rounded-lg text-sm focus:outline-none focus:border-indigo-500 placeholder-[#878AA2]" />
                                </div>
                                <button
                                    onClick={() => { setPlPage(1); fetchPL(); }}
                                    disabled={plLoading}
                                    className="bg-indigo-600 hover:bg-indigo-700 px-5 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-colors"
                                >
                                    <Search size={14} /> {plLoading ? "Searching..." : "Search"}
                                </button>
                            </div>
                        </div>

                        {/* P&L Content */}
                        <div className="p-5">
                            {plSelectedBets ? (
                                <>
                                    <button
                                        onClick={() => { setPlSelectedBets(null); setPlSelectedName(""); }}
                                        className="text-indigo-400 hover:text-indigo-300 flex items-center gap-2 text-sm font-medium mb-4 transition-colors"
                                    >
                                        <ArrowLeft size={14} /> Back to Report
                                    </button>
                                    <h3 className="text-lg font-semibold mb-3">Bets for {plSelectedName}</h3>
                                    <div className="overflow-x-auto">
                                        <table className="w-full text-sm">
                                            <thead>
                                                <tr className="border-b border-[#1E2D55]/50 text-[#878AA2] text-xs uppercase tracking-wider">
                                                    <th className="px-3 py-2 text-left">User ID</th>
                                                    <th className="px-3 py-2 text-left">Selection</th>
                                                    <th className="px-3 py-2 text-left">Type</th>
                                                    <th className="px-3 py-2 text-center">Odds</th>
                                                    <th className="px-3 py-2 text-center">Stake</th>
                                                    <th className="px-3 py-2 text-center">Result</th>
                                                    <th className="px-3 py-2 text-center">P&L</th>
                                                    <th className="px-3 py-2 text-center">Date</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {plSelectedBets.map((bet, idx) => {
                                                    const pl = calcBetPL(bet);
                                                    return (
                                                        <tr key={bet.id} className={`border-b border-[#1E2D55]/30 ${idx % 2 === 0 ? "bg-[#0E1831]/30" : ""}`}>
                                                            <td className="px-3 py-2">{bet.user_id}</td>
                                                            <td className="px-3 py-2">{bet.selection_name}</td>
                                                            <td className="px-3 py-2 capitalize">{bet.bet_type || "-"}</td>
                                                            <td className="px-3 py-2 text-center">{parseFloat(String(bet.odds)).toFixed(2)}</td>
                                                            <td className="px-3 py-2 text-center">{formatCurrency(bet.stake_amount)}</td>
                                                            <td className="px-3 py-2 text-center">
                                                                <span className={`px-2 py-1 rounded text-xs ${bet.result_status === "won" ? "bg-[#0ECC68]/20 text-green-300" :
                                                                    bet.result_status === "loss" || bet.result_status === "lost" ? "bg-[#E01B4F]/20 text-red-300" :
                                                                        bet.result_status === "refund" ? "bg-[#2B6EF5]/20 text-blue-300" :
                                                                            "bg-[#FFC23F]/20 text-yellow-300"
                                                                    }`}>{bet.result_status}</span>
                                                            </td>
                                                            <td className={`px-3 py-2 text-center font-bold ${pl >= 0 ? "text-[#0ECC68]" : "text-[#E01B4F]"}`}>
                                                                {pl >= 0 ? "+" : ""}{pl.toFixed(2)}
                                                            </td>
                                                            <td className="px-3 py-2 text-center text-xs text-[#878AA2] whitespace-nowrap">
                                                                {(bet.updated_at || bet.created_at) ? new Date(bet.updated_at || bet.created_at!).toLocaleString() : "-"}
                                                            </td>
                                                        </tr>
                                                    );
                                                })}
                                            </tbody>
                                        </table>
                                    </div>
                                </>
                            ) : (
                                <>
                                    <div className="overflow-x-auto">
                                        <table className="w-full text-sm">
                                            <thead>
                                                <tr className="border-b border-[#1E2D55]/50">
                                                    <th className="px-4 py-3 text-left text-[#8384A5] font-semibold">Market</th>
                                                    <th className="px-4 py-3 text-right text-[#8384A5] font-semibold">P&L</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {Object.keys(plGrouped).length === 0 ? (
                                                    <tr><td colSpan={2} className="px-4 py-8 text-center text-[#878AA2]">No data found</td></tr>
                                                ) : (
                                                    Object.entries(plGrouped).map(([date, events]) => (
                                                        <React.Fragment key={date}>
                                                            <tr>
                                                                <td colSpan={2} className="px-4 py-2 text-[#F9F9F9] font-bold bg-[#162140]/40">{date}</td>
                                                            </tr>
                                                            {Object.entries(events).map(([eventName, markets]) => (
                                                                <React.Fragment key={eventName}>
                                                                    <tr>
                                                                        <td colSpan={2} className="px-4 py-2 pl-6 text-[#8384A5] font-semibold bg-[#162140]/20">{eventName}</td>
                                                                    </tr>
                                                                    {markets.map((market, mIdx) => (
                                                                        <tr key={mIdx} className={`border-b border-[#1E2D55]/20 hover:bg-[#162140]/10 ${mIdx % 2 === 0 ? "bg-[#0E1831]/20" : ""}`}>
                                                                            <td className="px-4 py-2 pl-10 text-[#8384A5]">
                                                                                {market.marketName}
                                                                                <button
                                                                                    onClick={() => { setPlSelectedBets(market.bets); setPlSelectedName(market.marketName); }}
                                                                                    className="text-indigo-400 hover:text-indigo-300 ml-3 text-xs font-medium transition-colors"
                                                                                >
                                                                                    <Eye size={12} className="inline mr-1" /> View Bets
                                                                                </button>
                                                                            </td>
                                                                            <td className={`px-4 py-2 text-right font-bold ${market.pl >= 0 ? "text-[#0ECC68]" : "text-[#E01B4F]"}`}>
                                                                                {market.pl >= 0 ? "+" : ""}{market.pl.toFixed(2)}
                                                                            </td>
                                                                        </tr>
                                                                    ))}
                                                                    {/* Event Total */}
                                                                    <tr className="bg-[#162140]/10">
                                                                        <td className="px-4 py-2 text-right text-[#878AA2] font-medium">Subtotal</td>
                                                                        <td className={`px-4 py-2 text-right font-bold ${markets.reduce((s, m) => s + m.pl, 0) >= 0 ? "text-[#0ECC68]" : "text-[#E01B4F]"
                                                                            }`}>
                                                                            {markets.reduce((s, m) => s + m.pl, 0) >= 0 ? "+" : ""}
                                                                            {markets.reduce((s, m) => s + m.pl, 0).toFixed(2)}
                                                                        </td>
                                                                    </tr>
                                                                </React.Fragment>
                                                            ))}
                                                        </React.Fragment>
                                                    ))
                                                )}
                                                {Object.keys(plGrouped).length > 0 && (
                                                    <tr className="bg-[#162140]/30">
                                                        <td className="px-4 py-3 text-right text-[#F9F9F9] font-bold">Grand Total</td>
                                                        <td className={`px-4 py-3 text-right font-bold text-lg ${plGrandTotal >= 0 ? "text-[#0ECC68]" : "text-[#E01B4F]"}`}>
                                                            {plGrandTotal >= 0 ? "+" : ""}{plGrandTotal.toFixed(2)}
                                                        </td>
                                                    </tr>
                                                )}
                                            </tbody>
                                        </table>
                                    </div>

                                    {/* P&L Pagination */}
                                    <div className="flex items-center justify-between mt-4 pt-4 border-t border-[#1E2D55]/50">
                                        <span className="text-[#878AA2] text-sm">Total: {plTotal} records</span>
                                        <div className="flex items-center gap-3">
                                            <select value={plLimit} onChange={(e) => setPlLimit(Number(e.target.value))}
                                                className="bg-[#162140]/50 border border-[#1E2D55] px-2 py-1 rounded text-sm">
                                                <option value={25}>25</option>
                                                <option value={50}>50</option>
                                                <option value={100}>100</option>
                                            </select>
                                            <Pagination page={plPage} setPage={setPlPage} />
                                        </div>
                                    </div>
                                </>
                            )}
                        </div>
                    </div>
                )}

                {/* ==================== NET EXPOSURE TAB ==================== */}
                {activeTab === "market" && (
                    <div className="bg-[#0E1831]/60 backdrop-blur rounded-xl border border-[#1E2D55]/50">
                        {/* Exposure Header */}
                        <div className="p-5 border-b border-[#1E2D55]/50">
                            <div className="flex items-center justify-between">
                                <h2 className="text-xl font-semibold">Net Exposure</h2>
                                <div className="flex items-center gap-3">
                                    <div className="flex items-center gap-2 text-sm text-[#878AA2]">
                                        <span>Events: <strong className="text-[#F9F9F9]">{exposureMeta.totalEvents}</strong></span>
                                        <span className="text-gray-600">|</span>
                                        <span>Total Exposure: <strong className="text-[#F9F9F9]">{formatCurrency(exposureMeta.totalExposure)}</strong></span>
                                    </div>
                                    <span className="bg-indigo-600/30 text-indigo-300 px-3 py-1 rounded-full text-sm font-mono">
                                        {exposureTimer}s
                                    </span>
                                    <button
                                        onClick={() => { setExposureTimer(10); fetchExposure(); }}
                                        disabled={exposureLoading}
                                        className="bg-[#162140] hover:bg-[#1E2D55] px-4 py-2 rounded-lg flex items-center gap-2 text-sm transition-colors"
                                    >
                                        <RefreshCw size={14} className={exposureLoading ? "animate-spin" : ""} />
                                        Refresh
                                    </button>
                                </div>
                            </div>

                            {/* Column Headers */}
                            <div className="grid grid-cols-7 gap-2 mt-4 text-xs uppercase tracking-wider text-[#878AA2] font-medium px-4">
                                <div className="col-span-2">Market</div>
                                <div className="text-center">Stake</div>
                                <div className="text-center">1</div>
                                <div className="text-center">X</div>
                                <div className="text-center">2</div>
                                <div className="text-center">P/L</div>
                            </div>
                        </div>

                        {/* Market Book Detail View */}
                        {marketBook ? (
                            <div className="p-5">
                                <button
                                    onClick={() => { setMarketBook(null); setMarketBookTitle(""); }}
                                    className="text-indigo-400 hover:text-indigo-300 flex items-center gap-2 text-sm font-medium mb-4 transition-colors"
                                >
                                    <ArrowLeft size={14} /> Back to Exposure
                                </button>
                                <h3 className="text-lg font-semibold mb-3">User Book — {marketBookTitle}</h3>

                                {marketBookLoading ? (
                                    <p className="text-[#878AA2] text-center py-8">Loading...</p>
                                ) : (
                                    <div className="overflow-x-auto">
                                        <table className="w-full text-sm">
                                            <thead>
                                                <tr className="border-b border-[#1E2D55]/50 text-[#878AA2] text-xs uppercase tracking-wider">
                                                    <th className="px-4 py-3 text-left">User</th>
                                                    {marketBook.length > 0 && Object.keys(marketBook[0].runners).map((r) => (
                                                        <th key={r} className="px-4 py-3 text-center">{r}</th>
                                                    ))}
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {marketBook.map((entry, idx) => (
                                                    <tr key={entry.userId} className={`border-b border-[#1E2D55]/30 ${idx % 2 === 0 ? "bg-[#0E1831]/30" : ""}`}>
                                                        <td className="px-4 py-2 font-medium">{entry.username || entry.userId}</td>
                                                        {Object.values(entry.runners).map((val, rIdx) => (
                                                            <td key={rIdx} className={`px-4 py-2 text-center font-bold ${val >= 0 ? "text-[#0ECC68]" : "text-[#E01B4F]"}`}>
                                                                {val >= 0 ? "+" : ""}{val.toFixed(2)}
                                                            </td>
                                                        ))}
                                                    </tr>
                                                ))}
                                                {marketBook.length === 0 && (
                                                    <tr><td colSpan={10} className="px-4 py-8 text-center text-[#878AA2]">No user exposure data</td></tr>
                                                )}
                                            </tbody>
                                        </table>
                                    </div>
                                )}
                            </div>
                        ) : (
                            /* Exposure Events */
                            <div className="p-5 space-y-4">
                                {exposureLoading ? (
                                    <p className="text-[#878AA2] text-center py-8">Loading...</p>
                                ) : exposureData.length === 0 ? (
                                    <p className="text-[#878AA2] text-center py-8">No exposure data found</p>
                                ) : (
                                    exposureData.map((event) => {
                                        const isStandard = (gt: string) => {
                                            const t = (gt || "").toLowerCase();
                                            return t.includes("match_odds") || t.includes("bookmaker") || t.includes("match odds");
                                        };
                                        const standardMarkets = event.markets.filter((m) => isStandard(m.gameType));
                                        const fancyMarkets = event.markets.filter((m) => !isStandard(m.gameType));

                                        return (
                                            <React.Fragment key={event.id}>
                                                {/* Standard Markets */}
                                                {standardMarkets.length > 0 && (
                                                    <div className="bg-[#162140]/20 rounded-lg overflow-hidden border border-[#1E2D55]/30">
                                                        <div className="px-4 py-3 bg-[#162140]/30 flex items-center justify-between">
                                                            <span className="font-semibold">{event.eventName}</span>
                                                            <span className="text-[#878AA2] text-xs">
                                                                {event.eventDate ? new Date(event.eventDate).toLocaleString() : ""}
                                                            </span>
                                                        </div>
                                                        {standardMarkets.map((market) => {
                                                            const runners = getStandardRunners(market);
                                                            return (
                                                                <div key={market.id} className="grid grid-cols-7 gap-2 px-4 py-3 border-t border-[#1E2D55]/20 items-center hover:bg-[#162140]/10 transition-colors">
                                                                    <div className="col-span-2 flex items-center gap-2">
                                                                        <span className="text-sm font-medium">{market.gameType ? market.gameType.replace(/_/g, " ").toUpperCase() : market.marketName}</span>
                                                                        <button
                                                                            onClick={() => fetchMarketBook(market.matchId, market.marketName, market.gameType)}
                                                                            className="text-indigo-400 hover:text-indigo-300 transition-colors"
                                                                            title="View User Book"
                                                                        >
                                                                            <Eye size={14} />
                                                                        </button>
                                                                    </div>
                                                                    <div className="text-center text-sm font-mono">
                                                                        {runners.length > 0 ? ((market.selections[runners[0]] || 0) * -1).toFixed(2) : "0.00"}
                                                                    </div>
                                                                    {[0, 1, 2].map((i) => {
                                                                        const runner = runners[i];
                                                                        const pl = runner ? (market.selections[runner] || 0) : 0;
                                                                        return (
                                                                            <div key={i} className={`text-center text-sm font-bold ${pl < 0 ? "text-[#0ECC68]" : pl > 0 ? "text-[#E01B4F]" : "text-[#878AA2]"}`}>
                                                                                {runner ? formatExposure(pl) : "-"}
                                                                            </div>
                                                                        );
                                                                    })}
                                                                    <div className="text-center text-sm font-mono text-[#878AA2]">
                                                                        {market.pl?.toFixed(2) || "0.00"}
                                                                    </div>
                                                                </div>
                                                            );
                                                        })}
                                                    </div>
                                                )}

                                                {/* Fancy Markets */}
                                                {fancyMarkets.length > 0 && (
                                                    <div className="bg-[#162140]/20 rounded-lg overflow-hidden border border-[#1E2D55]/30">
                                                        <div className="px-4 py-3 bg-[#162140]/30 flex items-center justify-between">
                                                            <div className="flex items-center gap-3">
                                                                <span className="font-semibold">{event.eventName}</span>
                                                                <span className="bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded text-xs font-medium">Fancy</span>
                                                            </div>
                                                        </div>
                                                        {fancyMarkets.map((market) => (
                                                            <div key={market.id} className="grid grid-cols-7 gap-2 px-4 py-3 border-t border-[#1E2D55]/20 items-center hover:bg-[#162140]/10">
                                                                <div className="col-span-5 flex items-center gap-2">
                                                                    <span className="text-sm">{market.gameType || market.marketName}</span>
                                                                    <button
                                                                        onClick={() => fetchMarketBook(market.matchId, market.marketName, market.gameType)}
                                                                        className="text-indigo-400 hover:text-indigo-300 transition-colors"
                                                                    >
                                                                        <Eye size={14} />
                                                                    </button>
                                                                </div>
                                                                <div className="text-center text-sm font-mono">{market.stake?.toFixed(2) || "0.00"}</div>
                                                                <div className={`text-center text-sm font-bold ${market.pl < 0 ? "text-[#0ECC68]" : "text-[#E01B4F]"}`}>
                                                                    {formatExposure(market.pl)}
                                                                </div>
                                                            </div>
                                                        ))}
                                                    </div>
                                                )}
                                            </React.Fragment>
                                        );
                                    })
                                )}
                            </div>
                        )}
                    </div>
                )}

                {/* ==================== BET LOCK TAB ==================== */}
                {activeTab === "betlock" && (
                    <div className="space-y-6">
                        {/* Sub tabs: Users | Staff */}
                        <div className="flex gap-1 bg-[#0E1831]/60 rounded-lg p-1 border border-[#1E2D55]/50 w-fit">
                            <button
                                onClick={() => setLockSubTab("users")}
                                className={`flex items-center gap-2 px-5 py-2.5 rounded-md text-sm font-medium transition-all ${lockSubTab === "users" ? "bg-indigo-600 text-[#F9F9F9] shadow" : "text-[#878AA2] hover:text-[#F9F9F9] hover:bg-[#162140]"}`}
                            >
                                <Users size={14} /> Users ({lockUsers.length})
                            </button>
                            <button
                                onClick={() => setLockSubTab("staff")}
                                className={`flex items-center gap-2 px-5 py-2.5 rounded-md text-sm font-medium transition-all ${lockSubTab === "staff" ? "bg-indigo-600 text-[#F9F9F9] shadow" : "text-[#878AA2] hover:text-[#F9F9F9] hover:bg-[#162140]"}`}
                            >
                                <Shield size={14} /> Staff ({lockStaff.length})
                            </button>
                        </div>

                        {/* Info banner for staff */}
                        {lockSubTab === "staff" && (
                            <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-4 flex items-start gap-3">
                                <Lock size={16} className="text-amber-400 mt-0.5 flex-shrink-0" />
                                <div>
                                    <p className="text-amber-400 text-sm font-semibold">Staff Bet Lock</p>
                                    <p className="text-[#878AA2] text-xs mt-1">Locking a staff member will block all users under them and their entire downline from placing bets.</p>
                                </div>
                            </div>
                        )}

                        {/* Search + Refresh */}
                        <div className="flex gap-3 items-center">
                            <div className="relative w-full sm:w-72">
                                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#878AA2]" />
                                <input
                                    value={lockSearch}
                                    onChange={e => setLockSearch(e.target.value)}
                                    placeholder={`Search ${lockSubTab}...`}
                                    className="w-full bg-[#0E1831]/60 border border-[#1E2D55]/50 rounded-lg pl-9 pr-3 py-2.5 text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 text-[#F9F9F9] placeholder-[#878AA2]"
                                />
                            </div>
                            <button
                                onClick={() => { setLockLoading(true); Promise.all([fetchLockUsers(), fetchLockStaff()]).finally(() => setLockLoading(false)); }}
                                className="flex items-center gap-2 px-4 py-2.5 bg-[#0E1831]/60 hover:bg-[#162140] border border-[#1E2D55]/50 rounded-lg text-sm transition"
                            >
                                <RefreshCw size={14} className={lockLoading ? "animate-spin" : ""} /> Refresh
                            </button>
                        </div>

                        {/* Users Table */}
                        {lockSubTab === "users" && (
                            <div className="bg-[#0E1831]/40 rounded-xl border border-[#1E2D55]/50 overflow-hidden">
                                <div className="overflow-x-auto">
                                    <table className="w-full text-sm">
                                        <thead>
                                            <tr className="text-left text-[#878AA2] text-xs uppercase tracking-wider bg-[#0E1831]/60">
                                                <th className="px-4 py-3">ID</th>
                                                <th className="px-4 py-3">Name</th>
                                                <th className="px-4 py-3">Email</th>
                                                <th className="px-4 py-3">Staff</th>
                                                <th className="px-4 py-3">Bet Status</th>
                                                <th className="px-4 py-3">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {lockLoading ? (
                                                <tr><td colSpan={6} className="text-center py-12 text-[#878AA2]">Loading...</td></tr>
                                            ) : filteredLockUsers.length === 0 ? (
                                                <tr><td colSpan={6} className="text-center py-12 text-[#878AA2]">No users found</td></tr>
                                            ) : (
                                                filteredLockUsers.map((u: any, idx: number) => (
                                                    <tr key={u.id} className={`border-t border-[#1E2D55]/50 hover:bg-[#162140]/30 transition ${idx % 2 === 0 ? "" : "bg-[#0E1831]/20"}`}>
                                                        <td className="px-4 py-3 font-mono text-xs text-[#8384A5]">{u.id}</td>
                                                        <td className="px-4 py-3 font-medium">{u.name || "—"}</td>
                                                        <td className="px-4 py-3 text-[#878AA2] text-xs">{u.email || "—"}</td>
                                                        <td className="px-4 py-3 text-xs text-[#878AA2]">{u.staff_name || "—"}</td>
                                                        <td className="px-4 py-3">
                                                            {u.sports_betlocked ? (
                                                                <span className="flex items-center gap-1 text-xs font-semibold text-[#E01B4F]">
                                                                    <Lock size={12} /> Locked
                                                                </span>
                                                            ) : (
                                                                <span className="flex items-center gap-1 text-xs font-semibold text-emerald-400">
                                                                    <Unlock size={12} /> Allowed
                                                                </span>
                                                            )}
                                                        </td>
                                                        <td className="px-4 py-3">
                                                            <button
                                                                onClick={() => toggleUserLock(u.id, !u.sports_betlocked)}
                                                                disabled={togglingId === u.id}
                                                                className={`text-xs px-3 py-1.5 rounded-lg font-medium transition disabled:opacity-50 ${u.sports_betlocked
                                                                    ? "bg-emerald-500/15 text-emerald-400 hover:bg-emerald-500/25 border border-emerald-500/30"
                                                                    : "bg-[#E01B4F]/15 text-[#E01B4F] hover:bg-[#E01B4F]/25 border border-[#E01B4F]/30"
                                                                    }`}
                                                            >
                                                                {togglingId === u.id ? "..." : u.sports_betlocked ? "Unlock" : "Lock"}
                                                            </button>
                                                        </td>
                                                    </tr>
                                                ))
                                            )}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        )}

                        {/* Staff Table */}
                        {lockSubTab === "staff" && (
                            <div className="bg-[#0E1831]/40 rounded-xl border border-[#1E2D55]/50 overflow-hidden">
                                <div className="overflow-x-auto">
                                    <table className="w-full text-sm">
                                        <thead>
                                            <tr className="text-left text-[#878AA2] text-xs uppercase tracking-wider bg-[#0E1831]/60">
                                                <th className="px-4 py-3">ID</th>
                                                <th className="px-4 py-3">Name</th>
                                                <th className="px-4 py-3">Email</th>
                                                <th className="px-4 py-3">Parent ID</th>
                                                <th className="px-4 py-3">Bet Status</th>
                                                <th className="px-4 py-3">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {lockLoading ? (
                                                <tr><td colSpan={6} className="text-center py-12 text-[#878AA2]">Loading...</td></tr>
                                            ) : filteredLockStaff.length === 0 ? (
                                                <tr><td colSpan={6} className="text-center py-12 text-[#878AA2]">No staff found</td></tr>
                                            ) : (
                                                filteredLockStaff.map((s: any, idx: number) => (
                                                    <tr key={s.id} className={`border-t border-[#1E2D55]/50 hover:bg-[#162140]/30 transition ${idx % 2 === 0 ? "" : "bg-[#0E1831]/20"}`}>
                                                        <td className="px-4 py-3 font-mono text-xs text-[#8384A5]">{s.id}</td>
                                                        <td className="px-4 py-3 font-medium">{s.name || "—"}</td>
                                                        <td className="px-4 py-3 text-[#878AA2] text-xs">{s.email || "—"}</td>
                                                        <td className="px-4 py-3 text-xs text-[#878AA2]">{s.parent_id || "Root"}</td>
                                                        <td className="px-4 py-3">
                                                            {s.sports_betlocked ? (
                                                                <span className="flex items-center gap-1 text-xs font-semibold text-[#E01B4F]">
                                                                    <Lock size={12} /> Locked
                                                                </span>
                                                            ) : (
                                                                <span className="flex items-center gap-1 text-xs font-semibold text-emerald-400">
                                                                    <Unlock size={12} /> Allowed
                                                                </span>
                                                            )}
                                                        </td>
                                                        <td className="px-4 py-3">
                                                            <button
                                                                onClick={() => toggleStaffLock(s.id, !s.sports_betlocked)}
                                                                disabled={togglingId === s.id}
                                                                className={`text-xs px-3 py-1.5 rounded-lg font-medium transition disabled:opacity-50 ${s.sports_betlocked
                                                                    ? "bg-emerald-500/15 text-emerald-400 hover:bg-emerald-500/25 border border-emerald-500/30"
                                                                    : "bg-[#E01B4F]/15 text-[#E01B4F] hover:bg-[#E01B4F]/25 border border-[#E01B4F]/30"
                                                                    }`}
                                                            >
                                                                {togglingId === s.id ? "..." : s.sports_betlocked ? "Unlock" : "Lock"}
                                                            </button>
                                                        </td>
                                                    </tr>
                                                ))
                                            )}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        )}
                    </div>
                )}

                {/* ==================== SETTLED VOID TAB ==================== */}
                {activeTab === "settledvoid" && (
                    <div className="bg-[#0E1831]/60 backdrop-blur rounded-xl border border-[#1E2D55]/50">
                        {/* Header */}
                        <div className="p-5 border-b border-[#1E2D55]/50">
                            <div className="flex items-center justify-between mb-4">
                                <h2 className="text-xl font-semibold flex items-center gap-2">
                                    <AlertTriangle size={20} className="text-amber-400" /> Settled Void
                                </h2>
                                <button
                                    onClick={() => fetchSettledMarkets()}
                                    disabled={svLoading}
                                    className="bg-[#162140] hover:bg-[#1E2D55] px-4 py-2 rounded-lg flex items-center gap-2 text-sm transition-colors"
                                >
                                    <RefreshCw size={14} className={svLoading ? "animate-spin" : ""} />
                                    {svLoading ? "Loading..." : "Refresh"}
                                </button>
                            </div>
                            <div className="flex items-center gap-3">
                                <div className="relative flex-1 max-w-sm">
                                    <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#878AA2]" />
                                    <input
                                        type="text"
                                        value={svSearch}
                                        onChange={(e) => setSvSearch(e.target.value)}
                                        onKeyDown={(e) => { if (e.key === "Enter") fetchSettledMarkets(); }}
                                        placeholder="Search match, market type..."
                                        className="bg-[#162140]/50 border border-[#1E2D55] pl-9 pr-3 py-2 rounded-lg text-sm w-full focus:outline-none focus:border-indigo-500 placeholder-[#878AA2]"
                                    />
                                </div>
                                <button
                                    onClick={() => fetchSettledMarkets()}
                                    className="bg-indigo-600 hover:bg-indigo-700 px-4 py-2 rounded-lg text-sm font-medium transition-colors"
                                >
                                    Search
                                </button>
                            </div>
                        </div>

                        <div className="p-5">
                            {/* Bets Detail View */}
                            {svSelectedMarket ? (
                                <>
                                    <div className="flex items-center justify-between mb-4">
                                        <button
                                            onClick={() => { setSvSelectedMarket(null); setSvBets([]); }}
                                            className="text-indigo-400 hover:text-indigo-300 flex items-center gap-2 text-sm font-medium transition-colors"
                                        >
                                            <ArrowLeft size={14} /> Back to Markets
                                        </button>
                                        <button
                                            onClick={() => voidMarketAfterSettlement(svSelectedMarket.matchId, svSelectedMarket.marketType)}
                                            disabled={svVoidingMarket}
                                            className="bg-[#E01B4F] hover:bg-red-700 px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-colors disabled:opacity-50"
                                        >
                                            <XCircle size={14} /> {svVoidingMarket ? "Voiding..." : "Void Entire Market"}
                                        </button>
                                    </div>

                                    <div className="bg-[#162140]/30 rounded-lg p-4 mb-4">
                                        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                                            <div><span className="text-[#878AA2]">Match:</span> <span className="font-medium">{svSelectedMarket.matchTitle || svSelectedMarket.matchId}</span></div>
                                            <div><span className="text-[#878AA2]">Market:</span> <span className="font-medium">{svSelectedMarket.marketType}</span></div>
                                            <div><span className="text-[#878AA2]">Teams:</span> <span className="font-medium">{svSelectedMarket.teamOne} vs {svSelectedMarket.teamTwo}</span></div>
                                            <div><span className="text-[#878AA2]">Total Entries:</span> <span className="font-medium">{svSelectedMarket.totalEntries}</span></div>
                                        </div>
                                    </div>

                                    {svBetsLoading ? (
                                        <p className="text-[#878AA2] text-center py-8">Loading bets...</p>
                                    ) : svBets.length === 0 ? (
                                        <p className="text-[#878AA2] text-center py-8">No settled bets found</p>
                                    ) : (
                                        <div className="overflow-x-auto">
                                            <table className="w-full text-sm">
                                                <thead>
                                                    <tr className="border-b border-[#1E2D55]/50 text-[#878AA2] text-xs uppercase tracking-wider">
                                                        <th className="px-3 py-3 text-left">Ledger ID</th>
                                                        <th className="px-3 py-3 text-left">User</th>
                                                        <th className="px-3 py-3 text-left">Selection</th>
                                                        <th className="px-3 py-3 text-center">Type</th>
                                                        <th className="px-3 py-3 text-center">Odds</th>
                                                        <th className="px-3 py-3 text-center">Stake</th>
                                                        <th className="px-3 py-3 text-center">Net Amount</th>
                                                        <th className="px-3 py-3 text-center">Profit</th>
                                                        <th className="px-3 py-3 text-center">Loss</th>
                                                        <th className="px-3 py-3 text-center">Result</th>
                                                        <th className="px-3 py-3 text-center">Date</th>
                                                        <th className="px-3 py-3 text-center">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {svBets.map((bet, idx) => (
                                                        <tr key={bet.ledgerId} className={`border-b border-[#1E2D55]/30 hover:bg-[#162140]/20 transition-colors ${idx % 2 === 0 ? "bg-[#0E1831]/30" : ""}`}>
                                                            <td className="px-3 py-2 font-mono text-xs">{bet.ledgerId}</td>
                                                            <td className="px-3 py-2">
                                                                <div className="font-medium">{bet.username}</div>
                                                                <div className="text-xs text-[#878AA2]">ID: {bet.userId}</div>
                                                            </td>
                                                            <td className="px-3 py-2">{bet.selectionName || "-"}</td>
                                                            <td className="px-3 py-2 text-center">
                                                                <span className={`px-2 py-1 rounded text-xs font-medium capitalize ${["back", "yes"].includes((bet.betType || "").toLowerCase())
                                                                    ? "bg-blue-400/20 text-blue-300"
                                                                    : ["lay", "no"].includes((bet.betType || "").toLowerCase())
                                                                        ? "bg-pink-400/20 text-pink-300"
                                                                        : "bg-[#1E2D55]/30 text-[#8384A5]"
                                                                    }`}>{bet.betType || "-"}</span>
                                                            </td>
                                                            <td className="px-3 py-2 text-center font-bold">{bet.odds?.toFixed(2) ?? "-"}</td>
                                                            <td className="px-3 py-2 text-center">{bet.stakeAmount != null ? formatCurrency(bet.stakeAmount) : "-"}</td>
                                                            <td className={`px-3 py-2 text-center font-bold ${bet.netamount >= 0 ? "text-[#0ECC68]" : "text-[#E01B4F]"}`}>
                                                                {formatCurrency(bet.netamount)}
                                                            </td>
                                                            <td className="px-3 py-2 text-center text-[#0ECC68]">{formatCurrency(bet.profit)}</td>
                                                            <td className="px-3 py-2 text-center text-[#E01B4F]">{formatCurrency(bet.loss)}</td>
                                                            <td className="px-3 py-2 text-center">
                                                                <span className={`px-2 py-1 text-xs rounded ${bet.resultStatus === "won" ? "bg-[#0ECC68]/20 text-green-300" :
                                                                    bet.resultStatus === "lost" || bet.resultStatus === "loss" ? "bg-[#E01B4F]/20 text-red-300" :
                                                                        bet.resultStatus === "voided_after_settlement" ? "bg-purple-500/20 text-purple-300" :
                                                                            "bg-[#1E2D55]/30 text-[#878AA2]"
                                                                    }`}>{bet.resultStatus || "-"}</span>
                                                            </td>
                                                            <td className="px-3 py-2 text-center text-xs text-[#878AA2] whitespace-nowrap">
                                                                {bet.createdAt ? new Date(bet.createdAt).toLocaleString() : "-"}
                                                            </td>
                                                            <td className="px-3 py-2 text-center">
                                                                <button
                                                                    onClick={() => voidSingleBetAfterSettlement(bet.ledgerId)}
                                                                    disabled={svVoidingBetId === bet.ledgerId}
                                                                    className="bg-[#E01B4F]/15 text-[#E01B4F] hover:bg-[#E01B4F]/25 border border-[#E01B4F]/30 text-xs px-3 py-1.5 rounded-lg font-medium transition disabled:opacity-50"
                                                                >
                                                                    {svVoidingBetId === bet.ledgerId ? "Voiding..." : "Void Bet"}
                                                                </button>
                                                            </td>
                                                        </tr>
                                                    ))}
                                                </tbody>
                                            </table>
                                        </div>
                                    )}
                                </>
                            ) : (
                                /* Markets List grouped by market type */
                                <>
                                    {svLoading ? (
                                        <p className="text-[#878AA2] text-center py-8">Loading settled markets...</p>
                                    ) : Object.keys(svGrouped).length === 0 ? (
                                        <p className="text-[#878AA2] text-center py-8">No settled markets found</p>
                                    ) : (
                                        <div className="space-y-4">
                                            {Object.entries(svGrouped).map(([marketType, markets]) => (
                                                <div key={marketType} className="bg-[#162140]/20 rounded-lg overflow-hidden border border-[#1E2D55]/30">
                                                    <div className="px-4 py-3 bg-[#162140]/30 flex items-center justify-between">
                                                        <span className="font-semibold flex items-center gap-2">
                                                            {marketType}
                                                            <span className="bg-indigo-500/20 text-indigo-300 text-xs px-2 py-0.5 rounded-full">{markets.length}</span>
                                                        </span>
                                                    </div>
                                                    <div className="divide-y divide-[#1E2D55]/20">
                                                        {markets.map((market) => (
                                                            <div key={`${market.matchId}-${market.marketType}-${market.sportId}`} className="px-4 py-3 hover:bg-[#162140]/10 transition-colors">
                                                                <div className="flex items-center justify-between">
                                                                    <div className="flex-1">
                                                                        <div className="font-medium text-sm">{market.matchTitle || market.matchId}</div>
                                                                        <div className="text-xs text-[#878AA2] mt-1 flex flex-wrap gap-3">
                                                                            <span>{market.teamOne} vs {market.teamTwo}</span>
                                                                            <span>Entries: {market.totalEntries}</span>
                                                                            <span>Users: {market.totalUsers}</span>
                                                                            <span>Net: {formatCurrency(market.totalNetAmount)}</span>
                                                                            <span>{market.lastSettledAt ? new Date(market.lastSettledAt).toLocaleString() : ""}</span>
                                                                        </div>
                                                                    </div>
                                                                    <div className="flex items-center gap-2 ml-4">
                                                                        <button
                                                                            onClick={() => {
                                                                                setSvSelectedMarket(market);
                                                                                fetchSettledBets(market.matchId, market.marketType);
                                                                            }}
                                                                            className="bg-indigo-500/15 text-indigo-400 hover:bg-indigo-500/25 border border-indigo-500/30 text-xs px-3 py-1.5 rounded-lg font-medium flex items-center gap-1 transition"
                                                                        >
                                                                            <Eye size={12} /> View Bets
                                                                        </button>
                                                                        <button
                                                                            onClick={() => voidMarketAfterSettlement(market.matchId, market.marketType)}
                                                                            disabled={svVoidingMarket}
                                                                            className="bg-[#E01B4F]/15 text-[#E01B4F] hover:bg-[#E01B4F]/25 border border-[#E01B4F]/30 text-xs px-3 py-1.5 rounded-lg font-medium flex items-center gap-1 transition disabled:opacity-50"
                                                                        >
                                                                            <XCircle size={12} /> Void Market
                                                                        </button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        ))}
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                </>
                            )}
                        </div>
                    </div>
                )}

            </div>
        </div>
    );
};

// ==================== REUSABLE COMPONENTS ====================

const DashboardBetTable = ({
    bets,
    formatCurrency,
    emptyMessage = "No bets found",
}: {
    bets: Bet[];
    formatCurrency: (n: number) => string;
    emptyMessage?: string;
}) => (
    <div className="overflow-x-auto">
        <table className="w-full text-sm">
            <thead>
                <tr className="border-b border-[#1E2D55]/50 text-[#878AA2] text-xs uppercase tracking-wider">
                    <th className="px-3 py-3 text-left">Match</th>
                    <th className="px-3 py-3">Selection</th>
                    <th className="px-3 py-3">Type</th>
                    <th className="px-3 py-3">Market</th>
                    <th className="px-3 py-3">Odds</th>
                    <th className="px-3 py-3">Stake</th>
                    <th className="px-3 py-3">Liability</th>
                    <th className="px-3 py-3">Status</th>
                    <th className="px-3 py-3">Bet Status</th>
                    <th className="px-3 py-3">Date</th>
                </tr>
            </thead>
            <tbody>
                {bets.length === 0 ? (
                    <tr><td colSpan={10} className="p-8 text-center text-[#878AA2]">{emptyMessage}</td></tr>
                ) : (
                    bets.map((b, idx) => (
                        <tr key={b.id} className={`border-b border-[#1E2D55]/30 ${idx % 2 === 0 ? "bg-[#0E1831]/30" : ""}`}>
                            <td className="px-3 py-2">{b.match_title}</td>
                            <td className="px-3 py-2">{b.selection_name}</td>
                            <td className="px-3 py-2 capitalize">{b.bet_type}</td>
                            <td className="px-3 py-2">{b.market_type}</td>
                            <td className="px-3 py-2">{b.odds}</td>
                            <td className="px-3 py-2">{formatCurrency(b.stake_amount)}</td>
                            <td className="px-3 py-2">{formatCurrency(b.liability)}</td>
                            <td className="px-3 py-2">
                                <span className={`px-2 py-1 text-xs rounded ${b.status === "closed" ? "bg-[#1E2D55]/30 text-[#8384A5]" :
                                    b.status === "open" ? "bg-[#FFC23F]/20 text-yellow-300" :
                                        b.status === "manual" ? "bg-orange-500/20 text-orange-300" : "bg-[#1E2D55]/30 text-[#878AA2]"
                                    }`}>{b.status}</span>
                            </td>
                            <td className="px-3 py-2">
                                <span className={`px-2 py-1 text-xs rounded ${b.result_status === "won" ? "bg-[#0ECC68]/20 text-green-300" :
                                    b.result_status === "lost" ? "bg-[#E01B4F]/20 text-red-300" :
                                        b.result_status === "pending" ? "bg-[#FFC23F]/20 text-yellow-300" : "bg-[#1E2D55]/30 text-[#878AA2]"
                                    }`}>{b.result_status}</span>
                            </td>
                            <td className="px-3 py-2 text-xs text-[#878AA2] whitespace-nowrap">
                                {new Date(b.match_start_time).toLocaleString()}
                            </td>
                        </tr>
                    ))
                )}
            </tbody>
        </table>
    </div>
);

const Pagination = ({ page, setPage }: { page: number; setPage: React.Dispatch<React.SetStateAction<number>> }) => (
    <div className="flex items-center gap-2">
        <button onClick={() => setPage((p) => Math.max(p - 1, 1))}
            className="bg-[#162140] hover:bg-[#1E2D55] px-3 py-1.5 rounded-lg text-sm transition-colors">
            Prev
        </button>
        <span className="text-[#878AA2] text-sm px-2">Page {page}</span>
        <button onClick={() => setPage((p) => p + 1)}
            className="bg-[#162140] hover:bg-[#1E2D55] px-3 py-1.5 rounded-lg text-sm transition-colors">
            Next
        </button>
    </div>
);

const Card = ({ title, value, icon, color }: { title: string; value: any; icon: React.ReactNode; color?: string }) => {
    const colorMap: Record<string, string> = {
        green: "text-[#0ECC68]",
        red: "text-[#E01B4F]",
        yellow: "text-[#FFC23F]",
        default: "text-indigo-400",
    };
    return (
        <div className="bg-[#0E1831]/60 backdrop-blur p-5 rounded-xl border border-[#1E2D55]/50 flex justify-between items-center hover:border-[#1E2D55]/50 transition-colors">
            <div>
                <p className="text-[#878AA2] text-sm">{title}</p>
                <p className="text-xl font-bold mt-1">{value}</p>
            </div>
            <div className={colorMap[color || "default"]}>{icon}</div>
        </div>
    );
};

export default SportsDashboard;
