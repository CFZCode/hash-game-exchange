/* ─────────────────────────────────────────────────────────────────
   Access Management — single source of truth.
   Sidebar visibility, route guards, and the AccessManagementTab UI
   all derive from these tables.
   ───────────────────────────────────────────────────────────────── */

export interface PageDef {
  path: string;
  label: string;
}

export interface GroupDef {
  title: string;
  pages: PageDef[];
}

export interface AuthorityDef {
  key: string;
  label: string;
  description?: string;
}

/* ── Pages, organised by sidebar group ─────────────────────────── */
export const PAGE_GROUPS: GroupDef[] = [
  {
    title: "Main",
    pages: [
      { path: "/admin-dashboard", label: "Dashboard" },
      { path: "/users", label: "Users" },
      { path: "/reports", label: "User Reports" },
      { path: "/kyc", label: "User KYC" },
      { path: "/wallet", label: "Wallet" },
      { path: "/redeemcode", label: "Redeem Codes" },
      { path: "/turnover-report", label: "Turnover Report" },
    ],
  },
  {
    title: "Agent Panel",
    pages: [
      { path: "/admin-dashboard", label: "Dashboard" },
      { path: "/users", label: "Users" },
    ],
  },
  {
    title: "Admin",
    pages: [
      { path: "/admin-management", label: "Client Management" },
      { path: "/percentage-hierarchy", label: "Percentage Hierarchy" },
    ],
  },
  {
    title: "History",
    pages: [
      { path: "/history", label: "Bet History" },
      { path: "/account-statement", label: "Account Statement" },
    ],
  },
  {
    title: "Sports Exchange",
    pages: [
      { path: "/sports-dashboard", label: "Sports Dashboard" },
      { path: "/sportsbeting", label: "Sports Betting" },
      { path: "/MOsettle", label: "Market Settlement" },
      { path: "/Fansettle", label: "Fancy Settlement" },
      { path: "/fancyreport", label: "Fancy Report" },
      { path: "/marketwins", label: "Market Wins" },
      { path: "/fanwins", label: "Fan Wins" },
      { path: "/sports-lock", label: "Sports Lock" },
      { path: "/sports-config", label: "Sports Config" },
    ],
  },
  {
    title: "Sports Analytics",
    pages: [
      { path: "/sports-dashboard", label: "Sports Dashboard" },
      { path: "/sportsbeting", label: "Sports Betting" },
      { path: "/marketwins", label: "Market Wins" },
      { path: "/fanwins", label: "Fan Wins" },
      { path: "/sports-lock", label: "Sports Lock" },
    ],
  },
  {
    title: "Gaming",
    pages: [
      { path: "/games", label: "Games" },
      { path: "/house", label: "House Edge" },
      { path: "/win-settings", label: "Win Settings" },
      { path: "/winloss", label: "Win/Loss Toggle" },
      { path: "/club", label: "Club Membership" },
      { path: "/bonus", label: "Bonus" },
    ],
  },
  {
    title: "Transactions",
    pages: [
      { path: "/deposit", label: "Deposit" },
      { path: "/withdraw", label: "Withdraw" },
      { path: "/account-statement", label: "Account Statement" },
    ],
  },
  {
    title: "Marketing",
    pages: [
      { path: "/giftcard-admin", label: "Gift Cards" },
      { path: "/spinwheel", label: "Spin Wheel" },
      { path: "/blog", label: "Blog" },
      { path: "/banner", label: "Asset Management" },
      { path: "/seo-manager", label: "SEO Manager" },
    ],
  },
  {
    title: "Settings",
    pages: [
      { path: "/bankdetails", label: "Bank Details" },
      { path: "/payment-methods", label: "Payment Methods" },
      { path: "/siteconfig", label: "Site Config" },
      { path: "/providers-priority", label: "Providers Priority" },
      { path: "/vendor-priority", label: "Vendor Priority" },
      { path: "/type-priority", label: "Type Priority" },
      { path: "/userconfig", label: "User Config" },
      { path: "/settings", label: "General Settings" },
    ],
  },
  {
    title: "Services",
    pages: [
      { path: "/notification", label: "Notification" },
      { path: "/notification-settings", label: "Notification Settings" },
    ],
  },
];

/* ── Action-level authority toggles ────────────────────────────── */
export const AUTHORITY_GROUPS: { title: string; items: AuthorityDef[] }[] = [
  {
    title: "User Management",
    items: [
      { key: "canCreateUser",        label: "Create User" },
      { key: "canCreateAgent",       label: "Create Agent / Staff" },
      { key: "canEditUser",          label: "Edit User" },
      { key: "canDeleteUser",        label: "Delete User" },
      { key: "canChangeUserPassword",label: "Reset User Password" },
      { key: "canLockUser",          label: "Lock / Unlock User" },
      { key: "canChangeExposureLimit", label: "Change Exposure Limit" },
      { key: "canManageKYC",         label: "Manage KYC" },
    ],
  },
  {
    title: "Transactions",
    items: [
      { key: "canDepositWithdraw",   label: "Deposit / Withdraw Funds",
        description: "Move real money between this account and its downline." },
      { key: "canApproveDeposit",    label: "Approve / Reject Deposit" },
      { key: "canApproveWithdraw",   label: "Approve / Reject Withdraw" },
    ],
  },
  {
    title: "Settlement",
    items: [
      { key: "canSettleSports",      label: "Sports / Market Settlement" },
      { key: "canSettleFancy",       label: "Fancy Settlement" },
    ],
  },
  {
    title: "Marketing",
    items: [
      { key: "canCreateRedeemCode",  label: "Create Redeem Code" },
      { key: "canIssueGiftCard",     label: "Issue Gift Card" },
      { key: "canIssueBonus",        label: "Issue Bonus" },
      { key: "canSendNotification",  label: "Send Notification" },
    ],
  },
  {
    title: "Reports & Config",
    items: [
      { key: "canViewReports",       label: "View Reports" },
      { key: "canExportCSV",         label: "Export Data (CSV)" },
      { key: "canEditSiteConfig",    label: "Edit Site Config" },
      { key: "canEditSportsBetLimits", label: "Edit Sports Bet Limits",
        description: "Change the max odds allowed on match markets. Only honoured for executives of a SuperAdmin." },
      { key: "canEditPriorities",    label: "Edit Providers / Vendors / Type Priority" },
    ],
  },
  {
    title: "Access Management",
    items: [
      {
        key: "canManageStaff",
        label: "Manage Executives",
        description: "Allows this user to open Access Management and create / edit / view activity for their executives.",
      },
    ],
  },
];

/* Flat list of all authority keys — handy for default state */
export const ALL_AUTHORITY_KEYS: string[] = AUTHORITY_GROUPS.flatMap(g =>
  g.items.map(i => i.key)
);

export const ALL_GROUP_TITLES: string[] = PAGE_GROUPS.map(g => g.title);

export const ALL_PAGE_PATHS: string[] = Array.from(
  new Set(PAGE_GROUPS.flatMap(g => g.pages.map(p => p.path)))
);

/* ── Permission shape stored per staff row ─────────────────────── */
export interface StaffPermissions {
  /** group title -> visible (overrides individual page when false) */
  groups: Record<string, boolean>;
  /** route path -> visible */
  pages: Record<string, boolean>;
  /** authority key -> granted */
  authority: Record<string, boolean>;
}

export const buildEmptyPermissions = (): StaffPermissions => ({
  groups: Object.fromEntries(ALL_GROUP_TITLES.map(t => [t, false])),
  pages: Object.fromEntries(ALL_PAGE_PATHS.map(p => [p, false])),
  authority: Object.fromEntries(ALL_AUTHORITY_KEYS.map(k => [k, false])),
});

export const buildFullPermissions = (): StaffPermissions => ({
  groups: Object.fromEntries(ALL_GROUP_TITLES.map(t => [t, true])),
  pages: Object.fromEntries(ALL_PAGE_PATHS.map(p => [p, true])),
  authority: Object.fromEntries(ALL_AUTHORITY_KEYS.map(k => [k, true])),
});

/* Agent-hierarchy roles short-circuit the permission system.
   They use the legacy GROUP_ACCESS whitelist in Sidebar.tsx and have full
   `can()` authority — their scope is constrained by role level (CHILD_ROLES)
   rather than per-key permission flags. Only "Executive" runs through
   usePermissions() / lordsApi.getMyPermissions(). */
export const SUPER_ROLES = [
  "SuperAdmin",
  "MotherAdmin",
  "Admin",
  "SubAdmin",
  "Master",
  "Agent",
  "SubAgent",
] as const;

/* ── Retired authority keys ────────────────────────────────────────
   The credit-limit / G-T-settlement model is gone. Executives created
   before the change still carry these keys in their stored permissions,
   so DEPOSIT_WITHDRAW_KEYS is what callers should check: the new key,
   plus the legacy ones it replaced. That way nobody silently loses the
   ability to move money at deploy time.
   ──────────────────────────────────────────────────────────────── */
export const DEPOSIT_WITHDRAW_KEYS = [
  "canDepositWithdraw",
  "canChangeCreditLimit",  // legacy
  "canTransferCredit",     // legacy
  "canTransferCasino",     // legacy
] as const;
