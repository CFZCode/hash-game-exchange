# MyApp Admin Panel — Complete Route & API Reference

Generated from a full sweep of `src/` (App.tsx, all 130 components/hooks/services).
Everything below is what the **frontend actually calls** — paths, query params, request
bodies, and the response shapes the code consumes.

- **API base:** `https://example.com` (hardcoded in `src/utils/api.ts`, `src/services/marketingApi.ts`, and ~20 components)
- **Socket base:** `https://example.com/admin-panel` (`src/services/socketService.ts`)
- **Auth:** `Authorization: Bearer <token>` from `localStorage.token`
- **Extra headers seen:** `x-staff-id` (currentUserId — sports/deposit/withdraw/bet-history), `role-key` (bonus + redeem-code APIs), `admin_token` (legacy, SelfDeposit only)

---

## 1. HTTP clients

| Client | File | Behaviour |
|---|---|---|
| `apiFetch<T>(path, opts)` | `src/utils/api.ts` | Adds `Content-Type: application/json` + Bearer token. **401 → `localStorage.clear()` + redirect `/login`** (checks `errorData.code === 'TOKEN_EXPIRED'`). Non-OK → throws `Error(bodyText)` with `.status`. `204 → {}`, else parsed JSON. |
| `apiDownload(path, opts)` | `src/utils/api.ts` | Same auth/401 handling, returns `Blob` (PDF). Error body JSON-parsed for `.message`. |
| `mktgFetch<T>` | `src/services/marketingApi.ts` | Separate session (`mktgToken` / `mktgUser`). **401 *or* 403 → clear marketing session + redirect `/marketing/login`.** Never touches the admin `token`. |
| raw `fetch` / `axios` | ~25 components | Legacy call sites; most pass `x-staff-id` manually, some pass no auth at all. |

### localStorage keys
`token`, `userRole`, `userEmail`, `userName`, `currentUserId`, `executiveId`, `myPermissions` (cache), `mode` (House page), `adminUsers` (local demo), `mktgToken`, `mktgUser`.

---

## 2. Frontend route map (`src/App.tsx`)

### Public
| Path | Component | Notes |
|---|---|---|
| `/login` | `Login` | Email → staff login, non-email → executive login |
| `/marketing/login` | `marketing/MarketingLogin` | separate session |
| `*` | `NotFound` | catch-all, must stay last |

### Marketing panel (guarded by `MarketingLayout`, own session)
| Path | Component |
|---|---|
| `/marketing` (index) | `MarketingDashboard` |
| `/marketing/direct-users` | `MarketingCustomers channel="direct"` |
| `/marketing/agent-users` | `MarketingCustomers channel="agent"` |

### Protected (`ProtectedRoutes` → needs `localStorage.token`, inside `Layout`)
| Path | Component | Guard |
|---|---|---|
| `/` | → redirect `/admin-management` | — |
| `/admin-dashboard` | `AdminDashboard` (tabs: Direct Users / Agent System / Sports) | none |
| `/admin-management` | `AdminManagement` layout (tab bar) | none |
| `/admin-management` index + `/dashboard` | `DashboardTab` | |
| `/admin-management/setting` | `SettingsTab` | **stub** |
| `/admin-management/myaccount` | `MyAccountTab` | |
| `/admin-management/staff-portal` | `StaffPortalTab` | |
| `/admin-management/betlist` | `BetListTab` | **stub** |
| `/admin-management/betlistlive` | `BetListLiveTab` | **stub** |
| `/admin-management/casino` | `CasinoTab` | **stub** |
| `/admin-management/riskmanagement` | `RiskManagementTab` | **stub** |
| `/admin-management/import` | `ImportTab` | **stub** |
| `/admin-management/message` | `MessageTab` | **stub** |
| `/admin-management/gamecenter` | `GameCenterTab` | **stub** |
| `/admin-management/agents` | `AgentListingTab` | |
| `/admin-management/transfer` | `TransferTab` | |
| `/admin-management/access` | `AccessManagementTab` | |
| `/admin-management/marketing-users` | `MarketingUsersTab` | SuperAdmin-only (self-gated) |
| `/activity-log` | `ActivityLogTab` | none |
| `/withdraw` | `WithdrawPage` | `canApproveWithdraw` |
| `/deposit` | `DepositPage` | `canApproveDeposit` |
| `/users` | `Users` | page perm |
| `/settings` | `Settings` | **static placeholder** |
| `/account-statement` | `AccountStatement` | page perm |
| `/account-report/:subject/:id` | `agent-statement/AccountReport` | page `/admin-management`; `subject` = `staff` \| `user` |
| `/games` | `Games` | **static sample data** |
| `/win-settings` | `WinSetting` | **local state only** |
| `/house` | `House` | |
| `/wallet` | `WalletUpdate` | |
| `/history` | `History` | |
| `/seo-manager` | `SeoManager` | **static placeholder** |
| `/affiliate` | `Refrel` | |
| `/marketwins` | `MarketWins` | |
| `/MOsettle` | `matchsettlement` | `canSettleSports` |
| `/Fansettle` | `FancySettlement` | `canSettleFancy` |
| `/fancyreport` | `FancyResult` | |
| `/fanwins` | `FanwinsHistory` | |
| `/bonus` | `Bonus` | `canIssueBonus` |
| `/club` | `ClubMembership` | |
| `/banner` | `Banner` | |
| `/bankdetails` | `BankDetails` | |
| `/redeemcode` | `RedeemCode` | `canCreateRedeemCode` |
| `/sportsbeting` | `SportsBetting` | |
| `/exchangerate` | `ExchangeRate` | |
| `/notification` | `notification` | `canSendNotification` |
| `/swaphistory` | `SwapHistory` | |
| `/reports` | `Reports` | `canViewReports` |
| `/kyc` | `UserKyc` | `canManageKYC` |
| `/siteconfig` | `SiteConfig` | `canEditSiteConfig` |
| `/providers-priority` | `ProvidersPriority` | `canEditPriorities` |
| `/vendor-priority` | `VendorPriority` | `canEditPriorities` |
| `/type-priority` | `TypePriority` | `canEditPriorities` |
| `/userconfig` | `UserConfig` | |
| `/winloss` | `GameWinLossToggle` | |
| `/notification-settings` | `NotificationSettings` | **6-line stub** |
| `/percentage-hierarchy` | `PercentageHierarchyPage` | |
| `/giftcard-admin` | `AdminGiftcards` | `canIssueGiftCard` |
| `/turnover-report` | `TurnoverReport` | `canViewReports` |
| `/vaultpro` | `vaultpro` | |
| `/peer-trade` | `PeerTrade` | |
| `/sports-dashboard` | `sportsbetStats` | |
| `/sports-lock` | `sportsbetStats` (same component) | |
| `/sports-config` | `SportsConfig` | `canEditSiteConfig` |
| `/spinwheel` | `spinWheel` | |
| `/blog` | `Blog` | |

**Guard logic** (`RequirePermission` + `usePermissions`): `SUPER_ROLES` (SuperAdmin, MotherAdmin, Admin, SubAdmin, Master, Agent, SubAgent) bypass everything. Only `Executive` runs the permission check — `pages[path]` AND `authority[key]`; failure renders "Access Denied" then `<Navigate to="/admin-management">`.

---

## 3. Auth & session

| Method | Path | Body | Response |
|---|---|---|---|
| POST | `/api/staff/auth/login` | `{ email, password }` | `{ status, token, firstLogin?, hasTransactionPassword?, user: { id, executiveId?, name, email?, username?, role: { name } } }` |
| POST | `/api/staff/auth/executive/login` | `{ username, password }` | same shape; `user.kind === 'marketing'` marks a marketing account (checked in `marketingApi.marketingLogin`) |
| POST | `/api/staff/auth/first-login-password` | `{ staffId, newPassword }` | `{ transactionPassword }` — shown once on the login screen |
| POST | `/api/staff/auth/logout` | — (Bearer, `keepalive`) | fire-and-forget from `Sidebar.handleLogout` |

Role `User` is rejected client-side after login. `firstLogin: true` forces the change-password stage before any token is persisted.

---

## 4. Staff / hierarchy (`/api/staff`)

| Method | Path | Params / Body | Response used |
|---|---|---|---|
| GET | `/api/staff` | — | `StaffRow[]` — tolerated as `[]`, `{data:[]}` or `{staff:[]}`. Fields: `id, name, email, username, role, status, inr\|balance, parent_id, phone, country, wa_slug, wa_phone, percentage` |
| POST | `/api/staff` | `{ name, email, phone, country, password, role_name, initial_balance, parent_id, percentage, transactionPassword }` | created staff |
| PATCH | `/api/staff/:id` | `{ name, phone, country }` or `{ status }` | — |
| DELETE | `/api/staff/:id` | — | — |
| GET | `/api/staff/:id` | — | `{ id, name, email, role, phone, country, agent_code }` |
| PATCH | `/api/staff/password` | `{ oldPassword, newPassword }` | — |
| GET | `/api/staff/players` | — | `Node[]` `{ id, name, role:{name,level}, balance, parent_id }` |
| POST | `/api/staff/players` | `{ username, email, password, initial_balance, transactionPassword }` | `{ userId? }` |
| DELETE | `/api/staff/players/:id` | — | — |
| GET | `/api/staff/tree` | — | array or `{ data: [] }` |
| GET | `/api/staff/metrics/:id` | — | `{ staff_cnt, player_cnt, bank }` |
| GET | `/api/staff/analytics/:id` | — | `{ staffTrend: [{day,count}], playerTrend: [{day,count}] }` |
| GET | `/api/staff/rollup/:id` | — | `{ data: { own_balance, … } }` — drives the top-bar balance |
| GET | `/api/staff/rollupStaff/:id` | — | `[{ staff_id, … }]` (keyed by `staff_id` in BankingTab) |
| POST | `/api/staff/transfer` | `{ toType: 'user'\|'staff', toId, amount, direction }` | — |
| GET | `/api/staff/transfers` · `/api/staff/transfers/:uid` | `?dir=deposit\|withdraw&page&limit` | `{ status, data: TransferRow[] }` |
| GET | `/api/staff/transfers/summary` | — | `{ status, total_deposit, total_withdraw }` |
| GET | `/api/staff/:id/percent-tree` | — | `Node[] { id, name, role, percentage, parent_id, depth }` (depth 0 = me, descending) |
| GET | `/api/staff/:id/percent-chain` | — | same shape, ancestors (depth 1 = parent) |
| GET | `/api/staff/:id/whatsapp-ref` | — | `{ slug, phone, link }` |
| POST | `/api/deposit/staff-pl` | `{ staffId }` | `{ data: { profitLoss } }` |
| POST | `/api/deposit/user-pl` | `{ userId }` | `{ data: { profitLoss } }` |

```ts
TransferRow = {
  id, from_type: 'staff'|'user', from_id, to_type, to_id,
  amount: number|string, created_at,
  from_name: string|null, to_name: string|null,
  direction: 'deposit'|'withdraw'|'internal'|'collect'|'pay',
  transfer_type?: string|null      // legacy G/T rows
}
```

---

## 5. Lords module (`/lords`)

All mutating calls require `transactionPassword`.

| Method | Path | Body / Query | Response |
|---|---|---|---|
| POST | `/lords/user-setting/update-password` | `{ userId, userType:'STAFF'\|'USER', newPassword, transactionPassword }` | — |
| POST | `/lords/user-setting/status` | `{ userId, userType, status?, betStatus?, sportsLocked?, casinoLocked?, systemLocked?, transactionPassword }` | — |
| POST | `/lords/user-setting/exposure-limit` | `{ userId, userType, exposureLimit: number\|null, transactionPassword }` | — |
| POST | `/lords/quick-refill` | `{ userId, amount, note?, transactionPassword }` | — |
| POST | `/lords/funds/transfer` | `{ userId, userType, amount, direction:'deposit'\|'withdraw', note?, transactionPassword }` | `{ status, message, balance }` |
| GET | `/lords/transfer/statement` | `?page&limit` (default 1 / 25) | `{ data: TransferRow[] }` |
| GET | `/lords/net-exposure/sports` | `?userId&userType` | `{ data: EventGroup[], meta: { totalExposure } }` |
| GET | `/lords/users/all-details` | `?page&limit&search&parentId` | `{ users: Agent[], totalPages? }` |
| POST | `/lords/update-current` | `{}` | `{ data: { id, name, role, level, balance, … } }` |

```ts
Agent = {                              // /lords/users/all-details → users[]
  id, username, role, account_type: 'STAFF'|'USER',
  balance, exposure, percentage,
  status, bet_status,
  bet_locked, sports_locked, casino_locked, system_locked,
  exp_limit: number|null,
  sports_pnl, casino_pnl,              // lifetime, + = you earned
  has_downline: boolean
}

EventGroup = {                         // net-exposure
  eventId, eventName, category,
  markets: [{ gameType, teamName, exposure, userName?, userId? }]
}
```

### Access management (Executives) — `/lords/access`

| Method | Path | Body / Query | Response |
|---|---|---|---|
| GET | `/lords/access/executives` | `?page&limit&search` | `{ executives: Executive[], totalPages }` |
| POST | `/lords/access/executives` | `{ username, password, permissions, transactionPassword }` | `{ success, executiveId? }` |
| PATCH | `/lords/access/executives/:id` | `{ permissions, transactionPassword }` | — |
| PATCH | `/lords/access/executives/:id/password` | `{ newPassword, transactionPassword }` | — |
| PATCH | `/lords/access/executives/:id/lock` | `{ lock: boolean, transactionPassword }` | — |
| GET | `/lords/access/executives/:id/activity` | `?page&limit&from&to` | `{ entries: ExecutiveActivity[], totalPages }` |
| GET | `/lords/access/activity` | `?page&limit&action&status&targetType&staffId&q&from&to` | `ActivityLogResponse` |
| GET | `/lords/access/me/permissions` | — | `{ permissions: StaffPermissions, role }` |
| GET | `/lords/access/marketing-users` | `?page&limit&search` | `{ users: MarketingUser[], totalPages }` |
| POST | `/lords/access/marketing-users` | `{ username, password, transactionPassword }` | — |
| PATCH | `/lords/access/marketing-users/:id/password` | `{ newPassword, transactionPassword }` | — |
| PATCH | `/lords/access/marketing-users/:id/lock` | `{ lock, transactionPassword }` | — |

```ts
Executive = { id, username, status:'active'|'inactive'|'locked',
              parentUserId?, parentUsername?, parentRole?,
              createdAt?, lastLogin?, permissions: StaffPermissions }

MarketingUser = { id, username, status, createdAt, lastLogin: string|null }

StaffPermissions = {
  groups:    Record<string, boolean>,   // sidebar group title → visible
  pages:     Record<string, boolean>,   // route path → visible
  authority: Record<string, boolean>    // canCreateUser, canSettleSports, …
}

ActivityLogResponse = {
  status, scope?: { isSuperAdmin, staffId },
  entries: ActivityEntry[], total, page, limit, totalPages
}
ActivityEntry = { id, staffId, executiveId, actorName, actorRole, actorLevel,
                  action, targetType, targetId, targetName, details,
                  ip, country, region, city, location, userAgent,
                  status:'success'|'failed', errorMessage, createdAt }
```

Full page/authority key catalogue lives in `src/constants/permissions.ts`
(`PAGE_GROUPS`, `AUTHORITY_GROUPS`, `DEPOSIT_WITHDRAW_KEYS` incl. legacy
`canChangeCreditLimit` / `canTransferCredit` / `canTransferCasino`).

---

## 6. Admin analytics, users & risk (`/api/admin`)

| Method | Path | Response |
|---|---|---|
| GET | `/api/admin/dashboard` | `{ totalUsers, previousTotalUsers, newUsersToday, deposits, withdrawals, financials, timestamp, date }` |
| GET | `/api/admin/user-stats` | `{ totalUsers, previousTotalUsers, newUsersToday, activeUsers30d, previousActiveUsers30d, verifiedUsers, previousVerifiedUsers, topCountries:[{country,count}], registrationTrend:[{date,count}], timestamp }` |
| GET | `/api/admin/agent-users` | `{ currency?, scope?:{isSuperAdmin,staffId}, count?, users:[], staff:[] }` |
| GET | `/api/admin/user-risk/:userId` | `RiskData` (below) |
| POST | `/api/admin/user-lock` | body `{ user_id, is_locked \| sports_betlocked \| lock_targetx \| casino_locked: boolean }` → `{ success, user }` |
| GET | `/api/admin/staff-risk/:staffId` | `StaffRiskData` (below) |
| POST | `/api/admin/staff-lock` | `{ staff_id, system_locked \| sports_betlocked }` → `{ success, staff }` |
| GET | `/api/admin/balance-sheet/:userId` | `?currency&page&limit` → `BalanceSheetResponse` |
| GET | `/api/admin/users/tree` | flat `TreeUser[]` (turned into a tree client-side) |
| GET/PUT | `/api/admin/config/user/:id` | site-config booleans per user; PUT body = changed keys only |
| GET/PUT | `/api/admin/config/global` | PUT body = changed booleans + `transactionPassword` |

```ts
deposits = { total, previousTotal,
             breakdown: { crypto, fiat, upi?, payIn? },
             today: { amount, count, breakdown: { crypto:{amount,count}, fiat:{…}, upi?, payIn? } } }
withdrawals = same shape (breakdown partial)
financials  = { netBalance, previousNetBalance, todayNetBalance }

/api/admin/agent-users → users[]: { id, name, email, country, phone,
    total_deposit_inr, total_withdrawal_inr, pnl_inr,
    is_locked, sports_betlocked, staff_name, staff_email }
  staff[]: { id, name, email, country, phone, role_id, role_name, role_level,
    parent_id, parent_name, system_locked, sports_betlocked, created_at }

RiskData = {
  currency,
  user: { id, name, email, country, phone, created, updated_at, level,
          games_played, two_fa_status, parent_staff_id, staff_name,
          staff_email, is_direct, last_ip?, last_login_at? },
  locks: { is_locked, lock_targetx, sports_betlocked, casino_locked },
  financials: { total_deposit_inr, total_withdrawal_inr, net_inr,
                deposit_count, withdrawal_count },
  activity: { source, distinct_ip_count, distinct_ips: string[],
              ip_breakdown: [{ ip_address, uses, last_seen, first_seen }],
              recent_logins?: [{ id, ip_address, user_agent, created_at }],
              recent_bets: [{ id, ip_address, created_at, stake_amount,
                              original_currency, status, result_status }] },
  risk_flags: { multiple_ips, two_fa_disabled, high_withdrawal_ratio, no_activity },
  timestamp
}

StaffRiskData = {
  currency,
  staff: { id, name, email, country, phone, role_id, role_name, role_level,
           parent_id, parent_name, parent_email, percentage, first_login,
           created_at, balance_inr },
  locks: { system_locked, sports_betlocked },
  parent_chain: [{ id, name, email, role_name, depth }],
  downline: { direct_staff_count, subtree_staff_count, users_count, locked_users,
              total_deposits_inr, total_withdrawals_inr, net_inr },
  risk_flags: { first_login_pending, locked, no_downline },
  timestamp
}

BalanceSheetResponse = {
  status,
  user: { id, name, email, staff_name, live_balance },
  currency,
  summary: { total_credit, total_debit, net, ledger_balance,
             open_exposure, reconciled, event_count },
  pagination: { page, limit, total, pages },
  rows: [{ ts, type:'CREDIT'|'DEBIT', category, description, amount, balance, currency }]
}
```

---

## 7. Account statement / "hisab" (`/api/admin/agent-report`)

Subject path: `STAFF → /api/admin/agent-report/:id`, `USER → /api/admin/agent-report/user/:id`.

| Method | Path | Query | Response |
|---|---|---|---|
| GET | `<subject>/statement` | `from,to,page,limit,category(all\|money\|sports\|casino)` | `AgentStatement` |
| GET | `<subject>/bets` | `kind=sports\|casino,from,to,page,limit` | `BetPage<SportsBetRow\|CasinoTxnRow>` |
| GET | `<subject>/pdf` | `from,to` | **PDF blob** |
| GET | `/api/admin/agent-report/:staffId` | `full=1,from,to` | **PDF blob** (settlement report) |

```ts
AgentStatement = {
  status,
  subject: { type:'STAFF'|'USER', id, name, email, role, level, agent_code, parent_name },
  period:  { from, to }, category,
  balance: { live, opening, closing, movement,
             deposit_in, withdraw_out,
             given_downline, given_agents, given_players,
             collected_downline, collected_agents, collected_players,
             bank_in?, bank_out?, total_in, total_out,
             open_exposure, unexplained },
  rows: LedgerRow[], pagination: { page, limit, total, pages },
  gaming: {
    sports: { settled_bets, player_pnl, agent_pnl, placed_bets, turnover, open_bets, open_stake },
    casino: { txns, bets, staked, wins, won, player_pnl, agent_pnl },
    total:  { player_pnl, agent_pnl, headline_pnl, headline_sports,
              headline_casino, headline_for:'AGENT'|'PLAYER' }
  },
  daily:        [{ date, deposit, withdraw, sports_pnl, casino_pnl, net }],
  sports_daily: [{ date, bets, player_pnl, agent_pnl }],
  casino_daily: [{ date, bets, staked, won, player_pnl, agent_pnl }],
  players:  [{ id, name, staff_name, wallet, funded, collected, sports_pnl,
               casino_pnl, sports_bets, casino_bets, casino_staked,
               agent_pnl, player_pnl }],
  downline: [{ id, name, role, depth, balance, players, wallet, funded,
               collected, sports_pnl, casino_pnl, agent_pnl }]
}

LedgerRow = { id, ts, kind, label, party, direction:'IN'|'OUT',
              note, legacy, amount /* signed */, balance }
kind ∈ DEPOSIT_UPLINE | WITHDRAW_UPLINE | DEPOSIT_AGENT | COLLECTED_AGENT |
       DEPOSIT_PLAYER | COLLECTED_PLAYER | BANK_DEPOSIT | GATEWAY_DEPOSIT |
       BANK_WITHDRAW | GATEWAY_WITHDRAW | SPORTS | CASINO

SportsBetRow = { id, ts, user, match, selection, market, side, odds, stake, status, result }
CasinoTxnRow = { id, ts, user, action, game, round, amount }
BetPage<T>   = { status, kind, rows: T[], pagination }
```

**Sign conventions:** ledger `amount` is signed (+ in / − out); `player_pnl` + = players won; `agent_pnl` = −`player_pnl`; `headline_*` = whichever side the subject keeps.

### PDF reports (raw `fetch` → blob, Bearer only)
| Path | Query | Page |
|---|---|---|
| `/api/report/player/:userId` | `from,to` (ISO, optional) | `PlayerReportDialog` |
| `/api/report/casino/:userId` | `from,to` (ISO, IST-pinned) | `SessionReportDialog` |
| `/api/report/sports/:userId` | `from,to` | `SessionReportDialog` |

Errors come back as JSON `{ error }` even though success is a blob.

---

## 8. Wallet, users, email

| Method | Path | Body / Query | Response |
|---|---|---|---|
| GET | `/getwallet` | — | `House[]` — `{ uid, name, btc, eth, ltc, bch, usdt, trx, doge, ada, xrp, bnb, usdp, nexo, mkr, tusd, usdc, busd, nc, inr, shib, matic, bjb, sc, mvr, aed, npr, pkr, bdt }` |
| POST | `/updatebalance` | `{ uid, coin, amount, operation:'debit'\|'credit', transactionPassword }` | error body `{ error }` |
| GET | `/wallethistory/:uid` | `?coin` | `{ history: TransactionHistory[], count }` |
| POST | `/adminwalletadd` | `{ amount }` | `{ message, balance: { staff_id, inr } }` |
| GET | `/getUserData` | — | array (or `{users:[]}`) of `{ id, name, email, country, phone, total_deposit_inr, total_withdrawal_inr, is_locked, sports_betlocked }` |
| GET/PUT | `/email/settings` | PUT `{ apaynotificationemail, gmailuser, gmailapppassword? }` | GET `{ gmailuser, apaynotificationemail, hasAppPassword }` |
| POST | `/email/settings/test` | — | `{ message? }` |

```ts
TransactionHistory = { id, uid, username, coin, operation, amount,
                       previous_balance, new_balance, transaction_time, description }
```

---

## 9. Deposits & withdrawals

### Gateway deposits (`SelfDeposit`, Direct Users tab)
| Method | Path | Params / Body |
|---|---|---|
| GET | `/depositHistory/crypto/deposits` | `page,limit,status,startDate,endDate,userid` → `{ success, data: Payment[], page, total }` |
| GET | `/depositHistory/crypto/stats` | → `{ success, data: PaymentStats }` |
| GET | `/depositHistory/fiat/deposits` | same params + `currency` → `{ success, data: FiatPayment[], page, total }` |
| GET | `/depositHistory/fiat/stats` | `?startDate&endDate&currency` → `{ success, data: FiatStats }` |
| GET | `/api/deposits/admin/all-deposits` | manual deposits, merged client-side into the fiat list |
| GET | `/api/deposits/screenshot/:depositId` | image **blob** |
| PUT | `/api/deposits/admin/approve/:depositId` | `{ admin_comment }` → `{ success }` |
| PUT | `/api/deposits/admin/reject/:depositId` | `{ admin_comment }` → `{ success }` |

`PaymentStats/FiatStats = { total_transactions, total_amount, successful_amount, processing_amount, successful_transactions, processing_transactions, failed_transactions }`

### Gateway withdrawals (`SelfWithdraw`)
| Method | Path | Body |
|---|---|---|
| GET | `/getWithdrawData` | → array, sorted by `date` desc client-side |
| GET | `/getFiatWithdrawData` | → array |
| POST | `/updateWithdrawStatus` | `{ id, status }` |
| POST | `/updateFiatWithdrawStatus` | `{ id, status }` |

All four send `x-staff-id`.

### Agent-side deposit/withdraw
`Deposit.tsx` / `Withdraw.tsx` / `AccountStatement.tsx` all read
`GET /api/staff/transfers[/:uid]?dir=deposit|withdraw&page&limit` → `{ status, data: TransferRow[] }`
(Deposit additionally filters `from_type==='staff' && to_type==='user'` in memory.)

### Turnover / target-x (`TurnoverReport`)
| Method | Path | Body | Response |
|---|---|---|---|
| GET | `/api/deposits/admin/all-wagers` | — | `{ success, data: WagerRow[] }` — `{ id, name, email, wager, total_deposit, target, target_percentage, wager_multiplier?, is_locked? }` |
| POST | `/api/deposits/admin/update-all-targetx` | `{ multiplier }` | `{ success, message }` |
| POST | `/api/deposits/admin/targetx/:userId` | `{ multiplier }` | `{ success }` |
| POST | `/api/deposits/admin/targetx/:userId/lock` | `{ is_locked }` | `{ success }` |

---

## 10. Bet history (`/betHistory`)

| Method | Path | Params | Response |
|---|---|---|---|
| GET | `/betHistory/admin/analytics` | — | `{ totals:{ total, total_bets, total_wins, total_losses, total_wagered, total_payouts, total_losses_amt }, today:{ today_total, today_bets, today_wins, today_wagered }, typeBreakdown:[{transaction_type,count,total_amount}], topUsers:[{user_id,user_name,bet_count,wagered,won}] }` |
| GET | `/betHistory/transactions` | `page,limit,search` | `{ transactions: [], pagination: { totalCount, totalPages, currentPage, limit } }` |
| GET | `/betHistory/transactions/user/:userId` | `page,limit,game_type=all,search` | same |
| GET | `/betHistory/admin/bet-history` | `page,limit,type=sports` | `{ list: BetListItem[], stats }` |
| GET | `/betHistory/user/bet-history` | `page,limit,type=sports,user_id` | `{ list, stats }` |

Transaction rows are normalised client-side (`id/transaction_id`, `user_name/name`, `game_title/match_title/game`, `transaction_type` derived from `profit`, `amount`, `currency_code/currency/coin`, `transaction_timestamp/created_at/timestamp`).

---

## 11. Sports

### Sports dashboard / lock / settled-void (`sportsbetStats`, `x-staff-id` on everything)
| Method | Path | Params / Body | Response |
|---|---|---|---|
| GET | `/api/sportsmain/admin/bet-ticker` | `?sport` | `{ success, data: TickerBet[] }` |
| GET | `/api/sportsmain/admin/net-exposure` | — | `{ success, data: ExposureEvent[], meta:{ totalEvents, totalExposure } }` |
| GET | `/api/sportsmain/admin/net-exposure/market-book/:matchId` | `?marketType` | `{ success, data: MarketBookEntry[] }` |
| GET | `/api/sportsmain/admin/betlock/users` | — | plain array `[{ id, name, email, sports_betlocked }]` |
| GET | `/api/sportsmain/admin/betlock/staff` | — | plain array (same shape) |
| POST | `/api/sportsmain/admin/betlock/user/toggle` | `{ user_id, locked }` | — |
| POST | `/api/sportsmain/admin/betlock/staff/toggle` | `{ staff_id, locked }` | — |
| GET | `/api/internalsettle/settled-markets` | `?limit&offset&search` | `{ success, data: SettledMarket[] }` |
| GET | `/api/internalsettle/settled-bets` | `?match_id&market_type` | `{ success, data: SettledBet[] }` |
| POST | `/api/internalsettle/void-market-after-settlement` | `{ match_id, market_type }` | `{ success, processedEntries, affectedUsers, error? }` |
| POST | `/api/internalsettle/void-bet-after-settlement` | `{ ledger_id }` | `{ success, betId, userId, error? }` |

### Admin dashboard → Sports tab
| Method | Path | Body |
|---|---|---|
| GET | `/api/sportsmain/admin/bet-list?type=current&page=1&limit=200` | → `{ data: BetRow[] }` |
| POST | `/api/sportsmain/admin/game-report` | `{ event:'ALL', fromDate, toDate, limit, offset }` → `{ data: ReportRow[] }` |

```ts
BetRow    = { id, user_id, username, created_at, description, selection,
              game_type, bet_type, odds, amount, liability, status, result_status }
ReportRow = { bet_id, user_id, username, event, game_type, market, selection,
              match_title, bet_type, stake, odds, ledger_amount, profit, loss,
              netamount, commission, closing, settled_at }
TickerBet = { id, user_id, username, created_at, description, selection,
              game_type, bet_type, odds, amount, liability, status, source }
BetListItem = { id, user_id, game_type, match_title, selection_name, bet_type,
                market_type, odds, stake_amount, liability, status, result_status,
                sport_id, event_name, updated_at, created_at, fancy_name }
ExposureEvent = { id, …, category, markets: [{ id, …, selections: Record<string,number>,
                  runners: string[], stake, pl }] }
MarketBookEntry = { …, username, runners: Record<string, number> }
```

### Internal settlement (`/MOsettle` → `matchsettlement`, `/Fansettle` → `FancySettlement`)
| Method | Path | Params / Body |
|---|---|---|
| GET | `/api/internalsettle/momatches` | `?limit=100&offset=0` → `{ success, data: [] }` (rows carry `gameType:'MO'\|'BM'`, `matchId`, `eventId`, `marketType`, `totalBets`, `matchTitle`, `teamOne/teamTwo`) — **polled every 2 s** |
| GET | `/api/internalsettle/fanmatches` | `?limit&offset` → `{ success, data: Record<tabKey, rows[]> }` (grouped by market type) |
| GET | `/api/internalsettle/open-bets` | `?match_id&market_type&game_type` → `{ success, data: [] }` |
| POST | `/api/internalsettle/void-single-bet` | `{ bet_id }` → `{ success, error? }` |
| POST | `/api/internalsettle/declareresult` | `{ eventid, match_id, match_title, game_type, market_type, winnerName }`; fancy variants add `fancyName` and use `winnerId` for run-line markets |
| POST | `/api/internalsettle/void` | `{ eventid, match_id, market_type, gametype/game_type }` (+ `selection_name` for fancy markets) |

### Sports betting list (`/sportsbeting`)
| Method | Path | Params / Body | Response |
|---|---|---|---|
| GET | `/sportsbetting/admin/bets` | `page,limit,status,gameResult,startDate,endDate,search,currency` | `{ success, bets: SportsBet[], pagination:{ total, totalPages, page, limit }, error? }` |
| DELETE | `/sportsbetting/admin/bets/:id` | — | `{ success, error? }` |
| PUT | `/sportsbetting/admin/bets/:id/status` | `{ status, resultDeclaredTime }` | `{ success, error? }` |

### Wins / unsettled history
| Method | Path | Params | Response |
|---|---|---|---|
| GET | `/sportsbetting/marketwins` | `page,limit,search,userId` | `{ data\|transactions: MarketWin[], pagination }` — `MarketWin = { id, totalbets, matchid, eventid, team1ex, team2ex, drawex, winteam, matchname, payout, user_id, created_at }` |
| GET | `/sportsbetting/fanwins` | `page,limit,search,userId` | `{ data: FanWin[], pagination }` — `FanWin = { id, userid, fancyname, selection, runsodds, payout, eventid, matchid, created_at }` |
| GET | `/sportsbetting/fancynotsettle` | `page,limit,search` | `{ results: FancyResult[], pagination:{ total, totalPages, page, limit } }` — `FancyResult = { id, fancyname, eventid, matchid, lastfetchdate }` |

`pagination` on these pages is `{ totalCount, totalPages, currentPage, limit }`.

### Sports config (`/sports-config`, also embedded in Site Config)
| Method | Path | Body | Response |
|---|---|---|---|
| GET | `/sports/sports` | — | `{ data: SportConfig[] }` (`{ id, game_name, enabled, … }`) |
| PUT | `/sports/sports/:id` | `{ enabled }` | `{ success }` |

---

## 12. Casino / GIS catalogue

| Method | Path | Body / Query | Response |
|---|---|---|---|
| GET | `/api/gis/livecasino` · `popularslots` · `crashgames` · `hotgames` · `indiangames` | `?page=1&limit=5000` | `{ success, data: Game[], pagination:{ currentPage, totalPages, totalItems, itemsPerPage } }` |
| POST | `/api/gis/admin/gis/<same category>` | `{ uuids: string[] }` (ordered) | — |
| GET | `/api/gis/admin/gis/games/search` | `?q&limit=50` | `{ data: Game[] }` |
| PUT | `/api/gis/admin/gis/games/:uuid/image` | `{ image }` | — |
| GET | `/api/gis/admin/gis/vendors` | — | `{ success, data: [{ vendor, total, has_priority, priority_updated_at }] }` |
| GET/POST | `/api/gis/admin/gis/priority/:vendor` | POST `{ uuids }` | GET `{ success, vendor, updated_at, data: GisGame[] }` |
| GET | `/api/gis/admin/gis/vendor-search` | `?vendor&q&limit=50` | `{ success, data: GisGame[] }` |
| GET | `/api/gis/admin/gis/types` | — | `{ success, data: [{ type, total, has_priority, priority_updated_at }] }` |
| GET/POST | `/api/gis/admin/gis/type-priority/:type` | POST `{ uuids }` | GET `{ success, type, updated_at, data: GisGame[] }` |
| GET | `/api/gis/admin/gis/type-search` | `?type&q&limit=50` | `{ success, data: GisGame[] }` |
| GET/PUT | `/api/gis/admin/providers` | PUT `{ updates:[{name,enabled}], transactionPassword }` | `{ data: Provider[] }` |
| GET | `/api/gis/sync/providersnew` | — | `{ added, removed, providers_count }` |

`Game/GisGame = { uuid, name, provider?, image?, type?, is_mobile?, has_freespins? }`

---

## 13. Site & user configuration

| Method | Path | Body | Response |
|---|---|---|---|
| GET | `/api/admin/config/global` | — | `Record<string, any>` — booleans listed in `src/constants/booleanKeys.ts` (`casino, wheelspin, welcomepack, provablyfair, vipclub, bonus, affiliate, giftcards, sports, home_livesports, home_heroSection, home_welcomebanner, home_latestwins, home_livecasino, home_gamingcards, home_popularslots, home_bonus500banner, home_crashgames, home_paymentbanner, home_leaderboard, home_promocards`) |
| PUT | `/api/admin/config/global` | changed keys + `transactionPassword` | updated config |
| GET | `/api/admin/users/tree` | — | flat user list → tree client-side |
| GET/PUT | `/api/admin/config/user/:id` | PUT = changed boolean keys | updated config |
| GET/PUT | `/admin/users/game-toggles` | PUT `{ action:'blacklist-all'\|'whitelist-all'\|'disable-all' }` | GET `ToggleRow[] { uid, name, blacklist, whitelist }` |
| PUT | `/admin/user/:uid/game-toggle` | `{ blacklist, whitelist }` | — |

---

## 14. House edge (`/house`)

| Method | Path | Body | Response |
|---|---|---|---|
| GET | `/gethouse` | — | `House[] { uid, name, max, current }` — polled every 3 s in automatic mode |
| POST | `/updatehouse` | `{ uid, max, current }` | — |
| GET | `/start-house` · `/stop-house` | — | mode switch (automatic / manual) |
| GET | `/reset-house` | — | then `window.location.reload()` |
| GET | `/win-house` | — | then reload |

---

## 15. Marketing, bonuses & promos

| Feature | Method | Path | Body / Query | Response |
|---|---|---|---|---|
| Gift cards | GET | `/giftcard/admin/list` | — | `GiftCard[]` |
| | GET | `/giftcard/admin/analytics` | — | `{ stats: { total_cards, total_activations, total_claimed, total_activated, total_claimed_amount }, cards: [{ id, unique_key, amount, created_at, activations, claims }] }` |
| | GET | `/giftcard/admin/records` | `page,limit=25,status,search` | `{ total, data: Record[] }` |
| | POST | `/giftcard/admin/create` | `{ uniqueKey, description, periodDays, endDate, depositStatus, depositAmount, wagerStatus, wagerTimes, allUserStatus, amount }` | — |
| | DELETE | `/giftcard/admin/delete/:id` | — | — |
| Spin wheel | GET/PUT | `/api/spinwin/admin/config` | PUT `{ min_deposit, claim_cooldown_days, is_active, unlimited_spin }` | `{ success, data: Config }` |
| | GET | `/api/spinwin/admin/slices` | — | `{ success, data: Slice[] }` (`{ id?, label, reward_pct, color, sort_order, is_bad_luck, weight }`) |
| | PUT | `/api/spinwin/admin/slices-bulk` | `{ slices: Slice[] }` | — |
| | GET | `/api/spinwin/admin/claims` | `?page&limit=15` | `{ success, data: Claim[], total }` (`{ id, user_id, username, deposit_amount, reward_amount, slice_label, redeem_code, claimed_at }`) |
| Bonus | GET | `/bonus/admin/userbonus` · `/bonus/admin/bonusgame` | header `role-key` | `BonusData[]` |
| | PUT | `/bonus/userbonus` | `{ userid, name, vipbonus, specialbonus, generalbonus, joiningbonus }` | — |
| | PUT | `/bonus/bonusgame` | `{ userid, role:'admin', target_userid, dailybonus, weeklybonus, monthlybonus, depositbonus, rakebackbonus, luckyspin, rollcompetitionbonus }` | — |
| Redeem codes | GET | `/bonus/users` | header `role-key` | `[{ id, name }]` |
| | GET | `/bonus/redeem-bonus` | | `[{ userid, code, amount, status, createdat, updatedat }]` |
| | POST | `/bonus/redeem-bonus/create` | `{ userid, amount }` | — |
| Affiliate | GET | `/affiliateAdmin/dashboard-stats` | | `{ success, data: DashboardStats }` |
| | GET | `/affiliateAdmin/top-affiliates?limit=10` | | `{ success, data: [] }` |
| | GET/PUT | `/affiliateAdmin/settings` | PUT = `{ affiliatebonus, comissionpercent, registerbonus }` | `{ success, data }` |
| | GET | `/affiliateAdmin/teams` | | `{ success, data: Team[] }` |
| | GET | `/affiliateAdmin/rewards-list` | `?page&limit=30` | `{ success, data: RewardRecord[], pagination:{ totalPages } }` |
| Blog | GET | `/api/getblog/all` | | `{ blogs: Blog[] }` |
| | POST | `/api/blogs/createBlog` · `/api/blogs/updateBlog` | **multipart**: `title, subheading, description, author, category, date, image`, plus `id` on update | — |
| | POST | `/api/blogs/deleteBlogById?id=` | `{}` | — |
| Banners | GET | `/api/banners/getAllImagesBinary` | | `{ status:'success', images: [{ id, type, filename, base64 }] }` |
| | POST | `/api/banners/updateBanner` | multipart `{ type, image }` | — |
| Club membership | GET | `/clubmembership/clubs/fetch` | | `{ data: Club[] }` |
| | GET | `/clubmembership/:clubId/hierarchy` | | `{ hierarchy: Member[] }` |
| | PUT | `/clubmembership/update` | multipart (incl. `profilePicture`) | — |
| | PUT | `/clubmembership/earnings-config` | `{ owner/agent/member earnings %, thresholds }` | — |
| | DELETE | `/clubmembership/:clubId/delete` | | — |
| | POST | `/clubmembership/join` | `{ … }` (by clubId or code) | — |
| | POST | `/clubmembership/change-role` | `{ userId, clubId, newRole }` | — |
| Notifications | GET | `/firebase/allToken` | | `{ success, tokens: [{ id, name, email, platform, user_id, last_used }] }` |
| | POST | `/firebase/send-bulk` · `/firebase/send-to-user` | `{ userId?, title, body, type:'info'\|'success'\|'warning'\|'error', data:{ extraInfo } }` | ok/!ok |

---

## 16. Reports, KYC, rates, swaps, bank details

| Method | Path | Params | Response |
|---|---|---|---|
| GET | `/reports/users` | `page,limit=15,search` | `{ users: User[], pagination:{ pages, current, total } }` — `User = { id, name, avatar?, wager, games_played, vipDetails?, level?, referalcode? }` |
| GET | `/reports/user/:userId` | — | `{ user?, vipDetails?, wager, credits? }` |
| GET | `/reports/export` | `?search` | CSV blob |
| GET | `/kyc/admin/applications` | — | `KycApplication[]` `{ id, userId, firstName, lastName, gender, dob, address, city, country, documentType, idFrontPath?, idBackPath?, passportPath?, status:'Pending'\|'Verified'\|'Rejected', rejectionReason?, createdAt }` — polled every 2 min |
| PUT | `/kyc/update-status` | `{ userId, status, rejectionReason? }` | — |
| GET | `/exchangeRate/rates` | — | `{ success, data: [{ currency, usd_rate, last_updated }] }` |
| PUT | `/exchangeRate/rates/:currency` | `{ usd_rate }` | `{ success }` |
| GET | `/internalswap/history` | — | `{ success, data: SwapHistoryItem[] }` — `{ id, uid, from_currency, to_currency, from_amount, to_amount, fee_percentage, fee_amount, fee_currency, usd_rate_from, usd_rate_to, created_at, user_name }` |
| GET | `/bankdetails/:coin` | header `x-staff-id` | `Detail[] { id, bank_name, account_number, ifsc_code, account_holder_name, upi_id, qr_image }` |
| POST/PUT | `/bankdetails/:coin[/:id]` | multipart form | — |
| DELETE | `/bankdetails/:coin/:id` | — | — |

---

## 17. Vault Pro (`/vaultpro`)

| Method | Path | Body | Response |
|---|---|---|---|
| GET | `/vault/admin/vault/stats` | — | `{ totalUsers, totalBalance, todayInterest }` |
| GET | `/vault/admin/vault/users` | — | `VaultUser[] { id, userid, coin, vaultBalance, name, interest_rate, lock_period, startTime, endTime, status, locked, remaining:{days,hours,minutes,seconds}\|null, createdAt, updatedAt }` |
| GET | `/vault/admin/vault/interest-history` | — | `InterestRecord[] { userid, coin, principal, interest, rate, deposit_id, createdAt, name }` |
| GET | `/vault/lock-options` | — | `LockOption[] { value, label, days, rate }` |
| POST | `/vault/admin/update-interest` | `{ lock_period, rate }` | — |
| POST | `/vault/admin/add-lock-period` | `{ lock_period, label, days, rate }` | — |
| POST | `/vault/admin/delete-lock-period` | `{ lock_period }` | fails if active deposits exist |

---

## 18. P2P trading (`/peer-trade`)

| Method | Path | Body |
|---|---|---|
| GET | `/trade/admin/p2p/payment-types` · `payment-accounts` · `offers` · `orders` · `sell-orders` · `disputes` | — (plain arrays) |
| POST | `/trade/admin/p2p/payment-type` | `{ name, code }` |
| POST | `/trade/admin/p2p/payment-account` | **multipart** `{ payment_type_id, account_name, account_number, ifsc_code, upi_id, extra_details, qr_image }` |
| POST | `/trade/admin/p2p/create-offer` | `{ username, coin, fiat, price, min_limit, max_limit, available_amount, payment_account_ids[], payment_time, is_featured, is_verified, is_kyc_verified, segment:'BUY'\|'SELL' }` |
| POST | `/trade/admin/p2p/release/:orderId` · `cancel/:orderId` | — |
| DELETE | `/trade/admin/p2p/order/:orderId` | — |
| PUT | `/trade/admin/p2p/order/:id/status` | `{ status }` |
| POST | `/trade/admin/p2p/sell-cancel/:id` | — |
| POST | `/trade/admin/p2p/sell-release/:id` | **multipart** `{ admin_payment_proof, admin_note }` |
| PUT | `/trade/admin/p2p/dispute/:id/status` | `{ status, admin_note }` |

Uploaded media is served from `https://example.com/uploads/<filename>` (QR images, payment proofs, dispute screenshots).

---

## 19. Marketing panel API (`/marketing`, `mktgToken`)

| Method | Path | Query | Response |
|---|---|---|---|
| POST | `/api/staff/auth/executive/login` | `{ username, password }` | must return `user.kind === 'marketing'` |
| GET | `/marketing/me` | — | `{ user: { id, username } }` |
| GET | `/marketing/analytics/signups` | `from,to` | `{ total, byChannel:{online,agent}, series:[{date,online,agent}], estimatedUsers, estimatedOn }` |
| GET | `/marketing/analytics/deposits` | `from,to` | `{ totals:{volume,count,average}, byChannel:{ online: ChannelDeposits, agent: ChannelDeposits }, series:[{date,online,agent,onlineCount,agentCount}] }` |
| GET | `/marketing/analytics/retention` | `from,to` | `{ series:[{date,activeDepositors}], byChannel:{ online:{depositors,repeatDepositors,repeatRate}, agent:{…} } }` |
| GET | `/marketing/analytics/top-agents` | `from,to,limit=10` | `{ agents:[{ agentId, agentName, agentCode, role, customers, depositVolume, depositCount }] }` |
| GET | `/marketing/customers` | `channel,depositors,newOnly,from,to,search,sort(recent\|deposits\|name),page,limit` | `{ customers: Customer[], total, page, limit, totalPages }` |

```ts
ChannelDeposits = { volume, count, average, depositors, cohortSize, converted, conversionRate }
Customer = { id, name, email, phone, country, status, channel:'online'|'agent',
             createdAt, createdEstimated, lastLoginAt, lastIp,
             referralCode, referredBy,
             agent: { id, name, code, role } | null,
             depositCount, depositVolume, lastDepositAt }
```

---

## 20. Socket.IO — namespace `/admin-panel`

```ts
io('https://example.com/admin-panel', {
  auth: { token: `Bearer ${token}` },
  reconnectionAttempts: 5,
  transports: ['websocket', 'polling'],
})
```
Lifecycle events logged: `connect`, `disconnect`, `connect_error`.

### Client → server (emit)
| Event | Payload | Purpose |
|---|---|---|
| `getAdminProfile` | — | request profile push |
| `getUsersAllDetails` | `{ page?, limit?, search?, parentId? }` | subscribe to live agent listing |
| `stopUsersAllDetails` | — | unsubscribe |
| `getExecutiveList` | `{ page?, limit?, search? }` | subscribe to executive list |
| `stopExecutiveList` | — | unsubscribe |
| `getExecutiveActivity` | `{ executiveId, page?, limit? }` | subscribe to one executive's activity |
| `stopExecutiveActivity` | — | unsubscribe |
| `getMyPermissions` | — | subscribe to own effective permissions |

### Server → client (listen)
| Event | Payload |
|---|---|
| `adminProfileUpdate` | admin profile object |
| `usersAllDetailsUpdate` | `{ users: Agent[], … }` — same shape as `GET /lords/users/all-details` |
| `executiveListUpdate` | `{ executives: Executive[], totalPages? }` |
| `executiveActivityUpdate` | `{ entries: ExecutiveActivity[], totalPages? }` |
| `myPermissionsUpdate` | `{ permissions: StaffPermissions, role }` |

### Mutations with ack callbacks
| Event | Payload | Ack |
|---|---|---|
| `updateExecutivePermissions` | `{ executiveId, permissions, transactionPassword }` | `{ success, message? }` |
| `lockExecutive` | `{ executiveId, lock, transactionPassword }` | `{ success, message? }` |
| `resetExecutivePassword` | `{ executiveId, newPassword, transactionPassword }` | `{ success, message? }` |
| `createExecutive` | `{ username, password, permissions, transactionPassword }` | `{ success, message?, executiveId? }` |

```ts
ExecutiveActivity = { id, executiveId, action /* "transfer.credit", "user.password.reset" */,
                      targetType?, targetId?, details?, ip?, userAgent?, createdAt }
```

**Who connects:** `AgentListingTab` (users list), `AccessManagementTab` (executive list + per-executive activity), `usePermissions` (own permissions, non-super roles only). The REST endpoint is always called first as a fallback, then the socket keeps it live.

---

## 21. Polling intervals

| Page | Endpoint | Interval |
|---|---|---|
| `matchsettlement` / `FancySettlement` | `momatches` / `fanmatches` | **2 s** |
| `House` (automatic mode) | `/gethouse` | 3 s |
| `NetExposureTab` | `/lords/net-exposure/sports` | 10 s |
| `sportsbetStats` ticker + exposure tabs | `bet-ticker`, `net-exposure` | 10 s |
| Admin dashboard → Sports | `bet-list` + `game-report` | 60 s |
| `UserKyc` | `/kyc/admin/applications` | 120 s |
| `DashboardTab`, dashboard `DirectUsersTab`, `AgentSystemTab` | dashboard bundles | 300 s |

---

## 22. Gaps & inconsistencies worth knowing

- **Stub pages with no API:** `SettingsTab`, `BetListTab`, `BetListLiveTab`, `CasinoTab`, `RiskManagementTab`, `ImportTab`, `MessageTab`, `GameCenterTab` (13-line placeholders), `Settings`, `SeoManager`, `NotificationSettings`, `WinSetting` (local state only), `Games` (hardcoded `sampleData`).
- **Unrouted components that still hold live API code:** `admin-management/BankingTab` (`/api/staff/transfer`, `/api/deposit/*-pl`), `admin-management/NetExposureTab`, `admin-management/UserManagementTab` (imported only for its `ROLE_HIERARCHY` export), `admin-management/Reports`, `MOsettle.tsx` (`/sportsbetting/momatches`, `calculate-payouts`, `manual-settlement`), `FanmanualSettle.tsx` (imported in `App.tsx` but no route — `/sportsbetting/fanpayouts`, `fancyrefundsettle`, `fancymanualsettle`), `UserManagementTab.backup.tsx`, `vaultpro.tsx.checkpoint`, root-level `FancyResult.tsx`.
- **Two components share `/sports-dashboard` and `/sports-lock`** — both render `sportsbetStats`, which picks the tab internally.
- **Auth inconsistency:** `/sports/sports`, `/exchangeRate/*`, `/internalswap/history`, `/gethouse` & friends, `/firebase/*`, `/api/deposits/screenshot/:id`, `/depositHistory/fiat/deposits` are called with **no Authorization header**. `SelfDeposit` still reads a stale `localStorage.admin_token` for approve/reject.
- **Hardcoded secret:** `ROLE_KEY` (`role-key` header) is embedded in `Bonus.tsx` and `RedeemCode.tsx`.
- **Response-shape drift:** `/api/staff` may return an array, `{data}`, or `{staff}`; `/sportsbetting/marketwins` returns `data` or `transactions`; `betlock/*` return bare arrays while every other sports endpoint wraps in `{success, data}`.
- `/api/staff/players/:id` (DELETE) is used for players while staff use `/api/staff/:id`.
