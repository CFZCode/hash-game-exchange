# MSSPORTS — Sports betting backend (from TENEXCH)

Sports only, backend only. Exported 2026-10-12 from the live TENEXCH server.
It covers live odds and events, place bet, exposure, current bets, results, settlement, manual settle and the account statement.

## Files

```
mssports/
├── api/                            ← ALL SPORTS APIs ARE HERE (3 files, every route listed at the top)
│   ├── oddsEvents.api.js           group 1: odds, events, score, bet settings     (18 routes)
│   ├── bets.api.js                 group 2: place bet, current bets, exposure,    (10 routes)
│   │                                        + Socket.IO balance push
│   └── settlementStatement.api.js  group 3: manual settle, account statement,     (41 routes)
│                                            admin sports config
├── core/sports-core.js             all business logic (controllers, services, models, helpers) in one file
├── workers/                        each worker is its own process / file
│   ├── odds.worker.js              odds cron      (tenexch pm2: tenexch-odd-cron)
│   ├── events.worker.js            event cron     (tenexch pm2: tenexch-event-cron)
│   ├── results.worker.js           results job    (tenexch pm2: undefined-sports-results-cron, newjobv2.js)
│   └── settlement.worker.js        settlement v2  (tenexch pm2: undefined-sports-settlement-worker, settlementv2.js)
├── example-server.js               how to mount the 3 API files + socket (works as-is)
├── ecosystem.config.cjs            pm2: API + 4 workers
├── package.json / .env.example     dependencies / every env key (names only)
├── CLAUDE.md                       instructions for Claude in the new project
├── PENDING_WORK.md                 known bugs + pending work (read before going live)
└── docs/FLOW.md                    how it all works: odds → bet → exposure → settlement → statement
```

`core/` and `workers/` are bundles made with esbuild from the tenexch source. Nothing was rewritten by hand.
Every module inside starts with a comment holding its original tenexch path (e.g. `// sportsbet/betBuffer.js`),
so you can search for it.

## Run

```bash
npm install
cp .env.example .env              # fill in values
npm start                         # API on PORT (example-server.js)
pm2 start ecosystem.config.cjs    # API + 4 workers
```

To use it in your own service:

```js
import { mountOddsEventsApi } from './api/oddsEvents.api.js';
import { mountBetsApi, setupBetsSocket } from './api/bets.api.js';
import { mountSettlementStatementApi } from './api/settlementStatement.api.js';
mountOddsEventsApi(app); mountBetsApi(app); mountSettlementStatementApi(app);
setupBetsSocket(io);   // Socket.IO server
```

Importing the API files (through `core/sports-core.js`) defines the Sequelize models and starts the
bet-limit cleanup cron (every minute), the same as the tenexch server did.

## What is included, and what is not

**Included:** only what tenexch runs today.
- The APIs that the live web frontend or admin panel calls (69 routes).
- The 4 sports workers.
- Every file those need.

**Not included:**
- Anything casino or third-party games.
- Routes with no caller. In tenexch they were:
  - `/cricket/get-all-sports-data`, `/cricket/live-stream`, `/cricket/score-summary`, `/cricket/score-animation`
  - `/cricket/gameresults`, `/cricket/sports-bets/all`, `/cricket/total-stake`, `/cricket/total-stake-live-events`
  - `POST /sports-bets/user`, `/cricket/wins/user`, `/cricket/matched-bets/user/event`, `/cricket/open-bets/user/event`, `/cricket/open-bets/all`
  - `/buffer-time`, `/exposures/:user_id`, `GET /matchexposures/match`, `/wallet/:uuid`
  - `/open/*`, `/history/*`, `/opencount/*`, `/transfers/*`, `/password/*`, `/admin/bets*`, `/settle`, `/test`
  - `/get-result`, `/get-result-v2`, `/void-audit`
  - 12 old `/betlock/*` per-user routes
  - the `sportsapi/` BullMQ routes (no consumer)
- The old settlement files `job.js`, `newjob.js`, `settlementWorker.js`, `settlementnew.js`.
- Admin panel reports and the integrity scanner.

"No caller" means no reference in the tenexch `frontend/src` or `admin/src`. A mobile app was not checked.

**Changed from tenexch** (casino removal + export glue). Details are in `PENDING_WORK.md` §F:
- casino code, casino fields and casino columns removed
- `TOTAL_EXPOSURE_SQL` made sports-only (tested equal on sports data)
- `utils/socketUtils.js` gets `io` via `setIO(io)` instead of importing `server.js`
- hardcoded feed keys moved to env
- the virtual-media key is renamed to `VIRTUAL_EVENT_API_KEY`

## Verified at export time

- Every file passes `node --check`.
- ESLint `no-undef` is clean, except two pre-existing `typeof`-guarded names in CricketService.
- Loading the 3 API files registers all **69** routes without errors.
- The example server boots:
  - `GET /api/user/betting-config` → 200
  - `POST /api/user/place` without a token → 401
  - a removed route → 404
- All 4 workers start without code errors (tested against unreachable DB / Redis).
- **Not tested:** real bets and real settlement against a database. Do that in staging first.
