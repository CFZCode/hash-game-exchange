var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn2, res) => function __init() {
  return fn2 && (res = (0, fn2[__getOwnPropNames(fn2)[0]])(fn2 = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// config/db.js
import { Sequelize } from "sequelize";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
var __filename, __dirname, envPath, IS_API_PROCESS, POOL_MAX, sequelize, db_default;
var init_db = __esm({
  "config/db.js"() {
    __filename = fileURLToPath(import.meta.url);
    __dirname = path.dirname(__filename);
    envPath = path.resolve(__dirname, "../.env");
    dotenv.config({ path: envPath });
    IS_API_PROCESS = path.basename(process.env.pm_exec_path || process.argv[1] || "") === "server.js";
    POOL_MAX = Number(process.env.DB_POOL_MAX) || (IS_API_PROCESS ? 25 : 10);
    sequelize = new Sequelize(
      process.env.DB_NAME,
      process.env.DB_USER,
      process.env.DB_PASSWORD,
      {
        host: process.env.DB_HOST,
        port: process.env.DB_PORT || 5432,
        dialect: "postgres",
        logging: false,
        // set to true for SQL logs
        pool: {
          max: POOL_MAX,
          // max connections in pool (see POOL_MAX above)
          min: 2,
          // min connections kept open
          acquire: 3e4,
          // max ms to wait for a connection before throwing error
          idle: 1e4,
          // max ms a connection can be idle before being released
          evict: 1e3
          // how often to check for idle connections (ms)
        }
      }
    );
    db_default = sequelize;
  }
});

// config/redisClient.js
var redisClient_exports = {};
__export(redisClient_exports, {
  default: () => redisClient_default
});
import Redis from "ioredis";
import dotenv2 from "dotenv";
var redis, redisClient_default;
var init_redisClient = __esm({
  "config/redisClient.js"() {
    dotenv2.config();
    redis = new Redis({
      host: process.env.REDIS_HOST || "127.0.0.1",
      port: process.env.REDIS_PORT || 6379,
      password: process.env.REDIS_PASSWORD || void 0,
      // undefined means no password
      db: process.env.REDIS_DB || 1,
      retryStrategy: (times) => {
        const delay = Math.min(times * 50, 2e3);
        return delay;
      }
    });
    redis.on("connect", () => {
      console.log("\u2705 Connected to Redis");
    });
    redis.on("error", (err) => {
      console.error("\u274C Redis Connection Error:", err);
    });
    redisClient_default = redis;
  }
});

// model/user/TotalExposure.js
var TotalExposure_exports = {};
__export(TotalExposure_exports, {
  default: () => TotalExposure_default
});
import { DataTypes as DataTypes21 } from "sequelize";
var TotalExposure, TotalExposure_default;
var init_TotalExposure = __esm({
  "model/user/TotalExposure.js"() {
    init_db();
    TotalExposure = db_default.define(
      "TotalExposure",
      {
        id: {
          type: DataTypes21.INTEGER,
          primaryKey: true,
          autoIncrement: true
        },
        user_id: {
          type: DataTypes21.INTEGER,
          allowNull: false,
          unique: true
          // 🔥 REQUIRED for upsert
        },
        total_exposure: {
          type: DataTypes21.DECIMAL(15, 2),
          // ✅ money-safe
          allowNull: false,
          defaultValue: 0
        }
      },
      {
        tableName: "total_exposures",
        timestamps: true
      }
    );
    TotalExposure_default = TotalExposure;
  }
});

// model/user/User.js
init_db();
import { DataTypes as DataTypes4 } from "sequelize";

// model/admin/Role.js
init_db();
import { DataTypes } from "sequelize";
var Role = db_default.define("Role", {
  role_id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  role: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true
  },
  power: {
    type: DataTypes.JSON,
    allowNull: false,
    defaultValue: []
  },
  level: {
    type: DataTypes.STRING,
    allowNull: false
  },
  is_owner: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  },
  is_company: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  },
  max_downline_percentage: {
    type: DataTypes.DECIMAL(5, 2),
    defaultValue: 100,
    comment: "Max % this role can distribute down"
  }
}, {
  timestamps: false
});
var Role_default = Role;

// model/admin/Staff.js
init_db();
import { DataTypes as DataTypes2 } from "sequelize";
var Staff = db_default.define("Staff", {
  staff_id: {
    type: DataTypes2.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  username: {
    type: DataTypes2.STRING,
    allowNull: false,
    unique: true
  },
  fullname: {
    type: DataTypes2.STRING,
    allowNull: true
  },
  city: {
    type: DataTypes2.STRING,
    allowNull: true
  },
  // "Mobile Number" on the admin create-account form. The form has always
  // sent it for staff too, but there was no column to keep it in, so More →
  // Additional Information showed a blank Mobile Number for every staff
  // account (user, 2026-09-21). Added by ensureStaffPhoneNumberColumn() in
  // config/dbInit.js, the same idempotent way the other late columns were.
  phone_number: {
    type: DataTypes2.STRING,
    allowNull: true
  },
  email: {
    type: DataTypes2.STRING,
    allowNull: true,
    unique: true,
    validate: {
      isEmail: true
    }
  },
  password: {
    type: DataTypes2.STRING,
    allowNull: false
  },
  role_id: {
    type: DataTypes2.INTEGER,
    allowNull: false,
    references: {
      model: Role_default,
      key: "role_id"
    }
  },
  role: {
    type: DataTypes2.STRING,
    allowNull: false,
    comment: "Denormalized role name for quick lookup (e.g., SUPER_ADMIN, ADMIN, USER)"
  },
  level: {
    type: DataTypes2.STRING,
    allowNull: false,
    comment: "Denormalized level (L1, L2, ..., L6)"
  },
  parent_id: {
    type: DataTypes2.INTEGER,
    allowNull: true
    // ✅ REMOVED the references block - let associations handle it
  },
  parent_owner_id: {
    type: DataTypes2.INTEGER,
    allowNull: true,
    comment: "ID of the owner who created this staff member (if applicable)"
  },
  percentage: {
    type: DataTypes2.DECIMAL(8, 3),
    allowNull: true,
    defaultValue: null
  },
  credit_limit: {
    type: DataTypes2.DECIMAL(15, 2),
    allowNull: false,
    defaultValue: 0,
    comment: "Maximum credit allowed for this staff member"
  },
  active: {
    type: DataTypes2.BOOLEAN,
    allowNull: false,
    defaultValue: true,
    comment: "Indicates if the staff member is active"
  },
  first_login: {
    type: DataTypes2.BOOLEAN,
    defaultValue: false
  },
  // Operator-set permission, ticked on the create-account form. false = this
  // account may NOT change its own password once the mandatory first-login
  // change (first_login: false -> true) is done. Default true so every
  // pre-existing account keeps behaving exactly as before.
  passwordChangeAllowed: {
    type: DataTypes2.BOOLEAN,
    allowNull: false,
    defaultValue: true,
    comment: "false = account cannot change its own password after the first-login change"
  },
  rules_accepted: {
    type: DataTypes2.BOOLEAN,
    defaultValue: false,
    comment: "True once the rules modal has been accepted after login"
  },
  transaction_password: {
    type: DataTypes2.STRING,
    allowNull: true,
    comment: "Stored as plain text"
  },
  txn_password_attempts: {
    type: DataTypes2.INTEGER,
    allowNull: true,
    defaultValue: 10,
    comment: "Transaction password attempts left; 0 locks txn actions + login until the parent changes this staff password (which resets it to 10)"
  },
  // ── Secure auth (2FA) ────────────────────────────────────────────────
  // securityAuthType is the source of truth for HOW this account logs in:
  // 'telegram' | 'google' | null. telegram2FAEnabled/telegramChatId stay as
  // the Telegram transport; googleAuthSecret is the base32 TOTP secret.
  googleAuthSecret: {
    type: DataTypes2.STRING,
    allowNull: true
  },
  securityAuthType: {
    type: DataTypes2.STRING,
    allowNull: true,
    defaultValue: null
  },
  telegramChatId: {
    type: DataTypes2.STRING,
    allowNull: true
  },
  telegram2FAEnabled: {
    type: DataTypes2.BOOLEAN,
    defaultValue: false
  },
  bet_locked: {
    type: DataTypes2.BOOLEAN,
    defaultValue: false,
    comment: "If true, this staff and all downline cannot place bets"
  },
  exp_limit: {
    type: DataTypes2.DECIMAL(20, 2),
    allowNull: true,
    defaultValue: null,
    comment: "Max exposure limit for the staff"
  },
  bal_down: {
    type: DataTypes2.DECIMAL(15, 2),
    allowNull: true,
    defaultValue: 0,
    comment: "Balance down value for the staff member"
  },
  bal_up: {
    type: DataTypes2.DECIMAL(15, 2),
    allowNull: true,
    defaultValue: 0,
    comment: "Balance up value for the staff member"
  },
  login_id: {
    type: DataTypes2.STRING,
    allowNull: true,
    comment: "Unique ID for the current active login session (single-session enforcement)"
  }
}, {
  tableName: "staff",
  // ✅ Explicitly set lowercase table name
  timestamps: true,
  paranoid: true
});
Staff.belongsTo(Role_default, {
  foreignKey: "role_id",
  as: "roleDetails"
});
Staff.belongsTo(Staff, {
  foreignKey: "parent_id",
  as: "parent"
});
Staff.hasMany(Staff, {
  foreignKey: "parent_id",
  as: "children"
});
var Staff_default = Staff;

// model/user/User.js
import bcrypt from "bcryptjs";

// model/admin/Affiliate.js
init_db();
import { DataTypes as DataTypes3 } from "sequelize";
var Affiliate = db_default.define("Affiliate", {
  uid: {
    type: DataTypes3.INTEGER,
    primaryKey: true,
    allowNull: false,
    references: {
      model: "users",
      // Reference the Users table
      key: "user_id"
    }
  },
  name: {
    type: DataTypes3.STRING,
    allowNull: false
  },
  referral_link: {
    type: DataTypes3.STRING,
    allowNull: false,
    unique: true
  },
  referral_code: {
    type: DataTypes3.STRING,
    allowNull: false,
    unique: true
  },
  friends: {
    type: DataTypes3.INTEGER,
    defaultValue: 0
  }
});

// model/user/User.js
var User = db_default.define("User", {
  user_id: {
    type: DataTypes4.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  username: {
    type: DataTypes4.STRING,
    allowNull: false,
    unique: true
  },
  fullname: {
    type: DataTypes4.STRING,
    allowNull: true
  },
  city: {
    type: DataTypes4.STRING,
    allowNull: true
  },
  email: {
    type: DataTypes4.STRING,
    allowNull: true,
    unique: true
  },
  phone_number: {
    type: DataTypes4.STRING,
    allowNull: true
  },
  country: {
    type: DataTypes4.STRING,
    allowNull: true
  },
  telegramChatId: {
    type: DataTypes4.STRING,
    allowNull: true
  },
  telegram2FAEnabled: {
    type: DataTypes4.BOOLEAN,
    defaultValue: false
  },
  // Base32 TOTP secret for Google Authenticator. Written when the user starts
  // the setup (so the QR survives a refresh) but only ACTIVE once
  // securityAuthType === 'google'.
  googleAuthSecret: {
    type: DataTypes4.STRING,
    allowNull: true
  },
  // Which secure-auth method the account uses at login:
  // 'android' | 'telegram' | 'google', or null when 2FA is off.
  // This is the single source of truth — telegram2FAEnabled only records that
  // a Telegram chat is linked.
  securityAuthType: {
    type: DataTypes4.STRING,
    allowNull: true,
    defaultValue: null,
    comment: "Active 2FA method: 'android' | 'telegram' | 'google' | null"
  },
  //  Removed coin_type
  password: {
    type: DataTypes4.STRING,
    allowNull: false
  },
  passwordChanged: {
    type: DataTypes4.BOOLEAN,
    allowNull: false,
    defaultValue: false,
    comment: "Indicates whether user has changed default password"
  },
  // Operator-set permission, ticked on the create-account form. false = this
  // account may NOT change its own password once the mandatory first-login
  // change (passwordChanged: false -> true) is done. Default true so every
  // pre-existing account keeps behaving exactly as before.
  passwordChangeAllowed: {
    type: DataTypes4.BOOLEAN,
    allowNull: false,
    defaultValue: true,
    comment: "false = account cannot change its own password after the first-login change"
  },
  //  Role ID reference
  role_id: {
    type: DataTypes4.INTEGER,
    allowNull: false,
    comment: "FK to roles table"
  },
  credit_limit: {
    type: DataTypes4.DECIMAL(15, 2),
    allowNull: false,
    defaultValue: 0,
    comment: "Maximum credit allowed for this user"
  },
  //  Hierarchy columns
  parent_staff_id: {
    type: DataTypes4.INTEGER,
    allowNull: true,
    comment: "References Staff table (who created this user)"
  },
  parent_owner_id: {
    type: DataTypes4.INTEGER,
    allowNull: true,
    comment: "If user was created by an owner, reference owner ID"
  },
  //  Keep role name for readability
  role: {
    type: DataTypes4.STRING,
    allowNull: false,
    defaultValue: "USER"
  },
  percentage: {
    type: DataTypes4.DECIMAL(8, 3),
    allowNull: true,
    defaultValue: 0
  },
  net_win: {
    type: DataTypes4.DECIMAL(18, 2),
    allowNull: true,
    defaultValue: 0
  },
  net_loss: {
    type: DataTypes4.DECIMAL(18, 2),
    allowNull: true,
    defaultValue: 0
  },
  profit: {
    type: DataTypes4.DECIMAL(18, 2),
    allowNull: true,
    defaultValue: 0
  },
  status: {
    type: DataTypes4.ENUM("Active", "InActive", "Pending"),
    defaultValue: "Active"
  },
  bet_locked: {
    type: DataTypes4.BOOLEAN,
    defaultValue: false,
    comment: "If true, user cannot place bets"
  },
  exp_limit: {
    type: DataTypes4.DECIMAL(20, 2),
    allowNull: true,
    defaultValue: null,
    comment: "Max exposure limit for the user"
  },
  login_id: {
    type: DataTypes4.STRING,
    allowNull: true,
    comment: "Unique ID for the current active login session"
  },
  user_gt: {
    type: DataTypes4.STRING,
    allowNull: true
  },
  rules_accepted: {
    type: DataTypes4.BOOLEAN,
    defaultValue: false,
    comment: "True once the rules modal has been accepted after login"
  },
  // Demo account (see server/demo/README.md). A demo user is a REAL row that
  // bets and settles through the normal engine; it only differs in that it
  // lives under the dedicated demo owner, its P&L never rolls up
  // (walletService.updateAllPointHierarchy skips it), the tracker ignores it,
  // and it is deactivated at demo_expires_at then purged by demoCleanup.
  is_demo: {
    type: DataTypes4.BOOLEAN,
    allowNull: false,
    defaultValue: false,
    comment: "true = throwaway demo account minted by POST /api/user/demo-login"
  },
  demo_expires_at: {
    type: DataTypes4.DATE,
    allowNull: true,
    comment: "Demo session end; authMiddleware rejects the token past this"
  }
}, {
  tableName: "users",
  timestamps: true
});
var User_default = User;

// model/admin/BetLock.js
init_db();
import { DataTypes as DataTypes5 } from "sequelize";
var BetLock = db_default.define(
  "BetLock",
  {
    id: {
      type: DataTypes5.BIGINT,
      primaryKey: true,
      autoIncrement: true
    },
    user_id: {
      type: DataTypes5.BIGINT,
      allowNull: false,
      unique: true
      // ✅ Ensure no duplicate user_ids
    },
    MatchOdds: {
      type: DataTypes5.BOOLEAN,
      defaultValue: false
    },
    OtherMarkets: {
      type: DataTypes5.BOOLEAN,
      defaultValue: false
    }
  },
  {
    tableName: "betlocks",
    // Adds created_at and updated_at
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at"
  }
);
var BetLock_default = BetLock;

// model/admin/Wallet.js
init_db();
import { DataTypes as DataTypes6 } from "sequelize";
function calculateProfitLoss(instance) {
  const cashReceived = parseFloat(instance.getDataValue("cash_received")) || 0;
  const inrBalance = parseFloat(instance.getDataValue("inr_balance")) || 0;
  const profitLoss = parseFloat((inrBalance - cashReceived).toFixed(2));
  const verdict = profitLoss >= 0 ? "profit" : "loss";
  instance.setDataValue("profit_loss", profitLoss);
  instance.setDataValue("verdict", verdict);
}
var Wallet = db_default.define(
  "Wallet",
  {
    wallet_id: {
      type: DataTypes6.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    // Generic Reference Fields
    user_id: { type: DataTypes6.INTEGER, allowNull: true, comment: "Reference for normal user wallet (end user)" },
    staff_id: { type: DataTypes6.INTEGER, allowNull: true, comment: "Reference for staff wallet (admin/supermaster/master)" },
    owner_id: { type: DataTypes6.INTEGER, allowNull: true, comment: "Reference for owner wallet (top-level company or super admin)" },
    // Wallet Classification
    user_type: {
      type: DataTypes6.ENUM("OWNER", "COMPANY", "SUPERADMIN", "ADMIN", "SUPERMASTER", "MASTER", "AGENT", "USER"),
      allowNull: false
    },
    // Wallet Info
    username: { type: DataTypes6.STRING, allowNull: false, unique: true },
    // Core Financial Fields
    inr_balance: { type: DataTypes6.DECIMAL(18, 2), allowNull: false, defaultValue: 0 },
    cash: { type: DataTypes6.DECIMAL(18, 2), allowNull: false, defaultValue: 0 },
    credit: { type: DataTypes6.DECIMAL(18, 2), allowNull: false, defaultValue: 0 },
    cash_received: { type: DataTypes6.DECIMAL(18, 2), allowNull: false, defaultValue: 0 },
    // Initial credit handed over at account creation (set once, first time)
    all_point: { type: DataTypes6.DECIMAL(18, 2), allowNull: false, defaultValue: 0 },
    // Cash settlement ka running total: upper_point = apne upline ke saath hua hisaab,
    // down_point = apne downline ke saath hua hisaab
    upper_point: { type: DataTypes6.DECIMAL(18, 2), allowNull: false, defaultValue: 0 },
    down_point: { type: DataTypes6.DECIMAL(18, 2), allowNull: false, defaultValue: 0 },
    // Category-wise settlement points ka running total
    sports_pts: { type: DataTypes6.DECIMAL(18, 2), allowNull: false, defaultValue: 0 },
    sportsbook_pts: { type: DataTypes6.DECIMAL(18, 2), allowNull: false, defaultValue: 0 },
    // Calculated Metrics
    profit_loss: { type: DataTypes6.DECIMAL(18, 2), allowNull: false, defaultValue: 0 },
    verdict: { type: DataTypes6.ENUM("profit", "loss"), allowNull: false, defaultValue: "profit" },
    // NEW – total commission the user has **received** (cumulative)
    totalCommission: {
      type: DataTypes6.DECIMAL(18, 2),
      allowNull: false,
      defaultValue: 0,
      comment: "Cumulative platform-fee commission earned by this wallet"
    }
  },
  {
    tableName: "Wallets",
    timestamps: true,
    hooks: {
      beforeCreate: calculateProfitLoss,
      beforeUpdate: calculateProfitLoss,
      // Recompute on read so increment()/bulk-update paths cannot serve a stale figure.
      // Fires for instances, raw:true rows and findAll alike (verified against this
      // codebase's query shapes). Rows that did not select the source columns — e.g.
      // aggregate queries like SUM(profit_loss) AS downPL — are skipped untouched.
      afterFind: (result) => {
        if (!result) return result;
        const rows = Array.isArray(result) ? result : [result];
        for (const row of rows) {
          if (!row) continue;
          const isInstance = typeof row.getDataValue === "function";
          const inr = isInstance ? row.getDataValue("inr_balance") : row.inr_balance;
          const recv = isInstance ? row.getDataValue("cash_received") : row.cash_received;
          if (inr === void 0 || recv === void 0) continue;
          const pl = parseFloat(((parseFloat(inr) || 0) - (parseFloat(recv) || 0)).toFixed(2));
          const verdict = pl >= 0 ? "profit" : "loss";
          if (isInstance) {
            row.setDataValue("profit_loss", pl);
            row.setDataValue("verdict", verdict);
            row.changed("profit_loss", false);
            row.changed("verdict", false);
          } else {
            row.profit_loss = pl;
            row.verdict = verdict;
          }
        }
        return result;
      }
    }
  }
);
Wallet.belongsTo(Staff_default, {
  foreignKey: "staff_id",
  as: "staff",
  constraints: false
});
var Wallet_default = Wallet;

// model/user/SportsBet.js
init_db();
import { DataTypes as DataTypes7 } from "sequelize";
var SportsBet = db_default.define(
  "SportsBet",
  {
    id: {
      type: DataTypes7.INTEGER,
      autoIncrement: true,
      primaryKey: true
    },
    user_id: {
      type: DataTypes7.BIGINT,
      allowNull: false
    },
    game_type: {
      type: DataTypes7.STRING(100),
      allowNull: false
    },
    match_title: {
      type: DataTypes7.STRING(255)
    },
    team_one: {
      type: DataTypes7.STRING(255),
      allowNull: true
    },
    team_two: {
      type: DataTypes7.STRING(255),
      allowNull: true
    },
    selection_name: {
      type: DataTypes7.STRING(255),
      allowNull: true
    },
    category: {
      type: DataTypes7.STRING(100),
      allowNull: true
    },
    bet_type: {
      type: DataTypes7.STRING(100),
      allowNull: false
    },
    market_type: {
      type: DataTypes7.STRING(100),
      allowNull: true,
      defaultValue: null
      // or "Over By Over" if you want
    },
    odds: {
      type: DataTypes7.DECIMAL(10, 4),
      allowNull: false
    },
    stake_amount: {
      type: DataTypes7.DECIMAL(15, 2),
      allowNull: false
    },
    event_name: {
      type: DataTypes7.STRING(255)
    },
    original_currency: {
      type: DataTypes7.STRING(10),
      allowNull: true,
      defaultValue: "INR"
    },
    original_amount: {
      type: DataTypes7.DECIMAL(15, 2),
      allowNull: true
    },
    usd_amount: {
      type: DataTypes7.DECIMAL(15, 2),
      allowNull: true
    },
    liability: {
      type: DataTypes7.DECIMAL(15, 2),
      allowNull: true
    },
    match_start_time: {
      type: DataTypes7.DATE,
      allowNull: true
    },
    match_end_time: {
      type: DataTypes7.DATE,
      allowNull: true
    },
    created_at: {
      type: DataTypes7.DATE,
      defaultValue: DataTypes7.NOW
    },
    updated_at: {
      type: DataTypes7.DATE,
      defaultValue: DataTypes7.NOW
    },
    match_id: {
      type: DataTypes7.STRING(100),
      allowNull: true
    },
    exposure_after_bet: {
      type: DataTypes7.DECIMAL(15, 2),
      allowNull: true
    },
    status: {
      type: DataTypes7.STRING(20),
      allowNull: true
    },
    eventid: {
      type: DataTypes7.TEXT
    },
    job_id: {
      type: DataTypes7.UUID,
      allowNull: true
    },
    ip_address: {
      type: DataTypes7.TEXT,
      allowNull: true
    },
    browser: {
      type: DataTypes7.TEXT,
      allowNull: true
    },
    fancy_name: {
      type: DataTypes7.TEXT,
      allowNull: true
    },
    result_status: {
      type: DataTypes7.TEXT,
      defaultValue: "pending"
    },
    fixed: {
      type: DataTypes7.INTEGER,
      defaultValue: 0
    },
    counts: {
      type: DataTypes7.INTEGER,
      defaultValue: 2
    },
    sport_id: {
      type: DataTypes7.TEXT,
      allowNull: true
    },
    unmatched: {
      type: DataTypes7.BOOLEAN,
      defaultValue: false
    },
    unmatched_odds: {
      type: DataTypes7.DECIMAL(10, 4),
      allowNull: true
    },
    size: {
      type: DataTypes7.INTEGER,
      allowNull: true
    },
    runners: {
      type: DataTypes7.JSON,
      allowNull: true
    },
    gtype: {
      type: DataTypes7.TEXT,
      allowNull: true
    },
    // League / competition name from the feed (cname), sent by the client at
    // placement. Only used for display — the statement Result modal prints
    // "Sport -> League -> Match -> Market". Column is added on boot by
    // ensureSportsBetLeagueColumn() in config/dbInit.js.
    league_name: {
      type: DataTypes7.STRING(255),
      allowNull: true
    },
    // Badlo is an EXACT-RUN swap that lives INSIDE an ordinary session market
    // ("Normal"), flagged per runner by the feed's `ik`. It is a property of
    // the BET, not of the market — so it is a flag here rather than a
    // market_type value. Overloading market_type with 'badlo' (the first
    // attempt) put these rows in their own market bucket, printed "badlo" as
    // the market name in the bet list, and split the runner's Normal book.
    // See helper/badloMarket.js.
    badlo: {
      type: DataTypes7.BOOLEAN,
      allowNull: false,
      defaultValue: false
    }
  },
  {
    tableName: "SportsBet",
    timestamps: false,
    indexes: [
      { fields: ["user_id"] },
      { fields: ["match_id"] },
      { fields: ["eventid"] },
      { fields: ["status"] },
      { fields: ["result_status"] },
      { fields: ["sport_id"] },
      { fields: ["job_id"] },
      { fields: ["user_id", "status"] },
      { fields: ["user_id", "match_id"] },
      { fields: ["user_id", "eventid", "status"] }
    ]
  }
);
var SportsBet_default = SportsBet;

// model/associations.js
User_default.hasOne(BetLock_default, {
  foreignKey: "user_id",
  as: "betlock",
  onDelete: "CASCADE"
});
BetLock_default.belongsTo(User_default, {
  foreignKey: "user_id",
  as: "user"
});
Wallet_default.belongsTo(User_default, {
  foreignKey: "user_id",
  as: "user",
  constraints: false
});
SportsBet_default.belongsTo(User_default, {
  foreignKey: "user_id",
  as: "user"
});

// jobs/betLimitCleanupJob.js
import cron from "node-cron";
import { Op as Op2 } from "sequelize";

// model/admin/BetLimitOverride.js
init_db();
import { DataTypes as DataTypes8 } from "sequelize";
var BetLimitOverride = db_default.define("BetLimitOverride", {
  id: {
    type: DataTypes8.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  scope: {
    type: DataTypes8.STRING(10),
    allowNull: false,
    comment: "'sports'"
  },
  sport_id: {
    type: DataTypes8.INTEGER,
    allowNull: true
  },
  event_id: {
    type: DataTypes8.STRING(40),
    allowNull: true,
    comment: "sports scope only \u2014 feed gmid"
  },
  market_id: {
    type: DataTypes8.STRING(60),
    allowNull: true,
    comment: "sports scope only \u2014 feed mid"
  },
  market_name: {
    type: DataTypes8.STRING(120),
    allowNull: true,
    comment: "display only (admin list)"
  },
  gtype: {
    type: DataTypes8.STRING(30),
    allowNull: true,
    comment: "display only (admin list)"
  },
  event_name: {
    type: DataTypes8.STRING(200),
    allowNull: true,
    comment: "display only (admin list)"
  },
  min_stake: {
    type: DataTypes8.DECIMAL(15, 2),
    allowNull: true,
    comment: "NULL = use the feed value"
  },
  max_stake: {
    type: DataTypes8.DECIMAL(15, 2),
    allowNull: true,
    comment: "NULL = use the feed value"
  },
  is_active: {
    type: DataTypes8.BOOLEAN,
    allowNull: false,
    defaultValue: true
  },
  // Sports scope only. Stamped the first time the cleanup job finds the
  // event gone from the live board; cleared again if it comes back. The row
  // is deleted once this is older than the grace window (see
  // jobs/betLimitCleanupJob.js). NULL = the match is still running.
  ended_at: {
    type: DataTypes8.DATE,
    allowNull: true,
    comment: "when the event left the live board; row is purged after the grace window"
  }
}, {
  tableName: "bet_limit_overrides",
  timestamps: true,
  // See BetBufferConfig for why uniqueness is declared here and not inline.
  indexes: [
    {
      name: "bet_limit_overrides_sports_uniq",
      unique: true,
      fields: ["scope", "event_id", "market_id"]
    }
  ]
});
BetLimitOverride.SCOPES = ["sports"];
var BetLimitOverride_default = BetLimitOverride;

// services/BettingConfigService.js
init_redisClient();

// model/admin/BetBufferConfig.js
init_db();
import { DataTypes as DataTypes10 } from "sequelize";

// model/admin/CommissionConfig.js
init_db();
import { DataTypes as DataTypes9 } from "sequelize";

// constants/commissionLeagues.js
var DEFAULT_LEAGUE_KEY = "default";
var DEFAULT_LEAGUE_LABEL = "All other leagues";
var COMMISSION_LEAGUES = {
  // Cricket
  4: [
    { key: "ecricket", label: "E-Cricket (Dim)", patterns: ["dim cricket league"], cid: 7526679, iscc: 4 },
    { key: "t10xi", label: "T10 XI", patterns: ["t10 xi"], cid: 56100513, iscc: 1 },
    { key: "t5xi", label: "T5 XI", patterns: ["t5 xi"], cid: 46201121, iscc: 1 },
    { key: "vcl", label: "Virtual Cricket League", patterns: ["virtual cricket league"], cid: 8590658, iscc: 2 }
  ],
  // Wrestling — one virtual league, same shape as cricket's VCL.
  69: [
    { key: "wwevirtual", label: "WWE Virtual", patterns: ["wwe virtual"], cid: 8524813, iscc: 2 }
  ]
};
var normaliseLeagueName = (name) => String(name || "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
var leaguesForSport = (sportId) => COMMISSION_LEAGUES[Number(sportId)] || [];
var leagueOptionsForSport = (sportId) => [
  { key: DEFAULT_LEAGUE_KEY, label: DEFAULT_LEAGUE_LABEL, is_default: true },
  ...leaguesForSport(sportId).map(({ key, label }) => ({ key, label, is_default: false }))
];
var isValidLeagueKey = (sportId, leagueKey) => leagueKey === DEFAULT_LEAGUE_KEY || leaguesForSport(sportId).some((l) => l.key === leagueKey);
var leagueKeyFromName = (sportId, leagueName) => {
  const norm = normaliseLeagueName(leagueName);
  if (!norm) return DEFAULT_LEAGUE_KEY;
  for (const league of leaguesForSport(sportId)) {
    if (league.patterns.some((p) => norm.includes(p))) return league.key;
  }
  return DEFAULT_LEAGUE_KEY;
};

// model/admin/CommissionConfig.js
var CommissionConfig = db_default.define("CommissionConfig", {
  id: {
    type: DataTypes9.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  sport_id: {
    type: DataTypes9.INTEGER,
    allowNull: false,
    comment: "feed etid (4 = Cricket)"
  },
  league_key: {
    type: DataTypes9.STRING(32),
    allowNull: false,
    defaultValue: DEFAULT_LEAGUE_KEY,
    comment: "default | ecricket | t10xi | t5xi | vcl | wwevirtual"
  },
  market_key: {
    type: DataTypes9.STRING(24),
    allowNull: false,
    comment: "matchodds | match_other | bookmaker | match1_other | fancy | \u2026"
  },
  enabled: {
    type: DataTypes9.BOOLEAN,
    allowNull: false,
    defaultValue: false
  },
  percent: {
    type: DataTypes9.DECIMAL(5, 2),
    allowNull: false,
    defaultValue: 2,
    comment: "commission % of net win"
  }
}, {
  tableName: "commission_configs",
  timestamps: true,
  // Uniqueness lives here, never inline on the column: an inline `unique`
  // makes Sequelize emit a fresh ADD CONSTRAINT on every sync, which is how
  // this platform's DBs collected thousands of duplicate unique constraints.
  indexes: [
    {
      name: "commission_configs_sport_league_market_uniq",
      unique: true,
      fields: ["sport_id", "league_key", "market_key"]
    }
  ]
});
CommissionConfig.MARKETS = [
  { key: "matchodds", label: "Match Odds", group: "Main", hint: "market name is exactly Match Odds" },
  { key: "match_other", label: "Other Main Markets", group: "Main", hint: "Over/Under, Correct Score, Match Result, Inning EvenOdd, Nth Ball\u2026" },
  { key: "bookmaker", label: "Bookmaker", group: "Bookmaker", hint: "Bookmaker, Bookmaker 2" },
  { key: "match1_other", label: "Other Bookmaker Markets", group: "Bookmaker", hint: "Tied Match, Completed Match, Score More Runs, BM Over/Under\u2026" },
  { key: "fancy", label: "Fancy", group: "Fancy", hint: "Normal, Over By Over, Ball By Ball" },
  { key: "fancy1", label: "Fancy1", group: "Fancy", hint: "" },
  { key: "fancy2", label: "Fancy2", group: "Fancy", hint: "Innings Overs/Runs lines" },
  { key: "oddeven", label: "Odd/Even", group: "Fancy", hint: "" },
  { key: "khado", label: "Khado", group: "Fancy", hint: "" },
  { key: "meter", label: "Meter", group: "Fancy", hint: "" },
  { key: "badlo", label: "Badlo", group: "Fancy", hint: "" },
  { key: "cricketcasino", label: "Cricket Casino", group: "Fancy", hint: "" },
  { key: "other", label: "Other", group: "Fancy", hint: "anything the feed ships with an unknown gtype" }
];
CommissionConfig.MARKET_KEYS = CommissionConfig.MARKETS.map((m) => m.key);
CommissionConfig.MAX_PERCENT = 50;
CommissionConfig.DEFAULT_PERCENT = 2;
var DIRECT_GTYPES = /* @__PURE__ */ new Set([
  "fancy",
  "fancy1",
  "fancy2",
  "oddeven",
  "khado",
  "meter",
  "badlo",
  "cricketcasino"
]);
var normMarketName = (name) => String(name || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
CommissionConfig.marketKeyOfBet = (bet) => {
  if (bet?.badlo === true || String(bet?.badlo) === "true") return "badlo";
  let g = String(bet?.gtype || "").toLowerCase().trim();
  if (!g) {
    const gt = String(bet?.game_type || "").toUpperCase();
    if (gt === "MO" || gt === "MATCH") g = "match";
    else if (gt === "BM" || gt === "BOOKMAKER") g = "match1";
    else if (gt === "FAN" || gt === "FANCY") g = "fancy";
  }
  const name = normMarketName(bet?.market_type);
  if (g === "match") return name === "MATCHODDS" ? "matchodds" : "match_other";
  if (g === "match1") return name.startsWith("BOOKMAKER") ? "bookmaker" : "match1_other";
  if (DIRECT_GTYPES.has(g)) return g;
  return "other";
};
CommissionConfig.leagueKeyOfBet = (bet) => leagueKeyFromName(bet?.sport_id, bet?.league_name);
CommissionConfig.isValidLeagueKey = isValidLeagueKey;
CommissionConfig.DEFAULT_LEAGUE_KEY = DEFAULT_LEAGUE_KEY;
CommissionConfig.LEGACY_GTYPE_EXPANSION = {
  match: ["matchodds", "match_other"],
  match1: ["bookmaker", "match1_other"]
};
var CommissionConfig_default = CommissionConfig;

// model/admin/BetBufferConfig.js
var BetBufferConfig = db_default.define("BetBufferConfig", {
  id: {
    type: DataTypes10.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  scope: {
    type: DataTypes10.STRING(10),
    allowNull: false,
    comment: "'sports'"
  },
  sport_id: {
    type: DataTypes10.INTEGER,
    allowNull: true,
    comment: "sports scope only \u2014 feed etid (4 = Cricket)"
  },
  league_key: {
    type: DataTypes10.STRING(32),
    allowNull: false,
    defaultValue: DEFAULT_LEAGUE_KEY,
    comment: "sports scope only \u2014 default | ecricket | t10xi | t5xi | vcl | wwevirtual"
  },
  category: {
    type: DataTypes10.STRING(20),
    allowNull: true,
    comment: "sports scope only \u2014 market key (CommissionConfig.MARKETS)"
  },
  buffer_seconds: {
    type: DataTypes10.DECIMAL(5, 2),
    allowNull: false,
    defaultValue: 0,
    comment: "0 = unset, caller uses its env default"
  }
}, {
  tableName: "bet_buffer_configs",
  timestamps: true,
  // Uniqueness lives here, never inline on the column: an inline `unique`
  // makes Sequelize emit a fresh ADD CONSTRAINT on every sync, which is how
  // this platform's DBs collected thousands of duplicate unique constraints.
  indexes: [
    {
      name: "bet_buffer_configs_sports_league_uniq",
      unique: true,
      fields: ["scope", "sport_id", "league_key", "category"]
    }
  ]
});
BetBufferConfig.SCOPES = ["sports"];
BetBufferConfig.MARKETS = CommissionConfig_default.MARKETS;
BetBufferConfig.MARKET_KEYS = CommissionConfig_default.MARKET_KEYS;
BetBufferConfig.DEFAULT_LEAGUE_KEY = DEFAULT_LEAGUE_KEY;
BetBufferConfig.isValidLeagueKey = isValidLeagueKey;
BetBufferConfig.LEGACY_CATEGORY_EXPANSION = {
  match_odds: ["matchodds", "match_other"],
  bookmaker: ["bookmaker", "match1_other"],
  fancy: ["fancy", "fancy1", "fancy2", "oddeven", "khado", "meter", "cricketcasino", "other"]
};
BetBufferConfig.CATEGORIES = Object.keys(BetBufferConfig.LEGACY_CATEGORY_EXPANSION);
BetBufferConfig.marketKeyOf = (bet) => CommissionConfig_default.marketKeyOfBet(bet);
BetBufferConfig.leagueKeyOf = (bet) => leagueKeyFromName(bet?.sport_id, bet?.league_name);
BetBufferConfig.categoryFromGtype = (gtype) => {
  const g = String(gtype || "").toLowerCase();
  if (g === "match") return "match_odds";
  if (g === "match1") return "bookmaker";
  return "fancy";
};
var BetBufferConfig_default = BetBufferConfig;

// model/admin/Owner.js
init_db();
import { DataTypes as DataTypes11 } from "sequelize";
var Owner = db_default.define(
  "Owner",
  {
    owner_id: {
      type: DataTypes11.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    username: {
      type: DataTypes11.STRING,
      allowNull: false
    },
    website_name: {
      type: DataTypes11.STRING,
      allowNull: false
    },
    domain_name: {
      type: DataTypes11.STRING,
      allowNull: false,
      unique: true
    },
    website_ui: {
      type: DataTypes11.STRING,
      allowNull: false
    },
    country: {
      type: DataTypes11.STRING,
      allowNull: false
    },
    logo: {
      type: DataTypes11.STRING,
      // Store the file path or URL
      allowNull: false
    },
    favicon: {
      type: DataTypes11.STRING,
      // Store the file path or URL
      allowNull: false
    },
    game_providers: {
      type: DataTypes11.JSON,
      // Store as JSON for multiple providers
      allowNull: false
    },
    subscription_plan: {
      type: DataTypes11.STRING,
      allowNull: false
    },
    platform_configurations: {
      type: DataTypes11.JSON,
      // Store as JSON for multiple configurations
      allowNull: false
    },
    payment_methods: {
      type: DataTypes11.JSON,
      // Store as JSON for multiple payment methods
      allowNull: false
    },
    site_email_address: {
      type: DataTypes11.STRING,
      allowNull: false,
      unique: true
      // Ensure email is unique
    },
    password: {
      type: DataTypes11.STRING,
      allowNull: false
    },
    platform_name: {
      type: DataTypes11.STRING,
      allowNull: false
    },
    role: {
      type: DataTypes11.ENUM("OWNER"),
      allowNull: false
    },
    account_status: {
      type: DataTypes11.BOOLEAN,
      defaultValue: true
    },
    unlimited_balance: {
      type: DataTypes11.BOOLEAN,
      defaultValue: true,
      comment: "If true, owner has unlimited balance and no deductions occur. If false, balance is deducted."
    },
    first_login: {
      type: DataTypes11.BOOLEAN,
      defaultValue: false
    },
    rules_accepted: {
      type: DataTypes11.BOOLEAN,
      defaultValue: false,
      comment: "True once the rules modal has been accepted after login"
    },
    transaction_password: {
      type: DataTypes11.STRING,
      allowNull: true,
      comment: "Stored as plain text"
    },
    txn_password_attempts: {
      type: DataTypes11.INTEGER,
      allowNull: true,
      defaultValue: 10,
      comment: "Transaction password attempts left; reset to 10 on a successful attempt"
    },
    // ── Secure auth (2FA) ────────────────────────────────────────────────
    // securityAuthType is the source of truth for HOW this account logs in:
    // 'telegram' | 'google' | null. telegram2FAEnabled/telegramChatId stay as
    // the Telegram transport; googleAuthSecret is the base32 TOTP secret.
    googleAuthSecret: {
      type: DataTypes11.STRING,
      allowNull: true
    },
    securityAuthType: {
      type: DataTypes11.STRING,
      allowNull: true,
      defaultValue: null
    },
    telegramChatId: {
      type: DataTypes11.STRING,
      allowNull: true
    },
    telegram2FAEnabled: {
      type: DataTypes11.BOOLEAN,
      defaultValue: false
    },
    login_id: {
      type: DataTypes11.STRING,
      allowNull: true,
      comment: "Unique ID for the current active login session (single-session enforcement)"
    }
  }
);
var Owner_default = Owner;

// model/admin/MaxOddsConfig.js
init_db();
import { DataTypes as DataTypes12 } from "sequelize";
var MaxOddsConfig = db_default.define("MaxOddsConfig", {
  id: {
    type: DataTypes12.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  sport_id: {
    type: DataTypes12.INTEGER,
    allowNull: false,
    comment: "feed etid (4 = Cricket)"
  },
  league_key: {
    type: DataTypes12.STRING(32),
    allowNull: false,
    defaultValue: DEFAULT_LEAGUE_KEY,
    comment: "default | ecricket | t10xi | t5xi | vcl | wwevirtual"
  },
  category: {
    type: DataTypes12.STRING(20),
    allowNull: false,
    comment: "'match_odds' | 'bookmaker'"
  },
  max_odds: {
    type: DataTypes12.DECIMAL(10, 2),
    allowNull: false,
    defaultValue: 0,
    comment: "bet refused when rate > this; 0 = no cap"
  },
  limited_overs_only: {
    type: DataTypes12.BOOLEAN,
    allowNull: false,
    defaultValue: false,
    comment: "cricket only: Oneday/T20 capped, Test exempt"
  }
}, {
  tableName: "max_odds_configs",
  timestamps: true,
  // Uniqueness lives here, never inline on the column: an inline `unique`
  // makes Sequelize emit a fresh ADD CONSTRAINT on every sync, which is how
  // this platform's DBs collected thousands of duplicate unique constraints.
  indexes: [
    {
      name: "max_odds_configs_sport_league_category_uniq",
      unique: true,
      fields: ["sport_id", "league_key", "category"]
    }
  ]
});
MaxOddsConfig.CATEGORIES = ["match_odds", "bookmaker"];
MaxOddsConfig.MAX_VALUE = 1e3;
MaxOddsConfig.LIMITED_OVERS_SPORT_ID = 4;
MaxOddsConfig.DEFAULT_LEAGUE_KEY = DEFAULT_LEAGUE_KEY;
MaxOddsConfig.isValidLeagueKey = isValidLeagueKey;
MaxOddsConfig.categoryFromGtype = (gtype) => {
  const g = String(gtype || "").toLowerCase();
  if (g === "match") return "match_odds";
  if (g === "match1") return "bookmaker";
  return null;
};
var MaxOddsConfig_default = MaxOddsConfig;

// model/admin/VirtualBetLimit.js
init_db();
import { DataTypes as DataTypes13 } from "sequelize";
var VirtualBetLimit = db_default.define("VirtualBetLimit", {
  id: {
    type: DataTypes13.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  sport_id: {
    type: DataTypes13.INTEGER,
    allowNull: false
  },
  league_key: {
    type: DataTypes13.STRING(40),
    allowNull: false,
    comment: "commissionLeagues key: ecricket, t10xi, t5xi, vcl, wwevirtual"
  },
  min_stake: {
    type: DataTypes13.DECIMAL(15, 2),
    allowNull: false,
    defaultValue: 0
  },
  max_stake: {
    type: DataTypes13.DECIMAL(15, 2),
    allowNull: false,
    defaultValue: 0
  }
}, {
  tableName: "virtual_bet_limits",
  timestamps: true,
  indexes: [{ unique: true, fields: ["sport_id", "league_key"] }]
});
var SEED_MIN = { ecricket: 200 };
var DEFAULT_SEED_MIN = 100;
var virtualLeagues = () => Object.entries(COMMISSION_LEAGUES).flatMap(([sid, list]) => list.map(({ key, label }) => ({ sport_id: Number(sid), league_key: key, label })));
var seedVirtualBetLimits = async () => {
  for (const { sport_id, league_key } of virtualLeagues()) {
    await VirtualBetLimit.findOrCreate({
      where: { sport_id, league_key },
      defaults: { sport_id, league_key, min_stake: SEED_MIN[league_key] ?? DEFAULT_SEED_MIN, max_stake: 0 }
    });
  }
};
var VirtualBetLimit_default = VirtualBetLimit;

// constants/sportsList.js
var SPORTS_LIST = [
  ["1", "Football"],
  ["2", "Tennis"],
  ["3", "Mixed Martial Arts"],
  ["4", "Cricket"],
  ["5", "Golf"],
  ["6", "Boxing"],
  ["7", "Beach Volleyball"],
  ["8", "Table Tennis"],
  ["9", "Futsal"],
  ["10", "Horse Racing"],
  ["11", "E Games"],
  ["15", "Basketball"],
  ["16", "MotoGP"],
  ["17", "Chess"],
  ["18", "Volleyball"],
  ["19", "Ice Hockey"],
  ["22", "Badminton"],
  ["25", "Hockey"],
  ["29", "Cycling"],
  ["32", "Motorbikes"],
  ["33", "Athletics"],
  ["35", "Basketball 3X3"],
  ["37", "Sumo"],
  ["38", "Virtual sports"],
  ["39", "Handball"],
  ["40", "Politics"],
  ["52", "Motor Sports"],
  ["53", "Baseball"],
  ["54", "Rugby Union"],
  ["55", "Rugby League"],
  ["57", "Darts"],
  ["58", "American Football"],
  ["59", "Snooker"],
  ["62", "Soccer"],
  ["64", "Esports"],
  ["65", "Greyhound Racing"],
  ["66", "Kabaddi"],
  ["67", "Boat Racing"],
  ["68", "Esoccer"],
  ["69", "Wrestling"]
];
var sportNameById = (id) => {
  const hit = SPORTS_LIST.find(([sid]) => String(sid) === String(id));
  return hit ? hit[1] : `Sport ${id}`;
};

// services/BettingConfigService.js
var KEY_BUFFER = "cfg:buffer:v2";
var KEY_MAX_ODDS = "cfg:maxodds:v2";
var KEY_VIRTUAL_LIMITS = "cfg:limits:virtual:v1";
var keyEventLimits = (eventId) => `cfg:limits:event:${eventId}`;
var REDIS_TTL_SEC = 300;
var MICRO_TTL_MS = 2e3;
var micro = /* @__PURE__ */ new Map();
var microGet = (key) => {
  const hit = micro.get(key);
  if (!hit) return void 0;
  if (hit.expires < Date.now()) {
    micro.delete(key);
    return void 0;
  }
  return hit.value;
};
var microSet = (key, value) => {
  micro.set(key, { value, expires: Date.now() + MICRO_TTL_MS });
};
var microDel = (key) => micro.delete(key);
var readThrough = async (key, builder, fallback) => {
  const local = microGet(key);
  if (local !== void 0) return local;
  try {
    const cached = await redisClient_default.get(key);
    if (cached != null) {
      const parsed = JSON.parse(cached);
      microSet(key, parsed);
      return parsed;
    }
  } catch (err) {
    console.warn(`[BettingConfig] redis read failed for ${key}:`, err.message);
  }
  let built;
  try {
    built = await builder();
  } catch (err) {
    console.warn(`[BettingConfig] build failed for ${key}:`, err.message);
    return fallback;
  }
  microSet(key, built);
  redisClient_default.set(key, JSON.stringify(built), "EX", REDIS_TTL_SEC).catch(
    (err) => console.warn(`[BettingConfig] redis write failed for ${key}:`, err.message)
  );
  return built;
};
var num = (v) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
};
var limitSide = (v) => {
  if (v === null || v === void 0 || v === "") return null;
  const n = Number(v);
  return Number.isFinite(n) && n > 0 ? n : null;
};
var readGlobalBuffer = async () => {
  const owner = await Owner_default.findOne({ attributes: ["platform_configurations"], raw: true });
  let config = owner?.platform_configurations;
  if (typeof config === "string") {
    try {
      config = JSON.parse(config);
    } catch {
      config = null;
    }
  }
  return num(config?.buffer_time);
};
var LEGACY_BUFFER_VIEW = { matchodds: "match_odds", bookmaker: "bookmaker", fancy: "fancy" };
var buildBufferMap = async () => {
  const [rows, global] = await Promise.all([
    BetBufferConfig_default.findAll({
      attributes: ["scope", "sport_id", "league_key", "category", "buffer_seconds"],
      raw: true
    }),
    readGlobalBuffer().catch(() => 0)
  ]);
  const map = { global, grid: {}, sports: {} };
  for (const row of rows) {
    const seconds = num(row.buffer_seconds);
    if (row.scope === "sports") {
      if (row.sport_id == null || !row.category) continue;
      const sid = String(row.sport_id);
      const league = String(row.league_key || DEFAULT_LEAGUE_KEY).toLowerCase();
      const isDefault = league === DEFAULT_LEAGUE_KEY;
      if (isDefault && seconds <= 0) continue;
      ((map.grid[sid] ||= {})[league] ||= {})[row.category] = Math.max(seconds, 0);
      if (isDefault && LEGACY_BUFFER_VIEW[row.category]) {
        (map.sports[sid] ||= {})[LEGACY_BUFFER_VIEW[row.category]] = seconds;
      }
    }
  }
  return map;
};
var EMPTY_BUFFERS = { global: 0, grid: {}, sports: {} };
var getBufferMap = () => readThrough(KEY_BUFFER, buildBufferMap, EMPTY_BUFFERS);
var resolveSportsBuffer = (map, sportId, leagueKey, marketKey) => {
  const sport = map?.grid?.[String(sportId)];
  if (!sport) return 0;
  if (leagueKey && leagueKey !== DEFAULT_LEAGUE_KEY) {
    const own = sport?.[leagueKey]?.[marketKey];
    if (own !== void 0) return num(own);
  }
  return num(sport?.[DEFAULT_LEAGUE_KEY]?.[marketKey]);
};
var getSportsBufferSeconds = async (sportId, bet, { allowGlobalFallback = true } = {}) => {
  const map = await getBufferMap();
  const seconds = resolveSportsBuffer(
    map,
    sportId,
    leagueKeyFromName(sportId, bet?.league_name),
    BetBufferConfig_default.marketKeyOf(bet)
  );
  return seconds || (allowGlobalFallback ? num(map?.global) : 0);
};
var buildEventLimitMap = async (eventId) => {
  const rows = await BetLimitOverride_default.findAll({
    where: { scope: "sports", event_id: String(eventId), is_active: true },
    attributes: ["market_id", "min_stake", "max_stake"],
    raw: true
  });
  const map = {};
  for (const row of rows) {
    if (!row.market_id) continue;
    const min = limitSide(row.min_stake);
    const max = limitSide(row.max_stake);
    if (min === null && max === null) continue;
    const entry = {};
    if (min !== null) entry.min = min;
    if (max !== null) entry.max = max;
    map[String(row.market_id)] = entry;
  }
  return map;
};
var getEventLimitMap = (eventId) => {
  if (!eventId) return Promise.resolve({});
  return readThrough(keyEventLimits(eventId), () => buildEventLimitMap(eventId), {});
};
var getMarketLimits = async (eventId, marketId) => {
  if (!eventId || !marketId) return {};
  const map = await getEventLimitMap(eventId);
  return map?.[String(marketId)] || {};
};
var buildMaxOddsMap = async () => {
  const rows = await MaxOddsConfig_default.findAll({
    attributes: ["sport_id", "league_key", "category", "max_odds", "limited_overs_only"],
    raw: true
  });
  const map = {};
  const entryOf = (sid) => map[sid] ||= { name: sportNameById(sid) };
  for (const row of rows) {
    if (!MaxOddsConfig_default.CATEGORIES.includes(row.category)) continue;
    const max = num(row.max_odds);
    const sid = String(row.sport_id);
    const league = String(row.league_key || DEFAULT_LEAGUE_KEY).toLowerCase();
    const cell = {
      max: Math.max(max, 0),
      limited_overs_only: !!row.limited_overs_only && Number(row.sport_id) === MaxOddsConfig_default.LIMITED_OVERS_SPORT_ID
    };
    if (league === DEFAULT_LEAGUE_KEY) {
      if (max <= 0) continue;
      entryOf(sid)[row.category] = cell;
    } else {
      ((entryOf(sid).leagues ||= {})[league] ||= {})[row.category] = cell;
    }
  }
  return map;
};
var getMaxOddsMap = () => readThrough(KEY_MAX_ODDS, buildMaxOddsMap, {});
var getMaxOddsRule = async (sportId, gtype, leagueName) => {
  const category = MaxOddsConfig_default.categoryFromGtype(gtype);
  if (!category) return null;
  const map = await getMaxOddsMap();
  const entry = map?.[String(sportId)];
  if (!entry) return null;
  const leagueKey = leagueKeyFromName(sportId, leagueName);
  const own = leagueKey !== DEFAULT_LEAGUE_KEY ? entry.leagues?.[leagueKey]?.[category] : void 0;
  const cell = own !== void 0 ? own : entry[category];
  const max = num(cell?.max);
  if (max <= 0) return null;
  return {
    max,
    limited_overs_only: !!cell.limited_overs_only,
    sport: entry.name || sportNameById(sportId),
    league: own !== void 0 ? leagueKey : DEFAULT_LEAGUE_KEY
  };
};
var buildVirtualLimitMap = async () => {
  const rows = await VirtualBetLimit_default.findAll({
    attributes: ["sport_id", "league_key", "min_stake", "max_stake"],
    raw: true
  });
  const map = {};
  for (const row of rows) {
    (map[String(row.sport_id)] ||= {})[String(row.league_key)] = {
      min: Math.max(num(row.min_stake), 0),
      max: Math.max(num(row.max_stake), 0)
    };
  }
  return map;
};
var getVirtualLimitMap = () => readThrough(KEY_VIRTUAL_LIMITS, buildVirtualLimitMap, {});
var getVirtualLimit = async (sportId, leagueName) => {
  const leagueKey = leagueKeyFromName(sportId, leagueName);
  if (leagueKey === DEFAULT_LEAGUE_KEY) return null;
  const map = await getVirtualLimitMap();
  const cell = map?.[String(sportId)]?.[leagueKey];
  if (!cell || !(cell.min > 0) && !(cell.max > 0)) return null;
  return { min: num(cell.min), max: num(cell.max), league: leagueKey };
};
var invalidate = async (key) => {
  microDel(key);
  try {
    await redisClient_default.del(key);
  } catch (err) {
    console.warn(`[BettingConfig] redis del failed for ${key}:`, err.message);
  }
};
var invalidateBuffers = () => invalidate(KEY_BUFFER);
var invalidateEventLimits = (eventId) => invalidate(keyEventLimits(eventId));
var invalidateMaxOdds = () => invalidate(KEY_MAX_ODDS);
var invalidateVirtualLimits = () => invalidate(KEY_VIRTUAL_LIMITS);
var BettingConfigService_default = {
  getBufferMap,
  getSportsBufferSeconds,
  getEventLimitMap,
  getMarketLimits,
  getMaxOddsMap,
  getMaxOddsRule,
  getVirtualLimitMap,
  getVirtualLimit,
  invalidateVirtualLimits,
  KEY_VIRTUAL_LIMITS,
  invalidateBuffers,
  invalidateEventLimits,
  invalidateMaxOdds,
  KEY_BUFFER,
  KEY_MAX_ODDS,
  keyEventLimits
};

// services/CricketService.js
init_redisClient();
import axios from "axios";
import dotenv3 from "dotenv";
import { Op } from "sequelize";

// helper/marketListStore.js
init_redisClient();
var TTL_SEC = 15 * 60 * 60;
var MISS_LIMIT = 10;
var MISS_WINDOW_MS = 30 * 1e3;
var REWRITE_MS = 60 * 1e3;
var listKey = (gmid) => `marketlist:${gmid}`;
var missKey = (gmid) => `marketlist:${gmid}:miss`;
var lastWrite = /* @__PURE__ */ new Map();
var lastMissAt = /* @__PURE__ */ new Map();
async function recordMarkets(gmid, markets) {
  if (!gmid || !Array.isArray(markets)) return;
  const rows = markets.filter((m) => m && m.mid != null && m.mname).map((m) => ({ mid: String(m.mid), mname: String(m.mname), sno: m.sno ?? null }));
  if (!rows.length) return;
  const sig = JSON.stringify(rows);
  const prev = lastWrite.get(String(gmid));
  if (prev && prev.sig === sig && Date.now() - prev.at < REWRITE_MS) return;
  lastWrite.set(String(gmid), { sig, at: Date.now() });
  lastMissAt.delete(String(gmid));
  const key = listKey(gmid);
  const fields = rows.flatMap((r) => [r.mid, JSON.stringify(r)]);
  const [, [, ttl]] = await redisClient_default.multi().hset(key, ...fields).ttl(key).del(missKey(gmid)).exec();
  if (ttl === -1) await redisClient_default.expire(key, TTL_SEC);
}
async function recordMiss(gmid) {
  if (!gmid) return;
  const now = Date.now();
  if (now - (lastMissAt.get(String(gmid)) || 0) < MISS_WINDOW_MS) return;
  lastMissAt.set(String(gmid), now);
  const [[, misses]] = await redisClient_default.multi().incr(missKey(gmid)).expire(missKey(gmid), TTL_SEC).exec();
  if (misses >= MISS_LIMIT) {
    await redisClient_default.del(listKey(gmid), missKey(gmid));
    lastWrite.delete(String(gmid));
  }
}
async function getStoredMarkets(gmid) {
  const hash2 = await redisClient_default.hgetall(listKey(gmid));
  return Object.values(hash2 || {}).map((v) => {
    try {
      return JSON.parse(v);
    } catch {
      return null;
    }
  }).filter(Boolean);
}

// model/user/FanWin.js
init_db();
import { DataTypes as DataTypes14 } from "sequelize";
var FanWin = db_default.define(
  "FanWin",
  {
    id: {
      type: DataTypes14.INTEGER,
      autoIncrement: true,
      primaryKey: true
    },
    user_id: {
      type: DataTypes14.BIGINT,
      allowNull: false,
      field: "user_id"
      // maps correctly to DB
    },
    fancyname: {
      type: DataTypes14.STRING(255),
      allowNull: false
    },
    selection: {
      type: DataTypes14.STRING(100),
      allowNull: false
    },
    runsodds: {
      type: DataTypes14.DECIMAL(10, 4),
      // allows 1.4600
      allowNull: false
    },
    payout: {
      type: DataTypes14.DECIMAL(15, 2),
      allowNull: false
    },
    created_at: {
      type: DataTypes14.DATE,
      allowNull: true,
      defaultValue: DataTypes14.NOW
    },
    eventid: {
      type: DataTypes14.TEXT,
      allowNull: false
    },
    matchid: {
      type: DataTypes14.STRING(100),
      allowNull: false
    }
  },
  {
    tableName: "fanwins",
    schema: "public",
    timestamps: false
  }
);
var FanWin_default = FanWin;

// model/user/MarketWin.js
init_db();
import { DataTypes as DataTypes15 } from "sequelize";
var MarketWin = db_default.define(
  "MarketWin",
  {
    id: {
      type: DataTypes15.BIGINT,
      autoIncrement: true,
      primaryKey: true
    },
    totalbets: {
      type: DataTypes15.BIGINT,
      allowNull: false
    },
    matchid: {
      type: DataTypes15.TEXT,
      allowNull: false
    },
    eventid: {
      type: DataTypes15.TEXT,
      allowNull: false
    },
    team1ex: {
      type: DataTypes15.DECIMAL(18, 2),
      allowNull: false
    },
    team2ex: {
      type: DataTypes15.DECIMAL(18, 2),
      allowNull: false
    },
    drawex: {
      type: DataTypes15.DECIMAL(18, 2),
      allowNull: true
    },
    winteam: {
      type: DataTypes15.TEXT,
      allowNull: false
    },
    matchname: {
      type: DataTypes15.TEXT,
      allowNull: false
    },
    payout: {
      type: DataTypes15.DECIMAL(18, 2),
      allowNull: false
    },
    created_at: {
      type: DataTypes15.DATE,
      allowNull: true,
      defaultValue: DataTypes15.NOW
    },
    user_id: {
      type: DataTypes15.BIGINT,
      allowNull: true
    },
    created_at: {
      type: DataTypes15.DATE,
      allowNull: true,
      defaultValue: DataTypes15.NOW
    }
  },
  {
    tableName: "marketwins",
    schema: "public",
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at"
  }
);
var MarketWin_default = MarketWin;

// services/CricketService.js
dotenv3.config();
var BASE_URL = process.env.DIAMOND_BASE_URL;
var API_KEY = process.env.DIAMOND_API_KEY;
var SPORTS_API_VERSION = process.env.SPORTS_API_VERSION || "v2";
var AVRKHUB_SPORTS_BASE_URL = process.env.AVRKHUB_SPORTS_BASE_URL;
var AVRKHUB_SPORTS_KEY = process.env.AVRKHUB_SPORTS_KEY;
var CACHE_TTL = 2;
console.log("DEBUG: BASE_URL =", BASE_URL);
console.log("DEBUG: API_KEY =", API_KEY ? "Loaded" : "Missing");
var getCachedData = async (key, fetchFunction) => {
  let cachedData = null;
  try {
    const cached = await redisClient_default.get(key);
    if (cached) {
      console.log(`\u26A1 Serving from cache: ${key}`);
      return JSON.parse(cached);
    }
  } catch (err) {
    console.error(`\u274C Redis Cache Error for ${key}:`, err.message);
  }
  try {
    console.log(`[Trace] Cache miss for ${key}, fetching...`);
    const data = await fetchFunction();
    redisClient_default.set(key, JSON.stringify(data), "EX", CACHE_TTL).catch(
      (err) => console.error(`\u274C Failed to set cache for ${key}:`, err.message)
    );
    console.log(`\u{1F310} Fetched from API & Cached: ${key}`);
    return data;
  } catch (err) {
    console.error(`\u274C API Error for ${key}:`, err.message);
    throw err;
  }
};
var PROBE_TTL_MS = 5 * 60 * 1e3;
var scoreProbeCache = /* @__PURE__ */ new Map();
var probeScoreUrl = async (url) => {
  const hit = scoreProbeCache.get(url);
  if (hit && Date.now() - hit.at < PROBE_TTL_MS) return hit.ok;
  let ok = false;
  try {
    const res = await axios.get(url, {
      timeout: 4e3,
      maxRedirects: 3,
      headers: {
        Accept: "text/html,application/xhtml+xml;q=0.9,*/*;q=0.8",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
      },
      validateStatus: (s) => s >= 200 && s < 400
    });
    ok = !!res;
  } catch {
    ok = false;
  }
  scoreProbeCache.set(url, { ok, at: Date.now() });
  return ok;
};
var PRIVATE_DATA_TTL_MS = Number(process.env.PRIVATE_DATA_TTL_MS) || 250;
var privateDataCache = /* @__PURE__ */ new Map();
var privateDataInFlight = /* @__PURE__ */ new Map();
async function fetchPrivateDataV2(gmid, sid) {
  const response = await axios.get(`${AVRKHUB_SPORTS_BASE_URL}/gamedataPrivate`, {
    params: { gmid, etid: sid, key: AVRKHUB_SPORTS_KEY },
    timeout: 8e3
  });
  let innerData = response.data?.data || [];
  if (innerData && !Array.isArray(innerData) && Array.isArray(innerData.data)) {
    innerData = innerData.data;
  }
  if (Array.isArray(innerData) && innerData.length > 0) {
    redisClient_default.setex(`odds:${gmid}`, 3, JSON.stringify(innerData)).catch(() => {
    });
    recordMarkets(gmid, innerData).catch(() => {
    });
  } else if (response.data?.success === false && /\b404\b/.test(`${response.data?.status ?? ""} ${response.data?.msg ?? ""} ${response.data?.error ?? ""}`)) {
    recordMiss(gmid).catch(() => {
    });
  }
  return { success: true, data: innerData };
}
async function sharedPrivateDataV2(gmid, sid) {
  const key = `${gmid}:${sid}`;
  const hit = privateDataCache.get(key);
  if (hit && Date.now() - hit.at < PRIVATE_DATA_TTL_MS) return structuredClone(hit.value);
  let pending = privateDataInFlight.get(key);
  if (!pending) {
    pending = fetchPrivateDataV2(gmid, sid).then((value) => {
      privateDataCache.set(key, { at: Date.now(), value });
      return value;
    }).finally(() => privateDataInFlight.delete(key));
    privateDataInFlight.set(key, pending);
  }
  return structuredClone(await pending);
}
setInterval(() => {
  const cutoff = Date.now() - 60 * 1e3;
  for (const [key, entry] of privateDataCache) if (entry.at < cutoff) privateDataCache.delete(key);
}, 60 * 1e3).unref();
var CricketService = {
  // fetchCricketData: async (id) => {
  //   // console.log("======>>>>fetch cricket all data for id : "+id+ "===="+ API_KEY+ "===="+BASE_URL);
  //   if (!id) {
  //     throw new Error("ID is required to fetch cricket data");
  //   }
  //   const key = `cricket_data_${id}`;
  //   return await getCachedData(key, async () => {
  //     const response = await axios.get(`${BASE_URL}/esid`, {
  //       headers: { Accept: "*/*" },
  //       params: { sid: id, key: API_KEY },
  //       timeout: 6000 // 3s timeout
  //     });
  //     return response.data;
  //   });
  // },
  fetchCricketData: async (id) => {
    try {
      const sid = id;
      if (!sid) {
        throw new Error("sid is required to fetch cricket data");
      }
      if (SPORTS_API_VERSION === "v2") {
        const response = await axios.get(`${AVRKHUB_SPORTS_BASE_URL}/highlighthomePrivate`, {
          params: { etid: id, key: AVRKHUB_SPORTS_KEY },
          timeout: 8e3,
          validateStatus: (s) => s >= 200 && s < 300 || s === 404
        });
        if (response.status === 404) {
          const empty = { success: true, data: { t1: [], t2: [] } };
          redisClient_default.set(`alleventss:${id}`, JSON.stringify(empty.data), "EX", 60).catch(() => {
          });
          return empty;
        }
        const rawData = response.data?.data?.data || response.data?.data || {};
        const t1 = Array.isArray(rawData.t1) ? rawData.t1 : [];
        const t2 = Array.isArray(rawData.t2) ? rawData.t2 : [];
        const finalData = {
          success: true,
          data: {
            t1: t1.map((e) => ({ ...e, etid: parseInt(id) })),
            t2: t2.map((e) => ({ ...e, etid: parseInt(id) }))
          }
        };
        redisClient_default.set(`alleventss:${id}`, JSON.stringify(finalData.data), "EX", 120).catch(() => {
        });
        return finalData;
      }
      const dataStr = await redisClient_default.get(`allevents:${sid}`);
      if (!dataStr) {
        return {
          success: true,
          data: { t1: [], t2: [] }
        };
      }
      let parsedData;
      try {
        parsedData = JSON.parse(dataStr);
      } catch (e) {
        console.error("Error parsing redis data", e);
        return {
          success: true,
          data: { t1: [], t2: [] }
        };
      }
      if (parsedData && typeof parsedData === "object" && !Array.isArray(parsedData) && Array.isArray(parsedData.t1)) {
        return {
          success: true,
          data: {
            t1: parsedData.t1 || [],
            t2: parsedData.t2 || []
          }
        };
      }
      if (Array.isArray(parsedData)) {
        const t1 = parsedData.filter(
          (e) => e?.status === "OPEN" && e?.gscode === 1
        );
        const t2 = parsedData.filter(
          (e) => e?.status === "SUSPENDED" || e?.gscode === 0
        );
        return {
          success: true,
          data: { t1, t2 }
        };
      }
      return {
        success: true,
        data: { t1: [], t2: [] }
      };
    } catch (err) {
      console.error(err);
      throw err;
    }
  },
  GetallSportsdata: async () => {
    const key = `all_sports_data`;
    return await getCachedData(key, async () => {
      const response = await axios.get(`${BASE_URL}/allSportid`, {
        headers: { Accept: "*/*" },
        params: { key: API_KEY },
        timeout: 6e3
      });
      return response?.data?.data;
    });
  },
  // GetMatchPrivateData: async (gmid, sid) => {
  //   // console.log("======>>>>fetch match private data for id : "+ sid+", gmid : "+gmid);
  //   if (!gmid || !sid) {
  //     throw new Error("Game ID is required to fetch match private data");
  //   }
  //   // Cache key combination of gmid and sid
  //   const key = `match_private_${gmid}_${sid}`;
  //   return await getCachedData(key, async () => {
  //     const response = await axios.get(`${BASE_URL}/gamedataPrivate`, {
  //       headers: { Accept: "*/*" },
  //       params: { gmid: gmid, etid: sid },
  //       timeout: 6000
  //     });
  //     // console.log("======>>>>Response  match private data for id : "+ sid+", gmid : "+gmid+"==response=="+ response.data);
  //     return response.data?.data;
  //   });
  // },
  GetMatchPrivateData: async (gmid, sid) => {
    if (!gmid || !sid) {
      throw new Error("gmid and sid are required to fetch match private data");
    }
    if (process.env.COUNT_CALLS === "true" && typeof isSampling !== "undefined" && isSampling) {
      requestCounter++;
    }
    try {
      if (SPORTS_API_VERSION === "v2") {
        return await sharedPrivateDataV2(gmid, sid);
      }
      const redisKey = `odds:${gmid}`;
      const cached = await redisClient_default.get(redisKey);
      if (!cached) {
        return { success: true, data: [] };
      }
      const parsedData = JSON.parse(cached);
      return { success: true, data: parsedData };
    } catch (error) {
      if (error?.response?.status === 404) recordMiss(gmid).catch(() => {
      });
      console.error(
        "GetMatchPrivateData(redis) error:",
        error.message
      );
      throw error;
    }
  },
  getSportDataById: async (gmid, sid) => {
    if (!sid || !gmid) {
      throw new Error("Sport ID is required to fetch data");
    }
    const key = `sport_data_${gmid}_${sid}`;
    return await getCachedData(key, async () => {
      if (SPORTS_API_VERSION === "v2") {
        const list = await CricketService.fetchCricketData(sid);
        const t1 = Array.isArray(list?.data?.t1) ? list.data.t1 : [];
        const t2 = Array.isArray(list?.data?.t2) ? list.data.t2 : [];
        const match = [...t2, ...t1].find((m) => String(m.gmid) === String(gmid));
        return { data: match ? [match] : [] };
      }
      const response = await axios.get(`${AVRKHUB_SPORTS_BASE_URL}/getDetailsData`, {
        headers: { Accept: "*/*" },
        params: { sid, gmid, key: API_KEY },
        timeout: 8e3
      });
      return response.data;
    });
  },
  fetchLiveStream: async (gmid) => {
    if (!gmid) {
      throw new Error("Game ID is required to fetch live stream data");
    }
    const key = `live_stream_${gmid}`;
    return await getCachedData(key, async () => {
      const response = await axios.get(`${BASE_URL}/tv_url`, {
        headers: { Accept: "*/*" },
        params: { gmid, key: API_KEY },
        timeout: 6e3
      });
      return response.data;
    });
  },
  fetchScoreCard: async (gmid, sid) => {
    if (!gmid) {
      throw new Error("gmid is required to fetch scorecard");
    }
    if (!sid) {
      throw new Error("sid is required to fetch scorecard");
    }
    if (SPORTS_API_VERSION === "v2") {
      const key2 = `scorecard_v2_${gmid}_${sid}`;
      return await getCachedData(key2, async () => {
        const response = await axios.get(`${AVRKHUB_SPORTS_BASE_URL}/scorecard`, {
          params: { gmid, etid: sid, key: AVRKHUB_SPORTS_KEY },
          timeout: 8e3
        });
        const data = response.data;
        if (data?.scorecard_url) {
          const covered = await probeScoreUrl(data.scorecard_url);
          return { score_url: covered ? data.scorecard_url : null };
        }
        return data;
      });
    }
    const key = `scorecard_${gmid}_${sid}`;
    return await getCachedData(key, async () => {
      const response = await axios.get(`${BASE_URL}/score`, {
        headers: { Accept: "*/*" },
        params: { gtv: gmid, key: API_KEY, sid, sportid: sid },
        timeout: 6e3
      });
      return response.data;
    });
  },
  fetchTreeData: async () => {
    if (SPORTS_API_VERSION === "v2") {
      const key2 = `tree_data_v2`;
      return await getCachedData(key2, async () => {
        const response = await axios.get(`${AVRKHUB_SPORTS_BASE_URL}/treedata`, {
          params: { key: AVRKHUB_SPORTS_KEY },
          timeout: 8e3
        });
        return response.data;
      });
    }
    const key = `tree_data`;
    return await getCachedData(key, async () => {
      const response = await axios.get(`${BASE_URL}/tree`, {
        headers: { Accept: "*/*" },
        params: { key: API_KEY },
        timeout: 6e3
      });
      return response.data;
    });
  },
  GetResult: async (sid, event_id, event_name, market_id, market_name) => {
    if (!sid) {
      throw new Error("sid is required");
    } else if (!event_id || !event_name || !market_id || !market_name) {
      throw new Error(
        "Event ID, Event Name, Market ID, Market Name and Market Type are required"
      );
    }
    const payload = {
      event_id,
      event_name,
      market_id,
      market_name
    };
    try {
      const response = await axios.post(
        `${BASE_URL}/get-result`,
        // no such endpoint is available in api , neeed to modify this one 
        payload,
        {
          headers: {
            Accept: "*/*",
            "Content-Type": "application/json"
          },
          params: {
            sid,
            key: API_KEY
          }
        }
      );
      return response.data;
    } catch (error) {
      if (axios.isAxiosError(error)) {
        console.error("\u274C Axios error :", {
          message: error.message,
          status: error.response?.status,
          data: error.response?.data
        });
        throw new Error(
          error.response?.data?.message || `Request failed with status ${error.response?.status}`
        );
      } else {
        console.error("\u274C Unknown error ", error);
        throw new Error("An unexpected error occurred.");
      }
    }
  },
  getAllSportsBets: async () => {
    const bets = await SportsBet_default.findAll();
    return bets;
  },
  /**
   * A user's own sports bets, filtered by settlement state.
   *
   * `status` mirrors the Current Bets radios:
   *   'matchbet'   -> still open and matched   (the page default)
   *   'unmatchbet' -> still open but unmatched
   *   'deletebet'  -> admin soft-cancelled
   *   'all'        -> no settlement filter (admin bet-history callers)
   *
   * Open-ness keys off result_status, NOT status: settlement stamps
   * status='closed' + a terminal result_status, and a bet can carry the
   * terminal result before `status` catches up (see systemTracker/verifier.js).
   * Admin deletion soft-cancels both columns to 'cancelled' and never removes
   * the row, so 'cancelled' has to be excluded from the open set explicitly.
   */
  getSportsBetsByUserId: async (user_id, { page = 1, limit = 10, search = "", betType = "all", status = "matchbet" } = {}) => {
    const offset = (page - 1) * limit;
    const where = { user_id };
    const and = [];
    if (betType !== "all") {
      const side = String(betType).toLowerCase();
      const aliases = side === "back" ? ["back", "yes"] : side === "lay" ? ["lay", "no"] : null;
      if (aliases) {
        and.push({ [Op.or]: aliases.map((v) => ({ bet_type: { [Op.iLike]: v } })) });
      } else {
        where.bet_type = betType;
      }
    }
    if (status === "deletebet") {
      and.push({
        [Op.or]: [
          { status: { [Op.iLike]: "cancelled" } },
          { result_status: { [Op.iLike]: "cancelled" } }
        ]
      });
    } else if (status !== "all") {
      and.push({
        [Op.or]: [
          { result_status: null },
          { result_status: { [Op.iLike]: "pending" } }
        ]
      });
      and.push({
        [Op.or]: [
          { status: null },
          { status: { [Op.notILike]: "closed" } }
        ]
      });
      and.push({ unmatched: status === "unmatchbet" });
    }
    if (search) {
      and.push({
        [Op.or]: [
          { match_title: { [Op.iLike]: `%${search}%` } },
          { selection_name: { [Op.iLike]: `%${search}%` } },
          { market_type: { [Op.iLike]: `%${search}%` } }
        ]
      });
    }
    if (and.length) {
      where[Op.and] = and;
    }
    const { count, rows } = await SportsBet_default.findAndCountAll({
      where,
      limit: parseInt(limit),
      offset: parseInt(offset),
      order: [["id", "ASC"]]
    });
    const totalStake = await SportsBet_default.sum("stake_amount", { where });
    return {
      rows,
      pagination: {
        total: count,
        page: parseInt(page),
        limit: parseInt(limit),
        total_pages: Math.ceil(count / limit),
        total_stake: Number(totalStake || 0)
      }
    };
  },
  getWinsByUserId: async (user_id) => {
    const fanWins = await FanWin_default.findAll({ where: { user_id } });
    const marketWins = await MarketWin_default.findAll({ where: { user_id } });
    const allWins = [{ marketWins }, { fanWins }];
    return allWins;
  }
};
var CricketService_default = CricketService;

// jobs/betLimitCleanupJob.js
var GRACE_MINUTES = Number(process.env.BET_LIMIT_GRACE_MINUTES) || 4;
var collectEventIds = (nodes, out) => {
  for (const node of nodes || []) {
    if (node?.gmid) out.add(String(node.gmid));
    if (Array.isArray(node?.children)) collectEventIds(node.children, out);
  }
  return out;
};
var runBetLimitCleanup = async () => {
  const rows = await BetLimitOverride_default.findAll({
    where: { scope: "sports" },
    attributes: ["id", "sport_id", "event_id", "ended_at"],
    raw: true
  });
  if (!rows.length) return { checked: 0, stamped: 0, revived: 0, deleted: 0 };
  const sportIds = [...new Set(rows.map((r) => r.sport_id).filter((id) => id != null))];
  const liveBySport = /* @__PURE__ */ new Map();
  await Promise.all(sportIds.map(async (sportId) => {
    try {
      const board = await CricketService_default.fetchCricketData(sportId);
      const t1 = Array.isArray(board?.data?.t1) ? board.data.t1 : [];
      const t2 = Array.isArray(board?.data?.t2) ? board.data.t2 : [];
      const ids = collectEventIds([...t1, ...t2], /* @__PURE__ */ new Set());
      if (ids.size) liveBySport.set(String(sportId), ids);
    } catch (err) {
      console.warn(`[betLimitCleanup] board fetch failed for sport ${sportId}:`, err.message);
    }
  }));
  const now = Date.now();
  const cutoff = new Date(now - GRACE_MINUTES * 60 * 1e3);
  const toStamp = [];
  const toRevive = [];
  const toDelete = [];
  const affectedEvents = /* @__PURE__ */ new Set();
  for (const row of rows) {
    const live = row.sport_id == null ? null : liveBySport.get(String(row.sport_id));
    if (!live) continue;
    if (live.has(String(row.event_id))) {
      if (row.ended_at) toRevive.push(row.id);
      continue;
    }
    if (!row.ended_at) {
      toStamp.push(row.id);
    } else if (new Date(row.ended_at) <= cutoff) {
      toDelete.push(row.id);
      affectedEvents.add(String(row.event_id));
    }
  }
  if (toRevive.length) {
    await BetLimitOverride_default.update({ ended_at: null }, { where: { id: { [Op2.in]: toRevive } } });
  }
  if (toStamp.length) {
    await BetLimitOverride_default.update({ ended_at: new Date(now) }, { where: { id: { [Op2.in]: toStamp } } });
  }
  if (toDelete.length) {
    await BetLimitOverride_default.destroy({ where: { id: { [Op2.in]: toDelete } } });
    await Promise.all(
      [...affectedEvents].map((eventId) => BettingConfigService_default.invalidateEventLimits(eventId))
    );
    console.log(
      `[betLimitCleanup] removed ${toDelete.length} override(s) from ${affectedEvents.size} finished event(s)`
    );
  }
  return {
    checked: rows.length,
    stamped: toStamp.length,
    revived: toRevive.length,
    deleted: toDelete.length
  };
};
cron.schedule("* * * * *", async () => {
  try {
    await runBetLimitCleanup();
  } catch (err) {
    console.error("[betLimitCleanup] run failed:", err.message);
  }
});
console.log(`[betLimitCleanup] scheduled \u2014 finished-match overrides purged after ${GRACE_MINUTES} min`);

// middleware/authMiddleware.js
import jwt from "jsonwebtoken";

// helper/tokenBlacklist.js
import crypto from "crypto";
import { Op as Op3 } from "sequelize";

// model/admin/TokenBlacklist.js
init_db();
import { DataTypes as DataTypes16 } from "sequelize";
var TokenBlacklist = db_default.define("TokenBlacklist", {
  token: {
    type: DataTypes16.STRING,
    allowNull: false,
    unique: true
  },
  expiresAt: {
    type: DataTypes16.DATE,
    allowNull: false
  }
});
var TokenBlacklist_default = TokenBlacklist;

// helper/tokenBlacklist.js
var hash = (token) => crypto.createHash("sha256").update(String(token)).digest("hex");
var isTokenBlacklisted = async (token) => {
  const row = await TokenBlacklist_default.findOne({
    where: { token: { [Op3.in]: [hash(token), token] } }
  });
  return !!row;
};

// model/Executive.js
init_db();
import { DataTypes as DataTypes17 } from "sequelize";
var Executive = db_default.define(
  "Executive",
  {
    id: {
      type: DataTypes17.INTEGER,
      autoIncrement: true,
      primaryKey: true
    },
    parent_type: {
      type: DataTypes17.ENUM("OWNER", "STAFF"),
      allowNull: false
    },
    parent_id: {
      type: DataTypes17.INTEGER,
      allowNull: false
    },
    username: {
      type: DataTypes17.STRING,
      allowNull: false,
      unique: true
    },
    email: {
      type: DataTypes17.STRING,
      allowNull: true,
      unique: true
    },
    full_name: {
      type: DataTypes17.STRING,
      allowNull: true
    },
    password: {
      type: DataTypes17.STRING,
      allowNull: false
    },
    role: {
      type: DataTypes17.STRING,
      allowNull: false
    },
    permissions: {
      type: DataTypes17.JSON,
      allowNull: false,
      defaultValue: {}
    },
    active: {
      type: DataTypes17.BOOLEAN,
      defaultValue: true
    }
  },
  {
    tableName: "executives",
    timestamps: true
  }
);
var Executive_default = Executive;

// middleware/authMiddleware.js
var authMiddleware = async (req, res, next) => {
  try {
    const authHeader = req.header("Authorization");
    if (!authHeader) return res.status(401).json({ error: "Access denied. No token provided." });
    const token = authHeader.replace("Bearer ", "").trim();
    if (!token || token === "null" || token === "undefined") {
      return res.status(401).json({ error: "Access denied. No valid token provided." });
    }
    if (await isTokenBlacklisted(token)) {
      return res.status(401).json({ error: "Token invalidated. Please log in again." });
    }
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    let actor = decoded.actor;
    let account = decoded.account;
    if (!actor || !account) {
      if (decoded.owner_id) {
        actor = { type: "OWNER", id: decoded.owner_id };
        account = { type: "OWNER", id: decoded.owner_id };
      } else if (decoded.staff_id) {
        actor = { type: "STAFF", id: decoded.staff_id };
        account = { type: "STAFF", id: decoded.staff_id };
      } else if (decoded.user_id) {
        actor = { type: "USER", id: decoded.user_id };
        account = { type: "USER", id: decoded.user_id };
      }
    }
    req.user = {
      actor,
      account,
      role: decoded.role?.toUpperCase(),
      level: decoded.level || null,
      username: decoded.username || null,
      permissions: decoded.permissions || null
    };
    if (req.user.actor?.type === "EXECUTIVE") {
      const executive = await Executive_default.findByPk(req.user.actor.id);
      if (!executive || executive.active === false) {
        return res.status(401).json({ error: "Executive account is disabled. Access denied." });
      }
      req.user.permissions = executive.permissions || {};
      req.user.role = (executive.role || req.user.role || "").toUpperCase();
      const parent = executive.parent_type === "OWNER" ? await Owner_default.findByPk(executive.parent_id) : await Staff_default.findByPk(executive.parent_id);
      if (!parent) {
        return res.status(401).json({ error: "Parent account not found. Access denied." });
      }
      if (executive.parent_type === "STAFF" && parent.active === false) {
        return res.status(401).json({ error: "Account is inactive. Access denied." });
      }
      req.user.username = parent.username;
      req.user.level = parent.level ?? null;
      console.log(
        `\u2705 Authenticated | actor=EXECUTIVE:${executive.id} | account=${req.user.account.type}:${req.user.account.id} | role=${req.user.role} | as=${parent.username}`
      );
      return next();
    }
    if (req.user.account?.type === "USER") {
      const user = await User_default.findByPk(req.user.account.id);
      if (!user || user.status !== "Active") {
        return res.status(401).json({ error: "Account is inactive. Access denied." });
      }
      if (user.login_id && decoded.sid !== user.login_id) {
        return res.status(401).json({ error: "Session expired. You have been logged out because your account was used on another device." });
      }
      if (user.is_demo && user.demo_expires_at && new Date(user.demo_expires_at).getTime() <= Date.now()) {
        return res.status(401).json({ error: "Demo session expired. Please login again.", demoExpired: true });
      }
      req.user.isDemo = !!user.is_demo;
    }
    if (req.user.account?.type === "STAFF") {
      const staff = await Staff_default.findByPk(req.user.account.id);
      if (!staff || req.user.role !== "OWNER" && !staff.active) {
        return res.status(401).json({ error: "Account is inactive. Access denied." });
      }
      if (staff.login_id && decoded.sid !== staff.login_id) {
        return res.status(401).json({ error: "Session expired. You have been logged out because your account was used on another device." });
      }
    }
    if (req.user.account?.type === "OWNER") {
      const owner = await Owner_default.findByPk(req.user.account.id);
      if (owner && owner.login_id && decoded.sid !== owner.login_id) {
        return res.status(401).json({ error: "Session expired. You have been logged out because your account was used on another device." });
      }
    }
    console.log(
      `\u2705 Authenticated | actor=${req.user.actor.type}:${req.user.actor.id} | account=${req.user.account.type}:${req.user.account.id} | role=${req.user.role}`
    );
    next();
  } catch (err) {
    console.error("\u274C authMiddleware error:", err.message);
    if (err.name === "TokenExpiredError") {
      return res.status(401).json({ error: "Token expired. Please log in again." });
    }
    return res.status(401).json({ error: "Invalid or malformed token. Please log in again." });
  }
};
var authMiddleware_default = authMiddleware;

// middleware/dateRangeMiddleware.js
var MS_PER_DAY = 1e3 * 60 * 60 * 24;
var maxDateRange = (maxDays) => (req, res, next) => {
  try {
    const { fromDate, toDate } = req.body || {};
    const from = new Date(fromDate);
    const to = new Date(toDate);
    if (!fromDate || !toDate || isNaN(from.getTime()) || isNaN(to.getTime())) {
      return res.status(400).json({ success: false, message: "fromDate and toDate are required (YYYY-MM-DD)." });
    }
    const rangeDays = (to - from) / MS_PER_DAY;
    if (rangeDays < 0) {
      return res.status(400).json({ success: false, message: "fromDate cannot be after toDate." });
    }
    if (rangeDays > maxDays) {
      return res.status(400).json({ success: false, message: `Date range cannot be more than ${maxDays} days.` });
    }
    next();
  } catch (error) {
    console.error("\u274C [maxDateRange] error:", error);
    return res.status(500).json({ success: false, message: "Server error while validating date range." });
  }
};

// middleware/permissionMiddleware.js
var requireOwner = (req, res, next) => {
  if (req.user?.actor?.type !== "OWNER") {
    return res.status(403).json({
      success: false,
      message: "Access denied. Owner only."
    });
  }
  return next();
};
var requireBackoffice = (req, res, next) => {
  const actorType = req.user?.actor?.type;
  if (actorType !== "OWNER" && actorType !== "STAFF" && actorType !== "EXECUTIVE") {
    return res.status(403).json({
      success: false,
      message: "Access denied. Back-office accounts only."
    });
  }
  return next();
};

// constants/messages.js
var MESSAGES = {
  AUTH: {
    CREDENTIALS_REQUIRED: "Email/Username and password are required",
    LOGIN_SUCCESS: "Login successful",
    MISSING_USERID_OR_OTP: "Missing userId or OTP",
    TWO_FA_VERIFIED: "2FA Verified",
    MISSING_USERID: "Missing userId",
    // Same reference toast as OTP_SENT — resend announces the code the
    // same way the initial generation does.
    OTP_RESENT: "Sucessfully Code Generate.",
    TOKEN_NOT_PROVIDED: "Token not provided",
    LOGOUT_SUCCESS: "Logged out successfully.",
    PASSWORDS_REQUIRED: "Current and new passwords are required",
    PASSWORD_CHANGED: "Password changed successfully",
    USER_ID_MISSING: "user_id missing (send it in the payload or use a valid token)",
    USER_NOT_FOUND: "User not exist",
    ACCOUNT_INACTIVE: "Account is inactive. Please contact support.",
    // This account or a staff above it is inactive — player + staff login
    // (helper/accountLockChain.js). Also the forceLogout toast on a lock.
    USER_LOCKED_CONTACT_UPLINE: "User is locked. Please contact upper level.",
    PASSWORD_WRONG: "Password is wrong",
    // Single-session enforcement: this account just signed in elsewhere,
    // so login_id changed and this token is already dead (authMiddleware).
    // Pushed over the socket so the old screen reacts at once instead of
    // waiting for its next request to 401 — i.e. instead of needing a reload.
    SESSION_TAKEN_OVER: "You have been logged out because this account signed in on another device.",
    // Player toast, shown on a phone: the long form above wrapped to two
    // lines and covered the top of the login page (user, 2026-09-15). The
    // player is already staring at the login screen, so "logged out" adds
    // nothing — only the reason does. Admin keeps the full sentence; it has
    // the width for it.
    SESSION_TAKEN_OVER_PLAYER: "Logged in on another device",
    // Reference-site wording, verbatim (typo included) — the 2FA page's
    // landing toast prints this. Player login only; admin keeps its own
    // ADMIN.AUTH.OTP_SENT below.
    OTP_SENT: "Sucessfully Code Generate.",
    LOGIN_FAILED: "Failed to login user",
    // Demo login (POST /user/demo-login) — a real throwaway account.
    DEMO_LOGIN_SUCCESS: "Demo login successful",
    DEMO_DISABLED: "Demo login is not available right now",
    DEMO_RATE_LIMITED: "Too many demo logins from this device. Please try again later.",
    DEMO_EXPIRED: "Demo session expired. Please login again.",
    OTP_EXPIRED_OR_NOT_REQUESTED: "OTP expired or not requested",
    INVALID_OTP: "Invalid OTP",
    // Login 2FA: a generated code is good for MAX_LOGIN_OTP_ATTEMPTS tries.
    // Reference text captured 2026-09-20 (iOS toast): "token code not valid.
    // You have 5attempt left" — no space before "attempt", keep it as is,
    // same shape as the transaction-code line below.
    TOKEN_NOT_VALID_ATTEMPTS_LEFT: (n) => `token code not valid. You have ${n}attempt left`,
    // ── Telegram bot texts ────────────────────────────────────────────
    // Captured from the reference bot "Securisep Authentication"
    // (screenshot 2026-09-20 4:31): the login code line carries the code
    // AND the username, with "not" bold — the wording Telegram's own login
    // message uses. The reference's own copy has a double space before the
    // username and a space before the full stop; the user asked for those
    // extras to go (2026-09-20), so it is single-spaced here.
    // NOTE: it says "30 sec" while our cached OTP lives 5 minutes; text
    // copied verbatim, see the plan's open question.
    TELEGRAM_LOGIN_CODE: (otp, username) => `<b>Login Code: ${otp} ${username}.</b> Do <b>not</b> give this code to anyone, even if they say they are from Telegram! Its valid for 30 sec.`,
    TELEGRAM_2FA_ENABLED: "2-Step Verification is enabled, Now you can use this bot to login into your account.",
    TELEGRAM_2FA_DISABLED: "2-Step Verification is disabled for your account.",
    OTP_EXPIRED: "OTP expired",
    TWO_FA_FAILED: "2FA Verification failed",
    TWO_FA_NOT_ENABLED: "2FA not enabled",
    LOGOUT_FAILED: "Failed to logout user",
    OTP_RESEND_FAILED: "Failed to resend OTP",
    INCORRECT_CURRENT_PASSWORD: "Password is Wrong",
    // New password identical to the one already on the account.
    PASSWORD_SAME_AS_OLD: "Password Must not be same as previous password.",
    PASSWORD_CHANGE_FAILED: "Failed to change password",
    // Account was created with the "Password Change" box ticked (or its
    // direct parent was) — see helper/passwordChangePermission.js.
    PASSWORD_CHANGE_NOT_ALLOWED: "Password cannot be changed",
    TERMS_AGREE_REQUIRED: "Please agree Terms and Conditions",
    // Reference re-login rule (frontend utils/reloginGuard.js): first login
    // with a different account after a logout is refused with this + reload.
    RELOAD_AND_RETRY: "Please reload page and retry !",
    // Google Authenticator (TOTP) secure auth
    GOOGLE_AUTH_SETUP_READY: "Scan the QR code in Google Authenticator",
    GOOGLE_AUTH_ENABLED: "Google Authenticator enabled successfully",
    GOOGLE_AUTH_DISABLED: "Google Authenticator disabled successfully",
    GOOGLE_AUTH_NOT_SETUP: "Google Authenticator setup not started. Please scan the QR code first.",
    GOOGLE_AUTH_NOT_ENABLED: "Google Authenticator is not enabled on this account",
    GOOGLE_AUTH_INVALID_CODE: "Invalid authentication code. Please try again.",
    GOOGLE_AUTH_CODE_REQUIRED: "6-digit authentication code is required",
    SECURE_AUTH_ALREADY_ENABLED: "Secure auth verification is already enabled. Disable it first.",
    // "Secure Auth Verification App" (Android, offline TOTP) secure auth
    ANDROID_AUTH_PAIR_READY: "Enter this code in your Secure Auth Verification App",
    ANDROID_AUTH_PAIRED: "Account added. Secure auth is now enabled.",
    ANDROID_AUTH_PAIR_INVALID: "This auth code is invalid or has expired. Please generate a new one.",
    ANDROID_AUTH_CODE_REQUIRED: "6-digit auth code is required",
    ANDROID_AUTH_CREDENTIALS_REQUIRED: "Please enter your username and password",
    ANDROID_AUTH_CREDENTIALS_INVALID: "Username or password is not valid for this auth code.",
    ANDROID_AUTH_NOT_PAIRED: "Secure Auth Verification App is not paired yet. Generate an auth code first.",
    ANDROID_AUTH_NOT_ENABLED: "Secure Auth Verification App is not enabled on this account",
    ANDROID_AUTH_ENABLED: "Secure Auth Verification App enabled successfully",
    ANDROID_AUTH_DISABLED: "Secure Auth Verification App disabled successfully",
    ANDROID_AUTH_TOO_MANY_ATTEMPTS: "Too many attempts. Please wait a minute and try again."
  },
  VALIDATION: {
    FIELD_REQUIRED: "This field is required",
    USERNAME_REQUIRED: "Username required",
    PASSWORD_REQUIRED: "Password required"
  },
  PASSWORD: {
    MUST_BE_NON_EMPTY: "Password must be a non-empty string",
    CANNOT_BE_WHITESPACE: "Password cannot be empty or whitespace only",
    HASH_FAILED: "Failed to hash password",
    HASHED_MUST_BE_NON_EMPTY: "Hashed password must be a non-empty string",
    COMPARE_FAILED: "Failed to compare passwords",
    SALT_GENERATION_FAILED: "Failed to generate salt",
    SALT_MUST_BE_NON_EMPTY: "Salt must be a non-empty string",
    HASH_WITH_SALT_FAILED: "Failed to hash password with salt",
    MIN_LENGTH: (minLength) => `Password must be at least ${minLength} characters long`,
    NEED_LOWERCASE: "Password must contain at least one lowercase letter",
    NEED_NUMBER: "Password must contain at least one number",
    NEED_SPECIAL_CHAR: "Password must contain at least one special character"
  },
  BET: {
    // Bet lock on the player or any staff above them — sports
    // placeBet (services/BetLockService.js). Also the forceLogout toast.
    LOCKED_CONTACT_UPLINE: "Bet is locked. Please contact upper level 1.",
    // General Lock (sports-lock) — n = role number of the locker
    // (Agent 1, Master 2, … Owner 7; see uplineNo in SportsLockController).
    GAME_LOCKED_CONTACT_UPLINE: (n) => `Game is locked. Please contact Upper Level${n}`,
    // Owner-set Max Odds (admin Settings → Max Odds). `scope` is the sport
    // name, or LIMITED_OVERS_SCOPE for a cricket "Oneday & T20 only" cell.
    // Always 2 decimals — reference: "Bet Not Accept Rate Over 4.00 on Oneday and T20".
    // Frontend twin: frontend/src/utils/betToastMessages.js RATE_OVER_LIMIT.
    RATE_OVER_LIMIT: (max, scope) => `Bet Not Accept Rate Over ${Number(max).toFixed(2)} on ${scope}`,
    LIMITED_OVERS_SCOPE: "Oneday and T20",
    // Server-side bet buffer (sportsbet/betBuffer.js) — verbatim twins of
    // frontend/src/utils/betToastMessages.js, so the toast a player sees
    // did not change when these checks moved off the browser.
    GAME_SUSPEND: "Bet Not Confirmed due to game suspend.",
    BALL_RUNNING: "Ball Running",
    ODDS_CHANGED: "Odds changed",
    ODDS_CHANGE_NOT_CONFIRMED: "Bet not confirm Odds change",
    UNMATCHED_NOT_ALLOWED: "Unmatched bet not allowed.",
    RANGE_NOT_VALID: "Bet Not Confirm Reason Min and Max Bet Range Not Valid.",
    // Same client_ref submitted again while the first one is still buffering.
    BET_ALREADY_PENDING: "Bet is already being placed."
  },
  ADMIN: {
    AUTH: {
      // ── Sab admin logins pe common ──────────────────────────────
      // Account exist na kare — staff aur owner, dono ke login/2FA/profile pe yahi text.
      // NOTE: admin/src/hooks/useAuth.js ka staff→executive cascade is text pe
      // /not found|not available/i match karta hai — "not available" hataana mat.
      ACCOUNT_NOT_AVAILABLE: "UserName not available",
      // Admin ka apna wording — player side AUTH.PASSWORD_WRONG use karta hai.
      // Executive login isko tab bhi bhejta hai jab username exist na kare —
      // jaan-bujh ke, taaki bahar se account ka hona pata na chale.
      PASSWORD_INCORRECT: "Password Incorrect",
      OTP_SENT: "2FA OTP sent to your linked Telegram",
      // ── Staff ───────────────────────────────────────────────────
      MISSING_STAFFID_OR_OTP: "Staff ID and OTP required",
      STAFF_ID_MISSING_TOKEN: "Invalid token payload: staff_id missing",
      STAFF_ID_MISSING: "staff_id missing (send it in the payload or use a valid token)",
      STAFF_LOGIN_FAILED: "Failed to login staff",
      STAFF_LOGOUT_FAILED: "Failed to logout staff",
      STAFF_PROFILE_FETCH_FAILED: "Failed to fetch staff profile",
      // Telegram body — HTML parse mode, isliye <b> tags.
      // Same reference bot line as the player side (MESSAGES.AUTH.
      // TELEGRAM_LOGIN_CODE) — one bot, one wording.
      TELEGRAM_STAFF_LOGIN_OTP: (otp, username) => MESSAGES.AUTH.TELEGRAM_LOGIN_CODE(otp, username),
      // ── Owner ───────────────────────────────────────────────────
      MISSING_OWNERID_OR_OTP: "Owner ID and OTP required",
      OWNER_ID_MISSING_TOKEN: "Invalid token payload: owner_id missing",
      OWNER_ID_MISSING: "owner_id missing (send it in the payload or use a valid token)",
      OWNER_LOGIN_FAILED: "Failed to login owner",
      OWNER_LOGOUT_FAILED: "Failed to logout owner",
      OWNER_PROFILE_FETCH_FAILED: "Failed to fetch owner profile",
      // Same reference bot line as the player side (MESSAGES.AUTH.
      // TELEGRAM_LOGIN_CODE) — one bot, one wording.
      TELEGRAM_OWNER_LOGIN_OTP: (otp, username) => MESSAGES.AUTH.TELEGRAM_LOGIN_CODE(otp, username),
      // ── Executive (multi-login) ─────────────────────────────────
      // Executive login me email field nahi hai, isliye shared
      // AUTH.CREDENTIALS_REQUIRED se alag wording.
      EXECUTIVE_CREDENTIALS_REQUIRED: "Username and password are required",
      EXECUTIVE_DISABLED: "Executive account is disabled"
    },
    // Activity log ki details — admin ke Activity Log report me dikhti hain.
    ACTIVITY: {
      STAFF_LOGIN: "Staff login successful",
      STAFF_2FA: "Staff 2FA verified",
      OWNER_LOGIN: "Owner login successful",
      OWNER_2FA: "Owner 2FA verified"
    },
    // Owner ke platform / site settings.
    SETTINGS: {
      PLATFORM_CONFIG_REQUIRED: "Platform configurations are required",
      PLATFORM_CONFIG_UPDATED: "Platform configurations updated successfully",
      PLATFORM_CONFIG_UPDATE_FAILED: "Failed to update platform configurations"
    },
    // Create Account (insertuser) — user + staff dono.
    USERS: {
      // Create Account: the username is already a user, staff or owner
      // name (case-insensitive). Sent by check-username (202), the
      // player create route (400) and the staff create route (409); the
      // admin shows this text as its toast, verbatim — reference wording.
      USERNAME_EXISTS: "User Name Already Exists",
      // Create Account: a negative (or non-numeric) credit amount.
      // Reference wording verbatim — lower-case, one word, trailing dot
      // (reference toast captured 2026-09-21 for an entry of -37).
      CREDIT_AMOUNT_INVALID: "creditamount is invalid.",
      // Create Account: no role picked, or a role this API does not know.
      // Reference wording verbatim (capital S, lower-case "type").
      SELECT_PROPER_USER_TYPE: "Select Proper User type",
      // Reference wording verbatim (typo included). Parent ka balance
      // credit se kam ho to account 0 credit pe banta hai; bal = parent
      // wallet ka asli inr_balance.
      CREATED_INSUFFICIENT_CREDIT: (bal) => `User Sucessfully Inserted But Your Client Does Not Have Sufficient Credit, Because Client Credit is : ${Number(bal).toFixed(2)}`,
      // Credit Withdraw (Credit Activity modal): child ka main balance
      // (USER → cash, staff → inr_balance) withdraw amount se kam.
      // Reference wording verbatim; bal = child ka asli balance. The
      // admin shows this as its error toast, text from here.
      WITHDRAW_INSUFFICIENT_BALANCE: (bal) => `Your Client Does Not Have Sufficient Balance, Because Client Balance is : ${Number(bal).toFixed(2)}`,
      // Credit Deposit (same modal): the SENDER (logged-in parent) has
      // less inr_balance than the deposit. Reference wording verbatim;
      // bal = sender's actual balance. Error toast in the admin.
      DEPOSIT_INSUFFICIENT_CREDIT: (bal) => `Your Client Does Not Have Sufficient Credit, Because Client Credit is : ${Number(bal).toFixed(2)}`,
      // Credit Deposit AND Credit Withdraw succeeded — the admin toasts
      // this on both (user, 2026-09-17: "dono ke case me same"). Reference
      // wording verbatim ("Sucessfull" typo included).
      BALANCE_TRANSFER_SUCCESS: "Sucessfull Balance Transfer"
    },
    // Transaction code (a.k.a. master password) — ONE set of strings for
    // every route that runs verifyTransactionPassword / the attempts
    // service (deposit, withdraw, create account, edit profile, lock,
    // settlement …). Controllers never spell these out inline.
    TXN: {
      REQUIRED: "Transaction password is required",
      ACCOUNT_NOT_FOUND: "User not found",
      // Reference-site wording, verbatim — including the missing space
      // before "attempt", the singular whatever the count, the lowercase
      // "t" and the FULL STOP at the end. Match it, do not tidy it.
      // First noted 2026-09-16 as "You have 8attempt left"; the full stop
      // was missed then and is plain in the 2026-09-21 phone recording of
      // General Lock: "transaction code not valid. You have 7attempt left."
      NOT_VALID_ATTEMPTS_LEFT: (n) => `transaction code not valid. You have ${n}attempt left.`,
      // The allowance is used up (counter at 0, staff deactivated) — and
      // every later attempt while still deactivated. Same text on every
      // transaction-code route (user, 2026-09-18).
      LIMIT_REACHED: "Unauthorized access",
      VERIFIED: "Transaction password verified",
      // Bet Lock says it differently. The operator ticks an account with
      // the Transaction Code box filled in, and a wrong code comes back
      // as this — user's toast DOM, 2026-09-23, full stop included. Only
      // the market-lock routes use it; every other transaction-code route
      // keeps NOT_VALID_ATTEMPTS_LEFT above.
      MASTER_NOT_VALID: "Master Password not valid."
    }
  }
};

// services/admin/transactionPasswordService.js
var MAX_TXN_PASSWORD_ATTEMPTS = 10;
async function verifyTxnPasswordWithAttempts(reqUser, transactionPassword) {
  const userId = reqUser.account ? reqUser.account.id : reqUser.user_id || reqUser.staff_id || reqUser.owner_id;
  const userRole = reqUser.role;
  if (!transactionPassword) {
    return { ok: false, status: 400, message: MESSAGES.ADMIN.TXN.REQUIRED };
  }
  const isOwner = userRole === "OWNER" || userRole === "Owner";
  const user = isOwner ? await Owner_default.findOne({ where: { owner_id: userId } }) : await Staff_default.findByPk(userId);
  if (!user) {
    return { ok: false, status: 404, message: MESSAGES.ADMIN.TXN.ACCOUNT_NOT_FOUND };
  }
  if (!isOwner && user.active === false) {
    return {
      ok: false,
      status: 403,
      message: MESSAGES.ADMIN.TXN.LIMIT_REACHED,
      attemptsLeft: 0
    };
  }
  const attemptsLeft = user.txn_password_attempts ?? MAX_TXN_PASSWORD_ATTEMPTS;
  if (!isOwner && attemptsLeft <= 0) {
    return { ok: false, status: 403, message: MESSAGES.ADMIN.TXN.LIMIT_REACHED, attemptsLeft: 0 };
  }
  if (user.transaction_password !== transactionPassword) {
    const remaining = Math.max(0, attemptsLeft - 1);
    const updates = { txn_password_attempts: remaining };
    let message = MESSAGES.ADMIN.TXN.NOT_VALID_ATTEMPTS_LEFT(remaining);
    if (remaining === 0) {
      message = MESSAGES.ADMIN.TXN.LIMIT_REACHED;
    }
    await user.update(updates);
    return { ok: false, status: 400, message, attemptsLeft: remaining };
  }
  if (attemptsLeft !== MAX_TXN_PASSWORD_ATTEMPTS) {
    await user.update({ txn_password_attempts: MAX_TXN_PASSWORD_ATTEMPTS });
  }
  return { ok: true, status: 200, message: MESSAGES.ADMIN.TXN.VERIFIED, attemptsLeft: MAX_TXN_PASSWORD_ATTEMPTS };
}

// middleware/transactionPasswordMiddleware.js
var verifyTransactionPassword = async (req, res, next) => {
  try {
    const { transactionPassword } = req.body;
    const result = await verifyTxnPasswordWithAttempts(req.user, transactionPassword);
    if (!result.ok) {
      return res.status(result.status).json({
        success: false,
        message: result.message,
        attemptsLeft: result.attemptsLeft
      });
    }
    next();
  } catch (error) {
    console.error("\u274C Transaction password verification error:", error);
    res.status(500).json({ success: false, message: "Internal server error during verification" });
  }
};
var verifyTransactionPasswordAs = (notValidMessage) => async (req, res, next) => {
  try {
    const { transactionPassword } = req.body;
    const result = await verifyTxnPasswordWithAttempts(req.user, transactionPassword);
    if (!result.ok) {
      const wrongPassword = result.status === 400 && !!transactionPassword;
      return res.status(result.status).json({
        success: false,
        message: wrongPassword ? notValidMessage : result.message,
        attemptsLeft: result.attemptsLeft
      });
    }
    next();
  } catch (error) {
    console.error("\u274C Transaction password verification error:", error);
    res.status(500).json({ success: false, message: "Internal server error during verification" });
  }
};
var transactionPasswordMiddleware_default = verifyTransactionPassword;

// controller/sports/cricket/cricketController.js
import dotenv5 from "dotenv";
import axios3 from "axios";

// services/ScoreAnimationService.js
import dotenv4 from "dotenv";
import axios2 from "axios";
dotenv4.config();
var HOST_URL = process.env.SCORECARD_HOST_URL || "https://scorecard.daimond-api.site/";
var MAX_ATTEMPTS = 5;
var TIMEOUT_MS = 8e3;
var PROVIDER_RE = /https?:\/\/[a-z0-9.-]*animationprovider\.com\/[^"'\s]+/i;
var isNotFoundPage = (html) => !html || html.length < 4e3 || /<title>\s*Page Not Found/i.test(html);
async function fetchOnce(etid, gmid) {
  const hostUrl = `${HOST_URL.replace(/\/+$/, "")}/?etid=${encodeURIComponent(etid)}&gmid=${encodeURIComponent(gmid)}`;
  const host = await axios2.get(hostUrl, { timeout: TIMEOUT_MS, responseType: "text" });
  const match = PROVIDER_RE.exec(String(host.data || ""));
  if (!match) return { ok: false, reason: "no provider url in host page" };
  const providerUrl = match[0];
  const page = await axios2.get(providerUrl, {
    timeout: TIMEOUT_MS,
    responseType: "text",
    // The provider answers 200 for its 404 page; never let axios throw on
    // status, the body is the only signal that matters.
    validateStatus: () => true
  });
  const html = String(page.data || "");
  if (isNotFoundPage(html)) return { ok: false, reason: "dead token", providerUrl };
  return { ok: true, html, providerUrl };
}
function withBase(html, providerUrl) {
  const origin = new URL(providerUrl).origin;
  const tag = `<base href="${origin}/">`;
  return /<head[^>]*>/i.test(html) ? html.replace(/<head([^>]*)>/i, `<head$1>${tag}`) : `${tag}${html}`;
}
async function getScoreUrl(etid, gmid) {
  const hostUrl = `${HOST_URL.replace(/\/+$/, "")}/?etid=${encodeURIComponent(etid)}&gmid=${encodeURIComponent(gmid)}`;
  const host = await axios2.get(hostUrl, { timeout: TIMEOUT_MS, responseType: "text" });
  const match = PROVIDER_RE.exec(String(host.data || ""));
  return match ? match[0] : null;
}
async function getScoreAnimation(etid, gmid) {
  let lastReason = "unknown";
  for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
    try {
      const result = await fetchOnce(etid, gmid);
      if (result.ok) {
        return { ok: true, html: withBase(result.html, result.providerUrl), attempts: attempt };
      }
      lastReason = result.reason;
    } catch (error) {
      lastReason = error.message;
    }
  }
  return { ok: false, attempts: MAX_ATTEMPTS, reason: lastReason };
}
var ScoreAnimationService_default = { getScoreAnimation, getScoreUrl };

// services/SportsEventsService.js
init_redisClient();

// helper/sportsTreeOrder.js
var minGmid = (league) => {
  let min = Number.POSITIVE_INFINITY;
  for (const match of league?.children || []) {
    const raw = match?.gmid;
    if (raw == null || raw === "") continue;
    const g = Number(raw);
    if (Number.isFinite(g) && g < min) min = g;
  }
  return min;
};
var sortLeaguesByMinGmid = (children) => {
  if (!Array.isArray(children) || children.length < 2) return children;
  return children.map((league, index) => ({ league, index, key: minGmid(league) })).sort((a, b) => a.key - b.key || a.index - b.index).map((row) => row.league);
};

// services/SportsEventsService.js
var CACHE_KEY = "sports_events_tree";
var CACHE_TTL2 = 15;
var RACING_SPLICE_AT = 4;
var SportsEventsService = {
  /**
   * The tree, ordered. Same node shape the tree endpoint returns
   * (sport {etid, name, oid, children} → league {cid, name, children} →
   * match {etid, gmid, iscc, name}), only as one ordered `sports` array.
   */
  buildEvents: async () => {
    const cached = await redisClient_default.get(CACHE_KEY).catch(() => null);
    if (cached) {
      try {
        return JSON.parse(cached);
      } catch {
      }
    }
    const tree = await CricketService_default.fetchTreeData();
    const inner = tree?.data?.data || tree?.data || tree || {};
    const t1 = Array.isArray(inner.t1) ? inner.t1 : [];
    const t2 = Array.isArray(inner.t2) ? inner.t2 : [];
    const sports = [...t1];
    sports.splice(RACING_SPLICE_AT, 0, ...t2);
    const racingIds = new Set(t2.map((s) => String(s?.etid)));
    const ordered = sports.map((sport) => {
      const children = sport?.children || [];
      if (!children.length || racingIds.has(String(sport?.etid))) return sport;
      return { ...sport, children: sortLeaguesByMinGmid(children) };
    });
    const payload = { sports: ordered };
    redisClient_default.set(CACHE_KEY, JSON.stringify(payload), "EX", CACHE_TTL2).catch(() => {
    });
    return payload;
  }
};
var SportsEventsService_default = SportsEventsService;

// controller/sports/cricket/cricketController.js
import { Op as Op4 } from "sequelize";
dotenv5.config();
var AVRKHUB_SPORTS_BASE_URL2 = process.env.AVRKHUB_SPORTS_BASE_URL;
var AVRKHUB_SPORTS_KEY2 = process.env.AVRKHUB_SPORTS_KEY;
var safeInt = (val, fallback = 1) => {
  if (val == null || val === "") return fallback;
  const n = parseInt(val, 10);
  return isNaN(n) ? fallback : Math.max(1, n);
};
var CricketController = {
  // fetch sports data by ID it will show all the data related to games id , ex : if 4 is cricket then it will show all the data [matches or events]related to cricket
  fetchCricketData: async (req, res) => {
    const { id } = req.body;
    if (!id) {
      return res.status(400).json({
        success: false,
        error: "ID is required to fetch cricket data"
      });
    }
    try {
      const cricketData = await CricketService_default.fetchCricketData(id);
      return res.status(200).json({
        success: true,
        data: cricketData
      });
    } catch (error) {
      console.error("\u274C Error:", error.message);
      return res.status(500).json({
        success: false,
        error: error.message
      });
    }
  },
  getSportdetailsById: async (req, res) => {
    const { gmid, sid } = req.body;
    if (!sid || !gmid) {
      return res.status(400).json({
        success: false,
        error: "Sport ID and Game ID are required to fetch data"
      });
    }
    try {
      const sportData = await CricketService_default.getSportDataById(gmid, sid);
      console.log("\u2705 Sport Data:", sportData);
      return res.status(200).json({
        success: true,
        data: sportData
      });
    } catch (error) {
      console.error("\u274C Error:", error.message);
      return res.status(500).json({
        success: false,
        error: error.message
      });
    }
  },
  GetallSportsdata: async (req, res) => {
    try {
      const allSportsData = await CricketService_default.GetallSportsdata();
      console.log("\u2705 All Sports Data:", allSportsData);
      return res.status(200).json({
        success: true,
        data: allSportsData
      });
    } catch (error) {
      console.error("\u274C Error:", error.message);
      return res.status(500).json({
        success: false,
        error: error.message
      });
    }
  },
  // Admin "More Market": every market the match has shown (redis store, see
  // helper/marketListStore.js) combined with the live feed, so the list is
  // never blank when either source fails. Live wins on name/sno.
  GetMarketList: async (req, res) => {
    const { gmid, sid } = req.body;
    if (!gmid || !sid) {
      return res.status(400).json({ success: false, error: "gmid and sid are required" });
    }
    const [stored, live] = await Promise.allSettled([
      getStoredMarkets(gmid),
      CricketService_default.GetMatchPrivateData(gmid, sid)
    ]);
    const byMid = /* @__PURE__ */ new Map();
    if (stored.status === "fulfilled") {
      stored.value.forEach((m) => byMid.set(String(m.mid), m));
    }
    const liveList2 = live.status === "fulfilled" && Array.isArray(live.value?.data) ? live.value.data : [];
    liveList2.forEach((m) => {
      if (m?.mid != null && m.mname) byMid.set(String(m.mid), { mid: String(m.mid), mname: m.mname, sno: m.sno ?? null });
    });
    if (stored.status === "rejected" && live.status === "rejected") {
      return res.status(500).json({ success: false, error: live.reason?.message || "market list unavailable" });
    }
    const data = [...byMid.values()].sort((x, y) => (Number(x.sno) || 0) - (Number(y.sno) || 0));
    return res.status(200).json({ success: true, data });
  },
  GetMatchPrivateData: async (req, res) => {
    const { gmid, sid } = req.body;
    if (!gmid || !sid) {
      return res.status(400).json({
        success: false,
        error: "Game ID || sid is required to fetch match private data"
      });
    }
    try {
      const matchPrivateData = await CricketService_default.GetMatchPrivateData(gmid, sid);
      return res.status(200).json({
        success: true,
        data: matchPrivateData
      });
    } catch (error) {
      console.error("\u274C Error:", error.message);
      return res.status(500).json({
        success: false,
        error: error.message
      });
    }
  },
  fetchLiveStream: async (req, res) => {
    const { gmid } = req.body;
    if (!gmid) {
      return res.status(400).json({
        success: false,
        error: "Game ID is required to fetch live stream data"
      });
    }
    try {
      const liveStreamData = await CricketService_default.fetchLiveStream(gmid);
      console.log("\u2705 Live Stream Data:", liveStreamData);
      return res.status(200).json({
        success: true,
        data: liveStreamData
      });
    } catch (error) {
      console.error("\u274C Error:", error.message);
      return res.status(500).json({
        success: false,
        error: error.message
      });
    }
  },
  /* Serves the score-animation page itself, retrying until it gets one that
   * is not the provider's 404. The iframe points here instead of at the
   * scorecard host, because a token is single-use — see
   * services/ScoreAnimationService.js and
   * docs/handover/2026-09-08-scorecard-404-fix.md. */
  fetchScoreAnimation: async (req, res) => {
    const gmid = req.query.gmid;
    const etid = req.query.etid;
    if (!gmid || !etid) {
      return res.status(400).send("gmid and etid are required");
    }
    try {
      const { ok, html, attempts, reason } = await ScoreAnimationService_default.getScoreAnimation(etid, gmid);
      res.set("Cache-Control", "no-store");
      res.set("Content-Type", "text/html; charset=utf-8");
      if (!ok) {
        console.warn(`[ScoreAnimation] gmid=${gmid} etid=${etid} gave up after ${attempts} attempts: ${reason}`);
        return res.status(502).send("");
      }
      res.set("X-Score-Attempts", String(attempts));
      return res.status(200).send(html);
    } catch (error) {
      console.error("\u274C ScoreAnimation Error:", error.message);
      return res.status(500).send("");
    }
  },
  /* The scorecard's iframe URL, minted fresh and handed over unused.
   *
   * The browser used to load the scorecard host itself, which meant a black
   * page while its nested provider frame came up, and a fresh token on every
   * iframe load — including the ones a remount caused. Resolving it here gives
   * the client a direct provider URL, one hop, one token, spent once by the
   * iframe that loads it.
   *
   * Deliberately NOT verified before returning: checking a token spends it, so
   * a "verified" URL would arrive already used. See
   * docs/handover/2026-09-08-scorecard-404-fix.md. */
  fetchScoreUrl: async (req, res) => {
    const { gmid, etid } = req.query;
    if (!gmid || !etid) {
      return res.status(400).json({
        success: false,
        error: "gmid and etid are required to fetch the score url"
      });
    }
    try {
      const url = await ScoreAnimationService_default.getScoreUrl(etid, gmid);
      if (!url) {
        return res.status(502).json({
          success: false,
          error: "Scorecard host did not return an animation url"
        });
      }
      res.set("Cache-Control", "no-store");
      return res.status(200).json({ success: true, data: { url } });
    } catch (error) {
      console.error("\u274C ScoreUrl Error:", error.message);
      return res.status(500).json({ success: false, error: error.message });
    }
  },
  fetchScoreCard: async (req, res) => {
    const { gmid, sid } = req.body;
    console.log("====>>>>scorecard_logs: " + gmid + " sid: " + sid);
    if (!gmid) {
      return res.status(400).json({
        success: false,
        error: "Game ID is required to fetch score card"
      });
    }
    if (!sid) {
      return res.status(400).json({
        success: false,
        error: "Sid is required to fetch score card"
      });
    }
    try {
      console.log(`[ScoreCard] Fetching scorecard for gmid=${gmid} sid=${sid}`);
      const scoreCard = await CricketService_default.fetchScoreCard(gmid, sid);
      console.log("\u2705 Score Card:", scoreCard);
      return res.status(200).json({
        success: true,
        data: scoreCard
      });
    } catch (primaryError) {
      console.warn("\u26A0\uFE0F Primary scorecard failed, trying gtv fallback:", primaryError.message);
      try {
        const matchRes = await CricketService_default.getSportDataById(gmid, sid);
        const match = matchRes?.data?.[0];
        const gtv = match?.gtv;
        if (!gtv) {
          return res.status(200).json({
            success: false,
            error: "Scorecard not available: gtv cannot be fetched"
          });
        }
        const scoreCard = await CricketService_default.fetchScoreCard(gtv, sid);
        console.log("\u2705 Score Card (gtv fallback):", scoreCard);
        return res.status(200).json({ success: true, data: scoreCard });
      } catch (fallbackError) {
        console.error("\u274C ScoreCard Error (all sources failed):", fallbackError.message);
        return res.status(500).json({
          success: false,
          error: fallbackError.message
        });
      }
    }
  },
  /* The sidebar's tree, ORDERED — see services/SportsEventsService.js for why
     the order is decided here and not left to the feed (which reshuffles) or
     to a hardcoded list of competition names in each client. Same nodes as
     fetchTreeData below, returned as one `sports` array already in order. */
  fetchSportsEvents: async (req, res) => {
    try {
      const data = await SportsEventsService_default.buildEvents();
      return res.status(200).json({ success: true, data });
    } catch (error) {
      console.error("\u274C Error building sports events:", error.message);
      return res.status(500).json({ success: false, error: error.message });
    }
  },
  fetchTreeData: async (req, res) => {
    try {
      const treeData = await CricketService_default.fetchTreeData();
      console.log("\u2705 Tree Data:", treeData);
      return res.status(200).json({
        success: true,
        data: treeData
      });
    } catch (error) {
      console.error("\u274C Error:", error.message);
      return res.status(500).json({
        success: false,
        error: error.message
      });
    }
  },
  GetResults: async (req, res) => {
    const { event_id, event_name, market_id, market_name, sid } = req.body;
    if (!event_id || !event_name || !market_id || !market_name || !sid) {
      return res.status(400).json({
        success: false,
        error: "Event ID, Event Name, Market ID, Market Name, Market Type and SID are required to get results"
      });
    }
    try {
      const resultsData = await CricketService_default.GetResult(sid, event_id, event_name, market_id, market_name);
      console.log("\u2705 Results Data:", resultsData);
      return res.status(200).json({
        success: true,
        data: resultsData
      });
    } catch (error) {
      console.error("\u274C Error:", error.message);
      return res.status(500).json({
        success: false,
        error: error.message
      });
    }
  },
  getAllSportsBets: async (req, res) => {
    try {
      const bets = await CricketService_default.getAllSportsBets();
      return res.status(200).json({ success: true, data: bets });
    } catch (error) {
      console.error("\u274C Error:", error.message);
      return res.status(500).json({ success: false, error: error.message });
    }
  },
  // used by user to get his own bets
  getSportsBetsByUserId: async (req, res) => {
    const user_id = req.user?.account?.id || req.user?.id;
    if (!user_id) {
      return res.status(401).json({ success: false, error: "Unauthorized: user_id missing" });
    }
    try {
      const { page, limit, search, betType, status } = req.query;
      const result = await CricketService_default.getSportsBetsByUserId(user_id, { page, limit, search, betType, status });
      return res.status(200).json({ success: true, data: result.rows, pagination: result.pagination });
    } catch (error) {
      console.error("\u274C Error:", error.message);
      return res.status(500).json({ success: false, error: error.message });
    }
  },
  // used by admin to get particular user's bets
  getSportsBetsOfUser: async (req, res) => {
    const role = req.user?.role;
    if (role === "User") {
      return res.status(401).json({ success: false, error: "Unauthorized: user not allowed" });
    }
    const user_id = req.body.user_id;
    if (!user_id) {
      return res.status(400).json({ success: false, error: "User ID is required" });
    }
    try {
      const bets = await CricketService_default.getSportsBetsByUserId(user_id, { status: "all" });
      return res.status(200).json({ success: true, data: bets });
    } catch (error) {
      console.error("\u274C Error:", error.message);
      return res.status(500).json({ success: false, error: error.message });
    }
  },
  getWinsByUserId: async (req, res) => {
    const user_id = req.user?.id;
    if (!user_id) {
      return res.status(401).json({ success: false, error: "Unauthorized: user_id missing" });
    }
    try {
      const wins = await CricketService_default.getWinsByUserId(user_id);
      return res.status(200).json({ success: true, data: wins });
    } catch (error) {
      console.error("\u274C Error:", error.message);
      return res.status(500).json({ success: false, error: error.message });
    }
  },
  getTotalStakeOnEvent: async (req, res) => {
    try {
      const totals = await SportsBet_default.findAll({
        attributes: [
          "eventid",
          [SportsBet_default.sequelize.fn("SUM", SportsBet_default.sequelize.col("stake_amount")), "total_stake"],
          [SportsBet_default.sequelize.fn("COUNT", SportsBet_default.sequelize.col("id")), "bets_count"]
        ],
        where: {
          // optional: ignore cancelled / voided bets
          // status: { [Op.notIn]: ['void', 'cancelled'] },
          eventid: { [Op4.ne]: null }
          // skip rows without eventid
        },
        group: ["eventid"],
        order: [[SportsBet_default.sequelize.literal("total_stake"), "DESC"]],
        raw: true
        // return plain objects (no Sequelize instances)
      });
      const result = totals.map((row) => ({
        eventid: row.eventid,
        total_stake: parseFloat(row.total_stake).toFixed(2),
        // e.g. "12345.00"
        bets_count: Number(row.bets_count)
      }));
      return res.status(200).json({
        success: true,
        data: result,
        meta: {
          total_events: result.length,
          generated_at: (/* @__PURE__ */ new Date()).toISOString()
        }
      });
    } catch (error) {
      console.error("Error in getTotalStakeOnEvent:", error);
      return res.status(500).json({
        success: false,
        error: error.message || "Internal server error"
      });
    }
  },
  getTotalStakeOnLiveAndUpcomingEvents: async (req, res) => {
    try {
      const totals = await SportsBet_default.findAll({
        attributes: [
          "eventid",
          [SportsBet_default.sequelize.fn("SUM", SportsBet_default.sequelize.col("stake_amount")), "total_stake"],
          [SportsBet_default.sequelize.fn("COUNT", SportsBet_default.sequelize.col("id")), "bets_count"]
        ],
        where: {
          eventid: { [Op4.ne]: null },
          result_status: "pending"
          // Only live or upcoming matches
          // Optional: exclude void/cancelled bets
          // status: { [Op.notIn]: ['void', 'cancelled', 'deleted'] },
        },
        group: ["eventid"],
        order: [[SportsBet_default.sequelize.literal("total_stake"), "DESC"]],
        raw: true
      });
      const result = totals.map((row) => ({
        eventid: row.eventid,
        total_stake: parseFloat(row.total_stake).toFixed(2),
        bets_count: Number(row.bets_count)
      }));
      return res.status(200).json({
        success: true,
        data: result,
        meta: {
          total_events: result.length,
          filter: "live_and_upcoming_only",
          generated_at: (/* @__PURE__ */ new Date()).toISOString()
        }
      });
    } catch (error) {
      console.error("Error in getTotalStakeOnLiveAndUpcomingEvents:", error);
      return res.status(500).json({
        success: false,
        error: error.message || "Internal server error"
      });
    }
  },
  // 1. Get ALL matched bets for an event for admin only
  getMatchedBetsByEvent: async (req, res) => {
    try {
      const { eventid } = req.query;
      if (!eventid) {
        return res.status(400).json({
          success: false,
          error: "eventid is required"
        });
      }
      const page = parseInt(req.query.page) || 1;
      const limit = parseInt(req.query.limit) || 50;
      const offset = (page - 1) * limit;
      const { count, rows } = await SportsBet_default.findAndCountAll({
        where: {
          eventid: eventid.toString()
        },
        include: [{
          model: User_default,
          as: "user",
          attributes: ["username"],
          required: false
        }],
        attributes: { exclude: ["job_id"] },
        order: [["created_at", "DESC"]],
        limit,
        offset,
        raw: false
      });
      const bets = rows.map((bet) => {
        const betPlain = bet.get({ plain: true });
        return {
          ...betPlain,
          stake_amount: parseFloat(betPlain.stake_amount).toFixed(2),
          odds: parseFloat(betPlain.odds).toFixed(4),
          liability: betPlain.liability ? parseFloat(betPlain.liability).toFixed(2) : null,
          usd_amount: betPlain.usd_amount ? parseFloat(betPlain.usd_amount).toFixed(2) : null
        };
      });
      return res.status(200).json({
        success: true,
        data: bets,
        pagination: {
          total: count,
          page,
          limit,
          total_pages: Math.ceil(count / limit)
        },
        meta: {
          eventid,
          filter: "matched_bets",
          generated_at: (/* @__PURE__ */ new Date()).toISOString()
        }
      });
    } catch (error) {
      console.error("Error in getMatchedBetsByEvent:", error);
      return res.status(500).json({
        success: false,
        error: error.message || "Internal server error"
      });
    }
  },
  // 2. Get only OPEN (pending result) bets for an event
  getOpenBetsByEvent: async (req, res) => {
    try {
      const { eventid } = req.query;
      if (!eventid) {
        return res.status(400).json({
          success: false,
          error: "eventid is required"
        });
      }
      const page = parseInt(req.query.page) || 1;
      const limit = parseInt(req.query.limit) || 50;
      const offset = (page - 1) * limit;
      const { count, rows } = await SportsBet_default.findAndCountAll({
        where: {
          eventid: eventid.toString(),
          result_status: "pending"
          // Only unsettled bets
          // status: { [Op.notIn]: ['void', 'cancelled', 'deleted'] },
          // eventid: { [Op.ne]: null },
        },
        attributes: { exclude: ["job_id", "ip_address"] },
        order: [["created_at", "DESC"]],
        limit,
        offset,
        raw: true
      });
      const bets = rows.map((bet) => ({
        ...bet,
        stake_amount: parseFloat(bet.stake_amount).toFixed(2),
        odds: parseFloat(bet.odds).toFixed(4),
        liability: bet.liability ? parseFloat(bet.liability).toFixed(2) : null,
        usd_amount: bet.usd_amount ? parseFloat(bet.usd_amount).toFixed(2) : null
      }));
      return res.status(200).json({
        success: true,
        data: bets,
        pagination: {
          total: count,
          page,
          limit,
          total_pages: Math.ceil(count / limit)
        },
        meta: {
          eventid,
          filter: "open_bets_only",
          generated_at: (/* @__PURE__ */ new Date()).toISOString()
        }
      });
    } catch (error) {
      console.error("Error in getOpenBetsByEvent:", error);
      return res.status(500).json({
        success: false,
        error: error.message || "Internal server error"
      });
    }
  },
  /**
   * 1. Get ALL matched bets of a USER on a specific event
   */
  getUserMatchedBetsByEvent: async (req, res) => {
    try {
      const { eventid, user_id } = req.query;
      if (!eventid || !user_id) {
        return res.status(400).json({
          success: false,
          error: "Both eventid and user_id are required"
        });
      }
      const page = safeInt(req.query.page) || 1;
      const limit = safeInt(req.query.limit) || 50;
      const offset = (page - 1) * limit;
      const { count, rows } = await SportsBet_default.findAndCountAll({
        where: {
          eventid: eventid.toString(),
          user_id: user_id.toString(),
          status: { [Op4.notIn]: ["void", "cancelled", "deleted"] },
          eventid: { [Op4.ne]: null }
        },
        attributes: { exclude: ["job_id", "ip_address"] },
        // hide sensitive
        order: [["created_at", "DESC"]],
        limit,
        offset,
        raw: true
      });
      const bets = rows.map((bet) => ({
        ...bet,
        stake_amount: parseFloat(bet.stake_amount).toFixed(2),
        odds: parseFloat(bet.odds).toFixed(4),
        liability: bet.liability ? parseFloat(bet.liability).toFixed(2) : null,
        usd_amount: bet.usd_amount ? parseFloat(bet.usd_amount).toFixed(2) : null
      }));
      return res.status(200).json({
        success: true,
        data: bets,
        pagination: {
          total: count,
          page,
          limit,
          total_pages: Math.ceil(count / limit)
        },
        meta: {
          eventid,
          user_id,
          filter: "user_matched_bets",
          generated_at: (/* @__PURE__ */ new Date()).toISOString()
        }
      });
    } catch (error) {
      console.error("Error in getUserMatchedBetsByEvent:", error);
      return res.status(500).json({
        success: false,
        error: error.message || "Internal server error"
      });
    }
  },
  /**
   * 2. Get only OPEN (pending result) bets of a USER on a specific event
   */
  getUserOpenBetsByEvent: async (req, res) => {
    try {
      const { eventid, user_id } = req.query;
      if (!eventid || !user_id) {
        return res.status(400).json({
          success: false,
          error: "Both eventid and user_id are required"
        });
      }
      const page = safeInt(req.query.page) || 1;
      const limit = safeInt(req.query.limit) || 50;
      const offset = (page - 1) * limit;
      const { count, rows } = await SportsBet_default.findAndCountAll({
        where: {
          eventid: eventid.toString(),
          user_id: user_id.toString(),
          result_status: "pending",
          // Only unsettled
          status: { [Op4.notIn]: ["void", "cancelled", "deleted"] },
          eventid: { [Op4.ne]: null }
        },
        attributes: { exclude: ["job_id", "ip_address"] },
        order: [["created_at", "DESC"]],
        limit,
        offset,
        raw: true
      });
      const bets = rows.map((bet) => ({
        ...bet,
        stake_amount: parseFloat(bet.stake_amount).toFixed(2),
        odds: parseFloat(bet.odds).toFixed(4),
        liability: bet.liability ? parseFloat(bet.liability).toFixed(2) : null,
        usd_amount: bet.usd_amount ? parseFloat(bet.usd_amount).toFixed(2) : null
      }));
      return res.status(200).json({
        success: true,
        data: bets,
        pagination: {
          total: count,
          page,
          limit,
          total_pages: Math.ceil(count / limit)
        },
        meta: {
          eventid,
          user_id,
          filter: "user_open_bets_only",
          generated_at: (/* @__PURE__ */ new Date()).toISOString()
        }
      });
    } catch (error) {
      console.error("Error in getUserOpenBetsByEvent:", error);
      return res.status(500).json({
        success: false,
        error: error.message || "Internal server error"
      });
    }
  },
  /**
   * 3. Get ONLY OPEN bets for a specific event and user (Fresh Implementation)
   */
  getUserOpenBetsForEvent: async (req, res) => {
    try {
      const { eventid, user_id } = req.query;
      console.log("getUserOpenBetsForEvent called with:", { eventid, user_id });
      if (!eventid || !user_id) {
        return res.status(400).json({
          success: false,
          error: "Both eventid and user_id are required"
        });
      }
      const bets = await SportsBet_default.findAll({
        where: {
          eventid: eventid.toString(),
          user_id: user_id.toString(),
          status: { [Op4.in]: ["open", "manual", "matched"] },
          // Matched list only — unmatched bets come from the grouped endpoint
          [Op4.or]: [{ unmatched: false }, { unmatched: null }]
        },
        attributes: { exclude: ["job_id", "ip_address"] },
        order: [["created_at", "DESC"]],
        raw: true
      });
      const formattedBets = bets.map((bet) => ({
        ...bet,
        stake_amount: parseFloat(bet.stake_amount).toFixed(2),
        odds: parseFloat(bet.odds).toFixed(4),
        liability: bet.liability ? parseFloat(bet.liability).toFixed(2) : null,
        usd_amount: bet.usd_amount ? parseFloat(bet.usd_amount).toFixed(2) : null,
        // Badlo legs are EXACT-RUN swaps, not back/lay — the bet list must not
        // paint them with the blue/pink side colours. Stated explicitly rather
        // than relying on the spread above, because this is a contract the
        // frontend reads. See server/helper/badloMarket.js.
        badlo: bet.badlo === true
      }));
      return res.status(200).json({
        success: true,
        data: formattedBets,
        meta: {
          eventid,
          user_id,
          filter: "fresh_open_bets_only",
          generated_at: (/* @__PURE__ */ new Date()).toISOString()
        }
      });
    } catch (error) {
      console.error("Error in getUserOpenBetsForEvent:", error);
      return res.status(500).json({
        success: false,
        error: error.message || "Internal server error"
      });
    }
  },
  /**
   * 4. Open bets split into matched / unmatched groups.
   * There is NO auto-matching engine — a bet placed with unmatched=true stays
   * unmatched until the user cancels it (POST /cancel-bet) or it settles.
   */
  getUserOpenBetsGrouped: async (req, res) => {
    try {
      const { eventid, user_id } = req.query;
      if (!eventid || !user_id) {
        return res.status(400).json({
          success: false,
          error: "Both eventid and user_id are required"
        });
      }
      const bets = await SportsBet_default.findAll({
        where: {
          eventid: eventid.toString(),
          user_id: user_id.toString(),
          status: { [Op4.in]: ["open", "manual", "matched"] }
        },
        attributes: { exclude: ["job_id", "ip_address"] },
        order: [["created_at", "DESC"]],
        raw: true
      });
      const format = (bet) => ({
        ...bet,
        stake_amount: parseFloat(bet.stake_amount).toFixed(2),
        odds: parseFloat(bet.odds).toFixed(4),
        liability: bet.liability ? parseFloat(bet.liability).toFixed(2) : null,
        usd_amount: bet.usd_amount ? parseFloat(bet.usd_amount).toFixed(2) : null,
        // Badlo legs are EXACT-RUN swaps, not back/lay — the bet list must not
        // paint them with the blue/pink side colours. Stated explicitly rather
        // than relying on the spread above, because this is a contract the
        // frontend reads. See server/helper/badloMarket.js.
        badlo: bet.badlo === true
      });
      return res.status(200).json({
        success: true,
        data: {
          matchedBets: bets.filter((b) => b.unmatched !== true).map(format),
          unmatchedBets: bets.filter((b) => b.unmatched === true).map(format)
        },
        meta: { eventid, user_id, generated_at: (/* @__PURE__ */ new Date()).toISOString() }
      });
    } catch (error) {
      console.error("Error in getUserOpenBetsGrouped:", error);
      return res.status(500).json({
        success: false,
        error: error.message || "Internal server error"
      });
    }
  },
  // Latest events from AVRKHUB sports feed (proxied)
  getLatestEvents: async (req, res) => {
    try {
      const result = await axios3.get(`${AVRKHUB_SPORTS_BASE_URL2}/get_latest_events`, {
        params: { key: AVRKHUB_SPORTS_KEY2 },
        timeout: 3e4
      });
      return res.status(200).json({
        success: true,
        data: result?.data?.data
      });
    } catch (error) {
      console.error("Error in getLatestEvents:", error);
      return res.status(500).json({
        success: false,
        error: error.message || "Internal server error"
      });
    }
  },
  // Single event detail from AVRKHUB sports feed (proxied) — gmid & etid required
  getGameDetailPrivate: async (req, res) => {
    const { gmid, etid } = req.query;
    if (!gmid || !etid) {
      return res.status(400).json({
        success: false,
        error: "gmid and etid are required"
      });
    }
    try {
      const result = await axios3.get(`${AVRKHUB_SPORTS_BASE_URL2}/gamedetailPrivate`, {
        params: { key: AVRKHUB_SPORTS_KEY2, gmid, etid },
        timeout: 3e4
      });
      return res.status(200).json({
        success: true,
        data: result?.data?.data
      });
    } catch (error) {
      console.error("Error in getGameDetailPrivate:", error);
      return res.status(500).json({
        success: false,
        error: error.message || "Internal server error"
      });
    }
  }
};
var cricketController_default = CricketController;

// controller/user/virtualEventController.js
import axios4 from "axios";
import dotenv6 from "dotenv";
dotenv6.config();
var VIRTUAL_EVENT_DATA_URL = process.env.VIRTUAL_EVENT_DATA_URL || "https://e-event-data.uhdmovies.online/";
var CACHE_TTL_MS = 30 * 1e3;
var MAX_ENTRIES = 500;
var cache = /* @__PURE__ */ new Map();
function evictOldest() {
  for (const k of cache.keys()) {
    if (cache.size <= MAX_ENTRIES) break;
    cache.delete(k);
  }
}
var CRICKETV_CARDS_URL = process.env.CRICKETV_CARDS_URL || "http://138.68.178.21:9000/cricketvdata2";
var CRICKETV_GTYPES = /* @__PURE__ */ new Set(["cricketv", "cricketv2"]);
var CARDS_REFRESH_MS = 300;
var CARDS_MAX_AGE_MS = 10 * 1e3;
var cardsCache = /* @__PURE__ */ new Map();
var cardsInflight = /* @__PURE__ */ new Map();
async function fetchCricketVCards(gtype, gmid) {
  const { data } = await axios4.get(CRICKETV_CARDS_URL, {
    params: { gmid, gtype, key: process.env.VIRTUAL_EVENT_API_KEY },
    timeout: 5e3
  });
  const t1 = data?.data?.data?.t1;
  if (!t1 || typeof t1.card !== "string") throw new Error("upstream returned no t1");
  return { card: t1.card, ft: Number(t1.ft) || 0, lt: Number(t1.lt) || 0 };
}
function refreshCricketVCards(key, gtype, gmid) {
  let pending = cardsInflight.get(key);
  if (!pending) {
    pending = fetchCricketVCards(gtype, gmid).then((data) => {
      cardsCache.delete(key);
      cardsCache.set(key, { at: Date.now(), data });
      while (cardsCache.size > MAX_ENTRIES) cardsCache.delete(cardsCache.keys().next().value);
      return data;
    }).finally(() => cardsInflight.delete(key));
    cardsInflight.set(key, pending);
  }
  return pending;
}
var VirtualEventController = {
  // GET /api/user/virtual/event-media?gmid=502328386&etid=69
  // -> { success, data: { gmid, etid, stream, score } | null }
  getEventMedia: async (req, res) => {
    const gmid = String(req.query.gmid ?? "").trim();
    const etid = String(req.query.etid ?? "").trim();
    if (!/^\d{1,20}$/.test(gmid)) {
      return res.status(400).json({ success: false, error: "A numeric gmid is required" });
    }
    if (etid && !/^\d{1,6}$/.test(etid)) {
      return res.status(400).json({ success: false, error: "etid must be numeric" });
    }
    const key = `${etid}:${gmid}`;
    const now = Date.now();
    const hit = cache.get(key);
    if (hit && now - hit.at < CACHE_TTL_MS) {
      return res.json({ success: true, data: hit.data, cached: true });
    }
    try {
      let data;
      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          ({ data } = await axios4.get(VIRTUAL_EVENT_DATA_URL, {
            params: etid ? { data: gmid, etid } : { data: gmid },
            timeout: 8e3
          }));
          break;
        } catch (e) {
          if (attempt === 1) throw e;
        }
      }
      const stream = typeof data?.stream === "string" ? data.stream : null;
      const score = typeof data?.score === "string" ? data.score : null;
      if (!stream && !score) throw new Error("upstream returned no stream/score");
      const media = { gmid, etid: etid || null, stream, score };
      cache.delete(key);
      cache.set(key, { at: now, data: media });
      evictOldest();
      return res.json({ success: true, data: media });
    } catch (err) {
      console.error(`[VirtualEventMedia] etid=${etid} gmid=${gmid} failed:`, err.message);
      if (hit) return res.json({ success: true, data: hit.data, stale: true });
      return res.json({ success: false, data: null, error: err.message });
    }
  },
  // GET /api/user/virtual/cricketv-cards?gmid=64835120&gtype=cricketv2
  // -> { success, data: { card, ft, lt } | null }
  getCricketVCards: async (req, res) => {
    const gmid = String(req.query.gmid ?? "").trim();
    const gtype = String(req.query.gtype ?? "").trim();
    if (!/^\d{1,20}$/.test(gmid)) {
      return res.status(400).json({ success: false, error: "A numeric gmid is required" });
    }
    if (!CRICKETV_GTYPES.has(gtype)) {
      return res.status(400).json({ success: false, error: "gtype must be cricketv or cricketv2" });
    }
    const key = `${gtype}:${gmid}`;
    const hit = cardsCache.get(key);
    const age = hit ? Date.now() - hit.at : Infinity;
    if (age < CARDS_MAX_AGE_MS) {
      if (age > CARDS_REFRESH_MS) {
        refreshCricketVCards(key, gtype, gmid).catch(
          (err) => console.error(`[CricketVCards] gtype=${gtype} gmid=${gmid} refresh failed:`, err.message)
        );
      }
      return res.json({ success: true, data: hit.data, cached: true });
    }
    try {
      const data = await refreshCricketVCards(key, gtype, gmid);
      return res.json({ success: true, data });
    } catch (err) {
      console.error(`[CricketVCards] gtype=${gtype} gmid=${gmid} failed:`, err.message);
      if (hit) return res.json({ success: true, data: hit.data, stale: true });
      return res.json({ success: false, data: null, error: err.message });
    }
  }
};
var virtualEventController_default = VirtualEventController;

// controller/user/bettingConfigController.js
var LEAGUES = Object.fromEntries(
  Object.entries(COMMISSION_LEAGUES).map(([sid, list]) => [
    sid,
    list.map(({ key, patterns }) => ({ key, patterns }))
  ])
);
var getBettingConfig = async (req, res) => {
  try {
    const [buffers, maxOdds, virtualLimits] = await Promise.all([
      BettingConfigService_default.getBufferMap(),
      BettingConfigService_default.getMaxOddsMap(),
      BettingConfigService_default.getVirtualLimitMap()
    ]);
    return res.json({
      success: true,
      // Seconds. `global` is the pre-existing platform-wide buffer and is
      // the fallback for any sport/market left unset.
      //   grid:   { "<sportId>": { "<leagueKey>": { "<marketKey>": seconds } } }
      //           — a variant league cell that is absent inherits 'default'.
      //   sports: the pre-2026-09-15 { match_odds, bookmaker, fancy } view of
      //           the default league, for bundles that predate the grid.
      buffers: {
        global: buffers?.global || 0,
        grid: buffers?.grid || {},
        sports: buffers?.sports || {}
      },
      // { "<sportId>": { name, match_odds?: { max, limited_overs_only },
      //   bookmaker?: {…}, leagues?: { "<leagueKey>": { match_odds?: {…} } } } }
      // — an absent default cell means "no cap"; an absent league cell
      // inherits the default one, a present one with max 0 is "no cap for
      // this league". The server re-checks every bet, so this only drives
      // the slip's early toast.
      max_odds: maxOdds || {},
      // { "<sportId>": { "<leagueKey>": { min, max } } } — virtual leagues
      // only; 0 = not set (feed value). placeBet re-checks every bet.
      virtual_limits: virtualLimits || {},
      leagues: LEAGUES
    });
  } catch (err) {
    console.error("getBettingConfig error:", err);
    return res.json({
      success: true,
      buffers: { global: 0, grid: {}, sports: {} },
      max_odds: {},
      virtual_limits: {},
      leagues: LEAGUES
    });
  }
};
var getEventBetLimits = async (req, res) => {
  try {
    const limits = await BettingConfigService_default.getEventLimitMap(req.params.event_id);
    return res.json({ success: true, limits: limits || {} });
  } catch (err) {
    console.error("getEventBetLimits error:", err);
    return res.json({ success: true, limits: {} });
  }
};
var bettingConfigController_default = { getBettingConfig, getEventBetLimits };

// controller/user/StakeButtonValueController.js
import jwt2 from "jsonwebtoken";

// model/user/StakeButtonValue.js
init_db();
import { DataTypes as DataTypes18 } from "sequelize";
var StakeButtonValue = db_default.define("StakeButtonValue", {
  id: {
    type: DataTypes18.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  user_id: {
    type: DataTypes18.INTEGER,
    allowNull: false,
    references: {
      model: "users",
      // Assuming your user table is named 'users'
      key: "user_id"
    }
  },
  game_buttons: {
    type: DataTypes18.JSON,
    allowNull: false,
    defaultValue: [],
    comment: "Array of { label: string, value: number } for Sports"
  }
}, {
  tableName: "stake_button_values",
  timestamps: true
});
var StakeButtonValue_default = StakeButtonValue;

// services/user/StakeButtonService.js
var DEFAULT_GAME_BUTTONS = [
  { label: "1k", value: 1e3 },
  { label: "2k", value: 2e3 },
  { label: "5k", value: 5e3 },
  { label: "10k", value: 1e4 },
  { label: "20k", value: 2e4 },
  { label: "25k", value: 25e3 }
];
var tableReady = null;
var ensureTable = () => {
  if (!tableReady) {
    tableReady = StakeButtonValue_default.sync().catch((e) => {
      tableReady = null;
      throw e;
    });
  }
  return tableReady;
};
var MAX_GAME_BUTTONS = 6;
var cleanButtons = (list, fallback, max = Infinity) => {
  if (!Array.isArray(list)) return fallback;
  const rows = list.filter((b) => b && Number(b.value) > 0).map((b) => ({ label: String(b.label ?? "").trim(), value: Number(b.value) })).slice(0, max);
  return rows.length ? rows : fallback;
};
var seedForUser = async (userId, transaction = void 0) => {
  if (!userId) return null;
  try {
    await ensureTable();
    const [row] = await StakeButtonValue_default.findOrCreate({
      where: { user_id: userId },
      defaults: {
        user_id: userId,
        game_buttons: DEFAULT_GAME_BUTTONS
      },
      ...transaction ? { transaction } : {}
    });
    return row;
  } catch (err) {
    console.error("seedForUser (stake buttons) failed for user", userId, err.message);
    return null;
  }
};

// controller/user/StakeButtonValueController.js
var playerIdFromToken = (req) => {
  try {
    const header = req.header("Authorization");
    if (!header) return null;
    const token = header.replace("Bearer ", "").trim();
    if (!token || token === "null" || token === "undefined") return null;
    const decoded = jwt2.verify(token, process.env.JWT_SECRET);
    if (decoded.user_id) return decoded.user_id;
    return decoded.account?.type === "USER" ? decoded.account.id : null;
  } catch {
    return null;
  }
};
var cleanGame = (list) => cleanButtons(list, DEFAULT_GAME_BUTTONS, MAX_GAME_BUTTONS);
var StakeButtonValueController = {
  // GET /user/stake-button-values
  // Logged in  → that user's own ladder (created with the defaults on first read).
  // Logged out → the defaults, with nothing written.
  getStakeButtonValues: async (req, res) => {
    try {
      const userId = playerIdFromToken(req);
      if (!userId) {
        return res.status(200).json({
          success: true,
          data: { game_buttons: DEFAULT_GAME_BUTTONS }
        });
      }
      const row = await seedForUser(userId);
      res.status(200).json({
        success: true,
        data: {
          game_buttons: cleanGame(row?.game_buttons)
        }
      });
    } catch (error) {
      console.error("Error fetching stake button values:", error);
      res.status(500).json({ success: false, error: "Failed to fetch button values" });
    }
  },
  // POST /user/stake-button-values — writes ONLY the caller's own row.
  updateStakeButtonValues: async (req, res) => {
    try {
      const userId = playerIdFromToken(req);
      if (!userId) {
        return res.status(403).json({ success: false, error: "Only a player account can set stake buttons" });
      }
      const { game_buttons } = req.body;
      if (!game_buttons) {
        return res.status(400).json({ success: false, error: "No data provided to update" });
      }
      await ensureTable();
      const row = await seedForUser(userId);
      if (!row) {
        return res.status(500).json({ success: false, error: "Failed to load button values" });
      }
      if (game_buttons) row.game_buttons = cleanGame(game_buttons);
      await row.save();
      res.status(200).json({
        success: true,
        data: {
          game_buttons: cleanGame(row.game_buttons)
        }
      });
    } catch (error) {
      console.error("Error updating stake button values:", error);
      res.status(500).json({ success: false, error: "Failed to update button values" });
    }
  }
};
var StakeButtonValueController_default = StakeButtonValueController;

// model/user/OneClickButtonList.js
init_db();
import { DataTypes as DataTypes19 } from "sequelize";
var OneClickButtonList = db_default.define("OneClickButtonList", {
  id: {
    type: DataTypes19.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  user_id: {
    type: DataTypes19.INTEGER,
    allowNull: false,
    unique: true,
    references: {
      model: "users",
      key: "user_id"
    }
  },
  buttons: {
    type: DataTypes19.JSON,
    allowNull: false,
    defaultValue: [100, 200, 300],
    comment: "Array of 3 numbers for 1-Click Betting stakes"
  }
}, {
  tableName: "oneclick_button_lists",
  timestamps: true
});
var OneClickButtonList_default = OneClickButtonList;

// controller/user/OneClickButtonListController.js
var DEFAULT_BUTTONS = [100, 200, 300];
var tableReady2 = null;
var ensureTable2 = () => {
  if (!tableReady2) {
    tableReady2 = OneClickButtonList_default.sync().catch((e) => {
      tableReady2 = null;
      throw e;
    });
  }
  return tableReady2;
};
var OneClickButtonListController = {
  // GET /user/buttonlist — the user's 1-Click Betting stake values
  getButtonList: async (req, res) => {
    try {
      const userId = req.user.account.id;
      await ensureTable2();
      const row = await OneClickButtonList_default.findOne({ where: { user_id: userId } });
      const buttons = row && Array.isArray(row.buttons) && row.buttons.length === 3 ? row.buttons : DEFAULT_BUTTONS;
      res.status(200).json({ success: true, data: { buttons } });
    } catch (error) {
      console.error("Error fetching one-click button list:", error);
      res.status(500).json({ success: false, error: "Failed to fetch button list" });
    }
  },
  // POST /user/updatebuttonlist — save the user's 1-Click Betting stake values
  updateButtonList: async (req, res) => {
    try {
      const userId = req.user.account.id;
      const { buttons } = req.body;
      const clean = Array.isArray(buttons) ? buttons.map((n) => parseInt(n, 10)).filter((n) => Number.isFinite(n) && n > 0) : [];
      if (clean.length !== 3) {
        return res.status(400).json({ success: false, error: "buttons must be an array of 3 positive numbers" });
      }
      await ensureTable2();
      const [row] = await OneClickButtonList_default.findOrCreate({
        where: { user_id: userId },
        defaults: { buttons: clean }
      });
      if (JSON.stringify(row.buttons) !== JSON.stringify(clean)) {
        row.buttons = clean;
        await row.save();
      }
      res.status(200).json({
        success: true,
        message: "Button list updated successfully",
        data: { buttons: row.buttons }
      });
    } catch (error) {
      console.error("Error updating one-click button list:", error);
      res.status(500).json({ success: false, error: "Failed to update button list" });
    }
  }
};
var OneClickButtonListController_default = OneClickButtonListController;

// sportsbet/sportbetscontroller.js
import xssClean from "xss-clean";
import fetch from "node-fetch";

// model/user/UserExposure.js
init_db();
import { DataTypes as DataTypes20 } from "sequelize";
var UserExposure = db_default.define(
  "UserExposure",
  {
    id: {
      type: DataTypes20.INTEGER,
      autoIncrement: true,
      primaryKey: true
    },
    user_id: {
      type: DataTypes20.BIGINT,
      allowNull: false
    },
    match_id: {
      type: DataTypes20.STRING,
      allowNull: false
    },
    event_id: {
      type: DataTypes20.STRING,
      allowNull: true
    },
    team_name: {
      type: DataTypes20.STRING,
      allowNull: false
    },
    exposure_amount: {
      type: DataTypes20.DECIMAL(15, 2),
      allowNull: false,
      defaultValue: 0
    },
    match_title: {
      type: DataTypes20.STRING(255),
      allowNull: true
    },
    game_type: {
      type: DataTypes20.STRING(100),
      allowNull: true
    },
    category: {
      type: DataTypes20.STRING(100),
      allowNull: true
      // or false if DB has NOT NULL
    },
    created_at: {
      type: DataTypes20.DATE,
      allowNull: false,
      defaultValue: DataTypes20.NOW
    },
    updated_at: {
      type: DataTypes20.DATE,
      allowNull: false,
      defaultValue: DataTypes20.NOW
    }
  },
  {
    tableName: "user_exposures",
    timestamps: false,
    // we manually manage timestamps
    indexes: [
      {
        unique: true,
        fields: ["user_id", "match_id", "team_name", "game_type"]
      }
    ]
  }
);
var UserExposure_default = UserExposure;

// helper/meterMarket.js
var METER_MAX_RUNS = 150;
var isMeterMarket = (marketType) => ["meter", "meters"].includes(String(marketType || "").toLowerCase());
var isYesSide = (betType) => ["yes", "back"].includes(String(betType || "").toLowerCase());
function meterPnl({ runs, line, stake, betType }) {
  const capped = Math.min(Number(runs), Number(line) + METER_MAX_RUNS);
  const diff = (capped - Number(line)) * Number(stake);
  const signed = isYesSide(betType) ? diff : -diff;
  return signed === 0 ? 0 : signed;
}
function meterLiability({ line, stake, betType }) {
  return isYesSide(betType) ? Number(line) * Number(stake) : METER_MAX_RUNS * Number(stake);
}

// helper/lineMarket.js
var isLineMarket = (marketType) => /\bline$/i.test(String(marketType || "").trim());
var isYesSide2 = (betType) => ["yes", "back"].includes(String(betType || "").toLowerCase());
var lineBetWon = ({ runs, line, betType }) => isYesSide2(betType) ? Number(runs) >= Number(line) : Number(runs) < Number(line);
var linePnl = ({ runs, line, stake, betType }) => (lineBetWon({ runs, line, betType }) ? 1 : -1) * Number(stake);
var LINE_EXPOSURE_GAME_TYPE = "fancy2";
var exposureIdentity = ({ marketType, selectionName, badlo = false }) => isLineMarket(marketType) ? { game_type: LINE_EXPOSURE_GAME_TYPE, team_name: String(marketType) } : { game_type: marketType, team_name: selectionName };

// helper/badloMarket.js
var isBadloBet = (bet) => bet?.badlo === true || String(bet?.badlo) === "true";
var BADLO_EXPOSURE_GAME_TYPE = "badlo";
var isYesSide3 = (betType) => ["yes", "back"].includes(String(betType || "").toLowerCase());
function badloPnl({ runs, line, stake, betType }) {
  if (Number(runs) !== Number(line)) return 0;
  const signed = (isYesSide3(betType) ? 1 : -1) * Number(stake);
  return signed === 0 ? 0 : signed;
}
function badloLiability({ stake, betType }) {
  return isYesSide3(betType) ? 0 : Number(stake);
}

// sportsbet/sportbetscontroller.js
init_TotalExposure();
init_db();

// model/admin/PlatformGames.js
init_db();
import { DataTypes as DataTypes22 } from "sequelize";
var PlatformGames = db_default.define(
  "PlatformGames",
  {
    id: {
      type: DataTypes22.INTEGER,
      primaryKey: true,
      allowNull: false
    },
    name: {
      type: DataTypes22.STRING,
      allowNull: false,
      unique: true
    },
    sport_id: {
      type: DataTypes22.TEXT,
      allowNull: true,
      unique: true
    }
  },
  {
    tableName: "platform_games",
    timestamps: false
  }
);
PlatformGames.FIXED_GAMES = [
  { id: 4, name: "Cricket", sport_id: "4" },
  { id: 65, name: "Greyhound", sport_id: "65" },
  { id: 10, name: "HorseRace", sport_id: "10" },
  { id: 1, name: "Soccer", sport_id: "1" },
  { id: 2, name: "Tennis", sport_id: "2" }
];
PlatformGames.syncFixedData = async () => {
  for (const game of PlatformGames.FIXED_GAMES) {
    await PlatformGames.findOrCreate({
      where: { id: game.id },
      defaults: game
    });
  }
  console.log("\u2705 PlatformGames table verified and fixed data ensured.");
};
var PlatformGames_default = PlatformGames;

// sportsbet/sportbetscontroller.js
import axios5 from "axios";
import { Op as Op6, Sequelize as Sequelize2 } from "sequelize";

// model/admin/UserMatchLocks.js
init_db();
import { DataTypes as DataTypes23 } from "sequelize";
var UserMatchLocks = db_default.define(
  "UserMatchLocks",
  {
    id: {
      type: DataTypes23.BIGINT,
      primaryKey: true,
      autoIncrement: true
    },
    user_id: {
      type: DataTypes23.BIGINT,
      allowNull: false
    },
    event_id: {
      type: DataTypes23.STRING,
      allowNull: false
    },
    is_locked: {
      type: DataTypes23.BOOLEAN,
      defaultValue: true
    }
  },
  {
    tableName: "user_match_locks",
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    indexes: [
      {
        unique: true,
        fields: ["user_id", "event_id"]
      }
    ]
  }
);
var UserMatchLocks_default = UserMatchLocks;

// model/admin/UserEventMarketLocks.js
init_db();
import { DataTypes as DataTypes24 } from "sequelize";
var UserEventMarketLocks = db_default.define(
  "UserEventMarketLocks",
  {
    id: {
      type: DataTypes24.BIGINT,
      primaryKey: true,
      autoIncrement: true
    },
    account_id: {
      type: DataTypes24.BIGINT,
      allowNull: false,
      comment: "staff_id or user_id"
    },
    account_type: {
      type: DataTypes24.ENUM("staff", "user"),
      allowNull: false
    },
    event_id: {
      type: DataTypes24.STRING,
      allowNull: false
    },
    market_id: {
      type: DataTypes24.STRING,
      allowNull: true,
      comment: "Primary identifier for the market (mid)"
    },
    market_name: {
      type: DataTypes24.STRING,
      allowNull: true,
      comment: "Fallback: e.g. MATCH_ODDS, bookmaker, Normal, fancy1, etc."
    },
    is_locked: {
      type: DataTypes24.BOOLEAN,
      defaultValue: true
    },
    locked_by: {
      type: DataTypes24.BIGINT,
      allowNull: true,
      comment: "staff_id or owner_id who locked"
    }
  },
  {
    tableName: "user_event_market_locks",
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    indexes: [
      {
        unique: true,
        name: "uq_event_market_lock",
        fields: ["account_id", "account_type", "event_id", "market_id"]
      }
    ]
  }
);
var UserEventMarketLocks_default = UserEventMarketLocks;

// services/BetLockService.js
var isBettingAllowed = async (userId, options = {}) => {
  const tx = options.transaction ? { transaction: options.transaction } : {};
  try {
    const user = await User_default.findByPk(userId, {
      attributes: ["user_id", "bet_locked", "parent_staff_id", "parent_owner_id"],
      ...tx
    });
    if (!user) {
      console.error(`BetLock: User ${userId} not found`);
      return false;
    }
    if (user.bet_locked) {
      console.log(`BetLock: User ${userId} is directly locked.`);
      return false;
    }
    if (user.parent_owner_id) {
      return true;
    }
    let currentStaffId = user.parent_staff_id;
    while (currentStaffId) {
      const staff = await Staff_default.findByPk(currentStaffId, {
        attributes: ["staff_id", "bet_locked", "parent_id", "parent_owner_id"],
        ...tx
      });
      if (!staff) {
        break;
      }
      if (staff.bet_locked) {
        console.log(`BetLock: User ${userId} blocked by Staff ${currentStaffId}`);
        return false;
      }
      if (staff.parent_owner_id) {
        return true;
      }
      currentStaffId = staff.parent_id;
    }
    return true;
  } catch (error) {
    console.error("Error in isBettingAllowed:", error);
    return false;
  }
};
var BetLockService_default = { isBettingAllowed };

// model/user/DebitLedger.js
init_db();
import { DataTypes as DataTypes25 } from "sequelize";
var DebitLedger = db_default.define(
  "DebitLedger",
  {
    id: {
      type: DataTypes25.BIGINT,
      primaryKey: true,
      autoIncrement: true
    },
    user_id: { type: DataTypes25.TEXT, allowNull: false },
    currency: { type: DataTypes25.TEXT, allowNull: true, defaultValue: "INR" },
    amount: { type: DataTypes25.DECIMAL, allowNull: false },
    // raw win amount
    reason: { type: DataTypes25.TEXT, allowNull: false },
    description: { type: DataTypes25.TEXT, allowNull: true },
    event_id: { type: DataTypes25.TEXT, allowNull: true },
    job_id: { type: DataTypes25.UUID, allowNull: true },
    match_id: { type: DataTypes25.TEXT, allowNull: true },
    meta: { type: DataTypes25.JSONB, allowNull: true },
    balance: { type: DataTypes25.DECIMAL(15, 2), allowNull: true },
    market_type: { type: DataTypes25.TEXT, allowNull: true },
    sport_id: { type: DataTypes25.TEXT, allowNull: true },
    commission: {
      type: DataTypes25.DECIMAL(18, 2),
      allowNull: true,
      comment: "2% platform fee deducted from the winning amount (null for losses / non-win entries)"
    },
    finalAmount: {
      type: DataTypes25.DECIMAL(18, 2),
      allowNull: true,
      comment: "amount credited to user after commission (amount - commission). Null for non-winning rows."
    },
    created_at: {
      type: DataTypes25.DATE,
      allowNull: true,
      defaultValue: DataTypes25.NOW
    }
  },
  {
    tableName: "debit_ledger",
    timestamps: false,
    indexes: [
      { name: "debit_ledger_user_id_idx", fields: ["user_id"] },
      { name: "debit_ledger_event_id_idx", fields: ["event_id"] },
      { name: "debit_ledger_created_at_idx", fields: ["created_at"] }
    ]
  }
);
var DebitLedger_default = DebitLedger;

// model/user/CreditsLedger.js
init_db();
import { DataTypes as DataTypes26 } from "sequelize";
var CreditsLedger = db_default.define(
  "CreditsLedger",
  {
    id: {
      type: DataTypes26.BIGINT,
      primaryKey: true,
      autoIncrement: true
    },
    user_id: {
      type: DataTypes26.TEXT,
      allowNull: false
    },
    bet_id: {
      type: DataTypes26.BIGINT,
      allowNull: true,
      comment: "Related bet ID for this ledger entry"
    },
    currency: {
      type: DataTypes26.TEXT,
      allowNull: true,
      defaultValue: "INR"
    },
    amount: {
      type: DataTypes26.DECIMAL,
      allowNull: false,
      comment: "Raw transaction amount (+win / -loss)"
    },
    reason: {
      type: DataTypes26.TEXT,
      allowNull: false
    },
    description: {
      type: DataTypes26.TEXT,
      allowNull: true
    },
    eventid: {
      type: DataTypes26.TEXT,
      allowNull: true
    },
    job_id: {
      type: DataTypes26.UUID,
      allowNull: true
    },
    match_id: {
      type: DataTypes26.TEXT,
      allowNull: true
    },
    meta: {
      type: DataTypes26.JSONB,
      allowNull: true
    },
    market_type: {
      type: DataTypes26.TEXT,
      allowNull: true
    },
    sport_id: {
      type: DataTypes26.TEXT,
      allowNull: true
    },
    commission: {
      type: DataTypes26.DECIMAL(18, 2),
      allowNull: true,
      comment: "2% platform fee deducted from winning amount (NULL for losses / non-win)"
    },
    netamount: {
      type: DataTypes26.DECIMAL(18, 2),
      allowNull: true,
      comment: "Amount credited after commission (amount - commission). NULL for non-win"
    },
    profit: {
      type: DataTypes26.DECIMAL(18, 2),
      allowNull: true,
      comment: "Winning amount (only for wins)"
    },
    loss: {
      type: DataTypes26.DECIMAL(18, 2),
      allowNull: true,
      comment: "Loss amount (only for losses)"
    },
    closing: {
      type: DataTypes26.DECIMAL(18, 2),
      allowNull: true,
      comment: "Closing amount (only for current user proffit ratio)"
    },
    category: {
      type: DataTypes26.STRING(20),
      allowNull: true,
      comment: "SPORTS - identifies settlement source"
    },
    points_applied: {
      type: DataTypes26.BOOLEAN,
      allowNull: false,
      defaultValue: false
    },
    balance: {
      type: DataTypes26.DECIMAL(18, 2),
      allowNull: true,
      defaultValue: 0,
      comment: "User wallet balance after this ledger entry"
    },
    created_at: {
      type: DataTypes26.DATE,
      allowNull: true,
      defaultValue: DataTypes26.NOW
    }
  },
  {
    tableName: "credits_ledger",
    timestamps: false,
    indexes: [
      { name: "credits_ledger_user_id_idx", fields: ["user_id"] },
      { name: "credits_ledger_eventid_idx", fields: ["eventid"] },
      { name: "credits_ledger_created_at_idx", fields: ["created_at"] }
    ]
  }
);
var CreditsLedger_default = CreditsLedger;

// controller/admin/SportsLockController.js
import { Op as Op5 } from "sequelize";

// model/admin/StaffSportsLock.js
init_db();
import { DataTypes as DataTypes27 } from "sequelize";
var StaffSportsLock = db_default.define("StaffSportsLock", {
  id: {
    type: DataTypes27.BIGINT,
    autoIncrement: true,
    primaryKey: true
  },
  staff_id: {
    type: DataTypes27.INTEGER,
    allowNull: true,
    references: {
      model: Staff_default,
      key: "staff_id"
    },
    onDelete: "CASCADE"
  },
  owner_id: {
    type: DataTypes27.INTEGER,
    allowNull: true,
    references: {
      model: Owner_default,
      key: "owner_id"
    },
    onDelete: "CASCADE"
  },
  // Dynamic String IDs for Sports Hierarchy
  // "4", "4-0", "1.12345678", "1.12345678-0"
  sport_id: {
    type: DataTypes27.STRING,
    allowNull: false
  },
  series_id: {
    type: DataTypes27.STRING,
    allowNull: true
  },
  match_id: {
    type: DataTypes27.STRING,
    allowNull: true
  },
  market_id: {
    type: DataTypes27.STRING,
    allowNull: true
  },
  lock_type: {
    type: DataTypes27.STRING,
    allowNull: true
  },
  is_locked: {
    type: DataTypes27.BOOLEAN,
    defaultValue: true
  }
}, {
  tableName: "staff_sports_lock",
  timestamps: true,
  createdAt: "created_at",
  updatedAt: "updated_at",
  indexes: [
    {
      name: "staff_sports_lock_unique_idx",
      unique: true,
      fields: ["staff_id", "owner_id", "sport_id", "series_id", "match_id", "market_id"]
    }
  ]
});
Staff_default.hasMany(StaffSportsLock, { foreignKey: "staff_id" });
StaffSportsLock.belongsTo(Staff_default, { foreignKey: "staff_id" });
Owner_default.hasMany(StaffSportsLock, { foreignKey: "owner_id" });
StaffSportsLock.belongsTo(Owner_default, { foreignKey: "owner_id" });
var StaffSportsLock_default = StaffSportsLock;

// model/admin/UserSportsLock.js
init_db();
import { DataTypes as DataTypes28 } from "sequelize";
var UserSportsLock = db_default.define("UserSportsLock", {
  id: {
    type: DataTypes28.BIGINT,
    autoIncrement: true,
    primaryKey: true
  },
  user_id: {
    type: DataTypes28.BIGINT,
    allowNull: false
  },
  // Dynamic String IDs
  sport_id: {
    type: DataTypes28.STRING,
    allowNull: false
  },
  series_id: {
    type: DataTypes28.STRING,
    allowNull: true
  },
  match_id: {
    type: DataTypes28.STRING,
    allowNull: true
  },
  market_id: {
    type: DataTypes28.STRING,
    allowNull: true
  },
  lock_type: {
    type: DataTypes28.STRING,
    allowNull: true
  },
  is_locked: {
    type: DataTypes28.BOOLEAN,
    defaultValue: true
  }
}, {
  tableName: "user_sports_lock",
  timestamps: true,
  createdAt: "created_at",
  updatedAt: "updated_at",
  indexes: [
    {
      name: "user_sports_lock_unique_idx",
      unique: true,
      fields: ["user_id", "sport_id", "series_id", "match_id", "market_id"]
    }
  ]
});
var UserSportsLock_default = UserSportsLock;

// helper/uplineLevelNo.js
var OWNER_UPLINE_NO = 7;
var uplineNo = (level) => {
  const l = parseInt(String(level || "").replace(/\D/g, ""), 10);
  return Number.isNaN(l) ? OWNER_UPLINE_NO : 1 + (6 - l);
};

// controller/admin/SportsLockController.js
var SportsLockController = {
  // Get locks for a target
  getSportsLocks: async (req, res) => {
    try {
      const { targetId } = req.params;
      const { type } = req.query;
      console.log("DEBUG getSportsLocks:", { targetId, type, reqUser: req.user });
      if (!targetId || !type) {
        return res.status(400).json({ success: false, message: "Missing targetId or type" });
      }
      let locks = [];
      if (type === "USER") {
        locks = await UserSportsLock_default.findAll({ where: { user_id: targetId } });
      } else if (type === "OWNER") {
        locks = await StaffSportsLock_default.findAll({ where: { owner_id: targetId } });
      } else {
        locks = await StaffSportsLock_default.findAll({ where: { staff_id: targetId } });
      }
      return res.status(200).json({
        success: true,
        data: locks
      });
    } catch (error) {
      console.error("Error fetching sports locks:", error);
      return res.status(500).json({ success: false, message: "Internal Server Error" });
    }
  },
  // Update Lock (Toggle)
  updateSportsLock: async (req, res) => {
    try {
      const {
        targetId,
        targetType,
        // 'USER', 'STAFF', 'OWNER'
        sportId,
        seriesId,
        matchId,
        marketId,
        isLocked
      } = req.body;
      console.log("DEBUG updateSportsLock:", req.body, req.user);
      const loggedInId = req.user.account ? req.user.account.id : req.user.id;
      const loggedInRole = req.user.role;
      if (targetType === "OWNER") {
        if (loggedInRole !== "OWNER") {
          return res.status(403).json({ success: false, message: "Only Owner can manage Owner locks" });
        }
      }
      let lock;
      const sportIdStr = sportId ? String(sportId) : null;
      const seriesIdStr = seriesId ? String(seriesId) : null;
      const matchIdStr = matchId ? String(matchId) : null;
      const marketIdStr = marketId ? String(marketId) : null;
      const lockData = {
        sport_id: sportIdStr,
        series_id: seriesIdStr,
        match_id: matchIdStr,
        market_id: marketIdStr,
        is_locked: isLocked
      };
      const uniqueWhere = {
        sport_id: sportIdStr,
        series_id: seriesIdStr,
        match_id: matchIdStr,
        market_id: marketIdStr
      };
      if (targetType === "USER") {
        uniqueWhere.user_id = targetId;
        if (req.body.lockType) uniqueWhere.lock_type = req.body.lockType;
        lock = await UserSportsLock_default.findOne({ where: uniqueWhere });
        if (lock) {
          lock.is_locked = isLocked;
          await lock.save();
        } else {
          lock = await UserSportsLock_default.create({
            ...lockData,
            user_id: targetId,
            lock_type: req.body.lockType || (marketIdStr ? "MARKET" : matchIdStr ? "MATCH" : seriesIdStr ? "SERIES" : "SPORT")
          });
        }
      } else {
        if (targetType === "OWNER") {
          uniqueWhere.owner_id = targetId;
          uniqueWhere.staff_id = null;
          lockData.owner_id = targetId;
          lockData.staff_id = null;
        } else {
          uniqueWhere.staff_id = targetId;
          uniqueWhere.owner_id = null;
          lockData.staff_id = targetId;
          lockData.owner_id = null;
        }
        if (req.body.lockType) uniqueWhere.lock_type = req.body.lockType;
        lock = await StaffSportsLock_default.findOne({ where: uniqueWhere });
        if (lock) {
          lock.is_locked = isLocked;
          await lock.save();
        } else {
          lock = await StaffSportsLock_default.create({
            ...lockData,
            lock_type: req.body.lockType || (marketIdStr ? "MARKET" : matchIdStr ? "MATCH" : seriesIdStr ? "SERIES" : "SPORT")
          });
        }
      }
      return res.status(200).json({ success: true, data: lock });
    } catch (error) {
      console.error("Error updating sports lock:", error);
      if (error.name === "SequelizeUniqueConstraintError") {
        return res.status(400).json({ success: false, message: "Lock already exists, please refresh." });
      }
      return res.status(500).json({ success: false, message: "Internal Server Error" });
    }
  },
  /**
   * Check if a bet is locked for a user via sports lock hierarchy.
   * Checks: User locks → Parent staff locks → up to Owner locks.
   * At each level checks: Sport → Series → Match → Market (broader lock blocks narrower).
   *
   * @param {number} userId - The user placing the bet
   * @param {string} sportId - Sport ID (e.g. "4" for Cricket)
   * @param {string|null} seriesId - Series/competition name (nullable)
   * @param {string|null} matchId - Match/event ID (nullable)
   * @param {string|null} marketId - Market ID (nullable)
   * @returns {{ allowed: boolean, message: string }}
   */
  // `options.transaction`: see BetLockService.isBettingAllowed — placeBet
  // passes its transaction so the check does not need a second connection.
  checkSportsLock: async (userId, sportId, seriesId, matchId, marketId, options = {}) => {
    const tx = options.transaction ? { transaction: options.transaction } : {};
    try {
      if (!userId || !sportId) return { allowed: true };
      const sportIdStr = String(sportId);
      const isBlockedByLocks = (locks) => {
        for (const lock of locks) {
          if (!lock.is_locked) continue;
          if (!lock.series_id && !lock.match_id && !lock.market_id) {
            return { blocked: true, reason: "Sport is locked" };
          }
          if (lock.series_id && !lock.match_id && !lock.market_id) {
            if (seriesId && String(lock.series_id) === String(seriesId)) {
              return { blocked: true, reason: "Series is locked" };
            }
          }
          if (lock.match_id && !lock.market_id) {
            if (matchId && String(lock.match_id) === String(matchId)) {
              return { blocked: true, reason: "Match is locked" };
            }
          }
          if (lock.market_id) {
            if (matchId && String(lock.match_id) === String(matchId) && marketId && String(lock.market_id) === String(marketId)) {
              return { blocked: true, reason: "Market is locked" };
            }
          }
        }
        return { blocked: false };
      };
      const userLocks = await UserSportsLock_default.findAll({
        where: { user_id: userId, sport_id: sportIdStr, is_locked: true },
        raw: true,
        ...tx
      });
      const userCheck = isBlockedByLocks(userLocks);
      const user = await User_default.findOne({
        where: { user_id: userId },
        attributes: ["parent_staff_id", "parent_owner_id"],
        raw: true,
        ...tx
      });
      if (!user) {
        return userCheck.blocked ? { allowed: false, message: MESSAGES.BET.GAME_LOCKED_CONTACT_UPLINE(OWNER_UPLINE_NO) } : { allowed: true };
      }
      const chain = [];
      let currentStaffId = user.parent_staff_id;
      while (currentStaffId) {
        const staff = await Staff_default.findOne({
          where: { staff_id: currentStaffId },
          attributes: ["parent_id", "level"],
          raw: true,
          ...tx
        });
        chain.push({ id: currentStaffId, level: staff?.level });
        currentStaffId = staff?.parent_id || null;
      }
      const staffIds = chain.map((s) => s.id);
      if (userCheck.blocked) {
        const n = chain.length ? uplineNo(chain[0].level) : OWNER_UPLINE_NO;
        return { allowed: false, message: MESSAGES.BET.GAME_LOCKED_CONTACT_UPLINE(n) };
      }
      if (staffIds.length > 0) {
        const staffLocks = await StaffSportsLock_default.findAll({
          where: {
            staff_id: { [Op5.in]: staffIds },
            sport_id: sportIdStr,
            is_locked: true
          },
          raw: true,
          ...tx
        });
        for (const s of chain) {
          const own = staffLocks.filter((l) => String(l.staff_id) === String(s.id));
          if (isBlockedByLocks(own).blocked) {
            return { allowed: false, message: MESSAGES.BET.GAME_LOCKED_CONTACT_UPLINE(uplineNo(s.level)) };
          }
        }
      }
      if (user.parent_owner_id) {
        const ownerLocks = await StaffSportsLock_default.findAll({
          where: { owner_id: user.parent_owner_id, staff_id: null, sport_id: sportIdStr, is_locked: true },
          raw: true,
          ...tx
        });
        const ownerCheck = isBlockedByLocks(ownerLocks);
        if (ownerCheck.blocked) {
          return { allowed: false, message: MESSAGES.BET.GAME_LOCKED_CONTACT_UPLINE(OWNER_UPLINE_NO) };
        }
      }
      return { allowed: true };
    } catch (error) {
      console.error("\u274C checkSportsLock error:", error);
      return { allowed: true };
    }
  }
};
var SportsLockController_default = SportsLockController;

// helper/cricketFormat.js
var TEST_FORMAT_RE = /\btest\b|ashes|first[\s-]?class|county\s+champ|sheffield\s+shield|ranji|plunket/i;
var isCricketTestFormat = (text) => TEST_FORMAT_RE.test(String(text || ""));

// services/SportsLeagueResolver.js
init_redisClient();
var EVENT_LIST_KEY = (etid) => `alleventss:${etid}`;
var LEAGUE_KEY = (gmid) => `league:evt:${gmid}`;
var LEAGUE_TTL_SEC = 12 * 60 * 60;
var MICRO_TTL_MS2 = 5e3;
var micro2 = /* @__PURE__ */ new Map();
var MICRO_MAX = 500;
var microGet2 = (gmid) => {
  const hit = micro2.get(gmid);
  if (!hit) return void 0;
  if (hit.expires < Date.now()) {
    micro2.delete(gmid);
    return void 0;
  }
  return hit.value;
};
var microSet2 = (gmid, value) => {
  if (micro2.size >= MICRO_MAX) micro2.clear();
  micro2.set(gmid, { value, expires: Date.now() + MICRO_TTL_MS2 });
};
var shape = (game) => ({
  cname: game?.cname ? String(game.cname) : null,
  cid: game?.cid != null ? Number(game.cid) : null,
  iscc: game?.iscc != null ? Number(game.iscc) : null
});
var resolveLeague = async (sportId, gmid) => {
  const key = String(gmid || "").trim();
  if (!key || !sportId) return null;
  const local = microGet2(key);
  if (local !== void 0) return local;
  try {
    const cached = await redisClient_default.get(LEAGUE_KEY(key));
    if (cached != null) {
      const parsed = JSON.parse(cached);
      microSet2(key, parsed);
      return parsed;
    }
  } catch (err) {
    console.warn("[LeagueResolver] redis read failed:", err.message);
  }
  let found = null;
  try {
    const raw = await redisClient_default.get(EVENT_LIST_KEY(sportId));
    if (raw) {
      const data = JSON.parse(raw);
      const games = [...data?.t1 || [], ...data?.t2 || []];
      const hit = games.find((g) => String(g?.gmid) === key);
      if (hit?.cname) found = shape(hit);
    }
  } catch (err) {
    console.warn("[LeagueResolver] event list read failed:", err.message);
  }
  if (found) {
    microSet2(key, found);
    redisClient_default.set(LEAGUE_KEY(key), JSON.stringify(found), "EX", LEAGUE_TTL_SEC).catch((err) => console.warn("[LeagueResolver] redis write failed:", err.message));
  } else {
    microSet2(key, null);
  }
  return found;
};
var resolveLeagueName = async (sportId, gmid) => {
  const hit = await resolveLeague(sportId, gmid);
  return hit?.cname || null;
};
var leagueNameForBet = async (sportId, gmid, clientLeagueName) => {
  const resolved = await resolveLeagueName(sportId, gmid);
  if (resolved) return String(resolved).slice(0, 255);
  const fromClient = String(clientLeagueName || "").trim();
  return fromClient ? fromClient.slice(0, 255) : null;
};

// helper/totalExposure.js
init_db();
init_TotalExposure();
import { QueryTypes } from "sequelize";
var TOTAL_EXPOSURE_SQL = `
  SELECT COALESCE(SUM(market_exposure), 0) AS total_exposure
  FROM (
    /* Team markets (match odds / bookmaker \u2026): only the worst runner is at
       risk, so they are grouped per market. */
    SELECT MIN(exposure_amount) AS market_exposure
    FROM user_exposures
    WHERE
      user_id = :user_id
      AND game_type IS NOT NULL
      AND (category IS NOT NULL OR game_type LIKE '%:%')
      AND game_type NOT IN (
        'Normal', 'Ball By Ball', 'Over By Over',
        'khado', 'meter', 'fancy1', 'oddeven', 'fancy2', 'badlo'
      )
      AND game_type NOT LIKE '%Overs Line%'
      AND NOT (
        team_name ILIKE '%back'
        OR team_name ILIKE '%lay'
        OR team_name ILIKE '%totalstake'
      )
    GROUP BY match_id, game_type, event_id

    UNION ALL

    /* Independent rows: fancy-family markets (one row each). */
    SELECT exposure_amount AS market_exposure
    FROM user_exposures
    WHERE
      user_id = :user_id
      AND (
        game_type IS NULL
        OR game_type IN (
          'Normal', 'Ball By Ball', 'Over By Over',
          'khado', 'meter', 'fancy1', 'oddeven', 'fancy2', 'badlo'
        )
        OR game_type LIKE '%Overs Line%'
      )
      AND NOT (
        team_name ILIKE '%back'
        OR team_name ILIKE '%lay'
        OR team_name ILIKE '%totalstake'
      )
  ) subquery;
`;
var recalcTotalExposure = async (userId, transaction = null) => {
  const opts = transaction ? { transaction } : {};
  const rows = await db_default.query(TOTAL_EXPOSURE_SQL, {
    replacements: { user_id: String(userId) },
    type: QueryTypes.SELECT,
    ...opts
  });
  const total = parseFloat(rows[0]?.total_exposure) || 0;
  await TotalExposure_default.upsert(
    { user_id: Number(userId), total_exposure: total },
    opts
  );
  return total;
};

// sportsbet/betBufferRules.js
var EPSILON = 1e-3;
var FANCY_EPSILON = 0.01;
var normalizeName = (s) => String(s || "").trim().toLowerCase();
var isLaySide = (betType) => betType === "lay" || betType === "no";
var feedSideFor = (betType, inverted = false) => {
  const lay = isLaySide(betType);
  return (inverted ? !lay : lay) ? "lay" : "back";
};
function isBlockedGameStatus(gs) {
  switch (gs) {
    case "SUSPENDED":
    case "BALL RUNNING":
    case "INACTIVE":
      return true;
    default:
      return false;
  }
}
function isBookieFavourMarket(marketType) {
  const mt = String(marketType || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
  return mt === "MATCHODDS" || mt === "BOOKMAKER" || mt === "BOOKMAKER2" || mt === "TIEDMATCH";
}
var findMarket = (marketList, marketId) => (marketList || []).find((m) => String(m?.mid) === String(marketId)) || null;
function findRunner(mkt, selectionId, runnerName) {
  if (!mkt?.section) return null;
  if (selectionId) {
    return mkt.section.find((s) => String(s.sid) === String(selectionId)) || null;
  }
  const wantNat = normalizeName(runnerName);
  return mkt.section.find((s) => normalizeName(s.nat) === wantNat) || (mkt.section.length === 1 ? mkt.section[0] : null);
}
var runnerGameStatus = (runner) => String(runner?.gstatus || "").toUpperCase() || String(runner?.status || "").toUpperCase();
var marketBlockedStatus = (mkt) => {
  if (!mkt || String(mkt.gtype || "").toLowerCase() === "match1") return null;
  const s = String(mkt.status || "").toUpperCase();
  return isBlockedGameStatus(s) ? s : null;
};
function readBufferTick({ marketList, marketId, selectionId, betType, feedSideInverted = false }) {
  const mkt = findMarket(marketList, marketId);
  if (!mkt?.section) return { state: "skip" };
  const mktStatus = marketBlockedStatus(mkt);
  if (mktStatus) return { state: "blocked", status: mktStatus };
  const runner = mkt.section.find((s) => String(s.sid) === String(selectionId));
  if (!runner?.odds) return { state: "skip" };
  const gs = runnerGameStatus(runner);
  if (isBlockedGameStatus(gs)) return { state: "blocked", status: gs };
  const feedSide = feedSideFor(betType, feedSideInverted);
  const bestObj = runner.odds.find((o) => String(o.otype || "").toLowerCase() === feedSide && (o.tno === 0 || o.oname === (feedSide === "lay" ? "lay1" : "back1")));
  if (!bestObj || !bestObj.odds || bestObj.odds <= 0) return { state: "blocked", status: "NO_ODDS" };
  return { state: "live", odds: Number(bestObj.odds), size: Number(bestObj.size) || 0 };
}
function finalSuspensionStatus({ marketList, marketId, selectionId, runnerName, strict = false }) {
  const mkt = findMarket(marketList, marketId);
  if (!mkt && strict) return "CLOSED";
  const mktStatus = marketBlockedStatus(mkt);
  if (mktStatus) return mktStatus;
  const runner = findRunner(mkt, selectionId, runnerName);
  if (!runner) return strict ? "CLOSED" : null;
  const gs = runnerGameStatus(runner);
  return isBlockedGameStatus(gs) ? gs : null;
}
function fancyOddsDrift({ marketList, marketId, runnerName, betType, selectedOdds, feedSideInverted = false, strict = false }) {
  const result = { mismatch: false, liveSize: null };
  const unconfirmed = () => strict ? { mismatch: true, liveSize: null, closest: null } : result;
  const mkt = findMarket(marketList, marketId);
  if (!mkt?.section) return unconfirmed();
  const wantNat = normalizeName(runnerName);
  let sectionFound = mkt.section.find((s) => normalizeName(s.nat) === wantNat);
  if (!sectionFound && mkt.section.length === 1) sectionFound = mkt.section[0];
  if (!sectionFound) return unconfirmed();
  const side = feedSideFor(betType, feedSideInverted);
  const oddsArr = sectionFound.odds || [];
  const sideTiers = oddsArr.filter((o) => String(o.otype || "").toLowerCase() === side).map((o) => Number(o.odds)).filter((n) => Number.isFinite(n) && n > 0);
  if (sideTiers.length === 0) return unconfirmed();
  const closest = sideTiers.reduce((best, curr) => Math.abs(curr - selectedOdds) < Math.abs(best - selectedOdds) ? curr : best);
  if (Math.abs(closest - selectedOdds) > FANCY_EPSILON) {
    result.mismatch = true;
    result.closest = closest;
    return result;
  }
  const liveObj = oddsArr.find((o) => String(o.otype || "").toLowerCase() === side && Math.abs(Number(o.odds) - closest) <= FANCY_EPSILON);
  if (liveObj?.size) result.liveSize = Number(liveObj.size);
  return result;
}
function deriveBufferFlags({ marketList, marketId }) {
  const mkt = findMarket(marketList, marketId);
  if (!mkt) return null;
  const gtype = normalizeName(mkt.gtype);
  const mname = mkt.mname || "";
  return {
    ownLine: gtype === "khado" || normalizeName(mname) === "khado",
    liveTracked: gtype === "match" || isBookieFavourMarket(mname),
    lineMarket: gtype === "fancy2" || isLineMarket(mname),
    marketType: mname
  };
}
function manualBetLiveCheck({ betType, editedOdds, liveOdds }) {
  const accept = isLaySide(betType) ? liveOdds <= editedOdds + EPSILON : liveOdds >= editedOdds - EPSILON;
  return { accept, finalOdds: liveOdds };
}
function autoBetCheck({ marketType, betType, selectedOdds, currentOdds }) {
  if (!isBookieFavourMarket(marketType)) return { accept: true, finalOdds: currentOdds };
  if (betType === "back" || betType === "yes") {
    return { accept: currentOdds >= selectedOdds - EPSILON, finalOdds: currentOdds };
  }
  if (isLaySide(betType)) {
    return { accept: currentOdds <= selectedOdds + EPSILON, finalOdds: currentOdds };
  }
  return { accept: true, finalOdds: currentOdds };
}
function readMarketList(body) {
  let node = body;
  for (let i = 0; i < 6 && node && typeof node === "object"; i++) {
    if (Array.isArray(node)) return node;
    node = node.data;
  }
  return Array.isArray(node) ? node : null;
}

// sportsbet/liveOdds.js
var POLL_MS = Number(process.env.LIVE_ODDS_POLL_MS) || 700;
var pollers = /* @__PURE__ */ new Map();
async function pollOnce(gmid, p) {
  if (p.inFlight) return;
  p.inFlight = true;
  try {
    const res = await CricketService_default.GetMatchPrivateData(gmid, p.sid);
    const list = readMarketList(res);
    if (list && list.length) {
      p.list = list;
      p.at = Date.now();
    }
  } catch (err) {
    console.warn(`[liveOdds] poll failed gmid=${gmid}: ${err.message}`);
  } finally {
    p.inFlight = false;
  }
}
function acquire(gmid, sid) {
  const key = String(gmid);
  let p = pollers.get(key);
  if (!p) {
    p = { sid, refs: 0, timer: null, list: null, at: 0, inFlight: false, first: null };
    pollers.set(key, p);
    p.first = pollOnce(key, p);
    p.timer = setInterval(() => {
      pollOnce(key, p);
    }, POLL_MS);
  }
  p.refs += 1;
  return p.first;
}
function release(gmid) {
  const key = String(gmid);
  const p = pollers.get(key);
  if (!p) return;
  p.refs -= 1;
  if (p.refs <= 0) {
    clearInterval(p.timer);
    pollers.delete(key);
  }
}
function snapshot(gmid) {
  const p = pollers.get(String(gmid));
  if (!p || !p.list) return { list: null, ageMs: Infinity };
  return { list: p.list, ageMs: Date.now() - p.at };
}
var liveOdds_default = { acquire, release, snapshot };

// sportsbet/betInflight.js
var OUTCOME_TTL_MS = Number(process.env.BET_OUTCOME_TTL_MS) || 5 * 60 * 1e3;
var REF_RE = /^[A-Za-z0-9-]{8,64}$/;
var entries = /* @__PURE__ */ new Map();
var keyOf = (userId, ref) => `${userId}:${ref}`;
var cleanRef = (ref) => typeof ref === "string" && REF_RE.test(ref) ? ref : null;
function sweep() {
  const now = Date.now();
  for (const [k, e] of entries) {
    if (now - e.at > OUTCOME_TTL_MS) entries.delete(k);
  }
}
setInterval(sweep, 60 * 1e3).unref();
function begin(userId, ref) {
  const k = keyOf(userId, ref);
  const existing = entries.get(k);
  if (existing) return existing;
  entries.set(k, { state: "pending", status: null, body: null, at: Date.now() });
  return null;
}
function finish(userId, ref, body, status) {
  entries.set(keyOf(userId, ref), {
    state: body?.success ? "accepted" : "rejected",
    status,
    body,
    at: Date.now()
  });
}
function get(userId, ref) {
  return entries.get(keyOf(userId, ref)) || null;
}
var betInflight_default = { cleanRef, begin, finish, get };

// sportsbet/betBuffer.js
var BUFFER_ENABLED = String(process.env.SERVER_SIDE_BET_BUFFER ?? "true").toLowerCase() !== "false";
var FAIL_CLOSED = String(process.env.BET_FEED_FAIL_CLOSED ?? "true").toLowerCase() !== "false";
var LIVE_DEFAULT_SECONDS = Number(process.env.BET_BUFFER_DEFAULT_SECONDS) || 5;
var FANCY_DEFAULT_SECONDS = Number(process.env.FANCY_BUFFER_DEFAULT_SECONDS) || 3;
var MAX_AGE_MS = Number(process.env.LIVE_ODDS_MAX_AGE_MS) || 5e3;
var FIRST_POLL_WAIT_MS = 3e3;
var TICK_MS = 500;
var USD_RATE = 0.0118;
var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
var round2 = (n) => Math.round(n * 100) / 100;
var bool = (v) => v === true || v === "true";
var reject = (message, code) => ({ accept: false, message, code });
var liveList = (gmid) => {
  const { list, ageMs } = liveOdds_default.snapshot(gmid);
  return list && ageMs <= MAX_AGE_MS ? list : null;
};
async function resolveBufferSeconds(body, sb, liveTracked) {
  let leagueName = null;
  try {
    leagueName = await leagueNameForBet(body.sid, body.eventid, body.league_name);
  } catch {
    leagueName = body.league_name || null;
  }
  const configured = await BettingConfigService_default.getSportsBufferSeconds(
    body.sid,
    { gtype: sb.gtype, market_type: sb.mname, badlo: body.badlo, league_name: leagueName },
    { allowGlobalFallback: liveTracked }
  ).catch(() => 0);
  if (configured > 0) return configured;
  return liveTracked ? LIVE_DEFAULT_SECONDS : FANCY_DEFAULT_SECONDS;
}
async function runBetBuffer(body, sb, opts = {}) {
  const noWait = opts.noWait === true;
  const gmid = body.eventid;
  const marketId = body.match_id;
  const selectionId = body.selection_id;
  const betType = body.bet_type;
  const slipOdds = Number(body.odds) || 0;
  const selectedOdds = Number(sb.selected_odds) || slipOdds;
  const isCashout = body.is_cashout === true;
  const badlo = isBadloBet(body) || String(body.market_type || "").toLowerCase() === "badlo";
  const runnerName = sb.runner_name || body.nat || body.fancy_name || body.selection_name;
  const stake = Number(body.stake_amount) || 0;
  const canPoll = gmid && body.sid;
  if (FAIL_CLOSED && (!canPoll || !marketId)) return reject(MESSAGES.BET.GAME_SUSPEND, "NO_MARKET_REF");
  const bufferSeconds = noWait ? 0 : await resolveBufferSeconds(body, sb, bool(sb.live_tracked));
  const started = Date.now();
  let finalSize = Number(sb.initial_size) || 0;
  let blocked = false;
  let ticks = 0;
  let liveTicks = 0;
  const firstPoll = canPoll ? liveOdds_default.acquire(gmid, body.sid) : null;
  try {
    if (marketId && selectionId && bufferSeconds > 0 && canPoll) {
      const deadline = started + bufferSeconds * 1e3;
      while (Date.now() + TICK_MS <= deadline) {
        await sleep(TICK_MS);
        ticks++;
        const list2 = liveList(gmid);
        if (!list2) continue;
        const tick = readBufferTick({
          marketList: list2,
          marketId,
          selectionId,
          betType,
          feedSideInverted: bool(sb.line_market)
        });
        if (tick.state === "blocked") {
          blocked = true;
          break;
        }
        if (tick.state !== "live") continue;
        liveTicks++;
        finalSize = tick.size;
      }
      if (!blocked) {
        const rest = deadline - Date.now();
        if (rest > 0) await sleep(rest);
      }
    }
    if (canPoll && !liveList(gmid)) await Promise.race([firstPoll, sleep(FIRST_POLL_WAIT_MS)]);
    const list = canPoll ? liveList(gmid) : null;
    if (!list && marketId) {
      if (FAIL_CLOSED) {
        console.warn(`[betBuffer] FEED MISS gmid=${gmid} market=${marketId} \u2014 rejected (fail closed)`);
        return reject(MESSAGES.BET.GAME_SUSPEND, "FEED_UNAVAILABLE");
      }
      console.warn(`[betBuffer] FEED MISS gmid=${gmid} market=${marketId} \u2014 checks skipped (fail open, BET_FEED_FAIL_CLOSED=false)`);
    }
    const feedFlags = list ? deriveBufferFlags({ marketList: list, marketId }) : null;
    const flags = feedFlags || (FAIL_CLOSED ? null : {
      ownLine: bool(sb.own_line),
      liveTracked: bool(sb.live_tracked),
      lineMarket: bool(sb.line_market),
      marketType: sb.market_type
    });
    if (list && !flags) {
      if (FAIL_CLOSED) return reject(MESSAGES.BET.GAME_SUSPEND, "SUSPENDED:CLOSED");
    }
    const ownLine = Boolean(flags?.ownLine) || badlo;
    const lineMarket = Boolean(flags?.lineMarket);
    const liveTracked = Boolean(flags?.liveTracked) && !ownLine && !lineMarket;
    const edited = bool(sb.edited) && liveTracked;
    if (feedFlags && isLineMarket(body.market_type) && !feedFlags.lineMarket) {
      return reject(MESSAGES.BET.GAME_SUSPEND, "MARKET_TYPE_MISMATCH");
    }
    if (list && marketId) {
      const gs = finalSuspensionStatus({ marketList: list, marketId, selectionId, runnerName, strict: FAIL_CLOSED });
      if (gs) return reject(gs === "BALL RUNNING" ? MESSAGES.BET.BALL_RUNNING : MESSAGES.BET.GAME_SUSPEND, `SUSPENDED:${gs}`);
    }
    if (list && !liveTracked && !ownLine && marketId) {
      const drift = fancyOddsDrift({
        marketList: list,
        marketId,
        runnerName,
        betType,
        selectedOdds: slipOdds,
        feedSideInverted: lineMarket,
        strict: FAIL_CLOSED
      });
      if (drift.mismatch) return reject(MESSAGES.BET.ODDS_CHANGED, `FANCY_DRIFT:${slipOdds}->${drift.closest}`);
      if (drift.liveSize) finalSize = drift.liveSize;
    }
    if (blocked) return reject(MESSAGES.BET.GAME_SUSPEND, "BLOCKED_IN_BUFFER");
    let finalOdds = slipOdds;
    if (liveTracked && list) {
      const tick = readBufferTick({ marketList: list, marketId, selectionId, betType, feedSideInverted: false });
      if (tick.state === "live") {
        finalOdds = tick.odds;
        finalSize = tick.size;
      } else if (FAIL_CLOSED) {
        return reject(MESSAGES.BET.GAME_SUSPEND, `NO_LIVE_PRICE:${tick.status || tick.state}`);
      }
    }
    let finalStake = stake;
    if (ownLine) {
      finalOdds = slipOdds;
    } else if (isCashout) {
      const live = liveTracked && finalOdds > 0 ? finalOdds : slipOdds;
      const diff = Number(sb.cashout_diff) || 0;
      if (diff > 0 && Math.abs(live - slipOdds) > 1e-3) {
        const divisor = bool(sb.cashout_percent) ? live / 100 + 1 : live;
        finalStake = round2(diff / divisor);
        const maxStake = Number(sb.max_stake) || 0;
        if (!(finalStake > 0) || maxStake > 0 && finalStake > maxStake) {
          return reject(MESSAGES.BET.RANGE_NOT_VALID, "CASHOUT_RANGE");
        }
      }
      finalOdds = live;
    } else if (edited) {
      const manual = manualBetLiveCheck({ betType, editedOdds: slipOdds, liveOdds: finalOdds });
      if (!manual.accept) return reject(MESSAGES.BET.UNMATCHED_NOT_ALLOWED, `MANUAL_LIMIT:${slipOdds}/${finalOdds}`);
      finalOdds = manual.finalOdds;
    } else {
      const auto = autoBetCheck({ marketType: flags?.marketType ?? sb.market_type, betType, selectedOdds, currentOdds: finalOdds });
      if (!auto.accept) return reject(MESSAGES.BET.ODDS_CHANGE_NOT_CONFIRMED, `ODDS_MOVED:${selectedOdds}->${finalOdds}`);
      finalOdds = auto.finalOdds;
    }
    return { accept: true, odds: finalOdds, size: finalSize, stake: finalStake, bufferSeconds, ticks, liveTicks };
  } finally {
    if (canPoll) liveOdds_default.release(gmid);
  }
}
function applyDecision(body, d) {
  const odds = Number(Number(d.odds).toFixed(2));
  body.odds = odds;
  body.user_rate = odds;
  if (d.size > 0) {
    body.size = d.size;
    if (body.bet_type === "back" || body.bet_type === "yes") body.back_size = d.size;
    if (isLaySide(body.bet_type)) body.lay_size = d.size;
  }
  if (d.stake !== Number(body.stake_amount)) {
    const stake = Number(Number(d.stake).toFixed(2));
    body.stake_amount = stake;
    body.original_amount = stake;
    body.amount = stake;
    body.usd_amount = Number((stake * USD_RATE).toFixed(2));
  }
}
var placeBetBuffered = async (req, res) => {
  let sb = req.body?.server_buffer;
  if (req.body) delete req.body.server_buffer;
  if (isLineMarket(req.body?.market_type)) {
    sb = {
      ...sb && typeof sb === "object" ? sb : {},
      line_market: true,
      own_line: false,
      live_tracked: false,
      edited: false
    };
  }
  const noWait = !sb || typeof sb !== "object" || !BUFFER_ENABLED;
  if (!sb || typeof sb !== "object") sb = {};
  const userId = req.user?.account?.id;
  const ref = cleanRef(sb.client_ref);
  if (ref) {
    const existing = betInflight_default.begin(userId, ref);
    if (existing) {
      if (existing.state === "pending") {
        return res.status(409).json({ success: false, pending: true, error: MESSAGES.BET.BET_ALREADY_PENDING });
      }
      return res.status(existing.status || 200).json({ ...existing.body, duplicate: true });
    }
  }
  let decision = null;
  const sendJson = res.json.bind(res);
  res.json = (payload) => {
    let out = payload;
    if (payload?.success && decision?.accept) {
      out = { ...payload, odds: Number(Number(decision.odds).toFixed(2)), stake: decision.stake, client_ref: ref };
    }
    if (ref) betInflight_default.finish(userId, ref, out, res.statusCode);
    return sendJson(out);
  };
  const t0 = Date.now();
  try {
    decision = await runBetBuffer(req.body, sb, { noWait });
  } catch (err) {
    console.error("[betBuffer] decision error:", err);
    return res.status(500).json({ success: false, error: "Bet placement failed" });
  }
  const tag = `user=${userId} gmid=${req.body.eventid} market=${req.body.match_id} sel=${req.body.selection_id} ${req.body.bet_type} ref=${ref || "-"} ${Date.now() - t0}ms`;
  if (!decision.accept) {
    console.log(`[betBuffer] \u2717 rejected ${tag} code=${decision.code}`);
    return res.status(400).json({ success: false, error: decision.message, code: decision.code });
  }
  console.log(`[betBuffer] \u2713 decided ${tag} X=${sb.selected_odds} slip=${req.body.odds} \u2192 ${decision.odds} stake=${req.body.stake_amount}\u2192${decision.stake} size=${decision.size} buffer=${decision.bufferSeconds}s ticks=${decision.liveTicks}/${decision.ticks}`);
  applyDecision(req.body, decision);
  return placeBet(req, res);
};
async function checkBetLive(body) {
  const sb = isLineMarket(body?.market_type) ? { line_market: true } : {};
  const d = await runBetBuffer(body, sb, { noWait: true });
  if (d.accept) applyDecision(body, d);
  return d;
}
var getBetResult = async (req, res) => {
  const userId = req.user?.account?.id;
  const ref = cleanRef(req.params.client_ref);
  if (!ref) return res.status(400).json({ success: false, error: "Invalid client_ref" });
  const e = betInflight_default.get(userId, ref);
  if (!e) return res.json({ success: true, state: "unknown" });
  return res.json({
    success: true,
    state: e.state,
    message: e.state === "rejected" ? e.body?.error || e.body?.message || null : null,
    odds: e.body?.odds ?? null,
    stake: e.body?.stake ?? null
  });
};

// model/admin/StaffMarketLocks.js
init_db();
import { DataTypes as DataTypes29 } from "sequelize";
var StaffMarketLocks = db_default.define(
  "StaffMarketLocks",
  {
    id: {
      type: DataTypes29.BIGINT,
      autoIncrement: true,
      primaryKey: true
    },
    staff_id: {
      type: DataTypes29.INTEGER,
      allowNull: true,
      // null = Owner/Global
      references: {
        model: Staff_default,
        key: "staff_id"
      },
      onDelete: "CASCADE"
    },
    game_id: {
      type: DataTypes29.INTEGER,
      // PlatformGames uses INTEGER id
      allowNull: false,
      references: {
        model: PlatformGames_default,
        key: "id"
      },
      onDelete: "CASCADE"
    },
    market_name: {
      type: DataTypes29.STRING,
      allowNull: false
      // e.g. "Match_Odds", "ALL", "TurboGrill_Studio"
    },
    is_locked: {
      type: DataTypes29.BOOLEAN,
      defaultValue: true
    }
  },
  {
    tableName: "staff_market_locks",
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
    indexes: [
      {
        unique: true,
        fields: ["staff_id", "game_id", "market_name"]
      }
    ]
  }
);
Staff_default.hasMany(StaffMarketLocks, { foreignKey: "staff_id" });
StaffMarketLocks.belongsTo(Staff_default, { foreignKey: "staff_id" });
PlatformGames_default.hasMany(StaffMarketLocks, { foreignKey: "game_id" });
StaffMarketLocks.belongsTo(PlatformGames_default, { foreignKey: "game_id" });
var StaffMarketLocks_default = StaffMarketLocks;

// sportsbet/sportbetscontroller.js
var cachedUsdRate = 0;
var cachedAt = 0;
var sportsDataSet = [
  { sid: 4, ename: "Cricket" },
  { sid: 1, ename: "Football" },
  { sid: 2, ename: "Tennis" },
  { sid: 8, ename: "Table Tennis" },
  { sid: 68, ename: "Esoccer" },
  { sid: 10, ename: "Horse Racing" },
  { sid: 65, ename: "Greyhound Racing" },
  { sid: 15, ename: "Basketball" },
  { sid: 69, ename: "Wrestling" },
  { sid: 18, ename: "Volleyball" },
  { sid: 22, ename: "Badminton" },
  { sid: 59, ename: "Snooker" },
  { sid: 57, ename: "Darts" },
  { sid: 6, ename: "Boxing" },
  { sid: 3, ename: "Mixed Martial Arts" },
  { sid: 58, ename: "American Football" },
  { sid: 11, ename: "E Games" },
  { sid: 19, ename: "Ice Hockey" },
  { sid: 9, ename: "Futsal" },
  { sid: 40, ename: "Politics" },
  { sid: 67, ename: "Boat Racing" },
  { sid: 52, ename: "Motor Sports" },
  { sid: 12, ename: "Greyhounds" },
  { sid: 66, ename: "Kabaddi" },
  { sid: 5, ename: "Golf" },
  { sid: 55, ename: "Rugby League" },
  { sid: 7, ename: "Beach Volleyball" },
  { sid: 13, ename: "Trotting" },
  { sid: 39, ename: "Handball" },
  { sid: 14, ename: "Speedway" },
  { sid: 16, ename: "MotoGP" },
  { sid: 17, ename: "Chess" },
  { sid: 20, ename: "Equine Sports" },
  { sid: 21, ename: "Australian Rules" },
  { sid: 23, ename: "Formula 1" },
  { sid: 24, ename: "Nascar" },
  { sid: 25, ename: "Hockey" },
  { sid: 26, ename: "Supercars" },
  { sid: 27, ename: "Netball" },
  { sid: 28, ename: "Surfing" },
  { sid: 29, ename: "Cycling" },
  { sid: 30, ename: "Gaelic Sports" },
  { sid: 31, ename: "Biathlon" },
  { sid: 32, ename: "Motorbikes" },
  { sid: 33, ename: "Athletics" },
  { sid: 34, ename: "Squash" },
  { sid: 35, ename: "Basketball 3X3" },
  { sid: 36, ename: "Floorball" },
  { sid: 37, ename: "Sumo" },
  { sid: 38, ename: "Virtual sports" },
  { sid: 41, ename: "Weather" }
];
var sportsMap = sportsDataSet.reduce((acc, item) => {
  acc[item.sid] = item.ename;
  return acc;
}, {});
function normalizeOdds(odds) {
  if (odds > 100) return Math.floor((odds / 100 + 1) * 100) / 100;
  if (odds < 100) return Math.floor((1 + odds / 100) * 100) / 100;
  return 2;
}
function calculateRunnerExposure({
  runners,
  selectedRunner,
  stake,
  odd,
  betType,
  oldExposures = {}
}) {
  let newExposures = { ...oldExposures };
  const profit = Math.round(stake * (odd - 1) * 100) / 100;
  const liability = Math.round(stake * (odd - 1) * 100) / 100;
  const isBack = betType === "back" || betType === "yes";
  for (const runner of runners) {
    const prev = oldExposures[runner] || 0;
    if (runner === selectedRunner) {
      newExposures[runner] = Math.round((isBack ? prev + profit : prev - liability) * 100) / 100;
    } else {
      newExposures[runner] = Math.round((isBack ? prev - stake : prev + stake) * 100) / 100;
    }
  }
  return newExposures;
}
async function resolveMarketLimits({ eventid, sid, match_id, mname, market_type, selection_name }) {
  const override = await BettingConfigService_default.getMarketLimits(eventid, match_id).catch(() => ({}));
  const pd = await CricketService_default.GetMatchPrivateData(eventid, sid);
  const markets = Array.isArray(pd?.data) ? pd.data : [];
  if (!markets.length) {
    if (override?.min > 0 || override?.max > 0) {
      return {
        minLimit: Number(override.min) || 0,
        maxLimit: Number(override.max) || 0,
        marketName: mname || market_type || ""
      };
    }
    return null;
  }
  const mkt = markets.find((m) => String(m.mid) === String(match_id)) || markets.find((m) => (m.mname || "") === (mname || market_type));
  if (!mkt) {
    if (override?.min > 0 || override?.max > 0) {
      return {
        minLimit: Number(override.min) || 0,
        maxLimit: Number(override.max) || 0,
        marketName: mname || market_type || ""
      };
    }
    return null;
  }
  const selNorm = (selection_name || "").toString().trim().toLowerCase();
  const sec = (mkt.section || []).find((s) => (s.nat || "").trim().toLowerCase() === selNorm) || null;
  const isRacing = String(sid) === "10" || String(sid) === "65";
  const maxLimit = !isRacing && Number(mkt.maxb) > 0 ? Number(mkt.maxb) : Number(mkt.max) > 0 ? Number(mkt.max) : Number(sec?.max) || 0;
  const minLimit = Number(sec?.min) > 0 ? Number(sec.min) : Number(mkt.min) || 0;
  return {
    minLimit: Number(override?.min) > 0 ? Number(override.min) : minLimit,
    maxLimit: Number(override?.max) > 0 ? Number(override.max) : maxLimit,
    marketName: mkt.mname
  };
}
var RACE_BET_WINDOW_MINUTES = Number(process.env.RACE_BET_WINDOW_MINUTES) || 5;
var IST_OFFSET_MS = 5.5 * 60 * 60 * 1e3;
function parseFeedIstTime(stime) {
  if (!stime || typeof stime !== "string") return null;
  const m = stime.trim().match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})[ ,]+(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)?$/i);
  if (!m) {
    const d = new Date(stime);
    return Number.isNaN(d.getTime()) ? null : d.getTime();
  }
  const [, mo, day, yr, hh, mi, ss, ap] = m;
  let h = Number(hh);
  if (ap) {
    const up = ap.toUpperCase();
    if (up === "PM" && h !== 12) h += 12;
    if (up === "AM" && h === 12) h = 0;
  }
  return Date.UTC(Number(yr), Number(mo) - 1, Number(day), h, Number(mi), Number(ss || 0)) - IST_OFFSET_MS;
}
function findRaceNode(nodes, eventid) {
  for (const n of nodes || []) {
    if (n && String(n.gmid) === String(eventid) && n.stime) return n;
    const hit = findRaceNode(Array.isArray(n?.children) ? n.children : null, eventid);
    if (hit) return hit;
  }
  return null;
}
async function resolveRaceStartMs(eventid, sid) {
  const board = await CricketService_default.fetchCricketData(sid);
  const t1 = Array.isArray(board?.data?.t1) ? board.data.t1 : [];
  const t2 = Array.isArray(board?.data?.t2) ? board.data.t2 : [];
  const race = findRaceNode([...t1, ...t2], eventid);
  if (!race?.stime) return null;
  return parseFeedIstTime(race.stime);
}
var getMarketNameFromGtype = ({ mname, gtype, nat, section }) => {
  console.log("market name from gtype", { mname, gtype, nat, section });
  if (!mname || !gtype) return null;
  if (gtype === "match" || gtype === "match1") {
    let sections = [];
    if (Array.isArray(section)) {
      sections = section;
    } else if (typeof section === "string") {
      try {
        sections = JSON.parse(section);
      } catch (e) {
        sections = [];
      }
    }
    const runnerNames = sections.map((s) => s?.nat?.trim()).filter(Boolean);
    if (runnerNames.length === 0) return null;
    const marketName = runnerNames.length > 1 ? runnerNames.join(" vs ") : runnerNames[0];
    return {
      mname,
      gtype,
      marketName
    };
  }
  if (!nat || typeof nat !== "string") return null;
  return {
    mname,
    gtype,
    marketName: nat.trim()
  };
};
async function inrToUsd(inrAmount = 0) {
  const FIVE_MIN = 5 * 60 * 1e3;
  const now = Date.now();
  if (!cachedUsdRate || now - cachedAt > FIVE_MIN) {
    try {
      const r = await fetch("https://api.exchangerate.host/latest?base=INR&symbols=USD");
      const j = await r.json();
      cachedUsdRate = 1 / j.rates.USD;
      cachedAt = now;
    } catch (e) {
      console.error("FX fetch failed, using fallback 83:", e.message);
      cachedUsdRate = 1 / 83;
    }
  }
  return +(inrAmount * cachedUsdRate).toFixed(2);
}
var checkUserBetLock = async (user_id, game_type, event_id = null, transaction = null, market_id = null) => {
  try {
    console.log("[BetLock] checkUserBetLock CALLED:", { user_id, game_type, event_id, market_id });
    if (!user_id || !game_type) {
      return {
        allowed: false,
        message: "Missing required parameters: user_id or game_type."
      };
    }
    const betLock = await BetLock_default.findOne({ where: { user_id }, transaction });
    if (betLock) {
      if (game_type.trim().toUpperCase() === "MO") {
        if (betLock.MatchOdds === true) {
          return {
            allowed: false,
            message: "Bet not allowed, contact admin (MatchOdds locked)."
          };
        }
      } else {
        if (betLock.OtherMarkets === true) {
          return {
            allowed: false,
            message: "Bet not allowed, contact admin (OtherMarkets locked)."
          };
        }
      }
    }
    if (event_id) {
      const matchLock = await UserMatchLocks_default.findOne({
        where: { user_id, event_id: String(event_id), is_locked: true },
        transaction
      });
      if (matchLock) {
        return {
          allowed: false,
          message: "Bet not allowed, this match is locked for you."
        };
      }
    }
    if (event_id) {
      let marketCondition;
      if (market_id) {
        marketCondition = { market_id: String(market_id) };
      } else {
        const marketNames = [];
        const gt = game_type.trim().toUpperCase();
        if (gt === "MO" || gt === "MATCH" || gt === "MATCH_ODDS" || gt === "MATCH1") {
          marketNames.push("MATCH_ODDS", "Match_Odds", "match_odds", "MATCH", "match", "match1");
        } else if (gt === "BM" || gt === "BOOKMAKER" || gt === "BOOKMAKER2") {
          marketNames.push("bookmaker", "Bookmaker", "BOOKMAKER", "bookmaker2", "BM");
        } else if (gt === "FAN" || gt === "FANCY" || gt === "FANCY1" || gt === "NORMAL") {
          marketNames.push("fancy1", "Fancy", "FANCY", "Normal", "normal", "FAN");
        } else {
          marketNames.push(game_type.trim());
        }
        marketCondition = { market_name: { [Op6.in]: marketNames } };
      }
      console.log("[BetLock] Checking market lock for user:", { user_id, event_id, market_id, game_type, marketCondition });
      const userMarketLock = await UserEventMarketLocks_default.findOne({
        where: {
          account_id: user_id,
          account_type: "user",
          event_id: String(event_id),
          ...marketCondition,
          is_locked: true
        },
        transaction
      });
      console.log("[BetLock] User market lock result:", userMarketLock ? userMarketLock.toJSON() : "NOT FOUND");
      const user = await User_default.findOne({ where: { user_id }, attributes: ["parent_staff_id"], transaction });
      if (userMarketLock) {
        const parent = user?.parent_staff_id ? await Staff_default.findOne({ where: { staff_id: user.parent_staff_id }, attributes: ["level"], transaction }) : null;
        return {
          allowed: false,
          message: MESSAGES.BET.GAME_LOCKED_CONTACT_UPLINE(parent ? uplineNo(parent.level) : OWNER_UPLINE_NO)
        };
      }
      if (user?.parent_staff_id) {
        let staffId = user.parent_staff_id;
        const visited = /* @__PURE__ */ new Set();
        while (staffId && !visited.has(staffId)) {
          visited.add(staffId);
          const staffLock = await UserEventMarketLocks_default.findOne({
            where: {
              account_id: staffId,
              account_type: "staff",
              event_id: String(event_id),
              ...marketCondition,
              is_locked: true
            },
            transaction
          });
          const staff = await Staff_default.findOne({ where: { staff_id: staffId }, attributes: ["parent_id", "level"], transaction });
          if (staffLock) {
            return {
              allowed: false,
              message: MESSAGES.BET.GAME_LOCKED_CONTACT_UPLINE(uplineNo(staff?.level))
            };
          }
          staffId = staff?.parent_id || null;
        }
      }
    }
    return { allowed: true };
  } catch (error) {
    console.error("Error checking user bet lock:", error);
    return {
      allowed: false,
      message: "Internal server error while checking bet lock."
    };
  }
};
var getAllAncestorStaffIds = async (userId, transaction = null) => {
  let ancestors = [];
  let currentUser = await User_default.findOne({ where: { user_id: userId }, attributes: ["parent_staff_id"], transaction });
  if (!currentUser || !currentUser.parent_staff_id) return [];
  let currentStaffId = currentUser.parent_staff_id;
  while (currentStaffId) {
    ancestors.push(currentStaffId);
    const staff = await Staff_default.findOne({ where: { staff_id: currentStaffId }, attributes: ["parent_id"], transaction });
    if (!staff || !staff.parent_id) break;
    currentStaffId = staff.parent_id;
  }
  return ancestors;
};
var LINE_MARKET_DEFAULT_MIN_STAKE = Number(process.env.LINE_MARKET_MIN_STAKE) || 100;
var LINE_MARKET_DEFAULT_MAX_STAKE = Number(process.env.LINE_MARKET_MAX_STAKE) || 1e5;
var checkPlatformBetLock = async (sportsId, game_type, user_id, transaction = null) => {
  console.log("check platform betlock ===> for ", { sportsId, game_type, user_id });
  try {
    if (!sportsId || !game_type || !user_id) {
      return {
        allowed: false,
        message: "Missing required parameters: sportsId, game_type or user_id."
      };
    }
    const ancestors = await getAllAncestorStaffIds(user_id, transaction);
    const staffIdsToCheck = [null, ...ancestors];
    let key = game_type.trim();
    if (key == "MO") {
      key = "Match_Odds";
    }
    const locks = await StaffMarketLocks_default.findAll({
      where: {
        game_id: sportsId,
        staff_id: { [Op6.or]: staffIdsToCheck },
        market_name: { [Op6.or]: [key, "ALL"] },
        is_locked: true
      },
      transaction
    });
    if (locks.length > 0) {
      const lock = locks[0];
      const lockType = lock.market_name === "ALL" ? "ALL markets" : `${key} market`;
      const locker = lock.staff_id ? `upline staff` : `Owner`;
      return {
        allowed: false,
        message: `Bet not allowed, ${lockType} is locked by ${locker}.`
      };
    }
    return { allowed: true };
  } catch (err) {
    console.error("Error checking platform bet lock:", err);
    return {
      allowed: false,
      message: "Internal server error while checking platform lock."
    };
  }
};
var walletUpdate = async (wallet, balanceChange, transaction, context = {}) => {
  const {
    user_id,
    match_title,
    selection_name,
    market_type,
    game_type,
    match_id,
    eventid,
    sid,
    newBet
  } = context;
  if (isNaN(balanceChange)) {
    console.error(`[walletUpdate] \u274C Critical: balanceChange is NaN for user ${user_id}. Context:`, context);
    return;
  }
  let currentCash = Number(wallet.cash || 0);
  if (balanceChange < 0) {
    const amountToAdd = Math.abs(balanceChange);
    wallet.cash = currentCash + amountToAdd;
    await wallet.save({ transaction });
  } else if (balanceChange > 0) {
    const amountToDeduct = balanceChange;
    if (currentCash >= amountToDeduct) {
      wallet.cash = currentCash - amountToDeduct;
    }
    if (isNaN(wallet.cash)) {
      console.error(`[walletUpdate] \u274C Resulting balance is NaN! Reverting. Curr: ${currentCash}, Ded: ${amountToDeduct}`);
      throw new Error("Balance calculation resulted in NaN");
    }
    await wallet.save({ transaction });
  }
  const newBalance = Number(wallet.cash || 0);
  if (balanceChange > 0) {
    await DebitLedger_default.create({
      user_id,
      amount: balanceChange,
      currency: "INR",
      reason: "bet_placed",
      description: `${match_title} ${selection_name}`,
      balance: newBalance,
      market_type: market_type || game_type,
      match_id,
      event_id: eventid,
      sport_id: sid,
      meta: { bet_id: newBet?.id }
    }, { transaction });
  }
  const placedAmount = balanceChange > 0 ? -balanceChange : 0;
  if (balanceChange < 0) {
    const releaseAmount = Math.abs(balanceChange);
  }
  console.log(`[walletUpdate] Delta: ${balanceChange}, Cash: ${wallet.cash}`);
};
var placeBet = async (req, res, opts) => {
  const options = opts && typeof opts === "object" && !Array.isArray(opts) ? opts : {};
  const externalTx = options.transaction || null;
  const skipMinStakeOpt = options.skipMinStake === true;
  const transaction = externalTx || await db_default.transaction();
  try {
    let isNonFancyMarket = function(market_type2) {
      if (fixedNonFancyMarkets.includes(market_type2)) {
        return true;
      }
      if (/^Game Winner\s+(?:[1-9]|1\d|20)\/(?:[1-9]|1\d|20)$/.test(market_type2)) {
        return true;
      }
      if (/^Match Time Result\s+\d{2}:\d{2}$/.test(market_type2)) {
        return true;
      }
      if (/^\d+(?:st|nd|rd|th)\s+Set Race To\s+(?:[1-9]|1[0-5])\.0$/.test(market_type2)) {
        return true;
      }
      if (/^Under\/Over(?: 180s)?\s+\d+(\.\d)?$/.test(market_type2)) {
        return true;
      }
      if (/^Total Tie Break in the Match\s+\d+(\.\d)?$/.test(market_type2)) {
        return true;
      }
      if (/^Point Winner\s+(?:[1-9]|1\d|20)\/(?:[1-9]|1\d|20)\/(?:[1-9]|1\d|20)$/.test(market_type2)) {
        return true;
      }
      if (/^Game To Deuce\s+(?:[1-9]|1\d|20)\/(?:[1-9]|1\d|20)$/.test(market_type2)) {
        return true;
      }
      if (/^Game To Deuce\s+(?:[1-9]|1\d|20)\/(?:[1-9]|1\d|20)\/(?:[1-9]|1\d|20)$/.test(market_type2)) {
        return true;
      }
      return false;
    }, isFancyMatch = function(gameType = "", matchList = []) {
      const normalized = gameType.toUpperCase();
      return matchList.some(
        (item) => item instanceof RegExp ? item.test(normalized) : normalized.includes(item.toUpperCase())
      );
    };
    const user_id = req.user.account.id;
    if (!user_id) {
      if (!externalTx) await transaction.rollback();
      return res.status(400).json({ success: false, error: "User ID is required" });
    }
    let {
      game_type,
      match_id,
      match_title,
      selection_name,
      bet_type,
      odds,
      stake_amount,
      team_one,
      team_two,
      category,
      original_currency,
      original_amount,
      usd_amount,
      match_start_time,
      eventid,
      fancy_name,
      count,
      sid,
      market_type,
      // League/competition (feed cname) — display-only, see SportsBet.league_name
      league_name,
      // Badlo rides inside an ordinary session market and keeps its
      // market_type ('Normal'); this flag is what marks the bet.
      badlo,
      unmatched,
      unmatched_odds,
      is_cashout,
      size,
      runners,
      lay_size,
      back_size,
      runner_odds,
      mname,
      gtype,
      nat,
      section
    } = req.body;
    count = runners.length;
    console.log("PLACE BET PAYLOAD RECEIVED:", req.body);
    const ip_address = req.headers["x-forwarded-for"]?.split(",")[0] || req.connection.remoteAddress || req.ip;
    console.log("IP ADDRESS:", ip_address);
    const browser = req.headers["user-agent"] || null;
    let effectiveLeagueName = null;
    try {
      effectiveLeagueName = await leagueNameForBet(sid, eventid, league_name);
    } catch (leagueErr) {
      console.warn("[PlaceBet] league resolve failed:", leagueErr.message);
      effectiveLeagueName = league_name ? String(league_name).slice(0, 255) : null;
    }
    const hierarchyAllowed = await BetLockService_default.isBettingAllowed(user_id, { transaction });
    if (!hierarchyAllowed) {
      if (!externalTx) await transaction.rollback();
      return res.status(403).json({
        success: false,
        message: MESSAGES.BET.LOCKED_CONTACT_UPLINE
      });
    }
    let sportsId = null;
    if (sid) {
      const platformGame = await PlatformGames_default.findOne({ where: { sport_id: String(sid) }, transaction });
      if (platformGame) {
        sportsId = platformGame.id;
      }
    }
    const lockStatus = await checkUserBetLock(user_id, game_type, eventid, transaction, match_id);
    if (!lockStatus.allowed) {
      if (!externalTx) await transaction.rollback();
      return res.status(403).json({
        success: false,
        message: lockStatus.message
      });
    }
    if (!sportsId) {
      console.warn(`Could not resolve PlatformGame for sid: ${sid}`);
    }
    if (sportsId) {
      const platformlockStatus = await checkPlatformBetLock(sportsId, game_type, user_id, transaction);
      if (!platformlockStatus.allowed) {
        if (!externalTx) await transaction.rollback();
        return res.status(403).json({
          success: false,
          message: platformlockStatus.message
        });
      }
    }
    if (sid) {
      const sportsLockStatus = await SportsLockController_default.checkSportsLock(
        user_id,
        sid,
        // sport_id
        null,
        // series_id (not available in bet payload, checked at sport/match/market level)
        eventid,
        // match_id (event_id is the match identifier)
        match_id,
        // market_id
        { transaction }
        // same connection as the bet (no second pool slot)
      );
      if (!sportsLockStatus.allowed) {
        if (!externalTx) await transaction.rollback();
        return res.status(403).json({
          success: false,
          message: sportsLockStatus.message
        });
      }
    }
    const placedata = getMarketNameFromGtype({ mname, gtype, nat, section });
    console.log("placedata", placedata);
    const virtualLimit = await BettingConfigService_default.getVirtualLimit(sid, effectiveLeagueName).catch(() => null);
    if (isLineMarket(market_type)) {
      const f2 = { ...await BettingConfigService_default.getMarketLimits(eventid, match_id).catch(() => ({})) };
      if (!(Number(f2?.min) > 0)) f2.min = LINE_MARKET_DEFAULT_MIN_STAKE;
      if (!(Number(f2?.max) > 0)) f2.max = LINE_MARKET_DEFAULT_MAX_STAKE;
      if (Number(virtualLimit?.min) > 0) f2.min = virtualLimit.min;
      if (Number(virtualLimit?.max) > 0) f2.max = virtualLimit.max;
      const f2Stake = Number(stake_amount);
      const f2SkipMin = is_cashout === true || skipMinStakeOpt;
      if (!f2SkipMin && Number(f2?.min) > 0 && f2Stake < Number(f2.min)) {
        throw new Error(`Minimum bet amount is ${Number(f2.min)}`);
      }
      if (Number(f2?.max) > 0 && f2Stake > Number(f2.max)) {
        throw new Error(`Maximum bet amount is ${Number(f2.max)}`);
      }
      console.log(`[placeBet] line market \u2014 feed min/max skipped (stake=${stake_amount}, min=${f2.min} max=${f2.max})`);
    } else {
      let limits = null;
      try {
        limits = await resolveMarketLimits({ eventid, sid, match_id, mname, market_type, selection_name });
      } catch (limitErr) {
        console.warn("[placeBet] Market limits lookup failed (non-blocking):", limitErr.message);
      }
      if (virtualLimit) {
        const base = limits || { marketName: mname || market_type || match_id, minLimit: 0, maxLimit: Number(process.env.MAX_STAKE_HARD_CAP) || 5e5 };
        limits = {
          ...base,
          minLimit: Number(virtualLimit.min) > 0 ? Number(virtualLimit.min) : base.minLimit,
          maxLimit: Number(virtualLimit.max) > 0 ? Number(virtualLimit.max) : base.maxLimit
        };
      }
      const stakeNum = Number(stake_amount);
      const skipMin = is_cashout === true || skipMinStakeOpt;
      if (limits) {
        console.log(`[placeBet] Limits for ${limits.marketName}: min=${limits.minLimit} max=${limits.maxLimit} stake=${stakeNum}${skipMin ? " (cashout \u2014 min skipped)" : ""}`);
        if (!skipMin && limits.minLimit > 0 && stakeNum < limits.minLimit) {
          throw new Error(`Minimum bet amount is ${limits.minLimit}`);
        }
        if (limits.maxLimit > 0 && stakeNum > limits.maxLimit) {
          throw new Error(`Maximum bet amount is ${limits.maxLimit}`);
        }
      } else {
        const hardCap = Number(process.env.MAX_STAKE_HARD_CAP) || 5e5;
        const minDefault = Number(process.env.MIN_STAKE_DEFAULT) || 0;
        console.warn(`[placeBet] Limits unavailable for market ${match_id} \u2014 fallback caps min=${minDefault} max=${hardCap}`);
        if (!skipMin && minDefault > 0 && stakeNum < minDefault) {
          throw new Error(`Minimum bet amount is ${minDefault}`);
        }
        if (stakeNum > hardCap) {
          throw new Error(`Maximum bet amount is ${hardCap}`);
        }
      }
    }
    if (String(sid) === "10") {
      let raceStartMs = null;
      try {
        raceStartMs = await resolveRaceStartMs(eventid, sid);
      } catch (raceErr) {
        console.warn("[placeBet] Race window lookup failed (non-blocking):", raceErr.message);
      }
      if (raceStartMs != null) {
        const minutesToOff = (raceStartMs - Date.now()) / 6e4;
        console.log(`[placeBet] Race window: gmid=${eventid} minutesToOff=${minutesToOff.toFixed(1)} window=${RACE_BET_WINDOW_MINUTES}`);
        if (minutesToOff > RACE_BET_WINDOW_MINUTES) {
          throw new Error(`Betting opens ${RACE_BET_WINDOW_MINUTES} minutes before the race starts`);
        }
      } else {
        console.warn(`[placeBet] Race window: start time unavailable for gmid=${eventid} \u2014 check skipped (fail open)`);
      }
    }
    {
      const gtypeForCap = { MATCH: "match", MO: "match", MATCH1: "match1", BOOKMAKER: "match1", BM: "match1" }[String(gtype || game_type || "").toUpperCase()];
      const rule = await BettingConfigService_default.getMaxOddsRule(sid, gtypeForCap, effectiveLeagueName);
      if (rule && Number(odds) > rule.max) {
        let scope = rule.sport;
        let capApplies = true;
        if (rule.limited_overs_only) {
          scope = MESSAGES.BET.LIMITED_OVERS_SCOPE;
          let hay = String(match_title || "");
          try {
            const sd = await CricketService_default.getSportDataById(eventid, sid);
            const m = Array.isArray(sd?.data) ? sd.data[0] : null;
            if (m) hay = `${m.cname || ""} ${m.ename || match_title || ""}`;
          } catch (fmtErr) {
            console.warn("[placeBet] Max-odds format lookup failed (non-blocking):", fmtErr.message);
          }
          capApplies = !isCricketTestFormat(hay);
        }
        if (capApplies) {
          throw new Error(MESSAGES.BET.RATE_OVER_LIMIT(rule.max, scope));
        }
      }
    }
    const stake = Number(stake_amount);
    const oddN = Number(odds);
    let betTypeLower = (bet_type || "").toLowerCase().trim();
    console.log("Bet details:", { stake, oddN, betTypeLower, game_type });
    if (game_type === "BOOKMAKER") {
      game_type = "BM";
    }
    if (game_type === "FANCY") {
      game_type = "FAN";
    }
    console.log("Normalized game_type:", game_type);
    const isYesNo = betTypeLower === "yes" || betTypeLower === "no";
    const isFancy = game_type === "FAN" || game_type === "MO" && isYesNo;
    const isBookmaker = game_type === "BM";
    if (stake <= 0) throw new Error("Invalid stake");
    if (isFancy) {
      if (!Number.isFinite(oddN) || oddN <= 0) throw new Error("Invalid fancy odds");
    } else {
      if (!Number.isFinite(oddN) || oddN < 1) throw new Error("Invalid odds");
    }
    const wallet = await Wallet_default.findOne({ where: { user_id }, transaction, lock: transaction.LOCK.UPDATE });
    if (!wallet) throw new Error("Wallet not found");
    const currentInr = Number(wallet.cash);
    console.log("Current wallet balance:", currentInr);
    const isBadlo = isBadloBet({ badlo }) || String(market_type || "").toLowerCase() === "badlo";
    const exposureIds = exposureIdentity({ marketType: market_type, selectionName: selection_name, badlo: isBadlo });
    const exposureGameType = exposureIds.game_type;
    const oldExposuresRows = await UserExposure_default.findAll({
      where: {
        user_id,
        match_id,
        game_type: exposureGameType
      },
      transaction,
      lock: transaction.LOCK.UPDATE
    });
    const oldExposures = {};
    oldExposuresRows.forEach((r) => oldExposures[r.team_name] = Number(r.exposure_amount));
    console.log("OLD EXPOSURES:", oldExposures);
    let newExposures = { ...oldExposures };
    const sel = exposureIds.team_name != null ? String(exposureIds.team_name) : (selection_name || "").toString();
    const selLower = sel.trim().toLowerCase();
    const isDrawSel = selLower === "the draw" || selLower === "draw";
    const normGameType = isFancy ? "FAN" : game_type === "BM" ? "BM" : "MO";
    const marketsfornonfancy = [
      "Game Winner 1/2",
      "OVER_UNDER_55",
      "OVER_UNDER_45",
      "OVER_UNDER_35",
      "OVER_UNDER_25",
      "OVER_UNDER_15",
      "OVER_UNDER_05",
      "OVER_UNDER_10",
      "2nd Period Winner",
      "1st Period Winner",
      "3rd Period Winner",
      "Both Teams To Score",
      "DRAW_NO_BET",
      "Draw No Bet",
      "HALF_TIME",
      "Match Time Result 70:00",
      "Match Time Result 10:00",
      "Match Time Result 30:00",
      "Match Time Result 20:00",
      "Match Time Result 40:00",
      "Match Time Result 60:00",
      "Match Time Result 50:00",
      "Match Time Result 70:00",
      "Match Time Result 80:00",
      "Match Time Result 90:00",
      "Game Winner 1/1",
      "Game Winner 1/2",
      "Game Winner 1/3",
      "Game Winner 1/4",
      "Game Winner 1/5",
      "Game Winner 1/6",
      "Game Winner 1/7",
      "Game Winner 1/8",
      "Game Winner 1/9",
      "Game Winner 1/10",
      "Game Winner 1/11",
      "Game Winner 1/12",
      "Game Winner 1/13",
      "Game Winner 1/14",
      "Game Winner 1/15",
      "Game Winner 1/16",
      "Game Winner 1/17",
      "Game Winner 1/18",
      "Game Winner 1/19",
      "Game Winner 1/20",
      "Game Winner 2/2",
      "Game Winner 2/3",
      "Game Winner 2/4",
      "Game Winner 2/5",
      "Game Winner 2/6",
      "Game Winner 2/7",
      "Game Winner 2/8",
      "Game Winner 2/9",
      "Game Winner 2/10",
      "Game Winner 2/11",
      "Game Winner 2/12",
      "Game Winner 2/13",
      "Game Winner 2/14",
      "Game Winner 2/15",
      "Game Winner 2/16",
      "Game Winner 2/17",
      "Game Winner 2/18",
      "Game Winner 2/19",
      "Game Winner 2/20",
      "Game Winner 3/1",
      "Game Winner 3/2",
      "Game Winner 3/3",
      "Game Winner 3/4",
      "Game Winner 3/5",
      "Game Winner 3/6",
      "Game Winner 3/7",
      "Game Winner 3/8",
      "Game Winner 3/9",
      "Game Winner 3/10",
      "Game Winner 3/11",
      "Game Winner 3/12",
      "Game Winner 3/13",
      "Game Winner 3/14",
      "Game Winner 3/15",
      "Game Winner 3/16",
      "Game Winner 3/17",
      "Game Winner 3/18",
      "Game Winner 3/19",
      "Game Winner 3/20",
      "Game Winner 4/1",
      "Game Winner 4/2",
      "Game Winner 4/3",
      "Game Winner 4/4",
      "Game Winner 4/5",
      "Game Winner 4/6",
      "Game Winner 4/7",
      "Game Winner 4/8",
      "Game Winner 4/9",
      "Game Winner 4/10",
      "Game Winner 4/11",
      "Game Winner 4/12",
      "Game Winner 4/13",
      "Game Winner 4/14",
      "Game Winner 4/15",
      "Game Winner 4/16",
      "Game Winner 4/17",
      "Game Winner 4/18",
      "Game Winner 4/19",
      "Game Winner 4/20",
      "Game Winner 5/1",
      "Game Winner 5/2",
      "Game Winner 5/3",
      "Game Winner 5/4",
      "Game Winner 5/5",
      "Game Winner 5/6",
      "Game Winner 5/7",
      "Game Winner 5/8",
      "Game Winner 5/9",
      "Game Winner 5/10",
      "Game Winner 5/11",
      "Game Winner 5/12",
      "Game Winner 5/13",
      "Game Winner 5/14",
      "Game Winner 5/15",
      "Game Winner 5/16",
      "Game Winner 5/17",
      "Game Winner 5/18",
      "Game Winner 5/19",
      "Game Winner 5/20",
      "Game Winner 6/1",
      "Game Winner 6/2",
      "Game Winner 6/3",
      "Game Winner 6/4",
      "Game Winner 6/5",
      "Game Winner 6/6",
      "Game Winner 6/7",
      "Game Winner 6/8",
      "Game Winner 6/9",
      "Game Winner 6/10",
      "Game Winner 7/1",
      "Game Winner 7/2",
      "Game Winner 7/3",
      "Game Winner 7/4",
      "Game Winner 7/5",
      "Game Winner 7/6",
      "Game Winner 7/7",
      "Game Winner 2/7",
      "Game Winner 3/7",
      "Game Winner 4/7",
      "Game Winner 5/7",
      "Game Winner 6/7",
      "Game Winner 7/7",
      "1st Set Winner Home/Away",
      "2nd Set Winner Home/Away",
      "3rd Set Winner Home/Away",
      "4th Set Winner Home/Away",
      "5th Set Winner Home/Away",
      "1st Set Winner",
      "2nd Set Winner",
      "3rd Set Winner",
      "4th Set Winner",
      "5th Set Winner",
      "6th Set Winner",
      "1st Half Winner",
      "2nd Half Winner",
      "3rd Half Winner",
      "4th Half Winner",
      "5th Half Winner",
      "6th Half Winner",
      "1st Quarter Winner",
      "2nd Quarter Winner",
      "3rd Quarter Winner",
      "4th Quarter Winner",
      "5th Quarter Winner",
      "6th Quarter Winner",
      "1st Set Race To 1.0",
      "1st Set Race To 2.0",
      "1st Set Race To 3.0",
      "1st Set Race To 4.0",
      "1st Set Race To 5.0",
      "1st Set Race To 6.0",
      "1st Set Race To 7.0",
      "1st Set Race To 8.0",
      "1st Set Race To 9.0",
      "1st Set Race To 10.0",
      "1st Set Race To 11.0",
      "1st Set Race To 12.0",
      "1st Set Race To 13.0",
      "1st Set Race To 14.0",
      "1st Set Race To 15.0",
      "2nd Set Race To 1.0",
      "2nd Set Race To 2.0",
      "2nd Set Race To 3.0",
      "2nd Set Race To 4.0",
      "2nd Set Race To 5.0",
      "2nd Set Race To 6.0",
      "2nd Set Race To 7.0",
      "2nd Set Race To 8.0",
      "2nd Set Race To 9.0",
      "2nd Set Race To 10.0",
      "2nd Set Race To 11.0",
      "2nd Set Race To 12.0",
      "2nd Set Race To 13.0",
      "2nd Set Race To 14.0",
      "2nd Set Race To 15.0",
      "3rd Set Race To 1.0",
      "3rd Set Race To 2.0",
      "3rd Set Race To 3.0",
      "3rd Set Race To 4.0",
      "3rd Set Race To 5.0",
      "3rd Set Race To 6.0",
      "3rd Set Race To 7.0",
      "3rd Set Race To 8.0",
      "3rd Set Race To 9.0",
      "3rd Set Race To 10.0",
      "3rd Set Race To 11.0",
      "3rd Set Race To 12.0",
      "3rd Set Race To 13.0",
      "3rd Set Race To 14.0",
      "3rd Set Race To 15.0",
      "4th Set Race To 1.0",
      "4th Set Race To 2.0",
      "4th Set Race To 3.0",
      "4th Set Race To 4.0",
      "4th Set Race To 5.0",
      "4th Set Race To 6.0",
      "4th Set Race To 7.0",
      "4th Set Race To 8.0",
      "4th Set Race To 9.0",
      "4th Set Race To 10.0",
      "4th Set Race To 11.0",
      "4th Set Race To 12.0",
      "4th Set Race To 13.0",
      "4th Set Race To 14.0",
      "4th Set Race To 15.0",
      "Point Winner 1/1/1",
      "Point Winner 1/1/1",
      "Point Winner 1/1/2",
      "Point Winner 1/1/3",
      "Point Winner 1/1/4",
      "Point Winner 1/1/5",
      "Point Winner 1/1/6",
      "Point Winner 1/1/7",
      "Point Winner 1/1/8",
      "Point Winner 1/1/9",
      "Point Winner 1/1/10",
      "Point Winner 1/1/11",
      "Point Winner 1/1/12",
      "Point Winner 1/1/13",
      "Point Winner 1/1/14",
      "Point Winner 1/1/15",
      "Point Winner 1/1/16",
      "Point Winner 1/1/17",
      "Point Winner 1/1/18",
      "Point Winner 1/1/19",
      "Point Winner 1/1/20",
      "Point Winner 1/2/1",
      "Point Winner 1/2/2",
      "Point Winner 1/2/3",
      "Point Winner 1/2/4",
      "Point Winner 1/2/5",
      "Point Winner 1/2/6",
      "Point Winner 1/2/7",
      "Point Winner 1/2/8",
      "Point Winner 1/2/9",
      "Point Winner 1/2/10",
      "Point Winner 1/2/11",
      "Point Winner 1/2/12",
      "Point Winner 1/2/13",
      "Point Winner 1/2/14",
      "Point Winner 1/2/15",
      "Point Winner 1/2/16",
      "Point Winner 1/2/17",
      "Point Winner 1/2/18",
      "Point Winner 1/2/19",
      "Point Winner 1/2/20",
      "Point Winner 1/3/1",
      "Point Winner 1/3/2",
      "Point Winner 1/3/3",
      "Point Winner 1/3/4",
      "Point Winner 1/3/5",
      "Point Winner 1/3/6",
      "Point Winner 1/3/7",
      "Point Winner 1/3/8",
      "Point Winner 1/3/9",
      "Point Winner 1/3/10",
      "Point Winner 1/3/11",
      "Point Winner 1/3/12",
      "Point Winner 1/3/13",
      "Point Winner 1/3/14",
      "Point Winner 1/3/15",
      "Point Winner 1/3/16",
      "Point Winner 1/3/17",
      "Point Winner 1/3/18",
      "Point Winner 1/3/19",
      "Point Winner 1/3/20",
      "Point Winner 1/4/1",
      "Point Winner 1/4/2",
      "Point Winner 1/4/3",
      "Point Winner 1/4/4",
      "Point Winner 1/4/5",
      "Point Winner 1/4/6",
      "Point Winner 1/4/7",
      "Point Winner 1/4/8",
      "Point Winner 1/4/9",
      "Point Winner 1/5/1",
      "Point Winner 1/5/2",
      "Point Winner 1/5/3",
      "Point Winner 1/5/4",
      "Point Winner 1/5/5",
      "Point Winner 1/5/6",
      "Point Winner 1/5/7",
      "Point Winner 1/5/8",
      "Point Winner 1/5/9",
      "Point Winner 1/6/1",
      "Point Winner 1/6/2",
      "Point Winner 1/6/3",
      "Point Winner 1/6/4",
      "Point Winner 1/6/5",
      "Point Winner 1/6/6",
      "Point Winner 1/6/7",
      "Point Winner 1/6/8",
      "Point Winner 1/6/9",
      "Point Winner 1/7/1",
      "Point Winner 1/7/2",
      "Point Winner 1/7/3",
      "Point Winner 1/7/4",
      "Point Winner 1/7/5",
      "Point Winner 1/7/6",
      "Point Winner 1/7/7",
      "Point Winner 1/7/8",
      "Point Winner 1/7/9",
      "Point Winner 1/8/1",
      "Point Winner 1/8/2",
      "Point Winner 1/8/3",
      "Point Winner 1/8/4",
      "Point Winner 1/8/5",
      "Point Winner 1/8/6",
      "Point Winner 1/8/7",
      "Point Winner 1/8/8",
      "Point Winner 1/8/9",
      "Point Winner 1/9/1",
      "Point Winner 1/9/2",
      "Point Winner 1/9/3",
      "Point Winner 1/9/4",
      "Point Winner 1/9/5",
      "Point Winner 1/9/6",
      "Point Winner 1/9/7",
      "Point Winner 1/9/8",
      "Point Winner 1/9/9",
      "Point Winner 2/1/1",
      "Point Winner 2/1/2",
      "Point Winner 2/1/3",
      "Point Winner 2/1/4",
      "Point Winner 2/1/5",
      "Point Winner 2/1/6",
      "Point Winner 2/1/7",
      "Point Winner 2/1/8",
      "Point Winner 2/1/9",
      "Point Winner 2/2/1",
      "Point Winner 2/2/2",
      "Point Winner 2/2/3",
      "Point Winner 2/2/4",
      "Point Winner 2/2/5",
      "Point Winner 2/2/6",
      "Point Winner 2/2/7",
      "Point Winner 2/2/8",
      "Point Winner 2/2/9",
      "Point Winner 2/3/1",
      "Point Winner 2/3/2",
      "Point Winner 2/3/3",
      "Point Winner 2/3/4",
      "Point Winner 2/3/5",
      "Point Winner 2/3/6",
      "Point Winner 2/3/7",
      "Point Winner 2/3/8",
      "Point Winner 2/3/9",
      "Point Winner 2/4/1",
      "Point Winner 2/4/2",
      "Point Winner 2/4/3",
      "Point Winner 2/4/4",
      "Point Winner 2/4/5",
      "Point Winner 2/4/6",
      "Point Winner 2/4/7",
      "Point Winner 2/4/8",
      "Point Winner 2/4/9",
      "Point Winner 2/5/1",
      "Point Winner 2/5/2",
      "Point Winner 2/5/3",
      "Point Winner 2/5/4",
      "Point Winner 2/5/5",
      "Point Winner 2/5/6",
      "Point Winner 2/5/7",
      "Point Winner 2/5/8",
      "Point Winner 2/5/9",
      "Point Winner 2/6/1",
      "Point Winner 2/6/2",
      "Point Winner 2/6/3",
      "Point Winner 2/6/4",
      "Point Winner 2/6/5",
      "Point Winner 2/6/6",
      "Point Winner 2/6/7",
      "Point Winner 2/6/8",
      "Point Winner 2/6/9",
      "Point Winner 2/7/1",
      "Point Winner 2/7/2",
      "Point Winner 2/7/3",
      "Point Winner 2/7/4",
      "Point Winner 2/7/5",
      "Point Winner 2/7/6",
      "Point Winner 2/7/7",
      "Point Winner 2/7/8",
      "Point Winner 2/7/9",
      "Point Winner 2/8/1",
      "Point Winner 2/8/2",
      "Point Winner 2/8/3",
      "Point Winner 2/8/4",
      "Point Winner 2/8/5",
      "Point Winner 2/8/6",
      "Point Winner 2/8/7",
      "Point Winner 2/8/8",
      "Point Winner 2/8/9",
      "Point Winner 2/9/1",
      "Point Winner 2/9/2",
      "Point Winner 2/9/3",
      "Point Winner 2/9/4",
      "Point Winner 2/9/5",
      "Point Winner 2/9/6",
      "Point Winner 2/9/7",
      "Point Winner 2/9/8",
      "Point Winner 2/9/9",
      "Point Winner 3/1/1",
      "Point Winner 3/1/2",
      "Point Winner 3/1/3",
      "Point Winner 3/1/4",
      "Point Winner 3/1/5",
      "Point Winner 3/1/6",
      "Point Winner 3/1/7",
      "Point Winner 3/1/8",
      "Point Winner 3/1/9",
      "Point Winner 3/2/1",
      "Point Winner 3/2/2",
      "Point Winner 3/2/3",
      "Point Winner 3/2/4",
      "Point Winner 3/2/5",
      "Point Winner 3/2/6",
      "Point Winner 3/2/7",
      "Point Winner 3/2/8",
      "Point Winner 3/2/9",
      "Point Winner 3/3/1",
      "Point Winner 3/3/2",
      "Point Winner 3/3/3",
      "Point Winner 3/3/4",
      "Point Winner 3/3/5",
      "Point Winner 3/3/6",
      "Point Winner 3/3/7",
      "Point Winner 3/3/8",
      "Point Winner 3/3/9",
      "Point Winner 3/4/1",
      "Point Winner 3/4/2",
      "Point Winner 3/4/3",
      "Point Winner 3/4/4",
      "Point Winner 3/4/5",
      "Point Winner 3/4/6",
      "Point Winner 3/4/7",
      "Point Winner 3/4/8",
      "Point Winner 3/4/9",
      "Point Winner 3/5/1",
      "Point Winner 3/5/2",
      "Point Winner 3/5/3",
      "Point Winner 3/5/4",
      "Point Winner 3/5/5",
      "Point Winner 3/5/6",
      "Point Winner 3/5/7",
      "Point Winner 3/5/8",
      "Point Winner 3/5/9",
      "Point Winner 3/6/1",
      "Point Winner 3/6/2",
      "Point Winner 3/6/3",
      "Point Winner 3/6/4",
      "Point Winner 3/6/5",
      "Point Winner 3/6/6",
      "Point Winner 3/6/7",
      "Point Winner 3/6/8",
      "Point Winner 3/6/9",
      "Point Winner 3/7/1",
      "Point Winner 3/7/2",
      "Point Winner 3/7/3",
      "Point Winner 3/7/4",
      "Point Winner 3/7/5",
      "Point Winner 3/7/6",
      "Point Winner 3/7/7",
      "Point Winner 3/7/8",
      "Point Winner 3/7/9",
      "Point Winner 3/8/1",
      "Point Winner 3/8/2",
      "Point Winner 3/8/3",
      "Point Winner 3/8/4",
      "Point Winner 3/8/5",
      "Point Winner 3/8/6",
      "Point Winner 3/8/7",
      "Point Winner 3/8/8",
      "Point Winner 3/8/9",
      "Point Winner 3/9/1",
      "Point Winner 3/9/2",
      "Point Winner 3/9/3",
      "Point Winner 3/9/4",
      "Point Winner 3/9/5",
      "Point Winner 3/9/6",
      "Point Winner 3/9/7",
      "Point Winner 3/9/8",
      "Point Winner 3/9/9",
      "Point Winner 4/1/1",
      "Point Winner 4/1/2",
      "Point Winner 4/1/3",
      "Point Winner 4/1/4",
      "Point Winner 4/1/5",
      "Point Winner 4/1/6",
      "Point Winner 4/1/7",
      "Point Winner 4/1/8",
      "Point Winner 4/1/9",
      "Point Winner 4/2/1",
      "Point Winner 4/2/2",
      "Point Winner 4/2/3",
      "Point Winner 4/2/4",
      "Point Winner 4/2/5",
      "Point Winner 4/2/6",
      "Point Winner 4/2/7",
      "Point Winner 4/2/8",
      "Point Winner 4/2/9",
      "Point Winner 4/3/1",
      "Point Winner 4/3/2",
      "Point Winner 4/3/3",
      "Point Winner 4/3/4",
      "Point Winner 4/3/5",
      "Point Winner 4/3/6",
      "Point Winner 4/3/7",
      "Point Winner 4/3/8",
      "Point Winner 4/3/9",
      "Point Winner 4/4/1",
      "Point Winner 4/4/2",
      "Point Winner 4/4/3",
      "Point Winner 4/4/4",
      "Point Winner 4/4/5",
      "Point Winner 4/4/6",
      "Point Winner 4/4/7",
      "Point Winner 4/4/8",
      "Point Winner 4/4/9",
      "Point Winner 4/5/1",
      "Point Winner 4/5/2",
      "Point Winner 4/5/3",
      "Point Winner 4/5/4",
      "Point Winner 4/5/5",
      "Point Winner 4/5/6",
      "Point Winner 4/5/7",
      "Point Winner 4/5/8",
      "Point Winner 4/5/9",
      "Point Winner 4/6/1",
      "Point Winner 4/6/2",
      "Point Winner 4/6/3",
      "Point Winner 4/6/4",
      "Point Winner 4/6/5",
      "Point Winner 4/6/6",
      "Point Winner 4/6/7",
      "Point Winner 4/6/8",
      "Point Winner 4/6/9",
      "Point Winner 4/7/1",
      "Point Winner 4/7/2",
      "Point Winner 4/7/3",
      "Point Winner 4/7/4",
      "Point Winner 4/7/5",
      "Point Winner 4/7/6",
      "Point Winner 4/7/7",
      "Point Winner 4/7/8",
      "Point Winner 4/7/9",
      "Point Winner 4/8/1",
      "Point Winner 4/8/2",
      "Point Winner 4/8/3",
      "Point Winner 4/8/4",
      "Point Winner 4/8/5",
      "Point Winner 4/8/6",
      "Point Winner 4/8/7",
      "Point Winner 4/8/8",
      "Point Winner 4/8/9",
      "Point Winner 4/9/1",
      "Point Winner 4/9/2",
      "Point Winner 4/9/3",
      "Point Winner 4/9/4",
      "Point Winner 4/9/5",
      "Point Winner 4/9/6",
      "Point Winner 4/9/7",
      "Point Winner 4/9/8",
      "Point Winner 4/9/9",
      "Under/Over 5.5",
      "Under/Over 0.5",
      "Under/Over 1.5",
      "Under/Over 2.5",
      "Under/Over 3.5",
      "Under/Over 4.5",
      "Under/Over 6.5",
      // 'BM 1st Set Winner',
      // 'BM 2nd Set Winner',
      // 'BM 3rd Set Winner',
      // 'BM 4th Set Winner',
      // 'BM 5th Set Winner',
      "1st Set Race To 10.0",
      "1st Set Race To 9.0",
      "1st Set Race To 8.0",
      "1st Set Race To 7.0",
      "1st Set Race To 6.0",
      "1st Set Race To 5.0",
      "1st Set Race To 4.0",
      "1st Set Race To 3.0",
      "1st Set Race To 2.0",
      "1st Set Race To 1.0",
      "2nd Set Race To 10.0",
      "2nd Set Race To 9.0",
      "2nd Set Race To 8.0",
      "2nd Set Race To 7.0",
      "2nd Set Race To 6.0",
      "2nd Set Race To 5.0",
      "2nd Set Race To 4.0",
      "2nd Set Race To 3.0",
      "2nd Set Race To 2.0",
      "2nd Set Race To 1.0",
      "3rd Set Race To 10.0",
      "3rd Set Race To 9.0",
      "3rd Set Race To 8.0",
      "3rd Set Race To 7.0",
      "3rd Set Race To 6.0",
      "3rd Set Race To 5.0",
      "3rd Set Race To 4.0",
      "3rd Set Race To 3.0",
      "3rd Set Race To 2.0",
      "3rd Set Race To 1.0",
      "4th Set Race To 10.0",
      "4th Set Race To 9.0",
      "4th Set Race To 8.0",
      "4th Set Race To 7.0",
      "4th Set Race To 6.0",
      "4th Set Race To 5.0",
      "4th Set Race To 4.0",
      "4th Set Race To 3.0",
      "4th Set Race To 2.0",
      "4th Set Race To 1.0",
      "5th Set Race To 4.0",
      "5th Set Race To 3.0",
      "5th Set Race To 2.0",
      "5th Set Race To 1.0",
      "Total Tie Break in the Match 0.5",
      "Total Tie Break in the Match 1.0",
      "Total Tie Break in the Match 1.5",
      "Total Tie Break in the Match 2.0",
      "Total Tie Break in the Match 2.5",
      "Total Tie Break in the Match 3.5",
      "Game To Deuce 1/1",
      "Game To Deuce 1/2",
      "Game To Deuce 1/3",
      "Game To Deuce 1/4",
      "Game To Deuce 1/5",
      "Game To Deuce 1/6",
      "Game To Deuce 1/7",
      "Game To Deuce 1/8",
      "Game To Deuce 1/9",
      "Game To Deuce 1/10",
      "Game To Deuce 1/11",
      "Game To Deuce 1/12",
      "Game To Deuce 1/13",
      "Game To Deuce 1/14",
      "Game To Deuce 1/15",
      "Game To Deuce 1/16",
      "Game To Deuce 1/17",
      "Game To Deuce 1/18",
      "Game To Deuce 1/19",
      "Game To Deuce 1/20",
      "Game To Deuce 2/1",
      "Game To Deuce 2/2",
      "Game To Deuce 2/3",
      "Game To Deuce 2/4",
      "Game To Deuce 2/5",
      "Game To Deuce 2/6",
      "Game To Deuce 2/7",
      "Game To Deuce 2/8",
      "Game To Deuce 2/9",
      "Game To Deuce 2/10",
      "Game To Deuce 2/11",
      "Game To Deuce 2/12",
      "Game To Deuce 2/13",
      "Game To Deuce 2/14",
      "Game To Deuce 2/15",
      "Game To Deuce 2/16",
      "Game To Deuce 2/17",
      "Game To Deuce 2/18",
      "Game To Deuce 2/19",
      "Game To Deuce 2/20",
      "Game To Deuce 3/1",
      "Game To Deuce 3/2",
      "Game To Deuce 3/3",
      "Game To Deuce 3/4",
      "Game To Deuce 3/5",
      "Game To Deuce 3/6",
      "Game To Deuce 3/7",
      "Game To Deuce 3/8",
      "Game To Deuce 3/9",
      "Game To Deuce 3/10",
      "Game To Deuce 3/11",
      "Game To Deuce 3/12",
      "Game To Deuce 3/13",
      "Game To Deuce 3/14",
      "Game To Deuce 3/15",
      "Game To Deuce 3/16",
      "Game To Deuce 3/17",
      "Game To Deuce 3/18",
      "Game To Deuce 3/19",
      "Game To Deuce 3/20",
      "Game To Deuce 4/1",
      "Game To Deuce 4/2",
      "Game To Deuce 4/3",
      "Game To Deuce 4/4",
      "Game To Deuce 4/5",
      "Game To Deuce 4/6",
      "Game To Deuce 4/7",
      "Game To Deuce 4/8",
      "Game To Deuce 4/9",
      "Game To Deuce 4/10",
      "Game To Deuce 4/11",
      "Game To Deuce 4/12",
      "Game To Deuce 4/13",
      "Game To Deuce 4/14",
      "Game To Deuce 4/15",
      "Game To Deuce 4/16",
      "Game To Deuce 4/17",
      "Game To Deuce 4/18",
      "Game To Deuce 4/19",
      "Game To Deuce 4/20",
      "Game To Deuce 5/1",
      "Game To Deuce 5/2",
      "Game To Deuce 5/3",
      "Game To Deuce 5/4",
      "Game To Deuce 5/5",
      "Game To Deuce 5/6",
      "Game To Deuce 5/7",
      "Game To Deuce 5/8",
      "Game To Deuce 5/9",
      "Game To Deuce 5/10",
      "Game To Deuce 5/11",
      "Game To Deuce 5/12",
      "Game To Deuce 5/13",
      "Game To Deuce 5/14",
      "Game To Deuce 5/15",
      "Game To Deuce 5/16",
      "Game To Deuce 5/17",
      "Game To Deuce 5/18",
      "Game To Deuce 5/19",
      "Game To Deuce 5/20",
      "Game To Deuce 6/1",
      "Game To Deuce 6/2",
      "Game To Deuce 6/3",
      "Game To Deuce 6/4",
      "Game To Deuce 6/5",
      "Game To Deuce 6/6",
      "Game To Deuce 6/7",
      "Game To Deuce 6/8",
      "Game To Deuce 6/9",
      "Game To Deuce 6/10",
      "Game To Deuce 6/11",
      "Game To Deuce 6/12",
      "Game To Deuce 6/13",
      "Game To Deuce 6/14",
      "Game To Deuce 6/15",
      "Game To Deuce 6/16",
      "Game To Deuce 6/17",
      "Game To Deuce 6/18",
      "Game To Deuce 6/19",
      "Game To Deuce 6/20",
      "Game To Deuce 7/1",
      "Game To Deuce 7/2",
      "Game To Deuce 7/3",
      "Game To Deuce 7/4",
      "Game To Deuce 7/5",
      "Game To Deuce 7/6",
      "Game To Deuce 7/7",
      "Game To Deuce 7/8",
      "Game To Deuce 7/9",
      "Game To Deuce 7/10",
      "Game To Deuce 8/1",
      "Game To Deuce 8/2",
      "Game To Deuce 8/3",
      "Game To Deuce 8/4",
      "Game To Deuce 8/5",
      "Game To Deuce 8/6",
      "Game To Deuce 8/7",
      "Game To Deuce 8/8",
      "Game To Deuce 8/9",
      "Game To Deuce 8/10",
      "Game To Deuce 9/1",
      "Game To Deuce 9/2",
      "Game To Deuce 9/3",
      "Game To Deuce 9/4",
      "Game To Deuce 9/5",
      "Game To Deuce 9/6",
      "Game To Deuce 9/7",
      "Game To Deuce 9/8",
      "Game To Deuce 9/9",
      "Under/Over 180s 0.5",
      "Under/Over 180s 1.0",
      "Under/Over 180s 1.5",
      "Under/Over 180s 2.0",
      "Under/Over 180s 2.5",
      "Under/Over 180s 3.0",
      "Under/Over 180s 3.5",
      "Under/Over 180s 4.0",
      "Tied Match",
      "TIED_MATCH"
    ];
    const fixedNonFancyMarkets = [
      "OVER_UNDER_55",
      "OVER_UNDER_45",
      "OVER_UNDER_35",
      "OVER_UNDER_25",
      "OVER_UNDER_15",
      "OVER_UNDER_05",
      "OVER_UNDER_10",
      "2nd Period Winner",
      "1st Period Winner",
      "3rd Period Winner",
      "Both Teams To Score",
      "DRAW_NO_BET",
      "Draw No Bet",
      "HALF_TIME",
      "1st Set Winner Home/Away",
      "2nd Set Winner Home/Away",
      "3rd Set Winner Home/Away",
      "4th Set Winner Home/Away",
      "5th Set Winner Home/Away",
      "1st Set Winner",
      "2nd Set Winner",
      "3rd Set Winner",
      "4th Set Winner",
      "5th Set Winner",
      "6th Set Winner",
      "1st Half Winner",
      "2nd Half Winner",
      "3rd Half Winner",
      "4th Half Winner",
      "5th Half Winner",
      "6th Half Winner",
      "1st Quarter Winner",
      "2nd Quarter Winner",
      "3rd Quarter Winner",
      "4th Quarter Winner",
      "5th Quarter Winner",
      "6th Quarter Winner",
      "Tied Match",
      "TIED_MATCH"
    ];
    const marketsforfancy = [
      "1st Innings 6 Overs Line",
      "2nd Innings 6 Overs Line",
      "3rd Innings 6 Overs Line",
      "1st Innings 50 Overs Line",
      "2nd Innings 50 Overs Line",
      "3rd Innings 50 Overs Line",
      "1st Innings 40 Overs Line",
      "2nd Innings 40 Overs Line",
      "3rd Innings 40 Overs Line",
      "1st Innings 30 Overs Line",
      "2nd Innings 30 Overs Line",
      "3rd Innings 30 Overs Line",
      "1st Innings 20 Overs Line",
      "2nd Innings 20 Overs Line",
      "3rd Innings 20 Overs Line",
      "1st Innings 10 Overs Line",
      "2nd Innings 10 Overs Line",
      "3rd Innings 10 Overs Line",
      "Over By Over",
      "Ball By Ball",
      "Normal",
      "khado",
      "meter",
      "fancy1",
      "oddeven",
      "badlo"
    ];
    const isFancyMarketType = marketsforfancy.includes(market_type) || isLineMarket(market_type);
    const marketsforBMfancy = [
      "BM 1st Set Winner",
      "BM 2nd Set Winner",
      "BM 3rd Set Winner",
      "BM 4th Set Winner",
      "BM 5th Set Winner",
      "BM 6th Set Winner"
    ];
    const bigRunnerSessionMarket = /\b(1ST|2ND|3RD)\s+INN\s+(\d+(\.\d+)?\s+OVER|LAMBI)\b/i;
    const marketforfancywithbigrunners = [
      bigRunnerSessionMarket,
      "TOURNAMENT_WINNER",
      "Next Goal 1.0",
      "Next Goal 2.0",
      "Next Goal 3.0",
      "Next Goal 4.0",
      "Next Goal 5.0",
      "Next Goal 6.0",
      "Next Goal 7.0",
      "Next Goal 8.0",
      "Next Goal 9.0",
      "Next Goal 10.0",
      "Match Result/Both Teams to score",
      "Correct Score 1st Set",
      "Correct Score 2nd Set",
      "Correct Score 3rd Set",
      "Correct Score 4th Set",
      "Correct Score 5th Set",
      "Correct Score 6th Set",
      "HT/FT"
      // 'oddeven'
    ];
    if (isFancyMarketType) {
      console.log("marketsforfancy", marketsforfancy);
      console.log("market_type", market_type);
      const S = Number(stake);
      let L = Number(lay_size);
      let B = Number(back_size);
      if (market_type === "fancy1" || market_type === "oddeven") {
        console.log("runner_odds", oddN);
        L = (oddN - 1) * 100;
        B = (oddN - 1) * 100;
        console.log("oddeven hit ");
        console.log("L", L);
        console.log("B", B);
      }
      let layword = sel + "lay";
      let backword = sel + "back";
      if (isLineMarket(market_type)) {
        const lineBets = await SportsBet_default.findAll({
          where: { user_id, eventid, market_type, status: "open" },
          attributes: ["bet_type", "odds", "stake_amount"],
          transaction
        });
        const legs = [
          ...lineBets.map((b) => ({ line: Number(b.odds), stake: Number(b.stake_amount), betType: b.bet_type })),
          { line: Number(oddN), stake: S, betType: betTypeLower }
        ].filter((l) => Number.isFinite(l.line) && Number.isFinite(l.stake));
        const probes = [Math.min(...legs.map((l) => l.line)) - 1, ...legs.map((l) => l.line)];
        const worst = Math.min(
          ...probes.map((r) => legs.reduce((sum, l) => sum + linePnl({ runs: r, ...l }), 0))
        );
        newExposures[sel] = Math.min(0, Number(worst.toFixed(2)));
        newExposures[layword] = (oldExposures[layword] || 0) + stake;
        newExposures[backword] = (oldExposures[backword] || 0) - stake;
      } else {
        console.log("oldExposures", oldExposures);
        let layExp = Number(oldExposures?.[layword] || 0);
        let backExp = Number(oldExposures?.[backword] || 0);
        console.log("layExp", layExp);
        console.log("backExp", backExp);
        const layRisk = market_type === "fancy1" || market_type === "oddeven" ? S * L / 100 : S * L / 100;
        const backWin = market_type === "fancy1" || market_type === "oddeven" ? S * B / 100 : S * B / 100;
        if (market_type === "oddeven") {
          if (betTypeLower === "lay" || betTypeLower === "no") {
            layExp += layRisk;
            backExp -= S;
          } else if (betTypeLower === "back" || betTypeLower === "yes") {
            layExp -= S;
            backExp += backWin;
          }
        } else {
          if (betTypeLower === "lay" || betTypeLower === "no") {
            layExp += S;
            backExp -= layRisk;
          } else if (betTypeLower === "back" || betTypeLower === "yes") {
            layExp -= S;
            backExp += backWin;
          }
        }
        console.log("layExp", layExp);
        console.log("backExp", backExp);
        newExposures[layword] = layExp;
        newExposures[backword] = backExp;
        let stakeKey = sel + "totalstake";
        let totalStake = Number(oldExposures?.[stakeKey] || 0) + S;
        newExposures[stakeKey] = totalStake;
        const IS_METER = isMeterMarket(market_type);
        const existingBets = await SportsBet_default.findAll({
          where: { user_id, selection_name: sel, eventid, status: "open" },
          attributes: ["bet_type", "stake_amount", "odds", "size", "liability", "badlo"],
          transaction
        });
        const toContribution = (betType, line, win, lose) => ({
          line: Number(line),
          isYes: ["yes", "back"].includes(String(betType || "").toLowerCase()),
          winAmt: win,
          loseAmt: lose
        });
        const contribs = existingBets.map((b) => {
          const stk = Number(b.stake_amount);
          const sz = market_type === "fancy1" || market_type === "oddeven" ? (Number(b.odds) - 1) * 100 : Number(b.size);
          const liab = Number(b.liability);
          const isYes = ["yes", "back"].includes(String(b.bet_type || "").toLowerCase());
          const legIsBadlo = isBadloBet(b);
          return {
            ...toContribution(
              b.bet_type,
              b.odds,
              legIsBadlo ? stk : isYes ? stk * sz / 100 : stk,
              // win amount
              legIsBadlo ? stk : isYes ? stk : liab > 0 ? liab : stk * sz / 100
              // lose amount
            ),
            stake: stk,
            // meter/line/badlo price off the stake, not a bhav
            isBadlo: legIsBadlo
          };
        });
        contribs.push(
          isBadlo ? { ...toContribution(betTypeLower, oddN, S, S), stake: S, isBadlo: true } : betTypeLower === "lay" || betTypeLower === "no" ? { ...toContribution(betTypeLower, oddN, S, layRisk), stake: S, isBadlo: false } : { ...toContribution(betTypeLower, oddN, backWin, S), stake: S, isBadlo: false }
        );
        const validContribs = contribs.filter(
          (c) => !isNaN(c.line) && c.line > 0 && !isNaN(c.winAmt) && !isNaN(c.loseAmt)
        );
        const pnlAt = (r) => validContribs.reduce((sum, c) => {
          if (c.isBadlo) {
            return sum + badloPnl({
              runs: r,
              line: c.line,
              stake: c.stake,
              betType: c.isYes ? "yes" : "no"
            });
          }
          if (IS_METER) {
            return sum + meterPnl({
              runs: r,
              line: c.line,
              stake: c.stake,
              betType: c.isYes ? "yes" : "no"
            });
          }
          return sum + ((c.isYes ? r >= c.line : r < c.line) ? c.winAmt : -c.loseAmt);
        }, 0);
        let worstCase = 0;
        if (validContribs.length) {
          const lines = validContribs.map((c) => c.line);
          const hasBadlo = validContribs.some((c) => c.isBadlo);
          const points = IS_METER ? [0, ...new Set(lines.map((l) => l + METER_MAX_RUNS))] : [
            Math.min(...lines) - 1,
            ...new Set(lines),
            ...hasBadlo ? [...new Set(lines)].map((l) => l + 0.5) : []
          ];
          worstCase = Math.min(...points.map(pnlAt));
        }
        worstCase = Math.round(worstCase * 100) / 100;
        if (IS_METER && validContribs.length) {
          const capEnd = Math.max(...validContribs.map((c) => c.line)) + METER_MAX_RUNS;
          newExposures[layword] = Math.round(pnlAt(0) * 100) / 100;
          newExposures[backword] = Math.round(pnlAt(capEnd) * 100) / 100;
        }
        if (market_type === "fancy1" || market_type === "oddeven") {
          newExposures[sel] = Math.min(layExp, backExp);
        } else {
          newExposures[sel] = worstCase;
        }
        console.log("[FANCY EXPOSURE TRACK]", {
          selection: sel,
          betType: betTypeLower,
          stake: S,
          layBhav: L,
          backBhav: B,
          layExposure: layExp,
          backExposure: backExp,
          worstCase,
          openBets: existingBets.length + 1
        });
      }
    } else if (normGameType === "MO") {
      newExposures = calculateRunnerExposure({
        runners,
        selectedRunner: sel,
        stake,
        odd: oddN,
        betType: betTypeLower,
        oldExposures
      });
    } else if (normGameType === "BM") {
      const newodds = normalizeOdds(oddN);
      console.log(`Normalized BM odds: ${oddN} \u2192 ${newodds}`);
      newExposures = calculateRunnerExposure({
        runners,
        selectedRunner: sel,
        stake,
        odd: newodds,
        betType: betTypeLower,
        oldExposures
      });
    } else if (isNonFancyMarket(market_type)) {
      let profit = 0;
      let layLiab = 0;
      if (market_type === "Tied Match") {
        let new_odds = oddN / 100;
        profit = Math.round(stake * new_odds * 100) / 100;
        layLiab = Math.round(stake * new_odds * 100) / 100;
      } else {
        profit = Math.round(stake * (oddN - 1) * 100) / 100;
        layLiab = Math.round(stake * (oddN - 1) * 100) / 100;
      }
      if (isDrawSel) {
        if (betTypeLower === "back" || betTypeLower === "yes" || betTypeLower === "Yes") {
          newExposures["The Draw"] = (oldExposures["The Draw"] || 0) + profit;
          newExposures[team_one] = (oldExposures[team_one] || 0) - stake;
          newExposures[team_two] = (oldExposures[team_two] || 0) - stake;
        } else {
          newExposures["The Draw"] = (oldExposures["The Draw"] || 0) - layLiab;
          newExposures[team_one] = (oldExposures[team_one] || 0) + stake;
          newExposures[team_two] = (oldExposures[team_two] || 0) + stake;
        }
      } else {
        const otherTeam = sel === team_one ? team_two : team_one;
        if (betTypeLower === "back") {
          newExposures[sel] = (oldExposures[sel] || 0) + profit;
          newExposures[otherTeam] = (oldExposures[otherTeam] || 0) - stake;
          if (count == 3 || oldExposures["The Draw"] !== void 0) {
            newExposures["The Draw"] = (oldExposures["The Draw"] || 0) - stake;
          }
        } else {
          newExposures[sel] = (oldExposures[sel] || 0) - layLiab;
          newExposures[otherTeam] = (oldExposures[otherTeam] || 0) + stake;
          if (count == 3 || oldExposures["The Draw"] !== void 0) {
            newExposures["The Draw"] = (oldExposures["The Draw"] || 0) + stake;
          }
        }
      }
    } else if (isFancyMatch(market_type, marketsforBMfancy)) {
      const newodds = normalizeOdds(oddN);
      console.log(`Normalized BM odds: ${oddN} \u2192 ${newodds}`);
      newExposures = calculateRunnerExposure({
        runners,
        selectedRunner: sel,
        stake,
        odd: newodds,
        betType: betTypeLower,
        oldExposures
      });
    } else if (isFancyMatch(market_type, marketforfancywithbigrunners)) {
      newExposures = calculateRunnerExposure({
        runners,
        selectedRunner: sel,
        stake,
        odd: oddN,
        betType: betTypeLower,
        oldExposures
      });
    } else {
      throw new Error(`bet is closed for this market`);
    }
    console.log("NEW EXPOSURES:", newExposures);
    let balanceChange = 0;
    if (isFancyMarketType) {
      const oldNegs = Object.entries(oldExposures).filter(([key, val]) => key === sel && val < 0).map(([, val]) => val);
      const newNegs = Object.entries(newExposures).filter(([key, val]) => key === sel && val < 0).map(([, val]) => val);
      const oldMax = oldNegs.length ? Math.abs(Math.min(...oldNegs)) : 0;
      const newMax = newNegs.length ? Math.abs(Math.min(...newNegs)) : 0;
      const liabInc = newMax - oldMax;
      console.log("LIABILITY CALCULATION (MO/BM):");
      console.log("- Old liabilities:", oldNegs);
      console.log("- New liabilities:", newNegs);
      console.log("- Old total liability (blocked):", oldMax);
      console.log("- New total liability (to block):", newMax);
      console.log("- Liability change:", liabInc);
      if (Object.keys(oldExposures).length === 0) balanceChange = newMax;
      else if (liabInc > 0) balanceChange = liabInc;
      else if (liabInc < 0) balanceChange = liabInc;
      if (balanceChange > 0 && currentInr < balanceChange) throw new Error("Bet Not Confirm Check Exposure Limit And Balance");
    } else {
      const oldNegs = Object.values(oldExposures).filter((x) => x < 0);
      const newNegs = Object.values(newExposures).filter((x) => x < 0);
      const oldMax = oldNegs.length ? Math.abs(Math.min(...oldNegs)) : 0;
      const newMax = newNegs.length ? Math.abs(Math.min(...newNegs)) : 0;
      const liabInc = newMax - oldMax;
      console.log("LIABILITY CALCULATION (MO/BM):");
      console.log("- Old liabilities:", oldNegs);
      console.log("- New liabilities:", newNegs);
      console.log("- Old total liability (blocked):", oldMax);
      console.log("- New total liability (to block):", newMax);
      console.log("- Liability change:", liabInc);
      if (Object.keys(oldExposures).length === 0) balanceChange = newMax;
      else if (liabInc > 0) balanceChange = liabInc;
      else if (liabInc < 0) balanceChange = liabInc;
      if (balanceChange > 0 && currentInr < balanceChange) throw new Error("Bet not confirm check balance.");
    }
    console.log("FINAL BALANCE CHANGE:", balanceChange, "(+deduct, -release)");
    for (const [name, amt] of Object.entries(newExposures)) {
      await UserExposure_default.upsert(
        {
          user_id,
          match_id,
          team_name: name,
          exposure_amount: amt,
          match_title,
          game_type: exposureGameType,
          event_id: eventid,
          category: "sports"
        },
        { transaction }
      );
    }
    console.log("het");
    let singleBetLiability;
    if (market_type === "oddeven") {
      singleBetLiability = stake;
    } else if (market_type === "fancy1") {
      singleBetLiability = betTypeLower === "back" || betTypeLower === "yes" ? stake : stake * (oddN - 1);
    } else if (market_type === "Tied Match") {
      let new_odds = oddN / 100;
      singleBetLiability = betTypeLower === "back" ? stake : stake * new_odds;
    } else if (normGameType === "MO" || marketsfornonfancy.includes(market_type)) {
      singleBetLiability = betTypeLower === "back" ? stake : stake * (oddN - 1);
    } else if (normGameType === "MO" || normGameType === "BM") {
      const newodds = normalizeOdds(oddN);
      singleBetLiability = betTypeLower === "back" ? stake : stake * (newodds - 1);
    } else if (bigRunnerSessionMarket.test(market_type)) {
      singleBetLiability = betTypeLower === "back" || betTypeLower === "yes" ? stake : stake * (oddN - 1);
    } else if (isLineMarket(market_type)) {
      singleBetLiability = stake;
    } else if (isMeterMarket(market_type)) {
      singleBetLiability = meterLiability({ line: oddN, stake, betType: betTypeLower });
    } else if (isBadlo) {
      singleBetLiability = badloLiability({ stake, betType: betTypeLower });
    } else {
      singleBetLiability = betTypeLower === "back" || betTypeLower === "yes" ? stake : size * stake / 100;
    }
    console.log("tesr", singleBetLiability);
    let fixed = 0;
    if (!isFancyMarketType) {
      size = 0;
    }
    if (isLineMarket(market_type)) {
      size = 0;
    }
    if (isBadlo && !(Number(size) > 0)) {
      size = Number(betTypeLower === "yes" || betTypeLower === "back" ? back_size : lay_size) || 0;
    }
    size = Number.isFinite(Number(size)) ? Math.round(Number(size)) : 0;
    const storedGameType = isFancyMarketType ? "FAN" : normGameType;
    const finalBetType = (game_type === "FAN" || isFancyMarketType) && bet_type ? bet_type.toLowerCase() === "back" ? "yes" : bet_type.toLowerCase() === "lay" ? "no" : bet_type : bet_type;
    const startTime = match_start_time || /* @__PURE__ */ new Date();
    const newBet = await SportsBet_default.create(
      {
        user_id,
        game_type: storedGameType,
        match_id,
        match_title,
        team_one,
        team_two,
        selection_name,
        category: category || "1",
        bet_type: finalBetType,
        odds: oddN,
        stake_amount: stake,
        original_currency: original_currency || "INR",
        original_amount: original_amount || stake,
        usd_amount: usd_amount || await inrToUsd(stake),
        liability: singleBetLiability,
        match_start_time: startTime,
        exposure_after_bet: Math.max(0, ...Object.values(newExposures).filter((v) => v < 0).map((v) => Math.abs(v)), 0),
        status: "open",
        eventid,
        ip_address,
        browser,
        fancy_name: fancy_name || "NULL",
        fixed,
        counts: count,
        sport_id: sid,
        fancy_name: fancy_name || "NULL",
        fixed,
        counts: count,
        sport_id: sid,
        market_type,
        unmatched: unmatched || false,
        unmatched_odds: unmatched_odds || null,
        is_cashout: is_cashout === true,
        size,
        runners,
        gtype: gtype || null,
        badlo: isBadlo,
        league_name: effectiveLeagueName,
        // placeCombinedBet stamps both legs of a badlo swap with ONE time — they
        // are a single click, and the statement lists them as one pair.
        ...options.createdAt ? { created_at: options.createdAt } : {}
      },
      { transaction }
    );
    await walletUpdate(wallet, balanceChange, transaction, {
      user_id,
      match_title,
      selection_name,
      market_type,
      game_type,
      match_id,
      eventid,
      sid,
      newBet
    });
    const betExposureValues = Object.values(newExposures);
    console.log("NEW EXPOSURES FOR THIS BET:", newExposures);
    console.log("EXPOSURE VALUES:", betExposureValues);
    let betNetExposure = 0;
    if (betExposureValues.length > 0) {
      const minValue = Math.min(...betExposureValues);
      betNetExposure = minValue < 0 ? Math.abs(minValue) : 0;
    }
    console.log("NET EXPOSURE OF THIS BET:", betNetExposure);
    const exposureResults = await db_default.query(TOTAL_EXPOSURE_SQL, {
      replacements: { user_id },
      type: db_default.QueryTypes.SELECT,
      transaction
    });
    const totalUserExposure = parseFloat(exposureResults[0]?.total_exposure) || 0;
    console.log("Calculated Total User Exposure (Net):", totalUserExposure);
    await TotalExposure_default.upsert(
      {
        user_id,
        total_exposure: totalUserExposure
      },
      { transaction }
    );
    console.log(`\u2705 TotalExposure upserted for user ${user_id}: ${totalUserExposure}`);
    if (!externalTx) await transaction.commit();
    const newBalance = balanceChange !== 0 ? currentInr - balanceChange : currentInr;
    console.log("Transaction completed successfully");
    console.log("Old balance:", currentInr);
    console.log("New balance:", newBalance);
    console.log("Actual balance delta:", newBalance - currentInr);
    return res.json({
      success: true,
      exposure: { [match_id]: { match_title, teams: newExposures } },
      balanceDelta: newBalance - currentInr,
      oldBalance: currentInr,
      newBalance,
      totalExposure: totalUserExposure
    });
  } catch (err) {
    if (!externalTx) await transaction.rollback();
    console.error("PLACE BET ERROR:", err.message);
    return res.status(400).json({ success: false, error: err.message });
  }
};
var MAX_COMBINED_LEGS = 10;
var makeLegRes = () => ({
  statusCode: 200,
  body: null,
  status(code) {
    this.statusCode = code;
    return this;
  },
  json(payload) {
    this.body = payload;
    return this;
  }
});
var placeCombinedBet = async (req, res) => {
  let transaction = null;
  try {
    const user_id = req.user?.account?.id;
    if (!user_id) return res.status(400).json({ success: false, error: "User ID is required" });
    const legs = Array.isArray(req.body?.bets) ? req.body.bets : null;
    if (!legs || legs.length < 2) {
      return res.status(400).json({ success: false, error: "A combined bet needs at least 2 selections" });
    }
    if (legs.length > MAX_COMBINED_LEGS) {
      return res.status(400).json({ success: false, error: `A combined bet supports at most ${MAX_COMBINED_LEGS} selections` });
    }
    const first = legs[0] || {};
    if (!legs.every((l) => String(l?.eventid) === String(first.eventid) && String(l?.match_id) === String(first.match_id))) {
      return res.status(400).json({ success: false, error: "All combined selections must belong to the same market" });
    }
    const isBadloSlip = legs.every((l) => isBadloBet(l));
    const firstSide = String(first.bet_type || "").toLowerCase();
    if (!isBadloSlip && !legs.every((l) => String(l?.bet_type || "").toLowerCase() === firstSide)) {
      return res.status(400).json({ success: false, error: "All combined selections must be the same bet type (all back or all lay)" });
    }
    const selNames = legs.map((l) => String(l?.selection_name || "").trim());
    if (selNames.some((s) => !s)) {
      return res.status(400).json({ success: false, error: "Every combined selection needs a selection name" });
    }
    if (!isBadloSlip && new Set(selNames.map((s) => s.toLowerCase())).size !== selNames.length) {
      return res.status(400).json({ success: false, error: "Combined selections must be distinct runners" });
    }
    if (isBadloSlip) {
      const runs = legs.map((l) => Number(l?.odds));
      if (runs.some((r) => !Number.isFinite(r) || r <= 0)) {
        return res.status(400).json({ success: false, error: "Every badlo selection needs a run" });
      }
      if (new Set(runs).size !== runs.length) {
        return res.status(400).json({ success: false, error: "Badlo selections must be on distinct runs" });
      }
    }
    if (legs.some((l) => !Number.isFinite(Number(l?.stake_amount)) || Number(l?.stake_amount) <= 0)) {
      return res.status(400).json({ success: false, error: "Invalid stake on a combined selection" });
    }
    if (legs.some((l) => !Array.isArray(l?.runners) || !l.runners.length)) {
      return res.status(400).json({ success: false, error: "Combined selections are missing the runner list" });
    }
    const totalStake = isBadloSlip ? Math.max(...legs.map((l) => Number(l.stake_amount))) : legs.reduce((s, l) => s + Number(l.stake_amount), 0);
    try {
      const limits = await resolveMarketLimits({
        eventid: first.eventid,
        sid: first.sid,
        match_id: first.match_id,
        mname: first.mname,
        market_type: first.market_type,
        selection_name: first.selection_name
      });
      if (limits) {
        console.log(`[placeCombinedBet] Limits for ${limits.marketName}: min=${limits.minLimit} max=${limits.maxLimit} total=${totalStake}`);
        if (limits.minLimit > 0 && totalStake < limits.minLimit) {
          return res.status(400).json({ success: false, error: `Minimum bet amount is ${limits.minLimit}` });
        }
        if (limits.maxLimit > 0 && totalStake > limits.maxLimit) {
          return res.status(400).json({ success: false, error: `Maximum bet amount is ${limits.maxLimit}` });
        }
      }
    } catch (limitErr) {
      console.warn("[placeCombinedBet] Market limits lookup failed (non-blocking):", limitErr.message);
    }
    for (const leg of legs) {
      const d = await checkBetLive(leg);
      if (!d.accept) {
        console.log(`[placeCombinedBet] \u2717 rejected user=${user_id} gmid=${leg.eventid} market=${leg.match_id} sel=${leg.selection_id} code=${d.code}`);
        return res.status(400).json({ success: false, error: `${leg.selection_name}: ${d.message}`, code: d.code });
      }
    }
    transaction = await db_default.transaction();
    const slipCreatedAt = isBadloSlip ? /* @__PURE__ */ new Date() : null;
    const legResults = [];
    for (const leg of legs) {
      const legReq = {
        user: req.user,
        headers: req.headers,
        connection: req.connection,
        ip: req.ip,
        body: leg
      };
      const legRes = makeLegRes();
      await placeBet(legReq, legRes, { transaction, skipMinStake: true, createdAt: slipCreatedAt });
      if (!legRes.body || legRes.body.success !== true) {
        const msg = legRes.body?.error || legRes.body?.message || "Bet rejected";
        throw new Error(`${leg.selection_name}: ${msg}`);
      }
      legResults.push(legRes.body);
    }
    await transaction.commit();
    transaction = null;
    const last = legResults[legResults.length - 1];
    return res.json({
      success: true,
      legs: legResults.length,
      exposure: last?.exposure,
      balanceDelta: legResults.reduce((s, r) => s + Number(r?.balanceDelta || 0), 0),
      newBalance: last?.newBalance,
      totalExposure: last?.totalExposure
    });
  } catch (err) {
    if (transaction) {
      try {
        await transaction.rollback();
      } catch (rbErr) {
        console.error("COMBINED BET ROLLBACK ERROR:", rbErr.message);
      }
    }
    console.error("PLACE COMBINED BET ERROR:", err.message);
    return res.status(400).json({ success: false, error: err.message });
  }
};
var cancelBet = async (req, res) => {
  const transaction = await db_default.transaction();
  try {
    const user_id = req.user.account.id;
    if (!user_id) throw new Error("User ID is required");
    const { bet_id } = req.body;
    if (!bet_id) throw new Error("bet_id is required");
    const bet = await SportsBet_default.findOne({
      where: { id: bet_id },
      transaction,
      lock: transaction.LOCK.UPDATE
    });
    if (!bet) {
      await transaction.rollback();
      return res.status(404).json({ success: false, error: "Bet not found" });
    }
    if (String(bet.user_id) !== String(user_id)) {
      await transaction.rollback();
      return res.status(403).json({ success: false, error: "Not your bet" });
    }
    if (bet.unmatched !== true) {
      await transaction.rollback();
      return res.status(400).json({ success: false, error: "Only unmatched bets can be cancelled" });
    }
    if (bet.status !== "open") {
      await transaction.rollback();
      return res.status(400).json({ success: false, error: `Bet is already ${bet.status}` });
    }
    if (bet.game_type !== "MO" && bet.game_type !== "BM") {
      await transaction.rollback();
      return res.status(400).json({ success: false, error: "Only match-odds unmatched bets can be cancelled" });
    }
    console.log(`[cancelBet] user=${user_id} bet=${bet_id} market=${bet.market_type} match=${bet.match_id}`);
    bet.status = "cancelled";
    bet.result_status = "cancelled";
    bet.updated_at = /* @__PURE__ */ new Date();
    await bet.save({ transaction });
    const cancelExpGameType = exposureIdentity({ marketType: bet.market_type, selectionName: bet.selection_name, badlo: isBadloBet(bet) }).game_type;
    const oldRows = await UserExposure_default.findAll({
      where: { user_id, match_id: bet.match_id, game_type: cancelExpGameType },
      transaction,
      lock: transaction.LOCK.UPDATE
    });
    const oldExposures = {};
    oldRows.forEach((r) => oldExposures[r.team_name] = Number(r.exposure_amount));
    const remaining = await SportsBet_default.findAll({
      where: {
        user_id,
        match_id: bet.match_id,
        market_type: bet.market_type,
        badlo: isBadloBet(bet),
        status: "open"
      },
      order: [["created_at", "ASC"]],
      transaction
    });
    let replayed = {};
    for (const b of remaining) {
      const runners = Array.isArray(b.runners) ? b.runners : [];
      if (!runners.length) continue;
      const odd = b.game_type === "BM" ? normalizeOdds(Number(b.odds)) : Number(b.odds);
      replayed = calculateRunnerExposure({
        runners,
        selectedRunner: b.selection_name,
        stake: Number(b.stake_amount),
        odd,
        betType: (b.bet_type || "").toLowerCase(),
        oldExposures: replayed
      });
    }
    const newExposures = {};
    for (const name of /* @__PURE__ */ new Set([...Object.keys(oldExposures), ...Object.keys(replayed)])) {
      newExposures[name] = Number((replayed[name] || 0).toFixed(2));
    }
    console.log("[cancelBet] OLD EXPOSURES:", oldExposures);
    console.log("[cancelBet] RECOMPUTED EXPOSURES:", newExposures);
    for (const [name, amt] of Object.entries(newExposures)) {
      await UserExposure_default.upsert(
        {
          user_id,
          match_id: bet.match_id,
          team_name: name,
          exposure_amount: amt,
          match_title: bet.match_title,
          game_type: cancelExpGameType,
          event_id: bet.eventid,
          category: "sports"
        },
        { transaction }
      );
    }
    const oldNegs = Object.values(oldExposures).filter((x) => x < 0);
    const newNegs = Object.values(newExposures).filter((x) => x < 0);
    const oldMax = oldNegs.length ? Math.abs(Math.min(...oldNegs)) : 0;
    const newMax = newNegs.length ? Math.abs(Math.min(...newNegs)) : 0;
    const refund = Number((oldMax - newMax).toFixed(2));
    console.log(`[cancelBet] Liability: old=${oldMax} new=${newMax} refund=${refund}`);
    const wallet = await Wallet_default.findOne({
      where: { user_id },
      transaction,
      lock: transaction.LOCK.UPDATE
    });
    if (!wallet) throw new Error("Wallet not found");
    if (refund > 0) {
      wallet.cash = Number(wallet.cash || 0) + refund;
      if (isNaN(wallet.cash)) throw new Error("Balance calculation resulted in NaN");
      await wallet.save({ transaction });
    }
    const newBalance = Number(wallet.cash || 0);
    const exposureResults = await db_default.query(TOTAL_EXPOSURE_SQL, {
      replacements: { user_id },
      type: db_default.QueryTypes.SELECT,
      transaction
    });
    const totalUserExposure = parseFloat(exposureResults[0]?.total_exposure) || 0;
    await TotalExposure_default.upsert({ user_id, total_exposure: totalUserExposure }, { transaction });
    await transaction.commit();
    console.log(`[cancelBet] \u2705 bet=${bet_id} refund=${refund} newBalance=${newBalance} totalExposure=${totalUserExposure}`);
    return res.json({
      success: true,
      cancelled_bet_id: bet.id,
      refund,
      newBalance,
      totalExposure: totalUserExposure,
      exposure: { [bet.match_id]: { match_title: bet.match_title, teams: newExposures } }
    });
  } catch (err) {
    await transaction.rollback();
    console.error("CANCEL BET ERROR:", err.message);
    return res.status(400).json({ success: false, error: err.message });
  }
};
var getFancyBets = async (req, res) => {
  try {
    const user_id = req.user.account.id;
    const { runner, match_id, event_id, sport_id, market_type } = req.query;
    if (!runner || !match_id) {
      return res.status(400).json({ success: false, error: "Missing required parameters" });
    }
    const whereClause = {
      user_id,
      [Op6.or]: [
        { selection_name: { [Op6.iLike]: runner.trim() } },
        { fancy_name: { [Op6.iLike]: runner.trim() } }
      ],
      // match_id param carries the gmid, which bets persist in `eventid`
      eventid: String(event_id || match_id),
      status: "open"
    };
    if (sport_id) whereClause.sport_id = String(sport_id);
    if (market_type) whereClause.market_type = String(market_type);
    const bets = await SportsBet_default.findAll({
      where: whereClause,
      // market_type included so the client can spot fancy1/oddeven, where
      // `size` is market volume rather than a bhav
      // fancy_name carries the khado band width — the ladder needs it to draw
      // the win band (see prepareBetPayload).
      // `badlo` marks the EXACT-RUN legs: the ladder draws them as spikes, not
      // as the step every other session bet draws (helper/badloMarket.js).
      attributes: ["bet_type", "stake_amount", "odds", "size", "liability", "market_type", "fancy_name", "badlo"]
    });
    return res.json({ success: true, bets });
  } catch (err) {
    console.error("GET FANCY BETS ERROR:", err.message);
    return res.status(500).json({ success: false, error: err.message });
  }
};
var controller = {
  placeBet,
  placeCombinedBet,
  cancelBet,
  getFancyBets
};
var sportbetscontroller_default = controller;

// services/ExposureService.js
init_db();
init_TotalExposure();
async function getUserTotalExposure(user_id) {
  const TotalExposure2 = (await Promise.resolve().then(() => (init_TotalExposure(), TotalExposure_exports))).default;
  const record = await TotalExposure2.findOne({ where: { user_id } });
  if (record) {
    return parseFloat(record.total_exposure);
  }
  return null;
}
async function getexpossurebyid(user_id, match_id) {
  const { Op: Op16 } = await import("sequelize");
  return await UserExposure_default.findAll({
    where: {
      user_id,
      [Op16.or]: [
        { match_id },
        { event_id: match_id }
      ]
    }
  });
}
async function getUserExposures(userId) {
  const rows = await UserExposure_default.findAll({
    where: { user_id: Number(userId) },
    raw: true
  });
  const exposures = {};
  for (const row of rows) {
    const matchId = row.match_id;
    const teamName = row.team_name;
    const amount = Number(row.exposure_amount || 0);
    if (!exposures[matchId]) {
      exposures[matchId] = {
        match_title: row.match_title || "",
        teams: {}
      };
    }
    const current = Number(exposures[matchId].teams[teamName] || 0);
    exposures[matchId].teams[teamName] = current + amount;
  }
  return exposures;
}

// controller/user/userExposureController.js
var ExposureController = {
  getAllExposuresForUser: async (req, res) => {
    try {
      const { user_id } = req.body;
      if (!user_id) {
        return res.status(400).json({
          success: false,
          error: "User ID (uuid) is required"
        });
      }
      const exposures = await getUserExposures(user_id);
      return res.status(200).json({
        success: true,
        exposures
      });
    } catch (error) {
      console.error("\u274C getAllExposuresForUser error:", error);
      return res.status(500).json({
        success: false,
        error: error.message
      });
    }
  },
  // 🎯 Get Exposure By User & Match (POST body)
  getExposureById: async (req, res) => {
    try {
      const { user_id, match_id } = req.body;
      if (!user_id || !match_id) {
        return res.status(400).json({
          success: false,
          error: "user_id and match_id are required"
        });
      }
      const exposureData = await getexpossurebyid(user_id, match_id);
      return res.status(200).json({
        success: true,
        message: "Exposure data fetched successfully",
        data: exposureData
      });
    } catch (error) {
      console.error("\u274C Get exposure error:", error);
      return res.status(500).json({
        success: false,
        error: error.message
      });
    }
  },
  // 🎯 Get Exposure By Query Params (GET)
  getExposureByQuery: async (req, res) => {
    try {
      const { match_id } = req.query;
      const user_id = req.user?.account?.id;
      if (!match_id) {
        return res.status(400).json({
          success: false,
          error: "match_id is required"
        });
      }
      if (!user_id) {
        return res.status(401).json({
          success: false,
          error: "Unauthorized"
        });
      }
      const { Op: Op16 } = await import("sequelize");
      const exposureData = await UserExposure_default.findAll({
        where: {
          user_id,
          [Op16.or]: [
            { match_id },
            { event_id: match_id }
          ]
        }
      });
      return res.status(200).json({
        success: true,
        message: "Exposure data fetched successfully",
        data: exposureData
      });
    } catch (error) {
      console.error("\u274C Get exposure by query error:", error);
      return res.status(500).json({
        success: false,
        error: error.message
      });
    }
  }
};
var userExposureController_default = ExposureController;

// utils/jwt.js
import jwt3 from "jsonwebtoken";
function verifyToken(token) {
  return jwt3.verify(token, process.env.JWT_SECRET);
}

// services/walletService.js
import { Op as Op7 } from "sequelize";

// model/admin/Transaction.js
init_db();
import { DataTypes as DataTypes30 } from "sequelize";
var Transaction = db_default.define("Transaction", {
  id: {
    type: DataTypes30.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  // Existing fields (kept for backward compatibility)
  credit: {
    type: DataTypes30.STRING,
    // Username of credited user
    allowNull: true
  },
  debit: {
    type: DataTypes30.STRING,
    // Username of debited user
    allowNull: true
  },
  amount: {
    type: DataTypes30.DECIMAL(20, 2),
    allowNull: false
  },
  balance: {
    type: DataTypes30.DECIMAL(20, 2),
    allowNull: false
    // ✅ This is required - we now populate it in all transactions
  },
  wallet_id: {
    type: DataTypes30.INTEGER,
    allowNull: true
  },
  // ✅ New fields for enhanced transaction logging
  user_id: {
    type: DataTypes30.INTEGER,
    allowNull: true,
    comment: "User ID linked to this transaction"
  },
  staff_id: {
    type: DataTypes30.INTEGER,
    allowNull: true,
    comment: "Staff ID linked to this transaction"
  },
  owner_id: {
    type: DataTypes30.INTEGER,
    allowNull: true,
    comment: "Owner ID linked to this transaction"
  },
  username: {
    type: DataTypes30.STRING,
    allowNull: true,
    comment: "Username linked to this transaction"
  },
  type: {
    type: DataTypes30.STRING,
    allowNull: true,
    comment: "Transaction type (ADD_CASH, SUBTRACT_CREDIT, CREDIT_INR, DEBIT_USDT, etc.)"
  },
  previous_balance: {
    type: DataTypes30.DECIMAL(20, 2),
    allowNull: true,
    comment: "Balance before this transaction"
  },
  new_balance: {
    type: DataTypes30.DECIMAL(20, 2),
    allowNull: true,
    comment: "Balance after this transaction"
  },
  initiated_by: {
    type: DataTypes30.STRING,
    allowNull: true,
    comment: "Who initiated this transaction (Admin/System/User)"
  }
}, {
  tableName: "transactions",
  timestamps: true,
  // Keep createdAt and updatedAt
  underscored: false
});
var Transaction_default = Transaction;

// model/admin/PointLedger.js
init_db();
import { DataTypes as DataTypes31 } from "sequelize";
var PointLedger = db_default.define(
  "PointLedger",
  {
    id: { type: DataTypes31.BIGINT.UNSIGNED, primaryKey: true, autoIncrement: true },
    // Event ki unique pehchaan — hamesha constants/pointLedger.js ke
    // pointEntryRef builders se banao, haath se nahi
    entry_ref: { type: DataTypes31.STRING(120), allowNull: false },
    // VARCHAR rakha (ENUM nahi) — values readable hain ('User creation', 'Bank Deposite')
    // aur naya type aaye toh DB ALTER nahi lagta
    event_type: { type: DataTypes31.STRING(40), allowNull: false },
    // Jis wallet ki entry hai usi ka username (reports me join bachata hai)
    username: { type: DataTypes31.STRING(100), allowNull: true },
    // Entry ke waqt wallet ka inr_balance kya tha (closing)
    closing_inr_balance: { type: DataTypes31.DECIMAL(18, 2), allowNull: true },
    // Doosri side wale (parent/sender) ka closing inr_balance — deposit/withdraw/settle/creation me
    closing_inr_balance_parent: { type: DataTypes31.DECIMAL(18, 2), allowNull: true },
    // Sirf BET_SETTLEMENT me: kis sport/game se aaya
    sport_id: { type: DataTypes31.STRING(50), allowNull: true },
    game_type: { type: DataTypes31.STRING(50), allowNull: true },
    // Sirf BET_SETTLEMENT me bharta hai: POINT_CATEGORY (SPORTS)
    category: { type: DataTypes31.STRING(30), allowNull: true },
    // Kis bet se aaya (sports = market ki pehli bet id)
    bet_id: { type: DataTypes31.BIGINT, allowNull: true },
    wallet_id: { type: DataTypes31.INTEGER, allowNull: false },
    // Sirf CASH_SETTLEMENT me: kiske SAATH hisaab hua (upar wala wallet).
    // Settle-out me entry sirf neeche wale ke wallet me lagti hai — upar wale ka
    // all_point touch nahi hota (sirf cash), uska apna claim upline ke saath
    // tabhi clear hota hai jab upar se settlement aata hai.
    settled_with_wallet_id: { type: DataTypes31.INTEGER, allowNull: true },
    // Sign ke saath: jeet +, haar − (BET_SETTLEMENT me chain ke har wallet me same delta)
    delta: { type: DataTypes31.DECIMAL(18, 2), allowNull: false },
    // Entry lagne ke turant baad all_point kya bana (audit ke liye)
    all_point_after: { type: DataTypes31.DECIMAL(18, 2), allowNull: true },
    // Kis user ke event se ye entry aayi (jeetne/haarne wala user)
    source_user_id: { type: DataTypes31.INTEGER, allowNull: true },
    remark: { type: DataTypes31.STRING(255), allowNull: true }
  },
  {
    tableName: "point_ledger",
    timestamps: true,
    createdAt: "created_at",
    updatedAt: false,
    indexes: [
      // Ek hi key do kaam karti hai:
      //  1. Idempotency — same event same wallet pe dobara INSERT = DB reject
      //  2. Per-wallet SUM — wallet_id prefix + implicit PK id se
      //     "WHERE wallet_id = ? AND id > ?" range bhi isi se chalta hai
      { unique: true, fields: ["wallet_id", "entry_ref"], name: "uq_wallet_entry" }
    ]
  }
);
var PointLedger_default = PointLedger;

// constants/pointLedger.js
var POINT_EVENT = {
  USER_CREATION: "User creation",
  // user/staff/owner create hua (opening credit)
  BET_SETTLEMENT: "BET_SETTLEMENT",
  // user ki bet/market settle hui (poori chain me)
  BANK_DEPOSIT: "Bank Deposite",
  // parent ne child ko diya (sirf normal deposit)
  BANK_WITHDRAW: "Bank Withdraw",
  // parent ne child se liya (sirf normal withdraw)
  CREDIT: "Credit",
  // sirf settlement me: parent ne child ko diya (+)
  DEBIT: "Debit",
  // sirf settlement me: parent ne child se liya (−)
  MANUAL_ADJUSTMENT: "MANUAL_ADJUSTMENT",
  // admin correction (API se, DB se nahi)
  REVERSAL: "REVERSAL",
  // galat entry ka ulta — original kabhi delete nahi hoti
  // Sports win commission (owner cell ON): jeet ke baad alag '- Comm' entry, poori
  // chain me settlement jaisa hi (docs/plans/2026-09-09-sports-win-commission.md)
  COMMISSION: "COMMISSION"
};
var POINT_EVENT_TYPES = Object.values(POINT_EVENT);
var POINT_CATEGORY = {
  SPORTS: "SPORTS"
};
var pointEntryRef = {
  opening: (walletId) => `open:${walletId}`,
  baseline: (walletId) => `baseline:${walletId}`,
  bet: (betType, betId) => `settle:bet:${betType}:${betId}`,
  // settlement ke baad void: original settle:bet:* entry kabhi delete nahi hoti,
  // uske saamne ye ulti entry banti hai (POINT_EVENT.REVERSAL)
  betReversal: (betType, betId) => `reverse:bet:${betType}:${betId}`,
  // win commission on a settled bet/market, and its void-time reversal
  commission: (betType, betId) => `commission:bet:${betType}:${betId}`,
  commissionReversal: (betType, betId) => `reverse:commission:${betType}:${betId}`,
  deposit: (transactionId) => `deposit:${transactionId}`,
  withdraw: (transactionId) => `withdraw:${transactionId}`,
  cashSettle: (transactionId) => `cashsettle:${transactionId}`,
  adjust: (adminUsername, uniqueId) => `adjust:${adminUsername}:${uniqueId}`
};
var LEDGER_CATEGORY_ALIASES = {
  SPORTS: ["SPORTS"]
};

// services/walletService.js
init_db();

// utils/socketUtils.js
var _io = null;
var setIO = (io) => {
  _io = io;
};
async function getIO() {
  if (process.env.WORKER_MODE) return null;
  return _io;
}
var BALANCE_UPDATES_CHANNEL = "socket:balance_updates";
var _pub = null;
async function getPublisher() {
  if (_pub) return _pub;
  try {
    const mod = await Promise.resolve().then(() => (init_redisClient(), redisClient_exports));
    _pub = mod.default;
  } catch {
    _pub = null;
  }
  return _pub;
}
var emitBalanceUpdate = async (userId, balanceData) => {
  const payload = {
    userId,
    balance: {
      ...balanceData.inr_balance != null && { inr_balance: balanceData.inr_balance },
      // Raw exposure value (negative = liability)
      ...balanceData.exposure != null && { exposure: parseFloat(balanceData.exposure) }
    },
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  };
  const io = await getIO();
  if (io) {
    io.to(`user_${userId}`).emit("balanceUpdate", payload);
    return;
  }
  const pub2 = await getPublisher();
  if (pub2) {
    try {
      await pub2.publish(BALANCE_UPDATES_CHANNEL, JSON.stringify(payload));
    } catch (err) {
      console.error("emitBalanceUpdate: redis publish failed:", err.message);
    }
  }
};

// helper/voidLabel.js
var VOID_SUFFIX = "-void";
var isVoidRow = (row) => row?.event_type === POINT_EVENT.REVERSAL || String(row?.entry_ref || "").startsWith("reverse:");
var stripVoidPrefix = (text) => String(text || "").replace(/^VOID after settlement\s*[—-]\s*/i, "").trim();
var withVoidSuffix = (text) => {
  const s = stripVoidPrefix(text);
  if (!s) return VOID_SUFFIX;
  return s.endsWith(VOID_SUFFIX) ? s : `${s} ${VOID_SUFFIX}`;
};

// wallet_utility/hierarchyUtility.js
var decrementAncestorCashReceived = async (userId, amount, transaction) => {
  try {
    console.log(`[Hierarchy] Decrementing cash_received for ancestors of user ${userId} by ${amount}`);
    const txnOpts = transaction ? { transaction } : {};
    const lockOpts = transaction ? { transaction, lock: transaction.LOCK.UPDATE } : {};
    const user = await User_default.findByPk(userId, txnOpts);
    if (!user) return;
    let currentStaffId = user.parent_staff_id;
    let currentOwnerId = user.parent_owner_id;
    const userWallet = await Wallet_default.findOne({
      where: { user_id: userId, user_type: "USER" },
      ...lockOpts
    });
    if (userWallet) {
      const prevRec = parseFloat(userWallet.cash_received || 0);
      userWallet.cash_received = prevRec - parseFloat(amount);
      await userWallet.save(txnOpts);
      console.log(`[Hierarchy] Decremented cash_received for User ${userId} (${user.username})`);
    }
    while (currentStaffId) {
      const staff = await Staff_default.findByPk(currentStaffId, txnOpts);
      if (!staff) break;
      const wallet = await Wallet_default.findOne({
        where: { staff_id: currentStaffId, user_type: staff.role.toUpperCase() },
        ...lockOpts
      });
      if (wallet) {
        const prevRec = parseFloat(wallet.cash_received || 0);
        wallet.cash_received = prevRec - parseFloat(amount);
        await wallet.save(txnOpts);
        console.log(`[Hierarchy] Decremented cash_received for Staff ${currentStaffId} (${staff.username})`);
      }
      currentOwnerId = staff.parent_owner_id;
      currentStaffId = staff.parent_id;
    }
    if (currentOwnerId) {
      const owner = await Owner_default.findByPk(currentOwnerId, txnOpts);
      if (owner) {
        const wallet = await Wallet_default.findOne({
          where: { owner_id: currentOwnerId, user_type: "OWNER" },
          ...lockOpts
        });
        if (wallet) {
          const prevRec = parseFloat(wallet.cash_received || 0);
          wallet.cash_received = prevRec - parseFloat(amount);
          await wallet.save(txnOpts);
          console.log(`[Hierarchy] Decremented cash_received for Owner ${currentOwnerId} (${owner.username})`);
        }
      }
    }
  } catch (e) {
    console.error("\u274C decrementAncestorCashReceived error:", e);
    throw e;
  }
};

// services/walletService.js
var WalletService = {
  // ---------------------------------------------------------------------------
  // Helper: determine correct ID field
  // ---------------------------------------------------------------------------
  getWalletQueryField(userType) {
    const type = userType ? userType.toUpperCase() : null;
    if (type === "USER") return "user_id";
    if (["SUPERADMIN", "COMPANY", "ADMIN", "SUPERMASTER", "MASTER", "AGENT"].includes(type)) return "staff_id";
    if (type === "OWNER") return "owner_id";
    return "USER TYPE NOT FOUND";
  },
  // -----------------------------------------------------------------------
  // Helper: Get Hierarchy IDs (User, Staff, Owner)
  // -----------------------------------------------------------------------
  getHierarchyIds: async (entityId, userType) => {
    const type = userType ? userType.toUpperCase() : "";
    let userId = null;
    let staffId = null;
    let ownerId = null;
    if (type === "USER") {
      userId = entityId;
      const user = await User_default.findByPk(entityId);
      if (user) {
        staffId = user.parent_staff_id;
        ownerId = user.parent_owner_id;
      }
    } else if (type === "OWNER") {
      ownerId = entityId;
    } else {
      staffId = entityId;
      const staff = await Staff_default.findByPk(entityId);
      if (staff && staff.parent_owner_id) {
        ownerId = staff.parent_owner_id;
      } else {
        const owner = await Owner_default.findOne({ attributes: ["owner_id"] });
        if (owner) ownerId = owner.owner_id;
      }
    }
    return { userId, staffId, ownerId };
  },
  // -----------------------------------------------------------------------
  // CREATE WALLET
  // -----------------------------------------------------------------------
  createWallet: async (entityId, userType, transaction, username, credit = 0, cash = 0) => {
    try {
      const roleMap = {
        company: "COMPANY",
        superadmin: "SUPERADMIN",
        admin: "ADMIN",
        supermaster: "SUPERMASTER",
        master: "MASTER",
        agent: "AGENT",
        owner: "OWNER",
        user: "USER"
      };
      const normalised = roleMap[userType?.toLowerCase()] || userType?.toUpperCase();
      const idField = WalletService.getWalletQueryField(normalised);
      const whereClause = { [idField]: entityId, user_type: normalised };
      const existing = await Wallet_default.findOne({ where: whereClause, transaction });
      if (existing) return existing;
      const walletData = {
        user_type: normalised,
        username,
        inr_balance: 0,
        cash: 0,
        credit: 0
      };
      if (idField === "user_id") walletData.user_id = entityId;
      if (idField === "staff_id") walletData.staff_id = entityId;
      if (idField === "owner_id") walletData.owner_id = entityId;
      return await Wallet_default.create(walletData, { transaction });
    } catch (e) {
      console.error("\u274C createWallet error:", e);
      throw e;
    }
  },
  // -----------------------------------------------------------------------
  // CREDIT BALANCE (INR) - Used in creditBalance controller
  // -----------------------------------------------------------------------
  creditBalance: async (entityId, amount, userType, transaction, initiatedBy, senderType = null) => {
    try {
      const idField = WalletService.getWalletQueryField(userType);
      const wallet = await Wallet_default.findOne({ where: { [idField]: entityId, user_type: userType }, transaction });
      if (!wallet) throw new Error("Wallet not found");
      const prev = parseFloat(wallet.inr_balance);
      wallet.inr_balance = prev + parseFloat(amount);
      await wallet.save({ transaction });
      const { userId: t_userId, staffId: t_staffId, ownerId: t_ownerId } = await WalletService.getHierarchyIds(entityId, userType);
      await Transaction_default.create(
        {
          wallet_id: wallet.wallet_id,
          username: wallet.username,
          user_id: t_userId,
          staff_id: t_staffId,
          owner_id: t_ownerId,
          type: "CREDIT_INR",
          amount: parseFloat(amount),
          previous_balance: prev,
          new_balance: wallet.inr_balance,
          balance: wallet.inr_balance,
          credit: wallet.username,
          debit: initiatedBy,
          initiated_by: initiatedBy
        },
        { transaction }
      );
      emitBalanceUpdate(entityId, { inr_balance: wallet.inr_balance });
      return wallet;
    } catch (e) {
      console.error("\u274C creditBalance error:", e);
      throw e;
    }
  },
  // -----------------------------------------------------------------------
  // DEBIT BALANCE (INR)
  // -----------------------------------------------------------------------
  debitBalance: async (entityId, amount, userType, transaction, initiatedBy) => {
    try {
      const idField = WalletService.getWalletQueryField(userType);
      const wallet = await Wallet_default.findOne({ where: { [idField]: entityId, user_type: userType }, transaction });
      if (!wallet) throw new Error("Wallet not found");
      const current = parseFloat(wallet.inr_balance);
      if (current < parseFloat(amount)) throw new Error("Insufficient balance");
      wallet.inr_balance = current - parseFloat(amount);
      const updatedPL = Math.round((wallet.inr_balance - parseFloat(wallet.cash_received || 0)) * 100) / 100;
      wallet.profit_loss = updatedPL;
      wallet.verdict = updatedPL >= 0 ? "profit" : "loss";
      await wallet.save({ transaction });
      const { userId: t_userId, staffId: t_staffId, ownerId: t_ownerId } = await WalletService.getHierarchyIds(entityId, userType);
      await Transaction_default.create({
        wallet_id: wallet.wallet_id,
        username: wallet.username,
        user_id: t_userId,
        staff_id: t_staffId,
        owner_id: t_ownerId,
        type: "DEBIT_INR",
        amount: parseFloat(amount),
        previous_balance: current,
        new_balance: wallet.inr_balance,
        balance: wallet.inr_balance,
        credit: initiatedBy,
        debit: wallet.username,
        initiated_by: initiatedBy
      }, { transaction });
      emitBalanceUpdate(entityId, { inr_balance: wallet.inr_balance });
      return wallet;
    } catch (e) {
      console.error("\u274C debitBalance error:", e);
      throw e;
    }
  },
  /**
   * Recursively decrements cash_received for all ancestors (Staff & Owners)
   * Triggered when a User loses a bet.
   */
  decrementAncestorCashReceived,
  // -----------------------------------------------------------------------
  // ADD CASH → OWNER gets it for FREE
  // -----------------------------------------------------------------------
  //This is old Api and not recommended to use in tenexch
  addCash: async (receiverId, amount, userType, transaction, initiatedBy, senderId = null, senderType = null) => {
    if (!userType || !receiverId) throw new Error("ReceiverId and UserType required");
    try {
      const receiverField = WalletService.getWalletQueryField(userType);
      const receiverWallet = await Wallet_default.findOne({ where: { [receiverField]: receiverId }, transaction });
      if (!receiverWallet) throw new Error("Receiver wallet not found");
      let performDeduction = false;
      let senderOwner = null;
      if (senderId && senderType) {
        if (senderType.toUpperCase() !== "OWNER") {
          performDeduction = true;
        } else {
          const owner = await Owner_default.findByPk(senderId, { transaction });
          senderOwner = owner;
          if (owner && !owner.unlimited_balance) {
            performDeduction = true;
          }
        }
      }
      if (performDeduction) {
        const senderField = WalletService.getWalletQueryField(senderType);
        const senderWallet = await Wallet_default.findOne({
          where: { [senderField]: senderId, user_type: senderType },
          transaction,
          lock: transaction.LOCK.UPDATE
        });
        if (!senderWallet) throw new Error("Sender wallet not found");
        const currentBal = parseFloat(senderWallet.inr_balance ?? 0);
        const currentCash = parseFloat(senderWallet.cash ?? 0);
        const deductAmount = parseFloat(amount);
        if (currentBal < deductAmount) throw new Error("Insufficient INR balance in sender");
        if (currentCash < deductAmount) throw new Error("Insufficient CASH in sender");
        const newBalance = Math.round((currentBal - deductAmount) * 100) / 100;
        const newCash = Math.round((currentCash - deductAmount) * 100) / 100;
        senderWallet.setDataValue("inr_balance", newBalance);
        senderWallet.setDataValue("cash", newCash);
        senderWallet.changed("inr_balance", true);
        senderWallet.changed("cash", true);
        const newProfitLoss = Math.round((newBalance - parseFloat(senderWallet.cash_received || 0)) * 100) / 100;
        senderWallet.setDataValue("profit_loss", newProfitLoss);
        senderWallet.setDataValue("verdict", newProfitLoss >= 0 ? "profit" : "loss");
        senderWallet.changed("profit_loss", true);
        senderWallet.changed("verdict", true);
        await senderWallet.save({ transaction });
        let { userId: s_userId, staffId: s_staffId, ownerId: s_ownerId } = await WalletService.getHierarchyIds(senderId, senderType);
        if (senderType.toUpperCase() === "OWNER" && userType.toUpperCase() !== "USER" && userType.toUpperCase() !== "OWNER") {
          s_staffId = receiverId;
        }
        if (senderType.toUpperCase() === "OWNER" && userType.toUpperCase() === "USER") {
          s_userId = receiverId;
        }
        await Transaction_default.create({
          wallet_id: senderWallet.wallet_id,
          user_id: s_userId,
          staff_id: s_staffId,
          owner_id: s_ownerId,
          username: senderType.toUpperCase() === "OWNER" && senderOwner ? senderOwner.username : senderWallet.username,
          type: "DEBIT_FOR_CASH",
          amount: deductAmount,
          previous_balance: currentBal,
          new_balance: newBalance,
          balance: newBalance,
          credit: receiverWallet.username,
          debit: senderType.toUpperCase() === "OWNER" && senderOwner ? senderOwner.username : senderWallet.username,
          initiated_by: initiatedBy
        }, { transaction });
        emitBalanceUpdate(senderId, { inr_balance: newBalance, cash: newCash });
        console.log(`Cash deducted from ${senderType} (${senderId})`);
      } else if (senderType?.toUpperCase() === "OWNER") {
        console.log(`OWNER (${senderId}) added cash \u2192 FREE (unlimited balance)`);
        let { userId: s_userId, staffId: s_staffId, ownerId: s_ownerId } = await WalletService.getHierarchyIds(senderId, senderType);
        if (senderType.toUpperCase() === "OWNER" && userType.toUpperCase() !== "USER" && userType.toUpperCase() !== "OWNER") {
          s_staffId = receiverId;
        }
        if (senderType.toUpperCase() === "OWNER" && userType.toUpperCase() === "USER") {
          s_userId = receiverId;
        }
        const senderWallet = await Wallet_default.findOne({ where: { [WalletService.getWalletQueryField(senderType)]: senderId } });
        const currentBal = senderWallet ? parseFloat(senderWallet.inr_balance || 0) : 0;
        await Transaction_default.create({
          wallet_id: senderWallet ? senderWallet.wallet_id : null,
          user_id: s_userId,
          staff_id: s_staffId,
          owner_id: s_ownerId,
          username: senderOwner ? senderOwner.username : "OWNER",
          type: "DEBIT_FOR_CASH",
          amount: parseFloat(amount),
          previous_balance: currentBal,
          new_balance: currentBal,
          // Balance unchanged
          balance: currentBal,
          credit: receiverWallet.username,
          debit: senderOwner ? senderOwner.username : "OWNER",
          initiated_by: initiatedBy
        }, { transaction });
      }
      const prevCash = parseFloat(receiverWallet.cash || 0);
      const prevInr = parseFloat(receiverWallet.inr_balance || 0);
      receiverWallet.cash = prevCash + parseFloat(amount);
      receiverWallet.inr_balance = prevInr + parseFloat(amount);
      await receiverWallet.save({ transaction });
      let { userId: r_userId, staffId: r_staffId, ownerId: r_ownerId } = await WalletService.getHierarchyIds(receiverId, userType);
      if (senderType && senderType.toUpperCase() === "OWNER" && userType && userType.toUpperCase() === "USER") {
        r_staffId = null;
        if (!r_ownerId) r_ownerId = senderId;
      }
      await Transaction_default.create({
        wallet_id: receiverWallet.wallet_id,
        user_id: r_userId,
        staff_id: r_staffId,
        owner_id: r_ownerId,
        username: receiverWallet.username,
        type: "ADD_CASH",
        amount: parseFloat(amount),
        previous_balance: prevCash,
        new_balance: receiverWallet.cash,
        balance: receiverWallet.inr_balance,
        credit: receiverWallet.username,
        debit: initiatedBy,
        initiated_by: initiatedBy
      }, { transaction });
      emitBalanceUpdate(receiverId, { cash: receiverWallet.cash, inr_balance: receiverWallet.inr_balance });
      return receiverWallet;
    } catch (e) {
      console.error("\u274C addCash error:", e);
      throw e;
    }
  },
  // This is the new api for deposite
  addDeposit: async (receiverId, amount, userType, transaction, initiatedBy, senderId, senderType, remark = "") => {
    if (!receiverId || !userType) throw new Error("receiverId and userType required");
    if (!senderId || !senderType) throw new Error("sender info not found");
    try {
      const senderRole = senderType.toUpperCase();
      if (senderRole !== "OWNER" && senderRole !== "STAFF") {
        throw new Error("Only owner or staff can deposit");
      }
      const dep = Math.round(parseFloat(amount) * 100) / 100;
      if (isNaN(dep) || dep <= 0) throw new Error("amount must be greater than 0");
      const receiverRole = userType.toUpperCase() === "USER" ? "USER" : "STAFF";
      let receiver, parentStaff, parentOwner;
      if (receiverRole === "USER") {
        receiver = await User_default.findByPk(receiverId, { transaction });
        if (!receiver) throw new Error(`User ${receiverId} not found`);
        parentStaff = receiver.parent_staff_id;
        parentOwner = receiver.parent_owner_id;
      } else {
        receiver = await Staff_default.findByPk(receiverId, { transaction });
        if (!receiver) throw new Error(`Staff ${receiverId} not found`);
        parentStaff = receiver.parent_id;
        parentOwner = receiver.parent_owner_id;
      }
      let isDirect = false;
      if (senderRole === "OWNER") {
        isDirect = !parentStaff && Number(parentOwner) === Number(senderId);
      } else {
        isDirect = Number(parentStaff) === Number(senderId);
      }
      if (!isDirect) {
        throw new Error(`${receiver.username} is not your direct child, deposit not allowed`);
      }
      const receiverWallet = await Wallet_default.findOne({
        where: receiverRole === "USER" ? { user_id: receiverId, user_type: "USER" } : { staff_id: receiverId },
        transaction
      });
      if (!receiverWallet) throw new Error("Receiver wallet not found");
      const senderWallet = await Wallet_default.findOne({
        where: senderRole === "OWNER" ? { owner_id: senderId, user_type: "OWNER" } : { staff_id: senderId },
        transaction,
        lock: transaction.LOCK.UPDATE
      });
      if (!senderWallet) throw new Error("Sender wallet not found");
      let deduct = true;
      if (senderRole === "OWNER") {
        const owner = await Owner_default.findByPk(senderId, { transaction });
        if (owner && owner.unlimited_balance) deduct = false;
      }
      const senderInrBefore = Math.round(parseFloat(senderWallet.inr_balance || 0) * 100) / 100;
      let senderInrAfter = senderInrBefore;
      if (deduct) {
        if (senderInrBefore < dep) throw new Error(MESSAGES.ADMIN.USERS.DEPOSIT_INSUFFICIENT_CREDIT(senderInrBefore));
        senderInrAfter = Math.round((senderInrBefore - dep) * 100) / 100;
        await Wallet_default.increment({ inr_balance: -dep }, { where: { wallet_id: senderWallet.wallet_id }, transaction });
        await Transaction_default.create({
          wallet_id: senderWallet.wallet_id,
          user_id: null,
          staff_id: senderRole === "STAFF" ? senderId : null,
          owner_id: senderRole === "OWNER" ? senderId : null,
          username: senderWallet.username,
          type: "DEPOSIT",
          amount: dep,
          previous_balance: senderInrBefore,
          new_balance: senderInrAfter,
          balance: senderInrAfter,
          credit: receiverWallet.username,
          debit: senderWallet.username,
          initiated_by: initiatedBy
        }, { transaction });
        emitBalanceUpdate(senderId, { inr_balance: senderInrAfter });
      }
      let recInrBefore = Math.round(parseFloat(receiverWallet.inr_balance || 0) * 100) / 100;
      let recInrAfter = Math.round((recInrBefore + dep) * 100) / 100;
      const inc = { inr_balance: dep, credit: dep, all_point: dep };
      if (receiverRole === "USER") {
        inc.cash = dep;
        recInrBefore = Math.round(parseFloat(receiverWallet.cash || 0) * 100) / 100;
        recInrAfter = Math.round((recInrBefore + dep) * 100) / 100;
      }
      await Wallet_default.increment(inc, { where: { wallet_id: receiverWallet.wallet_id }, transaction });
      const recTxn = await Transaction_default.create({
        wallet_id: receiverWallet.wallet_id,
        user_id: receiverRole === "USER" ? receiverId : null,
        staff_id: receiverRole === "STAFF" ? receiverId : null,
        owner_id: null,
        username: receiverWallet.username,
        type: "DEPOSIT",
        amount: dep,
        previous_balance: recInrBefore,
        new_balance: recInrAfter,
        balance: recInrAfter,
        credit: receiverWallet.username,
        debit: senderWallet.username,
        initiated_by: initiatedBy
      }, { transaction });
      const recAllPointBefore = Math.round(parseFloat(receiverWallet.all_point || 0) * 100) / 100;
      const recAllPointAfter = Math.round((recAllPointBefore + dep) * 100) / 100;
      await PointLedger_default.create({
        entry_ref: pointEntryRef.deposit(recTxn.id),
        event_type: POINT_EVENT.CREDIT,
        wallet_id: receiverWallet.wallet_id,
        username: receiverWallet.username,
        settled_with_wallet_id: senderWallet.wallet_id,
        delta: dep,
        all_point_after: recAllPointAfter,
        closing_inr_balance: Math.round((parseFloat(receiverWallet.inr_balance || 0) + dep) * 100) / 100,
        closing_inr_balance_parent: senderInrAfter,
        source_user_id: receiverRole === "USER" ? receiverId : null,
        remark: `${remark}#${senderWallet.username}/${receiverWallet.username}`
      }, { transaction });
      const recCredit = Math.round((parseFloat(receiverWallet.credit || 0) + dep) * 100) / 100;
      const emitData = { inr_balance: recInrAfter, credit: recCredit };
      if (receiverRole === "USER") emitData.cash = Math.round((parseFloat(receiverWallet.cash || 0) + dep) * 100) / 100;
      emitBalanceUpdate(receiverId, emitData);
      return {
        receiver: receiverWallet.username,
        receiver_type: receiverRole,
        amount: dep,
        receiver_inr_after: recInrAfter,
        sender: senderWallet.username,
        sender_inr_after: senderInrAfter,
        sender_charged: deduct
      };
    } catch (e) {
      console.error("\u274C addDeposit error:", e);
      throw e;
    }
  },
  // This is the new api for withdraw from child
  withdrawFromChild: async (childId, amount, userType, transaction, initiatedBy, actorId, actorType, remark = "") => {
    if (!childId || !userType) throw new Error("childId and userType required");
    if (!actorId || !actorType) throw new Error("actor info not found");
    try {
      const actorRole = actorType.toUpperCase();
      if (actorRole !== "OWNER" && actorRole !== "STAFF") {
        throw new Error("Only owner or staff can withdraw");
      }
      const wd = Math.round(parseFloat(amount) * 100) / 100;
      if (isNaN(wd) || wd <= 0) throw new Error("amount must be greater than 0");
      const childRole = userType.toUpperCase() === "USER" ? "USER" : "STAFF";
      let child, parentStaff, parentOwner;
      if (childRole === "USER") {
        child = await User_default.findByPk(childId, { transaction });
        if (!child) throw new Error(`User ${childId} not found`);
        parentStaff = child.parent_staff_id;
        parentOwner = child.parent_owner_id;
      } else {
        child = await Staff_default.findByPk(childId, { transaction });
        if (!child) throw new Error(`Staff ${childId} not found`);
        parentStaff = child.parent_id;
        parentOwner = child.parent_owner_id;
      }
      let isDirect = false;
      if (actorRole === "OWNER") {
        isDirect = !parentStaff && Number(parentOwner) === Number(actorId);
      } else {
        isDirect = Number(parentStaff) === Number(actorId);
      }
      if (!isDirect) {
        throw new Error(`${child.username} is not your direct child, withdrawal not allowed`);
      }
      const childWallet = await Wallet_default.findOne({
        where: childRole === "USER" ? { user_id: childId, user_type: "USER" } : { staff_id: childId },
        transaction,
        lock: transaction.LOCK.UPDATE
      });
      if (!childWallet) throw new Error("Child wallet not found");
      const actorWallet = await Wallet_default.findOne({
        where: actorRole === "OWNER" ? { owner_id: actorId, user_type: "OWNER" } : { staff_id: actorId },
        transaction
      });
      if (!actorWallet) throw new Error("Parent wallet not found");
      const mainCol = childRole === "USER" ? "cash" : "inr_balance";
      const childMainBefore = Math.round(parseFloat(childWallet[mainCol] || 0) * 100) / 100;
      const childMainAfter = Math.round((childMainBefore - wd) * 100) / 100;
      if (childMainBefore < wd) {
        throw new Error(MESSAGES.ADMIN.USERS.WITHDRAW_INSUFFICIENT_BALANCE(childMainBefore));
      }
      const dec = { inr_balance: -wd, credit: -wd, all_point: -wd };
      if (childRole === "USER") dec.cash = -wd;
      await Wallet_default.increment(dec, { where: { wallet_id: childWallet.wallet_id }, transaction });
      const childTxn = await Transaction_default.create({
        wallet_id: childWallet.wallet_id,
        user_id: childRole === "USER" ? childId : null,
        staff_id: childRole === "STAFF" ? childId : null,
        owner_id: null,
        username: childWallet.username,
        type: "WITHDRAWAL",
        amount: wd,
        previous_balance: childMainBefore,
        new_balance: childMainAfter,
        balance: childMainAfter,
        credit: actorWallet.username,
        debit: childWallet.username,
        initiated_by: initiatedBy
      }, { transaction });
      const childAllPointBefore = Math.round(parseFloat(childWallet.all_point || 0) * 100) / 100;
      const childAllPointAfter = Math.round((childAllPointBefore - wd) * 100) / 100;
      await PointLedger_default.create({
        entry_ref: pointEntryRef.withdraw(childTxn.id),
        event_type: POINT_EVENT.DEBIT,
        wallet_id: childWallet.wallet_id,
        username: childWallet.username,
        settled_with_wallet_id: actorWallet.wallet_id,
        delta: -wd,
        all_point_after: childAllPointAfter,
        closing_inr_balance: Math.round((parseFloat(childWallet.inr_balance || 0) - wd) * 100) / 100,
        closing_inr_balance_parent: Math.round((parseFloat(actorWallet.inr_balance || 0) + wd) * 100) / 100,
        source_user_id: childRole === "USER" ? childId : null,
        remark: `${remark}#${childWallet.username}/${actorWallet.username}`
      }, { transaction });
      const actorInrBefore = Math.round(parseFloat(actorWallet.inr_balance || 0) * 100) / 100;
      const actorInrAfter = Math.round((actorInrBefore + wd) * 100) / 100;
      await Wallet_default.increment({ inr_balance: wd }, { where: { wallet_id: actorWallet.wallet_id }, transaction });
      await Transaction_default.create({
        wallet_id: actorWallet.wallet_id,
        user_id: null,
        staff_id: actorRole === "STAFF" ? actorId : null,
        owner_id: actorRole === "OWNER" ? actorId : null,
        username: actorWallet.username,
        type: "WITHDRAWAL",
        amount: wd,
        previous_balance: actorInrBefore,
        new_balance: actorInrAfter,
        balance: actorInrAfter,
        credit: actorWallet.username,
        debit: childWallet.username,
        initiated_by: initiatedBy
      }, { transaction });
      const childCredit = Math.round((parseFloat(childWallet.credit || 0) - wd) * 100) / 100;
      const childInr = Math.round((parseFloat(childWallet.inr_balance || 0) - wd) * 100) / 100;
      const childEmit = { inr_balance: childInr, credit: childCredit, all_point: childAllPointAfter };
      if (childRole === "USER") childEmit.cash = Math.round((parseFloat(childWallet.cash || 0) - wd) * 100) / 100;
      emitBalanceUpdate(childId, childEmit);
      emitBalanceUpdate(actorId, { inr_balance: actorInrAfter });
      return {
        child: childWallet.username,
        child_type: childRole,
        amount: wd,
        child_main_after: childMainAfter,
        child_all_point_after: childAllPointAfter,
        parent: actorWallet.username,
        parent_inr_after: actorInrAfter
      };
    } catch (e) {
      console.error("\u274C withdrawFromChild error:", e);
      throw e;
    }
  },
  // -----------------------------------------------------------------------
  // SUBTRACT CASH (user → staff/admin)
  // -----------------------------------------------------------------------
  //This is old Api and not recommended to use in tenexch
  subtractCash: async (senderId, amount, senderType, transaction, initiatedBy, receiverId, receiverType) => {
    try {
      const idField = WalletService.getWalletQueryField(senderType);
      const wallet = await Wallet_default.findOne({ where: { [idField]: senderId }, transaction });
      if (!wallet) throw new Error("Wallet not found");
      const prevCash = parseFloat(wallet.cash || 0);
      if (prevCash < parseFloat(amount)) throw new Error("Insufficient cash");
      const prevInr = parseFloat(wallet.inr_balance || 0);
      wallet.cash = prevCash - parseFloat(amount);
      wallet.inr_balance = prevInr - parseFloat(amount);
      await wallet.save({ transaction });
      let { userId: s_userId, staffId: s_staffId, ownerId: s_ownerId } = await WalletService.getHierarchyIds(senderId, senderType);
      if (receiverType && receiverType.toUpperCase() === "OWNER" && senderType && senderType.toUpperCase() === "USER") {
        s_staffId = null;
        if (!s_ownerId) s_ownerId = receiverId;
      }
      await Transaction_default.create({
        wallet_id: wallet.wallet_id,
        user_id: s_userId,
        staff_id: s_staffId,
        owner_id: s_ownerId,
        username: wallet.username,
        type: "SUBTRACT_CASH",
        amount: parseFloat(amount),
        previous_balance: prevCash,
        new_balance: wallet.cash,
        balance: wallet.inr_balance,
        credit: initiatedBy,
        debit: wallet.username,
        initiated_by: initiatedBy
      }, { transaction });
      emitBalanceUpdate(senderId, { cash: wallet.cash, inr_balance: wallet.inr_balance });
      if (receiverId && receiverType) {
        const receiverField = WalletService.getWalletQueryField(receiverType);
        const receiverWallet = await Wallet_default.findOne({
          where: { [receiverField]: receiverId },
          transaction,
          lock: transaction.LOCK.UPDATE
        });
        if (receiverWallet) {
          const rPrevCash = parseFloat(receiverWallet.cash || 0);
          const rPrevInr = parseFloat(receiverWallet.inr_balance || 0);
          receiverWallet.cash = rPrevCash + parseFloat(amount);
          receiverWallet.inr_balance = rPrevInr + parseFloat(amount);
          await receiverWallet.save({ transaction });
          const { userId: r_userId, staffId: r_staffId, ownerId: r_ownerId } = await WalletService.getHierarchyIds(receiverId, receiverType);
          await Transaction_default.create({
            wallet_id: receiverWallet.wallet_id,
            user_id: r_userId,
            staff_id: r_staffId,
            owner_id: r_ownerId,
            username: receiverWallet.username,
            type: "COLLECT_CASH",
            amount: parseFloat(amount),
            previous_balance: rPrevCash,
            new_balance: receiverWallet.cash,
            balance: receiverWallet.inr_balance,
            credit: receiverWallet.username,
            debit: wallet.username,
            initiated_by: initiatedBy
          }, { transaction });
          emitBalanceUpdate(receiverId, { cash: receiverWallet.cash, inr_balance: receiverWallet.inr_balance });
        }
      }
      return wallet;
    } catch (e) {
      console.error("\u274C subtractCash error:", e);
      throw e;
    }
  },
  updateAllPointHierarchy: async (betId, betType) => {
    if (!betId) return { success: false, error: "betId is required" };
    const category = (betType || "").toString().toUpperCase();
    if (!Object.values(POINT_CATEGORY).includes(category)) {
      return { success: false, error: `invalid betType "${betType}" \u2014 SPORTS chahiye` };
    }
    let gtype = null;
    const ledgerCategories = LEDGER_CATEGORY_ALIASES[category] || [category];
    let credit = await CreditsLedger_default.findOne({
      where: {
        bet_id: betId,
        category: { [Op7.in]: ledgerCategories },
        [Op7.or]: [{ profit: { [Op7.ne]: null } }, { loss: { [Op7.ne]: null } }]
      },
      order: [["id", "ASC"]]
    });
    if (!credit) return { success: false, error: `credits_ledger entry not found for ${category} bet ${betId}` };
    if (credit?.points_applied) {
      return { success: true, duplicate: true, reason: `bet ${betId} ke points pehle hi lag chuke hain` };
    }
    const net = Math.round((parseFloat(credit.profit || 0) + parseFloat(credit.loss || 0)) * 100) / 100;
    if (net === 0) {
      await credit.update({ points_applied: true });
      return { success: true, skipped: true, reason: `bet ${betId} ka net 0 hai` };
    }
    const outcome = net > 0 ? "won" : "loss";
    const userId = Number(credit.user_id);
    const entryRef = pointEntryRef.bet(category, betId);
    if (category === POINT_CATEGORY.SPORTS) {
      const sportsBet = await SportsBet_default.findByPk(betId, { attributes: ["gtype"] });
      gtype = sportsBet?.gtype || null;
    }
    if (!gtype) gtype = credit?.market_type || credit?.meta?.market_type || null;
    const tx = await db_default.transaction();
    try {
      const user = await User_default.findByPk(userId, { transaction: tx });
      if (!user) throw new Error(`user ${userId} not found`);
      if (user.is_demo) {
        await credit.update({ points_applied: true }, { transaction: tx });
        await tx.commit();
        return { success: true, skipped: true, reason: `bet ${betId} belongs to demo user ${userId} \u2014 points not rolled up` };
      }
      const staffIds = [];
      let ownerId = user.parent_owner_id || null;
      let staffId = user.parent_staff_id;
      const visited = /* @__PURE__ */ new Set();
      while (staffId) {
        if (visited.has(staffId)) break;
        visited.add(staffId);
        const staff = await Staff_default.findByPk(staffId, { transaction: tx });
        if (!staff) throw new Error(`staff ${staffId} not found (user ${userId} ki hierarchy)`);
        staffIds.push(staff.staff_id);
        if (staff.parent_owner_id) ownerId = staff.parent_owner_id;
        staffId = staff.parent_id;
      }
      const wallets = [];
      const userWallet = await Wallet_default.findOne({ where: { user_id: userId, user_type: "USER" }, transaction: tx });
      if (!userWallet) throw new Error(`wallet not found for user ${userId}`);
      wallets.push(userWallet);
      for (const id of staffIds) {
        const staffWallet = await Wallet_default.findOne({ where: { staff_id: id }, transaction: tx });
        if (!staffWallet) throw new Error(`wallet not found for staff ${id}`);
        wallets.push(staffWallet);
      }
      if (ownerId) {
        const ownerWallet = await Wallet_default.findOne({ where: { owner_id: ownerId, user_type: "OWNER" }, transaction: tx });
        if (!ownerWallet) throw new Error(`wallet not found for owner ${ownerId}`);
        wallets.push(ownerWallet);
      }
      const walletIds = wallets.map((w) => w.wallet_id);
      const categoryColumn = {
        SPORTS: "sports_pts"
      }[category];
      const incFields = { all_point: net };
      if (categoryColumn) incFields[categoryColumn] = net;
      await Wallet_default.increment(incFields, { where: { wallet_id: walletIds }, transaction: tx });
      const updated = await Wallet_default.findAll({
        where: { wallet_id: walletIds },
        attributes: ["wallet_id", "user_id", "staff_id", "owner_id", "username", "all_point", "inr_balance"],
        transaction: tx
      });
      await PointLedger_default.bulkCreate(
        updated.map((w) => ({
          entry_ref: entryRef,
          event_type: POINT_EVENT.BET_SETTLEMENT,
          category,
          bet_id: betId,
          wallet_id: w.wallet_id,
          username: w.username,
          delta: net,
          all_point_after: parseFloat(w?.all_point || 0),
          closing_inr_balance: parseFloat(w?.inr_balance || 0),
          sport_id: credit?.sport_id || null,
          game_type: gtype,
          source_user_id: userId,
          remark: credit?.description
        })),
        { transaction: tx }
      );
      await credit.update({ points_applied: true }, { transaction: tx });
      await tx.commit();
      for (const w of updated) {
        const entityId = w.user_id || w.staff_id || w.owner_id;
        if (entityId) {
          emitBalanceUpdate(entityId, { all_point: parseFloat(w.all_point || 0) });
        }
      }
      return {
        success: true,
        status: outcome,
        point: Math.abs(net),
        entry_ref: entryRef,
        wallets_updated: wallets.length,
        usernames: wallets.map((w) => w.username)
      };
    } catch (err) {
      await tx.rollback();
      return { success: false, error: err.message };
    }
  },
  /**
   * updateAllPointHierarchy ka ulta — jab ek settle ho chuki bet ko void kiya
   * jaata hai to us settlement se lage all_point/category points wapas lene
   * hote hain (poori chain me: user → staff → owner).
   *
   * Original `settle:bet:*` PointLedger entry kabhi delete nahi hoti; uske
   * saamne `reverse:bet:*` entries banti hain (POINT_EVENT.REVERSAL) —
   * (wallet_id, entry_ref) unique index dobara reverse hone se rokta hai.
   * PointLedger entry likhna zaroori hai: bina ledger ke all_point change ko
   * integrity cron tampering samajh ke revert kar deta hai.
   *
   * @param {number} betId
   * @param {string} betType POINT_CATEGORY ka koi value
   */
  reverseAllPointHierarchy: async (betId, betType) => {
    if (!betId) return { success: false, error: "betId is required" };
    const category = (betType || "").toString().toUpperCase();
    if (!Object.values(POINT_CATEGORY).includes(category)) {
      return { success: false, error: `invalid betType "${betType}" \u2014 SPORTS chahiye` };
    }
    const credit = await CreditsLedger_default.findOne({
      where: {
        bet_id: betId,
        category: { [Op7.in]: LEDGER_CATEGORY_ALIASES[category] || [category] },
        [Op7.or]: [{ profit: { [Op7.ne]: null } }, { loss: { [Op7.ne]: null } }]
      },
      order: [["id", "ASC"]]
    });
    if (!credit) return { success: true, skipped: true, reason: `credits_ledger entry not found for ${category} bet ${betId}` };
    if (!credit.points_applied) return { success: true, skipped: true, reason: `bet ${betId} ke points kabhi apply hi nahi hue` };
    const net = Math.round((parseFloat(credit.profit || 0) + parseFloat(credit.loss || 0)) * 100) / 100;
    if (net === 0) return { success: true, skipped: true, reason: `bet ${betId} ka net 0 hai` };
    const delta = -net;
    const userId = Number(credit.user_id);
    const entryRef = pointEntryRef.betReversal(category, betId);
    const tx = await db_default.transaction();
    try {
      const user = await User_default.findByPk(userId, { transaction: tx });
      if (!user) throw new Error(`user ${userId} not found`);
      const staffIds = [];
      let ownerId = user.parent_owner_id || null;
      let staffId = user.parent_staff_id;
      const visited = /* @__PURE__ */ new Set();
      while (staffId) {
        if (visited.has(staffId)) break;
        visited.add(staffId);
        const staff = await Staff_default.findByPk(staffId, { transaction: tx });
        if (!staff) throw new Error(`staff ${staffId} not found (user ${userId} ki hierarchy)`);
        staffIds.push(staff.staff_id);
        if (staff.parent_owner_id) ownerId = staff.parent_owner_id;
        staffId = staff.parent_id;
      }
      const wallets = [];
      const userWallet = await Wallet_default.findOne({ where: { user_id: userId, user_type: "USER" }, transaction: tx });
      if (!userWallet) throw new Error(`wallet not found for user ${userId}`);
      wallets.push(userWallet);
      for (const id of staffIds) {
        const staffWallet = await Wallet_default.findOne({ where: { staff_id: id }, transaction: tx });
        if (!staffWallet) throw new Error(`wallet not found for staff ${id}`);
        wallets.push(staffWallet);
      }
      if (ownerId) {
        const ownerWallet = await Wallet_default.findOne({ where: { owner_id: ownerId, user_type: "OWNER" }, transaction: tx });
        if (!ownerWallet) throw new Error(`wallet not found for owner ${ownerId}`);
        wallets.push(ownerWallet);
      }
      const walletIds = wallets.map((w) => w.wallet_id);
      const categoryColumn = {
        SPORTS: "sports_pts"
      }[category];
      const incFields = { all_point: delta };
      if (categoryColumn) incFields[categoryColumn] = delta;
      await Wallet_default.increment(incFields, { where: { wallet_id: walletIds }, transaction: tx });
      const updated = await Wallet_default.findAll({
        where: { wallet_id: walletIds },
        attributes: ["wallet_id", "user_id", "staff_id", "owner_id", "username", "all_point", "inr_balance"],
        transaction: tx
      });
      await PointLedger_default.bulkCreate(
        updated.map((w) => ({
          entry_ref: entryRef,
          event_type: POINT_EVENT.REVERSAL,
          category,
          bet_id: betId,
          wallet_id: w.wallet_id,
          username: w.username,
          delta,
          all_point_after: parseFloat(w?.all_point || 0),
          closing_inr_balance: parseFloat(w?.inr_balance || 0),
          sport_id: credit?.sport_id || null,
          game_type: credit?.market_type || null,
          source_user_id: userId,
          remark: withVoidSuffix(credit?.description || "")
        })),
        { transaction: tx }
      );
      await tx.commit();
      for (const w of updated) {
        const entityId = w.user_id || w.staff_id || w.owner_id;
        if (entityId) emitBalanceUpdate(entityId, { all_point: parseFloat(w.all_point || 0) });
      }
      return { success: true, point: Math.abs(delta), entry_ref: entryRef, wallets_updated: wallets.length };
    } catch (err) {
      await tx.rollback();
      return { success: false, error: err.message };
    }
  },
  // ── Silent void: settlement ke point rows MITA do ──────────────────────────
  // Admin ke "Create statement entry" switch ka OFF wala raasta. Ulti entry
  // likhne ke bajaye ASLI entry hi hata di jaati hai, taaki statement me aisa
  // lage jaise settlement kabhi hui hi nahi.
  //
  // Har deleted row ke liye teen kaam, usi wallet par:
  //   1. wallet.all_point (+ category pts) me se us row ka delta ghatao
  //   2. us wallet ki BAAD wali rows ke snapshots peeche khisakao —
  //      all_point_after hamesha, aur closing_inr_balance SIRF player ki apni
  //      wallet par (settlement ne upline ka inr_balance chhua hi nahi tha,
  //      sirf points chale the)
  //   3. row delete
  //
  // (2) ke bina statement ka "pts" column poora hi jhooth bol deta: baad ki
  // saari rows jeet wala balance dikhati rehti hain aur aakhri line asli wallet
  // se match nahi karti. Aur (1) ke saath all_point = SUM(point_ledger.delta)
  // barabar bana rehta hai — system tracker ka tier-1 check wahi dekhta hai.
  deletePointEntries: async (entryRef) => {
    if (!entryRef) return { success: false, error: "entryRef is required" };
    const tx = await db_default.transaction();
    try {
      const rows = await PointLedger_default.findAll({
        where: { entry_ref: entryRef },
        order: [["id", "ASC"]],
        transaction: tx,
        lock: tx.LOCK.UPDATE
      });
      if (!rows.length) {
        await tx.commit();
        return { success: true, skipped: true, reason: `${entryRef} ki koi entry nahi mili` };
      }
      const touched = [];
      for (const r of rows) {
        const delta = Math.round((parseFloat(r.delta) || 0) * 100) / 100;
        const wallet = await Wallet_default.findOne({
          where: { wallet_id: r.wallet_id },
          transaction: tx,
          lock: tx.LOCK.UPDATE
        });
        if (!wallet) throw new Error(`wallet ${r.wallet_id} not found (${entryRef})`);
        const categoryColumn = {
          SPORTS: "sports_pts"
        }[String(r.category || "").toUpperCase()];
        const decFields = { all_point: -delta };
        if (categoryColumn) decFields[categoryColumn] = -delta;
        await Wallet_default.increment(decFields, { where: { wallet_id: r.wallet_id }, transaction: tx });
        await db_default.query(
          `UPDATE point_ledger SET all_point_after = all_point_after - :d
            WHERE wallet_id = :w AND id > :id AND all_point_after IS NOT NULL`,
          { replacements: { d: delta, w: r.wallet_id, id: r.id }, transaction: tx }
        );
        if (wallet.user_id != null) {
          await db_default.query(
            `UPDATE point_ledger SET closing_inr_balance = closing_inr_balance - :d
              WHERE wallet_id = :w AND id > :id AND closing_inr_balance IS NOT NULL`,
            { replacements: { d: delta, w: r.wallet_id, id: r.id }, transaction: tx }
          );
        }
        await r.destroy({ transaction: tx });
        touched.push(r.wallet_id);
      }
      await tx.commit();
      for (const walletId of touched) {
        const w = await Wallet_default.findOne({
          where: { wallet_id: walletId },
          attributes: ["wallet_id", "user_id", "staff_id", "owner_id", "all_point"],
          raw: true
        });
        const entityId = w?.user_id || w?.staff_id || w?.owner_id;
        if (entityId) emitBalanceUpdate(entityId, { all_point: parseFloat(w.all_point || 0) });
      }
      return { success: true, deleted: rows.length, entry_ref: entryRef };
    } catch (err) {
      await tx.rollback();
      return { success: false, error: err.message };
    }
  },
  // ── Sports win commission → points chain ────────────────────────────────
  // Settlement ke baad alag movement: user ne `amount` commission di. Wahi
  // hierarchy walk jo updateAllPointHierarchy karta hai (user → staff chain →
  // owner), delta = -amount har wallet par, event_type COMMISSION, ek row per
  // wallet — isi row se user ke statement me "…- Comm" line dikhti hai aur
  // all_point = SUM(point_ledger) bana rehta hai.
  // Plan: docs/plans/2026-09-09-sports-win-commission.md
  applyCommissionPoints: async ({ betId, userId, amount, remark, sportId, gtype }) => {
    const comm = Math.round((parseFloat(amount) || 0) * 100) / 100;
    if (!betId) return { success: false, error: "betId is required" };
    if (!(comm > 0)) return { success: true, skipped: true, reason: "commission is 0" };
    return WalletService._writeCommissionChain({
      betId,
      userId,
      delta: -comm,
      remark,
      sportId,
      gtype,
      eventType: POINT_EVENT.COMMISSION,
      entryRef: pointEntryRef.commission(POINT_CATEGORY.SPORTS, betId)
    });
  },
  // Settlement void ke saath commission bhi wapas — ulti entry, original kabhi delete nahi hoti.
  reverseCommissionPoints: async ({ betId, userId, amount, remark, sportId, gtype }) => {
    const comm = Math.round((parseFloat(amount) || 0) * 100) / 100;
    if (!betId) return { success: false, error: "betId is required" };
    if (!(comm > 0)) return { success: true, skipped: true, reason: "commission is 0" };
    return WalletService._writeCommissionChain({
      betId,
      userId,
      delta: comm,
      remark,
      sportId,
      gtype,
      eventType: POINT_EVENT.REVERSAL,
      entryRef: pointEntryRef.commissionReversal(POINT_CATEGORY.SPORTS, betId)
    });
  },
  _writeCommissionChain: async ({ betId, userId, delta, remark, sportId, gtype, eventType, entryRef }) => {
    const category = POINT_CATEGORY.SPORTS;
    const tx = await db_default.transaction();
    try {
      const user = await User_default.findByPk(userId, { transaction: tx });
      if (!user) throw new Error(`user ${userId} not found`);
      if (user.is_demo) {
        await tx.commit();
        return { success: true, skipped: true, reason: `bet ${betId} belongs to demo user ${userId} \u2014 commission points not rolled up` };
      }
      const already = await PointLedger_default.findOne({ where: { entry_ref: entryRef }, attributes: ["id"], transaction: tx });
      if (already) {
        await tx.commit();
        return { success: true, duplicate: true, reason: `${entryRef} already written` };
      }
      const staffIds = [];
      let ownerId = user.parent_owner_id || null;
      let staffId = user.parent_staff_id;
      const visited = /* @__PURE__ */ new Set();
      while (staffId) {
        if (visited.has(staffId)) break;
        visited.add(staffId);
        const staff = await Staff_default.findByPk(staffId, { transaction: tx });
        if (!staff) throw new Error(`staff ${staffId} not found (user ${userId} ki hierarchy)`);
        staffIds.push(staff.staff_id);
        if (staff.parent_owner_id) ownerId = staff.parent_owner_id;
        staffId = staff.parent_id;
      }
      const wallets = [];
      const userWallet = await Wallet_default.findOne({ where: { user_id: userId, user_type: "USER" }, transaction: tx });
      if (!userWallet) throw new Error(`wallet not found for user ${userId}`);
      wallets.push(userWallet);
      for (const id of staffIds) {
        const staffWallet = await Wallet_default.findOne({ where: { staff_id: id }, transaction: tx });
        if (!staffWallet) throw new Error(`wallet not found for staff ${id}`);
        wallets.push(staffWallet);
      }
      if (ownerId) {
        const ownerWallet = await Wallet_default.findOne({ where: { owner_id: ownerId, user_type: "OWNER" }, transaction: tx });
        if (!ownerWallet) throw new Error(`wallet not found for owner ${ownerId}`);
        wallets.push(ownerWallet);
      }
      const walletIds = wallets.map((w) => w.wallet_id);
      await Wallet_default.increment({ all_point: delta, sports_pts: delta }, { where: { wallet_id: walletIds }, transaction: tx });
      const updated = await Wallet_default.findAll({
        where: { wallet_id: walletIds },
        attributes: ["wallet_id", "user_id", "staff_id", "owner_id", "username", "all_point", "inr_balance"],
        transaction: tx
      });
      await PointLedger_default.bulkCreate(
        updated.map((w) => ({
          entry_ref: entryRef,
          event_type: eventType,
          category,
          bet_id: betId,
          wallet_id: w.wallet_id,
          username: w.username,
          delta,
          all_point_after: parseFloat(w?.all_point || 0),
          closing_inr_balance: parseFloat(w?.inr_balance || 0),
          sport_id: sportId || null,
          game_type: gtype || null,
          source_user_id: userId,
          remark: String(remark || "").slice(0, 255)
        })),
        { transaction: tx }
      );
      await tx.commit();
      for (const w of updated) {
        const entityId = w.user_id || w.staff_id || w.owner_id;
        if (entityId) emitBalanceUpdate(entityId, { all_point: parseFloat(w.all_point || 0) });
      }
      return { success: true, point: Math.abs(delta), entry_ref: entryRef, wallets_updated: wallets.length };
    } catch (err) {
      await tx.rollback();
      return { success: false, error: err.message };
    }
  },
  settlePointsFromChild: async (userId, username, points, actorId, actorType, initiatedBy, remark) => {
    const actorRole = actorType ? actorType.toUpperCase() : "";
    if (actorRole !== "OWNER" && actorRole !== "STAFF") {
      return { success: false, error: "Only owner or staff can do settlement" };
    }
    if (!userId || !username) return { success: false, error: "userId and username are required" };
    if (!actorId) return { success: false, error: "Settling account id not found" };
    const delta = Math.round(parseFloat(points) * 100) / 100;
    if (isNaN(delta)) return { success: false, error: `Invalid points value "${points}"` };
    if (delta === 0) return { success: false, error: "points cannot be 0" };
    const tx = await db_default.transaction();
    try {
      const actorWhere = actorRole === "OWNER" ? { owner_id: actorId, user_type: "OWNER" } : { staff_id: actorId };
      const actorWallet = await Wallet_default.findOne({ where: actorWhere, transaction: tx, lock: tx.LOCK.UPDATE });
      if (!actorWallet) throw new Error(`Wallet not found for ${actorRole} ${actorId}`);
      const user = await User_default.findByPk(userId, { transaction: tx });
      const staff = await Staff_default.findByPk(userId, { transaction: tx });
      let child = null;
      if (user && user.username === username) {
        child = {
          isUser: true,
          id: user.user_id,
          username: user.username,
          parentStaff: user.parent_staff_id,
          parentOwner: user.parent_owner_id
        };
      } else if (staff && staff.username === username) {
        child = {
          isUser: false,
          id: staff.staff_id,
          username: staff.username,
          parentStaff: staff.parent_id,
          parentOwner: staff.parent_owner_id
        };
      }
      if (!child) throw new Error(`${username} (id ${userId}) not found`);
      let isDirect = false;
      if (actorRole === "OWNER") {
        isDirect = !child.parentStaff && Number(child.parentOwner) === Number(actorId);
      } else {
        isDirect = Number(child.parentStaff) === Number(actorId);
      }
      if (!isDirect) {
        throw new Error(`${child.username} is not your direct child, settlement not allowed`);
      }
      const childWhere = child.isUser ? { user_id: child.id, user_type: "USER" } : { staff_id: child.id };
      const childWallet = await Wallet_default.findOne({
        where: childWhere,
        transaction: tx,
        lock: tx.LOCK.UPDATE
      });
      if (!childWallet) throw new Error(`Wallet not found for ${child.username}`);
      if (childWallet.wallet_id === actorWallet.wallet_id) {
        throw new Error("Cannot settle with your own account");
      }
      const sumRow = await PointLedger_default.findOne({
        where: { wallet_id: childWallet.wallet_id },
        attributes: [[db_default.fn("SUM", db_default.col("delta")), "total"]],
        raw: true,
        transaction: tx
      });
      const ledgerPoint = Math.round(parseFloat(sumRow.total || 0) * 100) / 100;
      const counter = Math.round(parseFloat(childWallet.all_point || 0) * 100) / 100;
      const credit = Math.round(parseFloat(childWallet.credit || 0) * 100) / 100;
      const pending = Math.round((ledgerPoint - credit) * 100) / 100;
      if (counter !== ledgerPoint) {
        throw new Error(`${child.username} all_point does not match ledger (wallet ${counter}, ledger ${ledgerPoint}), settlement blocked`);
      }
      if (pending === 0) throw new Error(`${child.username} has no pending settlement`);
      if (pending > 0 && delta > 0 || pending < 0 && delta < 0 || Math.abs(delta) > Math.abs(pending)) {
        throw new Error(`Amount Greater than P/L`);
      }
      const newAllPoint = Math.round((counter + delta) * 100) / 100;
      const taking = delta < 0;
      const childMainCol = child.isUser ? "cash" : "inr_balance";
      const childMainBefore = Math.round(parseFloat(childWallet[childMainCol] || 0) * 100) / 100;
      const childMainAfter = Math.round((childMainBefore + delta) * 100) / 100;
      const actorInrBefore = Math.round(parseFloat(actorWallet.inr_balance || 0) * 100) / 100;
      if (taking && childMainBefore < Math.abs(delta)) {
        throw new Error(`${child.username} has only ${childMainBefore} ${child.isUser ? "cash" : "INR"}, cannot take ${Math.abs(delta)}`);
      }
      if (!taking && actorInrBefore < delta) {
        throw new Error(`${actorWallet.username} has only ${actorInrBefore} INR, cannot pay ${delta}`);
      }
      const actorInrAfter = Math.round((actorInrBefore - delta) * 100) / 100;
      const creditName = taking ? actorWallet.username : child.username;
      const debitName = taking ? child.username : actorWallet.username;
      const txnRow = await Transaction_default.create({
        wallet_id: childWallet.wallet_id,
        user_id: child.isUser ? child.id : null,
        staff_id: child.isUser ? null : child.id,
        owner_id: null,
        username: child.username,
        type: "POINT_SETTLEMENT",
        amount: Math.abs(delta),
        previous_balance: childMainBefore,
        new_balance: childMainAfter,
        balance: childMainAfter,
        credit: creditName,
        debit: debitName,
        initiated_by: initiatedBy || actorWallet.username
      }, { transaction: tx });
      await Transaction_default.create({
        wallet_id: actorWallet.wallet_id,
        user_id: null,
        staff_id: actorRole === "STAFF" ? actorId : null,
        owner_id: actorRole === "OWNER" ? actorId : null,
        username: actorWallet.username,
        type: "POINT_SETTLEMENT",
        amount: Math.abs(delta),
        previous_balance: actorInrBefore,
        new_balance: actorInrAfter,
        balance: actorInrAfter,
        credit: creditName,
        debit: debitName,
        initiated_by: initiatedBy || actorWallet.username
      }, { transaction: tx });
      const entryRef = pointEntryRef.cashSettle(txnRow.id);
      const childInc = { all_point: delta, upper_point: delta, inr_balance: delta };
      if (child.isUser) childInc.cash = delta;
      await Wallet_default.increment(childInc, { where: { wallet_id: childWallet.wallet_id }, transaction: tx });
      await Wallet_default.increment(
        { down_point: -delta, inr_balance: -delta },
        { where: { wallet_id: actorWallet.wallet_id }, transaction: tx }
      );
      remark = remark ? remark : delta > 0 ? POINT_EVENT.BANK_DEPOSIT : POINT_EVENT.BANK_WITHDRAW;
      await PointLedger_default.create({
        entry_ref: entryRef,
        event_type: delta > 0 ? POINT_EVENT.BANK_DEPOSIT : POINT_EVENT.BANK_WITHDRAW,
        wallet_id: childWallet.wallet_id,
        username: child.username,
        settled_with_wallet_id: actorWallet.wallet_id,
        delta,
        all_point_after: newAllPoint,
        closing_inr_balance: Math.round((parseFloat(childWallet.inr_balance || 0) + delta) * 100) / 100,
        closing_inr_balance_parent: actorInrAfter,
        source_user_id: child.isUser ? child.id : null,
        remark: `${remark}#${taking ? `${child.username}/${actorWallet.username}` : `${actorWallet.username}/${child.username}`}`
      }, { transaction: tx });
      await tx.commit();
      emitBalanceUpdate(child.id, { all_point: newAllPoint });
      const pendingAfter = Math.round((pending + delta) * 100) / 100;
      return {
        success: true,
        all_point_after: newAllPoint
      };
    } catch (err) {
      await tx.rollback();
      console.error("\u274C settlePointsFromChild error:", err.message);
      return { success: false, error: err.message };
    }
  },
  // -----------------------------------------------------------------------
  // ADD CREDIT → OWNER gets it for FREE
  // -----------------------------------------------------------------------
  // -----------------------------------------------------------------------
  // GET USER WALLET
  // -----------------------------------------------------------------------
  getUserWallet: async (entityId, userType) => {
    const idField = WalletService.getWalletQueryField(userType);
    const w = await Wallet_default.findOne({ where: { [idField]: entityId, user_type: userType } });
    if (!w) throw new Error("Wallet not found");
    return {
      username: w.username,
      user_type: w.user_type,
      cash: parseFloat(w.cash || 0),
      inr_balance: parseFloat(w.inr_balance || 0),
      cash_received: parseFloat(w.cash_received || 0)
    };
  },
  // -----------------------------------------------------------------------
  // Optional: Get all wallets, by role, etc.
  // -----------------------------------------------------------------------
  getAllWallets: async () => await Wallet_default.findAll(),
  getWalletsByRole: async (role) => await Wallet_default.findAll({ where: { user_type: role.toUpperCase() } })
};
var walletService_default = WalletService;

// socket/socketHandler.js
var BALANCE_INTERVAL_MS = 3e3;
var setupSocketHandlers = (io) => {
  io.on("connection", (socket) => {
    socket.on("authenticate", (data) => {
      const { userId, token } = data;
      if (userId) {
        socket.join(`user_${userId}`);
        socket.userId = userId;
      }
    });
    socket.on("getBalance", async (data) => {
      try {
        const token = socket.handshake.auth.token || data?.token;
        if (!token) {
          socket.emit("balanceUpdate", { error: "No token provided" });
          return;
        }
        const decoded = verifyToken(token);
        const userId = decoded.user_id;
        const userRole = (decoded.role || "USER").toUpperCase();
        const balance = await walletService_default.getUserWallet(userId, userRole);
        const total_exposure = await getUserTotalExposure(userId);
        const balanceData = {
          userId,
          balance: {
            inr_balance: balance.inr_balance,
            exposure: total_exposure !== null ? total_exposure : null
            // its total exposure of user of diffrent games combined
          },
          timestamp: (/* @__PURE__ */ new Date()).toISOString()
        };
        socket.emit("balanceUpdate", balanceData);
      } catch (err) {
        console.error("Error in getBalance socket event:", err);
        socket.emit("balanceUpdate", { error: "Failed to fetch balance", details: err.message });
      }
    });
    socket.on("subscribeBalance", async (data) => {
      try {
        const token = socket.handshake.auth.token || data?.token;
        if (!token) return;
        const decoded = verifyToken(token);
        const userId = decoded.user_id;
        const userRole = (decoded.role || "USER").toUpperCase();
        let inFlight = false;
        const tick = async () => {
          if (inFlight || !socket.connected) return;
          inFlight = true;
          try {
            const balance = await walletService_default.getUserWallet(userId, userRole);
            const total_exposure = await getUserTotalExposure(userId);
            if (!socket.connected) return;
            socket.emit("balanceUpdate", {
              userId,
              balance: {
                ...balance.inr_balance != null && { inr_balance: balance.inr_balance },
                ...total_exposure != null && { exposure: total_exposure }
              },
              timestamp: (/* @__PURE__ */ new Date()).toISOString()
            });
          } catch (err) {
            console.error("Error in balance tick:", err.message);
          } finally {
            inFlight = false;
          }
        };
        if (socket.balanceTimer) clearInterval(socket.balanceTimer);
        await tick();
        socket.balanceTimer = setInterval(tick, BALANCE_INTERVAL_MS);
      } catch (err) {
        console.error("Error in subscribeBalance socket event:", err.message);
      }
    });
    socket.on("unsubscribeBalance", () => {
      if (socket.balanceTimer) {
        clearInterval(socket.balanceTimer);
        socket.balanceTimer = null;
      }
    });
    socket.on("disconnect", () => {
      if (socket.balanceTimer) {
        clearInterval(socket.balanceTimer);
        socket.balanceTimer = null;
      }
    });
  });
  io.engine.on("connection_error", (err) => {
    console.error(
      "Socket.IO connection error:",
      err.code,
      err.message,
      err.context?.sid || ""
    );
  });
};

// core-entry.js
init_redisClient();
init_db();

// services/statement/StatementBuilder.js
import { Op as Op8 } from "sequelize";

// utils/sportsNames.js
var sportsDataSet2 = [
  { sid: 4, name: "Cricket", active: true },
  { sid: 1, name: "Football", active: true },
  { sid: 2, name: "Tennis", active: true },
  { sid: 8, name: "Table Tennis", active: true },
  { sid: 68, name: "Esoccer", active: true },
  { sid: 10, name: "Horse Racing", active: true },
  { sid: 65, name: "Greyhound Racing", active: true },
  { sid: 15, name: "Basketball", active: true },
  { sid: 69, name: "Wrestling", active: true },
  { sid: 18, name: "Volleyball", active: true },
  { sid: 22, name: "Badminton", active: true },
  { sid: 59, name: "Snooker", active: true },
  { sid: 57, name: "Darts", active: true },
  { sid: 6, name: "Boxing", active: true },
  { sid: 3, name: "Mixed Martial Arts", active: true },
  { sid: 58, name: "American Football", active: true },
  { sid: 11, name: "E Games", active: true },
  { sid: 19, name: "Ice Hockey", active: true },
  { sid: 9, name: "Futsal", active: true },
  { sid: 40, name: "Politics", active: true },
  { sid: 67, name: "Boat Racing", active: true },
  { sid: 52, name: "Motor Sports", active: true },
  { sid: 12, name: "Greyhounds", active: true },
  // not present in the upstream sports tree
  { sid: 66, name: "Kabaddi", active: true }
];
var nameBySid = new Map(sportsDataSet2.map((s) => [String(s.sid), s.name]));
var sidByName = new Map(sportsDataSet2.map((s) => [s.name.toLowerCase(), s.sid]));

// services/statement/StatementBuilder.js
var SPORT_NAMES = {
  ...Object.fromEntries(sportsDataSet2.map((s) => [String(s.sid), s.name])),
  "1": "Football",
  "2": "Tennis",
  "4": "Cricket",
  "7": "Horse Racing",
  "10": "Horse Racing",
  "65": "Greyhound Racing",
  "1477": "Kabaddi"
};
function sportsNet(b, ledgerNet = null) {
  const stake = parseFloat(b.stake_amount) || 0;
  const liab = parseFloat(b.liability) || 0;
  const odds = parseFloat(b.odds) || 0;
  const size = parseFloat(b.size) || 0;
  const bt = String(b.bet_type || "").toLowerCase();
  const gt = String(b.game_type || "").toUpperCase();
  const mt = String(b.market_type || "").toLowerCase();
  const res = String(b.result_status || "").toLowerCase();
  const isBack = bt === "back" || bt === "yes";
  const isLay = bt === "lay" || bt === "no";
  const netFromLedger = gt === "FAN" && (isMeterMarket(b.market_type) || isBadloBet(b) || mt === "oddeven" || mt === "fancy1");
  if (netFromLedger && ledgerNet != null && Number.isFinite(Number(ledgerNet))) {
    return Math.round(Number(ledgerNet) * 100) / 100;
  }
  let pl = 0;
  if (res === "won") {
    if (isBack) {
      if (gt === "BM") pl = stake * (odds / 100);
      else if (mt === "tied match") pl = stake * (odds / 100);
      else if (gt === "FAN") {
        if (mt === "fancy1") pl = stake;
        else if (isLineMarket(b.market_type)) pl = stake;
        else pl = size > 0 ? stake * (size / 100) : stake * (odds / 100);
      } else pl = stake * (odds - 1);
    } else if (isLay) {
      pl = stake;
    }
  } else if (res === "loss") {
    if (isBack) pl = -stake;
    else if (isLay) pl = -liab;
  }
  return pl;
}
async function loadFanSettlementNet(userId, bets) {
  const ids = (bets || []).filter((b) => String(b.game_type || "").toUpperCase() === "FAN").map((b) => b.id).filter((id) => id != null);
  if (!ids.length) return /* @__PURE__ */ new Map();
  const rows = await CreditsLedger_default.findAll({
    where: {
      ...userId != null ? { user_id: String(userId) } : {},
      reason: "settlement",
      bet_id: { [Op8.in]: ids },
      netamount: { [Op8.ne]: null }
    },
    attributes: ["id", "bet_id", "netamount"],
    order: [["id", "ASC"]],
    raw: true
  });
  const out = /* @__PURE__ */ new Map();
  for (const r of rows) {
    const k = String(r.bet_id);
    if (!out.has(k)) out.set(k, r.netamount);
  }
  return out;
}

// services/user/UserStatementService.js
import { Op as Op9 } from "sequelize";

// helper/naiveLocalTime.js
var toNaiveLocalTime = (value) => {
  if (!value) return null;
  const dt = new Date(value);
  if (Number.isNaN(dt.getTime())) return null;
  const p = (n) => String(n).padStart(2, "0");
  return `${dt.getFullYear()}-${p(dt.getMonth() + 1)}-${p(dt.getDate())} ${p(dt.getHours())}:${p(dt.getMinutes())}:${p(dt.getSeconds())}`;
};

// helper/fanMarketName.js
var isKhadoBet = (bet) => String(bet?.market_type || "").toLowerCase() === "khado";
var fanMarketName = (bet) => isKhadoBet(bet) ? bet?.selection_name || bet?.fancy_name || null : bet?.fancy_name || bet?.selection_name || null;

// services/user/UserStatementService.js
var IST_OFFSET_MS2 = 5.5 * 60 * 60 * 1e3;
var istStartOfDay = (value) => {
  const t = new Date(value);
  if (isNaN(t)) return null;
  const ist = new Date(t.getTime() + IST_OFFSET_MS2);
  ist.setUTCHours(0, 0, 0, 0);
  return new Date(ist.getTime() - IST_OFFSET_MS2);
};
var buildOpeningRow = (groupedRows, search, accountCreatedAt, fallbackBalance = null) => {
  if (search && String(search).trim()) return null;
  if (!groupedRows.length) {
    if (fallbackBalance === null) return null;
    const at0 = istStartOfDay(accountCreatedAt);
    if (!at0) return null;
    return {
      __opening: true,
      id: null,
      created_at: at0,
      delta: fallbackBalance,
      closing_inr_balance: fallbackBalance,
      remark: "Opening pts",
      category: null,
      bet_id: null
    };
  }
  const first = groupedRows[0];
  const closing = parseFloat(first.closing_inr_balance);
  const firstDelta = parseFloat(first.delta || 0);
  if (!Number.isFinite(closing) || !Number.isFinite(firstDelta)) return null;
  const opening = Math.round((closing - firstDelta) * 100) / 100;
  const at = istStartOfDay(accountCreatedAt || first.created_at);
  if (!at) return null;
  return {
    __opening: true,
    id: null,
    created_at: at,
    delta: opening,
    closing_inr_balance: opening,
    remark: "Opening pts",
    category: null,
    bet_id: null
  };
};
var isCommissionRow = (row) => row.event_type === POINT_EVENT.COMMISSION || String(row.entry_ref || "").startsWith("reverse:commission:");
var sportsMarketKey = (row, sportsBetMap) => {
  const base = sportsMarketBaseKey(row, sportsBetMap);
  if (!base) return null;
  const key = isCommissionRow(row) ? `${base}:comm` : base;
  return isVoidRow(row) ? `${key}:void` : key;
};
var sportsMarketBaseKey = (row, sportsBetMap) => {
  if (row.category !== "SPORTS") return null;
  const bet = sportsBetMap[row.bet_id];
  if (!bet || !bet.eventid) return null;
  if (String(bet.game_type || "").toUpperCase() === "FAN") {
    const name = fanMarketName(bet);
    return name ? `S:${bet.eventid}:${bet.market_type || ""}:${name}` : null;
  }
  return bet.match_id ? `S:${bet.eventid}:${bet.match_id}` : null;
};
var groupStatementRows = (rows, sportsBetMap) => {
  const out = [];
  const seen = {};
  for (const row of rows) {
    const key = sportsMarketKey(row, sportsBetMap);
    if (!key) {
      out.push(row);
      continue;
    }
    if (seen[key] === void 0) {
      seen[key] = out.length;
      out.push({ ...row });
      continue;
    }
    const merged = out[seen[key]];
    merged.delta = Number(merged.delta || 0) + Number(row.delta || 0);
    merged.created_at = row.created_at;
    merged.closing_inr_balance = row.closing_inr_balance;
    merged.remark = row.remark;
    merged.bet_id = row.bet_id;
  }
  return out;
};
var UserStatementService = {
  getAccountStatementV2: async (target, filters) => {
    try {
      const { fromDate, toDate, reportType, search, page = 1, limit = 25 } = filters;
      const offset = (page - 1) * limit;
      console.log(`\u{1F50D} [UserStatementService] StatementV2 for ${target.username} (wallet ${target.walletId}) | ${fromDate || "-"} \u2192 ${toDate || "-"} | type: ${reportType} | search: ${search || "-"}`);
      const where = { wallet_id: target.walletId };
      if (fromDate || toDate) {
        where.created_at = {};
        if (fromDate) where.created_at[Op9.gte] = new Date(fromDate);
        if (toDate) {
          const end = new Date(toDate);
          end.setHours(23, 59, 59, 999);
          where.created_at[Op9.lte] = end;
        }
      }
      if (search && String(search).trim()) {
        where.remark = { [Op9.iLike]: `%${String(search).trim()}%` };
      }
      const rt = String(reportType || "ALL").toUpperCase().trim();
      if (rt === "TRANSACTION") where.bet_id = null;
      else if (rt === "SPORTS") where.bet_id = { [Op9.ne]: null };
      const rawLedgerRows = await PointLedger_default.findAll({
        where,
        order: [["id", "ASC"]],
        // purani entry pehle
        raw: true
      });
      const allRows = target?.isDemo && rt !== "ALL" ? rawLedgerRows.filter((r) => r.event_type !== POINT_EVENT.USER_CREATION) : rawLedgerRows;
      const sportsBetIds = [...new Set(allRows.filter((r) => r.category === "SPORTS" && r.bet_id).map((r) => Number(r.bet_id)))];
      const sportsBetMap = {};
      if (sportsBetIds.length) {
        const sportsBets = await SportsBet_default.findAll({
          where: { id: sportsBetIds },
          attributes: ["id", "sport_id", "eventid", "match_id", "market_type", "game_type", "fancy_name", "selection_name"],
          raw: true
        });
        sportsBets.forEach((b) => {
          sportsBetMap[b.id] = b;
        });
      }
      const groupedRows = groupStatementRows(allRows, sportsBetMap);
      let openingFallback = null;
      if (!groupedRows.length) {
        const prevWhere = { wallet_id: target.walletId };
        if (fromDate) prevWhere.created_at = { [Op9.lt]: new Date(fromDate) };
        const prev = await PointLedger_default.findOne({
          where: prevWhere,
          order: [["id", "DESC"]],
          attributes: ["closing_inr_balance"],
          raw: true
        });
        openingFallback = prev ? Number(prev.closing_inr_balance) || 0 : 0;
      }
      const openingRow = buildOpeningRow(groupedRows, search, target?.createdAt, openingFallback);
      const ledgerRows = [
        ...openingRow ? [openingRow] : [],
        ...groupedRows
      ];
      const count = ledgerRows.length;
      const rows = ledgerRows.slice(offset, offset + parseInt(limit));
      const data = rows.map((r) => {
        const delta = parseFloat(r.delta || 0);
        if (r.__opening) {
          const bal = parseFloat(r.closing_inr_balance).toFixed(2);
          return {
            date: r.created_at,
            credit: bal,
            debit: "-",
            closing: bal,
            description: "Opening pts",
            fromto: "-",
            category: null,
            betId: null,
            sportId: null,
            eventId: null,
            matchId: null,
            marketType: null,
            gameType: null,
            isOpening: true
          };
        }
        let sportId = null, eventId = null, matchId = null, marketType = null, gameType = null;
        let fancyName = null;
        const voidRow = isVoidRow(r);
        let description = r?.remark?.split("#")[0] || r.event_type;
        if (voidRow) description = stripVoidPrefix(description);
        if (r.category === "SPORTS") {
          const sb = sportsBetMap[r.bet_id];
          sportId = sb?.sport_id ?? r.sport_id ?? null;
          eventId = sb?.eventid ?? null;
          matchId = sb?.match_id ?? null;
          marketType = sb?.market_type ?? null;
          gameType = sb?.game_type ?? r.game_type ?? null;
          if (String(gameType || "").toUpperCase() === "FAN") {
            fancyName = fanMarketName(sb);
            if (fancyName && description && !description.includes(fancyName)) {
              const parts = String(description).split(" / ");
              const spanAt = parts.length - 2;
              if (isKhadoBet(sb) && parts.length >= 3 && parts[spanAt] === String(sb.fancy_name ?? "")) {
                parts[spanAt] = fancyName;
                description = parts.join(" / ");
              } else if (parts.length >= 2) {
                parts.splice(parts.length - 1, 0, fancyName);
                description = parts.join(" / ");
              }
            }
          }
        }
        if (voidRow) description = withVoidSuffix(description);
        return {
          date: r.created_at,
          credit: delta > 0 ? delta.toFixed(2) : "-",
          debit: delta < 0 ? Math.abs(delta).toFixed(2) : "-",
          closing: r.closing_inr_balance != null ? parseFloat(r.closing_inr_balance).toFixed(2) : "-",
          description,
          fromto: r?.remark?.split("#")[1] || "-",
          category: r.category || null,
          betId: r.bet_id != null ? Number(r.bet_id) : null,
          sportId,
          eventId,
          matchId,
          marketType,
          gameType,
          fancyName,
          // 'User creation' = the account's opening credit: nothing to open.
          eventType: r.event_type || null
        };
      });
      return {
        success: true,
        data,
        total: count,
        totalPages: Math.ceil(count / limit),
        currentPage: parseInt(page)
      };
    } catch (e) {
      console.error("\u274C [UserStatementService] getAccountStatementV2 error:", e);
      throw e;
    }
  },
  /**
   * Result modal for a SPORTS statement row: us market ke bets (SportsBet table
   * se) + winner (credits_ledger settlement description se).
   * Pehchaan: matchId (= market/mid) + eventId (= match/gmid), aur FAN par uske
   * upar fancyName — kyunki fancy markets ka match_id poore event me ek hi hota
   * hai (DB me 724 FAN bets par sirf 153 distinct match_id vs 420 asli markets).
   * Bina fancyName ke modal us event ki SAARI fancy bets dikha deta tha.
   * user_id filter se sirf logged-in user ke apne bets aate hain.
   */
  getStatementMarketBets: async (target, params = {}) => {
    try {
      const { matchId, eventId, fancyName } = params;
      if (!matchId || !eventId) {
        return { success: false, message: "matchId and eventId required" };
      }
      const fancy = fancyName ? String(fancyName).trim() : "";
      const where = {
        user_id: target.id,
        match_id: String(matchId),
        eventid: String(eventId),
        // Bet placement kabhi fancy_name me naam rakhta hai, kabhi sirf
        // selection_name me (khado/fancy1 par fancy_name line hoti hai),
        // isliye dono par match karo.
        ...fancy ? { [Op9.or]: [{ fancy_name: fancy }, { selection_name: fancy }] } : {}
      };
      const betRows = await SportsBet_default.findAll({
        where,
        order: [["created_at", "ASC"], ["id", "DESC"]],
        raw: true
      });
      const settledCredit = { [Op9.or]: [{ profit: { [Op9.ne]: null } }, { loss: { [Op9.ne]: null } }] };
      const betIds = betRows.map((b) => b.id);
      const credit = await CreditsLedger_default.findOne({
        where: {
          category: "SPORTS",
          user_id: String(target.id),
          eventid: String(eventId),
          // Commission rows carry loss too, and sort newer — the winner must
          // come from the settlement row, never "…- Comm".
          reason: { [Op9.notIn]: ["commission", "commission_void"] },
          ...fancy && betIds.length ? { bet_id: { [Op9.in]: betIds } } : { match_id: String(matchId) },
          ...settledCredit
        },
        order: [["id", "DESC"]],
        raw: true
      });
      let winner = null;
      if (credit?.description) {
        const parts = String(credit.description).split(" / ");
        if (parts.length >= 2) winner = parts[parts.length - 1].trim() || null;
      }
      const fanNet = await loadFanSettlementNet(target.id, betRows);
      const DELETED_STATES = ["refund", "void", "deleted", "cancelled"];
      let totalBets = 0;
      let totalWin = 0;
      const bets = betRows.map((b) => {
        const bt = String(b.bet_type || "").toLowerCase();
        const side = bt === "back" || bt === "yes" ? "BACK" : bt === "lay" || bt === "no" ? "LAY" : null;
        const rs = String(b.result_status || "").toLowerCase();
        const deleted = DELETED_STATES.includes(rs) || DELETED_STATES.includes(String(b.status || "").toLowerCase());
        const settled = rs === "won" || rs === "loss";
        const win = settled ? Math.round(sportsNet(b, fanNet.get(String(b.id))) * 100) / 100 : null;
        if (!deleted) {
          totalBets += 1;
          totalWin += win || 0;
        }
        return {
          ...b,
          user: { username: target.username || null },
          sport_name: SPORT_NAMES[b.sport_id] || (b.sport_id ? `Sport ${b.sport_id}` : null),
          side,
          win,
          deleted
        };
      });
      const first = betRows[0] || null;
      const header = first ? {
        sportId: first.sport_id || null,
        sportName: SPORT_NAMES[first.sport_id] || (first.sport_id ? `Sport ${first.sport_id}` : "-"),
        eventId: first.eventid || null,
        matchId: first.match_id || null,
        matchTitle: first.match_title || [first.team_one, first.team_two].filter(Boolean).join(" v ") || "-",
        // League segment of the Result-modal breadcrumb (buildBreadcrumb in
        // AccountStatement.jsx). Null on bets placed before the column existed.
        competitionName: first.league_name || null,
        marketType: first.market_type || "-",
        gameType: first.game_type || null,
        // FAN par market_type sirf "Normal"/"khado" jaisa bucket hai — modal ke
        // breadcrumb me asli market yahi naam hai.
        fancyName: String(first.game_type || "").toUpperCase() === "FAN" ? fanMarketName(first) : null,
        // Naive "YYYY-MM-DD HH:mm:ss": match_start_time holds the feed's IST wall
        // clock read as server-local, so a raw Date rendered 3h30m late in an IST
        // browser (00:30 showed as 04:00). See helper/naiveLocalTime.js.
        gameTime: toNaiveLocalTime(first.match_start_time) || first.created_at || null
      } : null;
      return {
        success: true,
        header,
        winner,
        description: credit?.description || null,
        settledAt: credit?.created_at || null,
        totalBets,
        totalWin: Math.round(totalWin * 100) / 100,
        bets
      };
    } catch (e) {
      console.error("\u274C [UserStatementService] getStatementMarketBets error:", e);
      throw e;
    }
  }
};
var UserStatementService_default = UserStatementService;

// controller/user/UserStatementController.js
var UserStatementController = {
  getAccountStatementV2: async (req, res) => {
    try {
      console.log("\u{1F4DD} [UserStatementController] getAccountStatementV2 request:", req.body);
      const id = req.user.user_id || req?.user?.account?.id;
      if (!id) {
        return res.status(401).json({ success: false, message: "User not authenticated or ID missing" });
      }
      const { reportType, fromDate, toDate, search, page, limit } = req.body || {};
      const rt = String(reportType || "ALL").toUpperCase().trim();
      if (!["ALL", "TRANSACTION", "SPORTS"].includes(rt)) {
        return res.status(400).json({ success: false, message: "reportType must be ALL, TRANSACTION or SPORTS" });
      }
      const wallet = await Wallet_default.findOne({
        where: { user_id: id },
        attributes: ["wallet_id", "username", "createdAt"],
        raw: true
      });
      if (!wallet) {
        return res.status(404).json({ success: false, message: "Wallet not found" });
      }
      const target = {
        id,
        username: req.user.username,
        walletId: wallet.wallet_id,
        createdAt: wallet.createdAt,
        isDemo: !!req.user.isDemo
      };
      const result = await UserStatementService_default.getAccountStatementV2(target, { reportType: rt, fromDate, toDate, search, page, limit });
      return res.status(200).json(result);
    } catch (error) {
      console.error("\u274C [UserStatementController] getAccountStatementV2 Error:", error);
      res.status(500).json({ success: false, error: error.message });
    }
  },
  /**
   * Result modal data for one SPORTS statement row:
   * us market ke saare bets + winner.
   * Input: matchId (= market/mid) + eventId (= match/gmid) — statement row se.
   */
  getStatementMarketBets: async (req, res) => {
    try {
      const id = req.user.user_id || req?.user?.account?.id;
      if (!id) {
        return res.status(401).json({ success: false, message: "User not authenticated or ID missing" });
      }
      const { matchId, eventId, fancyName } = req.body || {};
      if (!matchId || !eventId) {
        return res.status(400).json({ success: false, message: "matchId and eventId required" });
      }
      const result = await UserStatementService_default.getStatementMarketBets(
        { id, username: req.user.username },
        { matchId, eventId, fancyName }
      );
      if (!result?.success) return res.status(400).json(result);
      return res.status(200).json(result);
    } catch (error) {
      console.error("\u274C [UserStatementController] getStatementMarketBets Error:", error);
      res.status(500).json({ success: false, error: error.message });
    }
  }
};
var UserStatementController_default = UserStatementController;

// helper/exposureBucket.js
var PER_SELECTION_MARKETS = /* @__PURE__ */ new Set([
  "Normal",
  "Ball By Ball",
  "Over By Over",
  "khado",
  "meter",
  "fancy1",
  "oddeven",
  "badlo"
]);
var isPerSelectionMarket = (marketType) => PER_SELECTION_MARKETS.has(String(marketType || "")) || isLineMarket(marketType);
var selectionExposureRows = (sel) => [sel, `${sel}lay`, `${sel}back`, `${sel}totalstake`];
var isHelperExposureRow = (teamName) => /(?:lay|back|totalstake)$/i.test(String(teamName || ""));
var releasableLiability = (exposures, { perSelection, sel } = {}) => {
  if (perSelection) {
    const base = exposures.find((e) => e.team_name === sel);
    return Math.min(0, parseFloat(base?.exposure_amount || 0));
  }
  return exposures.reduce(
    (min, e) => Math.min(min, parseFloat(e.exposure_amount || 0)),
    0
  );
};
var additiveBucketLiability = (exposures) => exposures.reduce((sum, e) => {
  if (isHelperExposureRow(e.team_name)) return sum;
  const val = parseFloat(e.exposure_amount || 0);
  return val < 0 ? sum + val : sum;
}, 0);
var SETTLED_RESULT_STATUSES = ["won", "loss", "lost"];

// sportsbet/betresult/settlementQueue.js
import IORedis from "ioredis";
import { Op as Op10 } from "sequelize";

// model/user/SportsEventSettlementJobs.js
init_db();
import { DataTypes as DataTypes32 } from "sequelize";
var SportsEventSettlementJob = db_default.define(
  "SportsEventSettlementJob",
  {
    job_id: {
      type: DataTypes32.UUID,
      defaultValue: DataTypes32.UUIDV4,
      primaryKey: true
    },
    user_id: {
      type: DataTypes32.TEXT,
      allowNull: false
    },
    eventid: {
      type: DataTypes32.TEXT,
      allowNull: false
    },
    status: {
      type: DataTypes32.TEXT,
      allowNull: false,
      defaultValue: "queued"
    },
    priority: {
      type: DataTypes32.INTEGER,
      allowNull: false,
      defaultValue: 5
    },
    run_after: {
      type: DataTypes32.DATE,
      allowNull: false,
      defaultValue: DataTypes32.NOW
    },
    payload: {
      type: DataTypes32.JSONB,
      allowNull: false
    },
    error_msg: {
      type: DataTypes32.TEXT,
      allowNull: true
    },
    created_at: {
      type: DataTypes32.DATE,
      allowNull: false,
      defaultValue: DataTypes32.NOW
    },
    updated_at: {
      type: DataTypes32.DATE,
      allowNull: false,
      defaultValue: DataTypes32.NOW
    },
    bet_type: {
      type: DataTypes32.TEXT,
      allowNull: true
    },
    bet_id: {
      type: DataTypes32.TEXT,
      allowNull: true
    }
  },
  {
    tableName: "sports_event_settlement_jobs",
    timestamps: false,
    indexes: [
      {
        // this MUST match your conflictFields and be unique
        unique: true,
        fields: ["user_id", "eventid", "bet_id"],
        name: "uniq_user_event_bet"
      },
      {
        fields: ["status"]
      }
    ]
  }
);
var SportsEventSettlementJobs_default = SportsEventSettlementJob;

// sportsbet/betresult/settlementQueue.js
var WAKE_CHANNEL = `sports-settle:wake:${process.env.DB_NAME || "default"}`;
var REARM_AFTER_MS = +(process.env.REARM_AFTER_MS || 2e4);
var noopLog = { info: () => {
}, error: () => {
}, debug: () => {
} };
var pub = null;
function getPublisher2(log = noopLog) {
  if (pub) return pub;
  try {
    pub = new IORedis({
      host: process.env.REDIS_HOST || "127.0.0.1",
      port: +(process.env.REDIS_PORT || 6379),
      maxRetriesPerRequest: null
    });
    pub.on("error", (e) => log.error("[SettleQueue] redis wake error", { error: e.message }));
  } catch (e) {
    log.error("[SettleQueue] redis wake unavailable", { error: e.message });
    pub = null;
  }
  return pub;
}
async function wakeSettlement(count, log = noopLog) {
  const p = getPublisher2(log);
  if (!p) return;
  try {
    await p.publish(WAKE_CHANNEL, String(count));
    log.info("[SettleQueue] settlement worker woken", { count, channel: WAKE_CHANNEL });
  } catch (e) {
    log.error("[SettleQueue] wake publish failed", { error: e.message });
  }
}
async function enqueueSettlementJob(b, declared, log = noopLog) {
  const userId = String(b.user_id);
  const eid = String(b.eventid);
  const betIdStr = String(b.id);
  const betType = (b.bet_type || "").toString().toLowerCase() || "unknown";
  const payload = { user_id: userId, eventid: eid, bet_id: betIdStr, bet_type: betType, bet: b, match_over: declared };
  const now = /* @__PURE__ */ new Date();
  const pointBet = (jobId) => SportsBet_default.update(
    { job_id: jobId },
    { where: { id: b.id, status: { [Op10.in]: ["open", "manual"] } } }
  );
  const existing = await SportsEventSettlementJobs_default.findOne({
    where: { user_id: userId, eventid: eid, bet_id: betIdStr },
    attributes: ["job_id", "status", "updated_at"]
  });
  if (existing && (existing.status === "queued" || existing.status === "processing")) {
    if (String(b.job_id || "") !== String(existing.job_id)) await pointBet(existing.job_id);
    return { jobId: existing.job_id, action: "already-live" };
  }
  if (existing) {
    const age = Date.now() - new Date(existing.updated_at).getTime();
    if (age < REARM_AFTER_MS) return { jobId: existing.job_id, action: "cooldown" };
    await existing.update({ status: "queued", run_after: now, updated_at: now, error_msg: null, payload });
    await pointBet(existing.job_id);
    return { jobId: existing.job_id, action: "re-armed" };
  }
  let job;
  try {
    job = await SportsEventSettlementJobs_default.create({
      user_id: userId,
      eventid: eid,
      bet_id: betIdStr,
      bet_type: betType,
      status: "queued",
      priority: 5,
      run_after: now,
      payload,
      created_at: now,
      updated_at: now
    });
  } catch (e) {
    if (e.name === "SequelizeUniqueConstraintError") return { action: "race-skip" };
    throw e;
  }
  await pointBet(job.job_id);
  return { jobId: job.job_id, action: "created" };
}
async function enqueueManualBets({ eventid, match_id, market_type, log = noopLog }) {
  const where = { status: "manual", eventid: String(eventid) };
  if (match_id) where.match_id = String(match_id);
  if (market_type) where.market_type = market_type;
  const bets = await SportsBet_default.findAll({
    where,
    attributes: [
      "id",
      "user_id",
      "game_type",
      "bet_type",
      "selection_name",
      "odds",
      "stake_amount",
      "match_title",
      "match_id",
      "fancy_name",
      "eventid",
      "created_at",
      "sport_id",
      "market_type",
      "status",
      "team_one",
      "team_two",
      "runners",
      "job_id"
    ],
    order: [["created_at", "ASC"]]
  });
  let queued = 0;
  for (const b of bets) {
    try {
      const r = await enqueueSettlementJob(b, true, log);
      if (r?.action === "created" || r?.action === "re-armed") queued++;
    } catch (e) {
      log.error("[SettleQueue] manual enqueue failed", { betId: b.id, error: e.message });
    }
  }
  if (queued) await wakeSettlement(queued, log);
  log.info("[SettleQueue] manual declare queued", { eventid, match_id, market_type, bets: bets.length, queued });
  return { bets: bets.length, queued };
}

// mannualSettle/controller.js
init_TotalExposure();

// model/admin/BetVoidAudit.js
init_db();
import { DataTypes as DataTypes33 } from "sequelize";
var VOID_TYPES = {
  OPEN_BET: "OPEN_BET",
  // POST /void-single-bet
  MARKET: "MARKET",
  // POST /void  (market / one fancy session)
  AFTER_SETTLEMENT: "AFTER_SETTLEMENT",
  // POST /void-bet-after-settlement, /void-market-after-settlement
  FEED_SUSPENDED: "FEED_SUSPENDED",
  // settlementv2: provider declared the market SUSPENDED
  AUTO_TIMEOUT: "AUTO_TIMEOUT"
  // autoVoid.js: still open N s after MATCH_ODDS/BOOKMAKER declared
};
var money = { type: DataTypes33.DECIMAL(15, 2), allowNull: true };
var BetVoidAudit = db_default.define(
  "BetVoidAudit",
  {
    id: { type: DataTypes33.BIGINT, autoIncrement: true, primaryKey: true },
    // ── which void operation ────────────────────────────────────────────────
    void_group_id: { type: DataTypes33.UUID, allowNull: false },
    is_representative: { type: DataTypes33.BOOLEAN, allowNull: false, defaultValue: false },
    void_type: { type: DataTypes33.STRING(32), allowNull: false },
    // ── which bet ───────────────────────────────────────────────────────────
    bet_id: { type: DataTypes33.BIGINT, allowNull: false },
    bet_kind: { type: DataTypes33.STRING(16), allowNull: false, defaultValue: "SPORTS" },
    user_id: { type: DataTypes33.BIGINT, allowNull: false },
    username: { type: DataTypes33.STRING(255), allowNull: true },
    // Bet identity FROZEN at void time. Denormalised on purpose: a report must
    // still read correctly if the bet row is later edited or purged.
    match_id: { type: DataTypes33.STRING(255), allowNull: true },
    eventid: { type: DataTypes33.STRING(255), allowNull: true },
    match_title: { type: DataTypes33.STRING(255), allowNull: true },
    market_type: { type: DataTypes33.STRING(255), allowNull: true },
    game_type: { type: DataTypes33.STRING(100), allowNull: true },
    selection_name: { type: DataTypes33.STRING(255), allowNull: true },
    bet_type: { type: DataTypes33.STRING(32), allowNull: true },
    odds: { type: DataTypes33.DECIMAL(15, 4), allowNull: true },
    stake_amount: money,
    liability: money,
    // ── PRE ─────────────────────────────────────────────────────────────────
    status_before: { type: DataTypes33.STRING(32), allowNull: true },
    result_status_before: { type: DataTypes33.STRING(32), allowNull: true },
    cash_before: money,
    inr_before: money,
    // The bucket's own liability (the `sel` row for a per-selection market, the
    // worst row for MO/BM) — what this void was actually holding.
    exposure_before: money,
    total_exposure_before: money,
    // ── POST ────────────────────────────────────────────────────────────────
    status_after: { type: DataTypes33.STRING(32), allowNull: true },
    result_status_after: { type: DataTypes33.STRING(32), allowNull: true },
    cash_after: money,
    inr_after: money,
    exposure_after: money,
    total_exposure_after: money,
    // Money returned FOR THE GROUP (repeated on each row of the group — sum over
    // DISTINCT void_group_id). 0 is a legitimate value: a void of a bet whose
    // liability was already held by nothing releases nothing.
    refund_amount: { type: DataTypes33.DECIMAL(15, 2), allowNull: true },
    exposure_rows_deleted: { type: DataTypes33.INTEGER, allowNull: true },
    // credits_ledger row this void wrote, when it wrote one.
    ledger_id: { type: DataTypes33.BIGINT, allowNull: true },
    // ── who and how ─────────────────────────────────────────────────────────
    actor: { type: DataTypes33.STRING(255), allowNull: true },
    actor_role: { type: DataTypes33.STRING(64), allowNull: true },
    ip_address: { type: DataTypes33.STRING(64), allowNull: true },
    browser: { type: DataTypes33.TEXT, allowNull: true },
    note: { type: DataTypes33.TEXT, allowNull: true },
    // Historical rows reconstructed from SportsBet + credits_ledger. Their
    // wallet/exposure columns are NULL and must not be read as zero.
    backfilled: { type: DataTypes33.BOOLEAN, allowNull: false, defaultValue: false },
    created_at: { type: DataTypes33.DATE, allowNull: false, defaultValue: DataTypes33.NOW }
  },
  {
    tableName: "bet_void_audit",
    timestamps: false,
    indexes: [
      // Reports filter by time first, then narrow.
      { fields: ["created_at"] },
      { fields: ["user_id", "created_at"] },
      { fields: ["void_group_id"] },
      { fields: ["void_type", "created_at"] },
      // The tracker joins from SportsBet to "did this void get audited?".
      { fields: ["bet_kind", "bet_id"] }
    ]
  }
);
var BetVoidAudit_default = BetVoidAudit;

// mannualSettle/controller.js
init_db();

// model/admin/manualresult.js
init_db();
import { DataTypes as DataTypes34 } from "sequelize";
var MannualResult = db_default.define("MannualResult", {
  id: {
    type: DataTypes34.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  match_title: {
    type: DataTypes34.STRING,
    allowNull: false
  },
  eventid: {
    type: DataTypes34.STRING,
    allowNull: false
  },
  match_id: {
    type: DataTypes34.STRING,
    allowNull: false
  },
  market_type: {
    type: DataTypes34.STRING,
    allowNull: false
  },
  game_type: {
    type: DataTypes34.STRING,
    allowNull: false
  },
  winnerId: {
    type: DataTypes34.INTEGER,
    allowNull: true,
    field: "winnerId"
  },
  winnerName: {
    type: DataTypes34.STRING,
    allowNull: true,
    field: "winnerName"
  },
  fancyName: {
    type: DataTypes34.STRING,
    allowNull: true,
    field: "fancyName"
  }
}, {
  tableName: "mannual_result",
  timestamps: true,
  // createdAt & updatedAt
  underscored: true
  // created_at, updated_at
});
var manualresult_default = MannualResult;

// mannualSettle/controller.js
import { Op as Op13, Sequelize as Sequelize3 } from "sequelize";
import { fn, col, literal } from "sequelize";

// model/admin/UserActivityLog.js
init_db();
import { DataTypes as DataTypes35 } from "sequelize";
var UserActivityLog = db_default.define("UserActivityLog", {
  id: {
    type: DataTypes35.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  username: {
    type: DataTypes35.STRING,
    allowNull: false
  },
  user_id: {
    type: DataTypes35.INTEGER,
    allowNull: true,
    comment: "ID if type is USER"
  },
  staff_id: {
    type: DataTypes35.INTEGER,
    allowNull: true,
    comment: "ID if type is STAFF"
  },
  owner_id: {
    type: DataTypes35.INTEGER,
    allowNull: true,
    comment: "ID if type is OWNER"
  },
  user_type: {
    type: DataTypes35.ENUM("USER", "STAFF", "OWNER"),
    allowNull: false
  },
  action: {
    type: DataTypes35.STRING,
    allowNull: false,
    comment: "LOGIN, PASSWORD_CHANGE, STATUS_CHANGE, etc."
  },
  ip_address: {
    type: DataTypes35.STRING,
    allowNull: true
  },
  browser_detail: {
    type: DataTypes35.STRING,
    allowNull: true,
    comment: "User Agent string"
  },
  details: {
    type: DataTypes35.TEXT,
    allowNull: true,
    comment: "Additional details in JSON or text format"
  }
}, {
  tableName: "user_activity_logs",
  timestamps: true,
  updatedAt: false
  // We only care about creation time for logs
});
var UserActivityLog_default = UserActivityLog;

// services/admin/ActivityLogService.js
var ActivityLogService = {
  /**
   * Log a user activity
   * @param {Object} params
   * @param {Object} params.req - Express request object (to extract IP and User Agent)
   * @param {Object} params.user - User object (should contain id, username, role/user_type)
   * @param {string} params.action - Action name (e.g., 'LOGIN', 'PASSWORD_CHANGE')
   * @param {string} [params.details] - Optional details
   */
  log: async ({ req, user, action, details = null }) => {
    try {
      const ip_address = req.headers["x-forwarded-for"] || req.socket.remoteAddress || req.ip;
      const browser_detail = req.headers["user-agent"];
      let user_type = "USER";
      if (user.role === "OWNER") {
        user_type = "OWNER";
      } else if (user.role && user.role !== "USER") {
        user_type = "STAFF";
      } else if (user.user_type) {
        user_type = user.user_type;
      }
      let userIdField = {};
      if (user_type === "OWNER") {
        userIdField = { owner_id: user.id || user.owner_id };
      } else if (user_type === "STAFF") {
        userIdField = { staff_id: user.id || user.staff_id };
      } else {
        userIdField = { user_id: user.id || user.user_id };
      }
      await UserActivityLog_default.create({
        username: user.username,
        ...userIdField,
        user_type,
        action,
        ip_address,
        browser_detail,
        details: typeof details === "object" ? JSON.stringify(details) : details
      });
      console.log(`\u{1F4DD} Activity Logged: ${user.username} - ${action}`);
    } catch (error) {
      console.error("\u274C Failed to log activity:", error.message);
    }
  },
  /**
   * Get logs with filters and pagination
   */
  getLogs: async ({ startDate, endDate, logType, userId, userType, page = 1, limit = 10 }) => {
    try {
      const { Op: Op16 } = await import("sequelize");
      const offset = (page - 1) * limit;
      const where = {};
      if (startDate && endDate) {
        where.createdAt = {
          [Op16.between]: [new Date(startDate), /* @__PURE__ */ new Date(endDate + "T23:59:59.999Z")]
        };
      }
      if (logType) {
        where.action = logType;
      }
      if (userId && userType) {
        where.user_type = userType;
        if (userType === "OWNER") where.owner_id = userId;
        else if (userType === "STAFF") where.staff_id = userId;
        else where.user_id = userId;
      }
      const { count, rows } = await UserActivityLog_default.findAndCountAll({
        where,
        order: [["createdAt", "DESC"]],
        limit: parseInt(limit),
        offset: parseInt(offset)
      });
      return {
        total: count,
        totalPages: Math.ceil(count / limit),
        currentPage: parseInt(page),
        logs: rows
      };
    } catch (error) {
      console.error("\u274C Failed to fetch logs:", error.message);
      throw error;
    }
  }
};
var ActivityLogService_default = ActivityLogService;

// services/admin/voidAuditService.js
import { randomUUID } from "crypto";
var newVoidGroupId = () => randomUUID();
var num2 = (v) => v === null || v === void 0 || v === "" ? null : Number(v);
var actorFrom = (req) => ({
  actor: req?.user?.actor?.username || req?.user?.username || null,
  actor_role: req?.user?.actor?.role || req?.user?.role || null,
  ip_address: (req?.headers?.["x-forwarded-for"] || "").split(",")[0].trim() || req?.socket?.remoteAddress || req?.ip || null,
  browser: req?.headers?.["user-agent"] || null
});
var recordVoidAudit = async ({
  voidGroupId,
  voidType,
  bets = [],
  representativeBetId = null,
  before = {},
  after = {},
  refundAmount = null,
  exposureRowsDeleted = null,
  ledgerId = null,
  context = {},
  betKind = "SPORTS",
  backfilled = false
}, t = null) => {
  if (!bets.length) return [];
  const rows = bets.map((b) => ({
    void_group_id: voidGroupId,
    is_representative: representativeBetId != null && Number(b.id) === Number(representativeBetId),
    void_type: voidType,
    bet_id: b.id,
    bet_kind: betKind,
    user_id: b.user_id,
    username: context.username || b.username || null,
    match_id: b.match_id != null ? String(b.match_id) : null,
    eventid: b.eventid != null ? String(b.eventid) : b.event_id != null ? String(b.event_id) : null,
    match_title: b.match_title || b.event_name || null,
    market_type: b.market_type || null,
    game_type: b.game_type || null,
    // sports rows call it `selection_name` (`selection` kept as a fallback).
    selection_name: b.selection_name || b.selection || null,
    bet_type: b.bet_type || null,
    odds: num2(b.odds),
    stake_amount: num2(b.stake_amount ?? b.stake),
    liability: num2(b.liability ?? b.exposer),
    status_before: before.status ?? b.status ?? null,
    result_status_before: before.resultStatus ?? b.result_status ?? null,
    cash_before: num2(before.cash),
    inr_before: num2(before.inr),
    exposure_before: num2(before.exposure),
    total_exposure_before: num2(before.totalExposure),
    status_after: after.status ?? null,
    result_status_after: after.resultStatus ?? null,
    cash_after: num2(after.cash),
    inr_after: num2(after.inr),
    exposure_after: num2(after.exposure),
    total_exposure_after: num2(after.totalExposure),
    refund_amount: num2(refundAmount),
    exposure_rows_deleted: exposureRowsDeleted == null ? null : Number(exposureRowsDeleted),
    ledger_id: ledgerId == null ? null : Number(ledgerId),
    actor: context.actor || null,
    actor_role: context.actor_role || null,
    ip_address: context.ip_address || null,
    browser: context.browser || null,
    note: context.note || null,
    backfilled,
    created_at: /* @__PURE__ */ new Date()
  }));
  return BetVoidAudit_default.bulkCreate(rows, t ? { transaction: t } : {});
};

// services/admin/sportsMarketVoidService.js
init_db();
import { Op as Op11 } from "sequelize";
init_TotalExposure();
var recordVoidRefund = async ({ uid, refundAmount, bet, actor, source = "manual_void", label = "MANUAL VOID" }, t) => {
  if (!(Number(refundAmount) > 0)) return null;
  const wallet = await Wallet_default.findOne({
    where: { user_id: uid },
    attributes: ["wallet_id", "cash"],
    transaction: t
  });
  const marketType = bet?.market_type || null;
  const selection = bet?.selection_name ? ` / ${bet.selection_name}` : "";
  const title = bet?.match_title || bet?.event_name || "match";
  const ledgerRow = await CreditsLedger_default.create({
    user_id: String(uid),
    currency: "INR",
    amount: refundAmount,
    reason: "refund",
    description: `${label} \u2014 ${title} / ${marketType || "-"}${selection}`,
    eventid: bet?.eventid ? String(bet.eventid) : null,
    match_id: bet?.match_id ? String(bet.match_id) : null,
    market_type: marketType,
    bet_id: bet?.id ?? null,
    meta: {
      source,
      voided_by: actor || "owner",
      exposure_released: Number(refundAmount)
    },
    netamount: refundAmount,
    closing: wallet ? Number(wallet.cash) : null,
    profit: null,
    loss: null,
    category: "SPORTS"
  }, { transaction: t });
  return ledgerRow?.id ?? null;
};
var voidOpenMarket = async ({
  match_id,
  market_type,
  gametype = null,
  selection_name = null,
  voidType = VOID_TYPES.MARKET,
  context = {},
  note = null,
  ledgerSource = "manual_void",
  ledgerLabel = "MANUAL VOID"
}) => {
  if (!match_id || !market_type) {
    throw new Error("Missing required fields: match_id, market_type");
  }
  const t = await db_default.transaction();
  try {
    const whereClause = {
      match_id,
      market_type,
      status: "open"
    };
    if (gametype) {
      whereClause.game_type = gametype;
    }
    if (selection_name) {
      whereClause.selection_name = selection_name;
    }
    const bets = await SportsBet_default.findAll({
      where: whereClause,
      attributes: ["user_id"],
      group: ["user_id"],
      transaction: t
    });
    const userIds = bets.map((b) => b.user_id);
    const marketIsPerSelection = isPerSelectionMarket(market_type);
    const scopedToSelection = Boolean(selection_name) && marketIsPerSelection;
    const { game_type: bucketGameType, team_name: bucketSel } = exposureIdentity({
      marketType: market_type,
      selectionName: selection_name || null
    });
    const voidGroupId = newVoidGroupId();
    const auditCtx = context || {};
    const actorName = auditCtx.actor || null;
    const auditPending = [];
    for (const uid of userIds) {
      const walletBefore = await Wallet_default.findOne({
        where: { user_id: uid },
        attributes: ["cash", "inr_balance"],
        transaction: t
      });
      const snapBefore = await TotalExposure_default.findOne({
        where: { user_id: uid },
        attributes: ["total_exposure"],
        transaction: t
      });
      let refundAmount = 0;
      let ledgerId = null;
      let exposureRowsDeleted = 0;
      let exposureBefore = null;
      const exposureWhere = {
        user_id: uid,
        match_id,
        game_type: bucketGameType
      };
      let perSelection = scopedToSelection;
      if (scopedToSelection) {
        exposureWhere.team_name = { [Op11.in]: selectionExposureRows(bucketSel) };
      }
      let exposures = await UserExposure_default.findAll({
        where: exposureWhere,
        transaction: t
      });
      if (!exposures.length && exposureWhere.game_type !== market_type) {
        exposureWhere.game_type = market_type;
        delete exposureWhere.team_name;
        perSelection = false;
        exposures = await UserExposure_default.findAll({
          where: exposureWhere,
          transaction: t
        });
        if (exposures.length) {
          console.warn(
            "[voidOpenMarket] released a PRE-MIGRATION line exposure row",
            { uid, match_id, market_type }
          );
        }
      }
      const badloSels = (await SportsBet_default.findAll({
        where: { ...whereClause, user_id: uid, badlo: true },
        attributes: ["selection_name"],
        group: ["selection_name"],
        transaction: t
      })).map((b) => b.selection_name);
      let badloWhere = null;
      let badloExposures = [];
      if (badloSels.length > 0) {
        badloWhere = {
          user_id: uid,
          match_id,
          game_type: BADLO_EXPOSURE_GAME_TYPE,
          team_name: {
            [Op11.in]: badloSels.flatMap((s) => selectionExposureRows(
              exposureIdentity({ marketType: market_type, selectionName: s, badlo: true }).team_name
            ))
          }
        };
        badloExposures = await UserExposure_default.findAll({
          where: badloWhere,
          transaction: t
        });
      }
      if (exposures.length > 0 || badloExposures.length > 0) {
        let minExp;
        if (perSelection) {
          minExp = releasableLiability(exposures, { perSelection: true, sel: bucketSel });
        } else if (marketIsPerSelection) {
          minExp = additiveBucketLiability(exposures);
        } else {
          minExp = releasableLiability(exposures, { perSelection: false });
        }
        minExp += additiveBucketLiability(badloExposures);
        exposureBefore = minExp;
        if (minExp < 0) {
          refundAmount = Math.abs(minExp);
          await Wallet_default.increment("cash", {
            by: refundAmount,
            where: { user_id: uid },
            transaction: t
          });
          const repBet = await SportsBet_default.findOne({
            where: { ...whereClause, user_id: uid },
            order: [["id", "ASC"]],
            transaction: t
          });
          ledgerId = await recordVoidRefund({
            uid,
            refundAmount,
            bet: repBet,
            actor: actorName,
            source: ledgerSource,
            label: ledgerLabel
          }, t);
        }
        if (exposures.length > 0) {
          exposureRowsDeleted = await UserExposure_default.destroy({
            where: exposureWhere,
            transaction: t
          });
        }
        if (badloExposures.length > 0) {
          exposureRowsDeleted += await UserExposure_default.destroy({
            where: badloWhere,
            transaction: t
          });
        }
      }
      const userBets = await SportsBet_default.findAll({
        where: { ...whereClause, user_id: uid },
        transaction: t
      });
      auditPending.push({
        uid,
        userBets,
        walletBefore,
        snapBefore,
        refundAmount,
        ledgerId,
        exposureRowsDeleted,
        exposureBefore,
        representativeBetId: userBets.length ? Math.min(...userBets.map((b) => Number(b.id))) : null
      });
    }
    await SportsBet_default.update(
      {
        status: "closed",
        result_status: "refunded",
        match_end_time: /* @__PURE__ */ new Date()
      },
      {
        where: whereClause,
        transaction: t
      }
    );
    const totalsAfter = {};
    for (const uid of userIds) {
      totalsAfter[uid] = await recalcTotalExposure(uid, t);
    }
    let auditedBets = 0;
    for (const a of auditPending) {
      const walletAfter = await Wallet_default.findOne({
        where: { user_id: a.uid },
        attributes: ["cash", "inr_balance"],
        transaction: t
      });
      await recordVoidAudit({
        voidGroupId,
        voidType,
        bets: a.userBets,
        representativeBetId: a.representativeBetId,
        before: {
          status: "open",
          resultStatus: "pending",
          cash: a.walletBefore?.cash,
          inr: a.walletBefore?.inr_balance,
          exposure: a.exposureBefore,
          totalExposure: a.snapBefore?.total_exposure
        },
        after: {
          status: "closed",
          resultStatus: "refunded",
          cash: walletAfter?.cash,
          inr: walletAfter?.inr_balance,
          exposure: a.exposureRowsDeleted > 0 ? 0 : a.exposureBefore,
          totalExposure: totalsAfter[a.uid]
        },
        refundAmount: a.refundAmount,
        exposureRowsDeleted: a.exposureRowsDeleted,
        ledgerId: a.ledgerId,
        context: {
          ...auditCtx,
          note: note || (selection_name ? `session void: ${selection_name}` : `whole ${market_type} market`)
        }
      }, t);
      auditedBets += a.userBets.length;
    }
    await t.commit();
    return { userIds, betsVoided: auditedBets, voidGroupId };
  } catch (error) {
    await t.rollback();
    throw error;
  }
};

// services/admin/sportsVoidService.js
init_db();
import { Op as Op12 } from "sequelize";

// services/settlement/sportsCommissionService.js
init_db();

// services/CommissionConfigService.js
init_redisClient();
var KEY_COMMISSION = "cfg:commission:v2";
var REDIS_TTL_SEC2 = 300;
var MICRO_TTL_MS3 = 2e3;
var NOT_ENABLED = Object.freeze({ enabled: false, percent: 0 });
var micro3 = null;
var microGet3 = () => {
  if (!micro3) return void 0;
  if (micro3.expires < Date.now()) {
    micro3 = null;
    return void 0;
  }
  return micro3.value;
};
var microSet3 = (value) => {
  micro3 = { value, expires: Date.now() + MICRO_TTL_MS3 };
};
var microDel2 = () => {
  micro3 = null;
};
var buildMap = async () => {
  const rows = await CommissionConfig_default.findAll({
    attributes: ["sport_id", "league_key", "market_key", "enabled", "percent"],
    raw: true
  });
  const map = {};
  for (const row of rows) {
    const pct = Number(row.percent);
    const sid = String(row.sport_id);
    const league = String(row.league_key || DEFAULT_LEAGUE_KEY).toLowerCase();
    const market = String(row.market_key || "").toLowerCase();
    if (!market) continue;
    ((map[sid] ||= {})[league] ||= {})[market] = {
      enabled: !!row.enabled && Number.isFinite(pct) && pct > 0,
      percent: Number.isFinite(pct) ? pct : 0
    };
  }
  return map;
};
var getMap = async () => {
  const local = microGet3();
  if (local !== void 0) return local;
  try {
    const cached = await redisClient_default.get(KEY_COMMISSION);
    if (cached != null) {
      const parsed = JSON.parse(cached);
      microSet3(parsed);
      return parsed;
    }
  } catch (err) {
    console.warn(`[CommissionConfig] redis read failed for ${KEY_COMMISSION}:`, err.message);
  }
  let built;
  try {
    built = await buildMap();
  } catch (err) {
    console.warn("[CommissionConfig] build failed:", err.message);
    return {};
  }
  microSet3(built);
  redisClient_default.set(KEY_COMMISSION, JSON.stringify(built), "EX", REDIS_TTL_SEC2).catch(
    (err) => console.warn(`[CommissionConfig] redis write failed for ${KEY_COMMISSION}:`, err.message)
  );
  return built;
};
var getRule = async (sportId, leagueKey, marketKey) => {
  try {
    const map = await getMap();
    const sport = map?.[String(sportId)];
    if (!sport) return NOT_ENABLED;
    const market = String(marketKey || "").toLowerCase();
    const league = String(leagueKey || DEFAULT_LEAGUE_KEY).toLowerCase();
    if (league !== DEFAULT_LEAGUE_KEY) {
      const own = sport?.[league]?.[market];
      if (own) {
        return own.enabled ? { enabled: true, percent: Number(own.percent), source: "league" } : { ...NOT_ENABLED, source: "league" };
      }
    }
    const fallback = sport?.[DEFAULT_LEAGUE_KEY]?.[market];
    if (fallback?.enabled) {
      return { enabled: true, percent: Number(fallback.percent), source: "default" };
    }
  } catch (err) {
    console.warn("[CommissionConfig] getRule failed:", err.message);
  }
  return NOT_ENABLED;
};
var invalidate2 = async () => {
  microDel2();
  try {
    await redisClient_default.del(KEY_COMMISSION);
  } catch (err) {
    console.warn(`[CommissionConfig] redis del failed for ${KEY_COMMISSION}:`, err.message);
  }
};
var CommissionConfigService_default = {
  getMap,
  getRule,
  invalidate: invalidate2,
  KEY_COMMISSION
};

// services/settlement/sportsCommissionService.js
var COMMISSION_REASON = "commission";
var COMMISSION_VOID_REASON = "commission_void";

// services/admin/sportsVoidService.js
var round22 = (v) => Math.round((Number(v) || 0) * 100) / 100;
var VOID_WINDOW_HOURS = Number(process.env.SPORTS_SETTLED_VOID_WINDOW_HOURS || 24);
var since = () => new Date(Date.now() - VOID_WINDOW_HOURS * 60 * 60 * 1e3);
var SETTLEMENT_WHERE = { category: "SPORTS", reason: "settlement" };
var VOID_REASON = "settlement_void";
var voidedLedgerIds = async (settlementRows) => {
  if (!settlementRows.length) return /* @__PURE__ */ new Set();
  const voids = await CreditsLedger_default.findAll({
    where: {
      category: "SPORTS",
      reason: VOID_REASON,
      match_id: { [Op12.in]: [...new Set(settlementRows.map((r) => String(r.match_id)))] }
    },
    raw: true
  });
  if (!voids.length) return /* @__PURE__ */ new Set();
  const out = /* @__PURE__ */ new Set();
  for (const v of voids) {
    const linked = Number(v.meta?.reverses_ledger_id || 0);
    if (linked) {
      out.add(linked);
      continue;
    }
    const candidate = settlementRows.filter(
      (s) => String(s.user_id) === String(v.user_id) && String(s.match_id) === String(v.match_id) && String(s.market_type || "") === String(v.market_type || "") && Number(s.bet_id || 0) === Number(v.bet_id || 0) && Number(s.id) < Number(v.id) && !out.has(Number(s.id))
    ).sort((a, b) => b.id - a.id)[0];
    if (candidate) out.add(Number(candidate.id));
  }
  return out;
};
var netOf = (row) => round22(Number(row.profit || 0) + Number(row.loss || 0));
var listSettledMarkets = async ({ search = "", limit = 200, offset = 0 } = {}) => {
  const lim = Math.min(Math.max(Number(limit) || 200, 1), 500);
  const off = Math.max(Number(offset) || 0, 0);
  const rows = await CreditsLedger_default.findAll({
    where: { ...SETTLEMENT_WHERE, created_at: { [Op12.gte]: since() } },
    order: [["id", "DESC"]],
    raw: true
  });
  if (!rows.length) return { windowHours: VOID_WINDOW_HOURS, data: [] };
  const voided = await voidedLedgerIds(rows);
  const live = rows.filter((r) => !voided.has(Number(r.id)));
  if (!live.length) return { windowHours: VOID_WINDOW_HOURS, data: [] };
  const groups = /* @__PURE__ */ new Map();
  for (const r of live) {
    const key = `${r.match_id}|${r.market_type || ""}`;
    if (!groups.has(key)) {
      groups.set(key, {
        matchId: String(r.match_id || ""),
        marketType: r.market_type || "",
        eventId: r.eventid != null ? String(r.eventid) : null,
        matchTitle: null,
        teamOne: null,
        teamTwo: null,
        totalEntries: 0,
        users: /* @__PURE__ */ new Set(),
        totalNetAmount: 0,
        settledAt: r.created_at
      });
    }
    const g = groups.get(key);
    g.totalEntries += 1;
    g.users.add(String(r.user_id));
    g.totalNetAmount = round22(g.totalNetAmount + netOf(r));
    if (r.created_at && new Date(r.created_at) > new Date(g.settledAt)) g.settledAt = r.created_at;
  }
  const bets = await SportsBet_default.findAll({
    where: { match_id: { [Op12.in]: [...new Set(live.map((r) => String(r.match_id)))] } },
    attributes: ["match_id", "market_type", "match_title", "team_one", "team_two"],
    raw: true
  });
  for (const b of bets) {
    const g = groups.get(`${b.match_id}|${b.market_type || ""}`);
    if (g && !g.matchTitle) {
      g.matchTitle = b.match_title || null;
      g.teamOne = b.team_one || null;
      g.teamTwo = b.team_two || null;
    }
  }
  let data = [...groups.values()].map((g) => ({
    matchId: g.matchId,
    marketType: g.marketType,
    eventId: g.eventId,
    matchTitle: g.matchTitle,
    teamOne: g.teamOne,
    teamTwo: g.teamTwo,
    totalEntries: g.totalEntries,
    totalUsers: g.users.size,
    totalNetAmount: g.totalNetAmount,
    settledAt: g.settledAt
  }));
  const term = String(search || "").trim().toLowerCase();
  if (term) {
    data = data.filter(
      (m) => [m.matchId, m.marketType, m.matchTitle, m.teamOne, m.teamTwo].some((v) => String(v ?? "").toLowerCase().includes(term))
    );
  }
  return { windowHours: VOID_WINDOW_HOURS, data: data.slice(off, off + lim) };
};
var listSettledBets = async ({ matchId, marketType }) => {
  if (!matchId) throw new Error("match_id is required");
  const rows = await CreditsLedger_default.findAll({
    where: {
      ...SETTLEMENT_WHERE,
      match_id: String(matchId),
      ...marketType ? { market_type: marketType } : {},
      created_at: { [Op12.gte]: since() }
    },
    order: [["id", "DESC"]],
    raw: true
  });
  if (!rows.length) return [];
  const voided = await voidedLedgerIds(rows);
  const live = rows.filter((r) => !voided.has(Number(r.id)));
  if (!live.length) return [];
  const userIds = [...new Set(live.map((r) => Number(r.user_id)))];
  const users = await User_default.findAll({
    where: { user_id: { [Op12.in]: userIds } },
    attributes: ["user_id", "username"],
    raw: true
  });
  const nameOf = new Map(users.map((u) => [Number(u.user_id), u.username]));
  const marketBets = await SportsBet_default.findAll({
    where: {
      match_id: String(matchId),
      ...marketType ? { market_type: marketType } : {},
      user_id: { [Op12.in]: userIds }
    },
    raw: true
  });
  return live.map((r) => {
    const mine = marketBets.filter((b) => Number(b.user_id) === Number(r.user_id));
    const anchor = mine.find((b) => Number(b.id) === Number(r.bet_id)) || mine[0] || null;
    return {
      ledgerId: Number(r.id),
      betId: Number(r.bet_id || anchor?.id || 0),
      userId: Number(r.user_id),
      username: nameOf.get(Number(r.user_id)) || `user_${r.user_id}`,
      // Ek ledger row poore market ko cover kar sakti hai (MO/BM) ya ek hi bet ko
      // (fancy/oddeven) — dono soorat me user ko saaf dikhe.
      selectionName: mine.length > 1 ? `${mine.length} bets` : anchor?.selection_name || "-",
      betType: anchor?.bet_type || "-",
      odds: anchor?.odds ?? null,
      stakeAmount: mine.reduce((s, b) => s + Number(b.stake_amount || 0), 0),
      netamount: netOf(r),
      cashDelta: round22(Number(r.netamount || 0)),
      resultStatus: netOf(r) > 0 ? "won" : netOf(r) < 0 ? "loss" : "settled",
      betCount: mine.length,
      settledAt: r.created_at
    };
  });
};
var voidSettledLedgerEntry = async (ledgerId, outerTx = null, { writeStatement = true } = {}) => {
  const id = Number(ledgerId);
  if (!Number.isFinite(id) || id <= 0) throw new Error("ledger_id is required");
  const transaction = outerTx || await db_default.transaction();
  let summary;
  try {
    const row = await CreditsLedger_default.findOne({
      where: { id, ...SETTLEMENT_WHERE },
      lock: transaction.LOCK.UPDATE,
      transaction
    });
    if (!row) throw new Error(`Settlement entry ${id} not found (already voided?)`);
    if (!row.created_at || new Date(row.created_at) < since()) {
      throw new Error(
        `Settlement is older than ${VOID_WINDOW_HOURS}h \u2014 it can only be voided within ${VOID_WINDOW_HOURS} hours`
      );
    }
    if ((await voidedLedgerIds([row.get({ plain: true })])).has(id)) {
      throw new Error(`Settlement ${id} is already voided`);
    }
    const userId = Number(row.user_id);
    const net = netOf(row);
    const wallet = await Wallet_default.findOne({
      where: { user_id: String(userId) },
      lock: transaction.LOCK.UPDATE,
      transaction
    });
    if (!wallet) throw new Error(`Wallet not found for user ${userId}`);
    const cashBefore = Number(wallet.cash || 0);
    const inrBefore = Number(wallet.inr_balance || 0);
    await wallet.update(
      { cash: round22(cashBefore - net), inr_balance: round22(inrBefore - net) },
      { transaction }
    );
    const counters = { profit: -net };
    if (net > 0) counters.net_win = -net;
    else if (net < 0) counters.net_loss = -net;
    await User_default.increment(counters, { where: { user_id: userId }, transaction });
    const sameMarket = await CreditsLedger_default.findAll({
      where: {
        ...SETTLEMENT_WHERE,
        user_id: String(userId),
        match_id: row.match_id,
        market_type: row.market_type,
        id: { [Op12.ne]: id }
      },
      attributes: ["bet_id"],
      raw: true,
      transaction
    });
    const claimedByOthers = sameMarket.map((r) => Number(r.bet_id)).filter(Boolean);
    const settledOnly = {
      status: "closed",
      result_status: { [Op12.in]: SETTLED_RESULT_STATUSES }
    };
    const scopeToOwnBet = isPerSelectionMarket(row.market_type) && Number(row.bet_id || 0) > 0;
    const betsBeforeVoid = await SportsBet_default.findAll({
      where: {
        user_id: userId,
        match_id: row.match_id,
        ...row.market_type ? { market_type: row.market_type } : {},
        ...settledOnly,
        ...scopeToOwnBet ? { id: Number(row.bet_id) } : claimedByOthers.length ? { id: { [Op12.notIn]: claimedByOthers } } : {}
      },
      transaction
    });
    const [betsVoided] = await SportsBet_default.update(
      { result_status: "void", status: "closed", updated_at: /* @__PURE__ */ new Date() },
      {
        where: {
          user_id: userId,
          match_id: row.match_id,
          ...row.market_type ? { market_type: row.market_type } : {},
          ...settledOnly,
          ...scopeToOwnBet ? { id: Number(row.bet_id) } : claimedByOthers.length ? { id: { [Op12.notIn]: claimedByOthers } } : {}
        },
        transaction
      }
    );
    if (writeStatement) {
      await CreditsLedger_default.create(
        {
          user_id: String(userId),
          currency: "INR",
          amount: -Number(row.netamount || 0),
          reason: "settlement_void",
          description: withVoidSuffix(row.description || `${row.match_id} / ${row.market_type || ""}`),
          netamount: -Number(row.netamount || 0),
          closing: round22(cashBefore - net),
          market_type: row.market_type || null,
          sport_id: row.sport_id || null,
          eventid: row.eventid || null,
          match_id: row.match_id || null,
          ...net > 0 ? { profit: -net } : { loss: -net },
          bet_id: row.bet_id || null,
          category: "SPORTS",
          points_applied: true,
          // Original row se pakka link — isi se list voided settlements ko chhupati hai
          meta: { reverses_ledger_id: id }
        },
        { transaction }
      );
    } else {
      await row.destroy({ transaction });
    }
    let commissionVoided = 0;
    let commissionRemark = null;
    let commissionSportId = null;
    let commissionGtype = null;
    const commRows = await CreditsLedger_default.findAll({
      where: {
        user_id: String(userId),
        category: "SPORTS",
        reason: COMMISSION_REASON,
        [Op12.and]: [db_default.literal(`(meta->>'commission_of_ledger_id') = '${Number(id)}'`)]
      },
      order: [["id", "ASC"]],
      lock: transaction.LOCK.UPDATE,
      transaction
    });
    for (const c of commRows) {
      const alreadyVoided = await CreditsLedger_default.findOne({
        where: {
          user_id: String(userId),
          reason: COMMISSION_VOID_REASON,
          [Op12.and]: [db_default.literal(`(meta->>'reverses_ledger_id') = '${Number(c.id)}'`)]
        },
        attributes: ["id"],
        transaction
      });
      if (alreadyVoided) continue;
      const comm = round22(Math.abs(Number(c.netamount ?? c.commission ?? 0)));
      if (!(comm > 0)) continue;
      commissionVoided = round22(commissionVoided + comm);
      commissionRemark = c.description || null;
      commissionSportId = c.sport_id || null;
      commissionGtype = c.meta?.gtype || null;
      await wallet.update(
        {
          cash: round22(Number(wallet.cash || 0) + comm),
          inr_balance: round22(Number(wallet.inr_balance || 0) + comm)
        },
        { transaction }
      );
      await User_default.increment({ net_loss: comm, profit: comm }, { where: { user_id: userId }, transaction });
      if (writeStatement) {
        await CreditsLedger_default.create(
          {
            user_id: String(userId),
            currency: "INR",
            amount: comm,
            reason: COMMISSION_VOID_REASON,
            description: withVoidSuffix(c.description || ""),
            netamount: comm,
            closing: round22(Number(wallet.cash || 0)),
            market_type: c.market_type || null,
            sport_id: c.sport_id || null,
            eventid: c.eventid || null,
            match_id: c.match_id || null,
            loss: comm,
            // reverses the commission row's loss = -comm
            bet_id: c.bet_id || null,
            category: "SPORTS",
            points_applied: true,
            meta: { reverses_ledger_id: Number(c.id), commission_of_ledger_id: Number(id) }
          },
          { transaction }
        );
      } else {
        await c.destroy({ transaction });
      }
    }
    summary = {
      ledgerId: id,
      writeStatement,
      userId,
      matchId: String(row.match_id || ""),
      marketType: row.market_type || "",
      betId: Number(row.bet_id || 0),
      net,
      betsVoided,
      cashBefore,
      cashAfter: round22(cashBefore - net + commissionVoided),
      inrBefore,
      inrAfter: round22(inrBefore - net + commissionVoided),
      commissionVoided,
      commissionRemark,
      commissionSportId,
      commissionGtype
    };
    const totalExposureAfter = await recalcTotalExposure(userId, transaction);
    await recordVoidAudit({
      voidGroupId: newVoidGroupId(),
      voidType: VOID_TYPES.AFTER_SETTLEMENT,
      bets: betsBeforeVoid,
      representativeBetId: Number(row.bet_id) || null,
      before: {
        cash: cashBefore,
        inr: inrBefore,
        totalExposure: null
        // settled bets hold no exposure row to read
      },
      after: {
        status: "closed",
        resultStatus: "void",
        cash: summary.cashAfter,
        inr: summary.inrAfter,
        totalExposure: totalExposureAfter
      },
      refundAmount: -net,
      ledgerId: id,
      context: {
        // Audit hamesha likhti hai — silent void par bhi. Statement se rows hat
        // jaati hain, par yahan (aur activity log me) poora trail rehta hai.
        note: `settlement void \u2014 reverses credits_ledger #${id} (net ${net})` + (commissionVoided > 0 ? `; commission ${commissionVoided} refunded` : "") + (writeStatement ? "" : "; SILENT (statement entries deleted)")
      }
    }, transaction);
    if (!outerTx) await transaction.commit();
  } catch (error) {
    if (!outerTx) await transaction.rollback();
    throw error;
  }
  if (outerTx) return summary;
  return { ...summary, points: await reversePointsAndEmit(summary) };
};
var reversePointsAndEmit = async (summary) => {
  if (!summary?.betId) return { success: true, skipped: true, reason: "no bet_id on ledger row" };
  if (summary.writeStatement === false) {
    const del = await walletService_default.deletePointEntries(
      pointEntryRef.bet(POINT_CATEGORY.SPORTS, summary.betId)
    );
    if (!del.success) console.error("[sportsVoid] point delete failed:", summary.betId, del.error);
    if (Number(summary.commissionVoided) > 0) {
      const cdel = await walletService_default.deletePointEntries(
        pointEntryRef.commission(POINT_CATEGORY.SPORTS, summary.betId)
      );
      if (!cdel.success) console.error("[sportsVoid] commission point delete failed:", summary.betId, cdel.error);
      del.commission = cdel;
    }
    try {
      const fresh = await Wallet_default.findOne({ where: { user_id: String(summary.userId) }, raw: true });
      emitBalanceUpdate(summary.userId, { inr_balance: fresh?.inr_balance, cash: fresh?.cash });
    } catch (err) {
      console.error("[sportsVoid] balance emit failed:", summary.userId, err.message);
    }
    return del;
  }
  const res = await walletService_default.reverseAllPointHierarchy(summary.betId, POINT_CATEGORY.SPORTS);
  if (!res.success) console.error("[sportsVoid] point reversal failed:", summary.betId, res.error);
  if (Number(summary.commissionVoided) > 0) {
    const cres = await walletService_default.reverseCommissionPoints({
      betId: summary.betId,
      userId: summary.userId,
      amount: summary.commissionVoided,
      remark: withVoidSuffix(summary.commissionRemark || ""),
      sportId: summary.commissionSportId,
      gtype: summary.commissionGtype
    });
    if (!cres.success) console.error("[sportsVoid] commission point reversal failed:", summary.betId, cres.error);
    res.commission = cres;
  }
  try {
    const fresh = await Wallet_default.findOne({ where: { user_id: String(summary.userId) }, raw: true });
    emitBalanceUpdate(summary.userId, { inr_balance: fresh?.inr_balance, cash: fresh?.cash });
  } catch (err) {
    console.error("[sportsVoid] balance emit failed:", summary.userId, err.message);
  }
  return res;
};
var voidSettledMarket = async ({ matchId, marketType, writeStatement = true }) => {
  if (!matchId) throw new Error("match_id is required");
  const rows = await CreditsLedger_default.findAll({
    where: {
      ...SETTLEMENT_WHERE,
      match_id: String(matchId),
      ...marketType ? { market_type: marketType } : {},
      created_at: { [Op12.gte]: since() }
    },
    order: [["id", "ASC"]],
    raw: true
  });
  const alreadyVoided = await voidedLedgerIds(rows);
  const pending = rows.filter((r) => !alreadyVoided.has(Number(r.id)));
  if (!pending.length) {
    throw new Error(
      rows.length ? "This market is already voided" : `No settlement entries found for this market in the last ${VOID_WINDOW_HOURS}h`
    );
  }
  const transaction = await db_default.transaction();
  const summaries = [];
  try {
    for (const r of pending) {
      summaries.push(await voidSettledLedgerEntry(r.id, transaction, { writeStatement }));
    }
    await transaction.commit();
  } catch (error) {
    await transaction.rollback();
    throw error;
  }
  for (const s of summaries) {
    s.points = await reversePointsAndEmit(s);
  }
  return {
    affectedUsers: new Set(summaries.map((s) => s.userId)).size,
    entries: summaries.length,
    summaries
  };
};

// mannualSettle/controller.js
var recordManualVoidRefund = (args, t) => recordVoidRefund(args, t);
var parseRunners = (raw) => {
  if (!raw) return null;
  if (Array.isArray(raw)) return raw.length ? raw : null;
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length ? parsed : null;
  } catch {
    return null;
  }
};
var getMoMatches = async (req, res) => {
  const limit = parseInt(req.query.limit, 10) || 100;
  const offset = parseInt(req.query.offset, 10) || 0;
  try {
    const rows = await SportsBet_default.findAll({
      attributes: [
        "match_id",
        "eventid",
        "game_type",
        "market_type",
        [fn("MAX", col("match_title")), "match_title"],
        [fn("MAX", col("team_one")), "team_one"],
        [fn("MAX", col("team_two")), "team_two"],
        [fn("COUNT", col("*")), "totalbets"],
        [fn("MAX", col("counts")), "counts"],
        // Same bug getFanOpenBets fixed below: without the runner list
        // the declare modal falls back to [team_one, team_two], so a
        // 3-way market's draw has no button and cannot be declared.
        // `runners` is json, which has no MAX aggregate in Postgres —
        // cast to text here and parse it back in the mapper.
        [literal("MAX(runners::text)"), "runners"]
      ],
      where: {
        game_type: { [Op13.or]: ["MO", "BM"] },
        status: "open",
        match_id: { [Op13.ne]: null },
        eventid: { [Op13.ne]: null }
      },
      group: ["match_id", "eventid", "game_type", "market_type"],
      order: [[fn("MAX", col("created_at")), "DESC"]],
      limit,
      offset,
      raw: true
    });
    const payload = rows.map((r) => ({
      matchId: r.match_id,
      eventId: r.eventid,
      gameType: r.game_type,
      marketType: r.market_type,
      matchTitle: r.match_title,
      teamOne: r.team_one,
      teamTwo: r.team_two,
      totalBets: parseInt(r.totalbets, 10),
      counts: r.counts !== null ? Number(r.counts) : null,
      runners: parseRunners(r.runners)
    }));
    return res.json({ success: true, data: payload });
  } catch (err) {
    console.error("getMoMatches error:", err);
    return res.status(500).json({ success: false, error: err.message });
  }
};
var getFanOpenBets = async (req, res) => {
  const limit = parseInt(req.query.limit, 10) || void 0;
  const offset = parseInt(req.query.offset, 10) || void 0;
  const marketsforfancy = [
    "1st Innings 6 Overs Line",
    "2nd Innings 6 Overs Line",
    "3rd Innings 6 Overs Line",
    "1st Innings 50 Overs Line",
    "2nd Innings 50 Overs Line",
    "3rd Innings 50 Overs Line",
    "1st Innings 40 Overs Line",
    "2nd Innings 40 Overs Line",
    "3rd Innings 40 Overs Line",
    "1st Innings 30 Overs Line",
    "2nd Innings 30 Overs Line",
    "3rd Innings 30 Overs Line",
    "1st Innings 20 Overs Line",
    "2nd Innings 20 Overs Line",
    "3rd Innings 20 Overs Line",
    "1st Innings 10 Overs Line",
    "2nd Innings 10 Overs Line",
    "3rd Innings 10 Overs Line",
    "Over By Over",
    "Ball By Ball",
    "Normal",
    "khado",
    "meter",
    "fancy1",
    "oddeven",
    "badlo"
  ];
  try {
    const groups = await SportsBet_default.findAll({
      attributes: [
        "match_id",
        "eventid",
        "match_id",
        "eventid",
        "market_type",
        "selection_name",
        "game_type",
        [fn("MAX", col("match_title")), "match_title"],
        [fn("COUNT", col("*")), "totalbets"],
        [fn("MAX", col("counts")), "counts"]
      ],
      where: {
        // game_type: 'FAN', // Removed to follow previous pattern if user wants mo/bm here too? NO, user said "getFanOpenBets". Let's assume FAN only unless told.
        // Wait, "gametype should come proper".
        // I will include game_type in attributes.
        game_type: "FAN",
        status: "open",
        match_id: { [Op13.ne]: null },
        eventid: { [Op13.ne]: null }
        // removed strict market_type filter to include others
      },
      group: ["match_id", "eventid", "market_type", "selection_name", "game_type"],
      order: [[fn("MAX", col("created_at")), "DESC"]],
      limit,
      offset,
      raw: true
    });
    if (!groups.length) {
      return res.json({ success: true, data: { fancy1: [], others: [] } });
    }
    const criteria = groups.map((g) => ({
      match_id: g.match_id,
      eventid: g.eventid,
      market_type: g.market_type,
      selection_name: g.selection_name,
      game_type: g.game_type
    }));
    const bets = await SportsBet_default.findAll({
      where: limit ? { status: "open", [Op13.or]: criteria } : { game_type: "FAN", status: "open", match_id: { [Op13.ne]: null }, eventid: { [Op13.ne]: null } },
      order: [["created_at", "ASC"]],
      raw: true
    });
    const groupMap = /* @__PURE__ */ new Map();
    groups.forEach((g) => {
      let mType = g.market_type;
      let groupKey = mType;
      if (!marketsforfancy.includes(mType)) {
        groupKey = "others";
      }
      const key = `${g.match_id}||${g.eventid}||${mType}||${g.game_type}||${g.selection_name}`;
      if (groupMap.has(key)) {
        const existing = groupMap.get(key);
        existing.totalBets += parseInt(g.totalbets, 10);
      } else {
        groupMap.set(key, {
          groupKey,
          matchId: g.match_id,
          eventId: g.eventid,
          matchTitle: g.match_title,
          marketType: mType,
          // Original type
          selectionName: g.selection_name,
          gameType: g.game_type,
          totalBets: parseInt(g.totalbets, 10),
          counts: g.counts !== null ? Number(g.counts) : null,
          bets: []
        });
      }
    });
    bets.forEach((b) => {
      let mType = b.market_type;
      const key = `${b.match_id}||${b.eventid}||${mType}||${b.game_type}||${b.selection_name}`;
      const bucket = groupMap.get(key);
      if (bucket) {
        bucket.bets.push({
          id: b.id,
          userId: b.user_id,
          betType: b.bet_type,
          selectionName: b.selection_name,
          marketType: b.market_type,
          gameType: b.game_type,
          teamOne: b.team_one,
          teamTwo: b.team_two,
          odds: b.odds !== null ? Number(b.odds) : null,
          stakeAmount: b.stake_amount !== null ? Number(b.stake_amount) : null,
          originalCurrency: b.original_currency,
          originalAmount: b.original_amount !== null ? Number(b.original_amount) : null,
          usdAmount: b.usd_amount !== null ? Number(b.usd_amount) : null,
          liability: b.liability !== null ? Number(b.liability) : null,
          status: b.status,
          createdAt: b.created_at,
          counts: b.counts !== null ? Number(b.counts) : null,
          // The declare modal offers ONE BUTTON PER RUNNER when the
          // bet carries a runner list ("0 Number" … "9 Number", a
          // 10-way market). Without this field it saw `undefined`,
          // fell back to [team_one, 'Draw', team_two] on counts >= 3,
          // and an operator could only ever declare the first runner,
          // a draw, or the second — the other 8 were unreachable.
          // Sequelize returns this JSON column already parsed.
          runners: b.runners || null
        });
      }
    });
    const payload = {};
    marketsforfancy.forEach((m) => {
      payload[m] = [];
    });
    payload["others"] = [];
    for (const val of groupMap.values()) {
      const listKey2 = val.groupKey;
      delete val.groupKey;
      if (payload[listKey2]) {
        payload[listKey2].push(val);
      } else {
        payload["others"].push(val);
      }
    }
    return res.json({ success: true, data: payload });
  } catch (err) {
    console.error("getFanOpenBets error:", err);
    return res.status(500).json({ success: false, error: err.message });
  }
};
var declareResult = async (req, res) => {
  const { eventid, match_id, match_title, game_type, market_type, winnerName, winnerId, fancyName } = req.body;
  if (!eventid || !match_id || !match_title || !game_type || !market_type) {
    return res.status(400).json({
      success: false,
      error: "Missing required fields: eventid, match_id, match_title, game_type, market_type"
    });
  }
  if (["MO", "BM"].includes(game_type)) {
    if (!winnerName) {
      return res.status(400).json({ success: false, error: "winnerName is required for MO and BM" });
    }
  } else if (game_type === "FAN") {
    const marketsforfancy = [
      "1st Innings 6 Overs Line",
      "2nd Innings 6 Overs Line",
      "3rd Innings 6 Overs Line",
      "1st Innings 50 Overs Line",
      "2nd Innings 50 Overs Line",
      "3rd Innings 50 Overs Line",
      "1st Innings 40 Overs Line",
      "2nd Innings 40 Overs Line",
      "3rd Innings 40 Overs Line",
      "1st Innings 30 Overs Line",
      "2nd Innings 30 Overs Line",
      "3rd Innings 30 Overs Line",
      "1st Innings 20 Overs Line",
      "2nd Innings 20 Overs Line",
      "3rd Innings 20 Overs Line",
      "1st Innings 10 Overs Line",
      "2nd Innings 10 Overs Line",
      "3rd Innings 10 Overs Line",
      "Over By Over",
      "Ball By Ball",
      "Normal",
      "khado",
      "meter",
      "badlo"
    ];
    const lineMarket = isLineMarket(market_type);
    if (lineMarket && !/^\d+$/.test(String(winnerId ?? "").trim())) {
      return res.status(400).json({ success: false, error: "winnerId must be the run total (a whole number) for a line market" });
    }
    if (marketsforfancy.includes(market_type) || lineMarket) {
      if (["fancy1", "oddeven"].includes(market_type)) {
        if (!winnerName) {
          return res.status(400).json({ success: false, error: "winnerName is required for this fancy market" });
        }
      } else {
        if (!winnerId) {
          return res.status(400).json({ success: false, error: "winnerId is required for this fancy market" });
        }
      }
      if (!fancyName) {
        return res.status(400).json({ success: false, error: "fancyName is required for this fancy market" });
      }
    } else {
      if (!winnerName) {
        return res.status(400).json({ success: false, error: "winnerName is required for this fancy market" });
      }
    }
  }
  const t = await db_default.transaction();
  try {
    const newResult = await manualresult_default.create({
      eventid,
      match_id,
      match_title,
      game_type,
      market_type,
      winnerName: winnerName || null,
      winnerId: winnerId || null,
      fancyName: fancyName || null
    }, { transaction: t });
    const [updatedCount] = await SportsBet_default.update(
      { status: "manual" },
      {
        where: {
          match_id,
          market_type,
          game_type,
          status: "open",
          ...["fancy1", "oddeven", "Over By Over", "Ball By Ball", "khado", "meter", "Normal", "badlo"].includes(market_type) ? { selection_name: fancyName } : {}
        },
        transaction: t
      }
    );
    await t.commit();
    let settlement = null;
    try {
      settlement = await enqueueManualBets({
        eventid,
        match_id,
        market_type,
        log: { info: console.log, error: console.error, debug: () => {
        } }
      });
    } catch (e) {
      console.error("declareResult: settlement enqueue failed", e.message);
    }
    return res.json({
      success: true,
      message: "Result declared successfully",
      data: {
        manualResult: newResult,
        updatedBets: updatedCount,
        settlement
      }
    });
  } catch (error) {
    await t.rollback();
    console.error("declareResult error:", error);
    return res.status(500).json({
      success: false,
      error: error.message || "Internal Server Error"
    });
  }
};
var voidResult = async (req, res) => {
  const { eventid, match_id, market_type, gametype, selection_name } = req.body;
  if (!eventid || !match_id || !market_type) {
    return res.status(400).json({
      success: false,
      error: "Missing required fields: eventid, match_id, market_type"
    });
  }
  try {
    const { userIds, betsVoided, voidGroupId } = await voidOpenMarket({
      match_id,
      market_type,
      gametype,
      selection_name,
      voidType: VOID_TYPES.MARKET,
      context: actorFrom(req)
    });
    return res.json({
      success: true,
      message: "Voided successfully",
      count: userIds.length,
      betsVoided,
      voidGroupId
    });
  } catch (error) {
    console.error("voidResult error:", error);
    return res.status(500).json({
      success: false,
      error: error.message || "Internal Server Error"
    });
  }
};
var getOpenBetsForMarket = async (req, res) => {
  const { match_id, market_type, game_type, selection_name } = req.query;
  if (!match_id || !market_type) {
    return res.status(400).json({
      success: false,
      error: "match_id and market_type are required"
    });
  }
  try {
    const whereClause = { match_id, market_type, status: "open" };
    if (game_type) whereClause.game_type = game_type;
    if (selection_name) whereClause.selection_name = selection_name;
    const bets = await SportsBet_default.findAll({
      where: whereClause,
      order: [["created_at", "DESC"]],
      raw: true
    });
    const userIds = [...new Set(bets.map((b) => b.user_id).filter(Boolean))];
    const userMap = {};
    if (userIds.length > 0) {
      const users = await User_default.findAll({
        where: { user_id: { [Op13.in]: userIds } },
        attributes: ["user_id", "username"],
        raw: true
      });
      users.forEach((u) => {
        userMap[u.user_id] = u.username;
      });
    }
    const data = bets.map((b) => ({
      id: b.id,
      userId: b.user_id,
      username: userMap[b.user_id] || null,
      betType: b.bet_type,
      selectionName: b.selection_name,
      marketType: b.market_type,
      gameType: b.game_type,
      odds: b.odds !== null ? Number(b.odds) : null,
      stakeAmount: b.stake_amount !== null ? Number(b.stake_amount) : null,
      liability: b.liability !== null ? Number(b.liability) : null,
      status: b.status,
      matchId: b.match_id,
      eventId: b.eventid,
      createdAt: b.created_at
    }));
    return res.json({ success: true, data });
  } catch (error) {
    console.error("getOpenBetsForMarket error:", error);
    return res.status(500).json({
      success: false,
      error: error.message || "Internal Server Error"
    });
  }
};
var voidSingleOpenBet = async (req, res) => {
  const { bet_id } = req.body;
  if (!bet_id) {
    return res.status(400).json({ success: false, error: "bet_id is required" });
  }
  const t = await db_default.transaction();
  try {
    const bet = await SportsBet_default.findOne({
      where: { id: bet_id, status: "open" },
      transaction: t
    });
    if (!bet) {
      await t.rollback();
      return res.status(404).json({ success: false, error: "Open bet not found" });
    }
    const uid = bet.user_id;
    const match_id = bet.match_id;
    const market_type = bet.market_type;
    const walletBefore = await Wallet_default.findOne({
      where: { user_id: uid },
      attributes: ["cash", "inr_balance"],
      transaction: t
    });
    const snapBefore = await TotalExposure_default.findOne({
      where: { user_id: uid },
      attributes: ["total_exposure"],
      transaction: t
    });
    const badlo = isBadloBet(bet);
    const { game_type: expGameType, team_name: sel } = exposureIdentity({
      marketType: market_type,
      selectionName: bet.selection_name,
      badlo
    });
    const perSelection = isPerSelectionMarket(market_type) || badlo;
    const otherBets = await SportsBet_default.count({
      where: {
        match_id,
        market_type,
        user_id: uid,
        status: "open",
        id: { [Op13.ne]: bet_id },
        ...perSelection ? { selection_name: bet.selection_name, badlo } : {}
      },
      transaction: t
    });
    let refundAmount = 0;
    let ledgerId = null;
    let exposureRowsDeleted = 0;
    let exposureBefore = null;
    if (otherBets === 0) {
      const exposureWhere = {
        user_id: uid,
        match_id,
        // Line markets file their rows under 'fancy2', keyed by the
        // market name rather than the runner — see helper/lineMarket.js.
        game_type: expGameType,
        // …and for a per-selection market, ONLY this selection's four
        // rows. Without this the destroy would wipe every other open
        // session of the same market_type and leave them unblocked.
        ...perSelection ? { team_name: { [Op13.in]: selectionExposureRows(sel) } } : {}
      };
      const exposures = await UserExposure_default.findAll({
        where: exposureWhere,
        transaction: t
      });
      if (exposures.length > 0) {
        const minExp = releasableLiability(exposures, { perSelection, sel });
        exposureBefore = minExp;
        if (minExp < 0) {
          refundAmount = Math.abs(minExp);
          await Wallet_default.increment("cash", {
            by: refundAmount,
            where: { user_id: uid },
            transaction: t
          });
          ledgerId = await recordManualVoidRefund({
            uid,
            refundAmount,
            bet,
            // the single bet being voided
            actor: req.user?.actor?.username || req.user?.username
          }, t);
        }
        exposureRowsDeleted = await UserExposure_default.destroy({ where: exposureWhere, transaction: t });
      }
    }
    await SportsBet_default.update(
      {
        status: "closed",
        result_status: "refunded",
        match_end_time: /* @__PURE__ */ new Date()
      },
      { where: { id: bet_id }, transaction: t }
    );
    const totalAfter = await recalcTotalExposure(uid, t);
    const walletAfter = await Wallet_default.findOne({
      where: { user_id: uid },
      attributes: ["cash", "inr_balance"],
      transaction: t
    });
    await recordVoidAudit({
      voidGroupId: newVoidGroupId(),
      voidType: VOID_TYPES.OPEN_BET,
      bets: [bet],
      representativeBetId: bet.id,
      before: {
        status: "open",
        resultStatus: bet.result_status,
        cash: walletBefore?.cash,
        inr: walletBefore?.inr_balance,
        exposure: exposureBefore,
        totalExposure: snapBefore?.total_exposure
      },
      after: {
        status: "closed",
        resultStatus: "refunded",
        cash: walletAfter?.cash,
        inr: walletAfter?.inr_balance,
        // The bucket is gone when rows were destroyed; when the gate
        // held it is untouched and still equals the pre value.
        exposure: exposureRowsDeleted > 0 ? 0 : exposureBefore,
        totalExposure: totalAfter
      },
      refundAmount,
      exposureRowsDeleted,
      ledgerId,
      context: {
        ...actorFrom(req),
        note: otherBets > 0 ? `exposure retained \u2014 ${otherBets} other open bet(s) still hold this bucket` : null
      }
    }, t);
    await t.commit();
    return res.json({
      success: true,
      message: "Bet voided successfully",
      betId: bet_id,
      userId: uid,
      refunded: refundAmount
    });
  } catch (error) {
    await t.rollback();
    console.error("voidSingleOpenBet error:", error);
    return res.status(500).json({
      success: false,
      error: error.message || "Internal Server Error"
    });
  }
};
var getSettledMarkets = async (req, res) => {
  try {
    const { data, windowHours } = await listSettledMarkets({
      search: req.query.search || "",
      limit: req.query.limit,
      offset: req.query.offset
    });
    return res.json({ success: true, windowHours, data });
  } catch (error) {
    console.error("getSettledMarkets error:", error);
    return res.status(500).json({ success: false, error: error.message || "Internal Server Error" });
  }
};
var getSettledBets = async (req, res) => {
  try {
    const data = await listSettledBets({
      matchId: req.query.match_id,
      marketType: req.query.market_type
    });
    return res.json({ success: true, data });
  } catch (error) {
    console.error("getSettledBets error:", error);
    return res.status(400).json({ success: false, error: error.message || "Internal Server Error" });
  }
};
var voidBetAfterSettlement = async (req, res) => {
  const ledgerId = req.body?.ledger_id;
  const writeStatement = req.body?.write_statement !== false;
  if (!ledgerId) return res.status(400).json({ success: false, error: "ledger_id is required" });
  try {
    const result = await voidSettledLedgerEntry(ledgerId, null, { writeStatement });
    await ActivityLogService_default.log({
      req,
      user: { id: req.user?.account?.id, username: req.user?.username, role: req.user?.role },
      action: "SPORTS_BET_VOID_AFTER_SETTLEMENT",
      details: result
    });
    return res.json({
      success: true,
      message: `Settlement voided \u2014 cash ${result.cashBefore} -> ${result.cashAfter}, inr ${result.inrBefore} -> ${result.inrAfter}, ${result.betsVoided} bet(s) marked void`,
      ...result
    });
  } catch (error) {
    console.error("voidBetAfterSettlement error:", error);
    return res.status(400).json({ success: false, error: error.message || "Internal Server Error" });
  }
};
var voidMarketAfterSettlement = async (req, res) => {
  const { match_id, market_type } = req.body || {};
  const writeStatement = req.body?.write_statement !== false;
  if (!match_id) return res.status(400).json({ success: false, error: "match_id is required" });
  try {
    const result = await voidSettledMarket({ matchId: match_id, marketType: market_type, writeStatement });
    await ActivityLogService_default.log({
      req,
      user: { id: req.user?.account?.id, username: req.user?.username, role: req.user?.role },
      action: "SPORTS_MARKET_VOID_AFTER_SETTLEMENT",
      details: { match_id, market_type, writeStatement, affectedUsers: result.affectedUsers, entries: result.entries }
    });
    return res.json({
      success: true,
      message: `${result.entries} settlement entries voided across ${result.affectedUsers} user(s)`,
      ...result
    });
  } catch (error) {
    console.error("voidMarketAfterSettlement error:", error);
    return res.status(400).json({ success: false, error: error.message || "Internal Server Error" });
  }
};
var controller2 = {
  getMoMatches,
  getFanOpenBets,
  declareResult,
  voidResult,
  getOpenBetsForMarket,
  voidSingleOpenBet,
  getSettledMarkets,
  getSettledBets,
  voidBetAfterSettlement,
  voidMarketAfterSettlement
};
var controller_default = controller2;

// controller/admin/betLockController.js
import { Op as Op14 } from "sequelize";
var toBool = (value) => {
  return value === true || value === "true" || value === 1 || value === "1";
};
var successResponse = (res, message, data = null, count = null) => {
  const response = { success: true, message };
  if (data !== null) response.data = data;
  if (count !== null) response.count = count;
  return res.status(200).json(response);
};
var errorResponse = (res, message, status = 500) => {
  return res.status(status).json({ success: false, error: message });
};
var buildMarketWhere = (event_id, market_id, market_name) => {
  const where = { event_id: String(event_id) };
  if (market_id) {
    where.market_id = String(market_id);
  } else if (market_name) {
    where.market_name = market_name;
  }
  return where;
};
var getMarketLockChildren = async (req, res) => {
  try {
    const { event_id } = req.params;
    const { market_id, market_name } = req.query;
    const loggedInRole = req.user?.role?.toUpperCase();
    const loggedInId = req.user?.account?.id;
    console.log("[BetLock] getMarketLockChildren:", { event_id, market_id, market_name, loggedInRole, loggedInId });
    if (!event_id) {
      return errorResponse(res, "event_id is required", 400);
    }
    if (!market_id && !market_name) {
      return errorResponse(res, "market_id or market_name is required", 400);
    }
    let children = [];
    if (loggedInRole === "OWNER") {
      const staffChildren = await Staff_default.findAll({
        where: { parent_owner_id: loggedInId },
        attributes: ["staff_id", "username", "role", "level"],
        raw: true
      });
      const userChildren = await User_default.findAll({
        where: { parent_owner_id: loggedInId },
        attributes: ["user_id", "username"],
        raw: true
      });
      children = [
        ...staffChildren.map((s) => ({ id: s.staff_id, username: s.username, type: "staff", role: s.role, level: s.level })),
        ...userChildren.map((u) => ({ id: u.user_id, username: u.username, type: "user", role: "USER" }))
      ];
    } else {
      const staffChildren = await Staff_default.findAll({
        where: { parent_id: loggedInId },
        attributes: ["staff_id", "username", "role", "level"],
        raw: true
      });
      const userChildren = await User_default.findAll({
        where: { parent_staff_id: loggedInId },
        attributes: ["user_id", "username"],
        raw: true
      });
      children = [
        ...staffChildren.map((s) => ({ id: s.staff_id, username: s.username, type: "staff", role: s.role, level: s.level })),
        ...userChildren.map((u) => ({ id: u.user_id, username: u.username, type: "user", role: "USER" }))
      ];
    }
    const accountIds = children.map((c) => c.id);
    if (accountIds.length === 0) {
      return successResponse(res, "No children found", [], 0);
    }
    const lockWhere = {
      account_id: { [Op14.in]: accountIds },
      ...buildMarketWhere(event_id, market_id, market_name),
      is_locked: true
    };
    const existingLocks = await UserEventMarketLocks_default.findAll({
      where: lockWhere,
      attributes: ["account_id", "account_type"],
      raw: true
    });
    const lockedSet = new Set(existingLocks.map((l) => `${l.account_type}_${l.account_id}`));
    const result = children.map((c) => ({
      ...c,
      is_locked: lockedSet.has(`${c.type}_${c.id}`)
    }));
    return successResponse(res, "Market lock children retrieved", result, result.length);
  } catch (error) {
    console.error("getMarketLockChildren error:", error);
    return errorResponse(res, "Failed to fetch market lock children");
  }
};
var toggleMarketLock = async (req, res) => {
  try {
    const { account_id, account_type, event_id, market_id, market_name, is_locked } = req.body;
    const loggedInId = req.user?.account?.id;
    if (!account_id || !account_type || !event_id) {
      return errorResponse(res, "account_id, account_type, and event_id are required", 400);
    }
    if (!market_id && !market_name) {
      return errorResponse(res, "market_id or market_name is required", 400);
    }
    if (!["staff", "user"].includes(account_type)) {
      return errorResponse(res, "account_type must be 'staff' or 'user'", 400);
    }
    const lock = toBool(is_locked);
    const findWhere = {
      account_id,
      account_type,
      event_id: String(event_id),
      ...market_id ? { market_id: String(market_id) } : { market_name }
    };
    if (lock) {
      const [record, created] = await UserEventMarketLocks_default.findOrCreate({
        where: findWhere,
        defaults: {
          is_locked: true,
          locked_by: loggedInId,
          market_id: market_id ? String(market_id) : null,
          market_name: market_name || null
        }
      });
      if (!created) {
        await record.update({ is_locked: true, locked_by: loggedInId });
      }
      return successResponse(res, "Market locked successfully", record);
    } else {
      await UserEventMarketLocks_default.destroy({ where: findWhere });
      return successResponse(res, "Market unlocked successfully");
    }
  } catch (error) {
    console.error("toggleMarketLock error:", error);
    return errorResponse(res, "Failed to toggle market lock");
  }
};
var bulkToggleMarketLock = async (req, res) => {
  try {
    const { accounts, event_id, market_id, market_name, is_locked } = req.body;
    const loggedInId = req.user?.account?.id;
    console.log("[BetLock] bulkToggleMarketLock:", { accounts_count: accounts?.length, event_id, market_id, market_name, is_locked, loggedInId });
    if (!Array.isArray(accounts) || accounts.length === 0 || !event_id) {
      return errorResponse(res, "accounts array and event_id are required", 400);
    }
    if (!market_id && !market_name) {
      return errorResponse(res, "market_id or market_name is required", 400);
    }
    const lock = toBool(is_locked);
    let processed = 0;
    for (const acc of accounts) {
      const { account_id, account_type } = acc;
      if (!account_id || !account_type) continue;
      const findWhere = {
        account_id,
        account_type,
        event_id: String(event_id),
        ...market_id ? { market_id: String(market_id) } : { market_name }
      };
      if (lock) {
        const [record, created] = await UserEventMarketLocks_default.findOrCreate({
          where: findWhere,
          defaults: {
            is_locked: true,
            locked_by: loggedInId,
            market_id: market_id ? String(market_id) : null,
            market_name: market_name || null
          }
        });
        if (!created) {
          await record.update({ is_locked: true, locked_by: loggedInId });
        }
      } else {
        await UserEventMarketLocks_default.destroy({ where: findWhere });
      }
      processed++;
    }
    return successResponse(res, `${processed} accounts ${lock ? "locked" : "unlocked"} successfully`, null, processed);
  } catch (error) {
    console.error("bulkToggleMarketLock error:", error);
    return errorResponse(res, "Failed to bulk toggle market locks");
  }
};

// controller/admin/bettingConfigController.js
import { Op as Op15 } from "sequelize";

// model/admin/AutoVoidConfig.js
init_db();
import { DataTypes as DataTypes36 } from "sequelize";
var AutoVoidConfig = db_default.define("AutoVoidConfig", {
  id: {
    type: DataTypes36.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  enabled: {
    type: DataTypes36.BOOLEAN,
    allowNull: false,
    defaultValue: false
  },
  delay_seconds: {
    type: DataTypes36.INTEGER,
    allowNull: false,
    defaultValue: 600,
    comment: "seconds after the anchor result is first seen before the void fires"
  },
  on_match_odds: {
    type: DataTypes36.BOOLEAN,
    allowNull: false,
    defaultValue: true,
    comment: "a settled/void MATCH_ODDS market starts the timer"
  },
  on_bookmaker: {
    type: DataTypes36.BOOLEAN,
    allowNull: false,
    defaultValue: true,
    comment: "a settled/void BOOKMAKER market starts the timer"
  },
  enabled_at: {
    type: DataTypes36.DATE,
    allowNull: true,
    comment: "last OFF -> ON switch; a void never fires before enabled_at + delay"
  }
}, {
  tableName: "auto_void_config",
  timestamps: true
});
var AUTO_VOID_ROW_ID = 1;
var AUTO_VOID_MIN_DELAY = 30;
var AUTO_VOID_MAX_DELAY = 24 * 3600;
var getAutoVoidConfig = async () => {
  const [row] = await AutoVoidConfig.findOrCreate({
    where: { id: AUTO_VOID_ROW_ID },
    defaults: { id: AUTO_VOID_ROW_ID }
  });
  return row;
};

// sportsbet/betresult/autoVoid.js
init_db();

// model/user/SportsAutoVoidState.js
init_db();
import { DataTypes as DataTypes37 } from "sequelize";
var SportsAutoVoidState = db_default.define("SportsAutoVoidState", {
  eventid: {
    type: DataTypes37.STRING,
    primaryKey: true
  },
  sport_id: {
    type: DataTypes37.STRING,
    allowNull: true
  },
  match_title: {
    type: DataTypes37.STRING,
    allowNull: true
  },
  anchor_market: {
    type: DataTypes37.STRING(32),
    allowNull: false,
    comment: "MATCH_ODDS | BOOKMAKER \u2014 the feed market that started the timer"
  },
  anchor_status: {
    type: DataTypes37.STRING(16),
    allowNull: false,
    comment: "SETTLE | VOID as the feed reported it"
  },
  anchor_seen_at: {
    type: DataTypes37.DATE,
    allowNull: false
  },
  last_fired_at: {
    type: DataTypes37.DATE,
    allowNull: true
  },
  fire_count: {
    type: DataTypes37.INTEGER,
    allowNull: false,
    defaultValue: 0
  },
  bets_voided: {
    type: DataTypes37.INTEGER,
    allowNull: false,
    defaultValue: 0
  },
  void_group_ids: {
    type: DataTypes37.JSONB,
    allowNull: true,
    comment: "bet_void_audit.void_group_id of every group this row fired"
  },
  last_error: {
    type: DataTypes37.TEXT,
    allowNull: true
  }
}, {
  tableName: "sports_auto_void_state",
  timestamps: true
});

// sportsbet/betresult/autoVoid.js
var CONFIG_TTL_MS = +(process.env.AUTO_VOID_CONFIG_TTL_MS || 1e4);
function voidDueAt(anchorSeenAt, c) {
  const seen = new Date(anchorSeenAt).getTime();
  const on = c?.enabled_at ? new Date(c.enabled_at).getTime() : 0;
  const delayMs = Math.max(0, Number(c?.delay_seconds) || 0) * 1e3;
  return new Date(Math.max(seen, on) + delayMs);
}

// model/admin/ResultSourceLink.js
init_db();
import { DataTypes as DataTypes38 } from "sequelize";
var ResultSourceLink = db_default.define("ResultSourceLink", {
  id: {
    type: DataTypes38.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  name: {
    type: DataTypes38.STRING(60),
    allowNull: false
  },
  url: {
    type: DataTypes38.STRING(1e3),
    allowNull: false
  },
  sport_id: {
    type: DataTypes38.STRING(10),
    allowNull: true
  },
  sort_order: {
    type: DataTypes38.INTEGER,
    allowNull: false,
    defaultValue: 0
  },
  active: {
    type: DataTypes38.BOOLEAN,
    allowNull: false,
    defaultValue: true
  }
}, {
  tableName: "result_source_links",
  timestamps: true
});
var DEFAULT_LINKS = [
  { name: "Cricbuzz Live", url: "https://www.cricbuzz.com/cricket-match/live-scores", sport_id: "4", sort_order: 1 },
  { name: "Cricbuzz Recent", url: "https://www.cricbuzz.com/cricket-match/live-scores/recent-matches", sport_id: "4", sort_order: 2 },
  { name: "ESPNcricinfo", url: "https://www.espncricinfo.com/live-cricket-score", sport_id: "4", sort_order: 3 },
  { name: "Flashscore", url: "https://www.flashscore.com/", sport_id: null, sort_order: 10 },
  { name: "SofaScore", url: "https://www.sofascore.com/", sport_id: null, sort_order: 11 },
  { name: "Google Scorecard", url: "https://www.google.com/search?q={match}+scorecard", sport_id: null, sort_order: 20 },
  { name: "Google", url: "https://www.google.com/search?q={match}+{market}", sport_id: null, sort_order: 30 }
];
var ready = null;
var ensureResultSourceLinks = () => {
  if (!ready) {
    ready = (async () => {
      await ResultSourceLink.sync();
      if (!await ResultSourceLink.count()) await ResultSourceLink.bulkCreate(DEFAULT_LINKS);
    })().catch((e) => {
      ready = null;
      throw e;
    });
  }
  return ready;
};
var ResultSourceLink_default = ResultSourceLink;

// controller/admin/bettingConfigController.js
init_db();
import { QueryTypes as QueryTypes2 } from "sequelize";

// model/user/SportsConfig.js
init_db();
import { DataTypes as DataTypes39, Model } from "sequelize";
var SportsConfig = class extends Model {
};
SportsConfig.init(
  {
    id: {
      type: DataTypes39.INTEGER,
      autoIncrement: true,
      primaryKey: true
    },
    game_id: {
      type: DataTypes39.INTEGER,
      allowNull: false
    },
    game_name: {
      type: DataTypes39.STRING(50),
      allowNull: false
    },
    enabled: {
      type: DataTypes39.BOOLEAN,
      allowNull: false,
      defaultValue: false
    },
    created_at: {
      type: DataTypes39.DATE,
      allowNull: true,
      defaultValue: DataTypes39.NOW
    },
    updated_at: {
      type: DataTypes39.DATE,
      allowNull: true,
      defaultValue: DataTypes39.NOW
    }
  },
  {
    sequelize: db_default,
    modelName: "SportsConfig",
    tableName: "sports_config",
    timestamps: false
    // because you have custom created_at and updated_at
  }
);
var SportsConfig_default = SportsConfig;

// controller/admin/bettingConfigController.js
var BUFFER_MARKETS = BetBufferConfig_default.MARKETS;
var BUFFER_MARKET_KEYS = BetBufferConfig_default.MARKET_KEYS;
var MAX_BUFFER_SECONDS = 60;
var BULK_LIMIT = 500;
var fail = (res, code, message) => res.status(code).json({ success: false, error: message });
var parseBuffer = (raw) => {
  const n = Number(raw);
  if (!Number.isFinite(n) || n < 0 || n > MAX_BUFFER_SECONDS) return null;
  return Math.round(n * 100) / 100;
};
var parseLimit = (raw) => {
  if (raw === void 0 || raw === null || raw === "") return null;
  const n = Number(raw);
  if (!Number.isFinite(n) || n < 0) return void 0;
  return n > 0 ? Math.round(n * 100) / 100 : null;
};
var getSportsBuffers = async (req, res) => {
  try {
    const rows = await BetBufferConfig_default.findAll({
      where: { scope: "sports" },
      attributes: ["sport_id", "league_key", "category", "buffer_seconds"],
      raw: true
    });
    const saved = /* @__PURE__ */ new Map();
    for (const row of rows) {
      saved.set(
        `${row.sport_id}:${row.league_key || DEFAULT_LEAGUE_KEY}:${row.category}`,
        Number(row.buffer_seconds) || 0
      );
    }
    let enabled = /* @__PURE__ */ new Set();
    try {
      const cfg = await SportsConfig_default.findAll({
        where: { enabled: true },
        attributes: ["game_id"],
        raw: true
      });
      enabled = new Set(cfg.map((c) => String(c.game_id)));
    } catch {
    }
    const sports = SPORTS_LIST.map(([sportId, name]) => {
      const leagues = leagueOptionsForSport(sportId).map((league) => {
        const cells = {};
        for (const marketKey of BUFFER_MARKET_KEYS) {
          const parent = saved.get(`${sportId}:${DEFAULT_LEAGUE_KEY}:${marketKey}`) || 0;
          const own = saved.get(`${sportId}:${league.key}:${marketKey}`);
          if (league.is_default) {
            cells[marketKey] = { state: "set", seconds: own || 0, inherited: null };
          } else if (own !== void 0) {
            cells[marketKey] = { state: "set", seconds: own, inherited: parent };
          } else {
            cells[marketKey] = { state: "inherit", seconds: parent, inherited: parent };
          }
        }
        const configuredCount = BUFFER_MARKET_KEYS.filter((k) => cells[k].seconds > 0).length;
        return { ...league, cells, configured_count: configuredCount };
      });
      return { sport_id: Number(sportId), name, enabled: enabled.has(sportId), leagues };
    }).sort((a, b) => b.enabled === a.enabled ? 0 : b.enabled ? 1 : -1);
    return res.json({
      success: true,
      markets: BUFFER_MARKETS,
      market_keys: BUFFER_MARKET_KEYS,
      default_league_key: DEFAULT_LEAGUE_KEY,
      max_seconds: MAX_BUFFER_SECONDS,
      sports
    });
  } catch (err) {
    console.error("getSportsBuffers error:", err);
    return fail(res, 500, "Failed to load sports buffer configuration");
  }
};
var parseBufferCell = (body) => {
  const sportId = Number(body?.sport_id);
  const leagueKey = String(body?.league_key || DEFAULT_LEAGUE_KEY).toLowerCase().trim();
  const marketKey = String(body?.market_key || body?.category || "").toLowerCase().trim();
  const seconds = parseBuffer(body?.buffer_seconds);
  if (!Number.isInteger(sportId) || sportId <= 0) return { error: "sport_id is required" };
  if (!BUFFER_MARKET_KEYS.includes(marketKey)) {
    const legacy = BetBufferConfig_default.LEGACY_CATEGORY_EXPANSION[marketKey];
    return {
      error: legacy ? `'${marketKey}' is no longer a single market \u2014 use ${legacy.join(" or ")}` : `market_key must be one of ${BUFFER_MARKET_KEYS.join(", ")}`
    };
  }
  if (!isValidLeagueKey(sportId, leagueKey)) {
    const allowed = leagueOptionsForSport(sportId).map((l) => l.key).join(", ");
    return { error: `league_key '${leagueKey}' is not configured for sport ${sportId} (allowed: ${allowed})` };
  }
  if (seconds === null) return { error: `buffer_seconds must be between 0 and ${MAX_BUFFER_SECONDS}` };
  return { sportId, leagueKey, marketKey, seconds };
};
var upsertBufferCell = async ({ sportId, leagueKey, marketKey, seconds }) => {
  const where = { scope: "sports", sport_id: sportId, league_key: leagueKey, category: marketKey };
  const existing = await BetBufferConfig_default.findOne({ where });
  if (existing) {
    await existing.update({ buffer_seconds: seconds });
  } else {
    await BetBufferConfig_default.create({ ...where, buffer_seconds: seconds });
  }
};
var saveSportsBuffer = async (req, res) => {
  try {
    const cell = parseBufferCell(req.body);
    if (cell.error) return fail(res, 400, cell.error);
    await upsertBufferCell(cell);
    await BettingConfigService_default.invalidateBuffers();
    return res.json({
      success: true,
      sport_id: cell.sportId,
      league_key: cell.leagueKey,
      market_key: cell.marketKey,
      buffer_seconds: cell.seconds
    });
  } catch (err) {
    console.error("saveSportsBuffer error:", err);
    return fail(res, 500, "Failed to save buffer time");
  }
};
var saveSportsBufferBulk = async (req, res) => {
  try {
    const items = Array.isArray(req.body?.items) ? req.body.items : null;
    if (!items || items.length === 0) return fail(res, 400, "items must be a non-empty array");
    if (items.length > BULK_LIMIT) return fail(res, 400, `items may not exceed ${BULK_LIMIT} cells`);
    const cells = [];
    for (let i = 0; i < items.length; i += 1) {
      const cell = parseBufferCell(items[i]);
      if (cell.error) return fail(res, 400, `item ${i}: ${cell.error}`);
      cells.push(cell);
    }
    for (const cell of cells) await upsertBufferCell(cell);
    await BettingConfigService_default.invalidateBuffers();
    return res.json({ success: true, saved: cells.length });
  } catch (err) {
    console.error("saveSportsBufferBulk error:", err);
    return fail(res, 500, "Failed to save buffer times");
  }
};
var resetSportsBuffer = async (req, res) => {
  try {
    const sportId = Number(req.body?.sport_id);
    const leagueKey = String(req.body?.league_key || "").toLowerCase().trim();
    const marketKey = String(req.body?.market_key || "").toLowerCase().trim();
    if (!Number.isInteger(sportId) || sportId <= 0) return fail(res, 400, "sport_id is required");
    if (!BUFFER_MARKET_KEYS.includes(marketKey)) {
      return fail(res, 400, `market_key must be one of ${BUFFER_MARKET_KEYS.join(", ")}`);
    }
    if (!leagueKey || leagueKey === DEFAULT_LEAGUE_KEY) {
      return fail(res, 400, "only a league override can be reset \u2014 save 0 on the default cell instead");
    }
    if (!isValidLeagueKey(sportId, leagueKey)) {
      return fail(res, 400, `league_key '${leagueKey}' is not configured for sport ${sportId}`);
    }
    const removed = await BetBufferConfig_default.destroy({
      where: { scope: "sports", sport_id: sportId, league_key: leagueKey, category: marketKey }
    });
    await BettingConfigService_default.invalidateBuffers();
    return res.json({ success: true, removed, sport_id: sportId, league_key: leagueKey, market_key: marketKey });
  } catch (err) {
    console.error("resetSportsBuffer error:", err);
    return fail(res, 500, "Failed to reset buffer time");
  }
};
var flattenEvents = (nodes, out = []) => {
  for (const node of nodes || []) {
    if (node?.gmid) out.push(node);
    if (Array.isArray(node?.children)) flattenEvents(node.children, out);
  }
  return out;
};
var getInplayEvents = async (req, res) => {
  try {
    const requested = req.query?.sport_id ? [String(req.query.sport_id)] : null;
    let sportIds = requested;
    if (!sportIds) {
      try {
        const cfg = await SportsConfig_default.findAll({
          where: { enabled: true },
          attributes: ["game_id"],
          raw: true
        });
        sportIds = cfg.map((c) => String(c.game_id));
      } catch {
        sportIds = [];
      }
      if (!sportIds.length) sportIds = SPORTS_LIST.map(([id]) => id);
    }
    const boards = await Promise.all(
      sportIds.map(
        (sid) => CricketService_default.fetchCricketData(sid).then((data) => ({ sid, data })).catch(() => ({ sid, data: null }))
      )
    );
    const events = [];
    for (const { sid, data } of boards) {
      const t1 = Array.isArray(data?.data?.t1) ? data.data.t1 : [];
      const t2 = Array.isArray(data?.data?.t2) ? data.data.t2 : [];
      for (const event of flattenEvents([...t1, ...t2])) {
        events.push({
          event_id: String(event.gmid),
          sport_id: Number(event.etid || sid),
          sport_name: sportNameById(event.etid || sid),
          event_name: event.ename || event.name || "",
          competition: event.cname || "",
          start_time: event.stime || null,
          inplay: !!event.iplay
        });
      }
    }
    events.sort((a, b) => b.inplay === a.inplay ? 0 : b.inplay ? 1 : -1);
    const configured = await BetLimitOverride_default.findAll({
      where: { scope: "sports", is_active: true, event_id: { [Op15.in]: events.map((e) => e.event_id) } },
      attributes: ["event_id"],
      raw: true
    });
    const configuredIds = new Set(configured.map((c) => String(c.event_id)));
    return res.json({
      success: true,
      events: events.map((e) => ({ ...e, has_overrides: configuredIds.has(e.event_id) }))
    });
  } catch (err) {
    console.error("getInplayEvents error:", err);
    return fail(res, 500, "Failed to load inplay events");
  }
};
var getEventMarkets = async (req, res) => {
  try {
    const eventId = String(req.params.event_id || "");
    const sportId = req.query?.sport_id;
    if (!eventId) return fail(res, 400, "event_id is required");
    const [privateData, overrides] = await Promise.all([
      CricketService_default.GetMatchPrivateData(eventId, sportId).catch(() => null),
      BetLimitOverride_default.findAll({
        where: { scope: "sports", event_id: eventId },
        raw: true
      })
    ]);
    const byMarket = new Map(overrides.map((o) => [String(o.market_id), o]));
    const markets = Array.isArray(privateData?.data) ? privateData.data : [];
    const isRacing = String(sportId) === "10" || String(sportId) === "65";
    const rows = markets.map((market) => {
      const section = Array.isArray(market.section) ? market.section : [];
      const feedMax = !isRacing && Number(market.maxb) > 0 ? Number(market.maxb) : Number(market.max) > 0 ? Number(market.max) : Number(section[0]?.max) || 0;
      const feedMin = Number(section[0]?.min) > 0 ? Number(section[0].min) : Number(market.min) || 0;
      const override = byMarket.get(String(market.mid));
      return {
        market_id: String(market.mid),
        market_name: market.mname || "",
        gtype: market.gtype || "",
        category: BetBufferConfig_default.categoryFromGtype(market.gtype),
        feed_min: feedMin,
        feed_max: feedMax,
        override_id: override?.id ?? null,
        min_stake: override?.min_stake != null ? Number(override.min_stake) : null,
        max_stake: override?.max_stake != null ? Number(override.max_stake) : null,
        is_active: override ? !!override.is_active : true
      };
    });
    return res.json({ success: true, event_id: eventId, markets: rows });
  } catch (err) {
    console.error("getEventMarkets error:", err);
    return fail(res, 500, "Failed to load event markets");
  }
};
var saveEventLimit = async (req, res) => {
  try {
    const eventId = String(req.body?.event_id || "").trim();
    const marketId = String(req.body?.market_id || "").trim();
    if (!eventId) return fail(res, 400, "event_id is required");
    if (!marketId) return fail(res, 400, "market_id is required");
    const minStake = parseLimit(req.body?.min_stake);
    const maxStake = parseLimit(req.body?.max_stake);
    if (minStake === void 0) return fail(res, 400, "min_stake must be a positive number");
    if (maxStake === void 0) return fail(res, 400, "max_stake must be a positive number");
    if (minStake !== null && maxStake !== null && minStake >= maxStake) {
      return fail(res, 400, "min_stake must be lower than max_stake");
    }
    const where = { scope: "sports", event_id: eventId, market_id: marketId };
    const values = {
      sport_id: req.body?.sport_id ? Number(req.body.sport_id) : null,
      market_name: req.body?.market_name ? String(req.body.market_name).slice(0, 120) : null,
      gtype: req.body?.gtype ? String(req.body.gtype).slice(0, 30) : null,
      event_name: req.body?.event_name ? String(req.body.event_name).slice(0, 200) : null,
      min_stake: minStake,
      max_stake: maxStake,
      // Both sides cleared → the row stays but stops applying, which is
      // the same as deleting it and keeps the audit trail.
      is_active: !(minStake === null && maxStake === null)
    };
    const existing = await BetLimitOverride_default.findOne({ where });
    let row;
    if (existing) {
      row = await existing.update(values);
    } else {
      row = await BetLimitOverride_default.create({ ...where, ...values });
    }
    await BettingConfigService_default.invalidateEventLimits(eventId);
    return res.json({ success: true, override: row });
  } catch (err) {
    console.error("saveEventLimit error:", err);
    return fail(res, 500, "Failed to save bet limit");
  }
};
var deleteEventLimit = async (req, res) => {
  try {
    const row = await BetLimitOverride_default.findOne({
      where: { id: Number(req.params.id), scope: "sports" }
    });
    if (!row) return fail(res, 404, "Override not found");
    const eventId = row.event_id;
    await row.destroy();
    await BettingConfigService_default.invalidateEventLimits(eventId);
    return res.json({ success: true });
  } catch (err) {
    console.error("deleteEventLimit error:", err);
    return fail(res, 500, "Failed to clear bet limit");
  }
};
var parseMaxOdds = (raw) => {
  if (raw === void 0 || raw === null || raw === "") return 0;
  const n = Number(raw);
  if (!Number.isFinite(n) || n < 0 || n > MaxOddsConfig_default.MAX_VALUE) return null;
  return Math.round(n * 100) / 100;
};
var EMPTY_MAX_ODDS = Object.freeze({ max_odds: 0, limited_overs_only: false });
var getSportsMaxOdds = async (req, res) => {
  try {
    const rows = await MaxOddsConfig_default.findAll({
      attributes: ["sport_id", "league_key", "category", "max_odds", "limited_overs_only"],
      raw: true
    });
    const saved = /* @__PURE__ */ new Map();
    for (const row of rows) {
      saved.set(`${row.sport_id}:${row.league_key || DEFAULT_LEAGUE_KEY}:${row.category}`, {
        max_odds: Number(row.max_odds) || 0,
        limited_overs_only: !!row.limited_overs_only
      });
    }
    let enabled = /* @__PURE__ */ new Set();
    try {
      const cfg = await SportsConfig_default.findAll({
        where: { enabled: true },
        attributes: ["game_id"],
        raw: true
      });
      enabled = new Set(cfg.map((c) => String(c.game_id)));
    } catch {
    }
    const sports = SPORTS_LIST.map(([sportId, name]) => {
      const leagues = leagueOptionsForSport(sportId).map((league) => {
        const rules = {};
        for (const category of MaxOddsConfig_default.CATEGORIES) {
          const parent = saved.get(`${sportId}:${DEFAULT_LEAGUE_KEY}:${category}`) || { ...EMPTY_MAX_ODDS };
          const own = saved.get(`${sportId}:${league.key}:${category}`);
          if (league.is_default) {
            rules[category] = { state: "set", ...own || EMPTY_MAX_ODDS, inherited: null };
          } else if (own) {
            rules[category] = { state: "set", ...own, inherited: parent };
          } else {
            rules[category] = { state: "inherit", ...parent, inherited: parent };
          }
        }
        return { ...league, rules };
      });
      return {
        sport_id: Number(sportId),
        name,
        enabled: enabled.has(sportId),
        rules: leagues[0].rules,
        leagues
      };
    }).sort((a, b) => b.enabled === a.enabled ? 0 : b.enabled ? 1 : -1);
    return res.json({
      success: true,
      categories: MaxOddsConfig_default.CATEGORIES,
      max_value: MaxOddsConfig_default.MAX_VALUE,
      limited_overs_sport_id: MaxOddsConfig_default.LIMITED_OVERS_SPORT_ID,
      default_league_key: DEFAULT_LEAGUE_KEY,
      sports
    });
  } catch (err) {
    console.error("getSportsMaxOdds error:", err);
    return fail(res, 500, "Failed to load max odds configuration");
  }
};
var saveSportsMaxOdds = async (req, res) => {
  try {
    const sportId = Number(req.body?.sport_id);
    const leagueKey = String(req.body?.league_key || DEFAULT_LEAGUE_KEY).toLowerCase().trim();
    const category = String(req.body?.category || "");
    const maxOdds = parseMaxOdds(req.body?.max_odds);
    const flag = req.body?.limited_overs_only;
    const limitedOversOnly = sportId === MaxOddsConfig_default.LIMITED_OVERS_SPORT_ID && (flag === true || flag === "true" || flag === 1);
    if (!Number.isInteger(sportId) || sportId <= 0) return fail(res, 400, "sport_id is required");
    if (!MaxOddsConfig_default.CATEGORIES.includes(category)) {
      return fail(res, 400, `category must be one of ${MaxOddsConfig_default.CATEGORIES.join(", ")}`);
    }
    if (!isValidLeagueKey(sportId, leagueKey)) {
      const allowed = leagueOptionsForSport(sportId).map((l) => l.key).join(", ");
      return fail(res, 400, `league_key '${leagueKey}' is not configured for sport ${sportId} (allowed: ${allowed})`);
    }
    if (maxOdds === null) return fail(res, 400, `max_odds must be between 0 and ${MaxOddsConfig_default.MAX_VALUE}`);
    const where = { sport_id: sportId, league_key: leagueKey, category };
    const values = { max_odds: maxOdds, limited_overs_only: limitedOversOnly };
    const existing = await MaxOddsConfig_default.findOne({ where });
    if (existing) {
      await existing.update(values);
    } else {
      await MaxOddsConfig_default.create({ ...where, ...values });
    }
    await BettingConfigService_default.invalidateMaxOdds();
    return res.json({ success: true, sport_id: sportId, league_key: leagueKey, category, ...values });
  } catch (err) {
    console.error("saveSportsMaxOdds error:", err);
    return fail(res, 500, "Failed to save max odds");
  }
};
var resetSportsMaxOdds = async (req, res) => {
  try {
    const sportId = Number(req.body?.sport_id);
    const leagueKey = String(req.body?.league_key || "").toLowerCase().trim();
    const category = String(req.body?.category || "");
    if (!Number.isInteger(sportId) || sportId <= 0) return fail(res, 400, "sport_id is required");
    if (!MaxOddsConfig_default.CATEGORIES.includes(category)) {
      return fail(res, 400, `category must be one of ${MaxOddsConfig_default.CATEGORIES.join(", ")}`);
    }
    if (!leagueKey || leagueKey === DEFAULT_LEAGUE_KEY) {
      return fail(res, 400, "only a league override can be reset \u2014 save 0 on the sport row instead");
    }
    if (!isValidLeagueKey(sportId, leagueKey)) {
      return fail(res, 400, `league_key '${leagueKey}' is not configured for sport ${sportId}`);
    }
    const removed = await MaxOddsConfig_default.destroy({
      where: { sport_id: sportId, league_key: leagueKey, category }
    });
    await BettingConfigService_default.invalidateMaxOdds();
    return res.json({ success: true, removed, sport_id: sportId, league_key: leagueKey, category });
  } catch (err) {
    console.error("resetSportsMaxOdds error:", err);
    return fail(res, 500, "Failed to reset max odds");
  }
};
var autoVoidPayload = (row) => ({
  enabled: !!row.enabled,
  delay_seconds: Number(row.delay_seconds),
  on_match_odds: !!row.on_match_odds,
  on_bookmaker: !!row.on_bookmaker,
  min_delay_seconds: AUTO_VOID_MIN_DELAY,
  max_delay_seconds: AUTO_VOID_MAX_DELAY,
  enabled_at: row.enabled_at || null,
  updated_at: row.updatedAt || row.updated_at || null
});
var getAutoVoid = async (req, res) => {
  try {
    const row = await getAutoVoidConfig();
    return res.json({ success: true, data: autoVoidPayload(row) });
  } catch (err) {
    console.error("getAutoVoid error:", err);
    return fail(res, 500, "Failed to load auto void settings");
  }
};
var saveAutoVoid = async (req, res) => {
  try {
    const { enabled, delay_seconds, on_match_odds, on_bookmaker } = req.body || {};
    const patch = {};
    if (enabled !== void 0) patch.enabled = enabled === true || enabled === "true" || enabled === 1;
    if (on_match_odds !== void 0) patch.on_match_odds = on_match_odds === true || on_match_odds === "true" || on_match_odds === 1;
    if (on_bookmaker !== void 0) patch.on_bookmaker = on_bookmaker === true || on_bookmaker === "true" || on_bookmaker === 1;
    if (delay_seconds !== void 0) {
      const n = Number(delay_seconds);
      if (!Number.isInteger(n) || n < AUTO_VOID_MIN_DELAY || n > AUTO_VOID_MAX_DELAY) {
        return fail(res, 400, `Delay must be a whole number of seconds between ${AUTO_VOID_MIN_DELAY} and ${AUTO_VOID_MAX_DELAY}`);
      }
      patch.delay_seconds = n;
    }
    if (!Object.keys(patch).length) return fail(res, 400, "Nothing to update");
    const row = await getAutoVoidConfig();
    const next = { ...row.get({ plain: true }), ...patch };
    if (next.enabled && !next.on_match_odds && !next.on_bookmaker) {
      return fail(res, 400, "Pick at least one market (Match Odds or Bookmaker) to start the timer");
    }
    if (next.enabled && !row.enabled) patch.enabled_at = /* @__PURE__ */ new Date();
    await row.update(patch);
    return res.json({ success: true, message: "Auto void settings saved", data: autoVoidPayload(row) });
  } catch (err) {
    console.error("saveAutoVoid error:", err);
    return fail(res, 500, "Failed to save auto void settings");
  }
};
var TRACKER_LOOKBACK_DAYS = 3;
var getAutoVoidTracker = async (req, res) => {
  try {
    const cfg = (await getAutoVoidConfig()).get({ plain: true });
    const rows = await db_default.query(
      `SELECT s.eventid, s.match_title, s.sport_id, s.anchor_market, s.anchor_status,
                    s.anchor_seen_at, s.last_fired_at, s.last_error,
                    b.id AS bet_id, b.user_id, u.username, b.game_type, b.market_type,
                    b.selection_name, b.fancy_name, b.bet_type, b.odds, b.stake_amount,
                    b.liability, b.status, b.unmatched, b.created_at, b.match_id
               FROM sports_auto_void_state s
               JOIN "SportsBet" b ON b.eventid = s.eventid AND b.status IN ('open', 'manual')
               LEFT JOIN users u ON u.user_id = b.user_id
              WHERE s.anchor_seen_at > NOW() - (:days || ' days')::interval
              ORDER BY s.anchor_seen_at ASC, b.match_id, b.market_type, b.selection_name, b.id`,
      { type: QueryTypes2.SELECT, replacements: { days: String(TRACKER_LOOKBACK_DAYS) } }
    );
    const now = Date.now();
    const events = /* @__PURE__ */ new Map();
    for (const r of rows) {
      let ev = events.get(r.eventid);
      if (!ev) {
        const due = voidDueAt(r.anchor_seen_at, cfg);
        ev = {
          eventid: r.eventid,
          match_title: r.match_title,
          sport_id: r.sport_id,
          anchor_market: r.anchor_market,
          anchor_status: r.anchor_status,
          anchor_seen_at: r.anchor_seen_at,
          void_at: due,
          seconds_left: Math.round((due.getTime() - now) / 1e3),
          last_fired_at: r.last_fired_at,
          last_error: r.last_error,
          bet_count: 0,
          manual_count: 0,
          total_stake: 0,
          users: /* @__PURE__ */ new Set(),
          markets: /* @__PURE__ */ new Map()
        };
        events.set(r.eventid, ev);
      }
      const perSel = isPerSelectionMarket(r.market_type);
      const mKey = [r.match_id, r.market_type, r.game_type, perSel ? r.selection_name : ""].join("|");
      let m = ev.markets.get(mKey);
      if (!m) {
        m = {
          match_id: r.match_id,
          game_type: r.game_type,
          market_type: r.market_type,
          market_name: perSel ? r.selection_name : r.fancy_name && r.fancy_name !== "NULL" ? r.fancy_name : r.market_type,
          bet_count: 0,
          manual_count: 0,
          total_stake: 0,
          users: /* @__PURE__ */ new Set(),
          bets: []
        };
        ev.markets.set(mKey, m);
      }
      const stake = Number(r.stake_amount) || 0;
      const manual = r.status === "manual";
      m.bets.push({
        id: r.bet_id,
        user_id: r.user_id,
        username: r.username,
        selection_name: r.selection_name,
        bet_type: r.bet_type,
        odds: Number(r.odds),
        stake,
        status: r.status,
        unmatched: !!r.unmatched,
        created_at: r.created_at
      });
      for (const t of [m, ev]) {
        t.bet_count++;
        t.total_stake += stake;
        t.users.add(r.user_id);
        if (manual) t.manual_count++;
      }
    }
    const data = [...events.values()].map((ev) => ({
      ...ev,
      users: ev.users.size,
      markets: [...ev.markets.values()].map((m) => ({ ...m, users: m.users.size }))
    }));
    await ensureResultSourceLinks();
    const links = await ResultSourceLink_default.findAll({
      where: { active: true },
      attributes: ["id", "name", "url", "sport_id"],
      order: [["sort_order", "ASC"], ["id", "ASC"]],
      raw: true
    });
    return res.json({
      success: true,
      data: {
        enabled: !!cfg.enabled,
        delay_seconds: Number(cfg.delay_seconds),
        server_time: new Date(now),
        events: data,
        links
      }
    });
  } catch (err) {
    console.error("getAutoVoidTracker error:", err);
    return fail(res, 500, "Failed to load pending result tracker");
  }
};
var cleanLink = (body = {}) => {
  const name = String(body.name ?? "").trim();
  const url = String(body.url ?? "").trim();
  if (!name || name.length > 60) return { error: "Name is required (max 60 characters)" };
  if (!/^https?:\/\/[^\s]+$/i.test(url) || url.length > 1e3) return { error: "URL must start with http:// or https://" };
  const sport = body.sport_id === void 0 || body.sport_id === null || body.sport_id === "" ? null : String(body.sport_id);
  if (sport !== null && !SPORTS_LIST.some(([sid]) => sid === sport)) return { error: "Unknown sport" };
  const order = Number(body.sort_order ?? 0);
  return {
    row: {
      name,
      url,
      sport_id: sport,
      sort_order: Number.isFinite(order) ? Math.trunc(order) : 0,
      active: body.active === void 0 ? true : body.active === true || body.active === "true" || body.active === 1
    }
  };
};
var listResultLinks = async (req, res) => {
  try {
    await ensureResultSourceLinks();
    const rows = await ResultSourceLink_default.findAll({ order: [["sort_order", "ASC"], ["id", "ASC"]], raw: true });
    return res.json({ success: true, data: rows });
  } catch (err) {
    console.error("listResultLinks error:", err);
    return fail(res, 500, "Failed to load result links");
  }
};
var createResultLink = async (req, res) => {
  try {
    await ensureResultSourceLinks();
    const { row, error } = cleanLink(req.body);
    if (error) return fail(res, 400, error);
    const created = await ResultSourceLink_default.create(row);
    return res.json({ success: true, message: "Link added", data: created });
  } catch (err) {
    console.error("createResultLink error:", err);
    return fail(res, 500, "Failed to add link");
  }
};
var updateResultLink = async (req, res) => {
  try {
    await ensureResultSourceLinks();
    const link = await ResultSourceLink_default.findByPk(req.params.id);
    if (!link) return fail(res, 404, "Link not found");
    const { row, error } = cleanLink({ ...link.get({ plain: true }), ...req.body });
    if (error) return fail(res, 400, error);
    await link.update(row);
    return res.json({ success: true, message: "Link saved", data: link });
  } catch (err) {
    console.error("updateResultLink error:", err);
    return fail(res, 500, "Failed to save link");
  }
};
var deleteResultLink = async (req, res) => {
  try {
    await ensureResultSourceLinks();
    const removed = await ResultSourceLink_default.destroy({ where: { id: req.params.id } });
    if (!removed) return fail(res, 404, "Link not found");
    return res.json({ success: true, message: "Link deleted" });
  } catch (err) {
    console.error("deleteResultLink error:", err);
    return fail(res, 500, "Failed to delete link");
  }
};
var VIRTUAL_MAX_STAKE = 1e7;
var virtualLimitsPayload = async () => {
  await seedVirtualBetLimits();
  const rows = await VirtualBetLimit_default.findAll({ raw: true });
  const byKey = new Map(rows.map((r) => [`${r.sport_id}:${r.league_key}`, r]));
  return virtualLeagues().map(({ sport_id, league_key, label }) => {
    const r = byKey.get(`${sport_id}:${league_key}`) || {};
    return {
      sport_id,
      sport_name: sportNameById(sport_id),
      league_key,
      label,
      min_stake: Number(r.min_stake) || 0,
      max_stake: Number(r.max_stake) || 0,
      updated_at: r.updatedAt || r.updated_at || null
    };
  });
};
var getVirtualLimits = async (req, res) => {
  try {
    return res.json({ success: true, data: await virtualLimitsPayload() });
  } catch (err) {
    console.error("getVirtualLimits error:", err);
    return fail(res, 500, "Failed to load virtual bet limits");
  }
};
var saveVirtualLimits = async (req, res) => {
  try {
    const rows = Array.isArray(req.body?.rows) ? req.body.rows : null;
    if (!rows || !rows.length) return fail(res, 400, "Nothing to update");
    const known = new Set(virtualLeagues().map((l) => `${l.sport_id}:${l.league_key}`));
    const clean = [];
    for (const row of rows) {
      const sportId = Number(row?.sport_id);
      const leagueKey = String(row?.league_key || "");
      if (!known.has(`${sportId}:${leagueKey}`)) return fail(res, 400, `Unknown league ${leagueKey}`);
      const min = Number(row.min_stake ?? 0);
      const max = Number(row.max_stake ?? 0);
      if (!Number.isFinite(min) || min < 0 || min > VIRTUAL_MAX_STAKE || !Number.isFinite(max) || max < 0 || max > VIRTUAL_MAX_STAKE) {
        return fail(res, 400, "Min and Max must be numbers between 0 and 1,00,00,000");
      }
      if (min > 0 && max > 0 && min > max) {
        return fail(res, 400, "Min cannot be more than Max");
      }
      clean.push({ sport_id: sportId, league_key: leagueKey, min_stake: min, max_stake: max });
    }
    await seedVirtualBetLimits();
    for (const r of clean) {
      await VirtualBetLimit_default.update(
        { min_stake: r.min_stake, max_stake: r.max_stake },
        { where: { sport_id: r.sport_id, league_key: r.league_key } }
      );
    }
    await BettingConfigService_default.invalidateVirtualLimits();
    return res.json({ success: true, message: "Virtual bet limits saved", data: await virtualLimitsPayload() });
  } catch (err) {
    console.error("saveVirtualLimits error:", err);
    return fail(res, 500, "Failed to save virtual bet limits");
  }
};
var bettingConfigController_default2 = {
  getSportsBuffers,
  saveSportsBuffer,
  saveSportsBufferBulk,
  resetSportsBuffer,
  getInplayEvents,
  getEventMarkets,
  saveEventLimit,
  deleteEventLimit,
  getSportsMaxOdds,
  saveSportsMaxOdds,
  resetSportsMaxOdds,
  getAutoVoid,
  saveAutoVoid,
  getAutoVoidTracker,
  listResultLinks,
  createResultLink,
  updateResultLink,
  deleteResultLink,
  getVirtualLimits,
  saveVirtualLimits
};

// controller/admin/commissionConfigController.js
var MARKETS = CommissionConfig_default.MARKETS;
var MARKET_KEYS = CommissionConfig_default.MARKET_KEYS;
var MAX_PERCENT = CommissionConfig_default.MAX_PERCENT;
var DEFAULT_PERCENT = CommissionConfig_default.DEFAULT_PERCENT;
var fail2 = (res, code, message) => res.status(code).json({ success: false, error: message });
var parsePercent = (raw) => {
  const n = Number(raw);
  if (!Number.isFinite(n) || n < 0 || n > MAX_PERCENT) return null;
  return Math.round(n * 100) / 100;
};
var parseBool = (v) => v === true || v === "true" || v === 1 || v === "1";
var parseCell = (body) => {
  const sportId = Number(body?.sport_id);
  const leagueKey = String(body?.league_key || DEFAULT_LEAGUE_KEY).toLowerCase().trim();
  const marketKey = String(body?.market_key || body?.gtype || "").toLowerCase().trim();
  const percent = parsePercent(body?.percent);
  if (!Number.isInteger(sportId) || sportId <= 0) return { error: "sport_id is required" };
  if (CommissionConfig_default.LEGACY_GTYPE_EXPANSION[marketKey]) {
    return {
      error: `'${marketKey}' is no longer a single market \u2014 use ${CommissionConfig_default.LEGACY_GTYPE_EXPANSION[marketKey].join(" or ")}`
    };
  }
  if (!MARKET_KEYS.includes(marketKey)) {
    return { error: `market_key must be one of ${MARKET_KEYS.join(", ")}` };
  }
  if (!isValidLeagueKey(sportId, leagueKey)) {
    const allowed = leagueOptionsForSport(sportId).map((l) => l.key).join(", ");
    return { error: `league_key '${leagueKey}' is not configured for sport ${sportId} (allowed: ${allowed})` };
  }
  if (percent === null) return { error: `percent must be between 0 and ${MAX_PERCENT}` };
  return { sportId, leagueKey, marketKey, percent, enabled: parseBool(body?.enabled) };
};
var upsertCell = async ({ sportId, leagueKey, marketKey, enabled, percent }) => {
  const where = { sport_id: sportId, league_key: leagueKey, market_key: marketKey };
  const existing = await CommissionConfig_default.findOne({ where });
  if (existing) {
    await existing.update({ enabled, percent });
  } else {
    await CommissionConfig_default.create({ ...where, enabled, percent });
  }
};
var getSportsCommission = async (req, res) => {
  try {
    const rows = await CommissionConfig_default.findAll({
      attributes: ["sport_id", "league_key", "market_key", "enabled", "percent"],
      raw: true
    });
    const saved = /* @__PURE__ */ new Map();
    for (const row of rows) {
      saved.set(`${row.sport_id}:${row.league_key}:${row.market_key}`, {
        enabled: !!row.enabled,
        percent: Number(row.percent) || 0
      });
    }
    let enabledSports = /* @__PURE__ */ new Set();
    try {
      const cfg = await SportsConfig_default.findAll({
        where: { enabled: true },
        attributes: ["game_id"],
        raw: true
      });
      enabledSports = new Set(cfg.map((c) => String(c.game_id)));
    } catch {
    }
    const sports = SPORTS_LIST.map(([sportId, name]) => {
      const leagues = leagueOptionsForSport(sportId).map((league) => {
        const rules = {};
        for (const marketKey of MARKET_KEYS) {
          const hit = saved.get(`${sportId}:${league.key}:${marketKey}`);
          const inherited = league.is_default ? null : saved.get(`${sportId}:${DEFAULT_LEAGUE_KEY}:${marketKey}`) || null;
          if (hit) {
            rules[marketKey] = {
              state: hit.enabled ? "on" : "off",
              percent: hit.percent,
              // What this cell would fall back to if reset.
              inherited: inherited ? { state: inherited.enabled ? "on" : "off", percent: inherited.percent } : null
            };
          } else if (league.is_default) {
            rules[marketKey] = { state: "off", percent: DEFAULT_PERCENT, inherited: null };
          } else {
            rules[marketKey] = {
              state: "inherit",
              percent: inherited?.percent ?? DEFAULT_PERCENT,
              inherited: inherited ? { state: inherited.enabled ? "on" : "off", percent: inherited.percent } : { state: "off", percent: DEFAULT_PERCENT }
            };
          }
        }
        const activeCount = MARKET_KEYS.filter((k) => {
          const r = rules[k];
          if (r.state === "on") return true;
          if (r.state === "inherit") return r.inherited?.state === "on";
          return false;
        }).length;
        return { ...league, rules, active_count: activeCount };
      });
      return {
        sport_id: Number(sportId),
        name,
        enabled: enabledSports.has(sportId),
        leagues,
        active_count: leagues[0]?.active_count || 0
      };
    }).sort((a, b) => b.enabled === a.enabled ? 0 : b.enabled ? 1 : -1);
    return res.json({
      success: true,
      markets: MARKETS,
      market_keys: MARKET_KEYS,
      default_league_key: DEFAULT_LEAGUE_KEY,
      max_percent: MAX_PERCENT,
      default_percent: DEFAULT_PERCENT,
      sports
    });
  } catch (err) {
    console.error("getSportsCommission error:", err);
    return fail2(res, 500, "Failed to load commission configuration");
  }
};
var saveSportsCommission = async (req, res) => {
  try {
    const cell = parseCell(req.body);
    if (cell.error) return fail2(res, 400, cell.error);
    await upsertCell(cell);
    await CommissionConfigService_default.invalidate();
    return res.json({
      success: true,
      sport_id: cell.sportId,
      league_key: cell.leagueKey,
      market_key: cell.marketKey,
      enabled: cell.enabled,
      percent: cell.percent
    });
  } catch (err) {
    console.error("saveSportsCommission error:", err);
    return fail2(res, 500, "Failed to save commission setting");
  }
};
var BULK_LIMIT2 = 500;
var saveSportsCommissionBulk = async (req, res) => {
  try {
    const items = Array.isArray(req.body?.items) ? req.body.items : null;
    if (!items || items.length === 0) return fail2(res, 400, "items must be a non-empty array");
    if (items.length > BULK_LIMIT2) return fail2(res, 400, `items may not exceed ${BULK_LIMIT2} cells`);
    const cells = [];
    for (let i = 0; i < items.length; i += 1) {
      const cell = parseCell(items[i]);
      if (cell.error) return fail2(res, 400, `item ${i}: ${cell.error}`);
      cells.push(cell);
    }
    for (const cell of cells) await upsertCell(cell);
    await CommissionConfigService_default.invalidate();
    return res.json({ success: true, saved: cells.length });
  } catch (err) {
    console.error("saveSportsCommissionBulk error:", err);
    return fail2(res, 500, "Failed to save commission settings");
  }
};
var resetSportsCommission = async (req, res) => {
  try {
    const sportId = Number(req.body?.sport_id);
    const leagueKey = String(req.body?.league_key || "").toLowerCase().trim();
    const marketKey = String(req.body?.market_key || req.body?.gtype || "").toLowerCase().trim();
    if (!Number.isInteger(sportId) || sportId <= 0) return fail2(res, 400, "sport_id is required");
    if (!MARKET_KEYS.includes(marketKey)) return fail2(res, 400, `market_key must be one of ${MARKET_KEYS.join(", ")}`);
    if (!leagueKey || leagueKey === DEFAULT_LEAGUE_KEY) {
      return fail2(res, 400, "only a league override can be reset \u2014 switch the default cell OFF instead");
    }
    if (!isValidLeagueKey(sportId, leagueKey)) {
      return fail2(res, 400, `league_key '${leagueKey}' is not configured for sport ${sportId}`);
    }
    const removed = await CommissionConfig_default.destroy({
      where: { sport_id: sportId, league_key: leagueKey, market_key: marketKey }
    });
    await CommissionConfigService_default.invalidate();
    return res.json({ success: true, removed, sport_id: sportId, league_key: leagueKey, market_key: marketKey });
  } catch (err) {
    console.error("resetSportsCommission error:", err);
    return fail2(res, 500, "Failed to reset commission setting");
  }
};
var commissionConfigController_default = {
  getSportsCommission,
  saveSportsCommission,
  saveSportsCommissionBulk,
  resetSportsCommission
};
export {
  bettingConfigController_default2 as AdminBettingConfigController,
  BALANCE_UPDATES_CHANNEL,
  sportbetscontroller_default as BetController,
  commissionConfigController_default as CommissionConfigController,
  cricketController_default as CricketController,
  userExposureController_default as ExposureController,
  MESSAGES,
  controller_default as ManualSettleController,
  OneClickButtonListController_default as OneClickButtonListController,
  SportsLockController_default as SportsLockController,
  StakeButtonValueController_default as StakeButtonValueController,
  bettingConfigController_default as UserBettingConfigController,
  UserStatementController_default as UserStatementController,
  virtualEventController_default as VirtualEventController,
  authMiddleware_default as authMiddleware,
  bulkToggleMarketLock,
  getBetResult,
  getMarketLockChildren,
  maxDateRange,
  placeBetBuffered,
  redisClient_default as redisClient,
  requireBackoffice,
  requireOwner,
  db_default as sequelize,
  setIO,
  setupSocketHandlers,
  toggleMarketLock,
  transactionPasswordMiddleware_default as verifyTransactionPassword,
  verifyTransactionPasswordAs
};
