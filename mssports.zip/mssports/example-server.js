// Minimal host showing how the 3 API groups are mounted. In a microservices
// project, put these lines into the sports service's own server file.
import 'dotenv/config';
import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import { mountOddsEventsApi } from './api/oddsEvents.api.js';
import { mountBetsApi, setupBetsSocket } from './api/bets.api.js';
import { mountSettlementStatementApi } from './api/settlementStatement.api.js';

const app = express();
app.set('trust proxy', true);
app.use(express.json({ limit: '10mb' }));

mountOddsEventsApi(app);          // group 1: odds, events, score, bet settings
mountBetsApi(app);                // group 2: place bet, current bets, exposure
mountSettlementStatementApi(app); // group 3: manual settle, statement, admin config

const server = createServer(app);
const io = new Server(server, { path: '/socket.io', cors: { origin: true, credentials: true } });
setupBetsSocket(io);              // player room + balance push + worker relay

const PORT = process.env.PORT || 5005;
server.listen(PORT, () => console.log(`mssports API on :${PORT}`));
