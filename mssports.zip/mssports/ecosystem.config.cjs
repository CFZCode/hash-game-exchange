// pm2 config for the 4 sports workers (+ the example API host).
// Env values here are the ones tenexch runs with; secrets come from .env.
const path = require('path');
const dir = __dirname;

module.exports = {
  apps: [
    { name: 'mssports-api', script: path.join(dir, 'example-server.js'), cwd: dir, instances: 1, exec_mode: 'fork' },

    { name: 'mssports-odds', script: path.join(dir, 'workers/odds.worker.js'), cwd: dir, instances: 1, exec_mode: 'fork' },

    { name: 'mssports-events', script: path.join(dir, 'workers/events.worker.js'), cwd: dir, instances: 1, exec_mode: 'fork' },

    {
      name: 'mssports-results', script: path.join(dir, 'workers/results.worker.js'), cwd: dir,
      instances: 1, exec_mode: 'fork', max_restarts: 10, time: true,
      env: {
        NODE_ENV: 'production', DEBUG: '0', SETTLEMENT_VERSION: 'v2',
        API_TIMEOUT_MS: '40000', MAX_CONCURRENT_API: '3', RESULTS_POLL_MS: '2000',
        RESULT_CACHE_MS: '1500', SCAN_WRITE_MS: '60000', SUMMARY_KEEP_PER_EVENT: '5',
        SUMMARY_RETENTION_DAYS: '7', BET_CACHE_TTL_DAYS: '14',
        RESULTS_CRON_LOG_DIR: path.join(dir, 'logs'),
      },
    },

    {
      // ONE instance only — duplicate-settlement protection assumes it.
      name: 'mssports-settlement', script: path.join(dir, 'workers/settlement.worker.js'), cwd: dir,
      instances: 1, exec_mode: 'fork', max_restarts: 10, time: true,
      env: {
        NODE_ENV: 'production', DEBUG: '1', WORKER_MODE: '1', SETTLEMENT_VERSION: 'v2',
        API_TIMEOUT_MS: '15000', SETTLE_POLL_MS: '3000', SETTLE_BATCH_LIMIT: '100',
        SETTLE_REQUEUE_MS: '20000', SETTLE_STUCK_MS: '180000', RESULT_CACHE_MS: '2500',
        LEDGER_ZERO_ROWS: '0', SETTLEMENT_LOG_DIR: path.join(dir, 'logs'),
      },
    },
  ],
};
