# MSSPORTS — Instructions for Claude (read first)

This folder is the **sports betting module** taken from the TENEXCH monolith (Node 18, ESM, Express,
Sequelize/Postgres, Redis, Socket.IO). It is **sports only**: no casino, no third-party games.
It is going into a microservices project.

## Read in this order
1. `README.md` — the file layout, how to run, what was included or removed.
2. `api/*.api.js` — **every sports API is in these 3 files**, and each file lists its routes at the top.
3. `docs/FLOW.md` — odds → place bet → exposure → results → settlement → statement.
4. `PENDING_WORK.md` — **known bugs and open work. Check it before changing any money code.**

## Layout rules
- **APIs** = `api/` (3 hand-written route files). Add or change routes here.
- **Logic** = `core/sports-core.js`, one esbuild bundle of the tenexch source. Each module starts with
  `// <original/path.js>`; search that comment to find a module.
  To refactor: split the core back into modules along those comments. Do it as a move, not a rewrite.
- **Workers** = `workers/*.worker.js`, one self-contained bundle each, one process each:
  - `odds.worker.js` — odds cron. **Broken today**, and nothing reads its output; see PENDING_WORK D1.
  - `events.worker.js` — event list cron → Redis `alleventss:{sid}`.
  - `results.worker.js` — polls the results API, queues settlement jobs.
  - `settlement.worker.js` — pays out. **Exactly ONE instance, `WORKER_MODE=1`.**
  The workers do not import `core/`. Each carries its own copy of the code it needs.
  If you fix shared logic (e.g. exposure maths) in core, fix the same module in the worker bundle too, or rebuild both from one source.

## Hard facts
- Live odds come **directly from AVRKHUB** (`SPORTS_API_VERSION=v2`), with a 250 ms in-process cache, not from Redis.
- `match_id` on a bet is the **market id** (feed `mid`); `eventid` is the match (`gmid`).
- `market_type` (feed `mname`) decides the exposure/settlement branch, not `game_type`.
- Racing (sid 10 / 65): `maxb` is a flag; the real stake cap is `max`.
- Money path:
  - placement debits `Wallets.cash` and writes `user_exposures`, `total_exposures`, `debit_ledger`
  - settlement writes `cash`, `inr_balance`, `credits_ledger`, the `point_ledger` chain and commission
  - the statement reads `point_ledger`
- Balance push: workers publish on Redis `socket:balance_updates`; the API relays it to room `user_{id}` (`setupBetsSocket`).

## Rules
- **Money paths are sacred** (exposure, wallet, settlement, ledger). Any change needs a written before/after
  balance example and a test. Port first with the same maths, check parity against tenexch data, then refactor.
- Do not run Sequelize `sync({ alter: true })` against the tenexch database. This export removed casino columns from some
  models, and alter-sync would drop them (PENDING_WORK §F.4).
- Config goes in `.env`, never hardcoded hosts or keys.
- Fix the 🔴 items in `PENDING_WORK.md` before production traffic.
