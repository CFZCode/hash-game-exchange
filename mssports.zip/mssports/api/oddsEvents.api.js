// ============================================================================
// SPORTS API — GROUP 1: ODDS, EVENTS, SCORE, BET SETTINGS
// ============================================================================
// Every route is copied 1:1 from tenexch (same path, same middleware, same
// handler). Mount with:  mountOddsEventsApi(app)
//
//  Prefix /api/user
//  GET  /all/sports/tree                    sport → league → event tree
//  GET  /all/sports/events                  events across sports, by start time
//  POST /cricket/all-data                   event list of one sport  { sid }       → AVRKHUB highlighthomePrivate
//  POST /cricket/get-sport-data-by-id       one match                { gmid, sid }
//  POST /cricket/get-match-private-data     LIVE ODDS of one match   { gmid, sid } → AVRKHUB gamedataPrivate
//  GET  /v1/sports-get_latest_events        latest events
//  GET  /v1/sports-gamedetailPrivate        match detail             ?gmid&etid
//  POST /cricket/market-list                admin "More Market" list { gmid, sid }
//  POST /cricket/score-card                 scorecard                { gmid, sid }
//  GET  /cricket/score-url                  score widget url         ?gmid&etid
//  GET  /virtual/event-media                virtual sports media     ?gmid&etid
//  GET  /virtual/cricketv-cards             virtual cricket cards    ?gmid&gtype
//  GET  /betting-config                     buffer secs + max odds + virtual limits
//  GET  /bet-limits/:event_id               per-market min/max of one event
//  GET  /stake-button-values                stake buttons (public read)
//  POST /stake-button-values         🔒     save stake buttons
//  GET  /buttonlist                  🔒     one-click stake list
//  POST /updatebuttonlist            🔒     save one-click stake list
// ============================================================================

import express from 'express';
import { CricketController, VirtualEventController, UserBettingConfigController as BettingConfigController,
  StakeButtonValueController, OneClickButtonListController, authMiddleware } from '../core/sports-core.js';

export const oddsEventsRouter = express.Router();
const r = oddsEventsRouter;

// ── events + odds ───────────────────────────────────────────────────────────
r.get('/all/sports/tree', CricketController.fetchTreeData);
r.get('/all/sports/events', CricketController.fetchSportsEvents);
r.post('/cricket/all-data', CricketController.fetchCricketData);
r.post('/cricket/get-sport-data-by-id', CricketController.getSportdetailsById);
r.post('/cricket/get-match-private-data', CricketController.GetMatchPrivateData);
r.get('/v1/sports-get_latest_events', CricketController.getLatestEvents);
r.get('/v1/sports-gamedetailPrivate', CricketController.getGameDetailPrivate);
r.post('/cricket/market-list', CricketController.GetMarketList); // admin More Market: stored + live markets

// ── score + virtual media ───────────────────────────────────────────────────
r.post('/cricket/score-card', CricketController.fetchScoreCard);
r.get('/cricket/score-url', CricketController.fetchScoreUrl);
r.get('/virtual/event-media', VirtualEventController.getEventMedia);
r.get('/virtual/cricketv-cards', VirtualEventController.getCricketVCards);

// ── bet settings the slip reads ─────────────────────────────────────────────
r.get('/betting-config', BettingConfigController.getBettingConfig);
r.get('/bet-limits/:event_id', BettingConfigController.getEventBetLimits);
r.get('/stake-button-values', StakeButtonValueController.getStakeButtonValues);
r.post('/stake-button-values', authMiddleware, StakeButtonValueController.updateStakeButtonValues);
// tenexch: oneClickButtonRoutes used router.use(authMiddleware) — same effect here
r.get('/buttonlist', authMiddleware, OneClickButtonListController.getButtonList);
r.post('/updatebuttonlist', authMiddleware, OneClickButtonListController.updateButtonList);

export const mountOddsEventsApi = (app) => {
  app.use('/api/user', oddsEventsRouter);
};

export default mountOddsEventsApi;
