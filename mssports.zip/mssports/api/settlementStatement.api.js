// ============================================================================
// SPORTS API — GROUP 3: MANUAL SETTLEMENT, ACCOUNT STATEMENT, ADMIN CONFIG
// ============================================================================
// Every route is copied 1:1 from tenexch (same path, same middleware, same
// handler). Mount with:  mountSettlementStatementApi(app)
// (Automatic settlement runs in the workers, not here.)
//
//  Prefix /api/user — account statement
//  POST /account-statement-v2         🔒  statement, max 31 days, one row per market (point_ledger)
//  POST /account-statement-v2/bets    🔒  drill-down: bets + winner behind one statement row
//
//  Prefix /api/internalsettle — manual settle (🔒 + owner only)
//  GET  /momatches                        match-odds/bookmaker markets with open bets
//  GET  /fanmatches                       fancy markets with open bets
//  POST /declareresult                    declare a result → settles via the settlement worker
//  POST /void                             void a market / one fancy session
//  GET  /open-bets                        open bets of one market
//  POST /void-single-bet                  void one open bet
//  GET  /settled-markets                  settled markets (last 24 h)
//  GET  /settled-bets                     settled bets of one market
//  POST /void-bet-after-settlement    🔑  reverse a settled bet      (needs transaction password)
//  POST /void-market-after-settlement 🔑  reverse a settled market   (needs transaction password)
//
//  Prefix /api/admin — sports config
//  GET  /sports-lock/get/:targetId     🔒      sport locks of a user/staff
//  POST /sports-lock/update            🔒      set sport lock
//  GET  /betlock/market-locks/:event_id     🔒 backoffice   market locks of an event
//  POST /betlock/toggle-market-lock         🔒 backoffice 🔑 lock/unlock one market
//  POST /betlock/bulk-toggle-market-lock    🔒 backoffice 🔑 lock/unlock many markets
//  GET|POST|DELETE /betting-config/buffer/sports (+ POST /bulk)          👑 bet buffer seconds
//  GET  /betting-config/bet-limits/inplay                                👑 live events for limits
//  GET  /betting-config/bet-limits/event/:event_id                       👑 markets of an event
//  POST /betting-config/bet-limits/event, DELETE .../event/:id           👑 per-market min/max
//  GET|POST|DELETE /betting-config/max-odds/sports                       👑 max odds caps
//  GET|PUT /betting-config/auto-void, GET /auto-void/tracker             👑 auto-void config
//  GET|POST /betting-config/auto-void/links, PUT|DELETE .../links/:id    👑 result source links
//  GET|PUT /betting-config/virtual-limits                                👑 virtual league limits
//  GET|POST|DELETE /commission-config/sports (+ POST /bulk)              👑 win commission
// ============================================================================

import express from 'express';
import { authMiddleware, maxDateRange, requireOwner, requireBackoffice, verifyTransactionPassword,
  verifyTransactionPasswordAs, MESSAGES, UserStatementController, ManualSettleController as settleController,
  SportsLockController, getMarketLockChildren, toggleMarketLock, bulkToggleMarketLock,
  AdminBettingConfigController as BettingConfigController, CommissionConfigController } from '../core/sports-core.js';

// ── /api/user — account statement ───────────────────────────────────────────
export const statementRouter = express.Router();
statementRouter.post('/account-statement-v2', authMiddleware, maxDateRange(31), UserStatementController.getAccountStatementV2);
statementRouter.post('/account-statement-v2/bets', authMiddleware, UserStatementController.getStatementMarketBets);

// ── /api/internalsettle — manual settle ─────────────────────────────────────
export const manualSettleRouter = express.Router();
const ms = manualSettleRouter;
ms.get('/momatches', authMiddleware, requireOwner, settleController.getMoMatches);
ms.get('/fanmatches', authMiddleware, requireOwner, settleController.getFanOpenBets);
ms.post('/declareresult', authMiddleware, requireOwner, settleController.declareResult);
ms.post('/void', authMiddleware, requireOwner, settleController.voidResult);
ms.get('/open-bets', authMiddleware, requireOwner, settleController.getOpenBetsForMarket);
ms.post('/void-single-bet', authMiddleware, requireOwner, settleController.voidSingleOpenBet);
// Sports — settle ho chuke markets ka void (admin "Void Bets (After Settlement)" page).
ms.get('/settled-markets', authMiddleware, requireOwner, settleController.getSettledMarkets);
ms.get('/settled-bets', authMiddleware, requireOwner, settleController.getSettledBets);
ms.post('/void-bet-after-settlement', authMiddleware, requireOwner, verifyTransactionPassword, settleController.voidBetAfterSettlement);
ms.post('/void-market-after-settlement', authMiddleware, requireOwner, verifyTransactionPassword, settleController.voidMarketAfterSettlement);

// ── /api/admin/sports-lock ──────────────────────────────────────────────────
export const sportsLockRouter = express.Router();
sportsLockRouter.use(authMiddleware);
sportsLockRouter.get('/get/:targetId', SportsLockController.getSportsLocks);
sportsLockRouter.post('/update', SportsLockController.updateSportsLock);

// ── /api/admin — bet locks, betting config, commission ──────────────────────
export const sportsAdminRouter = express.Router();
const ad = sportsAdminRouter;
const requireTxnCode = verifyTransactionPasswordAs(MESSAGES.ADMIN.TXN.MASTER_NOT_VALID);
ad.get('/betlock/market-locks/:event_id', authMiddleware, requireBackoffice, getMarketLockChildren);
ad.post('/betlock/toggle-market-lock', authMiddleware, requireBackoffice, requireTxnCode, toggleMarketLock);
ad.post('/betlock/bulk-toggle-market-lock', authMiddleware, requireBackoffice, requireTxnCode, bulkToggleMarketLock);

ad.get('/betting-config/buffer/sports', authMiddleware, requireOwner, BettingConfigController.getSportsBuffers);
ad.post('/betting-config/buffer/sports', authMiddleware, requireOwner, BettingConfigController.saveSportsBuffer);
ad.post('/betting-config/buffer/sports/bulk', authMiddleware, requireOwner, BettingConfigController.saveSportsBufferBulk);
ad.delete('/betting-config/buffer/sports', authMiddleware, requireOwner, BettingConfigController.resetSportsBuffer);
// 'inplay' is declared BEFORE the ':event_id' style routes so Express can't match it as an id.
ad.get('/betting-config/bet-limits/inplay', authMiddleware, requireOwner, BettingConfigController.getInplayEvents);
ad.get('/betting-config/bet-limits/event/:event_id', authMiddleware, requireOwner, BettingConfigController.getEventMarkets);
ad.post('/betting-config/bet-limits/event', authMiddleware, requireOwner, BettingConfigController.saveEventLimit);
ad.delete('/betting-config/bet-limits/event/:id', authMiddleware, requireOwner, BettingConfigController.deleteEventLimit);
ad.get('/betting-config/max-odds/sports', authMiddleware, requireOwner, BettingConfigController.getSportsMaxOdds);
ad.post('/betting-config/max-odds/sports', authMiddleware, requireOwner, BettingConfigController.saveSportsMaxOdds);
ad.delete('/betting-config/max-odds/sports', authMiddleware, requireOwner, BettingConfigController.resetSportsMaxOdds);
ad.get('/betting-config/auto-void', authMiddleware, requireOwner, BettingConfigController.getAutoVoid);
ad.put('/betting-config/auto-void', authMiddleware, requireOwner, BettingConfigController.saveAutoVoid);
ad.get('/betting-config/auto-void/tracker', authMiddleware, requireOwner, BettingConfigController.getAutoVoidTracker);
ad.get('/betting-config/auto-void/links', authMiddleware, requireOwner, BettingConfigController.listResultLinks);
ad.post('/betting-config/auto-void/links', authMiddleware, requireOwner, BettingConfigController.createResultLink);
ad.put('/betting-config/auto-void/links/:id', authMiddleware, requireOwner, BettingConfigController.updateResultLink);
ad.delete('/betting-config/auto-void/links/:id', authMiddleware, requireOwner, BettingConfigController.deleteResultLink);
ad.get('/betting-config/virtual-limits', authMiddleware, requireOwner, BettingConfigController.getVirtualLimits);
ad.put('/betting-config/virtual-limits', authMiddleware, requireOwner, BettingConfigController.saveVirtualLimits);

ad.get('/commission-config/sports', authMiddleware, requireOwner, CommissionConfigController.getSportsCommission);
ad.post('/commission-config/sports', authMiddleware, requireOwner, CommissionConfigController.saveSportsCommission);
ad.post('/commission-config/sports/bulk', authMiddleware, requireOwner, CommissionConfigController.saveSportsCommissionBulk);
ad.delete('/commission-config/sports', authMiddleware, requireOwner, CommissionConfigController.resetSportsCommission);

export const mountSettlementStatementApi = (app) => {
  app.use('/api/user', statementRouter);
  app.use('/api/internalsettle', manualSettleRouter);
  app.use('/api/admin/sports-lock', sportsLockRouter);
  app.use('/api/admin', sportsAdminRouter);
};

export default mountSettlementStatementApi;
