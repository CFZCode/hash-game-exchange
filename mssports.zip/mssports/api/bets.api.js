// ============================================================================
// SPORTS API — GROUP 2: PLACE BET, CURRENT BETS, EXPOSURE, BALANCE SOCKET
// ============================================================================
// Every route is copied 1:1 from tenexch (same path, same middleware, same
// handler). Mount with:  mountBetsApi(app)  and  setupBetsSocket(io)
//
//  Prefix /api/user
//  POST /place                        🔒  place a bet (server-side buffer → placeBet)
//  GET  /bet-result/:client_ref       🔒  outcome of a buffered bet (after page reload)
//  POST /place-combined               🔒  combined slip
//  POST /cancel-bet                   🔒  cancel an unmatched bet   { bet_id }
//  GET  /fancy-bets                   🔒  user's fancy bets
//  POST /matchexposures/match         🔒  market book / exposure of one match
//  GET  /cricket/sports-bets/user     🔒  Current Bets page
//  GET  /cricket/user-open-bets           open bets of a user on an event   ?eventid&user_id  (⚠ no auth in tenexch)
//  GET  /cricket/user-open-bets-grouped   { matchedBets, unmatchedBets }    (⚠ no auth in tenexch)
//  GET  /cricket/matched-bets/all         admin: every bet on an event ?eventid (⚠ no auth in tenexch)
//
//  Socket.IO (setupBetsSocket):
//  client → 'authenticate' {userId}      join room user_<id>
//  client → 'getBalance' / 'subscribeBalance' / 'unsubscribeBalance'
//  server → 'balanceUpdate' { userId, balance: { inr_balance, exposure } }
//  Workers publish balance pushes on Redis 'socket:balance_updates'; this
//  process relays them to room user_<id>.
// ============================================================================

import express from 'express';
import { authMiddleware, BetController as controller, placeBetBuffered, getBetResult, ExposureController,
  CricketController, setupSocketHandlers, setIO, BALANCE_UPDATES_CHANNEL, redisClient } from '../core/sports-core.js';

export const betsRouter = express.Router();
const r = betsRouter;

// ── place / cancel ──────────────────────────────────────────────────────────
r.post('/place', authMiddleware, placeBetBuffered);
// What happened to a bet the page lost track of (reload mid-buffer).
r.get('/bet-result/:client_ref', authMiddleware, getBetResult);
r.post('/place-combined', authMiddleware, controller.placeCombinedBet);
r.post('/cancel-bet', authMiddleware, controller.cancelBet);

// ── exposure ────────────────────────────────────────────────────────────────
r.post('/matchexposures/match', authMiddleware, ExposureController.getExposureById);

// ── current / open bets ─────────────────────────────────────────────────────
r.get('/fancy-bets', authMiddleware, controller.getFancyBets);
r.get('/cricket/sports-bets/user', authMiddleware, CricketController.getSportsBetsByUserId);
r.get('/cricket/user-open-bets', CricketController.getUserOpenBetsForEvent);
r.get('/cricket/user-open-bets-grouped', CricketController.getUserOpenBetsGrouped); // { matchedBets, unmatchedBets } split
r.get('/cricket/matched-bets/all', CricketController.getMatchedBetsByEvent); // total bets on particular event - admin

export const mountBetsApi = (app) => {
  app.use('/api/user', betsRouter);
};

// Socket.IO: player room + live balance/exposure, plus the worker → socket
// relay that tenexch had inline in server.js.
export const setupBetsSocket = (io) => {
  setIO(io);
  setupSocketHandlers(io);

  // A subscriber-mode ioredis client can't run other commands, so the relay
  // needs its own duplicate connection.
  const balanceUpdatesSub = redisClient.duplicate();
  balanceUpdatesSub.subscribe(BALANCE_UPDATES_CHANNEL).catch((err) => {
    console.error('❌ Failed to subscribe to balance updates channel:', err.message);
  });
  balanceUpdatesSub.on('message', (channel, message) => {
    if (channel !== BALANCE_UPDATES_CHANNEL) return;
    try {
      const payload = JSON.parse(message);
      if (payload && payload.userId != null) {
        io.to(`user_${payload.userId}`).emit('balanceUpdate', payload);
      }
    } catch (err) {
      console.error('❌ Bad balance update payload from worker:', err.message);
    }
  });
  return balanceUpdatesSub;
};

export default mountBetsApi;
