# MSSPORTS — How the sports module works

Code references use **original tenexch paths** (e.g. `sportsbet/betBuffer.js`). In this package, search the
bundle for the comment `// <path>`: `core/sports-core.js` for the API, `workers/*.worker.js` for workers.

```
 AVRKHUB sports feed (AVRKHUB_SPORTS_BASE_URL + AVRKHUB_SPORTS_KEY)
   GET /highlighthomePrivate?etid=<sid>        → event list {t1 live, t2 upcoming}
   GET /gamedataPrivate?gmid=<gmid>&etid=<sid> → every market + odds of one match
        │
        ▼
 API (api/*.api.js + core)
   CricketService.fetchCricketData   → writes Redis alleventss:{sid} (120 s)
   CricketService.GetMatchPrivateData→ 250 ms in-process cache + in-flight dedupe;
                                       also writes Redis odds:{gmid} (3 s) and marketlist:{gmid}
   POST /api/user/place → betBuffer (wait + live checks, fail-closed) → placeBet (1 DB txn)
        │  SportsBet row status 'open'
        ▼
 results worker (every 2 s)  ── GET {AVRKHUB_BASE_URL}/get_result?gmid&sid ──►
   market SETTLE/VOID → sports_event_settlement_jobs row → PUBLISH sports-settle:wake:{DB_NAME}
        ▼
 settlement worker (ONE instance, WORKER_MODE=1)
   claim job → claim bets → wallet + credits_ledger + point_ledger chain + commission
   → delete user_exposures rows → recompute total_exposures → PUBLISH socket:balance_updates
        ▼
 API relays to Socket.IO room user_{id}, event 'balanceUpdate'
```

---

## 1. Odds & events

- **Live path = `SPORTS_API_VERSION=v2`**: direct HTTP to AVRKHUB. The v1 path (read Redis `odds:` / `allevents:`) is dead.
- Market fields from `gamedataPrivate`: `mid, mname, gtype, status, min, max, maxb, section[]{sid, nat, gstatus, min, max, odds[]{otype back|lay, oname back1|lay1…, tno, odds, size}}`.
  The body is sometimes wrapped twice (`data.data`); the code unwraps it.
- **Racing trap**: on racing (sid 10 / 65) `maxb` is a flag (always 1); the real stake cap is `max`. On cricket `maxb` is a real cap.

**Redis keys**

| Key | Written by | TTL | Used for |
|---|---|---|---|
| `alleventss:{sid}` | API `fetchCricketData` (120 s); events worker (3 h) | | league resolver, sports tree/events |
| `odds:{gmid}` | API (side write) | 3 s | v1 only (dead) |
| `oddss:{gmid}` | odds worker | 3 s | **nobody** |
| `marketlist:{gmid}` (hash) + `:miss` | `helper/marketListStore.js` | 15 h cap | admin "More Market" |
| `league:evt:{gmid}` | `SportsLeagueResolver` | 12 h | league name on each bet |
| `cfg:buffer:v2`, `cfg:maxodds:v2`, `cfg:limits:virtual:v1`, `cfg:limits:event:{eventId}` | `BettingConfigService` | 300 s | buffer, max odds, limits |
| commission rule key | `CommissionConfigService` | 300 s | win commission |
| `sports-settle:wake:{DB_NAME}` (pub/sub) | results worker, manual declare | | instant settlement wake |
| `socket:balance_updates` (pub/sub) | workers | | relayed to Socket.IO |

## 2. Place bet — `POST /api/user/place` (🔒)

**Body fields (main ones)**

| Field | Meaning |
|---|---|
| `eventid` | match id = feed `gmid` |
| `match_id` | **market** id = feed `mid` (not the match!) |
| `sid` | sport id (4 cricket, 1 football, 2 tennis, 10 horse, 65 greyhound…) |
| `selection_name` | runner name; for fancy the session name (also the exposure row key) |
| `selection_id` | runner `section.sid` (buffer only) |
| `market_type` / `mname` | feed `mname` — **this picks the money branch** |
| `gtype` | feed gtype: `match`, `match1`, `fancy`, `fancy1`, `fancy2`, `khado`, `meter`, `oddeven`… |
| `game_type` | `MATCH`/`MO`, `BOOKMAKER`→`BM`, `FANCY`→`FAN` |
| `bet_type` | `back` / `lay` / `yes` / `no` |
| `odds` | price; for fancy = run line; for BM = per-100 rate |
| `stake_amount` | stake (INR) |
| `size` | bhav (fancy rate) or volume |
| `runners` | **required** array of runner names |
| `is_cashout`, `badlo`, `unmatched` | flags |
| `server_buffer` | `{ client_ref, selected_odds, edited, live_tracked, runner_name, initial_size, max_stake, cashout_diff, cashout_percent }` |

**Responses**
- **200**: `{ success, exposure, balanceDelta, oldBalance, newBalance, totalExposure, odds, stake, client_ref }`
- **400**: `{ success:false, error, code }`. Codes:
  - `NO_MARKET_REF`, `FEED_UNAVAILABLE`, `SUSPENDED:<state>`, `MARKET_TYPE_MISMATCH`
  - `FANCY_DRIFT`, `BLOCKED_IN_BUFFER`, `NO_LIVE_PRICE`
  - `CASHOUT_RANGE`, `MANUAL_LIMIT`, `ODDS_MOVED`
- **409**: the same `client_ref` is still running.
- **403**: lock failure. The body is `{ success:false, message }` — note the key is `message`, not `error`.
- After a page reload, `GET /bet-result/:client_ref` returns `pending | accepted | rejected | unknown` (kept in memory for 5 min).

**Pipeline**
1. **Buffer** (`sportsbet/betBuffer.js`, no DB transaction yet)
   - Wait the buffer seconds: `bet_buffer_configs` grid → owner global → env default.
   - Every 500 ms, read the shared live-odds poller (`liveOdds.js`, 700 ms per match).
   - Final checks:
     - suspension: `SUSPENDED` / `BALL RUNNING` / `INACTIVE` / market missing → reject (**fail-closed**)
     - fancy line drift ±0.01
     - live-tracked markets book at the **current feed price**
     - edited limit price, cashout re-stake
2. **placeBet** (`sportsbet/sportbetscontroller.js`, one transaction)
   - Locks:
     - `users.bet_locked` and every upline `staff.bet_locked`
     - `BetLock` (MatchOdds / OtherMarkets)
     - `UserMatchLocks`, `UserEventMarketLocks` (user + upline)
     - `PlatformGames` + `StaffMarketLocks`
     - sports-lock hierarchy
   - Limits:
     - virtual league limits
     - stake min/max: owner override > feed (`maxb` → `max` → `section.max`; racing ignores `maxb`) > env
     - line markets have their own limits
     - horse racing only within 5 min of the off
     - max-odds cap (cricket can be "Oneday & T20 only")
   - `Wallets` row `FOR UPDATE`, then `user_exposures` rows `FOR UPDATE`.
   - Compute the new book (§3). `balanceChange = |worst new| − |worst old|`; if more than `cash`, reject.
   - Upsert `user_exposures` (`category='sports'`).
   - Insert the `SportsBet` row (`status 'open'`, `liability`, `exposure_after_bet`).
   - `Wallets.cash -= delta`, plus a `debit_ledger` row.
   - Recompute `total_exposures`, then commit.
   - No socket push here: the 3 s `subscribeBalance` tick shows the new balance.
3. **Combined slip** `POST /place-combined`: 2–10 legs on one market, all-or-nothing, in one shared transaction.
4. **Cancel** `POST /cancel-bet { bet_id }`
   - Only the user's own **unmatched**, open MO/BM bets.
   - Soft-cancel, replay the remaining bets of that market, refund `oldWorst − newWorst` to `cash`.

## 3. Exposure maths (`user_exposures`)

- **One row per (user, market id, game_type, runner)**, signed `exposure_amount` (negative = loss if that outcome wins).
- **Match Odds**: back adds `stake×(odds−1)` on the runner and `−stake` on the others; lay is the mirror.
- **Bookmaker**: same, with the odds normalised (`odds>100 → odds/100+1`, else `1+odds/100`).
- **Fancy family**: four rows per selection: `sel` (the money row), plus `sel+'lay'`, `sel+'back'`, `sel+'totalstake'` (legacy helpers, excluded from totals).
  - session / khado: worst P&L over every line → `sel`
  - badlo: exact-run spike
  - meter: `(min(runs, line+150) − line) × stake`
  - fancy1 / oddeven: bhav `(odds−1)×100`
  - line markets (`fancy2`): evens ±stake, worst run over all open bets
- **User total** (`total_exposures`) = `TOTAL_EXPOSURE_SQL`:
  - MIN per team-market group
  - plus the sum of independent fancy-family rows
  - helper rows excluded
  - It is a snapshot, never recomputed on read.

## 4. Results worker (`workers/results.worker.js`)

- Every 2 s it loads `SportsBet` with `status IN ('open','manual')` and `game_type IN ('MO','BM','FAN')`.
- One feed call per event (cached, rate-limited, retried).
- **Declared** = the matched market's status is `SETTLE` or `VOID`. How a bet's market is matched:
  - MO/BM: by teams or title
  - racing: by runner set
  - fancy: by name + `mname`, then a relaxed name; line markets are derived from session totals
- `status='manual'` bets are always "declared" (the owner declared them).
- Writes one job row per bet (unique `user_id, eventid, bet_id`), then the Redis wake.
- **Auto-void**: when MATCH_ODDS / BOOKMAKER are settled but a bet is still open after `delay_seconds` (`auto_void_config`), that market is voided.

## 5. Settlement worker (`workers/settlement.worker.js`)

- **Job claim:** `queued → processing`. Stuck jobs go back to `queued` after `SETTLE_STUCK_MS`.
- **Duplicate guard ("claim before money"):** `UPDATE … SET status='closed' WHERE id IN (...) AND status IN ('open','manual')`. 0 rows means skip.
- **MO / BM / racing / big-runner:** money is market-level, from `user_exposures`.
  - `cash += |most negative exposure| + exposure[winner]` (floored at 0)
  - `inr_balance += exposure[winner]`
  - one `credits_ledger` row per market
- **Fancy:** per bet. Release the selection's lock, then `cash += net` and `inr_balance += net`.
  - session yes wins if `runs ≥ line` (+stake×size/100); no wins `+stake`
  - fancy1 / oddeven / Tied Match / khado / meter / badlo / line markets each have their own rule
  - an unknown result is requeued, never guessed
- **Void / suspended:** refund path (`initiateRefund`), `bet_void_audit` row.
- **Points:** `WalletService.updateAllPointHierarchy(betId,'SPORTS')` writes `point_ledger` for the whole upline chain.
  It is idempotent through the unique `(wallet_id, entry_ref)`.
- **Commission:** after the payout, only when the net win > 0, using the `commission_configs` rule.
  It writes a `reason='commission'` ledger row and the matching points.
- **Then:**
  - delete the exposure rows
  - recompute `total_exposures`
  - `emitBalanceUpdate`, which publishes on Redis because the worker has no `io`

## 6. Manual settle (`/api/internalsettle`, owner only)

- `declareresult` writes `mannual_result`, flips the bets to `manual` and queues them; the worker pays out.
  - MO/BM need `winnerName`.
  - Session / line / khado / meter / badlo need `winnerId` (the run total) + `fancyName`.
  - fancy1 / oddeven need `winnerName`.
- `void` / `void-single-bet`: release the lock to `cash`, `refund` ledger row, close the bets, audit row.
- `void-bet-after-settlement` / `void-market-after-settlement` (+ transaction password, within 24 h):
  - reverse cash, inr, user counters, commission and points
  - `write_statement=true` writes a visible `settlement_void` row; `false` deletes the settlement row.

## 7. Account statement (`POST /api/user/account-statement-v2`)

- Body: `{ reportType: ALL|TRANSACTION|SPORTS, fromDate, toDate, search, page, limit }`, max 31 days.
- Source: **`point_ledger`** rows of the user's wallet.
- Grouping: one row per market. The key is `match_id` for MO/BM and the fancy name for FAN. Commission and void rows get their own lines.
- The first row is a synthetic "Opening pts" row.
- Row fields: `{ date, credit, debit, closing, description, fromto, category, betId, sportId, eventId, matchId, marketType, gameType, fancyName, eventType }`.
- Drill-down `POST /account-statement-v2/bets { matchId, eventId, fancyName? }`:
  - returns the bets, `header`, `winner` (last ` / ` part of the settlement ledger description), `totalBets`, `totalWin`
  - per-bet win comes from `sportsNet()`

## 8. Current bets

| Route | Auth | Params | Returns |
|---|---|---|---|
| `GET /api/user/cricket/sports-bets/user` | 🔒 | `page, limit, search, betType (all/back/lay), status (matchbet/unmatchbet/deletebet/all)` | `{ data, pagination{total,page,limit,total_pages,total_stake} }` |
| `GET /cricket/user-open-bets` | ⚠ none | `eventid, user_id` | open/manual/matched bets of the event |
| `GET /cricket/user-open-bets-grouped` | ⚠ none | `eventid, user_id` | `{ matchedBets, unmatchedBets }` |
| `GET /fancy-bets` | 🔒 | `runner, match_id/event_id, sport_id, market_type` | open fancy rows (run-amount ladder) |
| `POST /matchexposures/match` | 🔒 | `{ user_id, match_id }` | exposure rows of the match |

## 9. Key `SportsBet` columns

- **Ids:** `match_id` = **market id**; `eventid` = match gmid.
- **`game_type`:** `MO` | `BM` | `FAN`.
- **`bet_type`:** back/lay for MO/BM, yes/no for fancy.
- **`market_type`:** feed `mname`.
- **`status`:** `open` → `closed` (settled) / `cancelled` / `manual`.
- **`result_status`:** `pending` → `won` / `loss` / `void`…
- **Amounts:**
  - `liability`: back = stake; lay = stake×(odds−1); BM normalised; session no = size×stake/100
  - `size`: bhav for session markets; 0 for MO/BM and line markets
- **Other:** `job_id` (settlement), `league_name`, `runners` (JSON).
