// sportsMain/config/sid.js
var sidArray = [
  { eid: 4, active: true },
  // Cricket
  { eid: 1, active: true },
  // Football
  { eid: 2, active: true },
  // Tennis
  { eid: 8, active: true },
  // Table Tennis
  { eid: 68, active: true },
  // Esoccer
  { eid: 10, active: true },
  // Horse Racing
  { eid: 65, active: true },
  // Greyhound Racing
  { eid: 15, active: true },
  // Basketball
  { eid: 69, active: true },
  // Wrestling
  { eid: 18, active: true },
  // Volleyball
  { eid: 22, active: true },
  // Badminton
  { eid: 59, active: true },
  // Snooker
  { eid: 57, active: true },
  // Darts
  { eid: 6, active: true },
  // Boxing
  { eid: 3, active: true },
  // Mixed Martial Arts
  { eid: 58, active: true },
  // American Football
  { eid: 11, active: true },
  // E Games
  { eid: 19, active: true },
  // Ice Hockey
  { eid: 9, active: true },
  // Futsal
  { eid: 40, active: true },
  // Politics
  { eid: 67, active: true },
  // Boat Racing
  { eid: 52, active: true },
  // Motor Sports
  { eid: 12, active: true },
  // (not present in the upstream sports tree)
  { eid: 66, active: true }
  // Kabaddi
  // { eid: 5, active: true },
  // { eid: 55, active: true },
  // { eid: 7, active: true },
  // { eid: 13, active: true },
  // { eid: 39, active: true },
  // { eid: 14, active: true },
  // { eid: 16, active: true },
  // { eid: 17, active: true },
  // { eid: 20, active: true },
  // { eid: 21, active: true },
  // { eid: 23, active: true },
  // { eid: 24, active: true },
  // { eid: 25, active: true },
  // { eid: 26, active: true },
  // { eid: 27, active: true },
  // { eid: 28, active: true },
  // { eid: 29, active: true },
  // { eid: 30, active: true },
  // { eid: 31, active: true },
  // { eid: 32, active: true },
  // { eid: 33, active: true },
  // { eid: 34, active: true },
  // { eid: 35, active: true },
  // { eid: 36, active: true },
  // { eid: 37, active: true },
  // { eid: 38, active: true },
  // { eid: 41, active: true },
  // { eid: 42, active: true },
  // { eid: 43, active: true },
  // { eid: 44, active: true },
  // { eid: 45, active: true },
  // { eid: 46, active: true },
  // { eid: 47, active: true },
  // { eid: 48, active: true },
  // { eid: 49, active: true },
  // { eid: 50, active: true },
  // { eid: 51, active: true },
  // { eid: 53, active: true },
  // { eid: 54, active: true },
  // { eid: 56, active: true },
  // { eid: 60, active: true },
  // { eid: 61, active: true },
  // { eid: 62, active: true },
  // { eid: 63, active: true },
  // { eid: 64, active: true }
];

// config/redisClient.js
import Redis from "ioredis";
import dotenv from "dotenv";
dotenv.config();
var redis = new Redis({
  host: process.env.REDIS_HOST || "127.0.0.1",
  port: process.env.REDIS_PORT || 6379,
  password: process.env.REDIS_PASSWORD || void 0,
  // undefined means no password
  db: process.env.REDIS_DB || 1,
  retryStrategy: (times) => {
    const delay = Math.min(times * 50, 2e3);
    return delay;
  }
});
redis.on("connect", () => {
  console.log("\u2705 Connected to Redis");
});
redis.on("error", (err) => {
  console.error("\u274C Redis Connection Error:", err);
});
var redisClient_default = redis;

// sportsMain/helper/apihelper.js
import got from "got";
import http from "http";
import https from "https";
import dns from "dns";
import pLimit from "p-limit";

// sportsMain/config/env.js
var env_default = {
  SPORTS_BASE_URL: "http://primarydiamondfeeds.turnkeyxgaming.com:8000",
  SPORTS_API_KEY: process.env.SPORTS_API_KEY
  // was hardcoded in tenexch; moved to .env for the export
};

// sportsMain/helper/apihelper.js
var SPORTS_BASE_URL = "http://167.71.224.37:9000";
var SPORTS_API_KEY = env_default.SPORTS_API_KEY;
var agent = {
  http: new http.Agent({
    keepAlive: true,
    keepAliveMsecs: 15e3,
    maxSockets: 2e3,
    maxFreeSockets: 1e3,
    scheduling: "lifo"
  }),
  https: new https.Agent({
    keepAlive: true,
    keepAliveMsecs: 15e3,
    maxSockets: 2e3,
    maxFreeSockets: 1e3,
    scheduling: "lifo"
  })
};
var dnsCache = /* @__PURE__ */ new Map();
var DNS_TTL = 5 * 60 * 1e3;
var dnsLookup = (hostname, options, callback) => {
  const now = Date.now();
  const cached = dnsCache.get(hostname);
  if (cached && cached.expires > now) {
    return callback(null, cached.address, cached.family);
  }
  dns.lookup(hostname, options, (err, address, family) => {
    if (!err) {
      dnsCache.set(hostname, {
        address,
        family,
        expires: now + DNS_TTL
      });
    }
    callback(err, address, family);
  });
};
var prewarmDNS = () => {
  [SPORTS_BASE_URL].forEach((url) => {
    try {
      const host = new URL(url).hostname;
      dns.lookup(host, {}, () => {
      });
    } catch {
    }
  });
};
var COMMON_HEADERS = {
  // "x-turnkeyxgaming-key": SPORTS_API_KEY,
  accept: "application/json",
  // "accept-encoding": "gzip",
  connection: "keep-alive"
};
var CACHE_TTL = 3e3;
var responseCache = /* @__PURE__ */ new Map();
var getCache = (key) => {
  const item = responseCache.get(key);
  if (!item) return null;
  if (Date.now() > item.expiry) {
    responseCache.delete(key);
    return null;
  }
  return item.data;
};
var setCache = (key, data) => {
  responseCache.set(key, {
    data,
    expiry: Date.now() + CACHE_TTL
  });
};
var requestConfig = {
  method: "GET",
  agent,
  headers: COMMON_HEADERS,
  responseType: "json",
  retry: { limit: 0 },
  throwHttpErrors: true,
  decompress: true,
  followRedirect: false,
  http2: true,
  dnsLookup,
  timeout: {
    lookup: 200,
    connect: 800,
    secureConnect: 800,
    socket: 2e3,
    response: 1500
  }
};
var fetchSportsData = async (endpoint) => {
  const cached = getCache(endpoint);
  if (cached) return cached;
  const url = SPORTS_BASE_URL + endpoint;
  const res = await got(url, {
    ...requestConfig,
    timeout: { ...requestConfig.timeout, request: 3200 }
  });
  setCache(endpoint, res.body);
  return res.body;
};
var limit = pLimit(45);
prewarmDNS();

// sportsMain/cron/odds.js
var INTERVAL_SECONDS = 2;
var REDIS_TTL = 3;
var isRunning = false;
var runAllEventsCron = async () => {
  if (isRunning) return;
  const startTime = Date.now();
  isRunning = true;
  try {
    const activeSports = sidArray.filter((sport) => sport.active);
    const getMatchesPromises = activeSports.map(async (sport) => {
      const sportId = sport.eid;
      try {
        const cachedMatches = await redisClient_default.get(`alleventss:${sportId}`);
        if (!cachedMatches) return { sportId, matches: [] };
        const matches = JSON.parse(cachedMatches);
        const gmids = [
          ...new Set(
            matches.filter((match) => match && match.gmid).map((match) => match.gmid)
          )
        ];
        return { sportId, gmids };
      } catch (err) {
        console.error(`\u274C Redis get failed for sport ${sportId}:`, err.message);
        return { sportId, gmids: [] };
      }
    });
    const sportsWithGmids = await Promise.all(getMatchesPromises);
    const allOddsPromises = [];
    sportsWithGmids.forEach(({ sportId, gmids }) => {
      if (!gmids || gmids.length === 0) return;
      gmids.forEach((gmid) => {
        const promise = (async () => {
          const endpoint = `/gamedataPrivate?etid=${sportId}&gmid=${gmid}`;
          try {
            const response = await fetchSportsData(endpoint);
            const oddsData = response?.data || {};
            if (Array.isArray(oddsData) && oddsData.length > 0) {
              await redisClient_default.setex(
                `oddss:${gmid}`,
                REDIS_TTL,
                JSON.stringify(oddsData)
              );
              return { sportId, gmid, success: true, hasData: true };
            }
            return { sportId, gmid, success: true, hasData: false };
          } catch (err) {
            console.error(
              `\u274C Odds API failed for ${sportId}:${gmid}:`,
              err.message
            );
            return { sportId, gmid, success: false, error: err.message };
          }
        })();
        allOddsPromises.push(promise);
      });
    });
    const oddsResults = await Promise.allSettled(allOddsPromises);
    const totalGmids = allOddsPromises.length;
    const successful = oddsResults.filter(
      (r) => r.status === "fulfilled" && r.value.success
    );
    const withData = oddsResults.filter(
      (r) => r.status === "fulfilled" && r.value.success && r.value.hasData
    );
    const failed = oddsResults.filter(
      (r) => r.status === "rejected" || !r.value?.success
    );
    const endTime = Date.now();
    const processingTime = endTime - startTime;
    console.log(
      `\u26A1 ${totalGmids} matches processed in ${processingTime}ms | \u2705 ${successful.length} success (${withData.length} with odds) | \u274C ${failed.length} failed`
    );
    if (processingTime > 1800) {
      console.warn(
        `\u26A0\uFE0F Processing took ${processingTime}ms - slower than 1.8 second interval!`
      );
    }
  } catch (err) {
    console.error("\u274C Cron error:", err.message);
  } finally {
    isRunning = false;
  }
};
runAllEventsCron();
setInterval(runAllEventsCron, INTERVAL_SECONDS * 1e3);
