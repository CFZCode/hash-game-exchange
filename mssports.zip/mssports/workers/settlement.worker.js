var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// config/redisClient.js
var redisClient_exports = {};
__export(redisClient_exports, {
  default: () => redisClient_default
});
import Redis from "ioredis";
import dotenv2 from "dotenv";
var redis, redisClient_default;
var init_redisClient = __esm({
  "config/redisClient.js"() {
    dotenv2.config();
    redis = new Redis({
      host: process.env.REDIS_HOST || "127.0.0.1",
      port: process.env.REDIS_PORT || 6379,
      password: process.env.REDIS_PASSWORD || void 0,
      // undefined means no password
      db: process.env.REDIS_DB || 1,
      retryStrategy: (times) => {
        const delay = Math.min(times * 50, 2e3);
        return delay;
      }
    });
    redis.on("connect", () => {
      console.log("\u2705 Connected to Redis");
    });
    redis.on("error", (err) => {
      console.error("\u274C Redis Connection Error:", err);
    });
    redisClient_default = redis;
  }
});

// sportsbet/betresult/settlementv2.js
import fs from "fs";
import path2 from "path";
import IORedis from "ioredis";

// sportsbet/betresult/resultCache.js
var cache = /* @__PURE__ */ new Map();
var inflight = /* @__PURE__ */ new Map();
function makeCachedGet({ ax: ax3, ttlMs = 2500, rateLimit = null }) {
  return async function cachedGet2(url, params, cfg = {}) {
    const key = `${url}?gmid=${params?.gmid}&sid=${params?.sid}`;
    const hit = cache.get(key);
    if (hit && Date.now() - hit.at < ttlMs) return hit.res;
    const pending2 = inflight.get(key);
    if (pending2) return pending2;
    const p = (async () => {
      try {
        if (rateLimit) await rateLimit();
        const res = await ax3.get(url, { params, ...cfg });
        if (res.status === 200 || res.status === 404) cache.set(key, { at: Date.now(), res });
        return res;
      } finally {
        inflight.delete(key);
      }
    })();
    inflight.set(key, p);
    return p;
  };
}
function makePayloadGetter(cachedGet2, url) {
  return async function getPayload(gmid, sid) {
    const res = await cachedGet2(url, { gmid, sid: sid || "4" });
    if (res.status !== 200) return null;
    return typeof res?.data === "string" ? JSON.parse(res.data) : res.data;
  };
}

// sportsbet/betresult/settlementv2.js
import http from "http";
import https from "https";
import axios2 from "axios";
import { Op as Op2 } from "sequelize";

// helper/meterMarket.js
var METER_MAX_RUNS = 150;
var isMeterMarket = (marketType) => ["meter", "meters"].includes(String(marketType || "").toLowerCase());
var isYesSide = (betType) => ["yes", "back"].includes(String(betType || "").toLowerCase());
function meterPnl({ runs, line, stake, betType }) {
  const capped = Math.min(Number(runs), Number(line) + METER_MAX_RUNS);
  const diff = (capped - Number(line)) * Number(stake);
  const signed = isYesSide(betType) ? diff : -diff;
  return signed === 0 ? 0 : signed;
}

// helper/badloMarket.js
var isBadloBet = (bet) => bet?.badlo === true || String(bet?.badlo) === "true";
var isYesSide2 = (betType) => ["yes", "back"].includes(String(betType || "").toLowerCase());
function badloPnl({ runs, line, stake, betType }) {
  if (Number(runs) !== Number(line)) return 0;
  const signed = (isYesSide2(betType) ? 1 : -1) * Number(stake);
  return signed === 0 ? 0 : signed;
}

// helper/lineMarket.js
var isLineMarket = (marketType) => /\bline$/i.test(String(marketType || "").trim());
var LINE_EXPOSURE_GAME_TYPE = "fancy2";
var exposureIdentity = ({ marketType, selectionName, badlo = false }) => isLineMarket(marketType) ? { game_type: LINE_EXPOSURE_GAME_TYPE, team_name: String(marketType) } : { game_type: marketType, team_name: selectionName };

// helper/lineResult.js
var LINE_RE = /^(1st|2nd)\s+innings\s+(\d+)\s+overs?\s+line$/i;
var TEAM_TOTAL_RE = /^(\d+)\s+OVER\s+RUN\s+(.+?)(?:\s+ADV)?$/i;
var INNINGS_OVER_RE = /^(1ST|2ND)\s+INN\s+(\d+)\s+OVER\b/i;
var MULTI_INNINGS_RE = /\b(3RD|4TH)\s+INN/;
var ODDEVEN_RE = /^(1ST|2ND)\s+INN\s+(\d+)\s+OVER\s+RUN\s+ODD\s+EVEN$/i;
var norm = (s) => String(s || "").trim().replace(/\s+/g, " ").toUpperCase();
var inningsNo = (s) => /^1/.test(s) ? 1 : 2;
function parseLineMarket(marketType) {
  const m = LINE_RE.exec(String(marketType || "").trim());
  return m ? { innings: inningsNo(m[1]), overs: Number(m[2]) } : null;
}
function teamTotals(markets) {
  const out = /* @__PURE__ */ new Map();
  for (const m of markets) {
    if (norm(m?.gtype) !== "FANCY") continue;
    const name = norm(m?.marketName);
    if (name.includes("BHAV")) continue;
    const t = TEAM_TOTAL_RE.exec(name);
    if (!t) continue;
    const overs = Number(t[1]);
    const team = t[2].replace(/[.:\-]+$/, "").trim();
    if (/\s2$/.test(team)) continue;
    if (!out.has(overs)) out.set(overs, /* @__PURE__ */ new Map());
    const byTeam = out.get(overs);
    const runs = m?.status === "SETTLE" ? Number(m?.winnerId) : null;
    const prev = byTeam.get(team);
    if (prev && prev.runs !== runs) byTeam.set(team, { status: "CONFLICT", runs: null });
    else byTeam.set(team, { status: m?.status, runs });
  }
  return out;
}
function inningsEvidence(markets) {
  const ev = { 1: /* @__PURE__ */ new Map(), 2: /* @__PURE__ */ new Map() };
  const add = (inn, overs, fn) => {
    if (!ev[inn].has(overs)) ev[inn].set(overs, []);
    ev[inn].get(overs).push(fn);
  };
  for (const m of markets) {
    if (m?.status !== "SETTLE") continue;
    const g = norm(m?.gtype);
    if (g === "CRICKETCASINO") {
      const c = INNINGS_OVER_RE.exec(norm(m?.mname));
      const d = /^(\d)\s+NUMBER$/.exec(norm(m?.winnerName));
      if (c && d) add(inningsNo(c[1]), Number(c[2]), (runs) => runs % 10 === Number(d[1]));
    } else if (g === "ODDEVEN") {
      const o = ODDEVEN_RE.exec(norm(m?.marketName));
      const w = Number(m?.winnerId);
      if (o && (w === 1 || w === 2)) add(inningsNo(o[1]), Number(o[2]), (runs) => runs % 2 === 1 === (w === 1));
    }
  }
  return ev;
}
function score(inn, team, totals, ev) {
  let checked = 0, miss = 0;
  for (const [overs, checks] of ev[inn]) {
    const mine = totals.get(overs)?.get(team);
    if (!mine || mine.status !== "SETTLE" || !Number.isFinite(mine.runs)) continue;
    for (const check of checks) {
      checked++;
      if (!check(mine.runs)) miss++;
    }
  }
  return { checked, miss };
}
var MIN_CLUES = 2;
function battingOrder(markets) {
  if (markets.some((m) => MULTI_INNINGS_RE.test(norm(m?.mname)) || MULTI_INNINGS_RE.test(norm(m?.marketName)))) return null;
  const totals = teamTotals(markets);
  const teams = /* @__PURE__ */ new Set();
  for (const byTeam of totals.values()) for (const t of byTeam.keys()) teams.add(t);
  if (teams.size < 1 || teams.size > 2) return null;
  const ev = inningsEvidence(markets);
  const order = { 1: null, 2: null, totals };
  for (const team of teams) {
    const s1 = score(1, team, totals, ev);
    const s2 = score(2, team, totals, ev);
    const is1 = s1.checked >= MIN_CLUES && s1.miss === 0 && s2.miss > 0;
    const is2 = s2.checked >= MIN_CLUES && s2.miss === 0 && s1.miss > 0;
    if (is1 && is2) return null;
    const inn = is1 ? 1 : is2 ? 2 : null;
    if (!inn) continue;
    if (order[inn]) return null;
    order[inn] = team;
  }
  if (teams.size === 2 && (order[1] ? !order[2] : order[2])) {
    const known = order[1] ? 1 : 2;
    const inn = known === 1 ? 2 : 1;
    const other = [...teams].find((t) => t !== order[known]);
    if (score(inn, other, totals, ev).miss === 0) order[inn] = other;
  }
  return order[1] || order[2] ? order : null;
}
function resolveLineMarketFromFeed(markets, marketType) {
  const line = parseLineMarket(marketType);
  if (!line || !Array.isArray(markets)) return null;
  const order = battingOrder(markets);
  if (!order) return null;
  const team = order[line.innings];
  if (!team) return null;
  const row = order.totals.get(line.overs)?.get(team);
  if (!row) return null;
  const derived = `${line.overs} OVER RUN ${team}`;
  if (row.status === "VOID") {
    return { gtype: "LINE", mname: marketType, marketName: "TOTAL RUNS", status: "VOID", winnerId: null, winnerName: null, derivedFrom: derived };
  }
  if (row.status !== "SETTLE" || !Number.isFinite(row.runs)) return null;
  return { gtype: "LINE", mname: marketType, marketName: "TOTAL RUNS", status: "SETTLE", winnerId: row.runs, winnerName: null, derivedFrom: derived };
}

// helper/fanMarketName.js
var isKhadoBet = (bet) => String(bet?.market_type || "").toLowerCase() === "khado";
var fanMarketName = (bet) => isKhadoBet(bet) ? bet?.selection_name || bet?.fancy_name || null : bet?.fancy_name || bet?.selection_name || null;

// helper/exposureBucket.js
var PER_SELECTION_MARKETS = /* @__PURE__ */ new Set([
  "Normal",
  "Ball By Ball",
  "Over By Over",
  "khado",
  "meter",
  "fancy1",
  "oddeven",
  "badlo"
]);
var isPerSelectionMarket = (marketType) => PER_SELECTION_MARKETS.has(String(marketType || "")) || isLineMarket(marketType);
var selectionExposureRows = (sel) => [sel, `${sel}lay`, `${sel}back`, `${sel}totalstake`];

// services/admin/voidAuditService.js
import { randomUUID } from "crypto";

// model/admin/BetVoidAudit.js
import { DataTypes } from "sequelize";

// config/db.js
import { Sequelize } from "sequelize";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
var __filename = fileURLToPath(import.meta.url);
var __dirname = path.dirname(__filename);
var envPath = path.resolve(__dirname, "../.env");
dotenv.config({ path: envPath });
var IS_API_PROCESS = path.basename(process.env.pm_exec_path || process.argv[1] || "") === "server.js";
var POOL_MAX = Number(process.env.DB_POOL_MAX) || (IS_API_PROCESS ? 25 : 10);
var sequelize = new Sequelize(
  process.env.DB_NAME,
  process.env.DB_USER,
  process.env.DB_PASSWORD,
  {
    host: process.env.DB_HOST,
    port: process.env.DB_PORT || 5432,
    dialect: "postgres",
    logging: false,
    // set to true for SQL logs
    pool: {
      max: POOL_MAX,
      // max connections in pool (see POOL_MAX above)
      min: 2,
      // min connections kept open
      acquire: 3e4,
      // max ms to wait for a connection before throwing error
      idle: 1e4,
      // max ms a connection can be idle before being released
      evict: 1e3
      // how often to check for idle connections (ms)
    }
  }
);
var db_default = sequelize;

// model/admin/BetVoidAudit.js
var VOID_TYPES = {
  OPEN_BET: "OPEN_BET",
  // POST /void-single-bet
  MARKET: "MARKET",
  // POST /void  (market / one fancy session)
  AFTER_SETTLEMENT: "AFTER_SETTLEMENT",
  // POST /void-bet-after-settlement, /void-market-after-settlement
  FEED_SUSPENDED: "FEED_SUSPENDED",
  // settlementv2: provider declared the market SUSPENDED
  AUTO_TIMEOUT: "AUTO_TIMEOUT"
  // autoVoid.js: still open N s after MATCH_ODDS/BOOKMAKER declared
};
var money = { type: DataTypes.DECIMAL(15, 2), allowNull: true };
var BetVoidAudit = db_default.define(
  "BetVoidAudit",
  {
    id: { type: DataTypes.BIGINT, autoIncrement: true, primaryKey: true },
    // ── which void operation ────────────────────────────────────────────────
    void_group_id: { type: DataTypes.UUID, allowNull: false },
    is_representative: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false },
    void_type: { type: DataTypes.STRING(32), allowNull: false },
    // ── which bet ───────────────────────────────────────────────────────────
    bet_id: { type: DataTypes.BIGINT, allowNull: false },
    bet_kind: { type: DataTypes.STRING(16), allowNull: false, defaultValue: "SPORTS" },
    user_id: { type: DataTypes.BIGINT, allowNull: false },
    username: { type: DataTypes.STRING(255), allowNull: true },
    // Bet identity FROZEN at void time. Denormalised on purpose: a report must
    // still read correctly if the bet row is later edited or purged.
    match_id: { type: DataTypes.STRING(255), allowNull: true },
    eventid: { type: DataTypes.STRING(255), allowNull: true },
    match_title: { type: DataTypes.STRING(255), allowNull: true },
    market_type: { type: DataTypes.STRING(255), allowNull: true },
    game_type: { type: DataTypes.STRING(100), allowNull: true },
    selection_name: { type: DataTypes.STRING(255), allowNull: true },
    bet_type: { type: DataTypes.STRING(32), allowNull: true },
    odds: { type: DataTypes.DECIMAL(15, 4), allowNull: true },
    stake_amount: money,
    liability: money,
    // ── PRE ─────────────────────────────────────────────────────────────────
    status_before: { type: DataTypes.STRING(32), allowNull: true },
    result_status_before: { type: DataTypes.STRING(32), allowNull: true },
    cash_before: money,
    inr_before: money,
    // The bucket's own liability (the `sel` row for a per-selection market, the
    // worst row for MO/BM) — what this void was actually holding.
    exposure_before: money,
    total_exposure_before: money,
    // ── POST ────────────────────────────────────────────────────────────────
    status_after: { type: DataTypes.STRING(32), allowNull: true },
    result_status_after: { type: DataTypes.STRING(32), allowNull: true },
    cash_after: money,
    inr_after: money,
    exposure_after: money,
    total_exposure_after: money,
    // Money returned FOR THE GROUP (repeated on each row of the group — sum over
    // DISTINCT void_group_id). 0 is a legitimate value: a void of a bet whose
    // liability was already held by nothing releases nothing.
    refund_amount: { type: DataTypes.DECIMAL(15, 2), allowNull: true },
    exposure_rows_deleted: { type: DataTypes.INTEGER, allowNull: true },
    // credits_ledger row this void wrote, when it wrote one.
    ledger_id: { type: DataTypes.BIGINT, allowNull: true },
    // ── who and how ─────────────────────────────────────────────────────────
    actor: { type: DataTypes.STRING(255), allowNull: true },
    actor_role: { type: DataTypes.STRING(64), allowNull: true },
    ip_address: { type: DataTypes.STRING(64), allowNull: true },
    browser: { type: DataTypes.TEXT, allowNull: true },
    note: { type: DataTypes.TEXT, allowNull: true },
    // Historical rows reconstructed from SportsBet + credits_ledger. Their
    // wallet/exposure columns are NULL and must not be read as zero.
    backfilled: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false },
    created_at: { type: DataTypes.DATE, allowNull: false, defaultValue: DataTypes.NOW }
  },
  {
    tableName: "bet_void_audit",
    timestamps: false,
    indexes: [
      // Reports filter by time first, then narrow.
      { fields: ["created_at"] },
      { fields: ["user_id", "created_at"] },
      { fields: ["void_group_id"] },
      { fields: ["void_type", "created_at"] },
      // The tracker joins from SportsBet to "did this void get audited?".
      { fields: ["bet_kind", "bet_id"] }
    ]
  }
);
var BetVoidAudit_default = BetVoidAudit;

// services/admin/voidAuditService.js
var newVoidGroupId = () => randomUUID();
var num = (v) => v === null || v === void 0 || v === "" ? null : Number(v);
var recordVoidAudit = async ({
  voidGroupId,
  voidType,
  bets = [],
  representativeBetId = null,
  before = {},
  after = {},
  refundAmount = null,
  exposureRowsDeleted = null,
  ledgerId = null,
  context = {},
  betKind = "SPORTS",
  backfilled = false
}, t = null) => {
  if (!bets.length) return [];
  const rows = bets.map((b) => ({
    void_group_id: voidGroupId,
    is_representative: representativeBetId != null && Number(b.id) === Number(representativeBetId),
    void_type: voidType,
    bet_id: b.id,
    bet_kind: betKind,
    user_id: b.user_id,
    username: context.username || b.username || null,
    match_id: b.match_id != null ? String(b.match_id) : null,
    eventid: b.eventid != null ? String(b.eventid) : b.event_id != null ? String(b.event_id) : null,
    match_title: b.match_title || b.event_name || null,
    market_type: b.market_type || null,
    game_type: b.game_type || null,
    // sports rows call it `selection_name` (`selection` kept as a fallback).
    selection_name: b.selection_name || b.selection || null,
    bet_type: b.bet_type || null,
    odds: num(b.odds),
    stake_amount: num(b.stake_amount ?? b.stake),
    liability: num(b.liability ?? b.exposer),
    status_before: before.status ?? b.status ?? null,
    result_status_before: before.resultStatus ?? b.result_status ?? null,
    cash_before: num(before.cash),
    inr_before: num(before.inr),
    exposure_before: num(before.exposure),
    total_exposure_before: num(before.totalExposure),
    status_after: after.status ?? null,
    result_status_after: after.resultStatus ?? null,
    cash_after: num(after.cash),
    inr_after: num(after.inr),
    exposure_after: num(after.exposure),
    total_exposure_after: num(after.totalExposure),
    refund_amount: num(refundAmount),
    exposure_rows_deleted: exposureRowsDeleted == null ? null : Number(exposureRowsDeleted),
    ledger_id: ledgerId == null ? null : Number(ledgerId),
    actor: context.actor || null,
    actor_role: context.actor_role || null,
    ip_address: context.ip_address || null,
    browser: context.browser || null,
    note: context.note || null,
    backfilled,
    created_at: /* @__PURE__ */ new Date()
  }));
  return BetVoidAudit_default.bulkCreate(rows, t ? { transaction: t } : {});
};

// model/user/SportsSettlementReport.js
import { DataTypes as DataTypes2 } from "sequelize";
var SportsSettlementReport = db_default.define(
  "SportsSettlementReport",
  {
    id: {
      type: DataTypes2.BIGINT,
      primaryKey: true,
      autoIncrement: true
      // uses nextval('sports_settlement_report_id_seq') in Postgres
    },
    job_id: {
      type: DataTypes2.UUID,
      allowNull: true
    },
    bet_id: {
      type: DataTypes2.BIGINT,
      allowNull: false,
      unique: true
      // UNIQUE constraint
    },
    user_id: {
      type: DataTypes2.TEXT,
      allowNull: false
    },
    eventid: {
      type: DataTypes2.TEXT,
      allowNull: false
    },
    match_id: {
      type: DataTypes2.TEXT,
      allowNull: true
    },
    game_type: {
      type: DataTypes2.TEXT,
      allowNull: false
    },
    market_type: {
      type: DataTypes2.TEXT,
      allowNull: true
    },
    fancy_name: {
      type: DataTypes2.TEXT,
      allowNull: true
    },
    selection_name: {
      type: DataTypes2.TEXT,
      allowNull: true
    },
    user_selection_yn: {
      type: DataTypes2.TEXT,
      allowNull: true
    },
    resolved_winner: {
      type: DataTypes2.TEXT,
      allowNull: true
    },
    resolved_team: {
      type: DataTypes2.TEXT,
      allowNull: true
    },
    actual_numeric: {
      type: DataTypes2.DECIMAL,
      allowNull: true
    },
    rule_op: {
      type: DataTypes2.TEXT,
      allowNull: true
    },
    rule_threshold: {
      type: DataTypes2.DECIMAL,
      allowNull: true
    },
    credit_amount: {
      type: DataTypes2.DECIMAL,
      allowNull: false,
      defaultValue: 0
    },
    exposures_map: {
      type: DataTypes2.JSONB,
      allowNull: true
    },
    api_snapshot: {
      type: DataTypes2.JSONB,
      allowNull: true
    },
    decision_path: {
      type: DataTypes2.JSONB,
      allowNull: true
    },
    created_at: {
      type: DataTypes2.DATE,
      allowNull: true,
      defaultValue: DataTypes2.NOW
    }
  },
  {
    tableName: "sports_settlement_report",
    timestamps: false
    // created_at handled manually
  }
);
var SportsSettlementReport_default = SportsSettlementReport;

// model/user/SportsEventResultScan.js
import { DataTypes as DataTypes3 } from "sequelize";
var SportsEventResultScan = db_default.define(
  "SportsEventResultScan",
  {
    user_id: {
      type: DataTypes3.TEXT,
      allowNull: false,
      primaryKey: true
    },
    eventid: {
      type: DataTypes3.TEXT,
      allowNull: false,
      primaryKey: true
    },
    declared: {
      type: DataTypes3.BOOLEAN,
      allowNull: false,
      defaultValue: false
    },
    counts: {
      type: DataTypes3.JSONB,
      allowNull: false,
      defaultValue: {}
    },
    checked_at: {
      type: DataTypes3.DATE,
      allowNull: false,
      defaultValue: DataTypes3.NOW
    }
  },
  {
    tableName: "sports_event_result_scan",
    // 👈 your table
    timestamps: false,
    indexes: [
      {
        unique: true,
        fields: ["user_id", "eventid"]
      }
    ]
  }
);

// model/user/SportsEventResultSummary.js
import { DataTypes as DataTypes4 } from "sequelize";
var SportsEventResultSummary = db_default.define(
  "SportsEventResultSummary",
  {
    id: {
      type: DataTypes4.BIGINT,
      autoIncrement: true,
      primaryKey: true
    },
    user_id: {
      type: DataTypes4.TEXT,
      allowNull: false
    },
    eventid: {
      type: DataTypes4.TEXT,
      allowNull: false
    },
    declared: {
      type: DataTypes4.BOOLEAN,
      allowNull: false,
      defaultValue: false
    },
    counts: {
      type: DataTypes4.JSONB,
      allowNull: false,
      defaultValue: {}
    },
    result_meta: {
      type: DataTypes4.JSONB,
      allowNull: true
    },
    sections: {
      type: DataTypes4.JSONB,
      allowNull: true
    },
    recorded_at: {
      type: DataTypes4.DATE,
      allowNull: false,
      defaultValue: DataTypes4.NOW
    }
  },
  {
    tableName: "sports_event_result_summary",
    timestamps: false
    // no createdAt/updatedAt
  }
);

// model/admin/Wallet.js
import { DataTypes as DataTypes7 } from "sequelize";

// model/admin/Staff.js
import { DataTypes as DataTypes6 } from "sequelize";

// model/admin/Role.js
import { DataTypes as DataTypes5 } from "sequelize";
var Role = db_default.define("Role", {
  role_id: {
    type: DataTypes5.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  role: {
    type: DataTypes5.STRING,
    allowNull: false,
    unique: true
  },
  power: {
    type: DataTypes5.JSON,
    allowNull: false,
    defaultValue: []
  },
  level: {
    type: DataTypes5.STRING,
    allowNull: false
  },
  is_owner: {
    type: DataTypes5.BOOLEAN,
    defaultValue: false
  },
  is_company: {
    type: DataTypes5.BOOLEAN,
    defaultValue: false
  },
  max_downline_percentage: {
    type: DataTypes5.DECIMAL(5, 2),
    defaultValue: 100,
    comment: "Max % this role can distribute down"
  }
}, {
  timestamps: false
});
var Role_default = Role;

// model/admin/Staff.js
var Staff = db_default.define("Staff", {
  staff_id: {
    type: DataTypes6.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  username: {
    type: DataTypes6.STRING,
    allowNull: false,
    unique: true
  },
  fullname: {
    type: DataTypes6.STRING,
    allowNull: true
  },
  city: {
    type: DataTypes6.STRING,
    allowNull: true
  },
  // "Mobile Number" on the admin create-account form. The form has always
  // sent it for staff too, but there was no column to keep it in, so More →
  // Additional Information showed a blank Mobile Number for every staff
  // account (user, 2026-09-21). Added by ensureStaffPhoneNumberColumn() in
  // config/dbInit.js, the same idempotent way the other late columns were.
  phone_number: {
    type: DataTypes6.STRING,
    allowNull: true
  },
  email: {
    type: DataTypes6.STRING,
    allowNull: true,
    unique: true,
    validate: {
      isEmail: true
    }
  },
  password: {
    type: DataTypes6.STRING,
    allowNull: false
  },
  role_id: {
    type: DataTypes6.INTEGER,
    allowNull: false,
    references: {
      model: Role_default,
      key: "role_id"
    }
  },
  role: {
    type: DataTypes6.STRING,
    allowNull: false,
    comment: "Denormalized role name for quick lookup (e.g., SUPER_ADMIN, ADMIN, USER)"
  },
  level: {
    type: DataTypes6.STRING,
    allowNull: false,
    comment: "Denormalized level (L1, L2, ..., L6)"
  },
  parent_id: {
    type: DataTypes6.INTEGER,
    allowNull: true
    // ✅ REMOVED the references block - let associations handle it
  },
  parent_owner_id: {
    type: DataTypes6.INTEGER,
    allowNull: true,
    comment: "ID of the owner who created this staff member (if applicable)"
  },
  percentage: {
    type: DataTypes6.DECIMAL(8, 3),
    allowNull: true,
    defaultValue: null
  },
  credit_limit: {
    type: DataTypes6.DECIMAL(15, 2),
    allowNull: false,
    defaultValue: 0,
    comment: "Maximum credit allowed for this staff member"
  },
  active: {
    type: DataTypes6.BOOLEAN,
    allowNull: false,
    defaultValue: true,
    comment: "Indicates if the staff member is active"
  },
  first_login: {
    type: DataTypes6.BOOLEAN,
    defaultValue: false
  },
  // Operator-set permission, ticked on the create-account form. false = this
  // account may NOT change its own password once the mandatory first-login
  // change (first_login: false -> true) is done. Default true so every
  // pre-existing account keeps behaving exactly as before.
  passwordChangeAllowed: {
    type: DataTypes6.BOOLEAN,
    allowNull: false,
    defaultValue: true,
    comment: "false = account cannot change its own password after the first-login change"
  },
  rules_accepted: {
    type: DataTypes6.BOOLEAN,
    defaultValue: false,
    comment: "True once the rules modal has been accepted after login"
  },
  transaction_password: {
    type: DataTypes6.STRING,
    allowNull: true,
    comment: "Stored as plain text"
  },
  txn_password_attempts: {
    type: DataTypes6.INTEGER,
    allowNull: true,
    defaultValue: 10,
    comment: "Transaction password attempts left; 0 locks txn actions + login until the parent changes this staff password (which resets it to 10)"
  },
  // ── Secure auth (2FA) ────────────────────────────────────────────────
  // securityAuthType is the source of truth for HOW this account logs in:
  // 'telegram' | 'google' | null. telegram2FAEnabled/telegramChatId stay as
  // the Telegram transport; googleAuthSecret is the base32 TOTP secret.
  googleAuthSecret: {
    type: DataTypes6.STRING,
    allowNull: true
  },
  securityAuthType: {
    type: DataTypes6.STRING,
    allowNull: true,
    defaultValue: null
  },
  telegramChatId: {
    type: DataTypes6.STRING,
    allowNull: true
  },
  telegram2FAEnabled: {
    type: DataTypes6.BOOLEAN,
    defaultValue: false
  },
  bet_locked: {
    type: DataTypes6.BOOLEAN,
    defaultValue: false,
    comment: "If true, this staff and all downline cannot place bets"
  },
  exp_limit: {
    type: DataTypes6.DECIMAL(20, 2),
    allowNull: true,
    defaultValue: null,
    comment: "Max exposure limit for the staff"
  },
  bal_down: {
    type: DataTypes6.DECIMAL(15, 2),
    allowNull: true,
    defaultValue: 0,
    comment: "Balance down value for the staff member"
  },
  bal_up: {
    type: DataTypes6.DECIMAL(15, 2),
    allowNull: true,
    defaultValue: 0,
    comment: "Balance up value for the staff member"
  },
  login_id: {
    type: DataTypes6.STRING,
    allowNull: true,
    comment: "Unique ID for the current active login session (single-session enforcement)"
  }
}, {
  tableName: "staff",
  // ✅ Explicitly set lowercase table name
  timestamps: true,
  paranoid: true
});
Staff.belongsTo(Role_default, {
  foreignKey: "role_id",
  as: "roleDetails"
});
Staff.belongsTo(Staff, {
  foreignKey: "parent_id",
  as: "parent"
});
Staff.hasMany(Staff, {
  foreignKey: "parent_id",
  as: "children"
});
var Staff_default = Staff;

// model/admin/Wallet.js
function calculateProfitLoss(instance) {
  const cashReceived = parseFloat(instance.getDataValue("cash_received")) || 0;
  const inrBalance = parseFloat(instance.getDataValue("inr_balance")) || 0;
  const profitLoss = parseFloat((inrBalance - cashReceived).toFixed(2));
  const verdict = profitLoss >= 0 ? "profit" : "loss";
  instance.setDataValue("profit_loss", profitLoss);
  instance.setDataValue("verdict", verdict);
}
var Wallet = db_default.define(
  "Wallet",
  {
    wallet_id: {
      type: DataTypes7.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    // Generic Reference Fields
    user_id: { type: DataTypes7.INTEGER, allowNull: true, comment: "Reference for normal user wallet (end user)" },
    staff_id: { type: DataTypes7.INTEGER, allowNull: true, comment: "Reference for staff wallet (admin/supermaster/master)" },
    owner_id: { type: DataTypes7.INTEGER, allowNull: true, comment: "Reference for owner wallet (top-level company or super admin)" },
    // Wallet Classification
    user_type: {
      type: DataTypes7.ENUM("OWNER", "COMPANY", "SUPERADMIN", "ADMIN", "SUPERMASTER", "MASTER", "AGENT", "USER"),
      allowNull: false
    },
    // Wallet Info
    username: { type: DataTypes7.STRING, allowNull: false, unique: true },
    // Core Financial Fields
    inr_balance: { type: DataTypes7.DECIMAL(18, 2), allowNull: false, defaultValue: 0 },
    cash: { type: DataTypes7.DECIMAL(18, 2), allowNull: false, defaultValue: 0 },
    credit: { type: DataTypes7.DECIMAL(18, 2), allowNull: false, defaultValue: 0 },
    cash_received: { type: DataTypes7.DECIMAL(18, 2), allowNull: false, defaultValue: 0 },
    // Initial credit handed over at account creation (set once, first time)
    all_point: { type: DataTypes7.DECIMAL(18, 2), allowNull: false, defaultValue: 0 },
    // Cash settlement ka running total: upper_point = apne upline ke saath hua hisaab,
    // down_point = apne downline ke saath hua hisaab
    upper_point: { type: DataTypes7.DECIMAL(18, 2), allowNull: false, defaultValue: 0 },
    down_point: { type: DataTypes7.DECIMAL(18, 2), allowNull: false, defaultValue: 0 },
    // Category-wise settlement points ka running total
    sports_pts: { type: DataTypes7.DECIMAL(18, 2), allowNull: false, defaultValue: 0 },
    sportsbook_pts: { type: DataTypes7.DECIMAL(18, 2), allowNull: false, defaultValue: 0 },
    // Calculated Metrics
    profit_loss: { type: DataTypes7.DECIMAL(18, 2), allowNull: false, defaultValue: 0 },
    verdict: { type: DataTypes7.ENUM("profit", "loss"), allowNull: false, defaultValue: "profit" },
    // NEW – total commission the user has **received** (cumulative)
    totalCommission: {
      type: DataTypes7.DECIMAL(18, 2),
      allowNull: false,
      defaultValue: 0,
      comment: "Cumulative platform-fee commission earned by this wallet"
    }
  },
  {
    tableName: "Wallets",
    timestamps: true,
    hooks: {
      beforeCreate: calculateProfitLoss,
      beforeUpdate: calculateProfitLoss,
      // Recompute on read so increment()/bulk-update paths cannot serve a stale figure.
      // Fires for instances, raw:true rows and findAll alike (verified against this
      // codebase's query shapes). Rows that did not select the source columns — e.g.
      // aggregate queries like SUM(profit_loss) AS downPL — are skipped untouched.
      afterFind: (result) => {
        if (!result) return result;
        const rows = Array.isArray(result) ? result : [result];
        for (const row of rows) {
          if (!row) continue;
          const isInstance = typeof row.getDataValue === "function";
          const inr = isInstance ? row.getDataValue("inr_balance") : row.inr_balance;
          const recv = isInstance ? row.getDataValue("cash_received") : row.cash_received;
          if (inr === void 0 || recv === void 0) continue;
          const pl = parseFloat(((parseFloat(inr) || 0) - (parseFloat(recv) || 0)).toFixed(2));
          const verdict = pl >= 0 ? "profit" : "loss";
          if (isInstance) {
            row.setDataValue("profit_loss", pl);
            row.setDataValue("verdict", verdict);
            row.changed("profit_loss", false);
            row.changed("verdict", false);
          } else {
            row.profit_loss = pl;
            row.verdict = verdict;
          }
        }
        return result;
      }
    }
  }
);
Wallet.belongsTo(Staff_default, {
  foreignKey: "staff_id",
  as: "staff",
  constraints: false
});
var Wallet_default = Wallet;

// model/user/CreditsLedger.js
import { DataTypes as DataTypes8 } from "sequelize";
var CreditsLedger = db_default.define(
  "CreditsLedger",
  {
    id: {
      type: DataTypes8.BIGINT,
      primaryKey: true,
      autoIncrement: true
    },
    user_id: {
      type: DataTypes8.TEXT,
      allowNull: false
    },
    bet_id: {
      type: DataTypes8.BIGINT,
      allowNull: true,
      comment: "Related bet ID for this ledger entry"
    },
    currency: {
      type: DataTypes8.TEXT,
      allowNull: true,
      defaultValue: "INR"
    },
    amount: {
      type: DataTypes8.DECIMAL,
      allowNull: false,
      comment: "Raw transaction amount (+win / -loss)"
    },
    reason: {
      type: DataTypes8.TEXT,
      allowNull: false
    },
    description: {
      type: DataTypes8.TEXT,
      allowNull: true
    },
    eventid: {
      type: DataTypes8.TEXT,
      allowNull: true
    },
    job_id: {
      type: DataTypes8.UUID,
      allowNull: true
    },
    match_id: {
      type: DataTypes8.TEXT,
      allowNull: true
    },
    meta: {
      type: DataTypes8.JSONB,
      allowNull: true
    },
    market_type: {
      type: DataTypes8.TEXT,
      allowNull: true
    },
    sport_id: {
      type: DataTypes8.TEXT,
      allowNull: true
    },
    commission: {
      type: DataTypes8.DECIMAL(18, 2),
      allowNull: true,
      comment: "2% platform fee deducted from winning amount (NULL for losses / non-win)"
    },
    netamount: {
      type: DataTypes8.DECIMAL(18, 2),
      allowNull: true,
      comment: "Amount credited after commission (amount - commission). NULL for non-win"
    },
    profit: {
      type: DataTypes8.DECIMAL(18, 2),
      allowNull: true,
      comment: "Winning amount (only for wins)"
    },
    loss: {
      type: DataTypes8.DECIMAL(18, 2),
      allowNull: true,
      comment: "Loss amount (only for losses)"
    },
    closing: {
      type: DataTypes8.DECIMAL(18, 2),
      allowNull: true,
      comment: "Closing amount (only for current user proffit ratio)"
    },
    category: {
      type: DataTypes8.STRING(20),
      allowNull: true,
      comment: "SPORTS - identifies settlement source"
    },
    points_applied: {
      type: DataTypes8.BOOLEAN,
      allowNull: false,
      defaultValue: false
    },
    balance: {
      type: DataTypes8.DECIMAL(18, 2),
      allowNull: true,
      defaultValue: 0,
      comment: "User wallet balance after this ledger entry"
    },
    created_at: {
      type: DataTypes8.DATE,
      allowNull: true,
      defaultValue: DataTypes8.NOW
    }
  },
  {
    tableName: "credits_ledger",
    timestamps: false,
    indexes: [
      { name: "credits_ledger_user_id_idx", fields: ["user_id"] },
      { name: "credits_ledger_eventid_idx", fields: ["eventid"] },
      { name: "credits_ledger_created_at_idx", fields: ["created_at"] }
    ]
  }
);
var CreditsLedger_default = CreditsLedger;

// model/user/UserExposure.js
import { DataTypes as DataTypes9 } from "sequelize";
var UserExposure = db_default.define(
  "UserExposure",
  {
    id: {
      type: DataTypes9.INTEGER,
      autoIncrement: true,
      primaryKey: true
    },
    user_id: {
      type: DataTypes9.BIGINT,
      allowNull: false
    },
    match_id: {
      type: DataTypes9.STRING,
      allowNull: false
    },
    event_id: {
      type: DataTypes9.STRING,
      allowNull: true
    },
    team_name: {
      type: DataTypes9.STRING,
      allowNull: false
    },
    exposure_amount: {
      type: DataTypes9.DECIMAL(15, 2),
      allowNull: false,
      defaultValue: 0
    },
    match_title: {
      type: DataTypes9.STRING(255),
      allowNull: true
    },
    game_type: {
      type: DataTypes9.STRING(100),
      allowNull: true
    },
    category: {
      type: DataTypes9.STRING(100),
      allowNull: true
      // or false if DB has NOT NULL
    },
    created_at: {
      type: DataTypes9.DATE,
      allowNull: false,
      defaultValue: DataTypes9.NOW
    },
    updated_at: {
      type: DataTypes9.DATE,
      allowNull: false,
      defaultValue: DataTypes9.NOW
    }
  },
  {
    tableName: "user_exposures",
    timestamps: false,
    // we manually manage timestamps
    indexes: [
      {
        unique: true,
        fields: ["user_id", "match_id", "team_name", "game_type"]
      }
    ]
  }
);
var UserExposure_default = UserExposure;

// model/user/TotalExposure.js
import { DataTypes as DataTypes10 } from "sequelize";
var TotalExposure = db_default.define(
  "TotalExposure",
  {
    id: {
      type: DataTypes10.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    user_id: {
      type: DataTypes10.INTEGER,
      allowNull: false,
      unique: true
      // 🔥 REQUIRED for upsert
    },
    total_exposure: {
      type: DataTypes10.DECIMAL(15, 2),
      // ✅ money-safe
      allowNull: false,
      defaultValue: 0
    }
  },
  {
    tableName: "total_exposures",
    timestamps: true
  }
);
var TotalExposure_default = TotalExposure;

// model/user/SportsBet.js
import { DataTypes as DataTypes11 } from "sequelize";
var SportsBet = db_default.define(
  "SportsBet",
  {
    id: {
      type: DataTypes11.INTEGER,
      autoIncrement: true,
      primaryKey: true
    },
    user_id: {
      type: DataTypes11.BIGINT,
      allowNull: false
    },
    game_type: {
      type: DataTypes11.STRING(100),
      allowNull: false
    },
    match_title: {
      type: DataTypes11.STRING(255)
    },
    team_one: {
      type: DataTypes11.STRING(255),
      allowNull: true
    },
    team_two: {
      type: DataTypes11.STRING(255),
      allowNull: true
    },
    selection_name: {
      type: DataTypes11.STRING(255),
      allowNull: true
    },
    category: {
      type: DataTypes11.STRING(100),
      allowNull: true
    },
    bet_type: {
      type: DataTypes11.STRING(100),
      allowNull: false
    },
    market_type: {
      type: DataTypes11.STRING(100),
      allowNull: true,
      defaultValue: null
      // or "Over By Over" if you want
    },
    odds: {
      type: DataTypes11.DECIMAL(10, 4),
      allowNull: false
    },
    stake_amount: {
      type: DataTypes11.DECIMAL(15, 2),
      allowNull: false
    },
    event_name: {
      type: DataTypes11.STRING(255)
    },
    original_currency: {
      type: DataTypes11.STRING(10),
      allowNull: true,
      defaultValue: "INR"
    },
    original_amount: {
      type: DataTypes11.DECIMAL(15, 2),
      allowNull: true
    },
    usd_amount: {
      type: DataTypes11.DECIMAL(15, 2),
      allowNull: true
    },
    liability: {
      type: DataTypes11.DECIMAL(15, 2),
      allowNull: true
    },
    match_start_time: {
      type: DataTypes11.DATE,
      allowNull: true
    },
    match_end_time: {
      type: DataTypes11.DATE,
      allowNull: true
    },
    created_at: {
      type: DataTypes11.DATE,
      defaultValue: DataTypes11.NOW
    },
    updated_at: {
      type: DataTypes11.DATE,
      defaultValue: DataTypes11.NOW
    },
    match_id: {
      type: DataTypes11.STRING(100),
      allowNull: true
    },
    exposure_after_bet: {
      type: DataTypes11.DECIMAL(15, 2),
      allowNull: true
    },
    status: {
      type: DataTypes11.STRING(20),
      allowNull: true
    },
    eventid: {
      type: DataTypes11.TEXT
    },
    job_id: {
      type: DataTypes11.UUID,
      allowNull: true
    },
    ip_address: {
      type: DataTypes11.TEXT,
      allowNull: true
    },
    browser: {
      type: DataTypes11.TEXT,
      allowNull: true
    },
    fancy_name: {
      type: DataTypes11.TEXT,
      allowNull: true
    },
    result_status: {
      type: DataTypes11.TEXT,
      defaultValue: "pending"
    },
    fixed: {
      type: DataTypes11.INTEGER,
      defaultValue: 0
    },
    counts: {
      type: DataTypes11.INTEGER,
      defaultValue: 2
    },
    sport_id: {
      type: DataTypes11.TEXT,
      allowNull: true
    },
    unmatched: {
      type: DataTypes11.BOOLEAN,
      defaultValue: false
    },
    unmatched_odds: {
      type: DataTypes11.DECIMAL(10, 4),
      allowNull: true
    },
    size: {
      type: DataTypes11.INTEGER,
      allowNull: true
    },
    runners: {
      type: DataTypes11.JSON,
      allowNull: true
    },
    gtype: {
      type: DataTypes11.TEXT,
      allowNull: true
    },
    // League / competition name from the feed (cname), sent by the client at
    // placement. Only used for display — the statement Result modal prints
    // "Sport -> League -> Match -> Market". Column is added on boot by
    // ensureSportsBetLeagueColumn() in config/dbInit.js.
    league_name: {
      type: DataTypes11.STRING(255),
      allowNull: true
    },
    // Badlo is an EXACT-RUN swap that lives INSIDE an ordinary session market
    // ("Normal"), flagged per runner by the feed's `ik`. It is a property of
    // the BET, not of the market — so it is a flag here rather than a
    // market_type value. Overloading market_type with 'badlo' (the first
    // attempt) put these rows in their own market bucket, printed "badlo" as
    // the market name in the bet list, and split the runner's Normal book.
    // See helper/badloMarket.js.
    badlo: {
      type: DataTypes11.BOOLEAN,
      allowNull: false,
      defaultValue: false
    }
  },
  {
    tableName: "SportsBet",
    timestamps: false,
    indexes: [
      { fields: ["user_id"] },
      { fields: ["match_id"] },
      { fields: ["eventid"] },
      { fields: ["status"] },
      { fields: ["result_status"] },
      { fields: ["sport_id"] },
      { fields: ["job_id"] },
      { fields: ["user_id", "status"] },
      { fields: ["user_id", "match_id"] },
      { fields: ["user_id", "eventid", "status"] }
    ]
  }
);
var SportsBet_default = SportsBet;

// model/user/MarketWin.js
import { DataTypes as DataTypes12 } from "sequelize";
var MarketWin = db_default.define(
  "MarketWin",
  {
    id: {
      type: DataTypes12.BIGINT,
      autoIncrement: true,
      primaryKey: true
    },
    totalbets: {
      type: DataTypes12.BIGINT,
      allowNull: false
    },
    matchid: {
      type: DataTypes12.TEXT,
      allowNull: false
    },
    eventid: {
      type: DataTypes12.TEXT,
      allowNull: false
    },
    team1ex: {
      type: DataTypes12.DECIMAL(18, 2),
      allowNull: false
    },
    team2ex: {
      type: DataTypes12.DECIMAL(18, 2),
      allowNull: false
    },
    drawex: {
      type: DataTypes12.DECIMAL(18, 2),
      allowNull: true
    },
    winteam: {
      type: DataTypes12.TEXT,
      allowNull: false
    },
    matchname: {
      type: DataTypes12.TEXT,
      allowNull: false
    },
    payout: {
      type: DataTypes12.DECIMAL(18, 2),
      allowNull: false
    },
    created_at: {
      type: DataTypes12.DATE,
      allowNull: true,
      defaultValue: DataTypes12.NOW
    },
    user_id: {
      type: DataTypes12.BIGINT,
      allowNull: true
    },
    created_at: {
      type: DataTypes12.DATE,
      allowNull: true,
      defaultValue: DataTypes12.NOW
    }
  },
  {
    tableName: "marketwins",
    schema: "public",
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at"
  }
);
var MarketWin_default = MarketWin;

// model/user/FanWin.js
import { DataTypes as DataTypes13 } from "sequelize";
var FanWin = db_default.define(
  "FanWin",
  {
    id: {
      type: DataTypes13.INTEGER,
      autoIncrement: true,
      primaryKey: true
    },
    user_id: {
      type: DataTypes13.BIGINT,
      allowNull: false,
      field: "user_id"
      // maps correctly to DB
    },
    fancyname: {
      type: DataTypes13.STRING(255),
      allowNull: false
    },
    selection: {
      type: DataTypes13.STRING(100),
      allowNull: false
    },
    runsodds: {
      type: DataTypes13.DECIMAL(10, 4),
      // allows 1.4600
      allowNull: false
    },
    payout: {
      type: DataTypes13.DECIMAL(15, 2),
      allowNull: false
    },
    created_at: {
      type: DataTypes13.DATE,
      allowNull: true,
      defaultValue: DataTypes13.NOW
    },
    eventid: {
      type: DataTypes13.TEXT,
      allowNull: false
    },
    matchid: {
      type: DataTypes13.STRING(100),
      allowNull: false
    }
  },
  {
    tableName: "fanwins",
    schema: "public",
    timestamps: false
  }
);
var FanWin_default = FanWin;

// model/user/SportsEventSettlementJobs.js
import { DataTypes as DataTypes14 } from "sequelize";
var SportsEventSettlementJob = db_default.define(
  "SportsEventSettlementJob",
  {
    job_id: {
      type: DataTypes14.UUID,
      defaultValue: DataTypes14.UUIDV4,
      primaryKey: true
    },
    user_id: {
      type: DataTypes14.TEXT,
      allowNull: false
    },
    eventid: {
      type: DataTypes14.TEXT,
      allowNull: false
    },
    status: {
      type: DataTypes14.TEXT,
      allowNull: false,
      defaultValue: "queued"
    },
    priority: {
      type: DataTypes14.INTEGER,
      allowNull: false,
      defaultValue: 5
    },
    run_after: {
      type: DataTypes14.DATE,
      allowNull: false,
      defaultValue: DataTypes14.NOW
    },
    payload: {
      type: DataTypes14.JSONB,
      allowNull: false
    },
    error_msg: {
      type: DataTypes14.TEXT,
      allowNull: true
    },
    created_at: {
      type: DataTypes14.DATE,
      allowNull: false,
      defaultValue: DataTypes14.NOW
    },
    updated_at: {
      type: DataTypes14.DATE,
      allowNull: false,
      defaultValue: DataTypes14.NOW
    },
    bet_type: {
      type: DataTypes14.TEXT,
      allowNull: true
    },
    bet_id: {
      type: DataTypes14.TEXT,
      allowNull: true
    }
  },
  {
    tableName: "sports_event_settlement_jobs",
    timestamps: false,
    indexes: [
      {
        // this MUST match your conflictFields and be unique
        unique: true,
        fields: ["user_id", "eventid", "bet_id"],
        name: "uniq_user_event_bet"
      },
      {
        fields: ["status"]
      }
    ]
  }
);
var SportsEventSettlementJobs_default = SportsEventSettlementJob;

// model/user/User.js
import { DataTypes as DataTypes16 } from "sequelize";
import bcrypt from "bcryptjs";

// model/admin/Affiliate.js
import { DataTypes as DataTypes15 } from "sequelize";
var Affiliate = db_default.define("Affiliate", {
  uid: {
    type: DataTypes15.INTEGER,
    primaryKey: true,
    allowNull: false,
    references: {
      model: "users",
      // Reference the Users table
      key: "user_id"
    }
  },
  name: {
    type: DataTypes15.STRING,
    allowNull: false
  },
  referral_link: {
    type: DataTypes15.STRING,
    allowNull: false,
    unique: true
  },
  referral_code: {
    type: DataTypes15.STRING,
    allowNull: false,
    unique: true
  },
  friends: {
    type: DataTypes15.INTEGER,
    defaultValue: 0
  }
});

// model/user/User.js
var User = db_default.define("User", {
  user_id: {
    type: DataTypes16.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  username: {
    type: DataTypes16.STRING,
    allowNull: false,
    unique: true
  },
  fullname: {
    type: DataTypes16.STRING,
    allowNull: true
  },
  city: {
    type: DataTypes16.STRING,
    allowNull: true
  },
  email: {
    type: DataTypes16.STRING,
    allowNull: true,
    unique: true
  },
  phone_number: {
    type: DataTypes16.STRING,
    allowNull: true
  },
  country: {
    type: DataTypes16.STRING,
    allowNull: true
  },
  telegramChatId: {
    type: DataTypes16.STRING,
    allowNull: true
  },
  telegram2FAEnabled: {
    type: DataTypes16.BOOLEAN,
    defaultValue: false
  },
  // Base32 TOTP secret for Google Authenticator. Written when the user starts
  // the setup (so the QR survives a refresh) but only ACTIVE once
  // securityAuthType === 'google'.
  googleAuthSecret: {
    type: DataTypes16.STRING,
    allowNull: true
  },
  // Which secure-auth method the account uses at login:
  // 'android' | 'telegram' | 'google', or null when 2FA is off.
  // This is the single source of truth — telegram2FAEnabled only records that
  // a Telegram chat is linked.
  securityAuthType: {
    type: DataTypes16.STRING,
    allowNull: true,
    defaultValue: null,
    comment: "Active 2FA method: 'android' | 'telegram' | 'google' | null"
  },
  //  Removed coin_type
  password: {
    type: DataTypes16.STRING,
    allowNull: false
  },
  passwordChanged: {
    type: DataTypes16.BOOLEAN,
    allowNull: false,
    defaultValue: false,
    comment: "Indicates whether user has changed default password"
  },
  // Operator-set permission, ticked on the create-account form. false = this
  // account may NOT change its own password once the mandatory first-login
  // change (passwordChanged: false -> true) is done. Default true so every
  // pre-existing account keeps behaving exactly as before.
  passwordChangeAllowed: {
    type: DataTypes16.BOOLEAN,
    allowNull: false,
    defaultValue: true,
    comment: "false = account cannot change its own password after the first-login change"
  },
  //  Role ID reference
  role_id: {
    type: DataTypes16.INTEGER,
    allowNull: false,
    comment: "FK to roles table"
  },
  credit_limit: {
    type: DataTypes16.DECIMAL(15, 2),
    allowNull: false,
    defaultValue: 0,
    comment: "Maximum credit allowed for this user"
  },
  //  Hierarchy columns
  parent_staff_id: {
    type: DataTypes16.INTEGER,
    allowNull: true,
    comment: "References Staff table (who created this user)"
  },
  parent_owner_id: {
    type: DataTypes16.INTEGER,
    allowNull: true,
    comment: "If user was created by an owner, reference owner ID"
  },
  //  Keep role name for readability
  role: {
    type: DataTypes16.STRING,
    allowNull: false,
    defaultValue: "USER"
  },
  percentage: {
    type: DataTypes16.DECIMAL(8, 3),
    allowNull: true,
    defaultValue: 0
  },
  net_win: {
    type: DataTypes16.DECIMAL(18, 2),
    allowNull: true,
    defaultValue: 0
  },
  net_loss: {
    type: DataTypes16.DECIMAL(18, 2),
    allowNull: true,
    defaultValue: 0
  },
  profit: {
    type: DataTypes16.DECIMAL(18, 2),
    allowNull: true,
    defaultValue: 0
  },
  status: {
    type: DataTypes16.ENUM("Active", "InActive", "Pending"),
    defaultValue: "Active"
  },
  bet_locked: {
    type: DataTypes16.BOOLEAN,
    defaultValue: false,
    comment: "If true, user cannot place bets"
  },
  exp_limit: {
    type: DataTypes16.DECIMAL(20, 2),
    allowNull: true,
    defaultValue: null,
    comment: "Max exposure limit for the user"
  },
  login_id: {
    type: DataTypes16.STRING,
    allowNull: true,
    comment: "Unique ID for the current active login session"
  },
  user_gt: {
    type: DataTypes16.STRING,
    allowNull: true
  },
  rules_accepted: {
    type: DataTypes16.BOOLEAN,
    defaultValue: false,
    comment: "True once the rules modal has been accepted after login"
  },
  // Demo account (see server/demo/README.md). A demo user is a REAL row that
  // bets and settles through the normal engine; it only differs in that it
  // lives under the dedicated demo owner, its P&L never rolls up
  // (walletService.updateAllPointHierarchy skips it), the tracker ignores it,
  // and it is deactivated at demo_expires_at then purged by demoCleanup.
  is_demo: {
    type: DataTypes16.BOOLEAN,
    allowNull: false,
    defaultValue: false,
    comment: "true = throwaway demo account minted by POST /api/user/demo-login"
  },
  demo_expires_at: {
    type: DataTypes16.DATE,
    allowNull: true,
    comment: "Demo session end; authMiddleware rejects the token past this"
  }
}, {
  tableName: "users",
  timestamps: true
});
var User_default = User;

// services/walletService.js
import { Op } from "sequelize";

// model/admin/Owner.js
import { DataTypes as DataTypes17 } from "sequelize";
var Owner = db_default.define(
  "Owner",
  {
    owner_id: {
      type: DataTypes17.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    username: {
      type: DataTypes17.STRING,
      allowNull: false
    },
    website_name: {
      type: DataTypes17.STRING,
      allowNull: false
    },
    domain_name: {
      type: DataTypes17.STRING,
      allowNull: false,
      unique: true
    },
    website_ui: {
      type: DataTypes17.STRING,
      allowNull: false
    },
    country: {
      type: DataTypes17.STRING,
      allowNull: false
    },
    logo: {
      type: DataTypes17.STRING,
      // Store the file path or URL
      allowNull: false
    },
    favicon: {
      type: DataTypes17.STRING,
      // Store the file path or URL
      allowNull: false
    },
    game_providers: {
      type: DataTypes17.JSON,
      // Store as JSON for multiple providers
      allowNull: false
    },
    subscription_plan: {
      type: DataTypes17.STRING,
      allowNull: false
    },
    platform_configurations: {
      type: DataTypes17.JSON,
      // Store as JSON for multiple configurations
      allowNull: false
    },
    payment_methods: {
      type: DataTypes17.JSON,
      // Store as JSON for multiple payment methods
      allowNull: false
    },
    site_email_address: {
      type: DataTypes17.STRING,
      allowNull: false,
      unique: true
      // Ensure email is unique
    },
    password: {
      type: DataTypes17.STRING,
      allowNull: false
    },
    platform_name: {
      type: DataTypes17.STRING,
      allowNull: false
    },
    role: {
      type: DataTypes17.ENUM("OWNER"),
      allowNull: false
    },
    account_status: {
      type: DataTypes17.BOOLEAN,
      defaultValue: true
    },
    unlimited_balance: {
      type: DataTypes17.BOOLEAN,
      defaultValue: true,
      comment: "If true, owner has unlimited balance and no deductions occur. If false, balance is deducted."
    },
    first_login: {
      type: DataTypes17.BOOLEAN,
      defaultValue: false
    },
    rules_accepted: {
      type: DataTypes17.BOOLEAN,
      defaultValue: false,
      comment: "True once the rules modal has been accepted after login"
    },
    transaction_password: {
      type: DataTypes17.STRING,
      allowNull: true,
      comment: "Stored as plain text"
    },
    txn_password_attempts: {
      type: DataTypes17.INTEGER,
      allowNull: true,
      defaultValue: 10,
      comment: "Transaction password attempts left; reset to 10 on a successful attempt"
    },
    // ── Secure auth (2FA) ────────────────────────────────────────────────
    // securityAuthType is the source of truth for HOW this account logs in:
    // 'telegram' | 'google' | null. telegram2FAEnabled/telegramChatId stay as
    // the Telegram transport; googleAuthSecret is the base32 TOTP secret.
    googleAuthSecret: {
      type: DataTypes17.STRING,
      allowNull: true
    },
    securityAuthType: {
      type: DataTypes17.STRING,
      allowNull: true,
      defaultValue: null
    },
    telegramChatId: {
      type: DataTypes17.STRING,
      allowNull: true
    },
    telegram2FAEnabled: {
      type: DataTypes17.BOOLEAN,
      defaultValue: false
    },
    login_id: {
      type: DataTypes17.STRING,
      allowNull: true,
      comment: "Unique ID for the current active login session (single-session enforcement)"
    }
  }
);
var Owner_default = Owner;

// model/admin/Transaction.js
import { DataTypes as DataTypes18 } from "sequelize";
var Transaction = db_default.define("Transaction", {
  id: {
    type: DataTypes18.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  // Existing fields (kept for backward compatibility)
  credit: {
    type: DataTypes18.STRING,
    // Username of credited user
    allowNull: true
  },
  debit: {
    type: DataTypes18.STRING,
    // Username of debited user
    allowNull: true
  },
  amount: {
    type: DataTypes18.DECIMAL(20, 2),
    allowNull: false
  },
  balance: {
    type: DataTypes18.DECIMAL(20, 2),
    allowNull: false
    // ✅ This is required - we now populate it in all transactions
  },
  wallet_id: {
    type: DataTypes18.INTEGER,
    allowNull: true
  },
  // ✅ New fields for enhanced transaction logging
  user_id: {
    type: DataTypes18.INTEGER,
    allowNull: true,
    comment: "User ID linked to this transaction"
  },
  staff_id: {
    type: DataTypes18.INTEGER,
    allowNull: true,
    comment: "Staff ID linked to this transaction"
  },
  owner_id: {
    type: DataTypes18.INTEGER,
    allowNull: true,
    comment: "Owner ID linked to this transaction"
  },
  username: {
    type: DataTypes18.STRING,
    allowNull: true,
    comment: "Username linked to this transaction"
  },
  type: {
    type: DataTypes18.STRING,
    allowNull: true,
    comment: "Transaction type (ADD_CASH, SUBTRACT_CREDIT, CREDIT_INR, DEBIT_USDT, etc.)"
  },
  previous_balance: {
    type: DataTypes18.DECIMAL(20, 2),
    allowNull: true,
    comment: "Balance before this transaction"
  },
  new_balance: {
    type: DataTypes18.DECIMAL(20, 2),
    allowNull: true,
    comment: "Balance after this transaction"
  },
  initiated_by: {
    type: DataTypes18.STRING,
    allowNull: true,
    comment: "Who initiated this transaction (Admin/System/User)"
  }
}, {
  tableName: "transactions",
  timestamps: true,
  // Keep createdAt and updatedAt
  underscored: false
});
var Transaction_default = Transaction;

// model/admin/PointLedger.js
import { DataTypes as DataTypes19 } from "sequelize";
var PointLedger = db_default.define(
  "PointLedger",
  {
    id: { type: DataTypes19.BIGINT.UNSIGNED, primaryKey: true, autoIncrement: true },
    // Event ki unique pehchaan — hamesha constants/pointLedger.js ke
    // pointEntryRef builders se banao, haath se nahi
    entry_ref: { type: DataTypes19.STRING(120), allowNull: false },
    // VARCHAR rakha (ENUM nahi) — values readable hain ('User creation', 'Bank Deposite')
    // aur naya type aaye toh DB ALTER nahi lagta
    event_type: { type: DataTypes19.STRING(40), allowNull: false },
    // Jis wallet ki entry hai usi ka username (reports me join bachata hai)
    username: { type: DataTypes19.STRING(100), allowNull: true },
    // Entry ke waqt wallet ka inr_balance kya tha (closing)
    closing_inr_balance: { type: DataTypes19.DECIMAL(18, 2), allowNull: true },
    // Doosri side wale (parent/sender) ka closing inr_balance — deposit/withdraw/settle/creation me
    closing_inr_balance_parent: { type: DataTypes19.DECIMAL(18, 2), allowNull: true },
    // Sirf BET_SETTLEMENT me: kis sport/game se aaya
    sport_id: { type: DataTypes19.STRING(50), allowNull: true },
    game_type: { type: DataTypes19.STRING(50), allowNull: true },
    // Sirf BET_SETTLEMENT me bharta hai: POINT_CATEGORY (SPORTS)
    category: { type: DataTypes19.STRING(30), allowNull: true },
    // Kis bet se aaya (sports = market ki pehli bet id)
    bet_id: { type: DataTypes19.BIGINT, allowNull: true },
    wallet_id: { type: DataTypes19.INTEGER, allowNull: false },
    // Sirf CASH_SETTLEMENT me: kiske SAATH hisaab hua (upar wala wallet).
    // Settle-out me entry sirf neeche wale ke wallet me lagti hai — upar wale ka
    // all_point touch nahi hota (sirf cash), uska apna claim upline ke saath
    // tabhi clear hota hai jab upar se settlement aata hai.
    settled_with_wallet_id: { type: DataTypes19.INTEGER, allowNull: true },
    // Sign ke saath: jeet +, haar − (BET_SETTLEMENT me chain ke har wallet me same delta)
    delta: { type: DataTypes19.DECIMAL(18, 2), allowNull: false },
    // Entry lagne ke turant baad all_point kya bana (audit ke liye)
    all_point_after: { type: DataTypes19.DECIMAL(18, 2), allowNull: true },
    // Kis user ke event se ye entry aayi (jeetne/haarne wala user)
    source_user_id: { type: DataTypes19.INTEGER, allowNull: true },
    remark: { type: DataTypes19.STRING(255), allowNull: true }
  },
  {
    tableName: "point_ledger",
    timestamps: true,
    createdAt: "created_at",
    updatedAt: false,
    indexes: [
      // Ek hi key do kaam karti hai:
      //  1. Idempotency — same event same wallet pe dobara INSERT = DB reject
      //  2. Per-wallet SUM — wallet_id prefix + implicit PK id se
      //     "WHERE wallet_id = ? AND id > ?" range bhi isi se chalta hai
      { unique: true, fields: ["wallet_id", "entry_ref"], name: "uq_wallet_entry" }
    ]
  }
);
var PointLedger_default = PointLedger;

// constants/pointLedger.js
var POINT_EVENT = {
  USER_CREATION: "User creation",
  // user/staff/owner create hua (opening credit)
  BET_SETTLEMENT: "BET_SETTLEMENT",
  // user ki bet/market settle hui (poori chain me)
  BANK_DEPOSIT: "Bank Deposite",
  // parent ne child ko diya (sirf normal deposit)
  BANK_WITHDRAW: "Bank Withdraw",
  // parent ne child se liya (sirf normal withdraw)
  CREDIT: "Credit",
  // sirf settlement me: parent ne child ko diya (+)
  DEBIT: "Debit",
  // sirf settlement me: parent ne child se liya (−)
  MANUAL_ADJUSTMENT: "MANUAL_ADJUSTMENT",
  // admin correction (API se, DB se nahi)
  REVERSAL: "REVERSAL",
  // galat entry ka ulta — original kabhi delete nahi hoti
  // Sports win commission (owner cell ON): jeet ke baad alag '- Comm' entry, poori
  // chain me settlement jaisa hi (docs/plans/2026-09-09-sports-win-commission.md)
  COMMISSION: "COMMISSION"
};
var POINT_EVENT_TYPES = Object.values(POINT_EVENT);
var POINT_CATEGORY = {
  SPORTS: "SPORTS"
};
var pointEntryRef = {
  opening: (walletId) => `open:${walletId}`,
  baseline: (walletId) => `baseline:${walletId}`,
  bet: (betType, betId) => `settle:bet:${betType}:${betId}`,
  // settlement ke baad void: original settle:bet:* entry kabhi delete nahi hoti,
  // uske saamne ye ulti entry banti hai (POINT_EVENT.REVERSAL)
  betReversal: (betType, betId) => `reverse:bet:${betType}:${betId}`,
  // win commission on a settled bet/market, and its void-time reversal
  commission: (betType, betId) => `commission:bet:${betType}:${betId}`,
  commissionReversal: (betType, betId) => `reverse:commission:${betType}:${betId}`,
  deposit: (transactionId) => `deposit:${transactionId}`,
  withdraw: (transactionId) => `withdraw:${transactionId}`,
  cashSettle: (transactionId) => `cashsettle:${transactionId}`,
  adjust: (adminUsername, uniqueId) => `adjust:${adminUsername}:${uniqueId}`
};
var LEDGER_CATEGORY_ALIASES = {
  SPORTS: ["SPORTS"]
};

// utils/socketUtils.js
var _io = null;
async function getIO() {
  if (process.env.WORKER_MODE) return null;
  return _io;
}
var BALANCE_UPDATES_CHANNEL = "socket:balance_updates";
var _pub = null;
async function getPublisher() {
  if (_pub) return _pub;
  try {
    const mod = await Promise.resolve().then(() => (init_redisClient(), redisClient_exports));
    _pub = mod.default;
  } catch {
    _pub = null;
  }
  return _pub;
}
var emitBalanceUpdate = async (userId, balanceData) => {
  const payload = {
    userId,
    balance: {
      ...balanceData.inr_balance != null && { inr_balance: balanceData.inr_balance },
      // Raw exposure value (negative = liability)
      ...balanceData.exposure != null && { exposure: parseFloat(balanceData.exposure) }
    },
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  };
  const io = await getIO();
  if (io) {
    io.to(`user_${userId}`).emit("balanceUpdate", payload);
    return;
  }
  const pub = await getPublisher();
  if (pub) {
    try {
      await pub.publish(BALANCE_UPDATES_CHANNEL, JSON.stringify(payload));
    } catch (err) {
      console.error("emitBalanceUpdate: redis publish failed:", err.message);
    }
  }
};

// helper/voidLabel.js
var VOID_SUFFIX = "-void";
var stripVoidPrefix = (text) => String(text || "").replace(/^VOID after settlement\s*[—-]\s*/i, "").trim();
var withVoidSuffix = (text) => {
  const s = stripVoidPrefix(text);
  if (!s) return VOID_SUFFIX;
  return s.endsWith(VOID_SUFFIX) ? s : `${s} ${VOID_SUFFIX}`;
};

// constants/messages.js
var MESSAGES = {
  AUTH: {
    CREDENTIALS_REQUIRED: "Email/Username and password are required",
    LOGIN_SUCCESS: "Login successful",
    MISSING_USERID_OR_OTP: "Missing userId or OTP",
    TWO_FA_VERIFIED: "2FA Verified",
    MISSING_USERID: "Missing userId",
    // Same reference toast as OTP_SENT — resend announces the code the
    // same way the initial generation does.
    OTP_RESENT: "Sucessfully Code Generate.",
    TOKEN_NOT_PROVIDED: "Token not provided",
    LOGOUT_SUCCESS: "Logged out successfully.",
    PASSWORDS_REQUIRED: "Current and new passwords are required",
    PASSWORD_CHANGED: "Password changed successfully",
    USER_ID_MISSING: "user_id missing (send it in the payload or use a valid token)",
    USER_NOT_FOUND: "User not exist",
    ACCOUNT_INACTIVE: "Account is inactive. Please contact support.",
    // This account or a staff above it is inactive — player + staff login
    // (helper/accountLockChain.js). Also the forceLogout toast on a lock.
    USER_LOCKED_CONTACT_UPLINE: "User is locked. Please contact upper level.",
    PASSWORD_WRONG: "Password is wrong",
    // Single-session enforcement: this account just signed in elsewhere,
    // so login_id changed and this token is already dead (authMiddleware).
    // Pushed over the socket so the old screen reacts at once instead of
    // waiting for its next request to 401 — i.e. instead of needing a reload.
    SESSION_TAKEN_OVER: "You have been logged out because this account signed in on another device.",
    // Player toast, shown on a phone: the long form above wrapped to two
    // lines and covered the top of the login page (user, 2026-09-15). The
    // player is already staring at the login screen, so "logged out" adds
    // nothing — only the reason does. Admin keeps the full sentence; it has
    // the width for it.
    SESSION_TAKEN_OVER_PLAYER: "Logged in on another device",
    // Reference-site wording, verbatim (typo included) — the 2FA page's
    // landing toast prints this. Player login only; admin keeps its own
    // ADMIN.AUTH.OTP_SENT below.
    OTP_SENT: "Sucessfully Code Generate.",
    LOGIN_FAILED: "Failed to login user",
    // Demo login (POST /user/demo-login) — a real throwaway account.
    DEMO_LOGIN_SUCCESS: "Demo login successful",
    DEMO_DISABLED: "Demo login is not available right now",
    DEMO_RATE_LIMITED: "Too many demo logins from this device. Please try again later.",
    DEMO_EXPIRED: "Demo session expired. Please login again.",
    OTP_EXPIRED_OR_NOT_REQUESTED: "OTP expired or not requested",
    INVALID_OTP: "Invalid OTP",
    // Login 2FA: a generated code is good for MAX_LOGIN_OTP_ATTEMPTS tries.
    // Reference text captured 2026-09-20 (iOS toast): "token code not valid.
    // You have 5attempt left" — no space before "attempt", keep it as is,
    // same shape as the transaction-code line below.
    TOKEN_NOT_VALID_ATTEMPTS_LEFT: (n) => `token code not valid. You have ${n}attempt left`,
    // ── Telegram bot texts ────────────────────────────────────────────
    // Captured from the reference bot "Securisep Authentication"
    // (screenshot 2026-09-20 4:31): the login code line carries the code
    // AND the username, with "not" bold — the wording Telegram's own login
    // message uses. The reference's own copy has a double space before the
    // username and a space before the full stop; the user asked for those
    // extras to go (2026-09-20), so it is single-spaced here.
    // NOTE: it says "30 sec" while our cached OTP lives 5 minutes; text
    // copied verbatim, see the plan's open question.
    TELEGRAM_LOGIN_CODE: (otp, username) => `<b>Login Code: ${otp} ${username}.</b> Do <b>not</b> give this code to anyone, even if they say they are from Telegram! Its valid for 30 sec.`,
    TELEGRAM_2FA_ENABLED: "2-Step Verification is enabled, Now you can use this bot to login into your account.",
    TELEGRAM_2FA_DISABLED: "2-Step Verification is disabled for your account.",
    OTP_EXPIRED: "OTP expired",
    TWO_FA_FAILED: "2FA Verification failed",
    TWO_FA_NOT_ENABLED: "2FA not enabled",
    LOGOUT_FAILED: "Failed to logout user",
    OTP_RESEND_FAILED: "Failed to resend OTP",
    INCORRECT_CURRENT_PASSWORD: "Password is Wrong",
    // New password identical to the one already on the account.
    PASSWORD_SAME_AS_OLD: "Password Must not be same as previous password.",
    PASSWORD_CHANGE_FAILED: "Failed to change password",
    // Account was created with the "Password Change" box ticked (or its
    // direct parent was) — see helper/passwordChangePermission.js.
    PASSWORD_CHANGE_NOT_ALLOWED: "Password cannot be changed",
    TERMS_AGREE_REQUIRED: "Please agree Terms and Conditions",
    // Reference re-login rule (frontend utils/reloginGuard.js): first login
    // with a different account after a logout is refused with this + reload.
    RELOAD_AND_RETRY: "Please reload page and retry !",
    // Google Authenticator (TOTP) secure auth
    GOOGLE_AUTH_SETUP_READY: "Scan the QR code in Google Authenticator",
    GOOGLE_AUTH_ENABLED: "Google Authenticator enabled successfully",
    GOOGLE_AUTH_DISABLED: "Google Authenticator disabled successfully",
    GOOGLE_AUTH_NOT_SETUP: "Google Authenticator setup not started. Please scan the QR code first.",
    GOOGLE_AUTH_NOT_ENABLED: "Google Authenticator is not enabled on this account",
    GOOGLE_AUTH_INVALID_CODE: "Invalid authentication code. Please try again.",
    GOOGLE_AUTH_CODE_REQUIRED: "6-digit authentication code is required",
    SECURE_AUTH_ALREADY_ENABLED: "Secure auth verification is already enabled. Disable it first.",
    // "Secure Auth Verification App" (Android, offline TOTP) secure auth
    ANDROID_AUTH_PAIR_READY: "Enter this code in your Secure Auth Verification App",
    ANDROID_AUTH_PAIRED: "Account added. Secure auth is now enabled.",
    ANDROID_AUTH_PAIR_INVALID: "This auth code is invalid or has expired. Please generate a new one.",
    ANDROID_AUTH_CODE_REQUIRED: "6-digit auth code is required",
    ANDROID_AUTH_CREDENTIALS_REQUIRED: "Please enter your username and password",
    ANDROID_AUTH_CREDENTIALS_INVALID: "Username or password is not valid for this auth code.",
    ANDROID_AUTH_NOT_PAIRED: "Secure Auth Verification App is not paired yet. Generate an auth code first.",
    ANDROID_AUTH_NOT_ENABLED: "Secure Auth Verification App is not enabled on this account",
    ANDROID_AUTH_ENABLED: "Secure Auth Verification App enabled successfully",
    ANDROID_AUTH_DISABLED: "Secure Auth Verification App disabled successfully",
    ANDROID_AUTH_TOO_MANY_ATTEMPTS: "Too many attempts. Please wait a minute and try again."
  },
  VALIDATION: {
    FIELD_REQUIRED: "This field is required",
    USERNAME_REQUIRED: "Username required",
    PASSWORD_REQUIRED: "Password required"
  },
  PASSWORD: {
    MUST_BE_NON_EMPTY: "Password must be a non-empty string",
    CANNOT_BE_WHITESPACE: "Password cannot be empty or whitespace only",
    HASH_FAILED: "Failed to hash password",
    HASHED_MUST_BE_NON_EMPTY: "Hashed password must be a non-empty string",
    COMPARE_FAILED: "Failed to compare passwords",
    SALT_GENERATION_FAILED: "Failed to generate salt",
    SALT_MUST_BE_NON_EMPTY: "Salt must be a non-empty string",
    HASH_WITH_SALT_FAILED: "Failed to hash password with salt",
    MIN_LENGTH: (minLength) => `Password must be at least ${minLength} characters long`,
    NEED_LOWERCASE: "Password must contain at least one lowercase letter",
    NEED_NUMBER: "Password must contain at least one number",
    NEED_SPECIAL_CHAR: "Password must contain at least one special character"
  },
  BET: {
    // Bet lock on the player or any staff above them — sports
    // placeBet (services/BetLockService.js). Also the forceLogout toast.
    LOCKED_CONTACT_UPLINE: "Bet is locked. Please contact upper level 1.",
    // General Lock (sports-lock) — n = role number of the locker
    // (Agent 1, Master 2, … Owner 7; see uplineNo in SportsLockController).
    GAME_LOCKED_CONTACT_UPLINE: (n) => `Game is locked. Please contact Upper Level${n}`,
    // Owner-set Max Odds (admin Settings → Max Odds). `scope` is the sport
    // name, or LIMITED_OVERS_SCOPE for a cricket "Oneday & T20 only" cell.
    // Always 2 decimals — reference: "Bet Not Accept Rate Over 4.00 on Oneday and T20".
    // Frontend twin: frontend/src/utils/betToastMessages.js RATE_OVER_LIMIT.
    RATE_OVER_LIMIT: (max, scope) => `Bet Not Accept Rate Over ${Number(max).toFixed(2)} on ${scope}`,
    LIMITED_OVERS_SCOPE: "Oneday and T20",
    // Server-side bet buffer (sportsbet/betBuffer.js) — verbatim twins of
    // frontend/src/utils/betToastMessages.js, so the toast a player sees
    // did not change when these checks moved off the browser.
    GAME_SUSPEND: "Bet Not Confirmed due to game suspend.",
    BALL_RUNNING: "Ball Running",
    ODDS_CHANGED: "Odds changed",
    ODDS_CHANGE_NOT_CONFIRMED: "Bet not confirm Odds change",
    UNMATCHED_NOT_ALLOWED: "Unmatched bet not allowed.",
    RANGE_NOT_VALID: "Bet Not Confirm Reason Min and Max Bet Range Not Valid.",
    // Same client_ref submitted again while the first one is still buffering.
    BET_ALREADY_PENDING: "Bet is already being placed."
  },
  ADMIN: {
    AUTH: {
      // ── Sab admin logins pe common ──────────────────────────────
      // Account exist na kare — staff aur owner, dono ke login/2FA/profile pe yahi text.
      // NOTE: admin/src/hooks/useAuth.js ka staff→executive cascade is text pe
      // /not found|not available/i match karta hai — "not available" hataana mat.
      ACCOUNT_NOT_AVAILABLE: "UserName not available",
      // Admin ka apna wording — player side AUTH.PASSWORD_WRONG use karta hai.
      // Executive login isko tab bhi bhejta hai jab username exist na kare —
      // jaan-bujh ke, taaki bahar se account ka hona pata na chale.
      PASSWORD_INCORRECT: "Password Incorrect",
      OTP_SENT: "2FA OTP sent to your linked Telegram",
      // ── Staff ───────────────────────────────────────────────────
      MISSING_STAFFID_OR_OTP: "Staff ID and OTP required",
      STAFF_ID_MISSING_TOKEN: "Invalid token payload: staff_id missing",
      STAFF_ID_MISSING: "staff_id missing (send it in the payload or use a valid token)",
      STAFF_LOGIN_FAILED: "Failed to login staff",
      STAFF_LOGOUT_FAILED: "Failed to logout staff",
      STAFF_PROFILE_FETCH_FAILED: "Failed to fetch staff profile",
      // Telegram body — HTML parse mode, isliye <b> tags.
      // Same reference bot line as the player side (MESSAGES.AUTH.
      // TELEGRAM_LOGIN_CODE) — one bot, one wording.
      TELEGRAM_STAFF_LOGIN_OTP: (otp, username) => MESSAGES.AUTH.TELEGRAM_LOGIN_CODE(otp, username),
      // ── Owner ───────────────────────────────────────────────────
      MISSING_OWNERID_OR_OTP: "Owner ID and OTP required",
      OWNER_ID_MISSING_TOKEN: "Invalid token payload: owner_id missing",
      OWNER_ID_MISSING: "owner_id missing (send it in the payload or use a valid token)",
      OWNER_LOGIN_FAILED: "Failed to login owner",
      OWNER_LOGOUT_FAILED: "Failed to logout owner",
      OWNER_PROFILE_FETCH_FAILED: "Failed to fetch owner profile",
      // Same reference bot line as the player side (MESSAGES.AUTH.
      // TELEGRAM_LOGIN_CODE) — one bot, one wording.
      TELEGRAM_OWNER_LOGIN_OTP: (otp, username) => MESSAGES.AUTH.TELEGRAM_LOGIN_CODE(otp, username),
      // ── Executive (multi-login) ─────────────────────────────────
      // Executive login me email field nahi hai, isliye shared
      // AUTH.CREDENTIALS_REQUIRED se alag wording.
      EXECUTIVE_CREDENTIALS_REQUIRED: "Username and password are required",
      EXECUTIVE_DISABLED: "Executive account is disabled"
    },
    // Activity log ki details — admin ke Activity Log report me dikhti hain.
    ACTIVITY: {
      STAFF_LOGIN: "Staff login successful",
      STAFF_2FA: "Staff 2FA verified",
      OWNER_LOGIN: "Owner login successful",
      OWNER_2FA: "Owner 2FA verified"
    },
    // Owner ke platform / site settings.
    SETTINGS: {
      PLATFORM_CONFIG_REQUIRED: "Platform configurations are required",
      PLATFORM_CONFIG_UPDATED: "Platform configurations updated successfully",
      PLATFORM_CONFIG_UPDATE_FAILED: "Failed to update platform configurations"
    },
    // Create Account (insertuser) — user + staff dono.
    USERS: {
      // Create Account: the username is already a user, staff or owner
      // name (case-insensitive). Sent by check-username (202), the
      // player create route (400) and the staff create route (409); the
      // admin shows this text as its toast, verbatim — reference wording.
      USERNAME_EXISTS: "User Name Already Exists",
      // Create Account: a negative (or non-numeric) credit amount.
      // Reference wording verbatim — lower-case, one word, trailing dot
      // (reference toast captured 2026-09-21 for an entry of -37).
      CREDIT_AMOUNT_INVALID: "creditamount is invalid.",
      // Create Account: no role picked, or a role this API does not know.
      // Reference wording verbatim (capital S, lower-case "type").
      SELECT_PROPER_USER_TYPE: "Select Proper User type",
      // Reference wording verbatim (typo included). Parent ka balance
      // credit se kam ho to account 0 credit pe banta hai; bal = parent
      // wallet ka asli inr_balance.
      CREATED_INSUFFICIENT_CREDIT: (bal) => `User Sucessfully Inserted But Your Client Does Not Have Sufficient Credit, Because Client Credit is : ${Number(bal).toFixed(2)}`,
      // Credit Withdraw (Credit Activity modal): child ka main balance
      // (USER → cash, staff → inr_balance) withdraw amount se kam.
      // Reference wording verbatim; bal = child ka asli balance. The
      // admin shows this as its error toast, text from here.
      WITHDRAW_INSUFFICIENT_BALANCE: (bal) => `Your Client Does Not Have Sufficient Balance, Because Client Balance is : ${Number(bal).toFixed(2)}`,
      // Credit Deposit (same modal): the SENDER (logged-in parent) has
      // less inr_balance than the deposit. Reference wording verbatim;
      // bal = sender's actual balance. Error toast in the admin.
      DEPOSIT_INSUFFICIENT_CREDIT: (bal) => `Your Client Does Not Have Sufficient Credit, Because Client Credit is : ${Number(bal).toFixed(2)}`,
      // Credit Deposit AND Credit Withdraw succeeded — the admin toasts
      // this on both (user, 2026-09-17: "dono ke case me same"). Reference
      // wording verbatim ("Sucessfull" typo included).
      BALANCE_TRANSFER_SUCCESS: "Sucessfull Balance Transfer"
    },
    // Transaction code (a.k.a. master password) — ONE set of strings for
    // every route that runs verifyTransactionPassword / the attempts
    // service (deposit, withdraw, create account, edit profile, lock,
    // settlement …). Controllers never spell these out inline.
    TXN: {
      REQUIRED: "Transaction password is required",
      ACCOUNT_NOT_FOUND: "User not found",
      // Reference-site wording, verbatim — including the missing space
      // before "attempt", the singular whatever the count, the lowercase
      // "t" and the FULL STOP at the end. Match it, do not tidy it.
      // First noted 2026-09-16 as "You have 8attempt left"; the full stop
      // was missed then and is plain in the 2026-09-21 phone recording of
      // General Lock: "transaction code not valid. You have 7attempt left."
      NOT_VALID_ATTEMPTS_LEFT: (n) => `transaction code not valid. You have ${n}attempt left.`,
      // The allowance is used up (counter at 0, staff deactivated) — and
      // every later attempt while still deactivated. Same text on every
      // transaction-code route (user, 2026-09-18).
      LIMIT_REACHED: "Unauthorized access",
      VERIFIED: "Transaction password verified",
      // Bet Lock says it differently. The operator ticks an account with
      // the Transaction Code box filled in, and a wrong code comes back
      // as this — user's toast DOM, 2026-09-23, full stop included. Only
      // the market-lock routes use it; every other transaction-code route
      // keeps NOT_VALID_ATTEMPTS_LEFT above.
      MASTER_NOT_VALID: "Master Password not valid."
    }
  }
};

// wallet_utility/hierarchyUtility.js
var decrementAncestorCashReceived = async (userId, amount, transaction) => {
  try {
    console.log(`[Hierarchy] Decrementing cash_received for ancestors of user ${userId} by ${amount}`);
    const txnOpts = transaction ? { transaction } : {};
    const lockOpts = transaction ? { transaction, lock: transaction.LOCK.UPDATE } : {};
    const user = await User_default.findByPk(userId, txnOpts);
    if (!user) return;
    let currentStaffId = user.parent_staff_id;
    let currentOwnerId = user.parent_owner_id;
    const userWallet = await Wallet_default.findOne({
      where: { user_id: userId, user_type: "USER" },
      ...lockOpts
    });
    if (userWallet) {
      const prevRec = parseFloat(userWallet.cash_received || 0);
      userWallet.cash_received = prevRec - parseFloat(amount);
      await userWallet.save(txnOpts);
      console.log(`[Hierarchy] Decremented cash_received for User ${userId} (${user.username})`);
    }
    while (currentStaffId) {
      const staff = await Staff_default.findByPk(currentStaffId, txnOpts);
      if (!staff) break;
      const wallet = await Wallet_default.findOne({
        where: { staff_id: currentStaffId, user_type: staff.role.toUpperCase() },
        ...lockOpts
      });
      if (wallet) {
        const prevRec = parseFloat(wallet.cash_received || 0);
        wallet.cash_received = prevRec - parseFloat(amount);
        await wallet.save(txnOpts);
        console.log(`[Hierarchy] Decremented cash_received for Staff ${currentStaffId} (${staff.username})`);
      }
      currentOwnerId = staff.parent_owner_id;
      currentStaffId = staff.parent_id;
    }
    if (currentOwnerId) {
      const owner = await Owner_default.findByPk(currentOwnerId, txnOpts);
      if (owner) {
        const wallet = await Wallet_default.findOne({
          where: { owner_id: currentOwnerId, user_type: "OWNER" },
          ...lockOpts
        });
        if (wallet) {
          const prevRec = parseFloat(wallet.cash_received || 0);
          wallet.cash_received = prevRec - parseFloat(amount);
          await wallet.save(txnOpts);
          console.log(`[Hierarchy] Decremented cash_received for Owner ${currentOwnerId} (${owner.username})`);
        }
      }
    }
  } catch (e) {
    console.error("\u274C decrementAncestorCashReceived error:", e);
    throw e;
  }
};

// services/walletService.js
var WalletService = {
  // ---------------------------------------------------------------------------
  // Helper: determine correct ID field
  // ---------------------------------------------------------------------------
  getWalletQueryField(userType) {
    const type = userType ? userType.toUpperCase() : null;
    if (type === "USER") return "user_id";
    if (["SUPERADMIN", "COMPANY", "ADMIN", "SUPERMASTER", "MASTER", "AGENT"].includes(type)) return "staff_id";
    if (type === "OWNER") return "owner_id";
    return "USER TYPE NOT FOUND";
  },
  // -----------------------------------------------------------------------
  // Helper: Get Hierarchy IDs (User, Staff, Owner)
  // -----------------------------------------------------------------------
  getHierarchyIds: async (entityId, userType) => {
    const type = userType ? userType.toUpperCase() : "";
    let userId = null;
    let staffId = null;
    let ownerId = null;
    if (type === "USER") {
      userId = entityId;
      const user = await User_default.findByPk(entityId);
      if (user) {
        staffId = user.parent_staff_id;
        ownerId = user.parent_owner_id;
      }
    } else if (type === "OWNER") {
      ownerId = entityId;
    } else {
      staffId = entityId;
      const staff = await Staff_default.findByPk(entityId);
      if (staff && staff.parent_owner_id) {
        ownerId = staff.parent_owner_id;
      } else {
        const owner = await Owner_default.findOne({ attributes: ["owner_id"] });
        if (owner) ownerId = owner.owner_id;
      }
    }
    return { userId, staffId, ownerId };
  },
  // -----------------------------------------------------------------------
  // CREATE WALLET
  // -----------------------------------------------------------------------
  createWallet: async (entityId, userType, transaction, username, credit = 0, cash = 0) => {
    try {
      const roleMap = {
        company: "COMPANY",
        superadmin: "SUPERADMIN",
        admin: "ADMIN",
        supermaster: "SUPERMASTER",
        master: "MASTER",
        agent: "AGENT",
        owner: "OWNER",
        user: "USER"
      };
      const normalised = roleMap[userType?.toLowerCase()] || userType?.toUpperCase();
      const idField = WalletService.getWalletQueryField(normalised);
      const whereClause = { [idField]: entityId, user_type: normalised };
      const existing = await Wallet_default.findOne({ where: whereClause, transaction });
      if (existing) return existing;
      const walletData = {
        user_type: normalised,
        username,
        inr_balance: 0,
        cash: 0,
        credit: 0
      };
      if (idField === "user_id") walletData.user_id = entityId;
      if (idField === "staff_id") walletData.staff_id = entityId;
      if (idField === "owner_id") walletData.owner_id = entityId;
      return await Wallet_default.create(walletData, { transaction });
    } catch (e) {
      console.error("\u274C createWallet error:", e);
      throw e;
    }
  },
  // -----------------------------------------------------------------------
  // CREDIT BALANCE (INR) - Used in creditBalance controller
  // -----------------------------------------------------------------------
  creditBalance: async (entityId, amount, userType, transaction, initiatedBy, senderType = null) => {
    try {
      const idField = WalletService.getWalletQueryField(userType);
      const wallet = await Wallet_default.findOne({ where: { [idField]: entityId, user_type: userType }, transaction });
      if (!wallet) throw new Error("Wallet not found");
      const prev = parseFloat(wallet.inr_balance);
      wallet.inr_balance = prev + parseFloat(amount);
      await wallet.save({ transaction });
      const { userId: t_userId, staffId: t_staffId, ownerId: t_ownerId } = await WalletService.getHierarchyIds(entityId, userType);
      await Transaction_default.create(
        {
          wallet_id: wallet.wallet_id,
          username: wallet.username,
          user_id: t_userId,
          staff_id: t_staffId,
          owner_id: t_ownerId,
          type: "CREDIT_INR",
          amount: parseFloat(amount),
          previous_balance: prev,
          new_balance: wallet.inr_balance,
          balance: wallet.inr_balance,
          credit: wallet.username,
          debit: initiatedBy,
          initiated_by: initiatedBy
        },
        { transaction }
      );
      emitBalanceUpdate(entityId, { inr_balance: wallet.inr_balance });
      return wallet;
    } catch (e) {
      console.error("\u274C creditBalance error:", e);
      throw e;
    }
  },
  // -----------------------------------------------------------------------
  // DEBIT BALANCE (INR)
  // -----------------------------------------------------------------------
  debitBalance: async (entityId, amount, userType, transaction, initiatedBy) => {
    try {
      const idField = WalletService.getWalletQueryField(userType);
      const wallet = await Wallet_default.findOne({ where: { [idField]: entityId, user_type: userType }, transaction });
      if (!wallet) throw new Error("Wallet not found");
      const current = parseFloat(wallet.inr_balance);
      if (current < parseFloat(amount)) throw new Error("Insufficient balance");
      wallet.inr_balance = current - parseFloat(amount);
      const updatedPL = Math.round((wallet.inr_balance - parseFloat(wallet.cash_received || 0)) * 100) / 100;
      wallet.profit_loss = updatedPL;
      wallet.verdict = updatedPL >= 0 ? "profit" : "loss";
      await wallet.save({ transaction });
      const { userId: t_userId, staffId: t_staffId, ownerId: t_ownerId } = await WalletService.getHierarchyIds(entityId, userType);
      await Transaction_default.create({
        wallet_id: wallet.wallet_id,
        username: wallet.username,
        user_id: t_userId,
        staff_id: t_staffId,
        owner_id: t_ownerId,
        type: "DEBIT_INR",
        amount: parseFloat(amount),
        previous_balance: current,
        new_balance: wallet.inr_balance,
        balance: wallet.inr_balance,
        credit: initiatedBy,
        debit: wallet.username,
        initiated_by: initiatedBy
      }, { transaction });
      emitBalanceUpdate(entityId, { inr_balance: wallet.inr_balance });
      return wallet;
    } catch (e) {
      console.error("\u274C debitBalance error:", e);
      throw e;
    }
  },
  /**
   * Recursively decrements cash_received for all ancestors (Staff & Owners)
   * Triggered when a User loses a bet.
   */
  decrementAncestorCashReceived,
  // -----------------------------------------------------------------------
  // ADD CASH → OWNER gets it for FREE
  // -----------------------------------------------------------------------
  //This is old Api and not recommended to use in tenexch
  addCash: async (receiverId, amount, userType, transaction, initiatedBy, senderId = null, senderType = null) => {
    if (!userType || !receiverId) throw new Error("ReceiverId and UserType required");
    try {
      const receiverField = WalletService.getWalletQueryField(userType);
      const receiverWallet = await Wallet_default.findOne({ where: { [receiverField]: receiverId }, transaction });
      if (!receiverWallet) throw new Error("Receiver wallet not found");
      let performDeduction = false;
      let senderOwner = null;
      if (senderId && senderType) {
        if (senderType.toUpperCase() !== "OWNER") {
          performDeduction = true;
        } else {
          const owner = await Owner_default.findByPk(senderId, { transaction });
          senderOwner = owner;
          if (owner && !owner.unlimited_balance) {
            performDeduction = true;
          }
        }
      }
      if (performDeduction) {
        const senderField = WalletService.getWalletQueryField(senderType);
        const senderWallet = await Wallet_default.findOne({
          where: { [senderField]: senderId, user_type: senderType },
          transaction,
          lock: transaction.LOCK.UPDATE
        });
        if (!senderWallet) throw new Error("Sender wallet not found");
        const currentBal = parseFloat(senderWallet.inr_balance ?? 0);
        const currentCash = parseFloat(senderWallet.cash ?? 0);
        const deductAmount = parseFloat(amount);
        if (currentBal < deductAmount) throw new Error("Insufficient INR balance in sender");
        if (currentCash < deductAmount) throw new Error("Insufficient CASH in sender");
        const newBalance = Math.round((currentBal - deductAmount) * 100) / 100;
        const newCash = Math.round((currentCash - deductAmount) * 100) / 100;
        senderWallet.setDataValue("inr_balance", newBalance);
        senderWallet.setDataValue("cash", newCash);
        senderWallet.changed("inr_balance", true);
        senderWallet.changed("cash", true);
        const newProfitLoss = Math.round((newBalance - parseFloat(senderWallet.cash_received || 0)) * 100) / 100;
        senderWallet.setDataValue("profit_loss", newProfitLoss);
        senderWallet.setDataValue("verdict", newProfitLoss >= 0 ? "profit" : "loss");
        senderWallet.changed("profit_loss", true);
        senderWallet.changed("verdict", true);
        await senderWallet.save({ transaction });
        let { userId: s_userId, staffId: s_staffId, ownerId: s_ownerId } = await WalletService.getHierarchyIds(senderId, senderType);
        if (senderType.toUpperCase() === "OWNER" && userType.toUpperCase() !== "USER" && userType.toUpperCase() !== "OWNER") {
          s_staffId = receiverId;
        }
        if (senderType.toUpperCase() === "OWNER" && userType.toUpperCase() === "USER") {
          s_userId = receiverId;
        }
        await Transaction_default.create({
          wallet_id: senderWallet.wallet_id,
          user_id: s_userId,
          staff_id: s_staffId,
          owner_id: s_ownerId,
          username: senderType.toUpperCase() === "OWNER" && senderOwner ? senderOwner.username : senderWallet.username,
          type: "DEBIT_FOR_CASH",
          amount: deductAmount,
          previous_balance: currentBal,
          new_balance: newBalance,
          balance: newBalance,
          credit: receiverWallet.username,
          debit: senderType.toUpperCase() === "OWNER" && senderOwner ? senderOwner.username : senderWallet.username,
          initiated_by: initiatedBy
        }, { transaction });
        emitBalanceUpdate(senderId, { inr_balance: newBalance, cash: newCash });
        console.log(`Cash deducted from ${senderType} (${senderId})`);
      } else if (senderType?.toUpperCase() === "OWNER") {
        console.log(`OWNER (${senderId}) added cash \u2192 FREE (unlimited balance)`);
        let { userId: s_userId, staffId: s_staffId, ownerId: s_ownerId } = await WalletService.getHierarchyIds(senderId, senderType);
        if (senderType.toUpperCase() === "OWNER" && userType.toUpperCase() !== "USER" && userType.toUpperCase() !== "OWNER") {
          s_staffId = receiverId;
        }
        if (senderType.toUpperCase() === "OWNER" && userType.toUpperCase() === "USER") {
          s_userId = receiverId;
        }
        const senderWallet = await Wallet_default.findOne({ where: { [WalletService.getWalletQueryField(senderType)]: senderId } });
        const currentBal = senderWallet ? parseFloat(senderWallet.inr_balance || 0) : 0;
        await Transaction_default.create({
          wallet_id: senderWallet ? senderWallet.wallet_id : null,
          user_id: s_userId,
          staff_id: s_staffId,
          owner_id: s_ownerId,
          username: senderOwner ? senderOwner.username : "OWNER",
          type: "DEBIT_FOR_CASH",
          amount: parseFloat(amount),
          previous_balance: currentBal,
          new_balance: currentBal,
          // Balance unchanged
          balance: currentBal,
          credit: receiverWallet.username,
          debit: senderOwner ? senderOwner.username : "OWNER",
          initiated_by: initiatedBy
        }, { transaction });
      }
      const prevCash = parseFloat(receiverWallet.cash || 0);
      const prevInr = parseFloat(receiverWallet.inr_balance || 0);
      receiverWallet.cash = prevCash + parseFloat(amount);
      receiverWallet.inr_balance = prevInr + parseFloat(amount);
      await receiverWallet.save({ transaction });
      let { userId: r_userId, staffId: r_staffId, ownerId: r_ownerId } = await WalletService.getHierarchyIds(receiverId, userType);
      if (senderType && senderType.toUpperCase() === "OWNER" && userType && userType.toUpperCase() === "USER") {
        r_staffId = null;
        if (!r_ownerId) r_ownerId = senderId;
      }
      await Transaction_default.create({
        wallet_id: receiverWallet.wallet_id,
        user_id: r_userId,
        staff_id: r_staffId,
        owner_id: r_ownerId,
        username: receiverWallet.username,
        type: "ADD_CASH",
        amount: parseFloat(amount),
        previous_balance: prevCash,
        new_balance: receiverWallet.cash,
        balance: receiverWallet.inr_balance,
        credit: receiverWallet.username,
        debit: initiatedBy,
        initiated_by: initiatedBy
      }, { transaction });
      emitBalanceUpdate(receiverId, { cash: receiverWallet.cash, inr_balance: receiverWallet.inr_balance });
      return receiverWallet;
    } catch (e) {
      console.error("\u274C addCash error:", e);
      throw e;
    }
  },
  // This is the new api for deposite
  addDeposit: async (receiverId, amount, userType, transaction, initiatedBy, senderId, senderType, remark = "") => {
    if (!receiverId || !userType) throw new Error("receiverId and userType required");
    if (!senderId || !senderType) throw new Error("sender info not found");
    try {
      const senderRole = senderType.toUpperCase();
      if (senderRole !== "OWNER" && senderRole !== "STAFF") {
        throw new Error("Only owner or staff can deposit");
      }
      const dep = Math.round(parseFloat(amount) * 100) / 100;
      if (isNaN(dep) || dep <= 0) throw new Error("amount must be greater than 0");
      const receiverRole = userType.toUpperCase() === "USER" ? "USER" : "STAFF";
      let receiver, parentStaff, parentOwner;
      if (receiverRole === "USER") {
        receiver = await User_default.findByPk(receiverId, { transaction });
        if (!receiver) throw new Error(`User ${receiverId} not found`);
        parentStaff = receiver.parent_staff_id;
        parentOwner = receiver.parent_owner_id;
      } else {
        receiver = await Staff_default.findByPk(receiverId, { transaction });
        if (!receiver) throw new Error(`Staff ${receiverId} not found`);
        parentStaff = receiver.parent_id;
        parentOwner = receiver.parent_owner_id;
      }
      let isDirect = false;
      if (senderRole === "OWNER") {
        isDirect = !parentStaff && Number(parentOwner) === Number(senderId);
      } else {
        isDirect = Number(parentStaff) === Number(senderId);
      }
      if (!isDirect) {
        throw new Error(`${receiver.username} is not your direct child, deposit not allowed`);
      }
      const receiverWallet = await Wallet_default.findOne({
        where: receiverRole === "USER" ? { user_id: receiverId, user_type: "USER" } : { staff_id: receiverId },
        transaction
      });
      if (!receiverWallet) throw new Error("Receiver wallet not found");
      const senderWallet = await Wallet_default.findOne({
        where: senderRole === "OWNER" ? { owner_id: senderId, user_type: "OWNER" } : { staff_id: senderId },
        transaction,
        lock: transaction.LOCK.UPDATE
      });
      if (!senderWallet) throw new Error("Sender wallet not found");
      let deduct = true;
      if (senderRole === "OWNER") {
        const owner = await Owner_default.findByPk(senderId, { transaction });
        if (owner && owner.unlimited_balance) deduct = false;
      }
      const senderInrBefore = Math.round(parseFloat(senderWallet.inr_balance || 0) * 100) / 100;
      let senderInrAfter = senderInrBefore;
      if (deduct) {
        if (senderInrBefore < dep) throw new Error(MESSAGES.ADMIN.USERS.DEPOSIT_INSUFFICIENT_CREDIT(senderInrBefore));
        senderInrAfter = Math.round((senderInrBefore - dep) * 100) / 100;
        await Wallet_default.increment({ inr_balance: -dep }, { where: { wallet_id: senderWallet.wallet_id }, transaction });
        await Transaction_default.create({
          wallet_id: senderWallet.wallet_id,
          user_id: null,
          staff_id: senderRole === "STAFF" ? senderId : null,
          owner_id: senderRole === "OWNER" ? senderId : null,
          username: senderWallet.username,
          type: "DEPOSIT",
          amount: dep,
          previous_balance: senderInrBefore,
          new_balance: senderInrAfter,
          balance: senderInrAfter,
          credit: receiverWallet.username,
          debit: senderWallet.username,
          initiated_by: initiatedBy
        }, { transaction });
        emitBalanceUpdate(senderId, { inr_balance: senderInrAfter });
      }
      let recInrBefore = Math.round(parseFloat(receiverWallet.inr_balance || 0) * 100) / 100;
      let recInrAfter = Math.round((recInrBefore + dep) * 100) / 100;
      const inc = { inr_balance: dep, credit: dep, all_point: dep };
      if (receiverRole === "USER") {
        inc.cash = dep;
        recInrBefore = Math.round(parseFloat(receiverWallet.cash || 0) * 100) / 100;
        recInrAfter = Math.round((recInrBefore + dep) * 100) / 100;
      }
      await Wallet_default.increment(inc, { where: { wallet_id: receiverWallet.wallet_id }, transaction });
      const recTxn = await Transaction_default.create({
        wallet_id: receiverWallet.wallet_id,
        user_id: receiverRole === "USER" ? receiverId : null,
        staff_id: receiverRole === "STAFF" ? receiverId : null,
        owner_id: null,
        username: receiverWallet.username,
        type: "DEPOSIT",
        amount: dep,
        previous_balance: recInrBefore,
        new_balance: recInrAfter,
        balance: recInrAfter,
        credit: receiverWallet.username,
        debit: senderWallet.username,
        initiated_by: initiatedBy
      }, { transaction });
      const recAllPointBefore = Math.round(parseFloat(receiverWallet.all_point || 0) * 100) / 100;
      const recAllPointAfter = Math.round((recAllPointBefore + dep) * 100) / 100;
      await PointLedger_default.create({
        entry_ref: pointEntryRef.deposit(recTxn.id),
        event_type: POINT_EVENT.CREDIT,
        wallet_id: receiverWallet.wallet_id,
        username: receiverWallet.username,
        settled_with_wallet_id: senderWallet.wallet_id,
        delta: dep,
        all_point_after: recAllPointAfter,
        closing_inr_balance: Math.round((parseFloat(receiverWallet.inr_balance || 0) + dep) * 100) / 100,
        closing_inr_balance_parent: senderInrAfter,
        source_user_id: receiverRole === "USER" ? receiverId : null,
        remark: `${remark}#${senderWallet.username}/${receiverWallet.username}`
      }, { transaction });
      const recCredit = Math.round((parseFloat(receiverWallet.credit || 0) + dep) * 100) / 100;
      const emitData = { inr_balance: recInrAfter, credit: recCredit };
      if (receiverRole === "USER") emitData.cash = Math.round((parseFloat(receiverWallet.cash || 0) + dep) * 100) / 100;
      emitBalanceUpdate(receiverId, emitData);
      return {
        receiver: receiverWallet.username,
        receiver_type: receiverRole,
        amount: dep,
        receiver_inr_after: recInrAfter,
        sender: senderWallet.username,
        sender_inr_after: senderInrAfter,
        sender_charged: deduct
      };
    } catch (e) {
      console.error("\u274C addDeposit error:", e);
      throw e;
    }
  },
  // This is the new api for withdraw from child
  withdrawFromChild: async (childId, amount, userType, transaction, initiatedBy, actorId, actorType, remark = "") => {
    if (!childId || !userType) throw new Error("childId and userType required");
    if (!actorId || !actorType) throw new Error("actor info not found");
    try {
      const actorRole = actorType.toUpperCase();
      if (actorRole !== "OWNER" && actorRole !== "STAFF") {
        throw new Error("Only owner or staff can withdraw");
      }
      const wd = Math.round(parseFloat(amount) * 100) / 100;
      if (isNaN(wd) || wd <= 0) throw new Error("amount must be greater than 0");
      const childRole = userType.toUpperCase() === "USER" ? "USER" : "STAFF";
      let child, parentStaff, parentOwner;
      if (childRole === "USER") {
        child = await User_default.findByPk(childId, { transaction });
        if (!child) throw new Error(`User ${childId} not found`);
        parentStaff = child.parent_staff_id;
        parentOwner = child.parent_owner_id;
      } else {
        child = await Staff_default.findByPk(childId, { transaction });
        if (!child) throw new Error(`Staff ${childId} not found`);
        parentStaff = child.parent_id;
        parentOwner = child.parent_owner_id;
      }
      let isDirect = false;
      if (actorRole === "OWNER") {
        isDirect = !parentStaff && Number(parentOwner) === Number(actorId);
      } else {
        isDirect = Number(parentStaff) === Number(actorId);
      }
      if (!isDirect) {
        throw new Error(`${child.username} is not your direct child, withdrawal not allowed`);
      }
      const childWallet = await Wallet_default.findOne({
        where: childRole === "USER" ? { user_id: childId, user_type: "USER" } : { staff_id: childId },
        transaction,
        lock: transaction.LOCK.UPDATE
      });
      if (!childWallet) throw new Error("Child wallet not found");
      const actorWallet = await Wallet_default.findOne({
        where: actorRole === "OWNER" ? { owner_id: actorId, user_type: "OWNER" } : { staff_id: actorId },
        transaction
      });
      if (!actorWallet) throw new Error("Parent wallet not found");
      const mainCol = childRole === "USER" ? "cash" : "inr_balance";
      const childMainBefore = Math.round(parseFloat(childWallet[mainCol] || 0) * 100) / 100;
      const childMainAfter = Math.round((childMainBefore - wd) * 100) / 100;
      if (childMainBefore < wd) {
        throw new Error(MESSAGES.ADMIN.USERS.WITHDRAW_INSUFFICIENT_BALANCE(childMainBefore));
      }
      const dec = { inr_balance: -wd, credit: -wd, all_point: -wd };
      if (childRole === "USER") dec.cash = -wd;
      await Wallet_default.increment(dec, { where: { wallet_id: childWallet.wallet_id }, transaction });
      const childTxn = await Transaction_default.create({
        wallet_id: childWallet.wallet_id,
        user_id: childRole === "USER" ? childId : null,
        staff_id: childRole === "STAFF" ? childId : null,
        owner_id: null,
        username: childWallet.username,
        type: "WITHDRAWAL",
        amount: wd,
        previous_balance: childMainBefore,
        new_balance: childMainAfter,
        balance: childMainAfter,
        credit: actorWallet.username,
        debit: childWallet.username,
        initiated_by: initiatedBy
      }, { transaction });
      const childAllPointBefore = Math.round(parseFloat(childWallet.all_point || 0) * 100) / 100;
      const childAllPointAfter = Math.round((childAllPointBefore - wd) * 100) / 100;
      await PointLedger_default.create({
        entry_ref: pointEntryRef.withdraw(childTxn.id),
        event_type: POINT_EVENT.DEBIT,
        wallet_id: childWallet.wallet_id,
        username: childWallet.username,
        settled_with_wallet_id: actorWallet.wallet_id,
        delta: -wd,
        all_point_after: childAllPointAfter,
        closing_inr_balance: Math.round((parseFloat(childWallet.inr_balance || 0) - wd) * 100) / 100,
        closing_inr_balance_parent: Math.round((parseFloat(actorWallet.inr_balance || 0) + wd) * 100) / 100,
        source_user_id: childRole === "USER" ? childId : null,
        remark: `${remark}#${childWallet.username}/${actorWallet.username}`
      }, { transaction });
      const actorInrBefore = Math.round(parseFloat(actorWallet.inr_balance || 0) * 100) / 100;
      const actorInrAfter = Math.round((actorInrBefore + wd) * 100) / 100;
      await Wallet_default.increment({ inr_balance: wd }, { where: { wallet_id: actorWallet.wallet_id }, transaction });
      await Transaction_default.create({
        wallet_id: actorWallet.wallet_id,
        user_id: null,
        staff_id: actorRole === "STAFF" ? actorId : null,
        owner_id: actorRole === "OWNER" ? actorId : null,
        username: actorWallet.username,
        type: "WITHDRAWAL",
        amount: wd,
        previous_balance: actorInrBefore,
        new_balance: actorInrAfter,
        balance: actorInrAfter,
        credit: actorWallet.username,
        debit: childWallet.username,
        initiated_by: initiatedBy
      }, { transaction });
      const childCredit = Math.round((parseFloat(childWallet.credit || 0) - wd) * 100) / 100;
      const childInr = Math.round((parseFloat(childWallet.inr_balance || 0) - wd) * 100) / 100;
      const childEmit = { inr_balance: childInr, credit: childCredit, all_point: childAllPointAfter };
      if (childRole === "USER") childEmit.cash = Math.round((parseFloat(childWallet.cash || 0) - wd) * 100) / 100;
      emitBalanceUpdate(childId, childEmit);
      emitBalanceUpdate(actorId, { inr_balance: actorInrAfter });
      return {
        child: childWallet.username,
        child_type: childRole,
        amount: wd,
        child_main_after: childMainAfter,
        child_all_point_after: childAllPointAfter,
        parent: actorWallet.username,
        parent_inr_after: actorInrAfter
      };
    } catch (e) {
      console.error("\u274C withdrawFromChild error:", e);
      throw e;
    }
  },
  // -----------------------------------------------------------------------
  // SUBTRACT CASH (user → staff/admin)
  // -----------------------------------------------------------------------
  //This is old Api and not recommended to use in tenexch
  subtractCash: async (senderId, amount, senderType, transaction, initiatedBy, receiverId, receiverType) => {
    try {
      const idField = WalletService.getWalletQueryField(senderType);
      const wallet = await Wallet_default.findOne({ where: { [idField]: senderId }, transaction });
      if (!wallet) throw new Error("Wallet not found");
      const prevCash = parseFloat(wallet.cash || 0);
      if (prevCash < parseFloat(amount)) throw new Error("Insufficient cash");
      const prevInr = parseFloat(wallet.inr_balance || 0);
      wallet.cash = prevCash - parseFloat(amount);
      wallet.inr_balance = prevInr - parseFloat(amount);
      await wallet.save({ transaction });
      let { userId: s_userId, staffId: s_staffId, ownerId: s_ownerId } = await WalletService.getHierarchyIds(senderId, senderType);
      if (receiverType && receiverType.toUpperCase() === "OWNER" && senderType && senderType.toUpperCase() === "USER") {
        s_staffId = null;
        if (!s_ownerId) s_ownerId = receiverId;
      }
      await Transaction_default.create({
        wallet_id: wallet.wallet_id,
        user_id: s_userId,
        staff_id: s_staffId,
        owner_id: s_ownerId,
        username: wallet.username,
        type: "SUBTRACT_CASH",
        amount: parseFloat(amount),
        previous_balance: prevCash,
        new_balance: wallet.cash,
        balance: wallet.inr_balance,
        credit: initiatedBy,
        debit: wallet.username,
        initiated_by: initiatedBy
      }, { transaction });
      emitBalanceUpdate(senderId, { cash: wallet.cash, inr_balance: wallet.inr_balance });
      if (receiverId && receiverType) {
        const receiverField = WalletService.getWalletQueryField(receiverType);
        const receiverWallet = await Wallet_default.findOne({
          where: { [receiverField]: receiverId },
          transaction,
          lock: transaction.LOCK.UPDATE
        });
        if (receiverWallet) {
          const rPrevCash = parseFloat(receiverWallet.cash || 0);
          const rPrevInr = parseFloat(receiverWallet.inr_balance || 0);
          receiverWallet.cash = rPrevCash + parseFloat(amount);
          receiverWallet.inr_balance = rPrevInr + parseFloat(amount);
          await receiverWallet.save({ transaction });
          const { userId: r_userId, staffId: r_staffId, ownerId: r_ownerId } = await WalletService.getHierarchyIds(receiverId, receiverType);
          await Transaction_default.create({
            wallet_id: receiverWallet.wallet_id,
            user_id: r_userId,
            staff_id: r_staffId,
            owner_id: r_ownerId,
            username: receiverWallet.username,
            type: "COLLECT_CASH",
            amount: parseFloat(amount),
            previous_balance: rPrevCash,
            new_balance: receiverWallet.cash,
            balance: receiverWallet.inr_balance,
            credit: receiverWallet.username,
            debit: wallet.username,
            initiated_by: initiatedBy
          }, { transaction });
          emitBalanceUpdate(receiverId, { cash: receiverWallet.cash, inr_balance: receiverWallet.inr_balance });
        }
      }
      return wallet;
    } catch (e) {
      console.error("\u274C subtractCash error:", e);
      throw e;
    }
  },
  updateAllPointHierarchy: async (betId, betType) => {
    if (!betId) return { success: false, error: "betId is required" };
    const category = (betType || "").toString().toUpperCase();
    if (!Object.values(POINT_CATEGORY).includes(category)) {
      return { success: false, error: `invalid betType "${betType}" \u2014 SPORTS chahiye` };
    }
    let gtype = null;
    const ledgerCategories = LEDGER_CATEGORY_ALIASES[category] || [category];
    let credit = await CreditsLedger_default.findOne({
      where: {
        bet_id: betId,
        category: { [Op.in]: ledgerCategories },
        [Op.or]: [{ profit: { [Op.ne]: null } }, { loss: { [Op.ne]: null } }]
      },
      order: [["id", "ASC"]]
    });
    if (!credit) return { success: false, error: `credits_ledger entry not found for ${category} bet ${betId}` };
    if (credit?.points_applied) {
      return { success: true, duplicate: true, reason: `bet ${betId} ke points pehle hi lag chuke hain` };
    }
    const net = Math.round((parseFloat(credit.profit || 0) + parseFloat(credit.loss || 0)) * 100) / 100;
    if (net === 0) {
      await credit.update({ points_applied: true });
      return { success: true, skipped: true, reason: `bet ${betId} ka net 0 hai` };
    }
    const outcome = net > 0 ? "won" : "loss";
    const userId = Number(credit.user_id);
    const entryRef = pointEntryRef.bet(category, betId);
    if (category === POINT_CATEGORY.SPORTS) {
      const sportsBet = await SportsBet_default.findByPk(betId, { attributes: ["gtype"] });
      gtype = sportsBet?.gtype || null;
    }
    if (!gtype) gtype = credit?.market_type || credit?.meta?.market_type || null;
    const tx = await db_default.transaction();
    try {
      const user = await User_default.findByPk(userId, { transaction: tx });
      if (!user) throw new Error(`user ${userId} not found`);
      if (user.is_demo) {
        await credit.update({ points_applied: true }, { transaction: tx });
        await tx.commit();
        return { success: true, skipped: true, reason: `bet ${betId} belongs to demo user ${userId} \u2014 points not rolled up` };
      }
      const staffIds = [];
      let ownerId = user.parent_owner_id || null;
      let staffId = user.parent_staff_id;
      const visited = /* @__PURE__ */ new Set();
      while (staffId) {
        if (visited.has(staffId)) break;
        visited.add(staffId);
        const staff = await Staff_default.findByPk(staffId, { transaction: tx });
        if (!staff) throw new Error(`staff ${staffId} not found (user ${userId} ki hierarchy)`);
        staffIds.push(staff.staff_id);
        if (staff.parent_owner_id) ownerId = staff.parent_owner_id;
        staffId = staff.parent_id;
      }
      const wallets = [];
      const userWallet = await Wallet_default.findOne({ where: { user_id: userId, user_type: "USER" }, transaction: tx });
      if (!userWallet) throw new Error(`wallet not found for user ${userId}`);
      wallets.push(userWallet);
      for (const id of staffIds) {
        const staffWallet = await Wallet_default.findOne({ where: { staff_id: id }, transaction: tx });
        if (!staffWallet) throw new Error(`wallet not found for staff ${id}`);
        wallets.push(staffWallet);
      }
      if (ownerId) {
        const ownerWallet = await Wallet_default.findOne({ where: { owner_id: ownerId, user_type: "OWNER" }, transaction: tx });
        if (!ownerWallet) throw new Error(`wallet not found for owner ${ownerId}`);
        wallets.push(ownerWallet);
      }
      const walletIds = wallets.map((w) => w.wallet_id);
      const categoryColumn = {
        SPORTS: "sports_pts"
      }[category];
      const incFields = { all_point: net };
      if (categoryColumn) incFields[categoryColumn] = net;
      await Wallet_default.increment(incFields, { where: { wallet_id: walletIds }, transaction: tx });
      const updated = await Wallet_default.findAll({
        where: { wallet_id: walletIds },
        attributes: ["wallet_id", "user_id", "staff_id", "owner_id", "username", "all_point", "inr_balance"],
        transaction: tx
      });
      await PointLedger_default.bulkCreate(
        updated.map((w) => ({
          entry_ref: entryRef,
          event_type: POINT_EVENT.BET_SETTLEMENT,
          category,
          bet_id: betId,
          wallet_id: w.wallet_id,
          username: w.username,
          delta: net,
          all_point_after: parseFloat(w?.all_point || 0),
          closing_inr_balance: parseFloat(w?.inr_balance || 0),
          sport_id: credit?.sport_id || null,
          game_type: gtype,
          source_user_id: userId,
          remark: credit?.description
        })),
        { transaction: tx }
      );
      await credit.update({ points_applied: true }, { transaction: tx });
      await tx.commit();
      for (const w of updated) {
        const entityId = w.user_id || w.staff_id || w.owner_id;
        if (entityId) {
          emitBalanceUpdate(entityId, { all_point: parseFloat(w.all_point || 0) });
        }
      }
      return {
        success: true,
        status: outcome,
        point: Math.abs(net),
        entry_ref: entryRef,
        wallets_updated: wallets.length,
        usernames: wallets.map((w) => w.username)
      };
    } catch (err) {
      await tx.rollback();
      return { success: false, error: err.message };
    }
  },
  /**
   * updateAllPointHierarchy ka ulta — jab ek settle ho chuki bet ko void kiya
   * jaata hai to us settlement se lage all_point/category points wapas lene
   * hote hain (poori chain me: user → staff → owner).
   *
   * Original `settle:bet:*` PointLedger entry kabhi delete nahi hoti; uske
   * saamne `reverse:bet:*` entries banti hain (POINT_EVENT.REVERSAL) —
   * (wallet_id, entry_ref) unique index dobara reverse hone se rokta hai.
   * PointLedger entry likhna zaroori hai: bina ledger ke all_point change ko
   * integrity cron tampering samajh ke revert kar deta hai.
   *
   * @param {number} betId
   * @param {string} betType POINT_CATEGORY ka koi value
   */
  reverseAllPointHierarchy: async (betId, betType) => {
    if (!betId) return { success: false, error: "betId is required" };
    const category = (betType || "").toString().toUpperCase();
    if (!Object.values(POINT_CATEGORY).includes(category)) {
      return { success: false, error: `invalid betType "${betType}" \u2014 SPORTS chahiye` };
    }
    const credit = await CreditsLedger_default.findOne({
      where: {
        bet_id: betId,
        category: { [Op.in]: LEDGER_CATEGORY_ALIASES[category] || [category] },
        [Op.or]: [{ profit: { [Op.ne]: null } }, { loss: { [Op.ne]: null } }]
      },
      order: [["id", "ASC"]]
    });
    if (!credit) return { success: true, skipped: true, reason: `credits_ledger entry not found for ${category} bet ${betId}` };
    if (!credit.points_applied) return { success: true, skipped: true, reason: `bet ${betId} ke points kabhi apply hi nahi hue` };
    const net = Math.round((parseFloat(credit.profit || 0) + parseFloat(credit.loss || 0)) * 100) / 100;
    if (net === 0) return { success: true, skipped: true, reason: `bet ${betId} ka net 0 hai` };
    const delta = -net;
    const userId = Number(credit.user_id);
    const entryRef = pointEntryRef.betReversal(category, betId);
    const tx = await db_default.transaction();
    try {
      const user = await User_default.findByPk(userId, { transaction: tx });
      if (!user) throw new Error(`user ${userId} not found`);
      const staffIds = [];
      let ownerId = user.parent_owner_id || null;
      let staffId = user.parent_staff_id;
      const visited = /* @__PURE__ */ new Set();
      while (staffId) {
        if (visited.has(staffId)) break;
        visited.add(staffId);
        const staff = await Staff_default.findByPk(staffId, { transaction: tx });
        if (!staff) throw new Error(`staff ${staffId} not found (user ${userId} ki hierarchy)`);
        staffIds.push(staff.staff_id);
        if (staff.parent_owner_id) ownerId = staff.parent_owner_id;
        staffId = staff.parent_id;
      }
      const wallets = [];
      const userWallet = await Wallet_default.findOne({ where: { user_id: userId, user_type: "USER" }, transaction: tx });
      if (!userWallet) throw new Error(`wallet not found for user ${userId}`);
      wallets.push(userWallet);
      for (const id of staffIds) {
        const staffWallet = await Wallet_default.findOne({ where: { staff_id: id }, transaction: tx });
        if (!staffWallet) throw new Error(`wallet not found for staff ${id}`);
        wallets.push(staffWallet);
      }
      if (ownerId) {
        const ownerWallet = await Wallet_default.findOne({ where: { owner_id: ownerId, user_type: "OWNER" }, transaction: tx });
        if (!ownerWallet) throw new Error(`wallet not found for owner ${ownerId}`);
        wallets.push(ownerWallet);
      }
      const walletIds = wallets.map((w) => w.wallet_id);
      const categoryColumn = {
        SPORTS: "sports_pts"
      }[category];
      const incFields = { all_point: delta };
      if (categoryColumn) incFields[categoryColumn] = delta;
      await Wallet_default.increment(incFields, { where: { wallet_id: walletIds }, transaction: tx });
      const updated = await Wallet_default.findAll({
        where: { wallet_id: walletIds },
        attributes: ["wallet_id", "user_id", "staff_id", "owner_id", "username", "all_point", "inr_balance"],
        transaction: tx
      });
      await PointLedger_default.bulkCreate(
        updated.map((w) => ({
          entry_ref: entryRef,
          event_type: POINT_EVENT.REVERSAL,
          category,
          bet_id: betId,
          wallet_id: w.wallet_id,
          username: w.username,
          delta,
          all_point_after: parseFloat(w?.all_point || 0),
          closing_inr_balance: parseFloat(w?.inr_balance || 0),
          sport_id: credit?.sport_id || null,
          game_type: credit?.market_type || null,
          source_user_id: userId,
          remark: withVoidSuffix(credit?.description || "")
        })),
        { transaction: tx }
      );
      await tx.commit();
      for (const w of updated) {
        const entityId = w.user_id || w.staff_id || w.owner_id;
        if (entityId) emitBalanceUpdate(entityId, { all_point: parseFloat(w.all_point || 0) });
      }
      return { success: true, point: Math.abs(delta), entry_ref: entryRef, wallets_updated: wallets.length };
    } catch (err) {
      await tx.rollback();
      return { success: false, error: err.message };
    }
  },
  // ── Silent void: settlement ke point rows MITA do ──────────────────────────
  // Admin ke "Create statement entry" switch ka OFF wala raasta. Ulti entry
  // likhne ke bajaye ASLI entry hi hata di jaati hai, taaki statement me aisa
  // lage jaise settlement kabhi hui hi nahi.
  //
  // Har deleted row ke liye teen kaam, usi wallet par:
  //   1. wallet.all_point (+ category pts) me se us row ka delta ghatao
  //   2. us wallet ki BAAD wali rows ke snapshots peeche khisakao —
  //      all_point_after hamesha, aur closing_inr_balance SIRF player ki apni
  //      wallet par (settlement ne upline ka inr_balance chhua hi nahi tha,
  //      sirf points chale the)
  //   3. row delete
  //
  // (2) ke bina statement ka "pts" column poora hi jhooth bol deta: baad ki
  // saari rows jeet wala balance dikhati rehti hain aur aakhri line asli wallet
  // se match nahi karti. Aur (1) ke saath all_point = SUM(point_ledger.delta)
  // barabar bana rehta hai — system tracker ka tier-1 check wahi dekhta hai.
  deletePointEntries: async (entryRef) => {
    if (!entryRef) return { success: false, error: "entryRef is required" };
    const tx = await db_default.transaction();
    try {
      const rows = await PointLedger_default.findAll({
        where: { entry_ref: entryRef },
        order: [["id", "ASC"]],
        transaction: tx,
        lock: tx.LOCK.UPDATE
      });
      if (!rows.length) {
        await tx.commit();
        return { success: true, skipped: true, reason: `${entryRef} ki koi entry nahi mili` };
      }
      const touched = [];
      for (const r of rows) {
        const delta = Math.round((parseFloat(r.delta) || 0) * 100) / 100;
        const wallet = await Wallet_default.findOne({
          where: { wallet_id: r.wallet_id },
          transaction: tx,
          lock: tx.LOCK.UPDATE
        });
        if (!wallet) throw new Error(`wallet ${r.wallet_id} not found (${entryRef})`);
        const categoryColumn = {
          SPORTS: "sports_pts"
        }[String(r.category || "").toUpperCase()];
        const decFields = { all_point: -delta };
        if (categoryColumn) decFields[categoryColumn] = -delta;
        await Wallet_default.increment(decFields, { where: { wallet_id: r.wallet_id }, transaction: tx });
        await db_default.query(
          `UPDATE point_ledger SET all_point_after = all_point_after - :d
            WHERE wallet_id = :w AND id > :id AND all_point_after IS NOT NULL`,
          { replacements: { d: delta, w: r.wallet_id, id: r.id }, transaction: tx }
        );
        if (wallet.user_id != null) {
          await db_default.query(
            `UPDATE point_ledger SET closing_inr_balance = closing_inr_balance - :d
              WHERE wallet_id = :w AND id > :id AND closing_inr_balance IS NOT NULL`,
            { replacements: { d: delta, w: r.wallet_id, id: r.id }, transaction: tx }
          );
        }
        await r.destroy({ transaction: tx });
        touched.push(r.wallet_id);
      }
      await tx.commit();
      for (const walletId of touched) {
        const w = await Wallet_default.findOne({
          where: { wallet_id: walletId },
          attributes: ["wallet_id", "user_id", "staff_id", "owner_id", "all_point"],
          raw: true
        });
        const entityId = w?.user_id || w?.staff_id || w?.owner_id;
        if (entityId) emitBalanceUpdate(entityId, { all_point: parseFloat(w.all_point || 0) });
      }
      return { success: true, deleted: rows.length, entry_ref: entryRef };
    } catch (err) {
      await tx.rollback();
      return { success: false, error: err.message };
    }
  },
  // ── Sports win commission → points chain ────────────────────────────────
  // Settlement ke baad alag movement: user ne `amount` commission di. Wahi
  // hierarchy walk jo updateAllPointHierarchy karta hai (user → staff chain →
  // owner), delta = -amount har wallet par, event_type COMMISSION, ek row per
  // wallet — isi row se user ke statement me "…- Comm" line dikhti hai aur
  // all_point = SUM(point_ledger) bana rehta hai.
  // Plan: docs/plans/2026-09-09-sports-win-commission.md
  applyCommissionPoints: async ({ betId, userId, amount, remark, sportId, gtype }) => {
    const comm = Math.round((parseFloat(amount) || 0) * 100) / 100;
    if (!betId) return { success: false, error: "betId is required" };
    if (!(comm > 0)) return { success: true, skipped: true, reason: "commission is 0" };
    return WalletService._writeCommissionChain({
      betId,
      userId,
      delta: -comm,
      remark,
      sportId,
      gtype,
      eventType: POINT_EVENT.COMMISSION,
      entryRef: pointEntryRef.commission(POINT_CATEGORY.SPORTS, betId)
    });
  },
  // Settlement void ke saath commission bhi wapas — ulti entry, original kabhi delete nahi hoti.
  reverseCommissionPoints: async ({ betId, userId, amount, remark, sportId, gtype }) => {
    const comm = Math.round((parseFloat(amount) || 0) * 100) / 100;
    if (!betId) return { success: false, error: "betId is required" };
    if (!(comm > 0)) return { success: true, skipped: true, reason: "commission is 0" };
    return WalletService._writeCommissionChain({
      betId,
      userId,
      delta: comm,
      remark,
      sportId,
      gtype,
      eventType: POINT_EVENT.REVERSAL,
      entryRef: pointEntryRef.commissionReversal(POINT_CATEGORY.SPORTS, betId)
    });
  },
  _writeCommissionChain: async ({ betId, userId, delta, remark, sportId, gtype, eventType, entryRef }) => {
    const category = POINT_CATEGORY.SPORTS;
    const tx = await db_default.transaction();
    try {
      const user = await User_default.findByPk(userId, { transaction: tx });
      if (!user) throw new Error(`user ${userId} not found`);
      if (user.is_demo) {
        await tx.commit();
        return { success: true, skipped: true, reason: `bet ${betId} belongs to demo user ${userId} \u2014 commission points not rolled up` };
      }
      const already = await PointLedger_default.findOne({ where: { entry_ref: entryRef }, attributes: ["id"], transaction: tx });
      if (already) {
        await tx.commit();
        return { success: true, duplicate: true, reason: `${entryRef} already written` };
      }
      const staffIds = [];
      let ownerId = user.parent_owner_id || null;
      let staffId = user.parent_staff_id;
      const visited = /* @__PURE__ */ new Set();
      while (staffId) {
        if (visited.has(staffId)) break;
        visited.add(staffId);
        const staff = await Staff_default.findByPk(staffId, { transaction: tx });
        if (!staff) throw new Error(`staff ${staffId} not found (user ${userId} ki hierarchy)`);
        staffIds.push(staff.staff_id);
        if (staff.parent_owner_id) ownerId = staff.parent_owner_id;
        staffId = staff.parent_id;
      }
      const wallets = [];
      const userWallet = await Wallet_default.findOne({ where: { user_id: userId, user_type: "USER" }, transaction: tx });
      if (!userWallet) throw new Error(`wallet not found for user ${userId}`);
      wallets.push(userWallet);
      for (const id of staffIds) {
        const staffWallet = await Wallet_default.findOne({ where: { staff_id: id }, transaction: tx });
        if (!staffWallet) throw new Error(`wallet not found for staff ${id}`);
        wallets.push(staffWallet);
      }
      if (ownerId) {
        const ownerWallet = await Wallet_default.findOne({ where: { owner_id: ownerId, user_type: "OWNER" }, transaction: tx });
        if (!ownerWallet) throw new Error(`wallet not found for owner ${ownerId}`);
        wallets.push(ownerWallet);
      }
      const walletIds = wallets.map((w) => w.wallet_id);
      await Wallet_default.increment({ all_point: delta, sports_pts: delta }, { where: { wallet_id: walletIds }, transaction: tx });
      const updated = await Wallet_default.findAll({
        where: { wallet_id: walletIds },
        attributes: ["wallet_id", "user_id", "staff_id", "owner_id", "username", "all_point", "inr_balance"],
        transaction: tx
      });
      await PointLedger_default.bulkCreate(
        updated.map((w) => ({
          entry_ref: entryRef,
          event_type: eventType,
          category,
          bet_id: betId,
          wallet_id: w.wallet_id,
          username: w.username,
          delta,
          all_point_after: parseFloat(w?.all_point || 0),
          closing_inr_balance: parseFloat(w?.inr_balance || 0),
          sport_id: sportId || null,
          game_type: gtype || null,
          source_user_id: userId,
          remark: String(remark || "").slice(0, 255)
        })),
        { transaction: tx }
      );
      await tx.commit();
      for (const w of updated) {
        const entityId = w.user_id || w.staff_id || w.owner_id;
        if (entityId) emitBalanceUpdate(entityId, { all_point: parseFloat(w.all_point || 0) });
      }
      return { success: true, point: Math.abs(delta), entry_ref: entryRef, wallets_updated: wallets.length };
    } catch (err) {
      await tx.rollback();
      return { success: false, error: err.message };
    }
  },
  settlePointsFromChild: async (userId, username, points, actorId, actorType, initiatedBy, remark) => {
    const actorRole = actorType ? actorType.toUpperCase() : "";
    if (actorRole !== "OWNER" && actorRole !== "STAFF") {
      return { success: false, error: "Only owner or staff can do settlement" };
    }
    if (!userId || !username) return { success: false, error: "userId and username are required" };
    if (!actorId) return { success: false, error: "Settling account id not found" };
    const delta = Math.round(parseFloat(points) * 100) / 100;
    if (isNaN(delta)) return { success: false, error: `Invalid points value "${points}"` };
    if (delta === 0) return { success: false, error: "points cannot be 0" };
    const tx = await db_default.transaction();
    try {
      const actorWhere = actorRole === "OWNER" ? { owner_id: actorId, user_type: "OWNER" } : { staff_id: actorId };
      const actorWallet = await Wallet_default.findOne({ where: actorWhere, transaction: tx, lock: tx.LOCK.UPDATE });
      if (!actorWallet) throw new Error(`Wallet not found for ${actorRole} ${actorId}`);
      const user = await User_default.findByPk(userId, { transaction: tx });
      const staff = await Staff_default.findByPk(userId, { transaction: tx });
      let child = null;
      if (user && user.username === username) {
        child = {
          isUser: true,
          id: user.user_id,
          username: user.username,
          parentStaff: user.parent_staff_id,
          parentOwner: user.parent_owner_id
        };
      } else if (staff && staff.username === username) {
        child = {
          isUser: false,
          id: staff.staff_id,
          username: staff.username,
          parentStaff: staff.parent_id,
          parentOwner: staff.parent_owner_id
        };
      }
      if (!child) throw new Error(`${username} (id ${userId}) not found`);
      let isDirect = false;
      if (actorRole === "OWNER") {
        isDirect = !child.parentStaff && Number(child.parentOwner) === Number(actorId);
      } else {
        isDirect = Number(child.parentStaff) === Number(actorId);
      }
      if (!isDirect) {
        throw new Error(`${child.username} is not your direct child, settlement not allowed`);
      }
      const childWhere = child.isUser ? { user_id: child.id, user_type: "USER" } : { staff_id: child.id };
      const childWallet = await Wallet_default.findOne({
        where: childWhere,
        transaction: tx,
        lock: tx.LOCK.UPDATE
      });
      if (!childWallet) throw new Error(`Wallet not found for ${child.username}`);
      if (childWallet.wallet_id === actorWallet.wallet_id) {
        throw new Error("Cannot settle with your own account");
      }
      const sumRow = await PointLedger_default.findOne({
        where: { wallet_id: childWallet.wallet_id },
        attributes: [[db_default.fn("SUM", db_default.col("delta")), "total"]],
        raw: true,
        transaction: tx
      });
      const ledgerPoint = Math.round(parseFloat(sumRow.total || 0) * 100) / 100;
      const counter = Math.round(parseFloat(childWallet.all_point || 0) * 100) / 100;
      const credit = Math.round(parseFloat(childWallet.credit || 0) * 100) / 100;
      const pending2 = Math.round((ledgerPoint - credit) * 100) / 100;
      if (counter !== ledgerPoint) {
        throw new Error(`${child.username} all_point does not match ledger (wallet ${counter}, ledger ${ledgerPoint}), settlement blocked`);
      }
      if (pending2 === 0) throw new Error(`${child.username} has no pending settlement`);
      if (pending2 > 0 && delta > 0 || pending2 < 0 && delta < 0 || Math.abs(delta) > Math.abs(pending2)) {
        throw new Error(`Amount Greater than P/L`);
      }
      const newAllPoint = Math.round((counter + delta) * 100) / 100;
      const taking = delta < 0;
      const childMainCol = child.isUser ? "cash" : "inr_balance";
      const childMainBefore = Math.round(parseFloat(childWallet[childMainCol] || 0) * 100) / 100;
      const childMainAfter = Math.round((childMainBefore + delta) * 100) / 100;
      const actorInrBefore = Math.round(parseFloat(actorWallet.inr_balance || 0) * 100) / 100;
      if (taking && childMainBefore < Math.abs(delta)) {
        throw new Error(`${child.username} has only ${childMainBefore} ${child.isUser ? "cash" : "INR"}, cannot take ${Math.abs(delta)}`);
      }
      if (!taking && actorInrBefore < delta) {
        throw new Error(`${actorWallet.username} has only ${actorInrBefore} INR, cannot pay ${delta}`);
      }
      const actorInrAfter = Math.round((actorInrBefore - delta) * 100) / 100;
      const creditName = taking ? actorWallet.username : child.username;
      const debitName = taking ? child.username : actorWallet.username;
      const txnRow = await Transaction_default.create({
        wallet_id: childWallet.wallet_id,
        user_id: child.isUser ? child.id : null,
        staff_id: child.isUser ? null : child.id,
        owner_id: null,
        username: child.username,
        type: "POINT_SETTLEMENT",
        amount: Math.abs(delta),
        previous_balance: childMainBefore,
        new_balance: childMainAfter,
        balance: childMainAfter,
        credit: creditName,
        debit: debitName,
        initiated_by: initiatedBy || actorWallet.username
      }, { transaction: tx });
      await Transaction_default.create({
        wallet_id: actorWallet.wallet_id,
        user_id: null,
        staff_id: actorRole === "STAFF" ? actorId : null,
        owner_id: actorRole === "OWNER" ? actorId : null,
        username: actorWallet.username,
        type: "POINT_SETTLEMENT",
        amount: Math.abs(delta),
        previous_balance: actorInrBefore,
        new_balance: actorInrAfter,
        balance: actorInrAfter,
        credit: creditName,
        debit: debitName,
        initiated_by: initiatedBy || actorWallet.username
      }, { transaction: tx });
      const entryRef = pointEntryRef.cashSettle(txnRow.id);
      const childInc = { all_point: delta, upper_point: delta, inr_balance: delta };
      if (child.isUser) childInc.cash = delta;
      await Wallet_default.increment(childInc, { where: { wallet_id: childWallet.wallet_id }, transaction: tx });
      await Wallet_default.increment(
        { down_point: -delta, inr_balance: -delta },
        { where: { wallet_id: actorWallet.wallet_id }, transaction: tx }
      );
      remark = remark ? remark : delta > 0 ? POINT_EVENT.BANK_DEPOSIT : POINT_EVENT.BANK_WITHDRAW;
      await PointLedger_default.create({
        entry_ref: entryRef,
        event_type: delta > 0 ? POINT_EVENT.BANK_DEPOSIT : POINT_EVENT.BANK_WITHDRAW,
        wallet_id: childWallet.wallet_id,
        username: child.username,
        settled_with_wallet_id: actorWallet.wallet_id,
        delta,
        all_point_after: newAllPoint,
        closing_inr_balance: Math.round((parseFloat(childWallet.inr_balance || 0) + delta) * 100) / 100,
        closing_inr_balance_parent: actorInrAfter,
        source_user_id: child.isUser ? child.id : null,
        remark: `${remark}#${taking ? `${child.username}/${actorWallet.username}` : `${actorWallet.username}/${child.username}`}`
      }, { transaction: tx });
      await tx.commit();
      emitBalanceUpdate(child.id, { all_point: newAllPoint });
      const pendingAfter = Math.round((pending2 + delta) * 100) / 100;
      return {
        success: true,
        all_point_after: newAllPoint
      };
    } catch (err) {
      await tx.rollback();
      console.error("\u274C settlePointsFromChild error:", err.message);
      return { success: false, error: err.message };
    }
  },
  // -----------------------------------------------------------------------
  // ADD CREDIT → OWNER gets it for FREE
  // -----------------------------------------------------------------------
  // -----------------------------------------------------------------------
  // GET USER WALLET
  // -----------------------------------------------------------------------
  getUserWallet: async (entityId, userType) => {
    const idField = WalletService.getWalletQueryField(userType);
    const w = await Wallet_default.findOne({ where: { [idField]: entityId, user_type: userType } });
    if (!w) throw new Error("Wallet not found");
    return {
      username: w.username,
      user_type: w.user_type,
      cash: parseFloat(w.cash || 0),
      inr_balance: parseFloat(w.inr_balance || 0),
      cash_received: parseFloat(w.cash_received || 0)
    };
  },
  // -----------------------------------------------------------------------
  // Optional: Get all wallets, by role, etc.
  // -----------------------------------------------------------------------
  getAllWallets: async () => await Wallet_default.findAll(),
  getWalletsByRole: async (role) => await Wallet_default.findAll({ where: { user_type: role.toUpperCase() } })
};
var walletService_default = WalletService;

// model/admin/CommissionConfig.js
import { DataTypes as DataTypes20 } from "sequelize";

// constants/commissionLeagues.js
var DEFAULT_LEAGUE_KEY = "default";
var DEFAULT_LEAGUE_LABEL = "All other leagues";
var COMMISSION_LEAGUES = {
  // Cricket
  4: [
    { key: "ecricket", label: "E-Cricket (Dim)", patterns: ["dim cricket league"], cid: 7526679, iscc: 4 },
    { key: "t10xi", label: "T10 XI", patterns: ["t10 xi"], cid: 56100513, iscc: 1 },
    { key: "t5xi", label: "T5 XI", patterns: ["t5 xi"], cid: 46201121, iscc: 1 },
    { key: "vcl", label: "Virtual Cricket League", patterns: ["virtual cricket league"], cid: 8590658, iscc: 2 }
  ],
  // Wrestling — one virtual league, same shape as cricket's VCL.
  69: [
    { key: "wwevirtual", label: "WWE Virtual", patterns: ["wwe virtual"], cid: 8524813, iscc: 2 }
  ]
};
var normaliseLeagueName = (name) => String(name || "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
var leaguesForSport = (sportId) => COMMISSION_LEAGUES[Number(sportId)] || [];
var isValidLeagueKey = (sportId, leagueKey) => leagueKey === DEFAULT_LEAGUE_KEY || leaguesForSport(sportId).some((l) => l.key === leagueKey);
var leagueKeyFromName = (sportId, leagueName) => {
  const norm3 = normaliseLeagueName(leagueName);
  if (!norm3) return DEFAULT_LEAGUE_KEY;
  for (const league of leaguesForSport(sportId)) {
    if (league.patterns.some((p) => norm3.includes(p))) return league.key;
  }
  return DEFAULT_LEAGUE_KEY;
};
var leagueLabel = (sportId, leagueKey) => {
  if (leagueKey === DEFAULT_LEAGUE_KEY) return DEFAULT_LEAGUE_LABEL;
  const hit = leaguesForSport(sportId).find((l) => l.key === leagueKey);
  return hit ? hit.label : leagueKey;
};

// model/admin/CommissionConfig.js
var CommissionConfig = db_default.define("CommissionConfig", {
  id: {
    type: DataTypes20.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  sport_id: {
    type: DataTypes20.INTEGER,
    allowNull: false,
    comment: "feed etid (4 = Cricket)"
  },
  league_key: {
    type: DataTypes20.STRING(32),
    allowNull: false,
    defaultValue: DEFAULT_LEAGUE_KEY,
    comment: "default | ecricket | t10xi | t5xi | vcl | wwevirtual"
  },
  market_key: {
    type: DataTypes20.STRING(24),
    allowNull: false,
    comment: "matchodds | match_other | bookmaker | match1_other | fancy | \u2026"
  },
  enabled: {
    type: DataTypes20.BOOLEAN,
    allowNull: false,
    defaultValue: false
  },
  percent: {
    type: DataTypes20.DECIMAL(5, 2),
    allowNull: false,
    defaultValue: 2,
    comment: "commission % of net win"
  }
}, {
  tableName: "commission_configs",
  timestamps: true,
  // Uniqueness lives here, never inline on the column: an inline `unique`
  // makes Sequelize emit a fresh ADD CONSTRAINT on every sync, which is how
  // this platform's DBs collected thousands of duplicate unique constraints.
  indexes: [
    {
      name: "commission_configs_sport_league_market_uniq",
      unique: true,
      fields: ["sport_id", "league_key", "market_key"]
    }
  ]
});
CommissionConfig.MARKETS = [
  { key: "matchodds", label: "Match Odds", group: "Main", hint: "market name is exactly Match Odds" },
  { key: "match_other", label: "Other Main Markets", group: "Main", hint: "Over/Under, Correct Score, Match Result, Inning EvenOdd, Nth Ball\u2026" },
  { key: "bookmaker", label: "Bookmaker", group: "Bookmaker", hint: "Bookmaker, Bookmaker 2" },
  { key: "match1_other", label: "Other Bookmaker Markets", group: "Bookmaker", hint: "Tied Match, Completed Match, Score More Runs, BM Over/Under\u2026" },
  { key: "fancy", label: "Fancy", group: "Fancy", hint: "Normal, Over By Over, Ball By Ball" },
  { key: "fancy1", label: "Fancy1", group: "Fancy", hint: "" },
  { key: "fancy2", label: "Fancy2", group: "Fancy", hint: "Innings Overs/Runs lines" },
  { key: "oddeven", label: "Odd/Even", group: "Fancy", hint: "" },
  { key: "khado", label: "Khado", group: "Fancy", hint: "" },
  { key: "meter", label: "Meter", group: "Fancy", hint: "" },
  { key: "badlo", label: "Badlo", group: "Fancy", hint: "" },
  { key: "cricketcasino", label: "Cricket Casino", group: "Fancy", hint: "" },
  { key: "other", label: "Other", group: "Fancy", hint: "anything the feed ships with an unknown gtype" }
];
CommissionConfig.MARKET_KEYS = CommissionConfig.MARKETS.map((m) => m.key);
CommissionConfig.MAX_PERCENT = 50;
CommissionConfig.DEFAULT_PERCENT = 2;
var DIRECT_GTYPES = /* @__PURE__ */ new Set([
  "fancy",
  "fancy1",
  "fancy2",
  "oddeven",
  "khado",
  "meter",
  "badlo",
  "cricketcasino"
]);
var normMarketName = (name) => String(name || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
CommissionConfig.marketKeyOfBet = (bet) => {
  if (bet?.badlo === true || String(bet?.badlo) === "true") return "badlo";
  let g = String(bet?.gtype || "").toLowerCase().trim();
  if (!g) {
    const gt = String(bet?.game_type || "").toUpperCase();
    if (gt === "MO" || gt === "MATCH") g = "match";
    else if (gt === "BM" || gt === "BOOKMAKER") g = "match1";
    else if (gt === "FAN" || gt === "FANCY") g = "fancy";
  }
  const name = normMarketName(bet?.market_type);
  if (g === "match") return name === "MATCHODDS" ? "matchodds" : "match_other";
  if (g === "match1") return name.startsWith("BOOKMAKER") ? "bookmaker" : "match1_other";
  if (DIRECT_GTYPES.has(g)) return g;
  return "other";
};
CommissionConfig.leagueKeyOfBet = (bet) => leagueKeyFromName(bet?.sport_id, bet?.league_name);
CommissionConfig.isValidLeagueKey = isValidLeagueKey;
CommissionConfig.DEFAULT_LEAGUE_KEY = DEFAULT_LEAGUE_KEY;
CommissionConfig.LEGACY_GTYPE_EXPANSION = {
  match: ["matchodds", "match_other"],
  match1: ["bookmaker", "match1_other"]
};
var CommissionConfig_default = CommissionConfig;

// services/CommissionConfigService.js
init_redisClient();
var KEY_COMMISSION = "cfg:commission:v2";
var REDIS_TTL_SEC = 300;
var MICRO_TTL_MS = 2e3;
var NOT_ENABLED = Object.freeze({ enabled: false, percent: 0 });
var micro = null;
var microGet = () => {
  if (!micro) return void 0;
  if (micro.expires < Date.now()) {
    micro = null;
    return void 0;
  }
  return micro.value;
};
var microSet = (value) => {
  micro = { value, expires: Date.now() + MICRO_TTL_MS };
};
var microDel = () => {
  micro = null;
};
var buildMap = async () => {
  const rows = await CommissionConfig_default.findAll({
    attributes: ["sport_id", "league_key", "market_key", "enabled", "percent"],
    raw: true
  });
  const map = {};
  for (const row of rows) {
    const pct = Number(row.percent);
    const sid = String(row.sport_id);
    const league = String(row.league_key || DEFAULT_LEAGUE_KEY).toLowerCase();
    const market = String(row.market_key || "").toLowerCase();
    if (!market) continue;
    ((map[sid] ||= {})[league] ||= {})[market] = {
      enabled: !!row.enabled && Number.isFinite(pct) && pct > 0,
      percent: Number.isFinite(pct) ? pct : 0
    };
  }
  return map;
};
var getMap = async () => {
  const local = microGet();
  if (local !== void 0) return local;
  try {
    const cached = await redisClient_default.get(KEY_COMMISSION);
    if (cached != null) {
      const parsed = JSON.parse(cached);
      microSet(parsed);
      return parsed;
    }
  } catch (err) {
    console.warn(`[CommissionConfig] redis read failed for ${KEY_COMMISSION}:`, err.message);
  }
  let built;
  try {
    built = await buildMap();
  } catch (err) {
    console.warn("[CommissionConfig] build failed:", err.message);
    return {};
  }
  microSet(built);
  redisClient_default.set(KEY_COMMISSION, JSON.stringify(built), "EX", REDIS_TTL_SEC).catch(
    (err) => console.warn(`[CommissionConfig] redis write failed for ${KEY_COMMISSION}:`, err.message)
  );
  return built;
};
var getRule = async (sportId, leagueKey, marketKey) => {
  try {
    const map = await getMap();
    const sport = map?.[String(sportId)];
    if (!sport) return NOT_ENABLED;
    const market = String(marketKey || "").toLowerCase();
    const league = String(leagueKey || DEFAULT_LEAGUE_KEY).toLowerCase();
    if (league !== DEFAULT_LEAGUE_KEY) {
      const own = sport?.[league]?.[market];
      if (own) {
        return own.enabled ? { enabled: true, percent: Number(own.percent), source: "league" } : { ...NOT_ENABLED, source: "league" };
      }
    }
    const fallback = sport?.[DEFAULT_LEAGUE_KEY]?.[market];
    if (fallback?.enabled) {
      return { enabled: true, percent: Number(fallback.percent), source: "default" };
    }
  } catch (err) {
    console.warn("[CommissionConfig] getRule failed:", err.message);
  }
  return NOT_ENABLED;
};
var invalidate = async () => {
  microDel();
  try {
    await redisClient_default.del(KEY_COMMISSION);
  } catch (err) {
    console.warn(`[CommissionConfig] redis del failed for ${KEY_COMMISSION}:`, err.message);
  }
};
var CommissionConfigService_default = {
  getMap,
  getRule,
  invalidate,
  KEY_COMMISSION
};

// services/SportsLeagueResolver.js
init_redisClient();
var EVENT_LIST_KEY = (etid) => `alleventss:${etid}`;
var LEAGUE_KEY = (gmid) => `league:evt:${gmid}`;
var LEAGUE_TTL_SEC = 12 * 60 * 60;
var MICRO_TTL_MS2 = 5e3;
var micro2 = /* @__PURE__ */ new Map();
var MICRO_MAX = 500;
var microGet2 = (gmid) => {
  const hit = micro2.get(gmid);
  if (!hit) return void 0;
  if (hit.expires < Date.now()) {
    micro2.delete(gmid);
    return void 0;
  }
  return hit.value;
};
var microSet2 = (gmid, value) => {
  if (micro2.size >= MICRO_MAX) micro2.clear();
  micro2.set(gmid, { value, expires: Date.now() + MICRO_TTL_MS2 });
};
var shape = (game) => ({
  cname: game?.cname ? String(game.cname) : null,
  cid: game?.cid != null ? Number(game.cid) : null,
  iscc: game?.iscc != null ? Number(game.iscc) : null
});
var resolveLeague = async (sportId, gmid) => {
  const key = String(gmid || "").trim();
  if (!key || !sportId) return null;
  const local = microGet2(key);
  if (local !== void 0) return local;
  try {
    const cached = await redisClient_default.get(LEAGUE_KEY(key));
    if (cached != null) {
      const parsed = JSON.parse(cached);
      microSet2(key, parsed);
      return parsed;
    }
  } catch (err) {
    console.warn("[LeagueResolver] redis read failed:", err.message);
  }
  let found = null;
  try {
    const raw = await redisClient_default.get(EVENT_LIST_KEY(sportId));
    if (raw) {
      const data = JSON.parse(raw);
      const games = [...data?.t1 || [], ...data?.t2 || []];
      const hit = games.find((g) => String(g?.gmid) === key);
      if (hit?.cname) found = shape(hit);
    }
  } catch (err) {
    console.warn("[LeagueResolver] event list read failed:", err.message);
  }
  if (found) {
    microSet2(key, found);
    redisClient_default.set(LEAGUE_KEY(key), JSON.stringify(found), "EX", LEAGUE_TTL_SEC).catch((err) => console.warn("[LeagueResolver] redis write failed:", err.message));
  } else {
    microSet2(key, null);
  }
  return found;
};
var resolveLeagueName = async (sportId, gmid) => {
  const hit = await resolveLeague(sportId, gmid);
  return hit?.cname || null;
};

// services/settlement/sportsCommissionService.js
var COMMISSION_REASON = "commission";
var COMMISSION_SUFFIX = "- Comm";
var round2 = (v) => Math.round((Number(v) || 0) * 100) / 100;
async function applyWinCommission(p) {
  const log2 = p.log || console;
  try {
    const netWin = round2(p.netWin);
    if (!(netWin > 0)) return { applied: false, reason: "no net win" };
    if (!p.settlementLedgerId) return { applied: false, reason: "no settlement ledger id" };
    const bet = p.bet || {};
    const sportId = bet.sport_id ?? p.sport_id ?? null;
    const marketKey = CommissionConfig_default.marketKeyOfBet(bet);
    let leagueName = bet.league_name || null;
    if (!leagueName && (bet.eventid || p.eventid)) {
      leagueName = await resolveLeagueName(sportId, bet.eventid || p.eventid);
    }
    const leagueKey = leagueKeyFromName(sportId, leagueName);
    const rule = await CommissionConfigService_default.getRule(sportId, leagueKey, marketKey);
    if (!rule.enabled) {
      return { applied: false, reason: `cell off (${sportId}/${leagueKey}/${marketKey})` };
    }
    const comm = round2(netWin * rule.percent / 100);
    if (!(comm > 0)) return { applied: false, reason: "rounds to 0" };
    const dup = await CreditsLedger_default.findOne({
      where: {
        user_id: String(p.user_id),
        reason: COMMISSION_REASON,
        bet_id: bet.id || null
      },
      attributes: ["id", "meta"],
      raw: true
    });
    if (dup && Number(dup.meta?.commission_of_ledger_id) === Number(p.settlementLedgerId)) {
      return { applied: false, reason: `already charged (ledger ${dup.id})` };
    }
    const description = `${p.description || ""}${COMMISSION_SUFFIX}`;
    let newCash = 0, newInr = 0, ledgerId = null;
    await db_default.transaction(async (transaction) => {
      const wallet = await Wallet_default.findOne({
        where: { user_id: String(p.user_id) },
        transaction,
        lock: transaction.LOCK.UPDATE
      });
      if (!wallet) throw new Error(`wallet not found for user ${p.user_id}`);
      newCash = round2(Number(wallet.cash || 0) - comm);
      newInr = round2(Number(wallet.inr_balance || 0) - comm);
      await wallet.update({ cash: newCash, inr_balance: newInr }, { transaction });
      await User_default.increment(
        { net_loss: -comm, profit: -comm },
        { where: { user_id: p.user_id }, transaction }
      );
      const row = await CreditsLedger_default.create({
        user_id: String(p.user_id),
        currency: "INR",
        amount: -comm,
        reason: COMMISSION_REASON,
        description,
        eventid: p.eventid || null,
        match_id: p.match_id || null,
        job_id: p.job_id || null,
        market_type: p.market_type || null,
        sport_id: sportId != null ? String(sportId) : null,
        meta: {
          commission_of_ledger_id: Number(p.settlementLedgerId),
          percent: rule.percent,
          // Which cell of the grid charged this, so a disputed
          // commission can be traced back without replaying config
          // history. `gtype` is kept for the pre-2026-09-12 readers.
          market_key: marketKey,
          league_key: leagueKey,
          league_name: leagueName || null,
          rule_source: rule.source || "default",
          gtype: String(bet.gtype || "").toLowerCase() || null,
          net_win: netWin
        },
        commission: comm,
        netamount: -comm,
        profit: null,
        loss: -comm,
        bet_id: bet.id || null,
        closing: newCash,
        category: "SPORTS"
      }, { transaction });
      ledgerId = row.id;
    });
    const pts = await walletService_default.applyCommissionPoints({
      betId: Number(bet.id),
      userId: Number(p.user_id),
      amount: comm,
      remark: description,
      sportId: sportId != null ? String(sportId) : null,
      gtype: marketKey
    });
    if (!pts.success) {
      log2.error("[Commission] points chain failed", { user_id: p.user_id, bet_id: bet.id, error: pts.error });
    }
    log2.info("[Commission] charged", {
      user_id: p.user_id,
      bet_id: bet.id,
      sport_id: sportId,
      market_key: marketKey,
      league_key: leagueKey,
      league: leagueLabel(sportId, leagueKey),
      league_name: leagueName || null,
      rule_source: rule.source || "default",
      market_name: bet.market_type || null,
      net_win: netWin,
      percent: rule.percent,
      commission: comm,
      ledger_id: ledgerId,
      closing_cash: newCash,
      closing_inr: newInr
    });
    return {
      applied: true,
      commission: comm,
      percent: rule.percent,
      ledgerId,
      market_key: marketKey,
      league_key: leagueKey
    };
  } catch (err) {
    log2.error("[Commission] failed \u2014 settlement stands, commission NOT charged", {
      user_id: p?.user_id,
      bet_id: p?.bet?.id,
      error: err.message
    });
    return { applied: false, reason: err.message };
  }
}

// model/admin/manualresult.js
import { DataTypes as DataTypes21 } from "sequelize";
var MannualResult = db_default.define("MannualResult", {
  id: {
    type: DataTypes21.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  match_title: {
    type: DataTypes21.STRING,
    allowNull: false
  },
  eventid: {
    type: DataTypes21.STRING,
    allowNull: false
  },
  match_id: {
    type: DataTypes21.STRING,
    allowNull: false
  },
  market_type: {
    type: DataTypes21.STRING,
    allowNull: false
  },
  game_type: {
    type: DataTypes21.STRING,
    allowNull: false
  },
  winnerId: {
    type: DataTypes21.INTEGER,
    allowNull: true,
    field: "winnerId"
  },
  winnerName: {
    type: DataTypes21.STRING,
    allowNull: true,
    field: "winnerName"
  },
  fancyName: {
    type: DataTypes21.STRING,
    allowNull: true,
    field: "fancyName"
  }
}, {
  tableName: "mannual_result",
  timestamps: true,
  // createdAt & updatedAt
  underscored: true
  // created_at, updated_at
});
var manualresult_default = MannualResult;

// sportsbet/betresult/customMarketResolvers.js
import axios from "axios";
var AVRKHUB_BASE_URL = process.env.AVRKHUB_BASE_URL || "https://diamond-result-v2.avrkhub.in";
var ax = axios.create({
  timeout: 1e4,
  headers: { "User-Agent": "d99-settlement-h2h-fallback/1.0" }
});
async function resolveH2HBookmakerFallback({
  eventid,
  sport_id,
  market_type,
  team_one,
  team_two,
  logger,
  // Optional (gmid, sid) => parsed payload | null. When supplied the caller's
  // per-event result cache answers instead of a fresh feed call per bet.
  getPayload = null
}) {
  const log2 = logger || console;
  const mt = (market_type || "").toUpperCase().trim();
  if (!mt.includes("BOOKMAKER")) return null;
  if (mt === "BOOKMAKER" || mt === "BOOKMAKER 2") return null;
  const overMatch = mt.match(/(\d+(?:\.\d+)?)\s*OVER/);
  if (!overMatch) return null;
  const overNum = overMatch[1];
  const cleanTeam = (s) => {
    const m = (s || "").toUpperCase().trim().match(/^([A-Z]+\d*)/);
    if (!m) return "";
    return m[1].replace(/\d+$/, "");
  };
  const t1 = cleanTeam(team_one);
  const t2 = cleanTeam(team_two);
  if (!t1 || !t2) return null;
  log2.info?.("[H2HFallback] start", {
    eventid,
    market_type,
    team_one,
    team_two,
    overNum,
    t1,
    t2
  });
  let data;
  try {
    if (getPayload) {
      data = await getPayload(eventid, sport_id || "4");
    } else {
      const res = await ax.get(`${AVRKHUB_BASE_URL}/get_result`, {
        params: { gmid: eventid, sid: sport_id || "4" }
      });
      data = typeof res?.data === "string" ? JSON.parse(res.data) : res.data;
    }
  } catch (e) {
    log2.error?.("[H2HFallback] upstream fetch failed", {
      eventid,
      error: e.message
    });
    return null;
  }
  const markets = Array.isArray(data?.markets) ? data.markets : [];
  const findSession = (teamCode) => {
    const overEsc = overNum.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const re = new RegExp(
      `^${overEsc}\\s*OVER\\s+RUNS?(?:\\s+BHAV)?\\s+${teamCode}(?:\\b|\\(|\\.|$)`,
      "i"
    );
    return markets.find(
      (m) => (m?.mname || "").toUpperCase() === "NORMAL" && m?.status === "SETTLE" && m?.winnerId != null && re.test(m?.marketName || "")
    );
  };
  const m1 = findSession(t1);
  const m2 = findSession(t2);
  if (!m1 || !m2) {
    log2.warn?.("[H2HFallback] missing one or both session results", {
      eventid,
      t1,
      t2,
      found_t1: !!m1,
      found_t2: !!m2
    });
    return null;
  }
  const score1 = parseInt(m1.winnerId, 10);
  const score2 = parseInt(m2.winnerId, 10);
  let winnerName;
  if (score1 > score2) winnerName = team_one;
  else if (score2 > score1) winnerName = team_two;
  else winnerName = "SUSPENDED";
  log2.info?.("[H2HFallback] resolved", {
    eventid,
    market_type,
    t1,
    score1,
    t2,
    score2,
    winnerName
  });
  return {
    declared: true,
    items: [
      {
        ename: m1.ename || "",
        marketName: market_type,
        mname: market_type,
        winnerName,
        winnerId: null,
        status: "SETTLE"
      }
    ],
    meta: {
      source: "h2h_bookmaker_fallback",
      overNum,
      t1,
      score1,
      t1_market: m1.marketName,
      t2,
      score2,
      t2_market: m2.marketName
    }
  };
}
function splitRunnerString(value) {
  if (value == null) return [];
  if (Array.isArray(value)) {
    return value.map((v) => {
      if (typeof v === "string") return v;
      if (v && typeof v === "object") return v.nat || v.name || v.runnerName || v.selection_name || "";
      return "";
    }).map((s) => String(s).trim()).filter(Boolean);
  }
  if (typeof value === "string") {
    const s = value.trim();
    if (!s) return [];
    if (s.startsWith("[") || s.startsWith("{")) {
      try {
        return splitRunnerString(JSON.parse(s));
      } catch (_) {
      }
    }
    return s.split(/\s+vs\s+/i).map((x) => x.trim()).filter(Boolean);
  }
  return [];
}
function runnersKey(value) {
  return splitRunnerString(value).map((s) => s.toUpperCase().replace(/\s+/g, " ").trim()).filter(Boolean).sort().join("|");
}
var normMname = (v) => String(v || "").trim().toUpperCase().replace(/[\s_]+/g, " ");
function matchMarketByRunners(markets, runners, eventName, mname) {
  const key = runnersKey(runners);
  if (!key) return null;
  if (key.split("|").length < 3) return null;
  const wantMname = normMname(mname);
  const list = Array.isArray(markets) ? markets : [];
  return list.find((m) => {
    const natKey = runnersKey(m?.natName || m?.nat || "");
    if (!natKey || natKey !== key) return false;
    if (wantMname && normMname(m?.mname) !== wantMname) return false;
    return true;
  }) || null;
}

// helper/totalExposure.js
import { QueryTypes } from "sequelize";
var TOTAL_EXPOSURE_SQL = `
  SELECT COALESCE(SUM(market_exposure), 0) AS total_exposure
  FROM (
    /* Team markets (match odds / bookmaker \u2026): only the worst runner is at
       risk, so they are grouped per market. */
    SELECT MIN(exposure_amount) AS market_exposure
    FROM user_exposures
    WHERE
      user_id = :user_id
      AND game_type IS NOT NULL
      AND (category IS NOT NULL OR game_type LIKE '%:%')
      AND game_type NOT IN (
        'Normal', 'Ball By Ball', 'Over By Over',
        'khado', 'meter', 'fancy1', 'oddeven', 'fancy2', 'badlo'
      )
      AND game_type NOT LIKE '%Overs Line%'
      AND NOT (
        team_name ILIKE '%back'
        OR team_name ILIKE '%lay'
        OR team_name ILIKE '%totalstake'
      )
    GROUP BY match_id, game_type, event_id

    UNION ALL

    /* Independent rows: fancy-family markets (one row each). */
    SELECT exposure_amount AS market_exposure
    FROM user_exposures
    WHERE
      user_id = :user_id
      AND (
        game_type IS NULL
        OR game_type IN (
          'Normal', 'Ball By Ball', 'Over By Over',
          'khado', 'meter', 'fancy1', 'oddeven', 'fancy2', 'badlo'
        )
        OR game_type LIKE '%Overs Line%'
      )
      AND NOT (
        team_name ILIKE '%back'
        OR team_name ILIKE '%lay'
        OR team_name ILIKE '%totalstake'
      )
  ) subquery;
`;

// sportsbet/betresult/settlementv2.js
process.on("uncaughtException", (err) => {
  console.error("[Settlement] Uncaught Exception:", err);
  process.exit(1);
});
process.on("unhandledRejection", (err) => {
  console.error("[Settlement] Unhandled Rejection:", err);
  process.exit(1);
});
async function applyWalletDeltaWithLedger(user_id, { cashDelta = 0, inrDelta = 0, ledger }) {
  return db_default.transaction(async (t) => {
    const w = await Wallet_default.findOne({
      where: { user_id: String(user_id) },
      transaction: t,
      lock: t.LOCK.UPDATE
    });
    if (!w) return null;
    const newCash = Number(w.cash || 0) + Number(cashDelta || 0);
    const newInr = Number(w.inr_balance || 0) + Number(inrDelta || 0);
    await w.update(
      inrDelta ? { cash: newCash, inr_balance: newInr } : { cash: newCash },
      { transaction: t }
    );
    const ledgerRow = await CreditsLedger_default.create({ ...ledger, closing: newCash }, { transaction: t });
    return { ledgerRow, newCash, newInr };
  });
}
console.log("[Settlement] Process started");
var DEBUG = process.env.DEBUG === "1" || process.env.DEBUG === "true";
var BATCH_LIMIT = +(process.env.SETTLE_BATCH_LIMIT || 10);
var RESULTS_API_BASE = process.env.RESULTS_API_BASE || "https://apilords.codefactory.games/api";
var AVRKHUB_BASE_URL2 = process.env.AVRKHUB_BASE_URL || "https://diamond-result-v2.avrkhub.in";
var API_TIMEOUT_MS = +(process.env.API_TIMEOUT_MS || 3e4);
var LEDGER_ZERO_ROWS = process.env.LEDGER_ZERO_ROWS === "1" || process.env.LEDGER_ZERO_ROWS === "true";
var LOG_DIR = process.env.SETTLEMENT_LOG_DIR || path2.join(process.cwd(), "sportsbet/betresult/logs");
var LOG_BASENAME = "settlement-worker-v3-avrkhub";
var CRON_SCHEDULE = process.env.CRON_SCHEDULE || "*/1 * * * *";
var CRON_TZ = process.env.CRON_TZ || "UTC";
var CRON_IMMEDIATE = process.env.CRON_IMMEDIATE === "1" || process.env.CRON_IMMEDIATE === "true";
var MAX_CONCURRENT_API = +(process.env.MAX_CONCURRENT_API || 3);
var RESULTS_RATE_LIMIT_MS = +(process.env.RESULTS_RATE_LIMIT_MS || 250);
var RESULTS_MAX_FETCH_RETRIES = +(process.env.RESULTS_MAX_FETCH_RETRIES || 6);
var RESULTS_RETRY_BASE_MS = +(process.env.RESULTS_RETRY_BASE_MS || 500);
var RESULTS_FORCE_IPV4 = process.env.RESULTS_FORCE_IPV4 === "1" || process.env.RESULTS_FORCE_IPV4 === "true";
var RESULTS_DISABLE_KEEPALIVE = process.env.RESULTS_DISABLE_KEEPALIVE === "1" || process.env.RESULTS_DISABLE_KEEPALIVE === "true";
var USER_AGENT = process.env.USER_AGENT || `settlement-worker/3.0.0-avrkhub (+node ${process.version})`;
var SETTLE_POLL_MS = +(process.env.SETTLE_POLL_MS || 3e3);
var SETTLE_REQUEUE_MS = +(process.env.SETTLE_REQUEUE_MS || 2e4);
var SETTLE_STUCK_MS = +(process.env.SETTLE_STUCK_MS || 18e4);
var RESULT_CACHE_MS = +(process.env.RESULT_CACHE_MS || 2500);
var WAKE_CHANNEL = `sports-settle:wake:${process.env.DB_NAME || "default"}`;
var sportsDataSet = [
  { sid: 4, name: "Cricket", active: true },
  { sid: 1, name: "Football", active: true },
  { sid: 2, name: "Tennis", active: true },
  { sid: 8, name: "Table Tennis", active: true },
  { sid: 68, name: "Esoccer", active: true },
  { sid: 10, name: "Horse Racing", active: true },
  { sid: 65, name: "Greyhound Racing", active: true },
  { sid: 15, name: "Basketball", active: true },
  { sid: 69, name: "Wrestling", active: true },
  { sid: 18, name: "Volleyball", active: true },
  { sid: 22, name: "Badminton", active: true },
  { sid: 59, name: "Snooker", active: true },
  { sid: 57, name: "Darts", active: true },
  { sid: 6, name: "Boxing", active: true },
  { sid: 3, name: "Mixed Martial Arts", active: true },
  { sid: 58, name: "American Football", active: true },
  { sid: 11, name: "E Games", active: true },
  { sid: 19, name: "Ice Hockey", active: true },
  { sid: 9, name: "Futsal", active: true },
  { sid: 40, name: "Politics", active: true },
  { sid: 67, name: "Boat Racing", active: true },
  { sid: 52, name: "Motor Sports", active: true },
  { sid: 12, name: "Greyhounds", active: true },
  // not present in the upstream sports tree
  { sid: 66, name: "Kabaddi", active: true }
];
var getSportName = (sid) => {
  const sport = sportsDataSet.find((s) => String(s.sid) === String(sid));
  return sport ? sport.name : sid != null && sid !== "" ? String(sid) : "Unknown";
};
var buildSettlementDesc = (bet, market_type, winnerLabel) => {
  const matchTitle = bet.match_title || `${bet.team_one} - ${bet.team_two}`;
  const fancyName = String(bet.game_type || "").toUpperCase() === "FAN" ? fanMarketName(bet) || "" : "";
  return [getSportName(bet.sport_id), matchTitle, market_type, fancyName, winnerLabel].filter((p) => p !== null && p !== void 0 && p !== "").join(" / ");
};
var bigRunnerSessionMarket = /\b(1ST|2ND|3RD)\s+INN\s+(\d+(\.\d+)?\s+OVER|LAMBI)\b/i;
function isNonFancyMarket(market_type) {
  if (fixedNonFancyMarkets.includes(market_type)) {
    return true;
  }
  if (bigRunnerSessionMarket.test(market_type)) {
    return true;
  }
  if (/^Game Winner\s+(?:[1-9]|1\d|20)\/(?:[1-9]|1\d|20)$/.test(market_type)) {
    return true;
  }
  if (/^Match Time Result\s+\d{2}:\d{2}$/.test(market_type)) {
    return true;
  }
  if (/^\d+(?:st|nd|rd|th)\s+Set Race To\s+(?:[1-9]|1[0-5])\.0$/.test(market_type)) {
    return true;
  }
  if (/^Under\/Over(?: 180s)?\s+\d+(\.\d)?$/.test(market_type)) {
    return true;
  }
  if (/^Total Tie Break in the Match\s+\d+(\.\d)?$/.test(market_type)) {
    return true;
  }
  if (/^Correct Score\s+\d+(?:st|nd|rd|th)\s+Set$/.test(market_type)) {
    return true;
  }
  if (/^Point Winner\s+(?:[1-9]|1\d|20)\/(?:[1-9]|1\d|20)\/(?:[1-9]|1\d|20)$/.test(market_type)) {
    return true;
  }
  if (/^Game To Deuce\s+(?:[1-9]|1\d|20)\/(?:[1-9]|1\d|20)$/.test(market_type)) {
    return true;
  }
  if (/^Game To Deuce\s+(?:[1-9]|1\d|20)\/(?:[1-9]|1\d|20)\/(?:[1-9]|1\d|20)$/.test(market_type)) {
    return true;
  }
  return false;
}
var fixedNonFancyMarkets = [
  "OVER_UNDER_55",
  "OVER_UNDER_45",
  "OVER_UNDER_35",
  "OVER_UNDER_25",
  "OVER_UNDER_15",
  "OVER_UNDER_05",
  "OVER_UNDER_10",
  "2nd Period Winner",
  "1st Period Winner",
  "3rd Period Winner",
  "Both Teams To Score",
  "DRAW_NO_BET",
  "Draw No Bet",
  "HALF_TIME",
  "Correct Score 1st Set",
  "Correct Score 2nd Set",
  "Correct Score 3rd Set",
  "Correct Score 4th Set",
  "Correct Score 5th Set",
  "1st Set Winner Home/Away",
  "2nd Set Winner Home/Away",
  "3rd Set Winner Home/Away",
  "4th Set Winner Home/Away",
  "5th Set Winner Home/Away",
  "1st Set Winner",
  "2nd Set Winner",
  "3rd Set Winner",
  "4th Set Winner",
  "5th Set Winner",
  "6th Set Winner",
  "1st Half Winner",
  "2nd Half Winner",
  "3rd Half Winner",
  "4th Half Winner",
  "5th Half Winner",
  "6th Half Winner",
  "1st Quarter Winner",
  "2nd Quarter Winner",
  "3rd Quarter Winner",
  "4th Quarter Winner",
  "5th Quarter Winner",
  "6th Quarter Winner",
  "Tied Match",
  "TIED_MATCH"
];
function ensureLogDir() {
  try {
    fs.mkdirSync(LOG_DIR, { recursive: true });
    console.log("[Settlement] Log directory ensured:", LOG_DIR);
  } catch (e) {
    console.error("[Settlement] Failed to create log directory:", e.message);
  }
}
ensureLogDir();
function currentLogPath() {
  const d = /* @__PURE__ */ new Date(), yyyy = d.getFullYear(), mm = String(d.getMonth() + 1).padStart(2, "0"), dd = String(d.getDate()).padStart(2, "0");
  return path2.join(LOG_DIR, `${LOG_BASENAME}-${yyyy}-${mm}-${dd}.log`);
}
function writeLog(level, msg, ctx = {}) {
  const ctxStr = Object.keys(ctx).length ? " " + JSON.stringify(ctx) : "";
  const line = `[${(/* @__PURE__ */ new Date()).toISOString()}] [${level}] ${msg}${ctxStr}
`;
  if (level === "ERROR") console.error(msg, ctx);
  else console.log(msg, ctx);
  try {
    fs.appendFileSync(currentLogPath(), line, "utf8");
  } catch (e) {
    console.error("[Settlement] Log write failed:", e.message);
  }
}
var log = {
  info: (m, c = {}) => writeLog("INFO", m, c),
  warn: (m, c = {}) => writeLog("WARN", m, c),
  error: (m, c = {}) => writeLog("ERROR", m, c),
  debug: (m, c = {}) => {
    if (DEBUG) writeLog("DEBUG", m, c);
  }
};
var nowIso = () => (/* @__PURE__ */ new Date()).toISOString();
var lower = (s) => (s || "").toString().trim().toLowerCase();
var norm2 = (s) => (s || "").toString().toLowerCase().replace(/\s+/g, " ").replace(/[^\w\s]/g, "").trim();
var num2 = (x) => {
  const n = Number(x);
  return Number.isFinite(n) ? n : 0;
};
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function jitter(ms) {
  return Math.round(ms * (1 + Math.random() * 0.25));
}
function parseRetryAfter(h) {
  if (!h) return null;
  const n = Number(h);
  if (!Number.isNaN(n)) return Math.max(0, Math.round(n * 1e3));
  const d = Date.parse(h);
  return Number.isNaN(d) ? null : Math.max(0, d - Date.now());
}
var httpAgent = new http.Agent({ keepAlive: !RESULTS_DISABLE_KEEPALIVE, family: RESULTS_FORCE_IPV4 ? 4 : void 0 });
var httpsAgent = new https.Agent({ keepAlive: !RESULTS_DISABLE_KEEPALIVE, family: RESULTS_FORCE_IPV4 ? 4 : void 0 });
var ax2 = axios2.create({
  timeout: API_TIMEOUT_MS,
  httpAgent,
  httpsAgent,
  validateStatus: () => true,
  headers: {
    "Accept": "application/json",
    "User-Agent": USER_AGENT
  }
});
var lastApiCallAt = 0;
async function globalRateLimit() {
  const gap = RESULTS_RATE_LIMIT_MS > 0 ? RESULTS_RATE_LIMIT_MS : 0;
  const now = Date.now();
  const wait = Math.max(0, lastApiCallAt + gap - now);
  if (wait) await sleep(wait);
  lastApiCallAt = Date.now();
}
var AsyncQueue = class {
  constructor(max) {
    this.max = max;
    this.running = 0;
    this.q = [];
  }
  push(task) {
    return new Promise((res, rej) => {
      this.q.push({ task, res, rej });
      this._next();
    });
  }
  _next() {
    if (this.running >= this.max) return;
    const n = this.q.shift();
    if (!n) return;
    this.running++;
    n.task().then(n.res, n.rej).finally(() => {
      this.running--;
      this._next();
    });
  }
};
var apiQueue = new AsyncQueue(MAX_CONCURRENT_API);
var cachedGet = makeCachedGet({ ax: ax2, ttlMs: RESULT_CACHE_MS, rateLimit: globalRateLimit });
var getResultPayload = makePayloadGetter(cachedGet, `${AVRKHUB_BASE_URL2}/get_result`);
function buildPerAttemptConfig(attempt) {
  if (attempt >= 3) {
    return {
      httpAgent: new http.Agent({ keepAlive: false, family: 4 }),
      httpsAgent: new https.Agent({ keepAlive: false, family: 4 }),
      headers: { "Connection": "close" }
    };
  }
  return {};
}
function normalizeText(v) {
  if (!v) return "";
  return String(v).trim().toUpperCase().replace(/\s+/g, " ");
}
function relaxFancyName(v) {
  return normalizeText(v).replace(/[:.\-]+$/, "").replace(/\s+ADV$/, "").replace(/[:.\-]+$/, "").trim();
}
function normalizeMarketType(v) {
  if (!v) return "";
  return String(v).trim().toUpperCase();
}
async function fetchResultForEvent(eventid, eventName, marketId, marketName, sport_id, market_type, gameType, team_one, team_two, runners) {
  log.debug("[SettlementV2] fetchResultForEvent start", { eventid, eventName, marketId, marketName, market_type, gameType });
  const maxAttempts = RESULTS_MAX_FETCH_RETRIES || 6;
  const url = `${AVRKHUB_BASE_URL2}/get_result`;
  return apiQueue.push(async () => {
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        const res = await cachedGet(url, { gmid: eventid, sid: sport_id || "4" }, buildPerAttemptConfig(attempt));
        log.debug("[SettlementV2] fetchResultForEvent response", { eventid, attempt, status: res.status });
        if (res.status === 200) {
          const data = typeof res?.data === "string" ? JSON.parse(res.data) : res.data;
          const markets = Array.isArray(data?.markets) ? data.markets : [];
          let matchedMarket;
          const inputEventName = normalizeText(eventName);
          const inputMname = normalizeMarketType(market_type);
          const teamEventName = team_one && team_two ? normalizeText(`${team_one} v ${team_two}`) : "";
          if (teamEventName) {
            matchedMarket = markets.find(
              (m) => normalizeText(m?.ename) === teamEventName && normalizeMarketType(m?.mname) === inputMname
            );
          }
          if (!matchedMarket) {
            matchedMarket = markets.find(
              (m) => normalizeText(m?.ename) === inputEventName && normalizeMarketType(m?.mname) === inputMname
            );
          }
          if (!matchedMarket) {
            matchedMarket = markets.find(
              (m) => normalizeText(m?.marketName) === inputEventName && normalizeMarketType(m?.mname) === inputMname
            );
          }
          if (!matchedMarket) {
            matchedMarket = matchMarketByRunners(markets, runners, eventName, market_type);
            if (matchedMarket) {
              log.debug("[SettlementV2] matched via runners field", { eventid, mname: matchedMarket.mname });
            }
          }
          const declared = matchedMarket?.status === "SETTLE";
          const isVoid = matchedMarket?.status === "VOID";
          if (isVoid && matchedMarket) {
            matchedMarket = { ...matchedMarket, winnerName: "SUSPENDED", winnerId: null };
          }
          return {
            declared: declared || isVoid,
            items: matchedMarket ? [matchedMarket] : [],
            meta: { success: data?.success, source: "avrkhub", gmid: data?.gmid }
          };
        }
        if (res.status === 429 || res.status >= 500 && res.status <= 599) {
          const ra = parseRetryAfter(res.headers?.["retry-after"]);
          const wait = ra != null ? ra : jitter(RESULTS_RETRY_BASE_MS * Math.pow(2, attempt - 1));
          log.debug("[SettlementV2] retry backoff", { eventid, attempt, status: res.status, waitMs: wait });
          await sleep(wait);
          continue;
        }
        return { declared: false, items: [] };
      } catch (e) {
        const wait = jitter(RESULTS_RETRY_BASE_MS * Math.pow(2, attempt - 1));
        log.error("[SettlementV2] fetchResultForEvent error", { eventid, attempt, error: e.message, nextWaitMs: wait });
        await sleep(wait);
      }
    }
    log.debug("[SettlementV2] fetchResultForEvent exhausted", { eventid });
    return { declared: false, items: [] };
  });
}
async function fetchResultForEventFancy(eventid, eventName, marketId, selection_name, sport_id, market_type) {
  log.debug("[SettlementV2] fetchResultForEventFancy start", { eventid, eventName, marketId, selection_name, market_type });
  const maxAttempts = RESULTS_MAX_FETCH_RETRIES || 6;
  const url = `${AVRKHUB_BASE_URL2}/get_result`;
  return apiQueue.push(async () => {
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        const res = await cachedGet(url, { gmid: eventid, sid: sport_id || "4" }, buildPerAttemptConfig(attempt));
        log.debug("[SettlementV2] fetchResultForEventFancy response", { eventid, attempt, status: res.status });
        if (res.status === 200) {
          const data = typeof res?.data === "string" ? JSON.parse(res.data) : res.data;
          const markets = Array.isArray(data?.markets) ? data.markets : [];
          let matchedMarket;
          const inputMarketName = normalizeText(selection_name);
          const inputMarketType = normalizeMarketType(market_type);
          if (market_type === "TIED_MATCH" || market_type === "Tied Match") {
            matchedMarket = markets.find(
              (m) => normalizeMarketType(m?.mname) === inputMarketType
            );
          } else {
            matchedMarket = markets.find(
              (m) => normalizeText(m?.marketName) === inputMarketName && normalizeMarketType(m?.mname) === inputMarketType
            );
            if (!matchedMarket) {
              matchedMarket = markets.find(
                (m) => relaxFancyName(m?.marketName) === relaxFancyName(selection_name) && normalizeMarketType(m?.mname) === inputMarketType
              );
            }
            if (!matchedMarket) {
              matchedMarket = markets.find(
                (m) => m?.gtype === "CRICKETCASINO" && normalizeMarketType(m?.mname) === inputMarketType
              );
            }
            if (!matchedMarket && isLineMarket(market_type)) {
              matchedMarket = resolveLineMarketFromFeed(markets, market_type);
              if (matchedMarket) {
                log.info("[SettlementV2] line market derived", { eventid, market_type, status: matchedMarket.status, winnerId: matchedMarket.winnerId, from: matchedMarket.derivedFrom });
              }
            }
          }
          const declared = matchedMarket?.status === "SETTLE";
          const isVoid = matchedMarket?.status === "VOID";
          if (isVoid && matchedMarket) {
            matchedMarket = { ...matchedMarket, winnerName: "SUSPENDED", winnerId: "SUSPENDED" };
          }
          return {
            declared: declared || isVoid,
            items: matchedMarket ? [matchedMarket] : [],
            meta: { success: data?.success, source: "avrkhub", gmid: data?.gmid }
          };
        }
        if (res.status === 429 || res.status >= 500 && res.status <= 599) {
          const ra = parseRetryAfter(res.headers?.["retry-after"]);
          const wait = ra != null ? ra : jitter(RESULTS_RETRY_BASE_MS * Math.pow(2, attempt - 1));
          log.debug("[SettlementV2] fancy retry backoff", { eventid, attempt, status: res.status, waitMs: wait });
          await sleep(wait);
          continue;
        }
        return { declared: false, items: [] };
      } catch (e) {
        const wait = jitter(RESULTS_RETRY_BASE_MS * Math.pow(2, attempt - 1));
        log.error("[SettlementV2] fetchResultForEventFancy error", { eventid, attempt, error: e.message });
        await sleep(wait);
      }
    }
    log.debug("[SettlementV2] fetchResultForEventFancy exhausted", { eventid });
    return { declared: false, items: [] };
  });
}
async function fetchManualResult(eventid, match_id, game_type, market_type, selection_name) {
  log.debug("[Settlement] fetchManualResult start", { eventid, match_id, game_type, market_type, selection_name });
  try {
    const whereClause = {
      eventid: String(eventid),
      match_id: String(match_id),
      game_type: String(game_type),
      market_type: String(market_type)
    };
    const marketsforfancyCheck = [
      "1st Innings 6 Overs Line",
      "2nd Innings 6 Overs Line",
      "3rd Innings 6 Overs Line",
      "1st Innings 50 Overs Line",
      "2nd Innings 50 Overs Line",
      "3rd Innings 50 Overs Line",
      "1st Innings 40 Overs Line",
      "2nd Innings 40 Overs Line",
      "3rd Innings 40 Overs Line",
      "1st Innings 30 Overs Line",
      "2nd Innings 30 Overs Line",
      "3rd Innings 30 Overs Line",
      "1st Innings 20 Overs Line",
      "2nd Innings 20 Overs Line",
      "3rd Innings 20 Overs Line",
      "1st Innings 10 Overs Line",
      "2nd Innings 10 Overs Line",
      "3rd Innings 10 Overs Line",
      "Over By Over",
      "Ball By Ball",
      "Normal",
      "khado",
      "meter",
      "fancy1",
      "oddeven",
      "badlo"
    ];
    if (game_type === "FAN") {
      if (marketsforfancyCheck.includes(market_type) && selection_name) {
        whereClause.fancyName = selection_name;
      }
    }
    const manualRes = await manualresult_default.findOne({
      where: whereClause,
      order: [["created_at", "DESC"]]
    });
    if (!manualRes) {
      log.info("[Settlement] Manual result not found", whereClause);
      return { declared: false, items: [] };
    }
    log.debug("[Settlement] Manual result found", { id: manualRes.id, winnerName: manualRes.winnerName, winnerId: manualRes.winnerId });
    const item = {
      winnerName: manualRes.winnerName,
      winnerId: manualRes.winnerId,
      final_result: manualRes.winnerName
      // For MO/BM resolveMobmWinner uses final_result
    };
    return {
      declared: true,
      items: [item],
      meta: { source: "manual", manual_result_id: manualRes.id }
    };
  } catch (e) {
    log.error("[Settlement] fetchManualResult error", { eventid, error: e.message });
    return { declared: false, items: [] };
  }
}
var exposureGameTypeFor = (market_type) => exposureIdentity({ marketType: market_type, selectionName: null }).game_type;
async function getMatchExposures(user_id, match_id, market_type) {
  try {
    const exposures = await UserExposure_default.findAll({
      // A line market files its rows under game_type 'fancy2' (keyed by
      // market name, not runner) — see helper/lineMarket.js.
      where: { user_id: String(user_id), match_id: String(match_id), game_type: exposureGameTypeFor(market_type) },
      attributes: ["team_name", "exposure_amount"]
    });
    const map = {};
    for (const r of exposures) {
      map[(r.team_name || "").toString()] = Number(r.exposure_amount || 0);
    }
    return map;
  } catch (e) {
    log.error("[Settlement] getMatchExposures failed", { user_id, match_id, error: e.message });
    return {};
  }
}
async function clearExposuresForMatch(user_id, match_id, market_type, selections = null) {
  try {
    const where = {
      user_id: String(user_id),
      match_id: String(match_id),
      game_type: exposureGameTypeFor(market_type)
    };
    if (Array.isArray(selections) && selections.length && isPerSelectionMarket(market_type)) {
      where.team_name = { [Op2.in]: selections.flatMap(selectionExposureRows) };
    }
    await UserExposure_default.destroy({ where });
    log.debug("[Settlement] Exposures cleared", { user_id, match_id, market_type, selections });
  } catch (e) {
    log.error("[Settlement] clearExposuresForMatch failed", { user_id, match_id, error: e.message });
  }
}
async function recalcTotalExposure(user_id) {
  try {
    const exposureResults = await db_default.query(TOTAL_EXPOSURE_SQL, {
      replacements: { user_id },
      type: db_default.QueryTypes.SELECT
    });
    const total = parseFloat(exposureResults[0]?.total_exposure) || 0;
    await TotalExposure_default.upsert({ user_id: Number(user_id), total_exposure: total });
    log.info("[Settlement] TotalExposure recalculated", { user_id, total });
    const wallet = await Wallet_default.findOne({ where: { user_id: String(user_id) } });
    await emitBalanceUpdate(Number(user_id), {
      inr_balance: wallet?.inr_balance,
      exposure: total
    });
  } catch (e) {
    log.error("[Settlement] recalcTotalExposure failed", { user_id, error: e.message });
  }
}
async function closeBetsForMatch(user_id, match_id, onlyLine = false, resultStatus, job_id) {
  try {
    const whereClause = {
      user_id: String(user_id),
      match_id: String(match_id),
      job_id: String(job_id),
      status: { [Op2.in]: ["open", "manual"] }
    };
    if (onlyLine) {
      whereClause.bet_type = { [Op2.in]: ["yes", "no"] };
    }
    await SportsBet_default.update(
      { status: "closed", result_status: resultStatus, fixed: 1, updated_at: /* @__PURE__ */ new Date() },
      { where: whereClause }
    );
    log.debug("[Settlement] Bets closed", { user_id, match_id, onlyLine, resultStatus });
  } catch (e) {
    log.error("[Settlement] closeBetsForMatch failed", { user_id, match_id, error: e.message });
  }
}
function normalize(str) {
  return (str || "").toString().toLowerCase().replace(/\s+/g, " ").replace(/[^\w\s]/g, "").trim();
}
function splitWinnerNames(winnerStr) {
  return String(winnerStr || "").split(",").map((s) => s.trim()).filter(Boolean);
}
function matchNameToRunner(declared, runnerList) {
  const d = normalize(declared);
  if (!d) return null;
  for (const r of runnerList) {
    if (normalize(r) === d) return { name: r, reason: "exact match to runner" };
  }
  for (const r of runnerList) {
    const rn = normalize(r);
    if (rn && (d.startsWith(rn) || rn.startsWith(d) || d.includes(rn))) {
      return { name: r, reason: "fuzzy match to runner" };
    }
  }
  return null;
}
function resolveMobmWinner({ result, team_one, team_two, runners }) {
  console.log("inside resolveMobmWinner", result, team_one, team_two, result);
  let final_result = result.items[0].winnerName;
  const runnerList = splitRunnerString(runners);
  if (runnerList.length >= 3 && String(final_result || "").includes(",")) {
    const declaredNames = splitWinnerNames(final_result);
    if (declaredNames.length >= 2) {
      const resolved = [];
      for (const dn of declaredNames) {
        const hit = matchNameToRunner(dn, runnerList);
        if (!hit) {
          log.error("[Settlement] resolveMobmWinner: multi-winner name not a runner \u2014 requeue", { declared: dn, runners: runnerList });
          return { winnerName: "UNRESOLVED", winnerNames: [], reason: `multi-winner "${dn}" matched no runner` };
        }
        resolved.push(hit.name);
      }
      return {
        winnerName: resolved.join(","),
        winnerNames: resolved,
        reason: `multi-winner: ${declaredNames.length} names matched to runners`
      };
    }
  }
  console.log("final_result", final_result);
  const items = result?.items || [];
  const item = items[0];
  const resultStr = final_result || item?.final_result || "";
  const finalResult = normalize(resultStr);
  const teamOneNorm = normalize(team_one);
  const teamTwoNorm = normalize(team_two);
  if (["suspended", "cancelled"].includes(finalResult)) {
    log.debug("[Settlement] resolveMobmWinner: result is SUSPENDED or CANCELLED", { finalResult, resultStr });
    return { winnerName: "SUSPENDED", winnerNames: [], reason: `final_result is ${finalResult.toUpperCase()}` };
  }
  if (["draw", "tie", "abandoned", "no result"].some((term) => finalResult.includes(term))) {
    log.debug("[Settlement] resolveMobmWinner: draw or no result", { finalResult, team_one, team_two });
    return { winnerName: "The Draw", winnerNames: ["The Draw"], reason: "final_result indicates draw/tie/abandoned/no result" };
  }
  if (finalResult) {
    if (finalResult === teamOneNorm) {
      return { winnerName: team_one, winnerNames: [team_one], reason: "exact match to team_one" };
    }
    if (finalResult === teamTwoNorm) {
      return { winnerName: team_two, winnerNames: [team_two], reason: "exact match to team_two" };
    }
    if (runnerList.length >= 3) {
      for (const r of runnerList) {
        if (finalResult === normalize(r)) {
          return { winnerName: r, winnerNames: [r], reason: "exact match to runner" };
        }
      }
    }
    if (finalResult.startsWith(teamOneNorm)) {
      return { winnerName: team_one, winnerNames: [team_one], reason: "startsWith team_one" };
    }
    if (finalResult.startsWith(teamTwoNorm)) {
      return { winnerName: team_two, winnerNames: [team_two], reason: "startsWith team_two" };
    }
    if (finalResult.includes(teamOneNorm)) {
      return { winnerName: team_one, winnerNames: [team_one], reason: "contains team_one" };
    }
    if (finalResult.includes(teamTwoNorm)) {
      return { winnerName: team_two, winnerNames: [team_two], reason: "contains team_two" };
    }
    if (finalResult.substring(0, 3) === teamOneNorm.substring(0, 3)) {
      return { winnerName: team_one, winnerNames: [team_one], reason: "first 3 letters match team_one" };
    }
    if (finalResult.substring(0, 3) === teamTwoNorm.substring(0, 3)) {
      return { winnerName: team_two, winnerNames: [team_two], reason: "first 3 letters match team_two" };
    }
    if (runnerList.length >= 3) {
      const hit = matchNameToRunner(resultStr, runnerList);
      if (hit) {
        return { winnerName: hit.name, winnerNames: [hit.name], reason: hit.reason };
      }
    }
    log.debug("[Settlement] resolveMobmWinner: no string match", { finalResult, team_one, team_two, resultStr });
  }
  log.debug("[Settlement] resolveMobmWinner: ambiguous result", { finalResult, team_one, team_two });
  return { winnerName: "SUSPENDED", winnerNames: [], reason: "ambiguous; fallback SUSPENDED" };
}
function resolveFancyWinner({ result, fancy_name, selection_name, team_one, team_two, bet_type, market_type, odds, badlo = false }) {
  console.log("result", result);
  let final_result = result.winnerId;
  console.log("market_type", market_type);
  console.log("final_result", final_result);
  console.log("odds", odds);
  console.log("selection_name", selection_name);
  console.log("team_one", team_one);
  console.log("team_two", team_two);
  console.log("bet_type", bet_type);
  if (["suspended", "cancelled", "your_request_is_invalid"].includes(lower(final_result))) {
    log.debug("[Settlement] resolveFancyWinner: result is SUSPENDED or CANCELLED or request_is_invalid", { final_result });
    return { type: "suspended", reason: `final_result is ${final_result.toUpperCase()}` };
  }
  let winnerName = "";
  const lowerMarket = lower(fancy_name);
  team_one = lower(team_one);
  team_two = lower(team_two);
  const finalwinningdata = normalize(final_result || "");
  if (/^\s*\d+\s*NUMBER\s*$/i.test(String(result.winnerName || ""))) {
    const pick = normalize(selection_name || "");
    const outcome = normalize(result.winnerName || "");
    if (!pick) {
      log.info("[Settlement] cricketcasino: bet has no selection, requeue", { selection_name, winnerName: result.winnerName });
      return { type: "unknown", reason: "cricketcasino needs a selection to compare" };
    }
    const hit = pick === outcome;
    const backed = ["yes", "back"].includes(lower(bet_type));
    winnerName = (backed ? hit : !hit) ? "won" : "loss";
    return {
      type: "string",
      winnerName,
      reason: `cricketcasino: pick "${selection_name}" vs result "${result.winnerName}" -> ${winnerName}`
    };
  } else if (market_type === "oddeven") {
    const rawOddEven = final_result === null || final_result === void 0 || final_result === "" ? result.winnerName : final_result;
    const oddEvenToken = normalize(String(rawOddEven ?? ""));
    const resultIsOdd = oddEvenToken === "1" || oddEvenToken === "odd";
    const resultIsEven = oddEvenToken === "2" || oddEvenToken === "even";
    if (!resultIsOdd && !resultIsEven) {
      log.info("[Settlement] oddeven: unreadable result, requeue", {
        final_result,
        winnerName: result.winnerName,
        selection_name
      });
      return { type: "unknown", reason: `oddeven result "${rawOddEven}" is neither odd nor even` };
    }
    const betIsOddSide = ["yes", "back"].includes(lower(bet_type));
    winnerName = betIsOddSide === resultIsOdd ? "won" : "loss";
    return {
      type: "string",
      winnerName,
      reason: `oddeven: result=${resultIsOdd ? "ODD" : "EVEN"} bet=${bet_type}`
    };
  } else if (market_type === "fancy1") {
    const fancy1Raw = result.winnerName !== null && result.winnerName !== void 0 && String(result.winnerName).trim() !== "" ? result.winnerName : final_result;
    const fancy1Tok = lower(fancy1Raw);
    const fancy1Yes = fancy1Tok === "yes" || fancy1Tok === "1";
    const fancy1No = fancy1Tok === "no" || fancy1Tok === "2";
    if (!fancy1Yes && !fancy1No) {
      return { type: "unknown", reason: `fancy1 result "${fancy1Raw}" is neither yes nor no` };
    }
    const backedYes = ["yes", "back"].includes(lower(bet_type));
    winnerName = backedYes === fancy1Yes ? "won" : "loss";
    return { type: "string", winnerName, reason: `fancy1: result=${fancy1Yes ? "YES" : "NO"} bet=${bet_type}` };
  } else if (market_type === "TIED_MATCH" || market_type === "Tied Match") {
    const tmOutcome = String(final_result).trim() === "1" ? "YES" : "NO";
    const tmSel = String(selection_name || "").trim().toUpperCase();
    const tmBacked = bet_type === "yes" || bet_type === "YES";
    const tmSelWins = tmSel === tmOutcome;
    winnerName = (tmBacked ? tmSelWins : !tmSelWins) ? "won" : "loss";
    return { type: "string", winnerName, reason: "determined from final_result string for tied match" };
  } else if (market_type === "Over By Over") {
    if (bet_type === "yes") {
      if (final_result >= odds) {
        winnerName = "won";
      } else {
        winnerName = "loss";
      }
      return { type: "string", winnerName, reason: "determined from final_result string for over by over" };
    } else if (bet_type === "no") {
      if (final_result < odds) {
        winnerName = "won";
      } else {
        winnerName = "loss";
      }
      return { type: "string", winnerName, reason: "determined from final_result string for over by over" };
    }
  } else if (market_type === "2nd Period Winner" || market_type === "1st Period Winner" || market_type === "3rd Period Winner") {
    if (bet_type === "yes" && final_result === selection_name) {
      winnerName = "won";
    } else if (bet_type === "no" && final_result !== selection_name) {
      winnerName = "won";
    } else {
      winnerName = "loss";
    }
    return { type: "string", winnerName, reason: "determined from final_result string for tied match" };
  } else if (market_type === "khado" && /^\d+(\.\d+)?$/.test(String(fancy_name || "").trim())) {
    const band = Number(String(fancy_name).trim());
    const line = Number(odds);
    const runs = Number(final_result);
    if (!Number.isFinite(runs) || !Number.isFinite(line) || band <= 0) {
      log.warn("[Settlement] khado: non-numeric result/line, requeue", { final_result, odds, fancy_name });
      return { type: "unknown", reason: "khado band needs a numeric result, line and width" };
    }
    const inBand = runs >= line && runs <= line + band - 1;
    if (bet_type === "yes" || bet_type === "YES") {
      winnerName = inBand ? "won" : "loss";
    } else {
      winnerName = inBand ? "loss" : "won";
    }
    return { type: "string", winnerName, reason: `khado band ${line}-${line + band - 1} (width ${band}), result ${runs} -> ${winnerName}` };
  } else if (isBadloBet({ badlo })) {
    const runs = Number(final_result);
    const line = Number(odds);
    if (!Number.isFinite(runs) || !Number.isFinite(line)) {
      log.warn("[Settlement] badlo: non-numeric result/line, requeue", { final_result, odds });
      return { type: "unknown", reason: "badlo needs a numeric result and run" };
    }
    return { type: "badlo", runs, line, reason: `badlo run ${line}, result ${runs}` };
  } else if (isMeterMarket(market_type)) {
    const runs = Number(final_result);
    const line = Number(odds);
    if (!Number.isFinite(runs) || !Number.isFinite(line)) {
      log.warn("[Settlement] meter: non-numeric result/line, requeue", { final_result, odds });
      return { type: "unknown", reason: "meter needs a numeric result and line" };
    }
    return { type: "meter", runs, line, reason: `meter line ${line}, result ${runs}` };
  } else if (market_type === "1st Innings 6 Overs Line" || market_type === "2nd Innings 6 Overs Line" || market_type === "3rd Innings 6 Overs Line" || market_type === "1st Innings 10 Overs Line" || market_type === "2nd Innings 10 Overs Line" || market_type === "3rd Innings 10 Overs Line" || market_type === "1st Innings 15 Overs Line" || market_type === "2nd Innings 15 Overs Line" || market_type === "3rd Innings 15 Overs Line" || market_type === "1st Innings 20 Overs Line" || market_type === "2nd Innings 20 Overs Line" || market_type === "3rd Innings 20 Overs Line" || market_type === "1st Innings 25 Overs Line" || market_type === "2nd Innings 25 Overs Line" || market_type === "3rd Innings 25 Overs Line" || market_type === "1st Innings 30 Overs Line" || market_type === "2nd Innings 30 Overs Line" || market_type === "3rd Innings 30 Overs Line" || market_type === "1st Innings 35 Overs Line" || market_type === "2nd Innings 35 Overs Line" || market_type === "3rd Innings 35 Overs Line" || market_type === "1st Innings 40 Overs Line" || market_type === "2nd Innings 40 Overs Line" || market_type === "3rd Innings 40 Overs Line" || market_type === "1st Innings 45 Overs Line" || market_type === "2nd Innings 45 Overs Line" || market_type === "3rd Innings 45 Overs Line" || market_type === "1st Innings 50 Overs Line" || market_type === "2nd Innings 50 Overs Line" || market_type === "3rd Innings 50 Overs Line" || market_type === "Over By Over" || market_type === "Normal" || market_type === "Ball By Ball" || market_type === "khado" || isLineMarket(market_type)) {
    if (bet_type === "yes") {
      if (final_result >= odds) {
        winnerName = "won";
      } else {
        winnerName = "loss";
      }
      return { type: "string", winnerName, reason: "determined from final_result string for 1st innings 6 overs line" };
    } else if (bet_type === "no") {
      if (final_result < odds) {
        winnerName = "won";
      } else {
        winnerName = "loss";
      }
      return { type: "string", winnerName, reason: "determined from final_result string for 1st innings 6 overs line" };
    }
  } else if (market_type === "OVER_UNDER_35" || market_type === "OVER_UNDER_25" || market_type === "OVER_UNDER_15" || market_type === "OVER_UNDER_05") {
    const isUnderSelection = selection_name.includes("Under");
    const isOverSelection = selection_name.includes("Over");
    const isUnderResult = final_result === "Under";
    const isOverResult = final_result === "Over";
    let isWin = false;
    if (bet_type === "yes") {
      isWin = isUnderSelection && isUnderResult || isOverSelection && isOverResult;
    } else if (bet_type === "no") {
      isWin = isUnderSelection && isOverResult || isOverSelection && isUnderResult;
    }
    winnerName = isWin ? "won" : "loss";
    console.log("winnerName", winnerName);
    console.log("market_type", market_type);
    console.log("final_result", final_result);
    console.log("selection_name", selection_name);
    console.log("bet_type", bet_type);
    return {
      type: "string",
      winnerName,
      reason: "derived using over/under + yes/no logic"
    };
  } else if (market_type === "Next Goal 1.0" || market_type === "Next Goal 2.0" || market_type === "Next Goal 3.0" || market_type === "Next Goal 4.0" || market_type === "Next Goal 5.0" || market_type === "Next Goal 6.0" || market_type === "Next Goal 7.0" || market_type === "Next Goal 8.0" || market_type === "Next Goal 9.0" || market_type === "Next Goal 10.0") {
    if (final_result === selection_name && bet_type === "yes") {
      winnerName = "won";
    } else if (final_result !== selection_name && bet_type === "no") {
      winnerName = "won";
    } else {
      winnerName = "loss";
    }
    return { type: "string", winnerName, reason: "determined from final_result string for tied match" };
  } else if (market_type === "1st Innings 50 Overs Line" || market_type === "2nd Innings 50 Overs Line") {
    if (bet_type === "yes") {
      if (final_result >= odds) {
        winnerName = "won";
      } else {
        winnerName = "loss";
      }
      return { type: "string", winnerName, reason: "determined from final_result string for innings 50 overs line" };
    } else if (bet_type === "no") {
      if (final_result < odds) {
        winnerName = "won";
      } else {
        winnerName = "loss";
      }
      return { type: "string", winnerName, reason: "determined from final_result string for  innings 50 overs line" };
    }
  } else if (market_type === "Game To Deuce 1/1" || market_type === "Game To Deuce 1/2" || market_type === "Game To Deuce 1/3" || market_type === "Game To Deuce 1/4" || market_type === "Game To Deuce 2/1" || market_type === "Game To Deuce 2/2" || market_type === "Game To Deuce 2/3" || market_type === "Game To Deuce 2/4" || market_type === "Game To Deuce 3/1" || market_type === "Game To Deuce 3/2" || market_type === "Game To Deuce 3/3" || market_type === "Game To Deuce 3/4") {
    if (final_result === "0" && selection_name === "No" || selection_name === "NO") {
      winnerName = "won";
    } else if (final_result === "1" && selection_name === "Yes" || selection_name === "YES") {
      winnerName = "won";
    } else {
      winnerName = "loss";
    }
    return { type: "string", winnerName, reason: "determined from final_result string for game deuce" };
  } else if (market_type === "HALF_TIME" || market_type === "Match Time Result 70:00" || market_type === "Match Time Result 10:00" || market_type === "Match Time Result 20:00" || market_type === "Match Time Result 30:00" || market_type === "Match Time Result 40:00" || market_type === "Match Time Result 50:00" || market_type === "Match Time Result 60:00" || market_type === "Match Time Result 80:00" || market_type === "Match Time Result 90:00") {
    if (final_result === selection_name && bet_type === "yes") {
      winnerName = "won";
    } else if (final_result !== selection_name && bet_type === "no") {
      winnerName = "won";
    } else {
      winnerName = "loss";
    }
    return { type: "string", winnerName, reason: "determined from final_result string for half time" };
  } else if (market_type === "Both Teams To Score") {
    if (final_result === 0 && selection_name === "No" || selection_name === "NO") {
      winnerName = "won";
    } else if (final_result > 0 && selection_name === "Yes" || selection_name === "YES") {
      winnerName = "won";
    } else {
      winnerName = "loss";
    }
    return { type: "string", winnerName, reason: "determined from final_result string for both teams to score" };
  } else if (market_type === "Game Winner 1/2" || market_type === "Game Winner 1/3" || market_type === "Game Winner 1/4" || market_type === "Game Winner 2/2" || market_type === "Game Winner 2/3" || market_type === "Game Winner 2/4" || market_type === "Game Winner 3/2" || market_type === "Game Winner 3/3" || market_type === "Game Winner 3/4" || market_type === "Game Winner 2/7") {
    if (final_result === selection_name && bet_type === "yes") {
      winnerName = "won";
    } else if (final_result !== selection_name && bet_type === "no") {
      winnerName = "won";
    } else {
      winnerName = "loss";
    }
    return { type: "string", winnerName, reason: "determined from final_result string for tied match" };
  } else if (market_type === "1st Set Winner Home/Away" || market_type === "2nd Set Winner Home/Away" || market_type === "3rd Set Winner Home/Away" || market_type === "1st Set Race To 4.0" || market_type === "2nd Set Race To 4.0" || market_type === "3rd Set Race To 4.0") {
    if (final_result === selection_name && bet_type === "yes") {
      winnerName = "won";
    } else if (final_result !== selection_name && bet_type === "no") {
      winnerName = "won";
    } else {
      winnerName = "loss";
    }
    return { type: "string", winnerName, reason: "determined from final_result string for tied match" };
  } else if (market_type === "Correct Score" || market_type === "Correct Score 1st Set" || market_type === "Correct Score 2nd Set" || market_type === "Coreect Score 3rd Set") {
    if (bet_type === "yes" && final_result === 1) {
      winnerName = "won";
    } else if (bet_type === "no" && final_result === 0) {
      winnerName = "won";
    } else {
      winnerName = "loss";
    }
    return { type: "string", winnerName, reason: "determined from final_result string for tied match" };
  } else if (market_type === "Point Winner 1/3/1" || market_type === "Point Winner 1/2/1" || market_type === "Point Winner 1/1/1" || market_type === "Point Winner 2/3/1" || market_type === "Point Winner 2/2/1" || market_type === "Point Winner 2/1/1" || market_type === "Point Winner 3/3/1" || market_type === "Point Winner 3/2/1" || market_type === "Point Winner 3/1/1" || market_type === "Point Winner 1/2/1") {
    if (final_result === selection_name && bet_type === "yes") {
      winnerName = "won";
    } else if (final_result !== selection_name && bet_type === "no") {
      winnerName = "won";
    } else {
      winnerName = "loss";
    }
    return { type: "string", winnerName, reason: "determined from final_result string for tied match" };
  } else if (market_type === "Match Result/Both Teams to score") {
    if (final_result === 0 && selection_name === "No" || selection_name === "NO") {
      winnerName = "won";
    } else if (final_result > 0 && selection_name === "Yes" || selection_name === "YES") {
      winnerName = "won";
    } else {
      winnerName = "loss";
    }
    return { type: "string", winnerName, reason: "determined from final_result string for tied match" };
  }
}
async function initiateRefund({ job_id, user_id, eventid, match_id, bet, market_type }) {
  const { id: bet_id, stake_amount } = bet;
  const stake = num2(stake_amount);
  const meta = { api: { type: "result", eventid, match_id, status: "suspended" }, bet_id };
  try {
    const [refundClaimed] = await SportsBet_default.update(
      { status: "closed", result_status: "refund", fixed: 1, updated_at: /* @__PURE__ */ new Date() },
      { where: { id: bet_id, status: { [Op2.in]: ["open", "manual"] } } }
    );
    if (!refundClaimed) {
      log.warn("[Settlement] refund skipped \u2014 bet already closed", { bet_id, user_id, job_id });
      return;
    }
    const wallet = await Wallet_default.findOne({ where: { user_id } });
    if (!wallet) {
      log.error("[Settlement] No wallet found for user", { bet_id, user_id });
      throw new Error(`No wallet found for user_id=${user_id}`);
    }
    const placementEntries = await CreditsLedger_default.findAll({
      where: {
        bet_id,
        user_id: String(user_id),
        reason: { [Op2.in]: ["bet_placed", "exposure_release"] }
      },
      attributes: ["amount", "reason"],
      raw: true
    });
    let refundAmount;
    let refundSource;
    if (placementEntries.length > 0) {
      const placementSum = placementEntries.reduce(
        (s, e) => s + (parseFloat(e.amount) || 0),
        0
      );
      refundAmount = -placementSum;
      refundSource = `placement_sum=${placementSum.toFixed(2)} (entries=${placementEntries.length})`;
    } else {
      log.warn("[Settlement] Refund: no placement entries for bet \u2014 falling back to stake", { bet_id, user_id, stake });
      refundAmount = stake;
      refundSource = `legacy_fallback_stake=${stake}`;
    }
    const desc = buildSettlementDesc(bet, market_type, "SUSPENDED");
    const refundWrite = await applyWalletDeltaWithLedger(user_id, {
      cashDelta: refundAmount,
      ledger: {
        user_id: String(user_id),
        currency: "INR",
        amount: refundAmount,
        reason: "refund",
        description: desc,
        eventid: String(eventid),
        job_id: String(job_id || ""),
        match_id: match_id ? String(match_id) : null,
        meta: { ...meta || {}, refund_source: refundSource, placement_entries: placementEntries.length },
        market_type,
        bet_id,
        netamount: refundAmount,
        category: "SPORTS"
      }
    });
    if (!refundWrite) throw new Error(`No wallet found for user_id=${user_id}`);
    const newBalance = refundWrite.newCash;
    const cashBefore = newBalance - Number(refundAmount);
    log.info(`[Settlement] Refund applied`, { bet_id, user_id, refundAmount, balance: newBalance, refundSource });
    await SportsBet_default.update(
      { status: "closed", result_status: "refund", fixed: 1, updated_at: /* @__PURE__ */ new Date() },
      { where: { id: bet_id, job_id: String(job_id), status: { [Op2.in]: ["open", "manual"] } } }
    );
    log.debug("[Settlement] Bet marked as refunded", { bet_id, user_id });
    try {
      await recordVoidAudit({
        voidGroupId: newVoidGroupId(),
        voidType: VOID_TYPES.FEED_SUSPENDED,
        bets: [bet],
        representativeBetId: bet_id,
        before: { status: "open", resultStatus: "pending", cash: cashBefore },
        after: { status: "closed", resultStatus: "refund", cash: newBalance },
        refundAmount,
        context: {
          actor: "settlement-worker",
          actor_role: "SYSTEM",
          note: `provider declared SUSPENDED \u2014 ${refundSource}`
        }
      });
    } catch (auditErr) {
      log.error("[Settlement] void audit write failed", { bet_id, user_id, error: auditErr.message });
    }
    await writeReport({
      job_id,
      bet_id,
      user_id,
      eventid,
      match_id,
      game_type: String(bet.game_type || "MO").toUpperCase(),
      market_type,
      selection_name: bet.selection_name,
      resolved_winner: null,
      resolved_team: null,
      credit_amount: stake,
      exposures_map: {},
      api_snapshot: { status: "refund due to SUSPENDED" },
      bet_id,
      user_id,
      eventid,
      match_id,
      decision_path: ["refund due to SUSPENDED status", desc]
    });
  } catch (e) {
    log.error("[Settlement] Refund failed", { bet_id, user_id, error: e.message });
    await writeReport({
      job_id,
      bet_id,
      user_id,
      eventid,
      match_id,
      game_type: String(bet.game_type || "MO").toUpperCase(),
      market_type,
      selection_name: bet.selection_name,
      resolved_winner: null,
      resolved_team: null,
      credit_amount: stake,
      exposures_map: {},
      api_snapshot: { status: "refund failed SUSPENDED", bet_id, user_id, eventid, match_id },
      decision_path: ["[Settlement] Refund failed", { bet_id, user_id, error: e.message }]
    });
    throw e;
  }
}
function normalizeOdds(odds) {
  let newodds;
  if (odds > 100) {
    newodds = odds / 100 + 1;
  } else if (odds < 100) {
    newodds = 1 + odds / 100;
  } else {
    newodds = 2;
  }
  return Math.floor(newodds * 100) / 100;
}
function getOdds(b) {
  const raw = b.odds ?? b.price ?? b.rate ?? b.odd ?? 0;
  const o = Number(raw);
  const gameType = String(b.game_type || "").toUpperCase();
  if (gameType === "BM") return normalizeOdds(o);
  return Number.isFinite(o) ? o : 0;
}
function getStake(b) {
  return num2(b.stake_amount ?? b.stake ?? b.amount ?? b.stakeValue ?? b.size);
}
function isBack(b) {
  const t = lower(b.bet_type);
  return t === "back" || t === "yes";
}
function isLay(b) {
  const t = lower(b.bet_type);
  return t === "lay" || t === "no";
}
function isWinningSelection(bet, winners) {
  const sel = norm2(bet.selection_name || "");
  const list = Array.isArray(winners) ? winners : [winners];
  return list.some((w) => norm2(w) === sel);
}
function moBmBetWinCredit(bet, winners) {
  const selIsWinner = isWinningSelection(bet, winners);
  const stake = getStake(bet);
  const odds = getOdds(bet);
  if (isBack(bet)) return selIsWinner ? Math.max(0, (odds - 1) * stake) : 0;
  if (isLay(bet)) return selIsWinner ? 0 : Math.max(0, stake);
  return 0;
}
function moBmBetPnl(bet, winners) {
  const selIsWinner = isWinningSelection(bet, winners);
  const stake = getStake(bet);
  const odds = getOdds(bet);
  if (isBack(bet)) return selIsWinner ? (odds - 1) * stake : -stake;
  if (isLay(bet)) return selIsWinner ? -((odds - 1) * stake) : stake;
  return 0;
}
function normalizeExposure(value) {
  return Math.abs(value);
}
async function writeReport(r) {
  try {
    const [report, created] = await SportsSettlementReport_default.findOrCreate({
      where: { bet_id: r.bet_id },
      defaults: {
        job_id: r.job_id,
        bet_id: r.bet_id,
        user_id: r.user_id,
        eventid: r.eventid,
        match_id: r.match_id,
        game_type: r.game_type,
        market_type: r.market_type,
        fancy_name: r.fancy_name || null,
        selection_name: r.selection_name || null,
        user_selection_yn: r.user_selection_yn || null,
        resolved_winner: r.resolved_winner || null,
        resolved_team: r.resolved_team || null,
        actual_numeric: r.actual_numeric != null ? r.actual_numeric : null,
        rule_op: r.rule_op || null,
        rule_threshold: r.rule_threshold != null ? r.rule_threshold : null,
        credit_amount: Number(r.credit_amount || 0),
        exposures_map: r.exposures_map || {},
        api_snapshot: r.api_snapshot || {},
        decision_path: r.decision_path || [],
        created_at: /* @__PURE__ */ new Date()
      }
    });
    if (!created) {
      log.debug("[Settlement] Report already exists, skipping", { bet_id: r.bet_id });
    }
  } catch (e) {
    log.error("[Settlement] writeReport failed", { bet_id: r.bet_id, error: e.message });
  }
}
async function processMobmGroup({ job_id, user_id, eventid, match_id, bets, eventName, marketId, marketName, market_type, game_type, team_one, team_two, sport_id }) {
  log.info("[Settlement] Processing MO/BM group", { user_id, eventid, match_id, bets: bets.length });
  let result;
  const any = bets[0] || {};
  if (any.status === "manual") {
    result = await fetchManualResult(eventid, match_id, game_type, market_type);
  } else {
    result = await fetchResultForEvent(eventid, eventName, marketId, marketName, sport_id, market_type, game_type, team_one, team_two, any.runners);
  }
  if (!result.declared) {
    const fallback = await resolveH2HBookmakerFallback({
      eventid,
      sport_id: any.sport_id || sport_id,
      market_type,
      team_one,
      team_two,
      logger: log,
      getPayload: getResultPayload
    });
    if (fallback?.declared) {
      log.info("[Settlement] H2H bookmaker fallback applied", {
        user_id,
        match_id,
        eventid,
        ...fallback.meta
      });
      result = fallback;
    }
  }
  if (!result.declared) {
    log.info("[Settlement] MO/BM group not declared, requeue", { user_id, match_id, eventid });
    return { settled: false, requeue: true };
  }
  const { winnerName, winnerNames, reason } = resolveMobmWinner({ result, team_one, team_two, runners: any.runners });
  const winners = winnerNames && winnerNames.length ? winnerNames : [winnerName];
  const isMultiWinner = winners.length >= 2;
  log.info(`[Settlement] MO/BM WINNER NAME or STATUS="${winnerName}" (${reason})`, { match_id, eventid, bets: bets.length });
  console.log("step donw 22");
  if (winnerName === "UNRESOLVED") {
    log.error("[Settlement] MO/BM winner names unresolved \u2014 requeue", { user_id, match_id, eventid, reason });
    return { settled: false, requeue: true };
  }
  if (winnerName.toUpperCase() === "SUSPENDED") {
    log.info("[Settlement] MO/BM group SUSPENDED, initiating refunds", { user_id, match_id, eventid });
    for (const bet of bets) {
      await initiateRefund({ job_id, user_id, eventid, match_id, bet, market_type });
    }
    await clearExposuresForMatch(user_id, match_id, market_type);
    return { settled: true, requeue: false };
  }
  const preCredit = bets.reduce((sum, b) => sum + moBmBetWinCredit(b, winners), 0);
  const [claimedCount] = await SportsBet_default.update(
    { status: "closed", result_status: preCredit > 0 ? "won" : "loss", fixed: 1, updated_at: /* @__PURE__ */ new Date() },
    { where: { id: { [Op2.in]: bets.map((b) => b.id) }, status: { [Op2.in]: ["open", "manual"] } } }
  );
  if (!claimedCount) {
    log.warn("[Settlement] MO/BM bets already settled \u2014 duplicate pass skipped", { user_id, match_id, eventid, job_id, bet_ids: bets.map((b) => b.id) });
    return { settled: true, requeue: false };
  }
  let totalCredit = 0;
  console.log("step donw exposure");
  console.log("market_type", market_type);
  const exposuresMap = await getMatchExposures(user_id, match_id, market_type);
  console.log("exposuresMap", exposuresMap);
  const user = await User_default.findByPk(user_id);
  const firstBet = bets[0] || {};
  const rawExposures = await getMatchExposures(user_id, match_id, market_type);
  const marketExposures = {};
  for (const [k, v] of Object.entries(rawExposures)) {
    marketExposures[k.trim()] = v;
  }
  const t1 = (firstBet.team_one || "").trim();
  const t2 = (firstBet.team_two || "").trim();
  const mTeam1 = marketExposures[t1] || 0;
  const mTeam2 = marketExposures[t2] || 0;
  const mDraw = marketExposures["The Draw"] || marketExposures["Draw"] || 0;
  const mNegExposures = Object.values(marketExposures).filter((x) => x < 0);
  const mMostNeg = mNegExposures.length > 0 ? Math.min(...mNegExposures) : 0;
  const winTrimmed = (winnerName || "").trim();
  let winnerExposure = 0;
  if (isMultiWinner) {
    const allMarketBets = await SportsBet_default.findAll({
      where: { user_id: String(user_id), match_id, market_type, status: { [Op2.in]: ["open", "manual"] } }
    });
    const legs = allMarketBets.length ? allMarketBets : bets;
    winnerExposure = legs.reduce((sum, leg) => sum + moBmBetPnl(leg, winners), 0);
    log.info("[Settlement] multi-winner market valuation", { user_id, match_id, winners, legs: legs.length, winnerExposure });
  } else if (t1 === winTrimmed) winnerExposure = mTeam1;
  else if (t2 === winTrimmed) winnerExposure = mTeam2;
  else if (winTrimmed === "The Draw" || winTrimmed === "Draw") winnerExposure = mDraw;
  else {
    winnerExposure = marketExposures[winTrimmed] || 0;
  }
  let marketFinalCredit = 0;
  if (winnerName === "refund") {
    marketFinalCredit = normalizeExposure(mMostNeg);
  } else {
    marketFinalCredit = normalizeExposure(mMostNeg) + winnerExposure;
  }
  if (marketFinalCredit < 0) marketFinalCredit = 0;
  const marketNetAmount = winnerName === "refund" ? 0 : winnerExposure;
  console.log("[Settlement] MARKET-LEVEL:", { mTeam1, mTeam2, mDraw, mMostNeg, winnerExposure, marketFinalCredit, marketNetAmount });
  const allFixed = bets.every((b) => b.fixed == 1);
  for (const bet of bets) {
    let credit = moBmBetWinCredit(bet, winners);
    const stake = getStake(bet);
    const selIsWinner = isWinningSelection(bet, winners);
    totalCredit += credit;
    const rawOdds = getOdds(bet);
    const normalizedOddsValue = normalizeOdds(rawOdds);
    const desc = `MO/BM per-bet; winner="${winnerName}"; bet_type=${bet.bet_type}; selection="${bet.selection_name}"; odds=${rawOdds}; normalized_odds=${normalizedOddsValue}; stake=${stake}; credit=${credit}`;
    const meta = { api: { type: "result", eventid, marketId, marketName, status: result.declared }, winnerName, reason, bet_id: bet.id, odds: rawOdds, normalized_odds: normalizedOddsValue };
    if (bet.fixed == 0) {
      let totalbets = await SportsBet_default.count({ where: { eventid, match_id, game_type: "MO", user_id } });
      let drawex = firstBet.counts == 3 ? mDraw : 0;
      await MarketWin_default.create({
        totalbets,
        matchid: match_id,
        eventid,
        team1ex: mTeam1,
        team2ex: mTeam2,
        drawex,
        winteam: winnerName,
        matchname: `${bet.team_one} vs ${bet.team_two}`,
        payout: marketFinalCredit,
        user_id,
        created_at: /* @__PURE__ */ new Date()
      });
    }
    let cost = 0;
    if (isBack(bet) || bet.bet_type === "Yes" || bet.bet_type === "yes") {
      cost = stake;
    } else if (isLay(bet) || bet.bet_type === "No" || bet.bet_type === "no") {
      cost = (rawOdds - 1) * stake;
    }
    cost = cost > 0 ? cost : 0;
    let profit = 0;
    let loss = 0;
    let netamount = 0;
    if (credit > 0) {
      profit = credit;
      netamount = credit;
    } else {
      if (isBack(bet) || bet.bet_type === "Yes" || bet.bet_type === "yes") {
        loss = -stake;
        netamount = -stake;
      } else if (isLay(bet) || bet.bet_type === "No" || bet.bet_type === "no") {
        loss = -bet.liability;
        netamount = -bet.liability;
      }
    }
    console.log("per-bet netamount", netamount, "credit", credit);
    console.log("per-bet profit", profit, "loss", loss);
    await User_default.increment(
      {
        net_win: profit,
        net_loss: loss,
        profit: netamount
      },
      {
        where: { user_id }
      }
    );
    await writeReport({
      job_id,
      bet_id: bet.id,
      user_id,
      eventid,
      match_id,
      game_type: String(bet.game_type || "MO").toUpperCase(),
      market_type,
      selection_name: bet.selection_name,
      resolved_winner: winnerName || null,
      resolved_team: winnerName || null,
      credit_amount: marketFinalCredit,
      exposures_map: exposuresMap,
      api_snapshot: result.meta,
      decision_path: [reason, desc]
    });
  }
  let moSettlementLedgerRow = null;
  let moSettlementDesc = null;
  if (!allFixed && (marketFinalCredit !== 0 || marketNetAmount !== 0)) {
    try {
      moSettlementDesc = buildSettlementDesc(firstBet, market_type, winnerName);
      const moWrite = await applyWalletDeltaWithLedger(user_id, {
        cashDelta: Number(marketFinalCredit),
        inrDelta: Number(marketNetAmount),
        ledger: {
          user_id: String(user_id),
          currency: "INR",
          amount: marketFinalCredit,
          reason: "settlement",
          description: moSettlementDesc,
          netamount: marketFinalCredit,
          market_type: market_type || null,
          sport_id: firstBet.sport_id || null,
          eventid: eventid || null,
          match_id: match_id || null,
          job_id: job_id || null,
          // Pivot on marketNetAmount (actual market P/L). Using totalCredit
          // misclassified wins as losses when stake-locked credits summed to 0
          // but the net outcome was positive (e.g. successful cashout).
          profit: marketNetAmount > 0 ? marketNetAmount : 0,
          loss: marketNetAmount < 0 ? marketNetAmount : null,
          bet_id: firstBet.id || null,
          category: "SPORTS"
        }
      });
      if (moWrite) {
        moSettlementLedgerRow = moWrite.ledgerRow;
        console.log("[Settlement] WALLET UPDATE (ONCE):", { marketFinalCredit, newCash: moWrite.newCash, marketNetAmount, newInr: moWrite.newInr });
      } else {
        log.error("[Settlement] No wallet found for user", { user_id });
      }
    } catch (err) {
      log.error("[Settlement] Error updating wallet", { user_id, error: err.message });
    }
  }
  const resultStatus = totalCredit > 0 ? "won" : "loss";
  await SportsBet_default.update({ fixed: 1, updated_at: /* @__PURE__ */ new Date() }, { where: { match_id, user_id, game_type, market_type } });
  await closeBetsForMatch(user_id, match_id, false, resultStatus, job_id);
  await clearExposuresForMatch(user_id, match_id, market_type);
  if (!allFixed && Number(marketNetAmount) !== 0) {
    try {
      const pointRes = await walletService_default.updateAllPointHierarchy(Number(firstBet.id), POINT_CATEGORY.SPORTS);
      if (!pointRes.success) log.error("[Settlement] all_point update failed", { user_id, error: pointRes.error });
    } catch (err) {
      log.error("[Settlement] all_point update error", { user_id, error: err.message });
    }
  }
  if (moSettlementLedgerRow && Number(marketNetAmount) > 0) {
    await applyWinCommission({
      user_id,
      bet: firstBet,
      netWin: marketNetAmount,
      settlementLedgerId: moSettlementLedgerRow.id,
      description: moSettlementDesc,
      market_type,
      eventid,
      match_id,
      job_id,
      log
    });
  }
  return { settled: true, requeue: false };
}
async function processnonfancy({ job_id, user_id, eventid, match_id, bet, eventName, marketId, marketName, market_type, game_type, team_one, team_two, result }) {
  console.log("result", result);
  console.log("entered nonfancysettlement");
  let winnerName, reason;
  if (bigRunnerSessionMarket.test(market_type || "")) {
    const declared = (result?.items?.[0]?.winnerName ?? "").toString().trim();
    if (!declared) {
      log.info("[Settlement] Big-runner session market declared without winnerName, requeue", { match_id, eventid, market_type });
      return { settled: false, requeue: true };
    }
    if (["suspended", "cancelled", "your_request_is_invalid"].includes(lower(declared))) {
      winnerName = "SUSPENDED";
      reason = `declared result is ${declared}`;
    } else {
      winnerName = declared;
      reason = "winnerName taken directly from declared result (big-runner session market)";
    }
  } else {
    ({ winnerName, reason } = resolveMobmWinner({ result, team_one, team_two, final_result: result.final_result }));
  }
  log.info(`[Settlement] FAN/non-FAN WINNER NAME or STATUS="${winnerName}" (${reason})`, { match_id, eventid, marketId, marketName });
  console.log("step donw fan -non fan 22");
  if (winnerName.toUpperCase() === "SUSPENDED") {
    log.info("[Settlement] MO/BM group SUSPENDED, initiating refunds", { user_id, match_id, eventid });
    await initiateRefund({ job_id, user_id, eventid, match_id, bet, market_type });
    await clearExposuresForMatch(user_id, match_id, market_type);
    return { settled: true, requeue: false };
  }
  const nfPreCredit = moBmBetWinCredit(bet, winnerName);
  const [nfClaimed] = await SportsBet_default.update(
    { status: "closed", result_status: nfPreCredit > 0 ? "won" : "loss", fixed: 1, updated_at: /* @__PURE__ */ new Date() },
    { where: { id: bet.id, status: { [Op2.in]: ["open", "manual"] } } }
  );
  if (!nfClaimed) {
    log.warn("[Settlement] non-fancy bet already settled \u2014 duplicate pass skipped", { user_id, match_id, eventid, job_id, bet_id: bet.id });
    return { settled: true, requeue: false };
  }
  console.log("step donw exposure");
  console.log("market_type", market_type);
  const exposuresMap = await getMatchExposures(user_id, match_id, market_type);
  console.log("exposuresMap", exposuresMap);
  const user = await User_default.findByPk(user_id);
  const rawOldExposures = await getMatchExposures(user_id, match_id, market_type);
  const oldExposures = {};
  for (const [k, v] of Object.entries(rawOldExposures)) {
    oldExposures[k.trim()] = v;
  }
  const bt1 = (bet.team_one || "").trim();
  const bt2 = (bet.team_two || "").trim();
  const team1 = oldExposures[bt1] || 0;
  const team2 = oldExposures[bt2] || 0;
  const draw = oldExposures["The Draw"] || oldExposures["Draw"] || 0;
  const negExposures = Object.values(oldExposures).filter((x) => x < 0);
  const mostNeg = negExposures.length > 0 ? Math.min(...negExposures) : 0;
  const nfWinTrimmed = (winnerName || "").trim();
  let winnerExposure = 0;
  if (bt1 === nfWinTrimmed) winnerExposure = team1;
  else if (bt2 === nfWinTrimmed) winnerExposure = team2;
  else if (nfWinTrimmed === "The Draw" || nfWinTrimmed === "Draw") winnerExposure = draw;
  else {
    winnerExposure = oldExposures[nfWinTrimmed] || 0;
    if (!(nfWinTrimmed in oldExposures)) {
      const key = Object.keys(oldExposures).find((k) => norm2(k) === norm2(nfWinTrimmed));
      if (key) winnerExposure = oldExposures[key];
    }
  }
  let finalcredit = 0;
  if (winnerName === "refund") {
    finalcredit = normalizeExposure(mostNeg);
  } else {
    finalcredit = normalizeExposure(mostNeg) + winnerExposure;
  }
  if (finalcredit < 0) finalcredit = 0;
  const marketNetAmount = winnerName === "refund" ? 0 : winnerExposure;
  console.log("[Settlement] NON-FANCY MARKET-LEVEL:", { team1, team2, draw, mostNeg, winnerExposure, finalcredit, marketNetAmount });
  let credit = moBmBetWinCredit(bet, winnerName);
  const stake = getStake(bet);
  const selIsWinner = norm2(bet.selection_name) === norm2(winnerName);
  let totalCredit = credit;
  const rawOdds = getOdds(bet);
  const normalizedOddsValue = normalizeOdds(rawOdds);
  const desc = `FAN per-bet; winner="${winnerName}"; bet_type=${bet.bet_type}; selection="${bet.selection_name}"; odds=${rawOdds}; normalized_odds=${normalizedOddsValue}; stake=${stake}; credit=${credit}`;
  const meta = { api: { type: "result", eventid, marketId, marketName, status: result.declared }, winnerName, reason, bet_id: bet.id, odds: rawOdds, normalized_odds: normalizedOddsValue };
  if (bet.fixed == 0) {
    let totalbets = await SportsBet_default.count({ where: { eventid, match_id, game_type: "MO", user_id } });
    let drawex = bet.counts == 3 ? draw : 0;
    await MarketWin_default.create({
      totalbets,
      matchid: match_id,
      eventid,
      team1ex: team1,
      team2ex: team2,
      drawex,
      winteam: winnerName,
      matchname: `${bet.team_one} vs ${bet.team_two}`,
      payout: finalcredit,
      user_id,
      created_at: /* @__PURE__ */ new Date()
    });
  }
  let cost = 0;
  if (isBack(bet)) {
    cost = stake;
  } else if (isLay(bet)) {
    cost = (rawOdds - 1) * stake;
  }
  cost = cost > 0 ? cost : 0;
  let profit = 0;
  let loss = 0;
  let netamount = 0;
  if (credit > 0) {
    profit = credit;
    netamount = credit;
  } else {
    if (isBack(bet) || bet.bet_type === "Yes" || bet.bet_type === "yes") {
      loss = -stake;
      netamount = -stake;
    } else if (isLay(bet) || bet.bet_type === "No" || bet.bet_type === "no") {
      loss = -bet.liability;
      netamount = -bet.liability;
    }
  }
  console.log("netamount", netamount);
  console.log("profit", profit);
  console.log("loss", loss);
  let nfSettlementLedgerRow = null;
  let nfSettlementDesc = null;
  if (bet.fixed != 1 && (finalcredit !== 0 || marketNetAmount !== 0)) {
    try {
      nfSettlementDesc = buildSettlementDesc(bet, market_type, winnerName);
      const nfWrite = await applyWalletDeltaWithLedger(user_id, {
        cashDelta: Number(finalcredit),
        inrDelta: Number(marketNetAmount),
        ledger: {
          user_id: String(user_id),
          currency: "INR",
          amount: finalcredit,
          reason: "settlement",
          description: nfSettlementDesc,
          netamount: finalcredit,
          market_type: market_type || null,
          sport_id: bet.sport_id || null,
          eventid: eventid || null,
          match_id: match_id || null,
          job_id: job_id || null,
          profit: profit || 0,
          loss: loss || null,
          bet_id: bet.id || null,
          category: "SPORTS"
        }
      });
      if (nfWrite) {
        nfSettlementLedgerRow = nfWrite.ledgerRow;
        console.log("[Settlement] NON-FANCY WALLET UPDATE:", { finalcredit, newCash: nfWrite.newCash, marketNetAmount, newInr: nfWrite.newInr });
      } else {
        log.error("[Settlement] No wallet found for user", { user_id });
      }
    } catch (err) {
      log.error("[Settlement] Error updating wallet", { user_id, error: err.message });
    }
  }
  await User_default.increment(
    {
      net_win: profit,
      net_loss: loss,
      profit: netamount
    },
    {
      where: { user_id }
    }
  );
  await writeReport({
    job_id,
    bet_id: bet.id,
    user_id,
    eventid,
    match_id,
    game_type: String(bet.game_type || "MO").toUpperCase(),
    market_type,
    selection_name: bet.selection_name,
    resolved_winner: winnerName || null,
    resolved_team: winnerName || null,
    credit_amount: finalcredit,
    exposures_map: exposuresMap,
    api_snapshot: result.meta,
    decision_path: [reason, desc]
  });
  const resultStatus = totalCredit > 0 ? "won" : "loss";
  await SportsBet_default.update({ fixed: 1, updated_at: /* @__PURE__ */ new Date() }, { where: { match_id, user_id, game_type, market_type } });
  await closeBetsForMatch(user_id, match_id, false, resultStatus, job_id);
  await clearExposuresForMatch(user_id, match_id, market_type);
  if (bet.fixed != 1 && Number(marketNetAmount) !== 0) {
    try {
      const pointRes = await walletService_default.updateAllPointHierarchy(Number(bet.id), POINT_CATEGORY.SPORTS);
      if (!pointRes.success) log.error("[Settlement] all_point update failed", { user_id, error: pointRes.error });
    } catch (err) {
      log.error("[Settlement] all_point update error", { user_id, error: err.message });
    }
  }
  if (nfSettlementLedgerRow && Number(marketNetAmount) > 0) {
    await applyWinCommission({
      user_id,
      bet,
      netWin: marketNetAmount,
      settlementLedgerId: nfSettlementLedgerRow.id,
      description: nfSettlementDesc,
      market_type,
      eventid,
      match_id,
      job_id,
      log
    });
  }
  return { settled: true, requeue: false };
}
async function processFanBet({ job_id, bet, eventName, marketId, marketName }) {
  const { id: bet_id, user_id, eventid, match_id, fancy_name, selection_name, bet_type, game_type, odds, stake_amount, market_type, team_one, team_two, runners, size, sport_id, status } = bet;
  log.info("[Settlement] Processing FAN bet", { bet_id, user_id, eventid, fancy_name, match_id, bet_type, sport_id, market_type, status });
  let result;
  if (status === "manual") {
    result = await fetchManualResult(eventid, match_id, game_type, market_type, selection_name);
  } else {
    result = await fetchResultForEventFancy(eventid, eventName, marketId, selection_name, sport_id, market_type);
  }
  log.debug("[Settlement] FAN result", { bet_id, eventid, declared: result.declared });
  console.log(" FAN result'", { bet_id, eventid, declared: result.declared });
  const user = await User_default.findByPk(user_id);
  const exposuresMap = await getMatchExposures(user_id, match_id, market_type);
  if (!result.declared) {
    log.info("[Settlement] FAN bet not declared, requeue", { bet_id, user_id, eventid });
    return { settled: false, requeue: true };
  }
  console.log("done1");
  console.log("team_one", team_one);
  console.log("team_two", team_two);
  log.info("[Settlement] calling resolveFancyWinner with data : ", { result, fancy_name, final_result: result.items, selection_name, team_one, team_two, bet_type });
  if (isNonFancyMarket(market_type)) {
    return await processnonfancy({ job_id, user_id, eventid, match_id, bet, eventName, marketId, marketName, market_type, game_type, team_one, team_two, result });
  } else {
    const resolve = resolveFancyWinner({ result: result.items[0], fancy_name, selection_name, team_one, team_two, bet_type, market_type, odds, badlo: isBadloBet(bet) });
    let credit = 0;
    let winner = false;
    let netamount = 0;
    let resolved_winner = null;
    let desc = null;
    let meta = null;
    const decision_path = [resolve.reason];
    console.log("step after resolver ");
    console.log(resolve);
    console.log("step after resolver ");
    if (resolve.type === "suspended") {
      await initiateRefund({ job_id, user_id, eventid, match_id, bet, market_type });
      const suspendedStem = exposureIdentity({
        marketType: market_type,
        selectionName: selection_name,
        badlo: isBadloBet(bet)
      }).team_name;
      await clearExposuresForMatch(user_id, match_id, market_type, [suspendedStem]);
      return { settled: true, requeue: false };
    } else if (resolve.type === "meter") {
      netamount = Math.round(meterPnl({
        runs: resolve.runs,
        line: resolve.line,
        stake: stake_amount,
        betType: bet_type
      }) * 100) / 100;
      winner = netamount > 0;
      credit = winner ? netamount : 0;
      resolved_winner = winner ? selection_name : null;
      decision_path.push(`meter: line=${resolve.line} runs=${resolve.runs} net=${netamount}`);
    } else if (resolve.type === "badlo") {
      netamount = Math.round(badloPnl({
        runs: resolve.runs,
        line: resolve.line,
        stake: stake_amount,
        betType: bet_type
      }) * 100) / 100;
      winner = netamount > 0;
      credit = winner ? netamount : 0;
      resolved_winner = winner ? selection_name : null;
      decision_path.push(`badlo: run=${resolve.line} result=${resolve.runs} net=${netamount}`);
    } else if (resolve.type === "string") {
      winner = resolve.winnerName === "won";
      if (market_type === "TIED_MATCH" || market_type === "OVER_UNDER_35" || market_type === "OVER_UNDER_25" || market_type === "OVER_UNDER_15" || market_type === "OVER_UNDER_05" || market_type === "Tied Match" || market_type === "Game Winner 1/2" || market_type === "Game Winner 1/3" || market_type === "1st Set Winner Home/Away" || market_type === "2nd Set Winner Home/Away" || market_type === "3rd Set Winner Home/Away" || market_type === "Next Goal 1.0" || market_type === "Next Goal 2.0" || market_type === "Next Goal 3.0" || market_type === "Next Goal 4.0" || market_type === "Next Goal 5.0" || market_type === "Next Goal 6.0" || market_type === "Game Winner 2/2" || market_type === "Game Winner 2/3" || market_type === "Game Winner 2/4" || market_type === "Game Winner 3/2" || market_type === "Game Winner 3/3" || market_type === "Game Winner 3/4" || market_type === "Game Winner 2/7" || market_type === "Game Winner 4/3" || market_type === "Game Winner 4/4" || market_type === "1st Period Winner" || market_type === "2nd Period Winner" || market_type === "3rd Period Winner" || market_type === "Game To Deuce 1/1" || market_type === "Game To Deuce 1/2" || market_type === "Game To Deuce 1/3" || market_type === "Game To Deuce 1/4" || market_type === "Game To Deuce 2/1" || market_type === "Game To Deuce 2/2" || market_type === "Game To Deuce 2/3" || market_type === "Game To Deuce 2/4" || market_type === "Game To Deuce 3/1" || market_type === "Game To Deuce 3/2" || market_type === "Game To Deuce 3/3" || market_type === "Game To Deuce 3/4" || market_type === "Correct Score" || market_type === "Correct Score1" || market_type === "Correct Score 1st Set" || market_type === "Correct Score 2nd Set" || market_type === "Correct Score 3rd Set" || market_type === "1st Set Race To 4.0" || market_type === "2nd Set Race To 4.0" || market_type === "3rd Set Race To 4.0" || market_type === "Point Winner 1/3/1" || market_type === "Point Winner 1/2/1" || market_type === "Point Winner 1/1/1" || market_type === "Point Winner 2/3/1" || market_type === "Point Winner 2/2/1" || market_type === "Point Winner 2/1/1" || market_type === "Point Winner 3/3/1" || market_type === "Point Winner 3/2/1" || market_type === "Point Winner 3/1/1" || market_type === "Point Winner 1/3/2" || market_type === "Point Winner 1/2/2" || market_type === "Point Winner 1/1/2" || market_type === "Point Winner 2/3/2" || market_type === "Point Winner 2/2/2" || market_type === "Point Winner 2/1/2" || market_type === "Point Winner 3/3/2" || market_type === "Point Winner 3/2/2" || market_type === "Point Winner 3/1/2" || market_type === "Point Winner 1/2/1" || market_type === "HALF_TIME" || market_type === "Match Result/Both Teams to score" || market_type === "Both Teams To Score" || market_type === "Match Time Result 70:00" || market_type === "Match Time Result 10:00" || market_type === "Match Time Result 20:00" || market_type === "Match Time Result 30:00" || market_type === "Match Time Result 40:00" || market_type === "Match Time Result 50:00" || market_type === "Match Time Result 60:00" || market_type === "Match Time Result 80:00" || market_type === "Match Time Result 90:00" || market_type === "oddeven" || market_type === "fancy1") {
        if (market_type === "oddeven") {
          credit = winner ? stake_amount * (odds - 1) : 0;
          netamount = winner ? stake_amount * (odds - 1) : -stake_amount;
        } else if (market_type === "TIED_MATCH" || market_type === "Tied Match") {
          const tmYes = bet_type === "yes" || bet_type === "YES";
          if (winner) {
            credit = tmYes ? stake_amount * (odds / 100) : stake_amount;
            netamount = credit;
          } else {
            credit = 0;
            netamount = tmYes ? -stake_amount : -(parseFloat(bet.liability) || stake_amount);
          }
        } else if (winner) {
          credit = bet_type === "yes" || bet_type === "YES" ? stake_amount * (odds - 1) : stake_amount;
          netamount = bet_type === "yes" || bet_type === "YES" ? stake_amount * (odds - 1) : stake_amount;
        } else {
          credit = 0;
          netamount = bet_type === "yes" || bet_type === "YES" ? -stake_amount : market_type === "fancy1" ? -stake_amount * (odds - 1) : -stake_amount * odds;
        }
      } else if (isLineMarket(market_type)) {
        credit = winner ? Number(stake_amount) : 0;
        netamount = winner ? Number(stake_amount) : -Number(stake_amount);
      } else {
        console.log("size", bet.size);
        if (winner) {
          credit = bet_type === "yes" || bet_type === "YES" ? stake_amount * (bet.size / 100) : stake_amount;
          netamount = bet_type === "yes" || bet_type === "YES" ? stake_amount * (bet.size / 100) : stake_amount;
        } else {
          credit = 0;
          netamount = bet_type === "yes" || bet_type === "YES" ? -stake_amount : -stake_amount * (bet.size / 100);
        }
      }
      resolved_winner = winner ? selection_name : null;
      decision_path.push(`string match: selection=${selection_name} winnerName=${resolve.winnerName}`);
    } else {
      log.info("[Settlement] Unknown resolve type for FAN bet, requeue", { bet_id, type: resolve.type });
      return { settled: false, requeue: true };
    }
    const resultStatus = winner ? "won" : "loss";
    let alreadySettled = false;
    await db_default.transaction(async (transaction) => {
      const [claimed] = await SportsBet_default.update(
        { status: "closed", result_status: resultStatus, fixed: 1, updated_at: /* @__PURE__ */ new Date() },
        { where: { id: bet_id, status: { [Op2.in]: ["open", "manual"] } }, transaction }
      );
      if (!claimed) {
        alreadySettled = true;
        return;
      }
      const expIds = exposureIdentity({ marketType: market_type, selectionName: selection_name, badlo: isBadloBet(bet) });
      let oldExposuresRows = await UserExposure_default.findAll({
        where: {
          user_id,
          match_id,
          game_type: expIds.game_type,
          team_name: expIds.team_name
        },
        transaction,
        lock: transaction.LOCK.UPDATE
      });
      let expStemLegacy = null;
      if (!oldExposuresRows.length && (expIds.game_type !== market_type || expIds.team_name !== selection_name)) {
        oldExposuresRows = await UserExposure_default.findAll({
          where: { user_id, match_id, game_type: market_type, team_name: selection_name },
          transaction,
          lock: transaction.LOCK.UPDATE
        });
        if (oldExposuresRows.length) {
          expStemLegacy = selection_name;
          log.warn("[Settlement] released a PRE-MIGRATION line exposure row", {
            bet_id,
            market_type,
            selection_name
          });
        }
      }
      const oldExposure = oldExposuresRows[0] ? Number(oldExposuresRows[0].exposure_amount) : 0;
      console.log("OLD EXPOSURES:", oldExposure);
      let releaseexposure = Math.abs(oldExposure);
      if (releaseexposure > 0) {
        const creditRecord = await Wallet_default.findOne({
          where: { user_id: String(user_id) },
          transaction,
          lock: transaction.LOCK.UPDATE
        });
        if (!creditRecord) {
          console.log("{exposure release} No credit record for user", { user_id });
        } else {
          const currentBal = Number(creditRecord.cash || 0);
          const addAmt = Number(releaseexposure);
          const newBal = currentBal + addAmt;
          await creditRecord.update(
            { cash: newBal },
            { transaction }
          );
          console.log("newBal after exposure release", newBal);
        }
      }
      console.log("step after credit or reffund ");
      console.log("amount ", credit);
      console.log("winner ", winner);
      console.log("netamount ", netamount);
      const fanResultItem = result.items && result.items[0] || {};
      const fanWinnerLabel = fanResultItem.winnerName ?? fanResultItem.winnerId ?? (winner ? "won" : "loss");
      desc = buildSettlementDesc(bet, market_type, fanWinnerLabel);
      meta = { api: { type: "result", eventid, marketName: fancy_name, bettingType: bet_type }, bet_id };
      await FanWin_default.create({
        user_id,
        fancyname: fancy_name,
        selection: selection_name,
        runsodds: odds,
        payout: credit,
        eventid,
        matchid: match_id,
        created_at: /* @__PURE__ */ new Date()
      }, { transaction });
      if (Number(netamount) !== 0) {
        const amt = Number(num2(netamount));
        try {
          const creditRecord = await Wallet_default.findOne({
            where: { user_id: String(user_id) },
            transaction,
            lock: transaction.LOCK.UPDATE
          });
          if (!creditRecord) {
            log.error("[Settlement] No credit record for user", { user_id });
            return;
          }
          const currentCash = Number(creditRecord.cash || 0);
          const currentInr = Number(creditRecord.inr_balance || 0);
          const newCash = currentCash + amt;
          const newInr = currentInr + amt;
          await creditRecord.update(
            { cash: newCash, inr_balance: newInr },
            { transaction }
          );
          console.log("[Settlement wallet]");
          console.log("currentCash:", currentCash, "newCash:", newCash);
          console.log("currentInr:", currentInr, "newInr:", newInr);
          console.log("netamount :", amt);
        } catch (err) {
          log.error("[Settlement] Error updating credit record", {
            user_id,
            error: err.message
          });
          throw err;
        }
      }
      const expStem = expStemLegacy ?? expIds.team_name;
      const expGt = expStemLegacy ? market_type : expIds.game_type;
      await UserExposure_default.destroy({
        where: {
          user_id,
          match_id,
          game_type: expGt,
          [Op2.or]: [
            { team_name: expStem },
            { team_name: `${expStem}lay` },
            { team_name: `${expStem}back` },
            { team_name: `${expStem}totalstake` }
          ]
        },
        transaction
      });
    });
    await user.increment("net_win", { by: winner ? netamount : 0 });
    await user.increment("profit", { by: netamount });
    await user.increment("net_loss", { by: winner ? 0 : netamount });
    console.log("user", user);
    const walletForClosing = await Wallet_default.findOne({ where: { user_id: String(user_id) } });
    let closing = walletForClosing ? Number(walletForClosing.cash || 0) : 0;
    const fanSettlementLedgerRow = await CreditsLedger_default.create({
      user_id,
      currency: "INR",
      amount: credit,
      // REQUIRED (raw +win / -loss)
      reason: "settlement",
      // REQUIRED (ex: BET_WIN, BET_LOSS)
      description: desc || null,
      eventid: eventid || null,
      match_id: match_id || null,
      job_id: job_id || null,
      market_type: market_type || null,
      sport_id: bet.sport_id || null,
      meta: meta || null,
      commission: null,
      // `??`, not `||`: a badlo leg off its run (or a meter landing on its
      // line) settles at a REAL net of 0. `|| null` stored that as NULL,
      // the statement skips NULL netamount and fell back to the bet-row
      // formula, which showed every such leg as a full -stake loss.
      netamount: netamount ?? null,
      profit: winner ? netamount : null,
      loss: winner ? null : netamount,
      bet_id: bet.id || null,
      closing: closing || null,
      category: "SPORTS"
    });
    console.log("teset credit ledger");
    const fanStake = getStake(bet);
    const fanNetPL = credit - fanStake;
    if (alreadySettled) {
      log.warn("[Settlement] FAN bet already settled \u2014 duplicate pass skipped", { bet_id, user_id, job_id });
      return { settled: true, requeue: false };
    }
    const fanNet = Number(num2(netamount));
    if (fanNet !== 0) {
      try {
        const pointRes = await walletService_default.updateAllPointHierarchy(Number(bet_id), POINT_CATEGORY.SPORTS);
        if (!pointRes.success) log.error("[Settlement] all_point update failed", { user_id, error: pointRes.error });
      } catch (err) {
        log.error("[Settlement] all_point update error", { user_id, error: err.message });
      }
    }
    if (fanSettlementLedgerRow && winner && fanNet > 0) {
      await applyWinCommission({
        user_id,
        bet,
        netWin: fanNet,
        settlementLedgerId: fanSettlementLedgerRow.id,
        description: desc,
        market_type,
        eventid,
        match_id,
        job_id,
        log
      });
    }
  }
  return { settled: true, requeue: false };
}
async function processJob(job) {
  const { job_id, user_id, eventid } = job;
  log.info(`[Settlement] Processing job job_id=${job_id} user=${user_id} event=${eventid}`, { job_id });
  const bets = await SportsBet_default.findAll({
    where: { job_id: String(job_id), status: { [Op2.in]: ["open", "manual"] } },
    order: [["created_at", "ASC"]]
  });
  if (!bets.length) {
    log.info(`[Settlement] No open bets for job_id=${job_id}; marking done`, { job_id });
    await SportsEventSettlementJobs_default.update(
      { status: "done", updated_at: /* @__PURE__ */ new Date(), error_msg: null },
      { where: { job_id: String(job_id) } }
    );
    return;
  }
  log.debug("[Settlement] Found bets", { job_id, bet_count: bets.length });
  const moBmByMatch = /* @__PURE__ */ new Map();
  const fanBets = [];
  for (const b of bets) {
    const gt = (b?.game_type).toUpperCase();
    if (gt === "MO" || gt === "BM" || gt === "BO") {
      const k = `${b.user_id}::${b.match_id}`;
      if (!moBmByMatch.has(k)) moBmByMatch.set(k, []);
      moBmByMatch.get(k).push(b);
    } else if (gt === "FAN") {
      fanBets.push(b);
    } else {
      log.error(`[Settlement] Unknown game_type="${b.game_type}"`, { bet_id: b.id });
    }
  }
  let anyRequeue = false;
  for (const [, group] of moBmByMatch.entries()) {
    const any = group[0];
    try {
      const res = await processMobmGroup({
        job_id,
        user_id: any.user_id,
        eventid: any.eventid,
        match_id: any.match_id,
        bets: group,
        eventName: any.match_title || "",
        marketId: any.match_id,
        marketName: any.selection_name || "",
        market_type: any.market_type,
        game_type: any.game_type,
        team_one: any.team_one,
        team_two: any.team_two,
        sport_id: any.sport_id,
        market_type: any.market_type,
        game_type: any.game_type
      });
      if (res.requeue) anyRequeue = true;
    } catch (e) {
      anyRequeue = true;
      log.error(`[Settlement] MO/BM group failed`, { match_id: any.match_id, error: e.message });
    }
  }
  for (const b of fanBets) {
    try {
      const res = await processFanBet({
        job_id,
        bet: b,
        eventName: b.match_title || "",
        marketId: b.match_id,
        marketName: b.fancy_name || ""
      });
      if (res.requeue) anyRequeue = true;
    } catch (e) {
      anyRequeue = true;
      log.error(`[Settlement] FAN bet failed`, { bet_id: b.id, error: e.message });
    }
  }
  const touchedUsers = new Set(bets.map((b) => String(b.user_id)));
  if (user_id != null) touchedUsers.add(String(user_id));
  for (const uid of touchedUsers) {
    await recalcTotalExposure(uid);
  }
  if (anyRequeue) {
    await SportsEventSettlementJobs_default.update(
      { status: "queued", run_after: new Date(Date.now() + SETTLE_REQUEUE_MS), updated_at: /* @__PURE__ */ new Date(), error_msg: null },
      { where: { job_id: String(job_id) } }
    );
    log.info(`[Settlement] job_id=${job_id} kept queued, retry in ${SETTLE_REQUEUE_MS} ms`, { job_id });
  } else {
    await SportsEventSettlementJobs_default.update(
      { status: "done", updated_at: /* @__PURE__ */ new Date(), error_msg: null },
      { where: { job_id: String(job_id) } }
    );
    log.info(`[Settlement] job_id=${job_id} DONE`, { job_id });
  }
}
async function requeueStuckJobs() {
  try {
    const cutoff = new Date(Date.now() - SETTLE_STUCK_MS);
    const [n] = await SportsEventSettlementJobs_default.update(
      { status: "queued", run_after: /* @__PURE__ */ new Date(), updated_at: /* @__PURE__ */ new Date(), error_msg: "recovered from stuck processing" },
      { where: { status: "processing", updated_at: { [Op2.lt]: cutoff } } }
    );
    if (n) log.warn("[Settlement] recovered stuck processing job(s)", { count: n });
  } catch (e) {
    log.error("[Settlement] stuck-job recovery failed", { error: e.message });
  }
}
async function pollOnce() {
  const startedAt = Date.now();
  try {
    await requeueStuckJobs();
    const rows = await SportsEventSettlementJobs_default.findAll({
      where: { status: "queued", run_after: { [Op2.lte]: /* @__PURE__ */ new Date() } },
      order: [["created_at", "ASC"]],
      limit: BATCH_LIMIT,
      attributes: ["job_id", "user_id", "eventid", "payload"]
    });
    if (!rows.length) {
      log.debug("[Settlement] poll: nothing queued");
      return 0;
    }
    log.info(`[Settlement] ===== Poll start ${nowIso()} =====`);
    log.info(`[Settlement] Picked ${rows.length} queued job(s)`, { job_count: rows.length });
    for (const job of rows) {
      let user_id = job?.user_id;
      const jobStart = Date.now();
      try {
        const updatedCount = await SportsEventSettlementJobs_default.update(
          { status: "processing", updated_at: /* @__PURE__ */ new Date() },
          { where: { job_id: job.job_id, status: "queued" } }
        );
        if (updatedCount[0] === 0) {
          log.debug("[Settlement] Job already taken", { job_id: job.job_id });
          continue;
        }
        let eventid = job?.eventid;
        if (!user_id || !eventid) {
          log.error("[Settlement] Job missing userId/eventId", { job_id: job.job_id });
          await SportsEventSettlementJobs_default.update(
            { status: "failed", error_msg: "Missing userId/eventId", updated_at: /* @__PURE__ */ new Date() },
            { where: { job_id: job.job_id } }
          );
          continue;
        }
        await processJob(job);
        log.info("[Settlement] job finished", { job_id: job.job_id, ms: Date.now() - jobStart });
      } catch (e) {
        log.error(`[Settlement] Job failed`, { job_id: job.job_id, user_id, error: e.message });
        await SportsEventSettlementJobs_default.update(
          { status: "failed", error_msg: e.message, updated_at: /* @__PURE__ */ new Date() },
          { where: { job_id: job.job_id } }
        );
      }
    }
    const queued = await SportsEventSettlementJobs_default.count({ where: { status: "queued" } });
    const processing = await SportsEventSettlementJobs_default.count({ where: { status: "processing" } });
    log.info(`[Settlement] queue stats => queued:${queued || 0} processing:${processing || 0}`);
    log.info(`[Settlement] ===== Poll end (${Date.now() - startedAt} ms) =====`);
    return rows.length;
  } catch (e) {
    log.error("[Settlement] pollOnce failed", { error: e.message });
    return 0;
  }
}
var running = false;
var pending = false;
async function runPoll(trigger) {
  if (running) {
    pending = true;
    return;
  }
  running = true;
  try {
    do {
      pending = false;
      const picked = await pollOnce();
      if (picked >= BATCH_LIMIT) pending = true;
    } while (pending);
  } catch (e) {
    log.error("[Settlement] poll loop error", { trigger, error: e.message });
  } finally {
    running = false;
  }
}
function startScheduler() {
  log.info(`[Settlement] Scheduler starting (poll every ${SETTLE_POLL_MS} ms, redis wake on "${WAKE_CHANNEL}")`);
  setInterval(() => runPoll("timer"), SETTLE_POLL_MS);
  runPoll("startup");
  try {
    const sub = new IORedis({
      host: process.env.REDIS_HOST || "127.0.0.1",
      port: +(process.env.REDIS_PORT || 6379),
      maxRetriesPerRequest: null
    });
    sub.on("error", (e) => log.error("[Settlement] redis wake error (timer poll still active)", { error: e.message }));
    sub.subscribe(WAKE_CHANNEL, (err) => {
      if (err) log.error("[Settlement] redis wake subscribe failed", { error: err.message });
      else log.info("[Settlement] redis wake subscribed", { channel: WAKE_CHANNEL });
    });
    sub.on("message", (channel) => {
      if (channel === WAKE_CHANNEL) runPoll("wake");
    });
  } catch (e) {
    log.error("[Settlement] redis wake unavailable \u2014 timer poll only", { error: e.message });
  }
}
async function start() {
  try {
    log.info("[SettlementV2] Worker v3.1.0 (AVRKHUB, fast-settle) starting...");
    await SportsEventSettlementJobs_default.count();
    log.info("[Settlement] Database connection verified");
    startScheduler();
  } catch (e) {
    log.error("[Settlement] Startup failed", { error: e.message });
    process.exit(1);
  }
}
start().catch((e) => {
  log.error("[Settlement] Fatal", { error: e.message });
  process.exit(1);
});
export {
  pollOnce,
  start
};
