// sportsbet/betresult/newjobv2.js
import fs from "fs";
import path2 from "path";
import http from "http";
import https from "https";
import axios2 from "axios";

// model/user/SportsEventResultScan.js
import { DataTypes } from "sequelize";

// config/db.js
import { Sequelize } from "sequelize";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
var __filename = fileURLToPath(import.meta.url);
var __dirname = path.dirname(__filename);
var envPath = path.resolve(__dirname, "../.env");
dotenv.config({ path: envPath });
var IS_API_PROCESS = path.basename(process.env.pm_exec_path || process.argv[1] || "") === "server.js";
var POOL_MAX = Number(process.env.DB_POOL_MAX) || (IS_API_PROCESS ? 25 : 10);
var sequelize = new Sequelize(
  process.env.DB_NAME,
  process.env.DB_USER,
  process.env.DB_PASSWORD,
  {
    host: process.env.DB_HOST,
    port: process.env.DB_PORT || 5432,
    dialect: "postgres",
    logging: false,
    // set to true for SQL logs
    pool: {
      max: POOL_MAX,
      // max connections in pool (see POOL_MAX above)
      min: 2,
      // min connections kept open
      acquire: 3e4,
      // max ms to wait for a connection before throwing error
      idle: 1e4,
      // max ms a connection can be idle before being released
      evict: 1e3
      // how often to check for idle connections (ms)
    }
  }
);
var db_default = sequelize;

// model/user/SportsEventResultScan.js
var SportsEventResultScan = db_default.define(
  "SportsEventResultScan",
  {
    user_id: {
      type: DataTypes.TEXT,
      allowNull: false,
      primaryKey: true
    },
    eventid: {
      type: DataTypes.TEXT,
      allowNull: false,
      primaryKey: true
    },
    declared: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false
    },
    counts: {
      type: DataTypes.JSONB,
      allowNull: false,
      defaultValue: {}
    },
    checked_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW
    }
  },
  {
    tableName: "sports_event_result_scan",
    // 👈 your table
    timestamps: false,
    indexes: [
      {
        unique: true,
        fields: ["user_id", "eventid"]
      }
    ]
  }
);
var SportsEventResultScan_default = SportsEventResultScan;

// model/user/SportsEventResultSummary.js
import { DataTypes as DataTypes2 } from "sequelize";
var SportsEventResultSummary = db_default.define(
  "SportsEventResultSummary",
  {
    id: {
      type: DataTypes2.BIGINT,
      autoIncrement: true,
      primaryKey: true
    },
    user_id: {
      type: DataTypes2.TEXT,
      allowNull: false
    },
    eventid: {
      type: DataTypes2.TEXT,
      allowNull: false
    },
    declared: {
      type: DataTypes2.BOOLEAN,
      allowNull: false,
      defaultValue: false
    },
    counts: {
      type: DataTypes2.JSONB,
      allowNull: false,
      defaultValue: {}
    },
    result_meta: {
      type: DataTypes2.JSONB,
      allowNull: true
    },
    sections: {
      type: DataTypes2.JSONB,
      allowNull: true
    },
    recorded_at: {
      type: DataTypes2.DATE,
      allowNull: false,
      defaultValue: DataTypes2.NOW
    }
  },
  {
    tableName: "sports_event_result_summary",
    timestamps: false
    // no createdAt/updatedAt
  }
);
var SportsEventResultSummary_default = SportsEventResultSummary;

// model/user/SportsEventSettlementJobs.js
import { DataTypes as DataTypes3 } from "sequelize";
var SportsEventSettlementJob = db_default.define(
  "SportsEventSettlementJob",
  {
    job_id: {
      type: DataTypes3.UUID,
      defaultValue: DataTypes3.UUIDV4,
      primaryKey: true
    },
    user_id: {
      type: DataTypes3.TEXT,
      allowNull: false
    },
    eventid: {
      type: DataTypes3.TEXT,
      allowNull: false
    },
    status: {
      type: DataTypes3.TEXT,
      allowNull: false,
      defaultValue: "queued"
    },
    priority: {
      type: DataTypes3.INTEGER,
      allowNull: false,
      defaultValue: 5
    },
    run_after: {
      type: DataTypes3.DATE,
      allowNull: false,
      defaultValue: DataTypes3.NOW
    },
    payload: {
      type: DataTypes3.JSONB,
      allowNull: false
    },
    error_msg: {
      type: DataTypes3.TEXT,
      allowNull: true
    },
    created_at: {
      type: DataTypes3.DATE,
      allowNull: false,
      defaultValue: DataTypes3.NOW
    },
    updated_at: {
      type: DataTypes3.DATE,
      allowNull: false,
      defaultValue: DataTypes3.NOW
    },
    bet_type: {
      type: DataTypes3.TEXT,
      allowNull: true
    },
    bet_id: {
      type: DataTypes3.TEXT,
      allowNull: true
    }
  },
  {
    tableName: "sports_event_settlement_jobs",
    timestamps: false,
    indexes: [
      {
        // this MUST match your conflictFields and be unique
        unique: true,
        fields: ["user_id", "eventid", "bet_id"],
        name: "uniq_user_event_bet"
      },
      {
        fields: ["status"]
      }
    ]
  }
);
var SportsEventSettlementJobs_default = SportsEventSettlementJob;

// model/user/SportsBetResultCache.js
import { DataTypes as DataTypes4 } from "sequelize";
var SportsBetResultCache = db_default.define(
  "SportsBetResultCache",
  {
    user_id: {
      type: DataTypes4.TEXT,
      allowNull: false,
      primaryKey: true
    },
    eventid: {
      type: DataTypes4.TEXT,
      allowNull: false,
      primaryKey: true
    },
    match_id: {
      type: DataTypes4.TEXT,
      allowNull: false,
      primaryKey: true
    },
    bucket: {
      type: DataTypes4.TEXT,
      allowNull: false,
      primaryKey: true
    },
    declared: {
      type: DataTypes4.BOOLEAN,
      allowNull: false,
      defaultValue: false
    },
    is_match_over: {
      type: DataTypes4.BOOLEAN,
      allowNull: false,
      defaultValue: false
    },
    winner_name: {
      type: DataTypes4.TEXT,
      allowNull: true
    },
    winner_id: {
      type: DataTypes4.BIGINT,
      allowNull: true
    },
    market_id: {
      type: DataTypes4.TEXT,
      allowNull: true
    },
    market_name: {
      type: DataTypes4.TEXT,
      allowNull: true
    },
    provider: {
      type: DataTypes4.TEXT,
      allowNull: true
    },
    betting_type: {
      type: DataTypes4.TEXT,
      allowNull: true
    },
    declared_at: {
      type: DataTypes4.DATE,
      allowNull: true
    },
    api_snapshot: {
      type: DataTypes4.JSONB,
      allowNull: true
    },
    recorded_at: {
      type: DataTypes4.DATE,
      allowNull: false,
      defaultValue: DataTypes4.NOW
    }
  },
  {
    tableName: "sports_bet_result_cache",
    timestamps: false,
    // no auto createdAt/updatedAt
    indexes: [
      {
        unique: true,
        fields: ["user_id", "eventid", "match_id", "bucket"]
        // composite PK
      },
      {
        fields: ["declared"]
      },
      {
        fields: ["is_match_over"]
      }
    ]
  }
);
var SportsBetResultCache_default = SportsBetResultCache;

// model/user/Tokens.js
import { DataTypes as DataTypes5 } from "sequelize";
var Tokens = db_default.define(
  "Tokens",
  {
    uid: {
      type: DataTypes5.NUMERIC,
      allowNull: false,
      primaryKey: true
    },
    key: {
      type: DataTypes5.TEXT,
      allowNull: false
    }
  },
  {
    tableName: "tokens",
    // explicitly set table name
    timestamps: false
    // disable createdAt/updatedAt if not needed
  }
);

// model/user/SportsBet.js
import { DataTypes as DataTypes6 } from "sequelize";
var SportsBet = db_default.define(
  "SportsBet",
  {
    id: {
      type: DataTypes6.INTEGER,
      autoIncrement: true,
      primaryKey: true
    },
    user_id: {
      type: DataTypes6.BIGINT,
      allowNull: false
    },
    game_type: {
      type: DataTypes6.STRING(100),
      allowNull: false
    },
    match_title: {
      type: DataTypes6.STRING(255)
    },
    team_one: {
      type: DataTypes6.STRING(255),
      allowNull: true
    },
    team_two: {
      type: DataTypes6.STRING(255),
      allowNull: true
    },
    selection_name: {
      type: DataTypes6.STRING(255),
      allowNull: true
    },
    category: {
      type: DataTypes6.STRING(100),
      allowNull: true
    },
    bet_type: {
      type: DataTypes6.STRING(100),
      allowNull: false
    },
    market_type: {
      type: DataTypes6.STRING(100),
      allowNull: true,
      defaultValue: null
      // or "Over By Over" if you want
    },
    odds: {
      type: DataTypes6.DECIMAL(10, 4),
      allowNull: false
    },
    stake_amount: {
      type: DataTypes6.DECIMAL(15, 2),
      allowNull: false
    },
    event_name: {
      type: DataTypes6.STRING(255)
    },
    original_currency: {
      type: DataTypes6.STRING(10),
      allowNull: true,
      defaultValue: "INR"
    },
    original_amount: {
      type: DataTypes6.DECIMAL(15, 2),
      allowNull: true
    },
    usd_amount: {
      type: DataTypes6.DECIMAL(15, 2),
      allowNull: true
    },
    liability: {
      type: DataTypes6.DECIMAL(15, 2),
      allowNull: true
    },
    match_start_time: {
      type: DataTypes6.DATE,
      allowNull: true
    },
    match_end_time: {
      type: DataTypes6.DATE,
      allowNull: true
    },
    created_at: {
      type: DataTypes6.DATE,
      defaultValue: DataTypes6.NOW
    },
    updated_at: {
      type: DataTypes6.DATE,
      defaultValue: DataTypes6.NOW
    },
    match_id: {
      type: DataTypes6.STRING(100),
      allowNull: true
    },
    exposure_after_bet: {
      type: DataTypes6.DECIMAL(15, 2),
      allowNull: true
    },
    status: {
      type: DataTypes6.STRING(20),
      allowNull: true
    },
    eventid: {
      type: DataTypes6.TEXT
    },
    job_id: {
      type: DataTypes6.UUID,
      allowNull: true
    },
    ip_address: {
      type: DataTypes6.TEXT,
      allowNull: true
    },
    browser: {
      type: DataTypes6.TEXT,
      allowNull: true
    },
    fancy_name: {
      type: DataTypes6.TEXT,
      allowNull: true
    },
    result_status: {
      type: DataTypes6.TEXT,
      defaultValue: "pending"
    },
    fixed: {
      type: DataTypes6.INTEGER,
      defaultValue: 0
    },
    counts: {
      type: DataTypes6.INTEGER,
      defaultValue: 2
    },
    sport_id: {
      type: DataTypes6.TEXT,
      allowNull: true
    },
    unmatched: {
      type: DataTypes6.BOOLEAN,
      defaultValue: false
    },
    unmatched_odds: {
      type: DataTypes6.DECIMAL(10, 4),
      allowNull: true
    },
    size: {
      type: DataTypes6.INTEGER,
      allowNull: true
    },
    runners: {
      type: DataTypes6.JSON,
      allowNull: true
    },
    gtype: {
      type: DataTypes6.TEXT,
      allowNull: true
    },
    // League / competition name from the feed (cname), sent by the client at
    // placement. Only used for display — the statement Result modal prints
    // "Sport -> League -> Match -> Market". Column is added on boot by
    // ensureSportsBetLeagueColumn() in config/dbInit.js.
    league_name: {
      type: DataTypes6.STRING(255),
      allowNull: true
    },
    // Badlo is an EXACT-RUN swap that lives INSIDE an ordinary session market
    // ("Normal"), flagged per runner by the feed's `ik`. It is a property of
    // the BET, not of the market — so it is a flag here rather than a
    // market_type value. Overloading market_type with 'badlo' (the first
    // attempt) put these rows in their own market bucket, printed "badlo" as
    // the market name in the bet list, and split the runner's Normal book.
    // See helper/badloMarket.js.
    badlo: {
      type: DataTypes6.BOOLEAN,
      allowNull: false,
      defaultValue: false
    }
  },
  {
    tableName: "SportsBet",
    timestamps: false,
    indexes: [
      { fields: ["user_id"] },
      { fields: ["match_id"] },
      { fields: ["eventid"] },
      { fields: ["status"] },
      { fields: ["result_status"] },
      { fields: ["sport_id"] },
      { fields: ["job_id"] },
      { fields: ["user_id", "status"] },
      { fields: ["user_id", "match_id"] },
      { fields: ["user_id", "eventid", "status"] }
    ]
  }
);
var SportsBet_default = SportsBet;

// sportsbet/betresult/newjobv2.js
import { Op as Op3 } from "sequelize";

// sportsbet/betresult/customMarketResolvers.js
import axios from "axios";
var AVRKHUB_BASE_URL = process.env.AVRKHUB_BASE_URL || "https://diamond-result-v2.avrkhub.in";
var ax = axios.create({
  timeout: 1e4,
  headers: { "User-Agent": "d99-settlement-h2h-fallback/1.0" }
});
async function resolveH2HBookmakerFallback({
  eventid,
  sport_id,
  market_type,
  team_one,
  team_two,
  logger,
  // Optional (gmid, sid) => parsed payload | null. When supplied the caller's
  // per-event result cache answers instead of a fresh feed call per bet.
  getPayload = null
}) {
  const log2 = logger || console;
  const mt = (market_type || "").toUpperCase().trim();
  if (!mt.includes("BOOKMAKER")) return null;
  if (mt === "BOOKMAKER" || mt === "BOOKMAKER 2") return null;
  const overMatch = mt.match(/(\d+(?:\.\d+)?)\s*OVER/);
  if (!overMatch) return null;
  const overNum = overMatch[1];
  const cleanTeam = (s) => {
    const m = (s || "").toUpperCase().trim().match(/^([A-Z]+\d*)/);
    if (!m) return "";
    return m[1].replace(/\d+$/, "");
  };
  const t1 = cleanTeam(team_one);
  const t2 = cleanTeam(team_two);
  if (!t1 || !t2) return null;
  log2.info?.("[H2HFallback] start", {
    eventid,
    market_type,
    team_one,
    team_two,
    overNum,
    t1,
    t2
  });
  let data;
  try {
    if (getPayload) {
      data = await getPayload(eventid, sport_id || "4");
    } else {
      const res = await ax.get(`${AVRKHUB_BASE_URL}/get_result`, {
        params: { gmid: eventid, sid: sport_id || "4" }
      });
      data = typeof res?.data === "string" ? JSON.parse(res.data) : res.data;
    }
  } catch (e) {
    log2.error?.("[H2HFallback] upstream fetch failed", {
      eventid,
      error: e.message
    });
    return null;
  }
  const markets = Array.isArray(data?.markets) ? data.markets : [];
  const findSession = (teamCode) => {
    const overEsc = overNum.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const re = new RegExp(
      `^${overEsc}\\s*OVER\\s+RUNS?(?:\\s+BHAV)?\\s+${teamCode}(?:\\b|\\(|\\.|$)`,
      "i"
    );
    return markets.find(
      (m) => (m?.mname || "").toUpperCase() === "NORMAL" && m?.status === "SETTLE" && m?.winnerId != null && re.test(m?.marketName || "")
    );
  };
  const m1 = findSession(t1);
  const m2 = findSession(t2);
  if (!m1 || !m2) {
    log2.warn?.("[H2HFallback] missing one or both session results", {
      eventid,
      t1,
      t2,
      found_t1: !!m1,
      found_t2: !!m2
    });
    return null;
  }
  const score1 = parseInt(m1.winnerId, 10);
  const score2 = parseInt(m2.winnerId, 10);
  let winnerName;
  if (score1 > score2) winnerName = team_one;
  else if (score2 > score1) winnerName = team_two;
  else winnerName = "SUSPENDED";
  log2.info?.("[H2HFallback] resolved", {
    eventid,
    market_type,
    t1,
    score1,
    t2,
    score2,
    winnerName
  });
  return {
    declared: true,
    items: [
      {
        ename: m1.ename || "",
        marketName: market_type,
        mname: market_type,
        winnerName,
        winnerId: null,
        status: "SETTLE"
      }
    ],
    meta: {
      source: "h2h_bookmaker_fallback",
      overNum,
      t1,
      score1,
      t1_market: m1.marketName,
      t2,
      score2,
      t2_market: m2.marketName
    }
  };
}
function splitRunnerString(value) {
  if (value == null) return [];
  if (Array.isArray(value)) {
    return value.map((v) => {
      if (typeof v === "string") return v;
      if (v && typeof v === "object") return v.nat || v.name || v.runnerName || v.selection_name || "";
      return "";
    }).map((s) => String(s).trim()).filter(Boolean);
  }
  if (typeof value === "string") {
    const s = value.trim();
    if (!s) return [];
    if (s.startsWith("[") || s.startsWith("{")) {
      try {
        return splitRunnerString(JSON.parse(s));
      } catch (_) {
      }
    }
    return s.split(/\s+vs\s+/i).map((x) => x.trim()).filter(Boolean);
  }
  return [];
}
function runnersKey(value) {
  return splitRunnerString(value).map((s) => s.toUpperCase().replace(/\s+/g, " ").trim()).filter(Boolean).sort().join("|");
}
var normMname = (v) => String(v || "").trim().toUpperCase().replace(/[\s_]+/g, " ");
function matchMarketByRunners(markets, runners, eventName, mname) {
  const key = runnersKey(runners);
  if (!key) return null;
  if (key.split("|").length < 3) return null;
  const wantMname = normMname(mname);
  const list = Array.isArray(markets) ? markets : [];
  return list.find((m) => {
    const natKey = runnersKey(m?.natName || m?.nat || "");
    if (!natKey || natKey !== key) return false;
    if (wantMname && normMname(m?.mname) !== wantMname) return false;
    return true;
  }) || null;
}

// sportsbet/betresult/resultCache.js
var cache = /* @__PURE__ */ new Map();
var inflight = /* @__PURE__ */ new Map();
function makeCachedGet({ ax: ax3, ttlMs = 2500, rateLimit = null }) {
  return async function cachedGet2(url, params, cfg = {}) {
    const key = `${url}?gmid=${params?.gmid}&sid=${params?.sid}`;
    const hit = cache.get(key);
    if (hit && Date.now() - hit.at < ttlMs) return hit.res;
    const pending = inflight.get(key);
    if (pending) return pending;
    const p = (async () => {
      try {
        if (rateLimit) await rateLimit();
        const res = await ax3.get(url, { params, ...cfg });
        if (res.status === 200 || res.status === 404) cache.set(key, { at: Date.now(), res });
        return res;
      } finally {
        inflight.delete(key);
      }
    })();
    inflight.set(key, p);
    return p;
  };
}
function makePayloadGetter(cachedGet2, url) {
  return async function getPayload(gmid, sid) {
    const res = await cachedGet2(url, { gmid, sid: sid || "4" });
    if (res.status !== 200) return null;
    return typeof res?.data === "string" ? JSON.parse(res.data) : res.data;
  };
}

// model/admin/AutoVoidConfig.js
import { DataTypes as DataTypes7 } from "sequelize";
var AutoVoidConfig = db_default.define("AutoVoidConfig", {
  id: {
    type: DataTypes7.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  enabled: {
    type: DataTypes7.BOOLEAN,
    allowNull: false,
    defaultValue: false
  },
  delay_seconds: {
    type: DataTypes7.INTEGER,
    allowNull: false,
    defaultValue: 600,
    comment: "seconds after the anchor result is first seen before the void fires"
  },
  on_match_odds: {
    type: DataTypes7.BOOLEAN,
    allowNull: false,
    defaultValue: true,
    comment: "a settled/void MATCH_ODDS market starts the timer"
  },
  on_bookmaker: {
    type: DataTypes7.BOOLEAN,
    allowNull: false,
    defaultValue: true,
    comment: "a settled/void BOOKMAKER market starts the timer"
  },
  enabled_at: {
    type: DataTypes7.DATE,
    allowNull: true,
    comment: "last OFF -> ON switch; a void never fires before enabled_at + delay"
  }
}, {
  tableName: "auto_void_config",
  timestamps: true
});
var AUTO_VOID_ROW_ID = 1;
var AUTO_VOID_MAX_DELAY = 24 * 3600;
var getAutoVoidConfig = async () => {
  const [row] = await AutoVoidConfig.findOrCreate({
    where: { id: AUTO_VOID_ROW_ID },
    defaults: { id: AUTO_VOID_ROW_ID }
  });
  return row;
};
var AutoVoidConfig_default = AutoVoidConfig;

// model/user/SportsAutoVoidState.js
import { DataTypes as DataTypes8 } from "sequelize";
var SportsAutoVoidState = db_default.define("SportsAutoVoidState", {
  eventid: {
    type: DataTypes8.STRING,
    primaryKey: true
  },
  sport_id: {
    type: DataTypes8.STRING,
    allowNull: true
  },
  match_title: {
    type: DataTypes8.STRING,
    allowNull: true
  },
  anchor_market: {
    type: DataTypes8.STRING(32),
    allowNull: false,
    comment: "MATCH_ODDS | BOOKMAKER \u2014 the feed market that started the timer"
  },
  anchor_status: {
    type: DataTypes8.STRING(16),
    allowNull: false,
    comment: "SETTLE | VOID as the feed reported it"
  },
  anchor_seen_at: {
    type: DataTypes8.DATE,
    allowNull: false
  },
  last_fired_at: {
    type: DataTypes8.DATE,
    allowNull: true
  },
  fire_count: {
    type: DataTypes8.INTEGER,
    allowNull: false,
    defaultValue: 0
  },
  bets_voided: {
    type: DataTypes8.INTEGER,
    allowNull: false,
    defaultValue: 0
  },
  void_group_ids: {
    type: DataTypes8.JSONB,
    allowNull: true,
    comment: "bet_void_audit.void_group_id of every group this row fired"
  },
  last_error: {
    type: DataTypes8.TEXT,
    allowNull: true
  }
}, {
  tableName: "sports_auto_void_state",
  timestamps: true
});
var SportsAutoVoidState_default = SportsAutoVoidState;

// services/admin/sportsMarketVoidService.js
import { Op } from "sequelize";

// model/admin/Wallet.js
import { DataTypes as DataTypes11 } from "sequelize";

// model/admin/Staff.js
import { DataTypes as DataTypes10 } from "sequelize";

// model/admin/Role.js
import { DataTypes as DataTypes9 } from "sequelize";
var Role = db_default.define("Role", {
  role_id: {
    type: DataTypes9.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  role: {
    type: DataTypes9.STRING,
    allowNull: false,
    unique: true
  },
  power: {
    type: DataTypes9.JSON,
    allowNull: false,
    defaultValue: []
  },
  level: {
    type: DataTypes9.STRING,
    allowNull: false
  },
  is_owner: {
    type: DataTypes9.BOOLEAN,
    defaultValue: false
  },
  is_company: {
    type: DataTypes9.BOOLEAN,
    defaultValue: false
  },
  max_downline_percentage: {
    type: DataTypes9.DECIMAL(5, 2),
    defaultValue: 100,
    comment: "Max % this role can distribute down"
  }
}, {
  timestamps: false
});
var Role_default = Role;

// model/admin/Staff.js
var Staff = db_default.define("Staff", {
  staff_id: {
    type: DataTypes10.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  username: {
    type: DataTypes10.STRING,
    allowNull: false,
    unique: true
  },
  fullname: {
    type: DataTypes10.STRING,
    allowNull: true
  },
  city: {
    type: DataTypes10.STRING,
    allowNull: true
  },
  // "Mobile Number" on the admin create-account form. The form has always
  // sent it for staff too, but there was no column to keep it in, so More →
  // Additional Information showed a blank Mobile Number for every staff
  // account (user, 2026-09-21). Added by ensureStaffPhoneNumberColumn() in
  // config/dbInit.js, the same idempotent way the other late columns were.
  phone_number: {
    type: DataTypes10.STRING,
    allowNull: true
  },
  email: {
    type: DataTypes10.STRING,
    allowNull: true,
    unique: true,
    validate: {
      isEmail: true
    }
  },
  password: {
    type: DataTypes10.STRING,
    allowNull: false
  },
  role_id: {
    type: DataTypes10.INTEGER,
    allowNull: false,
    references: {
      model: Role_default,
      key: "role_id"
    }
  },
  role: {
    type: DataTypes10.STRING,
    allowNull: false,
    comment: "Denormalized role name for quick lookup (e.g., SUPER_ADMIN, ADMIN, USER)"
  },
  level: {
    type: DataTypes10.STRING,
    allowNull: false,
    comment: "Denormalized level (L1, L2, ..., L6)"
  },
  parent_id: {
    type: DataTypes10.INTEGER,
    allowNull: true
    // ✅ REMOVED the references block - let associations handle it
  },
  parent_owner_id: {
    type: DataTypes10.INTEGER,
    allowNull: true,
    comment: "ID of the owner who created this staff member (if applicable)"
  },
  percentage: {
    type: DataTypes10.DECIMAL(8, 3),
    allowNull: true,
    defaultValue: null
  },
  credit_limit: {
    type: DataTypes10.DECIMAL(15, 2),
    allowNull: false,
    defaultValue: 0,
    comment: "Maximum credit allowed for this staff member"
  },
  active: {
    type: DataTypes10.BOOLEAN,
    allowNull: false,
    defaultValue: true,
    comment: "Indicates if the staff member is active"
  },
  first_login: {
    type: DataTypes10.BOOLEAN,
    defaultValue: false
  },
  // Operator-set permission, ticked on the create-account form. false = this
  // account may NOT change its own password once the mandatory first-login
  // change (first_login: false -> true) is done. Default true so every
  // pre-existing account keeps behaving exactly as before.
  passwordChangeAllowed: {
    type: DataTypes10.BOOLEAN,
    allowNull: false,
    defaultValue: true,
    comment: "false = account cannot change its own password after the first-login change"
  },
  rules_accepted: {
    type: DataTypes10.BOOLEAN,
    defaultValue: false,
    comment: "True once the rules modal has been accepted after login"
  },
  transaction_password: {
    type: DataTypes10.STRING,
    allowNull: true,
    comment: "Stored as plain text"
  },
  txn_password_attempts: {
    type: DataTypes10.INTEGER,
    allowNull: true,
    defaultValue: 10,
    comment: "Transaction password attempts left; 0 locks txn actions + login until the parent changes this staff password (which resets it to 10)"
  },
  // ── Secure auth (2FA) ────────────────────────────────────────────────
  // securityAuthType is the source of truth for HOW this account logs in:
  // 'telegram' | 'google' | null. telegram2FAEnabled/telegramChatId stay as
  // the Telegram transport; googleAuthSecret is the base32 TOTP secret.
  googleAuthSecret: {
    type: DataTypes10.STRING,
    allowNull: true
  },
  securityAuthType: {
    type: DataTypes10.STRING,
    allowNull: true,
    defaultValue: null
  },
  telegramChatId: {
    type: DataTypes10.STRING,
    allowNull: true
  },
  telegram2FAEnabled: {
    type: DataTypes10.BOOLEAN,
    defaultValue: false
  },
  bet_locked: {
    type: DataTypes10.BOOLEAN,
    defaultValue: false,
    comment: "If true, this staff and all downline cannot place bets"
  },
  exp_limit: {
    type: DataTypes10.DECIMAL(20, 2),
    allowNull: true,
    defaultValue: null,
    comment: "Max exposure limit for the staff"
  },
  bal_down: {
    type: DataTypes10.DECIMAL(15, 2),
    allowNull: true,
    defaultValue: 0,
    comment: "Balance down value for the staff member"
  },
  bal_up: {
    type: DataTypes10.DECIMAL(15, 2),
    allowNull: true,
    defaultValue: 0,
    comment: "Balance up value for the staff member"
  },
  login_id: {
    type: DataTypes10.STRING,
    allowNull: true,
    comment: "Unique ID for the current active login session (single-session enforcement)"
  }
}, {
  tableName: "staff",
  // ✅ Explicitly set lowercase table name
  timestamps: true,
  paranoid: true
});
Staff.belongsTo(Role_default, {
  foreignKey: "role_id",
  as: "roleDetails"
});
Staff.belongsTo(Staff, {
  foreignKey: "parent_id",
  as: "parent"
});
Staff.hasMany(Staff, {
  foreignKey: "parent_id",
  as: "children"
});
var Staff_default = Staff;

// model/admin/Wallet.js
function calculateProfitLoss(instance) {
  const cashReceived = parseFloat(instance.getDataValue("cash_received")) || 0;
  const inrBalance = parseFloat(instance.getDataValue("inr_balance")) || 0;
  const profitLoss = parseFloat((inrBalance - cashReceived).toFixed(2));
  const verdict = profitLoss >= 0 ? "profit" : "loss";
  instance.setDataValue("profit_loss", profitLoss);
  instance.setDataValue("verdict", verdict);
}
var Wallet = db_default.define(
  "Wallet",
  {
    wallet_id: {
      type: DataTypes11.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    // Generic Reference Fields
    user_id: { type: DataTypes11.INTEGER, allowNull: true, comment: "Reference for normal user wallet (end user)" },
    staff_id: { type: DataTypes11.INTEGER, allowNull: true, comment: "Reference for staff wallet (admin/supermaster/master)" },
    owner_id: { type: DataTypes11.INTEGER, allowNull: true, comment: "Reference for owner wallet (top-level company or super admin)" },
    // Wallet Classification
    user_type: {
      type: DataTypes11.ENUM("OWNER", "COMPANY", "SUPERADMIN", "ADMIN", "SUPERMASTER", "MASTER", "AGENT", "USER"),
      allowNull: false
    },
    // Wallet Info
    username: { type: DataTypes11.STRING, allowNull: false, unique: true },
    // Core Financial Fields
    inr_balance: { type: DataTypes11.DECIMAL(18, 2), allowNull: false, defaultValue: 0 },
    cash: { type: DataTypes11.DECIMAL(18, 2), allowNull: false, defaultValue: 0 },
    credit: { type: DataTypes11.DECIMAL(18, 2), allowNull: false, defaultValue: 0 },
    cash_received: { type: DataTypes11.DECIMAL(18, 2), allowNull: false, defaultValue: 0 },
    // Initial credit handed over at account creation (set once, first time)
    all_point: { type: DataTypes11.DECIMAL(18, 2), allowNull: false, defaultValue: 0 },
    // Cash settlement ka running total: upper_point = apne upline ke saath hua hisaab,
    // down_point = apne downline ke saath hua hisaab
    upper_point: { type: DataTypes11.DECIMAL(18, 2), allowNull: false, defaultValue: 0 },
    down_point: { type: DataTypes11.DECIMAL(18, 2), allowNull: false, defaultValue: 0 },
    // Category-wise settlement points ka running total
    sports_pts: { type: DataTypes11.DECIMAL(18, 2), allowNull: false, defaultValue: 0 },
    sportsbook_pts: { type: DataTypes11.DECIMAL(18, 2), allowNull: false, defaultValue: 0 },
    // Calculated Metrics
    profit_loss: { type: DataTypes11.DECIMAL(18, 2), allowNull: false, defaultValue: 0 },
    verdict: { type: DataTypes11.ENUM("profit", "loss"), allowNull: false, defaultValue: "profit" },
    // NEW – total commission the user has **received** (cumulative)
    totalCommission: {
      type: DataTypes11.DECIMAL(18, 2),
      allowNull: false,
      defaultValue: 0,
      comment: "Cumulative platform-fee commission earned by this wallet"
    }
  },
  {
    tableName: "Wallets",
    timestamps: true,
    hooks: {
      beforeCreate: calculateProfitLoss,
      beforeUpdate: calculateProfitLoss,
      // Recompute on read so increment()/bulk-update paths cannot serve a stale figure.
      // Fires for instances, raw:true rows and findAll alike (verified against this
      // codebase's query shapes). Rows that did not select the source columns — e.g.
      // aggregate queries like SUM(profit_loss) AS downPL — are skipped untouched.
      afterFind: (result) => {
        if (!result) return result;
        const rows = Array.isArray(result) ? result : [result];
        for (const row of rows) {
          if (!row) continue;
          const isInstance = typeof row.getDataValue === "function";
          const inr = isInstance ? row.getDataValue("inr_balance") : row.inr_balance;
          const recv = isInstance ? row.getDataValue("cash_received") : row.cash_received;
          if (inr === void 0 || recv === void 0) continue;
          const pl = parseFloat(((parseFloat(inr) || 0) - (parseFloat(recv) || 0)).toFixed(2));
          const verdict = pl >= 0 ? "profit" : "loss";
          if (isInstance) {
            row.setDataValue("profit_loss", pl);
            row.setDataValue("verdict", verdict);
            row.changed("profit_loss", false);
            row.changed("verdict", false);
          } else {
            row.profit_loss = pl;
            row.verdict = verdict;
          }
        }
        return result;
      }
    }
  }
);
Wallet.belongsTo(Staff_default, {
  foreignKey: "staff_id",
  as: "staff",
  constraints: false
});
var Wallet_default = Wallet;

// model/user/UserExposure.js
import { DataTypes as DataTypes12 } from "sequelize";
var UserExposure = db_default.define(
  "UserExposure",
  {
    id: {
      type: DataTypes12.INTEGER,
      autoIncrement: true,
      primaryKey: true
    },
    user_id: {
      type: DataTypes12.BIGINT,
      allowNull: false
    },
    match_id: {
      type: DataTypes12.STRING,
      allowNull: false
    },
    event_id: {
      type: DataTypes12.STRING,
      allowNull: true
    },
    team_name: {
      type: DataTypes12.STRING,
      allowNull: false
    },
    exposure_amount: {
      type: DataTypes12.DECIMAL(15, 2),
      allowNull: false,
      defaultValue: 0
    },
    match_title: {
      type: DataTypes12.STRING(255),
      allowNull: true
    },
    game_type: {
      type: DataTypes12.STRING(100),
      allowNull: true
    },
    category: {
      type: DataTypes12.STRING(100),
      allowNull: true
      // or false if DB has NOT NULL
    },
    created_at: {
      type: DataTypes12.DATE,
      allowNull: false,
      defaultValue: DataTypes12.NOW
    },
    updated_at: {
      type: DataTypes12.DATE,
      allowNull: false,
      defaultValue: DataTypes12.NOW
    }
  },
  {
    tableName: "user_exposures",
    timestamps: false,
    // we manually manage timestamps
    indexes: [
      {
        unique: true,
        fields: ["user_id", "match_id", "team_name", "game_type"]
      }
    ]
  }
);
var UserExposure_default = UserExposure;

// model/user/TotalExposure.js
import { DataTypes as DataTypes13 } from "sequelize";
var TotalExposure = db_default.define(
  "TotalExposure",
  {
    id: {
      type: DataTypes13.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    user_id: {
      type: DataTypes13.INTEGER,
      allowNull: false,
      unique: true
      // 🔥 REQUIRED for upsert
    },
    total_exposure: {
      type: DataTypes13.DECIMAL(15, 2),
      // ✅ money-safe
      allowNull: false,
      defaultValue: 0
    }
  },
  {
    tableName: "total_exposures",
    timestamps: true
  }
);
var TotalExposure_default = TotalExposure;

// model/user/CreditsLedger.js
import { DataTypes as DataTypes14 } from "sequelize";
var CreditsLedger = db_default.define(
  "CreditsLedger",
  {
    id: {
      type: DataTypes14.BIGINT,
      primaryKey: true,
      autoIncrement: true
    },
    user_id: {
      type: DataTypes14.TEXT,
      allowNull: false
    },
    bet_id: {
      type: DataTypes14.BIGINT,
      allowNull: true,
      comment: "Related bet ID for this ledger entry"
    },
    currency: {
      type: DataTypes14.TEXT,
      allowNull: true,
      defaultValue: "INR"
    },
    amount: {
      type: DataTypes14.DECIMAL,
      allowNull: false,
      comment: "Raw transaction amount (+win / -loss)"
    },
    reason: {
      type: DataTypes14.TEXT,
      allowNull: false
    },
    description: {
      type: DataTypes14.TEXT,
      allowNull: true
    },
    eventid: {
      type: DataTypes14.TEXT,
      allowNull: true
    },
    job_id: {
      type: DataTypes14.UUID,
      allowNull: true
    },
    match_id: {
      type: DataTypes14.TEXT,
      allowNull: true
    },
    meta: {
      type: DataTypes14.JSONB,
      allowNull: true
    },
    market_type: {
      type: DataTypes14.TEXT,
      allowNull: true
    },
    sport_id: {
      type: DataTypes14.TEXT,
      allowNull: true
    },
    commission: {
      type: DataTypes14.DECIMAL(18, 2),
      allowNull: true,
      comment: "2% platform fee deducted from winning amount (NULL for losses / non-win)"
    },
    netamount: {
      type: DataTypes14.DECIMAL(18, 2),
      allowNull: true,
      comment: "Amount credited after commission (amount - commission). NULL for non-win"
    },
    profit: {
      type: DataTypes14.DECIMAL(18, 2),
      allowNull: true,
      comment: "Winning amount (only for wins)"
    },
    loss: {
      type: DataTypes14.DECIMAL(18, 2),
      allowNull: true,
      comment: "Loss amount (only for losses)"
    },
    closing: {
      type: DataTypes14.DECIMAL(18, 2),
      allowNull: true,
      comment: "Closing amount (only for current user proffit ratio)"
    },
    category: {
      type: DataTypes14.STRING(20),
      allowNull: true,
      comment: "SPORTS - identifies settlement source"
    },
    points_applied: {
      type: DataTypes14.BOOLEAN,
      allowNull: false,
      defaultValue: false
    },
    balance: {
      type: DataTypes14.DECIMAL(18, 2),
      allowNull: true,
      defaultValue: 0,
      comment: "User wallet balance after this ledger entry"
    },
    created_at: {
      type: DataTypes14.DATE,
      allowNull: true,
      defaultValue: DataTypes14.NOW
    }
  },
  {
    tableName: "credits_ledger",
    timestamps: false,
    indexes: [
      { name: "credits_ledger_user_id_idx", fields: ["user_id"] },
      { name: "credits_ledger_eventid_idx", fields: ["eventid"] },
      { name: "credits_ledger_created_at_idx", fields: ["created_at"] }
    ]
  }
);
var CreditsLedger_default = CreditsLedger;

// helper/lineMarket.js
var isLineMarket = (marketType) => /\bline$/i.test(String(marketType || "").trim());
var LINE_EXPOSURE_GAME_TYPE = "fancy2";
var exposureIdentity = ({ marketType, selectionName, badlo = false }) => isLineMarket(marketType) ? { game_type: LINE_EXPOSURE_GAME_TYPE, team_name: String(marketType) } : { game_type: marketType, team_name: selectionName };

// helper/badloMarket.js
var BADLO_EXPOSURE_GAME_TYPE = "badlo";

// helper/exposureBucket.js
var PER_SELECTION_MARKETS = /* @__PURE__ */ new Set([
  "Normal",
  "Ball By Ball",
  "Over By Over",
  "khado",
  "meter",
  "fancy1",
  "oddeven",
  "badlo"
]);
var isPerSelectionMarket = (marketType) => PER_SELECTION_MARKETS.has(String(marketType || "")) || isLineMarket(marketType);
var selectionExposureRows = (sel) => [sel, `${sel}lay`, `${sel}back`, `${sel}totalstake`];
var isHelperExposureRow = (teamName) => /(?:lay|back|totalstake)$/i.test(String(teamName || ""));
var releasableLiability = (exposures, { perSelection, sel } = {}) => {
  if (perSelection) {
    const base = exposures.find((e) => e.team_name === sel);
    return Math.min(0, parseFloat(base?.exposure_amount || 0));
  }
  return exposures.reduce(
    (min, e) => Math.min(min, parseFloat(e.exposure_amount || 0)),
    0
  );
};
var additiveBucketLiability = (exposures) => exposures.reduce((sum, e) => {
  if (isHelperExposureRow(e.team_name)) return sum;
  const val = parseFloat(e.exposure_amount || 0);
  return val < 0 ? sum + val : sum;
}, 0);

// helper/totalExposure.js
import { QueryTypes } from "sequelize";
var TOTAL_EXPOSURE_SQL = `
  SELECT COALESCE(SUM(market_exposure), 0) AS total_exposure
  FROM (
    /* Team markets (match odds / bookmaker \u2026): only the worst runner is at
       risk, so they are grouped per market. */
    SELECT MIN(exposure_amount) AS market_exposure
    FROM user_exposures
    WHERE
      user_id = :user_id
      AND game_type IS NOT NULL
      AND (category IS NOT NULL OR game_type LIKE '%:%')
      AND game_type NOT IN (
        'Normal', 'Ball By Ball', 'Over By Over',
        'khado', 'meter', 'fancy1', 'oddeven', 'fancy2', 'badlo'
      )
      AND game_type NOT LIKE '%Overs Line%'
      AND NOT (
        team_name ILIKE '%back'
        OR team_name ILIKE '%lay'
        OR team_name ILIKE '%totalstake'
      )
    GROUP BY match_id, game_type, event_id

    UNION ALL

    /* Independent rows: fancy-family markets (one row each). */
    SELECT exposure_amount AS market_exposure
    FROM user_exposures
    WHERE
      user_id = :user_id
      AND (
        game_type IS NULL
        OR game_type IN (
          'Normal', 'Ball By Ball', 'Over By Over',
          'khado', 'meter', 'fancy1', 'oddeven', 'fancy2', 'badlo'
        )
        OR game_type LIKE '%Overs Line%'
      )
      AND NOT (
        team_name ILIKE '%back'
        OR team_name ILIKE '%lay'
        OR team_name ILIKE '%totalstake'
      )
  ) subquery;
`;
var recalcTotalExposure = async (userId, transaction = null) => {
  const opts = transaction ? { transaction } : {};
  const rows = await db_default.query(TOTAL_EXPOSURE_SQL, {
    replacements: { user_id: String(userId) },
    type: QueryTypes.SELECT,
    ...opts
  });
  const total = parseFloat(rows[0]?.total_exposure) || 0;
  await TotalExposure_default.upsert(
    { user_id: Number(userId), total_exposure: total },
    opts
  );
  return total;
};

// services/admin/voidAuditService.js
import { randomUUID } from "crypto";

// model/admin/BetVoidAudit.js
import { DataTypes as DataTypes15 } from "sequelize";
var VOID_TYPES = {
  OPEN_BET: "OPEN_BET",
  // POST /void-single-bet
  MARKET: "MARKET",
  // POST /void  (market / one fancy session)
  AFTER_SETTLEMENT: "AFTER_SETTLEMENT",
  // POST /void-bet-after-settlement, /void-market-after-settlement
  FEED_SUSPENDED: "FEED_SUSPENDED",
  // settlementv2: provider declared the market SUSPENDED
  AUTO_TIMEOUT: "AUTO_TIMEOUT"
  // autoVoid.js: still open N s after MATCH_ODDS/BOOKMAKER declared
};
var money = { type: DataTypes15.DECIMAL(15, 2), allowNull: true };
var BetVoidAudit = db_default.define(
  "BetVoidAudit",
  {
    id: { type: DataTypes15.BIGINT, autoIncrement: true, primaryKey: true },
    // ── which void operation ────────────────────────────────────────────────
    void_group_id: { type: DataTypes15.UUID, allowNull: false },
    is_representative: { type: DataTypes15.BOOLEAN, allowNull: false, defaultValue: false },
    void_type: { type: DataTypes15.STRING(32), allowNull: false },
    // ── which bet ───────────────────────────────────────────────────────────
    bet_id: { type: DataTypes15.BIGINT, allowNull: false },
    bet_kind: { type: DataTypes15.STRING(16), allowNull: false, defaultValue: "SPORTS" },
    user_id: { type: DataTypes15.BIGINT, allowNull: false },
    username: { type: DataTypes15.STRING(255), allowNull: true },
    // Bet identity FROZEN at void time. Denormalised on purpose: a report must
    // still read correctly if the bet row is later edited or purged.
    match_id: { type: DataTypes15.STRING(255), allowNull: true },
    eventid: { type: DataTypes15.STRING(255), allowNull: true },
    match_title: { type: DataTypes15.STRING(255), allowNull: true },
    market_type: { type: DataTypes15.STRING(255), allowNull: true },
    game_type: { type: DataTypes15.STRING(100), allowNull: true },
    selection_name: { type: DataTypes15.STRING(255), allowNull: true },
    bet_type: { type: DataTypes15.STRING(32), allowNull: true },
    odds: { type: DataTypes15.DECIMAL(15, 4), allowNull: true },
    stake_amount: money,
    liability: money,
    // ── PRE ─────────────────────────────────────────────────────────────────
    status_before: { type: DataTypes15.STRING(32), allowNull: true },
    result_status_before: { type: DataTypes15.STRING(32), allowNull: true },
    cash_before: money,
    inr_before: money,
    // The bucket's own liability (the `sel` row for a per-selection market, the
    // worst row for MO/BM) — what this void was actually holding.
    exposure_before: money,
    total_exposure_before: money,
    // ── POST ────────────────────────────────────────────────────────────────
    status_after: { type: DataTypes15.STRING(32), allowNull: true },
    result_status_after: { type: DataTypes15.STRING(32), allowNull: true },
    cash_after: money,
    inr_after: money,
    exposure_after: money,
    total_exposure_after: money,
    // Money returned FOR THE GROUP (repeated on each row of the group — sum over
    // DISTINCT void_group_id). 0 is a legitimate value: a void of a bet whose
    // liability was already held by nothing releases nothing.
    refund_amount: { type: DataTypes15.DECIMAL(15, 2), allowNull: true },
    exposure_rows_deleted: { type: DataTypes15.INTEGER, allowNull: true },
    // credits_ledger row this void wrote, when it wrote one.
    ledger_id: { type: DataTypes15.BIGINT, allowNull: true },
    // ── who and how ─────────────────────────────────────────────────────────
    actor: { type: DataTypes15.STRING(255), allowNull: true },
    actor_role: { type: DataTypes15.STRING(64), allowNull: true },
    ip_address: { type: DataTypes15.STRING(64), allowNull: true },
    browser: { type: DataTypes15.TEXT, allowNull: true },
    note: { type: DataTypes15.TEXT, allowNull: true },
    // Historical rows reconstructed from SportsBet + credits_ledger. Their
    // wallet/exposure columns are NULL and must not be read as zero.
    backfilled: { type: DataTypes15.BOOLEAN, allowNull: false, defaultValue: false },
    created_at: { type: DataTypes15.DATE, allowNull: false, defaultValue: DataTypes15.NOW }
  },
  {
    tableName: "bet_void_audit",
    timestamps: false,
    indexes: [
      // Reports filter by time first, then narrow.
      { fields: ["created_at"] },
      { fields: ["user_id", "created_at"] },
      { fields: ["void_group_id"] },
      { fields: ["void_type", "created_at"] },
      // The tracker joins from SportsBet to "did this void get audited?".
      { fields: ["bet_kind", "bet_id"] }
    ]
  }
);
var BetVoidAudit_default = BetVoidAudit;

// services/admin/voidAuditService.js
var newVoidGroupId = () => randomUUID();
var num = (v) => v === null || v === void 0 || v === "" ? null : Number(v);
var recordVoidAudit = async ({
  voidGroupId,
  voidType,
  bets = [],
  representativeBetId = null,
  before = {},
  after = {},
  refundAmount = null,
  exposureRowsDeleted = null,
  ledgerId = null,
  context = {},
  betKind = "SPORTS",
  backfilled = false
}, t = null) => {
  if (!bets.length) return [];
  const rows = bets.map((b) => ({
    void_group_id: voidGroupId,
    is_representative: representativeBetId != null && Number(b.id) === Number(representativeBetId),
    void_type: voidType,
    bet_id: b.id,
    bet_kind: betKind,
    user_id: b.user_id,
    username: context.username || b.username || null,
    match_id: b.match_id != null ? String(b.match_id) : null,
    eventid: b.eventid != null ? String(b.eventid) : b.event_id != null ? String(b.event_id) : null,
    match_title: b.match_title || b.event_name || null,
    market_type: b.market_type || null,
    game_type: b.game_type || null,
    // sports rows call it `selection_name` (`selection` kept as a fallback).
    selection_name: b.selection_name || b.selection || null,
    bet_type: b.bet_type || null,
    odds: num(b.odds),
    stake_amount: num(b.stake_amount ?? b.stake),
    liability: num(b.liability ?? b.exposer),
    status_before: before.status ?? b.status ?? null,
    result_status_before: before.resultStatus ?? b.result_status ?? null,
    cash_before: num(before.cash),
    inr_before: num(before.inr),
    exposure_before: num(before.exposure),
    total_exposure_before: num(before.totalExposure),
    status_after: after.status ?? null,
    result_status_after: after.resultStatus ?? null,
    cash_after: num(after.cash),
    inr_after: num(after.inr),
    exposure_after: num(after.exposure),
    total_exposure_after: num(after.totalExposure),
    refund_amount: num(refundAmount),
    exposure_rows_deleted: exposureRowsDeleted == null ? null : Number(exposureRowsDeleted),
    ledger_id: ledgerId == null ? null : Number(ledgerId),
    actor: context.actor || null,
    actor_role: context.actor_role || null,
    ip_address: context.ip_address || null,
    browser: context.browser || null,
    note: context.note || null,
    backfilled,
    created_at: /* @__PURE__ */ new Date()
  }));
  return BetVoidAudit_default.bulkCreate(rows, t ? { transaction: t } : {});
};

// services/admin/sportsMarketVoidService.js
var recordVoidRefund = async ({ uid, refundAmount, bet, actor, source = "manual_void", label = "MANUAL VOID" }, t) => {
  if (!(Number(refundAmount) > 0)) return null;
  const wallet = await Wallet_default.findOne({
    where: { user_id: uid },
    attributes: ["wallet_id", "cash"],
    transaction: t
  });
  const marketType = bet?.market_type || null;
  const selection = bet?.selection_name ? ` / ${bet.selection_name}` : "";
  const title = bet?.match_title || bet?.event_name || "match";
  const ledgerRow = await CreditsLedger_default.create({
    user_id: String(uid),
    currency: "INR",
    amount: refundAmount,
    reason: "refund",
    description: `${label} \u2014 ${title} / ${marketType || "-"}${selection}`,
    eventid: bet?.eventid ? String(bet.eventid) : null,
    match_id: bet?.match_id ? String(bet.match_id) : null,
    market_type: marketType,
    bet_id: bet?.id ?? null,
    meta: {
      source,
      voided_by: actor || "owner",
      exposure_released: Number(refundAmount)
    },
    netamount: refundAmount,
    closing: wallet ? Number(wallet.cash) : null,
    profit: null,
    loss: null,
    category: "SPORTS"
  }, { transaction: t });
  return ledgerRow?.id ?? null;
};
var voidOpenMarket = async ({
  match_id,
  market_type,
  gametype = null,
  selection_name = null,
  voidType = VOID_TYPES.MARKET,
  context = {},
  note = null,
  ledgerSource = "manual_void",
  ledgerLabel = "MANUAL VOID"
}) => {
  if (!match_id || !market_type) {
    throw new Error("Missing required fields: match_id, market_type");
  }
  const t = await db_default.transaction();
  try {
    const whereClause = {
      match_id,
      market_type,
      status: "open"
    };
    if (gametype) {
      whereClause.game_type = gametype;
    }
    if (selection_name) {
      whereClause.selection_name = selection_name;
    }
    const bets = await SportsBet_default.findAll({
      where: whereClause,
      attributes: ["user_id"],
      group: ["user_id"],
      transaction: t
    });
    const userIds = bets.map((b) => b.user_id);
    const marketIsPerSelection = isPerSelectionMarket(market_type);
    const scopedToSelection = Boolean(selection_name) && marketIsPerSelection;
    const { game_type: bucketGameType, team_name: bucketSel } = exposureIdentity({
      marketType: market_type,
      selectionName: selection_name || null
    });
    const voidGroupId = newVoidGroupId();
    const auditCtx = context || {};
    const actorName = auditCtx.actor || null;
    const auditPending = [];
    for (const uid of userIds) {
      const walletBefore = await Wallet_default.findOne({
        where: { user_id: uid },
        attributes: ["cash", "inr_balance"],
        transaction: t
      });
      const snapBefore = await TotalExposure_default.findOne({
        where: { user_id: uid },
        attributes: ["total_exposure"],
        transaction: t
      });
      let refundAmount = 0;
      let ledgerId = null;
      let exposureRowsDeleted = 0;
      let exposureBefore = null;
      const exposureWhere = {
        user_id: uid,
        match_id,
        game_type: bucketGameType
      };
      let perSelection = scopedToSelection;
      if (scopedToSelection) {
        exposureWhere.team_name = { [Op.in]: selectionExposureRows(bucketSel) };
      }
      let exposures = await UserExposure_default.findAll({
        where: exposureWhere,
        transaction: t
      });
      if (!exposures.length && exposureWhere.game_type !== market_type) {
        exposureWhere.game_type = market_type;
        delete exposureWhere.team_name;
        perSelection = false;
        exposures = await UserExposure_default.findAll({
          where: exposureWhere,
          transaction: t
        });
        if (exposures.length) {
          console.warn(
            "[voidOpenMarket] released a PRE-MIGRATION line exposure row",
            { uid, match_id, market_type }
          );
        }
      }
      const badloSels = (await SportsBet_default.findAll({
        where: { ...whereClause, user_id: uid, badlo: true },
        attributes: ["selection_name"],
        group: ["selection_name"],
        transaction: t
      })).map((b) => b.selection_name);
      let badloWhere = null;
      let badloExposures = [];
      if (badloSels.length > 0) {
        badloWhere = {
          user_id: uid,
          match_id,
          game_type: BADLO_EXPOSURE_GAME_TYPE,
          team_name: {
            [Op.in]: badloSels.flatMap((s) => selectionExposureRows(
              exposureIdentity({ marketType: market_type, selectionName: s, badlo: true }).team_name
            ))
          }
        };
        badloExposures = await UserExposure_default.findAll({
          where: badloWhere,
          transaction: t
        });
      }
      if (exposures.length > 0 || badloExposures.length > 0) {
        let minExp;
        if (perSelection) {
          minExp = releasableLiability(exposures, { perSelection: true, sel: bucketSel });
        } else if (marketIsPerSelection) {
          minExp = additiveBucketLiability(exposures);
        } else {
          minExp = releasableLiability(exposures, { perSelection: false });
        }
        minExp += additiveBucketLiability(badloExposures);
        exposureBefore = minExp;
        if (minExp < 0) {
          refundAmount = Math.abs(minExp);
          await Wallet_default.increment("cash", {
            by: refundAmount,
            where: { user_id: uid },
            transaction: t
          });
          const repBet = await SportsBet_default.findOne({
            where: { ...whereClause, user_id: uid },
            order: [["id", "ASC"]],
            transaction: t
          });
          ledgerId = await recordVoidRefund({
            uid,
            refundAmount,
            bet: repBet,
            actor: actorName,
            source: ledgerSource,
            label: ledgerLabel
          }, t);
        }
        if (exposures.length > 0) {
          exposureRowsDeleted = await UserExposure_default.destroy({
            where: exposureWhere,
            transaction: t
          });
        }
        if (badloExposures.length > 0) {
          exposureRowsDeleted += await UserExposure_default.destroy({
            where: badloWhere,
            transaction: t
          });
        }
      }
      const userBets = await SportsBet_default.findAll({
        where: { ...whereClause, user_id: uid },
        transaction: t
      });
      auditPending.push({
        uid,
        userBets,
        walletBefore,
        snapBefore,
        refundAmount,
        ledgerId,
        exposureRowsDeleted,
        exposureBefore,
        representativeBetId: userBets.length ? Math.min(...userBets.map((b) => Number(b.id))) : null
      });
    }
    await SportsBet_default.update(
      {
        status: "closed",
        result_status: "refunded",
        match_end_time: /* @__PURE__ */ new Date()
      },
      {
        where: whereClause,
        transaction: t
      }
    );
    const totalsAfter = {};
    for (const uid of userIds) {
      totalsAfter[uid] = await recalcTotalExposure(uid, t);
    }
    let auditedBets = 0;
    for (const a of auditPending) {
      const walletAfter = await Wallet_default.findOne({
        where: { user_id: a.uid },
        attributes: ["cash", "inr_balance"],
        transaction: t
      });
      await recordVoidAudit({
        voidGroupId,
        voidType,
        bets: a.userBets,
        representativeBetId: a.representativeBetId,
        before: {
          status: "open",
          resultStatus: "pending",
          cash: a.walletBefore?.cash,
          inr: a.walletBefore?.inr_balance,
          exposure: a.exposureBefore,
          totalExposure: a.snapBefore?.total_exposure
        },
        after: {
          status: "closed",
          resultStatus: "refunded",
          cash: walletAfter?.cash,
          inr: walletAfter?.inr_balance,
          exposure: a.exposureRowsDeleted > 0 ? 0 : a.exposureBefore,
          totalExposure: totalsAfter[a.uid]
        },
        refundAmount: a.refundAmount,
        exposureRowsDeleted: a.exposureRowsDeleted,
        ledgerId: a.ledgerId,
        context: {
          ...auditCtx,
          note: note || (selection_name ? `session void: ${selection_name}` : `whole ${market_type} market`)
        }
      }, t);
      auditedBets += a.userBets.length;
    }
    await t.commit();
    return { userIds, betsVoided: auditedBets, voidGroupId };
  } catch (error) {
    await t.rollback();
    throw error;
  }
};

// sportsbet/betresult/autoVoid.js
var ANCHOR_MARKETS = {
  MATCH_ODDS: "on_match_odds",
  BOOKMAKER: "on_bookmaker"
};
var ANCHOR_DONE = /* @__PURE__ */ new Set(["SETTLE", "VOID"]);
var CONFIG_TTL_MS = +(process.env.AUTO_VOID_CONFIG_TTL_MS || 1e4);
function anchorStatuses(markets) {
  const out = {};
  for (const m of Array.isArray(markets) ? markets : []) {
    const name = String(m?.mname || "").trim().toUpperCase();
    if (!(name in ANCHOR_MARKETS)) continue;
    const status = String(m?.status || "").toUpperCase();
    if (!out[name] || ANCHOR_DONE.has(status)) out[name] = status;
  }
  return out;
}
async function ensureAutoVoidTables() {
  await AutoVoidConfig_default.sync();
  await db_default.query("ALTER TABLE auto_void_config ADD COLUMN IF NOT EXISTS enabled_at TIMESTAMPTZ");
  await SportsAutoVoidState_default.sync();
}
function voidDueAt(anchorSeenAt, c) {
  const seen = new Date(anchorSeenAt).getTime();
  const on = c?.enabled_at ? new Date(c.enabled_at).getTime() : 0;
  const delayMs = Math.max(0, Number(c?.delay_seconds) || 0) * 1e3;
  return new Date(Math.max(seen, on) + delayMs);
}
function createAutoVoid({ log: log2 }) {
  let cfg = null;
  let cfgAt = 0;
  async function config() {
    if (cfg && Date.now() - cfgAt < CONFIG_TTL_MS) return cfg;
    cfg = (await getAutoVoidConfig()).get({ plain: true });
    cfgAt = Date.now();
    return cfg;
  }
  function pickAnchor(anchors, c) {
    for (const [mname, flag] of Object.entries(ANCHOR_MARKETS)) {
      if (!c[flag]) continue;
      const status = anchors?.[mname];
      if (status && ANCHOR_DONE.has(status)) return { market: mname, status };
    }
    return null;
  }
  function groupBets(bets) {
    const groups = /* @__PURE__ */ new Map();
    for (const b of bets) {
      const perSel = isPerSelectionMarket(b.market_type);
      const key = [b.match_id, b.market_type, b.game_type, perSel ? b.selection_name : ""].join("|");
      let g = groups.get(key);
      if (!g) {
        g = {
          match_id: b.match_id,
          market_type: b.market_type,
          gametype: b.game_type,
          selection_name: perSel ? b.selection_name : null,
          betIds: []
        };
        groups.set(key, g);
      }
      g.betIds.push(b.id);
    }
    return [...groups.values()];
  }
  async function afterScan(events) {
    let c;
    try {
      c = await config();
    } catch (e) {
      log2.error("[AutoVoid] config read failed", { error: e.message });
      return;
    }
    for (const ev of events.values()) {
      try {
        if (!ev.anchors) continue;
        const anchor = pickAnchor(ev.anchors, c);
        if (!anchor) continue;
        const now = /* @__PURE__ */ new Date();
        let state = await SportsAutoVoidState_default.findOne({ where: { eventid: String(ev.eventid) } });
        if (!state) {
          state = await SportsAutoVoidState_default.create({
            eventid: String(ev.eventid),
            sport_id: ev.sport_id != null ? String(ev.sport_id) : null,
            match_title: ev.match_title || null,
            anchor_market: anchor.market,
            anchor_status: anchor.status,
            anchor_seen_at: now
          });
          log2.info("[AutoVoid] armed", {
            eventid: ev.eventid,
            anchor: anchor.market,
            status: anchor.status,
            enabled: !!c.enabled,
            fireAt: voidDueAt(now, c).toISOString(),
            pending: ev.pending.length
          });
        }
        if (!c.enabled) continue;
        if (now < voidDueAt(state.anchor_seen_at, c)) continue;
        if (!ev.pending.length) continue;
        const elapsed = now - new Date(state.anchor_seen_at);
        const groups = groupBets(ev.pending);
        const seenAt = new Date(state.anchor_seen_at).toISOString();
        const note = `auto void: ${state.anchor_market} ${state.anchor_status} seen ${seenAt}, +${Math.round(elapsed / 1e3)}s`;
        const groupIds = [];
        let betsVoided = 0;
        let lastError = null;
        for (const g of groups) {
          try {
            const r = await voidOpenMarket({
              match_id: g.match_id,
              market_type: g.market_type,
              gametype: g.gametype,
              selection_name: g.selection_name,
              voidType: VOID_TYPES.AUTO_TIMEOUT,
              context: { actor: "auto-void", actor_role: "system" },
              note,
              ledgerSource: "auto_void",
              ledgerLabel: "AUTO VOID"
            });
            groupIds.push(r.voidGroupId);
            betsVoided += r.betsVoided;
            log2.info("[AutoVoid] voided market", {
              eventid: ev.eventid,
              match_id: g.match_id,
              market_type: g.market_type,
              selection: g.selection_name,
              users: r.userIds.length,
              bets: r.betsVoided,
              voidGroupId: r.voidGroupId
            });
          } catch (e) {
            lastError = `${g.market_type}${g.selection_name ? " / " + g.selection_name : ""}: ${e.message}`;
            log2.error("[AutoVoid] void failed", {
              eventid: ev.eventid,
              match_id: g.match_id,
              market_type: g.market_type,
              selection: g.selection_name,
              error: e.message
            });
          }
        }
        await state.update({
          last_fired_at: now,
          fire_count: (state.fire_count || 0) + 1,
          bets_voided: (state.bets_voided || 0) + betsVoided,
          void_group_ids: [...state.void_group_ids || [], ...groupIds],
          last_error: lastError
        });
      } catch (e) {
        log2.error("[AutoVoid] event failed", { eventid: ev.eventid, error: e.message });
      }
    }
  }
  return { afterScan };
}

// helper/lineResult.js
var LINE_RE = /^(1st|2nd)\s+innings\s+(\d+)\s+overs?\s+line$/i;
var TEAM_TOTAL_RE = /^(\d+)\s+OVER\s+RUN\s+(.+?)(?:\s+ADV)?$/i;
var INNINGS_OVER_RE = /^(1ST|2ND)\s+INN\s+(\d+)\s+OVER\b/i;
var MULTI_INNINGS_RE = /\b(3RD|4TH)\s+INN/;
var ODDEVEN_RE = /^(1ST|2ND)\s+INN\s+(\d+)\s+OVER\s+RUN\s+ODD\s+EVEN$/i;
var norm = (s) => String(s || "").trim().replace(/\s+/g, " ").toUpperCase();
var inningsNo = (s) => /^1/.test(s) ? 1 : 2;
function parseLineMarket(marketType) {
  const m = LINE_RE.exec(String(marketType || "").trim());
  return m ? { innings: inningsNo(m[1]), overs: Number(m[2]) } : null;
}
function teamTotals(markets) {
  const out = /* @__PURE__ */ new Map();
  for (const m of markets) {
    if (norm(m?.gtype) !== "FANCY") continue;
    const name = norm(m?.marketName);
    if (name.includes("BHAV")) continue;
    const t = TEAM_TOTAL_RE.exec(name);
    if (!t) continue;
    const overs = Number(t[1]);
    const team = t[2].replace(/[.:\-]+$/, "").trim();
    if (/\s2$/.test(team)) continue;
    if (!out.has(overs)) out.set(overs, /* @__PURE__ */ new Map());
    const byTeam = out.get(overs);
    const runs = m?.status === "SETTLE" ? Number(m?.winnerId) : null;
    const prev = byTeam.get(team);
    if (prev && prev.runs !== runs) byTeam.set(team, { status: "CONFLICT", runs: null });
    else byTeam.set(team, { status: m?.status, runs });
  }
  return out;
}
function inningsEvidence(markets) {
  const ev = { 1: /* @__PURE__ */ new Map(), 2: /* @__PURE__ */ new Map() };
  const add = (inn, overs, fn) => {
    if (!ev[inn].has(overs)) ev[inn].set(overs, []);
    ev[inn].get(overs).push(fn);
  };
  for (const m of markets) {
    if (m?.status !== "SETTLE") continue;
    const g = norm(m?.gtype);
    if (g === "CRICKETCASINO") {
      const c = INNINGS_OVER_RE.exec(norm(m?.mname));
      const d = /^(\d)\s+NUMBER$/.exec(norm(m?.winnerName));
      if (c && d) add(inningsNo(c[1]), Number(c[2]), (runs) => runs % 10 === Number(d[1]));
    } else if (g === "ODDEVEN") {
      const o = ODDEVEN_RE.exec(norm(m?.marketName));
      const w = Number(m?.winnerId);
      if (o && (w === 1 || w === 2)) add(inningsNo(o[1]), Number(o[2]), (runs) => runs % 2 === 1 === (w === 1));
    }
  }
  return ev;
}
function score(inn, team, totals, ev) {
  let checked = 0, miss = 0;
  for (const [overs, checks] of ev[inn]) {
    const mine = totals.get(overs)?.get(team);
    if (!mine || mine.status !== "SETTLE" || !Number.isFinite(mine.runs)) continue;
    for (const check of checks) {
      checked++;
      if (!check(mine.runs)) miss++;
    }
  }
  return { checked, miss };
}
var MIN_CLUES = 2;
function battingOrder(markets) {
  if (markets.some((m) => MULTI_INNINGS_RE.test(norm(m?.mname)) || MULTI_INNINGS_RE.test(norm(m?.marketName)))) return null;
  const totals = teamTotals(markets);
  const teams = /* @__PURE__ */ new Set();
  for (const byTeam of totals.values()) for (const t of byTeam.keys()) teams.add(t);
  if (teams.size < 1 || teams.size > 2) return null;
  const ev = inningsEvidence(markets);
  const order = { 1: null, 2: null, totals };
  for (const team of teams) {
    const s1 = score(1, team, totals, ev);
    const s2 = score(2, team, totals, ev);
    const is1 = s1.checked >= MIN_CLUES && s1.miss === 0 && s2.miss > 0;
    const is2 = s2.checked >= MIN_CLUES && s2.miss === 0 && s1.miss > 0;
    if (is1 && is2) return null;
    const inn = is1 ? 1 : is2 ? 2 : null;
    if (!inn) continue;
    if (order[inn]) return null;
    order[inn] = team;
  }
  if (teams.size === 2 && (order[1] ? !order[2] : order[2])) {
    const known = order[1] ? 1 : 2;
    const inn = known === 1 ? 2 : 1;
    const other = [...teams].find((t) => t !== order[known]);
    if (score(inn, other, totals, ev).miss === 0) order[inn] = other;
  }
  return order[1] || order[2] ? order : null;
}
function resolveLineMarketFromFeed(markets, marketType) {
  const line = parseLineMarket(marketType);
  if (!line || !Array.isArray(markets)) return null;
  const order = battingOrder(markets);
  if (!order) return null;
  const team = order[line.innings];
  if (!team) return null;
  const row = order.totals.get(line.overs)?.get(team);
  if (!row) return null;
  const derived = `${line.overs} OVER RUN ${team}`;
  if (row.status === "VOID") {
    return { gtype: "LINE", mname: marketType, marketName: "TOTAL RUNS", status: "VOID", winnerId: null, winnerName: null, derivedFrom: derived };
  }
  if (row.status !== "SETTLE" || !Number.isFinite(row.runs)) return null;
  return { gtype: "LINE", mname: marketType, marketName: "TOTAL RUNS", status: "SETTLE", winnerId: row.runs, winnerName: null, derivedFrom: derived };
}

// sportsbet/betresult/settlementQueue.js
import IORedis from "ioredis";
import { Op as Op2 } from "sequelize";
var WAKE_CHANNEL = `sports-settle:wake:${process.env.DB_NAME || "default"}`;
var REARM_AFTER_MS = +(process.env.REARM_AFTER_MS || 2e4);
var noopLog = { info: () => {
}, error: () => {
}, debug: () => {
} };
var pub = null;
function getPublisher(log2 = noopLog) {
  if (pub) return pub;
  try {
    pub = new IORedis({
      host: process.env.REDIS_HOST || "127.0.0.1",
      port: +(process.env.REDIS_PORT || 6379),
      maxRetriesPerRequest: null
    });
    pub.on("error", (e) => log2.error("[SettleQueue] redis wake error", { error: e.message }));
  } catch (e) {
    log2.error("[SettleQueue] redis wake unavailable", { error: e.message });
    pub = null;
  }
  return pub;
}
async function wakeSettlement(count, log2 = noopLog) {
  const p = getPublisher(log2);
  if (!p) return;
  try {
    await p.publish(WAKE_CHANNEL, String(count));
    log2.info("[SettleQueue] settlement worker woken", { count, channel: WAKE_CHANNEL });
  } catch (e) {
    log2.error("[SettleQueue] wake publish failed", { error: e.message });
  }
}
async function enqueueSettlementJob(b, declared, log2 = noopLog) {
  const userId = String(b.user_id);
  const eid = String(b.eventid);
  const betIdStr = String(b.id);
  const betType = (b.bet_type || "").toString().toLowerCase() || "unknown";
  const payload = { user_id: userId, eventid: eid, bet_id: betIdStr, bet_type: betType, bet: b, match_over: declared };
  const now = /* @__PURE__ */ new Date();
  const pointBet = (jobId) => SportsBet_default.update(
    { job_id: jobId },
    { where: { id: b.id, status: { [Op2.in]: ["open", "manual"] } } }
  );
  const existing = await SportsEventSettlementJobs_default.findOne({
    where: { user_id: userId, eventid: eid, bet_id: betIdStr },
    attributes: ["job_id", "status", "updated_at"]
  });
  if (existing && (existing.status === "queued" || existing.status === "processing")) {
    if (String(b.job_id || "") !== String(existing.job_id)) await pointBet(existing.job_id);
    return { jobId: existing.job_id, action: "already-live" };
  }
  if (existing) {
    const age = Date.now() - new Date(existing.updated_at).getTime();
    if (age < REARM_AFTER_MS) return { jobId: existing.job_id, action: "cooldown" };
    await existing.update({ status: "queued", run_after: now, updated_at: now, error_msg: null, payload });
    await pointBet(existing.job_id);
    return { jobId: existing.job_id, action: "re-armed" };
  }
  let job;
  try {
    job = await SportsEventSettlementJobs_default.create({
      user_id: userId,
      eventid: eid,
      bet_id: betIdStr,
      bet_type: betType,
      status: "queued",
      priority: 5,
      run_after: now,
      payload,
      created_at: now,
      updated_at: now
    });
  } catch (e) {
    if (e.name === "SequelizeUniqueConstraintError") return { action: "race-skip" };
    throw e;
  }
  await pointBet(job.job_id);
  return { jobId: job.job_id, action: "created" };
}

// sportsbet/betresult/newjobv2.js
process.on("uncaughtException", (err) => {
  console.error("[ResultCron] Uncaught Exception:", err);
});
process.on("unhandledRejection", (err) => {
  console.error("[ResultCron] Unhandled Rejection:", err);
});
console.log("[ResultCron] Process started");
var DEBUG = process.env.DEBUG === "1" || process.env.DEBUG === "true";
var LOG_DIR = process.env.RESULTS_CRON_LOG_DIR || path2.join(process.cwd(), "sportsbet/betresult/logs");
var LOG_BASENAME = "results-cron";
function ensureLogDir() {
  try {
    fs.mkdirSync(LOG_DIR, { recursive: true });
  } catch (_) {
  }
}
ensureLogDir();
function currentLogPath() {
  const d = /* @__PURE__ */ new Date(), yyyy = d.getFullYear(), mm = String(d.getMonth() + 1).padStart(2, "0"), dd = String(d.getDate()).padStart(2, "0");
  return path2.join(LOG_DIR, `${LOG_BASENAME}-${yyyy}-${mm}-${dd}.log`);
}
function writeLog(level, msg, ctx = {}) {
  const ctxStr = Object.keys(ctx).length ? " " + JSON.stringify(ctx) : "";
  const line = `[${(/* @__PURE__ */ new Date()).toISOString()}] [${level}] ${msg}${ctxStr}
`;
  if (level === "ERROR") console.error(msg, ctx);
  else console.log(msg, ctx);
  try {
    fs.appendFileSync(currentLogPath(), line, "utf8");
  } catch (e) {
    console.error("Log write failed:", e.message);
  }
}
var log = {
  info: (m, c = {}) => writeLog("INFO", m, c),
  error: (m, c = {}) => writeLog("ERROR", m, c),
  debug: (m, c = {}) => {
    if (DEBUG) writeLog("DEBUG", m, c);
  }
};
var RESULTS_API_BASE = process.env.RESULTS_API_BASE || "https://apilords.codefactory.games/api";
var AVRKHUB_BASE_URL2 = process.env.AVRKHUB_BASE_URL || "https://diamond-result-v2.avrkhub.in";
var SETTLEMENT_VERSION = process.env.SETTLEMENT_VERSION || "v2";
var API_TIMEOUT_MS = +(process.env.API_TIMEOUT_MS || 3e4);
var MAX_CONCURRENT_API = +(process.env.MAX_CONCURRENT_API || 3);
var USER_BATCH_CONCURRENCY = +(process.env.USER_BATCH_CONCURRENCY || 5);
var RESULTS_REQUEUE_MS = +(process.env.RESULTS_REQUEUE_MS || 12e4);
var RESULTS_POLL_MS = +(process.env.RESULTS_POLL_MS || process.env.CRON_INTERVAL_MS || 3e3);
var RESULT_CACHE_MS = +(process.env.RESULT_CACHE_MS || 2500);
var SCAN_WRITE_MS = +(process.env.SCAN_WRITE_MS || 6e4);
var PRUNE_EVERY_MS = +(process.env.PRUNE_EVERY_MS || 36e5);
var SUMMARY_KEEP_PER_EVENT = +(process.env.SUMMARY_KEEP_PER_EVENT || 5);
var SUMMARY_RETENTION_DAYS = +(process.env.SUMMARY_RETENTION_DAYS || 7);
var BET_CACHE_TTL_DAYS = +(process.env.BET_CACHE_TTL_DAYS || 14);
var RESULTS_MAX_FETCH_RETRIES = +(process.env.RESULTS_MAX_FETCH_RETRIES || 6);
var RESULTS_RETRY_BASE_MS = +(process.env.RESULTS_RETRY_BASE_MS || 500);
var RESULTS_FORCE_IPV4 = process.env.RESULTS_FORCE_IPV4 === "1" || process.env.RESULTS_FORCE_IPV4 === "true";
var RESULTS_DISABLE_KEEPALIVE = process.env.RESULTS_DISABLE_KEEPALIVE === "1" || process.env.RESULTS_DISABLE_KEEPALIVE === "true";
var RESULTS_RATE_LIMIT_MS = +(process.env.RESULTS_RATE_LIMIT_MS || 250);
var RESULTS_SID_FALLBACKS = (process.env.RESULTS_SID_FALLBACKS || "4,1,2,8,10,65").split(",").map((s) => Number(String(s).trim())).filter((n) => Number.isInteger(n) && n > 0);
var KNOWN_VALID_SIDS = /* @__PURE__ */ new Set([1, 2, 4, 8, 10, 65, ...RESULTS_SID_FALLBACKS]);
function isValidSid(sid) {
  const n = Number(sid);
  return Number.isInteger(n) && n > 0 && KNOWN_VALID_SIDS.has(n);
}
var httpAgent = new http.Agent({ keepAlive: !RESULTS_DISABLE_KEEPALIVE, family: RESULTS_FORCE_IPV4 ? 4 : void 0 });
var httpsAgent = new https.Agent({ keepAlive: !RESULTS_DISABLE_KEEPALIVE, family: RESULTS_FORCE_IPV4 ? 4 : void 0 });
var ax2 = axios2.create({
  timeout: API_TIMEOUT_MS,
  httpAgent,
  httpsAgent,
  validateStatus: () => true,
  headers: {
    "Accept": "application/json",
    "User-Agent": `results-cron/1.0 (+node ${process.version})`
  }
});
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function jitter(ms) {
  return Math.round(ms * (1 + Math.random() * 0.25));
}
function parseRetryAfter(h) {
  if (!h) return null;
  const n = Number(h);
  if (!Number.isNaN(n)) return Math.max(0, Math.round(n * 1e3));
  const d = Date.parse(h);
  return Number.isNaN(d) ? null : Math.max(0, d - Date.now());
}
function buildPerAttemptConfig(attempt) {
  if (attempt >= 3) {
    return {
      httpAgent: new http.Agent({ keepAlive: false, family: 4 }),
      httpsAgent: new https.Agent({ keepAlive: false, family: 4 }),
      headers: { "Connection": "close" }
    };
  }
  return {};
}
var lastApiCallAt = 0;
async function globalRateLimit() {
  const gap = RESULTS_RATE_LIMIT_MS > 0 ? RESULTS_RATE_LIMIT_MS : 0;
  const now = Date.now();
  const wait = Math.max(0, lastApiCallAt + gap - now);
  if (wait) await sleep(wait);
  lastApiCallAt = Date.now();
}
var AsyncQueue = class {
  constructor(max) {
    this.max = max;
    this.running = 0;
    this.q = [];
  }
  push(task) {
    return new Promise((res, rej) => {
      this.q.push({ task, res, rej });
      this._next();
    });
  }
  _next() {
    if (this.running >= this.max) return;
    const n = this.q.shift();
    if (!n) return;
    this.running++;
    n.task().then(n.res, n.rej).finally(() => {
      this.running--;
      this._next();
    });
  }
};
var apiQueue = new AsyncQueue(MAX_CONCURRENT_API);
var cachedGet = makeCachedGet({ ax: ax2, ttlMs: RESULT_CACHE_MS, rateLimit: globalRateLimit });
var getResultPayload = makePayloadGetter(cachedGet, `${AVRKHUB_BASE_URL2}/get_result`);
async function ensureTables() {
  await SportsEventResultScan_default.sync();
  await SportsEventResultSummary_default.sync();
  await SportsEventSettlementJobs_default.sync();
  await SportsBetResultCache_default.sync();
  await ensureAutoVoidTables();
  log.info("[ResultCron] tables ensured.");
}
function normalizeText(v) {
  if (!v) return "";
  return String(v).trim().toUpperCase().replace(/\s+/g, " ");
}
function normalizeMarketType(v) {
  if (!v) return "";
  return String(v).trim().toUpperCase();
}
function relaxFancyName(v) {
  return normalizeText(v).replace(/[:.\-]+$/, "").replace(/\s+ADV$/, "").replace(/[:.\-]+$/, "").trim();
}
async function fetchResultForEvent(eventid, eventName, marketId, marketName, sport_id, market_type, gameType, team_one, team_two, runners) {
  log.debug("[ResultCronV2] fetchResultForEvent start", { eventid, eventName, market_type, version: SETTLEMENT_VERSION });
  const maxAttempts = RESULTS_MAX_FETCH_RETRIES || 6;
  const useAvrkhub = SETTLEMENT_VERSION !== "v1";
  const url = useAvrkhub ? `${AVRKHUB_BASE_URL2}/get_result` : `${RESULTS_API_BASE}/result/get-result`;
  let sidCandidates;
  if (!useAvrkhub) sidCandidates = [sport_id];
  else if (isValidSid(sport_id)) sidCandidates = [Number(sport_id)];
  else if (Number.isInteger(Number(sport_id)) && Number(sport_id) > 0) {
    const own = Number(sport_id);
    sidCandidates = [own, ...RESULTS_SID_FALLBACKS.filter((s) => s !== own)];
  } else {
    sidCandidates = [...RESULTS_SID_FALLBACKS];
    log.info("[ResultCronV2] bad sid on bet \u2014 using fallbacks", { eventid, sport_id, sidCandidates });
  }
  return apiQueue.push(async () => {
    let sidIdx = 0;
    let sid = sidCandidates[sidIdx];
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        let res;
        if (useAvrkhub) {
          res = await cachedGet(url, { gmid: eventid, sid: sid || "4" }, buildPerAttemptConfig(attempt));
        } else {
          await globalRateLimit();
          res = await ax2.post(url, { event_id: eventid, sid }, buildPerAttemptConfig(attempt));
        }
        log.debug("[ResultCronV2] response", { eventid, sid, attempt, status: res.status });
        if (res.status === 200) {
          const data = typeof res?.data === "string" ? JSON.parse(res.data) : res.data;
          if (useAvrkhub && data?.gmid && String(data.gmid) !== String(eventid)) {
            log.error("[ResultCronV2] gmid mismatch \u2014 trying next sid", { eventid, sid, got: data?.gmid });
            if (sidIdx < sidCandidates.length - 1) {
              sid = sidCandidates[++sidIdx];
              continue;
            }
            return { declared: false, items: [], feedState: "unknown" };
          }
          const markets = Array.isArray(data?.markets) ? data.markets : [];
          let matchedMarket;
          const inputMarketName = normalizeText(marketName);
          const inputMarketType = normalizeMarketType(market_type);
          if (market_type === "TIED_MATCH" || market_type === "Tied Match") {
            matchedMarket = markets.find(
              (m) => normalizeMarketType(m?.mname) === inputMarketType
            );
          } else if (gameType === "FAN") {
            matchedMarket = markets.find(
              (m) => normalizeText(m?.marketName) === inputMarketName && normalizeMarketType(m?.mname) === inputMarketType
            );
            if (!matchedMarket) {
              matchedMarket = markets.find(
                (m) => relaxFancyName(m?.marketName) === relaxFancyName(marketName) && normalizeMarketType(m?.mname) === inputMarketType
              );
            }
            if (!matchedMarket) {
              matchedMarket = markets.find(
                (m) => m?.gtype === "CRICKETCASINO" && normalizeMarketType(m?.mname) === inputMarketType
              );
            }
            if (!matchedMarket && isLineMarket(market_type)) {
              matchedMarket = resolveLineMarketFromFeed(markets, market_type);
              if (matchedMarket) {
                log.info("[ResultCronV2] line market derived", { eventid, market_type, status: matchedMarket.status, winnerId: matchedMarket.winnerId, from: matchedMarket.derivedFrom });
              }
            }
          } else {
            const inputEventName = normalizeText(eventName);
            const inputMname = normalizeMarketType(market_type);
            if (useAvrkhub) {
              const teamEventName = team_one && team_two ? normalizeText(`${team_one} v ${team_two}`) : "";
              if (teamEventName) {
                matchedMarket = markets.find(
                  (m) => normalizeText(m?.ename) === teamEventName && normalizeMarketType(m?.mname) === inputMname
                );
              }
              if (!matchedMarket) {
                matchedMarket = markets.find(
                  (m) => normalizeText(m?.ename) === inputEventName && normalizeMarketType(m?.mname) === inputMname
                );
              }
              if (!matchedMarket) {
                matchedMarket = markets.find(
                  (m) => normalizeText(m?.marketName) === inputEventName && normalizeMarketType(m?.mname) === inputMname
                );
              }
              if (!matchedMarket) {
                matchedMarket = matchMarketByRunners(markets, runners, eventName, market_type);
                if (matchedMarket) {
                  log.debug("[ResultCronV2] matched via runners field", { eventid, mname: matchedMarket.mname });
                }
              }
            } else {
              matchedMarket = markets.find(
                (m) => normalizeText(m?.marketName) === inputEventName && normalizeMarketType(m?.mname) === inputMname
              );
            }
          }
          const declared = matchedMarket?.status === "SETTLE" || matchedMarket?.status === "VOID";
          log.debug("[ResultCronV2] matchedMarket", { eventid, market_type, gameType, declared, status: matchedMarket?.status });
          const feedState = markets.some((m) => m?.status === "PENDING") ? "live" : "complete";
          return {
            declared,
            feedState,
            // MATCH_ODDS / BOOKMAKER status from the SAME payload —
            // the auto-void timer's anchor (autoVoid.js). Free.
            anchors: anchorStatuses(markets),
            items: matchedMarket ? [matchedMarket] : [],
            meta: { success: data?.success, source: useAvrkhub ? "avrkhub" : "diamond", gmid: data?.gmid, resolvedSid: sid }
          };
        }
        if (res.status === 429 || res.status >= 500 && res.status <= 599) {
          const ra = parseRetryAfter(res.headers?.["retry-after"]);
          const wait = ra != null ? ra : jitter(RESULTS_RETRY_BASE_MS * Math.pow(2, attempt - 1));
          log.debug("[ResultCronV2] retry backoff", { eventid, attempt, status: res.status, waitMs: wait });
          await sleep(wait);
          continue;
        }
        if ((res.status === 400 || res.status === 404) && sidIdx < sidCandidates.length - 1) {
          log.debug("[ResultCronV2] sid rejected \u2014 trying next", { eventid, sid, status: res.status });
          sid = sidCandidates[++sidIdx];
          attempt = 0;
          continue;
        }
        return { declared: false, items: [], feedState: "unknown" };
      } catch (e) {
        const wait = jitter(RESULTS_RETRY_BASE_MS * Math.pow(2, attempt - 1));
        const isTimeout = e.code === "ECONNABORTED" || e.message.includes("timeout");
        if (isTimeout) {
          log.error("[ResultCronV2] fetchResultForEvent TIMEOUT", { eventid, attempt, error: e.message });
        } else {
          log.error("[ResultCronV2] fetchResultForEvent error", { eventid, attempt, error: e.message, code: e.code });
        }
        if (attempt < maxAttempts) {
          log.info("[ResultCronV2] retrying after backoff...", { eventid, waitMs: wait });
          await sleep(wait);
        }
      }
    }
    log.debug("[ResultCronV2] fetchResultForEvent exhausted", { eventid, sidCandidates });
    return { declared: false, items: [], feedState: "unknown" };
  });
}
async function pruneSummaries() {
  try {
    const cutoff = new Date(Date.now() - SUMMARY_RETENTION_DAYS * 24 * 60 * 60 * 1e3);
    await SportsEventResultSummary_default.destroy({ where: { recorded_at: { [Op3.lt]: cutoff } } });
    log.debug("[ResultCron] pruneSummaries done");
  } catch (e) {
    log.error("[ResultCron] pruneSummaries error", { error: e.message });
  }
}
async function pruneBetCache() {
  try {
    const cutoff = new Date(Date.now() - BET_CACHE_TTL_DAYS * 24 * 60 * 60 * 1e3);
    await SportsBetResultCache_default.destroy({ where: { recorded_at: { [Op3.lt]: cutoff } } });
    log.debug("[ResultCron] pruneBetCache done");
  } catch (e) {
    log.error("[ResultCron] pruneBetCache error", { error: e.message });
  }
}
var wakeSettlement2 = (count) => wakeSettlement(count, log);
var enqueueSettlementJob2 = (b, declared) => enqueueSettlementJob(b, declared, log);
var tablesEnsured = false;
var lastPruneAt = 0;
var lastHeartbeatAt = 0;
var HEARTBEAT_MS = +(process.env.HEARTBEAT_MS || 6e4);
var lastScanWrite = /* @__PURE__ */ new Map();
var autoVoid = createAutoVoid({ log });
async function runOnce() {
  const t0 = Date.now();
  let queued = 0;
  try {
    if (!tablesEnsured) {
      await ensureTables();
      tablesEnsured = true;
    }
    const allBets = await SportsBet_default.findAll({
      where: {
        status: { [Op3.in]: ["open", "manual"] },
        game_type: { [Op3.in]: ["MO", "BM", "FAN"] },
        eventid: { [Op3.ne]: null }
      },
      attributes: ["id", "user_id", "game_type", "bet_type", "selection_name", "odds", "stake_amount", "match_title", "match_id", "fancy_name", "eventid", "created_at", "sport_id", "market_type", "status", "team_one", "team_two", "runners", "job_id"],
      order: [["created_at", "ASC"]]
    });
    if (!allBets || !allBets.length) {
      log.debug("[ResultCron] no open bets.");
      return;
    }
    const scanAgg = /* @__PURE__ */ new Map();
    const eventAgg = /* @__PURE__ */ new Map();
    for (const b of allBets) {
      try {
        if (!b.eventid) continue;
        const userId = b.user_id;
        const eid = b.eventid;
        const eventName = b.match_title || "";
        const gameType = (b.game_type || "").toUpperCase();
        const marketId = b.match_id || b.eventid;
        const sport_id = b.sport_id;
        const market_type = b.market_type;
        let marketName = b.selection_name || "";
        if (gameType === "MO") marketName = "Match_Odds";
        else if (gameType === "BM") marketName = "BookMaker";
        let declared = false;
        let result_meta = null;
        let feedState = null;
        if (b.status === "manual") {
          declared = true;
        } else {
          const res = await fetchResultForEvent(eid, eventName, marketId, marketName, sport_id, market_type, gameType, b.team_one, b.team_two, b.runners);
          declared = !!res?.declared;
          result_meta = res?.meta || null;
          feedState = res?.feedState || "unknown";
          if (res?.anchors) {
            const ea = eventAgg.get(String(eid)) || { eventid: eid, sport_id, match_title: eventName, anchors: null, pending: [] };
            ea.anchors = res.anchors;
            eventAgg.set(String(eid), ea);
          }
          const goodSid = res?.meta?.resolvedSid;
          if (goodSid && String(goodSid) !== String(sport_id)) {
            try {
              await b.update({ sport_id: goodSid });
              log.info("[ResultCron] healed bad sport_id", { betId: b.id, from: sport_id, to: goodSid });
            } catch (e) {
              log.error("[ResultCron] sport_id heal failed", { betId: b.id, error: e.message });
            }
          }
          if (!declared && gameType === "BM") {
            const fb = await resolveH2HBookmakerFallback({
              eventid: eid,
              sport_id,
              market_type,
              team_one: b.team_one,
              team_two: b.team_two,
              logger: log,
              getPayload: getResultPayload
            });
            if (fb?.declared) {
              log.info("[ResultCron] H2H bookmaker fallback declared", { betId: b.id, ...fb.meta });
              declared = true;
              result_meta = fb.meta;
            }
          }
        }
        if (!declared && b.status === "open") {
          const ea = eventAgg.get(String(eid)) || { eventid: eid, sport_id, match_title: eventName, anchors: null, pending: [] };
          ea.pending.push(b);
          eventAgg.set(String(eid), ea);
        }
        const key = `${userId}:${eid}`;
        const agg = scanAgg.get(key) || { user_id: userId, eventid: eid, declared: false, feed: null, total: 0, result_meta: null, firstBet: b };
        agg.total++;
        if (declared) {
          agg.declared = true;
          agg.result_meta = agg.result_meta || result_meta;
        }
        if (feedState) agg.feed = feedState;
        scanAgg.set(key, agg);
        if (declared) {
          const r = await enqueueSettlementJob2(b, declared);
          if (r.action === "created" || r.action === "re-armed") {
            queued++;
            log.info("[ResultCron] job queued", { user_id: userId, eventid: eid, betId: b.id, gameType, market_type, jobId: r.jobId, action: r.action });
          } else {
            log.debug("[ResultCron] job not queued", { betId: b.id, action: r.action, jobId: r.jobId });
          }
        }
      } catch (err) {
        log.error("[ResultCron] error processing single bet", { betId: b.id, error: err.message });
      }
    }
    if (queued) await wakeSettlement2(queued);
    try {
      await autoVoid.afterScan(eventAgg);
    } catch (e) {
      log.error("[AutoVoid] afterScan failed", { error: e.message });
    }
    for (const [key, agg] of scanAgg) {
      const prev = lastScanWrite.get(key);
      const changed = !prev || prev.declared !== agg.declared || prev.feed !== agg.feed;
      if (!changed && Date.now() - prev.at < SCAN_WRITE_MS) continue;
      const counts = { total: agg.total, feed: agg.feed };
      try {
        await SportsEventResultScan_default.upsert({
          user_id: agg.user_id,
          eventid: agg.eventid,
          declared: agg.declared,
          counts,
          checked_at: /* @__PURE__ */ new Date()
        }, { conflictFields: ["user_id", "eventid"] });
      } catch (e) {
        log.error("[ResultCron] scan upsert fail", { key, error: e.message });
      }
      try {
        await SportsEventResultSummary_default.create({
          user_id: agg.user_id,
          eventid: agg.eventid,
          declared: agg.declared,
          counts: JSON.stringify(counts),
          result_meta: agg.result_meta ? JSON.stringify(agg.result_meta) : null,
          sections: JSON.stringify({ bets: [agg.firstBet] }),
          recorded_at: /* @__PURE__ */ new Date()
        });
      } catch (e) {
        log.error("[ResultCron] summary insert fail", { key, error: e.message });
      }
      lastScanWrite.set(key, { declared: agg.declared, feed: agg.feed, at: Date.now() });
    }
    if (Date.now() - lastPruneAt > PRUNE_EVERY_MS) {
      lastPruneAt = Date.now();
      try {
        await pruneSummaries();
      } catch (e) {
        log.error("prune summaries fail", { error: e.message });
      }
      try {
        await pruneBetCache();
      } catch (e) {
        log.error("prune cache fail", { error: e.message });
      }
    }
    const ms = Date.now() - t0;
    const line = { bets: allBets.length, events: scanAgg.size, queued, ms };
    if (queued || ms > 5e3 || Date.now() - lastHeartbeatAt > HEARTBEAT_MS) {
      lastHeartbeatAt = Date.now();
      log.info("[ResultCron] scan done", line);
    } else {
      log.debug("[ResultCron] scan done", line);
    }
  } catch (e) {
    log.error("[ResultCron] fatal", { error: e.message });
  }
}
var running = false;
async function runGuarded() {
  if (running) return;
  running = true;
  try {
    await runOnce();
  } finally {
    running = false;
  }
}
function scheduleNext() {
  setTimeout(async () => {
    await runGuarded();
    scheduleNext();
  }, RESULTS_POLL_MS);
}
function startCron() {
  log.info("[ResultCron] Scheduler starting...", { everyMs: RESULTS_POLL_MS, resultCacheMs: RESULT_CACHE_MS, wake: WAKE_CHANNEL });
  runGuarded().then(scheduleNext);
}
startCron();
export {
  runOnce,
  startCron
};
