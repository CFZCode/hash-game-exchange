# MSSPORTS — Known bugs & pending work

Everything below was found while exporting the sports module from TENEXCH on 2026-10-12.
**None of it was fixed in this export.** The code is the same logic that runs live in tenexch.
Fix each item in the new project, with a test, before going live.

**How to find code:** the bundled files keep a comment with the original tenexch path above
every module. For example, search `// sportsbet/betresult/settlementv2.js` in
`workers/settlement.worker.js`, then search for the function name given below.

Severity: 🔴 money / security · 🟠 correctness · 🟡 cleanup

---

## A. Settlement (money) — `workers/settlement.worker.js`

| # | Sev | Where | Problem | Fix idea |
|---|---|---|---|---|
| A1 | 🔴 | `processFanBet` | A duplicate pass that **loses** the bet claim still runs `user.increment(net_win/profit/net_loss)` and `CreditsLedger.create(...)` **before** the `if (alreadySettled) return` check. Result: a phantom `settlement` ledger row and wrong user counters (the wallet itself does not change). | Move the `alreadySettled` return right after the claim, before any counter or ledger write. |
| A2 | 🔴 | `processFanBet` | The FAN `credits_ledger` row is written **after** the wallet transaction commits, so wallet and ledger are not atomic. A crash between them leaves money moved with no ledger row. | Write the ledger row inside the same transaction (like `applyWalletDeltaWithLedger` does). |
| A3 | 🔴 | `processMobmGroup` | The bet claim (`status='closed'`) and the wallet write are **separate transactions**. A wallet error after the claim is only logged, so bets end up closed but **unpaid**. | Claim + wallet + ledger in one transaction, or roll the claim back on failure. |
| A4 | 🔴 | whole worker | Duplicate-settlement safety **assumes exactly one worker instance**. Two instances = double payouts possible (tenexch incident 2026-08-19). | Run one instance only, or add a real distributed lock (Postgres advisory lock / `SELECT … FOR UPDATE SKIP LOCKED`). |
| A5 | 🟠 | `initiateRefund` (void/refund) | The refund amount = −Σ `credits_ledger` rows with `reason IN (bet_placed, exposure_release)`. Placement does **not** write those rows any more (it writes `debit_ledger`; the credits_ledger writes are commented out), so refunds fall back to the stake. **Needs checking for lay bets**, where the blocked amount is the liability, not the stake. | Verify on real data. If wrong, compute the refund from the exposure that was actually blocked. |
| A6 | 🟠 | `settlementQueue.js` wake publisher + worker wake subscriber | Their Redis clients do not pass `REDIS_PASSWORD`. On a password-protected Redis the instant wake fails silently, and settlement only runs on the 3 s timer. | Reuse the shared redis config (with password). |
| A7 | 🟠 | manual declare (`api/settlementStatement.api.js` → `declareResult`) | `mannual_result` has no uniqueness; the newest row wins. There is no "undeclare". A wrong declare must be fixed with void-after-settlement. | Add a unique key or an explicit undeclare flow. |

## B. Place bet / exposure — `core/sports-core.js`

| # | Sev | Where | Problem | Fix idea |
|---|---|---|---|---|
| B1 | 🔴 | `placeBet` (`// sportsbet/sportbetscontroller.js`) | Two balance fields. `placeBet` checks and debits **`Wallets.cash`**, but the socket balance push (`getBalance` / `subscribeBalance`) reports **`Wallets.inr_balance`**. Settlement moves both. | Decide one spendable balance field for the new wallet service. |
| B2 | 🟠 | `placeBet` | The DB transaction is opened on the first line and stays open across **upstream HTTP calls** (market limits from the feed, cricket format lookup, race board, FX rate). Under load this holds DB connections. | Do all feed reads first, then open the transaction just before the wallet `FOR UPDATE`. |
| B3 | 🟠 | `placeBet` → `inrToUsd` | When `usd_amount` is missing, it calls `https://api.exchangerate.host` **inside** the bet transaction (fallback 1/83). | Use a cached rate from config; never call out inside the transaction. |
| B4 | 🟠 | `walletUpdate` | The debit only happens `if (cash >= delta)`, otherwise it is skipped silently. An earlier check rejects that case today, but the skip is unsafe. | Throw instead of skipping. |
| B5 | 🟠 | `SportsBet.create` in `placeBet` | `is_cashout` is written but is **not in the `SportsBet` model**. Sequelize drops unknown fields silently. | Add the column to the model (check it exists in the DB). |
| B6 | 🟠 | `SportsLockController.checkSportsLock` | Fails **open**: a DB error lets the bet through. All other lock checks fail closed. | Fail closed. |
| B7 | 🟠 | `sportsbet/betInflight.js`, `sportsbet/liveOdds.js` | The `client_ref` registry (`/bet-result/:client_ref`) and the live-odds pollers live in **process memory**. They break with 2+ API replicas or after a restart. | Move to Redis (`SET NX` + TTL for client_ref). |
| B8 | 🟡 | `TOTAL_EXPOSURE_SQL` (`// helper/totalExposure.js`) | The fancy-family market list exists **three times**: `marketsforfancy` (placement), `PER_SELECTION_MARKETS`, and this SQL. If they drift, the total exposure is wrong. | One shared constant. |
| B9 | 🟡 | `placeBet`, settlement, manual settle | ~800 market names are hardcoded in lists (`marketsfornonfancy`, `fixedNonFancyMarkets`, `marketsforfancy`, …), copied between placement, settlement and manual settle. | One shared market-type registry. |

## C. Security

| # | Sev | Route | Problem |
|---|---|---|---|
| C1 | 🔴 | `GET /api/user/cricket/user-open-bets`, `/cricket/user-open-bets-grouped` | **No auth.** `user_id` comes from the query string, so anyone can read anyone's open bets. |
| C2 | 🔴 | `GET /api/user/cricket/matched-bets/all` | **No auth.** Admin view of every bet on an event. |
| C3 | 🔴 | `POST /api/user/matchexposures/match` | Auth is required, but it trusts `user_id` from the **body**, so a player can read another player's exposure. Use the token's user id. |
| C4 | 🟠 | `authMiddleware` | `req.user.account.type` is never checked on player routes, so a STAFF or OWNER token is treated as a user id. |
| C5 | 🟠 | odds + events workers | `sportsMain/helper/apihelper.js` has a hardcoded feed host `http://167.71.224.37:9000` (raw IP, plain HTTP). Move it to env. |

## D. Workers

| # | Sev | Worker | Problem |
|---|---|---|---|
| D1 | 🟠 | `workers/odds.worker.js` | **Broken in production.** It reads Redis `alleventss:{sid}` as an array, but the value is `{t1,t2,t3}`, so every tick fails with `matches.filter is not a function` (seen in tenexch pm2 logs). Even if fixed, the key it writes (`oddss:{gmid}`) is **read by nobody**: live odds come straight from AVRKHUB (`SPORTS_API_VERSION=v2`). Either delete it, or fix it and switch the API to read odds from Redis (better for scale: one feed call per match instead of per request). |
| D2 | 🟡 | `workers/events.worker.js` | Writes `alleventss:{sid}` (TTL 3 h) every minute. The API also writes the same key (TTL 120 s) when `/cricket/all-data` is called. Two writers with different TTLs; keep one. |
| D3 | 🟡 | v1 code path | `SPORTS_API_VERSION=v1` reads `odds:{gmid}` / `allevents:{sid}`, which no worker writes. The v1 path is dead; delete it when porting. |

## E. Code quality (no behaviour impact today)

- Duplicate keys in object literals (the last one wins, so behaviour is defined, but intent is unclear):
  - `SportsBet.create` in `placeBet`: `fancy_name`, `fixed`, `counts`, `sport_id`
  - `cricketController`: `eventid`
  - `MarketWin` model: `created_at`
  - settlement worker: `bet_id`, `user_id`, `eventid`, `match_id`, `market_type`, `game_type`
- `CricketService.GetMatchPrivateData` references the undefined `isSampling` / `requestCounter`. This is guarded by `typeof`, so it never crashes; it is dead debug code.
- Magic numbers that should be config:
  - race window 5 min
  - `METER_MAX_RUNS` 150
  - line market stake 100 / 100000
  - hard cap 500000
  - USD rate 0.0118
  - sport id → name maps (duplicated)

---

## F. Pending work to run this in the microservices project

1. **Auth.** Use the same `JWT_SECRET` as the user/auth service. The middleware reads `user_id` / `account` from the token
   and loads the `users` / `staff` / owner rows for status checks.
2. **Shared tables this module reads/writes** (another service owns them today):
   - users / accounts: `users`, `staff`, owner, `executives`, `tokens` / token blacklist
   - money: `Wallets`, `credits_ledger`, `debit_ledger`, `point_ledger`, `user_exposures`, `total_exposures`
   - Settlement walks the whole agent hierarchy to write `point_ledger` (`WalletService.updateAllPointHierarchy`).
   Decide: keep one DB, or put Wallet + Ledger + Exposure behind a wallet service with an atomic reserve/commit API.
   Placement must debit the wallet **and** write exposure atomically.
3. **Sports-owned tables:**
   - bets and settlement: `SportsBet`, `sports_event_settlement_jobs`, `sports_event_result_scan`, `sports_event_result_summary`, `sports_bet_result_cache`, `sports_settlement_report`, `sports_auto_void_state`, `mannual_result`, `bet_void_audit`, `marketwins`, `fanwins`
   - config: `bet_buffer_configs`, `bet_limit_overrides`, `max_odds_configs`, `virtual_bet_limits`, `commission_configs`, `auto_void_config`, `result_source_link`
   - locks: `betlocks`, `user_match_locks`, `user_event_market_locks`, `staff_market_locks`, `user_sports_lock`, `staff_sports_lock`, `platform_games`
   - user settings: `stake_button_values`, `oneclick_button_lists`, `sports_config`
   - The schema = the Sequelize model definitions inside `core/sports-core.js` (search `sequelize.define`). There are no SQL migrations.
4. **Schema changes in this export vs tenexch** (all in removed casino features):
   - `Wallets` model drops `casino_pts` and `thirdparty_pts`
   - `stake_button_values` drops `casino_buttons`
   - `bet_buffer_configs` / `bet_limit_overrides` drop `game_name` and the casino unique index
   If you point this at the **existing tenexch DB**, do **not** run `sync({ alter: true })`: it would drop those columns.
5. **Exposure SQL changed to sports-only.** `TOTAL_EXPOSURE_SQL` lost its non-sports branches. It was tested equal to the
   tenexch query on ~10,000 random rows (0 mismatches over 400 users) **for tables with only sports rows**. If the new DB's
   `user_exposures` also holds rows from another product, the totals will differ; use the tenexch query then.
6. **API changes vs tenexch** (removed because casino or unused):
   - `GET /betting-config` no longer returns `casino_limits` or `buffers.casino`
   - `stake-button-values` no longer returns or accepts `casino_buttons`
   - the statement no longer has the "Live Casino" closing line or the `gamename`, `casinoCode`, `roundId` fields
   - `/account-statement-v2/casino-bets` is gone
7. **Unverified callers.** "Unused" routes were removed based on the tenexch web frontend + admin code only. Any mobile app that
   calls a removed route will get 404. Full list of removed routes: `README.md`.
8. **Tests.** No automated tests ship with this package. Port at least:
   - placement exposure maths for each market family
   - settlement win/loss per market family
   - void-after-settlement reversal
   - the A1–A3 fixes
9. **Settlement report / admin readers.** In tenexch, admin reports, the integrity scanner (`systemTracker`) and the Pending Result
   Tracker read the sports tables. They are not part of this package.
