import redis from '../config/redisClient.js';
import BetBufferConfig from '../model/admin/BetBufferConfig.js';
import BetLimitOverride from '../model/admin/BetLimitOverride.js';
import Owner from '../model/admin/Owner.js';
import MaxOddsConfig from '../model/admin/MaxOddsConfig.js';
import VirtualBetLimit from '../model/admin/VirtualBetLimit.js';
import { sportNameById } from '../constants/sportsList.js';
import { DEFAULT_LEAGUE_KEY, leagueKeyFromName } from '../constants/commissionLeagues.js';

// ─────────────────────────────────────────────────────────────────────────────
// Betting config cache — buffer times, min/max stake overrides and max odds.
//
// These rows are read on EVERY bet placement and, for limits, on every event
// page load, but they change only when an owner presses Save. So they are read
// through two cache tiers:
//
//   1. Redis (shared by every pm2 worker)  — TTL below, invalidated on write.
//   2. A per-process micro cache            — MICRO_TTL_MS, so a 300ms odds
//                                             poll never round-trips Redis.
//
// Both tiers FAIL OPEN: any Redis or DB error returns "nothing configured",
// which is exactly today's behaviour. A config lookup must never be able to
// take betting down.
//
// Invalidation is a plain redis.del of the affected key. There is one shared
// Redis (config/redisClient.js, db 1), so every worker sees the delete on its
// next read — no pub/sub needed. The micro cache is bounded by MICRO_TTL_MS,
// so a save is visible platform-wide within that window at worst.
// ─────────────────────────────────────────────────────────────────────────────

// v2 (2026-09-15): the buffer and max-odds maps gained the league level (and
// the buffer the Commission market keys) — new keys, so no process ever parses
// an old-shape map out of redis.
const KEY_BUFFER = 'cfg:buffer:v2';
const KEY_CASINO_LIMITS = 'cfg:limits:casino:v1';
const KEY_MAX_ODDS = 'cfg:maxodds:v2';
const KEY_VIRTUAL_LIMITS = 'cfg:limits:virtual:v1';
const keyEventLimits = (eventId) => `cfg:limits:event:${eventId}`;

const REDIS_TTL_SEC = 300;
const MICRO_TTL_MS = 2000;

const micro = new Map(); // key -> { value, expires }

const microGet = (key) => {
    const hit = micro.get(key);
    if (!hit) return undefined;
    if (hit.expires < Date.now()) {
        micro.delete(key);
        return undefined;
    }
    return hit.value;
};

const microSet = (key, value) => {
    micro.set(key, { value, expires: Date.now() + MICRO_TTL_MS });
};

const microDel = (key) => micro.delete(key);

// Read-through: micro → redis → builder(). Never throws.
const readThrough = async (key, builder, fallback) => {
    const local = microGet(key);
    if (local !== undefined) return local;

    try {
        const cached = await redis.get(key);
        if (cached != null) {
            const parsed = JSON.parse(cached);
            microSet(key, parsed);
            return parsed;
        }
    } catch (err) {
        console.warn(`[BettingConfig] redis read failed for ${key}:`, err.message);
    }

    let built;
    try {
        built = await builder();
    } catch (err) {
        console.warn(`[BettingConfig] build failed for ${key}:`, err.message);
        return fallback;
    }

    microSet(key, built);
    redis.set(key, JSON.stringify(built), 'EX', REDIS_TTL_SEC).catch((err) =>
        console.warn(`[BettingConfig] redis write failed for ${key}:`, err.message)
    );
    return built;
};

const num = (v) => {
    const n = Number(v);
    return Number.isFinite(n) ? n : 0;
};

// A limit side is "set" only when it is a real positive number; NULL / 0 both
// mean "leave the feed value alone".
const limitSide = (v) => {
    if (v === null || v === undefined || v === '') return null;
    const n = Number(v);
    return Number.isFinite(n) && n > 0 ? n : null;
};

// ── Buffers ────────────────────────────────────────────────────────────────
// Shape: { global: 5,
//          grid:   { "4": { default: { matchodds: 7, match_other: 7, fancy: 1 },
//                           t10xi:   { matchodds: 2, fancy: 0 } } },
//          sports: { "4": { match_odds: 7, bookmaker: 1, fancy: 1 } },
//          casino: { "teen20": 4 } }
//
// `grid` is the real sports config — sport → league → market, the Commission
// grid's keys (BetBufferConfig):
//   * default league: only configured (> 0) cells appear.
//   * variant league (t10xi, ecricket, …): every SAVED row appears, 0 included
//     — a saved row is an explicit override; an absent cell inherits the
//     sport's default cell.
// `sports` is the pre-2026-09-15 3-bucket view of the default league
// (matchodds / bookmaker / fancy), so a browser still running the old bundle
// keeps the buffer it had.
// An unconfigured cell falls back to `global` (the pre-existing platform-wide
// Owner.platform_configurations.buffer_time) and then to the caller's env
// default. Reading `global` from here also gets the old uncached
// Owner.findOne() off the per-bet path.
const readGlobalBuffer = async () => {
    const owner = await Owner.findOne({ attributes: ['platform_configurations'], raw: true });
    let config = owner?.platform_configurations;
    if (typeof config === 'string') {
        try { config = JSON.parse(config); } catch { config = null; }
    }
    return num(config?.buffer_time);
};

// Default-league market key → the legacy bucket it is shown under in `sports`.
const LEGACY_BUFFER_VIEW = { matchodds: 'match_odds', bookmaker: 'bookmaker', fancy: 'fancy' };

const buildBufferMap = async () => {
    const [rows, global] = await Promise.all([
        BetBufferConfig.findAll({
            attributes: ['scope', 'sport_id', 'league_key', 'category', 'game_name', 'buffer_seconds'],
            raw: true,
        }),
        readGlobalBuffer().catch(() => 0),
    ]);

    const map = { global, grid: {}, sports: {}, casino: {} };
    for (const row of rows) {
        const seconds = num(row.buffer_seconds);
        if (row.scope === 'sports') {
            if (row.sport_id == null || !row.category) continue;
            const sid = String(row.sport_id);
            const league = String(row.league_key || DEFAULT_LEAGUE_KEY).toLowerCase();
            const isDefault = league === DEFAULT_LEAGUE_KEY;
            // A default cell at 0 is "unset"; a variant row at 0 is an explicit
            // override and must stay, or it would silently inherit again.
            if (isDefault && seconds <= 0) continue;
            ((map.grid[sid] ||= {})[league] ||= {})[row.category] = Math.max(seconds, 0);
            if (isDefault && LEGACY_BUFFER_VIEW[row.category]) {
                (map.sports[sid] ||= {})[LEGACY_BUFFER_VIEW[row.category]] = seconds;
            }
        } else if (row.scope === 'casino') {
            if (seconds <= 0 || !row.game_name) continue;
            map.casino[String(row.game_name).toLowerCase()] = seconds;
        }
    }
    return map;
};

const EMPTY_BUFFERS = { global: 0, grid: {}, sports: {}, casino: {} };

const getBufferMap = () => readThrough(KEY_BUFFER, buildBufferMap, EMPTY_BUFFERS);

// Saved seconds for one (sport, league, market) cell after inheritance, or 0.
// Frontend mirror: getSportsBufferSeconds() in frontend/src/apiservices/bettingConfig.js.
const resolveSportsBuffer = (map, sportId, leagueKey, marketKey) => {
    const sport = map?.grid?.[String(sportId)];
    if (!sport) return 0;
    if (leagueKey && leagueKey !== DEFAULT_LEAGUE_KEY) {
        const own = sport?.[leagueKey]?.[marketKey];
        if (own !== undefined) return num(own);
    }
    return num(sport?.[DEFAULT_LEAGUE_KEY]?.[marketKey]);
};

// Seconds for one sports bet: its (sport, league, market) cell after
// inheritance, else the platform-wide value, else 0 (caller falls back to its
// env default). `bet` uses SportsBet column names: gtype, market_type (market
// name), badlo, league_name.
// `allowGlobalFallback: false` skips the platform-wide value — the bet slip
// only lets live-tracked markets (Match Odds / Bookmaker) inherit it, and the
// server-side buffer (sportsbet/betBuffer.js) must resolve the same number.
const getSportsBufferSeconds = async (sportId, bet, { allowGlobalFallback = true } = {}) => {
    const map = await getBufferMap();
    const seconds = resolveSportsBuffer(
        map,
        sportId,
        leagueKeyFromName(sportId, bet?.league_name),
        BetBufferConfig.marketKeyOf(bet)
    );
    return seconds || (allowGlobalFallback ? num(map?.global) : 0);
};

// Seconds for one casino game, or 0 when unset. Casino has never used the
// platform-wide buffer (it is a frontend env constant today), so no fallback
// to `global` here — an unconfigured game keeps the env default.
const getCasinoBufferSeconds = async (gameName) => {
    const map = await getBufferMap();
    return num(map?.casino?.[String(gameName || '').toLowerCase()]);
};

// ── Casino limits ──────────────────────────────────────────────────────────
// Shape: { "teen20": { min: 100, max: 25000 } } — sides that are not
// overridden are simply absent.
const buildCasinoLimitMap = async () => {
    const rows = await BetLimitOverride.findAll({
        where: { scope: 'casino', is_active: true },
        attributes: ['game_name', 'min_stake', 'max_stake'],
        raw: true,
    });

    const map = {};
    for (const row of rows) {
        if (!row.game_name) continue;
        const min = limitSide(row.min_stake);
        const max = limitSide(row.max_stake);
        if (min === null && max === null) continue;
        const entry = {};
        if (min !== null) entry.min = min;
        if (max !== null) entry.max = max;
        map[String(row.game_name).toLowerCase()] = entry;
    }
    return map;
};

const getCasinoLimitMap = () => readThrough(KEY_CASINO_LIMITS, buildCasinoLimitMap, {});

// { min, max } for one casino game — either side may be absent.
const getCasinoLimits = async (gameName) => {
    const map = await getCasinoLimitMap();
    return map?.[String(gameName || '').toLowerCase()] || {};
};

// ── Sports (event) limits ──────────────────────────────────────────────────
// Shape: { "<market_id>": { min: 100, max: 50000 } }
const buildEventLimitMap = async (eventId) => {
    const rows = await BetLimitOverride.findAll({
        where: { scope: 'sports', event_id: String(eventId), is_active: true },
        attributes: ['market_id', 'min_stake', 'max_stake'],
        raw: true,
    });

    const map = {};
    for (const row of rows) {
        if (!row.market_id) continue;
        const min = limitSide(row.min_stake);
        const max = limitSide(row.max_stake);
        if (min === null && max === null) continue;
        const entry = {};
        if (min !== null) entry.min = min;
        if (max !== null) entry.max = max;
        map[String(row.market_id)] = entry;
    }
    return map;
};

const getEventLimitMap = (eventId) => {
    if (!eventId) return Promise.resolve({});
    return readThrough(keyEventLimits(eventId), () => buildEventLimitMap(eventId), {});
};

// { min, max } for one market of one event — either side may be absent.
const getMarketLimits = async (eventId, marketId) => {
    if (!eventId || !marketId) return {};
    const map = await getEventLimitMap(eventId);
    return map?.[String(marketId)] || {};
};

// ── Max odds ───────────────────────────────────────────────────────────────
// Shape: { "4": { name: "Cricket",
//                 match_odds: { max: 4, limited_overs_only: true },
//                 leagues: { t10xi: { match_odds: { max: 0, limited_overs_only: false } } } } }
// The top-level category cells are the DEFAULT league and appear only with
// max > 0 — an absent cell means "no cap" (the pre-2026-09-15 shape, so an old
// bundle keeps reading the sport cap). `leagues` holds every SAVED variant row,
// max 0 included: that is an explicit "no cap for this league" and beats the
// sport's cap; an absent league cell inherits the default cell. The flag is
// kept only for cricket, the one sport it means anything for.
const buildMaxOddsMap = async () => {
    const rows = await MaxOddsConfig.findAll({
        attributes: ['sport_id', 'league_key', 'category', 'max_odds', 'limited_overs_only'],
        raw: true,
    });

    const map = {};
    const entryOf = (sid) => (map[sid] ||= { name: sportNameById(sid) });
    for (const row of rows) {
        if (!MaxOddsConfig.CATEGORIES.includes(row.category)) continue;
        const max = num(row.max_odds);
        const sid = String(row.sport_id);
        const league = String(row.league_key || DEFAULT_LEAGUE_KEY).toLowerCase();
        const cell = {
            max: Math.max(max, 0),
            limited_overs_only: !!row.limited_overs_only
                && Number(row.sport_id) === MaxOddsConfig.LIMITED_OVERS_SPORT_ID,
        };
        if (league === DEFAULT_LEAGUE_KEY) {
            if (max <= 0) continue;
            entryOf(sid)[row.category] = cell;
        } else {
            ((entryOf(sid).leagues ||= {})[league] ||= {})[row.category] = cell;
        }
    }
    return map;
};

const getMaxOddsMap = () => readThrough(KEY_MAX_ODDS, buildMaxOddsMap, {});

// { max, limited_overs_only, sport, league } for one sports market, or null
// when the market has no cap (unset/0 cell, an explicit "no cap" league row, or
// a fancy-family gtype that is never capped). `leagueName` is the feed cname —
// callers must pass a SERVER-resolved name (SportsLeagueResolver), never a raw
// client field. Frontend mirror: getSportsMaxOddsRule() in bettingConfig.js.
const getMaxOddsRule = async (sportId, gtype, leagueName) => {
    const category = MaxOddsConfig.categoryFromGtype(gtype);
    if (!category) return null;
    const map = await getMaxOddsMap();
    const entry = map?.[String(sportId)];
    if (!entry) return null;
    const leagueKey = leagueKeyFromName(sportId, leagueName);
    const own = leagueKey !== DEFAULT_LEAGUE_KEY ? entry.leagues?.[leagueKey]?.[category] : undefined;
    const cell = own !== undefined ? own : entry[category];
    const max = num(cell?.max);
    if (max <= 0) return null;
    return {
        max,
        limited_overs_only: !!cell.limited_overs_only,
        sport: entry.name || sportNameById(sportId),
        league: own !== undefined ? leagueKey : DEFAULT_LEAGUE_KEY,
    };
};

// ── Virtual league limits ──────────────────────────────────────────────────
// Shape: { "4": { ecricket: { min: 200, max: 0 }, t5xi: { min: 100, max: 0 } },
//          "69": { wwevirtual: { … } } }
// 0 on a side = not set (feed value applies). Admin Settings → Virtual Bet Limits.
const buildVirtualLimitMap = async () => {
    const rows = await VirtualBetLimit.findAll({
        attributes: ['sport_id', 'league_key', 'min_stake', 'max_stake'],
        raw: true,
    });
    const map = {};
    for (const row of rows) {
        (map[String(row.sport_id)] ||= {})[String(row.league_key)] = {
            min: Math.max(num(row.min_stake), 0),
            max: Math.max(num(row.max_stake), 0),
        };
    }
    return map;
};

const getVirtualLimitMap = () => readThrough(KEY_VIRTUAL_LIMITS, buildVirtualLimitMap, {});

// { min, max, league } for a bet in a virtual league, or null for a real match
// (or a virtual league with neither side set). `leagueName` must be the
// SERVER-resolved name (SportsLeagueResolver). Frontend mirror:
// peekVirtualLimit() in bettingConfig.js.
const getVirtualLimit = async (sportId, leagueName) => {
    const leagueKey = leagueKeyFromName(sportId, leagueName);
    if (leagueKey === DEFAULT_LEAGUE_KEY) return null;
    const map = await getVirtualLimitMap();
    const cell = map?.[String(sportId)]?.[leagueKey];
    if (!cell || (!(cell.min > 0) && !(cell.max > 0))) return null;
    return { min: num(cell.min), max: num(cell.max), league: leagueKey };
};

// ── Invalidation (called by the admin write endpoints) ─────────────────────
const invalidate = async (key) => {
    microDel(key);
    try {
        await redis.del(key);
    } catch (err) {
        console.warn(`[BettingConfig] redis del failed for ${key}:`, err.message);
    }
};

const invalidateBuffers = () => invalidate(KEY_BUFFER);
const invalidateCasinoLimits = () => invalidate(KEY_CASINO_LIMITS);
const invalidateEventLimits = (eventId) => invalidate(keyEventLimits(eventId));
const invalidateMaxOdds = () => invalidate(KEY_MAX_ODDS);
const invalidateVirtualLimits = () => invalidate(KEY_VIRTUAL_LIMITS);

export default {
    getBufferMap,
    getSportsBufferSeconds,
    getCasinoBufferSeconds,
    getCasinoLimitMap,
    getCasinoLimits,
    getEventLimitMap,
    getMarketLimits,
    getMaxOddsMap,
    getMaxOddsRule,
    getVirtualLimitMap,
    getVirtualLimit,
    invalidateVirtualLimits,
    KEY_VIRTUAL_LIMITS,
    invalidateBuffers,
    invalidateCasinoLimits,
    invalidateEventLimits,
    invalidateMaxOdds,
    KEY_BUFFER,
    KEY_CASINO_LIMITS,
    KEY_MAX_ODDS,
    keyEventLimits,
};
