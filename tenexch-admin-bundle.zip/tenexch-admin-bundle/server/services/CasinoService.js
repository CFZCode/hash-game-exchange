import axios from "axios";
import dotenv from "dotenv";
dotenv.config();
import redis from "../config/redisClient.js"; // Import Redis Client
import CasinoBet from "../model/user/casino.js";
import sequelize from "../config/db.js";
import UserExposure from "../model/user/UserExposure.js";
import User from "../model/user/User.js";
import Wallet from "../model/admin/Wallet.js";
import TotalExposure from "../model/user/TotalExposure.js";
import { emitBalanceUpdate } from "../utils/socketUtils.js";
import { QueryTypes, Op } from "sequelize";
import { casinoAllDataKey, fetchCasinoTypeFeed } from "../helper/casinoFeed.js";
import {
  fetchWinNameFromVendor,
  readResults,
  readTieRounds,
  resolveRoundStamp,
  storeResults,
} from "../helper/casinoResults.js";
import {
  findCasinoMarket,
  calculateCasinoBook,
  calculateTwoWayBook,
  calculateLadderBook,
  casinoMarketGameType,
  isSuperOverFamily,
  extractBookmakerRunners,
} from "../helper/casinoMarketBook.js";
import { TOTAL_EXPOSURE_SQL } from "../helper/totalExposure.js";
import { MESSAGES } from "../constants/messages.js";
import { oppositeSides } from "../helper/casinoExclusiveSides.js";
import { checkCasinoBetOffered } from "../helper/casinoBetOffer.js";

// Tables whose last-results get the archiver's drawn rounds merged back in.
const TIE_MERGED_TYPES = new Set(["poker20"]);

// CASINO_API_BASE_URL is the one and only casino vendor. DIAMOND_BASE_URL
// (:3009) used to be tried first in every call below and has been refusing
// connections for months, so each request paid a doomed connect and a
// "trying fallback..." log line before reaching the host that actually answers.
// The two vendors also disagreed on path, param name and wrapping, so the old
// fallback leg — not the primary — is what these calls now keep.
const BASE_URL = process.env.CASINO_API_BASE_URL;
const API_KEY = process.env.CASINO_API_KEY;
const CACHE_TTL = 2; // Cache time in seconds
const round2 = (n) => Math.round((Number(n) || 0) * 100) / 100;

// teen / teen62 quote "Player A"/"Player B" on TWO markets (Main, etype
// "match" / Consecutive, etype "fancy1") and the payload's mtype is the only
// discriminator. Only Main is the two-way book registered in
// casinoMarketBook.js; a Consecutive bet keeps the legacy single row.
const isTeenOneDayConsecutiveBet = ({ gameName, selection, mtype }) =>
  ["teen", "teen62"].includes(String(gameName).toLowerCase()) &&
  ["player a", "player b"].includes(String(selection).trim().toLowerCase()) &&
  String(mtype || "").toLowerCase() !== "match";

// team_name written by the LEGACY single-row exposure path. placeBet writes it
// and undoBet reverses it, so the two must derive it identically.
const legacyExposureTeamName = ({ gameName, selection, player_name, mtype }) => {
  if (gameName === "abj") return player_name || selection;
  return isTeenOneDayConsecutiveBet({ gameName, selection, mtype })
    ? `${String(selection).trim()} Consecutive`
    : selection;
};
// The header reads total_exposures (socket getBalance heartbeat); every writer
// must use the SAME query. Its one copy lives in helper/totalExposure.js;
// re-exported here because services/admin/casinoVoidService.js imports it
// from this module.
export { TOTAL_EXPOSURE_SQL };

// Roulette tables: the bet must be one the live feed is offering right now.
// The server used to book whatever selection + odds the client sent; on
// ourroullete that stored bets like "3" @9.70 (a single number at corner odds),
// which then settled as a straight bet. Every roulette page sends selection =
// feed `n` and odds = `b` (back) / `l` (lay) of the clicked position, so a real
// click always passes; odds never move inside a round (measured 2026-10-07).
// See docs/plans/2026-10-07-roulette-board-chips.md §9.
const ROULETTE_GAMES = new Set(["roulette11", "roulette12", "roulette13", "ourroullete"]);
const sameName = (a, b) =>
  String(a ?? "").replace(/\s+/g, "").toLowerCase() ===
  String(b ?? "").replace(/\s+/g, "").toLowerCase();

async function assertRouletteBetOffered({ gameName, selection, odds, type, roundId }) {
  let root = null;
  try {
    const feed = await CasinoService.fetchAllData(gameName);
    root = feed?.data?.data ?? feed?.data ?? feed ?? null;
  } catch {
    root = null;
  }
  const liveMid = root?.mid ?? root?.gmid ?? null;
  if (!root || String(liveMid) !== String(roundId) || !(Number(root?.lt ?? 0) > 0)) {
    throw new Error(MESSAGES.BET.GAME_SUSPEND);
  }
  const side = String(type || "back").toLowerCase() === "lay" ? "l" : "b";
  const open = (root.sub || []).filter(
    (item) => Number(item?.s) === 1 && Number(item?.[side]) > 0 && sameName(item?.n, selection)
  );
  if (!open.length) throw new Error(MESSAGES.BET.GAME_SUSPEND);
  const want = Number(odds) || 0;
  if (!open.some((item) => Math.abs(Number(item[side]) - want) < 0.005)) {
    throw new Error(MESSAGES.BET.ODDS_CHANGED);
  }
}

// Every casino table: the bet must be on the round the live feed is showing
// now, on a market that is open (helper/casinoBetOffer.js). Andar Bahar 50 /
// 150 also get their deal position from the feed: the "/N" the client put in
// player_name is replaced, because the bet is decided only by cards from #N on.
// Doli Dana per-roll markets get their roll from the feed (`betRoundId`, stored
// as round_id; exposure stays keyed by the match).
// Returns { player_name, betRoundId }. Plan: docs/plans/2026-10-14-casino-placement-feed-check.md,
// docs/plans/2026-10-15-dolidana-side-markets-per-roll.md
async function assertCasinoBetOffered({ gameName, selection, eventId, roundId, player_name }) {
  let feed = null;
  try {
    feed = await CasinoService.fetchAllData(gameName);
  } catch {
    feed = null;
  }
  const verdict = checkCasinoBetOffered({ gameName, selection, roundId: eventId, feed });
  const roundOk = !roundId || String(roundId) === String(eventId);
  if (!verdict.ok || !roundOk) {
    console.warn("[placeBet] rejected: not offered", {
      gameName, selection, eventId, roundId, reason: verdict.reason || "round-id",
    });
    throw new Error(MESSAGES.BET.GAME_SUSPEND);
  }
  if (verdict.unchecked) {
    console.warn("[placeBet] feed check skipped:", gameName, verdict.unchecked);
  }
  if (verdict.position) {
    return { player_name: `${String(selection).trim()}/${verdict.position}`, betRoundId: null };
  }
  return { player_name, betRoundId: verdict.rollMid || null };
}

// Non-bettable third outcome that makes the SuperOver Bookmaker book EXHAUSTIVE.
// A super over can TIE (both teams lose — the result feed carries a 'T'), so a
// plain two-team [A,B] book would UNDER-LOCK a hedged both-teams position (it
// locks min(A,B) but a tie loses BOTH stakes). Adding this phantom runner books
// the tie as −stake so the worst-case lock covers it. It is never a selection,
// so settlement (resolveSuperover3) never sees it, and it is not read by any
// frontend cell — the display only looks up the real team names. (Mirrors dt6's
// non-bettable "Tie" runner.) Must not collide with the Tie market's own "Tie"
// nat, nor end in back/lay/totalstake (the header-exposure SQL filter).
const SUPEROVER_TIE_RUNNER = "The Tie";

// Games whose Bookmaker market is booked two-way (profit on the backed team,
// worst-case loss on the other). The sibling games (superover, cricketv3) share
// the EXACT same layout and machinery — add them here to extend the behaviour.
// superover added 2026-10-10: its header exposure summed every Bookmaker bet
// (back + lay on ENG, or ENG + RSA) instead of netting them —
// docs/worklog/2026-10-10.md item 8.
const SUPEROVER_BOOKMAKER_GAMES = new Set(["superover3", "superover2", "superover"]);
// Tables whose Bookmaker bets are refunded on a TIE (no "The Tie" runner in
// their book). Must match SUPEROVER_TIE_REFUND_GAMES in settlementCasinoWorker.js.
// superover3 (Mini) added 2026-10-12 by user decision ("Refund like Super
// Over") — docs/plans/2026-10-12-mini-superover-parity.md.
const SUPEROVER_TIE_REFUND_GAMES = new Set(["superover", "superover2", "superover3"]);

// Resolve this round's two Bookmaker team names from the live feed. The names
// rotate every round, so the Bookmaker market can't live in the static MARKETS
// registry — it's booked dynamically at placement instead. Shape-tolerant:
// fetchAllData returns the provider body (primary) or its `.data` (fallback), and
// extractBookmakerRunners peels one more `.data` layer, so try both wrappings.
// Returns [] on any failure → placement falls back to the legacy single-row path.
const resolveSuperOverBookmakerRunners = async (gameName) => {
  try {
    const feed = await CasinoService.fetchAllData(gameName);
    let info = extractBookmakerRunners(feed);
    if ((info?.runners?.length || 0) < 2 && feed?.data) {
      info = extractBookmakerRunners(feed.data);
    }
    return info?.runners || [];
  } catch (_) {
    return [];
  }
};

// Helper for caching. On a cache miss, concurrent callers for the same key
// share one in-flight upstream request instead of each hitting the vendor.
const inFlightFetches = new Map();

// Redis is an ACCELERATOR here, never a dependency — every path below must end
// at the vendor if redis can't answer. A redis that is *down* rejects and is
// caught, but a redis that is *stuck* (node hung, network black hole) is worse:
// ioredis queues the command on its offline queue and the promise never
// settles, so without this bound every casino request would hang behind it.
const REDIS_TIMEOUT_MS = Number(process.env.CASINO_REDIS_TIMEOUT_MS || 300);
// After a timeout, stop touching redis for a moment instead of paying (and
// queueing) another command per request while it is unreachable.
const REDIS_COOLDOWN_MS = Number(process.env.CASINO_REDIS_COOLDOWN_MS || 5000);
let redisDownUntil = 0;

const markRedisDown = (key, reason) => {
  if (Date.now() >= redisDownUntil) {
    console.error(`❌ Redis unusable for ${key} (${reason}) — going direct to the API for ${REDIS_COOLDOWN_MS}ms`);
  }
  redisDownUntil = Date.now() + REDIS_COOLDOWN_MS;
};

const redisIsUsable = () => Date.now() >= redisDownUntil;

// Resolves the cached string, or null for "redis had nothing for me" — a miss,
// an error and a timeout are all the same answer to the caller: go fetch it.
const redisGetBounded = (key) =>
  new Promise((resolve) => {
    let settled = false;
    const finish = (value) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve(value);
    };
    const timer = setTimeout(() => {
      markRedisDown(key, `no reply in ${REDIS_TIMEOUT_MS}ms`);
      finish(null);
    }, REDIS_TIMEOUT_MS);

    redis
      .get(key)
      .then((value) => finish(value))
      .catch((err) => {
        markRedisDown(key, err.message);
        finish(null);
      });
  });

const getCachedData = async (key, fetchFunction, ttl = CACHE_TTL) => {
  if (redisIsUsable()) {
    try {
      const cached = await redisGetBounded(key);
      if (cached) {
        return JSON.parse(cached);
      }
    } catch (err) {
      // Only a JSON.parse failure lands here — a poisoned key must not become a
      // 500 either, so drop it and fetch fresh.
      console.error(`❌ Redis Cache Error for ${key}:`, err.message);
    }
  }

  if (inFlightFetches.has(key)) {
    return inFlightFetches.get(key);
  }

  const fetchPromise = (async () => {
    try {
      const data = await fetchFunction();

      // Set Cache (Async, don't block). Skipped while redis is known-bad so a
      // hung node doesn't collect one queued command per request.
      if (redisIsUsable()) {
        redis.set(key, JSON.stringify(data), 'EX', ttl).catch(err => {
          markRedisDown(key, err.message);
          console.error(`❌ Failed to set cache for ${key}:`, err.message);
        });
      }

      return data;
    } catch (err) {
      console.error(`❌ API Error for ${key}:`, err.message);
      throw err;
    }
  })();

  inFlightFetches.set(key, fetchPromise);
  try {
    return await fetchPromise;
  } finally {
    inFlightFetches.delete(key);
  }
};

const CasinoService = {
  // Served out of casinoall:<type>, which casinobet/cron/casinoAllDataCron.js
  // rewrites for EVERY table roughly once a second — so the frontend's 1s poll
  // is a redis read and the vendor sees one request per table per second no
  // matter how many users sit on that table. getCachedData answers straight
  // from that key when it's there; on a miss (cron stopped, or a table it
  // doesn't warm) it falls back to fetching on demand and caching for
  // CACHE_TTL, collapsing concurrent misses into a single upstream call. The
  // vendor call itself lives in helper/casinoFeed.js so the cron writes the
  // exact shape this path would have returned.
  fetchAllData: async (type, data) => {
    if (!type) {
      throw new Error("Type are required casiono server");
    }

    return await getCachedData(casinoAllDataKey(type), () => fetchCasinoTypeFeed(type));
  },
  fetchCricketData: async (id) => {
    if (!id) {
      throw new Error("ID is required to fetch cricket data");
    }
    const key = `casino_cricket_data_${id}`;
    return await getCachedData(key, async () => {
      // NOTE: the vendor answers 404 for /esid — it does not serve this route.
      // Both legs of the old primary/fallback pair hit the same wall, so this
      // is not a regression, but the caller has been getting nothing for a
      // while and needs a real source before it can work.
      const response = await axios.get(`${BASE_URL}/esid`, {
        headers: { Accept: "*/*" },
        params: { sid: id, key: API_KEY },
        timeout: 3000
      });
      return response.data;
    });
  },
  fetchCasinolastResults: async (type) => {
    if (!type) {
      throw new Error("Type are required to fetch casino results");
    }
    const key = `casino_last_results_${type}`;
    // 1s TTL: clients poll this every second, so the shared default would
    // add up to 2s of extra staleness on top of the poll interval.
    return await getCachedData(key, async () => {
      const response = await axios.get(`${BASE_URL}/casino/lastresultsnew`, {
        headers: { Accept: "*/*" },
        // Vendors disagree on casing: 138.68.178.21:8000 requires lowercase
        // `gtype` (400s on `gType`), the avrkhub demo host requires `gType`
        // (400s on `gtype`). Sending both satisfies either one.
        params: { gtype: type, gType: type, key: API_KEY },
        timeout: 8000
      });
      const data = response.data?.data;
      // 20-20 Poker: the vendor list drops drawn rounds; the archiver stores
      // them as win "0" and they go back in their place here (shown as "T").
      // Plan: docs/plans/2026-10-12-poker-tie-full-refund-hidden.md
      if (TIE_MERGED_TYPES.has(type) && Array.isArray(data?.res) && data.res.length) {
        try {
          const mids = data.res.map((r) => String(r.mid)).sort();
          const ties = await readTieRounds(type, mids[0], mids[mids.length - 1]);
          if (ties.length) {
            const listed = new Set(mids);
            const merged = [...data.res, ...ties.filter((m) => !listed.has(m)).map((m) => ({ mid: Number(m), win: "0" }))]
              .sort((a, b) => (String(b.mid) > String(a.mid) ? 1 : String(b.mid) < String(a.mid) ? -1 : 0))
              .slice(0, data.res.length);
            return { ...data, res: merged };
          }
        } catch (err) {
          console.error(`[CasinoService] tie merge failed for ${type}:`, err.message);
        }
      }
      return data;
    }, 1);
  },

  fetchCasionDetailResults: async (type, mid) => {
    if (!type || !mid) {
      throw new Error("Type and mid are required to fetch casino detail results");
    }

    const key = `casino_detail_results_${type}_${mid}`;
    return await getCachedData(key, async () => {
      const response = await axios.get(`${BASE_URL}/detail_casino_results`, {
        headers: { Accept: "*/*" },
        params: { gtype: type, mid: mid, key: API_KEY },
        timeout: 8000
      });
      return response.data?.data;
    });
  },

  // Result report (/report/casinoresult ka data).
  //
  // Source ab casino_result_archive table hai, redis nahi: vendor sirf aakhri
  // 10 rounds deta hai, aur pehle wala redis zset 7 din / 300 rows par kata
  // hua tha (restart par to wo bhi udd jaata tha). Archiver worker
  // (casinobet/cron/casinoResultsArchiveCron.js) har table ka har round DB me
  // likhta hai, 115 din retention ke saath.
  //
  // Request par live 10 rounds bhi fetch hote hain aur wahin archive me chale
  // jaate hain — isliye abhi-abhi khatam hua round turant dikhta hai (archiver
  // ke 20s pass ka intezaar nahi), aur archiver band ho to bhi page chalta hai.
  //
  // date (YYYY-MM-DD, IST calendar din) diya ho to usi din ke saare rounds
  // aate hain; frontend hi paginate/search karta hai. Bina date ke latest N.
  fetchCasinoResultReport: async (type, options = {}) => {
    if (!type) {
      throw new Error("Type is required to fetch casino result report");
    }
    const date = options.date || null;
    const limit = Number(options.limit) || null;

    // ---- 1. Live tip: vendor ke 10 rounds + winName, aur archive me upsert.
    let res1 = null;
    let live = [];
    try {
      // upstream cold ho to pehli call timeout ho sakti hai — ek retry ke baad
      // prayah succeed karti hai.
      let last;
      for (let attempt = 0; ; attempt++) {
        try {
          last = await CasinoService.fetchCasinolastResults(type);
          break;
        } catch (err) {
          if (attempt >= 1) throw err;
          await new Promise((resolve) => setTimeout(resolve, 500));
        }
      }
      const container = last && last.data && (last.data.res || last.data.res1) ? last.data : last;
      const res = Array.isArray(container && container.res) ? container.res : [];
      res1 = (container && container.res1) || null;

      const winNameFor = async (item) => {
        const key = `casino_result_winname_${type}_${item.mid}`;
        try {
          const cached = await redis.get(key);
          if (cached !== null) return cached || null;
        } catch (err) { /* redis down — direct fetch */ }
        let winName = null;
        try {
          winName = await fetchWinNameFromVendor(type, item.mid);
          // Result immutable hai to 6h cache theek, par jo round abhi chal raha
          // hai uska naam abhi null hai — usko 6 ghante cache karna matlab wo
          // round page par hamesha bina naam ke. Khali jawab 60s hi rakho.
          redis.set(key, winName || '', 'EX', winName ? 6 * 60 * 60 : 60).catch(() => {});
        } catch (err) { /* detail fail — winName null, archiver baad me bharega */ }
        return winName;
      };

      for (let i = 0; i < res.length; i += 5) {
        const chunk = res.slice(i, i + 5);
        const names = await Promise.all(chunk.map(winNameFor));
        chunk.forEach((item, j) => live.push({ ...item, winName: names[j] }));
      }

      if (live.length) {
        storeResults(type, live).catch((err) => {
          console.warn(`⚠️ casino result archive write failed: ${err.message}`);
        });
      }
    } catch (err) {
      // Vendor down — DB me jo hai wahi jawab hai.
      console.warn(`⚠️ casino live results unavailable for ${type}: ${err.message}`);
    }

    // ---- 2. Poora din (ya latest N) archive se.
    let rows;
    try {
      rows = await readResults({ gtype: type, date, limit });
    } catch (err) {
      // Table na ho / DB hiccup — page live 10 ke saath chalta rahe.
      console.error(`❌ casino result archive read failed: ${err.message}`);
      return { data: { res: live, res1 }, total: live.length };
    }

    // Abhi-abhi fetch kiya round archive-write complete hone se pehle bhi dikhna
    // chahiye. Merge positional hai, re-sort nahi: DB ka order pehle se sahi hai
    // (readResults ka comment dekho — mid par sort karna ballbyball/superover
    // jaise random-mid tables ko shuffle kar deta). Jo live round DB me pehle se
    // hai uska naam usi jagah bhar do; jo nahi hai wo sabse naya hai, upar lagao.
    const wanted = (item) => {
      if (!date) return true;
      // resolveRoundStamp, parseMid nahi: superover/ballbyball jaise tables ka
      // mid timestamp nahi hota, unka din "abhi" (IST) hai.
      return resolveRoundStamp(item.mid).round_date === date;
    };

    const byMid = new Map(rows.map((r) => [String(r.mid), r]));
    const fresh = [];
    live.filter(wanted).forEach((item) => {
      const key = String(item.mid);
      const existing = byMid.get(key);
      if (existing) {
        if (item.win != null) existing.win = item.win;
        if (item.winName) existing.winName = existing.winName || item.winName;
        return;
      }
      const stamp = resolveRoundStamp(item.mid);
      fresh.push({
        mid: key,
        win: item.win != null ? item.win : null,
        winName: item.winName || null,
        round_date: stamp.round_date,
        round_time: stamp.round_time,
      });
    });

    // `live` vendor ke newest-first order me hai, aur `fresh` usi order me bhara
    // gaya — to seedha aage jod do.
    const finalRes = [...fresh, ...rows];

    return { data: { res: finalRes, res1 }, total: finalRes.length };
  },

  fetchCasionDetailsData: async (gmid, sid) => {
    if (!gmid || !sid) {
      throw new Error("gmid and sid are required to fetch casino details data");
    }

    const key = `casino_details_data_${gmid}_${sid}`;
    return await getCachedData(key, async () => {
      // NOTE: the vendor answers 404 for /getDetailsData too — same as /esid,
      // both legs of the old pair were dead. Needs a real source.
      const response = await axios.get(`${BASE_URL}/getDetailsData`, {
        headers: { Accept: "*/*" },
        params: { gmid: gmid, sid: sid, key: API_KEY },
        timeout: 3000
      });
      return response.data;
    });
  },

  placeBet: async (betData) => {
    // Checked BEFORE opening the DB transaction: the feed read may take a
    // moment, and a transaction must never sit open across it.
    if (ROULETTE_GAMES.has(String(betData?.gameName || "").toLowerCase())) {
      await assertRouletteBetOffered(betData);
    } else {
      betData = { ...betData, ...(await assertCasinoBetOffered(betData)) };
    }

    const transaction = await sequelize.transaction();

    try {
      const {
        userId,
        player_name,
        gameName,
        odds,
        amount,
        selection,
        exposer,
        libality,
        eventId,
        roundId,
        betRoundId,
        type,
        mtype,
        ip_address,
        browser
      } = betData;

      if (!userId || !gameName || !selection || !amount || !odds) {
        throw new Error("Missing required bet fields");
      }

      const wallet = await Wallet.findOne({
        where: { user_id: userId },
        transaction,
        lock: transaction.LOCK.UPDATE
      });

      if (!wallet) {
        throw new Error("Wallet not found");
      }

      // One side per round (aaa/aaa2/vaaa Under 7 / Over 7): reject before
      // anything is written. Runs after the wallet row lock, so a concurrent
      // Under + Over pair for the same user is serialised and the second one
      // sees the first. Plan: docs/plans/2026-10-08-casino-under7-over7-exclusive.md
      const opposite = oppositeSides(gameName, selection);
      if (opposite.length && eventId) {
        const clash = await CasinoBet.findOne({
          where: {
            user_id: userId,
            game_name: gameName,
            event_id: eventId,
            selection: { [Op.in]: opposite },
            status: { [Op.in]: ["open", "processing"] },
            [Op.or]: [{ result_status: null }, { result_status: "" }],
          },
          attributes: ["id", "selection"],
          transaction,
        });
        if (clash) {
          const err = new Error(MESSAGES.BET.OPPOSITE_SIDE_EXISTS(clash.selection));
          err.statusCode = 400;
          err.code = "OPPOSITE_SIDE_EXISTS";
          throw err;
        }
      }

      const currentCash = Number(wallet.cash);

      // AAA / AAA2 main players use a three-runner profit-and-loss book.
      // teen/teen62 Consecutive bets share the Main nats but are their own
      // markets: one YES/NO line PER PLAYER (game_type "teen:conA" / "teen:conB"),
      // so back + lay on the same player net (back 100 @2.43 + lay 100 @2.53 →
      // lock 10, was 253 on the legacy row) while A and B stay separate — both can
      // have a consecutive, so they must never net against each other. Main is
      // untouched. Plan: docs/plans/2026-10-13-teen-oneday-audit-fixes.md (B).
      let market = isTeenOneDayConsecutiveBet({ gameName, selection, mtype })
        ? { key: `con${String(selection).trim().slice(-1).toUpperCase()}`, twoWay: true }
        : findCasinoMarket(gameName, selection, mtype);

      // Mini SuperOver Bookmaker (match-winner) is a two-runner exchange book:
      // the backed team shows the profit and the other team the worst-case loss.
      // Its runner names rotate every round, so it can't be a static MARKETS
      // entry — resolve this round's teams from the live feed and book it here.
      // Only the Bookmaker selection (a team name) matches; Fancy/Tie/Fancy1
      // selections don't, so they keep the legacy single-row (worst-case-only)
      // path — exactly what the other markets should still show.
      if (
        !market &&
        SUPEROVER_BOOKMAKER_GAMES.has(String(gameName).trim().toLowerCase())
      ) {
        const runners = await resolveSuperOverBookmakerRunners(gameName);
        const sel = String(selection).trim().toLowerCase();
        if (
          runners.length >= 2 &&
          runners.some((r) => String(r).trim().toLowerCase() === sel)
        ) {
          // superover refunds its Bookmaker bets on a TIE (resolveSuperover3), so
          // a tie risks nothing there and the book is ENG/RSA only — the header
          // shows the worse of the two, 0 when both are positive. Tables not in
          // SUPEROVER_TIE_REFUND_GAMES lose backs on a tie, so they keep the runner.
          const tieRefunds = SUPEROVER_TIE_REFUND_GAMES.has(String(gameName).trim().toLowerCase());
          market = { key: "bookmaker", runners: tieRefunds ? [...runners] : [...runners, SUPEROVER_TIE_RUNNER] };
        }
      }

      const gameType = market
        ? casinoMarketGameType(gameName, market.key)
        : null;

      // Load the existing book for the current round.
      const oldExposures = {};

      if (market) {
        const rows = await UserExposure.findAll({
          where: {
            user_id: userId,
            match_id: String(roundId),
            event_id: String(roundId),
            game_type: gameType,
          },
          transaction,
        });

        for (const row of rows) {
          oldExposures[row.team_name] =
            Number(row.exposure_amount) || 0;
        }
      }

      let bookRows;

      if (market?.twoWay) {
        bookRows = calculateTwoWayBook({
          selection,
          stake: amount,
          odds,
          type,
          oldExposures,
        });
      } else if (market?.ladder) {
        // Super Over session lines: one runs-ladder book per team (see
        // casinoMarketBook DYNAMIC_MARKETS.superover). Delta rows, like the
        // runner books below — the worst-case lock reads every ladder row.
        bookRows = calculateLadderBook({
          ladder: market.ladder,
          stake: amount,
          odds,
          type,
        });
      } else if (market) {
        bookRows = calculateCasinoBook({
          market,
          selection,
          stake: amount,
          odds,
          type,
        });
      } else {
        // Existing behavior for casino games not managed as a runner book.
        bookRows = [{
          team_name: legacyExposureTeamName({
            gameName,
            selection,
            player_name,
            mtype,
          }),
          delta: Number(exposer || 0),
        }];
      }

      // Lock only the change in the market's worst possible outcome.
      let effExposer = Number(exposer || 0);

      if (market) {
        const newTotals = {};

        for (const row of bookRows) {
          newTotals[row.team_name] =
            row.value !== undefined
              ? Number(row.value)
              : round2(
                (Number(oldExposures[row.team_name]) || 0) +
                Number(row.delta)
              );
        }

        const outcomeNames = market.twoWay
          ? [String(selection).trim()]
          : Object.keys(newTotals);

        const worstOf = (book) =>
          Math.min(
            0,
            ...outcomeNames.map((name) => Number(book[name]) || 0)
          );

        const oldWorst = worstOf(oldExposures);
        const newWorst = worstOf(newTotals);

        effExposer = -round2(
          Math.abs(newWorst) - Math.abs(oldWorst)
        );
      }

      if (effExposer < 0 && currentCash < Math.abs(effExposer)) {
        throw new Error("Insufficient balance");
      }

      wallet.cash = round2(currentCash + effExposer);
      await wallet.save({ transaction });

      const bet = await CasinoBet.create(
        {
          user_id: userId,
          player_name: player_name || "",
          odds,
          stake: amount,
          selection,
          exposer: effExposer,
          libality: libality || 0,
          game_name: gameName,
          status: "open",
          event_id: eventId || null,
          // Doli Dana per-roll market: the roll it is decided on (feed), so
          // settlement + the roll's result modal find it. Everything keyed by
          // the match (exposure rows, My Bets) keeps using roundId / eventId.
          round_id: betRoundId || roundId || 0,
          type: type || null,
          mtype: mtype || null,
          ip_address: ip_address || null,
          browser: browser || null,
        },
        { transaction }
      );

      // Store one row per possible AAA outcome.
      for (const row of bookRows) {
        const existingExposure = await UserExposure.findOne({
          where: {
            user_id: userId,
            match_id: String(roundId),
            team_name: row.team_name,
            event_id: String(roundId),
            game_type: gameType,
          },
          transaction,
        });

        const nextAmount = row.value !== undefined
          ? Number(row.value)
          : round2(
            (Number(existingExposure?.exposure_amount) || 0) +
            Number(row.delta)
          );

        if (existingExposure) {
          await existingExposure.update(
            { exposure_amount: nextAmount },
            { transaction }
          );
        } else {
          await UserExposure.create(
            {
              user_id: userId,
              match_id: String(roundId),
              exposure_amount: nextAmount,
              team_name: row.team_name,
              match_title: gameName,
              event_id: String(roundId),
              game_type: gameType,
              category: "casino",
            },
            { transaction }
          );
        }
      }

      // Preserve the other site's TotalExposure snapshot behavior.
      const exposureResults = await sequelize.query(TOTAL_EXPOSURE_SQL, {
        replacements: { user_id: String(userId) },
        type: QueryTypes.SELECT,
        transaction,
      });

      const totalUserExposure =
        parseFloat(exposureResults[0]?.total_exposure) || 0;

      await TotalExposure.upsert(
        {
          user_id: Number(userId),
          total_exposure: totalUserExposure,
        },
        { transaction }
      );

      await transaction.commit();

      (async () => {
        try {
          const freshWallet = await Wallet.findOne({
            where: { user_id: userId },
            raw: true,
          });

          emitBalanceUpdate(userId, {
            inr_balance: freshWallet?.inr_balance,
            cash: freshWallet?.cash,
            exposure: totalUserExposure,
          });
        } catch (error) {
          console.error(
            "[CasinoService.placeBet] balance emit failed:",
            error.message
          );
        }
      })();

      return bet.get({ plain: true });
    } catch (error) {
      await transaction.rollback();
      // Keep a typed rejection (statusCode) so the controller can answer 400.
      if (error?.statusCode) throw error;
      throw new Error(error.message || "Failed to place casino bet");
    }
  },

  /**
   * Player-facing undo of open bets on a still-open round.
   *
   * The tables that need this place a bet IMMEDIATELY on chip click (the
   * roulettes), where the on-table "Undo"/"Clear" buttons used to only remove
   * the chip visually while the money stayed locked. Reversal mirrors the
   * settlement void path exactly: cash gets the placement lock back, the
   * bet's delta comes back out of its exposure row, the bet closes as
   * status=closed / result_status=void / credit_amt=0. inr_balance and P/L
   * are untouched and no ledger row is written.
   *
   * Guards — do not relax any of them:
   *  - caller identity comes from the TOKEN (controller), never the body;
   *  - only the LEGACY single-row exposure path is reversible. A book
   *    market's row is a min() over the whole market and cannot be un-applied
   *    by reversing one bet's delta, so book-managed bets are refused.
   *  - bets unwind ONE BY ONE, never via a blanket DELETE of the round's
   *    exposure rows — other bets on the round may share those rows.
   *  - the round must still be OPEN FOR BETTING (live feed mid matches and
   *    lt > 0). On the roulettes nothing is revealed during the betting
   *    window (`card` stays empty until the spin), so an undo is exactly as
   *    informed as the original bet. If a game reveals information mid-round,
   *    an undo there would let players cancel known losers — re-justify
   *    before extending this to any other game.
   */
  undoBet: async ({ userId, gameName, roundId, all = false }) => {
    if (!userId || !gameName || !roundId) {
      throw new Error("Missing required undo fields");
    }

    // Exploit guard: re-fetch the live feed; the same round must still be
    // open for betting.
    let feedRoot = null;
    try {
      const feed = await CasinoService.fetchAllData(gameName);
      feedRoot = feed?.data?.data ?? feed?.data ?? feed ?? null;
    } catch (err) {
      feedRoot = null;
    }
    const liveMid = feedRoot?.mid ?? feedRoot?.gmid ?? null;
    const liveLt = Number(feedRoot?.lt ?? 0);
    if (!feedRoot || String(liveMid) !== String(roundId) || liveLt <= 0) {
      throw new Error("Betting is closed for this round — undo not allowed");
    }

    const transaction = await sequelize.transaction();
    try {
      const wallet = await Wallet.findOne({
        where: { user_id: userId },
        transaction,
        lock: transaction.LOCK.UPDATE,
      });
      if (!wallet) throw new Error("Wallet not found");

      const openBets = await CasinoBet.findAll({
        where: {
          user_id: userId,
          game_name: gameName,
          round_id: String(roundId),
          // The settlement worker claims EVERY open bet each pass (open →
          // processing) while it looks for a result, then puts it back. On a
          // round still open for betting (guard above) that result cannot exist,
          // so a "processing" bet is still undoable — matching only "open" made
          // Undo miss most of a multi-bet round ("No open bets to undo", user
          // 2026-10-12, after Repeat). Race-safe: this SELECT … FOR UPDATE waits
          // for a settle in progress and Postgres re-checks the WHERE, so a bet
          // the worker just closed drops out; after we void, the worker's
          // releaseBetToOpen (status processing + no result_status) and
          // settleBetCommon (exits on status closed) both skip it.
          status: { [Op.in]: ["open", "processing"] },
          result_status: { [Op.or]: [null, ""] },
        },
        order: [["id", "DESC"]],
        transaction,
        lock: transaction.LOCK.UPDATE,
      });

      // Undo reverses the most recent bet; Clear (all) reverses every open
      // bet on the round in this ONE transaction — a half-failed Clear would
      // leave the wallet and the exposure rows disagreeing.
      const targets = all ? openBets : openBets.slice(0, 1);
      if (!targets.length) {
        throw new Error("No open bets to undo on this round");
      }

      for (const bet of targets) {
        if (findCasinoMarket(bet.game_name, bet.selection, bet.mtype)) {
          throw new Error("This market cannot be undone");
        }
        // SuperOver Bookmaker bets are booked dynamically (runners resolved from
        // the live feed at placement), so findCasinoMarket can't see them. They
        // write namespaced exposure rows the legacy single-row reversal below
        // can't unwind — reject them too, or the wallet would be refunded while
        // the book rows are orphaned.
        if (isSuperOverFamily(bet.game_name)) {
          const bookedRow = await UserExposure.findOne({
            where: {
              user_id: userId,
              match_id: String(roundId),
              event_id: String(roundId),
              game_type: casinoMarketGameType(bet.game_name, "bookmaker"),
              team_name: bet.selection,
            },
            transaction,
          });
          if (bookedRow) {
            throw new Error("This market cannot be undone");
          }
        }
      }

      let cash = Number(wallet.cash || 0);

      for (const bet of targets) {
        const exposerNum = Number(bet.exposer || 0); // the (negative) lock

        // Placement did cash += exposer; reverse it.
        cash = round2(cash - exposerNum);

        const teamName = legacyExposureTeamName({
          gameName: bet.game_name,
          selection: bet.selection,
          player_name: bet.player_name,
          mtype: bet.mtype,
        });

        const row = await UserExposure.findOne({
          where: {
            user_id: userId,
            match_id: String(roundId),
            team_name: teamName,
            event_id: String(roundId),
            game_type: null,
          },
          transaction,
        });

        if (row) {
          const remaining = round2(
            Number(row.exposure_amount || 0) - exposerNum
          );
          if (Math.abs(remaining) < 0.005) {
            await row.destroy({ transaction });
          } else {
            await row.update(
              { exposure_amount: remaining },
              { transaction }
            );
          }
        }

        await bet.update(
          { status: "closed", result_status: "void", credit_amt: 0 },
          { transaction }
        );
      }

      await wallet.update({ cash }, { transaction });

      const exposureResults = await sequelize.query(TOTAL_EXPOSURE_SQL, {
        replacements: { user_id: String(userId) },
        type: QueryTypes.SELECT,
        transaction,
      });
      const totalUserExposure =
        parseFloat(exposureResults[0]?.total_exposure) || 0;
      await TotalExposure.upsert(
        { user_id: Number(userId), total_exposure: totalUserExposure },
        { transaction }
      );

      await transaction.commit();

      (async () => {
        try {
          const freshWallet = await Wallet.findOne({
            where: { user_id: userId },
            raw: true,
          });
          emitBalanceUpdate(userId, {
            inr_balance: freshWallet?.inr_balance,
            cash: freshWallet?.cash,
            exposure: totalUserExposure,
          });
        } catch (error) {
          console.error(
            "[CasinoService.undoBet] balance emit failed:",
            error.message
          );
        }
      })();

      return { undone: targets.length };
    } catch (error) {
      await transaction.rollback();
      throw new Error(error.message || "Failed to undo casino bet");
    }
  },
  UserBets: async (userId, match_id) => {
    try {
      if (!userId) {
        throw new Error("User ID is required to fetch bets");
      }

      // Round ka "My Bet" panel sirf ABHI chal rahi bets dikhata hai. Void hui
      // bet status='closed' + result_status='void' par chali jaati hai
      // (services/admin/casinoVoidService.js), settlement won/lost likhta hai.
      // Pehle yahan koi filter nahi tha, isliye void/settled bets panel me bhi
      // dikhti thi aur frontend ke computeUserBook me unka exposure bhi jud
      // raha tha. Sirf `status` dekhna kaafi nahi — worker jis bet ka result
      // resolve nahi kar paata use wapas 'open' kar deta hai, isliye terminal
      // result_status bhi check hota hai (wahi filter jo UserBetsHistory aur
      // casinoVoidService use karte hain).
      const bets = await CasinoBet.findAll({
        where: {
          user_id: userId,
          event_id: match_id,
          status: { [Op.in]: ["open", "processing"] },
          [Op.or]: [{ result_status: null }, { result_status: "" }],
        },
        // Bina ORDER BY ke Postgres rows kisi bhi order me deta hai (open ->
        // processing update par row hil jaati hai). Latest bet sabse upar.
        order: [["id", "DESC"]],
      });

      return bets.map(bet => bet.get({ plain: true }));
    } catch (error) {
      throw new Error(error.message || "Failed to fetch user bets");
    }
  },
  UserBetsHistory: async (userId) => {
    try {
      if (!userId) {
        throw new Error("User ID is required to fetch bets");
      }

      // "Current Bets" = sirf abhi chal rahi bets. Worker bet ko
      // open -> processing -> closed + result_status (won/lost/void) par le
      // jaata hai, to open/processing aur result aane se pehle wali rows hi
      // current hain. Pehle yahan koi filter nahi tha, isliye settle ho chuki
      // purani bets bhi Casino tab me dikh rahi thi.
      const bets = await CasinoBet.findAll({
        where: {
          user_id: userId,
          status: { [Op.in]: ["open", "processing"] },
          [Op.or]: [{ result_status: null }, { result_status: "" }],
        },
        // ASC = first placed on top, like the reference Current Bets (and the
        // sports tab, CricketService.getSportsBetsByUserId). DESC listed it upside down.
        order: [["id", "ASC"]],
      });

      return bets.map(bet => bet.get({ plain: true }));
    } catch (error) {
      throw new Error(error.message || "Failed to fetch user bets");
    }
  }
};




export default CasinoService;
