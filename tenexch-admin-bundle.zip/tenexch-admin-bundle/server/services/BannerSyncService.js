import axios from 'axios';
import sequelize from '../config/db.js';
import Carousel from '../model/admin/Carousel.js';
import Poster from '../model/admin/Poster.js';
import BannerSync, { BANNER_SYNC_ROW_ID } from '../model/admin/BannerSync.js';

// Mirrors the reference site's homepage carousel + welcome poster into our
// `carousels` / `posters` tables every 4 hours.
//
// The images come from the Python service in auto-update/tenexch_banners
// (pm2: tenexch-banners-api, localhost only). It reads www.tenexch.com through
// the Geonix proxy with real Chrome; its README explains where the data lives.
//
// FULL MIRROR (owner decision 2026-09-19): after a successful run the carousel
// is exactly the site's list, in the site's order. Rows whose image is still on
// the site keep their id; every other row is deleted, hand-made ones included.
// A run that gets nothing usable never touches the tables.
//
// BANNERS_API_URL is read per call: server.js runs dotenv.config() after the
// ESM imports are evaluated (same trap as FixturesService).

const DEFAULT_API_URL = 'http://127.0.0.1:9023';
const INTERVAL_MS = 4 * 60 * 60 * 1000;
const RETRY_MS = 15 * 60 * 1000;  // after a failed run
const TICK_MS = 60 * 1000;        // how often the loop checks next_run_at
// A live fetch launches Chrome through the proxy: ~15-40 s, sometimes more.
const FETCH_TIMEOUT_MS = 3 * 60 * 1000;

// Site banner -> carousel columns. The site's own link fields:
//   gtype "Game"   + eid (sport id) + gameId (event id)  -> sports
//   gtype "Casino" + gmid (table slug, e.g. teen41)      -> casino
//   anything else (fantasy providers, plain promos)      -> others (image only)
const mapBanner = (b) => {
    const gtype = String(b.gtype || '').toLowerCase();
    const row = {
        image_url: b.source_url,
        category: 'others',
        sport_id: null,
        event_id: null,
        game_name: null,
        game_uid: null,
    };
    if (gtype === 'game' && b.eid && b.gameId) {
        return { ...row, category: 'sports', sport_id: String(b.eid), event_id: String(b.gameId) };
    }
    if (gtype === 'casino' && b.gmid) {
        return { ...row, category: 'casino', game_name: String(b.gmid).toLowerCase() };
    }
    return row;
};

const fetchSiteBanners = async () => {
    const base = (process.env.BANNERS_API_URL || DEFAULT_API_URL).replace(/\/+$/, '');
    const { data } = await axios.get(`${base}/banners`, {
        params: { refresh: 1 },
        timeout: FETCH_TIMEOUT_MS,
    });
    return data;
};

// Carousel full mirror, in one transaction. -> { count, added, removed }
const mirrorCarousel = async (siteBanners, t) => {
    const wanted = siteBanners.filter((b) => b?.source_url).map(mapBanner);
    const existing = await Carousel.findAll({ order: [['carousel_id', 'ASC']], transaction: t });

    const byUrl = new Map();
    for (const row of existing) {
        if (!byUrl.has(row.image_url)) byUrl.set(row.image_url, row);
    }

    const kept = new Set();
    const added = [];
    for (const [index, values] of wanted.entries()) {
        const row = byUrl.get(values.image_url);
        if (row && !kept.has(row.carousel_id)) {
            await row.update({ ...values, sort_order: index }, { transaction: t });
            kept.add(row.carousel_id);
        } else {
            const created = await Carousel.create({ ...values, sort_order: index }, { transaction: t });
            kept.add(created.carousel_id);
            added.push(values.image_url);
        }
    }

    const stale = existing.filter((row) => !kept.has(row.carousel_id));
    if (stale.length) {
        await Carousel.destroy({
            where: { carousel_id: stale.map((row) => row.carousel_id) },
            transaction: t,
        });
    }

    return { count: wanted.length, added, removed: stale.map((row) => row.image_url) };
};

// Welcome poster: upsert desktop (is_mobile false) + mobile (true). A variant
// the site does not send is left as it is. -> true when any link changed.
const mirrorPosters = async (welcome, t) => {
    if (!welcome || welcome.error) return false;
    let changed = false;
    for (const [variant, isMobile] of [['desktop', false], ['mobile', true]]) {
        const url = welcome[variant]?.source_url;
        if (!url) continue;
        const poster = await Poster.findOne({ where: { is_mobile: isMobile }, transaction: t });
        if (!poster) {
            await Poster.create({ image_url: url, is_mobile: isMobile }, { transaction: t });
            changed = true;
        } else if (poster.image_url !== url) {
            await poster.update({ image_url: url }, { transaction: t });
            changed = true;
        }
    }
    return changed;
};

const getRow = async () => {
    const [row] = await BannerSync.findOrCreate({
        where: { id: BANNER_SYNC_ROW_ID },
        defaults: { id: BANNER_SYNC_ROW_ID, next_run_at: new Date() },
    });
    return row;
};

let inflight = null;

const runOnce = async (trigger) => {
    const row = await getRow();
    const startedAt = new Date();
    await row.update({ status: 'running', trigger, last_run_at: startedAt, error: null });

    try {
        const data = await fetchSiteBanners();
        const banners = Array.isArray(data?.banners) ? data.banners : [];
        // Never mirror an empty list: that would wipe the carousel on a bad read.
        if (!banners.length) {
            throw new Error(data?.error || 'banner service returned no banners');
        }

        const result = await sequelize.transaction(async (t) => {
            const carousel = await mirrorCarousel(banners, t);
            const posterChanged = await mirrorPosters(data.welcome_banner, t);
            return { ...carousel, posterChanged };
        });

        // The service serves its previous list (with `error`) when a live read
        // fails; that list was still applied, but the owner should see why.
        // A soft error still means we mirrored STALE data, so come back on the
        // short retry instead of coasting a whole interval on it.
        await row.update({
            status: data.error ? 'error' : 'ok',
            last_success_at: new Date(),
            next_run_at: new Date(startedAt.getTime() + (data.error ? RETRY_MS : INTERVAL_MS)),
            site_fetched_at: data.fetched_at ? new Date(data.fetched_at) : null,
            carousel_count: result.count,
            added: result.added,
            removed: result.removed,
            poster_changed: result.posterChanged,
            error: data.error || null,
        });
        console.log(`[banner-sync] ${trigger}: ${result.count} banners, +${result.added.length} -${result.removed.length}, poster ${result.posterChanged ? 'changed' : 'same'}`);
    } catch (error) {
        const message = error.response?.data?.error || error.message;
        await row.update({
            status: 'error',
            next_run_at: new Date(startedAt.getTime() + RETRY_MS),
            error: message,
        });
        console.error(`[banner-sync] ${trigger} failed: ${message}`);
    }
    return row;
};

const BannerSyncService = {
    INTERVAL_MS,

    // Single flight: a manual "Update now" during a scheduled run shares it.
    run(trigger = 'manual') {
        if (!inflight) {
            inflight = runOnce(trigger).finally(() => { inflight = null; });
        }
        return inflight;
    },

    isRunning() {
        return Boolean(inflight);
    },

    async getStatus() {
        const row = await getRow();
        return {
            ...row.get({ plain: true }),
            // a 'running' left behind by a restart mid-run is not running
            status: row.status === 'running' && !inflight ? 'error' : row.status,
            running: Boolean(inflight),
            interval_hours: INTERVAL_MS / 3600000,
        };
    },

    // Called once from server.js after listen(). Checks every minute whether
    // next_run_at has passed; a fresh table runs right away.
    startLoop() {
        const tick = async () => {
            try {
                if (inflight) return;
                const row = await getRow();
                if (!row.next_run_at || row.next_run_at.getTime() <= Date.now()) {
                    await BannerSyncService.run('schedule');
                }
            } catch (error) {
                console.error('[banner-sync] tick failed:', error.message);
            }
        };
        setInterval(tick, TICK_MS).unref();
        tick();
    },
};

export default BannerSyncService;
