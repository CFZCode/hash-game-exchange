/**
 * Google Authenticator (TOTP) support — RFC 4648 base32 + RFC 6238 TOTP.
 *
 * Implemented on node:crypto rather than a TOTP package: the algorithm is a
 * HMAC-SHA1 over a 30-second counter, and keeping it here means the shared
 * secret never leaves the process. Only the QR image uses a library.
 *
 * The secret is stored base32-encoded on users.google_auth_secret — that is the
 * same string Google Authenticator shows as the "Setup Code" (manual entry).
 */
import crypto from 'crypto';
import QRCode from 'qrcode';

const BASE32_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
const DIGITS = 6;
const PERIOD = 30; // seconds per code, per the Authenticator spec

// RFC 4648 base32, no padding — Authenticator apps reject '=' in the secret.
const base32Encode = (buffer) => {
    let bits = 0;
    let value = 0;
    let output = '';
    for (const byte of buffer) {
        value = (value << 8) | byte;
        bits += 8;
        while (bits >= 5) {
            output += BASE32_ALPHABET[(value >>> (bits - 5)) & 31];
            bits -= 5;
        }
    }
    if (bits > 0) output += BASE32_ALPHABET[(value << (5 - bits)) & 31];
    return output;
};

const base32Decode = (encoded) => {
    const clean = String(encoded || '').toUpperCase().replace(/=+$/, '').replace(/\s+/g, '');
    let bits = 0;
    let value = 0;
    const bytes = [];
    for (const char of clean) {
        const index = BASE32_ALPHABET.indexOf(char);
        if (index === -1) throw new Error('Invalid base32 character in secret');
        value = (value << 5) | index;
        bits += 5;
        if (bits >= 8) {
            bytes.push((value >>> (bits - 8)) & 255);
            bits -= 8;
        }
    }
    return Buffer.from(bytes);
};

// HOTP (RFC 4226): HMAC-SHA1 of the counter, dynamically truncated to 6 digits.
const generateHOTP = (secretBuffer, counter) => {
    const counterBuffer = Buffer.alloc(8);
    counterBuffer.writeBigUInt64BE(BigInt(counter));

    const digest = crypto.createHmac('sha1', secretBuffer).update(counterBuffer).digest();
    const offset = digest[digest.length - 1] & 0x0f;
    const binary =
        ((digest[offset] & 0x7f) << 24) |
        ((digest[offset + 1] & 0xff) << 16) |
        ((digest[offset + 2] & 0xff) << 8) |
        (digest[offset + 3] & 0xff);

    return String(binary % 10 ** DIGITS).padStart(DIGITS, '0');
};

// Secure Auth APP "per-open" codes. The app mints a fresh code each time an
// account is opened (and every 30s after) instead of showing the shared 30s
// window: code = HOTP(secret, SESSION_DOMAIN + epochSecond it was minted).
// SESSION_DOMAIN keeps these counters far away from the TOTP counters
// (floor(t/30)) so the two schemes never produce the same counter. Mirror of
// secure-auth-app/.../Totp.kt sessionCode() — change both together.
const SESSION_DOMAIN = 2 ** 40;
const SESSION_MAX_AGE_SEC = 35; // 30s on screen + a little typing / clock slack
const SESSION_SKEW_SEC = 5;     // phone clock slightly ahead
// A per-open code is accepted once: remember it until it can no longer verify.
const usedSessionCodes = new Map(); // `${secret}:${code}` -> expiresAt ms

const GoogleAuthService = {
    PERIOD,

    /**
     * Which securityAuthType values are TOTP — i.e. the code comes from an app
     * the account already holds, so nothing is pushed at login and there is no
     * OTP cache entry to look up.
     *
     * 'google' is the Authenticator; 'android' is our own "Secure Auth
     * Verification App", which is the same algorithm with our branding, so the
     * login paths must treat them identically. Every 2FA branch asks this
     * instead of comparing to 'google' — that is what stopped six copies of the
     * same string drifting apart.
     */
    isTotpType: (type) => type === 'google' || type === 'android',

    // 20 random bytes = 160-bit secret, the size Google Authenticator expects.
    generateSecret: () => base32Encode(crypto.randomBytes(20)),

    /**
     * otpauth:// URI the QR encodes. `label` shows as the account name in the
     * app; `issuer` groups it under the site name.
     */
    buildOtpAuthUrl: (secret, label, issuer) => {
        const safeIssuer = encodeURIComponent(issuer);
        const safeLabel = encodeURIComponent(label);
        const params = new URLSearchParams({
            secret,
            issuer,
            algorithm: 'SHA1',
            digits: String(DIGITS),
            period: String(PERIOD),
        });
        return `otpauth://totp/${safeIssuer}:${safeLabel}?${params.toString()}`;
    },

    // PNG data URI — rendered straight into an <img src> by the frontend.
    buildQrDataUrl: async (otpAuthUrl) =>
        QRCode.toDataURL(otpAuthUrl, { errorCorrectionLevel: 'M', margin: 2, width: 260 }),

    /**
     * Verify a user-entered code. `window` accepts codes from N steps either
     * side of now (default 1 = ±30s) so a slightly-off phone clock still works.
     */
    verifyToken: (secret, token, window = 1) => {
        const code = String(token || '').replace(/\s+/g, '');
        if (!secret || !/^\d{6}$/.test(code)) return false;

        let secretBuffer;
        try {
            secretBuffer = base32Decode(secret);
        } catch {
            return false;
        }

        const counter = Math.floor(Date.now() / 1000 / PERIOD);
        for (let offset = -window; offset <= window; offset += 1) {
            const expected = generateHOTP(secretBuffer, counter + offset);
            // Constant-time compare — both strings are always 6 ASCII digits.
            if (crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(code))) return true;
        }
        return false;
    },

    /**
     * A per-open code from the Secure Auth app (see SESSION_DOMAIN): valid for
     * SESSION_MAX_AGE_SEC after it was minted, single use.
     */
    verifySessionCode: (secret, token) => {
        const code = String(token || '').replace(/\s+/g, '');
        if (!secret || !/^\d{6}$/.test(code)) return false;

        let secretBuffer;
        try {
            secretBuffer = base32Decode(secret);
        } catch {
            return false;
        }

        const nowMs = Date.now();
        for (const [k, exp] of usedSessionCodes) if (exp < nowMs) usedSessionCodes.delete(k);
        const usedKey = `${secret}:${code}`;
        if (usedSessionCodes.has(usedKey)) return false;

        const nowSec = Math.floor(nowMs / 1000);
        for (let s = nowSec - SESSION_MAX_AGE_SEC; s <= nowSec + SESSION_SKEW_SEC; s += 1) {
            const expected = generateHOTP(secretBuffer, SESSION_DOMAIN + s);
            if (crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(code))) {
                usedSessionCodes.set(usedKey, nowMs + (SESSION_MAX_AGE_SEC + SESSION_SKEW_SEC + 5) * 1000);
                return true;
            }
        }
        return false;
    },

    /**
     * Code check for an account by its securityAuthType. 'android' (our app)
     * accepts the per-open code AND the classic 30s TOTP, so installs of the
     * older app build keep working; 'google' stays plain TOTP.
     */
    verifyCodeForType: (type, secret, token) => {
        if (GoogleAuthService.verifyToken(secret, token)) return true;
        return type === 'android' && GoogleAuthService.verifySessionCode(secret, token);
    },
};

export default GoogleAuthService;
