import axios from 'axios';
import { buildUserStatement, sportsNet, loadFanSettlementNet, SPORT_NAMES } from '../statement/StatementBuilder.js';
import PointLedger from '../../model/admin/PointLedger.js';
import CasinoBet from '../../model/user/casino.js';
import TableCasino from '../../model/admin/TableCasino.js';
import CasinoResult from '../../model/admin/CasinoResult.js';
import SportsBet from '../../model/user/SportsBet.js';
import CreditsLedger from '../../model/user/CreditsLedger.js';
import { Op } from 'sequelize';
import { POINT_EVENT } from '../../constants/pointLedger.js';
import { toNaiveLocalTime } from '../../helper/naiveLocalTime.js';
import { fanMarketName, isKhadoBet } from '../../helper/fanMarketName.js';
import { isVoidRow, stripVoidPrefix, withVoidSuffix } from '../../helper/voidLabel.js';
import redis from '../../config/redisClient.js';
import { casinoAllDataKey } from '../../helper/casinoFeed.js';
import { decidingIndex } from '../../helper/ab50Settle.js';
import { ab4DecidingIndex } from '../../helper/ab4Settle.js';
import { casinoBetOutcome } from '../../helper/casinoBetResult.js';
import { UNDO_DELETED_GAMES, loadRefundedBetIds, loadUndoneBetIds } from '../../helper/casinoRefundedBets.js';

// tableid → display name ('mogambo' → 'Mogambo'); settlement worker ka hi lookup
const casinoGameLabel = (tableid) => {
  const table = TableCasino.FIXED_TABLES.find((t) => t.tableid === tableid);
  return table ? table.tablename : (tableid || 'Casino');
};

// Provider detail-results — settlement worker ka hi endpoint. casinoresult
// table stale ho sakti hai (worker_fetch May se ruka hai), isliye miss par
// live fetch + cache-back.
const CASINO_API_BASE = process.env.CASINO_RESULTS_API_BASE || 'https://apilords.codefactory.games/api';
const CASINO_DETAIL_PATH = process.env.CASINO_DETAIL_RESULTS_PATH || '/casino/casino/detail-results';

const fetchCasinoWinner = async (gameCode, mid) => {
  try {
    const resp = await axios.post(
      `${CASINO_API_BASE}${CASINO_DETAIL_PATH}`,
      { type: gameCode, mid },
      { timeout: 6000 }
    );
    const winnat = resp.data?.data?.data?.t1?.winnat;
    return winnat != null && String(winnat).trim() !== '' ? String(winnat) : null;
  } catch (e) {
    console.warn(`⚠️ [UserStatementService] casino winner fetch failed (${gameCode}/${mid}):`, e.message);
    return null;
  }
};

// Andar Bahar 50 / 150 (ab3 / ab4): the dealt cards of one round. A finished
// round never changes, so its cards are cached in redis; a running round (bets
// settle card by card, the row can exist mid-deal) is read from the live table.
const fetchAbRoundCards = async (mid, gameCode = 'ab3') => {
  const key = `${gameCode}:cards:${mid}`;
  try {
    const cached = await redis.get(key);
    if (cached) return cached.split(',');
  } catch { /* redis down → fetch */ }
  let card = null;
  try {
    const resp = await axios.post(`${CASINO_API_BASE}${CASINO_DETAIL_PATH}`, { type: gameCode, mid }, { timeout: 6000 });
    card = resp.data?.data?.data?.t1?.card || null;
    if (card) { try { await redis.set(key, card, 'EX', 7 * 24 * 3600); } catch { /* cache only */ } }
  } catch { /* still running → live feed below */ }
  if (!card) {
    try {
      const raw = await redis.get(casinoAllDataKey(gameCode));
      const feed = raw ? JSON.parse(raw) : null;
      const g = feed && feed.data && feed.mid == null ? feed.data : feed;
      if (g && String(g.mid) === String(mid)) card = g.card || null;
    } catch { /* no live table */ }
  }
  return card ? String(card).split(',').map((c) => c.trim()) : null;
};

// Ek casino ledger row kis round ki hai — "<game>:<round>".
// Casino nahi hai ya round pata nahi chala to null (aisi row alag hi dikhegi).
// Statement IST (UTC+05:30) me dikhta hai, jabki server Europe/Berlin (+02:00)
// par chalta hai. `setHours(0,0,0,0)` server ke din ko zero karta tha, jo IST me
// 03:30 dikhta — isliye din IST me hi kaata jaata hai.
const IST_OFFSET_MS = 5.5 * 60 * 60 * 1000;
const istStartOfDay = (value) => {
  const t = new Date(value);
  if (isNaN(t)) return null;
  const ist = new Date(t.getTime() + IST_OFFSET_MS);  // IST ka wall-clock, UTC ki tarah
  ist.setUTCHours(0, 0, 0, 0);                        // us din ki shuruaat
  return new Date(ist.getTime() - IST_OFFSET_MS);     // wapas asli instant
};

// Statement ki PEHLI line: "Opening pts" — range me AANE SE PEHLE ka balance.
// Range ki sabse purani entry ka closing_inr_balance us entry ke BAAD ka balance
// hai, isliye usme se usi entry ka apna delta ghatate hain:
//     opening = closing_inr_balance - delta
// Sirf closing lene se naya account apne hi opening credit ko opening balance
// bhi dikha deta tha (5,000 credit -> "Opening pts 5,000" jabki 0 hona chahiye).
// Casino-grouped row par bhi sahi: closing round ki AAKHRI entry se aata hai aur
// delta pure round ka jod hai, to ghatane par round se pehle ka balance milta hai.
//
// Date ACCOUNT BANNE ke din ki shuruaat (00:00:00) hoti hai — pehli entry ke din
// ki nahi. Account creation hi wo lamha hai jahan se ye balance carry hota hai.
// Shape ledger row jaisa hi rakha hai taki niche ki slicing/paging ise ek aam row
// ki tarah gine. Search ke waqt row nahi banti: 'Opening pts' user ke search term
// se match nahi karti, aur usse result set jhootha lagta.
const buildOpeningRow = (groupedRows, search, accountCreatedAt, fallbackBalance = null) => {
  if (search && String(search).trim()) return null;

  // Range me ek bhi entry nahi (ya demo par sirf 'User creation' thi, jo hata di)
  // — tab bhi table khaali nahi rehta: range se PEHLE ka closing hi opening hai.
  if (!groupedRows.length) {
    if (fallbackBalance === null) return null;
    const at0 = istStartOfDay(accountCreatedAt);
    if (!at0) return null;
    return {
      __opening: true,
      id: null,
      created_at: at0,
      delta: fallbackBalance,
      closing_inr_balance: fallbackBalance,
      remark: 'Opening pts',
      category: null,
      bet_id: null,
    };
  }

  const first = groupedRows[0];
  const closing = parseFloat(first.closing_inr_balance);
  const firstDelta = parseFloat(first.delta || 0);
  if (!Number.isFinite(closing) || !Number.isFinite(firstDelta)) return null;
  const opening = Math.round((closing - firstDelta) * 100) / 100;

  const at = istStartOfDay(accountCreatedAt || first.created_at);
  if (!at) return null;

  return {
    __opening: true,
    id: null,
    created_at: at,
    delta: opening,
    closing_inr_balance: opening,
    remark: 'Opening pts',
    category: null,
    bet_id: null,
  };
};

// Statement ki AAKHRI line: "Live Casino" — reference site ki tarah. Ye koi
// transaction NAHI hai: Credit/Debit dono khaali rehte hain, sirf `pts` me range
// ke aakhir ka closing balance dikhta hai. Opening row ka ulta jodi-daar.
//
// isOpening bhi true bhejte hain (isClosing ke saath): frontend isi flag se row
// ko synthetic maan ke inert rakhta hai (result modal nahi kholta) — uske peeche
// koi bet/round hota hi nahi. isClosing alag se hai taaki aage frontend chahe to
// dono me farq kar sake.
const buildLiveCasinoRow = (groupedRows, search, isDemo) => {
  if (!groupedRows.length) return null;
  if (search && String(search).trim()) return null;
  // Demo account ka statement ye closing line bilkul nahi dikhata.
  if (isDemo) return null;

  const last = groupedRows[groupedRows.length - 1];
  const closing = parseFloat(last.closing_inr_balance);
  if (!Number.isFinite(closing)) return null;

  return {
    __liveCasino: true,
    id: null,
    // Date = jis waqt statement maanga gaya (API call ka time) — ye row koi
    // transaction nahi hai, iski apni koi "hui thi" date hoti hi nahi.
    created_at: new Date(),
    delta: 0,
    closing_inr_balance: closing,
    remark: 'Live Casino',
    category: null,
    bet_id: null,
  };
};

// Games whose bets settle one by one inside a round (ab3 / ab4: card by card).
// Reference statement: bets DECIDED BY THE SAME DEALT CARD are one row
// ("Bahar 9/25" + "Andar 9/33", both decided by the 9 at #34), credit/debit
// netted; every other bet is its own row ("Bahar 9/34" and "Bahar 9/38" fall
// to different 9s → two rows). bet.decIdx is set before grouping.
// ab4 added 2026-10-12 (user: "make the account statement match that").
const abRankOf = (selection) => String(selection || '').trim().match(/(10|[2-9]|[AJQK])$/i)?.[1]?.toUpperCase() || null;
const AB_DECIDING_INDEX = { ab3: decidingIndex, ab4: ab4DecidingIndex };
const PER_BET_STATEMENT_GAMES = new Set(Object.keys(AB_DECIDING_INDEX));
// Which dealt card decided `bet` in its game (null = undecided / pushed).
const abDecidingIndex = (gameName, bet, cards) =>
  AB_DECIDING_INDEX[String(gameName || '').toLowerCase()]?.({ selection: bet.selection, playerName: bet.player_name, cards }) ?? null;

// Super Over (reference statement): the Bookmaker bets of a round are ONE row,
// every fancy bet (session "1 over run ENG", ball-by-ball "0.4 Over Zero RSA",
// "Common Wicket ENG") is its OWN row with its own result. Bookmaker = a
// selection without OVER / COMMON / RUN — the same test resolveSuperover3 uses
// for its match-winner branch (team name or Tie). Mini SuperOver (superover3)
// added 2026-10-12; its "Tie" runner sits in the Fancy1 market, so a Tie bet is
// its own Fancy1 row, not part of the Bookmaker row
// (docs/plans/2026-10-12-mini-superover-parity.md).
const SUPEROVER_FANCY_STATEMENT_GAMES = new Set(['superover', 'superover2', 'superover3']);
// The fancy line a bet is on, without the run line a session bet carries:
// "1 over run ENG 13" → "1 over run ENG"; "0.4 Over Zero RSA" stays.
const superOverFancyName = (sel) => {
  const s = String(sel || '').trim();
  const m = s.match(/^(\d+\s+over\s+run(?:\s+bhav)?\s+\S+)\s+\d+(?:\.\d+)?$/i);
  return m ? m[1] : s;
};
const superOverFancyMarket = (sel) => (/^\d+\s+over\s+run/i.test(String(sel || '').trim()) ? 'Fancy' : 'Fancy1');

// Round result text of a Super Over round ("ENG : 18 | RSA : 12") + winner,
// from the provider. A finished round never changes, so it is cached in memory.
const superOverResultCache = new Map();
const fetchSuperOverResult = async (gameCode, mid) => {
  const key = `${gameCode}:${mid}`;
  if (superOverResultCache.has(key)) return superOverResultCache.get(key);
  try {
    const resp = await axios.post(`${CASINO_API_BASE}${CASINO_DETAIL_PATH}`, { type: gameCode, mid }, { timeout: 6000 });
    const t1 = resp.data?.data?.data?.t1;
    if (!t1?.winnat) return null;
    const totals = {};
    for (const m of String(t1.rdesc || '').matchAll(/([A-Za-z]+)\s*:\s*(\d+)/g)) totals[m[1].toUpperCase()] = Number(m[2]);
    const out = { winner: String(t1.winnat), totals, teams: Object.keys(totals) };
    superOverResultCache.set(key, out);
    if (superOverResultCache.size > 500) superOverResultCache.delete(superOverResultCache.keys().next().value);
    return out;
  } catch (e) {
    console.warn(`⚠️ [UserStatementService] super over result fetch failed (${gameCode}/${mid}):`, e.message);
    return null;
  }
};

const isSuperOverFancyBet = (bet) =>
  !!bet
  && SUPEROVER_FANCY_STATEMENT_GAMES.has(String(bet.game_name || '').toLowerCase())
  && (/OVER|COMMON|RUN|BHAV/i.test(String(bet.selection || '')) || /^\s*tie\s*$/i.test(String(bet.selection || '')));

const casinoRoundKey = (row, casinoBetMap) => {
  if (row.category !== 'CASINO') return null;

  const bet = casinoBetMap[row.bet_id];
  // Reference: one row per fancy LINE per round (all bets on "1 over run ENG"
  // together, whatever their run line), Bookmaker one row per round.
  if (isSuperOverFancyBet(bet)) return `${bet.game_name}:${bet.round_id}:fancy:${superOverFancyName(bet.selection).toLowerCase()}`;
  if (bet && PER_BET_STATEMENT_GAMES.has(String(bet.game_name || '').toLowerCase())) {
    return bet.decIdx != null
      ? `${bet.game_name}:${bet.round_id}:dec:${bet.decIdx}`
      : `${bet.game_name}:${bet.round_id}:bet:${bet.id}`;
  }
  if (bet && bet.round_id) return `${bet.game_name}:${bet.round_id}`;

  // bet row na mile to remark se: "Mogambo / R.No : 192260726064843 / Yes"
  const m = String(row.remark || '').match(/R\.No\s*:\s*(\S+)/i);
  return m ? `?:${m[1]}` : null;
};

// Ek hi sports market par kai bets (YES+NO, ya baar-baar lagayi hui) — settlement
// har bet ki alag ledger entry banata hai, isliye statement me wahi market do-teen
// baar dikhti thi. Ek market = ek row, jisme NET dikhe: -120 + 90 = -30 (debit),
// -100 + 100 = 0 (Credit/Debit dono khaali, pts wahi ka wahi).
//
// FAN par `match_id` market ki pehchaan NAHI hai — ek event ki saari fancy ek hi
// match_id share karti hain (DB me 724 FAN bets, sirf 153 distinct match_id,
// jabki 420 asli fancy markets), to usse group karne par poore event ki saari
// fancy ek row me mil jaati. Isliye FAN ki key fancy ka naam hai. MO/BM par
// match_id hi asli market id hai, aur back+lay dono usi ek row me netne chahiye.
// Win commission ki apni line hoti hai — market ki jeet wali row me net NAHI
// hoti (190 aur -3.80 alag dikhte hain, 186.20 ek row me nahi). Commission ki
// void-reversal usi commission group me jaati hai (net 0), settlement void jaisa.
const isCommissionRow = (row) =>
  row.event_type === POINT_EVENT.COMMISSION
  || String(row.entry_ref || '').startsWith('reverse:commission:');

const sportsMarketKey = (row, sportsBetMap) => {
  const base = sportsMarketBaseKey(row, sportsBetMap);
  if (!base) return null;
  const key = isCommissionRow(row) ? `${base}:comm` : base;
  // Void ki ulti entry ab settlement wali row me MERGE nahi hoti. Pehle dono ek
  // hi key par aate the, delta net 0 ho jaata tha aur row blank pad jaati thi —
  // statement me void ka koi nishaan hi nahi bachta tha. Ab void ki apni line
  // banti hai ("… -void"), debit side par (jeeti hui market ka paisa wapas).
  return isVoidRow(row) ? `${key}:void` : key;
};

const sportsMarketBaseKey = (row, sportsBetMap) => {
  if (row.category !== 'SPORTS') return null;

  const bet = sportsBetMap[row.bet_id];
  if (!bet || !bet.eventid) return null;          // key na bane to row akeli rahegi

  if (String(bet.game_type || '').toUpperCase() === 'FAN') {
    const name = fanMarketName(bet);
    return name ? `S:${bet.eventid}:${bet.market_type || ''}:${name}` : null;
  }

  return bet.match_id ? `S:${bet.eventid}:${bet.match_id}` : null;
};

// Ek round / ek market me kai bets lagi ho to statement me ek hi row dikhni chahiye.
// Us row ka delta = us group ke saare deltas ka jod (+ = credit, - = debit).
// Baaki fields group ki AAKHRI entry se aate hain (date, closing, remark, bet_id).
// Transaction rows (bet_id null) ko haath nahi lagta.
const groupStatementRows = (rows, casinoBetMap, sportsBetMap) => {
  const out = [];
  const seen = {};   // round / market key -> out me uska index

  for (const row of rows) {
    const key = casinoRoundKey(row, casinoBetMap) || sportsMarketKey(row, sportsBetMap);

    if (!key) {
      out.push(row);
      continue;
    }

    if (seen[key] === undefined) {
      seen[key] = out.length;
      out.push({ ...row });
      continue;
    }

    const merged = out[seen[key]];
    merged.delta = Number(merged.delta || 0) + Number(row.delta || 0);
    merged.created_at = row.created_at;
    merged.closing_inr_balance = row.closing_inr_balance;
    merged.remark = row.remark;
    merged.bet_id = row.bet_id;
  }

  return out;
};

const UserStatementService = {
  /**
   * Dedicated account statement for the logged-in user.
   * Delegates to the shared StatementBuilder so the user panel and the
   * admin panel return identical, tallying numbers:
   *   • one net row per SETTLED bet (Credit if won, Debit if lost)
   *   • deposits / withdrawals from the Transaction table
   *   • running balance: Opening + ΣCredit − ΣDebit = Closing
   */
  getAccountStatement: async (user, filters) => {
    console.log(`🔍 [UserStatementService] Statement for: ${user.username} | Type: ${filters?.reportType}`);
    return buildUserStatement(user, filters);
  },


  getAccountStatementV2: async (target, filters) => {
    try {
      const { fromDate, toDate, reportType, search, page = 1, limit = 25 } = filters;
      const offset = (page - 1) * limit;

      console.log(`🔍 [UserStatementService] StatementV2 for ${target.username} (wallet ${target.walletId}) | ${fromDate || '-'} → ${toDate || '-'} | type: ${reportType} | search: ${search || '-'}`);

      // User ki apni wallet ki entries
      const where = { wallet_id: target.walletId };

      // Date range (created_at par) — toDate ka poora din shamil
      if (fromDate || toDate) {
        where.created_at = {};
        if (fromDate) where.created_at[Op.gte] = new Date(fromDate);
        if (toDate) {
          const end = new Date(toDate);
          end.setHours(23, 59, 59, 999);
          where.created_at[Op.lte] = end;
        }
      }

      // Remark pe search — case-insensitive partial match
      if (search && String(search).trim()) {
        where.remark = { [Op.iLike]: `%${String(search).trim()}%` };
      }

      const rt = String(reportType || 'ALL').toUpperCase().trim();
      if (rt === 'TRANSACTION') where.bet_id = null;
      else if (rt === 'SPORTS') where.bet_id = { [Op.ne]: null };
      // ALL: koi bet_id filter nahi — dono aayenge

      // Pehle poore range ki entries laao. Page baad me kaatenge, kyunki ek casino
      // round ki kai entries milkar ek row banti hain — pehle DB par page kaat dete
      // to ek round do pages me bat jaata aur total galat aata.
      // Range route par 31 din tak seemit hai (maxDateRange(31)).
      const rawLedgerRows = await PointLedger.findAll({
        where,
        order: [['id', 'ASC']],   // purani entry pehle
        raw: true,
      });

      // Demo account ka statement 'User creation' (opening credit) row nahi dikhata.
      // JS me chhanta hai, SQL me nahi: `event_type != 'User creation'` NULL
      // event_type wali purani rows ko bhi gira deta hai.
     const allRows = target?.isDemo && rt !== 'ALL'
  ? rawLedgerRows.filter((r) => r.event_type !== POINT_EVENT.USER_CREATION)
  : rawLedgerRows;
      // Casino rows ke liye bet se gamename/round_id nikalo (remark parse pe bharosa nahi)
      const casinoBetIds = [...new Set(allRows.filter(r => r.category === 'CASINO' && r.bet_id).map(r => Number(r.bet_id)))];
      const casinoBetMap = {};
      if (casinoBetIds.length) {
        const casinoBets = await CasinoBet.findAll({
          where: { id: casinoBetIds },
          // result_status: the Super Over Fancy1 remark ends "/ 1" (won) or "/ 2" (lost).
          attributes: ['id', 'game_name', 'round_id', 'selection', 'player_name', 'result_status'],
          raw: true,
        });
        casinoBets.forEach(b => { casinoBetMap[b.id] = b; });

        // ab3 / ab4: which dealt card decided each bet (statement grouping key).
        const abBets = casinoBets.filter((b) => PER_BET_STATEMENT_GAMES.has(String(b.game_name || '').toLowerCase()));
        const abRoundKey = (b) => `${String(b.game_name).toLowerCase()}|${b.round_id}`;
        const abRounds = [...new Set(abBets.map(abRoundKey))];
        const abCards = {};
        await Promise.all(abRounds.map(async (k) => {
          const [game, round] = k.split('|');
          abCards[k] = await fetchAbRoundCards(round, game);
        }));
        abBets.forEach((b) => {
          const cards = abCards[abRoundKey(b)];
          b.decIdx = cards ? abDecidingIndex(b.game_name, b, cards) : null;
        });
      }

      // Sports rows: ledger ka bet_id -> us bet ka sport/event/market. Grouping se
      // PEHLE chahiye (pehle ye slice ke baad sirf ek page ke liye banta tha), aur
      // neeche row mapping bhi isi map se chalti hai.
      const sportsBetIds = [...new Set(allRows.filter(r => r.category === 'SPORTS' && r.bet_id).map(r => Number(r.bet_id)))];
      const sportsBetMap = {};
      if (sportsBetIds.length) {
        const sportsBets = await SportsBet.findAll({
          where: { id: sportsBetIds },
          attributes: ['id', 'sport_id', 'eventid', 'match_id', 'market_type', 'game_type', 'fancy_name', 'selection_name'],
          raw: true,
        });
        sportsBets.forEach(b => { sportsBetMap[b.id] = b; });
      }

      // Ek casino round / ek sports market = ek row
      const groupedRows = groupStatementRows(allRows, casinoBetMap, sportsBetMap);

      // "Opening pts" line slice se PEHLE lagti hai, isliye ye har reportType
      // (ALL / TRANSACTION / SPORTS) me aati hai, page 1 par sr.no 1 banti hai
      // aur `count` me bhi gin jaati hai — paging apne aap sahi rehta hai.
      // Kuch na mile to opening ke liye range se PEHLE ka aakhri closing balance.
      let openingFallback = null;
      if (!groupedRows.length) {
        const prevWhere = { wallet_id: target.walletId };
        if (fromDate) prevWhere.created_at = { [Op.lt]: new Date(fromDate) };
        const prev = await PointLedger.findOne({
          where: prevWhere,
          order: [['id', 'DESC']],
          attributes: ['closing_inr_balance'],
          raw: true,
        });
        openingFallback = prev ? Number(prev.closing_inr_balance) || 0 : 0;
      }
      const openingRow = buildOpeningRow(groupedRows, search, target?.createdAt, openingFallback);
      // "Live Casino" closing line SABSE AAKHIR me — isliye slice se pehle joda
      // jaata hai: tab hi wo aakhri page par aati hai aur `count` me gini jaati hai.
      const liveCasinoRow = buildLiveCasinoRow(groupedRows, search, target?.isDemo);
      const ledgerRows = [
        ...(openingRow ? [openingRow] : []),
        ...groupedRows,
        ...(liveCasinoRow ? [liveCasinoRow] : []),
      ];

      // Phir is page ka hissa kaato
      const count = ledgerRows.length;
      const rows = ledgerRows.slice(offset, offset + parseInt(limit));

      // (sportsBetMap upar bana hai — grouping ko bhi chahiye tha)

      // Super Over rows read like the reference ("cricket / ENG Vs RSA Super
      // Over/R.No.:<round> / <market> / <result>"), which needs each round's
      // result (teams, innings totals, winner).
      const soResults = {};
      await Promise.all([...new Set(rows
        .map((r) => (r.category === 'CASINO' ? casinoBetMap[r.bet_id] : null))
        .filter((cb) => cb && SUPEROVER_FANCY_STATEMENT_GAMES.has(String(cb.game_name || '').toLowerCase()) && cb.round_id)
        .map((cb) => `${cb.game_name}|${cb.round_id}`))]
        .map(async (k) => {
          const [g, rid] = k.split('|');
          soResults[k] = await fetchSuperOverResult(g, rid);
        }));

      // User perspective: delta > 0 = credit, delta < 0 = debit; closing = user ka closing_inr_balance
      const data = rows.map(r => {
        const delta = parseFloat(r.delta || 0);

        // "Opening pts": hamesha Credit side, Debit khaali — balance 0 ho tab bhi.
        // Iske peeche koi bet/round nahi, isliye saare lookup fields null.
        if (r.__opening) {
          const bal = parseFloat(r.closing_inr_balance).toFixed(2);
          return {
            date: r.created_at,
            credit: bal,
            debit: '-',
            closing: bal,
            description: 'Opening pts',
            fromto: '-',
            category: null,
            betId: null,
            gamename: null,
            roundId: null,
            sportId: null,
            eventId: null,
            matchId: null,
            marketType: null,
            gameType: null,
            isOpening: true,
          };
        }

        // "Live Casino": aakhri line. Credit/Debit dono khaali ('-' frontend par
        // blank cell banta hai), sirf closing dikhta hai — reference jaisa.
        if (r.__liveCasino) {
          const bal = parseFloat(r.closing_inr_balance).toFixed(2);
          return {
            date: r.created_at,
            credit: '-',
            debit: '-',
            closing: bal,
            description: 'Live Casino',
            fromto: '-',
            category: null,
            betId: null,
            gamename: null,
            roundId: null,
            sportId: null,
            eventId: null,
            matchId: null,
            marketType: null,
            gameType: null,
            isOpening: true,    // synthetic => frontend row ko inert rakhta hai
            isClosing: true,
          };
        }

        let gamename = null;
        let roundId = null;
        let casinoCode = null;
        let abCardDescription = null;
        if (r.category === 'CASINO') {
          const cb = casinoBetMap[r.bet_id];
          if (cb) {
            gamename = casinoGameLabel(cb.game_name);
            // The table's API code, so the result modal never has to guess it
            // back from the label ("Andar Bahar" is ab20, not ab3; "Andar-Bahar
            // 150 card", "Matka", "K.B.C" … resolved to nothing). User 2026-10-12.
            casinoCode = cb.game_name || null;
            roundId = cb.round_id || null;
            // Andar Bahar 50 / 150: one row per bet; the reference names the card
            // bet on after the round no. ("… / R.No : 123 / Card Q").
            const abRank = PER_BET_STATEMENT_GAMES.has(String(cb.game_name || '').toLowerCase())
              ? String(cb.selection || '').trim().match(/(10|[2-9]|[AJQK])$/i)?.[1]
              : null;
            if (abRank && roundId) {
              // ab4: the reference appends the number of the card that decided
              // the row to the round no. (5261013161054 + #87 → 526101316105487),
              // the same id its statement modal shows. A pushed bet (no deciding
              // card) keeps the plain round no. Display only: `roundId` below
              // stays the real round for the result modal. User 2026-10-14.
              const decNo = String(cb.game_name || '').toLowerCase() === 'ab4' && cb.decIdx != null
                ? String(cb.decIdx + 1)
                : '';
              abCardDescription = `${gamename} / R.No : ${roundId}${decNo} / Card ${abRank.toUpperCase()}`;
            }
            // Super Over, reference wording:
            //   cricket / ENG Vs RSA Super Over/R.No.:<round> / Bookmaker / <winner>
            //   cricket / … / Fancy / 1 over run ENG / <ENG innings runs>
            //   cricket / … / Fancy1 / 0.3 Over Wicket ENG / <1 won | 2 lost>
            if (SUPEROVER_FANCY_STATEMENT_GAMES.has(String(cb.game_name || '').toLowerCase()) && roundId) {
              const res = soResults[`${cb.game_name}|${cb.round_id}`];
              const ename = res?.teams?.length === 2 ? `${res.teams[0]} Vs ${res.teams[1]} ${gamename}` : gamename;
              const head = `cricket / ${ename}/R.No.:${roundId}`;
              if (isSuperOverFancyBet(cb)) {
                const name = superOverFancyName(cb.selection);
                const market = superOverFancyMarket(cb.selection);
                let tail = '';
                if (market === 'Fancy') {
                  const team = String(name.split(/\s+/).pop() || '').toUpperCase();
                  if (res?.totals?.[team] != null) tail = ` / ${res.totals[team]}`;
                } else if (cb.result_status === 'won' || cb.result_status === 'lost') {
                  tail = ` / ${cb.result_status === 'won' ? 1 : 2}`;
                }
                abCardDescription = `${head} / ${market} / ${name}${tail}`;
              } else {
                const winner = res?.winner || String(r.remark || '').split('/').pop().trim();
                abCardDescription = `${head} / Bookmaker${winner ? ` / ${winner}` : ''}`;
              }
            }
          } else {
            // bet row na mile toh remark se: "Mogambo / R.No : 192260726064843 / Yes"
            const m = String(r.remark || '').match(/^(.*?)\s*\/\s*R\.No\s*:\s*(\S+)/i);
            if (m) { gamename = m[1]; roundId = m[2]; }
          }
        }

        let sportId = null, eventId = null, matchId = null, marketType = null, gameType = null;
        let fancyName = null;
        // Void row: purani entries ka remark "VOID after settlement — X" hai,
        // nayi seedha "X -void". Prefix yahan hata dete hain taaki neeche ka
        // FAN naam-splice wahi kaam kare jo aam row par karta hai; suffix
        // sabse aakhir me lagta hai.
        const voidRow = isVoidRow(r);
        let description = r?.remark?.split('#')[0] || r.event_type;
        if (voidRow) description = stripVoidPrefix(description);
        if (abCardDescription) description = abCardDescription;
        // The stored remark keeps the table name as it was spelled at
        // settlement time ("Queen top open teenpatti / R.No : …"). A renamed
        // table must read right on PAST rows too (user 2026-10-11), so when the
        // stored prefix is that same table in another spelling, rebuild the
        // prefix from the current label. Display only — the DB row is untouched.
        if (r.category === 'CASINO' && !abCardDescription && gamename && roundId) {
          const dm = String(description).match(/^(.*?)(\s*\/\s*R\.No\s*:.*)$/i);
          // Spelling-insensitive: case, hyphens/spaces and a plural "s" ("Andar-Bahar
          // 150 card" → "ANDAR BAHAR 150 CARDS", 2026-10-14).
          const loose = (s) => String(s).toLowerCase().replace(/[^a-z0-9]/g, '').replace(/s$/, '');
          if (dm && loose(dm[1].trim()) === loose(gamename) && dm[1].trim() !== gamename) {
            description = `${gamename}${dm[2]}`;
          }
        }
        if (r.category === 'SPORTS') {
          const sb = sportsBetMap[r.bet_id];
          sportId = sb?.sport_id ?? r.sport_id ?? null;
          eventId = sb?.eventid ?? null;
          matchId = sb?.match_id ?? null;
          marketType = sb?.market_type ?? null;
          gameType = sb?.game_type ?? r.game_type ?? null;

          // Fancy ka naam: settlementv2 ab ise description me likhta hai, par
          // purani entries me sirf "… / Normal / <result>" hai — jisse pata hi
          // nahi chalta ki row kis fancy ki hai. Bet se naam le kar result se
          // theek pehle jod dete hain, taaki purana aur naya dono ek jaisa
          // dikhe: "Cricket / A v B / Normal / 1st wkt BT W / 40".
          // (Ye sirf display hai — DB me kuch nahi badalta, isliye `search`
          // abhi bhi asli remark par hi chalta hai.)
          // Ye naam row ke saath bhi jaata hai: Result modal isi se apne bets
          // filter karta hai, kyunki FAN par match_id poore event ka common hai.
          if (String(gameType || '').toUpperCase() === 'FAN') {
            fancyName = fanMarketName(sb);
            if (fancyName && description && !description.includes(fancyName)) {
              const parts = String(description).split(' / ');
              const spanAt = parts.length - 2;
              // khado settled before fanMarketName wrote the span ("… / khado / 8 / 24")
              // where the market name belongs — swap it rather than add a segment.
              if (isKhadoBet(sb) && parts.length >= 3 && parts[spanAt] === String(sb.fancy_name ?? '')) {
                parts[spanAt] = fancyName;
                description = parts.join(' / ');
              } else if (parts.length >= 2) {
                parts.splice(parts.length - 1, 0, fancyName);
                description = parts.join(' / ');
              }
            }
          }
        }

        // "-void" sabse AAKHIR me — fancy ka naam ghus jaane ke baad, taaki
        // line "Cricket / A v B / Normal / 1st wkt / 40 -void" padhi jaaye.
        if (voidRow) description = withVoidSuffix(description);

        return {
          date: r.created_at,
          credit: delta > 0 ? delta.toFixed(2) : '-',
          debit: delta < 0 ? Math.abs(delta).toFixed(2) : '-',
          closing: r.closing_inr_balance != null ? parseFloat(r.closing_inr_balance).toFixed(2) : '-',
          description,
          fromto: r?.remark?.split('#')[1] || '-',
          category: r.category || null,
          betId: r.bet_id != null ? Number(r.bet_id) : null,
          gamename,
          casinoCode,
          roundId,
          sportId,
          eventId,
          matchId,
          marketType,
          gameType,
          fancyName,
          // 'User creation' = the account's opening credit: nothing to open.
          eventType: r.event_type || null,
        };
      });

      return {
        success: true,
        data,
        total: count,
        totalPages: Math.ceil(count / limit),
        currentPage: parseInt(page),
      };
    } catch (e) {
      console.error('❌ [UserStatementService] getAccountStatementV2 error:', e);
      throw e;
    }
  },

  /**
   * Result modal for a SPORTS statement row: us market ke bets (SportsBet table
   * se) + winner (credits_ledger settlement description se).
   * Pehchaan: matchId (= market/mid) + eventId (= match/gmid), aur FAN par uske
   * upar fancyName — kyunki fancy markets ka match_id poore event me ek hi hota
   * hai (DB me 724 FAN bets par sirf 153 distinct match_id vs 420 asli markets).
   * Bina fancyName ke modal us event ki SAARI fancy bets dikha deta tha.
   * user_id filter se sirf logged-in user ke apne bets aate hain.
   */
  getStatementMarketBets: async (target, params = {}) => {
    try {
      const { matchId, eventId, fancyName } = params;
      if (!matchId || !eventId) {
        return { success: false, message: 'matchId and eventId required' };
      }

      const fancy = fancyName ? String(fancyName).trim() : '';

      const where = {
        user_id: target.id,
        match_id: String(matchId),
        eventid: String(eventId),
        // Bet placement kabhi fancy_name me naam rakhta hai, kabhi sirf
        // selection_name me (khado/fancy1 par fancy_name line hoti hai),
        // isliye dono par match karo.
        ...(fancy ? { [Op.or]: [{ fancy_name: fancy }, { selection_name: fancy }] } : {}),
      };

      // Ties on created_at are the two legs of one badlo swap (they share a
      // placement time); the reference lists the given-up `no` leg — the later
      // id — first, hence id DESC as the tie-break.
      const betRows = await SportsBet.findAll({
        where,
        order: [['created_at', 'ASC'], ['id', 'DESC']],
        raw: true,
      });

      // Winner: settlement entry ki description ka aakhri hissa
      // "Cricket / Southern Brave W v Birmingham Phoenix W / oddeven / 1" → "1"
      // Fancy par match_id se dhoondhne par event ki KISI BHI fancy ka result
      // aa jaata tha (aakhri settle hui entry), isliye ab in bets ke bet_id se
      // hi dhoondte hain — purani entries par bhi ye sahi rehta hai.
      const settledCredit = { [Op.or]: [{ profit: { [Op.ne]: null } }, { loss: { [Op.ne]: null } }] };
      const betIds = betRows.map(b => b.id);
      const credit = await CreditsLedger.findOne({
        where: {
          category: 'SPORTS',
          user_id: String(target.id),
          eventid: String(eventId),
          // Commission rows carry loss too, and sort newer — the winner must
          // come from the settlement row, never "…- Comm".
          reason: { [Op.notIn]: ['commission', 'commission_void'] },
          ...(fancy && betIds.length
            ? { bet_id: { [Op.in]: betIds } }   // credits_ledger.bet_id is bigint
            : { match_id: String(matchId) }),
          ...settledCredit,
        },
        order: [['id', 'DESC']],
        raw: true,
      });

      let winner = null;
      if (credit?.description) {
        const parts = String(credit.description).split(' / ');
        if (parts.length >= 2) winner = parts[parts.length - 1].trim() || null;
      }

      // Same source of truth the statement uses — settlement's own per-bet
      // payout. See sportsNet(): meter/badlo cannot be re-derived from the row.
      const fanNet = await loadFanSettlementNet(target.id, betRows);

      const DELETED_STATES = ['refund', 'void', 'deleted', 'cancelled'];
      let totalBets = 0;
      let totalWin = 0;

      // Full SportsBet row as-is + user/sport_name + computed side/win/deleted
      const bets = betRows.map(b => {
        const bt = String(b.bet_type || '').toLowerCase();
        const side = (bt === 'back' || bt === 'yes') ? 'BACK'
          : (bt === 'lay' || bt === 'no') ? 'LAY' : null;
        const rs = String(b.result_status || '').toLowerCase();
        const deleted = DELETED_STATES.includes(rs) || DELETED_STATES.includes(String(b.status || '').toLowerCase());
        const settled = rs === 'won' || rs === 'loss';
        const win = settled ? Math.round(sportsNet(b, fanNet.get(String(b.id))) * 100) / 100 : null;

        if (!deleted) {
          totalBets += 1;
          totalWin += win || 0;
        }

        return {
          ...b,
          user: { username: target.username || null },
          sport_name: SPORT_NAMES[b.sport_id] || (b.sport_id ? `Sport ${b.sport_id}` : null),
          side,
          win,
          deleted,
        };
      });

      const first = betRows[0] || null;
      const header = first ? {
        sportId: first.sport_id || null,
        sportName: SPORT_NAMES[first.sport_id] || (first.sport_id ? `Sport ${first.sport_id}` : '-'),
        eventId: first.eventid || null,
        matchId: first.match_id || null,
        matchTitle: first.match_title || [first.team_one, first.team_two].filter(Boolean).join(' v ') || '-',
        // League segment of the Result-modal breadcrumb (buildBreadcrumb in
        // AccountStatement.jsx). Null on bets placed before the column existed.
        competitionName: first.league_name || null,
        marketType: first.market_type || '-',
        gameType: first.game_type || null,
        // FAN par market_type sirf "Normal"/"khado" jaisa bucket hai — modal ke
        // breadcrumb me asli market yahi naam hai.
        fancyName: String(first.game_type || '').toUpperCase() === 'FAN'
          ? fanMarketName(first)
          : null,
        // Naive "YYYY-MM-DD HH:mm:ss": match_start_time holds the feed's IST wall
        // clock read as server-local, so a raw Date rendered 3h30m late in an IST
        // browser (00:30 showed as 04:00). See helper/naiveLocalTime.js.
        gameTime: toNaiveLocalTime(first.match_start_time) || first.created_at || null,
      } : null;

      return {
        success: true,
        header,
        winner,
        description: credit?.description || null,
        settledAt: credit?.created_at || null,
        totalBets,
        totalWin: Math.round(totalWin * 100) / 100,
        bets,
      };
    } catch (e) {
      console.error('❌ [UserStatementService] getStatementMarketBets error:', e);
      throw e;
    }
  },

  /**
   * Result modal for a CASINO statement row: us round ke SAARE bets
   * (casino_bets table se) + winner (casinoresult table se, provider winnat).
   * Pehchaan: roundId (statement row ka roundId). Purane bets jinke paas
   * round_id nahi hai unke liye betId fallback — sirf wahi ek bet aayega.
   */
  getStatementCasinoBets: async (target, params = {}) => {
    try {
      const { roundId, betId, view } = params;
      if (!roundId && !betId) {
        return { success: false, message: 'roundId or betId required' };
      }

      let where = roundId
        ? { user_id: target.id, round_id: String(roundId) }
        : { user_id: target.id, id: Number(betId) };
      let bookmakerOnly = false;
      let fancyLine = null; // Super Over fancy row: its line's bets only

      // A per-card game (ab3) row opens only the bets on its card in that
      // round (same grouping as the statement row), not the whole round.
      if (roundId && betId) {
        const own = await CasinoBet.findOne({
          where: { user_id: target.id, id: Number(betId) },
          attributes: ['id', 'game_name', 'selection', 'player_name'],
          raw: true,
        });
        // Super Over: a fancy row opens only its own bet; the Bookmaker row
        // opens the round's Bookmaker bets (fancy dropped after the fetch).
        if (isSuperOverFancyBet(own)) {
          fancyLine = superOverFancyName(own.selection).toLowerCase();
        } else if (own && SUPEROVER_FANCY_STATEMENT_GAMES.has(String(own.game_name || '').toLowerCase())) {
          bookmakerOnly = true;
        }
        if (own && PER_BET_STATEMENT_GAMES.has(String(own.game_name || '').toLowerCase())) {
          // Same rule as the statement row: the bets decided by the same dealt
          // card (this bet's) are one row; an undecided bet stands alone.
          where = { user_id: target.id, id: Number(betId) };
          const rank = abRankOf(own.selection);
          const cards = rank ? await fetchAbRoundCards(String(roundId), String(own.game_name).toLowerCase()) : null;
          const ownIdx = cards ? abDecidingIndex(own.game_name, own, cards) : null;
          if (ownIdx != null) {
            const sameCard = await CasinoBet.findAll({
              where: { user_id: target.id, round_id: String(roundId), selection: { [Op.in]: [`Andar ${rank}`, `Bahar ${rank}`] } },
              attributes: ['id', 'selection', 'player_name'],
              raw: true,
            });
            const ids = sameCard
              .filter((b) => abDecidingIndex(own.game_name, b, cards) === ownIdx)
              .map((b) => b.id);
            if (ids.length) where = { user_id: target.id, id: { [Op.in]: ids } };
          }
        }
      }

      const fetchedRows = await CasinoBet.findAll({
        where,
        order: [['created_at', 'ASC'], ['id', 'ASC']],
        raw: true,
      });
      // Roulette: bets the player undid are not listed (helper/casinoRefundedBets.js)
      // — except in Beach Roulette's Result modal, where they stay and land
      // under "Deleted" (casinoBetOutcome), like the reference.
      const undone = await loadUndoneBetIds(fetchedRows);
      const keepUndone = (b) => view === 'result'
        && UNDO_DELETED_GAMES.has(String(b.game_name || '').toLowerCase());
      const allBetRows = fetchedRows.filter((b) => !undone.has(String(b.id)) || keepUndone(b));
      const betRows = bookmakerOnly
        ? allBetRows.filter((b) => !isSuperOverFancyBet(b))
        : fancyLine
          ? allBetRows.filter((b) => isSuperOverFancyBet(b) && superOverFancyName(b.selection).toLowerCase() === fancyLine)
          : allBetRows;

      const first = betRows[0] || null;
      const gameCode = first?.game_name || null;
      const round = String(roundId || first?.round_id || '');

      // Winner: provider ka winnat — casinoresult (gamename, mid) unique.
      // mid akela unique nahi hai isliye game_name se disambiguate.
      let winner = null;
      if (round) {
        const result = await CasinoResult.findOne({
          where: { mid: round, ...(gameCode ? { gamename: gameCode } : {}) },
          raw: true,
        });
        winner = result?.win != null ? String(result.win) : null;

        // Table miss → provider se live winnat, aur cache back karo taaki
        // agli baar table se mil jaaye.
        if (!winner && gameCode) {
          winner = await fetchCasinoWinner(gameCode, round);
          if (winner) {
            try {
              await CasinoResult.upsert({ gamename: gameCode, mid: round, win: winner, date: new Date() });
            } catch (cacheErr) {
              console.warn('⚠️ [UserStatementService] casinoresult cache-back failed:', cacheErr.message);
            }
          }
        }
      }

      // settledAt: is round ke bets ki settlement ledger entry (latest)
      let settledAt = null;
      if (betRows.length) {
        const credit = await CreditsLedger.findOne({
          where: {
            category: 'CASINO',
            user_id: String(target.id),
            bet_id: { [Op.in]: betRows.map(b => b.id) },
          },
          order: [['id', 'DESC']],
          raw: true,
        });
        settledAt = credit?.created_at || null;
      }

      const round2 = (n) => Math.round(Number(n || 0) * 100) / 100;
      let totalBets = 0;
      let totalWin = 0;

      // Full casino_bets row as-is + user/game label + computed side/win/deleted
      // (helper/casinoBetResult.js — same rules as the admin Result modal).
      const refunded = await loadRefundedBetIds(betRows);
      const bets = betRows.map(b => {
        const { side, win, deleted } = casinoBetOutcome(b, { refunded: refunded.has(String(b.id)) });

        if (!deleted) {
          totalBets += 1;
          totalWin += win || 0;
        }

        return {
          ...b,
          user: { username: target.username || null },
          game_label: casinoGameLabel(b.game_name),
          side,
          win,
          deleted,
        };
      });

      const header = first ? {
        gamename: casinoGameLabel(gameCode),
        gameCode,
        roundId: first.round_id != null ? String(first.round_id) : (round || null),
        eventId: first.event_id != null ? String(first.event_id) : null,
        gameTime: first.created_at || null,
      } : null;

      return {
        success: true,
        header,
        winner,
        settledAt,
        totalBets,
        totalWin: round2(totalWin),
        bets,
      };
    } catch (e) {
      console.error('❌ [UserStatementService] getStatementCasinoBets error:', e);
      throw e;
    }
  },
};

export default UserStatementService;
