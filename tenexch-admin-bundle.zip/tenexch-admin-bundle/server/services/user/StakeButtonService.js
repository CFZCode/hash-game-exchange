import StakeButtonValue from '../../model/user/StakeButtonValue.js';

// The stake ladders a brand-new account starts with — exactly what the
// reference's "Set Button Value" modal shows on a fresh login.
//   Game Buttons:   1k  2k  5k  10k  20k  25k
//   Casino Buttons: 10  20  50  100  200  500
// Keep these two lists as the single source of truth: the controller seeds
// from them, account creation seeds from them, and the player app falls back
// to the same numbers when the API cannot be reached.
export const DEFAULT_GAME_BUTTONS = [
    { label: '1k', value: 1000 },
    { label: '2k', value: 2000 },
    { label: '5k', value: 5000 },
    { label: '10k', value: 10000 },
    { label: '20k', value: 20000 },
    { label: '25k', value: 25000 },
];

export const DEFAULT_CASINO_BUTTONS = [
    { label: '10', value: 10 },
    { label: '20', value: 20 },
    { label: '50', value: 50 },
    { label: '100', value: 100 },
    { label: '200', value: 200 },
    { label: '500', value: 500 },
];

// dbInit does not sync this table, so create it on first use (memoised — runs
// at most once per process). Same pattern as OneClickButtonListController.
let tableReady = null;
export const ensureTable = () => {
    if (!tableReady) {
        tableReady = StakeButtonValue.sync().catch((e) => { tableReady = null; throw e; });
    }
    return tableReady;
};

// The reference ladder has exactly six game buttons, and so does every slip
// that prints it. Older rows were stored with eight (…50k, 75k), so the cap is
// applied on read as well as on save — a stored ninth entry never reaches a
// client. Casino buttons are deliberately NOT capped.
export const MAX_GAME_BUTTONS = 6;

// Only keep what a client could actually render: an entry needs a positive
// value. Blank rows from the editor's padding are dropped here rather than
// being stored and filtered again by every client. `max` trims to the first
// N valid entries (game buttons pass MAX_GAME_BUTTONS).
export const cleanButtons = (list, fallback, max = Infinity) => {
    if (!Array.isArray(list)) return fallback;
    const rows = list
        .filter((b) => b && Number(b.value) > 0)
        .map((b) => ({ label: String(b.label ?? '').trim(), value: Number(b.value) }))
        .slice(0, max);
    return rows.length ? rows : fallback;
};

/**
 * Give one user their own row, if they do not have one yet.
 *
 * Called at account creation so the defaults are in the database from day one,
 * and again on the first read as a safety net for accounts that predate this.
 * Never throws at the caller: a missing stake ladder must not fail (or roll
 * back) the creation of an account.
 *
 * @param {number} userId
 * @param {object} [transaction] sequelize transaction of the caller, if any
 */
export const seedForUser = async (userId, transaction = undefined) => {
    if (!userId) return null;
    try {
        await ensureTable();
        const [row] = await StakeButtonValue.findOrCreate({
            where: { user_id: userId },
            defaults: {
                user_id: userId,
                game_buttons: DEFAULT_GAME_BUTTONS,
                casino_buttons: DEFAULT_CASINO_BUTTONS,
            },
            ...(transaction ? { transaction } : {}),
        });
        return row;
    } catch (err) {
        console.error('seedForUser (stake buttons) failed for user', userId, err.message);
        return null;
    }
};

export default { DEFAULT_GAME_BUTTONS, DEFAULT_CASINO_BUTTONS, ensureTable, cleanButtons, seedForUser };
