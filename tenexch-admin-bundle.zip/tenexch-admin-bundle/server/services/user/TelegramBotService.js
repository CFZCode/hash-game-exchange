
import { Telegraf } from 'telegraf';
import dotenv from 'dotenv';
import SecureAuthConfigService from './SecureAuthConfigService.js';
dotenv.config();

// The Telegraf instance is rebuilt whenever the owner swaps the bot token in
// the admin panel, so a token change takes effect without a server restart.
let bot = null;
let botToken = null;

const getBot = async () => {
    const token = await SecureAuthConfigService.getBotToken();
    if (!token) return null;
    if (!bot || token !== botToken) {
        bot = new Telegraf(token);
        botToken = token;
    }
    return bot;
};

const TelegramBotService = {
    sendMessage: async (chatId, text) => {
        const instance = await getBot();
        if (!instance) {
            console.warn('⚠️ Telegram Bot Token not set, cannot send message.');
            return;
        }
        try {
            await instance.telegram.sendMessage(chatId, text, { parse_mode: 'HTML' });
        } catch (error) {
            console.error('❌ Telegram Send Message Error:', error.message);
        }
    },
};

export default TelegramBotService;
