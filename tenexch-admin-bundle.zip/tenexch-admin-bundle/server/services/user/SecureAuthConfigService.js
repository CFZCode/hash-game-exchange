/**
 * Reads/writes the site's Telegram-bot settings for secure auth.
 *
 * The values live in the `secure_auth_config` table (single row) so an owner can
 * change the bot from the admin panel. `.env` is only the seed / fallback, which
 * keeps a site working if the row was never created.
 *
 * A small in-process cache avoids a query on every OTP send; it is cleared by
 * save(), and expires on its own so other pm2 processes (crons, the bot) pick a
 * change up without a restart.
 */
import { Telegraf } from 'telegraf';
import SecureAuthConfig, { SECURE_AUTH_ROW_ID } from '../../model/admin/SecureAuthConfig.js';

const CACHE_TTL_MS = 30 * 1000;
let cache = null;
let cachedAt = 0;

const envFallback = () => ({
    bot_username: process.env.TELEGRAM_BOT_USERNAME || null,
    bot_token: process.env.TELEGRAM_BOT_TOKEN || null,
});

/**
 * Ask Telegram which bot a token belongs to. Used to fill in the handle when a
 * token is saved without one, so the player instructions never show a blank bot.
 * Returns null on any failure — this is a convenience, never a hard dependency.
 */
const resolveUsernameFromToken = async (token) => {
    if (!token) return null;
    try {
        const me = await new Telegraf(token).telegram.getMe();
        return me?.username || null;
    } catch (error) {
        console.warn('⚠️ Could not resolve bot username from token:', error.message);
        return null;
    }
};

const SecureAuthConfigService = {
    clearCache: () => { cache = null; cachedAt = 0; },

    resolveUsernameFromToken,

    /** Raw config incl. the token. Server-side only — never send this to a client. */
    get: async () => {
        if (cache && Date.now() - cachedAt < CACHE_TTL_MS) return cache;
        try {
            const row = await SecureAuthConfig.findByPk(SECURE_AUTH_ROW_ID);
            const fallback = envFallback();
            cache = {
                bot_username: row?.bot_username || fallback.bot_username,
                bot_token: row?.bot_token || fallback.bot_token,
            };
        } catch (error) {
            // A missing table (pre-migration boot) must not break OTP delivery.
            console.error('❌ SecureAuthConfig read failed, using .env:', error.message);
            cache = envFallback();
        }
        cachedAt = Date.now();
        return cache;
    },

    getBotToken: async () => (await SecureAuthConfigService.get()).bot_token,

    getBotUsername: async () => (await SecureAuthConfigService.get()).bot_username,

    /** https://t.me/<handle> — what the player taps in the instructions. */
    getBotLink: async () => {
        const username = await SecureAuthConfigService.getBotUsername();
        return username ? `https://t.me/${username}` : null;
    },

    /**
     * Upsert the single row. Only the fields present in `patch` are written, so
     * saving a username alone never wipes the stored token.
     */
    save: async (patch) => {
        const [row] = await SecureAuthConfig.findOrCreate({
            where: { id: SECURE_AUTH_ROW_ID },
            defaults: { id: SECURE_AUTH_ROW_ID, ...envFallback() },
        });

        if (patch.bot_username !== undefined) {
            // Tolerate '@handle' and a full t.me URL — store the bare handle.
            row.bot_username = String(patch.bot_username || '')
                .trim()
                .replace(/^https?:\/\/t\.me\//i, '')
                .replace(/^@/, '') || null;
        }
        const previousToken = row.bot_token;
        if (patch.bot_token !== undefined) {
            row.bot_token = String(patch.bot_token || '').trim() || null;
        }
        const tokenChanged = row.bot_token && row.bot_token !== previousToken;

        // The handle must always belong to the token that actually delivers the
        // codes: a new token with the PREVIOUS bot's handle still in the form
        // sent players to a bot nobody was listening on. So whenever the token
        // changes, Telegram decides the handle; a typed one is only a fallback.
        // (A token with no handle at all would render "(bot not configured)".)
        if (tokenChanged || (!row.bot_username && row.bot_token)) {
            row.bot_username = (await resolveUsernameFromToken(row.bot_token)) || row.bot_username;
        }

        await row.save();
        SecureAuthConfigService.clearCache();
        return row;
    },
};

export default SecureAuthConfigService;
