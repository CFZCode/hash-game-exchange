import redis from '../config/redisClient.js';
import { Op } from 'sequelize';
import Staff from '../model/admin/Staff.js';
import User from '../model/user/User.js';
import ThirdPartyGameLimit from '../model/admin/ThirdPartyGameLimit.js';

// ─────────────────────────────────────────────────────────────────────────────
// Third-party (JS games) stake limit — resolution + cache.
//
// WHAT IT MEANS
//   The owner sets a max stake on a hierarchy node (owner / staff / user). That
//   number is the DEFAULT for the whole sub-tree below it. A player's effective
//   limit is the FIRST non-zero value walking nearest → farthest:
//
//       USER:<id> → STAFF:<parent> → STAFF:<grandparent> → … → OWNER:<root>
//
//   0 (or no row anywhere in the chain) = no limit. The cap is per SINGLE bet.
//
// WHY IT IS SHAPED LIKE THIS
//   This is read on EVERY third-party bet callback but written only when the
//   owner presses Save, so it is read through the same two tiers
//   BettingConfigService uses:
//
//     1. Redis (shared by every pm2 worker) — TTL below, deleted on write.
//     2. A per-process micro cache          — MICRO_TTL_MS, so a burst of
//                                             callbacks never round-trips Redis.
//
//   Two keys only:
//     tpl:map:v1        the WHOLE limit table as { "STAFF:12": 500, … }. Only
//                       nodes that actually have a limit are in it (dozens, not
//                       thousands), so one small JSON answers every lookup and
//                       invalidation on save is a single del — no subtree walk.
//     tpl:chain:u:<id>  that player's ancestor chain, which changes only when
//                       the account is moved to another parent (assign-agent);
//                       CHAIN_TTL_SEC bounds how long a move stays stale.
//
//   Everything FAILS OPEN: any Redis or DB error resolves to 0 = no limit,
//   which is exactly the behaviour before this feature existed. A limit lookup
//   must never be able to take betting down.
// ─────────────────────────────────────────────────────────────────────────────

const KEY_MAP = 'tpl:map:v1';
const keyChain = (userId) => `tpl:chain:u:${userId}`;

const MAP_TTL_SEC = 300;
const CHAIN_TTL_SEC = 600;
const MICRO_TTL_MS = 2000;

// Guards against a corrupted parent_id loop turning a bet into an infinite walk.
const MAX_CHAIN_DEPTH = 20;

const micro = new Map(); // key -> { value, expires }

const microGet = (key) => {
    const hit = micro.get(key);
    if (!hit) return undefined;
    if (hit.expires < Date.now()) {
        micro.delete(key);
        return undefined;
    }
    return hit.value;
};

const microSet = (key, value) => {
    micro.set(key, { value, expires: Date.now() + MICRO_TTL_MS });
};

// Read-through: micro → redis → builder(). Never throws.
const readThrough = async (key, ttlSec, builder, fallback) => {
    const local = microGet(key);
    if (local !== undefined) return local;

    try {
        const cached = await redis.get(key);
        if (cached != null) {
            const parsed = JSON.parse(cached);
            microSet(key, parsed);
            return parsed;
        }
    } catch (err) {
        console.warn(`[ThirdPartyLimit] redis read failed for ${key}:`, err.message);
    }

    let built;
    try {
        built = await builder();
    } catch (err) {
        console.warn(`[ThirdPartyLimit] build failed for ${key}:`, err.message);
        return fallback;
    }

    microSet(key, built);
    redis.set(key, JSON.stringify(built), 'EX', ttlSec).catch((err) =>
        console.warn(`[ThirdPartyLimit] redis write failed for ${key}:`, err.message)
    );
    return built;
};

const drop = async (key) => {
    micro.delete(key);
    try {
        await redis.del(key);
    } catch (err) {
        console.warn(`[ThirdPartyLimit] redis del failed for ${key}:`, err.message);
    }
};

export const holderKey = (type, id) => `${String(type).toUpperCase()}:${Number(id)}`;

// ── Limit map ───────────────────────────────────────────────────────────────

const buildLimitMap = async () => {
    const rows = await ThirdPartyGameLimit.findAll({
        where: { max_amount: { [Op.gt]: 0 } },
        attributes: ['holder_type', 'holder_id', 'max_amount'],
        raw: true,
    });
    const map = {};
    for (const r of rows) {
        const amount = parseFloat(r.max_amount || 0);
        if (amount > 0) map[holderKey(r.holder_type, r.holder_id)] = amount;
    }
    return map;
};

export const getLimitMap = () => readThrough(KEY_MAP, MAP_TTL_SEC, buildLimitMap, {});

// ── Ancestor chains ─────────────────────────────────────────────────────────

// Nearest → farthest, e.g. ['STAFF:14', 'STAFF:13', 'STAFF:12', 'OWNER:1'].
const buildStaffChain = async (staffId) => {
    const chain = [];
    let currentId = Number(staffId) || null;
    let ownerId = null;
    let depth = 0;

    while (currentId && depth++ < MAX_CHAIN_DEPTH) {
        const staff = await Staff.findByPk(currentId, {
            attributes: ['staff_id', 'parent_id', 'parent_owner_id'],
            raw: true,
        });
        if (!staff) break;
        chain.push(holderKey('STAFF', staff.staff_id));
        // Every staff row carries the root owner id, deep ones included, so the
        // owner is known even if the walk stops early on a broken parent_id.
        if (staff.parent_owner_id) ownerId = staff.parent_owner_id;
        currentId = staff.parent_id;
    }

    return { chain, ownerId };
};

const buildUserChain = async (userId) => {
    const user = await User.findByPk(userId, {
        attributes: ['user_id', 'parent_staff_id', 'parent_owner_id'],
        raw: true,
    });
    if (!user) return [];

    const chain = [holderKey('USER', user.user_id)];

    let ownerId = user.parent_owner_id || null;
    if (user.parent_staff_id) {
        const up = await buildStaffChain(user.parent_staff_id);
        chain.push(...up.chain);
        if (up.ownerId) ownerId = up.ownerId;
    }

    if (ownerId) chain.push(holderKey('OWNER', ownerId));
    return chain;
};

// The chain for any node, used by the admin screen. Users go through the cache
// (bet path); staff/owner are resolved live because the admin list asks for
// them once per page load, not once per bet.
export const getChainForHolder = async (holderType, holderId) => {
    const type = String(holderType).toUpperCase();

    if (type === 'USER') {
        return readThrough(keyChain(holderId), CHAIN_TTL_SEC, () => buildUserChain(holderId), []);
    }

    if (type === 'STAFF') {
        const { chain, ownerId } = await buildStaffChain(holderId);
        if (ownerId) chain.push(holderKey('OWNER', ownerId));
        return chain;
    }

    return [holderKey('OWNER', holderId)];
};

// ── Resolution ──────────────────────────────────────────────────────────────

const firstNonZero = (map, chain) => {
    for (const key of chain) {
        const value = map[key];
        if (value > 0) return value;
    }
    return 0;
};

/**
 * Effective per-bet stake cap for one node, inheritance included.
 * @returns {Promise<number>} 0 = no limit
 */
export const getEffectiveForHolder = async (holderType, holderId) => {
    try {
        const [map, chain] = await Promise.all([
            getLimitMap(),
            getChainForHolder(holderType, holderId),
        ]);
        return firstNonZero(map, chain);
    } catch (err) {
        console.warn('[ThirdPartyLimit] resolve failed:', err.message);
        return 0; // fail open
    }
};

/**
 * The one the bet path calls. Cached end to end: on a warm process this costs
 * two Map lookups and no IO at all.
 * @returns {Promise<number>} 0 = no limit
 */
export const getEffectiveLimit = (userId) => getEffectiveForHolder('USER', userId);

// ── Writes ──────────────────────────────────────────────────────────────────

/**
 * Set (or clear, when amount <= 0) one node's limit and invalidate the cache.
 * Storing 0 as a row would mean "pinned unlimited", which the feature does not
 * have — a cleared node inherits from above instead — so 0 deletes the row.
 */
export const setLimit = async ({ holderType, holderId, maxAmount, setByType = null, setById = null }) => {
    const type = String(holderType).toUpperCase();
    const id = Number(holderId);
    const amount = Number(maxAmount);

    if (!ThirdPartyGameLimit.HOLDER_TYPES.includes(type)) {
        throw new Error(`Invalid holder_type: ${holderType}`);
    }
    if (!Number.isInteger(id) || id <= 0) throw new Error('Invalid holder_id');
    if (!Number.isFinite(amount) || amount < 0) throw new Error('Invalid max_amount');

    if (amount <= 0) {
        await ThirdPartyGameLimit.destroy({ where: { holder_type: type, holder_id: id } });
    } else {
        const rounded = Math.round(amount * 100) / 100;
        const existing = await ThirdPartyGameLimit.findOne({
            where: { holder_type: type, holder_id: id },
        });
        if (existing) {
            await existing.update({ max_amount: rounded, set_by_type: setByType, set_by_id: setById });
        } else {
            await ThirdPartyGameLimit.create({
                holder_type: type,
                holder_id: id,
                max_amount: rounded,
                set_by_type: setByType,
                set_by_id: setById,
            });
        }
    }

    // One del — every node below inherits through the map, so there is nothing
    // per-descendant to invalidate. Other pm2 workers pick it up on their next
    // read; their micro cache bounds that to MICRO_TTL_MS.
    await drop(KEY_MAP);
    return amount <= 0 ? 0 : Math.round(amount * 100) / 100;
};

/** Call when a player is moved to a different parent (assign-agent). */
export const invalidateUserChain = (userId) => drop(keyChain(userId));

export default {
    getEffectiveLimit,
    getEffectiveForHolder,
    getChainForHolder,
    getLimitMap,
    setLimit,
    invalidateUserChain,
    holderKey,
};
