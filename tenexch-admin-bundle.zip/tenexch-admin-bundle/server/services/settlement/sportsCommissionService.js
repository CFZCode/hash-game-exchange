import sequelize from '../../config/db.js';
import Wallet from '../../model/admin/Wallet.js';
import User from '../../model/user/User.js';
import CreditsLedger from '../../model/user/CreditsLedger.js';
import CommissionConfig from '../../model/admin/CommissionConfig.js';
import CommissionConfigService from '../CommissionConfigService.js';
import { leagueKeyFromName, leagueLabel } from '../../constants/commissionLeagues.js';
import { resolveLeagueName } from '../SportsLeagueResolver.js';
import WalletService from '../walletService.js';

// ─────────────────────────────────────────────────────────────────────────────
// Sports win commission — the second, separate movement after a winning
// settlement. Plan: docs/plans/2026-09-09-sports-win-commission.md
//
// Rule: if the owner switched ON the (sport_id, league_key, market_key) cell,
// deduct percent × NET WIN from the wallet and write it as its own rows.
//
// market_key is finer than the feed's gtype: gtype 'match' is EVERY main
// market, so it is split into 'matchodds' (the market really is Match Odds)
// and 'match_other' (Over/Under, Correct Score, Match Result, Inning EvenOdd,
// Nth Ball Of Match…), and 'match1' into 'bookmaker' and 'match1_other'
// (Tied Match, Completed Match, Score More Runs…).
//
// league_key separates leagues the feed ships under the same sport id but that
// are a different product — cricket's T5 XI / T10 XI / Virtual Cricket League
// and the "(e)" e-cricket league all arrive as sport_id 4. A variant cell with
// no saved row INHERITS the sport's 'default' cell.
//
// The rows written are:
//
//   credits_ledger  reason='commission', amount/netamount = -comm,
//                   commission = comm, loss = -comm (so every ledger-based P/L
//                   counts it as a user loss), description = "<settlement desc>- Comm",
//                   meta.commission_of_ledger_id = the settlement row it belongs to
//   point_ledger    event_type COMMISSION, delta -comm on the whole chain
//                   (user → staff… → owner) — exactly like a settlement, so the
//                   statement shows the "- Comm" line and
//                   all_point = SUM(point_ledger) keeps holding
//   users           net_loss -= comm, profit -= comm (same counters a lost bet feeds)
//
// Base amount = the market's net win: marketNetAmount for MO/BM and non-fancy
// (one row per market), the bet's netamount for FAN (one row per bet).
// Losses, refunds, voids and net-zero markets never reach here.
//
// Never throws — a commission failure is logged and the settlement stands.
// ─────────────────────────────────────────────────────────────────────────────

export const COMMISSION_REASON = 'commission';
export const COMMISSION_VOID_REASON = 'commission_void';
export const COMMISSION_SUFFIX = '- Comm';

const round2 = (v) => Math.round((Number(v) || 0) * 100) / 100;

/**
 * @param {object} p
 * @param {number|string} p.user_id
 * @param {object} p.bet              representative SportsBet row (firstBet for MO/BM)
 * @param {number} p.netWin           market net P/L already paid (> 0 to charge)
 * @param {number} p.settlementLedgerId  credits_ledger.id of the settlement row
 * @param {string} p.description      the settlement row's description
 * @param {string} p.market_type
 * @param {string} [p.eventid]
 * @param {string} [p.match_id]
 * @param {string} [p.job_id]
 * @param {object} [p.log]            settlement logger ({ info, warn, error })
 */
export async function applyWinCommission(p) {
    const log = p.log || console;
    try {
        const netWin = round2(p.netWin);
        if (!(netWin > 0)) return { applied: false, reason: 'no net win' };
        if (!p.settlementLedgerId) return { applied: false, reason: 'no settlement ledger id' };

        const bet = p.bet || {};
        const sportId = bet.sport_id ?? p.sport_id ?? null;
        const marketKey = CommissionConfig.marketKeyOfBet(bet);

        // The league decides which ROW of the grid applies. It normally rides
        // on the bet (SportsBet.league_name, backfilled at placement), but a
        // bet placed before that backfill shipped — or one whose client never
        // sent a cname — has none, and guessing 'default' would bill a virtual
        // round at the real-match rate. Ask the feed cache before giving up.
        let leagueName = bet.league_name || null;
        if (!leagueName && (bet.eventid || p.eventid)) {
            leagueName = await resolveLeagueName(sportId, bet.eventid || p.eventid);
        }
        const leagueKey = leagueKeyFromName(sportId, leagueName);

        const rule = await CommissionConfigService.getRule(sportId, leagueKey, marketKey);
        if (!rule.enabled) {
            return { applied: false, reason: `cell off (${sportId}/${leagueKey}/${marketKey})` };
        }

        const comm = round2(netWin * rule.percent / 100);
        if (!(comm > 0)) return { applied: false, reason: 'rounds to 0' };

        // Idempotent per settlement row — a re-run of the same job must not
        // charge twice.
        const dup = await CreditsLedger.findOne({
            where: {
                user_id: String(p.user_id),
                reason: COMMISSION_REASON,
                bet_id: bet.id || null,
            },
            attributes: ['id', 'meta'],
            raw: true,
        });
        if (dup && Number(dup.meta?.commission_of_ledger_id) === Number(p.settlementLedgerId)) {
            return { applied: false, reason: `already charged (ledger ${dup.id})` };
        }

        const description = `${p.description || ''}${COMMISSION_SUFFIX}`;

        let newCash = 0, newInr = 0, ledgerId = null;
        await sequelize.transaction(async (transaction) => {
            const wallet = await Wallet.findOne({
                where: { user_id: String(p.user_id) },
                transaction,
                lock: transaction.LOCK.UPDATE,
            });
            if (!wallet) throw new Error(`wallet not found for user ${p.user_id}`);

            newCash = round2(Number(wallet.cash || 0) - comm);
            newInr = round2(Number(wallet.inr_balance || 0) - comm);
            await wallet.update({ cash: newCash, inr_balance: newInr }, { transaction });

            // Same counters a losing bet feeds (settlementv2 loss branch).
            await User.increment(
                { net_loss: -comm, profit: -comm },
                { where: { user_id: p.user_id }, transaction }
            );

            const row = await CreditsLedger.create({
                user_id: String(p.user_id),
                currency: 'INR',
                amount: -comm,
                reason: COMMISSION_REASON,
                description,
                eventid: p.eventid || null,
                match_id: p.match_id || null,
                job_id: p.job_id || null,
                market_type: p.market_type || null,
                sport_id: sportId != null ? String(sportId) : null,
                meta: {
                    commission_of_ledger_id: Number(p.settlementLedgerId),
                    percent: rule.percent,
                    // Which cell of the grid charged this, so a disputed
                    // commission can be traced back without replaying config
                    // history. `gtype` is kept for the pre-2026-09-12 readers.
                    market_key: marketKey,
                    league_key: leagueKey,
                    league_name: leagueName || null,
                    rule_source: rule.source || 'default',
                    gtype: String(bet.gtype || '').toLowerCase() || null,
                    net_win: netWin,
                },
                commission: comm,
                netamount: -comm,
                profit: null,
                loss: -comm,
                bet_id: bet.id || null,
                closing: newCash,
                category: 'SPORTS',
            }, { transaction });
            ledgerId = row.id;
        });

        // Points chain has its own transaction (same as settlement → all_point).
        const pts = await WalletService.applyCommissionPoints({
            betId: Number(bet.id),
            userId: Number(p.user_id),
            amount: comm,
            remark: description,
            sportId: sportId != null ? String(sportId) : null,
            gtype: marketKey,
        });
        if (!pts.success) {
            log.error('[Commission] points chain failed', { user_id: p.user_id, bet_id: bet.id, error: pts.error });
        }

        log.info('[Commission] charged', {
            user_id: p.user_id, bet_id: bet.id, sport_id: sportId,
            market_key: marketKey, league_key: leagueKey,
            league: leagueLabel(sportId, leagueKey), league_name: leagueName || null,
            rule_source: rule.source || 'default', market_name: bet.market_type || null,
            net_win: netWin, percent: rule.percent, commission: comm,
            ledger_id: ledgerId, closing_cash: newCash, closing_inr: newInr,
        });
        return {
            applied: true, commission: comm, percent: rule.percent, ledgerId,
            market_key: marketKey, league_key: leagueKey,
        };
    } catch (err) {
        log.error('[Commission] failed — settlement stands, commission NOT charged', {
            user_id: p?.user_id, bet_id: p?.bet?.id, error: err.message,
        });
        return { applied: false, reason: err.message };
    }
}

export default { applyWinCommission, COMMISSION_REASON, COMMISSION_VOID_REASON, COMMISSION_SUFFIX };
