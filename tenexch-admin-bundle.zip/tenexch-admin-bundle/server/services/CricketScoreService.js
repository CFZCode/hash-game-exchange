import dotenv from 'dotenv';
dotenv.config();

/* Live cricket score summary, served over HTTP instead of a socket per browser.
 *
 * WHY THIS EXISTS
 * The score provider only speaks Socket.IO v2 (Engine.IO v3) — every REST shape
 * we probed on it answers 404:
 *   /  /api/summary?eventId=  /summary/<gmid>  /api/event/<gmid>
 *   /event/<gmid>/summary  /api/score/<gmid>
 * So the frontend was opening its own WebSocket per viewer, and our existing
 * `/user/cricket/score-card` only returns an iframe URL, never the summary
 * fields the scorecard actually renders (spnnation1, score1, balls…).
 *
 * This service opens ONE upstream socket per match, no matter how many players
 * are watching, caches the latest summary and serves it over plain HTTP. A
 * thousand viewers on one match cost one upstream connection instead of a
 * thousand.
 *
 * WIRE FORMAT (Engine.IO v3 — hand-framed, no client library)
 *   "0{…}"           engine OPEN
 *   "40"             socket.io CONNECT      → safe to emit
 *   "2" / "3"        ping / pong            → keepalive
 *   "42[ev,payload]" EVENT                  → the data we want
 * We emit: 42["subscribe_event",{eventId,providerId:"1"}] and a "2" every 20s
 * (the server's pingInterval is 25s).
 *
 * RUNTIME NOTE
 * Uses the global WebSocket, which Node ships from v22. On an older runtime it
 * falls back to the optional `ws` package; if neither is available the service
 * reports that once and every request answers with `available: false` rather
 * than throwing on each call.
 */

const SOCKET_URL = process.env.SCORE_SOCKET_URL || 'wss://dimclscore.external247services.com';
// A match nobody has asked about for this long drops its upstream socket.
const IDLE_TIMEOUT_MS = 5 * 60 * 1000;
// How long a caller waits for the first frame when the socket has just opened.
const FIRST_FRAME_TIMEOUT_MS = 6000;
const PING_MS = 20000;
const RETRY_MS = 2000;

let WebSocketImpl = typeof WebSocket !== 'undefined' ? WebSocket : null;
let implChecked = !!WebSocketImpl;

async function resolveWebSocket() {
  if (implChecked) return WebSocketImpl;
  implChecked = true;
  try {
    const mod = await import('ws');
    WebSocketImpl = mod.default || mod.WebSocket;
  } catch {
    console.error(
      '[cricket-score] no WebSocket available: this runtime predates the global ' +
      'WebSocket (Node 22+) and the optional `ws` package is not installed. ' +
      'Live score summaries are disabled.'
    );
    WebSocketImpl = null;
  }
  return WebSocketImpl;
}

// gmid -> { ws, last, lastAt, lastAccess, waiters, timers… }
const rooms = new Map();

function closeRoom(gmid) {
  const room = rooms.get(gmid);
  if (!room) return;
  room.closedByUs = true;
  clearInterval(room.pingTimer);
  clearTimeout(room.retryTimer);
  clearInterval(room.idleTimer);
  try { room.ws?.close(); } catch { /* already gone */ }
  rooms.delete(gmid);
}

async function openRoom(gmid) {
  const Impl = await resolveWebSocket();
  if (!Impl) return null;

  const room = {
    ws: null,
    last: null,       // latest summary.data
    lastAt: null,     // when it arrived
    waiters: [],      // callers waiting for the very first frame
    closedByUs: false,
    lastAccess: Date.now(),
    pingTimer: null,
    retryTimer: null,
    idleTimer: null,
  };
  rooms.set(gmid, room);

  const SUB = '42' + JSON.stringify(['subscribe_event', { eventId: String(gmid), providerId: '1' }]);

  const connect = () => {
    let ws;
    try {
      ws = new Impl(`${SOCKET_URL.replace(/\/+$/, '')}/socket.io/?EIO=3&transport=websocket`);
    } catch {
      room.retryTimer = setTimeout(connect, RETRY_MS);
      return;
    }
    room.ws = ws;
    let subscribed = false;
    const subscribe = () => {
      if (subscribed || ws.readyState !== 1) return;
      subscribed = true;
      ws.send(SUB);
    };

    const onOpen = () => {
      // Some deployments send "40" first, some don't — subscribe on a short
      // delay too, so the window is never missed.
      setTimeout(subscribe, 300);
      room.pingTimer = setInterval(() => { if (ws.readyState === 1) ws.send('2'); }, PING_MS);
    };

    const onMessage = (event) => {
      const raw = typeof event === 'string' ? event : event?.data;
      const m = typeof raw === 'string' ? raw : String(raw ?? '');
      if (!m) return;
      if (m === '3') return;                       // pong
      if (m === '2') { ws.send('3'); return; }     // ping → pong
      if (m[0] === '0') return;                    // engine open
      if (m.startsWith('40')) { subscribe(); return; }
      if (!m.startsWith('42')) return;
      try {
        const [, payload] = JSON.parse(m.slice(2));
        const data = payload?.summary?.data;
        if (data && typeof data === 'object') {
          room.last = data;
          room.lastAt = Date.now();
          const waiters = room.waiters;
          room.waiters = [];
          waiters.forEach((resolve) => resolve(data));
        }
      } catch { /* malformed frame — ignore */ }
    };

    const onClose = () => {
      clearInterval(room.pingTimer);
      if (!room.closedByUs) room.retryTimer = setTimeout(connect, RETRY_MS);
    };

    // Global WebSocket takes events; `ws` takes both — addEventListener works
    // for either, so one path covers both runtimes.
    ws.addEventListener('open', onOpen);
    ws.addEventListener('message', onMessage);
    ws.addEventListener('close', onClose);
    ws.addEventListener('error', () => { try { ws.close(); } catch { /* noop */ } });
  };

  room.idleTimer = setInterval(() => {
    if (Date.now() - room.lastAccess > IDLE_TIMEOUT_MS) closeRoom(gmid);
  }, 60000);

  connect();
  return room;
}

/**
 * Latest score summary for a match.
 * @param {string|number} gmid
 * @returns {Promise<{available:boolean, data:object|null, ageMs:number|null}>}
 */
export async function getScoreSummary(gmid) {
  const key = String(gmid);
  let room = rooms.get(key);
  if (!room) room = await openRoom(key);
  if (!room) return { available: false, data: null, ageMs: null };

  room.lastAccess = Date.now();
  if (room.last) {
    return { available: true, data: room.last, ageMs: Date.now() - room.lastAt };
  }

  // Nothing cached yet — the socket has only just opened. Wait briefly for the
  // first frame rather than answering with an empty body the caller has to poll
  // around.
  const data = await new Promise((resolve) => {
    const timer = setTimeout(() => {
      room.waiters = room.waiters.filter((w) => w !== resolve);
      resolve(null);
    }, FIRST_FRAME_TIMEOUT_MS);
    room.waiters.push((d) => { clearTimeout(timer); resolve(d); });
  });

  return data
    ? { available: true, data, ageMs: 0 }
    : { available: true, data: null, ageMs: null };
}

/** Rooms currently held open — for health checks. */
export function getActiveRooms() {
  return [...rooms.entries()].map(([gmid, r]) => ({
    gmid,
    connected: r.ws?.readyState === 1,
    hasData: !!r.last,
    ageMs: r.lastAt ? Date.now() - r.lastAt : null,
    idleMs: Date.now() - r.lastAccess,
  }));
}

export default { getScoreSummary, getActiveRooms };
