import redis from '../config/redisClient.js';
import CricketService from './CricketService.js';
import { sortLeaguesByMinGmid } from '../helper/sportsTreeOrder.js';

/* The sidebar's event tree, in the REFERENCE's order.
 *
 * WHY THIS EXISTS. `/user/all/sports/tree` hands the tree back exactly as the
 * upstream feed gives it, and that feed reorders the SAME competitions every
 * few minutes. Every client then invented its own order: the admin held a
 * seeded name list (`data/seriesOrderSeed.js`, read off a reference capture),
 * which the user called out on 2026-09-23 ("naam ko daal ke hardcode karke
 * check laga raha hai, which is not good"); this endpoint then sorted leagues
 * by their soonest start time, read from the `alleventss:{etid}` cache — a
 * rule that was chosen, not the reference's, and that needed a second feed
 * and a Redis warm-up to work at all.
 *
 * The reference's rule was found on 2026-10-01 and lives in
 * helper/sportsTreeOrder.js: leagues by the smallest gmid among their matches.
 * It needs nothing but the tree, so the start-time lookup is gone.
 *
 * The order this endpoint returns:
 *   sports  — the feed's own t1 sequence, with t2 (Horse Racing 10, Greyhound
 *             Racing 65) spliced in after the 4th entry. That IS the
 *             reference's sport order, verified 39/39 on the live tree.
 *   leagues — by minimum match gmid, ascending (helper/sportsTreeOrder.js);
 *             every feed node kept, duplicates by name included.
 *   matches — left exactly as the tree gives them: that is already the
 *             reference's order (verified 569/569 league-rounds).
 *
 * Plan + measurements: docs/plans/2026-10-01-admin-events-order.md.
 */

/* The composed answer gets its own, longer cache than the raw tree (2 s): the
   order only moves when a fixture list turns over. */
const CACHE_KEY = 'sports_events_tree';
const CACHE_TTL = 15;

// racing lives in t2 and the reference shows it after Tennis (the 4th sport)
const RACING_SPLICE_AT = 4;

const SportsEventsService = {
  /**
   * The tree, ordered. Same node shape the tree endpoint returns
   * (sport {etid, name, oid, children} → league {cid, name, children} →
   * match {etid, gmid, iscc, name}), only as one ordered `sports` array.
   */
  buildEvents: async () => {
    const cached = await redis.get(CACHE_KEY).catch(() => null);
    if (cached) {
      try {
        return JSON.parse(cached);
      } catch { /* fall through and rebuild */ }
    }

    const tree = await CricketService.fetchTreeData();
    const inner = tree?.data?.data || tree?.data || tree || {};
    const t1 = Array.isArray(inner.t1) ? inner.t1 : [];
    const t2 = Array.isArray(inner.t2) ? inner.t2 : [];

    const sports = [...t1];
    sports.splice(RACING_SPLICE_AT, 0, ...t2);

    /* Racing (t2) is only two levels deep — sport → race, no competition in
       between — and its races carry their own `sdatetime`. Sorting them is the
       clients' business (they group races by country first), so t2 is passed
       through untouched. */
    const racingIds = new Set(t2.map((s) => String(s?.etid)));

    const ordered = sports.map((sport) => {
      const children = sport?.children || [];
      if (!children.length || racingIds.has(String(sport?.etid))) return sport;
      return { ...sport, children: sortLeaguesByMinGmid(children) };
    });

    const payload = { sports: ordered };
    redis.set(CACHE_KEY, JSON.stringify(payload), 'EX', CACHE_TTL).catch(() => { });
    return payload;
  },
};

export default SportsEventsService;
