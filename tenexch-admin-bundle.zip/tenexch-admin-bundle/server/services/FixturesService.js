import axios from 'axios';

// Upcoming fixtures scraped from the reference site by the Python collector in
// auto-update/tenexch (pm2: tenexch-fixtures-collector every 4 h, served by
// tenexch-fixtures-api on localhost). Read-only display data for the admin
// header ticker and the owner Fixtures page.
// FIXTURES_API_URL is read per call: server.js runs dotenv.config() after the
// ESM imports are evaluated, so a module-level read would see undefined.
const TIMEOUT_MS = 5000;

const EMPTY_META = { ok: false, stale: true, fetched_at: null, age_seconds: null, max_age_seconds: null };

const FixturesService = {
    // Never throws: a dead collector must not break the header, so failures come
    // back as { ok:false, data:[] } with the reason.
    async getFixtures() {
        const BASE_URL = process.env.FIXTURES_API_URL;
        if (!BASE_URL) {
            return { ok: false, data: [], meta: EMPTY_META, error: 'FIXTURES_API_URL not set' };
        }
        try {
            const [health, fixtures] = await Promise.all([
                axios.get(`${BASE_URL}/health`, { timeout: TIMEOUT_MS }),
                axios.get(`${BASE_URL}/fixturedata2`, { timeout: TIMEOUT_MS }),
            ]);
            const h = health.data || {};
            const rows = Array.isArray(fixtures.data?.data) ? fixtures.data.data : [];
            return {
                ok: true,
                data: rows.map((r) => ({
                    sportid: Number(r.sportid),
                    eid: r.eid,
                    ename: r.ename,
                    dt: r.dt, // "MM/DD/YYYY hh:mm:ss AM" as sent upstream, no timezone
                })),
                meta: {
                    ok: Boolean(h.ok),
                    stale: Boolean(h.stale),
                    fetched_at: h.fetched_at ?? null,
                    age_seconds: h.age_seconds ?? null,
                    max_age_seconds: h.max_age_seconds ?? null,
                },
            };
        } catch (error) {
            return { ok: false, data: [], meta: EMPTY_META, error: error.message };
        }
    },
};

export default FixturesService;
