// Secure channel: every API response and socket message the browser receives is
// AES-256-GCM encrypted (HTTP bodies deflated first), so the Network tab shows
// binary instead of JSON. Plan: docs/plans/2026-10-14-api-response-encryption.md
//
// API_ENCRYPTION=on turns it on (server/.env); anything else = off and every
// function here is a pass-through.
//
// Keys
//   session key   — per browser tab. ECDH P-256 key exchange at
//                   POST /api/cs/handshake, then HKDF-SHA256(secret, salt=sid,
//                   info='tenexch-cs-v1'). Never sent over the network. Kept in
//                   Redis `cs:s:<sid>` (12 h) so every server can use it.
//   broadcast key — one shared AES key for socket pushes (a room push is
//                   encrypted ONCE, not once per socket). Rotates every 10 min,
//                   kept in Redis `cs:bk` (current + previous). Each socket gets
//                   the keys wrapped in its own session key ('cs:bk' event).
//
// Frames (binary)
//   session   : [1][flags][iv 12][ciphertext][tag 16]
//   broadcast : [2][flags][keyId uint32 BE][iv 12][ciphertext][tag 16]
//   flags bit0 = body is deflate-raw compressed. The header is the GCM AAD.
import crypto from 'crypto';
import zlib from 'zlib';
import redis from '../config/redisClient.js';

export const ENABLED = process.env.API_ENCRYPTION === 'on';

const INFO = Buffer.from('tenexch-cs-v1');
const SESSION_TTL_S = 12 * 60 * 60; // same as the JWT
const ROTATE_MS = 10 * 60 * 1000;
const RELOAD_MS = 30 * 1000;
const CACHE_MS = 5 * 60 * 1000;
const CACHE_MAX = 50000;

const sessionCache = new Map(); // sid -> { key, z, until }

const badRequest = (message) => Object.assign(new Error(message), { status: 400 });

// ── Session keys ──────────────────────────────────────────────────────────────

export const handshake = async ({ pub, inflate } = {}) => {
  if (!ENABLED) return { enabled: false };
  const clientPub = Buffer.from(String(pub || ''), 'base64');
  if (clientPub.length !== 65 || clientPub[0] !== 4) throw badRequest('invalid public key');

  const ecdh = crypto.createECDH('prime256v1');
  ecdh.generateKeys();
  let secret;
  try {
    secret = ecdh.computeSecret(clientPub);
  } catch {
    throw badRequest('invalid public key');
  }
  const sid = crypto.randomBytes(16).toString('hex');
  const key = Buffer.from(crypto.hkdfSync('sha256', secret, Buffer.from(sid), INFO, 32));
  const z = inflate === true ? 1 : 0; // the browser can inflate deflate-raw

  await redis.set(`cs:s:${sid}`, JSON.stringify({ k: key.toString('base64'), z }), 'EX', SESSION_TTL_S);
  remember(sid, { key, z });
  return { enabled: true, sid, pub: ecdh.getPublicKey().toString('base64') };
};

const remember = (sid, session) => {
  if (sessionCache.size >= CACHE_MAX) sessionCache.clear();
  sessionCache.set(sid, { ...session, until: Date.now() + CACHE_MS });
};

// null when the sid is unknown or expired. Throws when Redis fails.
export const getSession = async (sid) => {
  if (typeof sid !== 'string' || !/^[0-9a-f]{32}$/.test(sid)) return null;
  const hit = sessionCache.get(sid);
  if (hit && hit.until > Date.now()) return hit;
  const raw = await redis.get(`cs:s:${sid}`);
  if (!raw) return null;
  const { k, z } = JSON.parse(raw);
  const session = { key: Buffer.from(k, 'base64'), z };
  remember(sid, session);
  return session;
};

// ── Sealing ───────────────────────────────────────────────────────────────────

const seal = (key, header, body) => {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  cipher.setAAD(header);
  const ct = Buffer.concat([cipher.update(body), cipher.final()]);
  return Buffer.concat([header, iv, ct, cipher.getAuthTag()]);
};

const jsonBytes = (obj) => Buffer.from(JSON.stringify(obj) ?? 'null');

// HTTP body for one session.
export const sealForSession = (session, obj) => {
  const json = jsonBytes(obj);
  const body = session.z ? zlib.deflateRawSync(json, { level: 1 }) : json;
  return seal(session.key, Buffer.from([1, session.z ? 1 : 0]), body);
};

// ── Broadcast keys (socket pushes) ────────────────────────────────────────────

let bk = null; // { cur: { id, key }, prev: { id, key } | null }
const rotationListeners = new Set();

const fromStored = (k) => (k ? { id: k.id, key: Buffer.from(k.k, 'base64'), t: k.t } : null);
const newKey = () => ({ id: crypto.randomInt(1, 2 ** 31), k: crypto.randomBytes(32).toString('base64'), t: Date.now() });

const applyKeys = (stored) => {
  const changed = !bk || bk.cur.id !== stored.cur.id;
  bk = { cur: fromStored(stored.cur), prev: fromStored(stored.prev) };
  if (changed) rotationListeners.forEach((fn) => { try { fn(); } catch (e) { console.error('[secureChannel] rotation listener:', e.message); } });
};

// Loads the shared keys and rotates them when due. One server wins the
// rotation (SET NX lock); the others pick the new key up on their next reload.
export const refreshBroadcastKeys = async () => {
  if (!ENABLED) return;
  try {
    let stored = JSON.parse((await redis.get('cs:bk')) || 'null');
    if (!stored || Date.now() - stored.cur.t > ROTATE_MS) {
      if (await redis.set('cs:bk:lock', '1', 'EX', 20, 'NX')) {
        stored = { cur: newKey(), prev: stored?.cur || null };
        await redis.set('cs:bk', JSON.stringify(stored));
      }
    }
    if (stored) applyKeys(stored);
  } catch (err) {
    console.error('[secureChannel] broadcast key reload failed:', err.message);
  }
  // Redis never reachable since boot: use a local key so pushes still go out
  // encrypted; it is replaced (and re-sent to sockets) once Redis answers.
  if (!bk) applyKeys({ cur: newKey(), prev: null });
};

// Socket payload. Synchronous (emit sites are synchronous); the key is in memory.
export const sealBroadcast = (obj) => {
  if (!ENABLED || !bk) return obj;
  const header = Buffer.alloc(6);
  header[0] = 2;
  header[1] = 0;
  header.writeUInt32BE(bk.cur.id, 2);
  return seal(bk.cur.key, header, jsonBytes(obj));
};

// The 'cs:bk' payload for one socket: current + previous broadcast keys,
// sealed with that socket's session key.
export const broadcastKeysFor = (session) => sealForSession(session, {
  keys: [bk?.cur, bk?.prev].filter(Boolean).map((k) => ({ id: k.id, k: k.key.toString('base64') })),
});

export const onBroadcastKeyRotation = (fn) => rotationListeners.add(fn);

// Wires the socket server: rejects unknown sessions, hands every socket the
// broadcast keys on connect and again after each rotation.
export const attachSocketCrypto = (io) => {
  if (!ENABLED) return;
  io.use(async (socket, next) => {
    try {
      const session = await getSession(socket.handshake.auth?.sid);
      if (!session) return next(new Error('CS_REHANDSHAKE'));
      socket.data.cs = session;
      return next();
    } catch (err) {
      console.error('[secureChannel] socket session lookup failed:', err.message);
      return next(new Error('CS_REHANDSHAKE'));
    }
  });
  io.on('connection', (socket) => {
    if (socket.data.cs) socket.emit('cs:bk', broadcastKeysFor(socket.data.cs));
  });
  onBroadcastKeyRotation(() => {
    for (const socket of io.sockets.sockets.values()) {
      if (socket.data.cs) socket.emit('cs:bk', broadcastKeysFor(socket.data.cs));
    }
  });
  // Never push plaintext while the shared key loads: start on a local key; the
  // shared one replaces it (and is re-sent to every socket) a moment later.
  if (!bk) applyKeys({ cur: newKey(), prev: null });
  refreshBroadcastKeys();
  setInterval(refreshBroadcastKeys, RELOAD_MS).unref();
};
