import axios from "axios";
import dotenv from "dotenv";
dotenv.config();
import { Op } from "sequelize";
import redis from "../config/redisClient.js"; // Import Redis Client
import { recordMarkets, recordMiss } from "../helper/marketListStore.js";

import SportsBet from '../model/user/SportsBet.js';
// import sequelize from '../config/db.js';

import FanWin from "../model/user/FanWin.js";
import MarketWin from "../model/user/MarketWin.js";

const BASE_URL = process.env.DIAMOND_BASE_URL;
const API_KEY = process.env.DIAMOND_API_KEY;
const SPORTS_API_VERSION = process.env.SPORTS_API_VERSION || 'v2';
const AVRKHUB_SPORTS_BASE_URL = process.env.AVRKHUB_SPORTS_BASE_URL;
const AVRKHUB_SPORTS_KEY = process.env.AVRKHUB_SPORTS_KEY;
const CACHE_TTL = 2; // Cache time in seconds

console.log("DEBUG: BASE_URL =", BASE_URL);
console.log("DEBUG: API_KEY =", API_KEY ? "Loaded" : "Missing");

// Helper for caching
const getCachedData = async (key, fetchFunction) => {
  let cachedData = null;

  // 1. Try to get from Cache
  try {
    const cached = await redis.get(key);
    if (cached) {
      console.log(`⚡ Serving from cache: ${key}`);
      return JSON.parse(cached);
    }
  } catch (err) {
    console.error(`❌ Redis Cache Error for ${key}:`, err.message);
    // Continue to fetch from API
  }

  // 2. Fetch from API
  try {
    console.log(`[Trace] Cache miss for ${key}, fetching...`);
    const data = await fetchFunction();

    // 3. Set Cache (Async, don't block)
    redis.set(key, JSON.stringify(data), 'EX', CACHE_TTL).catch(err =>
      console.error(`❌ Failed to set cache for ${key}:`, err.message)
    );

    console.log(`🌐 Fetched from API & Cached: ${key}`);
    return data;
  } catch (err) {
    console.error(`❌ API Error for ${key}:`, err.message);
    // If API fails, we return null or rethrow. 
    // For now, let's return null to avoid crashing the whole request if one sub-request fails,
    // assuming the controller handles nulls gracefully.
    // Or simpler: just throw/return error object so controller knows.
    throw err;
  }
};

// Probe a scorecard URL: resolves true only if the host actually answers.
// Results are memoized in-process for 5 minutes (the redis data cache is only
// 2s, which would re-pay the probe timeout on nearly every poll).
const PROBE_TTL_MS = 5 * 60 * 1000;
const scoreProbeCache = new Map(); // url -> { ok, at }
const probeScoreUrl = async (url) => {
  const hit = scoreProbeCache.get(url);
  if (hit && Date.now() - hit.at < PROBE_TTL_MS) return hit.ok;
  let ok = false;
  try {
    const res = await axios.get(url, {
      timeout: 4000,
      maxRedirects: 3,
      headers: {
        Accept: 'text/html,application/xhtml+xml;q=0.9,*/*;q=0.8',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
      },
      validateStatus: (s) => s >= 200 && s < 400,
    });
    ok = !!res;
  } catch {
    ok = false;
  }
  scoreProbeCache.set(url, { ok, at: Date.now() });
  return ok;
};

/* One upstream gamedataPrivate read per match, shared by every caller.
   The match page polls every 300 ms per viewer and each poll used to be its
   own AVRKHUB call, so upstream load grew with the audience (N viewers ≈ 3·N
   calls/s). Now concurrent callers share the in-flight request and a good
   answer is reused for PRIVATE_DATA_TTL_MS — upstream stays ~3 calls/s per
   match whatever the audience. Errors are shared while in flight, never
   cached. Every caller gets its own copy (callers may mutate the list).
   Plan: docs/plans/2026-10-12-performance-and-money-safety.md (Phase 2.1). */
const PRIVATE_DATA_TTL_MS = Number(process.env.PRIVATE_DATA_TTL_MS) || 250;
const privateDataCache = new Map();    // key → { at, value }
const privateDataInFlight = new Map(); // key → Promise<value>

async function fetchPrivateDataV2(gmid, sid) {
  const response = await axios.get(`${AVRKHUB_SPORTS_BASE_URL}/gamedataPrivate`, {
    params: { gmid, etid: sid, key: AVRKHUB_SPORTS_KEY },
    timeout: 8000
  });
  let innerData = response.data?.data || [];
  // Unwrap if AVRKHUB double-wraps in { data: [...] }
  if (innerData && !Array.isArray(innerData) && Array.isArray(innerData.data)) {
    innerData = innerData.data;
  }
  // Also cache in old key so odds cron stays warm
  if (Array.isArray(innerData) && innerData.length > 0) {
    redis.setex(`odds:${gmid}`, 3, JSON.stringify(innerData)).catch(() => { });
    // admin "More Market" keeps every market the match has shown
    recordMarkets(gmid, innerData).catch(() => { });
  } else if (response.data?.success === false
    && /\b404\b/.test(`${response.data?.status ?? ''} ${response.data?.msg ?? ''} ${response.data?.error ?? ''}`)) {
    recordMiss(gmid).catch(() => { });
  }
  return { success: true, data: innerData };
}

async function sharedPrivateDataV2(gmid, sid) {
  const key = `${gmid}:${sid}`;
  const hit = privateDataCache.get(key);
  if (hit && Date.now() - hit.at < PRIVATE_DATA_TTL_MS) return structuredClone(hit.value);

  let pending = privateDataInFlight.get(key);
  if (!pending) {
    pending = fetchPrivateDataV2(gmid, sid)
      .then((value) => {
        privateDataCache.set(key, { at: Date.now(), value });
        return value;
      })
      .finally(() => privateDataInFlight.delete(key));
    privateDataInFlight.set(key, pending);
  }
  return structuredClone(await pending);
}

// Drop answers nobody asked for again (matches that ended / left the page).
setInterval(() => {
  const cutoff = Date.now() - 60 * 1000;
  for (const [key, entry] of privateDataCache) if (entry.at < cutoff) privateDataCache.delete(key);
}, 60 * 1000).unref();

const CricketService = {
  // fetchCricketData: async (id) => {
  //   // console.log("======>>>>fetch cricket all data for id : "+id+ "===="+ API_KEY+ "===="+BASE_URL);
  //   if (!id) {
  //     throw new Error("ID is required to fetch cricket data");
  //   }

  //   const key = `cricket_data_${id}`;
  //   return await getCachedData(key, async () => {
  //     const response = await axios.get(`${BASE_URL}/esid`, {
  //       headers: { Accept: "*/*" },
  //       params: { sid: id, key: API_KEY },
  //       timeout: 6000 // 3s timeout
  //     });
  //     return response.data;
  //   });
  // },


  fetchCricketData: async (id) => {
    try {
      const sid = id;

      if (!sid) {
        throw new Error("sid is required to fetch cricket data");
      }

      if (SPORTS_API_VERSION === 'v2') {
        const response = await axios.get(`${AVRKHUB_SPORTS_BASE_URL}/highlighthomePrivate`, {
          params: { etid: id, key: AVRKHUB_SPORTS_KEY },
          timeout: 8000,
          validateStatus: (s) => (s >= 200 && s < 300) || s === 404
        });

        // 404 from upstream = no fixtures for this sport right now, not a server error
        if (response.status === 404) {
          const empty = { success: true, data: { t1: [], t2: [] } };
          redis.set(`alleventss:${id}`, JSON.stringify(empty.data), 'EX', 60).catch(() => { });
          return empty;
        }

        const rawData = response.data?.data?.data || response.data?.data || {};
        const t1 = Array.isArray(rawData.t1) ? rawData.t1 : [];
        const t2 = Array.isArray(rawData.t2) ? rawData.t2 : [];

        // Match the legacy format expected by the frontend
        const finalData = {
          success: true,
          data: {
            t1: t1.map(e => ({ ...e, etid: parseInt(id) })),
            t2: t2.map(e => ({ ...e, etid: parseInt(id) }))
          }
        };

        // Cache in redis key so other parts of the system (like odds cron) can see it
        redis.set(`alleventss:${id}`, JSON.stringify(finalData.data), 'EX', 120).catch(() => { });

        return finalData;
      }

      // console.log("======>>>>sid: " + sid)

      const dataStr = await redis.get(`allevents:${sid}`);
      // console.log("======>>>>dataStr: " + dataStr)

      if (!dataStr) {
        return {
          success: true,
          data: { t1: [], t2: [] }
        };
      }

      let parsedData;
      try {
        parsedData = JSON.parse(dataStr);
      } catch (e) {
        console.error("Error parsing redis data", e);
        return {
          success: true,
          data: { t1: [], t2: [] }
        };
      }

      // ✅ Redis already stores { t1, t2 }
      if (
        parsedData &&
        typeof parsedData === "object" &&
        !Array.isArray(parsedData) &&
        Array.isArray(parsedData.t1)
      ) {
        return {
          success: true,
          data: {
            t1: parsedData.t1 || [],
            t2: parsedData.t2 || []
          }
        };
      }

      // ✅ OLD redis structure (flat array → split now)
      if (Array.isArray(parsedData)) {

        const t1 = parsedData.filter(
          (e) => e?.status === "OPEN" && e?.gscode === 1
        );

        const t2 = parsedData.filter(
          (e) => e?.status === "SUSPENDED" || e?.gscode === 0
        );

        return {
          success: true,
          data: { t1, t2 }
        };
      }

      // fallback
      return {
        success: true,
        data: { t1: [], t2: [] }
      };

    } catch (err) {
      console.error(err);
      throw err;
    }
  },

  GetallSportsdata: async () => {
    const key = `all_sports_data`;
    return await getCachedData(key, async () => {
      const response = await axios.get(`${BASE_URL}/allSportid`, {
        headers: { Accept: "*/*" },
        params: { key: API_KEY },
        timeout: 6000
      });
      return response?.data?.data;
    });
  },


  // GetMatchPrivateData: async (gmid, sid) => {

  //   // console.log("======>>>>fetch match private data for id : "+ sid+", gmid : "+gmid);
  //   if (!gmid || !sid) {
  //     throw new Error("Game ID is required to fetch match private data");
  //   }

  //   // Cache key combination of gmid and sid
  //   const key = `match_private_${gmid}_${sid}`;
  //   return await getCachedData(key, async () => {
  //     const response = await axios.get(`${BASE_URL}/gamedataPrivate`, {
  //       headers: { Accept: "*/*" },
  //       params: { gmid: gmid, etid: sid },
  //       timeout: 6000
  //     });

  //     // console.log("======>>>>Response  match private data for id : "+ sid+", gmid : "+gmid+"==response=="+ response.data);
  //     return response.data?.data;
  //   });
  // },

  GetMatchPrivateData: async (gmid, sid) => {

    if (!gmid || !sid) {
      throw new Error("gmid and sid are required to fetch match private data");
    }

    if (process.env.COUNT_CALLS === "true" && typeof isSampling !== "undefined" && isSampling) {
      requestCounter++;
    }

    // console.log("GetMatchPrivateData(gmid, sid)", gmid, sid);

    try {
      if (SPORTS_API_VERSION === 'v2') {
        return await sharedPrivateDataV2(gmid, sid);
      }

      // IMPORTANT: odds cron stores by gmid only
      const redisKey = `odds:${gmid}`;



      const cached = await redis.get(redisKey);

      if (!cached) {
        return { success: true, data: [] };   // keep same behaviour as API (usually array)
      }

      const parsedData = JSON.parse(cached);
      return { success: true, data: parsedData };

    } catch (error) {
      if (error?.response?.status === 404) recordMiss(gmid).catch(() => { });
      console.error(
        "GetMatchPrivateData(redis) error:",
        error.message
      );
      throw error;
    }
  },


  getSportDataById: async (gmid, sid) => {
    if (!sid || !gmid) {
      throw new Error("Sport ID is required to fetch data");
    }

    const key = `sport_data_${gmid}_${sid}`;
    return await getCachedData(key, async () => {
      // v2: the dedicated upstream detail endpoint (/getDetailsData) 404s for a
      // large share of gmids (tennis/football/virtuals) — and it was being called
      // with the wrong credentials/params anyway (DIAMOND API_KEY + `sid` instead
      // of AVRKHUB_SPORTS_KEY + `etid`). Derive the single match header from the
      // same highlighthomePrivate list that powers all-data — proven to contain
      // the gmid, and exactly what the frontend already falls back to on a 404.
      // Shape mirrors the old upstream body ({ data: [match] }) so both consumers
      // (getSportdetailsById -> data[0] via frontend, and the scorecard gtv
      // fallback -> matchRes.data[0]) keep working unchanged.
      if (SPORTS_API_VERSION === 'v2') {
        const list = await CricketService.fetchCricketData(sid);
        const t1 = Array.isArray(list?.data?.t1) ? list.data.t1 : [];
        const t2 = Array.isArray(list?.data?.t2) ? list.data.t2 : [];
        const match = [...t2, ...t1].find((m) => String(m.gmid) === String(gmid));
        return { data: match ? [match] : [] };
      }

      const response = await axios.get(`${AVRKHUB_SPORTS_BASE_URL}/getDetailsData`, {
        headers: { Accept: "*/*" },
        params: { sid: sid, gmid: gmid, key: API_KEY },
        timeout: 8000
      });
      // console.log("======>>>>Response  match private data for id : "+ sid+", gmid : "+gmid+"==response=="+ response.data);
      return response.data;
    });
  },


  fetchLiveStream: async (gmid) => {
    if (!gmid) {
      throw new Error("Game ID is required to fetch live stream data");
    }
    const key = `live_stream_${gmid}`;
    // Cache live stream URL slightly longer if needed, but 2s is safe
    return await getCachedData(key, async () => {
      const response = await axios.get(`${BASE_URL}/tv_url`, {
        headers: { Accept: "*/*" },
        params: { gmid: gmid, key: API_KEY },
        timeout: 6000
      });
      return response.data;
    });
  },

  fetchScoreCard: async (gmid, sid) => {
    if (!gmid) {
      throw new Error("gmid is required to fetch scorecard");
    }
    if (!sid) {
      throw new Error("sid is required to fetch scorecard");
    }

    // v2: Use AVRKHUB scorecard endpoint - works for ALL sports (no gtv needed)
    if (SPORTS_API_VERSION === 'v2') {
      const key = `scorecard_v2_${gmid}_${sid}`;
      return await getCachedData(key, async () => {
        const response = await axios.get(`${AVRKHUB_SPORTS_BASE_URL}/scorecard`, {
          params: { gmid, etid: sid, key: AVRKHUB_SPORTS_KEY },
          timeout: 8000
        });
        // Response: { etid, gmid, scorecard_url }
        // Normalize to score_url for frontend compatibility
        const data = response.data;
        if (data?.scorecard_url) {
          // The scorecard host returns a URL for EVERY match but silently
          // HANGS (accepts the connection, never responds) for matches it
          // doesn't cover — currently all tennis/football. Probe the URL and
          // only hand it to the frontend if the host actually answers,
          // otherwise the page renders an empty banner box.
          const covered = await probeScoreUrl(data.scorecard_url);
          return { score_url: covered ? data.scorecard_url : null };
        }
        return data;
      });
    }

    // v1 fallback: Diamond /score endpoint (requires gtv)
    const key = `scorecard_${gmid}_${sid}`;
    return await getCachedData(key, async () => {
      const response = await axios.get(`${BASE_URL}/score`, {
        headers: { Accept: "*/*" },
        params: { gtv: gmid, key: API_KEY, sid: sid, sportid: sid },
        timeout: 6000
      });
      return response.data;
    });
  },

  fetchTreeData: async () => {
    if (SPORTS_API_VERSION === 'v2') {
      const key = `tree_data_v2`;
      return await getCachedData(key, async () => {
        const response = await axios.get(`${AVRKHUB_SPORTS_BASE_URL}/treedata`, {
          params: { key: AVRKHUB_SPORTS_KEY },
          timeout: 8000
        });
        return response.data;
      });
    }

    const key = `tree_data`;
    // Tree data changes less frequently, can potentially cache longer, but sticking to 2-5s for consistency
    return await getCachedData(key, async () => {
      const response = await axios.get(`${BASE_URL}/tree`, {
        headers: { Accept: "*/*" },
        params: { key: API_KEY },
        timeout: 6000
      });
      return response.data;
    });
  },







  GetResult: async (
    sid,
    event_id,
    event_name,
    market_id,
    market_name,

  ) => {
    if (!sid) {
      throw new Error("sid is required");
    } else if (
      !event_id ||
      !event_name ||
      !market_id ||
      !market_name

    ) {
      throw new Error(
        "Event ID, Event Name, Market ID, Market Name and Market Type are required"
      );
    }
    const payload = {
      event_id,
      event_name,
      market_id,
      market_name,

    };

    try {
      const response = await axios.post(
        `${BASE_URL}/get-result`, // no such endpoint is available in api , neeed to modify this one 
        payload,

        {
          headers: {
            Accept: "*/*",
            "Content-Type": "application/json",
          },
          params: {
            sid,
            key: API_KEY,
          },
        }
      );

      return response.data;
    } catch (error) {
      if (axios.isAxiosError(error)) {
        console.error("❌ Axios error :", {
          message: error.message,
          status: error.response?.status,
          data: error.response?.data,
        });
        throw new Error(
          error.response?.data?.message ||
          `Request failed with status ${error.response?.status}`
        );
      } else {
        console.error("❌ Unknown error ", error);
        throw new Error("An unexpected error occurred.");
      }
    }
  },


  getAllSportsBets: async () => {
    // Fetch all sports bets
    const bets = await SportsBet.findAll();
    return bets;
  },


  /**
   * A user's own sports bets, filtered by settlement state.
   *
   * `status` mirrors the Current Bets radios:
   *   'matchbet'   -> still open and matched   (the page default)
   *   'unmatchbet' -> still open but unmatched
   *   'deletebet'  -> admin soft-cancelled
   *   'all'        -> no settlement filter (admin bet-history callers)
   *
   * Open-ness keys off result_status, NOT status: settlement stamps
   * status='closed' + a terminal result_status, and a bet can carry the
   * terminal result before `status` catches up (see systemTracker/verifier.js).
   * Admin deletion soft-cancels both columns to 'cancelled' and never removes
   * the row, so 'cancelled' has to be excluded from the open set explicitly.
   */
  getSportsBetsByUserId: async (user_id, { page = 1, limit = 10, search = '', betType = 'all', status = 'matchbet' } = {}) => {
    const offset = (page - 1) * limit;
    const where = { user_id };
    const and = [];

    // Back/Lay are SIDE filters, not literal bet_type values: fancy markets
    // store the same two sides as 'yes'/'no' (yes = back, no = lay), so 'back'
    // must pull in the 'yes' rows and 'lay' the 'no' rows -- the same mapping
    // the row-colour helper on the Current Bets page already uses. Some rows
    // are stored with mixed casing ('Lay', 'Back'), hence iLike instead of =.
    if (betType !== 'all') {
      const side = String(betType).toLowerCase();
      const aliases = side === 'back' ? ['back', 'yes']
        : side === 'lay' ? ['lay', 'no']
        : null;
      if (aliases) {
        and.push({ [Op.or]: aliases.map((v) => ({ bet_type: { [Op.iLike]: v } })) });
      } else {
        where.bet_type = betType;
      }
    }

    if (status === 'deletebet') {
      and.push({
        [Op.or]: [
          { status: { [Op.iLike]: 'cancelled' } },
          { result_status: { [Op.iLike]: 'cancelled' } }
        ]
      });
    } else if (status !== 'all') {
      // Unsettled: result_status is still pending (or was never stamped).
      and.push({
        [Op.or]: [
          { result_status: null },
          { result_status: { [Op.iLike]: 'pending' } }
        ]
      });
      // Belt-and-braces against a row stamped closed before its result landed.
      // NULL-safe so a bet with no status set is not silently dropped.
      and.push({
        [Op.or]: [
          { status: null },
          { status: { [Op.notILike]: 'closed' } }
        ]
      });
      and.push({ unmatched: status === 'unmatchbet' });
    }

    if (search) {
      // iLike, not like: Postgres LIKE is case-sensitive. market_type, not
      // market_name: there is no market_name column, so the old clause threw.
      and.push({
        [Op.or]: [
          { match_title: { [Op.iLike]: `%${search}%` } },
          { selection_name: { [Op.iLike]: `%${search}%` } },
          { market_type: { [Op.iLike]: `%${search}%` } }
        ]
      });
    }

    if (and.length) {
      where[Op.and] = and;
    }

    // ASC = purani bet pehle, reference site jaisa (sabse pehle lagayi gayi bet
    // sabse upar). Pehle DESC tha to list ulti aati thi.
    const { count, rows } = await SportsBet.findAndCountAll({
      where,
      limit: parseInt(limit),
      offset: parseInt(offset),
      order: [['id', 'ASC']]
    });

    // "Total Amount" header POORE filtered set ka jod dikhata hai, sirf is page
    // ka nahi. Frontend ke paas sirf current page ki rows hoti hain, isliye ye
    // yahin (same `where` par) nikal ke bheja jaata hai — warna 29 bets par bhi
    // 25 ka hi total dikhta tha.
    const totalStake = await SportsBet.sum('stake_amount', { where });

    return {
      rows,
      pagination: {
        total: count,
        page: parseInt(page),
        limit: parseInt(limit),
        total_pages: Math.ceil(count / limit),
        total_stake: Number(totalStake || 0)
      }
    };
  },

  getWinsByUserId: async (user_id) => {
    // Fetch all winning bets for a specific user
    const fanWins = await FanWin.findAll({ where: { user_id } });
    const marketWins = await MarketWin.findAll({ where: { user_id, } });
    const allWins = [{ marketWins }, { fanWins }];
    return allWins;
  }
};

export default CricketService;

