import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import Executive from "../../model/Executive.js";
import { MESSAGES } from "../../constants/messages.js";

export const ExecutiveAuthService = {
  login: async (username, password) => {
    const executive = await Executive.findOne({
      where: { username }
    });

    // Account exist na kare to staff/owner jaisa hi message — teeno admin
    // logins ka wording ek rakhne ke liye.
    if (!executive) {
      throw new Error(MESSAGES.ADMIN.AUTH.ACCOUNT_NOT_AVAILABLE);
    }

    if (!executive.active) {
      throw new Error(MESSAGES.ADMIN.AUTH.EXECUTIVE_DISABLED);
    }

    const isMatch = await bcrypt.compare(password, executive.password);
    if (!isMatch) {
      throw new Error(MESSAGES.ADMIN.AUTH.PASSWORD_INCORRECT);
    }

    const token = jwt.sign(
      {
        actor: {
          type: "EXECUTIVE",
          id: executive.id
        },
        account: {
          type: executive.parent_type,
          id: executive.parent_id
        },
        role: executive.role,
        permissions: executive.permissions
      },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRATION || "1d" }
    );

    // Return the token plus a safe executive object so the frontend can store
    // the permission map without a separate profile call. Never leak the hash.
    return {
      token,
      executive: {
        id: executive.id,
        username: executive.username,
        email: executive.email,
        full_name: executive.full_name,
        role: executive.role,
        parent_type: executive.parent_type,
        permissions: executive.permissions || {},
        active: executive.active
      }
    };
  }
};
