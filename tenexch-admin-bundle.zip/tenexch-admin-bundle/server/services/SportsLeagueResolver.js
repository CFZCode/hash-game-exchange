import redis from '../config/redisClient.js';

// ─────────────────────────────────────────────────────────────────────────────
// Which LEAGUE (feed `cname`) does a match belong to?
//
// Why this exists: the league only ever reached the server because the browser
// sent it, and the browser cannot always know it. The match DETAIL feed
// (`gamedataPrivate`) returns no `cname` at all — verified 2026-09-12, its keys
// are gmid / mname / section / … — so GameDetails reads cname from the list
// payload and loses it whenever matchData is refreshed from the detail call.
// Result: SportsBet.league_name lands NULL on roughly one bet in ten. Same
// match, same user, same minute:
//
//     2364  Caribbean Premier League   02:47:12
//     2365  (null)                     02:47:35
//     2373  Caribbean Premier League   02:49:40
//     2374  (null)                     02:49:46
//
// Display-only that was merely untidy. Now that commission is charged per
// league (constants/commissionLeagues.js), a NULL would quietly bill a T10 XI
// win at the real-cricket rate — so the server resolves it itself.
//
// Source: redis `alleventss:<etid>`, the highlight list CricketService already
// caches for 60 s on every board poll. A match's league never changes, so each
// gmid is then memoised on its own key for 12 h — long enough to outlive the
// match, which is what settlement needs.
//
// FAILS OPEN: any miss returns null and the caller keeps whatever it had.
// Never throws, never calls upstream, never blocks a bet.
// ─────────────────────────────────────────────────────────────────────────────

const EVENT_LIST_KEY = (etid) => `alleventss:${etid}`;
const LEAGUE_KEY = (gmid) => `league:evt:${gmid}`;
const LEAGUE_TTL_SEC = 12 * 60 * 60;
const MICRO_TTL_MS = 5000;

// gmid -> { value, expires }. Bets on one match arrive in bursts, so the same
// gmid is asked for many times a second.
const micro = new Map();
const MICRO_MAX = 500;

const microGet = (gmid) => {
    const hit = micro.get(gmid);
    if (!hit) return undefined;
    if (hit.expires < Date.now()) { micro.delete(gmid); return undefined; }
    return hit.value;
};
const microSet = (gmid, value) => {
    if (micro.size >= MICRO_MAX) micro.clear();
    micro.set(gmid, { value, expires: Date.now() + MICRO_TTL_MS });
};

const shape = (game) => ({
    cname: game?.cname ? String(game.cname) : null,
    cid: game?.cid != null ? Number(game.cid) : null,
    iscc: game?.iscc != null ? Number(game.iscc) : null,
});

/**
 * { cname, cid, iscc } for a match, or null when it cannot be resolved.
 * @param {number|string} sportId feed etid
 * @param {number|string} gmid    the match id (SportsBet.eventid)
 */
export const resolveLeague = async (sportId, gmid) => {
    const key = String(gmid || '').trim();
    if (!key || !sportId) return null;

    const local = microGet(key);
    if (local !== undefined) return local;

    try {
        const cached = await redis.get(LEAGUE_KEY(key));
        if (cached != null) {
            const parsed = JSON.parse(cached);
            microSet(key, parsed);
            return parsed;
        }
    } catch (err) {
        console.warn('[LeagueResolver] redis read failed:', err.message);
    }

    let found = null;
    try {
        const raw = await redis.get(EVENT_LIST_KEY(sportId));
        if (raw) {
            const data = JSON.parse(raw);
            const games = [...(data?.t1 || []), ...(data?.t2 || [])];
            const hit = games.find((g) => String(g?.gmid) === key);
            if (hit?.cname) found = shape(hit);
        }
    } catch (err) {
        console.warn('[LeagueResolver] event list read failed:', err.message);
    }

    // Only a POSITIVE result is memoised. Caching "not found" for 12 h would
    // pin a match to the default league just because its board poll had not
    // run yet when the first bet landed.
    if (found) {
        microSet(key, found);
        redis.set(LEAGUE_KEY(key), JSON.stringify(found), 'EX', LEAGUE_TTL_SEC)
            .catch((err) => console.warn('[LeagueResolver] redis write failed:', err.message));
    } else {
        microSet(key, null);
    }
    return found;
};

/** Just the league name, or null. */
export const resolveLeagueName = async (sportId, gmid) => {
    const hit = await resolveLeague(sportId, gmid);
    return hit?.cname || null;
};

/**
 * The league name to STORE on a bet: what the client sent, else what the feed
 * says. Returns null when neither knows.
 */
//
// FEED FIRST, client second. Commission and Max Odds are both configured per
// league, so a client-sent name ("T10 XI" on a real match) must never be able
// to pick a cheaper row. The client value only fills in when the cached event
// list has no record of the match. The resolver is memoised per gmid, so this
// is one redis GET per bet at most.
export const leagueNameForBet = async (sportId, gmid, clientLeagueName) => {
    const resolved = await resolveLeagueName(sportId, gmid);
    if (resolved) return String(resolved).slice(0, 255);
    const fromClient = String(clientLeagueName || '').trim();
    return fromClient ? fromClient.slice(0, 255) : null;
};

export default { resolveLeague, resolveLeagueName, leagueNameForBet };
