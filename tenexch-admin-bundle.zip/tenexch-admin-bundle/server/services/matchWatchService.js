import CricketService from './CricketService.js';
import { matchRoom } from '../utils/socketUtils.js';
import { sealBroadcast } from './secureChannelService.js';

// Server-side feed + liveness for open match/race detail pages.
//
// A detail page used to drive everything off its own HTTP poll of
// get-match-private-data. Two problems: (1) a backgrounded tab throttles the
// poll's timer to ~once a minute, so a player coming back after 30 min sat on
// a dead board until they refreshed; (2) N players on one gmid = N upstream
// calls at 300ms each.
//
// Now the server polls each watched gmid ONCE per interval for everyone in
// room match_<sid>_<gmid> and pushes:
//   `matchData` { gmid, sid, data }  — `data` is byte-for-byte the REST body
//                                      of POST /user/cricket/get-match-private-data
//                                      ({success:true,data:…} or
//                                       {success:false,error:"…404"}), pushed
//                                      only when it CHANGED
//   `matchGone` { gmid, sid, reason } — the failure body has persisted
//                                      GONE_AFTER_MS straight: the match ended
// Socket pushes are delivered by XHR callbacks, not timers, so they keep
// arriving in a background tab — that is the whole point.
//
// Only the main server runs this (it needs io); workers never import it.
// Each server watches for its OWN subscribers, so emits are io.local (the
// Redis adapter would otherwise deliver them on every server too).

// Cricket/e-sports pages poll at 300ms, racing at 2s — mirror that so the
// push is never slower than the poll it replaces.
const INTERVAL_MS = Number(process.env.MATCH_FEED_INTERVAL_MS) || 300;
const RACING_INTERVAL_MS = Number(process.env.MATCH_FEED_RACING_INTERVAL_MS) || 2000;
const RACING_SIDS = new Set(['10', '65']);
/* Continuous failure needed before `matchGone`. A single upstream blip in a
   live match must never bounce a room full of players.

   This was 3000 ms. At a 300 ms tick that is TEN consecutive failures — an
   upstream deploy, a restart or one bad minute at the provider clears that bar
   easily, and every player on the gmid was evicted from a match that was still
   being played. 60 s of UNBROKEN failure (any single alive answer resets the
   clock) is a bar only a genuinely dead gmid reaches. A real ending is noticed
   a minute later, which nobody can feel; a false one used to be instant. */
const GONE_AFTER_MS = Number(process.env.MATCH_GONE_AFTER_MS) || 60000;
// A finished gmid stays remembered this long after its room empties, so a
// straggler reconnecting minutes later is still told at once.
const GONE_RETAIN_MS = 10 * 60 * 1000;

const watchers = new Map(); // key -> watcher

const keyOf = (sid, gmid) => `${sid}:${gmid}`;
const intervalFor = (sid) => (RACING_SIDS.has(String(sid)) ? RACING_INTERVAL_MS : INTERVAL_MS);

// Classify one private-data result.
//   'alive'    — an array came back (even empty: v1 mode returns [] when the
//                odds cron hasn't warmed the key yet, which is NOT "gone")
//   'noRecord' — inner {status:300, msg:"No Record Found."} — the virtual
//                between-rounds body; the round rotates, the game isn't gone
//   'gone'     — upstream 404 / explicit success:false — the feed dropped it
//   'blip'     — unrecognised shape; neither confirms nor clears
export function classify(res) {
  let node = res;
  for (let i = 0; i < 5 && node && typeof node === 'object'; i++) {
    if (Array.isArray(node)) return 'alive';
    if (node.success === false) {
      const noRecord = node.status === 300 || /no record/i.test(String(node.msg || ''));
      if (noRecord) return 'noRecord';
      /* Only a body that NAMES a 404/410 is proof of death.
         This used to be `return 'gone'` for every success:false body that was
         not "No Record Found" — with no look at the status at all, while
         classifyError next door was careful about exactly this. A bad key, a
         rate limit, a maintenance notice or any upstream 5xx wrapped into a
         200 body therefore started the eviction clock on a live match. */
      const text = `${node.status ?? ''} ${node.error ?? ''} ${node.msg ?? ''}`;
      return /\b(404|410)\b/.test(text) ? 'gone' : 'blip';
    }
    node = node.data;
  }
  return Array.isArray(node) ? 'alive' : 'blip';
}

/* Only a 404/410 is proof of death.

   This used to be `err?.response?.status ? 'gone' : 'blip'` — ANY HTTP status.
   A 500, 502, 503, 504 or 429 from the provider means "upstream is unwell right
   now"; it says NOTHING about whether this match exists. Ten of those in a row
   (three seconds) evicted a whole room from a live match. Only 404/410 mean
   "upstream knows its catalogue and this gmid is not in it".

   No response at all (timeout, DNS, connection refused) was already a blip and
   stays one. */
const GONE_STATUSES = new Set([404, 410]);

export function classifyError(err) {
  const status = err?.response?.status;
  if (!status) return 'blip';                      // timeout / DNS / upstream down
  return GONE_STATUSES.has(status) ? 'gone' : 'blip';
}

/* Second opinion before evicting anyone.

   private-data is ONE source. Asking it alone is how a provider-side glitch
   turned into "your match is over". The match list (highlighthomePrivate, the
   same feed that builds the home page and all-data) is an independent source
   for the same question, so a gmid is only declared dead when BOTH agree.

   Any doubt resolves to alive: a throw, a timeout, a cached list — all return
   false ("could not confirm"), and the watcher keeps the board up. Refusing to
   evict is always the recoverable mistake; evicting a live match is not.

   Cheap by construction — only reachable after GONE_AFTER_MS of unbroken
   failure, and a veto resets that clock, so this runs at most once a minute
   per gmid. */
export async function confirmGone(gmid, sid) {
  /* Racing is not confirmable this way, so it is never confirmed.
     getSportDataById searches the match list FLAT ([...t2, ...t1]), but racing
     all-data is nested COUNTRY > VENUE > RACE — a racing gmid is never in that
     flat array. The search therefore found nothing for EVERY racing gmid and
     answered "yes, confirmed gone", turning the second opinion into a rubber
     stamp on the one page where eviction hurts most: a race resolves in ninety
     seconds with the player's money on the board.
     Until there is a racing-shaped lookup, sid 10/65 get no confirmation, which
     under this function's contract means no eviction. */
  if (RACING_SIDS.has(String(sid))) return false;
  try {
    /* Read the SPORT'S WHOLE LIST, not getSportDataById.
       getSportDataById answers about one gmid — {data:[match]} when found,
       {data:[]} when not — so "empty" there IS the not-found answer and there is
       no way to tell it from "we have no data at all". Asking for the full list
       separates the two, and that distinction is the entire point:

         list empty      → the provider is not answering. Says nothing about
                           this match. Measured 2026-09-13 19:05: every sport
                           returned zero rows during an outage while matches
                           were being played, and the per-gmid feed 404'd for
                           live cricket and live tennis alike.
         list non-empty  → the provider is up and its catalogue is intact, so a
                           gmid missing from it is missing because it retired.

       fetchCricketData also turns an upstream 404 for a WHOLE SPORT into
       {success:true, t1:[], t2:[]}, and the v1 path returns empty whenever the
       odds cron has not warmed its Redis key — both land in the first case and
       confirm nothing, which is the safe direction. */
    const res = await CricketService.fetchCricketData(sid);
    const t1 = Array.isArray(res?.data?.t1) ? res.data.t1 : [];
    const t2 = Array.isArray(res?.data?.t2) ? res.data.t2 : [];
    const rows = [...t2, ...t1];
    if (rows.length === 0) return false;
    return !rows.some((m) => String(m?.gmid) === String(gmid));
  } catch {
    return false; // could not check → not confirmed → do not evict
  }
}

function gonePayload(w) {
  return { gmid: w.gmid, sid: w.sid, reason: 'feed_404', timestamp: new Date().toISOString() };
}

function stop(w) {
  clearInterval(w.timer);
  watchers.delete(keyOf(w.sid, w.gmid));
}

async function tick(io, w) {
  if (w.inFlight) return; // upstream slower than the interval — skip, don't stack
  w.inFlight = true;
  try {
    const room = io.sockets.adapter.rooms.get(w.room);
    if (!room || room.size === 0) {
      // Nobody watching. Keep a finished gmid around briefly for stragglers,
      // drop a live one at once — its next viewer restarts the watch.
      w.emptySince ||= Date.now();
      if (!w.gone || Date.now() - w.emptySince > GONE_RETAIN_MS) stop(w);
      return;
    }
    w.emptySince = null;
    if (w.gone) return; // already pushed; late subscribers are handled in subscribe()

    // Same envelope the REST controller sends, so the client feeds it through
    // the exact code path it already has for the HTTP response.
    let body;
    let verdict;
    try {
      const res = await CricketService.GetMatchPrivateData(w.gmid, w.sid);
      body = { success: true, data: res };
      verdict = classify(res);
    } catch (err) {
      body = { success: false, error: err.message };
      verdict = classifyError(err);
    }

    // Push only on change — a static board (or a repeated 404) costs nothing.
    const json = JSON.stringify(body);
    if (json !== w.lastJson) {
      w.lastJson = json;
      io.local.to(w.room).emit('matchData', sealBroadcast({ gmid: w.gmid, sid: w.sid, data: body }));
    }

    if (verdict === 'alive' || verdict === 'noRecord') {
      w.goneSince = null;
      /* Clear `gone` as well, not just the countdown.
         It used to be one-way: once an upstream outage lasted GONE_AFTER_MS the
         flag stayed true for the life of the watcher, even after the feed came
         back. socketHandler answers every `subscribeMatch` with
         `if (gone) emit('matchGone')`, so from then on EVERY player opening that
         gmid was bounced to the home page the moment their socket subscribed —
         while the very same tick was serving them a full board. Measured on
         gmid 461632184: private-data 200 with 17 markets, and the page still
         left for `/` 250 ms in, from useMatchGoneSocket. A match that answers
         again is not gone. */
      if (w.gone) {
        w.gone = false;
        console.log(`[matchWatch] back gmid=${w.gmid} sid=${w.sid} — feed answering again`);
      }
      return;
    }
    if (verdict === 'blip') return;

    w.goneSince ||= Date.now();
    if (Date.now() - w.goneSince >= GONE_AFTER_MS) {
      // Both sources must agree. If the match list still carries this gmid the
      // private-data 404 is the provider's problem, not the match's — restart
      // the clock and keep serving the board.
      if (!(await confirmGone(w.gmid, w.sid))) {
        w.goneSince = Date.now();
        console.log(`[matchWatch] veto gmid=${w.gmid} sid=${w.sid} — private-data 404 but still in the match list`);
        return;
      }
      w.gone = true;
      console.log(`[matchWatch] gone gmid=${w.gmid} sid=${w.sid} → ${room.size} viewer(s) (confirmed by match list)`);
      io.local.to(w.room).emit('matchGone', sealBroadcast(gonePayload(w)));
    }
  } catch (err) {
    console.error('[matchWatch] tick error:', err.message);
  } finally {
    w.inFlight = false;
  }
}

/**
 * Start (or reuse) the watcher for one gmid. Idempotent — one timer per gmid
 * no matter how many sockets subscribe.
 * @returns {{ gone: boolean, last: object|null }} whether the match is already
 *   known gone, and the last pushed body (so a new subscriber gets a board
 *   immediately instead of waiting for the next change)
 */
export function ensureWatch(io, gmid, sid) {
  const key = keyOf(sid, gmid);
  let w = watchers.get(key);
  if (!w) {
    w = {
      gmid, sid, room: matchRoom(sid, gmid), timer: null,
      goneSince: null, gone: false, inFlight: false, emptySince: null, lastJson: null,
    };
    w.timer = setInterval(() => tick(io, w), intervalFor(sid));
    watchers.set(key, w);
    setImmediate(() => tick(io, w));
  }
  return { gone: w.gone, last: w.lastJson ? JSON.parse(w.lastJson) : null };
}

export function goneEvent(gmid, sid) {
  const w = watchers.get(keyOf(sid, gmid));
  return w?.gone ? gonePayload(w) : null;
}

// Observability hook — not used by request code.
export function watchedCount() {
  return watchers.size;
}
