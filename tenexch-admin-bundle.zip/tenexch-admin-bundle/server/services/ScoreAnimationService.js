import dotenv from 'dotenv';
dotenv.config();
import axios from 'axios';

/* Score animation, fetched with retries so a dead token never reaches the page.
 *
 * THE PROBLEM, measured against the live provider
 *   The scorecard host mints a NEW token per request and the provider serves
 *   the graphic at
 *       <provider>/scoreanimationgraphic/<TOKEN>/<gtv>/<n>
 *   Two things make that fragile:
 *
 *   1. Some tokens are born dead. Eight freshly minted tokens for one match:
 *      two answered with a 404 page on their FIRST use — about a quarter.
 *   2. The 404 comes back as HTTP **200**. The body is a 2192-byte page titled
 *      "Page Not Found - 404"; a working one is ~7.8 KB titled
 *      "Score Animation". No status code check can tell them apart.
 *   3. A token is SINGLE-USE. A token that serves the real page on its first
 *      fetch serves the 404 page on every fetch after that — verified three
 *      times in a row.
 *
 *   (3) is why the browser cannot be given a verified URL: verifying it spends
 *   it, and the iframe would then load the 404. So the retry has to happen
 *   here, and whatever we end up with has to be served as HTML, not as a link.
 *
 * WHAT THIS DOES
 *   Fetch host page → pull out the provider URL → fetch it → if it is the 404
 *   page, throw that token away and start again with a fresh one. Up to
 *   MAX_ATTEMPTS. The good HTML is returned to be served from our own origin.
 *
 *   That is safe for this page: its only external script is absolute
 *   (wgt-s3-cdn.statscore.com/bundle/Embeder.js) and the event id is inlined.
 *   The one relative reference is Cloudflare's rocket-loader, which a <base>
 *   tag resolves.
 *
 * NOT CACHED, deliberately: a token is single-use, so a cached page would be a
 * guaranteed 404 on its second viewer.
 */

const HOST_URL = process.env.SCORECARD_HOST_URL || 'https://scorecard.daimond-api.site/';
const MAX_ATTEMPTS = 5;
const TIMEOUT_MS = 8000;

const PROVIDER_RE = /https?:\/\/[a-z0-9.-]*animationprovider\.com\/[^"'\s]+/i;
// The provider's own 404 page — HTTP 200, so it has to be recognised by body.
const isNotFoundPage = (html) =>
  !html || html.length < 4000 || /<title>\s*Page Not Found/i.test(html);

async function fetchOnce(etid, gmid) {
  const hostUrl = `${HOST_URL.replace(/\/+$/, '')}/?etid=${encodeURIComponent(etid)}&gmid=${encodeURIComponent(gmid)}`;
  const host = await axios.get(hostUrl, { timeout: TIMEOUT_MS, responseType: 'text' });
  const match = PROVIDER_RE.exec(String(host.data || ''));
  if (!match) return { ok: false, reason: 'no provider url in host page' };

  const providerUrl = match[0];
  const page = await axios.get(providerUrl, {
    timeout: TIMEOUT_MS,
    responseType: 'text',
    // The provider answers 200 for its 404 page; never let axios throw on
    // status, the body is the only signal that matters.
    validateStatus: () => true,
  });
  const html = String(page.data || '');
  if (isNotFoundPage(html)) return { ok: false, reason: 'dead token', providerUrl };
  return { ok: true, html, providerUrl };
}

/** Add a <base> so the page's one relative script still resolves. */
function withBase(html, providerUrl) {
  const origin = new URL(providerUrl).origin;
  const tag = `<base href="${origin}/">`;
  return /<head[^>]*>/i.test(html)
    ? html.replace(/<head([^>]*)>/i, `<head$1>${tag}`)
    : `${tag}${html}`;
}

/* Mint a provider URL WITHOUT spending it.
 *
 * Fetching the host page mints a token; fetching the provider URL spends it.
 * Those are separate, and it matters: the URL handed back here is untouched, so
 * the browser's iframe gets its FIRST use. Measured — mint, hand over, then use
 * once: 4/4 good immediately, 3/4 good after a 5s pause.
 *
 * This is why the caller must not "check" the URL before using it. Any fetch of
 * it is the one use it has.
 *
 * Pointing the iframe straight at the provider also drops a hop: the browser no
 * longer loads the scorecard host, whose page is solid black
 * (`body` and `#playerDiv` both rgb(0,0,0)) and which used to show through as a
 * black box while the real page came up underneath.
 */
export async function getScoreUrl(etid, gmid) {
  const hostUrl = `${HOST_URL.replace(/\/+$/, '')}/?etid=${encodeURIComponent(etid)}&gmid=${encodeURIComponent(gmid)}`;
  const host = await axios.get(hostUrl, { timeout: TIMEOUT_MS, responseType: 'text' });
  const match = PROVIDER_RE.exec(String(host.data || ''));
  return match ? match[0] : null;
}

/**
 * Working score-animation HTML for a match.
 * @returns {Promise<{ok:boolean, html?:string, attempts:number, reason?:string}>}
 */
export async function getScoreAnimation(etid, gmid) {
  let lastReason = 'unknown';
  for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
    try {
      const result = await fetchOnce(etid, gmid);
      if (result.ok) {
        return { ok: true, html: withBase(result.html, result.providerUrl), attempts: attempt };
      }
      lastReason = result.reason;
    } catch (error) {
      lastReason = error.message;
    }
  }
  return { ok: false, attempts: MAX_ATTEMPTS, reason: lastReason };
}

export default { getScoreAnimation, getScoreUrl };
