import redis from '../config/redisClient.js';
import CommissionConfig from '../model/admin/CommissionConfig.js';
import { DEFAULT_LEAGUE_KEY } from '../constants/commissionLeagues.js';

// ─────────────────────────────────────────────────────────────────────────────
// Sports win-commission config cache — same two-tier read-through as
// BettingConfigService (redis shared by every pm2 worker + a per-process micro
// cache). The settlement worker is a separate process from the admin API, so
// an owner Save invalidates the shared redis key and the worker sees it on its
// next read (at worst MICRO_TTL_MS later).
//
// FAILS OPEN to "not enabled": any redis/DB error means no commission is
// charged. A config lookup must never be able to break settlement.
//
// INHERIT: the grid is keyed (sport, league, market). A VARIANT league cell
// (t10xi, ecricket, …) with no saved row falls back to that sport's 'default'
// row, so turning commission on for Cricket keeps covering T10 XI until the
// owner deliberately overrides that cell. Only 'default' is terminal — no row
// there means no commission. This is why the map keeps DISABLED rows too: an
// explicit "T10 XI / Match Odds OFF" must beat the inherited default ON, and
// that is only distinguishable from "never configured" if the row is present.
// ─────────────────────────────────────────────────────────────────────────────

// v2: the map gained the league level and the market keys were split
// (match -> matchodds/match_other, match1 -> bookmaker/match1_other).
const KEY_COMMISSION = 'cfg:commission:v2';
const REDIS_TTL_SEC = 300;
const MICRO_TTL_MS = 2000;

const NOT_ENABLED = Object.freeze({ enabled: false, percent: 0 });

let micro = null; // { value, expires }

const microGet = () => {
    if (!micro) return undefined;
    if (micro.expires < Date.now()) { micro = null; return undefined; }
    return micro.value;
};
const microSet = (value) => { micro = { value, expires: Date.now() + MICRO_TTL_MS }; };
const microDel = () => { micro = null; };

// Shape: { "4": { "default": { matchodds: { enabled, percent } }, "t10xi": { … } } }
const buildMap = async () => {
    const rows = await CommissionConfig.findAll({
        attributes: ['sport_id', 'league_key', 'market_key', 'enabled', 'percent'],
        raw: true,
    });
    const map = {};
    for (const row of rows) {
        const pct = Number(row.percent);
        const sid = String(row.sport_id);
        const league = String(row.league_key || DEFAULT_LEAGUE_KEY).toLowerCase();
        const market = String(row.market_key || '').toLowerCase();
        if (!market) continue;
        ((map[sid] ||= {})[league] ||= {})[market] = {
            enabled: !!row.enabled && Number.isFinite(pct) && pct > 0,
            percent: Number.isFinite(pct) ? pct : 0,
        };
    }
    return map;
};

const getMap = async () => {
    const local = microGet();
    if (local !== undefined) return local;

    try {
        const cached = await redis.get(KEY_COMMISSION);
        if (cached != null) {
            const parsed = JSON.parse(cached);
            microSet(parsed);
            return parsed;
        }
    } catch (err) {
        console.warn(`[CommissionConfig] redis read failed for ${KEY_COMMISSION}:`, err.message);
    }

    let built;
    try {
        built = await buildMap();
    } catch (err) {
        console.warn('[CommissionConfig] build failed:', err.message);
        return {};
    }
    microSet(built);
    redis.set(KEY_COMMISSION, JSON.stringify(built), 'EX', REDIS_TTL_SEC).catch((err) =>
        console.warn(`[CommissionConfig] redis write failed for ${KEY_COMMISSION}:`, err.message)
    );
    return built;
};

/**
 * { enabled, percent, source } for one (sport, league, market). Never throws.
 *
 * `source` says which row decided it — 'league' (an explicit override on that
 * variant), 'default' (inherited from the sport) or 'none'. It is logged on
 * every charge so a disputed commission can be traced back to a cell.
 */
const getRule = async (sportId, leagueKey, marketKey) => {
    try {
        const map = await getMap();
        const sport = map?.[String(sportId)];
        if (!sport) return NOT_ENABLED;

        const market = String(marketKey || '').toLowerCase();
        const league = String(leagueKey || DEFAULT_LEAGUE_KEY).toLowerCase();

        // An explicit row on the variant league wins outright — including when
        // it is OFF, which is how an owner exempts T10 XI from a sport-wide ON.
        if (league !== DEFAULT_LEAGUE_KEY) {
            const own = sport?.[league]?.[market];
            if (own) {
                return own.enabled
                    ? { enabled: true, percent: Number(own.percent), source: 'league' }
                    : { ...NOT_ENABLED, source: 'league' };
            }
        }

        const fallback = sport?.[DEFAULT_LEAGUE_KEY]?.[market];
        if (fallback?.enabled) {
            return { enabled: true, percent: Number(fallback.percent), source: 'default' };
        }
    } catch (err) {
        console.warn('[CommissionConfig] getRule failed:', err.message);
    }
    return NOT_ENABLED;
};

/** Called by the admin write endpoints. */
const invalidate = async () => {
    microDel();
    try {
        await redis.del(KEY_COMMISSION);
    } catch (err) {
        console.warn(`[CommissionConfig] redis del failed for ${KEY_COMMISSION}:`, err.message);
    }
};

export default {
    getMap,
    getRule,
    invalidate,
    KEY_COMMISSION,
};
