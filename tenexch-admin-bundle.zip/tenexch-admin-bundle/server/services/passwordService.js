import bcrypt from 'bcryptjs';
import { MESSAGES } from '../constants/messages.js';


const PasswordService = {
    /**
     * Default salt rounds for password hashing
     */
    SALT_ROUNDS: 12,

    /**
     * Hash a password with bcrypt
     * @param {string} password - Plain text password to hash
     * @param {number} saltRounds - Number of salt rounds (default: 12)
     * @returns {Promise<string>} - Hashed password
     * @throws {Error} - If password is empty or hashing fails
     */
    hashPassword: async (password, saltRounds = PasswordService.SALT_ROUNDS) => {
        try {
            if (!password || typeof password !== 'string') {
                throw new Error(MESSAGES.PASSWORD.MUST_BE_NON_EMPTY);
            }

            if (password.trim().length === 0) {
                throw new Error(MESSAGES.PASSWORD.CANNOT_BE_WHITESPACE);
            }

            const hashedPassword = await bcrypt.hash(password, saltRounds);
            return hashedPassword;
        } catch (error) {
            if (error.message.includes('Password must be') || error.message.includes('Password cannot be')) {
                throw error;
            }
            throw new Error(MESSAGES.PASSWORD.HASH_FAILED);
        }
    },

    /**
     * Compare a plain text password with a hashed password
     * @param {string} password - Plain text password to compare
     * @param {string} hashedPassword - Hashed password to compare against
     * @returns {Promise<boolean>} - True if passwords match, false otherwise
     * @throws {Error} - If parameters are invalid or comparison fails
     */
    comparePassword: async (password, hashedPassword) => {
        try {
            if (!password || typeof password !== 'string') {
                throw new Error(MESSAGES.PASSWORD.MUST_BE_NON_EMPTY);
            }

            if (!hashedPassword || typeof hashedPassword !== 'string') {
                throw new Error(MESSAGES.PASSWORD.HASHED_MUST_BE_NON_EMPTY);
            }

            const isMatch = await bcrypt.compare(password, hashedPassword);
            return isMatch;
        } catch (error) {
            if (error.message.includes('must be a non-empty string')) {
                throw error;
            }
            throw new Error(MESSAGES.PASSWORD.COMPARE_FAILED);
        }
    },

    /**
     * Generate a salt for password hashing
     * @param {number} saltRounds - Number of salt rounds (default: 12)
     * @returns {Promise<string>} - Generated salt
     * @throws {Error} - If salt generation fails
     */
    generateSalt: async (saltRounds = PasswordService.SALT_ROUNDS) => {
        try {
            const salt = await bcrypt.genSalt(saltRounds);
            return salt;
        } catch (error) {
            throw new Error(MESSAGES.PASSWORD.SALT_GENERATION_FAILED);
        }
    },

    /**
     * Hash a password with a specific salt
     * @param {string} password - Plain text password to hash
     * @param {string} salt - Salt to use for hashing
     * @returns {Promise<string>} - Hashed password
     * @throws {Error} - If parameters are invalid or hashing fails
     */
    hashPasswordWithSalt: async (password, salt) => {
        try {
            if (!password || typeof password !== 'string') {
                throw new Error(MESSAGES.PASSWORD.MUST_BE_NON_EMPTY);
            }

            if (!salt || typeof salt !== 'string') {
                throw new Error(MESSAGES.PASSWORD.SALT_MUST_BE_NON_EMPTY);
            }

            const hashedPassword = await bcrypt.hash(password, salt);
            return hashedPassword;
        } catch (error) {
            if (error.message.includes('must be a non-empty string')) {
                throw error;
            }
            throw new Error(MESSAGES.PASSWORD.HASH_WITH_SALT_FAILED);
        }
    },

    /**
     * Validate password strength
     * @param {string} password - Password to validate
     * @param {Object} options - Validation options
     * @param {number} options.minLength - Minimum password length (default: 8)
     * @param {boolean} options.requireUppercase - Require uppercase letter (default: true)
     * @param {boolean} options.requireLowercase - Require lowercase letter (default: true)
     * @param {boolean} options.requireNumbers - Require numbers (default: true)
     * @param {boolean} options.requireSpecialChars - Require special characters (default: false)
     * @returns {Object} - Validation result with isValid boolean and errors array
     */
    validatePasswordStrength: (password, options = {}) => {
        const {
            minLength = 8,
            requireUppercase = true,
            requireLowercase = true,
            requireNumbers = true,
            requireSpecialChars = false
        } = options;

        const errors = [];

        if (!password || typeof password !== 'string') {
            errors.push(MESSAGES.PASSWORD.MUST_BE_NON_EMPTY);
            return { isValid: false, errors };
        }

        if (password.length < minLength) {
            errors.push(MESSAGES.PASSWORD.MIN_LENGTH(minLength));
        }

        if (requireUppercase) { /*
    if (!/[A-Z]/.test(password)) {
      errors.push('Password must contain at least one uppercase letter');
    }
    */ }

        if (requireLowercase && !/[a-z]/.test(password)) {
            errors.push(MESSAGES.PASSWORD.NEED_LOWERCASE);
        }

        if (requireNumbers && !/\d/.test(password)) {
            errors.push(MESSAGES.PASSWORD.NEED_NUMBER);
        }

        if (requireSpecialChars && !/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {
            errors.push(MESSAGES.PASSWORD.NEED_SPECIAL_CHAR);
        }

        return {
            isValid: errors.length === 0,
            errors
        };
    }
};

export default PasswordService; 