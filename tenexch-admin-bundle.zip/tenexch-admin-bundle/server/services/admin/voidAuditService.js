/**
 * voidAuditService — the single writer for `bet_void_audit`.
 *
 * Every void path funnels through here so the six entry points cannot drift in
 * what they record. See model/admin/BetVoidAudit.js for the grain and for why
 * the table exists at all.
 *
 * TRANSACTION CONTRACT
 * `recordVoidAudit` takes the caller's transaction and MUST be given one when
 * the caller has one open. The audit row then commits atomically with the void
 * it describes: a rolled-back void leaves no audit row claiming it happened, and
 * a committed void can never be missing its row.
 *
 * FAILURE POLICY — deliberately asymmetric to ActivityLogService, which
 * swallows its own errors so logging cannot break a user action. Here the write
 * IS part of the money operation: a void that cannot be audited must not
 * silently proceed, or we are back to the blind spot this table was built to
 * close. So errors propagate and roll the void back. The `tracker` check
 * `voidNotAudited` is the backstop for any path that has not been wired up yet.
 */
import { randomUUID } from "crypto";
import BetVoidAudit, { VOID_TYPES } from "../../model/admin/BetVoidAudit.js";
import { clientIp } from '../../utils/clientIp.js';

export { VOID_TYPES };

/** A fresh id tying together every bet of one void operation. */
export const newVoidGroupId = () => randomUUID();

const num = (v) => (v === null || v === undefined || v === "" ? null : Number(v));

/**
 * Pull the actor out of an Express request. Voids are owner-gated
 * (requireOwner), and `req.user.actor` is set when a staff member is acting on
 * an owner's behalf — record the person who clicked, not the account.
 */
export const actorFrom = (req) => ({
  actor: req?.user?.actor?.username || req?.user?.username || null,
  actor_role: req?.user?.actor?.role || req?.user?.role || null,
  ip_address: clientIp(req),
  browser: req?.headers?.["user-agent"] || null,
});

/**
 * Write one audit row per bet in a void group.
 *
 * @param {object}   p
 * @param {string}   p.voidGroupId     from newVoidGroupId(), shared by the group
 * @param {string}   p.voidType        one of VOID_TYPES
 * @param {object[]} p.bets            the bet rows being voided (SportsBet or CasinoBet)
 * @param {number}   [p.representativeBetId] bet carrying the group's ledger row
 * @param {object}   p.before          { cash, inr, exposure, totalExposure, status, resultStatus }
 * @param {object}   p.after           same shape, read after the mutations
 * @param {number}   [p.refundAmount]  money returned for the GROUP
 * @param {number}   [p.exposureRowsDeleted]
 * @param {number}   [p.ledgerId]
 * @param {object}   [p.context]       actorFrom(req) result, plus optional note
 * @param {string}   [p.betKind]       'SPORTS' (default) | 'CASINO'
 * @param {import('sequelize').Transaction} t  the caller's transaction
 */
export const recordVoidAudit = async (
  {
    voidGroupId,
    voidType,
    bets = [],
    representativeBetId = null,
    before = {},
    after = {},
    refundAmount = null,
    exposureRowsDeleted = null,
    ledgerId = null,
    context = {},
    betKind = "SPORTS",
    backfilled = false,
  },
  t = null,
) => {
  if (!bets.length) return [];

  const rows = bets.map((b) => ({
    void_group_id: voidGroupId,
    is_representative: representativeBetId != null && Number(b.id) === Number(representativeBetId),
    void_type: voidType,

    bet_id: b.id,
    bet_kind: betKind,
    user_id: b.user_id,
    username: context.username || b.username || null,

    match_id: b.match_id != null ? String(b.match_id) : null,
    eventid: b.eventid != null ? String(b.eventid) : (b.event_id != null ? String(b.event_id) : null),
    match_title: b.match_title || b.event_name || null,
    market_type: b.market_type || null,
    game_type: b.game_type || null,
    // Casino rows call it `selection`; sports rows `selection_name`.
    selection_name: b.selection_name || b.selection || null,
    bet_type: b.bet_type || null,
    odds: num(b.odds),
    stake_amount: num(b.stake_amount ?? b.stake),
    liability: num(b.liability ?? b.exposer),

    status_before: before.status ?? b.status ?? null,
    result_status_before: before.resultStatus ?? b.result_status ?? null,
    cash_before: num(before.cash),
    inr_before: num(before.inr),
    exposure_before: num(before.exposure),
    total_exposure_before: num(before.totalExposure),

    status_after: after.status ?? null,
    result_status_after: after.resultStatus ?? null,
    cash_after: num(after.cash),
    inr_after: num(after.inr),
    exposure_after: num(after.exposure),
    total_exposure_after: num(after.totalExposure),

    refund_amount: num(refundAmount),
    exposure_rows_deleted: exposureRowsDeleted == null ? null : Number(exposureRowsDeleted),
    ledger_id: ledgerId == null ? null : Number(ledgerId),

    actor: context.actor || null,
    actor_role: context.actor_role || null,
    ip_address: context.ip_address || null,
    browser: context.browser || null,
    note: context.note || null,

    backfilled,
    created_at: new Date(),
  }));

  return BetVoidAudit.bulkCreate(rows, t ? { transaction: t } : {});
};

export default { recordVoidAudit, newVoidGroupId, actorFrom, VOID_TYPES };
