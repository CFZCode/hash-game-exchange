/**
 * sportsMarketVoidService — the ONE implementation of "void every open bet of
 * a sports market (or one fancy session) and give the blocked money back".
 *
 * It used to live inline in mannualSettle/controller.js (`voidResult`, the
 * owner's POST /void). It was lifted out unchanged on 2026-09-16 so the
 * auto-void timer (sportsbet/betresult/autoVoid.js) can void a market with
 * exactly the same bucket rules, refund maths, ledger row and audit trail as
 * the owner's click. Two callers, one money path.
 *
 * Bucket rules (helper/exposureBucket.js):
 *  - MO/BM: one book per match_id + market_type; release the WORST row.
 *  - fancy family: one pot per SELECTION; a single session releases its own
 *    `sel` row, a whole-bucket teardown releases the SUM of every `sel` row.
 *  - badlo legs sit in their own ('badlo', runner) pot and are released too.
 *
 * Runs its own transaction. Throws after rollback; the caller decides how to
 * report it.
 */
import { Op } from "sequelize";
import sequelize from "../../config/db.js";
import Wallet from "../../model/admin/Wallet.js";
import SportsBet from "../../model/user/SportsBet.js";
import UserExposure from "../../model/user/UserExposure.js";
import TotalExposure from "../../model/user/TotalExposure.js";
import CreditsLedger from "../../model/user/CreditsLedger.js";
import { exposureIdentity } from "../../helper/lineMarket.js";
import { BADLO_EXPOSURE_GAME_TYPE } from "../../helper/badloMarket.js";
import {
    isPerSelectionMarket,
    selectionExposureRows,
    releasableLiability,
    additiveBucketLiability,
} from "../../helper/exposureBucket.js";
import { recalcTotalExposure } from "../../helper/totalExposure.js";
import { recordVoidAudit, newVoidGroupId, VOID_TYPES } from "./voidAuditService.js";

/**
 * Record a void's exposure release in credits_ledger.
 *
 * Voiding an OPEN bet is a LOCK RELEASE, not a transfer: `cash` returns to what it was
 * before placement and `inr_balance` is untouched. Until now that movement left no trace
 * anywhere — not the ledger, the statement, the reports, or the System Tracker — so an
 * owner releasing a player's exposure was invisible after the fact.
 *
 * reason='refund' is deliberate. Every existing consumer filters on reason and excludes
 * this one (StatementBuilder takes BET_WIN/BET_LOSS; the tracker's PL_WHERE and unpaidWin
 * take 'settlement'), so the row is purely additive: it cannot move users.profit, change
 * an account statement, or flip a tracker check. Writing it as 'settlement' instead would
 * corrupt plConsistency for every voided bet.
 *
 * profit/loss stay null — no P&L happened, only a lock release.
 * Always called inside the caller's transaction so a failure rolls the whole void back.
 *
 * `source`/`label` distinguish the owner's click ('manual_void' / "MANUAL VOID")
 * from the timer ('auto_void' / "AUTO VOID") in the ledger; both are reason='refund'.
 *
 * Plan: docs/plans/2026-08-23-refund-audit-trail.md
 */
export const recordVoidRefund = async (
    { uid, refundAmount, bet, actor, source = 'manual_void', label = 'MANUAL VOID' },
    t,
) => {
    if (!(Number(refundAmount) > 0)) return null; // nothing was released, nothing to record

    // read the post-increment cash on the same transaction so `closing` is exact
    const wallet = await Wallet.findOne({
        where: { user_id: uid },
        attributes: ['wallet_id', 'cash'],
        transaction: t,
    });

    const marketType = bet?.market_type || null;
    const selection = bet?.selection_name ? ` / ${bet.selection_name}` : '';
    const title = bet?.match_title || bet?.event_name || 'match';

    const ledgerRow = await CreditsLedger.create({
        user_id: String(uid),
        currency: 'INR',
        amount: refundAmount,
        reason: 'refund',
        description: `${label} — ${title} / ${marketType || '-'}${selection}`,
        eventid: bet?.eventid ? String(bet.eventid) : null,
        match_id: bet?.match_id ? String(bet.match_id) : null,
        market_type: marketType,
        bet_id: bet?.id ?? null,
        meta: {
            source,
            voided_by: actor || 'owner',
            exposure_released: Number(refundAmount),
        },
        netamount: refundAmount,
        closing: wallet ? Number(wallet.cash) : null,
        profit: null,
        loss: null,
        category: 'SPORTS',
    }, { transaction: t });

    // Returned so the caller can link bet_void_audit.ledger_id to this row.
    return ledgerRow?.id ?? null;
};

/**
 * Void every OPEN bet of one market — or one fancy session when
 * `selection_name` is given — for every user holding one.
 *
 * @param {object} p
 * @param {string} p.match_id
 * @param {string} p.market_type
 * @param {string} [p.gametype]        narrows to SportsBet.game_type (MO/BM/FAN)
 * @param {string} [p.selection_name]  one session of a per-selection market
 * @param {string} [p.voidType]        bet_void_audit.void_type (default MARKET)
 * @param {object} [p.context]         actorFrom(req) result or { actor, actor_role }
 * @param {string} [p.note]            audit note; defaults describe the scope
 * @param {string} [p.ledgerSource]    credits_ledger.meta.source
 * @param {string} [p.ledgerLabel]     credits_ledger.description prefix
 * @returns {Promise<{ userIds: number[], betsVoided: number, voidGroupId: string }>}
 */
export const voidOpenMarket = async ({
    match_id,
    market_type,
    gametype = null,
    selection_name = null,
    voidType = VOID_TYPES.MARKET,
    context = {},
    note = null,
    ledgerSource = 'manual_void',
    ledgerLabel = 'MANUAL VOID',
}) => {
    if (!match_id || !market_type) {
        throw new Error("Missing required fields: match_id, market_type");
    }

    const t = await sequelize.transaction();

    try {
        // 2. Build Where Clause for Finding Bets
        // We need to find 'open' bets to know which users are involved and to close them.
        const whereClause = {
            match_id,
            market_type,
            status: 'open'
        };

        if (gametype) {
            whereClause.game_type = gametype;
        }

        // If selection_name is provided, filter by it.
        // This is crucial for distinguishing specific Fancy sessions if they share market_type='fancy1'
        if (selection_name) {
            whereClause.selection_name = selection_name;
        }

        // 3. Find Affected Users
        const bets = await SportsBet.findAll({
            where: whereClause,
            attributes: ['user_id'],
            group: ['user_id'],
            transaction: t
        });

        const userIds = bets.map(b => b.user_id);

        // The exposure identity this market writes under. For a per-selection
        // market voided ONE SESSION AT A TIME (selection_name given) that is a
        // single selection's four rows; without a selection_name the caller is
        // tearing down the whole market_type bucket, so every row goes.
        const marketIsPerSelection = isPerSelectionMarket(market_type);
        const scopedToSelection = Boolean(selection_name) && marketIsPerSelection;
        const { game_type: bucketGameType, team_name: bucketSel } = exposureIdentity({
            marketType: market_type,
            selectionName: selection_name || null,
        });

        // ONE group id for the whole operation: a market void is a single action
        // even though it spans many users and many bets.
        const voidGroupId = newVoidGroupId();
        const auditCtx = context || {};
        const actorName = auditCtx.actor || null;
        // Collected per user inside the loop, written after the bets are closed
        // so status_after/result_status_after reflect reality.
        const auditPending = [];

        // 4. Process Each User (Refund Exposure)
        for (const uid of userIds) {
            const walletBefore = await Wallet.findOne({
                where: { user_id: uid },
                attributes: ['cash', 'inr_balance'],
                transaction: t,
            });
            const snapBefore = await TotalExposure.findOne({
                where: { user_id: uid }, attributes: ['total_exposure'], transaction: t,
            });
            let refundAmount = 0;
            let ledgerId = null;
            let exposureRowsDeleted = 0;
            let exposureBefore = null;
            // Find UserExposure entries.
            // Rows are keyed by (game_type, team_name) — exposureIdentity() owns
            // that pair. Line markets file under 'fancy2' keyed by the MARKET
            // name; everything else under (market_type, selection_name).
            //
            // Narrowing by team_name is what makes a single-session void safe:
            // fancy1 puts every session of the match in one game_type bucket, so
            // an unscoped destroy would wipe the exposure of every OTHER open
            // session too and leave those bets unblocked.
            const exposureWhere = {
                user_id: uid,
                match_id: match_id,
                game_type: bucketGameType,
            };

            // Per-selection markets own four rows per selection:
            //   sel, sel+'lay', sel+'back', sel+'totalstake'
            let perSelection = scopedToSelection;
            if (scopedToSelection) {
                exposureWhere.team_name = { [Op.in]: selectionExposureRows(bucketSel) };
            }

            let exposures = await UserExposure.findAll({
                where: exposureWhere,
                transaction: t
            });

            // LEGACY FALLBACK — line-market rows written before 2026-08-26 are filed
            // under (market_type, runner), not ('fancy2', mname). settlementv2.js
            // carries the same fallback; without it here a manual void of one of those
            // older markets silently releases NOTHING: findAll returns [], so the
            // wallet is never credited and the rows are never destroyed, and the
            // punter's stake stays locked forever with the bet showing 'refunded'.
            // (Exactly how saluser1 lost 200.00 on event 738470302 / 1st Innings
            // 6 Overs Line — voided 2026-08-26, no credits_ledger row, rows orphaned.)
            // exposureWhere is mutated on purpose so the destroy below clears the
            // identity that actually held the row rather than orphaning it again.
            if (!exposures.length && exposureWhere.game_type !== market_type) {
                exposureWhere.game_type = market_type;
                // Pre-migration line rows are keyed by the RUNNER ("Total Runs"),
                // not by the market name, so the selection filter above can never
                // match them — drop it or the fallback finds nothing and we are
                // back to the orphaned-row bug it exists to prevent. The legacy
                // game_type IS the market, so the bucket is still exact.
                delete exposureWhere.team_name;
                perSelection = false;
                exposures = await UserExposure.findAll({
                    where: exposureWhere,
                    transaction: t
                });
                if (exposures.length) {
                    console.warn('[voidOpenMarket] released a PRE-MIGRATION line exposure row',
                        { uid, match_id, market_type });
                }
            }

            // BADLO legs ride inside this market: they keep market_type 'Normal'
            // and the runner's selection_name, so whereClause finds them and
            // step 5 closes them — but their money is filed under a SEPARATE
            // ('badlo', runner) bucket (exposureIdentity in helper/lineMarket.js).
            // Without this the leg's stake stays blocked behind a bet that
            // already reads 'refunded' (user 24, "6 over run BT", 2026-09-11).
            // Scoped by the legs' OWN selections, so a whole-market void never
            // reaches another market's badlo pot on the same match.
            const badloSels = (await SportsBet.findAll({
                where: { ...whereClause, user_id: uid, badlo: true },
                attributes: ['selection_name'],
                group: ['selection_name'],
                transaction: t
            })).map((b) => b.selection_name);
            let badloWhere = null;
            let badloExposures = [];
            if (badloSels.length > 0) {
                badloWhere = {
                    user_id: uid,
                    match_id: match_id,
                    game_type: BADLO_EXPOSURE_GAME_TYPE,
                    team_name: {
                        [Op.in]: badloSels.flatMap((s) => selectionExposureRows(
                            exposureIdentity({ marketType: market_type, selectionName: s, badlo: true }).team_name
                        )),
                    },
                };
                badloExposures = await UserExposure.findAll({
                    where: badloWhere,
                    transaction: t
                });
            }

            if (exposures.length > 0 || badloExposures.length > 0) {
                // How much cash this teardown releases.
                //  - one session of a per-selection market -> that selection's own
                //    `sel` row, exactly what placement blocked.
                //  - the WHOLE bucket of a per-selection market -> the SUM of every
                //    selection's `sel` row: fancy money is additive across
                //    selections (helper/totalExposure.js), so taking a single min
                //    here would refund one session and swallow the rest.
                //  - MO/BM -> the worst row across the market book, unchanged.
                let minExp;
                if (perSelection) {
                    minExp = releasableLiability(exposures, { perSelection: true, sel: bucketSel });
                } else if (marketIsPerSelection) {
                    minExp = additiveBucketLiability(exposures);
                } else {
                    minExp = releasableLiability(exposures, { perSelection: false });
                }

                // Badlo is money STAKED, summed per selection — never netted
                // against the runner's Normal book (helper/badloMarket.js).
                minExp += additiveBucketLiability(badloExposures);

                exposureBefore = minExp;

                // Credit back if there is a negative exposure
                if (minExp < 0) {
                    refundAmount = Math.abs(minExp);
                    await Wallet.increment('cash', {
                        by: refundAmount,
                        where: { user_id: uid },
                        transaction: t
                    });

                    // Audit the release. Representative bet = this user's first still-open
                    // bet in the group, matching the bet_id convention MO/BM settlement
                    // already uses for per-market rows. Read before step 5 closes them.
                    const repBet = await SportsBet.findOne({
                        where: { ...whereClause, user_id: uid },
                        order: [['id', 'ASC']],
                        transaction: t
                    });
                    ledgerId = await recordVoidRefund({
                        uid,
                        refundAmount,
                        bet: repBet,
                        actor: actorName,
                        source: ledgerSource,
                        label: ledgerLabel,
                    }, t);
                }

                // Remove these exposure records as the market/selection is voided
                if (exposures.length > 0) {
                    exposureRowsDeleted = await UserExposure.destroy({
                        where: exposureWhere,
                        transaction: t
                    });
                }
                if (badloExposures.length > 0) {
                    exposureRowsDeleted += await UserExposure.destroy({
                        where: badloWhere,
                        transaction: t
                    });
                }
            }

            // Snapshot everything this user's slice of the void did. The bets
            // themselves are still 'open' at this point — step 5 closes them —
            // so read them NOW while they can still be identified by whereClause.
            const userBets = await SportsBet.findAll({
                where: { ...whereClause, user_id: uid },
                transaction: t,
            });
            auditPending.push({
                uid, userBets, walletBefore, snapBefore,
                refundAmount, ledgerId, exposureRowsDeleted, exposureBefore,
                representativeBetId: userBets.length
                    ? Math.min(...userBets.map((b) => Number(b.id)))
                    : null,
            });
        }

        // 5. Update Bets Status
        // mark status as closed and result_status as refunded
        await SportsBet.update(
            {
                status: 'closed',
                result_status: 'refunded',
                match_end_time: new Date()
            },
            {
                where: whereClause,
                transaction: t
            }
        );

        // 6. Snapshot follows the rows.
        // Step 4 destroyed this market's user_exposures for every affected
        // user. total_exposures is NOT recomputed on read — the header reads
        // it straight — so without this the released liability keeps eating
        // their balance forever (see helper/totalExposure.js).
        const totalsAfter = {};
        for (const uid of userIds) {
            totalsAfter[uid] = await recalcTotalExposure(uid, t);
        }

        // 7. Audit — one row per bet, all sharing this operation's group id.
        // Written inside the transaction so it cannot disagree with the void.
        let auditedBets = 0;
        for (const a of auditPending) {
            const walletAfter = await Wallet.findOne({
                where: { user_id: a.uid },
                attributes: ['cash', 'inr_balance'],
                transaction: t,
            });
            await recordVoidAudit({
                voidGroupId,
                voidType,
                bets: a.userBets,
                representativeBetId: a.representativeBetId,
                before: {
                    status: 'open',
                    resultStatus: 'pending',
                    cash: a.walletBefore?.cash,
                    inr: a.walletBefore?.inr_balance,
                    exposure: a.exposureBefore,
                    totalExposure: a.snapBefore?.total_exposure,
                },
                after: {
                    status: 'closed',
                    resultStatus: 'refunded',
                    cash: walletAfter?.cash,
                    inr: walletAfter?.inr_balance,
                    exposure: a.exposureRowsDeleted > 0 ? 0 : a.exposureBefore,
                    totalExposure: totalsAfter[a.uid],
                },
                refundAmount: a.refundAmount,
                exposureRowsDeleted: a.exposureRowsDeleted,
                ledgerId: a.ledgerId,
                context: {
                    ...auditCtx,
                    note: note || (selection_name
                        ? `session void: ${selection_name}`
                        : `whole ${market_type} market`),
                },
            }, t);
            auditedBets += a.userBets.length;
        }

        await t.commit();

        return { userIds, betsVoided: auditedBets, voidGroupId };
    } catch (error) {
        await t.rollback();
        throw error;
    }
};

export default { voidOpenMarket, recordVoidRefund };
