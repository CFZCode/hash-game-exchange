// import Agent from '../../model/admin/Agent.js'
// import TokenBlacklist from '../../model/admin/TokenBlacklist.js';
// import PasswordService from '../passwordService.js';
// import jwt from 'jsonwebtoken';

// const AuthService = {
//     login: async (email, password) => {
//         const user = await Agent.findOne({ where: { email } });
//         if (!user) throw new Error('User not found');

//         // Use PasswordService to securely compare passwords
//         const isMatch = await PasswordService.comparePassword(password, user.password);
//         if (!isMatch) throw new Error('Password Wrong');

//         console.log(user, 'agent------> user id')

//         // Generate a JWT token with user_id and role
//         const token = jwt.sign(
//             { user_id: user.agent_id, role: user.role, username: user.username }, // Ensure user_id is included
//             process.env.JWT_SECRET,
//             { expiresIn: process.env.JWT_EXPIRATION }
//         );

//         return token;
//     },

//     logout: async (token) => {
//         // Decode the token to get its expiration time
//         const decoded = jwt.verify(token, process.env.JWT_SECRET);

//         // Add the token to the blacklist
//         await TokenBlacklist.create({
//             token,
//             expiresAt: new Date(decoded.exp * 1000), // Convert expiration time to a Date object
//         });
//     },
// };

// export default AuthService;

import Agent from '../../model/admin/Agent.js';
import { blacklistToken } from '../../helper/tokenBlacklist.js';
import PasswordService from '../passwordService.js';
import jwt from 'jsonwebtoken';
import { MESSAGES } from '../../constants/messages.js';

const AuthService = {
    login: async (email, password) => {
        const user = await Agent.findOne({ where: { email } });
        if (!user) throw new Error(MESSAGES.ADMIN.AUTH.ACCOUNT_NOT_AVAILABLE);

        const isMatch = await PasswordService.comparePassword(password, user.password);
        if (!isMatch) throw new Error(MESSAGES.ADMIN.AUTH.PASSWORD_INCORRECT);

        console.log('Agent login user →', user.agent_id);

        const username = user.username || user.name || user.agent_name;

        const token = jwt.sign(
            { 
                user_id: user.agent_id, 
                role: user.role, 
                username 
            },
            process.env.JWT_SECRET,
            // Same fallback as ownerAuthService / staffAuthService /
            // userAuthService / executiveAuthService. Without it an unset
            // JWT_EXPIRATION makes this `expiresIn: undefined`, and jwt.sign
            // then issues a token with NO exp claim - an agent session that
            // never expires, and one that logout() cannot blacklist either
            // (it reads `decoded.exp`).
            { expiresIn: process.env.JWT_EXPIRATION || '1d' }
        );

        return token;
    },

    logout: async (token) => {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        await blacklistToken(token, new Date(decoded.exp * 1000));
    },
};

export default AuthService;
