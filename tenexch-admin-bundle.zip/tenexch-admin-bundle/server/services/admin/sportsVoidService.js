/**
 * Admin void for ALREADY SETTLED sports markets ("Void Bets (After Settlement)").
 *
 * Ye casino wale case 2 ka sports version hai. Settlement galat result par ho
 * gayi (ya upstream ne result badal diya) — ab poori settlement ulti karni hai.
 *
 * ── Paisa kaise ulta hota hai ────────────────────────────────────────────────
 * settlementv2.js har (user + market) ke liye EK wallet update karta hai aur
 * uske saath EK credits_ledger row likhta hai (reason 'settlement'):
 *
 *     cash        += marketFinalCredit   → ledger.netamount
 *     inr_balance += marketNetAmount     → ledger.profit + ledger.loss
 *
 * marketFinalCredit me placement ka lock bhi wapas aata hai, isliye:
 *     marketFinalCredit = lock + marketNetAmount
 * Void ka matlab hai user ko wahan wapas le jaana jahan bet lagne se PEHLE tha,
 * yaani settlement bhi ulti karo aur lock bhi refund karo:
 *     cash delta = lock − marketFinalCredit = −marketNetAmount
 *     inr  delta =                          −marketNetAmount
 * Dono ek hi number — bilkul casino jaisa. Prod data par verify kiya:
 * netamount − (profit+loss) hamesha us market ka asli lock nikla (single back
 * bet 2000 → 2000, hedged market → 0, 210500 exposure wala Bookmaker → 210500).
 *
 * Isliye lock ko alag se recompute karne ki zarurat nahi — ledger row hi kaafi
 * hai, aur wahi row asli wallet update se likhi gayi thi.
 *
 * Ek ledger row = ek wallet update = void ki ek unit. Fancy/oddeven jaise
 * per-bet settle hone wale markets me ek user ke ek hi market par kai rows hoti
 * hain; har row alag void hoti hai.
 */
import { Op } from "sequelize";
import sequelize from "../../config/db.js";
import SportsBet from "../../model/user/SportsBet.js";
import Wallet from "../../model/admin/Wallet.js";
import User from "../../model/user/User.js";
import CreditsLedger from "../../model/user/CreditsLedger.js";
import WalletService from "../walletService.js";
import { POINT_CATEGORY, pointEntryRef } from "../../constants/pointLedger.js";
import { COMMISSION_REASON, COMMISSION_VOID_REASON } from "../settlement/sportsCommissionService.js";
import { emitBalanceUpdate } from "../../utils/socketUtils.js";
import { withVoidSuffix } from "../../helper/voidLabel.js";
import { recalcTotalExposure } from "../../helper/totalExposure.js";
import {
  isPerSelectionMarket,
  SETTLED_RESULT_STATUSES,
} from "../../helper/exposureBucket.js";
import {
  recordVoidAudit,
  newVoidGroupId,
  VOID_TYPES,
} from "./voidAuditService.js";

const round2 = (v) => Math.round((Number(v) || 0) * 100) / 100;

// Casino wali window ke saath consistent — settle hone ke 24 ghante ke andar hi
// void ho sakta hai. List aur void DONO par lagti hai.
const VOID_WINDOW_HOURS = Number(process.env.SPORTS_SETTLED_VOID_WINDOW_HOURS || 24);
const since = () => new Date(Date.now() - VOID_WINDOW_HOURS * 60 * 60 * 1000);

const SETTLEMENT_WHERE = { category: "SPORTS", reason: "settlement" };
const VOID_REASON = "settlement_void";

/**
 * Void hone par original `settlement` row DELETE nahi hoti (statement ka trail
 * bana rehta hai) — uske saamne ek `settlement_void` row banti hai. Isliye list
 * ko khud filter karna padta hai, warna void ki hui market list me dikhti
 * rehti hai.
 *
 * Link `meta.reverses_ledger_id` se milta hai. Us field ke aane se pehle likhi
 * gayi void rows ke liye fallback: same (user, match, market, bet) par jo
 * settlement row void row se PEHLE ki hai.
 */
const voidedLedgerIds = async (settlementRows) => {
  if (!settlementRows.length) return new Set();

  const voids = await CreditsLedger.findAll({
    where: {
      category: "SPORTS",
      reason: VOID_REASON,
      match_id: { [Op.in]: [...new Set(settlementRows.map((r) => String(r.match_id)))] },
    },
    raw: true,
  });
  if (!voids.length) return new Set();

  const out = new Set();
  for (const v of voids) {
    const linked = Number(v.meta?.reverses_ledger_id || 0);
    if (linked) { out.add(linked); continue; }
    // legacy void row — tuple se sabse nazdeek purani settlement row dhoondo
    const candidate = settlementRows
      .filter((s) =>
        String(s.user_id) === String(v.user_id) &&
        String(s.match_id) === String(v.match_id) &&
        String(s.market_type || "") === String(v.market_type || "") &&
        Number(s.bet_id || 0) === Number(v.bet_id || 0) &&
        Number(s.id) < Number(v.id) &&
        !out.has(Number(s.id))
      )
      .sort((a, b) => b.id - a.id)[0];
    if (candidate) out.add(Number(candidate.id));
  }
  return out;
};

// Ek ledger row ka inr delta = us market/bet ka asli P/L
const netOf = (row) => round2(Number(row.profit || 0) + Number(row.loss || 0));

/**
 * Pichhle 24 ghante me settle hue sports markets, market-wise grouped.
 * Shape wahi jo admin ka VoidBets page pehle se expect karta hai.
 */
export const listSettledMarkets = async ({ search = "", limit = 200, offset = 0 } = {}) => {
  const lim = Math.min(Math.max(Number(limit) || 200, 1), 500);
  const off = Math.max(Number(offset) || 0, 0);

  const rows = await CreditsLedger.findAll({
    where: { ...SETTLEMENT_WHERE, created_at: { [Op.gte]: since() } },
    order: [["id", "DESC"]],
    raw: true,
  });
  if (!rows.length) return { windowHours: VOID_WINDOW_HOURS, data: [] };

  const voided = await voidedLedgerIds(rows);
  const live = rows.filter((r) => !voided.has(Number(r.id)));
  if (!live.length) return { windowHours: VOID_WINDOW_HOURS, data: [] };

  // (match_id, market_type) par group
  const groups = new Map();
  for (const r of live) {
    const key = `${r.match_id}|${r.market_type || ""}`;
    if (!groups.has(key)) {
      groups.set(key, {
        matchId: String(r.match_id || ""),
        marketType: r.market_type || "",
        eventId: r.eventid != null ? String(r.eventid) : null,
        matchTitle: null,
        teamOne: null,
        teamTwo: null,
        totalEntries: 0,
        users: new Set(),
        totalNetAmount: 0,
        settledAt: r.created_at,
      });
    }
    const g = groups.get(key);
    g.totalEntries += 1;
    g.users.add(String(r.user_id));
    g.totalNetAmount = round2(g.totalNetAmount + netOf(r));
    if (r.created_at && new Date(r.created_at) > new Date(g.settledAt)) g.settledAt = r.created_at;
  }

  // Match ka naam bets se — ledger me sirf ids hote hain
  const bets = await SportsBet.findAll({
    where: { match_id: { [Op.in]: [...new Set(live.map((r) => String(r.match_id)))] } },
    attributes: ["match_id", "market_type", "match_title", "team_one", "team_two"],
    raw: true,
  });
  for (const b of bets) {
    const g = groups.get(`${b.match_id}|${b.market_type || ""}`);
    if (g && !g.matchTitle) {
      g.matchTitle = b.match_title || null;
      g.teamOne = b.team_one || null;
      g.teamTwo = b.team_two || null;
    }
  }

  let data = [...groups.values()].map((g) => ({
    matchId: g.matchId,
    marketType: g.marketType,
    eventId: g.eventId,
    matchTitle: g.matchTitle,
    teamOne: g.teamOne,
    teamTwo: g.teamTwo,
    totalEntries: g.totalEntries,
    totalUsers: g.users.size,
    totalNetAmount: g.totalNetAmount,
    settledAt: g.settledAt,
  }));

  const term = String(search || "").trim().toLowerCase();
  if (term) {
    data = data.filter((m) =>
      [m.matchId, m.marketType, m.matchTitle, m.teamOne, m.teamTwo]
        .some((v) => String(v ?? "").toLowerCase().includes(term))
    );
  }

  return { windowHours: VOID_WINDOW_HOURS, data: data.slice(off, off + lim) };
};

/**
 * Ek market ke andar ki settlement entries (har user ki apni row).
 * Void ki unit yahi row hai, isliye ek row = ek ledger entry.
 */
export const listSettledBets = async ({ matchId, marketType }) => {
  if (!matchId) throw new Error("match_id is required");

  const rows = await CreditsLedger.findAll({
    where: {
      ...SETTLEMENT_WHERE,
      match_id: String(matchId),
      ...(marketType ? { market_type: marketType } : {}),
      created_at: { [Op.gte]: since() },
    },
    order: [["id", "DESC"]],
    raw: true,
  });
  if (!rows.length) return [];

  const voided = await voidedLedgerIds(rows);
  const live = rows.filter((r) => !voided.has(Number(r.id)));
  if (!live.length) return [];

  const userIds = [...new Set(live.map((r) => Number(r.user_id)))];
  const users = await User.findAll({
    where: { user_id: { [Op.in]: userIds } },
    attributes: ["user_id", "username"],
    raw: true,
  });
  const nameOf = new Map(users.map((u) => [Number(u.user_id), u.username]));

  const marketBets = await SportsBet.findAll({
    where: {
      match_id: String(matchId),
      ...(marketType ? { market_type: marketType } : {}),
      user_id: { [Op.in]: userIds },
    },
    raw: true,
  });

  return live.map((r) => {
    const mine = marketBets.filter((b) => Number(b.user_id) === Number(r.user_id));
    const anchor = mine.find((b) => Number(b.id) === Number(r.bet_id)) || mine[0] || null;
    return {
      ledgerId: Number(r.id),
      betId: Number(r.bet_id || anchor?.id || 0),
      userId: Number(r.user_id),
      username: nameOf.get(Number(r.user_id)) || `user_${r.user_id}`,
      // Ek ledger row poore market ko cover kar sakti hai (MO/BM) ya ek hi bet ko
      // (fancy/oddeven) — dono soorat me user ko saaf dikhe.
      selectionName: mine.length > 1 ? `${mine.length} bets` : (anchor?.selection_name || "-"),
      betType: anchor?.bet_type || "-",
      odds: anchor?.odds ?? null,
      stakeAmount: mine.reduce((s, b) => s + Number(b.stake_amount || 0), 0),
      netamount: netOf(r),
      cashDelta: round2(Number(r.netamount || 0)),
      resultStatus: netOf(r) > 0 ? "won" : netOf(r) < 0 ? "loss" : "settled",
      betCount: mine.length,
      settledAt: r.created_at,
    };
  });
};

/**
 * Ek settlement ledger row ko ulta karo (ek user ka ek market/bet).
 * Transaction ke andar sab; points chain commit ke baad (uska apna tx hai).
 */
export const voidSettledLedgerEntry = async (ledgerId, outerTx = null, { writeStatement = true } = {}) => {
  const id = Number(ledgerId);
  if (!Number.isFinite(id) || id <= 0) throw new Error("ledger_id is required");

  const transaction = outerTx || (await sequelize.transaction());
  let summary;
  try {
    const row = await CreditsLedger.findOne({
      where: { id, ...SETTLEMENT_WHERE },
      lock: transaction.LOCK.UPDATE,
      transaction,
    });
    if (!row) throw new Error(`Settlement entry ${id} not found (already voided?)`);
    if (!row.created_at || new Date(row.created_at) < since()) {
      throw new Error(
        `Settlement is older than ${VOID_WINDOW_HOURS}h — it can only be voided within ${VOID_WINDOW_HOURS} hours`
      );
    }

    // Ek settlement DO baar void nahi ho sakti.
    //
    // List voided rows ko chhupa deti hai, isliye click se ye normally hota hi
    // nahi — par ek PURANA khula admin page (list void se pehle load hui thi),
    // double-click, ya seedha dobara bheja gaya request wahi ledger_id le aata
    // hai. Bina guard ke paisa DOBARA ulta ho jaata tha: 100000 ki ek settlement
    // par dry run me user ka wallet 1000 se -99000 chala gaya. voidSettledMarket
    // ye filter apne level par pehle se karta hai; single-entry raasta nahi karta tha.
    //
    // Silent void (writeStatement=false) me settlement row hi delete ho jaati hai,
    // to dobara call par upar wala "not found" pehle hi pakad leta hai.
    if ((await voidedLedgerIds([row.get({ plain: true })])).has(id)) {
      throw new Error(`Settlement ${id} is already voided`);
    }

    const userId = Number(row.user_id);
    const net = netOf(row);

    const wallet = await Wallet.findOne({
      where: { user_id: String(userId) },
      lock: transaction.LOCK.UPDATE,
      transaction,
    });
    if (!wallet) throw new Error(`Wallet not found for user ${userId}`);

    const cashBefore = Number(wallet.cash || 0);
    const inrBefore = Number(wallet.inr_balance || 0);
    await wallet.update(
      { cash: round2(cashBefore - net), inr_balance: round2(inrBefore - net) },
      { transaction }
    );

    const counters = { profit: -net };
    if (net > 0) counters.net_win = -net;
    else if (net < 0) counters.net_loss = -net;
    await User.increment(counters, { where: { user_id: userId }, transaction });

    // Is row se judi bets — doosri settlement rows jin bets ko cover karti hain
    // unhe chhod do (fancy/oddeven me ek market par kai rows hoti hain).
    const sameMarket = await CreditsLedger.findAll({
      where: {
        ...SETTLEMENT_WHERE,
        user_id: String(userId),
        match_id: row.match_id,
        market_type: row.market_type,
        id: { [Op.ne]: id },
      },
      attributes: ["bet_id"],
      raw: true,
      transaction,
    });
    const claimedByOthers = sameMarket.map((r) => Number(r.bet_id)).filter(Boolean);

    // Ye void SIRF settle ho chuki bets ko chhoo sakta hai.
    //
    // Pehle ye filter sirf (user, match, market_type) tha. MO/BM par theek hai —
    // ek ledger row poore market ko cover karti hai. Lekin fancy family me ek
    // match par market_type ek hi ('fancy1') hota hai aur us ke andar dozens
    // ALAG-ALAG sessions hote hain, jinme se kai abhi OPEN hote hain. Un open
    // bets ko yahan 'void' mark kar dena do tarah se galat tha: live bet mar
    // jaati thi, aur uski user_exposures rows koi delete nahi karta — matlab
    // paisa hamesha ke liye block. (Wahi class ka bug jisne bet 1907 ka 10000
    // phansaya tha.) Open bet kabhi kisi settlement row me thi hi nahi.
    const settledOnly = {
      status: "closed",
      result_status: { [Op.in]: SETTLED_RESULT_STATUSES },
    };

    // Per-selection market me ledger row apni EK bet reverse karti hai, isliye
    // usi bet tak simat jao. MO/BM me ek row poore market ki hoti hai aur
    // bet_id sirf representative hota hai — wahan market-wide hi rehna hai.
    const scopeToOwnBet =
      isPerSelectionMarket(row.market_type) && Number(row.bet_id || 0) > 0;

    // Read the bets BEFORE the update — afterwards their status/result_status
    // are the POST values and the pre-state is unrecoverable.
    const betsBeforeVoid = await SportsBet.findAll({
      where: {
        user_id: userId,
        match_id: row.match_id,
        ...(row.market_type ? { market_type: row.market_type } : {}),
        ...settledOnly,
        ...(scopeToOwnBet
          ? { id: Number(row.bet_id) }
          : (claimedByOthers.length ? { id: { [Op.notIn]: claimedByOthers } } : {})),
      },
      transaction,
    });

    const [betsVoided] = await SportsBet.update(
      { result_status: "void", status: "closed", updated_at: new Date() },
      {
        where: {
          user_id: userId,
          match_id: row.match_id,
          ...(row.market_type ? { market_type: row.market_type } : {}),
          ...settledOnly,
          ...(scopeToOwnBet
            ? { id: Number(row.bet_id) }
            : (claimedByOthers.length ? { id: { [Op.notIn]: claimedByOthers } } : {})),
        },
        transaction,
      }
    );

    // Ulti ledger entry — original kabhi delete nahi hoti.
    //
    // ...sirf writeStatement ON par. Admin ke void dialog ka switch OFF ho to
    // statement me void ka koi nishaan nahi chahiye: tab ulti entry likhne ke
    // bajaye ASLI settlement row hi mita di jaati hai (paisa dono soorat me
    // ek hi tarah wapas jaata hai, sirf trail ka farq hai).
    if (writeStatement) {
      await CreditsLedger.create(
        {
          user_id: String(userId),
          currency: "INR",
          amount: -Number(row.netamount || 0),
          reason: "settlement_void",
          description: withVoidSuffix(row.description || `${row.match_id} / ${row.market_type || ""}`),
          netamount: -Number(row.netamount || 0),
          closing: round2(cashBefore - net),
          market_type: row.market_type || null,
          sport_id: row.sport_id || null,
          eventid: row.eventid || null,
          match_id: row.match_id || null,
          ...(net > 0 ? { profit: -net } : { loss: -net }),
          bet_id: row.bet_id || null,
          category: "SPORTS",
          points_applied: true,
          // Original row se pakka link — isi se list voided settlements ko chhupati hai
          meta: { reverses_ledger_id: id },
        },
        { transaction }
      );
    } else {
      await row.destroy({ transaction });
    }

    // Is settlement par lagi win commission bhi wapas (docs/plans/2026-09-09-sports-win-commission.md).
    // Commission row apne settlement row ko meta.commission_of_ledger_id se pehchaanti hai;
    // ek baar void ho chuki (commission_void row with meta.reverses_ledger_id) dobara nahi.
    let commissionVoided = 0;
    let commissionRemark = null;
    let commissionSportId = null;
    let commissionGtype = null;
    const commRows = await CreditsLedger.findAll({
      where: {
        user_id: String(userId),
        category: "SPORTS",
        reason: COMMISSION_REASON,
        [Op.and]: [sequelize.literal(`(meta->>'commission_of_ledger_id') = '${Number(id)}'`)],
      },
      order: [["id", "ASC"]],
      lock: transaction.LOCK.UPDATE,
      transaction,
    });
    for (const c of commRows) {
      const alreadyVoided = await CreditsLedger.findOne({
        where: {
          user_id: String(userId),
          reason: COMMISSION_VOID_REASON,
          [Op.and]: [sequelize.literal(`(meta->>'reverses_ledger_id') = '${Number(c.id)}'`)],
        },
        attributes: ["id"],
        transaction,
      });
      if (alreadyVoided) continue;
      const comm = round2(Math.abs(Number(c.netamount ?? c.commission ?? 0)));
      if (!(comm > 0)) continue;

      commissionVoided = round2(commissionVoided + comm);
      commissionRemark = c.description || null;
      commissionSportId = c.sport_id || null;
      commissionGtype = c.meta?.gtype || null;

      // wallet + counters ulte (commission ek user LOSS thi)
      await wallet.update(
        {
          cash: round2(Number(wallet.cash || 0) + comm),
          inr_balance: round2(Number(wallet.inr_balance || 0) + comm),
        },
        { transaction }
      );
      await User.increment({ net_loss: comm, profit: comm }, { where: { user_id: userId }, transaction });

      if (writeStatement) {
        await CreditsLedger.create(
          {
            user_id: String(userId),
            currency: "INR",
            amount: comm,
            reason: COMMISSION_VOID_REASON,
            description: withVoidSuffix(c.description || ""),
            netamount: comm,
            closing: round2(Number(wallet.cash || 0)),
            market_type: c.market_type || null,
            sport_id: c.sport_id || null,
            eventid: c.eventid || null,
            match_id: c.match_id || null,
            loss: comm, // reverses the commission row's loss = -comm
            bet_id: c.bet_id || null,
            category: "SPORTS",
            points_applied: true,
            meta: { reverses_ledger_id: Number(c.id), commission_of_ledger_id: Number(id) },
          },
          { transaction }
        );
      } else {
        await c.destroy({ transaction });
      }
    }

    summary = {
      ledgerId: id,
      writeStatement,
      userId,
      matchId: String(row.match_id || ""),
      marketType: row.market_type || "",
      betId: Number(row.bet_id || 0),
      net,
      betsVoided,
      cashBefore,
      cashAfter: round2(cashBefore - net + commissionVoided),
      inrBefore,
      inrAfter: round2(inrBefore - net + commissionVoided),
      commissionVoided,
      commissionRemark,
      commissionSportId,
      commissionGtype,
    };

    // Settle ho chuki bet par exposure row hoti hi nahi, to ye normally no-op
    // hai — yahan SELF-HEAL ke liye hai. Agar kisi purane void ne snapshot
    // stale chhod diya tha (jaise saluser1 par -1100), to us user ko agli baar
    // chhune par wo apne aap sahi ho jaata hai. Caller ke tx ke andar chalta
    // hai taaki market-level void me har row ke saath atomically commit ho.
    const totalExposureAfter = await recalcTotalExposure(userId, transaction);

    // Audit — inside the caller's transaction, so a market-level void that
    // rolls back leaves no rows claiming any of its entries succeeded.
    // `net` is the settlement P/L being reversed: cash and inr BOTH move by it,
    // unlike an open-bet void which only releases a cash lock. Recorded as
    // refund_amount so the report shows what the operation actually moved.
    await recordVoidAudit({
      voidGroupId: newVoidGroupId(),
      voidType: VOID_TYPES.AFTER_SETTLEMENT,
      bets: betsBeforeVoid,
      representativeBetId: Number(row.bet_id) || null,
      before: {
        cash: cashBefore,
        inr: inrBefore,
        totalExposure: null, // settled bets hold no exposure row to read
      },
      after: {
        status: "closed",
        resultStatus: "void",
        cash: summary.cashAfter,
        inr: summary.inrAfter,
        totalExposure: totalExposureAfter,
      },
      refundAmount: -net,
      ledgerId: id,
      context: {
        // Audit hamesha likhti hai — silent void par bhi. Statement se rows hat
        // jaati hain, par yahan (aur activity log me) poora trail rehta hai.
        note: `settlement void — reverses credits_ledger #${id} (net ${net})`
          + (commissionVoided > 0 ? `; commission ${commissionVoided} refunded` : "")
          + (writeStatement ? "" : "; SILENT (statement entries deleted)"),
      },
    }, transaction);

    if (!outerTx) await transaction.commit();
  } catch (error) {
    if (!outerTx) await transaction.rollback();
    throw error;
  }

  // all_point reversal ka apna transaction hai. Agar hum kisi bade (market wale)
  // transaction ke andar chal rahe hain to use YAHAN nahi chala sakte — wo usi
  // wallet row par lock maangega jo abhi hamare tx ke paas hai → deadlock.
  // Us soorat me caller commit ke baad reversePointsAndEmit() chalata hai.
  if (outerTx) return summary;
  return { ...summary, points: await reversePointsAndEmit(summary) };
};

// all_point chain ulti + user ko fresh balance push — dono commit ke BAAD
export const reversePointsAndEmit = async (summary) => {
  if (!summary?.betId) return { success: true, skipped: true, reason: "no bet_id on ledger row" };

  // Silent void (statement switch OFF): points ki ulti entry likhne ke bajaye
  // ASLI entries mita do — settlement ki bhi, commission ki bhi. Wallet se
  // utna hi point ghatta hai, bas statement me koi line nahi bachti.
  if (summary.writeStatement === false) {
    const del = await WalletService.deletePointEntries(
      pointEntryRef.bet(POINT_CATEGORY.SPORTS, summary.betId)
    );
    if (!del.success) console.error("[sportsVoid] point delete failed:", summary.betId, del.error);
    if (Number(summary.commissionVoided) > 0) {
      const cdel = await WalletService.deletePointEntries(
        pointEntryRef.commission(POINT_CATEGORY.SPORTS, summary.betId)
      );
      if (!cdel.success) console.error("[sportsVoid] commission point delete failed:", summary.betId, cdel.error);
      del.commission = cdel;
    }
    try {
      const fresh = await Wallet.findOne({ where: { user_id: String(summary.userId) }, raw: true });
      emitBalanceUpdate(summary.userId, { inr_balance: fresh?.inr_balance, cash: fresh?.cash });
    } catch (err) {
      console.error("[sportsVoid] balance emit failed:", summary.userId, err.message);
    }
    return del;
  }

  const res = await WalletService.reverseAllPointHierarchy(summary.betId, POINT_CATEGORY.SPORTS);
  if (!res.success) console.error("[sportsVoid] point reversal failed:", summary.betId, res.error);
  // Commission ke points bhi ulte (settlement chain jaisa hi)
  if (Number(summary.commissionVoided) > 0) {
    const cres = await WalletService.reverseCommissionPoints({
      betId: summary.betId,
      userId: summary.userId,
      amount: summary.commissionVoided,
      remark: withVoidSuffix(summary.commissionRemark || ""),
      sportId: summary.commissionSportId,
      gtype: summary.commissionGtype,
    });
    if (!cres.success) console.error("[sportsVoid] commission point reversal failed:", summary.betId, cres.error);
    res.commission = cres;
  }
  try {
    const fresh = await Wallet.findOne({ where: { user_id: String(summary.userId) }, raw: true });
    emitBalanceUpdate(summary.userId, { inr_balance: fresh?.inr_balance, cash: fresh?.cash });
  } catch (err) {
    console.error("[sportsVoid] balance emit failed:", summary.userId, err.message);
  }
  return res;
};

/**
 * Poore market ki saari settlement entries void — har user ke liye.
 * Sab ek hi transaction me: aadha voided market wallet aur ledger ko alag-alag
 * kahaniyan sunane lagta.
 */
export const voidSettledMarket = async ({ matchId, marketType, writeStatement = true }) => {
  if (!matchId) throw new Error("match_id is required");

  const rows = await CreditsLedger.findAll({
    where: {
      ...SETTLEMENT_WHERE,
      match_id: String(matchId),
      ...(marketType ? { market_type: marketType } : {}),
      created_at: { [Op.gte]: since() },
    },
    order: [["id", "ASC"]],
    raw: true,
  });
  const alreadyVoided = await voidedLedgerIds(rows);
  const pending = rows.filter((r) => !alreadyVoided.has(Number(r.id)));
  if (!pending.length) {
    throw new Error(
      rows.length
        ? "This market is already voided"
        : `No settlement entries found for this market in the last ${VOID_WINDOW_HOURS}h`
    );
  }

  const transaction = await sequelize.transaction();
  const summaries = [];
  try {
    for (const r of pending) {
      summaries.push(await voidSettledLedgerEntry(r.id, transaction, { writeStatement }));
    }
    await transaction.commit();
  } catch (error) {
    await transaction.rollback();
    throw error;
  }

  // Commit ke baad hi points/socket — warna wallet lock par deadlock
  for (const s of summaries) {
    s.points = await reversePointsAndEmit(s);
  }

  return {
    affectedUsers: new Set(summaries.map((s) => s.userId)).size,
    entries: summaries.length,
    summaries,
  };
};

export default {
  listSettledMarkets,
  listSettledBets,
  voidSettledLedgerEntry,
  voidSettledMarket,
};
