// Admin Account Statement (Game Report) ki har game row ke saamne Excel icon —
// click par us row ke PEECHE ke saare bets ek CSV me utar jaate hain.
//
// Row -> bets ka rishta wahi hai jo user panel ke Result modal me hai, isliye
// dono resolvers UserStatementService se hi reuse ho rahe hain (win/loss ka
// hisaab, winner, void detection — sab ek hi jagah, do jagah drift nahi hoga):
//   CASINO row -> us bet ka round_id -> us round ke saare bets
//   SPORTS row -> us bet ka match_id + eventid (+ fancy) -> us market ke bets
// point_ledger.bet_id casino me exact bet id hota hai aur sports me market ki
// PEHLI bet id — dono case me ek hi bet se poora group mil jaata hai.
import CasinoBet from '../../model/user/casino.js';
import SportsBet from '../../model/user/SportsBet.js';
import User from '../../model/user/User.js';
import UserStatementService from '../user/UserStatementService.js';
import { getUserIdsByHierarchy } from '../../helper/getuserids.js';

// Reference panel ke download ka exact column order — naam bhi wahi (case sameet),
// warna client ki purani sheets/macros match nahi karengi.
export const BET_EXPORT_COLUMNS = [
  'UserName', 'nation', 'userrate', 'bettype', 'amount', 'winloss', 'ismatched',
  'placedate', 'IpAddress', 'Nationjson', 'bhav', 'cname', 'userbalrate',
];

// placedate reference me "20/09/2026 22:12:12.553" hai — yaani IST wall clock
// with milliseconds. created_at timestamptz hai aur is box ka local time Europe
// hai, isliye timeZone EXPLICIT dete hain; warna CSV table se 3:30 ghante
// peeche dikhta.
const IST = 'Asia/Kolkata';
const fmtPlaceDate = (value) => {
  if (!value) return '';
  const d = new Date(value);
  if (isNaN(d)) return '';
  const p = new Intl.DateTimeFormat('en-GB', {
    timeZone: IST, day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false,
  }).formatToParts(d).reduce((a, x) => { a[x.type] = x.value; return a; }, {});
  const ms = String(d.getMilliseconds()).padStart(3, '0');
  return `${p.day}/${p.month}/${p.year} ${p.hour}:${p.minute}:${p.second}.${ms}`;
};

const num = (v) => (v == null || v === '' ? '' : String(Math.round(Number(v) * 100) / 100));

/**
 * Statement row -> uske peeche ke bets. CSV download aur Details modal dono
 * yahin se guzarte hain, taaki "kaun si bets" aur "kya ye mera downline hai"
 * ka jawab ek hi jagah tay ho.
 * @param {Object} requester - { role, username }  (login wala staff/owner)
 * @param {Object} params    - { betId, category } (statement row se)
 * @returns {Object} { success, category, betId, groupKey, user, target, detail }
 */
export const resolveStatementRowBets = async (requester, params = {}) => {
  const betId = Number(params.betId);
  const category = String(params.category || '').toUpperCase();
  if (!betId) return { success: false, message: 'betId required' };
  if (category !== 'CASINO' && category !== 'SPORTS') {
    return { success: false, message: 'Only SPORTS and CASINO rows can be exported' };
  }

  // 1. Row ka bet -> uska malik (kisne lagaya) aur group ki pehchaan
  let ownerUserId = null;
  let groupKey = null;
  if (category === 'CASINO') {
    const bet = await CasinoBet.findOne({ where: { id: betId }, raw: true });
    if (!bet) return { success: false, message: 'Bet not found' };
    ownerUserId = Number(bet.user_id);
    groupKey = { roundId: bet.round_id != null ? String(bet.round_id) : null, betId };
  } else {
    const bet = await SportsBet.findOne({ where: { id: betId }, raw: true });
    if (!bet) return { success: false, message: 'Bet not found' };
    ownerUserId = Number(bet.user_id);
    groupKey = {
      matchId: bet.match_id,
      eventId: bet.eventid,
      // FAN par market ka naam fancy_name me hota hai (khado par selection_name
      // me) — resolver dono par match karta hai, isliye jo bhara ho wahi bhejo.
      fancyName: String(bet.game_type || '').toUpperCase() === 'FAN'
        ? (bet.fancy_name && bet.fancy_name !== 'NULL' ? bet.fancy_name : bet.selection_name)
        : null,
    };
  }

  // 2. Hierarchy guard — bet lagane wala mere downline me hai ya nahi.
  // (statement khud username se wallet uthata hai; download uske aage jaakar
  // dusre ki bet detail na de de, isliye yahan explicit check.)
  const downline = await getUserIdsByHierarchy(requester.role, requester.username);
  if (!downline.map(Number).includes(ownerUserId)) {
    return { success: false, status: 403, message: 'Not your downline user' };
  }

  const user = await User.findOne({
    where: { user_id: ownerUserId },
    attributes: ['user_id', 'username', 'percentage'],
    raw: true,
  });
  const target = { id: ownerUserId, username: user?.username || null };

  // 3. Wahi resolver jo user panel ka Result modal use karta hai
  const detail = category === 'CASINO'
    ? await UserStatementService.getStatementCasinoBets(target, groupKey)
    : await UserStatementService.getStatementMarketBets(target, groupKey);

  if (!detail?.success) return { success: false, message: detail?.message || 'No bets found' };
  return { success: true, category, betId, groupKey, user, target, detail };
};

/**
 * Ek statement row ke peeche ke bets nikaal kar CSV rows bana do.
 * @param {Object} requester - { role, username }  (login wala staff/owner)
 * @param {Object} params    - { betId, category } (statement row se)
 * @returns {Object} { success, filename, columns, rows }
 */
export const buildStatementBetExport = async (requester, params = {}) => {
  const resolved = await resolveStatementRowBets(requester, params);
  if (!resolved.success) return resolved;
  const { category, betId, groupKey, user, target, detail } = resolved;
  const bets = detail.bets || [];

  // 4. Reference CSV shape
  //   userrate = jis price par bet lagi (reference casino row: Dragon @2 -> "2");
  //              run-wale fancy me ye rate hota hai (size, aam taur par 100)
  //   bhav     = fancy ki RUN line (223) — sirf run-wale fancy markets me
  //   cname    = currency (reference casino row: "INR")            [best guess]
  //   userbalrate = client ka User Rate % (users.percentage)       [best guess]
  //   Nationjson = reference sample me khaali tha, isliye khaali hi chhoda
  const rate = user?.percentage != null ? String(user.percentage) : '';
  const rows = bets.map((b) => {
    const isCasino = category === 'CASINO';
    const odds = Number(b.odds) || 0;
    const fancy = !isCasino && String(b.game_type || '').toUpperCase() === 'FAN';
    // FAN me odds/size ke do bilkul ulte matlab hain:
    //   fancy1 / oddeven -> odds = decimal price (1.95), size = VOLUME (5 lakh)
    //   baaki (Normal, khado, meter, *Line*) -> odds = RUN line (223), size = rate (100)
    // Isliye run-wale markets me price size se aata hai aur line bhav me jaati hai.
    const mt = String(b.market_type || '').toLowerCase();
    const runMarket = fancy && mt !== 'fancy1' && mt !== 'oddeven';
    const price = runMarket ? (Number(b.size) || 100) : odds;
    return [
      target.username || '',
      (isCasino ? b.selection : (b.fancy_name && b.fancy_name !== 'NULL' ? b.fancy_name : b.selection_name)) || '',
      num(price),
      String(isCasino ? (b.type || '') : (b.bet_type || '')).toLowerCase(),
      num(isCasino ? b.stake : b.stake_amount),
      b.win == null ? '' : num(b.win),
      isCasino ? 'True' : (b.unmatched ? 'False' : 'True'),
      fmtPlaceDate(b.created_at),
      b.ip_address || '',
      '',
      runMarket ? num(odds) : '',
      (isCasino ? 'INR' : (b.original_currency || 'INR')),
      rate,
    ];
  });

  // filename: kis client ki, kis round/market ki sheet hai — dono dikhe
  const stamp = groupKey.roundId || groupKey.matchId || betId;
  const filename = `${(target.username || 'bets').replace(/[^\w.-]/g, '')}-${String(stamp).replace(/[^\w.-]/g, '')}.csv`;

  return { success: true, filename, columns: BET_EXPORT_COLUMNS, rows };
};

const isBlank = (v) => v == null || String(v).trim() === '' || String(v).trim().toLowerCase() === 'null';
const n2 = (v) => (v == null || v === '' ? null : Math.round(Number(v) * 100) / 100);

/**
 * Account Statement ki game row par click -> "Details" modal ka data.
 * Wahi bets jo CSV me jaate hain, bas modal ke shape me (breadcrumb, winner,
 * game time + har bet ka side / win / deleted).
 * Nation / Rate / Bhav ke niyam user panel ke Result modal wale hi hain
 * (frontend StatementResultModal): fancy1 / oddeven me bhav nahi hota, khado
 * me Nation "<market>-<span>" aur Bhav = span.
 * @returns {Object} { success, breadcrumb, winner, gameTime, casino, totalBets, totalWin, bets }
 */
export const buildStatementBetDetail = async (requester, params = {}) => {
  const resolved = await resolveStatementRowBets(requester, params);
  if (!resolved.success) return resolved;
  const { category, target, detail } = resolved;
  const isCasino = category === 'CASINO';
  const header = detail.header || {};

  const crumbs = isCasino
    ? ['Casino', header.gamename, header.roundId]
    : [header.sportName, header.competitionName, header.matchTitle, header.marketType];
  const breadcrumb = crumbs.filter((p) => !isBlank(p) && p !== '-').join(' -> ');

  const bets = (detail.bets || []).map((b) => {
    const base = {
      id: b.id,
      username: target.username || '',
      win: b.win == null ? null : n2(b.win),
      date: b.created_at || null,
      ip: b.ip_address || '',
      browser: b.browser || '',
      side: b.side || null,
      deleted: !!b.deleted,
    };
    if (isCasino) {
      return { ...base, nation: b.selection || '', rate: n2(b.odds), bhav: null, amount: n2(b.stake) };
    }

    const mt = String(b.market_type || '').toLowerCase();
    const khado = mt === 'khado';
    const badlo = b.badlo === true || String(b.badlo) === 'true';
    let nation = [b.fancy_name, b.selection_name].find((v) => !isBlank(v)) ?? '';
    if (khado && !isBlank(b.selection_name)) {
      nation = isBlank(b.fancy_name) ? b.selection_name : `${b.selection_name}-${b.fancy_name}`;
    }
    let bhav = null;
    if (khado) bhav = isBlank(b.fancy_name) ? null : b.fancy_name;
    else if (mt !== 'fancy1' && mt !== 'oddeven') bhav = Number(b.size) ? n2(b.size) : null;

    return {
      ...base,
      nation,
      rate: n2(b.odds),
      bhav,
      amount: n2(b.stake_amount),
      // oddeven me lay side nahi hota — Odd aur Even dono back hain
      side: mt === 'oddeven' ? 'BACK' : base.side,
      badlo,
    };
  });

  return {
    success: true,
    breadcrumb,
    winner: detail.winner ?? null,
    gameTime: header.gameTime || null,
    // CASINO row: round ka result (cards) admin panel detail-results se khud
    // uthata hai — uske liye game code (= detail-results ka `type`) + round id.
    casino: isCasino
      ? { gameCode: header.gameCode || null, gameName: header.gamename || null, roundId: header.roundId || null }
      : null,
    totalBets: detail.totalBets || 0,
    totalWin: detail.totalWin || 0,
    bets,
  };
};

export default { resolveStatementRowBets, buildStatementBetExport, buildStatementBetDetail, BET_EXPORT_COLUMNS };
