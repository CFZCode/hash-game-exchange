// Admin casino Result modal: the logged-in admin's downline bets on one round,
// with Win / Deleted computed exactly like the Account Statement "Details"
// (helper/casinoBetResult.js). Read-only.
// Plan: docs/plans/2026-10-09-admin-casino-result-round-bets.md
import { Op } from 'sequelize';
import CasinoBet from '../../model/user/casino.js';
import User from '../../model/user/User.js';
import { getUserIdsByHierarchy } from '../../helper/getuserids.js';
import { casinoBetOutcome } from '../../helper/casinoBetResult.js';
import { UNDO_DELETED_GAMES, loadRefundedBetIds, loadUndoneBetIds } from '../../helper/casinoRefundedBets.js';

const round2 = (n) => (n == null || n === '' ? null : Math.round(Number(n) * 100) / 100);

/**
 * @param {Object} requester - { role, username } (logged-in staff / owner)
 * @param {Object} params    - { gameName, roundId } (feed type + round mid)
 * @returns {Object} { success, bets } | { success: false, status, message }
 *   bets: [{ id, username, nation, rate, amount, win, date, ip, browser, side, deleted }]
 */
export const getCasinoRoundBets = async (requester, { gameName, roundId } = {}) => {
  const game = String(gameName || '').trim();
  const round = String(roundId || '').trim();
  // round_id is BIGINT — anything else can't match a round
  if (!game || !/^\d+$/.test(round)) {
    return { success: false, status: 400, message: 'gameName and a numeric roundId are required' };
  }

  // Same downline scope as the statement bet detail
  const downline = await getUserIdsByHierarchy(requester.role, requester.username);
  if (!downline.length) return { success: true, bets: [] };

  const allRows = await CasinoBet.findAll({
    where: {
      game_name: game,
      round_id: round,
      user_id: { [Op.in]: downline },
    },
    order: [['created_at', 'ASC'], ['id', 'ASC']],
    raw: true,
  });
  // Roulette: bets the player undid are not listed (helper/casinoRefundedBets.js)
  // — except Beach Roulette, where they stay and land under "Deleted" (a void
  // with no refund row is deleted in casinoBetOutcome), like the reference.
  const undone = UNDO_DELETED_GAMES.has(game.toLowerCase())
    ? new Set()
    : await loadUndoneBetIds(allRows);
  const rows = allRows.filter((b) => !undone.has(String(b.id)));
  if (!rows.length) return { success: true, bets: [] };

  const users = await User.findAll({
    where: { user_id: { [Op.in]: [...new Set(rows.map((b) => b.user_id))] } },
    attributes: ['user_id', 'username'],
    raw: true,
  });
  const nameOf = new Map(users.map((u) => [String(u.user_id), u.username]));

  const refunded = await loadRefundedBetIds(rows);
  const bets = rows.map((b) => {
    const { side, win, deleted } = casinoBetOutcome(b, { refunded: refunded.has(String(b.id)) });
    return {
      id: b.id,
      username: nameOf.get(String(b.user_id)) || '',
      nation: b.selection || '',
      // Display name as placed ("Bahar A/136" on Andar Bahar 150 — the deal
      // position). Additive; the admin result modal shows it for ab4.
      player_name: b.player_name || '',
      // Market of the bet ("match" / "fancy" …): tells same-named runners apart
      // in display, e.g. Teenpatti 1-day Main vs Consecutive "Player A". Additive.
      mtype: b.mtype || '',
      rate: round2(b.odds),
      amount: round2(b.stake),
      win,
      date: b.created_at || null,
      ip: b.ip_address || '',
      browser: b.browser || '',
      side,
      deleted,
    };
  });

  return { success: true, bets };
};
