

import Staff from '../../model/admin/Staff.js';
import Wallet from '../../model/admin/Wallet.js';
import { blacklistToken } from '../../helper/tokenBlacklist.js';
import PasswordService from '../passwordService.js';
import GoogleAuthService from '../user/GoogleAuthService.js';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import { getUserIdsByHierarchy } from '../../helper/getuserids.js';
import { calculateMaxWinExposure } from '../../helper/netExposureHelper.js';
import { memoise } from '../../helper/ttlMemo.js';
import { MESSAGES } from '../../constants/messages.js';
import { isLoginLockedInChain } from '../../helper/accountLockChain.js';
import { emitAdminForceLogout } from '../../utils/socketUtils.js';

const StaffAuthService = {
  // 🧩 Secure Staff Login
  login: async (identifier, password, deviceId) => {
    try {
      // 1️⃣ Input validation
      if (!identifier || !password) {
        throw new Error(MESSAGES.AUTH.CREDENTIALS_REQUIRED);
      }

      // 2️⃣ Find staff by email OR username
      const { Op } = (await import('sequelize')); // Dynamic import if not available globally

      const staff = await Staff.findOne({
        where: {
          [Op.or]: [
            { email: { [Op.iLike]: identifier } },
            { username: { [Op.iLike]: identifier } }
          ]
        }
      });

      if (!staff) {
        throw new Error(MESSAGES.ADMIN.AUTH.ACCOUNT_NOT_AVAILABLE);
      }

      // Transaction code limit reached → account reads as not found until
      // the parent changes its password (resets attempts to 10).
      if (staff.txn_password_attempts === 0 && String(staff.role).toUpperCase() !== 'OWNER') {
        throw new Error(MESSAGES.ADMIN.AUTH.ACCOUNT_NOT_AVAILABLE);
      }

      // Locked = this staff (OWNER-role rows exempt) or any staff above it is
      // inactive (helper/accountLockChain.js).
      if (await isLoginLockedInChain({ type: 'STAFF', id: staff.staff_id })) {
        throw new Error(MESSAGES.AUTH.USER_LOCKED_CONTACT_UPLINE);
      }

      // 3️⃣ Validate password
      const isMatch = await PasswordService.comparePassword(password, staff.password);
      if (!isMatch) {
        throw new Error(MESSAGES.ADMIN.AUTH.PASSWORD_INCORRECT);
      }

      // 3.5️⃣ Check 2FA — TOTP first: its codes come from an app the account
      // already holds ('google' = Authenticator, 'android' = our own Secure
      // Auth Verification App), so there is nothing to send and no OTP cache
      // entry to make. `method` tells the
      // client which prompt to render (and that Resend does not apply).
      if (GoogleAuthService.isTotpType(staff.securityAuthType) && staff.googleAuthSecret) {
        return {
          require2FA: true,
          // The real type, so the client can name the right app.
          method: staff.securityAuthType,
          staffId: staff.staff_id,
          message: MESSAGES.ADMIN.AUTH.OTP_SENT
        };
      }

      if (staff.telegram2FAEnabled && staff.telegramChatId) {
        const otp = Math.floor(100000 + Math.random() * 900000).toString();

        global.otpCache = global.otpCache || {};
        global.otpCache[`staff_${staff.staff_id}`] = { otp, expires: Date.now() + 5 * 60 * 1000 };

        const TelegramBotService = (await import('../user/TelegramBotService.js')).default;
        await TelegramBotService.sendMessage(staff.telegramChatId, MESSAGES.ADMIN.AUTH.TELEGRAM_STAFF_LOGIN_OTP(otp, staff.username));

        return {
          require2FA: true,
          method: 'telegram',
          staffId: staff.staff_id,
          message: MESSAGES.ADMIN.AUTH.OTP_SENT
        };
      }

      console.log('✅ Staff login:', {
        staff_id: staff.staff_id,
        role: staff.role,
        username: staff.username,
      });

      // 4️⃣ Establish the active session id (single-session enforcement).
      //    Same browser reuses its deviceId (not logged out); a different
      //    device overwrites login_id and invalidates the previous token.
      const sessionId = deviceId || crypto.randomUUID();
      const previousSessionId = staff.login_id;
      staff.login_id = sessionId;
      await staff.save();
      /* The write above just invalidated whatever token the previous device
         held (authMiddleware compares the JWT's `sid` against login_id). That
         screen had no way to know until its next request 401'd, which is why
         a takeover only showed up after a reload. Push to the OLD session's
         room now — the new client is still waiting on this response, so it is
         not in the room yet and cannot log itself out. Only when the session
         actually CHANGED: logging in again from the same browser reuses its
         deviceId, and kicking yourself would be wrong. Never blocks the login
         — the emit helpers swallow their own errors. */
      if (previousSessionId && previousSessionId !== sessionId) {
        await emitAdminForceLogout([staff.staff_id], MESSAGES.AUTH.SESSION_TAKEN_OVER);
      }

      // 5️⃣ Build JWT payload
      const payload = {
        actor: {
          type: "STAFF",
          id: staff.staff_id
        },
        account: {
          type: "STAFF",
          id: staff.staff_id
        },
        role: staff.role?.toUpperCase() || 'STAFF',
        level: staff.level || null,
        username: staff.username,
        permissions: null,
        sid: sessionId
      };


      // 6️⃣ Sign JWT safely
      const token = jwt.sign(payload, process.env.JWT_SECRET, {
        expiresIn: process.env.JWT_EXPIRATION || '1d',
      });

      return {
        token,
        staff: {
          id: staff.staff_id,
          username: staff.username,
          role: staff.role,
          first_login: staff.first_login,
        }
      };
    } catch (error) {
      console.error('❌ StaffAuthService.login error:', error.message);
      throw new Error(error.message || MESSAGES.ADMIN.AUTH.STAFF_LOGIN_FAILED);
    }
  },

  // 🔁 Re-send the login OTP
  //
  // The code is pushed as part of login(), so a refresh of the 2FA screen used
  // to leave the operator on a page with no way to get one — the only route was
  // signing in again. Takes the staffId the login response already returned, so
  // no credentials are stored client-side. Same `staff_<id>` cache key and same
  // 5-minute window as login, so the previous code is replaced, not duplicated.
  resend2FA: async (staffId) => {
    try {
      const staff = await Staff.findByPk(staffId);
      if (!staff) throw new Error(MESSAGES.ADMIN.AUTH.ACCOUNT_NOT_AVAILABLE);
      if (!staff.telegramChatId || !staff.telegram2FAEnabled) {
        throw new Error(MESSAGES.AUTH.TWO_FA_NOT_ENABLED);
      }

      const otp = Math.floor(100000 + Math.random() * 900000).toString();

      global.otpCache = global.otpCache || {};
      global.otpCache[`staff_${staff.staff_id}`] = { otp, expires: Date.now() + 5 * 60 * 1000 };

      const TelegramBotService = (await import('../user/TelegramBotService.js')).default;
      await TelegramBotService.sendMessage(staff.telegramChatId, MESSAGES.ADMIN.AUTH.TELEGRAM_STAFF_LOGIN_OTP(otp, staff.username));

      return true;
    } catch (error) {
      console.error('❌ StaffAuthService.resend2FA error:', error.message);
      throw new Error(error.message || MESSAGES.AUTH.OTP_RESEND_FAILED);
    }
  },

  // 🔐 Verify 2FA
  verify2FA: async (staffId, otp, deviceId) => {
    try {
      const staff = await Staff.findByPk(staffId);
      if (!staff) throw new Error(MESSAGES.ADMIN.AUTH.ACCOUNT_NOT_AVAILABLE);

      // Transaction code limit reached → account reads as not found until
      // the parent changes its password (resets attempts to 10).
      if (staff.txn_password_attempts === 0 && String(staff.role).toUpperCase() !== 'OWNER') {
        throw new Error(MESSAGES.ADMIN.AUTH.ACCOUNT_NOT_AVAILABLE);
      }

      // Re-checked here: the upline may have locked the account between the
      // password step and the code.
      if (await isLoginLockedInChain({ type: 'STAFF', id: staff.staff_id })) {
        throw new Error(MESSAGES.AUTH.USER_LOCKED_CONTACT_UPLINE);
      }

      // TOTP accounts never got an OTP pushed — the code is live in the
      // Authenticator / Secure Auth Verification App, so it is checked against
      // the stored secret and the otpCache is not involved at all.
      if (GoogleAuthService.isTotpType(staff.securityAuthType)) {
        if (!staff.googleAuthSecret) throw new Error(MESSAGES.AUTH.GOOGLE_AUTH_NOT_ENABLED);
        if (!GoogleAuthService.verifyCodeForType(staff.securityAuthType, staff.googleAuthSecret, otp)) {
          throw new Error(MESSAGES.AUTH.GOOGLE_AUTH_INVALID_CODE);
        }
      } else {
        const cacheKey = `staff_${staffId}`;
        const record = global.otpCache && global.otpCache[cacheKey];

        if (!record) throw new Error(MESSAGES.AUTH.OTP_EXPIRED_OR_NOT_REQUESTED);
        if (record.otp !== otp) throw new Error(MESSAGES.AUTH.INVALID_OTP);
        if (Date.now() > record.expires) {
          delete global.otpCache[cacheKey];
          throw new Error(MESSAGES.AUTH.OTP_EXPIRED);
        }

        delete global.otpCache[cacheKey];
      }

      console.log('✅ 2FA Verified:', staff.username);

      // Establish the active session id (single-session enforcement)
      const sessionId = deviceId || crypto.randomUUID();
      const previousSessionId = staff.login_id;
      staff.login_id = sessionId;
      await staff.save();
      /* The write above just invalidated whatever token the previous device
         held (authMiddleware compares the JWT's `sid` against login_id). That
         screen had no way to know until its next request 401'd, which is why
         a takeover only showed up after a reload. Push to the OLD session's
         room now — the new client is still waiting on this response, so it is
         not in the room yet and cannot log itself out. Only when the session
         actually CHANGED: logging in again from the same browser reuses its
         deviceId, and kicking yourself would be wrong. Never blocks the login
         — the emit helpers swallow their own errors. */
      if (previousSessionId && previousSessionId !== sessionId) {
        await emitAdminForceLogout([staff.staff_id], MESSAGES.AUTH.SESSION_TAKEN_OVER);
      }

      // 4️⃣ Build JWT payload
      const payload = {
        actor: {
          type: "STAFF",
          id: staff.staff_id
        },
        account: {
          type: "STAFF",
          id: staff.staff_id
        },
        role: staff.role?.toUpperCase() || 'STAFF',
        level: staff.level || null,
        username: staff.username,
        permissions: null,
        sid: sessionId
      };


      // 5️⃣ Sign JWT safely
      const token = jwt.sign(payload, process.env.JWT_SECRET, {
        expiresIn: process.env.JWT_EXPIRATION || '1d',
      });

      return {
        token,
        staff: {
          id: staff.staff_id,
          username: staff.username,
          role: staff.role,
          first_login: staff.first_login,
        }
      };

    } catch (error) {
      throw new Error(error.message || MESSAGES.AUTH.TWO_FA_FAILED);
    }
  },

  // opts.maxWinTtlMs > 0 → recently computed max-win reuse (sirf socket push).
  // REST caller kuch pass nahi karta, isliye use hamesha fresh snapshot milta hai.
  getProfile: async (staff_id, { maxWinTtlMs = 0 } = {}) => {
    try {
      const staff = await Staff.findByPk(staff_id, {
        attributes: { exclude: ['password'] },
      });

      if (!staff) {
        throw new Error(MESSAGES.ADMIN.AUTH.ACCOUNT_NOT_AVAILABLE);
      }

      // Downline MAX WIN = is staff ke poore downline users book se zyada se
      // zyada kitna jeet sakte hain (user +20 = hamara -20). Owner card
      // (buildOwnerProfile) jaisa hi figure, POSITIVE aata hai — Home card
      // use minus me dikhata hai. Users list ki staff row abhi bhi worst-case
      // snapshot sum dikhati hai, isliye card aur list jaan-boojh ke alag hain.
      const computeMaxWin = () =>
        getUserIdsByHierarchy(staff.role || 'STAFF', staff.username)
          .then((userIds) => calculateMaxWinExposure(userIds));

      // Wallet aur downline exposure independent hain — saath me chalte hain.
      const [wallet, totalExposure] = await Promise.all([
        Wallet.findOne({ where: { staff_id } }),
        maxWinTtlMs > 0
          ? memoise(staffMaxWinCache, String(staff_id), maxWinTtlMs, computeMaxWin)
          : computeMaxWin(),
      ]);

      const profileData = { ...staff.toJSON() };
      if (wallet) Object.assign(profileData, wallet.toJSON());

      // Ledger-system keys — owner V2 profile jaise hi names, dashboard inhi se map hai
      profileData.inr_balance = parseFloat(wallet?.inr_balance || 0);
      profileData.total_exposure = totalExposure;
      profileData.credit = parseFloat(wallet?.credit || 0);
      profileData.all_point = parseFloat(wallet?.all_point || 0);
      profileData.upper_point = parseFloat(wallet?.upper_point || 0);
      profileData.down_point = parseFloat(wallet?.down_point || 0);
      profileData.settlement_points = Math.round((parseFloat(wallet?.all_point || 0) - parseFloat(wallet?.credit || 0)) * 100) / 100;
      profileData.sports_pts = parseFloat(wallet?.sports_pts || 0);
      profileData.casino_pts = parseFloat(wallet?.casino_pts || 0);
      profileData.thirdparty_pts = parseFloat(wallet?.thirdparty_pts || 0);

        return profileData;
    } catch (error) {
      console.error('❌ StaffAuthService.getProfile error:', error.message);
      // login/verify2FA jaisa hi pattern — asli wajah aage jaati hai, fallback
      // tabhi lagta hai jab error ke paas message hi na ho.
      throw new Error(error.message || MESSAGES.ADMIN.AUTH.STAFF_PROFILE_FETCH_FAILED);
    }
  },

  // 🚪 Staff Logout
  logout: async (token) => {
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      await blacklistToken(token, new Date(decoded.exp * 1000));
      console.log(`🗑️ Token blacklisted for staff_id: ${decoded.staff_id}`);
    } catch (error) {
      console.error('❌ StaffAuthService.logout error:', error.message);
      throw new Error(MESSAGES.ADMIN.AUTH.STAFF_LOGOUT_FAILED);
    }
  },
};

// ─────────────────────────────────────────────────────────────────────────────
// Staff profile snapshot for the 2-second socket push (socket/socketHandler.js
// `subscribeOwnerProfile`, STAFF branch). Same cost model as the owner push
// (controller/admin/userController.js getOwnerProfileForSocket):
//   - whole snapshot → shared by a staff's open tabs for STAFF_PROFILE_TTL_MS
//   - max-win exposure (hierarchy walk + user_exposures aggregate) → at most
//     every STAFF_MAXWIN_TTL_MS
// GET /admin/staff/profile never goes through here, so REST stays fully fresh.
// ─────────────────────────────────────────────────────────────────────────────
const STAFF_MAXWIN_TTL_MS = 10000;
const STAFF_PROFILE_TTL_MS = 1500;

const staffMaxWinCache = new Map();   // staff_id -> { at, promise }
const staffProfileCache = new Map();  // staff_id -> { at, promise }

export const getStaffProfileForSocket = (staffId) =>
  memoise(staffProfileCache, String(staffId), STAFF_PROFILE_TTL_MS, () =>
    StaffAuthService.getProfile(staffId, { maxWinTtlMs: STAFF_MAXWIN_TTL_MS })
  );

// Credit deposit/withdraw ke baad agla tick wallet turant dobara padhe. Max-win
// cache jaan-boojh ke nahi chheda — credit move se downline ki jeet nahi badalti.
export const invalidateStaffProfile = (staffId) => {
  staffProfileCache.delete(String(staffId));
};

export default StaffAuthService;

