/**
 * Admin void for UNSETTLED table-casino bets.
 *
 * Kuch casino rounds settle nahi ho paate (resolver missing, provider ka result
 * kabhi nahi aata) — bet `open`/`processing` par atak jaati hai aur uska
 * placement lock user ke `cash` + `user_exposures` me hamesha ke liye phansa
 * rehta hai. Aaj tak ye sirf ek one-time script se saaf hota tha
 * (scripts/voidStuckCasinoBets_20260729.js); ye service wahi kaam admin panel
 * ke liye deta hai.
 *
 * VOID = placement lock ulta karo. Money rules settlement worker ke void path
 * (casinobet/settlementCasinoWorker.js "VOID / REFUND CASE") se HU-BA-HU same
 * hain — agar wahan badle to yahan bhi badlo:
 *   • cash        -= exposer      (placement ne cash += exposer kiya tha)
 *   • inr_balance   untouched     (void me koi win/loss nahi)
 *   • P/L, net_win, staff all_point / bal_up — kuch nahi chhedte
 *   • casino_bets → status 'closed', result_status 'void', credit_amt 0
 *   • round ke saare user_exposures rows delete, phir total_exposures recompute
 *
 * Player-side `CasinoService.undoBet` yahan use NAHI ho sakta: wo round ke live
 * betting window me hi chalta hai (stuck rounds din puraane hote hain) aur book
 * markets ko refuse karta hai — stuck bets zyadatar wahi hote hain.
 */
import { Op, QueryTypes } from "sequelize";
import sequelize from "../../config/db.js";
import CasinoBet from "../../model/user/casino.js";
import Wallet from "../../model/admin/Wallet.js";
import UserExposure from "../../model/user/UserExposure.js";
import {
  recordVoidAudit,
  newVoidGroupId,
  VOID_TYPES,
} from "./voidAuditService.js";
import TotalExposure from "../../model/user/TotalExposure.js";
import User from "../../model/user/User.js";
import Staff from "../../model/admin/Staff.js";
import CreditsLedger from "../../model/user/CreditsLedger.js";
import WalletService from "../walletService.js";
import { POINT_CATEGORY } from "../../constants/pointLedger.js";
import { TOTAL_EXPOSURE_SQL } from "../CasinoService.js";
import { emitBalanceUpdate } from "../../utils/socketUtils.js";

// Ek bet "unsettled" tabhi hai jab worker ne use band nahi kiya.
const UNSETTLED = ["open", "processing"];

// …lekin sirf `status` dekhna KAAFI NAHI hai. Settlement worker jis bet ka
// result resolve nahi kar paata use `status='open'` par wapas rakh deta hai
// (settlementCasinoWorker.js ~7757/7775/7787) — bina ye dekhe ki beech me kisi
// ne use void to nahi kar diya. Us race me ek void ki hui bet dobara
// open → processing ho jaati hai aur list me laut aati hai; agar filter sirf
// status par hota to uspar dobara click karne par DOOSRA refund chala jaata.
// Isliye har jagah ye poora filter lagta hai: koi bhi terminal result_status
// (void/won/lost) hone ka matlab bet khatam — chahe status kuch bhi ho.
const NO_RESULT_YET = { [Op.or]: [null, ""] };
const unsettledWhere = (extra = {}) => ({
  status: { [Op.in]: UNSETTLED },
  result_status: NO_RESULT_YET,
  ...extra,
});

const round2 = (v) => Math.round((Number(v) || 0) * 100) / 100;

// Round ki pehchaan event_id se hoti hai — exposure rows bhi match_id me wahi
// value rakhte hain (worker clearExposuresForMatch(user_id, event_id) karta hai).
const roundKeyOf = (bet) => String(bet.event_id ?? bet.round_id ?? "");

/**
 * Saare unsettled casino bets, round-wise group kiye hue.
 * @returns {Promise<Array>} [{ roundKey, gameName, roundId, userId, username, betCount, totalStake, totalExposer, oldestAt, bets: [...] }]
 */
export const listUnsettledCasinoBets = async () => {
  const bets = await CasinoBet.findAll({
    where: unsettledWhere(),
    order: [["id", "ASC"]],
    raw: true,
  });
  if (!bets.length) return [];

  const userIds = [...new Set(bets.map((b) => Number(b.user_id)))];
  const users = await User.findAll({
    where: { user_id: { [Op.in]: userIds } },
    attributes: ["user_id", "username"],
    raw: true,
  });
  const nameOf = new Map(users.map((u) => [Number(u.user_id), u.username]));

  // Group = (user, round). Void hamesha isi granularity par hota hai, kyunki
  // ek book market ka exposure row poore market ka min() hota hai — ek bet ka
  // delta alag se ulta nahi kiya ja sakta.
  const groups = new Map();
  for (const b of bets) {
    const key = `${b.user_id}:${roundKeyOf(b)}`;
    if (!groups.has(key)) {
      groups.set(key, {
        groupKey: key,
        userId: Number(b.user_id),
        username: nameOf.get(Number(b.user_id)) || `user_${b.user_id}`,
        gameName: b.game_name,
        roundId: String(b.round_id ?? ""),
        eventId: roundKeyOf(b),
        betCount: 0,
        totalStake: 0,
        totalExposer: 0,
        oldestAt: b.created_at,
        bets: [],
      });
    }
    const g = groups.get(key);
    g.betCount += 1;
    g.totalStake = round2(g.totalStake + Number(b.stake || 0));
    g.totalExposer = round2(g.totalExposer + Number(b.exposer || 0));
    if (b.created_at && g.oldestAt && new Date(b.created_at) < new Date(g.oldestAt)) {
      g.oldestAt = b.created_at;
    }
    g.bets.push({
      betId: Number(b.id),
      selection: b.selection || b.player_name || "-",
      betType: b.type || "-",
      marketType: b.mtype || "-",
      odds: Number(b.odds || 0),
      stake: Number(b.stake || 0),
      exposer: Number(b.exposer || 0),
      status: b.status,
      createdAt: b.created_at,
    });
  }

  return [...groups.values()].sort(
    (a, b) => new Date(a.oldestAt || 0) - new Date(b.oldestAt || 0)
  );
};

/**
 * Diye gaye bet ids ko void karo.
 *
 * Rule: har (user, round) jise ye ids chhoote hain, uske SAARE unsettled bets
 * is call me hone chahiye. Aadha round void karne par us round ke exposure rows
 * delete ho jaate (worker ki convention) jabki baaki bets abhi zinda hoti —
 * exposure chhup ke gayab ho jaata. Isliye aisi request reject hoti hai aur UI
 * ko pura round bhejne ko kehti hai.
 *
 * @param {number[]} betIds
 * @returns {Promise<{ voided: number, refunds: Array, rounds: number }>}
 */
export const voidCasinoBets = async (betIds) => {
  const ids = [...new Set((betIds || []).map(Number).filter((n) => Number.isFinite(n) && n > 0))];
  if (!ids.length) throw new Error("bet_ids is required");

  const transaction = await sequelize.transaction();
  try {
    // Row lock pehle — settlement worker isi bet par kaam kar raha ho to wo
    // hamare peeche serialize hoga, aur UNSETTLED filter ki wajah se jo baad me
    // aayega use kuch milega hi nahi (double refund impossible).
    const bets = await CasinoBet.findAll({
      where: unsettledWhere({ id: { [Op.in]: ids } }),
      lock: transaction.LOCK.UPDATE,
      transaction,
    });
    if (!bets.length) {
      throw new Error("No unsettled casino bets found for the given ids (already settled or voided?)");
    }

    // (user, round) groups jo ye call chhoo raha hai
    const groups = new Map();
    for (const b of bets) {
      const key = `${b.user_id}:${roundKeyOf(b)}`;
      if (!groups.has(key)) {
        groups.set(key, {
          userId: Number(b.user_id),
          eventId: roundKeyOf(b),
          // event_id aur round_id aaj har row me same hote hain, par exposure row
          // placement ke waqt inhi me se ek se likhi jaati hai — dono rakh lete
          // hain taaki guard aur delete kabhi round miss na karein.
          roundKeys: [...new Set([b.event_id, b.round_id].filter((v) => v != null).map(String))],
          bets: [],
        });
      }
      const g0 = groups.get(key);
      for (const k of [b.event_id, b.round_id]) {
        if (k != null && !g0.roundKeys.includes(String(k))) g0.roundKeys.push(String(k));
      }
      g0.bets.push(b);
    }

    // Partial-round guard
    for (const g of groups.values()) {
      const left = await CasinoBet.count({
        where: unsettledWhere({
          user_id: g.userId,
          [Op.or]: [
            { event_id: { [Op.in]: g.roundKeys } },
            { round_id: { [Op.in]: g.roundKeys } },
          ],
          id: { [Op.notIn]: bets.map((b) => Number(b.id)) },
        }),
        transaction,
      });
      if (left > 0) {
        throw new Error(
          `Round ${g.eventId}: ${left} more unsettled bet(s) for this user — void the whole round instead of a single bet`
        );
      }
    }

    const refunds = [];
    // ONE group id for the whole call: voiding a round is a single action even
    // when it spans several bets and users.
    const voidGroupId = newVoidGroupId();

    for (const g of groups.values()) {
      const wallet = await Wallet.findOne({
        where: { user_id: String(g.userId) },
        lock: transaction.LOCK.UPDATE,
        transaction,
      });
      if (!wallet) throw new Error(`Wallet not found for user ${g.userId}`);

      // cash -= exposer, bilkul worker ke void path jaisa. exposer negative hai
      // (lock) to cash badhta hai; bet 708 jaisi hedge-leg par exposer positive
      // tha (placement ne release kiya tha) to yahan wapas kat-ta hai.
      const exposerSum = g.bets.reduce((s, b) => s + Number(b.exposer || 0), 0);
      const cashBefore = Number(wallet.cash || 0);
      const cashAfter = round2(cashBefore - exposerSum);
      await wallet.update({ cash: cashAfter }, { transaction });

      // Round ke exposure rows hata do — worker settle hone par bhi yahi karta
      // hai (clearExposuresForMatch). Guard upar ye pakka kar chuka hai ki is
      // round par is user ki aur koi bet zinda nahi, isliye kisi zinda bet ka
      // liability yahan udta nahi.
      //
      // `category: 'casino'` zaroori hai: match_id sirf ek string hai, koi
      // namespace nahi. Agar kabhi kisi sports match ka id casino round id se
      // mil gaya to bina is filter ke us user ka sports exposure bhi saaf ho
      // jaata (aaj aisa overlap nahi hai — ye usko aage bhi rokta hai).
      const removed = await UserExposure.destroy({
        where: {
          user_id: String(g.userId),
          match_id: { [Op.in]: g.roundKeys },
          category: "casino",
        },
        transaction,
      });

      await CasinoBet.update(
        {
          status: "closed",
          result_status: "void",
          credit_amt: 0,
          updated_at: new Date(),
        },
        { where: { id: { [Op.in]: g.bets.map((b) => Number(b.id)) } }, transaction }
      );

      const rows = await sequelize.query(TOTAL_EXPOSURE_SQL, {
        replacements: { user_id: String(g.userId) },
        type: QueryTypes.SELECT,
        transaction,
      });
      const totalExposure = parseFloat(rows[0]?.total_exposure) || 0;
      await TotalExposure.upsert(
        { user_id: Number(g.userId), total_exposure: totalExposure },
        { transaction }
      );

      // Audit trail — same table the sports voids write, so one report covers
      // both. exposerSum is signed (a lock is negative), and cash moves by
      // -exposerSum, so the money RETURNED is -exposerSum.
      await recordVoidAudit({
        voidGroupId,
        voidType: VOID_TYPES.CASINO_OPEN,
        betKind: "CASINO",
        bets: g.bets,
        representativeBetId: g.bets.length
          ? Math.min(...g.bets.map((b) => Number(b.id)))
          : null,
        before: { status: "open", cash: cashBefore, exposure: exposerSum },
        after: {
          status: "closed",
          resultStatus: "void",
          cash: cashAfter,
          exposure: removed > 0 ? 0 : exposerSum,
          totalExposure,
        },
        refundAmount: round2(-exposerSum),
        exposureRowsDeleted: removed,
        context: { note: `casino round(s) ${g.roundKeys.join(", ")}` },
      }, transaction);

      refunds.push({
        userId: g.userId,
        eventId: g.eventId,
        betIds: g.bets.map((b) => Number(b.id)),
        exposureRowsRemoved: removed,
        refund: round2(-exposerSum),
        cashBefore,
        cashAfter,
        totalExposure,
      });
    }

    await transaction.commit();

    // Commit ke BAAD hi socket — user ka header wahi number dikhaye jo DB me hai
    for (const r of refunds) {
      try {
        const fresh = await Wallet.findOne({ where: { user_id: String(r.userId) }, raw: true });
        emitBalanceUpdate(r.userId, {
          inr_balance: fresh?.inr_balance,
          cash: fresh?.cash,
          exposure: r.totalExposure,
        });
      } catch (err) {
        console.error("[casinoVoid] balance emit failed:", r.userId, err.message);
      }
    }

    return {
      voided: bets.length,
      rounds: refunds.length,
      refunds,
    };
  } catch (error) {
    await transaction.rollback();
    throw error;
  }
};

/* ──────────────────────────────────────────────────────────────────────────
 * CASE 2 — settlement ke BAAD void
 *
 * Upar wala case bet ka lock ulta karta hai. Yahan bet settle ho chuki hai, to
 * poori settlement ulti karni padti hai — sirf cash nahi, inr_balance bhi, aur
 * uske saath P/L, ledger, staff bal_up aur all_point chain bhi. Settlement ne
 * jo likha tha (settlementCasinoWorker.js WIN/LOSS case) uski poori list:
 *
 *   WIN : cash += credit_amt, inr += netProfit, User.net_win/profit += netProfit,
 *         CreditsLedger BET_WIN, staff bal_up += netProfit, all_point += netProfit
 *   LOSS: inr -= credit_amt,  User.net_loss/profit -= credit_amt,
 *         CreditsLedger BET_LOSS, staff bal_up -= credit_amt, all_point -= credit_amt
 *
 * Dono ko ek hi signed number se pakda ja sakta hai — wahi `netPoint` jo worker
 * compute karta hai:
 *      WIN  → netPoint = credit_amt + exposer   (exposer negative lock hai)
 *      LOSS → netPoint = -credit_amt
 * Aur reversal dono jagah same:  cash -= netPoint,  inr_balance -= netPoint.
 *
 * Placement lock ka refund alag se nahi karna padta — wo pehle hi settlement me
 * cash ke through nikal/aa chuka hai; upar wala formula end state ko wahin le
 * jaata hai jahan bet lagne se pehle tha.
 * ────────────────────────────────────────────────────────────────────────── */

const SETTLED = ["won", "lost", "loss"];
// Void hui bets bhi isi list me aati hain (read-only record) — admin ko dikhna
// chahiye ki kaunsi bet void ki gayi thi. Void par dobara void nahi hota.
const VOIDED = ["void"];
const LISTABLE = [...SETTLED, ...VOIDED];

// Settle ho chuki bet sirf ek chhoti window tak void ho sakti hai. Purani bet
// ka void poore hierarchy ka P/L aur points hila deta hai, aur tab tak upar
// settlement ho chuki hoti hai — isliye 24 ghante ke baad panel se void band.
// Window list aur void DONO par lagti hai: UI ka filter safety nahi hota, is
// liye server bhi purani bet ko mana karta hai.
const SETTLED_VOID_WINDOW_HOURS = Number(process.env.CASINO_SETTLED_VOID_WINDOW_HOURS || 24);
const settledSince = () => new Date(Date.now() - SETTLED_VOID_WINDOW_HOURS * 60 * 60 * 1000);

/**
 * Settle ho chuke casino bets (void karne layak).
 * @param {{ search?: string, limit?: number, offset?: number }} params
 */
export const listSettledCasinoBets = async ({ search = "", limit = 100, offset = 0, result = "" } = {}) => {
  const lim = Math.min(Math.max(Number(limit) || 100, 1), 500);
  const off = Math.max(Number(offset) || 0, 0);

  // result filter: '' = sab (won/lost/void), warna sirf wahi
  const wanted = String(result || "").toLowerCase();
  const statuses = wanted === "won" ? ["won"]
    : wanted === "lost" ? ["lost", "loss"]
    : wanted === "void" ? VOIDED
    : LISTABLE;

  // `status` par filter nahi lagate: worker ek void ki hui bet ko beech me
  // open/processing chhod sakta hai (dekho NO_RESULT_YET wala note). Sach
  // result_status me hai, isliye wahi authority hai.
  const where = {
    result_status: { [Op.in]: statuses },
    updated_at: { [Op.gte]: settledSince() },
  };

  // Search: username se dhoondhne ke liye pehle user ids nikalte hain, warna
  // bet id / round / game / selection par seedha match.
  const term = String(search || "").trim();
  if (term) {
    const matchedUsers = await User.findAll({
      where: { username: { [Op.iLike]: `%${term}%` } },
      attributes: ["user_id"],
      raw: true,
    });
    const or = [
      { game_name: { [Op.iLike]: `%${term}%` } },
      { selection: { [Op.iLike]: `%${term}%` } },
    ];
    if (/^\d+$/.test(term)) {
      or.push({ id: Number(term) });
      or.push({ round_id: term });
      or.push({ event_id: term });
    }
    if (matchedUsers.length) or.push({ user_id: { [Op.in]: matchedUsers.map((u) => Number(u.user_id)) } });
    where[Op.or] = or;
  }

  const { rows, count } = await CasinoBet.findAndCountAll({
    where,
    order: [["id", "DESC"]],
    limit: lim,
    offset: off,
    raw: true,
  });
  if (!rows.length) return { total: count, windowHours: SETTLED_VOID_WINDOW_HOURS, bets: [] };

  const users = await User.findAll({
    where: { user_id: { [Op.in]: [...new Set(rows.map((b) => Number(b.user_id)))] } },
    attributes: ["user_id", "username"],
    raw: true,
  });
  const nameOf = new Map(users.map((u) => [Number(u.user_id), u.username]));

  return {
    total: count,
    windowHours: SETTLED_VOID_WINDOW_HOURS,
    bets: rows.map((b) => ({
      betId: Number(b.id),
      userId: Number(b.user_id),
      username: nameOf.get(Number(b.user_id)) || `user_${b.user_id}`,
      gameName: b.game_name,
      roundId: String(b.round_id ?? ""),
      eventId: String(b.event_id ?? ""),
      selection: b.selection || b.player_name || "-",
      betType: b.type || "-",
      odds: Number(b.odds || 0),
      stake: Number(b.stake || 0),
      exposer: Number(b.exposer || 0),
      creditAmt: Number(b.credit_amt || 0),
      resultStatus: b.result_status,
      // pehle se void → sirf record ke liye dikh rahi hai, dobara void nahi hoti
      alreadyVoid: VOIDED.includes(String(b.result_status || "").toLowerCase()),
      // Jo settlement me user ke inr me gaya/nikla — void par yahi ulta hoga
      netPoint: netPointOf(b),
      createdAt: b.created_at,
      settledAt: b.updated_at,
    })),
  };
};

// Settlement ka signed P/L: jeet par profit (+), haar par loss (−).
const netPointOf = (bet) => {
  const rs = String(bet.result_status || "").toLowerCase();
  const creditAmt = Number(bet.credit_amt || 0);
  if (rs === "won") return round2(creditAmt + Number(bet.exposer || 0));
  return round2(-creditAmt);
};

/**
 * Ek settle ho chuki casino bet ko void karo (poori settlement reversal).
 * @param {number} betId
 */
export const voidSettledCasinoBet = async (betId) => {
  const id = Number(betId);
  if (!Number.isFinite(id) || id <= 0) throw new Error("bet_id is required");

  const transaction = await sequelize.transaction();
  let summary;
  try {
    const bet = await CasinoBet.findOne({
      where: { id, status: "closed", result_status: { [Op.in]: SETTLED } },
      lock: transaction.LOCK.UPDATE,
      transaction,
    });
    if (!bet) {
      throw new Error("Settled casino bet not found (already voided, or still unsettled?)");
    }

    // Window guard — UI purani bets dikhata hi nahi, par endpoint apne aap ko
    // bachata hai (direct API call / stale tab se purani bet void na ho jaaye).
    const settledAt = bet.updated_at ? new Date(bet.updated_at) : null;
    if (!settledAt || settledAt < settledSince()) {
      throw new Error(
        `Bet is older than ${SETTLED_VOID_WINDOW_HOURS}h — settled bets can only be voided within ${SETTLED_VOID_WINDOW_HOURS} hours of settlement`
      );
    }

    const userId = Number(bet.user_id);
    const netPoint = netPointOf(bet.get({ plain: true }));
    // Read BEFORE the bet.update below sets it to 'void' — the audit row needs
    // to say what the bet was, not what the void made it.
    const resultStatusBefore = String(bet.result_status || "");

    const wallet = await Wallet.findOne({
      where: { user_id: String(userId) },
      lock: transaction.LOCK.UPDATE,
      transaction,
    });
    if (!wallet) throw new Error(`Wallet not found for user ${userId}`);

    const cashBefore = Number(wallet.cash || 0);
    const inrBefore = Number(wallet.inr_balance || 0);
    await wallet.update(
      { cash: round2(cashBefore - netPoint), inr_balance: round2(inrBefore - netPoint) },
      { transaction }
    );

    // User ke lifetime counters bhi ulte
    const counters = { profit: -netPoint };
    if (netPoint > 0) counters.net_win = -netPoint;
    else if (netPoint < 0) counters.net_loss = -netPoint;
    await User.increment(counters, { where: { user_id: userId }, transaction });

    // Original BET_WIN/BET_LOSS row rehti hai; uske saamne ulti entry — statement
    // me trail dikhe. points_applied true taaki point cron ise settlement na samjhe.
    await CreditsLedger.create(
      {
        user_id: userId,
        currency: "INR",
        amount: Number(bet.credit_amt || 0),
        reason: "BET_VOID",
        description: `VOID after settlement — ${bet.game_name} / R.No : ${bet.round_id || bet.event_id || ""}`,
        eventid: bet.event_id,
        match_id: bet.selection,
        market_type: bet.mtype,
        netamount: -netPoint,
        ...(netPoint > 0 ? { profit: -netPoint } : { loss: -netPoint }),
        bet_id: id,
        closing: round2(cashBefore - netPoint),
        category: "CASINO",
        points_applied: true,
      },
      { transaction }
    );

    // Direct parent staff ka bal_up
    const userRow = await User.findOne({ where: { user_id: userId }, transaction });
    if (userRow?.parent_staff_id) {
      await Staff.increment(
        { bal_up: -netPoint },
        { where: { staff_id: userRow.parent_staff_id }, transaction }
      );
    }

    await bet.update(
      { status: "closed", result_status: "void", credit_amt: 0, updated_at: new Date() },
      { transaction }
    );

    // Settle ho chuki bet par exposure row hoti hi nahi, to ye normally no-op
    // hai — SELF-HEAL ke liye hai, bilkul sportsVoidService jaisa: kisi purane
    // void ka chhoda hua stale snapshot yahan apne aap sahi ho jaata hai.
    // Jaan-boojh kar CasinoService wala TOTAL_EXPOSURE_SQL (upar import hai),
    // helper/totalExposure.js wala NAHI — casino book markets ko ye GROUPED
    // maanta hai, wo ADDITIVE. Dono mix karne se ek hi user ka snapshot is baat
    // par badalta rehta ki aakhri baar likha kisne.
    const exposureRows = await sequelize.query(TOTAL_EXPOSURE_SQL, {
      replacements: { user_id: String(userId) },
      type: QueryTypes.SELECT,
      transaction,
    });
    const totalExposure = parseFloat(exposureRows[0]?.total_exposure) || 0;
    await TotalExposure.upsert(
      { user_id: Number(userId), total_exposure: totalExposure },
      { transaction }
    );

    // Audit — `bet` still holds the PRE values here (its .update above mutated
    // the row in the DB, but result_status was captured into resultStatusBefore
    // before that call).
    await recordVoidAudit({
      voidGroupId: newVoidGroupId(),
      voidType: VOID_TYPES.CASINO_SETTLED,
      betKind: "CASINO",
      bets: [bet],
      representativeBetId: id,
      before: {
        status: "closed",
        resultStatus: resultStatusBefore,
        cash: cashBefore,
        inr: inrBefore,
      },
      after: {
        status: "closed",
        resultStatus: "void",
        cash: round2(cashBefore - netPoint),
        inr: round2(inrBefore - netPoint),
        totalExposure,
      },
      // Settled void reverses a P/L: cash AND inr both move by -netPoint.
      refundAmount: round2(-netPoint),
      context: { note: `settled casino void — was ${resultStatusBefore}, net ${netPoint}` },
    }, transaction);

    summary = {
      betId: id,
      userId,
      resultStatus: String(bet.result_status || ""),
      netPoint,
      cashBefore,
      cashAfter: round2(cashBefore - netPoint),
      inrBefore,
      inrAfter: round2(inrBefore - netPoint),
      totalExposure,
    };

    await transaction.commit();
  } catch (error) {
    await transaction.rollback();
    throw error;
  }

  // all_point chain commit ke BAAD — uska apna transaction hai (settlement bhi
  // isi tarah post-commit chalata hai). Fail hone par bet void hi rehti hai,
  // sirf points reverse nahi hote — isliye result response me bhejte hain.
  const points = await WalletService.reverseAllPointHierarchy(id, POINT_CATEGORY.CASINO);
  if (!points.success) console.error("[casinoVoid] point reversal failed:", id, points.error);

  try {
    const fresh = await Wallet.findOne({ where: { user_id: String(summary.userId) }, raw: true });
    emitBalanceUpdate(summary.userId, {
      inr_balance: fresh?.inr_balance,
      cash: fresh?.cash,
      exposure: summary.totalExposure,
    });
  } catch (err) {
    console.error("[casinoVoid] balance emit failed:", summary.userId, err.message);
  }

  return { ...summary, points };
};

export default {
  listUnsettledCasinoBets,
  voidCasinoBets,
  listSettledCasinoBets,
  voidSettledCasinoBet,
};
