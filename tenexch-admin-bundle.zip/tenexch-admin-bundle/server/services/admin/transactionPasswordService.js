import Staff from '../../model/admin/Staff.js';
import Owner from '../../model/admin/Owner.js';
import { MESSAGES } from '../../constants/messages.js';

export const MAX_TXN_PASSWORD_ATTEMPTS = 10;

/**
 * Verify the transaction password for the authenticated admin (staff or owner)
 * while maintaining the attempts counter:
 *  - wrong password  → counter decrements, message reports attempts left
 *  - counter hits 0  → staff is locked out of transaction-code actions and
 *    login ("UserName not available") until the parent changes its password
 *    (restores the counter to MAX); owners are never locked — floors at 0
 *  - correct password → counter restored to MAX
 *
 * Returns { ok, status, message, attemptsLeft? } — never throws for auth
 * failures, only for unexpected errors (DB down etc.).
 */
export async function verifyTxnPasswordWithAttempts(reqUser, transactionPassword) {
  const userId = reqUser.account ? reqUser.account.id : (reqUser.user_id || reqUser.staff_id || reqUser.owner_id);
  const userRole = reqUser.role;

  if (!transactionPassword) {
    return { ok: false, status: 400, message: MESSAGES.ADMIN.TXN.REQUIRED };
  }

  const isOwner = userRole === 'OWNER' || userRole === 'Owner';
  const user = isOwner
    ? await Owner.findOne({ where: { owner_id: userId } })
    : await Staff.findByPk(userId);

  if (!user) {
    return { ok: false, status: 404, message: MESSAGES.ADMIN.TXN.ACCOUNT_NOT_FOUND };
  }

  // A deactivated staff account stays locked even if the correct password is
  // supplied now — only the upline reactivating it resets the allowance. Same
  // wording as the moment the limit was reached.
  if (!isOwner && user.active === false) {
    return {
      ok: false,
      status: 403,
      message: MESSAGES.ADMIN.TXN.LIMIT_REACHED,
      attemptsLeft: 0,
    };
  }

  const attemptsLeft = user.txn_password_attempts ?? MAX_TXN_PASSWORD_ATTEMPTS;

  // Staff at 0 attempts stay blocked from every transaction-code action, even
  // with the correct code, until the parent changes their password (which
  // resets the counter). Login also reads as "UserName not available".
  if (!isOwner && attemptsLeft <= 0) {
    return { ok: false, status: 403, message: MESSAGES.ADMIN.TXN.LIMIT_REACHED, attemptsLeft: 0 };
  }

  // Direct comparison since it's stored as plain text
  if (user.transaction_password !== transactionPassword) {
    const remaining = Math.max(0, attemptsLeft - 1);
    const updates = { txn_password_attempts: remaining };
    // Wording lives in constants/messages.js (ADMIN.TXN) — shared by every
    // transaction-code route. Limit reached → one fixed text, no counter.
    let message = MESSAGES.ADMIN.TXN.NOT_VALID_ATTEMPTS_LEFT(remaining);
    // Limit reached no longer flips `active` (that is the upline's manual
    // lock and cascades to the downline) — attempts = 0 IS the lock now.
    if (remaining === 0) {
      message = MESSAGES.ADMIN.TXN.LIMIT_REACHED;
    }
    await user.update(updates);
    return { ok: false, status: 400, message, attemptsLeft: remaining };
  }

  // Correct password → restore the full allowance.
  if (attemptsLeft !== MAX_TXN_PASSWORD_ATTEMPTS) {
    await user.update({ txn_password_attempts: MAX_TXN_PASSWORD_ATTEMPTS });
  }

  return { ok: true, status: 200, message: MESSAGES.ADMIN.TXN.VERIFIED, attemptsLeft: MAX_TXN_PASSWORD_ATTEMPTS };
}

export default { verifyTxnPasswordWithAttempts, MAX_TXN_PASSWORD_ATTEMPTS };
