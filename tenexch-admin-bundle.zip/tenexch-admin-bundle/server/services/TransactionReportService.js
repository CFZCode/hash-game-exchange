
import Transaction from '../model/admin/Transaction.js';
import CreditsLedger from '../model/user/CreditsLedger.js';
import PointLedger from '../model/admin/PointLedger.js';
import SportsBet from '../model/user/SportsBet.js';
import Staff from '../model/admin/Staff.js';
import User from '../model/user/User.js';
import { Op, or } from 'sequelize';
import sequelize from '../config/db.js';
import { POINT_EVENT } from '../constants/pointLedger.js';
import { buildUserStatement } from './statement/StatementBuilder.js';
import { getUserIdsByHierarchy } from '../controller/admin/userController.js';
import { isVoidRow, withVoidSuffix } from '../helper/voidLabel.js';
import TableCasino from '../model/admin/TableCasino.js';

// "Opening pts" ke liye: fromDate se PEHLE is wallet ka aakhri balance.
// Wallet do tarah ki rows me aata hai — apni (closing_inr_balance) aur jahan ye
// parent hai (closing_inr_balance_parent). Dono me jo baad ki (bada id) wahi
// balance. Pehle koi row hi nahi (account range ke andar bana) → 0.
const getOpeningBalance = async (walletId, fromDate) => {
  const before = { [Op.lt]: new Date(fromDate) };
  const [own, asParent] = await Promise.all([
    PointLedger.findOne({
      where: { wallet_id: walletId, created_at: before, closing_inr_balance: { [Op.ne]: null } },
      order: [['id', 'DESC']],
      attributes: ['id', 'closing_inr_balance'],
      raw: true,
    }),
    PointLedger.findOne({
      where: {
        settled_with_wallet_id: walletId,
        wallet_id: { [Op.ne]: walletId },
        created_at: before,
        closing_inr_balance_parent: { [Op.ne]: null },
      },
      order: [['id', 'DESC']],
      attributes: ['id', 'closing_inr_balance_parent'],
      raw: true,
    }),
  ]);
  if (!own && !asParent) return 0;
  if (own && (!asParent || Number(own.id) > Number(asParent.id))) return Number(own.closing_inr_balance) || 0;
  return Number(asParent.closing_inr_balance_parent) || 0;
};

const SPORT_NAMES = {
  '1': 'Football',
  '2': 'Tennis',
  '4': 'Cricket',
  '7': 'Horse Racing',
  '10': 'Horse Racing',
  '65': 'Greyhound Racing',
  '1477': 'Kabaddi',
};

const CASINO_GAME_NAMES = {
  'teen20c': '20-20 Teenpatti C',
  'dt20': 'Dragon Tiger 20',
  'mogambo': 'Mogambo',
  'teen20': '20-20 Teenpatti',
  'teen9': 'Teen Patti 9',
  'ab20': 'Andar Bahar 20',
  'lucky7': 'Lucky 7',
  'aaa': 'Amar Akbar Anthony',
};

const TransactionReportService = {
  /**
   * Generate account statement for a given target (User/Staff/Owner)
   * @param {Object} target - { id, type, username }
   * @param {Object} filters - { fromDate, toDate, gameName, page, limit }
   */
  getStatement: async (target, filters) => {
    const { fromDate, toDate, reportType, page = 1, limit = 25 } = filters;
    const offset = (page - 1) * limit;

    try {
      if (target.type === 'USER') {
        // Delegate to the shared StatementBuilder — same source as the user
        // panel: one net row per SETTLED bet (Credit if won, Debit if lost),
        // plus deposits/withdrawals, with a tallying running balance.
        console.log(`🔍 [TransactionReportService] Statement for User ID: ${target.id} | Filter: ${reportType}`);
        return buildUserStatement({ id: target.id, username: target.username }, filters);

      } else {
        // --- STAFF/OWNER LOGIC ---
        console.log(`🔍 [TransactionReportService] Fetching data for Staff/Owner: ${target.username} | Filter: ${reportType}`);

        const isLedgerReport = reportType === 'SPORTS' || reportType === 'CASINO' || reportType === 'THIRD-PARTY';

        if (isLedgerReport) {
          // For SPORTS/CASINO/THIRD-PARTY: fetch CreditsLedger for all descendant users
          // Staff's share = user P&L * (staff.percentage / 100). If percentage is 0/null, share is 0.
          let staffPercentage = 0;
          if (target.type !== 'OWNER') {
            const staff = await Staff.findOne({
              where: { username: target.username },
              attributes: ['percentage'],
              raw: true
            });
            staffPercentage = parseFloat(staff?.percentage || 0);
          }

          // Owner sees all users; staff sees only their direct users
          let userIds = [];
          if (target.type === 'OWNER') {
            userIds = await getUserIdsByHierarchy(target.type, target.username);
          } else {
            // Staff: only direct users (parent_staff_id = this staff's id)
            const staffRecord = await Staff.findOne({
              where: { username: target.username },
              attributes: ['staff_id'],
              raw: true
            });
            if (staffRecord) {
              const directUsers = await User.findAll({
                where: { parent_staff_id: staffRecord.staff_id },
                attributes: ['user_id'],
                raw: true
              });
              userIds = directUsers.map(u => u.user_id);
            }
          }

          if (!userIds || userIds.length === 0) {
            return { success: true, data: [], total: 0, totalPages: 0, currentPage: parseInt(page) };
          }

          const ledgerWhere = {
            user_id: { [Op.in]: userIds.map(id => String(id)) },
            category: reportType === 'THIRD-PARTY' ? 'THIRD_PARTY_CASINO' : reportType,
          };
          if (fromDate && toDate) {
            ledgerWhere.created_at = { [Op.between]: [new Date(fromDate), new Date(toDate + 'T23:59:59.999Z')] };
          }

          const ledgers = await CreditsLedger.findAll({
            where: ledgerWhere,
            order: [['created_at', 'ASC']],
            raw: true
          });

          // Build bet lookup maps for descriptions
          let sportsBetMap = {};
          let casinoBetMap = {};
          const betIds = ledgers.map(l => l.bet_id).filter(Boolean);

          if (betIds.length > 0) {
            if (reportType === 'SPORTS') {
              const sportsBets = await SportsBet.findAll({
                where: { id: { [Op.in]: betIds } },
                attributes: ['id', 'match_title', 'selection_name', 'market_type', 'sport_id', 'game_type', 'fancy_name'],
                raw: true
              });
              sportsBets.forEach(b => { sportsBetMap[b.id] = b; });
            }

            if (reportType === 'CASINO') {
              try {
                const [bets] = await sequelize.query(
                  `SELECT id, game_name, round_id, player_name FROM casino_bets WHERE id IN (${betIds.join(',')})`,
                );
                bets.forEach(b => { casinoBetMap[b.id] = b; });
              } catch (e) { /* casino_bets table might not exist */ }
            }
          }

          let runningClosing = 0;
          const formattedLedgers = ledgers.map(l => {
            const userAmt = parseFloat(l.amount || 0);
            // Staff's share of P&L = user amount * percentage / 100
            const staffAmt = userAmt * (staffPercentage / 100);
            runningClosing += staffAmt;

            let remark = l.description || l.reason;

            const sportsBet = sportsBetMap[l.bet_id];
            if (sportsBet) {
              const sportName = SPORT_NAMES[sportsBet.sport_id] || `Sport ${sportsBet.sport_id}`;
              const matchTitle = sportsBet.match_title || '-';
              const marketType = sportsBet.market_type || sportsBet.game_type || '-';
              const selection = (sportsBet.fancy_name && sportsBet.fancy_name !== 'NULL')
                ? sportsBet.fancy_name
                : (sportsBet.selection_name || '-');
              remark = `${sportName} / ${matchTitle} / ${marketType} / ${selection}`;
            }

            const casinoBet = casinoBetMap[l.bet_id];
            if (casinoBet) {
              const gameName = CASINO_GAME_NAMES[casinoBet.game_name] || casinoBet.game_name;
              const parts = [gameName];
              if (casinoBet.round_id) parts.push(`R.No : ${casinoBet.round_id}`);
              if (casinoBet.player_name) parts.push(casinoBet.player_name);
              remark = parts.join(' / ');
            }

            let fromto = '-';
            if (l.category === 'THIRD_PARTY_CASINO') {
              const meta = l.meta || {};
              const provider = meta.provider || l.sport_id || 'Third-Party';
              const gameName = meta.game_name || '-';
              remark = `${provider} / ${gameName}`;
              fromto = gameName;
            }

            return {
              id: `lg-${l.id}`,
              date: l.created_at,
              credit: staffAmt > 0 ? parseFloat(staffAmt.toFixed(2)) : 0,
              debit: staffAmt < 0 ? parseFloat(Math.abs(staffAmt).toFixed(2)) : 0,
              closing: parseFloat(runningClosing.toFixed(2)),
              description: remark,
              fromto,
            };
          });

          const total = formattedLedgers.length;
          const paginatedData = formattedLedgers.slice(offset, offset + parseInt(limit));

          return {
            success: true,
            data: paginatedData,
            total,
            totalPages: Math.ceil(total / limit),
            currentPage: parseInt(page),
          };

        } else {
          // TRANSACTION / Deposit-Withdraw / ALL: fetch from Transaction table
          // Only show rows where this staff's wallet was affected (username = their name)
          let where = {
            username: target.username
          };

          if (fromDate && toDate) {
            where.createdAt = { [Op.between]: [new Date(fromDate), new Date(toDate + 'T23:59:59.999Z')] };
          }

          const { count, rows } = await Transaction.findAndCountAll({
            where,
            order: [['createdAt', 'DESC']],
            limit: parseInt(limit),
            offset: parseInt(offset),
          });

          const tableData = rows.map(row => {
            const creditTypes = ['ADD_CASH', 'ADD_CREDIT', 'CREDIT', 'CREDIT_INR'];
            const debitTypes = ['SUBTRACT_CASH', 'SUBTRACT_CREDIT', 'DEBIT', 'DEBIT_INR', 'DEBIT_FOR_CASH', 'DEBIT_FOR_CREDIT'];

            const isCredit = creditTypes.includes(row.type);
            const isDebit = debitTypes.includes(row.type);

            let friendlyRemark = row.type || 'Transaction';
            if (row.type === 'ADD_CASH' || row.type === 'ADD_CREDIT') friendlyRemark = 'Deposit';
            if (row.type === 'SUBTRACT_CASH' || row.type === 'SUBTRACT_CREDIT') friendlyRemark = 'Withdrawal';
            if (row.type === 'DEBIT_FOR_CASH') friendlyRemark = 'Cash Given';
            if (row.type === 'DEBIT_FOR_CREDIT') friendlyRemark = 'Credit Given';
            if (row.type === 'OPENING_PTS') friendlyRemark = 'Opening Pts';

            return {
              id: row.id,
              date: row.createdAt,
              credit: isCredit ? parseFloat(row.amount).toFixed(2) : '-',
              debit: isDebit ? parseFloat(row.amount).toFixed(2) : '-',
              closing: parseFloat(row.new_balance || row.balance || 0).toFixed(2),
              description: friendlyRemark,
              fromto: (row.debit && row.credit) ? `${row.debit} → ${row.credit}` : (row.debit || row.credit || row.initiated_by || '-')
            };
          });

          return {
            success: true,
            data: tableData,
            total: count,
            totalPages: Math.ceil(count / limit),
            currentPage: parseInt(page),
          };
        }
      }
    } catch (error) {
      console.error('❌ [TransactionReportService] Error:', error);
      throw error;
    }
  },
  /**
   * Dedicated logic for a user's self-account statement.
   * Focuses on Transaction table for Deposit/Withdrawal and CreditsLedger for Sports/Casino.
   */
  getUserStatement: async (target, filters) => {
    const { fromDate, toDate, reportType, page = 1, limit = 25 } = filters;
    const offset = (page - 1) * limit;

    try {
      console.log(`🔍 [TransactionReportService] Fetching USER Statement for: ${target.username} | Filter: ${reportType}`);

      let transactions = [];
      let ledgers = [];

      // Determine what to fetch based on reportType
      // We assume types: TRANSACTION (Deposit/Withdraw), SPORTS, CASINO, THIRD-PARTY, ALL
      const shouldFetchTransactions = !reportType || reportType === 'ALL' || reportType === 'TRANSACTION';
      const shouldFetchLedger = !reportType || reportType === 'ALL' || reportType === 'SPORTS' || reportType === 'CASINO' || reportType === 'THIRD-PARTY';

      // 1. Fetch Transactions (Deposit/Withdrawal)
      if (shouldFetchTransactions) {
        const transactionWhere = { user_id: target.id };
        if (fromDate && toDate) {
          transactionWhere.createdAt = { [Op.between]: [new Date(fromDate), new Date(toDate + 'T23:59:59.999Z')] };
        }
        transactions = await Transaction.findAll({
          where: transactionWhere,
          order: [['createdAt', 'DESC']],
        });
      }

      // 2. Fetch Ledger (Bets/P&L)
      if (shouldFetchLedger) {
        const ledgerWhere = { user_id: target.id.toString() };
        if (reportType && reportType !== 'ALL') {
          ledgerWhere.reason = reportType;
        }
        if (fromDate && toDate) {
          ledgerWhere.created_at = { [Op.between]: [new Date(fromDate), new Date(toDate + 'T23:59:59.999Z')] };
        }
        ledgers = await CreditsLedger.findAll({
          where: ledgerWhere,
          order: [['created_at', 'DESC']],
        });
      }

      // 3. Normalize & Combine
      const formattedTransactions = transactions.map(t => {
        const isCredit = t.type === 'ADD_CASH' || t.type === 'ADD_CREDIT' || t.type === 'CREDIT' || t.type === 'CREDIT_INR';
        const isDebit = t.type === 'SUBTRACT_CASH' || t.type === 'SUBTRACT_CREDIT' || t.type === 'DEBIT' || t.type === 'DEBIT_INR' || t.type === 'DEBIT_FOR_CASH' || t.type === 'DEBIT_FOR_CREDIT';

        let friendlyRemark = t.type || 'Transaction';
        if (t.type === 'ADD_CASH' || t.type === 'ADD_CREDIT' || t.type === 'CREDIT_INR') friendlyRemark = 'deposit';
        if (t.type === 'SUBTRACT_CASH' || t.type === 'SUBTRACT_CREDIT' || t.type === 'DEBIT_INR') friendlyRemark = 'withdrawal';
        if (t.type === 'OPENING_PTS') friendlyRemark = 'Opening Pts';

        return {
          id: `tx-${t.id}`,
          date: t.createdAt,
          credit: isCredit ? t.amount : 0,
          debit: isDebit ? t.amount : 0,
          closing: t.new_balance || t.balance,
          description: friendlyRemark,
          rawDate: new Date(t.createdAt)
        };
      });

      const formattedLedgers = ledgers.map(l => {
        const isCredit = parseFloat(l.amount) > 0;
        return {
          id: `ld-${l.id}`,
          date: l.created_at,
          credit: isCredit ? l.amount : 0,
          debit: !isCredit ? Math.abs(l.amount) : 0,
          closing: l.balance,
          description: l.description || l.reason,
          rawDate: new Date(l.created_at)
        };
      });

      // Combine and Sort
      const combined = [...formattedTransactions, ...formattedLedgers].sort((a, b) => b.rawDate - a.rawDate);

      // Pagination
      const total = combined.length;
      const paginatedData = combined.slice(offset, offset + limit);

      return {
        success: true,
        data: paginatedData,
        total: total,
        totalPages: Math.ceil(total / limit),
        currentPage: parseInt(page),
      };

    } catch (e) {
      console.error('❌ getUserStatement error:', e);
      throw e;
    }
  },

  getStatementV21: async (target, filters) => {
    const { fromDate, toDate, reportType, clientName, page = 1, limit = 25,sportId,gameType,casinoType,statement } = filters;
    const offset = (page - 1) * limit;

    try {
      console.log(`🔍 [TransactionReportService] StatementV2 for ${target.username} (wallet ${target.walletId}) | ${fromDate} → ${toDate} | type: ${reportType} | client: ${clientName || '-'}`);

      // Base: meri wallet ki entries YA jo maine settle ki hain
      const where = {
        [Op.or]: [
          { wallet_id: target.walletId },
          { settled_with_wallet_id: target.walletId },
        ],
      };

     
      if (clientName?.trim()) {
        where.username = { [Op.iLike]: clientName.trim() };
        if (reportType === 'SPORTS') delete where[Op.or];
        //delete where[Op.or];
      }

      // Date range (created_at par) — toDate ka poora din shamil
      if (fromDate || toDate) {
        where.created_at = {};
        if (fromDate) where.created_at[Op.gte] = new Date(fromDate);
        if (toDate) {
          const end = new Date(toDate);
          end.setHours(23, 59, 59, 999);
          where.created_at[Op.lte] = end;
        }
      }

    
      if (reportType === 'TRANSACTION') {
        where.bet_id = null;
        if (statement) {
          if (statement === 'allcredit') {
            // saari Credit/Debit entries (scope ke andar - meri ya maine ki hui)
            where.event_type = { [Op.in]: [POINT_EVENT.CREDIT, POINT_EVENT.DEBIT,POINT_EVENT.USER_CREATION] };
          } else if (statement === 'creditupper') {
            // upar se mujhe jo mila - sirf MERI wallet ki Credit entries
            where.event_type = { [Op.in]: [POINT_EVENT.CREDIT, POINT_EVENT.USER_CREATION] };
            where.wallet_id = target.walletId;
            delete where[Op.or];
          } else if (statement === 'creditdown') {
            // jo maine neeche walon ke saath kiya - settled_with me meri wallet
            where.event_type = { [Op.in]: [POINT_EVENT.CREDIT, POINT_EVENT.DEBIT] };
            where.settled_with_wallet_id = target.walletId;
            delete where[Op.or];
          }
          else if (statement === 'allbalance') {
            where.event_type = { [Op.in]: [POINT_EVENT.BANK_DEPOSIT, POINT_EVENT.BANK_WITHDRAW] };
          }
          else if (statement === 'balanceupper') {
            where.event_type = { [Op.in]: [POINT_EVENT.BANK_DEPOSIT, POINT_EVENT.BANK_WITHDRAW] };
            where.wallet_id = target.walletId;
          }
          else if (statement === 'balancedown') {
            where.event_type = { [Op.in]: [POINT_EVENT.BANK_DEPOSIT, POINT_EVENT.BANK_WITHDRAW] };
            where.settled_with_wallet_id = target.walletId;
          }
          
        }
      } else if (reportType === 'SPORTS') {
        where.bet_id = { [Op.ne]: null };
        if (sportId && sportId !== '0') where.sport_id = String(sportId);
        if (gameType && gameType !== 'all') where.game_type = gameType;
        else if (casinoType && casinoType !== 'all') where.game_type = casinoType;
      }



      const { rows, count } = await PointLedger.findAndCountAll({
        where,
        order: [['id', 'ASC']],   // purani entry pehle (ascending)
        limit: parseInt(limit),
        offset,
        raw: true,
      });

      let data = [];

     if (reportType === 'TRANSACTION'){
        data = rows.map(r => {
        const delta = parseFloat(r.delta || 0);
        const iAmParent = Number(r.settled_with_wallet_id) === Number(target.walletId)
          && Number(r.wallet_id) !== Number(target.walletId);

        const closing = iAmParent
          ? (r.closing_inr_balance_parent ?? r.closing_inr_balance)
          : r.closing_inr_balance;

        const credited = iAmParent ? delta < 0 : delta > 0;

        return {
          date: r.created_at,
          credit: credited ? Math.abs(delta).toFixed(2) : '-',
          debit: !credited ? Math.abs(delta).toFixed(2) : '-',
          closing: closing != null ? parseFloat(closing).toFixed(2) : '-',
          description:  r?.remark?.split('#')[0] || r.event_type,
          fromto: r?.remark?.split('#')[1] || '-', 
        };
      });
     }
     else if(reportType === 'SPORTS'){

       let closing = 0;

       data = rows.map(r => {
        const delta = parseFloat(r.delta || 0);
        const isMyRow = Number(r?.wallet_id) === Number(target?.walletId);
        const myAmt = isMyRow ? -delta : delta;

        closing = Math.round((closing + myAmt) * 100) / 100;
        return {
          date: r.created_at,
          credit: myAmt > 0 ? myAmt : 0,
          debit: myAmt < 0 ? -myAmt : 0,
          closing,
          description: r?.remark,
        };
      });
     }
      

      return {
        success: true,
        data,
        total: count,
        totalPages: Math.ceil(count / limit),
        currentPage: parseInt(page),
      };
    } catch (e) {
      console.error('❌ getStatementV2 error:', e);
      throw e;
    }
  },

  getStatementV2: async (target, filters) => {
    const { fromDate, toDate, reportType, clientName, page = 1, limit = 25,sportId,gameType,casinoType,statement } = filters;
    const offset = (page - 1) * limit;

    try {
      const loginStaff= clientName?false:true
      console.log(`🔍 [TransactionReportService] StatementV2 for ${target.username} (wallet ${target.walletId}) | ${fromDate} → ${toDate} | type: ${reportType} | client: ${clientName || '-'}`);

      // Base: meri wallet ki entries YA jo maine settle ki hain
      const where = {
        [Op.or]: [
          { wallet_id: target.walletId },
          { settled_with_wallet_id: target.walletId },
        ],
      };


      // Date range (created_at par) — toDate ka poora din shamil
      if (fromDate || toDate) {
        where.created_at = {};
        if (fromDate) where.created_at[Op.gte] = new Date(fromDate);
        if (toDate) {
          const end = new Date(toDate);
          end.setHours(23, 59, 59, 999);
          where.created_at[Op.lte] = end;
        }
      }

    
      if (reportType === 'TRANSACTION') {
        where.bet_id = null;
        if (statement) {
          if (statement === 'allcredit') {
            // saari Credit/Debit entries (scope ke andar - meri ya maine ki hui)
            where.event_type = { [Op.in]: [POINT_EVENT.CREDIT, POINT_EVENT.DEBIT,POINT_EVENT.USER_CREATION] };
          } else if (statement === 'creditupper') {
            // upar se mujhe jo mila - sirf MERI wallet ki Credit entries
            where.event_type = { [Op.in]: [POINT_EVENT.CREDIT, POINT_EVENT.USER_CREATION] };
            where.wallet_id = target.walletId;
            delete where[Op.or];
          } else if (statement === 'creditdown') {
            // jo maine neeche walon ke saath kiya - settled_with me meri wallet
            where.event_type = { [Op.in]: [POINT_EVENT.CREDIT, POINT_EVENT.DEBIT] };
            where.settled_with_wallet_id = target.walletId;
            delete where[Op.or];
          }
          else if (statement === 'allbalance') {
            where.event_type = { [Op.in]: [POINT_EVENT.BANK_DEPOSIT, POINT_EVENT.BANK_WITHDRAW] };
          }
          else if (statement === 'balanceupper') {
            where.event_type = { [Op.in]: [POINT_EVENT.BANK_DEPOSIT, POINT_EVENT.BANK_WITHDRAW] };
            where.wallet_id = target.walletId;
          }
          else if (statement === 'balancedown') {
            where.event_type = { [Op.in]: [POINT_EVENT.BANK_DEPOSIT, POINT_EVENT.BANK_WITHDRAW] };
            where.settled_with_wallet_id = target.walletId;
          }
          
        }
      } else if (reportType === 'SPORTS') {
        where.bet_id = { [Op.ne]: null };
        if (sportId && sportId !== '0') where.sport_id = String(sportId);
        if (gameType && gameType !== 'all') where.game_type = gameType;
        else if (casinoType && casinoType !== 'all') where.game_type = casinoType;
      }



      // Synthetic rows (reference jaisa): "Opening pts" sabse upar — dono report
      // me, har statement filter me; "Live Casino" sabse neeche — sirf Game
      // Report me, aur tabhi jab range me koi entry ho. Ye DB rows nahi hain,
      // isliye paging virtual list [opening, ...DB rows, liveCasino] par hoti
      // hai: DB ka offset/limit usi hisaab se khisakta hai aur total me dono gine jaate hain.
      const pageSize = parseInt(limit);
      const count = await PointLedger.count({ where });
      const head = fromDate ? 1 : 0;
      const withLiveCasino = reportType === 'SPORTS';
      const total = head + count + (withLiveCasino ? 1 : 0);

      const dbOffset = Math.max(0, offset - head);
      const dbEnd = Math.min(count, offset + pageSize - head);
      const rows = dbEnd > dbOffset
        ? await PointLedger.findAll({
          where,
          order: [['id', 'ASC']],   // purani entry pehle (ascending)
          limit: dbEnd - dbOffset,
          offset: dbOffset,
          raw: true,
        })
        : [];
      const showOpening = head === 1 && offset === 0;
      const showLiveCasino = withLiveCasino && offset + pageSize >= total;
      const opening = fromDate ? await getOpeningBalance(target.walletId, fromDate) : 0;

      let data = [];

     if (reportType === 'TRANSACTION'){
        data = rows.map(r => {
        const delta = parseFloat(r.delta || 0);
        const iAmParent = Number(r.settled_with_wallet_id) === Number(target.walletId)
          && Number(r.wallet_id) !== Number(target.walletId);

        const closing = iAmParent
          ? (r.closing_inr_balance_parent ?? r.closing_inr_balance)
          : r.closing_inr_balance;

        const credited = iAmParent ? delta < 0 : delta > 0;

        return {
          date: r.created_at,
          credit: credited ? Math.abs(delta).toFixed(2) : '-',
          debit: !credited ? Math.abs(delta).toFixed(2) : '-',
          closing: closing != null ? parseFloat(closing).toFixed(2) : '-',
          description:  r?.remark?.split('#')[0] || r.event_type,
          fromto: r?.remark?.split('#')[1] || '-',
        };
      });
     }
     else if(reportType === 'SPORTS'){

       // pts = Opening + range ki shuruaat se ab tak ka game P/L. Page 2+ par
       // pichhle pages ka jod DB se aata hai — warna har page 0 se shuru hota tha
       // aur Live Casino (aakhri pts) galat banta.
       let closing = opening;
       const sumBefore = rows.length
         ? (dbOffset > 0 ? { ...where, id: { [Op.lt]: rows[0].id } } : null)
         : (showLiveCasino ? where : null);
       if (sumBefore) {
         const prev = Number(await PointLedger.sum('delta', { where: sumBefore })) || 0;
         closing = Math.round((closing + (loginStaff ? -prev : prev)) * 100) / 100;
       }

       // Andar Bahar 50 / 150: each bet is its own row and, like the player
       // statement (UserStatementService) and the reference, names the card bet
       // on after the round no.: "<game> / R.No : <round> / Card Q".
       const ab50Desc = {};
       const casinoIds = rows.filter((r) => r.category === 'CASINO' && r.bet_id).map((r) => Number(r.bet_id));
       if (casinoIds.length) {
         const [abBets] = await sequelize.query(
           `SELECT id, game_name, round_id, selection FROM casino_bets WHERE id IN (${casinoIds.join(',')}) AND game_name IN ('ab3', 'ab4')`
         );
         abBets.forEach((b) => {
           const rank = String(b.selection || '').trim().match(/(10|[2-9]|[AJQK])$/i)?.[1];
           if (rank && b.round_id) {
             ab50Desc[b.id] = {
               round: b.round_id,
               card: `Card ${rank.toUpperCase()}`,
               label: TableCasino.FIXED_TABLES.find((t) => t.tableid === b.game_name)?.tablename,
             };
           }
         });
       }

       // Game label = the table's CURRENT name, so past rows read a renamed
       // table right too ("Andar-Bahar 150 card" → "ANDAR BAHAR 150 CARDS",
       // 2026-10-14); the ledger remark's first part is only the fallback.
       const abDescOf = (r) => {
         const ab = ab50Desc[r.bet_id];
         if (!ab) return null;
         const label = ab.label || String(r?.remark || '').split(' / R.No')[0] || 'Andar Bahar 50 Cards';
         return `${label} / R.No : ${ab.round} / ${ab.card}`;
       };

       data = rows.map(r => {
        const delta = parseFloat(r.delta || 0);
        const myAmt = loginStaff ? -delta : delta;

        closing = Math.round((closing + myAmt) * 100) / 100;
        return {
          date: r.created_at,
          credit: myAmt > 0 ? myAmt : 0,
          debit: myAmt < 0 ? -myAmt : 0,
          closing,
          // Void ki ulti entry user panel jaisi hi padhi jaaye: "… -void"
          // (helper/voidLabel.js — dono panel ki wording ek hi jagah se).
          description: isVoidRow(r)
            ? withVoidSuffix(abDescOf(r) || r?.remark)
            : (abDescOf(r) || r?.remark),
          // Excel icon ke liye: is row ke peeche ka bet. casino me exact bet id,
          // sports me market ki pehli bet id — dono se poora group mil jaata hai
          // (services/admin/statementBetExportService.js). THIRD_PARTY rows ka
          // koi bet table nahi hai, isliye wahan icon nahi aayega.
          betId: r.bet_id != null ? Number(r.bet_id) : null,
          category: r.category || null,
        };
      });

       if (showLiveCasino) {
         // Aakhri line: koi transaction nahi, sirf range ke aakhir ka pts.
         // Date = statement maangne ka waqt (user statement jaisa).
         data.push({
           date: new Date(),
           credit: 0,
           debit: 0,
           closing,
           description: 'Live Casino',
           isOpening: true,
           isClosing: true,
         });
       }
     }

      if (showOpening) {
        // Date = From date 00:00:00, bina timezone ke — browser ise local
        // time maanta hai, to reference jaisa "06/09/2026 00:00:00" dikhta hai.
        data.unshift({
          date: `${fromDate}T00:00:00`,
          credit: '-',
          debit: '-',
          closing: opening.toFixed(2),
          description: 'Opening pts',
          fromto: '',
          isOpening: true,
        });
      }

      return {
        success: true,
        data,
        total,
        totalPages: Math.ceil(total / pageSize),
        currentPage: parseInt(page),
      };
    } catch (e) {
      console.error('❌ getStatementV2 error:', e);
      throw e;
    }
  },
};

export default TransactionReportService;
