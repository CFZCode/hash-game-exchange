// Routes called by other servers (casino vendors, Telegram, internal tools) or
// by monitoring — never by our own player/admin frontends. They are exempt from
// browser-only protections: rate limiting (a 429 would break settlement or game
// play) and response encryption (the caller cannot decrypt).
// Matched against req.path (full path, no query string).
export const SERVER_TO_SERVER_ROUTES = [
  /^\/api\/health$/,
  /^\/api\/jsGames(v2)?(\/|$)/,
  /^\/jsGamesv2(\/|$)/,
  /^\/api\/result(\/|$)/,
  /^\/api\/internalsettle(\/|$)/,
  /^\/api\/system-tracker(\/|$)/,
  /^\/api\/2fa\/telegram\/webhook(\/|$)/,
];

export const isServerToServerRoute = (path) => SERVER_TO_SERVER_ROUTES.some((r) => r.test(path));
