
import { Sequelize } from 'sequelize';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

// Always load .env from project root
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const envPath = path.resolve(__dirname, '../.env');
dotenv.config({ path: envPath });

// Pool size. The API process (entry server.js) serves every player request and
// every socket tick, so it gets 25; workers (settlement, crons) stay at 10.
// DB_POOL_MAX overrides both. Budget: Postgres max_connections = 300.
// Plan: docs/plans/2026-10-12-performance-and-money-safety.md (Phase 2.3).
// Under pm2, argv[1] is pm2's ProcessContainerFork.js; the real script is pm_exec_path.
const IS_API_PROCESS = path.basename(process.env.pm_exec_path || process.argv[1] || '') === 'server.js';
const POOL_MAX = Number(process.env.DB_POOL_MAX) || (IS_API_PROCESS ? 25 : 10);

const sequelize = new Sequelize(
  process.env.DB_NAME,
  process.env.DB_USER,
  process.env.DB_PASSWORD,
  {
    host: process.env.DB_HOST,
    port: process.env.DB_PORT || 5432,
    dialect: 'postgres',
    logging: false, // set to true for SQL logs
    pool: {
      max: POOL_MAX,  // max connections in pool (see POOL_MAX above)
      min: 2,         // min connections kept open
      acquire: 30000, // max ms to wait for a connection before throwing error
      idle: 10000,    // max ms a connection can be idle before being released
      evict: 1000,    // how often to check for idle connections (ms)
    },
  }
);

export default sequelize;
