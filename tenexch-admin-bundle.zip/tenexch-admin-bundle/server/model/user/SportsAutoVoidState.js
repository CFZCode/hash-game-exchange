import { DataTypes } from 'sequelize';
import sequelize from '../../config/db.js';

/**
 * One row per event the auto-void timer is watching.
 *
 * Written by the results detector (sportsbet/betresult/autoVoid.js) the first
 * time it sees the event's Match Odds / Bookmaker market SETTLE or VOID in the
 * feed. `anchor_seen_at` is OUR clock, never the feed's: a detector restart
 * can only delay a void, never fire it early. The row stays after the void so
 * a late straggler bet on the same event is voided on a later scan too, and
 * so the owner can see when and why the timer fired.
 */
const SportsAutoVoidState = sequelize.define('SportsAutoVoidState', {
    eventid: {
        type: DataTypes.STRING,
        primaryKey: true,
    },
    sport_id: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    match_title: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    anchor_market: {
        type: DataTypes.STRING(32),
        allowNull: false,
        comment: 'MATCH_ODDS | BOOKMAKER — the feed market that started the timer',
    },
    anchor_status: {
        type: DataTypes.STRING(16),
        allowNull: false,
        comment: 'SETTLE | VOID as the feed reported it',
    },
    anchor_seen_at: {
        type: DataTypes.DATE,
        allowNull: false,
    },
    last_fired_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    fire_count: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0,
    },
    bets_voided: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0,
    },
    void_group_ids: {
        type: DataTypes.JSONB,
        allowNull: true,
        comment: 'bet_void_audit.void_group_id of every group this row fired',
    },
    last_error: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
}, {
    tableName: 'sports_auto_void_state',
    timestamps: true,
});

export default SportsAutoVoidState;
