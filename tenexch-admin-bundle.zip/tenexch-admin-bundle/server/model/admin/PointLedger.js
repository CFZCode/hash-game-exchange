// models/PointLedger.js
// Append-only hisaab ki kitaab: all_point ka HAR change yahan ek entry hai.
// Rows kabhi UPDATE/DELETE nahi hoti — galti hui toh REVERSAL entry se sudharo.
// Cron isi table se counters verify karta hai. (Docs: docs/ledgerpoint.md)
import { DataTypes } from 'sequelize';
import sequelize from '../../config/db.js';

const PointLedger = sequelize.define(
  'PointLedger',
  {
    id: { type: DataTypes.BIGINT.UNSIGNED, primaryKey: true, autoIncrement: true },

    // Event ki unique pehchaan — hamesha constants/pointLedger.js ke
    // pointEntryRef builders se banao, haath se nahi
    entry_ref: { type: DataTypes.STRING(120), allowNull: false },

    // VARCHAR rakha (ENUM nahi) — values readable hain ('User creation', 'Bank Deposite')
    // aur naya type aaye toh DB ALTER nahi lagta
    event_type: { type: DataTypes.STRING(40), allowNull: false },

    // Jis wallet ki entry hai usi ka username (reports me join bachata hai)
    username: { type: DataTypes.STRING(100), allowNull: true },

    // Entry ke waqt wallet ka inr_balance kya tha (closing)
    closing_inr_balance: { type: DataTypes.DECIMAL(18, 2), allowNull: true },

    // Doosri side wale (parent/sender) ka closing inr_balance — deposit/withdraw/settle/creation me
    closing_inr_balance_parent: { type: DataTypes.DECIMAL(18, 2), allowNull: true },

    // Sirf BET_SETTLEMENT me: kis sport/game se aaya
    sport_id: { type: DataTypes.STRING(50), allowNull: true },
    game_type: { type: DataTypes.STRING(50), allowNull: true },

    // Sirf BET_SETTLEMENT me bharta hai: POINT_CATEGORY (SPORTS/CASINO/THIRD_PARTY)
    category: { type: DataTypes.STRING(30), allowNull: true },

    // Kis bet se aaya (casino = exact bet id, sports = market ki pehli bet id)
    bet_id: { type: DataTypes.BIGINT, allowNull: true },

    wallet_id: { type: DataTypes.INTEGER, allowNull: false },

    // Sirf CASH_SETTLEMENT me: kiske SAATH hisaab hua (upar wala wallet).
    // Settle-out me entry sirf neeche wale ke wallet me lagti hai — upar wale ka
    // all_point touch nahi hota (sirf cash), uska apna claim upline ke saath
    // tabhi clear hota hai jab upar se settlement aata hai.
    settled_with_wallet_id: { type: DataTypes.INTEGER, allowNull: true },

    // Sign ke saath: jeet +, haar − (BET_SETTLEMENT me chain ke har wallet me same delta)
    delta: { type: DataTypes.DECIMAL(18, 2), allowNull: false },

    // Entry lagne ke turant baad all_point kya bana (audit ke liye)
    all_point_after: { type: DataTypes.DECIMAL(18, 2), allowNull: true },

    // Kis user ke event se ye entry aayi (jeetne/haarne wala user)
    source_user_id: { type: DataTypes.INTEGER, allowNull: true },

    remark: { type: DataTypes.STRING(255), allowNull: true },
  },
  {
    tableName: 'point_ledger',
    timestamps: true,
    createdAt: 'created_at',
    updatedAt: false,
    indexes: [
      // Ek hi key do kaam karti hai:
      //  1. Idempotency — same event same wallet pe dobara INSERT = DB reject
      //  2. Per-wallet SUM — wallet_id prefix + implicit PK id se
      //     "WHERE wallet_id = ? AND id > ?" range bhi isi se chalta hai
      { unique: true, fields: ['wallet_id', 'entry_ref'], name: 'uq_wallet_entry' },
    ],
  }
);

export default PointLedger;
