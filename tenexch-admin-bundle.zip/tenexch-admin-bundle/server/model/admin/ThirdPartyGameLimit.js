import { DataTypes } from 'sequelize';
import sequelize from '../../config/db.js';

// Owner-set max stake for THIRD-PARTY (JS) games, hung on one hierarchy node.
//
//   holder_type = 'OWNER' | 'STAFF' | 'USER',  holder_id = that table's PK.
//
// A row is a DEFAULT for everything below that node: the effective limit of a
// player is the first non-zero value walking USER → parent staff chain → OWNER
// (nearest set value wins — see services/ThirdPartyLimitService.js).
//
// max_amount is per SINGLE bet, not a daily or per-round total. 0 means "no
// limit", and the API deletes the row instead of storing 0 — so a cleared node
// falls back to inheriting from above rather than pinning "unlimited".
//
// Deliberately its own table: `staff` / `users` are the two hottest tables in
// the DB and carry the duplicate-index damage, so nothing here ALTERs them.
const ThirdPartyGameLimit = sequelize.define('ThirdPartyGameLimit', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    holder_type: {
        type: DataTypes.STRING(10),
        allowNull: false,
        comment: "'OWNER' | 'STAFF' | 'USER'",
    },
    holder_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    max_amount: {
        type: DataTypes.DECIMAL(15, 2),
        allowNull: false,
        defaultValue: 0,
        comment: 'Max stake for ONE third-party bet. 0 / no row = no limit',
    },
    // Audit only — nothing reads these to make a decision.
    set_by_type: {
        type: DataTypes.STRING(10),
        allowNull: true,
    },
    set_by_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
}, {
    tableName: 'third_party_game_limits',
    timestamps: true,
    // Declared here, not inline on the column — same reason as BetLimitOverride:
    // an inline `unique: true` makes sync({alter}) re-add the constraint on
    // every boot, which is what bloated staff/users with duplicate indexes.
    indexes: [
        {
            name: 'third_party_game_limits_holder_uniq',
            unique: true,
            fields: ['holder_type', 'holder_id'],
        },
    ],
});

ThirdPartyGameLimit.HOLDER_TYPES = ['OWNER', 'STAFF', 'USER'];

export default ThirdPartyGameLimit;
