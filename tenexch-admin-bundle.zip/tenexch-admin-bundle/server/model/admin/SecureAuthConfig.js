import { DataTypes } from 'sequelize';
import sequelize from '../../config/db.js';

/**
 * Telegram bot used for secure-auth (2FA) — ONE row for the whole site (id 1),
 * so the owner can swap the bot from the admin panel instead of editing .env
 * and redeploying.
 *
 * Seeded from TELEGRAM_BOT_TOKEN on first boot; the DB value wins after that.
 */
const SecureAuthConfig = sequelize.define('SecureAuthConfig', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    bot_username: {
        type: DataTypes.STRING,
        allowNull: true,
        comment: "Bot handle WITHOUT the @, e.g. 'securisep_auth_bot'",
    },
    bot_token: {
        type: DataTypes.STRING,
        allowNull: true,
        comment: 'BotFather token — never returned to the client in full',
    },
}, {
    tableName: 'secure_auth_config',
    timestamps: true,
});

// The single row every read and write goes through.
export const SECURE_AUTH_ROW_ID = 1;

export default SecureAuthConfig;
