import { DataTypes } from 'sequelize';
import sequelize from '../../config/db.js';

const TableCasino = sequelize.define('TableCasino', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    tableid: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    tablename: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    // position on the reference's casino list; the list API orders by it
    sort_order: {
        type: DataTypes.INTEGER,
        allowNull: true,
    }
}, {
    tableName: 'table_casino',
    timestamps: true,
});


// 🧱 Predefined Tables
// Same tables, same labels, same order as the reference's General Lock
// "Casino List" (admin/excepted.txt, 2026-09-22): 171 rows. `sort_order` is
// the row's position on the reference. `tableid` is a LOCK/BET KEY — matched
// exactly (case-sensitive) by controller/casino/casinoController.js and the
// settlement worker — so ids 1-81 keep the spelling our feed sends even where
// the reference capitalises ("teen", not "Teen"). ids 82-171 are the tables
// the reference lists that we never had; their key is the reference's.
// `tablename` is display only.
TableCasino.FIXED_TABLES = [
  { id: 1, tableid: "teen", tablename: "Teenpatti 1-day", sort_order: 1 },
  { id: 2, tableid: "poker", tablename: "Poker 1-Day", sort_order: 2 },
  { id: 3, tableid: "baccarat", tablename: "Baccarat", sort_order: 7 },
  { id: 4, tableid: "baccarat2", tablename: "Baccarat 2", sort_order: 8 },
  { id: 5, tableid: "card32", tablename: "32 Cards A", sort_order: 10 },
  { id: 6, tableid: "card32eu", tablename: "32 Cards B", sort_order: 11 },
  { id: 7, tableid: "dt20", tablename: "20-20 Dragon Tiger", sort_order: 17 },
  { id: 8, tableid: "dt6", tablename: "1 Day Dragon Tiger", sort_order: 19 },
  { id: 9, tableid: "lucky7", tablename: "Lucky 7 - A", sort_order: 22 },
  { id: 10, tableid: "lucky7eu", tablename: "Lucky 7 - B", sort_order: 23 },
  { id: 11, tableid: "poker20", tablename: "20-20 Poker", sort_order: 24 },
  { id: 12, tableid: "poker6", tablename: "Poker 6 Players", sort_order: 25 },
  { id: 13, tableid: "teen20", tablename: "20-20 Teenpatti", sort_order: 26 },
  { id: 14, tableid: "teen8", tablename: "Teenpatti Open", sort_order: 27 },
  { id: 15, tableid: "teen9", tablename: "Teenpatti Test", sort_order: 28 },
  { id: 16, tableid: "queen", tablename: "Queen", sort_order: 41 },
  { id: 17, tableid: "lucky7eu2", tablename: "Lucky 7 - C", sort_order: 44 },
  { id: 18, tableid: "superover", tablename: "Super Over", sort_order: 45 },
  { id: 19, tableid: "trap", tablename: "The Trap", sort_order: 46 },
  { id: 20, tableid: "patti2", tablename: "2 Cards Teenpatti", sort_order: 49 },
  { id: 21, tableid: "teensin", tablename: "29Card Baccarat", sort_order: 50 },
  { id: 22, tableid: "teenmuf", tablename: "Muflis Teenpatti", sort_order: 51 },
  { id: 23, tableid: "race17", tablename: "Race to 17", sort_order: 55 },
  { id: 24, tableid: "teen20b", tablename: "20-20 Teenpatti B", sort_order: 56 },
  { id: 25, tableid: "trio", tablename: "Trio", sort_order: 58 },
  { id: 26, tableid: "notenum", tablename: "Note Number", sort_order: 59 },
  { id: 27, tableid: "teen1", tablename: "1 CARD ONE-DAY", sort_order: 64 },
  { id: 28, tableid: "race2", tablename: "Race to 2nd", sort_order: 83 },
  { id: 29, tableid: "teen32", tablename: "Instant Teenpatti 2.0", sort_order: 98 },
  { id: 30, tableid: "dum10", tablename: "Dus ka Dum", sort_order: 88 },
  { id: 31, tableid: "sicbo", tablename: "Sic Bo", sort_order: 101 },
  { id: 32, tableid: "ballbyball", tablename: "Ball by ball", sort_order: 102 },
  { id: 33, tableid: "teen33", tablename: "Instant Teenpatti 3.0", sort_order: 104 },
  { id: 34, tableid: "superover2", tablename: "Super Over2", sort_order: 107 },
  { id: 35, tableid: "sicbo2", tablename: "Sic Bo 2", sort_order: 109 },
  { id: 36, tableid: "teen41", tablename: "Queen Top Open Teenpatti", sort_order: 111 },
  { id: 37, tableid: "teen42", tablename: "Jack Top Open Teenpatti", sort_order: 112 },
  { id: 38, tableid: "lucky15", tablename: "Lucky 15", sort_order: 113 },
  { id: 39, tableid: "goal", tablename: "Goal", sort_order: 114 },
  { id: 40, tableid: "superover3", tablename: "Mini SuperOver", sort_order: 117 },
  { id: 41, tableid: "teen20c", tablename: "20-20 Teenpatti C", sort_order: 119 },
  { id: 42, tableid: "joker20", tablename: "Teenpatti Joker 20-20", sort_order: 128 },
  { id: 43, tableid: "poison20", tablename: "Teenpatti Poison 20-20", sort_order: 130 },
  { id: 44, tableid: "poison", tablename: "Teenpatti Poison One Day", sort_order: 133 },
  { id: 45, tableid: "lucky5", tablename: "Lucky 6", sort_order: 152 },
  { id: 46, tableid: "mogambo", tablename: "Mogambo", sort_order: 153 },
  { id: 47, tableid: "dolidana", tablename: "Doli Dana", sort_order: 154 },
  { id: 48, tableid: "teen62", tablename: "V VIP Teenpatti 1-day", sort_order: 160 },
  { id: 49, tableid: "dtl20", tablename: "20-20 D T L", sort_order: 20 },
  { id: 50, tableid: "dt202", tablename: "20-20 Dragon Tiger 2", sort_order: 18 },
  { id: 51, tableid: "kbc", tablename: "K.B.C", sort_order: 61 },
  { id: 52, tableid: "race20", tablename: "Race20", sort_order: 42 },
  { id: 53, tableid: "ab20", tablename: "Andar Bahar", sort_order: 5 },
  { id: 54, tableid: "abj", tablename: "Andar Bahar 2", sort_order: 6 },
  { id: 55, tableid: "ab3", tablename: "ANDAR BAHAR 50 CARDS", sort_order: 77 },
  { id: 56, tableid: "ab4", tablename: "ANDAR BAHAR 150 CARDS", sort_order: 116 },
  { id: 57, tableid: "aaa", tablename: "Amar Akbar Anthony", sort_order: 4 },
  { id: 58, tableid: "aaa2", tablename: "Amar Akbar Anthony 2", sort_order: 79 },
  { id: 59, tableid: "3cardj", tablename: "3 Cards Judgement", sort_order: 3 },
  { id: 60, tableid: "war", tablename: "Casino War", sort_order: 29 },
  { id: 61, tableid: "worli", tablename: "Worli Matka", sort_order: 30 },
  { id: 62, tableid: "worli2", tablename: "Instant Worli", sort_order: 31 },
  { id: 63, tableid: "worli3", tablename: "Matka", sort_order: 158 },
  { id: 64, tableid: "btable", tablename: "Bollywood Casino", sort_order: 9 },
  { id: 65, tableid: "btable2", tablename: "Bollywood Casino 2", sort_order: 120 },
  { id: 66, tableid: "lottcard", tablename: "lottcard", sort_order: 21 },
  { id: 67, tableid: "cricketv3", tablename: "5Five Cricket", sort_order: 16 },
  { id: 68, tableid: "cmatch20", tablename: "Cricket Match 20-20", sort_order: 12 },
  { id: 69, tableid: "cmeter", tablename: "Casino Meter", sort_order: 13 },
  { id: 70, tableid: "cmeter1", tablename: "1 Card Meter", sort_order: 89 },
  { id: 71, tableid: "teen6", tablename: "Teenpatti - 2.0", sort_order: 40 },
  { id: 72, tableid: "teen3", tablename: "Instant Teenpatti", sort_order: 86 },
  { id: 73, tableid: "teen120", tablename: "1 CARD 20-20", sort_order: 63 },
  { id: 74, tableid: "teenunique", tablename: "Unique Teenpatti", sort_order: 132 },
  { id: 75, tableid: "joker1", tablename: "Unlimited Joker One Day", sort_order: 127 },
  { id: 76, tableid: "joker120", tablename: "Unlimited Joker 20-20", sort_order: 129 },
  { id: 77, tableid: "goal2", tablename: "Goal 2", sort_order: 166 },
  { id: 78, tableid: "roulette11", tablename: "VIP Roulette", sort_order: 134 },
  { id: 79, tableid: "roulette12", tablename: "Beach Roulette", sort_order: 135 },
  { id: 80, tableid: "roulette13", tablename: "Regular Roulette", sort_order: 136 },
  { id: 81, tableid: "ourroullete", tablename: "Unique Roulette", sort_order: 118 },
  { id: 82, tableid: "CricketV", tablename: "Cricket V", sort_order: 14 },
  { id: 83, tableid: "CricketV2", tablename: "Cricket V2", sort_order: 15 },
  { id: 84, tableid: "dream", tablename: "Diam11", sort_order: 32 },
  { id: 85, tableid: "daba", tablename: "Player Battle", sort_order: 33 },
  { id: 86, tableid: "runner", tablename: "Runner", sort_order: 34 },
  { id: 87, tableid: "cockfight", tablename: "Cockfight", sort_order: 35 },
  { id: 88, tableid: "ezugi", tablename: "Ezugi", sort_order: 36 },
  { id: 89, tableid: "ss", tablename: "Super Spade", sort_order: 37 },
  { id: 90, tableid: "qt", tablename: "QTech", sort_order: 38 },
  { id: 91, tableid: "evo", tablename: "Evolution", sort_order: 39 },
  { id: 92, tableid: "pop-the-ball", tablename: "Pop The Ball", sort_order: 43 },
  { id: 93, tableid: "binary", tablename: "Binary", sort_order: 47 },
  { id: 94, tableid: "ludo-club", tablename: "Ludo Club", sort_order: 48 },
  { id: 95, tableid: "rummy", tablename: "Rummy", sort_order: 52 },
  { id: 96, tableid: "slot", tablename: "Slot", sort_order: 53 },
  { id: 97, tableid: "tgs", tablename: "Slot 2", sort_order: 54 },
  { id: 98, tableid: "TGSLive", tablename: "VivoGames-LuckyStreak", sort_order: 57 },
  { id: 99, tableid: "teen2024", tablename: "Teen 20 24", sort_order: 60 },
  { id: 100, tableid: "ludo-lands", tablename: "Ludo Lands", sort_order: 62 },
  { id: 101, tableid: "vteen20", tablename: "V-20-20 Teenpatti", sort_order: 65 },
  { id: 102, tableid: "vteen", tablename: "V-Teenpatti 1-day", sort_order: 66 },
  { id: 103, tableid: "vdt6", tablename: "V-1 Day Dragon Tiger", sort_order: 67 },
  { id: 104, tableid: "vdt20", tablename: "V-20-20 Dragon Tiger", sort_order: 68 },
  { id: 105, tableid: "vlucky7", tablename: "V-Lucky 7 - A", sort_order: 69 },
  { id: 106, tableid: "vrace17", tablename: "V-Race to 17", sort_order: 70 },
  { id: 107, tableid: "vteenmuf", tablename: "V-Muflis Teenpatti", sort_order: 71 },
  { id: 108, tableid: "vaaa", tablename: "V-Amar Akbar Anthony", sort_order: 72 },
  { id: 109, tableid: "vbtable", tablename: "V-Bollywood Casino", sort_order: 73 },
  { id: 110, tableid: "vbaccarat", tablename: "V-Baccarat", sort_order: 74 },
  { id: 111, tableid: "vtrio", tablename: "V-Trio", sort_order: 75 },
  { id: 112, tableid: "vtrap", tablename: "V-The Trap", sort_order: 76 },
  { id: 113, tableid: "vdtl20", tablename: "V-20-20 D T L", sort_order: 78 },
  { id: 114, tableid: "vivo", tablename: "Vivo Gaming", sort_order: 80 },
  { id: 115, tableid: "snakes-and-ladders", tablename: "snakes and ladders", sort_order: 81 },
  { id: 116, tableid: "roulette", tablename: "roulette", sort_order: 82 },
  { id: 117, tableid: "Astar", tablename: "Astar Game", sort_order: 84 },
  { id: 118, tableid: "smart", tablename: "Smart Soft", sort_order: 85 },
  { id: 119, tableid: "bc", tablename: "Creedroomz", sort_order: 87 },
  { id: 120, tableid: "bota", tablename: "Bota", sort_order: 90 },
  { id: 121, tableid: "tembo", tablename: "Tembo", sort_order: 91 },
  { id: 122, tableid: "ds", tablename: "Dragoon Soft", sort_order: 92 },
  { id: 123, tableid: "av", tablename: "Spribe", sort_order: 93 },
  { id: 124, tableid: "bcslot", tablename: "Pascal Game", sort_order: 94 },
  { id: 125, tableid: "lottery", tablename: "Lottery", sort_order: 95 },
  { id: 126, tableid: "radar", tablename: "sportbook", sort_order: 96 },
  { id: 127, tableid: "bti", tablename: "sportbook 1", sort_order: 97 },
  { id: 128, tableid: "prgslot", tablename: "Pragamatic slot", sort_order: 99 },
  { id: 129, tableid: "prglive", tablename: "Pragamatic live", sort_order: 100 },
  { id: 130, tableid: "roulette1", tablename: "roulette1", sort_order: 103 },
  { id: 131, tableid: "Scratch", tablename: "Scratch", sort_order: 105 },
  { id: 132, tableid: "roulette2", tablename: "roulette2", sort_order: 106 },
  { id: 133, tableid: "roulette3", tablename: "roulette3", sort_order: 108 },
  { id: 134, tableid: "Darwin", tablename: "Darwin", sort_order: 110 },
  { id: 135, tableid: "pg", tablename: "Pocket Game", sort_order: 115 },
  { id: 136, tableid: "bet", tablename: "betcore", sort_order: 121 },
  { id: 137, tableid: "teenjoker", tablename: "Teenpatti Joker", sort_order: 122 },
  { id: 138, tableid: "gemini1", tablename: "Gemini", sort_order: 123 },
  { id: 139, tableid: "Jilli", tablename: "Jilli", sort_order: 124 },
  { id: 140, tableid: "gemini2", tablename: "gemini live", sort_order: 125 },
  { id: 141, tableid: "Win", tablename: "Red Carat", sort_order: 126 },
  { id: 142, tableid: "Amigo", tablename: "Amigo", sort_order: 131 },
  { id: 143, tableid: "egt", tablename: "EGT", sort_order: 137 },
  { id: 144, tableid: "pteen", tablename: "Premium Teenpatti 1-day", sort_order: 138 },
  { id: 145, tableid: "pteen20", tablename: "Premium 20-20 Teenpatti", sort_order: 139 },
  { id: 146, tableid: "pdt6", tablename: "Premium 1 Day Dragon Tiger", sort_order: 140 },
  { id: 147, tableid: "pdt20", tablename: "Premium 20-20 Dragon Tiger", sort_order: 141 },
  { id: 148, tableid: "plucky7", tablename: "Premium Lucky 7", sort_order: 142 },
  { id: 149, tableid: "pcard32", tablename: "Premium 32 Cards", sort_order: 143 },
  { id: 150, tableid: "pbaccarat", tablename: "Premium Baccarat", sort_order: 144 },
  { id: 151, tableid: "tteen", tablename: "Tembo Teenpatti 1-day", sort_order: 145 },
  { id: 152, tableid: "tteen20", tablename: "Tembo 20-20 Teenpatti", sort_order: 146 },
  { id: 153, tableid: "tdt6", tablename: "Tembo 1 Day Dragon Tiger", sort_order: 147 },
  { id: 154, tableid: "tdt20", tablename: "Tembo 20-20 Dragon Tiger", sort_order: 148 },
  { id: 155, tableid: "tlucky7", tablename: "Tembo Lucky 7", sort_order: 149 },
  { id: 156, tableid: "tcard32", tablename: "Tembo 32 Cards", sort_order: 150 },
  { id: 157, tableid: "tbaccarat", tablename: "Tembo Baccarat", sort_order: 151 },
  { id: 158, tableid: "exa", tablename: "EXA", sort_order: 155 },
  { id: 159, tableid: "studio21", tablename: "Studio21", sort_order: 156 },
  { id: 160, tableid: "teen20v", tablename: "20-20 Teenpatti VIP", sort_order: 157 },
  { id: 161, tableid: "GVI", tablename: "GVI", sort_order: 159 },
  { id: 162, tableid: "beon", tablename: "Beon Gaming", sort_order: 161 },
  { id: 163, tableid: "Playtech", tablename: "Play Tech", sort_order: 162 },
  { id: 164, tableid: "King", tablename: "king", sort_order: 163 },
  { id: 165, tableid: "bb", tablename: "DimCL", sort_order: 164 },
  { id: 166, tableid: "avnew", tablename: "Aviator New", sort_order: 165 },
  { id: 167, tableid: "exanew1", tablename: "EXA Live", sort_order: 167 },
  { id: 168, tableid: "exanew2", tablename: "EXA Fantasy", sort_order: 168 },
  { id: 169, tableid: "exanew3", tablename: "EXA Slot", sort_order: 169 },
  { id: 170, tableid: "dimfantasy", tablename: "Fantasy", sort_order: 170 },
  { id: 171, tableid: "teenholdem", tablename: "Teenpatti Holdem", sort_order: 171 },
];

// 🧩 Function to insert (or verify) fixed records
TableCasino.syncFixedData = async () => {
    try {
        for (const table of TableCasino.FIXED_TABLES) {
            // Using upsert to ensure all fields are up-to-date, or findOrCreate if we only want to ensure existence.
            // Given "sync with current state", upsert is safer to enforce the definition.
            // However, verify if user meant "if not there". 
            // "insert pladtform games if not there" -> findOrCreate logic is safer for preserving custom edits if any.
            // User said: "sync table games which insert tables data"
            // Let's use findOrCreate logic as in PlatformGames example provided by user.
            
            await TableCasino.findOrCreate({
                where: { id: table.id },
                defaults: table,
            });
            
            // Also ensure the exact data if it exists? 
            // PlatformGames example did: findOrCreate, then explicit update.
            // Let's stick to findOrCreate first. If they want to force update, they can say so.
            // Actually, for table_id stability, we probably want to ensure tableid and tablename match ID.
            
            // Checking if we should enforce updates.
             const existing = await TableCasino.findByPk(table.id);
             if (existing) {
                 if (existing.tableid !== table.tableid || existing.tablename !== table.tablename || existing.sort_order !== table.sort_order) {
                     await existing.update({ tableid: table.tableid, tablename: table.tablename, sort_order: table.sort_order });
                 }
             }
        }
        console.log("✅ TableCasino table verified and fixed data ensured.");
    } catch (error) {
        console.error("❌ Error syncing TableCasino data:", error);
    }
};

export default TableCasino;
