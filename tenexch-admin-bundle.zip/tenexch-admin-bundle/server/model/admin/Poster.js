import { DataTypes } from 'sequelize';
import sequelize from '../../config/db.js'; // Adjust the path as needed

// One row per variant (web / mobile): holds the welcome poster image links (upserted, never listed)
const Poster = sequelize.define('Poster', {
    poster_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    image_url: {
        type: DataTypes.TEXT,
        allowNull: false,
    },
    is_mobile: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false, // false = web poster, true = mobile poster
    },
}, {
    tableName: 'posters',
    timestamps: true, // Adds createdAt and updatedAt fields
});

export default Poster;
