import { DataTypes } from 'sequelize';
import sequelize from '../../config/db.js';
import { DEFAULT_LEAGUE_KEY, isValidLeagueKey } from '../../constants/commissionLeagues.js';

// Owner-set maximum rate (odds) per sport × league × market category. A bet
// whose rate is ABOVE max_odds is refused at placement with
// "Bet Not Accept Rate Over <max> on <Sport>" (sportbetscontroller STEP 4.6).
//
// Keyed by (sport_id, league_key, category):
//   league_key 'default' = every ordinary league of the sport, plus the
//              variants in constants/commissionLeagues.js (cricket's ecricket /
//              t10xi / t5xi / vcl, wrestling's wwevirtual) — the same tabs as
//              the Commission grid. A variant cell with NO row inherits the
//              'default' cell; a saved variant row wins, and max_odds 0 there
//              means "no cap for this league".
//   category 'match_odds' → gtype 'match'  (decimal odds, e.g. 1.85)
//   category 'bookmaker'  → gtype 'match1' (the board's own scale, 93 = 1.93)
// Fancy-family markets are never capped — their "rate" is a run line.
//
// limited_overs_only (cricket only): the cap applies to Oneday / T20 matches,
// Test formats are exempt, and the message reads "... on Oneday and T20".
// This replaced the hardcoded 4.00 ODI/T20 rule; dbInit seeds that rule as the
// first row so the platform keeps the cap until the owner changes it.
//
// max_odds 0 = no cap. category is VARCHAR + a JS whitelist, NOT a Postgres
// enum: dbInit's blanket alter-sync is disabled and enum values can't be added
// by sync(). Plans: docs/plans/2026-09-11-football-rate-cap.md,
// docs/plans/2026-09-15-buffer-maxodds-league-market-grid.md
const MaxOddsConfig = sequelize.define('MaxOddsConfig', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    sport_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        comment: 'feed etid (4 = Cricket)',
    },
    league_key: {
        type: DataTypes.STRING(32),
        allowNull: false,
        defaultValue: DEFAULT_LEAGUE_KEY,
        comment: 'default | ecricket | t10xi | t5xi | vcl | wwevirtual',
    },
    category: {
        type: DataTypes.STRING(20),
        allowNull: false,
        comment: "'match_odds' | 'bookmaker'",
    },
    max_odds: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false,
        defaultValue: 0,
        comment: 'bet refused when rate > this; 0 = no cap',
    },
    limited_overs_only: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        comment: 'cricket only: Oneday/T20 capped, Test exempt',
    },
}, {
    tableName: 'max_odds_configs',
    timestamps: true,
    // Uniqueness lives here, never inline on the column: an inline `unique`
    // makes Sequelize emit a fresh ADD CONSTRAINT on every sync, which is how
    // this platform's DBs collected thousands of duplicate unique constraints.
    indexes: [
        {
            name: 'max_odds_configs_sport_league_category_uniq',
            unique: true,
            fields: ['sport_id', 'league_key', 'category'],
        },
    ],
});

MaxOddsConfig.CATEGORIES = ['match_odds', 'bookmaker'];
MaxOddsConfig.MAX_VALUE = 1000;
// The only sport the "Oneday & T20 only" condition means anything for.
MaxOddsConfig.LIMITED_OVERS_SPORT_ID = 4;
MaxOddsConfig.DEFAULT_LEAGUE_KEY = DEFAULT_LEAGUE_KEY;
MaxOddsConfig.isValidLeagueKey = isValidLeagueKey;

// gtype (feed) → max-odds category, or null for markets that are never capped.
// Frontend mirror: maxOddsCategoryOf() in frontend/src/apiservices/bettingConfig.js.
MaxOddsConfig.categoryFromGtype = (gtype) => {
    const g = String(gtype || '').toLowerCase();
    if (g === 'match') return 'match_odds';
    if (g === 'match1') return 'bookmaker';
    return null;
};

export default MaxOddsConfig;
