import { DataTypes } from 'sequelize';
import sequelize from '../../config/db.js';
import {
    DEFAULT_LEAGUE_KEY,
    leagueKeyFromName,
    isValidLeagueKey,
} from '../../constants/commissionLeagues.js';

// ─────────────────────────────────────────────────────────────────────────────
// Sports win commission, owner-configurable per sport × league × market.
//
// Keyed by (sport_id, league_key, market_key):
//
//   league_key   'default' = every ordinary league of that sport. Cricket also
//                has 'ecricket' / 't10xi' / 't5xi' / 'vcl' — the feed ships
//                those as sport_id 4 too, so without this dimension one Cricket
//                cell covered real matches AND virtual rounds.
//                See constants/commissionLeagues.js.
//
//   market_key   finer than the feed's gtype. gtype 'match' is NOT "Match
//                Odds" — it is every main market (MATCH_ODDS, OVER_UNDER_25,
//                CORRECT_SCORE, Match Result, "… Inning EvenOdd", "3rd Ball Of
//                Match", …). So 'match' is split into 'matchodds' (market name
//                is literally Match Odds) and 'match_other', and 'match1' into
//                'bookmaker' (Bookmaker, Bookmaker 2) and 'match1_other'
//                (Tied Match, Completed Match, Score More Runs, BM_OVER_UNDER…).
//
// A cell only charges when `enabled` is true AND `percent` > 0. Settlement
// deducts percent × NET WIN of the market (MO/BM: whole market; FAN: per bet)
// and writes a separate "…- Comm" row. Missing row = nothing charged.
//
// A variant-league cell with NO row INHERITS the sport's 'default' row — see
// services/CommissionConfigService.js getRule(). Only 'default' rows are
// terminal; absence there means "no commission".
//
// league_key / market_key are VARCHAR + a JS whitelist, NOT Postgres enums:
// dbInit's blanket alter-sync is disabled and enum values can't be added by
// sync().
// ─────────────────────────────────────────────────────────────────────────────
const CommissionConfig = sequelize.define('CommissionConfig', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    sport_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        comment: 'feed etid (4 = Cricket)',
    },
    league_key: {
        type: DataTypes.STRING(32),
        allowNull: false,
        defaultValue: DEFAULT_LEAGUE_KEY,
        comment: "default | ecricket | t10xi | t5xi | vcl | wwevirtual",
    },
    market_key: {
        type: DataTypes.STRING(24),
        allowNull: false,
        comment: 'matchodds | match_other | bookmaker | match1_other | fancy | …',
    },
    enabled: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
    },
    percent: {
        type: DataTypes.DECIMAL(5, 2),
        allowNull: false,
        defaultValue: 2,
        comment: 'commission % of net win',
    },
}, {
    tableName: 'commission_configs',
    timestamps: true,
    // Uniqueness lives here, never inline on the column: an inline `unique`
    // makes Sequelize emit a fresh ADD CONSTRAINT on every sync, which is how
    // this platform's DBs collected thousands of duplicate unique constraints.
    indexes: [
        {
            name: 'commission_configs_sport_league_market_uniq',
            unique: true,
            fields: ['sport_id', 'league_key', 'market_key'],
        },
    ],
});

// Markets the owner can configure, in display order, grouped for the admin
// grid. `group` only drives the UI's column headers.
CommissionConfig.MARKETS = [
    { key: 'matchodds', label: 'Match Odds', group: 'Main', hint: 'market name is exactly Match Odds' },
    { key: 'match_other', label: 'Other Main Markets', group: 'Main', hint: 'Over/Under, Correct Score, Match Result, Inning EvenOdd, Nth Ball…' },
    { key: 'bookmaker', label: 'Bookmaker', group: 'Bookmaker', hint: 'Bookmaker, Bookmaker 2' },
    { key: 'match1_other', label: 'Other Bookmaker Markets', group: 'Bookmaker', hint: 'Tied Match, Completed Match, Score More Runs, BM Over/Under…' },
    { key: 'fancy', label: 'Fancy', group: 'Fancy', hint: 'Normal, Over By Over, Ball By Ball' },
    { key: 'fancy1', label: 'Fancy1', group: 'Fancy', hint: '' },
    { key: 'fancy2', label: 'Fancy2', group: 'Fancy', hint: 'Innings Overs/Runs lines' },
    { key: 'oddeven', label: 'Odd/Even', group: 'Fancy', hint: '' },
    { key: 'khado', label: 'Khado', group: 'Fancy', hint: '' },
    { key: 'meter', label: 'Meter', group: 'Fancy', hint: '' },
    { key: 'badlo', label: 'Badlo', group: 'Fancy', hint: '' },
    { key: 'cricketcasino', label: 'Cricket Casino', group: 'Fancy', hint: '' },
    { key: 'other', label: 'Other', group: 'Fancy', hint: 'anything the feed ships with an unknown gtype' },
];
CommissionConfig.MARKET_KEYS = CommissionConfig.MARKETS.map((m) => m.key);
CommissionConfig.MAX_PERCENT = 50;
CommissionConfig.DEFAULT_PERCENT = 2;

// gtypes that ARE a market key one-for-one (everything except match / match1,
// which get split by market name below).
const DIRECT_GTYPES = new Set([
    'fancy', 'fancy1', 'fancy2', 'oddeven', 'khado', 'meter', 'badlo', 'cricketcasino',
]);

// Market NAME, comparable: upper-cased with every non-alphanumeric stripped.
// 'MATCH_ODDS' and 'Match Odds' both become 'MATCHODDS'; 'Bookmaker 2' becomes
// 'BOOKMAKER2'; 'BM_OVER_UNDER_25' becomes 'BMOVERUNDER25' (NOT a bookmaker).
const normMarketName = (name) => String(name || '').toUpperCase().replace(/[^A-Z0-9]/g, '');

/**
 * The commission market key for a bet. Never throws, always returns a key that
 * exists in MARKET_KEYS.
 *
 * SportsBet.gtype is set on every live bet; the game_type fallback (MO/BM/FAN)
 * only guards legacy rows written before gtype was stored.
 */
CommissionConfig.marketKeyOfBet = (bet) => {
    // Badlo is stored as a session row (gtype 'fancy') and marked ONLY by the
    // SportsBet.badlo flag (helper/badloMarket.js isBadloBet). Checked first,
    // otherwise every badlo bet fell into the Fancy cell and the Badlo cell
    // could never match anything.
    if (bet?.badlo === true || String(bet?.badlo) === 'true') return 'badlo';

    let g = String(bet?.gtype || '').toLowerCase().trim();
    if (!g) {
        const gt = String(bet?.game_type || '').toUpperCase();
        if (gt === 'MO' || gt === 'MATCH') g = 'match';
        else if (gt === 'BM' || gt === 'BOOKMAKER') g = 'match1';
        else if (gt === 'FAN' || gt === 'FANCY') g = 'fancy';
    }

    const name = normMarketName(bet?.market_type);
    if (g === 'match') return name === 'MATCHODDS' ? 'matchodds' : 'match_other';
    if (g === 'match1') return name.startsWith('BOOKMAKER') ? 'bookmaker' : 'match1_other';
    if (DIRECT_GTYPES.has(g)) return g;
    return 'other';
};

/**
 * The commission league key for a bet, from the feed cname stored on the row.
 * NULL / unknown league → 'default'.
 */
CommissionConfig.leagueKeyOfBet = (bet) =>
    leagueKeyFromName(bet?.sport_id, bet?.league_name);

CommissionConfig.isValidLeagueKey = isValidLeagueKey;
CommissionConfig.DEFAULT_LEAGUE_KEY = DEFAULT_LEAGUE_KEY;

// Legacy aliases — the pre-2026-09-12 grid was keyed by raw gtype. dbInit's
// migration expands those rows; these two only exist so an old row still maps
// somewhere if the migration has not run yet on some clone.
CommissionConfig.LEGACY_GTYPE_EXPANSION = {
    match: ['matchodds', 'match_other'],
    match1: ['bookmaker', 'match1_other'],
};

export default CommissionConfig;
