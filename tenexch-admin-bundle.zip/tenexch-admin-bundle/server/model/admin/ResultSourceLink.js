import { DataTypes } from 'sequelize';
import sequelize from '../../config/db.js';

/**
 * Result Source Links — owner-managed websites the team opens to look up a
 * result from the Pending Result Tracker (Settings → Auto Void).
 *
 * `url` may carry placeholders, filled in by the panel:
 *   {match}  → the event title  ("India v Australia")
 *   {market} → the market name  ("Most Wickets Bowler")
 * A link WITH {market} is shown on every market row (a per-market search);
 * a link without it is shown once per event.
 *
 * `sport_id` NULL = every sport, else one feed sport id (4 = Cricket).
 */
const ResultSourceLink = sequelize.define('ResultSourceLink', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    name: {
        type: DataTypes.STRING(60),
        allowNull: false,
    },
    url: {
        type: DataTypes.STRING(1000),
        allowNull: false,
    },
    sport_id: {
        type: DataTypes.STRING(10),
        allowNull: true,
    },
    sort_order: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0,
    },
    active: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
    },
}, {
    tableName: 'result_source_links',
    timestamps: true,
});

// Starter set, inserted only while the table is empty. The owner edits or
// deletes these freely afterwards.
const DEFAULT_LINKS = [
    { name: 'Cricbuzz Live', url: 'https://www.cricbuzz.com/cricket-match/live-scores', sport_id: '4', sort_order: 1 },
    { name: 'Cricbuzz Recent', url: 'https://www.cricbuzz.com/cricket-match/live-scores/recent-matches', sport_id: '4', sort_order: 2 },
    { name: 'ESPNcricinfo', url: 'https://www.espncricinfo.com/live-cricket-score', sport_id: '4', sort_order: 3 },
    { name: 'Flashscore', url: 'https://www.flashscore.com/', sport_id: null, sort_order: 10 },
    { name: 'SofaScore', url: 'https://www.sofascore.com/', sport_id: null, sort_order: 11 },
    { name: 'Google Scorecard', url: 'https://www.google.com/search?q={match}+scorecard', sport_id: null, sort_order: 20 },
    { name: 'Google', url: 'https://www.google.com/search?q={match}+{market}', sport_id: null, sort_order: 30 },
];

let ready = null;
/** Create the table and seed the defaults once per process. */
export const ensureResultSourceLinks = () => {
    if (!ready) {
        ready = (async () => {
            await ResultSourceLink.sync();
            if (!(await ResultSourceLink.count())) await ResultSourceLink.bulkCreate(DEFAULT_LINKS);
        })().catch((e) => { ready = null; throw e; });
    }
    return ready;
};

export default ResultSourceLink;
