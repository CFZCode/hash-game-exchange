


// models/Wallet.js
import { DataTypes } from 'sequelize';
import sequelize from '../../config/db.js';
import Staff from './Staff.js';

// profit_loss is DERIVED, never authoritative in storage.
//
// It is defined as inr_balance − cash_received. The beforeCreate/beforeUpdate hooks below
// keep the stored column right whenever a wallet is saved as an INSTANCE — but a large part
// of this codebase moves money with `Wallet.increment({ inr_balance: … })` and bulk
// `Wallet.update(…, { where })`, and BOTH bypass instance hooks entirely. Every such path
// left the stored copy behind: 17 of 73 live wallets were stale, and one account showed a
// −200.00 "inconsistency" that was simply two credit-path movements the hooks never saw.
//
// So the value is recomputed on every READ as well (afterFind). Consumers therefore always
// get the correct figure no matter how the row was written, including from write paths added
// later that nobody remembers to patch. The stored column is a cache; the formula is truth.
//
// Anything reading this column in RAW SQL (bypassing the model) must derive it itself —
// `inr_balance - cash_received` — and not trust the stored value.
// Plan: docs/plans/2026-08-23-profit-loss-derived.md
function calculateProfitLoss(instance) {
  const cashReceived = parseFloat(instance.getDataValue('cash_received')) || 0;
  const inrBalance   = parseFloat(instance.getDataValue('inr_balance')) || 0;

  const profitLoss = parseFloat((inrBalance - cashReceived).toFixed(2));
  const verdict    = profitLoss >= 0 ? 'profit' : 'loss';

  instance.setDataValue('profit_loss', profitLoss);
  instance.setDataValue('verdict',    verdict);
}

const Wallet = sequelize.define(
  'Wallet',
  {
    wallet_id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },

    // Generic Reference Fields
    user_id:   { type: DataTypes.INTEGER, allowNull: true, comment: 'Reference for normal user wallet (end user)' },
    staff_id:  { type: DataTypes.INTEGER, allowNull: true, comment: 'Reference for staff wallet (admin/supermaster/master)' },
    owner_id:  { type: DataTypes.INTEGER, allowNull: true, comment: 'Reference for owner wallet (top-level company or super admin)' },

    // Wallet Classification
    user_type: {
      type: DataTypes.ENUM('OWNER','COMPANY','SUPERADMIN','ADMIN','SUPERMASTER','MASTER','AGENT','USER'),
      allowNull: false,
    },

    // Wallet Info
    username: { type: DataTypes.STRING, allowNull: false, unique: true },

    // Core Financial Fields
    inr_balance: { type: DataTypes.DECIMAL(18,2), allowNull: false, defaultValue: 0.0 },
    cash:        { type: DataTypes.DECIMAL(18,2), allowNull: false, defaultValue: 0.0 },
    credit:      { type: DataTypes.DECIMAL(18,2), allowNull: false, defaultValue: 0.0 },
    cash_received:   { type: DataTypes.DECIMAL(18,2), allowNull: false, defaultValue: 0.0 },
    // Initial credit handed over at account creation (set once, first time)
    all_point:   { type: DataTypes.DECIMAL(18,2), allowNull: false, defaultValue: 0.0 },
    // Cash settlement ka running total: upper_point = apne upline ke saath hua hisaab,
    // down_point = apne downline ke saath hua hisaab
    upper_point: { type: DataTypes.DECIMAL(18,2), allowNull: false, defaultValue: 0.0 },
    down_point:  { type: DataTypes.DECIMAL(18,2), allowNull: false, defaultValue: 0.0 },
    // Category-wise settlement points ka running total
    casino_pts:     { type: DataTypes.DECIMAL(18,2), allowNull: false, defaultValue: 0.0 },
    sports_pts:     { type: DataTypes.DECIMAL(18,2), allowNull: false, defaultValue: 0.0 },
    thirdparty_pts: { type: DataTypes.DECIMAL(18,2), allowNull: false, defaultValue: 0.0 },
    sportsbook_pts: { type: DataTypes.DECIMAL(18,2), allowNull: false, defaultValue: 0.0 },

    // Calculated Metrics
    profit_loss: { type: DataTypes.DECIMAL(18,2), allowNull: false, defaultValue: 0.0 },
    verdict:     { type: DataTypes.ENUM('profit','loss'), allowNull: false, defaultValue: 'profit' },

    // NEW – total commission the user has **received** (cumulative)
    totalCommission: {
      type: DataTypes.DECIMAL(18,2),
      allowNull: false,
      defaultValue: 0.0,
      comment: 'Cumulative platform-fee commission earned by this wallet',
    },
  },
  {
    tableName: 'Wallets',
    timestamps: true,
    hooks: {
      beforeCreate: calculateProfitLoss,
      beforeUpdate: calculateProfitLoss,
      // Recompute on read so increment()/bulk-update paths cannot serve a stale figure.
      // Fires for instances, raw:true rows and findAll alike (verified against this
      // codebase's query shapes). Rows that did not select the source columns — e.g.
      // aggregate queries like SUM(profit_loss) AS downPL — are skipped untouched.
      afterFind: (result) => {
        if (!result) return result;
        const rows = Array.isArray(result) ? result : [result];
        for (const row of rows) {
          if (!row) continue;
          const isInstance = typeof row.getDataValue === 'function';
          const inr  = isInstance ? row.getDataValue('inr_balance')   : row.inr_balance;
          const recv = isInstance ? row.getDataValue('cash_received') : row.cash_received;
          // only derive when BOTH source columns were actually selected
          if (inr === undefined || recv === undefined) continue;
          const pl = parseFloat(((parseFloat(inr) || 0) - (parseFloat(recv) || 0)).toFixed(2));
          const verdict = pl >= 0 ? 'profit' : 'loss';
          if (isInstance) {
            row.setDataValue('profit_loss', pl);
            row.setDataValue('verdict', verdict);
            // Clear the dirty flags this sets. Deriving on READ must have no write-side
            // effect: without this the field comes back in instance.changed(), so an
            // unrelated `wallet.save()` would carry profit_loss along, and code that
            // branches on `changed()` would see a phantom modification.
            row.changed('profit_loss', false);
            row.changed('verdict', false);
          } else {
            row.profit_loss = pl;
            row.verdict = verdict;
          }
        }
        return result;
      },
    },
  }
);

Wallet.belongsTo(Staff, {
  foreignKey: 'staff_id',
  as: 'staff',
  constraints: false,
});


export default Wallet;