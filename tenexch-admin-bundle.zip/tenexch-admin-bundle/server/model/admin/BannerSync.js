import { DataTypes } from 'sequelize';
import sequelize from '../../config/db.js';

// One row (id BANNER_SYNC_ROW_ID): state of the 4-hourly carousel + poster
// mirror from the reference site (services/BannerSyncService.js). next_run_at
// lives here, not in memory, so a pm2 restart keeps the schedule.
export const BANNER_SYNC_ROW_ID = 1;

const BannerSync = sequelize.define('BannerSync', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
    },
    status: {
        // 'ok' | 'error' | 'running'
        type: DataTypes.STRING,
        allowNull: false,
        defaultValue: 'pending',
    },
    last_run_at: { type: DataTypes.DATE, allowNull: true },
    last_success_at: { type: DataTypes.DATE, allowNull: true },
    next_run_at: { type: DataTypes.DATE, allowNull: true },
    // when the Python service actually read the site (may be older than
    // last_run_at if it served its cached copy)
    site_fetched_at: { type: DataTypes.DATE, allowNull: true },
    trigger: {
        // 'schedule' | 'manual'
        type: DataTypes.STRING,
        allowNull: true,
    },
    carousel_count: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
    // image urls added to / removed from the carousel by the last successful run
    added: { type: DataTypes.JSONB, allowNull: false, defaultValue: [] },
    removed: { type: DataTypes.JSONB, allowNull: false, defaultValue: [] },
    poster_changed: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false },
    error: { type: DataTypes.TEXT, allowNull: true },
}, {
    tableName: 'banner_sync',
    timestamps: true,
});

export default BannerSync;
