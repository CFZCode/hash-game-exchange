import { DataTypes } from 'sequelize';
import sequelize from '../../config/db.js';

// Home Sliders — the two image strips at the bottom of the MOBILE home page
// ("Our Casino" and "New Games", frontend components/home/HomeCasinoCarousel).
// One row per tile: the artwork, the app path it opens, and where it sits in
// its strip. Before this table both strips were hardcoded arrays in the
// frontend, so changing a banner meant a rebuild.
const HomeSlider = sequelize.define('HomeSlider', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    section: {
        // Which of the two home strips the tile belongs to. Values map 1:1 to
        // the headings the player sees.
        type: DataTypes.ENUM('our_casino', 'new_games'),
        allowNull: false,
    },
    title: {
        type: DataTypes.STRING(80),
        allowNull: false,
        comment: 'Label shown in the admin table (never rendered to players)',
    },
    route: {
        type: DataTypes.STRING(160),
        allowNull: false,
        defaultValue: '',
        comment: 'Frontend path the tile opens; empty = image only, no link',
    },
    img: {
        // TEXT, not a short varchar: uploads from the admin panel are stored
        // as base64 data: URIs right in the row. Filenames (served from
        // /assets/casino/sidebanners) and full http(s) URLs also work.
        // Same three shapes CasinoGameManage.img accepts.
        type: DataTypes.TEXT,
        allowNull: true,
        comment: 'Tile image: filename, http(s) URL, or data: URI',
    },
    enabled: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
        comment: 'Off = hidden from the strip, row kept for later',
    },
    sort_order: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0,
        // Position WITHIN its section — the two strips scroll independently,
        // so numbering never has to be unique across the whole table. Managed
        // via the admin reorder endpoint, same as CasinoGameManage.sort_order.
        comment: 'Display position within the section; 0-based',
    },
}, {
    tableName: 'home_sliders',
    timestamps: true,
});

// Seed = exactly what the two strips showed while they were hardcoded, in the
// same order (frontend HomeCasinoCarousel CASINO_SLIDES / NEW_GAMES_SLIDES).
// Images are the files already shipped under
// frontend/public/assets/casino/sidebanners/ — stored as bare filenames and
// streamed from disk by the controller, so nothing had to be re-uploaded.
// Tiles whose reference art is a third-party slot we don't host land on the
// casino home (/o_casino), which is what the hardcoded version did too.
const SEED_SLIDERS = [
    // ── Our Casino ──
    { section: 'our_casino', title: 'Slot 204',       route: '/o_casino',            img: 'slot-204.jpg' },
    { section: 'our_casino', title: 'Mogambo',        route: '/casino/mogambo',      img: 'mogambo.jpg' },
    { section: 'our_casino', title: 'Super Over 2',   route: '/casino/superover2',   img: 'superover2.jpg' },
    { section: 'our_casino', title: 'Slot 51',        route: '/o_casino',            img: 'slot-51.jpg' },
    { section: 'our_casino', title: 'Our Roulette',   route: '/casino/ourroullete',  img: 'ourroullete.jpg' },
    { section: 'our_casino', title: 'Sicbo 2',        route: '/casino/sicbo2',       img: 'sicbo2.jpg' },
    { section: 'our_casino', title: 'Slot 200',       route: '/o_casino',            img: 'slot-200.jpg' },
    { section: 'our_casino', title: 'Teen Patti 41',  route: '/casino/teen41',       img: 'teen41.jpg' },
    { section: 'our_casino', title: 'Aero',           route: '/o_casino',            img: 'trb-aero.webp' },
    { section: 'our_casino', title: 'Slot 197',       route: '/o_casino',            img: 'slot-197.webp' },
    { section: 'our_casino', title: 'Poker 20',       route: '/casino/poker20',      img: 'poker20.png' },
    { section: 'our_casino', title: 'Animal Housing', route: '/o_casino',            img: 'amigo-animalhousing.png' },
    { section: 'our_casino', title: 'Queen',          route: '/casino/queen',        img: 'queen.png' },
    { section: 'our_casino', title: 'AAA',            route: '/casino/aaa',          img: 'aaa.png' },

    // ── New Games ──
    { section: 'new_games', title: 'JetX',          route: '/fantasy/smart/JetX',           img: 'jetx.webp' },
    { section: 'new_games', title: 'Jacktop',       route: '/fantasy/jacktop/140511',       img: 'jacktop.webp' },
    { section: 'new_games', title: 'Aviation',      route: '/fantasy/darwin/AVIATSR',       img: 'aviatsr.png' },
    { section: 'new_games', title: 'Pilot Chicken', route: '/fantasy/spribe/pilot-chicken', img: 'pilot-chicken.png' },
];

HomeSlider.SECTIONS = ['our_casino', 'new_games'];

// Seed ONCE per section, and only while that section is empty. Deliberately
// not a findOrCreate over every row the way CasinoGameManage seeds: these
// tiles are pure marketing art with no stable identity key, so re-seeding a
// section the owner has curated would resurrect banners they deleted.
HomeSlider.seedDefaults = async function seedDefaults() {
    for (const section of HomeSlider.SECTIONS) {
        const existing = await HomeSlider.count({ where: { section } });
        if (existing > 0) continue;
        const rows = SEED_SLIDERS
            .filter((slide) => slide.section === section)
            .map((slide, index) => ({ ...slide, enabled: true, sort_order: index }));
        await HomeSlider.bulkCreate(rows);
        console.log(`✅ Seeded ${rows.length} '${section}' home sliders`);
    }
};

export default HomeSlider;
