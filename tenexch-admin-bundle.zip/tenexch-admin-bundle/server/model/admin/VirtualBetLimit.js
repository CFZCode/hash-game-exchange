import { DataTypes } from 'sequelize';
import sequelize from '../../config/db.js';
import { COMMISSION_LEAGUES } from '../../constants/commissionLeagues.js';

/**
 * Virtual Bet Limits — owner-set min / max stake per VIRTUAL league.
 *
 * The virtual rounds (cricket's Dim "(e)" e-cricket, T5 XI, T10 XI, Virtual
 * Cricket League and wrestling's WWE Virtual) rotate every few minutes, so the
 * per-event Bet Limits screen cannot reach them. One row per league instead,
 * keyed exactly like the Commission / Buffer / Max Odds league tabs
 * (constants/commissionLeagues.js), so a bet's league_name is matched the same
 * way everywhere.
 *
 * min_stake / max_stake 0 = not set → the feed's own limit (and, for min, the
 * slip's normal floor) applies. A set side REPLACES the feed value for every
 * market of that league, and placeBet enforces it server-side.
 *
 * Seeded with the behaviour that existed before this screen: Dim 200 (the old
 * hardcoded VIRTUAL_MIN_BET_AMOUNT), everything else 100 (MIN_BET_AMOUNT).
 */
const VirtualBetLimit = sequelize.define('VirtualBetLimit', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    sport_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    league_key: {
        type: DataTypes.STRING(40),
        allowNull: false,
        comment: 'commissionLeagues key: ecricket, t10xi, t5xi, vcl, wwevirtual',
    },
    min_stake: {
        type: DataTypes.DECIMAL(15, 2),
        allowNull: false,
        defaultValue: 0,
    },
    max_stake: {
        type: DataTypes.DECIMAL(15, 2),
        allowNull: false,
        defaultValue: 0,
    },
}, {
    tableName: 'virtual_bet_limits',
    timestamps: true,
    indexes: [{ unique: true, fields: ['sport_id', 'league_key'] }],
});

// Pre-screen behaviour — see the header.
const SEED_MIN = { ecricket: 200 };
const DEFAULT_SEED_MIN = 100;

/** Every virtual league the screen lists: [{ sport_id, league_key, label }]. */
export const virtualLeagues = () =>
    Object.entries(COMMISSION_LEAGUES).flatMap(([sid, list]) =>
        list.map(({ key, label }) => ({ sport_id: Number(sid), league_key: key, label })));

/** Create any missing league row with its seed value. Safe to run every boot. */
export const seedVirtualBetLimits = async () => {
    for (const { sport_id, league_key } of virtualLeagues()) {
        await VirtualBetLimit.findOrCreate({
            where: { sport_id, league_key },
            defaults: { sport_id, league_key, min_stake: SEED_MIN[league_key] ?? DEFAULT_SEED_MIN, max_stake: 0 },
        });
    }
};

export default VirtualBetLimit;
