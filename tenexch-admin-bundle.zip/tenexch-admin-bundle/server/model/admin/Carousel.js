import { DataTypes } from 'sequelize';
import sequelize from '../../config/db.js'; // Adjust the path as needed

const Carousel = sequelize.define('Carousel', {
    carousel_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    image_url: {
        type: DataTypes.TEXT,
        allowNull: false,
    },
    category: {
        // NOTE for existing DBs: 'thirdparty' is added by the dbInit
        // mini-migration via ALTER TYPE ... ADD VALUE (alter-sync cannot be
        // trusted with Postgres enums); this list is what a fresh CREATE gets.
        type: DataTypes.ENUM('sports', 'casino', 'others', 'thirdparty'),
        allowNull: false,
    },
    sport_id: {
        type: DataTypes.STRING,
        allowNull: true, // required only when category = 'sports'
    },
    event_id: {
        type: DataTypes.STRING,
        allowNull: true, // required only when category = 'sports'
    },
    game_name: {
        type: DataTypes.STRING,
        allowNull: true, // required only when category = 'casino'
    },
    game_uid: {
        // The aggregator game id (js_games.game_uid) for a 'thirdparty' banner,
        // which opens at /casino/slot/<uid>. Deliberately NOT reusing
        // game_name: that column means "our casino table slug" and one column
        // carrying two unrelated meanings is how these rows get misread later.
        type: DataTypes.STRING,
        allowNull: true, // required only when category = 'thirdparty'
    },
    sort_order: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0, // display position; managed via the admin reorder endpoint
    },
}, {
    tableName: 'carousels',
    timestamps: true, // Adds createdAt and updatedAt fields
});

export default Carousel;
