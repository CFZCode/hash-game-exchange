import { DataTypes } from 'sequelize';
import sequelize from '../../config/db.js';

// Casino Manage — owner-controlled catalog of the VIP / Virtual / Premium
// tables. One row per game: whether it shows up in the frontend list at all
// (`enabled`) and how much balance an account needs to enter it
// (`min_balance`). The frontend reads only enabled rows via the public
// endpoint; the owner edits everything via /api/admin/casino-manage.
const CasinoGameManage = sequelize.define('CasinoGameManage', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    game_type: {
        type: DataTypes.STRING(40),
        allowNull: false,
        // Uniqueness lives in `indexes` below, NOT inline: with the blanket
        // sync({ alter: true }) in dbInit, an inline unique makes Sequelize
        // emit `ALTER COLUMN ... UNIQUE` — invalid Postgres ("syntax error at
        // or near UNIQUE") that crashed the server on deploy.
        comment: 'Feed/game key, e.g. teen20v1, vteen20, pteen',
    },
    name: {
        type: DataTypes.STRING(80),
        allowNull: false,
    },
    route: {
        type: DataTypes.STRING(120),
        allowNull: false,
        comment: 'Frontend path the tile navigates to',
    },
    category: {
        // 'our' = the main Our Casino grid. NOTE for existing DBs: enum values
        // are added by ensureCasinoGameManage() via ALTER TYPE ... ADD VALUE
        // (alter-sync can't be trusted with Postgres enums); this list is what
        // fresh CREATEs get.
        type: DataTypes.ENUM('our', 'vip', 'virtual', 'premium'),
        allowNull: false,
    },
    tile_category: {
        type: DataTypes.STRING(30),
        allowNull: true,
        comment: "Our Casino grid tab the tile files under (teenpatti/roulette/...)",
    },
    enabled: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
        comment: 'Off = hidden from the frontend list entirely',
    },
    min_balance: {
        type: DataTypes.DECIMAL(12, 2),
        allowNull: false,
        defaultValue: 0,
        comment: 'Balance required to ENTER the table; 0 = no gate',
    },
    img: {
        // TEXT, not a short varchar: uploads from the admin panel are stored
        // as base64 data: URIs right in the row. Filenames (served from
        // /assets/casino/games) and full http(s) URLs are also accepted.
        type: DataTypes.TEXT,
        allowNull: true,
        comment: 'Tile image: filename, http(s) URL, or data: URI',
    },
    launch_type: {
        // How the tile OPENS, kept separate from `category`, which decides
        // which grid tab it shows in. Keeping them apart is the point: a
        // third-party game can then sit in the Our/VIP/Virtual/Premium tab of
        // the owner's choosing and still launch through the aggregator.
        // Every pre-existing row defaults to 'table', i.e. today's behaviour.
        type: DataTypes.ENUM('table', 'third_party'),
        allowNull: false,
        defaultValue: 'table',
        comment: "'table' = in-house feed table at `route`; 'third_party' = launch game_uid via /jsGamesv2/launch",
    },
    game_uid: {
        // Which aggregator game to open — js_games.game_uid. Only meaningful
        // when launch_type is 'third_party'; the controller rejects that
        // combination with this empty, because a tile that launches nothing
        // looks identical to a broken one from the player's side.
        type: DataTypes.STRING(255),
        allowNull: true,
        comment: 'js_games.game_uid to launch when launch_type = third_party',
    },
    sort_order: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0,
        // Position WITHIN its category — the frontend renders one category per
        // tab, so numbering never has to be unique across the whole table.
        // Managed via the admin reorder endpoint, same as Carousel.sort_order.
        comment: 'Display position within the category; 0-based',
    },
}, {
    tableName: 'casino_game_manage',
    timestamps: true,
    indexes: [
        { unique: true, fields: ['game_type'] },
    ],
});

// Seed catalog. Routes are the reference site's own paths (mined from the
// dump: /vip-casino/, /vcasino/, /pcasino/); names come from the frontend
// casinoGames config for the same feed types. Per the current business rule
// only PREMIUM tables carry an entry threshold (20000) — VIP and Virtual
// seed at 0 so anyone can enter. All of it is editable from Casino Manage,
// and the seed NEVER overwrites an existing row (findOrCreate), so owner
// edits survive restarts.
const PREMIUM_MIN_BALANCE = 20000;

const SEED_GAMES = [
    // ── Our Casino (the main /o_casino grid — ported from the frontend's
    //    ourCasinoGames.json, order preserved; game_type carries an "our-"
    //    prefix so teen20v1 & co. don't collide with the managed feed rows) ──
    { game_type: "our-goal2", name: "Goal 2", route: "/casino/goal2", category: 'our', tile_category: "sports", img: "goal2.jpg" },
    { game_type: "our-worli3", name: "Worli 3", route: "/casino/worli3", category: 'our', tile_category: "worli", img: "worli3.gif" },
    { game_type: "our-teen62", name: "Teen 62", route: "/casino/teen62", category: 'our', tile_category: "teenpatti", img: "teen62.gif" },
    { game_type: "our-dolidana", name: "Doli Danna", route: "/casino/dolidana", category: 'our', tile_category: "bollywood", img: "dolidana.gif" },
    { game_type: "our-mogambo", name: "Mogambo", route: "/casino/mogambo", category: 'our', tile_category: "bollywood", img: "mogambo.gif" },
    { game_type: "our-teen20v1", name: "Teen Patti 20 V1", route: "/casino/teen20v1", category: 'our', tile_category: "teenpatti", img: "teen20v1.jpg" },
    { game_type: "our-lucky5", name: "Lucky 5", route: "/casino/lucky5", category: 'our', tile_category: "lucky7", img: "lucky5.jpg" },
    { game_type: "our-roulette12", name: "Roulette 12", route: "/casino/roulette12", category: 'our', tile_category: "roulette", img: "roulette12.jpg" },
    { game_type: "our-roulette13", name: "Roulette 13", route: "/casino/roulette13", category: 'our', tile_category: "roulette", img: "roulette13.jpg" },
    { game_type: "our-roulette11", name: "Roulette 11", route: "/casino/roulette11", category: 'our', tile_category: "roulette", img: "roulette11.jpg" },
    { game_type: "our-poison", name: "Poison", route: "/casino/poison", category: 'our', tile_category: "others", img: "poison.jpg" },
    { game_type: "our-teenunique", name: "Unique Teenpatti", route: "/casino/teenunique", category: 'our', tile_category: "teenpatti", img: "teenunique.jpg" },
    { game_type: "our-poison20", name: "Poison 20", route: "/casino/poison20", category: 'our', tile_category: "others", img: "poison20.jpg" },
    { game_type: "our-jokerteenpatti120", name: "Joker 120", route: "/casino/jokerteenpatti120", category: 'our', tile_category: "others", img: "joker120.jpg" },
    { game_type: "our-jokerteenpatti20", name: "Joker 20", route: "/casino/jokerteenpatti20", category: 'our', tile_category: "others", img: "joker20.jpg" },
    { game_type: "our-jokerteenpatti1", name: "Joker", route: "/casino/jokerteenpatti1", category: 'our', tile_category: "others", img: "joker1.jpg" },
    { game_type: "our-teen20c", name: "Teen Patti 20c", route: "/casino/teen20c", category: 'our', tile_category: "teenpatti", img: "teen20c.jpg" },
    { game_type: "our-bollywoodtable2", name: "Bet Table 2", route: "/casino/bollywoodtable2", category: 'our', tile_category: "baccarat", img: "btable2.jpg" },
    { game_type: "our-ourroullete", name: "Our Roulette", route: "/casino/ourroullete", category: 'our', tile_category: "roulette", img: "ourroullete.jpg" },
    { game_type: "our-superover3", name: "Super Over 3", route: "/casino/superover3", category: 'our', tile_category: "sports", img: "superover3.jpg" },
    { game_type: "our-goal", name: "Goals", route: "/casino/goal", category: 'our', tile_category: "sports", img: "goal.jpg" },
    { game_type: "our-ab4", name: "Andar Bahar 4", route: "/casino/ab4", category: 'our', tile_category: "andarbahar", img: "ab4.jpg" },
    { game_type: "our-lucky15", name: "Lucky 15", route: "/casino/lucky15", category: 'our', tile_category: "lucky7", img: "lucky15.jpg" },
    { game_type: "our-superover2", name: "Super Over 2", route: "/casino/superover2", category: 'our', tile_category: "sports", img: "superover2.jpg" },
    { game_type: "our-teen41", name: "Teen Patti 41", route: "/casino/teen41", category: 'our', tile_category: "teenpatti", img: "teen41.jpg" },
    { game_type: "our-teen42", name: "Teen Patti 42", route: "/casino/teen42", category: 'our', tile_category: "teenpatti", img: "teen42.jpg" },
    { game_type: "our-sicbo2", name: "Sicbo 2", route: "/casino/sicbo2", category: 'our', tile_category: "others", img: "sicbo2.jpg" },
    { game_type: "our-instantteenpatti3", name: "Instant Teenpatti 3.0", route: "/casino/instantteenpatti3", category: 'our', tile_category: "teenpatti", img: "teen33.jpg" },
    { game_type: "our-sicbo", name: "Sicbo", route: "/casino/sicbo", category: 'our', tile_category: "others", img: "sicbo.jpg" },
    { game_type: "our-ballbyball", name: "Ball by Ball", route: "/casino/ballbyball", category: 'our', tile_category: "sports", img: "ballbyball.jpg" },
    { game_type: "our-instantteenpatti2", name: "Instant Teenpatti 2.0", route: "/casino/instantteenpatti2", category: 'our', tile_category: "teenpatti", img: "teen32.jpg" },
    { game_type: "our-teen", name: "Teen Patti", route: "/casino/teen", category: 'our', tile_category: "teenpatti", img: "teen.jpg" },
    { game_type: "our-teen20", name: "Teen Patti 20", route: "/casino/teen20", category: 'our', tile_category: "teenpatti", img: "teen20.jpg" },
    { game_type: "our-teenpattitest", name: "Teen Patti 9", route: "/casino/teenpattitest", category: 'our', tile_category: "teenpatti", img: "teen9.jpg" },
    { game_type: "our-teenpattiopen", name: "Teen Patti 8", route: "/casino/teenpattiopen", category: 'our', tile_category: "teenpatti", img: "teen8.jpg" },
    { game_type: "our-pokeroneday", name: "Poker", route: "/casino/pokeroneday", category: 'our', tile_category: "poker", img: "poker.jpg" },
    { game_type: "our-poker20", name: "Poker 20", route: "/casino/poker20", category: 'our', tile_category: "poker", img: "poker20.jpg" },
    { game_type: "our-poker6player", name: "Poker 6", route: "/casino/poker6player", category: 'our', tile_category: "poker", img: "poker6.jpg" },
    { game_type: "our-baccarat", name: "Baccarat", route: "/casino/baccarat", category: 'our', tile_category: "baccarat", img: "baccarat.jpg" },
    { game_type: "our-baccarat2", name: "Baccarat 2", route: "/casino/baccarat2", category: 'our', tile_category: "baccarat", img: "baccarat2.jpg" },
    { game_type: "our-dt20", name: "Dragon Tiger 20", route: "/casino/dt20", category: 'our', tile_category: "dragontiger", img: "dt20.jpg" },
    { game_type: "our-dt6", name: "Dragon Tiger 6", route: "/casino/dt6", category: 'our', tile_category: "dragontiger", img: "dt6.jpg" },
    { game_type: "our-dtl20", name: "DTL 20", route: "/casino/dtl20", category: 'our', tile_category: "dragontiger", img: "dtl20.jpg" },
    { game_type: "our-dt202", name: "Dragon Tiger 202", route: "/casino/dt202", category: 'our', tile_category: "dragontiger", img: "dt202.jpg" },
    { game_type: "our-card32", name: "Card 32", route: "/casino/card32", category: 'our', tile_category: "32cards", img: "card32.jpg" },
    { game_type: "our-card32eu", name: "Card 32 EU", route: "/casino/card32eu", category: 'our', tile_category: "32cards", img: "card32eu.jpg" },
    { game_type: "our-ab20", name: "Andar Bahar 20", route: "/casino/ab20", category: 'our', tile_category: "andarbahar", img: "ab20.jpg" },
    { game_type: "our-abj", name: "AB Joker", route: "/casino/abj", category: 'our', tile_category: "andarbahar", img: "abj.jpg" },
    { game_type: "our-lucky7", name: "Lucky 7", route: "/casino/lucky7", category: 'our', tile_category: "lucky7", img: "lucky7.jpg" },
    { game_type: "our-lucky7eu", name: "Lucky 7 EU", route: "/casino/lucky7eu", category: 'our', tile_category: "lucky7", img: "lucky7eu.jpg" },
    { game_type: "our-3cardj", name: "3 Card Judgement", route: "/casino/3cardj", category: 'our', tile_category: "3cardj", img: "3cardj.jpg" },
    { game_type: "our-war", name: "Casino War", route: "/casino/war", category: 'our', tile_category: "casinowar", img: "war.jpg" },
    { game_type: "our-worli", name: "Worli", route: "/casino/worli", category: 'our', tile_category: "worli", img: "worli.jpg" },
    { game_type: "our-worli2", name: "Worli 2", route: "/casino/worli2", category: 'our', tile_category: "worli", img: "worli2.jpg" },
    { game_type: "our-aaa", name: "AAA", route: "/casino/aaa", category: 'our', tile_category: "others", img: "aaa.jpg" },
    { game_type: "our-btable", name: "Bet Table", route: "/casino/btable", category: 'our', tile_category: "baccarat", img: "btable.jpg" },
    { game_type: "our-lottcard", name: "Lott Card", route: "/casino/lottcard", category: 'our', tile_category: "lottery", img: "lottcard.jpg" },
    { game_type: "our-cricketv3", name: "Cricket V3", route: "/casino/cricketv3", category: 'our', tile_category: "sports", img: "cricketv3.jpg" },
    { game_type: "our-cmatch20", name: "Cricket Match", route: "/casino/cmatch20", category: 'our', tile_category: "sports", img: "cmatch20.jpg" },
    { game_type: "our-cmeter", name: "Casino Meter", route: "/casino/cmeter", category: 'our', tile_category: "others", img: "cmeter.jpg" },
    { game_type: "our-teen6", name: "Teen Patti 6", route: "/casino/teen6", category: 'our', tile_category: "teenpatti", img: "teen6.jpg" },
    { game_type: "our-queen", name: "Queen", route: "/casino/queen", category: 'our', tile_category: "queen", img: "queen.jpg" },
    { game_type: "our-race20", name: "Race 20", route: "/casino/race20", category: 'our', tile_category: "race", img: "race20.jpg" },
    { game_type: "our-lucky7eu2", name: "Lucky 7 EU 2", route: "/casino/lucky7eu2", category: 'our', tile_category: "lucky7", img: "lucky7eu2.jpg" },
    { game_type: "our-superover", name: "Super Over", route: "/casino/superover", category: 'our', tile_category: "sports", img: "superover.jpg" },
    { game_type: "our-trap", name: "Trap", route: "/casino/trap", category: 'our', tile_category: "others", img: "trap.jpg" },
    { game_type: "our-teenpatti2cards", name: "Teen Patti 2", route: "/casino/teenpatti2cards", category: 'our', tile_category: "teenpatti", img: "patti2.jpg" },
    { game_type: "our-29cardbaccarat", name: "29Card Baccarat", route: "/casino/29cardbaccarat", category: 'our', tile_category: "teenpatti", img: "teensin.jpg" },
    { game_type: "our-teenmuf", name: "Teen Patti Muflis", route: "/casino/teenmuf", category: 'our', tile_category: "teenpatti", img: "teenmuf.jpg" },
    { game_type: "our-raceto17", name: "Race to 17", route: "/casino/raceto17", category: 'our', tile_category: "race", img: "race17.jpg" },
    { game_type: "our-teenpattit20b", name: "20-20 Teenpatti B", route: "/casino/teenpattit20b", category: 'our', tile_category: "teenpatti", img: "teen20b.jpg" },
    { game_type: "our-trio", name: "Trio", route: "/casino/trio", category: 'our', tile_category: "others", img: "trio.jpg" },
    { game_type: "our-notenum", name: "Note Number", route: "/casino/notenum", category: 'our', tile_category: "others", img: "notenum.jpg" },
    { game_type: "our-1card2020", name: "1 Card 20-20", route: "/casino/1card2020", category: 'our', tile_category: "teenpatti", img: "teen120.jpg" },
    { game_type: "our-1card1day", name: "1 Card One-Day", route: "/casino/1card1day", category: 'our', tile_category: "teenpatti", img: "teen1.jpg" },
    { game_type: "our-ab3", name: "Andar Bahar", route: "/casino/ab3", category: 'our', tile_category: "andarbahar", img: "ab3.jpg" },
    { game_type: "our-aaa2", name: "AAA 2", route: "/casino/aaa2", category: 'our', tile_category: "others", img: "aaa2.jpg" },
    { game_type: "our-race2", name: "Race 2", route: "/casino/race2", category: 'our', tile_category: "race", img: "race2.jpg" },
    { game_type: "our-instantteenpatti", name: "Instant Teenpatti", route: "/casino/instantteenpatti", category: 'our', tile_category: "teenpatti", img: "teen3.jpg" },
    { game_type: "our-dum10", name: "Dum 10", route: "/casino/dum10", category: 'our', tile_category: "others", img: "dum10.jpg" },
    { game_type: "our-cmeter1", name: "Casino Meter 1", route: "/casino/cmeter1", category: 'our', tile_category: "others", img: "cmeter1.jpg" },

    // ── VIP ──
    { game_type: 'teen20v1', name: '20-20 Teenpatti VIP', route: '/casino/teen20v1', category: 'vip', tile_category: 'teenpatti', min_balance: 0, img: 'teen20v1.jpg' },

    // ── Virtual (reference /vcasino/*) ──
    // Array order IS the default grid sequence (see sort_order below), so these
    // nine sit in the reference site's own order, read off its /o_casino DOM.
    { game_type: 'vlucky7',  name: 'V-Lucky 7 - A',         route: '/vcasino/lucky7',  category: 'virtual', tile_category: 'lucky7', img: 'vlucky7.jpg' },
    { game_type: 'vtrio',    name: 'V-Trio',                route: '/vcasino/trio',    category: 'virtual', tile_category: 'others', img: 'vtrio.jpg' },
    { game_type: 'vdtl20',   name: 'V-20-20 D T L',         route: '/vcasino/dtl20',   category: 'virtual', tile_category: 'dragontiger', img: 'vdtl20.jpg' },
    { game_type: 'vteenmuf', name: 'V-Muflis Teenpatti',    route: '/vcasino/teenmuf', category: 'virtual', tile_category: 'teenpatti', img: 'vteenmuf.jpg' },
    { game_type: 'vaaa',     name: 'V-Amar Akbar Anthony',  route: '/vcasino/aaa',     category: 'virtual', tile_category: 'others', img: 'vaaa.jpg' },
    { game_type: 'vbtable',  name: 'V-Bollywood Casino',    route: '/vcasino/btable',  category: 'virtual', tile_category: 'bollywood', img: 'vbtable.jpg' },
    { game_type: 'vdt6',     name: 'V-1 Day Dragon Tiger',  route: '/vcasino/dt6',     category: 'virtual', tile_category: 'dragontiger', img: 'vdt6.jpg' },
    { game_type: 'vteen',    name: 'V-Teenpatti 1-Day',     route: '/vcasino/teen',    category: 'virtual', tile_category: 'teenpatti', img: 'vteen.jpg' },
    { game_type: 'vteen20',  name: 'V-20-20 Teenpatti',     route: '/vcasino/teen20',  category: 'virtual', tile_category: 'teenpatti', img: 'vteen20.jpg' },
    // Tables the reference does not carry — ours, kept enabled, parked after
    // its nine. The owner can reorder or disable them from Casino Manage.
    { game_type: 'vdt20',    name: 'V-20-20 Dragon Tiger',  route: '/vcasino/dt20',    category: 'virtual', tile_category: 'dragontiger', img: 'vdt20.jpg' },
    { game_type: 'vbaccarat', name: 'V-Baccarat',           route: '/vcasino/baccarat', category: 'virtual', tile_category: 'baccarat', img: 'vbaccarat.jpg' },
    { game_type: 'vrace17',  name: 'V-Race To 17',          route: '/vcasino/race17',  category: 'virtual', tile_category: 'race', img: 'vrace17.jpg' },
    { game_type: 'vtrap',    name: 'V-The Trap',            route: '/vcasino/trap',    category: 'virtual', tile_category: 'others', img: 'vtrap.jpg' },

    // ── Premium (reference /pcasino/*) ──
    { game_type: 'pteen',     name: 'Premium Teenpatti 1-Day',    route: '/pcasino/pteen',     category: 'premium', tile_category: 'teenpatti', min_balance: PREMIUM_MIN_BALANCE, img: 'pteen.jpg' },
    { game_type: 'pteen20',   name: 'Premium 20-20 Teenpatti',    route: '/pcasino/pteen20',   category: 'premium', tile_category: 'teenpatti', min_balance: PREMIUM_MIN_BALANCE, img: 'pteen20.jpg' },
    { game_type: 'pbaccarat', name: 'Premium Baccarat',           route: '/pcasino/pbaccarat', category: 'premium', tile_category: 'baccarat', min_balance: PREMIUM_MIN_BALANCE, img: 'pbaccarat.jpg' },
    { game_type: 'pdt20',     name: 'Premium 20-20 Dragon Tiger', route: '/pcasino/pdt20',     category: 'premium', tile_category: 'dragontiger', min_balance: PREMIUM_MIN_BALANCE, img: 'pdt20.jpg' },
    { game_type: 'pdt6',      name: 'Premium 1 Day Dragon Tiger', route: '/pcasino/pdt6',      category: 'premium', tile_category: 'dragontiger', min_balance: PREMIUM_MIN_BALANCE, img: 'pdt6.jpg' },
    { game_type: 'pcard32',   name: 'Premium 32 Cards',           route: '/pcasino/pcard32',   category: 'premium', tile_category: '32cards', min_balance: PREMIUM_MIN_BALANCE, img: 'pcard32.jpg' },
    { game_type: 'plucky7',   name: 'Premium Lucky 7',            route: '/pcasino/plucky7',   category: 'premium', tile_category: 'lucky7', min_balance: PREMIUM_MIN_BALANCE, img: 'plucky7.jpg' },
];

// game_type -> its 0-based position WITHIN its own category, derived from the
// order of SEED_GAMES above. Two readers: seedDefaults (positions a row it
// inserts) and the dbInit mini-migration (numbers rows that predate the
// sort_order column). Both therefore agree without repeating the sequence.
CasinoGameManage.seedOrderIndex = (() => {
    const perCategory = new Map();
    const index = new Map();
    for (const game of SEED_GAMES) {
        const next = perCategory.get(game.category) ?? 0;
        index.set(game.game_type, next);
        perCategory.set(game.category, next + 1);
    }
    return index;
})();

CasinoGameManage.seedDefaults = async function seedDefaults() {
    for (const game of SEED_GAMES) {
        // findOrCreate keys on game_type: new games get inserted, rows the
        // owner has already touched are left exactly as they are.
        const [row, created] = await CasinoGameManage.findOrCreate({
            where: { game_type: game.game_type },
            defaults: {
                enabled: true, min_balance: 0, img: null, tile_category: null,
                // Position applies on INSERT only — once a row exists its order
                // belongs to the owner, so this is deliberately NOT backfilled
                // below the way tile_category and img are.
                sort_order: CasinoGameManage.seedOrderIndex.get(game.game_type) ?? 0,
                ...game,
            },
        });
        // Null-only backfill: rows seeded before tile_category/img existed
        // pick up the catalog values; anything the owner has set (or
        // uploaded) stays untouched.
        if (!created) {
            const patch = {};
            if (row.tile_category == null && game.tile_category) patch.tile_category = game.tile_category;
            if (row.img == null && game.img) patch.img = game.img;
            if (Object.keys(patch).length) await row.update(patch);
        }
    }
};

export default CasinoGameManage;
