/**
 * bet_void_audit — one row per BET that a void touched, with the wallet and
 * exposure state captured on BOTH sides of the operation.
 *
 * WHY THIS EXISTS
 * Before this table a sports void left almost no trace. `voidResult` and
 * `voidSingleOpenBet` wrote nothing to the activity log at all, and the only
 * financial evidence was a single `credits_ledger` row with reason='refund' —
 * written ONCE PER VOID GROUP on a representative bet, and not written at all
 * when the released amount was zero. So "which bets were voided, by whom, and
 * what did it actually cost" could not be answered from the database.
 *
 * That blind spot is what let bet 1907 (10000, user 92) sit voided-but-still-
 * locked for hours: the void reported success, the bet read 'refunded', and
 * nothing recorded that no money had moved.
 *
 * GRAIN
 * One row per bet, so reports can join per bet. `void_group_id` ties together
 * every bet of one void operation, and `is_representative` marks the bet that
 * carries the group's credits_ledger refund row — the same convention
 * recordManualVoidRefund() uses. Reconstruct a group with:
 *
 *   SELECT * FROM bet_void_audit WHERE void_group_id = '…' ORDER BY bet_id;
 *
 * BEFORE/AFTER
 * `*_before` / `*_after` are read inside the void's own transaction, so they are
 * the true values either side of it. `refund_amount` is the money actually
 * returned FOR THE GROUP and is repeated on every row of that group — sum it
 * over DISTINCT void_group_id, never over rows, or a 4-bet group counts 4x.
 *
 * Backfilled history (backfilled=true) has NULL wallet/exposure columns: those
 * values are not reconstructable after the fact. Treat NULL as "unknown", never
 * as zero.
 */
import { DataTypes } from "sequelize";
import sequelize from "../../config/db.js";

// Every entry point that can void a bet. Kept as a plain string (not a PG enum)
// on purpose — an enum needs a migration to extend, and this list will grow.
export const VOID_TYPES = {
  OPEN_BET: "OPEN_BET",                 // POST /void-single-bet
  MARKET: "MARKET",                     // POST /void  (market / one fancy session)
  AFTER_SETTLEMENT: "AFTER_SETTLEMENT", // POST /void-bet-after-settlement, /void-market-after-settlement
  CASINO_OPEN: "CASINO_OPEN",           // POST /void-casino-bets
  CASINO_SETTLED: "CASINO_SETTLED",     // POST /void-settled-casino-bet
  FEED_SUSPENDED: "FEED_SUSPENDED",     // settlementv2: provider declared the market SUSPENDED
  AUTO_TIMEOUT: "AUTO_TIMEOUT",         // autoVoid.js: still open N s after MATCH_ODDS/BOOKMAKER declared
};

const money = { type: DataTypes.DECIMAL(15, 2), allowNull: true };

const BetVoidAudit = sequelize.define(
  "BetVoidAudit",
  {
    id: { type: DataTypes.BIGINT, autoIncrement: true, primaryKey: true },

    // ── which void operation ────────────────────────────────────────────────
    void_group_id: { type: DataTypes.UUID, allowNull: false },
    is_representative: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false },
    void_type: { type: DataTypes.STRING(32), allowNull: false },

    // ── which bet ───────────────────────────────────────────────────────────
    bet_id: { type: DataTypes.BIGINT, allowNull: false },
    bet_kind: { type: DataTypes.STRING(16), allowNull: false, defaultValue: "SPORTS" },
    user_id: { type: DataTypes.BIGINT, allowNull: false },
    username: { type: DataTypes.STRING(255), allowNull: true },

    // Bet identity FROZEN at void time. Denormalised on purpose: a report must
    // still read correctly if the bet row is later edited or purged.
    match_id: { type: DataTypes.STRING(255), allowNull: true },
    eventid: { type: DataTypes.STRING(255), allowNull: true },
    match_title: { type: DataTypes.STRING(255), allowNull: true },
    market_type: { type: DataTypes.STRING(255), allowNull: true },
    game_type: { type: DataTypes.STRING(100), allowNull: true },
    selection_name: { type: DataTypes.STRING(255), allowNull: true },
    bet_type: { type: DataTypes.STRING(32), allowNull: true },
    odds: { type: DataTypes.DECIMAL(15, 4), allowNull: true },
    stake_amount: money,
    liability: money,

    // ── PRE ─────────────────────────────────────────────────────────────────
    status_before: { type: DataTypes.STRING(32), allowNull: true },
    result_status_before: { type: DataTypes.STRING(32), allowNull: true },
    cash_before: money,
    inr_before: money,
    // The bucket's own liability (the `sel` row for a per-selection market, the
    // worst row for MO/BM) — what this void was actually holding.
    exposure_before: money,
    total_exposure_before: money,

    // ── POST ────────────────────────────────────────────────────────────────
    status_after: { type: DataTypes.STRING(32), allowNull: true },
    result_status_after: { type: DataTypes.STRING(32), allowNull: true },
    cash_after: money,
    inr_after: money,
    exposure_after: money,
    total_exposure_after: money,

    // Money returned FOR THE GROUP (repeated on each row of the group — sum over
    // DISTINCT void_group_id). 0 is a legitimate value: a void of a bet whose
    // liability was already held by nothing releases nothing.
    refund_amount: { type: DataTypes.DECIMAL(15, 2), allowNull: true },
    exposure_rows_deleted: { type: DataTypes.INTEGER, allowNull: true },
    // credits_ledger row this void wrote, when it wrote one.
    ledger_id: { type: DataTypes.BIGINT, allowNull: true },

    // ── who and how ─────────────────────────────────────────────────────────
    actor: { type: DataTypes.STRING(255), allowNull: true },
    actor_role: { type: DataTypes.STRING(64), allowNull: true },
    ip_address: { type: DataTypes.STRING(64), allowNull: true },
    browser: { type: DataTypes.TEXT, allowNull: true },
    note: { type: DataTypes.TEXT, allowNull: true },

    // Historical rows reconstructed from SportsBet + credits_ledger. Their
    // wallet/exposure columns are NULL and must not be read as zero.
    backfilled: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false },

    created_at: { type: DataTypes.DATE, allowNull: false, defaultValue: DataTypes.NOW },
  },
  {
    tableName: "bet_void_audit",
    timestamps: false,
    indexes: [
      // Reports filter by time first, then narrow.
      { fields: ["created_at"] },
      { fields: ["user_id", "created_at"] },
      { fields: ["void_group_id"] },
      { fields: ["void_type", "created_at"] },
      // The tracker joins from SportsBet to "did this void get audited?".
      { fields: ["bet_kind", "bet_id"] },
    ],
  }
);

export default BetVoidAudit;
