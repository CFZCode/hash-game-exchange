import { DataTypes } from "sequelize";
import sequelize from "../../config/db.js";

// Har casino round ka result — /report/casinoresult ka data source.
//
// Pehle ye history sirf redis me thi (casino_results_index_<type> zset, 7 din
// TTL, max 300 rows) kyunki vendor ka /casino/lastresultsnew sirf AAKHRI 10
// rounds deta hai. Redis restart = poori history gayi, aur 300 se peeche kuch
// dekha hi nahi ja sakta tha. Ab archiver worker
// (casinobet/cron/casinoResultsArchiveCron.js) har round yahan likhta hai aur
// report isi table se padhti hai. Retention 115 din — purge usi worker me.
//
// TZ TRAP: round ka time timestamp column me NAHI rakha. Vendor ka mid
// "<tableid><YYMMDDHHMMSS>" hai aur wo clock IST hai; is box par sequelize
// session UTC hai aur process TZ CEST — timestamptz me daalte hi wahi drift
// aa jaata jo SportsBet.match_start_time me hai. Isliye day aur time alag-alag
// plain values hain: round_date ek `date` (IST calendar din) aur round_time ek
// 'HH:MM:SS' string. Koi zone conversion kahin nahi hoti.
//
// Model me `indexes`/`unique` jaan-boojh ke nahi hain: is DB par sync() ne
// 11,611 duplicate UNIQUE constraints (1.12 GB) bana rakhe hain. Schema neeche
// ensureCasinoResultArchiveTable() raw DDL se banta hai, IF NOT EXISTS ke saath.
const CasinoResultArchive = sequelize.define(
  "CasinoResultArchive",
  {
    id: {
      type: DataTypes.BIGINT,
      primaryKey: true,
      autoIncrement: true,
    },

    // Casino type / gtype — "teen20", "lucky7eu", "vdt20" …
    gtype: {
      type: DataTypes.STRING(50),
      allowNull: false,
    },

    // Round id. String, number nahi: 15 digit mid Number.MAX_SAFE_INTEGER ke
    // neeche hai par kuch tables 18 tak jaate hain.
    mid: {
      type: DataTypes.STRING(32),
      allowNull: false,
    },

    // Feed ka raw winner code ("1", "2", "0", …). Report ka mapWinValue()
    // fallback isi par chalta hai jab win_name na ho.
    win: {
      type: DataTypes.STRING(50),
      allowNull: true,
    },

    // detail_casino_results ka `winnat` — jo Winner column me dikhta hai.
    // Null tab tak jab tak vendor result publish na kare.
    win_name: {
      type: DataTypes.STRING(150),
      allowNull: true,
    },

    // mid se nikala IST calendar din — report ke Date filter aur 115-din purge
    // dono ki key. DATEONLY sequelize se seedha 'YYYY-MM-DD' string aata hai.
    round_date: {
      type: DataTypes.DATEONLY,
      allowNull: true,
    },

    // mid se nikala IST 'HH:MM:SS'. Sirf display/export ke liye.
    round_time: {
      type: DataTypes.STRING(8),
      allowNull: true,
    },
  },
  {
    tableName: "casino_result_archive",
    timestamps: true,
    createdAt: "created_at",
    updatedAt: "updated_at",
  }
);

// Table + indexes raw DDL se, sync() se nahi (upar wali comment dekho).
// Worker boot par ek baar chalta hai; IF NOT EXISTS hone ki wajah se baar-baar
// chalna bhi safe hai.
export const ensureCasinoResultArchiveTable = async () => {
  await sequelize.query(`
    CREATE TABLE IF NOT EXISTS casino_result_archive (
      id          BIGSERIAL PRIMARY KEY,
      gtype       VARCHAR(50)  NOT NULL,
      mid         VARCHAR(32)  NOT NULL,
      win         VARCHAR(50),
      win_name    VARCHAR(150),
      round_date  DATE,
      round_time  VARCHAR(8),
      created_at  TIMESTAMPTZ  NOT NULL DEFAULT now(),
      updated_at  TIMESTAMPTZ  NOT NULL DEFAULT now()
    );
  `);
  // upsert ki conflict target — (gtype, mid) hi ek round ki pehchaan hai;
  // mid akela unique nahi hai (do tables ka mid same second pe ban sakta hai).
  await sequelize.query(`
    CREATE UNIQUE INDEX IF NOT EXISTS casino_result_archive_gtype_mid
      ON casino_result_archive (gtype, mid);
  `);
  // report ki exact query: WHERE gtype = ? AND round_date = ? ORDER BY mid DESC
  await sequelize.query(`
    CREATE INDEX IF NOT EXISTS casino_result_archive_gtype_date_mid
      ON casino_result_archive (gtype, round_date DESC, mid DESC);
  `);
  // 115-din purge ka scan — round_date NULL walon ke liye created_at fallback.
  await sequelize.query(`
    CREATE INDEX IF NOT EXISTS casino_result_archive_created_at
      ON casino_result_archive (created_at);
  `);
};

export default CasinoResultArchive;
