import { DataTypes } from 'sequelize';
import sequelize from '../../config/db.js';

// Owner-set min / max stake overrides.
//
//   * scope 'sports' → keyed by (event_id, market_id) — the feed's gmid + mid.
//     market_name / gtype / sport_id are denormalised for the admin list only;
//     nothing looks a row up by them.
//   * scope 'casino' → keyed by game_name (the `gameName` /casino/placebet
//     sends), covering Our / VIP / Virtual / Premium tables alike.
//
// A NULL min_stake or max_stake means "not overridden" — that side keeps the
// value the live feed quotes. A row with both NULL (or is_active false) is
// inert, so clearing one field never forces the other to be set.
const BetLimitOverride = sequelize.define('BetLimitOverride', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    scope: {
        type: DataTypes.STRING(10),
        allowNull: false,
        comment: "'sports' | 'casino'",
    },
    sport_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    event_id: {
        type: DataTypes.STRING(40),
        allowNull: true,
        comment: 'sports scope only — feed gmid',
    },
    market_id: {
        type: DataTypes.STRING(60),
        allowNull: true,
        comment: 'sports scope only — feed mid',
    },
    market_name: {
        type: DataTypes.STRING(120),
        allowNull: true,
        comment: 'display only (admin list)',
    },
    gtype: {
        type: DataTypes.STRING(30),
        allowNull: true,
        comment: 'display only (admin list)',
    },
    event_name: {
        type: DataTypes.STRING(200),
        allowNull: true,
        comment: 'display only (admin list)',
    },
    game_name: {
        type: DataTypes.STRING(60),
        allowNull: true,
        comment: 'casino scope only',
    },
    min_stake: {
        type: DataTypes.DECIMAL(15, 2),
        allowNull: true,
        comment: 'NULL = use the feed value',
    },
    max_stake: {
        type: DataTypes.DECIMAL(15, 2),
        allowNull: true,
        comment: 'NULL = use the feed value',
    },
    is_active: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
    },
    // Sports scope only. Stamped the first time the cleanup job finds the
    // event gone from the live board; cleared again if it comes back. The row
    // is deleted once this is older than the grace window (see
    // jobs/betLimitCleanupJob.js). NULL = the match is still running.
    ended_at: {
        type: DataTypes.DATE,
        allowNull: true,
        comment: 'when the event left the live board; row is purged after the grace window',
    },
}, {
    tableName: 'bet_limit_overrides',
    timestamps: true,
    // See BetBufferConfig for why uniqueness is declared here and not inline.
    indexes: [
        {
            name: 'bet_limit_overrides_sports_uniq',
            unique: true,
            fields: ['scope', 'event_id', 'market_id'],
        },
        {
            name: 'bet_limit_overrides_casino_uniq',
            unique: true,
            fields: ['scope', 'game_name'],
        },
    ],
});

BetLimitOverride.SCOPES = ['sports', 'casino'];

export default BetLimitOverride;
