import { DataTypes } from 'sequelize';
import sequelize from '../../config/db.js';
import CommissionConfig from './CommissionConfig.js';
import {
    DEFAULT_LEAGUE_KEY,
    leagueKeyFromName,
    isValidLeagueKey,
} from '../../constants/commissionLeagues.js';

// Bet-placement buffer, owner-configurable, in SECONDS.
//
// Two scopes share this table:
//   * scope 'sports' → keyed by (sport_id, league_key, category) — the SAME
//     grid as the Commission screen (plan
//     docs/plans/2026-09-15-buffer-maxodds-league-market-grid.md):
//       league_key  'default' = every ordinary league of the sport, plus the
//                   variants in constants/commissionLeagues.js (cricket's
//                   ecricket / t10xi / t5xi / vcl, wrestling's wwevirtual).
//       category    a Commission MARKET KEY — matchodds / match_other /
//                   bookmaker / match1_other / fancy / fancy1 / fancy2 /
//                   oddeven / khado / meter / badlo / cricketcasino / other.
//                   The column kept its old name; before 2026-09-15 it held
//                   match_odds / bookmaker / fancy, which dbInit expanded.
//   * scope 'casino' → keyed by game_name, the `gameName` the casino bet call
//     sends (teen20, vteen20, pteen, …), so Our / VIP / Virtual / Premium
//     tables all address the same column.
//
// INHERIT: a variant-league cell with NO row follows the sport's 'default'
// cell. A saved variant row wins even at 0 (0 = the site default).
//
// scope/category are VARCHAR + a JS whitelist, NOT Postgres enums: dbInit's
// blanket alter-sync is disabled and enum values can't be added by sync()
// (see the ALTER TYPE workaround CasinoGameManage needed).
//
// buffer_seconds 0 means "not configured" — the caller falls back to its env
// default, which is exactly today's behaviour.
const BetBufferConfig = sequelize.define('BetBufferConfig', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    scope: {
        type: DataTypes.STRING(10),
        allowNull: false,
        comment: "'sports' | 'casino'",
    },
    sport_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
        comment: 'sports scope only — feed etid (4 = Cricket)',
    },
    league_key: {
        type: DataTypes.STRING(32),
        allowNull: false,
        defaultValue: DEFAULT_LEAGUE_KEY,
        comment: 'sports scope only — default | ecricket | t10xi | t5xi | vcl | wwevirtual',
    },
    category: {
        type: DataTypes.STRING(20),
        allowNull: true,
        comment: 'sports scope only — market key (CommissionConfig.MARKETS)',
    },
    game_name: {
        type: DataTypes.STRING(60),
        allowNull: true,
        comment: 'casino scope only — gameName sent by /casino/placebet',
    },
    buffer_seconds: {
        type: DataTypes.DECIMAL(5, 2),
        allowNull: false,
        defaultValue: 0,
        comment: '0 = unset, caller uses its env default',
    },
}, {
    tableName: 'bet_buffer_configs',
    timestamps: true,
    // Uniqueness lives here, never inline on the column: an inline `unique`
    // makes Sequelize emit a fresh ADD CONSTRAINT on every sync, which is how
    // this platform's DBs collected thousands of duplicate unique constraints.
    indexes: [
        {
            name: 'bet_buffer_configs_sports_league_uniq',
            unique: true,
            fields: ['scope', 'sport_id', 'league_key', 'category'],
        },
        {
            name: 'bet_buffer_configs_casino_uniq',
            unique: true,
            fields: ['scope', 'game_name'],
        },
    ],
});

BetBufferConfig.SCOPES = ['sports', 'casino'];

// The market list is the Commission grid's, by reference — one list, so the
// two screens can never drift apart.
BetBufferConfig.MARKETS = CommissionConfig.MARKETS;
BetBufferConfig.MARKET_KEYS = CommissionConfig.MARKET_KEYS;
BetBufferConfig.DEFAULT_LEAGUE_KEY = DEFAULT_LEAGUE_KEY;
BetBufferConfig.isValidLeagueKey = isValidLeagueKey;

// Pre-2026-09-15 buckets → the market keys each one covered. dbInit copies a
// legacy row's seconds into every key listed. 'badlo' is deliberately absent:
// the badlo slip had no buffer at all, so it starts unset.
BetBufferConfig.LEGACY_CATEGORY_EXPANSION = {
    match_odds: ['matchodds', 'match_other'],
    bookmaker: ['bookmaker', 'match1_other'],
    fancy: ['fancy', 'fancy1', 'fancy2', 'oddeven', 'khado', 'meter', 'cricketcasino', 'other'],
};
BetBufferConfig.CATEGORIES = Object.keys(BetBufferConfig.LEGACY_CATEGORY_EXPANSION);

/** Buffer market key for a bet (SportsBet column names). */
BetBufferConfig.marketKeyOf = (bet) => CommissionConfig.marketKeyOfBet(bet);

/** Buffer league key for a bet, from its league_name. */
BetBufferConfig.leagueKeyOf = (bet) => leagueKeyFromName(bet?.sport_id, bet?.league_name);

// gtype (feed) → the old 3-bucket category. Still used by the Bet Limits
// screen to label an event's markets; the buffer itself keys on marketKeyOf.
BetBufferConfig.categoryFromGtype = (gtype) => {
    const g = String(gtype || '').toLowerCase();
    if (g === 'match') return 'match_odds';
    if (g === 'match1') return 'bookmaker';
    return 'fancy';
};

export default BetBufferConfig;
