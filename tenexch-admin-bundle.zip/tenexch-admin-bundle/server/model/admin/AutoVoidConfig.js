import { DataTypes } from 'sequelize';
import sequelize from '../../config/db.js';

/**
 * Auto Void — ONE row for the whole site (id 1), owner-only.
 *
 * Once the feed has declared an event's Match Odds or Bookmaker result, the
 * results detector (sportsbet/betresult/autoVoid.js) waits `delay_seconds`
 * and then voids every bet on that event that is still open with no result of
 * its own — stragglers the feed never declared (or declared under a name the
 * matcher cannot recognise). Voiding goes through the same service as the
 * owner's manual market void, so refund, ledger and audit are identical.
 *
 * Off by default: an operator turns it on from Settings → Auto Void.
 */
const AutoVoidConfig = sequelize.define('AutoVoidConfig', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    enabled: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
    },
    delay_seconds: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 600,
        comment: 'seconds after the anchor result is first seen before the void fires',
    },
    on_match_odds: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
        comment: 'a settled/void MATCH_ODDS market starts the timer',
    },
    on_bookmaker: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
        comment: 'a settled/void BOOKMAKER market starts the timer',
    },
    enabled_at: {
        type: DataTypes.DATE,
        allowNull: true,
        comment: 'last OFF -> ON switch; a void never fires before enabled_at + delay',
    },
}, {
    tableName: 'auto_void_config',
    timestamps: true,
});

// The single row every read and write goes through.
export const AUTO_VOID_ROW_ID = 1;

// Bounds shared by the controller and the panel.
export const AUTO_VOID_MIN_DELAY = 30;          // never race the settlement worker
export const AUTO_VOID_MAX_DELAY = 24 * 3600;   // one day

/** The site's row, created with defaults (disabled) on first read. */
export const getAutoVoidConfig = async () => {
    const [row] = await AutoVoidConfig.findOrCreate({
        where: { id: AUTO_VOID_ROW_ID },
        defaults: { id: AUTO_VOID_ROW_ID },
    });
    return row;
};

export default AutoVoidConfig;
