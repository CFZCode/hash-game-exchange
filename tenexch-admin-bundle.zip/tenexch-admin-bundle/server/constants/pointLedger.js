// constants/pointLedger.js
// Point ledger ke saare fixed strings EK jagah — kahin bhi magic string mat likho,
// hamesha yahan se import karo. (Docs: docs/ledgerpoint.md)

// all_point badalne ke sirf ye 4 raaste hain (+ REVERSAL galti sudharne ke liye).
// In ke alawa all_point kabhi change nahi hota — bina ledger entry ke aaya change
// cron tampering samajh ke revert kar deta hai.
export const POINT_EVENT = {
  USER_CREATION: 'User creation',       // user/staff/owner create hua (opening credit)
  BET_SETTLEMENT: 'BET_SETTLEMENT',     // user ki bet/market settle hui (poori chain me)
  BANK_DEPOSIT: 'Bank Deposite',        // parent ne child ko diya (sirf normal deposit)
  BANK_WITHDRAW: 'Bank Withdraw',       // parent ne child se liya (sirf normal withdraw)
  CREDIT: 'Credit',                     // sirf settlement me: parent ne child ko diya (+)
  DEBIT: 'Debit',                       // sirf settlement me: parent ne child se liya (−)
  MANUAL_ADJUSTMENT: 'MANUAL_ADJUSTMENT', // admin correction (API se, DB se nahi)
  REVERSAL: 'REVERSAL',                 // galat entry ka ulta — original kabhi delete nahi hoti
  // Sports win commission (owner cell ON): jeet ke baad alag '- Comm' entry, poori
  // chain me settlement jaisa hi (docs/plans/2026-09-09-sports-win-commission.md)
  COMMISSION: 'COMMISSION',
};

export const POINT_EVENT_TYPES = Object.values(POINT_EVENT);

// BET_SETTLEMENT entries ki category — naya provider aaye toh yahan value jodo,
// column VARCHAR hai isliye DB ALTER nahi lagega.
export const POINT_CATEGORY = {
  SPORTS: 'SPORTS',
  CASINO: 'CASINO',
  THIRD_PARTY: 'THIRD_PARTY',
};

// entry_ref builders — unique key (wallet_id, entry_ref) inhi par idempotency deti hai.
// Format kabhi haath se mat likho, hamesha in functions se banao.
export const pointEntryRef = {
  opening: (walletId) => `open:${walletId}`,
  baseline: (walletId) => `baseline:${walletId}`,
  bet: (betType, betId) => `settle:bet:${betType}:${betId}`,
  // settlement ke baad void: original settle:bet:* entry kabhi delete nahi hoti,
  // uske saamne ye ulti entry banti hai (POINT_EVENT.REVERSAL)
  betReversal: (betType, betId) => `reverse:bet:${betType}:${betId}`,
  // win commission on a settled bet/market, and its void-time reversal
  commission: (betType, betId) => `commission:bet:${betType}:${betId}`,
  commissionReversal: (betType, betId) => `reverse:commission:${betType}:${betId}`,
  deposit: (transactionId) => `deposit:${transactionId}`,
  withdraw: (transactionId) => `withdraw:${transactionId}`,
  cashSettle: (transactionId) => `cashsettle:${transactionId}`,
  adjust: (adminUsername, uniqueId) => `adjust:${adminUsername}:${uniqueId}`,
};

// credits_ledger.category me third-party rows historically 'THIRD_PARTY_CASINO'
// likhi jaati hain — reports/statement (reportsController, StatementBuilder,
// TransactionReportService) usi exact string par filter karte hain. Points ki
// taraf category hamesha POINT_CATEGORY value (THIRD_PARTY) rehti hai.
// Ledger row likhte waqt CREDITS_LEDGER_CATEGORY use karo, ledger row dhoondhte
// waqt LEDGER_CATEGORY_ALIASES — taaki purani 'THIRD_PARTY' rows bhi milti rahein.
export const CREDITS_LEDGER_CATEGORY = {
  SPORTS: 'SPORTS',
  CASINO: 'CASINO',
  THIRD_PARTY: 'THIRD_PARTY_CASINO',
};

export const LEDGER_CATEGORY_ALIASES = {
  SPORTS: ['SPORTS'],
  CASINO: ['CASINO'],
  THIRD_PARTY: ['THIRD_PARTY', 'THIRD_PARTY_CASINO'],
};
