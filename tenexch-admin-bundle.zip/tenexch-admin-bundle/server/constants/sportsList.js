// Sport etid → display name. Mirrors admin/src/config/sportsList.js, which the
// admin panel uses for its report filters; this copy exists so the server can
// name a sport without the panel telling it what the sports are (the Buffer
// Time screen is rendered from the API, not from a bundled list).
export const SPORTS_LIST = [
  ['1', 'Football'], ['2', 'Tennis'], ['3', 'Mixed Martial Arts'], ['4', 'Cricket'],
  ['5', 'Golf'], ['6', 'Boxing'], ['7', 'Beach Volleyball'], ['8', 'Table Tennis'],
  ['9', 'Futsal'], ['10', 'Horse Racing'], ['11', 'E Games'], ['15', 'Basketball'],
  ['16', 'MotoGP'], ['17', 'Chess'], ['18', 'Volleyball'], ['19', 'Ice Hockey'],
  ['22', 'Badminton'], ['25', 'Hockey'], ['29', 'Cycling'], ['32', 'Motorbikes'],
  ['33', 'Athletics'], ['35', 'Basketball 3X3'], ['37', 'Sumo'], ['38', 'Virtual sports'],
  ['39', 'Handball'], ['40', 'Politics'], ['52', 'Motor Sports'], ['53', 'Baseball'],
  ['54', 'Rugby Union'], ['55', 'Rugby League'], ['57', 'Darts'], ['58', 'American Football'],
  ['59', 'Snooker'], ['62', 'Soccer'], ['64', 'Esports'], ['65', 'Greyhound Racing'],
  ['66', 'Kabaddi'], ['67', 'Boat Racing'], ['68', 'Esoccer'], ['69', 'Wrestling'],
];

export const sportNameById = (id) => {
  const hit = SPORTS_LIST.find(([sid]) => String(sid) === String(id));
  return hit ? hit[1] : `Sport ${id}`;
};

export default SPORTS_LIST;
