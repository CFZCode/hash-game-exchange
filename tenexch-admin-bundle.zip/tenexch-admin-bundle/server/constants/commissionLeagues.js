// ─────────────────────────────────────────────────────────────────────────────
// Commission league variants — the extra ROW dimension of the commission grid.
//
// The feed ships several leagues that live under an ordinary sport etid but are
// a completely different product: cricket's virtual rounds (T5 XI / T10 XI /
// Virtual Cricket League) and the "(e)" e-cricket league (Dim Cricket League)
// all arrive as sport_id 4, exactly like a Caribbean Premier League match. The
// owner wants to charge (or not charge) commission on those separately, so the
// commission grid is keyed by (sport_id, league_key, market_key) instead of
// just (sport_id, gtype).
//
// A bet carries the league as SportsBet.league_name (the feed's `cname`), which
// is what the patterns below are matched against. `default` is every league
// that matches nothing here — i.e. the real matches.
//
// INHERIT: a variant cell with no saved row falls back to that sport's
// `default` row. Nothing changes for T10 XI until the owner explicitly saves a
// T10 XI cell. See services/CommissionConfigService.js getRule().
//
// cids are recorded for reference only (verified live 2026-09-12 against
// highlighthomePrivate etid=4/69) — matching is by name, because the cid never
// reaches the bet row.
// ─────────────────────────────────────────────────────────────────────────────

export const DEFAULT_LEAGUE_KEY = 'default';
export const DEFAULT_LEAGUE_LABEL = 'All other leagues';

// sport_id → variant leagues, in display order. `patterns` are lower-cased
// substrings tested against the normalised league name.
export const COMMISSION_LEAGUES = {
    // Cricket
    4: [
        { key: 'ecricket', label: 'E-Cricket (Dim)', patterns: ['dim cricket league'], cid: 7526679, iscc: 4 },
        { key: 't10xi', label: 'T10 XI', patterns: ['t10 xi'], cid: 56100513, iscc: 1 },
        { key: 't5xi', label: 'T5 XI', patterns: ['t5 xi'], cid: 46201121, iscc: 1 },
        { key: 'vcl', label: 'Virtual Cricket League', patterns: ['virtual cricket league'], cid: 8590658, iscc: 2 },
    ],
    // Wrestling — one virtual league, same shape as cricket's VCL.
    69: [
        { key: 'wwevirtual', label: 'WWE Virtual', patterns: ['wwe virtual'], cid: 8524813, iscc: 2 },
    ],
};

// Lower-case, collapse every run of non-alphanumerics to a single space, trim.
// "Dim Cricket League (1 over)" → "dim cricket league 1 over" → matches the
// 'dim cricket league' pattern. "T10  XI" → "t10 xi".
export const normaliseLeagueName = (name) =>
    String(name || '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();

/** Variant leagues configured for a sport (never null). */
export const leaguesForSport = (sportId) => COMMISSION_LEAGUES[Number(sportId)] || [];

/**
 * Every league key an owner can configure for a sport, `default` first.
 * [{ key, label, is_default }]
 */
export const leagueOptionsForSport = (sportId) => [
    { key: DEFAULT_LEAGUE_KEY, label: DEFAULT_LEAGUE_LABEL, is_default: true },
    ...leaguesForSport(sportId).map(({ key, label }) => ({ key, label, is_default: false })),
];

/** Is `leagueKey` a key this sport actually has? (`default` always is.) */
export const isValidLeagueKey = (sportId, leagueKey) =>
    leagueKey === DEFAULT_LEAGUE_KEY || leaguesForSport(sportId).some((l) => l.key === leagueKey);

/**
 * league_name (feed cname) → commission league key for this sport.
 * Unknown / empty / a real match → 'default'.
 */
export const leagueKeyFromName = (sportId, leagueName) => {
    const norm = normaliseLeagueName(leagueName);
    if (!norm) return DEFAULT_LEAGUE_KEY;
    for (const league of leaguesForSport(sportId)) {
        if (league.patterns.some((p) => norm.includes(p))) return league.key;
    }
    return DEFAULT_LEAGUE_KEY;
};

/** Display label for a key, for logs and the admin payload. */
export const leagueLabel = (sportId, leagueKey) => {
    if (leagueKey === DEFAULT_LEAGUE_KEY) return DEFAULT_LEAGUE_LABEL;
    const hit = leaguesForSport(sportId).find((l) => l.key === leagueKey);
    return hit ? hit.label : leagueKey;
};

export default COMMISSION_LEAGUES;
