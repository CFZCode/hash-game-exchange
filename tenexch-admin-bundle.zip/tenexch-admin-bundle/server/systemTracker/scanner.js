/**
 * scanner.js — System Tracker system-wide scanner (Tier 1, set-based).
 *
 * Re-expresses the calibration-clean wallet/exposure invariants as ONE aggregate
 * SQL each that returns only the offending users across the WHOLE users table.
 * Cost ≈ (#checks) queries regardless of user count. Findings are persisted to
 * `integrity_alerts` (UNIQUE(user_id,check_key)) and auto-resolved when a later
 * scan no longer sees them. The mother-admin bell reads the cached table; the
 * background worker re-runs scanAllUsers() on an interval.
 *
 * ONLY calibration-clean checks live here (per System Tracker §10). The deep
 * per-bet settlement rules stay in the on-demand per-user verifier (Tier 2).
 */

import { QueryTypes } from 'sequelize';
import sequelize from '../config/db.js';
import { HIERARCHY_CHECKS } from './hierarchyChecks.js';

const sel = (sql, replacements) => sequelize.query(sql, { type: QueryTypes.SELECT, replacements: replacements || {} });
const run = (sql, replacements) => sequelize.query(sql, { replacements: replacements || {} });

// Settlement P/L ledger predicate (sports 'settlement' + casino BET_WIN/BET_LOSS).
// Which ledger rows users.profit is actually built from. THIRD_PARTY is deliberately
// EXCLUDED: the sports and casino settlement paths call user.increment('profit', …)
// (settlementv2.js:2373, settlementWorker.js:1697, casinoVoidService), but the third-party
// path (jsgamesv2/gameController.js:311) writes its credits_ledger row and never touches
// users.profit. Counting it made 4 of 9 plConsistency findings pure arithmetic noise —
// each one's diff was exactly that account's third-party P/L (useraja1 24.00, saluser1
// 22.30, testuser1 10.00, sample00 322.10). The counter is not wrong; the check was.
const PL_WHERE = `( ( LOWER(reason) IN ('settlement','settlement_void','commission','commission_void')
                      OR UPPER(reason) IN ('BET_WIN','BET_LOSS') )
                    AND COALESCE(category,'') NOT LIKE 'THIRD%' )`;
// Fancy/independent exposure game_types (everything else team -> MIN/hedge).
// FANCY_GT matches the game_type column of **user_exposures** — that table really does
// store 'Normal'/'fancy1'/etc. It does NOT match "SportsBet".game_type, which only ever
// holds FAN/BM/MO (the equivalent values live in SportsBet.market_type). Using it against
// SportsBet made `b.game_type NOT IN (FANCY_GT)` always true, so the fancy branch of
// unpaidWin was dead code and fancy bets were graded with per-market grouping rules that
// do not apply to them. Verified on live data: game_type='FAN' covers all 388 fancy bets
// and BM/MO never collide.
const FANCY_GT = `('Normal','Ball By Ball','Over By Over','khado','meter','fancy1','oddeven','fancy2','badlo')`;
const SB_FANCY     = `b.game_type = 'FAN'`;
const SB_NOT_FANCY = `COALESCE(b.game_type,'') <> 'FAN'`;
const NOT_BACKLAY = `NOT (team_name ILIKE '%back' OR team_name ILIKE '%lay' OR team_name ILIKE '%totalstake')`;

// Each check returns: user_id, username, role, detail (SQL-built with the numbers).
const CORE_CHECKS = [
  // ---------------------------------------------------------------------------
  // REMOVED — `walletDerivation` (Wallets.profit_loss == inr_balance − cash_received).
  //
  // profit_loss is now DERIVED ON READ (model/admin/Wallet.js afterFind), so no consumer
  // reads the stored column any more and drift in it is inert by construction. Checking a
  // cache nobody trusts against a formula everybody recomputes reports nothing useful — it
  // only produced 7 permanent rows describing rows that had already been corrected in flight.
  // The remaining money-conservation rule (available + locked = total) is unaffected and
  // still on the bell via the per-user report.
  // ---------------------------------------------------------------------------
  {
    // Demoted to informational after replaying the counters against the code.
    // `users.profit` / `net_win` / `net_loss` are NOT maintained to a single definition:
    //
    //   settlementv2.js:1817 & 2089   User.increment({ net_win: profit, net_loss: loss,
    //                                                  profit: netamount })
    //   settlementv2.js:2372-2374     net_win += netamount ; profit += netamount
    //
    // net_win/net_loss are fed the P&L columns on one path and gross netamount on another,
    // while `profit` takes netamount in both. netamount folds in the returned stake, so the
    // two only agree where stake movement is nil — true for casino, false for team markets.
    // Stored counters are therefore a MIXTURE of two quantities accumulated over time.
    //
    // Consequence: no single ledger formula can reproduce them. Measured — Σ(profit+loss)
    // matches 28 of 32 accounts, Σ(netamount) matches 9, and a clean rebuild of the four
    // stragglers moves net_win by more than half (yogesh21 1,780,400 -> 850,150). Picking
    // a formula would REDEFINE the metric rather than repair it, which is a product
    // decision, not an integrity fix.
    //
    // So this cannot be asserted as an invariant — same rule already applied to
    // walletDerivation and exposure. It stays visible as a number worth watching.
    // → App-side fix first (make every path agree on one definition), THEN rebuild every
    //   account under it. Logged as A7.
    key: 'plConsistency', severity: 'info', informational: true,
    label: 'users.profit vs settlement ledger (counter is not maintained to one definition)',
    sql: `
      SELECT CAST(u.user_id AS TEXT) AS user_id, u.username, u.role,
        'users.profit ' || ROUND(COALESCE(u.profit,0)::numeric,2)
        || ' ≠ ledger Σ(profit+loss) ' || ROUND(COALESCE(l.pl,0)::numeric,2) AS detail
      FROM (SELECT * FROM users WHERE COALESCE(is_demo,false) = false) u
      LEFT JOIN (
        SELECT CAST(user_id AS TEXT) AS user_id,
               SUM(COALESCE(profit,0)) + SUM(COALESCE(loss,0)) AS pl
        FROM credits_ledger WHERE ${PL_WHERE}
        GROUP BY CAST(user_id AS TEXT)
      ) l ON l.user_id = CAST(u.user_id AS TEXT)
      WHERE ABS(COALESCE(u.profit,0) - COALESCE(l.pl,0)) > 0.01`,
  },
  {
    // Demoted to informational on tenexch: this site deliberately does not run the
    // net-exposure sync worker (worker/userNetExpSyncWorker.js has no pm2 process, by
    // the owner's decision), so user_net_exposure is stale BY DESIGN and this check can
    // never pass. Left in place because the derived number is still worth showing in the
    // per-user report — but it must not sit on the bell, where a permanently-failing
    // check would train the owner to ignore it.
    key: 'exposure', severity: 'info', informational: true,
    label: 'net_exposure = market-aware worst-case (team MIN / fancy SUM) — not synced on this site',
    sql: `
      SELECT CAST(u.user_id AS TEXT) AS user_id, u.username, u.role,
        'net_exposure ' || ROUND(COALESCE(ne.net_exposure,0)::numeric,2)
        || ' ≠ derived ' || ROUND(COALESCE(d.exp,0)::numeric,2) AS detail
      FROM (SELECT * FROM users WHERE COALESCE(is_demo,false) = false) u
      LEFT JOIN user_net_exposure ne ON CAST(ne.user_id AS TEXT) = CAST(u.user_id AS TEXT)
      LEFT JOIN (
        SELECT user_id, SUM(grp) AS exp FROM (
          SELECT CAST(user_id AS TEXT) AS user_id, LEAST(0, MIN(exposure_amount)) AS grp
            FROM user_exposures
           WHERE category <> 'casino' AND game_type IS NOT NULL
             AND game_type NOT IN ${FANCY_GT} AND game_type NOT LIKE '%Overs Line%' AND ${NOT_BACKLAY}
           GROUP BY CAST(user_id AS TEXT), match_id, game_type, event_id
          UNION ALL
          SELECT CAST(user_id AS TEXT) AS user_id, LEAST(exposure_amount, 0) AS grp
            FROM user_exposures
           WHERE ( category = 'casino' OR game_type IS NULL OR game_type IN ${FANCY_GT}
                   OR game_type LIKE '%Overs Line%' ) AND ${NOT_BACKLAY}
        ) x GROUP BY user_id
      ) d ON d.user_id = CAST(u.user_id AS TEXT)
      WHERE ABS(COALESCE(ne.net_exposure,0) - COALESCE(d.exp,0)) > 0.01`,
  },
  {
    key: 'missingSelection', severity: 'high',
    label: 'Every bet has a selection',
    sql: `
      SELECT x.user_id, u.username, u.role, COUNT(*) || ' bet(s) with no selection' AS detail
      FROM (
        SELECT CAST(user_id AS TEXT) AS user_id FROM "SportsBet" WHERE COALESCE(selection_name,'') = ''
        UNION ALL
        SELECT CAST(user_id AS TEXT) FROM casino_bets WHERE COALESCE(selection,'') = ''
      ) x JOIN (SELECT * FROM users WHERE COALESCE(is_demo,false) = false) u ON CAST(u.user_id AS TEXT) = x.user_id
      GROUP BY x.user_id, u.username, u.role`,
  },
  {
    // Unpaid winnings — MARKET-AWARE. MO/BM (team) markets settle PER-MARKET: the whole
    // (user, match, market) group gets ONE net settlement row on its first bet, so a
    // per-bet check would false-positive on every other winning bet in the group (the
    // exact trap §10 warns about). So: a TEAM group is unpaid only if it has winning
    // bets AND zero settlement rows in the ENTIRE group; FANCY bets settle per-bet, so
    // a won fancy bet with no own settlement row is genuinely unpaid.
    // REWRITTEN. The inherited rule was "group has a winning bet AND no settlement row".
    // That cannot distinguish an unpaid win from a HEDGE that netted exactly zero — and
    // in this schema settlement writes ONE net row per (user, match, market) group only
    // when the net is non-zero, so a perfectly hedged back+lay pair legitimately has no
    // row. Measured on live data: 154 of 154 groups with a non-zero net have their row,
    // and every single row-less group nets 0.00 or is refunded. The old rule therefore
    // had no discriminating power at all — it only ever surfaced hedges.
    //
    // This version is sound instead: if EVERY bet in a group won, the group cannot be a
    // hedge (a back and a lay on the same selection cannot both win), so the net must be
    // positive and a settlement row MUST exist. Fancy settles per bet, so a won fancy bet
    // with no row of its own is unpaid outright.
    // Live result: 35 all-won groups, 35 paid, 0 flagged.
    key: 'unpaidWin', severity: 'high',
    label: 'Winning bets are paid out',
    sql: `
      SELECT x.user_id, u.username, u.role,
        SUM(x.n)::int || ' winning market(s)/bet(s) with no payout recorded' AS detail
      FROM (
        SELECT g.uid AS user_id, g.bets AS n
        FROM (
          SELECT CAST(b.user_id AS TEXT) AS uid, b.match_id, b.market_type,
                 COUNT(*) AS bets,
                 COUNT(*) FILTER (WHERE LOWER(b.result_status)='won') AS won_bets,
                 COUNT(*) FILTER (WHERE LOWER(l.reason)='settlement' AND l.category='SPORTS') AS settle_rows
          FROM "SportsBet" b
          LEFT JOIN credits_ledger l ON CAST(l.bet_id AS TEXT)=CAST(b.id AS TEXT) AND l.category='SPORTS'
          WHERE ${SB_NOT_FANCY} AND LOWER(b.status)='closed'
          GROUP BY 1,2,3
        ) g WHERE g.bets = g.won_bets AND g.settle_rows = 0
        UNION ALL
        SELECT CAST(b.user_id AS TEXT), 1
        FROM "SportsBet" b
        WHERE ${SB_FANCY} AND LOWER(b.result_status)='won'
          AND NOT EXISTS (SELECT 1 FROM credits_ledger l
            WHERE l.category='SPORTS' AND LOWER(l.reason)='settlement' AND CAST(l.bet_id AS TEXT)=CAST(b.id AS TEXT))
      ) x JOIN (SELECT * FROM users WHERE COALESCE(is_demo,false) = false) u ON CAST(u.user_id AS TEXT) = x.user_id
      GROUP BY x.user_id, u.username, u.role`,
  },
  {
    // ORPHANED EXPOSURE — the signature of a void that released nothing.
    //
    // A negative user_exposures row is BLOCKED CASH. It is only legitimate while an
    // open bet is standing behind it: settlement and void both delete the row and hand
    // the money back. A row with no open bet behind it means the punter is paying for a
    // bet that no longer exists, and nothing else on the bell catches it — the
    // money-conservation rule derives `locked` from SportsBet.liability, not from these
    // rows, so an orphan just shows up as an unattributed few-thousand drift.
    //
    // Found in the wild, both silent for days:
    //   user 92 — fancy1 'Top Batsman ZIM T Tsiga' 10000, voided 2026-09-06. The void
    //     gated on match_id+market_type and the punter had 59 other open fancy1 bets on
    //     that match, so it skipped the refund and the destroy entirely.
    //   user 24 — '1st Innings 6 Overs Line' 200, voided 2026-08-26. Pre-migration line
    //     rows are keyed by runner, so the void's lookup matched nothing.
    //
    // The join mirrors exposureIdentity() (helper/lineMarket.js) exactly: fancy-family
    // rows are matched per SELECTION, line rows by MARKET name, badlo by its flag, and
    // MO/BM per market book. Verified against the whole live table: 2 findings, both
    // real, zero false positives.
    key: 'orphanExposure', severity: 'high',
    label: 'Blocked exposure has an open bet behind it (no stranded locks)',
    sql: `
      SELECT CAST(e.user_id AS TEXT) AS user_id, u.username, u.role,
        COUNT(*) || ' stranded exposure row(s) holding '
          || ROUND(ABS(SUM(e.exposure_amount))::numeric,2)
          || ' with no open bet (e.g. ' || MIN(e.team_name) || ')' AS detail
      FROM user_exposures e
      JOIN (SELECT * FROM users WHERE COALESCE(is_demo,false) = false) u ON CAST(u.user_id AS TEXT) = CAST(e.user_id AS TEXT)
      WHERE COALESCE(e.category,'') <> 'casino'
        AND e.exposure_amount < 0
        AND NOT (e.team_name ILIKE '%back' OR e.team_name ILIKE '%lay' OR e.team_name ILIKE '%totalstake')
        AND NOT EXISTS (
          SELECT 1 FROM "SportsBet" b
           WHERE CAST(b.user_id AS TEXT) = CAST(e.user_id AS TEXT)
             AND b.match_id = e.match_id
             AND b.status = 'open'
             AND (
                   (e.game_type IN ('Normal','Ball By Ball','Over By Over','khado','meter','fancy1','oddeven')
                      AND b.market_type = e.game_type AND b.selection_name = e.team_name)
                OR (e.game_type = 'fancy2' AND b.market_type = e.team_name)
                OR (e.game_type = 'badlo'  AND b.badlo = true)
                OR (e.game_type NOT IN ${FANCY_GT} AND b.market_type = e.game_type)
                 ))
      GROUP BY CAST(e.user_id AS TEXT), u.username, u.role`,
  },
  {
    // The MIRROR failure: an open bet with no exposure row. That is what an over-wide
    // clear leaves behind — one session settles or voids and takes the whole game_type
    // bucket with it, so every OTHER open session on that match is left live but
    // unblocked. The punter's cash was already deducted at placement and the header now
    // under-reports their exposure, letting them stake money that is already committed.
    // Only per-selection markets are asserted: MO/BM rows are runner-keyed and a bet's
    // selection legitimately has no row of its own.
    key: 'unblockedBet', severity: 'high',
    label: 'Open bets still hold their exposure row (nothing cleared them early)',
    sql: `
      SELECT CAST(b.user_id AS TEXT) AS user_id, u.username, u.role,
        COUNT(*) || ' open bet(s) staking '
          || ROUND(SUM(b.stake_amount)::numeric,2)
          || ' with no exposure row (e.g. ' || MIN(b.selection_name) || ')' AS detail
      FROM "SportsBet" b
      JOIN (SELECT * FROM users WHERE COALESCE(is_demo,false) = false) u ON CAST(u.user_id AS TEXT) = CAST(b.user_id AS TEXT)
      WHERE b.status = 'open'
        AND COALESCE(b.badlo,false) = false
        AND b.market_type IN ('Normal','Ball By Ball','Over By Over','khado','meter','fancy1','oddeven')
        AND NOT EXISTS (
          SELECT 1 FROM user_exposures e
           WHERE CAST(e.user_id AS TEXT) = CAST(b.user_id AS TEXT)
             AND e.match_id = b.match_id
             AND e.game_type = b.market_type
             AND e.team_name = b.selection_name)
      GROUP BY CAST(b.user_id AS TEXT), u.username, u.role`,
  },
  {
    // STALE SNAPSHOT — the third shape of the same family, and the only one that is
    // invisible in user_exposures itself.
    //
    // total_exposures is what the player's header reads (socket getBalance ->
    // getUserTotalExposure) and it is NOT recomputed on read. Any writer that adds or
    // removes user_exposures rows must call recalcTotalExposure(); one that forgets
    // leaves a number with nothing under it, and the punter sees exposure they do not
    // have (or, worse, none that they do). Found in the wild: useraja1 (user 22) sat at
    // -100.00 from 2026-08-01 with zero exposure rows and cash == inr_balance.
    //
    // The subquery mirrors TOTAL_EXPOSURE_SQL (helper/totalExposure.js, the one
    // copy every writer shares since 2026-10-07): casino BOOK markets
    // (game_type like 'teen1:main') are grouped MIN like sports team markets,
    // other casino rows are additive and never back/lay-filtered. Keep in step
    // with that file — if they diverge this check is the thing that says so.
    key: 'staleExposureSnapshot', severity: 'high',
    label: 'total_exposures snapshot matches the exposure rows under it',
    sql: `
      SELECT CAST(te.user_id AS TEXT) AS user_id, u.username, u.role,
        'header shows ' || ROUND(te.total_exposure::numeric,2)
        || ' but the rows derive ' || ROUND(COALESCE(d.derived,0)::numeric,2) AS detail
      FROM total_exposures te
      JOIN (SELECT * FROM users WHERE COALESCE(is_demo,false) = false) u ON CAST(u.user_id AS TEXT) = CAST(te.user_id AS TEXT)
      LEFT JOIN (
        SELECT user_id, SUM(m) AS derived FROM (
          SELECT CAST(user_id AS TEXT) AS user_id, MIN(exposure_amount) AS m
            FROM user_exposures
           WHERE (category <> 'casino' OR game_type LIKE '%:%') AND game_type IS NOT NULL
             AND game_type NOT IN ${FANCY_GT} AND game_type NOT LIKE '%Overs Line%' AND ${NOT_BACKLAY}
           GROUP BY 1, match_id, game_type, event_id
          UNION ALL
          SELECT CAST(user_id AS TEXT), exposure_amount FROM user_exposures
           WHERE ( (category = 'casino' AND (game_type IS NULL OR game_type NOT LIKE '%:%'))
                   OR game_type IS NULL OR game_type IN ${FANCY_GT}
                   OR game_type LIKE '%Overs Line%' )
             AND (category = 'casino' OR ${NOT_BACKLAY})
        ) q GROUP BY 1
      ) d ON d.user_id = CAST(te.user_id AS TEXT)
      WHERE ABS(te.total_exposure - COALESCE(d.derived,0)) > 0.01`,
  },
  {
    // VOID THAT RETURNED NOTHING — the one failure orphanExposure cannot see.
    //
    // orphanExposure catches a void that left the rows behind. The opposite slip leaves
    // NO trace at all: the exposure rows are destroyed but the wallet is never credited,
    // so the punter silently loses the stake and there is nothing left to point at.
    //
    // GRAIN MATTERS, and getting it wrong is what makes this check unusable. A void
    // writes ONE refund row per void GROUP, on a representative bet
    // (recordManualVoidRefund, mannualSettle/controller.js) — not one per bet. The group
    // is the exposure bucket: per SELECTION for the fancy family, per MARKET for MO/BM.
    // Asserting a row per BET reports 14 correct voids as broken; asserting it per
    // SELECTION still breaks MO/BM, where the representative bet is a different runner
    // (bets 1556-1558 'Zimbabwe' are covered by bet 1555 'Namibia' on the same
    // Bookmaker book). Measured at the right grain: 0 findings.
    //
    // Voids before 2026-08-23 wrote no ledger row at all (the audit trail landed that
    // day, docs/plans/2026-08-23-refund-audit-trail.md), so every earlier one
    // legitimately has none and asserting them would mark correct history as broken.
    // A zero-liability void also writes nothing by design, which is why this asserts
    // the GROUP has at least one row rather than any particular amount.
    key: 'voidRefundMissing', severity: 'high',
    label: 'Every void group returned its exposure to the wallet (refund row exists)',
    sql: `
      WITH v AS (
        SELECT b.id, CAST(b.user_id AS TEXT) AS user_id, b.match_id, b.market_type,
               CASE WHEN b.market_type IN ${FANCY_GT} OR b.market_type ILIKE '%line'
                    THEN b.selection_name ELSE '<market>' END AS bucket_key
          FROM "SportsBet" b
         WHERE LOWER(COALESCE(b.result_status,'')) IN ('refunded','void')
           AND COALESCE(b.match_end_time, b.updated_at) >= TIMESTAMPTZ '2026-08-23'
      )
      SELECT v.user_id, u.username, u.role,
        COUNT(*) || ' voided bet(s) on ' || v.market_type
          || ' with no refund row for the group (exposure released to nobody)' AS detail
      FROM v JOIN (SELECT * FROM users WHERE COALESCE(is_demo,false) = false) u ON CAST(u.user_id AS TEXT) = v.user_id
      GROUP BY v.user_id, u.username, u.role, v.match_id, v.market_type, v.bucket_key
      HAVING SUM(CASE WHEN EXISTS (SELECT 1 FROM credits_ledger l
                                    WHERE l.bet_id = v.id AND LOWER(l.reason) = 'refund')
                      THEN 1 ELSE 0 END) = 0`,
  },
  {
    // EVERY VOID MUST LEAVE AN AUDIT ROW.
    //
    // bet_void_audit is written inside each void's own transaction, so a
    // committed void cannot be missing its row — unless a void path was added
    // later and nobody wired it up. That is exactly the failure this catches:
    // not corrupt data, but a BLIND SPOT reopening. It is the backstop for the
    // one path that cannot write transactionally (settlementv2's SUSPENDED
    // refund runs without a transaction and swallows audit errors on purpose,
    // so a refund is never undone by a logging failure).
    //
    // Historical voids were backfilled (backfilled=true), so this should read 0
    // permanently. A finding means: find the void path that wrote no row.
    key: 'voidNotAudited', severity: 'high',
    label: 'Every voided bet has a bet_void_audit row',
    sql: `
      SELECT CAST(b.user_id AS TEXT) AS user_id, u.username, u.role,
        COUNT(*) || ' voided bet(s) with no audit row (e.g. bet ' || MIN(b.id) || ')' AS detail
      FROM "SportsBet" b
      JOIN (SELECT * FROM users WHERE COALESCE(is_demo,false) = false) u ON CAST(u.user_id AS TEXT) = CAST(b.user_id AS TEXT)
      WHERE LOWER(COALESCE(b.result_status,'')) IN ('refunded','void','refund')
        AND NOT EXISTS (SELECT 1 FROM bet_void_audit a
                         WHERE a.bet_kind = 'SPORTS' AND a.bet_id = b.id)
      GROUP BY CAST(b.user_id AS TEXT), u.username, u.role`,
  },
  // NOTE 1: a per-bet "win/loss vs booked P&L sign" check is intentionally NOT here —
  // MO/BM settle per-MARKET (one net row for a hedged back+lay group), so the row on
  // the group's first bet is the GROUP net, not that bet's P&L. A per-bet sign check
  // false-positives on hedged groups. Wrong-result detection for team markets lives in
  // the market-aware per-user verifier; the fancy-only per-bet sign check is there too.
  // NOTE 2: manual-settle / no-declared-result is informational, shown only in the
  // per-user wallet history (description + 'manual settle' badge), never the bell.
];

// Hierarchy / point-ledger invariants live in their own module (docs/ledgerpoint.md).
// Same check contract, so the scan loop below needs no special-casing.
export const CHECKS = [...CORE_CHECKS, ...HIERARCHY_CHECKS];

export async function ensureTable() {
  await run(`
    CREATE TABLE IF NOT EXISTS integrity_alerts (
      id           SERIAL PRIMARY KEY,
      user_id      TEXT NOT NULL,
      username     TEXT,
      role         TEXT,
      check_key    TEXT NOT NULL,
      label        TEXT,
      detail       TEXT,
      severity     TEXT DEFAULT 'high',
      detected_at  TIMESTAMPTZ DEFAULT now(),
      updated_at   TIMESTAMPTZ DEFAULT now(),
      resolved_at  TIMESTAMPTZ,
      UNIQUE (user_id, check_key)
    )`);
}

// Advisory-lock key for the scan. Any 64-bit constant works; it just has to be the
// same in every process that scans.
const SCAN_LOCK_KEY = 918273645;

/** Run all set-based checks, upsert findings, auto-resolve passers.
 *
 * CONCURRENCY-SAFE. The auto-resolve at the end is
 * `WHERE resolved_at IS NULL AND updated_at < :ts`, which means two overlapping scans
 * destroy each other's work: the later one resolves findings the earlier one has not
 * finished re-writing yet. Reproduced in practice — a worker restart during a manual
 * scan collapsed 25 live findings to 9, and a clean single scan restored all 25.
 * The panel's "Re-scan now" button makes that collision easy to hit near the worker's
 * 10-minute tick, so a scan now takes a Postgres advisory lock and a second caller
 * returns `{ skipped: true }` instead of corrupting the table.
 */
export async function scanAllUsers() {
  await ensureTable();

  // Transaction-scoped lock, deliberately. A session-scoped pg_advisory_lock would be
  // unsafe here: sequelize pools connections, so the matching pg_advisory_unlock could
  // land on a DIFFERENT connection than the one holding the lock and leak it forever.
  // pg_try_advisory_xact_lock is bound to this transaction and is released by the
  // commit/rollback below, on the right connection, even if the scan throws.
  const lockTx = await sequelize.transaction();
  try {
    const rows = await sequelize.query(`SELECT pg_try_advisory_xact_lock(:key) AS got`, {
      type: QueryTypes.SELECT, replacements: { key: SCAN_LOCK_KEY }, transaction: lockTx,
    });
    if (!(rows[0] && rows[0].got === true)) {
      await lockTx.rollback();
      return { skipped: true, reason: 'another scan is already running', totalFindings: 0, flaggedUsers: 0 };
    }
    // The checks themselves run on pooled connections outside lockTx — that is fine,
    // the transaction exists only to own the lock for the duration of the scan.
    const result = await runScan();
    await lockTx.commit();
    return result;
  } catch (e) {
    // Always settle the transaction, including when the lock query itself threw —
    // guarding this on `holding` would leak the pooled connection in exactly the
    // case where the DB is already unhappy.
    try { await lockTx.rollback(); } catch (_) { /* already committed or rolled back */ }
    throw e;
  }
}

async function runScan() {
  const ts = new Date();
  let totalFindings = 0;
  const flagged = new Set();

  for (const check of CHECKS) {
    try {
      const rows = await sel(check.sql);
      for (const r of rows) {
        totalFindings += 1;
        flagged.add(r.user_id);
        await run(
          `INSERT INTO integrity_alerts
             (user_id, username, role, check_key, label, detail, severity, detected_at, updated_at, resolved_at)
           VALUES (:user_id, :username, :role, :check_key, :label, :detail, :severity, :ts, :ts, NULL)
           ON CONFLICT (user_id, check_key) DO UPDATE SET
             username = EXCLUDED.username, role = EXCLUDED.role, label = EXCLUDED.label,
             detail = EXCLUDED.detail, severity = EXCLUDED.severity, updated_at = :ts,
             detected_at = CASE WHEN integrity_alerts.resolved_at IS NULL
                                THEN integrity_alerts.detected_at ELSE :ts END,
             resolved_at = NULL`,
          { user_id: r.user_id, username: r.username || null, role: r.role || null,
            check_key: check.key, label: check.label, detail: r.detail || null,
            severity: check.severity, ts }
        );
      }
    } catch (e) {
      console.error(`[integrity] check ${check.key} failed:`, e.message); // one bad check must not abort the scan
    }
  }

  // auto-resolve: any active row not refreshed in this scan now passes
  await run(`UPDATE integrity_alerts SET resolved_at = :ts, updated_at = :ts
             WHERE resolved_at IS NULL AND updated_at < :ts`, { ts });

  return { scannedAt: ts.toISOString(), totalFindings, flaggedUsers: flagged.size };
}

/** Read the cached table grouped per user (instant — no scan). */
export async function getActiveAlerts() {
  await ensureTable();
  const rows = await sel(
    `SELECT user_id, username, role, check_key, label, detail, severity, detected_at
       FROM integrity_alerts WHERE resolved_at IS NULL
      ORDER BY user_id, check_key`);
  const byUser = new Map();
  for (const r of rows) {
    if (!byUser.has(r.user_id)) byUser.set(r.user_id, { user_id: r.user_id, username: r.username, role: r.role, issues: [] });
    byUser.get(r.user_id).issues.push({ key: r.check_key, label: r.label, detail: r.detail, severity: r.severity, since: r.detected_at });
  }
  const lastScanRows = await sel(`SELECT MAX(updated_at) AS last FROM integrity_alerts`);

  // The bell must count only what an owner can ACT on. Informational rows (checks
  // demoted because this codebase does not maintain the invariant — see the notes on
  // walletDerivation and exposure) are still listed for context, but a badge that
  // includes them can never reach zero, and a badge that never reaches zero gets
  // ignored. So: `actionable` drives the bell, `totalIssues` stays for the full list.
  const isInfo = (r) => r.severity === 'info';
  const actionableRows = rows.filter((r) => !isInfo(r));
  return {
    count: byUser.size,
    totalIssues: rows.length,
    actionable: actionableRows.length,
    actionableUsers: new Set(actionableRows.map((r) => r.user_id)).size,
    informational: rows.length - actionableRows.length,
    users: Array.from(byUser.values()),
    lastScan: lastScanRows[0] ? lastScanRows[0].last : null,
  };
}

export default { CHECKS, ensureTable, scanAllUsers, getActiveAlerts };
