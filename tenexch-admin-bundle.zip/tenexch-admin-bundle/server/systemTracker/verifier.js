/**
 * verifier.js — System Tracker per-user verifier.
 *
 * Re-derives an account's wallet / P&L / exposure / settlement state DIRECTLY from
 * raw tables and compares against the app-maintained values. RAW SQL ONLY (no app
 * models); the only business-logic import is the pure rulebook (sportsRule.js).
 *
 * Output is organised into CATEGORIES → sub-rules so the panel reads as concepts
 * (what should be true) rather than formulas. Every check is { label(concept),
 * expected, actual, diff, pass, info, severity, subs? }.
 */

import { QueryTypes } from 'sequelize';
import R from './sportsRule.js';
import C from './casinoRule.js';
import L from './liveCasinoRule.js';
import { getEventResultIndex, normMarket } from './resultFeed.js';

const q = (sequelize, sql, replacements) => sequelize.query(sql, { type: QueryTypes.SELECT, replacements: replacements || {} });
const num = (v) => { const n = Number(v); return Number.isFinite(n) ? n : 0; };
const r2 = (v) => Number(num(v).toFixed(2));
const TOL = 0.01;

// one check (concept-named)
const chk = (label, expected, actual, { info = false, severity = 'high', subs = null, note = null } = {}) => {
  const diff = r2(num(actual) - num(expected));
  return { label, expected: r2(expected), actual: r2(actual), diff, pass: Math.abs(diff) <= TOL, info, severity, subs, note };
};
const catVerdict = (rules) => rules.every((r) => r.info || r.pass);

// See scanner.js — users.profit is never incremented for THIRD_PARTY settlements
// (jsgamesv2/gameController.js:311 writes the ledger row only), so counting those rows
// makes the comparison disagree by exactly the account's third-party P/L.
const PL_WHERE = `( ( LOWER(reason) IN ('settlement','settlement_void','commission','commission_void')
                      OR UPPER(reason) IN ('BET_WIN','BET_LOSS') )
                    AND COALESCE(category,'') NOT LIKE 'THIRD%' )`;
const FANCY_GT = `('Normal','Ball By Ball','Over By Over','khado','meter','fancy1','oddeven','fancy2','badlo')`;
const NOT_BACKLAY = `NOT (team_name ILIKE '%back' OR team_name ILIKE '%lay' OR team_name ILIKE '%totalstake')`;

/* ---------------------------------------------------------------- search */
export async function searchUsers(sequelize, qstr) {
  if (!qstr || String(qstr).trim().length < 2) return [];
  const like = `%${String(qstr).trim()}%`;
  return q(sequelize,
    `SELECT * FROM (
        SELECT CAST(user_id AS TEXT) AS user_id, username, CAST(role AS TEXT) AS role, 'user' AS kind FROM users
         WHERE username ILIKE :like OR CAST(user_id AS TEXT) ILIKE :like
        UNION ALL
        SELECT CAST(staff_id AS TEXT), username, CAST(role AS TEXT), 'staff' FROM staff
         WHERE (username ILIKE :like OR CAST(staff_id AS TEXT) ILIKE :like) AND "deletedAt" IS NULL
        UNION ALL
        SELECT CAST(owner_id AS TEXT), username, CAST(role AS TEXT), 'owner' FROM "Owners"
         WHERE username ILIKE :like OR CAST(owner_id AS TEXT) ILIKE :like
     ) s ORDER BY (kind <> 'user'), username LIMIT 25`, { like });
}

/* ----------------------------------------------------- dispatcher */
export async function buildUserReport(sequelize, idOrUsername) {
  const k = String(idOrUsername);
  const users = await q(sequelize,
    `SELECT user_id, username, role, net_win, net_loss, profit FROM users
      WHERE CAST(user_id AS TEXT) = :k OR username = :k LIMIT 1`, { k });
  if (users.length) return buildBettorReport(sequelize, users[0]);
  const staff = await q(sequelize,
    `SELECT staff_id AS id, username, role FROM staff
      WHERE (CAST(staff_id AS TEXT) = :k OR username = :k) AND "deletedAt" IS NULL LIMIT 1`, { k });
  if (staff.length) return buildAgentReport(sequelize, staff[0], 'staff', 'staff_id');
  const owner = await q(sequelize,
    `SELECT owner_id AS id, username, role FROM "Owners" WHERE CAST(owner_id AS TEXT) = :k OR username = :k LIMIT 1`, { k });
  if (owner.length) return buildAgentReport(sequelize, owner[0], 'owner', 'owner_id');
  return { found: false, error: 'Account not found' };
}

/* ============================ BETTOR (users) — full report =================== */
async function buildBettorReport(sequelize, u) {
  const uid = String(u.user_id);

  const w = (await q(sequelize,
    `SELECT inr_balance, cash, cash_received, profit_loss, "totalCommission" FROM "Wallets" WHERE user_id = :uid LIMIT 1`, { uid }))[0] || {};
  // total_exposures is THE live snapshot on this site: the player header, the admin
  // user list and the wallet's cash lock all read it. user_net_exposure is a dead table
  // here — its sync worker has no pm2 process (scanner.js already says so and demoted
  // its own copy of this check to informational), so it holds 3 rows for the whole site
  // and comparing against it failed this rule for every single account.
  const storedNetExp = num(((await q(sequelize,
    `SELECT total_exposure FROM total_exposures WHERE user_id = :uid LIMIT 1`, { uid }).catch(() => []))[0] || {}).total_exposure);

  const inr = num(w.inr_balance), cash = num(w.cash), locked = r2(inr - cash);
  const snapshot = {
    kind: 'user', user_id: uid, username: u.username, role: u.role,
    total_balance: r2(inr), available_balance: r2(cash), locked_exposure: locked,
    profit_loss: r2(u.profit), net_exposure: r2(storedNetExp),
    net_win: r2(u.net_win), net_loss: r2(u.net_loss), cash_received: r2(w.cash_received),
    // ledger-derived, per the owner's definition — these are the figures to trust
    actual_pl: null, total_win: null, total_loss: null,
  };

  const categories = [];

  // Re-derived worst-case exposure, market-aware: team markets (MO/BM) net to the worst
  // single runner per market, fancy/casino rows are their own per-selection pot. Hoisted
  // above the wallet block because money conservation needs it too — this, not the gross
  // sum of per-bet liability, is what the wallet actually locks out of `cash`.
  const derived = num(((await q(sequelize,
    `SELECT COALESCE(SUM(grp),0) AS exp FROM (
        SELECT LEAST(0, MIN(exposure_amount)) AS grp FROM user_exposures
         WHERE user_id=:uid AND category<>'casino' AND game_type IS NOT NULL
           AND game_type NOT IN ${FANCY_GT} AND game_type NOT LIKE '%Overs Line%' AND ${NOT_BACKLAY}
         GROUP BY match_id, game_type, event_id
        UNION ALL
        SELECT LEAST(exposure_amount,0) FROM user_exposures
         WHERE user_id=:uid AND (category='casino' OR game_type IS NULL OR game_type IN ${FANCY_GT} OR game_type LIKE '%Overs Line%') AND ${NOT_BACKLAY}
     ) s`, { uid }))[0] || {}).exp);

  /* ---- 1. WALLET INTEGRITY (money conservation — catch any rupee) ---- */
  // A bet that has reached a TERMINAL result_status holds no money, whatever `status`
  // still says. The settlement worker pushes bets it cannot resolve back to
  // 'open'/'processing' AFTER a void has been applied (casinoVoidService.js:38-47
  // documents this race and is why every filter there keys off result_status, not
  // status). Without these guards an already-refunded bet is counted as locked funds
  // and the account reports a phantom shortfall — measured: user 24 showed a false
  // "locked 2420" against 5 casino bets that were voided, refunded and had their
  // exposure rows cleared. Sports currently has no open-but-resolved rows; the guard
  // is there so it cannot start lying later either.
  const lockRows = (await q(sequelize,
    `SELECT (SELECT COALESCE(SUM(ABS(exposer)),0) FROM casino_bets
              WHERE user_id=:uid AND status IN ('open','processing')
                AND (result_status IS NULL OR result_status = '')) AS c,
            (SELECT COALESCE(SUM(liability),0) FROM "SportsBet"
              WHERE user_id=:uid AND status IN ('open','manual')
                AND LOWER(COALESCE(result_status,'pending')) IN ('pending','')) AS s`, { uid }))[0];
  // "SportsBet".liability is a GROSS per-bet number: it never nets the two sides of a
  // hedged pot. A meter line with a `no` @38 (liability 1500) and a `yes` @42
  // (liability 420) on the SAME selection reports 1920 while the pot risks 40; oddeven
  // stores stake x odds (195 on a 100 stake @1.95) where only the stake is at risk. So
  // the sports leg of "locked" is the worst case the exposure engine computed — the
  // same figure that produced `cash` — and the gross sum stays below as an advisory.
  const lockedLiab = num(lockRows.c) + Math.abs(derived);
  const grossLiab = num(lockRows.c) + num(lockRows.s);
  const lastClosing = num(((await q(sequelize,
    `SELECT closing FROM credits_ledger WHERE user_id=:uid ORDER BY created_at DESC, id DESC LIMIT 1`, { uid }))[0] || {}).closing);

  const walletRules = [
    chk('Available + locked funds equal the total balance', inr, cash + lockedLiab),
    // advisory: a hedged book makes this legitimately exceed the locked worst case. It
    // is here so a pot that genuinely under-locks against its own bets stays visible.
    chk('Gross per-bet liability (before pot offsetting)', lockedLiab, grossLiab, { info: true }),
    // NOTE: the old 'Stored balance is internally consistent' rule is gone. profit_loss is
    // derived on read now (model/admin/Wallet.js afterFind), so stored-vs-formula can no
    // longer disagree for any consumer. Money conservation is covered by the rule above.
    // advisory: casino placement does not write a ledger row, so when open casino
    // bets have locked cash the last ledger closing legitimately lags `cash`. The
    // hard money-conservation check above ('available + locked = total') already
    // guarantees no rupee is lost; this is a secondary confirmation only.
    chk('Wallet ledger running balance tracks the available balance', cash, lastClosing, { info: true }),
  ];
  categories.push({ key: 'wallet', label: 'Wallet Integrity', icon: 'wallet', rules: walletRules, pass: catVerdict(walletRules) });

  /* ---- 2. PROFIT & LOSS ---- */
  const pl = (await q(sequelize,
    `SELECT COALESCE(SUM(profit),0) AS p, COALESCE(SUM(loss),0) AS l FROM credits_ledger WHERE user_id=:uid AND ${PL_WHERE}`, { uid }))[0];
  const sp = num(pl.p), sl = num(pl.l);
  const byCat = await q(sequelize,
    `SELECT category, COALESCE(SUM(profit),0)+COALESCE(SUM(loss),0) AS net FROM credits_ledger WHERE user_id=:uid AND ${PL_WHERE} GROUP BY category`, { uid });
  // Owner's definition (2026-08-23):
  //   net_win = total win · net_loss = total loss · profit = actual P/L (+ or −)
  // which is exactly the ledger's own profit / loss columns. So the LEDGER figures are
  // reported as the answer, and the stored users.* counters are shown beside them as a
  // cache that is known to lag.
  //
  // The counters cannot currently be trusted: settlementv2.js increments net_win/net_loss
  // from the P&L columns but `profit` from `netamount` (total movement, stake included),
  // and a second path at :2372 uses netamount for all three. 16 of 32 accounts have
  // drifted. Fixing that means editing settlement, which the owner has ruled out — so the
  // tracker reports the truth from the ledger instead of asserting the counter is wrong.
  // Plan (not executed): docs/plans/2026-08-23-counter-definition-fix.md
  const storedProfit = num(u.profit), storedWin = num(u.net_win), storedLoss = num(u.net_loss);
  const plRules = [
    { label: 'Actual P/L (from ledger — total win + total loss)',
      expected: r2(sp + sl), actual: r2(sp + sl), diff: 0, pass: true, info: true,
      severity: 'review',
      note: Math.abs(storedProfit - (sp + sl)) <= 0.01
        ? 'stored counter agrees'
        : `stored users.profit reads ${r2(storedProfit)} — counter lags, ledger is authoritative`,
      subs: byCat.map((c) => ({ label: `${c.category} settled P/L`, expected: r2(c.net), actual: r2(c.net), diff: 0, pass: true, info: true })),
    },
    { label: 'Total win (from ledger)', expected: r2(sp), actual: r2(sp), diff: 0, pass: true, info: true,
      severity: 'review',
      note: Math.abs(storedWin - sp) <= 0.01 ? 'stored counter agrees' : `stored net_win reads ${r2(storedWin)}` },
    { label: 'Total loss (from ledger)', expected: r2(sl), actual: r2(sl), diff: 0, pass: true, info: true,
      severity: 'review',
      note: Math.abs(storedLoss - sl) <= 0.01 ? 'stored counter agrees' : `stored net_loss reads ${r2(storedLoss)}` },
  ];
  // fill the ledger-derived figures declared on the snapshot above
  snapshot.actual_pl = r2(sp + sl);
  snapshot.total_win = r2(sp);
  snapshot.total_loss = r2(sl);
  snapshot.counters_lag = Math.abs(storedProfit - (sp + sl)) > 0.01
    || Math.abs(storedWin - sp) > 0.01 || Math.abs(storedLoss - sl) > 0.01;

  categories.push({ key: 'pnl', label: 'Profit & Loss', icon: 'pnl', rules: plRules, pass: catVerdict(plRules) });

  /* ---- 3. EXPOSURE (overall + market-wise subs) ---- */
  // Same two-branch bucketing as `derived`, aggregated per market, so the sub-rows ADD UP
  // to the headline. A flat MIN over the whole market showed only the single worst line
  // (meter read -330 instead of -980) and the rows summed to a number appearing nowhere.
  const perMarket = await q(sequelize,
    `SELECT market, game_type, ROUND(SUM(grp)::numeric,2) AS worst FROM (
        SELECT COALESCE(match_title, match_id) AS market, game_type, LEAST(0, MIN(exposure_amount)) AS grp
          FROM user_exposures
         WHERE user_id=:uid AND category<>'casino' AND game_type IS NOT NULL
           AND game_type NOT IN ${FANCY_GT} AND game_type NOT LIKE '%Overs Line%' AND ${NOT_BACKLAY}
         GROUP BY 1, 2, match_id, event_id
        UNION ALL
        SELECT COALESCE(match_title, match_id) AS market, game_type, LEAST(exposure_amount, 0) AS grp
          FROM user_exposures
         WHERE user_id=:uid AND (category='casino' OR game_type IS NULL OR game_type IN ${FANCY_GT} OR game_type LIKE '%Overs Line%') AND ${NOT_BACKLAY}
     ) s GROUP BY market, game_type ORDER BY worst ASC`, { uid }).catch(() => []);
  const expRules = [
    chk('Net exposure equals the re-derived worst-case', derived, storedNetExp, {
      subs: perMarket.map((m) => ({ label: `${m.market} (${m.game_type || '—'})`, expected: r2(m.worst), actual: r2(m.worst), diff: 0, pass: true })),
    }),
  ];
  categories.push({ key: 'exposure', label: 'Exposure', icon: 'exposure', rules: expRules, pass: catVerdict(expRules) });

  /* ---- 4. SPORTS SETTLEMENT (structural concepts; subs = offending bets) ---- */
  const sBets = await q(sequelize,
    `SELECT id, bet_type, selection_name, market_type, game_type, category, stake_amount, odds, size, liability, status, result_status, match_id, match_title, eventid, fancy_name
       FROM "SportsBet" WHERE user_id=:uid ORDER BY id`, { uid });
  const sLedger = {};
  if (sBets.length) {
    for (const lr of await q(sequelize, `SELECT bet_id, reason, amount, netamount, profit, loss, commission FROM credits_ledger WHERE user_id=:uid AND category='SPORTS' AND bet_id IS NOT NULL`, { uid }))
      (sLedger[String(lr.bet_id)] ||= []).push(lr);
  }
  // Declared upstream results (authoritative source: sports_bet_result_cache holds
  // winner_name/winner_id per market). resultMap[eventid] = [{market_name,
  // betting_type, winner_name, winner_id}]. A settled bet whose event isn't here
  // was settled manually / without a confirmed result.
  // Declared results from BOTH sources: automatic (sports_bet_result_cache) and
  // manual (mannual_result — what the admin declared when settling by hand).
  // resultMap[eventid] = [{market_name, betting_type, winner_name, winner_id, source}].
  const resultMap = {};
  const autoSet = new Set();
  const manualSet = new Set();
  const eventIds = [...new Set(sBets.map((b) => String(b.eventid)).filter(Boolean))];
  if (eventIds.length) {
    for (const r of await q(sequelize,
      `SELECT CAST(eventid AS TEXT) AS eventid, market_name, betting_type, winner_name, winner_id
         FROM sports_bet_result_cache WHERE declared = true AND CAST(eventid AS TEXT) IN (:ids)`,
      { ids: eventIds }).catch(() => [])) {
      (resultMap[r.eventid] ||= []).push({ ...r, source: 'auto' }); autoSet.add(r.eventid);
    }
    for (const r of await q(sequelize,
      `SELECT CAST(eventid AS TEXT) AS eventid, market_type, game_type, "winnerName", "winnerId", "fancyName"
         FROM mannual_result WHERE CAST(eventid AS TEXT) IN (:ids)`,
      { ids: eventIds }).catch(() => [])) {
      (resultMap[r.eventid] ||= []).push({ market_name: r.fancyName || r.market_type, betting_type: r.game_type, winner_name: r.winnerName, winner_id: r.winnerId, source: 'manual' });
      manualSet.add(r.eventid);
    }
  }
  const declaredSet = new Set(Object.keys(resultMap)); // has SOME result (auto or manual)
  // Duplicate settlement rows that have ALREADY been reversed must not be reported as an
  // open double-payout. The 2026-08-19 incident (see docs/INCIDENT-2026-08-19-duplicate-
  // settlements.md) was remediated on 2026-08-20 with `correction` rows, and the original
  // settlement rows correctly remain in place — credits_ledger is history, not state.
  // Those corrections name the bets they cover in their description.
  const reversedBets = new Set();
  {
    const corr = await q(sequelize,
      `SELECT description FROM credits_ledger
        WHERE CAST(user_id AS TEXT) = :uid AND LOWER(reason) IN ('correction','settlement_void')`,
      { uid }).catch(() => []);
    for (const c of corr) {
      // descriptions read like "... on bet(s) 947,952,978,979 (duplicate FAN settlement passes)"
      const m = String(c.description || '').match(/bet\(s\)\s*([0-9,\s]+)/i);
      if (m) for (const id of m[1].split(',')) { const t = id.trim(); if (t) reversedBets.add(t); }
    }
  }
  categories.push(buildSportsSettlementCategory(sBets, sLedger, declaredSet, resultMap, manualSet, autoSet, reversedBets));

  // ---- the result each bet was SETTLED AGAINST (display only, never money math) ----
  // team (MO/BM) -> winning team from sports_settlement_report (local, resolved at
  // settle time); fancy -> the numeric line result from the live result feed, matched
  // by market name, with mannual_result as the fallback for hand-settled lines.
  const betResultMap = {};
  for (const r of await q(sequelize,
    `SELECT CAST(bet_id AS TEXT) AS bid, resolved_winner, resolved_team FROM sports_settlement_report WHERE CAST(user_id AS TEXT) = :uid`, { uid }).catch(() => [])) {
    const w = r.resolved_winner || r.resolved_team;
    if (w != null && String(w).trim() !== '') betResultMap[r.bid] = String(w);
  }
  const fancyBets = sBets.filter((b) => R.isFancyMarket(b));
  if (fancyBets.length) {
    const fEvents = [...new Set(fancyBets.map((b) => String(b.eventid)).filter(Boolean))];
    const idxByEvent = {};
    await Promise.all(fEvents.map(async (ev) => { idxByEvent[ev] = await getEventResultIndex(ev).catch(() => null); }));
    for (const b of fancyBets) {
      if (betResultMap[String(b.id)]) continue;
      const key = normMarket(b.fancy_name || b.market_type);
      let res = idxByEvent[String(b.eventid)]?.fancy?.[key];
      if (res == null) { // manual fallback (hand-settled lines absent from the feed)
        const mr = (resultMap[String(b.eventid)] || []).find((x) => normMarket(x.market_name) === key);
        if (mr) res = mr.winner_id ?? mr.winner_name;
      }
      if (res != null && String(res).trim() !== '') betResultMap[String(b.id)] = String(res);
    }
  }

  /* ---- 5. CASINO SETTLEMENT (casinoRule.js concepts: payout = stake×odds, loss =
     stake, every settled bet booked once, void→refund). Shown as the "Casino" tab. ---- */
  categories.push(await buildCasinoSettlementCategory(sequelize, uid));

  /* ---- 6. LIVE CASINO (JS games) — shown as the "Live Casino" tab. ---- */
  categories.push(await buildJsGamesCategory(sequelize, uid));

  /* ---- history (full wallet passbook: opening → every change → running balance) ---- */
  const history = await buildHistory(sequelize, uid, sBets, declaredSet, resultMap, manualSet, autoSet, w, betResultMap, u.username);

  // wallet tally = HARD money-conservation (Total = Available + Locked). This is the
  // calibration-clean "every rupee accounted" check — it does NOT use the ledger's
  // running `closing` (which lags `cash` because casino placements lock cash without a
  // ledger row), so it never false-positives on open bets.
  const walletTally = {
    total: r2(inr), available: r2(cash), locked: r2(lockedLiab),
    reconciles: Math.abs(inr - (cash + lockedLiab)) <= 0.01,
    diff: r2(inr - (cash + lockedLiab)),
    ledgerEnd: r2(lastClosing), // advisory: ledger end-balance (lags cash when bets are open)
  };

  const allPass = categories.every((c) => c.pass);
  return { found: true, kind: 'user', snapshot, categories, history, historyCount: history.length, walletTally, allPass };
}

/* ---- sports settlement category (reuse calibrated market-aware logic) ---- */
function buildSportsSettlementCategory(bets, ledgerByBet, declaredSet, resultMap = {}, manualSet = new Set(), autoSet = new Set(), reversedBets = new Set()) {
  const winnerStr = (eventid) => {
    const rows = resultMap[String(eventid)];
    if (!rows || !rows.length) return null;
    const team = rows.find((r) => /match|bookmaker|bm|mo/i.test(r.betting_type || '')) || rows[0];
    return team.winner_name || team.winner_id || null;
  };
  const agg = {};
  for (const rule of R.RULES) agg[rule.key] = { label: rule.label, severity: rule.severity, pass: true, count: 0, subs: [] };
  const flag = (key, label, severity, betId, detail) => {
    const a = agg[key] || (agg[key] = { label, severity, pass: true, count: 0, subs: [] });
    a.pass = false; a.count += 1;
    if (a.subs.length < 50) a.subs.push({ label: `Bet #${betId}`, note: detail, pass: false });
  };
  const fancy = bets.filter((b) => R.isFancyMarket(b));
  const team = bets.filter((b) => !R.isFancyMarket(b));
  for (const bet of fancy) {
    // checkBet's contract says settlement rows arrive "already de-reversed by caller".
    // A bet whose duplicates were reversed by a correction is settled correctly in net
    // terms, so its duplicate rows must not be reported as an open double payout — the
    // rows stay in credits_ledger because it is history, not state.
    const betReversed = reversedBets.has(String(bet.id));
    for (const v of R.checkBet(bet, ledgerByBet[String(bet.id)] || [], {})) {
      if (betReversed && v.key === 'settlementDuplicate') continue;
      flag(v.key, v.label, v.severity, bet.id, v.detail);
    }
  }
  const groups = {};
  for (const b of team) {
    const key = `${b.match_id}::${b.market_type}`;
    (groups[key] ||= { bets: [], settled: 0 });
    groups[key].bets.push(b);
    if (!R.isVoid(b) && (String(b.status).toLowerCase() === 'closed' || ['won', 'loss'].includes(String(b.result_status).toLowerCase()))) groups[key].settled += 1;
  }
  for (const [key, g] of Object.entries(groups)) {
    const rows = g.bets.flatMap((b) => (ledgerByBet[String(b.id)] || [])).filter((r) => String(r.reason).toLowerCase() === R.LEDGER.SETTLEMENT);
    if (g.settled > 0 && rows.length === 0) flag('settlementMissing', 'Every settled market has a settlement record', 'high', g.bets[0].id, `market ${key}: ${g.settled} settled bet(s), no settlement record`);
    const groupReversed = g.bets.some((b) => reversedBets.has(String(b.id)));
    if (rows.length > 1 && !groupReversed)
      flag('settlementDuplicate', 'No market is settled more than once', 'high', g.bets[0].id, `market ${key}: ${rows.length} settlement records`);
    // NOTE: the "voided bet has a refund row" assertion used to live here too — a second
    // copy of the rule already removed from sportsRule.js. Manual voids historically wrote
    // no ledger row at all (10 of 10 refunded bets on this site have none); the stake went
    // straight back to the wallet. Voids from 2026-08-23 do write one, but every earlier
    // one legitimately has nothing, so asserting it marks correct history as broken.
    // The wrong direction — a voided bet that ALSO carries a settlement row, i.e. money
    // moved as if it had won or lost — is still caught by sportsRule.checkBet.
    for (const b of g.bets) {
      if (!R.isVoid(b)) continue;
      const rowsFor = ledgerByBet[String(b.id)] || [];
      const settledRows = rowsFor.filter((r) => String(r.reason).toLowerCase() === R.LEDGER.SETTLEMENT);
      const reversals   = rowsFor.filter((r) => String(r.reason).toLowerCase() === 'settlement_void');
      // A bet voided AFTER it settled legitimately keeps its original settlement row and
      // gains a settlement_void reversal that cancels it — that is exactly what
      // sportsVoidService writes, and the pair nets to zero. Only an UNREVERSED settlement
      // on a voided bet means money moved and was never given back.
      if (settledRows.length > reversals.length)
        flag('voidRefundOnly', 'Every voided bet is refunded', 'high', b.id,
             `bet ${b.id} is voided but carries ${settledRows.length} settlement row(s) with only ${reversals.length} reversal(s)`);
    }
  }
  // concept-friendly labels
  const conceptLabel = {
    settlementMissing: 'Every settled bet has a settlement record',
    settlementDuplicate: 'No bet is settled twice (no double payout)',
    statusMismatch: 'Bet status agrees with its settlement record',
    commissionScope: 'Commission only on wins (owner-configured sports win commission)',
    voidRefundOnly: 'Every voided bet is refunded (no win/loss applied)',
    wrongResult: 'Win/loss agrees with the declared result',
  };
  const rules = Object.entries(agg).map(([key, a]) => ({
    label: conceptLabel[key] || a.label, severity: a.severity, pass: a.pass,
    count: a.count, subs: a.subs, expected: 0, actual: a.count, diff: a.count, info: a.severity !== 'high',
  }));

  // ---- extra detail rules the operator asked for ----
  const settled = bets.filter((b) => !R.isVoid(b) && (String(b.status).toLowerCase() === 'closed' || ['won', 'loss'].includes(String(b.result_status).toLowerCase())));

  // selection present on every bet (high)
  const noSel = bets.filter((b) => !String(b.selection_name || '').trim());
  rules.push({
    label: 'Selection is present on every bet', severity: 'high', pass: noSel.length === 0,
    count: noSel.length, expected: 0, actual: noSel.length, diff: noSel.length, info: false,
    subs: noSel.slice(0, 50).map((b) => ({ label: `Bet #${b.id}`, note: `${b.market_type || ''} — selection missing`, pass: false })),
  });

  // RE-VERIFIABILITY (advisory, NOT a money bug): the auto-result feed
  // (sports_bet_result_cache) is a TRANSIENT cache — old/expired events drop out of
  // it, so a long-settled bet usually has no result row TODAY even though it settled
  // from a real result at the time (proven by its own settlement ledger entry + the
  // wallet checks above). "No result row now" therefore means "cannot independently
  // re-verify this old settlement", not "settled without a result". The genuine money
  // check is 'Win/loss agrees with the money booked' below, which needs no feed cache.
  const noResult = settled.filter((b) => !declaredSet.has(String(b.eventid)));
  rules.push({
    label: 'Result still on record (re-verifiable)', severity: 'review', pass: noResult.length === 0,
    count: noResult.length, expected: 0, actual: noResult.length, diff: noResult.length, info: true,
    subs: noResult.slice(0, 50).map((b) => ({ label: `Bet #${b.id}`, note: `${b.selection_name || ''} · ${b.market_type || ''} — result no longer retained in feed cache; settled ${b.result_status}, re-verify N/A`, pass: false })),
  });

  // GENUINE MONEY CHECK (high) — FANCY ONLY. Each fancy/independent line settles
  // per-bet with its own settlement row, so its booked P&L sign must match win/loss.
  // (Team MO/BM markets settle PER-MARKET — one net row for the whole hedged group on
  // its first bet — so a per-bet sign check there would false-positive; team wrong-
  // result is covered by 'Win/loss matches the declared result' above.)
  const plSign = [];
  for (const b of settled) {
    if (!R.isFancyMarket(b)) continue; // team markets settle per-group, not per-bet
    const sl = (ledgerByBet[String(b.id)] || []).filter((r) => String(r.reason).toLowerCase() === R.LEDGER.SETTLEMENT);
    if (!sl.length) continue; // no settlement row → already covered by the settlement-record check
    const prof = sl.reduce((s, r) => s + num(r.profit), 0);
    const loss = sl.reduce((s, r) => s + num(r.loss), 0);
    const won = String(b.result_status).toLowerCase() === 'won';
    const ok = won ? (prof > 0 && loss === 0) : (loss < 0 && prof === 0);
    if (!ok) plSign.push({ label: `Bet #${b.id}`, note: `settled ${b.result_status} but ledger booked profit ${r2(prof)} / loss ${r2(loss)} — payout sign disagrees with result`, pass: false });
  }
  rules.push({
    label: 'Win/loss agrees with the money booked (fancy)', severity: 'high', pass: plSign.length === 0,
    count: plSign.length, expected: 0, actual: plSign.length, diff: plSign.length, info: false, subs: plSign,
  });

  // settled via a MANUALLY-declared result (admin), informational — show the winner
  const manual = settled.filter((b) => manualSet.has(String(b.eventid)) && !autoSet.has(String(b.eventid)));
  rules.push({
    label: 'Manually-settled bets (admin-declared result)', severity: 'review', pass: manual.length === 0,
    count: manual.length, expected: 0, actual: manual.length, diff: manual.length, info: true,
    subs: manual.slice(0, 50).map((b) => ({ label: `Bet #${b.id}`, note: `${b.selection_name || ''} · ${b.market_type || ''} — admin declared: ${winnerStr(b.eventid) || '?'} · settled ${b.result_status}`, pass: false })),
  });

  // settle-vs-result: when a result IS declared, win/loss must match it (review).
  // (Skipped per-bet when the event has no declared result — covered by 'manual' above.)
  const norm = (s) => String(s || '').toLowerCase().replace(/\s+/g, ' ').trim();
  const wrong = [];
  for (const b of settled) {
    const rows = resultMap[String(b.eventid)];
    if (!rows || !rows.length) continue; // no declared result → covered by 'manual'
    const fancy = R.isFancyMarket(b);
    let derived = null, winnerTxt = '';
    if (fancy) {
      // match the bet's fancy line by market/fancy name, then judge against its numeric winner
      const row = rows.find((r) => norm(r.market_name) === norm(b.fancy_name) || norm(r.market_name) === norm(b.market_type)) || rows[0];
      const numeric = Number(row.winner_id);
      winnerTxt = `${row.winner_name ?? row.winner_id}`;
      derived = R.fancyWins(b.market_type, b.bet_type, b.odds, Number.isFinite(numeric) ? numeric : null);
    } else {
      const row = rows.find((r) => /match|bookmaker|bm|mo/i.test(r.betting_type || '')) || rows[0];
      winnerTxt = row.winner_name;
      derived = R.betWins(b.bet_type, b.selection_name, row.winner_name);
    }
    if (derived == null) continue;
    const claimWon = String(b.result_status).toLowerCase() === 'won';
    if (derived !== claimWon) wrong.push({ label: `Bet #${b.id}`, note: `result "${winnerTxt}" implies ${derived ? 'WON' : 'LOSS'} but settled as ${b.result_status} (${b.selection_name})`, pass: false });
  }
  rules.push({
    label: 'Win/loss matches the declared result', severity: 'review', pass: wrong.length === 0,
    count: wrong.length, expected: 0, actual: wrong.length, diff: wrong.length, info: true, subs: wrong,
  });

  return { key: 'sports', label: 'Sports', icon: 'sports', rules, pass: rules.every((r) => r.pass || r.info) };
}

/* ---- casino settlement category — per-game accordion ---- */
async function buildCasinoSettlementCategory(sequelize, uid) {
  const bets = await q(sequelize,
    `SELECT id, game_name, type, odds, stake, selection, exposer, status, result_status, credit_amt
       FROM casino_bets WHERE user_id=:uid ORDER BY id`, { uid });
  const ledger = {};
  if (bets.length)
    for (const lr of await q(sequelize, `SELECT bet_id, reason, amount, netamount, profit, loss FROM credits_ledger WHERE user_id=:uid AND category='CASINO' AND bet_id IS NOT NULL`, { uid }))
      (ledger[String(lr.bet_id)] ||= []).push(lr);

  // aggregate violations BY CONCEPT (mirrors the sports settlement category)
  const agg = {};
  for (const rule of C.RULES) agg[rule.key] = { label: rule.label, severity: rule.severity, pass: true, count: 0, subs: [] };
  const flag = (key, label, severity, betId, detail) => {
    const a = agg[key] || (agg[key] = { label, severity, pass: true, count: 0, subs: [] });
    a.pass = false; a.count += 1;
    if (a.subs.length < 50) a.subs.push({ label: `Bet #${betId}`, note: detail, pass: false });
  };
  const settled = bets.filter((b) => C.isSettled(b));
  for (const b of settled)
    for (const v of C.checkBet(b, ledger[String(b.id)] || [])) flag(v.key, v.label, v.severity, b.id, `${b.game_name} · ${b.selection || ''} — ${v.detail}`);

  const rules = Object.values(agg).map((a) => ({
    label: a.label, severity: a.severity, pass: a.pass, count: a.count, subs: a.subs,
    expected: 0, actual: a.count, diff: a.count, info: a.severity !== 'high',
  }));

  // per-game summary (informational) — bets / open / settled / win-rate, no pass/fail
  const games = {};
  for (const b of bets) {
    const g = (games[b.game_name] ||= { bets: 0, open: 0, won: 0, lost: 0 });
    g.bets += 1;
    if (C.isOpen(b)) g.open += 1;
    else if (C.betWon(b)) g.won += 1;
    else if (C.betLost(b)) g.lost += 1;
  }
  rules.push({
    label: 'Per-game activity', severity: 'review', info: true, pass: true,
    count: Object.keys(games).length, expected: 0, actual: Object.keys(games).length, diff: 0,
    subs: Object.entries(games).sort((a, b) => b[1].bets - a[1].bets).slice(0, 60)
      .map(([game, g]) => ({ label: game, note: `${g.bets} bet(s) · ${g.won}W / ${g.lost}L${g.open ? ` · ${g.open} open` : ''}`, pass: true })),
  });

  return { key: 'casino', label: 'Table Casino', icon: 'casino', rules, pass: rules.every((r) => r.pass || r.info), betCount: bets.length };
}

/* ---- LIVE CASINO (third-party JS games). These move cash + inr_balance together on
   every bet/win callback (NO exposure lock), keyed by external_transaction_id for
   idempotency; sessions track entry/exit balance. Concepts: no replayed/duplicate
   callback (double credit), no stuck transaction, net P/L, and games launched. ---- */
async function buildJsGamesCategory(sequelize, uid) {
  const tx = await q(sequelize,
    `SELECT id, game_uid, transaction_type, amount, transaction_status, external_transaction_id, timestamp
       FROM js_game_transactions WHERE CAST(user_id AS TEXT) = :uid ORDER BY id`, { uid }).catch(() => []);
  const sessions = await q(sequelize,
    `SELECT game_name, game_uid, provider, entry_balance, exit_balance, "createdAt" AS ts
       FROM game_sessions WHERE CAST(user_id AS TEXT) = :uid ORDER BY "createdAt" DESC`, { uid }).catch(() => []);

  const rules = [];
  const ruleMeta = (k) => L.RULES.find((r) => r.key === k);

  // (HIGH) idempotency — a replayed callback (same external_transaction_id + type) would
  // double-credit/debit the wallet.
  const dups = L.duplicateGroups(tx);
  rules.push({
    label: ruleMeta('noDuplicate').label, severity: 'high', info: false,
    pass: dups.length === 0, count: dups.length, expected: 0, actual: dups.length, diff: dups.length,
    subs: dups.slice(0, 50).map((d) => ({ label: `txn ${d.key.split('::')[0]}`, note: `${d.txns.length}× ${d.txns[0].transaction_type}`, pass: false })),
  });

  // (HIGH) no stuck/failed transaction
  const stuck = L.stuckTxns(tx);
  rules.push({
    label: ruleMeta('allCompleted').label, severity: 'high', info: false,
    pass: stuck.length === 0, count: stuck.length, expected: 0, actual: stuck.length, diff: stuck.length,
    subs: stuck.slice(0, 50).map((t) => ({ label: `txn #${t.id}`, note: `${t.transaction_type} — status ${t.transaction_status}`, pass: false })),
  });

  // (info) net P/L — Σ win − Σ bet (transactions) when present, else closed-session sum
  const closed = sessions.filter((s) => s.exit_balance != null);
  const sessionPL = closed.reduce((s, x) => s + L.sessionPL(x), 0);
  const netPL = tx.length ? r2(L.netPL(tx)) : r2(sessionPL);
  rules.push({
    label: 'Live-casino net profit / loss', severity: 'review', info: true, pass: true,
    expected: netPL, actual: netPL, diff: 0, count: null,
  });

  // (info) games launched — sessions with provider + entry/exit
  rules.push({
    label: 'Games launched (sessions)', severity: 'review', info: true, pass: true,
    count: sessions.length, expected: 0, actual: sessions.length, diff: 0,
    subs: sessions.slice(0, 50).map((s) => ({
      label: s.game_name || s.game_uid || '—',
      note: `${s.provider || '—'} · entry ₹${r2(s.entry_balance)}${s.exit_balance != null ? ` → exit ₹${r2(s.exit_balance)} · P&L ${r2(num(s.exit_balance) - num(s.entry_balance))}` : ' · still open'}`,
      pass: true,
    })),
  });

  return { key: 'jsgames', label: 'Live Casino', icon: 'jsgames', rules, pass: rules.every((r) => r.pass || r.info), betCount: tx.length || sessions.length };
}

/* ---- full wallet passbook: deposits/withdrawals (transactions) + bet movements
   (credits_ledger), merged chronologically, each row showing the recorded balance.  ---- */
async function buildHistory(sequelize, uid, sportsBets, declaredSet = new Set(), resultMap = {}, manualSet = new Set(), autoSet = new Set(), wallet = {}, betResultMap = {}, username = '') {
  const sMap = {}; for (const b of sportsBets || []) sMap[String(b.id)] = b;
  const cBets = await q(sequelize, `SELECT id, game_name, type, odds, stake, selection, result_status, round_id FROM casino_bets WHERE user_id=:uid`, { uid }).catch(() => []);
  const cMap = {}; for (const b of cBets) cMap[String(b.id)] = b;

  // live-casino (JS games) money moves — credited/debited directly to the wallet (not in
  // credits_ledger), so they must be merged here too. game_sessions gives provider/name.
  const jsTx = await q(sequelize,
    `SELECT id, game_uid, transaction_type, amount, external_transaction_id, transaction_status, timestamp AS ts
       FROM js_game_transactions WHERE CAST(user_id AS TEXT) = :uid ORDER BY id`, { uid }).catch(() => []);
  const jsGameMap = {};
  if (jsTx.length)
    for (const s of await q(sequelize, `SELECT DISTINCT ON (game_uid) game_uid, game_name, provider FROM game_sessions WHERE CAST(user_id AS TEXT)=:uid ORDER BY game_uid, "createdAt" DESC`, { uid }).catch(() => []))
      jsGameMap[s.game_uid] = s;

  // (A) admin cash in/out — these live in `transactions`, NOT credits_ledger, so the
  // passbook must merge them or the opening deposit is missing. A row is the user's own
  // balance line when they are the credited party (ADD_CASH) or the debited party.
  const uname = String(username || '').trim();
  const txRows = uname ? await q(sequelize,
    `SELECT id, type, amount, previous_balance, new_balance, initiated_by, "createdAt" AS ts
       FROM transactions
      WHERE (UPPER(type) LIKE 'ADD%' AND TRIM(credit) = :uname)
         OR (UPPER(type) LIKE 'DEBIT%' AND TRIM(debit) = :uname)
      ORDER BY "createdAt" ASC, id ASC`, { uname }).catch(() => []) : [];

  // (B) bet movements
  const rows = await q(sequelize,
    `SELECT id, created_at AS ts, reason, amount, netamount, profit, loss, closing, category, market_type, bet_id, eventid
       FROM credits_ledger WHERE user_id=:uid ORDER BY created_at ASC, id ASC LIMIT 5000`, { uid });

  const tms = (t) => { const d = new Date(t).getTime(); return Number.isFinite(d) ? d : 0; };

  // unified events with a recorded balance + sort key (cash-in before bets at equal time)
  const events = [];
  for (const t of txRows) {
    const credit = /^ADD/i.test(t.type);
    events.push({
      kind: 'tx', sort: [tms(t.ts), 0, Number(t.id) || 0], ts: t.ts,
      id: `tx${t.id}`, reason: credit ? 'deposit' : 'withdraw', category: 'WALLET', cash: true,
      description: `${credit ? 'Cash deposited' : 'Cash withdrawn'} by ${t.initiated_by || 'admin'}`,
      amount: r2(credit ? num(t.amount) : -num(t.amount)), balance: num(t.new_balance),
    });
  }
  for (const row of rows) {
    const isSports = String(row.category || '').toUpperCase() === 'SPORTS';
    const isCasino = String(row.category || '').toUpperCase() === 'CASINO';
    const sb = (isSports && row.bet_id) ? sMap[String(row.bet_id)] : null; // bet_id collides across casino/sports — gate by category
    const cb = (isCasino && row.bet_id) ? cMap[String(row.bet_id)] : null;
    const settledResult = sb ? (betResultMap[String(row.bet_id)] || null) : null;
    let description = row.reason;
    if (sb) description = `${(sb.bet_type || '').toUpperCase()} ${sb.selection_name || ''} @${num(sb.odds)} · stake ₹${num(sb.stake_amount)} · exposure ₹${num(sb.liability)} · ${sb.market_type || ''}${sb.match_title ? ' · ' + sb.match_title : ''}${sb.result_status ? ' · ' + sb.result_status : ''}`;
    else if (cb) description = `${(cb.type || '').toUpperCase()} ${cb.selection || ''} @${num(cb.odds)} · stake ₹${num(cb.stake)} · ${cb.game_name}${cb.round_id != null ? ' · round ' + cb.round_id : ''}${cb.result_status ? ' · ' + cb.result_status : ''}`;
    const profitBook = /exposure_release/i.test(row.reason) ||
      (/settlement/i.test(row.reason) && num(row.profit) > 0 && num(row.loss) === 0 && num(row.netamount) >= 0 && num(row.amount) > 0 && num(row.profit) !== num(row.netamount));
    const manual = /settlement/i.test(row.reason) && sb && manualSet.has(String(sb.eventid)) && !autoSet.has(String(sb.eventid));
    const noResult = /settlement/i.test(row.reason) && sb && !declaredSet.has(String(sb.eventid));
    const won = sb && String(sb.result_status || '').toLowerCase() === 'won';
    const lost = sb && ['loss', 'lost'].includes(String(sb.result_status || '').toLowerCase());
    const payoutMismatch = /settlement/i.test(row.reason) && sb && R.isFancyMarket(sb) && (won || lost) &&
      (won ? !(num(row.profit) > 0 && num(row.loss) === 0) : !(num(row.loss) < 0 && num(row.profit) === 0));
    events.push({
      kind: 'cl', sort: [tms(row.ts), 1, Number(row.id) || 0], ts: row.ts,
      id: row.id, reason: row.reason, category: row.category, bet_id: row.bet_id, description,
      amount: r2(row.amount), balance: num(row.closing),
      profitBook, manual, noResult, payoutMismatch,
      result: sb ? (sb.result_status || null) : (cb ? (cb.result_status || null) : null),
      gameTag: sb ? (sb.market_type || sb.game_type || null) : (cb ? cb.game_name : null),
      betType: sb ? (sb.bet_type || null) : (cb ? cb.type : null), settledResult,
      roundId: cb ? (cb.round_id != null ? String(cb.round_id) : null) : null,
      gameName: cb ? (cb.game_name || null) : null,
      selection: cb ? (cb.selection || null) : (sb ? (sb.selection_name || null) : null),
    });
  }
  // (C) live-casino (JS games) transactions — provider / game / session(round) info
  for (const t of jsTx) {
    const g = jsGameMap[t.game_uid] || {};
    const delta = L.txnDelta(t);
    events.push({
      kind: 'js', sort: [tms(t.ts), 2, Number(t.id) || 0], ts: t.ts,
      id: `js${t.id}`, reason: t.transaction_type || 'live', category: 'LIVE', live: true,
      description: `${g.game_name || t.game_uid || 'Live game'}${t.transaction_type ? ' · ' + t.transaction_type : ''}`,
      amount: r2(delta), delta, // direct wallet move — no recorded balance, computed forward
      provider: g.provider || null, gameName: g.game_name || t.game_uid || null,
      sessionId: t.external_transaction_id || null,
      result: L.isWin(t) ? 'won' : (L.isBet(t) ? 'bet' : null),
    });
  }
  events.sort((a, b) => a.sort[0] - b.sort[0] || a.sort[1] - b.sort[1] || a.sort[2] - b.sort[2]);

  // opening balance = the balance just before the first event (0 for a fresh account
  // whose first event is its funding deposit; else derive from the first tx).
  const opening = txRows.length ? num(txRows[0].previous_balance)
    : (rows.length ? r2(num(rows[0].closing) - num(rows[0].amount)) : num(wallet.cash_received));

  let prev = opening;
  const out = events.map((e) => {
    // ledger/tx rows carry an authoritative recorded balance; live-casino (JS) rows have
    // none (direct wallet move) → run the balance forward from the prior row.
    const running = (e.balance != null) ? num(e.balance) : r2(prev + num(e.delta || 0));
    const walletDelta = r2(running - prev);
    prev = running;
    return {
      id: e.id, ts: e.ts, reason: e.reason, category: e.category, bet_id: e.bet_id ?? null,
      description: e.description, amount: e.amount, walletDelta, closing: r2(running),
      cash: e.cash || false, live: e.live || false, profitBook: e.profitBook || false, manual: e.manual || false,
      noResult: e.noResult || false, payoutMismatch: e.payoutMismatch || false,
      result: e.result || null, gameTag: e.gameTag || null, betType: e.betType || null,
      settledResult: e.settledResult || null, tallyBreak: running < -0.01,
      provider: e.provider || null, gameName: e.gameName || null,
      roundId: e.roundId || null, sessionId: e.sessionId || null, selection: e.selection || null,
    };
  });

  const openingRow = {
    id: 'opening', ts: events.length ? events[0].ts : null, reason: 'opening_balance', category: 'WALLET',
    bet_id: null, description: 'Account created — opening balance', cash: true,
    amount: r2(opening), walletDelta: null, closing: r2(opening), opening: true,
  };
  return [openingRow, ...out];
}

/* ============================ AGENT (staff/owner) ============================ */
/* ==================== AGENT / OWNER (staff, Owners) — hierarchy report ==========
 * Was a stub that ran one wallet check and then declared "betting checks are not
 * applicable" — which left every staff and owner account, i.e. every node that
 * actually holds the hierarchy together, unverified.
 *
 * An agent does not place bets, so per-bet settlement rules genuinely don't apply.
 * But the invariants that DO apply to a hierarchy node were never checked:
 * point-ledger truth, the upper/down mirror against its own children, and whether
 * its downline's books agree with its own.  (docs/ledgerpoint.md §3, §6, §7)
 */
async function buildAgentReport(sequelize, acct, kind, idCol) {
  const id = String(acct.id);
  const wRows = await q(sequelize,
    `SELECT wallet_id, inr_balance, cash, cash_received, profit_loss, "totalCommission",
            all_point, credit, upper_point, down_point
       FROM "Wallets" WHERE ${idCol}=:id LIMIT 1`, { id }).catch(() => []);
  const w = wRows[0] || {};
  const walletId = w.wallet_id;
  const inr = num(w.inr_balance), cash = num(w.cash);

  const snapshot = {
    kind, user_id: id, username: acct.username, role: acct.role,
    total_balance: r2(inr), available_balance: r2(cash), locked_exposure: r2(inr - cash),
    profit_loss: r2(num(w.inr_balance) - num(w.cash_received)), net_exposure: 0, net_win: 0, net_loss: 0,
    cash_received: r2(w.cash_received), all_point: r2(w.all_point), credit: r2(w.credit),
    upper_point: r2(w.upper_point), down_point: r2(w.down_point),
  };

  const categories = [];

  /* ---- 1. WALLET INTEGRITY ---- */
  const walletRules = [];
  if (wRows.length) {
    // profit_loss is derived on read now, so there is nothing left to compare it against.
    // The wallet's own money conservation is what matters for an agent node.
    walletRules.push(chk('Available funds do not exceed the total balance', inr, cash, { info: true }));
  } else {
    walletRules.push({ label: 'A wallet record exists for this account', expected: 1, actual: 0, diff: -1,
      pass: false, info: false, severity: 'high' });
  }
  categories.push({ key: 'wallet', label: 'Wallet Integrity', icon: 'wallet', rules: walletRules, pass: catVerdict(walletRules) });

  /* ---- 2. POINT LEDGER — the ledger is truth, all_point is only a cache ---- */
  const ledgerRules = [];
  if (walletId != null) {
    const led = (await q(sequelize,
      `SELECT COALESCE(SUM(delta),0) AS s, COUNT(*) AS n FROM point_ledger WHERE wallet_id = :wid`,
      { wid: walletId }).catch(() => []))[0] || {};
    ledgerRules.push(chk('all_point equals the sum of its ledger entries', num(led.s), num(w.all_point),
      { note: `${num(led.n)} ledger entr${num(led.n) === 1 ? 'y' : 'ies'}` }));

    const byType = await q(sequelize,
      `SELECT event_type, COUNT(*) AS n, COALESCE(SUM(delta),0) AS s
         FROM point_ledger WHERE wallet_id = :wid GROUP BY event_type ORDER BY 3 DESC`,
      { wid: walletId }).catch(() => []);
    if (byType.length) {
      ledgerRules.push({
        label: 'Where this account\'s points came from', expected: r2(w.all_point), actual: r2(w.all_point),
        diff: 0, pass: true, info: true, severity: 'review',
        subs: byType.map((t) => ({ label: t.event_type, expected: r2(t.s), actual: r2(t.s), diff: 0,
          pass: true, info: true, note: `${t.n} entr${Number(t.n) === 1 ? 'y' : 'ies'}` })),
      });
    }
    // an override on a hierarchy node moves every downline's books with it
    const manual = (await q(sequelize,
      `SELECT COUNT(*) AS n, COALESCE(SUM(delta),0) AS s FROM point_ledger
        WHERE wallet_id = :wid AND event_type IN ('MANUAL_ADJUSTMENT','REVERSAL')`,
      { wid: walletId }).catch(() => []))[0] || {};
    if (num(manual.n) > 0) {
      ledgerRules.push({ label: 'Manual adjustments / reversals on this account',
        expected: 0, actual: num(manual.n), diff: num(manual.n), pass: true, info: true,
        severity: 'review', note: `net ${r2(manual.s)} across ${num(manual.n)} entr${num(manual.n) === 1 ? 'y' : 'ies'}` });
    }
  }
  categories.push({ key: 'ledger', label: 'Point Ledger', icon: 'ledger', rules: ledgerRules, pass: catVerdict(ledgerRules) });

  /* ---- 3. HIERARCHY — this node vs the children hanging off it ---- */
  const hierRules = [];
  const staffId = kind === 'staff' ? id : null;
  const ownerId = kind === 'owner' ? id : null;

  const kids = await q(sequelize,
    `SELECT 'staff' AS kind, CAST(s.staff_id AS TEXT) AS id, s.username, CAST(s.role AS TEXT) AS role,
            COALESCE(w.upper_point,0) AS upper_point, COALESCE(w.inr_balance,0) AS inr_balance,
            COALESCE(w.all_point,0) AS all_point
       FROM staff s LEFT JOIN "Wallets" w ON w.staff_id = s.staff_id
      WHERE s."deletedAt" IS NULL
        AND ( (:staffId IS NOT NULL AND s.parent_id = CAST(:staffId AS INTEGER))
           OR (:ownerId IS NOT NULL AND s.parent_id IS NULL AND s.parent_owner_id = CAST(:ownerId AS INTEGER)) )
     UNION ALL
     SELECT 'user', CAST(u.user_id AS TEXT), u.username, CAST(u.role AS TEXT),
            COALESCE(w.upper_point,0), COALESCE(w.inr_balance,0), COALESCE(w.all_point,0)
       FROM users u LEFT JOIN "Wallets" w ON w.user_id = u.user_id
      WHERE ( (:staffId IS NOT NULL AND u.parent_staff_id = CAST(:staffId AS INTEGER))
           OR (:ownerId IS NOT NULL AND u.parent_staff_id IS NULL AND u.parent_owner_id = CAST(:ownerId AS INTEGER)) )`,
    { staffId, ownerId }).catch(() => []);

  const childUpper = kids.reduce((t, k) => t + num(k.upper_point), 0);
  hierRules.push(chk('down_point mirrors the sum of its children\'s upper_point', -childUpper, num(w.down_point),
    { note: `${kids.length} direct child account${kids.length === 1 ? '' : 's'}` }));

  if (kids.length) {
    hierRules.push({
      label: 'Direct downline', expected: kids.length, actual: kids.length, diff: 0,
      pass: true, info: true, severity: 'review',
      subs: kids.slice(0, 50).map((k) => ({
        label: `${k.username} (${k.role})`, expected: r2(k.inr_balance), actual: r2(k.inr_balance),
        diff: 0, pass: true, info: true, note: `upper ${r2(k.upper_point)} · points ${r2(k.all_point)}`,
      })),
    });
  }

  // the chain above this node — a break here strands every settlement below it
  if (kind === 'staff') {
    const chain = await q(sequelize,
      `WITH RECURSIVE up AS (
         SELECT s.staff_id, s.username, CAST(s.role AS TEXT) AS role, s.parent_id, s.parent_owner_id, 1 AS depth
           FROM staff s WHERE s.staff_id = CAST(:id AS INTEGER)
         UNION ALL
         SELECT p.staff_id, p.username, CAST(p.role AS TEXT), p.parent_id, p.parent_owner_id, up.depth + 1
           FROM up JOIN staff p ON p.staff_id = up.parent_id AND p."deletedAt" IS NULL
          WHERE up.depth < 12 )
       SELECT * FROM up ORDER BY depth`, { id }).catch(() => []);
    const top = chain[chain.length - 1];
    hierRules.push({
      label: 'Upline chain reaches an owner',
      expected: 1, actual: top && top.parent_owner_id ? 1 : 0,
      diff: top && top.parent_owner_id ? 0 : -1,
      pass: Boolean(top && top.parent_owner_id), info: false, severity: 'high',
      note: (chain.length > 1
              ? chain.map((c) => c.username).join(' → ')
              : `${acct.username} (hangs directly off the owner)`) || 'chain could not be walked',
    });
  }
  categories.push({ key: 'hierarchy', label: 'Hierarchy', icon: 'hierarchy', rules: hierRules, pass: catVerdict(hierRules) });

  /* ---- 4. not applicable, stated once ---- */
  const naRules = [{
    label: `${kind === 'owner' ? 'Owner' : 'Agent'} account — per-bet settlement checks do not apply (this account does not place bets)`,
    expected: 0, actual: 0, diff: 0, pass: true, info: true, severity: 'review',
  }];
  categories.push({ key: 'betting', label: 'Betting', icon: 'betting', rules: naRules, pass: true });

  const history = await buildHistory(sequelize, id, [], new Set(), {}, new Set(), new Set(), w, {}, acct.username);
  return { found: true, kind, snapshot, categories, history, historyCount: history.length,
           allPass: categories.every((c) => c.pass) };
}

export default { searchUsers, buildUserReport };
