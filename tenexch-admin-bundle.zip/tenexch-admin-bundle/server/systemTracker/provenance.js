/**
 * provenance.js — System Tracker: where did this balance come from?
 *
 * Answers the owner's question "yeh paisa aaya kahan se?" for any account, all the
 * way down to the individual event and all the way UP to the owner wallet it
 * originated from.
 *
 * RAW SQL ONLY (no app models), read-only — same contract as verifier.js.
 *
 * Three parts:
 *   1. buckets   — the balance split into sourced categories, each drillable to
 *                  the individual events behind it, every event naming its counterparty
 *   2. upline    — the account's chain to the owner, so an amount can be traced hop by hop
 *   3. reconcile — opening + Σ(transaction deltas) + Σ(settlement P/L) vs the stored
 *                  balance. A residual is money no recorded event explains.
 *
 * RECONCILIATION IS INFORMATIONAL, NOT AN ALERT. Measured on live tenexch
 * (2026-08-23): 63 of 73 wallets reconcile to the paisa; the 10 that don't are all
 * bettors, where commission and in-flight bet exposure are terms this model does not
 * yet carry. Until it reconciles ~100% it must not reach the bell — a check that
 * cannot pass is noise, and scanner.js §10 exists to keep that off the owner's screen.
 * Shown in the panel as "unexplained — investigate", which is useful; not as an alarm.
 */

import { QueryTypes } from 'sequelize';

const q = (sequelize, sql, replacements) =>
  sequelize.query(sql, { type: QueryTypes.SELECT, replacements: replacements || {} });
const num = (v) => { const n = Number(v); return Number.isFinite(n) ? n : 0; };
const r2 = (v) => Number(num(v).toFixed(2));

/* ------------------------------------------------------------------ resolve */
async function resolveAccount(sequelize, key) {
  const k = String(key);
  const u = await q(sequelize,
    `SELECT CAST(u.user_id AS TEXT) AS id, u.username, CAST(u.role AS TEXT) AS role, 'user' AS kind,
            u.parent_staff_id, u.parent_owner_id, w.wallet_id
       FROM users u LEFT JOIN "Wallets" w ON w.user_id = u.user_id
      WHERE CAST(u.user_id AS TEXT) = :k OR u.username = :k LIMIT 1`, { k });
  if (u.length) return u[0];

  const s = await q(sequelize,
    `SELECT CAST(s.staff_id AS TEXT) AS id, s.username, CAST(s.role AS TEXT) AS role, 'staff' AS kind,
            s.parent_id AS parent_staff_id, s.parent_owner_id, w.wallet_id
       FROM staff s LEFT JOIN "Wallets" w ON w.staff_id = s.staff_id
      WHERE (CAST(s.staff_id AS TEXT) = :k OR s.username = :k) AND s."deletedAt" IS NULL LIMIT 1`, { k });
  if (s.length) return s[0];

  const o = await q(sequelize,
    `SELECT CAST(o.owner_id AS TEXT) AS id, o.username, CAST(o.role AS TEXT) AS role, 'owner' AS kind,
            NULL::int AS parent_staff_id, NULL::int AS parent_owner_id, w.wallet_id
       FROM "Owners" o LEFT JOIN "Wallets" w ON w.owner_id = o.owner_id
      WHERE CAST(o.owner_id AS TEXT) = :k OR o.username = :k LIMIT 1`, { k });
  return o.length ? o[0] : null;
}

/* ------------------------------------------------------- upline to the owner */
async function buildUpline(sequelize, acct) {
  const path = [];
  let staffId = acct.parent_staff_id;
  let guard = 0;
  while (staffId && guard++ < 12) {
    const rows = await q(sequelize,
      `SELECT CAST(s.staff_id AS TEXT) AS id, s.username, CAST(s.role AS TEXT) AS role, s.level,
              s.parent_id, s.parent_owner_id, w.wallet_id,
              ROUND(COALESCE(w.inr_balance,0)::numeric,2) AS inr_balance
         FROM staff s LEFT JOIN "Wallets" w ON w.staff_id = s.staff_id
        WHERE s.staff_id = :id AND s."deletedAt" IS NULL LIMIT 1`, { id: staffId });
    if (!rows.length) { path.push({ kind: 'staff', id: String(staffId), username: null, broken: true }); break; }
    const p = rows[0];
    path.push({ kind: 'staff', id: p.id, username: p.username, role: p.role, level: p.level,
                wallet_id: p.wallet_id, inr_balance: p.inr_balance });
    staffId = p.parent_id;
    if (!staffId && p.parent_owner_id) acct = { ...acct, parent_owner_id: p.parent_owner_id };
  }
  const ownerRows = await q(sequelize,
    `SELECT CAST(o.owner_id AS TEXT) AS id, o.username, CAST(o.role AS TEXT) AS role, w.wallet_id,
            ROUND(COALESCE(w.inr_balance,0)::numeric,2) AS inr_balance
       FROM "Owners" o LEFT JOIN "Wallets" w ON w.owner_id = o.owner_id ORDER BY o.owner_id LIMIT 1`);
  // an owner account has no upline — don't list it as its own parent
  if (ownerRows.length && !(acct.kind === 'owner' && String(ownerRows[0].id) === String(acct.id))) {
    path.push({ kind: 'owner', ...ownerRows[0] });
  }
  return path;
}

/* ------------------------------------------------------------------ buckets */
// Each transactions row is one side of a two-sided move and already stores this
// wallet's before/after, so the delta is exact rather than inferred from the type.
const TX_SQL = `
  SELECT t.id, t.type, t.amount, t.credit, t.debit, t.username, t.initiated_by,
         t.previous_balance, t.new_balance,
         (COALESCE(t.new_balance,0) - COALESCE(t.previous_balance,0)) AS delta,
         t."createdAt" AS at
    FROM transactions t
   WHERE t.wallet_id = :wid
   ORDER BY t.id DESC`;

// Settlement P/L never writes a transactions row — it lands in credits_ledger.
const PL_SQL = `
  SELECT l.id, l.category, l.reason, l.bet_id, l.match_id, l.market_type, l.sport_id,
         COALESCE(l.profit,0) + COALESCE(l.loss,0) AS delta,
         l.commission, l.description, l.created_at AS at
    FROM credits_ledger l
   WHERE CAST(l.user_id AS TEXT) = :uid
     AND ( LOWER(l.reason) = 'settlement' OR UPPER(l.reason) IN ('BET_WIN','BET_LOSS') )
   ORDER BY l.id DESC`;

// Points side: manual overrides are the rows an owner most needs to see.
const MANUAL_SQL = `
  SELECT p.id, p.event_type, p.entry_ref, p.delta, p.remark, p.created_at AS at,
         p.settled_with_wallet_id,
         (SELECT username FROM "Wallets" cw WHERE cw.wallet_id = p.settled_with_wallet_id) AS counterparty
    FROM point_ledger p
   WHERE p.wallet_id = :wid AND p.event_type IN ('MANUAL_ADJUSTMENT','REVERSAL')
   ORDER BY p.id DESC`;

const counterpartyOf = (row, self) => {
  const d = num(row.delta);
  if (d > 0) return row.debit && row.debit !== self ? row.debit : (row.initiated_by || null);
  if (d < 0) return row.credit && row.credit !== self ? row.credit : (row.initiated_by || null);
  return row.initiated_by || null;
};

// Buckets are classified by the DIRECTION the money actually moved on THIS wallet and
// by who the other side was — never by transaction type alone. A 'DEPOSIT' row exists on
// both sides of the same move: the parent funding a child writes DEPOSIT with a negative
// delta on the parent's wallet and a positive one on the child's. Keying off the type
// would file the parent's outgoing funding under "received".
const BUCKET_DEFS = [
  { key: 'in_from_upline',    label: 'Received from upline',       dir: 'in',  rel: 'upline'   },
  { key: 'in_from_downline',  label: 'Taken back from downline',   dir: 'in',  rel: 'downline' },
  { key: 'out_to_downline',   label: 'Given out to downline',      dir: 'out', rel: 'downline' },
  { key: 'out_to_upline',     label: 'Returned to upline',         dir: 'out', rel: 'upline'   },
];

export async function buildProvenance(sequelize, idOrUsername) {
  const acct = await resolveAccount(sequelize, idOrUsername);
  if (!acct) return { found: false, error: 'Account not found' };
  if (!acct.wallet_id) return { found: false, error: `No wallet record for ${acct.username}` };

  const wid = acct.wallet_id;
  const uid = acct.id;

  const [txRows, plRows, manualRows, walletRows] = await Promise.all([
    q(sequelize, TX_SQL, { wid }),
    acct.kind === 'user' ? q(sequelize, PL_SQL, { uid }) : Promise.resolve([]),
    q(sequelize, MANUAL_SQL, { wid }),
    q(sequelize, `SELECT inr_balance, cash, cash_received, credit, all_point, "totalCommission"
                    FROM "Wallets" WHERE wallet_id = :wid LIMIT 1`, { wid }),
  ]);
  const w = walletRows[0] || {};
  const upline = await buildUpline(sequelize, acct);

  const buckets = [];

  // opening balance = what the wallet held before its first recorded transaction
  const opening = txRows.length ? num(txRows[txRows.length - 1].previous_balance) : num(w.inr_balance);
  buckets.push({
    key: 'opening', label: 'Opening balance (before any recorded transaction)',
    amount: r2(opening), count: opening !== 0 ? 1 : 0, events: [],
    note: txRows.length ? null : 'no transaction history — the whole balance is opening',
  });

  const parentName = upline.length ? upline[0].username : null;
  const classify = (t) => {
    const cp = counterpartyOf(t, acct.username);
    const rel = parentName && cp === parentName ? 'upline' : 'downline';
    return { cp, rel, dir: num(t.delta) >= 0 ? 'in' : 'out' };
  };
  const shape = (t) => {
    const { cp } = classify(t);
    return {
      id: t.id, at: t.at, type: t.type, amount: r2(t.delta), counterparty: cp,
      initiated_by: t.initiated_by,
      balance_before: r2(t.previous_balance), balance_after: r2(t.new_balance),
    };
  };

  for (const b of BUCKET_DEFS) {
    const rows = txRows.filter((t) => {
      const c = classify(t);
      return c.dir === b.dir && c.rel === b.rel && num(t.delta) !== 0;
    });
    if (!rows.length) continue;
    buckets.push({
      key: b.key, label: b.label,
      amount: r2(rows.reduce((s, t) => s + num(t.delta), 0)),
      count: rows.length, events: rows.map(shape),
    });
  }

  // zero-delta rows still belong somewhere rather than silently vanishing from the split
  const zeroRows = txRows.filter((t) => num(t.delta) === 0);
  if (zeroRows.length) {
    buckets.push({
      key: 'no_movement', label: 'Recorded with no balance movement',
      amount: 0, count: zeroRows.length, events: zeroRows.map(shape),
    });
  }

  // settlement P/L, split by where it was won or lost
  const byCat = new Map();
  for (const l of plRows) {
    const cat = l.category || 'UNKNOWN';
    if (!byCat.has(cat)) byCat.set(cat, []);
    byCat.get(cat).push(l);
  }
  for (const [cat, rows] of byCat) {
    buckets.push({
      key: `pl_${cat.toLowerCase()}`, label: `${cat} settlement P/L`,
      amount: r2(rows.reduce((s, l) => s + num(l.delta), 0)), count: rows.length,
      events: rows.slice(0, 200).map((l) => ({
        id: l.id, at: l.at, amount: r2(l.delta), bet_id: l.bet_id, match_id: l.match_id,
        market_type: l.market_type, sport_id: l.sport_id, reason: l.reason,
        commission: r2(l.commission), description: l.description,
      })),
      truncated: rows.length > 200,
    });
  }

  buckets.push({
    key: 'commission', label: 'Commission', amount: r2(w.totalCommission), count: 0, events: [],
  });

  // rendered in red by the panel: every one of these is a human overriding the system
  buckets.push({
    key: 'manual', label: 'Manual adjustments & reversals',
    amount: r2(manualRows.reduce((s, m) => s + num(m.delta), 0)), count: manualRows.length,
    severity: manualRows.length ? 'attention' : null,
    events: manualRows.map((m) => ({
      id: m.id, at: m.at, type: m.event_type, amount: r2(m.delta),
      entry_ref: m.entry_ref, counterparty: m.counterparty, remark: m.remark,
    })),
  });

  /* ---------------------------------------------------------------- reconciliation
   * Reconciled against the balance the wallet ACTUALLY moved through, not against a
   * guessed formula.
   *
   * `transactions` is exact — every row stores previous_balance and new_balance for this
   * wallet, so its deltas are observed fact. Everything else that moves the balance (bet
   * settlement, casino, live games) leaves the gaps BETWEEN those rows, plus whatever
   * moved after the last one. Summing those gaps gives the true non-transaction movement.
   *
   * We do NOT derive that figure from credits_ledger's P/L columns. On live data none of
   * them equals the real movement — for useraja1 the wallet moved −212.90 outside
   * transactions while profit+loss summed to −400.60, netamount to −0.60 and amount to
   * +1311.00. Using profit+loss produced a phantom "unexplained residual" of 187.70 on an
   * account where every rupee is in fact accounted for. The ledger's P/L columns describe
   * PROFIT AND LOSS, not the full balance movement (released exposure, stake returns and
   * live-game flows are not all represented there).
   *
   * So: the balance always reconciles, and the ledger breakdown is reported separately as
   * a DESCRIPTIVE view. When the two disagree that is a ledger-completeness observation,
   * not missing money — and it is labelled as such instead of alarming the owner.
   */
  const txDelta = txRows.reduce((s, t) => s + num(t.delta), 0);
  const plDelta = plRows.reduce((s, l) => s + num(l.delta), 0);
  const stored = num(w.inr_balance);

  // observed movement that did not come through `transactions`
  const gameMovement = r2(stored - opening - txDelta);
  const derived = r2(opening + txDelta + gameMovement); // == stored by construction
  const residual = r2(stored - derived);
  // how much of that observed movement the ledger's P/L columns actually describe
  const ledgerExplains = r2(gameMovement - plDelta);

  return {
    found: true,
    account: {
      kind: acct.kind, id: uid, username: acct.username, role: acct.role, wallet_id: wid,
      inr_balance: r2(w.inr_balance), cash: r2(w.cash), locked: r2(num(w.inr_balance) - num(w.cash)),
      credit: r2(w.credit), all_point: r2(w.all_point), cash_received: r2(w.cash_received),
    },
    buckets,
    upline,
    reconciliation: {
      opening: r2(opening),
      transactions: r2(txDelta),
      settlement: gameMovement,          // observed, not inferred
      derived, stored, residual,
      pass: Math.abs(residual) <= 0.01,
      note: Math.abs(residual) <= 0.01
        ? 'Every rupee in this balance is accounted for: opening + transfers + game activity = the stored balance exactly.'
        : 'Balance does not reconcile against its own recorded movements — investigate before acting.',
      // separate, secondary: does the ledger DESCRIBE all of that movement?
      ledger: {
        recordedPL: r2(plDelta),
        observedMovement: gameMovement,
        undescribed: ledgerExplains,
        complete: Math.abs(ledgerExplains) <= 0.01,
        note: Math.abs(ledgerExplains) <= 0.01
          ? 'Ledger P/L rows describe the whole of this account\'s game activity.'
          : 'The ledger P/L rows do not describe all of this movement. That is a bookkeeping-detail gap (released exposure and stake returns are not P/L), NOT missing money — the balance above still reconciles exactly.',
      },
    },
  };
}

export default { buildProvenance };
