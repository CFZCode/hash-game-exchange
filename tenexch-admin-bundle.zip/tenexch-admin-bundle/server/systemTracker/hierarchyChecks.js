/**
 * hierarchyChecks.js — System Tracker Tier-1 hierarchy & point-ledger checks.
 *
 * Same contract as the checks in scanner.js: each entry is ONE aggregate SQL that
 * returns only the offending accounts across the whole tree, shaped as
 * { user_id, username, role, detail }. scanner.js concats these onto CHECKS[].
 *
 * These cover the invariants that docs/ledgerpoint.md locks but nothing enforced:
 * the point ledger is the source of truth for all_point, a settlement must reach
 * every wallet in the bettor's upline, and upper/down points always mirror.
 *
 * CALIBRATION (read-only run against live tenexch, 2026-08-23) — per the Tier-1
 * rule in scanner.js §10 only calibration-clean checks belong on the bell:
 *   pointLedgerDrift 0 · chainCoverage 0 · orphanParent 0 · cyclicParent 0
 *   walletCardinality 0 · settleMirror 1 (real) · cashSettleCounterparty 2 (real)
 *   orphanWallet 1 (real, zero-balance) · voidNotRefunded 2 (real, market-aware)
 *
 * DELIBERATELY NOT HERE — `Wallets.credit` vs the account's 'User creation' ledger
 * entries. docs/ledgerpoint.md §3 says credit never changes, but the code plainly
 * does change it on later top-ups: the check returns 28 hits on clean live data.
 * A check that noisy makes the bell worthless, so it lives in the per-user verifier
 * as informational instead.
 */

// Every wallet with its account identity and the wallet_id of its DIRECT parent.
// acct_key namespaces staff/owner so a staff_id can't collide with a user_id on
// integrity_alerts' UNIQUE(user_id, check_key). Bettors keep their raw user_id so
// rows written by the pre-existing checks stay compatible.
const ACCOUNTS = `
  SELECT w.wallet_id, w.username, w.user_type,
         w.all_point, w.credit, w.upper_point, w.down_point, w.inr_balance, w.cash,
         CASE WHEN w.user_id  IS NOT NULL THEN CAST(w.user_id AS TEXT)
              WHEN w.staff_id IS NOT NULL THEN 'staff:' || w.staff_id
              ELSE 'owner:' || w.owner_id END AS acct_key,
         COALESCE(u.role, s.role, 'OWNER') AS role,
         CASE
           WHEN w.user_id IS NOT NULL THEN COALESCE(
             (SELECT pw.wallet_id FROM "Wallets" pw WHERE pw.staff_id = u.parent_staff_id LIMIT 1),
             (SELECT pw.wallet_id FROM "Wallets" pw WHERE pw.owner_id = u.parent_owner_id LIMIT 1))
           WHEN w.staff_id IS NOT NULL THEN COALESCE(
             (SELECT pw.wallet_id FROM "Wallets" pw WHERE pw.staff_id = s.parent_id LIMIT 1),
             (SELECT pw.wallet_id FROM "Wallets" pw WHERE pw.owner_id = s.parent_owner_id LIMIT 1))
           ELSE NULL END AS parent_wallet_id
  FROM "Wallets" w
  LEFT JOIN users u ON u.user_id  = w.user_id
  LEFT JOIN staff s ON s.staff_id = w.staff_id AND s."deletedAt" IS NULL
  -- Demo accounts (server/demo/README.md) are outside the money tree: their
  -- opening credit is never debited from the demo owner, by design.
  WHERE NOT EXISTS (SELECT 1 FROM users du WHERE du.user_id = w.user_id AND du.is_demo = true)
`;

// Fancy discriminator for "SportsBet". NOTE: SportsBet.game_type holds FAN/BM/MO — the
// ('Normal','khado',...) list that scanner.js names FANCY_GT matches SportsBet.market_type
// and user_exposures.game_type, NOT SportsBet.game_type. Verified on live data:
// game_type='FAN' covers all 388 fancy bets and BM/MO never appear in that list, so the
// inherited `b.game_type NOT IN (...)` test is always true and its fancy branch is dead.
// See the Findings section of docs/plans/2026-08-23-system-tracker-owner.md.
const SB_FANCY     = `b.game_type = 'FAN'`;
const SB_NOT_FANCY = `COALESCE(b.game_type,'') <> 'FAN'`;

export const HIERARCHY_CHECKS = [
  {
    // docs/ledgerpoint.md §7 — the nightly reconcile cron this repo never got.
    // The ledger is append-only truth; all_point is a cache. A gap means either a
    // settlement that skipped the ledger, or a hand-edited counter.
    key: 'pointLedgerDrift', severity: 'critical',
    label: 'Wallet all_point = SUM(point_ledger deltas)',
    sql: `
      SELECT a.acct_key AS user_id, a.username, a.role,
        'all_point ' || ROUND(COALESCE(a.all_point,0)::numeric,2)
        || ' ≠ ledger SUM ' || ROUND(COALESCE(l.s,0)::numeric,2)
        || ' — drift ' || ROUND((COALESCE(a.all_point,0)-COALESCE(l.s,0))::numeric,2) AS detail
      FROM (${ACCOUNTS}) a
      LEFT JOIN (SELECT wallet_id, SUM(delta) AS s FROM point_ledger GROUP BY wallet_id) l
             ON l.wallet_id = a.wallet_id
      WHERE ABS(COALESCE(a.all_point,0) - COALESCE(l.s,0)) > 0.01`,
  },
  {
    // docs/ledgerpoint.md §6 — one BET_SETTLEMENT entry per wallet in the bettor's
    // full upline. A chain 5 deep that only wrote 3 entries means two uplines
    // silently missed the delta: their books drift from the user's from then on.
    key: 'chainCoverage', severity: 'critical',
    label: 'Settlement reaches every wallet in the upline chain',
    sql: `
      WITH RECURSIVE chain AS (
        SELECT u.user_id, u.parent_staff_id AS cur_staff, 1 AS depth
          FROM (SELECT * FROM users WHERE COALESCE(is_demo,false) = false) u
        UNION ALL
        SELECT c.user_id, s.parent_id, c.depth + 1
          FROM chain c JOIN staff s ON s.staff_id = c.cur_staff
         WHERE c.cur_staff IS NOT NULL AND c.depth < 12
      ),
      expected AS (SELECT user_id, MAX(depth) + 1 AS n FROM chain GROUP BY user_id),
      actual AS (
        SELECT source_user_id AS user_id, entry_ref, COUNT(DISTINCT wallet_id) AS n
          FROM point_ledger
         WHERE event_type = 'BET_SETTLEMENT' AND source_user_id IS NOT NULL
         GROUP BY source_user_id, entry_ref
      )
      SELECT CAST(a.user_id AS TEXT) AS user_id, u.username, CAST(u.role AS TEXT) AS role,
        COUNT(*) || ' settlement(s) wrote ' || a.n
        || ' ledger entr(ies) but the upline chain needs ' || e.n AS detail
      FROM actual a
      JOIN expected e ON e.user_id = a.user_id
      JOIN (SELECT * FROM users WHERE COALESCE(is_demo,false) = false) u    ON u.user_id = a.user_id
      WHERE a.n <> e.n
      GROUP BY a.user_id, u.username, u.role, a.n, e.n`,
  },
  {
    // docs/ledgerpoint.md §3 locks this: child upper_point and parent down_point are
    // mirrors, so every parent/child pair nets to 0. If it doesn't, one side of a
    // settlement was booked and the other wasn't.
    key: 'settleMirror', severity: 'high',
    label: 'Parent down_point mirrors the sum of its children upper_point',
    sql: `
      WITH a AS (${ACCOUNTS})
      SELECT p.acct_key AS user_id, p.username, p.role,
        'down_point ' || ROUND(COALESCE(p.down_point,0)::numeric,2)
        || ' ≠ −Σ(children upper_point) ' || ROUND(COALESCE(-SUM(c.upper_point),0)::numeric,2)
        || ' — drift ' || ROUND((COALESCE(p.down_point,0) - COALESCE(-SUM(c.upper_point),0))::numeric,2) AS detail
      FROM a p LEFT JOIN a c ON c.parent_wallet_id = p.wallet_id
      GROUP BY p.acct_key, p.username, p.role, p.down_point
      HAVING ABS(COALESCE(p.down_point,0) - COALESCE(-SUM(c.upper_point),0)) > 0.01`,
  },
  {
    // docs/ledgerpoint.md §3 "direct-child rule (locked)": a cash settlement always
    // names its counterparty, and that counterparty is always the DIRECT parent.
    // Without it the money cannot be traced to an upline at all.
    key: 'cashSettleCounterparty', severity: 'high',
    label: 'Cash settlements are traceable to their direct parent',
    sql: `
      WITH a AS (${ACCOUNTS})
      SELECT a.acct_key AS user_id, a.username, a.role,
        COUNT(*) || ' cash settlement(s) with '
        || CASE WHEN COUNT(*) FILTER (WHERE pl.settled_with_wallet_id IS NULL) = COUNT(*)
                THEN 'no counterparty recorded'
                ELSE 'a counterparty that is not the direct parent' END AS detail
      FROM point_ledger pl
      JOIN a ON a.wallet_id = pl.wallet_id
      WHERE pl.event_type IN ('Credit','Debit')
        AND ( pl.settled_with_wallet_id IS DISTINCT FROM a.parent_wallet_id )
        -- A blank settled_with_wallet_id is only a problem if the counterparty cannot be
        -- recovered at all. These entry_refs are 'deposit:<transaction_id>' /
        -- 'withdraw:<id>' / 'cashsettle:<id>', so the paired transactions row still names
        -- both sides. Where it does, the money IS traceable to an upline and there is
        -- nothing to raise — the field is merely blank, not the trail.
        --
        -- Measured: exactly 2 rows in the whole table lack the field, both written in a
        -- 72-minute window on 2026-07-29 (02:06:09 → 02:06:32) before the code began
        -- populating it. Every one of the 66 rows since has it. Both recover cleanly to
        -- wallet 37 (agentaja), the account's real direct parent.
        AND NOT (
          pl.settled_with_wallet_id IS NULL
          AND EXISTS (
            SELECT 1 FROM transactions t
              JOIN "Wallets" cw ON cw.username IN (t.debit, t.credit)
             WHERE split_part(pl.entry_ref, ':', 2) ~ '^[0-9]+$'
               AND t.id = CAST(split_part(pl.entry_ref, ':', 2) AS INTEGER)
               AND cw.wallet_id = a.parent_wallet_id
          )
        )
      GROUP BY a.acct_key, a.username, a.role`,
  },
  {
    // Structurally impossible: available can never exceed the total. It means the wallet
    // will let a player stake or withdraw money the balance does not back. Locked funds
    // are inr_balance − cash, so this is a NEGATIVE lock.
    //
    // Root cause is a cash/inr divergence in the settlement path — the two columns are
    // incremented by DIFFERENT figures (sportsVoidService header: cash += netamount,
    // inr_balance += profit+loss), so any asymmetry accumulates. Correcting a wallet is a
    // customer-facing decision, not something to automate: see the runbook at
    // docs/RUNBOOK-system-tracker.md before acting.
    key: 'cashExceedsBalance', severity: 'critical',
    label: 'Available funds never exceed the total balance',
    sql: `
      SELECT CAST(u.user_id AS TEXT) AS user_id, u.username, CAST(u.role AS TEXT) AS role,
        'available ' || ROUND(w.cash::numeric,2)
        || ' exceeds total ' || ROUND(w.inr_balance::numeric,2)
        || ' by ' || ROUND((w.cash - w.inr_balance)::numeric,2)
        || ' — spendable balance the total does not back' AS detail
      FROM "Wallets" w JOIN (SELECT * FROM users WHERE COALESCE(is_demo,false) = false) u ON u.user_id = w.user_id
      WHERE w.cash > w.inr_balance + 0.01`,
  },
  {
    // Tier-1 copy of the per-account "No bet is settled twice" rule. That rule lives in the
    // per-user verifier, so it is only seen when somebody opens that account — which is why
    // the 2026-08-19 duplicate-settlement incident surfaced four days late instead of in ten
    // minutes. On the bell it would have been caught the same hour.
    //
    // Excludes duplicates that have already been REVERSED: credits_ledger is history, not
    // state, so the original rows correctly stay after a correction. The corrections name
    // the bets they cover in their description ("... on bet(s) 947,952,978,979 ...").
    // See docs/INCIDENT-2026-08-19-duplicate-settlements.md.
    key: 'settlementDuplicate', severity: 'critical',
    label: 'No bet is settled more than once (no double payout)',
    sql: `
      WITH dup AS (
        SELECT l.bet_id, CAST(l.user_id AS TEXT) AS uid, COUNT(*) AS rows,
               SUM(COALESCE(l.profit,0)+COALESCE(l.loss,0)) AS total_pl,
               MIN(COALESCE(l.profit,0)+COALESCE(l.loss,0)) AS per_row_pl
          FROM credits_ledger l
         WHERE LOWER(l.reason) = 'settlement' AND l.category = 'SPORTS' AND l.bet_id IS NOT NULL
         GROUP BY l.bet_id, CAST(l.user_id AS TEXT)
        HAVING COUNT(*) > 1
      ),
      reversed AS (
        SELECT CAST(user_id AS TEXT) AS uid,
               TRIM(regexp_split_to_table(
                 COALESCE(substring(description from 'bet\\(s\\)[[:space:]]*([0-9,[:space:]]+)'), ''),
                 ',')) AS bet_id_text
          FROM credits_ledger
         WHERE LOWER(reason) IN ('correction','settlement_void')
      )
      SELECT d.uid AS user_id, u.username, CAST(u.role AS TEXT) AS role,
        COUNT(*) || ' bet(s) with duplicate settlement rows — '
        || ROUND(SUM(d.total_pl - d.per_row_pl)::numeric,2) || ' booked in error, not reversed' AS detail
      FROM dup d
      JOIN (SELECT * FROM users WHERE COALESCE(is_demo,false) = false) u ON CAST(u.user_id AS TEXT) = d.uid
      WHERE NOT EXISTS (
        SELECT 1 FROM reversed r
         WHERE r.uid = d.uid AND r.bet_id_text = CAST(d.bet_id AS TEXT)
      )
      GROUP BY d.uid, u.username, u.role`,
  },
  {
    key: 'orphanParent', severity: 'high',
    label: 'Every account hangs off a live parent',
    sql: `
      SELECT CAST(u.user_id AS TEXT) AS user_id, u.username, CAST(u.role AS TEXT) AS role,
             'parent_staff_id ' || u.parent_staff_id || ' does not resolve to a live staff account' AS detail
        FROM (SELECT * FROM users WHERE COALESCE(is_demo,false) = false) u
       WHERE u.parent_staff_id IS NOT NULL
         AND NOT EXISTS (SELECT 1 FROM staff s WHERE s.staff_id = u.parent_staff_id AND s."deletedAt" IS NULL)
      UNION ALL
      SELECT CAST(u.user_id AS TEXT), u.username, CAST(u.role AS TEXT),
             'account has no parent at all (no parent_staff_id, no parent_owner_id)'
        FROM (SELECT * FROM users WHERE COALESCE(is_demo,false) = false) u WHERE u.parent_staff_id IS NULL AND u.parent_owner_id IS NULL
      UNION ALL
      SELECT 'staff:' || s.staff_id, s.username, CAST(s.role AS TEXT),
             'parent_id ' || s.parent_id || ' does not resolve to a live staff account'
        FROM staff s
       WHERE s."deletedAt" IS NULL AND s.parent_id IS NOT NULL
         AND NOT EXISTS (SELECT 1 FROM staff p WHERE p.staff_id = s.parent_id AND p."deletedAt" IS NULL)
      UNION ALL
      SELECT 'staff:' || s.staff_id, s.username, CAST(s.role AS TEXT),
             'staff account has neither a parent staff nor a parent owner'
        FROM staff s WHERE s."deletedAt" IS NULL AND s.parent_id IS NULL AND s.parent_owner_id IS NULL`,
  },
  {
    // A cycle makes the upline walk in WalletService.updateAllPointHierarchy loop
    // (it has a guard, but a cycle still means settlements stop reaching the top).
    key: 'cyclicParent', severity: 'critical',
    label: 'No cycle in any parent chain',
    sql: `
      WITH RECURSIVE walk AS (
        SELECT s.staff_id AS root, s.parent_id AS cur, 1 AS depth,
               ARRAY[s.staff_id] AS seen, false AS cyc
          FROM staff s WHERE s."deletedAt" IS NULL
        UNION ALL
        SELECT w.root, p.parent_id, w.depth + 1, w.seen || p.staff_id, p.staff_id = ANY(w.seen)
          FROM walk w JOIN staff p ON p.staff_id = w.cur
         WHERE NOT w.cyc AND w.depth < 15
      )
      SELECT 'staff:' || w.root AS user_id, s.username, CAST(s.role AS TEXT) AS role,
             'parent chain loops back on itself' AS detail
        FROM (SELECT DISTINCT root FROM walk WHERE cyc) w
        JOIN staff s ON s.staff_id = w.root`,
  },
  {
    key: 'walletCardinality', severity: 'high',
    label: 'Exactly one wallet per live account',
    sql: `
      SELECT CAST(u.user_id AS TEXT) AS user_id, u.username, CAST(u.role AS TEXT) AS role,
             COUNT(w.wallet_id) || ' wallet rows for this account (expected 1)' AS detail
        FROM (SELECT * FROM users WHERE COALESCE(is_demo,false) = false) u LEFT JOIN "Wallets" w ON w.user_id = u.user_id
       GROUP BY u.user_id, u.username, u.role HAVING COUNT(w.wallet_id) <> 1
      UNION ALL
      SELECT 'staff:' || s.staff_id, s.username, CAST(s.role AS TEXT),
             COUNT(w.wallet_id) || ' wallet rows for this account (expected 1)'
        FROM staff s LEFT JOIN "Wallets" w ON w.staff_id = s.staff_id
       WHERE s."deletedAt" IS NULL
       GROUP BY s.staff_id, s.username, s.role HAVING COUNT(w.wallet_id) <> 1`,
  },
  {
    // Graded by exposure, not by existence: a leftover wallet holding nothing is
    // housekeeping, one still holding money is a live hole.
    key: 'orphanWallet', severity: 'high',
    label: 'No wallet outlives the account behind it',
    sql: `
      SELECT 'wallet:' || w.wallet_id AS user_id, w.username, CAST(w.user_type AS TEXT) AS role,
        'wallet has no account behind it — holds '
        || ROUND(COALESCE(w.inr_balance,0)::numeric,2) || ' inr / '
        || ROUND(COALESCE(w.all_point,0)::numeric,2) || ' points'
        || CASE WHEN ABS(COALESCE(w.inr_balance,0)) <= 0.01 AND ABS(COALESCE(w.all_point,0)) <= 0.01
                THEN ' (empty — cleanup only)' ELSE ' (STILL HOLDS VALUE)' END AS detail
      FROM "Wallets" w
      WHERE NOT EXISTS (SELECT 1 FROM users  u WHERE u.user_id  = w.user_id)
        AND NOT EXISTS (SELECT 1 FROM staff  s WHERE s.staff_id = w.staff_id)
        AND NOT EXISTS (SELECT 1 FROM "Owners" o WHERE o.owner_id = w.owner_id)`,
  },
  // ---------------------------------------------------------------------------
  // REMOVED — `voidNotRefunded` ("voided/refunded bets returned the stake").
  //
  // It is not assertable in this schema. A refund writes NO credits_ledger row at
  // all: measured on live data, 10 of 10 refunded bets have zero SPORTS ledger rows.
  // The stake goes straight back to the wallet, exactly like a casino void, leaving
  // no per-bet money trace to check against.
  //
  // The check originally looked like it worked because the bet_id lookup was not
  // filtered by category, so it matched CASINO ledger rows that happen to share the
  // bet_id number space — the same collision that made 5 already-refunded casino
  // bets look stuck. With `category='SPORTS'` applied the truth is that every refund
  // looks identical, so the rule can only ever return "all of them" or "none".
  //
  // The real gap is app-side and is logged as its own finding: REFUNDS ARE NOT
  // AUDITABLE. Until a refund writes a ledger row (or any per-bet trace), no check
  // here can prove a stake was returned. Do not re-add this rule without that.
  // ---------------------------------------------------------------------------
];

export default HIERARCHY_CHECKS;
