/**
 * watchdog.js — System Tracker settlement watchdog (market-scoped).
 *
 * scanner.js answers "is this ACCOUNT's money right?". This answers "is this MARKET
 * settling at all?" — open bets on a match that finished hours ago, a result that was
 * declared but never paid, a settlement job wedged in 'processing', casino bets stuck
 * mid-flight, exposure never released.
 *
 * Findings are market-scoped rather than user-scoped, so they get their own table
 * instead of being forced into integrity_alerts' UNIQUE(user_id, check_key).
 *
 * THIS MODULE NEVER MOVES MONEY. Each finding carries a suggested_action and the
 * action_endpoint that resolves it — every one of those endpoints already exists and is
 * already requireOwner + transaction-password gated (server/mannualSettle/routes.js).
 * Detection and recommendation here; the money stays in the existing manual-settle stack,
 * behind a human click. (Decision D1, docs/plans/2026-08-23-system-tracker-owner.md.)
 */

import { QueryTypes } from 'sequelize';
import sequelize from '../config/db.js';

const sel = (sql, r) => sequelize.query(sql, { type: QueryTypes.SELECT, replacements: r || {} });
const run = (sql, r) => sequelize.query(sql, { replacements: r || {} });

// How long after a match starts an open bet is considered stale. The ask was "match
// not active for 2-3 hours"; 3h is the default and it is env-tunable per site because
// a test match and a 20-over game age very differently.
export const STALE_HOURS      = Number(process.env.WATCHDOG_STALE_HOURS)      || 3;
export const JOB_STUCK_MIN    = Number(process.env.WATCHDOG_JOB_STUCK_MIN)    || 30;
export const CASINO_STUCK_MIN = Number(process.env.WATCHDOG_CASINO_STUCK_MIN) || 60;
export const FEED_SILENT_MIN  = Number(process.env.WATCHDOG_FEED_SILENT_MIN)  || 30;
// How long the results cron must have STOPPED looking at an event before its open
// bets count as abandoned rather than simply in-progress. See STALE_REASON below.
export const POLL_SILENT_MIN  = Number(process.env.WATCHDOG_POLL_SILENT_MIN)  || 30;
// How long past match start the results cron may keep polling an event WITHOUT ever
// getting a declared result before that counts as broken rather than in-progress.
// POLL_WENT_SILENT below treats "cron still polling" as healthy — true right up until
// the cron is polling something it can never resolve: a sid the feed rejects, a market
// the feed does not carry, a gmid mismatch. Those poll happily forever, so every stale
// check stayed silent while the money sat locked. (Table tennis bets sat open 17h in
// exactly this hole: sport_id 8 was missing from the results cron's sid whitelist, so
// every poll 404'd, `declared` never flipped, and neither staleOpenMarket nor
// staleFancy could fire because the cron had not gone quiet.)
// Set well past STALE_HOURS on purpose: a Test match's MATCH_ODDS legitimately stays
// open for days, and this must not cry wolf on every long format.
export const NEVER_DECLARED_HOURS = Number(process.env.WATCHDOG_NEVER_DECLARED_HOURS) || 12;
// Grace period between a result being declared and settlement being expected to have
// applied it. The settlement worker runs on its own tick, so a freshly-declared result
// is NORMAL for a short window — without this the board flashes a critical alert on
// every routine settlement and the owner learns to ignore it. Once an event is declared
// the results cron stops polling it, so that row's checked_at freezes at ≈ declaration
// time and is a fair clock to measure from.
export const SETTLE_GRACE_MIN = Number(process.env.WATCHDOG_SETTLE_GRACE_MIN) || 15;

// See hierarchyChecks.js — fancy on "SportsBet" is game_type='FAN'. The
// ('Normal','khado',...) list matches market_type on this table, never game_type.
const SB_FANCY     = `b.game_type = 'FAN'`;
const SB_NOT_FANCY = `COALESCE(b.game_type,'') <> 'FAN'`;
const OPEN_BET = `LOWER(status) NOT IN ('closed','void','cancelled')`;

// The feed sends stime as an IST wall clock with no zone marker, and the bet-save
// path stores it straight into a timestamptz — so Postgres reads those digits in
// THIS process's local zone and the stored instant runs (IST - server offset) late:
// 3h30m while the server is on CEST, 4h30m on CET. Every staleness window below is
// real instant math, so without correcting it the alerts opened hours late and the
// error moved on each DST change. Reinterpret the stored wall clock as IST to get
// the true kickoff instant.
// See docs/plans/2026-09-06-market-analysis-date-and-pagination.md.
const SERVER_TZ = Intl.DateTimeFormat().resolvedOptions().timeZone;
export const FEED_TZ = process.env.FEED_TIMEZONE || 'Asia/Kolkata';
const MATCH_START = `((b.match_start_time AT TIME ZONE :serverTz) AT TIME ZONE :feedTz)`;

// A casino bet is only genuinely stuck if the worker never reached a verdict.
// A TERMINAL result_status (void/won/lost) means the bet IS finished and already
// paid — even when `status` still says 'processing'. casinoVoidService.js documents
// exactly this race: the settlement worker pushes a bet it cannot resolve back to
// 'open'/'processing' AFTER a void has been applied, which is why every filter there
// keys off result_status, not status. Without this the watchdog reports settled,
// refunded bets as money at risk. (Verified: user 24's 5 'processing' bets were all
// already voided — exposure rows cleared, wallet lock 0, nothing owed.)
const CASINO_NO_VERDICT = `(c.result_status IS NULL OR c.result_status = '')`;

// The results cron writes sports_event_result_scan per (user_id, eventid) and keeps
// re-checking until a result appears. So "open bets + cron still polling + not yet
// declared" is a market IN PROGRESS, not a stuck one — a Test-match fancy legitimately
// stays open for days. Only a market the cron has STOPPED looking at is abandoned.
const POLL_WENT_SILENT = `
  NOT EXISTS (
    SELECT 1 FROM sports_event_result_scan r
     WHERE r.eventid = b.eventid
       AND CAST(r.user_id AS TEXT) = CAST(b.user_id AS TEXT)
       AND r.checked_at > now() - (:pollSilentMin * interval '1 minute')
  )`;

// The exact complement of POLL_WENT_SILENT: the cron IS still looking at this event.
// Healthy on its own — only damning once paired with "and it has never once declared,
// long after the match started" (see resultNeverDeclared).
const POLL_STILL_ACTIVE = `
  EXISTS (
    SELECT 1 FROM sports_event_result_scan r
     WHERE r.eventid = b.eventid
       AND CAST(r.user_id AS TEXT) = CAST(b.user_id AS TEXT)
       AND r.checked_at > now() - (:pollSilentMin * interval '1 minute')
  )`;

/**
 * Each check returns rows shaped:
 *   ref_key, event_id, match_id, market_type, game_type, title,
 *   detail, bets_count, stake_total, stale_hours
 */
export const WATCHDOG_CHECKS = [
  {
    // A result IS declared upstream and the bets are still open — this is not a feed
    // problem, it is settlement not running. Listed first because it is the most
    // actionable: the answer is already known, it just was not applied.
    key: 'resultDeclaredNotSettled', severity: 'critical',
    label: 'Result declared but bets never settled',
    suggested_action: 'Result has been declared well past the settlement window. Re-run settlement for this event; if it will not settle, void the market.',
    action_endpoint: 'POST /api/internalsettle/declareresult',
    sql: `
      SELECT b.eventid || ':' || COALESCE(b.market_type,'-') AS ref_key,
             b.eventid AS event_id, b.match_id, b.market_type, b.game_type,
             MAX(b.match_title) AS title,
             COUNT(*) || ' bet(s) still open although the result is declared' AS detail,
             COUNT(*)::int AS bets_count, ROUND(SUM(b.stake_amount)::numeric,2) AS stake_total,
             ROUND((EXTRACT(EPOCH FROM (now() - MIN(${MATCH_START})))/3600)::numeric,1) AS stale_hours
        FROM "SportsBet" b
       WHERE ${OPEN_BET}
         -- sports_event_result_scan is keyed by (user_id, eventid): one bettor's
         -- result being declared says NOTHING about another's on the same event.
         -- Without the user_id match this fired on every bettor of any event where
         -- any one user had settled.
         AND EXISTS (SELECT 1 FROM sports_event_result_scan r
                      WHERE r.eventid = b.eventid
                        AND CAST(r.user_id AS TEXT) = CAST(b.user_id AS TEXT)
                        AND r.declared = true
                        AND r.checked_at < now() - (:settleGraceMin * interval '1 minute'))
       GROUP BY b.eventid, b.market_type, b.match_id, b.game_type`,
  },
  {
    // Excludes anything resultDeclaredNotSettled already owns: when the result IS known,
    // that finding is the more specific and more actionable diagnosis, and the owner
    // should see the market once, not twice with two different suggested actions.
    key: 'staleOpenMarket', severity: 'high',
    label: 'Open bets on a match that started hours ago',
    suggested_action: 'Check the result feed. Declare the result, or void the market if it will never settle.',
    action_endpoint: 'POST /api/internalsettle/declareresult | /void',
    sql: `
      SELECT b.eventid || ':' || COALESCE(b.market_type,'-') AS ref_key,
             b.eventid AS event_id, b.match_id, b.market_type, b.game_type,
             MAX(b.match_title) AS title,
             COUNT(*) || ' bet(s) open ' ||
             ROUND((EXTRACT(EPOCH FROM (now() - MIN(${MATCH_START})))/3600)::numeric,1)
             || 'h after the match started' AS detail,
             COUNT(*)::int AS bets_count, ROUND(SUM(b.stake_amount)::numeric,2) AS stake_total,
             ROUND((EXTRACT(EPOCH FROM (now() - MIN(${MATCH_START})))/3600)::numeric,1) AS stale_hours
        FROM "SportsBet" b
       WHERE ${OPEN_BET}
         AND b.match_start_time IS NOT NULL
         AND ${MATCH_START} < now() - (:staleHours * interval '1 hour')
         AND ${SB_NOT_FANCY}
         AND NOT EXISTS (SELECT 1 FROM sports_event_result_scan r
                          WHERE r.eventid = b.eventid
                            AND CAST(r.user_id AS TEXT) = CAST(b.user_id AS TEXT)
                            AND r.declared = true)
         AND ${POLL_WENT_SILENT}
       GROUP BY b.eventid, b.market_type, b.match_id, b.game_type`,
  },
  {
    // Fancy settles per bet rather than per market, so it is grouped and actioned
    // separately — the remedy is the fancy settlement screen, not the MO/BM one.
    key: 'staleFancy', severity: 'high',
    label: 'Open fancy bets on a match that started hours ago',
    suggested_action: 'Settle the fancy market, or void it if no result will come.',
    action_endpoint: 'POST /api/internalsettle/declareresult | /void-single-bet',
    sql: `
      SELECT b.eventid || ':fancy:' || COALESCE(b.fancy_name, b.market_type, '-') AS ref_key,
             b.eventid AS event_id, b.match_id, b.market_type, b.game_type,
             MAX(COALESCE(b.fancy_name, b.match_title)) AS title,
             COUNT(*) || ' fancy bet(s) open ' ||
             ROUND((EXTRACT(EPOCH FROM (now() - MIN(${MATCH_START})))/3600)::numeric,1)
             || 'h after the match started' AS detail,
             COUNT(*)::int AS bets_count, ROUND(SUM(b.stake_amount)::numeric,2) AS stake_total,
             ROUND((EXTRACT(EPOCH FROM (now() - MIN(${MATCH_START})))/3600)::numeric,1) AS stale_hours
        FROM "SportsBet" b
       WHERE ${OPEN_BET}
         AND b.match_start_time IS NOT NULL
         AND ${MATCH_START} < now() - (:staleHours * interval '1 hour')
         AND ${SB_FANCY}
         AND NOT EXISTS (SELECT 1 FROM sports_event_result_scan r
                          WHERE r.eventid = b.eventid
                            AND CAST(r.user_id AS TEXT) = CAST(b.user_id AS TEXT)
                            AND r.declared = true)
         AND ${POLL_WENT_SILENT}
       GROUP BY b.eventid, b.match_id, b.market_type, b.game_type, COALESCE(b.fancy_name, b.market_type, '-')`,
  },
  {
    // THE BLIND SPOT staleOpenMarket/staleFancy leave open. Both of those require the
    // cron to have gone QUIET; a cron that polls every 60s and fails every 60s is the
    // loudest possible failure and was the one thing neither of them could see. Money
    // stays locked indefinitely and nothing alerts. Covers fancy and non-fancy together
    // because the diagnosis and the remedy are identical: the feed is never going to
    // answer for this market, so find out why or settle it by hand.
    key: 'resultNeverDeclared', severity: 'high',
    label: 'Results cron polling for hours but the feed never declares',
    suggested_action: 'The cron is polling this event and getting nothing back. Check the feed for this sport (is the sid one the result API actually serves?), then declare or void the market.',
    action_endpoint: 'POST /api/internalsettle/declareresult | /void',
    sql: `
      SELECT b.eventid || ':nodecl:' || COALESCE(b.market_type,'-') AS ref_key,
             b.eventid AS event_id, b.match_id, b.market_type, b.game_type,
             MAX(b.match_title) AS title,
             COUNT(*) || ' bet(s) open ' ||
             ROUND((EXTRACT(EPOCH FROM (now() - MIN(${MATCH_START})))/3600)::numeric,1)
             || 'h after the match started - the cron is still polling (sport_id '
             || COALESCE(MAX(b.sport_id),'?') || ') but no result has ever been declared'
             AS detail,
             COUNT(*)::int AS bets_count, ROUND(SUM(b.stake_amount)::numeric,2) AS stake_total,
             ROUND((EXTRACT(EPOCH FROM (now() - MIN(${MATCH_START})))/3600)::numeric,1) AS stale_hours
        FROM "SportsBet" b
       WHERE ${OPEN_BET}
         AND b.match_start_time IS NOT NULL
         AND ${MATCH_START} < now() - (:neverDeclaredHours * interval '1 hour')
         AND NOT EXISTS (SELECT 1 FROM sports_event_result_scan r
                          WHERE r.eventid = b.eventid
                            AND CAST(r.user_id AS TEXT) = CAST(b.user_id AS TEXT)
                            AND r.declared = true)
         AND ${POLL_STILL_ACTIVE}
         -- ...and the FEED itself says this event is either finished or unservable.
         -- newjobv2.js records its verdict on every poll (see feedState there):
         --   'live'     payload still carries PENDING markets — the match is being
         --              played. A 5-day Test sits here legitimately; never alert.
         --   'complete' every market SETTLE and ours is not among them — the feed is
         --              done with this event, so our market is never arriving.
         --   'unknown'  400/404 across every supported sid — the feed cannot serve
         --              this event at all (bad sid, gmid it does not hold).
         -- Asking the feed beats guessing from our own rows: the previous version of
         -- this check inferred liveness from "did any sibling bet settle", which
         -- spared England v Pakistan (536350957) only by luck and would have fired
         -- for five days on a Test whose only bets were MATCH_ODDS.
         -- Rows written before this field exists have a NULL feed key and are
         -- suppressed until the cron rewrites them (one 60s tick).
         AND EXISTS (
             SELECT 1 FROM sports_event_result_scan r
              WHERE r.eventid = b.eventid
                AND CAST(r.user_id AS TEXT) = CAST(b.user_id AS TEXT)
                AND r.counts ->> 'feed' IN ('unknown','complete'))
       GROUP BY b.eventid, b.market_type, b.match_id, b.game_type`,
  },
  {
    key: 'stuckSettlementJob', severity: 'critical',
    label: 'Settlement job wedged in queued/processing',
    suggested_action: 'Check the sports settlement worker (pm2 undefined-sports-settlement-worker). Requeue the job.',
    action_endpoint: null,
    sql: `
      SELECT j.job_id::text AS ref_key, j.eventid AS event_id, NULL::text AS match_id,
             NULL::text AS market_type, j.bet_type AS game_type,
             'settlement job ' || j.status AS title,
             'job stuck in ' || j.status || ' since ' || to_char(j.updated_at,'YYYY-MM-DD HH24:MI') AS detail,
             1 AS bets_count, 0::numeric AS stake_total,
             ROUND((EXTRACT(EPOCH FROM (now() - j.updated_at))/3600)::numeric,1) AS stale_hours
        FROM sports_event_settlement_jobs j
       WHERE j.status IN ('queued','processing')
         AND j.updated_at < now() - (:jobStuckMin * interval '1 minute')`,
  },
  {
    key: 'stuckCasinoBet', severity: 'high',
    label: 'Casino bets stuck mid-settlement',
    suggested_action: 'Void the stuck casino bets to release the held exposure.',
    action_endpoint: 'POST /api/internalsettle/void-casino-bets',
    sql: `
      -- ref_key must carry EVERY column this check groups by, or two distinct groups
      -- collapse onto one row via ON CONFLICT and a finding is silently lost.
      SELECT 'casino:' || c.game_name
             || ':' || COALESCE(c.round_id::text,'-')
             || ':' || COALESCE(c.event_id::text,'-')
             || ':' || COALESCE(c.mtype,'-')
             || ':' || COALESCE(c.type,'-')
             || ':' || c.status AS ref_key,
             c.event_id::text, NULL::text AS match_id, c.mtype AS market_type, c.type AS game_type,
             c.game_name AS title,
             COUNT(*) || ' casino bet(s) held in ' || c.status
             || ' with no result recorded' AS detail,
             COUNT(*)::int AS bets_count, ROUND(SUM(c.stake)::numeric,2) AS stake_total,
             ROUND((EXTRACT(EPOCH FROM (now() - MIN(c.created_at)))/3600)::numeric,1) AS stale_hours
        FROM casino_bets c
       WHERE c.status IN ('open','processing','pending')
         AND ${CASINO_NO_VERDICT}
         AND c.created_at < now() - (:casinoStuckMin * interval '1 minute')
       GROUP BY c.game_name, c.round_id, c.event_id, c.mtype, c.type, c.status`,
  },
  {
    key: 'exposureNotReleased', severity: 'high',
    label: 'Exposure still held for a market with no open bets',
    suggested_action: 'Recompute the user exposure for this match — the bet closed but the lock did not lift.',
    action_endpoint: null,
    sql: `
      SELECT 'exp:' || e.match_id || ':' || CAST(e.user_id AS TEXT) AS ref_key,
             e.event_id::text, e.match_id::text, e.game_type AS market_type, e.game_type,
             COALESCE(u.username, CAST(e.user_id AS TEXT)) AS title,
             'exposure ' || ROUND(e.exposure_amount::numeric,2)
             || ' still held although no bet is open on this match' AS detail,
             1 AS bets_count, ROUND(ABS(e.exposure_amount)::numeric,2) AS stake_total,
             NULL::numeric AS stale_hours
        FROM user_exposures e
        LEFT JOIN users u ON CAST(u.user_id AS TEXT) = CAST(e.user_id AS TEXT)
       WHERE COALESCE(u.is_demo,false) = false
         AND e.category <> 'casino' AND e.match_id IS NOT NULL
         AND ABS(COALESCE(e.exposure_amount,0)) > 0.01
         AND NOT EXISTS (
             SELECT 1 FROM "SportsBet" b
              WHERE b.match_id = e.match_id
                AND CAST(b.user_id AS TEXT) = CAST(e.user_id AS TEXT)
                AND ${OPEN_BET})`,
  },
  {
    // The upstream CAUSE of most stale markets. Surfaced next to the symptoms on
    // purpose: if the feed is simply down, the markets below will settle themselves
    // once it returns, and voiding them would destroy correct settlements.
    key: 'feedSilent', severity: 'critical',
    label: 'Result feed has gone quiet',
    suggested_action: 'Check the results cron (pm2 undefined-sports-results-cron) before actioning any stale market below.',
    action_endpoint: null,
    sql: `
      SELECT 'feed:results' AS ref_key, NULL::text AS event_id, NULL::text AS match_id,
             NULL::text AS market_type, NULL::text AS game_type,
             'sports result feed' AS title,
             'no result scan written for ' ||
             ROUND((EXTRACT(EPOCH FROM (now() - MAX(r.checked_at)))/60)::numeric,0)
             || ' minutes' AS detail,
             0 AS bets_count, 0::numeric AS stake_total,
             ROUND((EXTRACT(EPOCH FROM (now() - MAX(r.checked_at)))/3600)::numeric,1) AS stale_hours
        FROM sports_event_result_scan r
       HAVING MAX(r.checked_at) < now() - (:feedSilentMin * interval '1 minute')`,
  },
];

export async function ensureTable() {
  await run(`
    CREATE TABLE IF NOT EXISTS settlement_watchdog (
      id               SERIAL PRIMARY KEY,
      kind             TEXT NOT NULL,
      ref_key          TEXT NOT NULL,
      label            TEXT,
      event_id         TEXT,
      match_id         TEXT,
      market_type      TEXT,
      game_type        TEXT,
      title            TEXT,
      severity         TEXT DEFAULT 'high',
      detail           TEXT,
      bets_count       INTEGER,
      stake_total      NUMERIC(18,2),
      stale_hours      NUMERIC(10,2),
      suggested_action TEXT,
      action_endpoint  TEXT,
      first_seen       TIMESTAMPTZ DEFAULT now(),
      last_seen        TIMESTAMPTZ DEFAULT now(),
      acknowledged_by  TEXT,
      acknowledged_at  TIMESTAMPTZ,
      resolved_at      TIMESTAMPTZ,
      UNIQUE (kind, ref_key)
    )`);
  await run(`CREATE INDEX IF NOT EXISTS settlement_watchdog_active
               ON settlement_watchdog (resolved_at, severity)`);
}

/** Run every watchdog check, upsert findings, auto-resolve anything that now passes. */
export async function scanWatchdog() {
  await ensureTable();
  const ts = new Date();
  const replacements = {
    staleHours: STALE_HOURS, jobStuckMin: JOB_STUCK_MIN,
    casinoStuckMin: CASINO_STUCK_MIN, feedSilentMin: FEED_SILENT_MIN,
    pollSilentMin: POLL_SILENT_MIN, settleGraceMin: SETTLE_GRACE_MIN,
    neverDeclaredHours: NEVER_DECLARED_HOURS,
    serverTz: SERVER_TZ, feedTz: FEED_TZ,
  };
  let total = 0;
  const byKind = {};

  for (const check of WATCHDOG_CHECKS) {
    try {
      const rows = await sel(check.sql, replacements);
      byKind[check.key] = rows.length;
      for (const r of rows) {
        total += 1;
        await run(
          `INSERT INTO settlement_watchdog
             (kind, ref_key, label, event_id, match_id, market_type, game_type, title,
              severity, detail, bets_count, stake_total, stale_hours,
              suggested_action, action_endpoint, first_seen, last_seen, resolved_at)
           VALUES (:kind, :ref_key, :label, :event_id, :match_id, :market_type, :game_type, :title,
                   :severity, :detail, :bets_count, :stake_total, :stale_hours,
                   :suggested_action, :action_endpoint, :ts, :ts, NULL)
           ON CONFLICT (kind, ref_key) DO UPDATE SET
             label = EXCLUDED.label, title = EXCLUDED.title, detail = EXCLUDED.detail,
             severity = EXCLUDED.severity, bets_count = EXCLUDED.bets_count,
             stake_total = EXCLUDED.stake_total, stale_hours = EXCLUDED.stale_hours,
             suggested_action = EXCLUDED.suggested_action,
             action_endpoint = EXCLUDED.action_endpoint,
             last_seen = :ts,
             -- a finding that resolved and came back is NEW again, so first_seen resets
             first_seen = CASE WHEN settlement_watchdog.resolved_at IS NULL
                               THEN settlement_watchdog.first_seen ELSE :ts END,
             -- ...and an acknowledgement does not carry over to the new occurrence
             acknowledged_by = CASE WHEN settlement_watchdog.resolved_at IS NULL
                                    THEN settlement_watchdog.acknowledged_by ELSE NULL END,
             acknowledged_at = CASE WHEN settlement_watchdog.resolved_at IS NULL
                                    THEN settlement_watchdog.acknowledged_at ELSE NULL END,
             resolved_at = NULL`,
          {
            kind: check.key, ref_key: String(r.ref_key), label: check.label,
            event_id: r.event_id || null, match_id: r.match_id || null,
            market_type: r.market_type || null, game_type: r.game_type || null,
            title: r.title || null, severity: check.severity, detail: r.detail || null,
            bets_count: r.bets_count ?? null, stake_total: r.stake_total ?? null,
            stale_hours: r.stale_hours ?? null,
            suggested_action: check.suggested_action || null,
            action_endpoint: check.action_endpoint || null, ts,
          }
        );
      }
    } catch (e) {
      // one bad check must never abort the sweep — same rule as scanner.js
      console.error(`[watchdog] check ${check.key} failed:`, e.message);
      byKind[check.key] = 'error';
    }
  }

  await run(`UPDATE settlement_watchdog SET resolved_at = :ts
              WHERE resolved_at IS NULL AND last_seen < :ts`, { ts });

  return { scannedAt: ts.toISOString(), totalFindings: total, byKind, thresholds: replacements };
}

/** Read the cached board — instant, no scan. */
export async function getActiveWatchdog({ includeResolved = false } = {}) {
  await ensureTable();
  const rows = await sel(`
    SELECT id, kind, ref_key, label, event_id, match_id, market_type, game_type, title,
           severity, detail, bets_count, stake_total, stale_hours,
           suggested_action, action_endpoint, first_seen, last_seen,
           acknowledged_by, acknowledged_at, resolved_at
      FROM settlement_watchdog
     ${includeResolved ? '' : 'WHERE resolved_at IS NULL'}
     ORDER BY CASE severity WHEN 'critical' THEN 0 WHEN 'high' THEN 1 ELSE 2 END,
              COALESCE(stale_hours,0) DESC, id DESC
     LIMIT 500`);
  const lastScan = await sel(`SELECT MAX(last_seen) AS last FROM settlement_watchdog`);
  return {
    count: rows.length,
    critical: rows.filter((r) => r.severity === 'critical' && !r.resolved_at).length,
    unacknowledged: rows.filter((r) => !r.acknowledged_by && !r.resolved_at).length,
    stakeAtRisk: Number(rows.reduce((s, r) => s + Number(r.stake_total || 0), 0).toFixed(2)),
    findings: rows,
    thresholds: { STALE_HOURS, JOB_STUCK_MIN, CASINO_STUCK_MIN, FEED_SILENT_MIN, POLL_SILENT_MIN, SETTLE_GRACE_MIN },
    lastScan: lastScan[0] ? lastScan[0].last : null,
  };
}

/** Owner marks a finding as "I am handling this" — it stays visible but stops nagging. */
export async function acknowledgeFinding(id, by) {
  await ensureTable();
  await run(`UPDATE settlement_watchdog
                SET acknowledged_by = :by, acknowledged_at = now()
              WHERE id = :id AND resolved_at IS NULL`, { id: Number(id), by: String(by || 'owner') });
  const rows = await sel(`SELECT * FROM settlement_watchdog WHERE id = :id`, { id: Number(id) });
  return rows[0] || null;
}

export default { WATCHDOG_CHECKS, ensureTable, scanWatchdog, getActiveWatchdog, acknowledgeFinding };
