import express from "express";
import authMiddleware from "../../middleware/authMiddleware.js";
import verifyTransactionPassword from "../../middleware/transactionPasswordMiddleware.js";
import { denyExecutives } from "../../middleware/permissionMiddleware.js";
import {
  createExecutive,
  getExecutives,
  updateExecutive,
  setExecutiveActive,
  changeExecutivePassword,
  deleteExecutive
} from "../../controller/executive/executiveController.js";

const router = express.Router();

// All executive-management actions are owner/staff-only; the controller's
// denyNonAdmins guard blocks executives/users/agents. Authentication is
// required on every route.
// Creating a login is at least as sensitive as a deposit, so /create also
// demands the caller's transaction password (body: transactionPassword).
// denyExecutives runs first so an executive can never burn the parent's
// transaction-password attempts by probing this route.
router.post("/create", authMiddleware, denyExecutives, verifyTransactionPassword, createExecutive);
router.get("/list", authMiddleware, getExecutives);
router.put("/:id", authMiddleware, updateExecutive);
router.patch("/:id/active", authMiddleware, setExecutiveActive);
router.post("/:id/password", authMiddleware, changeExecutivePassword);
router.delete("/:id", authMiddleware, deleteExecutive);

export default router;
