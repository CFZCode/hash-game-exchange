import express from 'express';
import authMiddleware from '../../middleware/authMiddleware.js';
import { requireOwner } from '../../middleware/permissionMiddleware.js';
import ThirdPartyLimitController from '../../controller/admin/thirdPartyLimitController.js';

const router = express.Router();

// Third Party Game Limit is owner-only end to end — staff and executives never
// see the screen (admin/src/utils/permissions.js OWNER_ONLY_ROUTES is the
// client mirror) and are refused here regardless. Same shape as
// bettingConfigRoutes.js (Buffer Time / Bet Limits).

// Direct downline (staff + users) with their own and inherited limits.
// ?parentId=<staff_id> drills into that staff's own direct children.
router.get('/third-party-limit/list', authMiddleware, requireOwner, ThirdPartyLimitController.listDownline);

// Set / clear one node's per-bet cap. 0 clears it (node inherits from above).
router.post('/third-party-limit/set', authMiddleware, requireOwner, ThirdPartyLimitController.saveLimit);

export default router;
