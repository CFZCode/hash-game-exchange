import express from 'express';
import Telegram2FAController from '../../controller/user/telegram2faController.js';
import AdminGoogleAuthController from '../../controller/admin/adminGoogleAuthController.js';
import AndroidAuthController from '../../controller/user/androidAuthController.js';
import authMiddleware from '../../middleware/authMiddleware.js';

const router = express.Router();

// An owner/staff turning secure auth on or off for THEIR OWN login.
//
// Deliberately the same controller the player routes use: it already resolves
// USER / STAFF / OWNER from the token, writes the same `telegramChatId` +
// `telegram2FAEnabled` columns the admin login flow reads, and builds the same
// `staff_<id>` / `owner_<id>` OTP cache keys that staffAuthService and
// ownerAuthService use at login. Duplicating it would mean two copies of the
// link-code table and two OTP conventions to keep in step.
//
// Not to be confused with `secureAuthConfigRoutes.js` — that is the OWNER-ONLY
// bot configuration (username + token). These are per-account.
router.post('/secure-auth/verify-password', authMiddleware, Telegram2FAController.verifyPassword);
router.post('/secure-auth/generate-link-code', authMiddleware, Telegram2FAController.generateLinkCode);
router.post('/secure-auth/send-disable-code', authMiddleware, Telegram2FAController.sendDisableCode);
router.post('/secure-auth/disable', authMiddleware, Telegram2FAController.disable2FA);

// Google Authenticator (TOTP) — the other method on the same page. Its own
// controller because an admin token resolves to an Owner/Staff row, but it
// reuses the shared GoogleAuthService the player side uses.
router.post('/secure-auth/google/setup', authMiddleware, AdminGoogleAuthController.setup);
router.post('/secure-auth/google/enable', authMiddleware, AdminGoogleAuthController.enable);
router.post('/secure-auth/google/disable', authMiddleware, AdminGoogleAuthController.disable);

// 'Secure Auth Verification App' (Android, offline TOTP) — the third method on
// the page. The SAME controller the player mount uses, so the pairing code an
// operator sees here and the one the phone redeems at /api/2fa/android/claim
// live in ONE pending-pairing table.
router.post('/secure-auth/android/pair', authMiddleware, AndroidAuthController.pair);
router.post('/secure-auth/android/enable', authMiddleware, AndroidAuthController.enable);
router.post('/secure-auth/android/disable', authMiddleware, AndroidAuthController.disable);

export default router;
