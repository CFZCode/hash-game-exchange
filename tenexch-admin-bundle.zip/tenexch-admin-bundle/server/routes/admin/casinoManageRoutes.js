import express from 'express';
import multer from 'multer';
import authMiddleware from '../../middleware/authMiddleware.js';
import { requireOwner } from '../../middleware/permissionMiddleware.js';
import { listGames, updateGame, createGame, uploadGameImage, reorderGames } from '../../controller/admin/casinoManageController.js';

const router = express.Router();

// Tile-art uploads: kept in memory (req.file.buffer) and answered as a base64
// data URL — nothing is ever written to disk or the web root.
const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 5 * 1024 * 1024 },
    fileFilter: (req, file, cb) => {
        if (!file.mimetype.startsWith('image/')) {
            return cb(new Error('Only image files are allowed'));
        }
        cb(null, true);
    },
});

// Multer errors (size/type) become clean 400s instead of a stack trace.
const uploadSingleImage = (req, res, next) => {
    upload.single('image')(req, res, (err) => {
        if (err) return res.status(400).json({ success: false, error: err.message });
        next();
    });
};

// Casino Manage is owner-only end to end — staff and executives never see it.
router.get('/casino-manage/list', authMiddleware, requireOwner, listGames);
router.post('/casino-manage/create', authMiddleware, requireOwner, createGame);
router.post('/casino-manage/upload', authMiddleware, requireOwner, uploadSingleImage, uploadGameImage);
// Must be declared BEFORE '/casino-manage/:id', or Express matches 'reorder'
// as an id — carouselRoutes.js orders /carousel/reorder first for this reason.
router.put('/casino-manage/reorder', authMiddleware, requireOwner, reorderGames);
router.put('/casino-manage/:id', authMiddleware, requireOwner, updateGame);

export default router;
