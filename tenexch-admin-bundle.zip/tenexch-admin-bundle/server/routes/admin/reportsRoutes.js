import express from 'express';
import ReportsController from '../../controller/admin/reportsController.js';
import authMiddleware from '../../middleware/authMiddleware.js';
import { requireBackoffice } from '../../middleware/permissionMiddleware.js';
import dateRangeMiddleware, { maxDateRange } from '../../middleware/dateRangeMiddleware.js';

const router = express.Router();

// 🔐 Protected: Get Account Statement
router.post('/accountstatement', authMiddleware, ReportsController.getAccountStatement);

// 🔐 Protected: Settlement report V2 — point_ledger se (apni + settle ki hui entries)
router.post('/statementv2', authMiddleware, maxDateRange(7), ReportsController.getStatementV2);

// 🔐 Protected: ek statement row ke peeche ke bets (Excel icon ka download)
router.post('/statementv2/bet-export', authMiddleware, ReportsController.getStatementBetExport);

// 🔐 Protected: statement row par click — us row ke bets (Details modal)
router.post('/statementv2/bet-detail', authMiddleware, ReportsController.getStatementBetDetail);

// 🔐 Protected: casino Result modal — downline bets of one round (?gameName=&roundId=)
router.get('/casino/round-bets', authMiddleware, requireBackoffice, ReportsController.getCasinoRoundBets);

// 🔐 Protected: Get Current Bets
router.get('/current-bets', authMiddleware, requireBackoffice, ReportsController.getCurrentBets);

router.post('/casino-report', authMiddleware, ReportsController.getCasinoReport);



router.post('/market-analysis', authMiddleware, ReportsController.getMarketAnalysis);

// 🔐 Protected: Market Analysis dashboard — exposure grouped by EVENT (ek event = ek entry, saare markets andar)
router.post('/market-analysis/dashboard', authMiddleware, ReportsController.getMarketAnalysisDashboard);

// 🔐 Protected: Per-user book for one market — game-details "User Book" popup
router.post('/user-book', authMiddleware, ReportsController.getUserBook);

router.post('/user-win-loss', authMiddleware, ReportsController.getUserWinLoss);

// 🔐 Protected: Category-wise point report — point_ledger se hierarchy ke
// users ki SUM(delta) per category (CASINO/SPORTS/THIRD_PARTY/SPORTSBOOK)
router.post('/point-category-report', authMiddleware, dateRangeMiddleware, ReportsController.getPointCategoryReport);

// 🔐 Protected: User Registration Report — hierarchy ke users ki registration/
// login/deposit detail + wallet ke category balances
router.get('/user-register-detail', authMiddleware, requireBackoffice, ReportsController.getUserRegisterDetail);

router.post('/total-profit-loss', authMiddleware, dateRangeMiddleware, ReportsController.getTotalProfitLoss);

// 🔐 Protected: User Bet History (downline only)
router.get('/user-bet-history', authMiddleware, ReportsController.getUserBetHistory);

// 🔐 Protected: Login History (downline only) — user-history page tab 1
router.get('/login-history', authMiddleware, requireBackoffice, ReportsController.getLoginHistory);

// 🔐 Protected: Change Password History (downline only) — user-history page tab 2
router.get('/password-history', authMiddleware, requireBackoffice, ReportsController.getPasswordHistory);

// 🔐 Protected: Match-scoped bets (downline only) — used by game-details page
router.get('/match-downline-bets', authMiddleware, ReportsController.getMatchDownlineBets);

// 🔐 Protected: Turnover Report — hierarchy ke users ki sports/casino bets
router.post('/turnover', authMiddleware, dateRangeMiddleware, ReportsController.getTurnoverReport);

export default router;
