import express from 'express';
import authMiddleware from '../../middleware/authMiddleware.js';
import { requireOwner } from '../../middleware/permissionMiddleware.js';
import BettingConfigController from '../../controller/admin/bettingConfigController.js';

const router = express.Router();

// Buffer Time and Bet Limits are owner-only end to end — staff and executives
// never see the screens (admin/src/utils/permissions.js OWNER_ONLY_ROUTES is
// the client mirror) and are refused here regardless.

// ── Buffer Time ────────────────────────────────────────────────────────────
router.get('/betting-config/buffer/sports', authMiddleware, requireOwner, BettingConfigController.getSportsBuffers);
router.post('/betting-config/buffer/sports', authMiddleware, requireOwner, BettingConfigController.saveSportsBuffer);
router.post('/betting-config/buffer/sports/bulk', authMiddleware, requireOwner, BettingConfigController.saveSportsBufferBulk);
router.delete('/betting-config/buffer/sports', authMiddleware, requireOwner, BettingConfigController.resetSportsBuffer);
router.get('/betting-config/buffer/casino', authMiddleware, requireOwner, BettingConfigController.getCasinoBuffers);
router.post('/betting-config/buffer/casino', authMiddleware, requireOwner, BettingConfigController.saveCasinoBuffer);

// ── Bet Limits (sports) ────────────────────────────────────────────────────
// 'inplay' and 'casino' are declared BEFORE the ':event_id' style routes so
// Express can't match them as an id — the same ordering carouselRoutes.js and
// casinoManageRoutes.js use.
router.get('/betting-config/bet-limits/inplay', authMiddleware, requireOwner, BettingConfigController.getInplayEvents);
router.get('/betting-config/bet-limits/casino', authMiddleware, requireOwner, BettingConfigController.getCasinoLimits);
router.post('/betting-config/bet-limits/casino', authMiddleware, requireOwner, BettingConfigController.saveCasinoLimit);
router.delete('/betting-config/bet-limits/casino/:id', authMiddleware, requireOwner, BettingConfigController.deleteCasinoLimit);

router.get('/betting-config/bet-limits/event/:event_id', authMiddleware, requireOwner, BettingConfigController.getEventMarkets);
router.post('/betting-config/bet-limits/event', authMiddleware, requireOwner, BettingConfigController.saveEventLimit);
router.delete('/betting-config/bet-limits/event/:id', authMiddleware, requireOwner, BettingConfigController.deleteEventLimit);

// ── Max Odds (sports) ──────────────────────────────────────────────────────
router.get('/betting-config/max-odds/sports', authMiddleware, requireOwner, BettingConfigController.getSportsMaxOdds);
router.post('/betting-config/max-odds/sports', authMiddleware, requireOwner, BettingConfigController.saveSportsMaxOdds);
router.delete('/betting-config/max-odds/sports', authMiddleware, requireOwner, BettingConfigController.resetSportsMaxOdds);

// ── Auto Void (sports) ─────────────────────────────────────────────────────
// Owner-only. Read by sportsbet/betresult/autoVoid.js; see that file.
router.get('/betting-config/auto-void', authMiddleware, requireOwner, BettingConfigController.getAutoVoid);
router.put('/betting-config/auto-void', authMiddleware, requireOwner, BettingConfigController.saveAutoVoid);
router.get('/betting-config/auto-void/tracker', authMiddleware, requireOwner, BettingConfigController.getAutoVoidTracker);
router.get('/betting-config/auto-void/links', authMiddleware, requireOwner, BettingConfigController.listResultLinks);
router.post('/betting-config/auto-void/links', authMiddleware, requireOwner, BettingConfigController.createResultLink);
router.put('/betting-config/auto-void/links/:id', authMiddleware, requireOwner, BettingConfigController.updateResultLink);
router.delete('/betting-config/auto-void/links/:id', authMiddleware, requireOwner, BettingConfigController.deleteResultLink);

// ── Virtual Bet Limits (Dim / T5 XI / T10 XI / VCL / WWE Virtual) ─────────
router.get('/betting-config/virtual-limits', authMiddleware, requireOwner, BettingConfigController.getVirtualLimits);
router.put('/betting-config/virtual-limits', authMiddleware, requireOwner, BettingConfigController.saveVirtualLimits);

export default router;
