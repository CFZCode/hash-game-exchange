import express from 'express';
import SecureAuthConfigController from '../../controller/admin/secureAuthConfigController.js';
import authMiddleware from '../../middleware/authMiddleware.js';
import { requireOwner } from '../../middleware/permissionMiddleware.js';

const router = express.Router();

// Secure-auth bot settings are owner-only — the token is a credential.
router.get('/secure-auth/bot', authMiddleware, requireOwner, SecureAuthConfigController.get);
router.put('/secure-auth/bot', authMiddleware, requireOwner, SecureAuthConfigController.update);

export default router;
