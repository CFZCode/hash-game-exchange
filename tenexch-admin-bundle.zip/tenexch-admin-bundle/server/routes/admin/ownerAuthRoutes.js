

import express from 'express';
import ownerAuthController from '../../controller/admin/ownerAuthController.js';
import authMiddleware from '../../middleware/authMiddleware.js';

const router = express.Router();

//  Owner / Website Login
router.post('/login-owner', ownerAuthController.login);

// Verify 2FA
router.post('/owner/verify-2fa', ownerAuthController.verify2FA);

// Re-send the login OTP — see the staff route for why this is unauthenticated.
router.post('/owner/resend-2fa-otp', ownerAuthController.resend2FA);

//  Owner Logout
router.post('/logout', authMiddleware, ownerAuthController.logout);

// Owner Profile
router.get('/profile', authMiddleware, ownerAuthController.getProfile);

// Accept Rules (rules modal)
router.post('/accept-rules', authMiddleware, ownerAuthController.acceptRules);

// Update Platform Configurations
router.post('/update-platform-configurations', authMiddleware, ownerAuthController.updatePlatformConfigurations);

export default router;
