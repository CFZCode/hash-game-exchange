import express from "express";
import {
  getBetLock,
  getAllBetLocks,
  lockBet,
  unlockBet,
  lockMultipleBets,
  unlockMultipleBets,
  lockAllMatchOdds,
  lockAllOtherMarkets,
  unlockAllBets,
  lockMatchForUser,
  unlockMatchForUser,
  getMatchLocks,
  getMarketLockChildren,
  toggleMarketLock,
  bulkToggleMarketLock,
} from "../../controller/admin/betLockController.js";
import authMiddleware from "../../middleware/authMiddleware.js";
import { verifyTransactionPasswordAs } from "../../middleware/transactionPasswordMiddleware.js";
import { MESSAGES } from "../../constants/messages.js";
import { requireOwner, requireBackoffice } from "../../middleware/permissionMiddleware.js";

const router = express.Router();

/**
 * ===========================
 *  BET LOCK ROUTES (Admin)
 * ===========================
 */

// Global bet lock
router.get("/betlock/", authMiddleware, requireBackoffice, getAllBetLocks);
router.get("/betlock/:user_id", authMiddleware, requireBackoffice, getBetLock);
router.post("/betlock/lock/user", authMiddleware, requireBackoffice, lockBet);
router.post("/betlock/unlock/user", authMiddleware, requireBackoffice, unlockBet);
router.post("/betlock/lock/multiple", authMiddleware, requireBackoffice, requireOwner, lockMultipleBets);
router.post("/betlock/unlock/multiple", authMiddleware, requireBackoffice, requireOwner, unlockMultipleBets);
router.post("/betlock/lock/all/matchodds", authMiddleware, requireBackoffice, requireOwner, lockAllMatchOdds);
router.post("/betlock/lock/all/othermarkets", authMiddleware, requireBackoffice, requireOwner, lockAllOtherMarkets);
router.post("/betlock/unlock/all", authMiddleware, requireBackoffice, requireOwner, unlockAllBets);

// Match-level locks
router.post("/betlock/lock/match", authMiddleware, requireBackoffice, lockMatchForUser);
router.post("/betlock/unlock/match", authMiddleware, requireBackoffice, unlockMatchForUser);
router.get("/betlock/match/:event_id", authMiddleware, requireBackoffice, getMatchLocks);

// Market-wise locks (event + market)
// Query params: ?market_id=xxx or ?market_name=xxx
router.get("/betlock/market-locks/:event_id", authMiddleware, requireBackoffice, getMarketLockChildren);
// The Bet Lock modal has no Submit button: ticking an account IS the call, and
// it carries the Transaction Code typed above the list. The code is verified
// here — before anything is locked — through the shared attempts service, with
// Bet Lock's own wording for a wrong one (`Master Password not valid.`).
// Reading the list stays open; only the two writes are gated.
const requireTxnCode = verifyTransactionPasswordAs(MESSAGES.ADMIN.TXN.MASTER_NOT_VALID);

router.post("/betlock/toggle-market-lock", authMiddleware, requireBackoffice, requireTxnCode, toggleMarketLock);
router.post("/betlock/bulk-toggle-market-lock", authMiddleware, requireBackoffice, requireTxnCode, bulkToggleMarketLock);

export default router;
