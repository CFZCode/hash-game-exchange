import express from 'express';
const router = express.Router();
import PosterController from '../../controller/admin/posterController.js'; // Adjust the path as needed
import authMiddleware from '../../middleware/authMiddleware.js'; // Adjust the path as needed
import { requireOwner } from '../../middleware/permissionMiddleware.js';

// Poster management lives on the owner-only Carousel page; the public site
// reads via /user/poster.

// Get the current poster link
router.get('/poster', authMiddleware, requireOwner, PosterController.getPoster);

// Set or update the poster link
router.put('/poster', authMiddleware, requireOwner, PosterController.upsertPoster);

export default router;
