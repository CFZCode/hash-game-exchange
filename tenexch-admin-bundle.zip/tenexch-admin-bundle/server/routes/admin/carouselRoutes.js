import express from 'express';
const router = express.Router();
import CarouselController from '../../controller/admin/carouselController.js'; // Adjust the path as needed
import authMiddleware from '../../middleware/authMiddleware.js'; // Adjust the path as needed
import { requireOwner } from '../../middleware/permissionMiddleware.js';

// Carousel management is owner-only; the public site reads via /user/carousel.

// Create a new carousel entry
router.post('/carousel/create', authMiddleware, requireOwner, CarouselController.createCarousel);

// List all carousel entries (admin table)
router.get('/carousel/list', authMiddleware, requireOwner, CarouselController.getAllCarousels);

// Rearrange display order (must be declared before /carousel/:carousel_id)
router.put('/carousel/reorder', authMiddleware, requireOwner, CarouselController.reorderCarousels);

// Update a carousel entry by carousel_id
router.put('/carousel/:carousel_id', authMiddleware, requireOwner, CarouselController.updateCarousel);

// Delete a carousel entry by carousel_id
router.delete('/carousel/:carousel_id', authMiddleware, requireOwner, CarouselController.deleteCarousel);

export default router;
