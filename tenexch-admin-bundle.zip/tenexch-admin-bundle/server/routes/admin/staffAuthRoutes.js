import express from 'express';
import staffAuthController from '../../controller/admin/staffAuthController.js';
import authMiddleware from '../../middleware/authMiddleware.js';

const router = express.Router();

// 🔐 Login (Staff / Admin / Owner / etc.)
router.post('/staff/login', staffAuthController.login);

// Verify 2FA
router.post('/staff/verify-2fa', staffAuthController.verify2FA);

// Re-send the login OTP — the 2FA screen calls this when it is refreshed.
// Public like verify-2fa: the caller has no token yet, only the staffId the
// login response returned.
router.post('/staff/resend-2fa-otp', staffAuthController.resend2FA);

// 🚪 Logout
router.post('/staff/logout', authMiddleware, staffAuthController.logout);

// 👤 Profile
router.get('/staff/profile', authMiddleware, staffAuthController.getProfile);

// ✅ Accept Rules (rules modal)
router.post('/staff/accept-rules', authMiddleware, staffAuthController.acceptRules);

export default router;
