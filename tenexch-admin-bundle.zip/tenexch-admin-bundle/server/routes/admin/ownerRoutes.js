import express from 'express';
import OwnerController from '../../controller/admin/OwnerController.js';
import authMiddleware from '../../middleware/authMiddleware.js';
import AuthController from '../../controller/admin/ownerAuthController.js';
import verifyTransactionPassword from '../../middleware/transactionPasswordMiddleware.js';
import crypto from 'crypto';
import { MESSAGES } from '../../constants/messages.js';

const router = express.Router();




//========== previously used routes but now disabled ==========================


//create owner used by cfz technologies only=======================================
// Owner creation used to be open to anyone (no login): a stranger could create
// an OWNER — with an opening balance of their choice — and reach every
// owner-only screen. Now it needs the secret setup token in the header
// X-Setup-Token, equal to OWNER_SETUP_TOKEN in server .env. Unset = closed (the
// normal state); set it only for the minute an owner is created, then remove it.
const requireOwnerSetupToken = (req, res, next) => {
  const expected = process.env.OWNER_SETUP_TOKEN || '';
  const given = String(req.get('X-Setup-Token') || '');
  const ok = expected.length >= 32 && given.length === expected.length
    && crypto.timingSafeEqual(Buffer.from(given), Buffer.from(expected));
  if (!ok) return res.status(403).json({ success: false, error: MESSAGES.ADMIN.AUTH.OWNER_SETUP_DISABLED });
  return next();
};
router.post('/owner/create-owner', requireOwnerSetupToken, OwnerController.createOwner);
// Get all clients/websites
// router.get('/owner', OwnerController.getAllOwners);
// // Delete a client/website
// router.delete('/owner/:ownerId', OwnerController.deleteOwner);

// //============================================================================================





// //login client/website
// router.post('/login-owner', AuthController.login);



// //Update a client/website
// router.put('/owner/:ownerId', authMiddleware, OwnerController.updateOwner);



// //Get a specific client/website
// router.get('/owner/:ownerId', authMiddleware, OwnerController.getOwner);



router.put('/owner/update-password', authMiddleware, verifyTransactionPassword, OwnerController.updatePassword);

export default router;


