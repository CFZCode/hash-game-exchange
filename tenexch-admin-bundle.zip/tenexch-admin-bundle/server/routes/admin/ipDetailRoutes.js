import express from 'express';
import IpDetailController from '../../controller/admin/ipDetailController.js';
import authMiddleware from '../../middleware/authMiddleware.js';

const router = express.Router();

// 🔐 Protected: IP geo lookup for the User History "Detail" modal
router.get('/ip-detail', authMiddleware, IpDetailController.getIpDetail);

export default router;
