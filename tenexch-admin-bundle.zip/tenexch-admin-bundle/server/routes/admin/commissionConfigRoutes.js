import express from 'express';
import authMiddleware from '../../middleware/authMiddleware.js';
import { requireOwner } from '../../middleware/permissionMiddleware.js';
import CommissionConfigController from '../../controller/admin/commissionConfigController.js';

const router = express.Router();

// Sports win commission is owner-only end to end — staff and executives never
// see the screen (admin/src/utils/permissions.js OWNER_ONLY_ROUTES is the
// client mirror) and are refused here regardless.
router.get('/commission-config/sports', authMiddleware, requireOwner, CommissionConfigController.getSportsCommission);
router.post('/commission-config/sports', authMiddleware, requireOwner, CommissionConfigController.saveSportsCommission);
// Save every dirty cell of the grid in one call — the league dimension made
// one-Save-per-cell impractical.
router.post('/commission-config/sports/bulk', authMiddleware, requireOwner, CommissionConfigController.saveSportsCommissionBulk);
// Drop a league override so the cell inherits the sport's default row again.
router.delete('/commission-config/sports', authMiddleware, requireOwner, CommissionConfigController.resetSportsCommission);

export default router;
