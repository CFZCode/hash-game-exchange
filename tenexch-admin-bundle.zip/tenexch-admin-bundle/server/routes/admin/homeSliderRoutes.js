import express from 'express';
import multer from 'multer';
import authMiddleware from '../../middleware/authMiddleware.js';
import { requireOwner } from '../../middleware/permissionMiddleware.js';
import {
    listSliders,
    createSlider,
    updateSlider,
    deleteSlider,
    reorderSliders,
    uploadSliderImage,
} from '../../controller/admin/homeSliderController.js';

const router = express.Router();

// Banner uploads: kept in memory (req.file.buffer) and answered as a base64
// data URL — nothing is ever written to disk or the web root.
const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 5 * 1024 * 1024 },
    fileFilter: (req, file, cb) => {
        if (!file.mimetype.startsWith('image/')) {
            return cb(new Error('Only image files are allowed'));
        }
        cb(null, true);
    },
});

// Multer errors (size/type) become clean 400s instead of a stack trace.
const uploadSingleImage = (req, res, next) => {
    upload.single('image')(req, res, (err) => {
        if (err) return res.status(400).json({ success: false, error: err.message });
        next();
    });
};

// Home Sliders is owner-only end to end — staff and executives never see it.
router.get('/home-slider/list', authMiddleware, requireOwner, listSliders);
router.post('/home-slider/create', authMiddleware, requireOwner, createSlider);
router.post('/home-slider/upload', authMiddleware, requireOwner, uploadSingleImage, uploadSliderImage);
// Must be declared BEFORE '/home-slider/:id', or Express matches 'reorder'
// as an id — casinoManageRoutes.js and carouselRoutes.js order theirs the
// same way for the same reason.
router.put('/home-slider/reorder', authMiddleware, requireOwner, reorderSliders);
router.put('/home-slider/:id', authMiddleware, requireOwner, updateSlider);
router.delete('/home-slider/:id', authMiddleware, requireOwner, deleteSlider);

export default router;
