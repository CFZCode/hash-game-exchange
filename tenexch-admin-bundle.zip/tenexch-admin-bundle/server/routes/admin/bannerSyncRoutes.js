import express from 'express';
const router = express.Router();
import BannerSyncController from '../../controller/admin/bannerSyncController.js';
import authMiddleware from '../../middleware/authMiddleware.js';
import { requireOwner } from '../../middleware/permissionMiddleware.js';

// Auto-update of the carousel + poster from the reference site (every 4 h).
// Shown on the owner-only Carousel page.
router.get('/banner-sync/status', authMiddleware, requireOwner, BannerSyncController.getStatus);
router.post('/banner-sync/run', authMiddleware, requireOwner, BannerSyncController.runNow);

export default router;
