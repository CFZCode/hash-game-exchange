import express from 'express';
const router = express.Router();
import FixturesController from '../../controller/admin/fixturesController.js';
import authMiddleware from '../../middleware/authMiddleware.js';
import { requireBackoffice } from '../../middleware/permissionMiddleware.js';

// Backoffice-wide: the header "Upcoming Fixtures" ticker shows for staff too.
// The Fixtures page itself is owner-only on the admin side.
router.get('/fixtures', authMiddleware, requireBackoffice, FixturesController.getFixtures);

export default router;
