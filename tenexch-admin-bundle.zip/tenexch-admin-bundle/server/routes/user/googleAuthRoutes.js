import express from 'express';
import GoogleAuthController from '../../controller/user/googleAuthController.js';
import AuthMiddleware from '../../middleware/authMiddleware.js';

const router = express.Router();

// Step 1: verify password, hand back the QR + setup code
router.post('/setup', AuthMiddleware, GoogleAuthController.setup);

// Step 2: confirm a code from the app → activates 'google' secure auth
router.post('/enable', AuthMiddleware, GoogleAuthController.enable);

// Step 3: confirm a code from the app → turns secure auth off
router.post('/disable', AuthMiddleware, GoogleAuthController.disable);

export default router;
