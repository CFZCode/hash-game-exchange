import express from 'express';
import AndroidAuthController from '../../controller/user/androidAuthController.js';
import AuthMiddleware from '../../middleware/authMiddleware.js';

const router = express.Router();

// Step 1: the 6-digit pairing code, shown as soon as the Android App tab opens
router.post('/pair', AuthMiddleware, AndroidAuthController.pair);

// Step 2: the PHONE exchanges that code for the TOTP secret.
//
// The only route here without AuthMiddleware, and it has to be: the Secure Auth
// App has no website session, which is the whole point of the pairing code. Its
// guards live in the controller — server-issued single-use code, 10-minute TTL,
// per-IP rate limit — and a claimed secret still cannot switch the account on
// without the logged-in session that calls /enable.
router.post('/claim', AndroidAuthController.claim);

// Manual fallback only — a successful /claim already switches secure auth on.
router.post('/enable', AuthMiddleware, AndroidAuthController.enable);

// Step 4: confirm a code from the app → turns secure auth off
router.post('/disable', AuthMiddleware, AndroidAuthController.disable);

export default router;
