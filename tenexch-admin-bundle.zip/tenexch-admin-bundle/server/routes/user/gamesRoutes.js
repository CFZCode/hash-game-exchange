import express from 'express';
import CricketController from '../../controller/sports/cricket/cricketController.js';
import BannerController from '../../controller/user/bannerController.js';
import CarouselController from '../../controller/admin/carouselController.js';
import PosterController from '../../controller/admin/posterController.js';
import VirtualEventController from '../../controller/user/virtualEventController.js';
import authMiddleware from '../../middleware/authMiddleware.js';
const router = express.Router();

// Dynamic welcome banner (proxied — upstream feed has no CORS headers)
router.get('/banners/welcome', BannerController.getWelcomeBanner);

// Admin-managed homepage carousel (public read)
router.get('/carousel', CarouselController.getPublicCarousels);

// Admin-managed welcome poster link (public read)
router.get('/poster', PosterController.getPublicPoster);

// Virtual games (T5 XI / T10 XI / Virtual Cricket League): resolve a round's
// stream + scorecard urls from the provider. Public read, same as banner/poster.
router.get('/virtual/event-media', VirtualEventController.getEventMedia);
// XI virtual live ball cards + countdown (vendor key stays server-side). Public read.
router.get('/virtual/cricketv-cards', VirtualEventController.getCricketVCards);



// Latest events from AVRKHUB sports feed
router.get('/v1/sports-get_latest_events', CricketController.getLatestEvents);

// Single event detail from AVRKHUB sports feed (gmid & etid required)
router.get('/v1/sports-gamedetailPrivate', CricketController.getGameDetailPrivate);

// POST route for fetching casino data with body parameters
router.post('/cricket/all-data', CricketController.fetchCricketData);
router.get('/cricket/get-all-sports-data', CricketController.GetallSportsdata);
router.post('/cricket/get-sport-data-by-id', CricketController.getSportdetailsById);
router.post('/cricket/get-match-private-data', CricketController.GetMatchPrivateData);
router.post('/cricket/market-list', CricketController.GetMarketList); // admin More Market: stored + live markets

router.post('/cricket/live-stream', CricketController.fetchLiveStream); 
router.post('/cricket/score-card', CricketController.fetchScoreCard);
// Live score summary (the rendered fields, not the iframe URL). GET so it can
// be polled and cached like any other read; one upstream socket serves every
// viewer of a match. See docs/handover/2026-09-08-cricket-score-api.md.
router.get('/cricket/score-summary', CricketController.fetchScoreSummary);
// The score animation page itself, retried until the provider hands back a
// working token. The scorecard iframe loads this. Public read, like the
// scorecard/banner endpoints around it.
router.get('/cricket/score-animation', CricketController.fetchScoreAnimation);
// The scorecard iframe's URL, resolved server-side and returned unused so the
// browser's first load is the token's first use. One hop instead of two — no
// black host page in between.
router.get('/cricket/score-url', CricketController.fetchScoreUrl);
router.get('/all/sports/tree', CricketController.fetchTreeData);
// Same tree, in a decided order (sports: feed order with racing after Tennis;
// leagues: soonest match first). The clients render it as it arrives instead of
// each holding their own list of competition names.
router.get('/all/sports/events', CricketController.fetchSportsEvents);
// router.post('/cricket/place-bet', authMiddleware, CricketController.Placebetdata); // this is not used now,  bet place function inside sports folder
router.post('/cricket/gameresults', CricketController.GetResults);
router.get('/cricket/sports-bets/all', CricketController.getAllSportsBets);
router.get('/cricket/sports-bets/user', authMiddleware, CricketController.getSportsBetsByUserId);

router.get('/cricket/total-stake', CricketController.getTotalStakeOnEvent);

router.get('/cricket/total-stake-live-events', CricketController.getTotalStakeOnLiveAndUpcomingEvents);



router.post('/sports-bets/user', authMiddleware, CricketController.getSportsBetsOfUser); // used by admin to get particular user's bets

router.get('/cricket/wins/user', authMiddleware, CricketController.getWinsByUserId);

//matched bets and open bets

router.get('/cricket/matched-bets/user/event', CricketController.getUserMatchedBetsByEvent);
router.get('/cricket/open-bets/user/event', CricketController.getUserOpenBetsForEvent); // Replaced with fresh implementation
router.get('/cricket/user-open-bets', CricketController.getUserOpenBetsForEvent); // New explicit route
router.get('/cricket/user-open-bets-grouped', CricketController.getUserOpenBetsGrouped); // { matchedBets, unmatchedBets } split

// for admin

router.get('/cricket/matched-bets/all', CricketController.getMatchedBetsByEvent); //total bets on particular event - admin
router.get('/cricket/open-bets/all', CricketController.getOpenBetsByEvent);
// router.get('/cricket/all-time-credit/user', authMiddleware, CricketController.getAllTimeCreditByUserId);

// Protected route: Logout
// router.post('/logout', authMiddleware, AuthController.logout);

export default router;

