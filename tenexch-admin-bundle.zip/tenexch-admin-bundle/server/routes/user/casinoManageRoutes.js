import express from 'express';
import { listPublicGames, serveGameImage } from '../../controller/admin/casinoManageController.js';

const router = express.Router();

// Public: the frontend's VIP / Virtual / Premium tabs, plus the enabled flag
// so the main grid can hide a managed game the owner switched off.
// min_balance rides along so the tile can gate entry client-side (the table
// page re-checks on top).
router.get('/casino-manage/games', listPublicGames);

// Tile art for rows storing base64 — a plain long-cached image response, so
// list payloads stay light no matter how much art the owner uploads.
router.get('/casino-manage/img/:id', serveGameImage);

export default router;
