import express from 'express';
import CasinoController from '../../controller/casino/casinoController.js';
import authMiddleware from '../../middleware/authMiddleware.js';
const router = express.Router();


// POST route for fetching casino data with body parameters
router.post('/casino/all-data', CasinoController.fetchAllData);

router.post('/casino/last-results', CasinoController.fetchLastResults);

router.post('/casino/detail-results', CasinoController.fetchDetailResults);

// SuperOver two-innings scorecard (initial/warm-start read; live updates arrive
// over the `superoverScorecard` socket event). Public, like all-data.
router.post('/casino/superover-scorecard', CasinoController.fetchSuperOverScorecard);

router.post('/casino/result-report', CasinoController.fetchResultReport);

// Both bet endpoints move money — token identity is mandatory (see controller;
// the body's userId is ignored).
router.post('/casino/placebet', authMiddleware, CasinoController.placeBet);
router.post('/casino/undobet', authMiddleware, CasinoController.undoBet);

router.post('/casino/mybets', CasinoController.getUserBets);
router.post('/casino/bet-history', CasinoController.UserBets);






// Protected route: Logout
// router.post('/logout', authMiddleware, AuthController.logout);

export default router;