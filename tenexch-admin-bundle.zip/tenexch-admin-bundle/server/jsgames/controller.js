import crypto from 'crypto';
import sequelize from '../config/db.js';
import GameResponseHandler from './gameResposneHandler.js';
import CryptoJS from 'crypto-js';
import NodeCache from 'node-cache';
import { Op } from 'sequelize';

// Sequelize Models
import Wallet from '../model/admin/Wallet.js';
import JSGame from './models/JSGame.js';
import JSGameTransaction from './models/JSGameTransaction.js';
import PrioritizedGame from './models/PrioritizedGame.js';
import PrioritizedCategory from './models/PrioritizedCategory.js';
import CategoryMembership from './models/CategoryMembership.js';
import SlotProvider from './models/SlotProvider.js';
import SlotProviderCategory from './models/SlotProviderCategory.js';
import JSGameSession from '../model/user/JSGameSession.js';
import CreditsLedger from '../model/user/CreditsLedger.js';
import ThirdPartyLimitService from '../services/ThirdPartyLimitService.js';

const cache = new NodeCache({ stdTTL: 300, checkperiod: 60 });

const AGENCY_CONFIG = {
  agency_uid: 'b96581ad0785ff9f86c960def63aee4b',
  aes_key: '8ce9295ab6786ef6e4bd8d07eda4ce81',
  player_prefix: 'h24e9e',
  server_url: 'https://huidu.bet'
};

// --- Game Categories ---
// game_type values in js_games are vendor-supplied and inconsistent
// ("Slot", "Slots", "Video Slot", "Crash Game", ...), so each category is
// defined as a set of ILIKE patterns over game_type.
const GAME_CATEGORIES = {
  crash: ['%crash%'],
  lottery: ['%lott%', '%keno%', '%bingo%', '%scratch%'],
  slot: ['%slot%'],
  fantasy: ['%fanta%', '%sport%', '%virtual%'],
};

// A game belongs to a category if its game_type matches a pattern OR it was
// manually pinned into the category (category_memberships). Async because the
// manual set is read from the DB; every call site awaits it.
async function buildCategoryFilter(category) {
  const patterns = GAME_CATEGORIES[category];
  if (!patterns) return null;
  const or = patterns.map(p => ({ game_type: { [Op.iLike]: p } }));
  const membership = await CategoryMembership.findOne({ where: { category } });
  const manualIds = parseGameIds(membership?.game_ids);
  if (manualIds.length) or.push({ id: { [Op.in]: manualIds } });
  return { [Op.or]: or };
}

// Attach the grouping an admin cares about to one game or an array of them:
// `manual_categories` (categories the game was pinned into) and `slot_provider`
// (the provider group holding it, null when none). Accepts Sequelize instances,
// returns plain objects so the extra fields survive JSON serialization.
async function withGroupInfo(games) {
  const list = Array.isArray(games) ? games : [games];

  const memberships = await CategoryMembership.findAll();
  const manualByGame = new Map();
  for (const m of memberships) {
    for (const gid of parseGameIds(m.game_ids)) {
      if (!manualByGame.has(gid)) manualByGame.set(gid, []);
      manualByGame.get(gid).push(m.category);
    }
  }

  // A game can be grouped once per category — in a slot group and a fantasy
  // group at the same time — so this is a list, keyed by category.
  const groupsByGame = new Map();
  for (const p of await SlotProvider.findAll()) {
    for (const gid of parseGameIds(p.game_ids)) {
      if (!groupsByGame.has(gid)) groupsByGame.set(gid, []);
      groupsByGame.get(gid).push({ category: p.category, provider: p.provider, label: p.label, tab: null });
    }
  }
  for (const c of await SlotProviderCategory.findAll()) {
    for (const gid of parseGameIds(c.game_ids)) {
      const entry = (groupsByGame.get(gid) || []).find(e => e.provider === c.provider);
      if (entry) entry.tab = { slug: c.slug, label: c.label };
    }
  }

  const out = list.map(g => {
    const groups = groupsByGame.get(g.id) || [];
    const slot = groups.find(e => e.category === 'slot') || null;
    return {
      ...(typeof g.toJSON === 'function' ? g.toJSON() : g),
      manual_categories: manualByGame.get(g.id) || [],
      provider_groups: groups,
      // Kept for the slot-era clients documented in slot-provider-groups.md
      slot_provider: slot ? { provider: slot.provider, label: slot.label } : null,
      slot_category: slot?.tab ? { provider: slot.provider, ...slot.tab } : null,
    };
  });
  return Array.isArray(games) ? out : out[0];
}

// --- Slot provider groups ---
// Inside the slot category games are further grouped by provider (Jili, Amigo,
// Red Tiger, ...). A slot game belongs to at most one group; the flat slot
// queue is the groups concatenated in provider order, with any still-ungrouped
// prioritized games kept at the tail.
const UNGROUPED = 'ungrouped';

function slugifyProvider(label) {
  return String(label || '')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60);
}

// Every category can be split into provider groups; `slot` was simply the first
// to use it. A category with no groups behaves exactly as it always did — one
// flat priority queue — so this is inert until an owner creates the first group.
function isKnownCategory(category) {
  return Object.prototype.hasOwnProperty.call(GAME_CATEGORIES, category);
}

// The category a provider/tab request is for. Slot-era routes pin it to 'slot'.
function requestCategory(req) {
  return req.params.category || 'slot';
}

async function loadProviders(category) {
  return SlotProvider.findAll({
    where: { category },
    order: [['sort_order', 'ASC'], ['provider', 'ASC']],
  });
}

// Rebuild prioritized_categories.slot from the provider groups so the player
// app keeps seeing one ordered slot queue. Games that are prioritized but not
// in any group keep their relative order at the end of the queue.
async function rebuildCategoryQueue(category) {
  const providers = await loadProviders(category);
  const ordered = [];
  const seen = new Set();
  for (const p of providers) {
    for (const id of parseGameIds(p.game_ids)) {
      if (!seen.has(id)) { seen.add(id); ordered.push(id); }
    }
  }

  const [queue] = await PrioritizedCategory.findOrCreate({
    where: { category },
    defaults: { category, game_ids: '' },
  });
  for (const id of parseGameIds(queue.game_ids)) {
    if (!seen.has(id)) { seen.add(id); ordered.push(id); }
  }

  await queue.update({ game_ids: ordered.join(',') });
  return ordered;
}

// Prioritized slot games that no provider group claims.
async function ungroupedIds(category) {
  const providers = await loadProviders(category);
  const grouped = new Set(providers.flatMap(p => parseGameIds(p.game_ids)));
  const queue = await PrioritizedCategory.findOne({ where: { category } });
  return parseGameIds(queue?.game_ids).filter(id => !grouped.has(id));
}

// Does this category use provider groups at all? Everything that behaves
// differently for a grouped category asks this, so nothing is hardcoded to slot.
async function hasProviderGroups(category) {
  return (await SlotProvider.count({ where: { category } })) > 0;
}

// --- Sub-categories inside a provider group ---
// One level below providers: Jili is Slot Game / Table Game / Fish Game / Crash
// Game, Red Tiger is New Slots / 3REEL…7REEL. Same two rules as the level above:
// a game sits in at most one category of its provider, and the provider's flat
// game_ids is derived — its categories concatenated in tab order, then whatever
// the group holds that no category claims ("uncategorized", kept at the tail).
const UNCATEGORIZED = 'uncategorized';

async function loadProviderCategories(provider) {
  return SlotProviderCategory.findAll({
    where: { provider },
    order: [['sort_order', 'ASC'], ['id', 'ASC']],
  });
}

// Resolve a :provider path segment: the slug (`red-tiger`) or the numeric id
// the player-facing /slot/:id URL carries (`24`).
async function resolveProvider(category, param) {
  const key = String(param ?? '').trim();
  if (!key) return null;
  const bySlug = await SlotProvider.findOne({ where: { category, provider: key } });
  if (bySlug) return bySlug;
  if (!/^\d+$/.test(key)) return null;
  return SlotProvider.findOne({ where: { category, ext_id: parseInt(key) } });
}

// Make sure the provider holds every game its tabs claim, without disturbing the
// order it already has: newly claimed games are appended, nothing is moved.
//
// The provider's flat list is deliberately NOT re-derived from the tabs. It is
// the hand-curated slot order the owner built before tabs existed and it is what
// the current app listing reads, so tabbing a group must not re-block it —
// splitting 190 Jili games into "116 tabbed then 74 untabbed" would shuffle
// two thirds of the provider. Tab order orders the tab page; provider order
// orders the flat listing; the two are independent on purpose.
async function rebuildProviderGameIds(providerRow) {
  const categories = await loadProviderCategories(providerRow.provider);
  const current = parseGameIds(providerRow.game_ids);
  if (categories.length === 0) return current;

  const held = new Set(current);
  const ordered = [...current];
  for (const category of categories) {
    for (const id of parseGameIds(category.game_ids)) {
      if (!held.has(id)) { held.add(id); ordered.push(id); }
    }
  }

  const next = ordered.join(',');
  if (next !== (providerRow.game_ids || '')) await providerRow.update({ game_ids: next });
  return ordered;
}

// Games the provider group holds that none of its categories claim.
async function uncategorizedIds(providerRow, categories = null) {
  const cats = categories || await loadProviderCategories(providerRow.provider);
  const claimed = new Set(cats.flatMap(c => parseGameIds(c.game_ids)));
  return parseGameIds(providerRow.game_ids).filter(id => !claimed.has(id));
}

// Pull games out of every category (optionally sparing one) — one game, one tab.
async function releaseFromTabs(category, ids, { exceptId = null } = {}) {
  if (!ids.length) return;
  const drop = new Set(ids);
  // Scoped to this category: a game can legitimately sit in a slot tab AND a
  // fantasy tab, it just cannot sit in two tabs of the same category.
  for (const tab of await SlotProviderCategory.findAll({ where: { category } })) {
    if (exceptId !== null && tab.id === exceptId) continue;
    const current = parseGameIds(tab.game_ids);
    const kept = current.filter(id => !drop.has(id));
    if (kept.length !== current.length) await tab.update({ game_ids: kept.join(',') });
  }
}

// Trim a provider's categories to the games the group still holds, so a game
// dropped from the group cannot be resurrected by the next rebuild.
async function pruneProviderCategories(providerRow) {
  const held = new Set(parseGameIds(providerRow.game_ids));
  for (const category of await loadProviderCategories(providerRow.provider)) {
    const current = parseGameIds(category.game_ids);
    const kept = current.filter(id => held.has(id));
    if (kept.length !== current.length) await category.update({ game_ids: kept.join(',') });
  }
}

// Move games into this provider group: out of every other group (and that
// group's categories), appended here if the group does not have them yet.
async function claimGamesForProvider(providerRow, ids) {
  if (!ids.length) return;
  const claimed = new Set(ids);
  for (const other of await loadProviders(providerRow.category)) {
    if (other.provider === providerRow.provider) continue;
    const current = parseGameIds(other.game_ids);
    const kept = current.filter(id => !claimed.has(id));
    if (kept.length !== current.length) {
      await other.update({ game_ids: kept.join(',') });
      await pruneProviderCategories(other);
    }
  }
  const own = parseGameIds(providerRow.game_ids);
  const missing = ids.filter(id => !own.includes(id));
  if (missing.length) await providerRow.update({ game_ids: [...own, ...missing].join(',') });
}

// Reject anything outside the category before it can enter a group or a tab.
async function rejectIdsOutsideCategory(category, ids) {
  if (!ids.length) return [];
  const found = await JSGame.findAll({
    where: { id: { [Op.in]: ids }, ...(await buildCategoryFilter(category)) },
    attributes: ['id'],
    raw: true,
  });
  const foundIds = new Set(found.map(g => g.id));
  return ids.filter(id => !foundIds.has(id));
}

// Fetch games by id, returned in the exact order of the id list.
async function findGamesInOrder(ids, extraWhere = {}) {
  if (!ids.length) return [];
  return JSGame.findAll({
    where: { ...extraWhere, id: { [Op.in]: ids } },
    order: sequelize.literal(`CASE ${ids.map((id, i) => `WHEN id = ${id} THEN ${i}`).join(' ')} ELSE ${ids.length} END`),
  });
}

function parseGameIds(gameIdsStr) {
  if (!gameIdsStr) return [];
  return gameIdsStr
    .split(',')
    .map(id => parseInt(id.trim()))
    .filter(id => Number.isInteger(id));
}

// Priority-queue pagination: page 1 serves the prioritized games (in queue
// order) first, then fills remaining slots with regular games; later pages
// continue through the regular games with the offset adjusted for how many
// prioritized games were already served.
async function fetchGamesWithPriority({ baseWhere, prioritizedGameIds, pageNum, perPageNum, offset }) {
  if (!prioritizedGameIds.length) {
    return JSGame.findAll({ where: baseWhere, order: [['id', 'ASC']], limit: perPageNum, offset });
  }

  if (pageNum === 1) {
    const prioritizedGames = await JSGame.findAll({
      where: { ...baseWhere, id: { [Op.in]: prioritizedGameIds } },
      order: sequelize.literal(`CASE ${prioritizedGameIds.map((id, i) => `WHEN id = ${id} THEN ${i}`).join(' ')} ELSE ${prioritizedGameIds.length} END`),
    });
    const remainingSlots = perPageNum - prioritizedGames.length;
    if (remainingSlots > 0) {
      const regularGames = await JSGame.findAll({
        where: { ...baseWhere, id: { [Op.notIn]: prioritizedGameIds } },
        order: [['id', 'ASC']], limit: remainingSlots,
      });
      return [...prioritizedGames, ...regularGames];
    }
    return prioritizedGames.slice(0, perPageNum);
  }

  const existingPrioritized = await JSGame.findAll({
    where: { ...baseWhere, id: { [Op.in]: prioritizedGameIds } },
    attributes: ['id'],
  });
  const existingIds = existingPrioritized.map(g => g.id);
  const adjustedOffset = offset + existingIds.length - perPageNum;
  return JSGame.findAll({
    where: { ...baseWhere, id: { [Op.notIn]: existingIds } },
    order: [['id', 'ASC']], limit: perPageNum, offset: Math.max(0, adjustedOffset),
  });
}

// --- Crypto Helpers ---

function encryptPayload(payload, key) {
  const keyBuffer = Buffer.from(key, 'utf8');
  const cipher = crypto.createCipheriv('aes-256-ecb', keyBuffer, Buffer.alloc(0));
  let encrypted = cipher.update(JSON.stringify(payload), 'utf8', 'base64');
  encrypted += cipher.final('base64');
  return encrypted;
}

function decryptPayload(encryptedPayload, key) {
  const keyWordArray = CryptoJS.enc.Utf8.parse(key);
  const decryptedWordArray = CryptoJS.AES.decrypt(encryptedPayload, keyWordArray, {
    mode: CryptoJS.mode.ECB,
    padding: CryptoJS.pad.Pkcs7
  });
  const decryptedString = decryptedWordArray.toString(CryptoJS.enc.Utf8);
  return JSON.parse(decryptedString);
}

// --- Route Handlers ---

async function getGameLaunchURL(req, res) {
  const {
    game_uid, user_id, credit_amount = '50', currency_code,
    language = 'en', home_url = '', callback_url = ''
  } = req.body;

  const allowedCurrencies = ['INR', 'BDT', 'USDT'];
  if (!allowedCurrencies.includes(currency_code)) {
    return res.status(400).json(
      GameResponseHandler.handleErrorResponse(10009, 'Invalid currency. Allowed currencies are INR, BDT, USDT')
    );
  }

  try {
    const game = await JSGame.findOne({ where: { game_uid, is_active: true } });
    if (!game) {
      return res.status(404).json(GameResponseHandler.handleErrorResponse(10008));
    }

    const payload = {
      agency_uid: AGENCY_CONFIG.agency_uid,
      member_account: `${AGENCY_CONFIG.player_prefix}_${currency_code}_${user_id}`,
      game_uid, timestamp: Date.now().toString(),
      credit_amount, currency_code, language, home_url, callback_url
    };

    const encryptedPayload = encryptPayload(payload, AGENCY_CONFIG.aes_key);

    const apiResponse = await fetch(`${AGENCY_CONFIG.server_url}/game/v1`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        agency_uid: AGENCY_CONFIG.agency_uid,
        timestamp: Date.now().toString(),
        payload: encryptedPayload
      })
    });

    const responseData = await apiResponse.json();
    const processedResponse = GameResponseHandler.processGameServerResponse(responseData);
    if (!processedResponse.success) {
      return res.status(400).json(processedResponse);
    }

    const sessionToken = crypto.randomBytes(16).toString('hex');
    const session = await JSGameSession.create({
      user_id, game_uid, session_token: sessionToken,
      launch_url: processedResponse.payload.game_launch_url
    });

    return res.json(
      GameResponseHandler.handleSuccessResponse(responseData, {
        game_launch_url: processedResponse.payload.game_launch_url,
        session_token: sessionToken,
        session: session.toJSON()
      })
    );
  } catch (err) {
    console.error('Game launch error:', err);
    return res.status(500).json(GameResponseHandler.handleErrorResponse(10000));
  }
}

async function processBetCallback(req, res) {
  const { payload } = req.body;

  try {
    const decryptedData = decryptPayload(payload, AGENCY_CONFIG.aes_key);
    if (!decryptedData || !decryptedData.member_account) {
      throw new Error('invalid decrypted payload');
    }

    const parts = decryptedData.member_account.split('_');
    const userId = parts[2];
    if (!userId) throw new Error('cannot extract user id from member_account');

    const betAmount = Number(decryptedData.bet_amount || 0);
    const winAmount = Number(decryptedData.win_amount || 0);
    const currencyRaw = (decryptedData.currency_code || '').toLowerCase();
    if (!/^[a-z_]+$/.test(currencyRaw)) throw new Error('invalid currency code');

    let transactionType;
    if (betAmount > 0 && winAmount === 0) transactionType = 'bet';
    else if (betAmount === 0 && winAmount > 0) transactionType = 'win';
    else if (betAmount === 0 && winAmount === 0) transactionType = 'loss';
    else transactionType = 'adjustment';

    // Owner ka Third Party Game Limit — per-bet stake cap jo hierarchy se
    // inherit hota hai (services/ThirdPartyLimitService.js), wahi jo v2
    // callback me lagta hai. Sirf bet leg par; koi bhi callback jo player ko
    // paisa deta hai use kabhi block nahi karte. Service fail-open hai
    // (error → 0 = no limit), so ye betting ko down nahi kar sakta.
    if (betAmount > 0 && winAmount <= 0) {
      const maxStake = await ThirdPartyLimitService.getEffectiveLimit(userId);
      if (maxStake > 0 && betAmount > maxStake) {
        console.warn('Third-party bet limit exceeded', { userId, game_uid: decryptedData.game_uid, betAmount, maxStake });
        return res.status(400).json(
          GameResponseHandler.handleErrorResponse(10025, `Bet limit exceeded. Max allowed per bet is ${maxStake}`)
        );
      }
    }

    const result = await sequelize.transaction(async (t) => {
      await JSGameTransaction.create({
        user_id: userId, game_uid: decryptedData.game_uid,
        transaction_type: transactionType,
        amount: transactionType === 'win' ? winAmount : betAmount,
        currency: currencyRaw, transaction_status: 'processed',
        external_transaction_id: decryptedData.game_round,
        serial_number: decryptedData.serial_number,
        additional_data: decryptedData
      }, { transaction: t });

      const wallet = await Wallet.findOne({
        where: { user_id: userId }, transaction: t, lock: t.LOCK.UPDATE,
      });
      if (!wallet) throw new Error('user wallet not found');

      const currentBalance = parseFloat(wallet.cash || 0);
      const newBalance = Number((currentBalance - betAmount + winAmount).toFixed(2));
      await wallet.update({ cash: newBalance }, { transaction: t });

      return { newBalance };
    });

    // Credits Ledger entry — only on win/loss settlement, not on bet placement
    const netChange = -betAmount + winAmount;
    const isSettled = transactionType === 'win' || transactionType === 'loss' || transactionType === 'bet_result';
    if (!isSettled) {
      // Skip ledger for bet placement, adjustments, etc.
    } else try {
      const isWin = netChange > 0;
      const isLoss = netChange < 0;

      // Fetch game details for ledger
      const gameInfo = await JSGame.findOne({
        where: { game_uid: decryptedData.game_uid || '' },
        attributes: ['game_name', 'vendor'],
      });
      const gameName = gameInfo?.game_name || decryptedData.game_uid || 'unknown';
      const providerName = gameInfo?.vendor || 'unknown';

     
    } catch (ledgerErr) {
      console.error('Credits ledger entry failed', ledgerErr);
    }

    const responsePayload = { credit_amount: String(result.newBalance), timestamp: Date.now().toString() };
    const encryptedResponsePayload = encryptPayload(responsePayload, AGENCY_CONFIG.aes_key);

    res.json({ code: 0, msg: '', payload: encryptedResponsePayload });
  } catch (error) {
    console.error('processBetCallback error:', error);
    res.status(500).json(GameResponseHandler.handleErrorResponse(1, 'Bet processing failed'));
  }
}

async function processGameTransfer(req, res) {
  const { user_id, game_uid, credit_amount, transfer_type, currency_code } = req.body;

  try {
    const payload = {
      agency_uid: AGENCY_CONFIG.agency_uid,
      member_account: `${AGENCY_CONFIG.player_prefix}_${currency_code}_${user_id}`,
      game_uid, timestamp: Date.now().toString(),
      credit_amount: transfer_type === 'deposit' ? credit_amount : `-${credit_amount}`,
      transfer_id: crypto.randomBytes(8).toString('hex')
    };

    const encryptedPayload = encryptPayload(payload, AGENCY_CONFIG.aes_key);

    const apiResponse = await fetch(`${AGENCY_CONFIG.server_url}/game/v2`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        agency_uid: AGENCY_CONFIG.agency_uid, timestamp: Date.now().toString(), payload: encryptedPayload
      })
    });

    const responseData = await apiResponse.json();
    const processedResponse = GameResponseHandler.processGameServerResponse(responseData);

    await JSGameTransaction.create({
      user_id, game_uid, transaction_type: transfer_type, amount: credit_amount,
      currency: 'USD', transaction_status: processedResponse.success ? 'completed' : 'failed',
      external_transaction_id: payload.transfer_id,
    });

    res.json(processedResponse);
  } catch (error) {
    GameResponseHandler.logErrorDetails('processGameTransfer', error, { user_id, game_uid });
    res.status(500).json(GameResponseHandler.handleErrorResponse(10004, 'Transfer processing failed'));
  }
}

async function getTransactionRecords(req, res) {
  const { from_date, to_date, page_no = 1, page_size = 30 } = req.body;

  try {
    const payload = {
      agency_uid: AGENCY_CONFIG.agency_uid, timestamp: Date.now().toString(),
      from_date: new Date(from_date).getTime(), to_date: new Date(to_date).getTime(),
      page_no, page_size
    };

    const encryptedPayload = encryptPayload(payload, AGENCY_CONFIG.aes_key);

    const apiResponse = await fetch(`${AGENCY_CONFIG.server_url}/game/transaction/list`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        agency_uid: AGENCY_CONFIG.agency_uid, timestamp: Date.now().toString(), payload: encryptedPayload
      })
    });

    const responseData = await apiResponse.json();
    const processedResponse = GameResponseHandler.processGameServerResponse(responseData);

    if (processedResponse.success && processedResponse.payload.records) {
      for (const record of processedResponse.payload.records) {
        await JSGameTransaction.findOrCreate({
          where: { external_transaction_id: record.transaction_id },
          defaults: {
            user_id: record.member_account.split('_')[2], game_uid: record.game_uid,
            transaction_type: 'transaction', amount: record.transfer_amount,
            currency: record.currency,
            transaction_status: record.transfer_status === 1 ? 'completed' : 'failed',
            serial_number: record.serial_number, additional_data: record
          }
        });
      }
    }

    res.json(processedResponse);
  } catch (error) {
    GameResponseHandler.logErrorDetails('getTransactionRecords', error);
    res.status(500).json(GameResponseHandler.handleErrorResponse(10004, 'Error fetching transaction records'));
  }
}

async function getActiveGames(req, res) {
  try {
    const { vendor, page = 1, per_page = 20, game_type, category, provider } = req.query;
    const pageNum = Math.max(1, parseInt(page));
    const perPageNum = Math.min(100, Math.max(1, parseInt(per_page)));
    const offset = (pageNum - 1) * perPageNum;

    if (category && !GAME_CATEGORIES[category]) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(
        10006, `Invalid category. Allowed categories: ${Object.keys(GAME_CATEGORIES).join(', ')}`
      ));
    }

    // `provider` groups the slot category further (jili, amigo, red-tiger, ...)
    let providerRow = null;
    if (provider) {
      if (!category) {
        return res.status(400).json(GameResponseHandler.handleErrorResponse(
          10006, 'provider requires a category'
        ));
      }
      providerRow = await resolveProvider(category, provider);
      if (!providerRow) {
        return res.status(404).json(GameResponseHandler.handleErrorResponse(
          10008, `Unknown provider '${provider}' in category '${category}'`));
      }
    }

    const cacheKey = `active_games_${vendor || 'all'}_${game_type || 'all'}_${category || 'all'}_${provider || 'all'}_${pageNum}_${perPageNum}`;
    const cachedResult = cache.get(cacheKey);
    if (cachedResult) {
      return res.json(GameResponseHandler.handleSuccessResponse({ payload: cachedResult, meta: { cached: true } }));
    }

    const where = { is_active: true };
    if (vendor) where.vendor = vendor;
    if (game_type) where.game_type = { [Op.iLike]: `%${game_type}%` };
    if (category) Object.assign(where, await buildCategoryFilter(category));

    // A provider group is a fixed, ordered list — serve exactly it, no filler.
    if (providerRow) {
      const groupIds = parseGameIds(providerRow.game_ids);
      // Drop ids the filters exclude (inactive, wrong vendor) before paginating,
      // so page size and total stay honest.
      const matching = groupIds.length
        ? new Set((await JSGame.findAll({ where: { ...where, id: { [Op.in]: groupIds } }, attributes: ['id'], raw: true })).map(g => g.id))
        : new Set();
      const visibleIds = groupIds.filter(id => matching.has(id));
      const pageIds = visibleIds.slice(offset, offset + perPageNum);
      const response = {
        games: await findGamesInOrder(pageIds),
        pagination: {
          current_page: pageNum, per_page: perPageNum,
          total: visibleIds.length, total_pages: Math.ceil(visibleIds.length / perPageNum),
        },
        category,
        provider: { provider: providerRow.provider, label: providerRow.label },
      };
      cache.set(cacheKey, response);
      return res.json(GameResponseHandler.handleSuccessResponse({ payload: response, meta: { cached: false } }));
    }

    const total = await JSGame.count({ where });
    const totalPages = Math.ceil(total / perPageNum);

    // Priority queue: category queue wins when a category is requested,
    // otherwise fall back to the per-vendor queue.
    let prioritizedGameIds = [];
    if (category) {
      const prioritized = await PrioritizedCategory.findOne({ where: { category } });
      prioritizedGameIds = parseGameIds(prioritized?.game_ids);
    } else if (vendor) {
      const prioritized = await PrioritizedGame.findOne({ where: { vendor } });
      prioritizedGameIds = parseGameIds(prioritized?.game_ids);
    }

    const games = await fetchGamesWithPriority({
      baseWhere: where, prioritizedGameIds, pageNum, perPageNum, offset,
    });

    const response = {
      games,
      pagination: { current_page: pageNum, per_page: perPageNum, total, total_pages: totalPages },
      ...(category ? { category } : {}),
    };
    cache.set(cacheKey, response);

    return res.json(GameResponseHandler.handleSuccessResponse({ payload: response, meta: { cached: false } }));
  } catch (error) {
    GameResponseHandler.logErrorDetails('getActiveGames', error);
    res.status(500).json(GameResponseHandler.handleErrorResponse(10004, 'Error fetching game list'));
  }
}

async function getGameCategories(req, res) {
  try {
    const cacheKey = 'game_categories';
    const cachedResult = cache.get(cacheKey);
    if (cachedResult) {
      return res.json(GameResponseHandler.handleSuccessResponse({ payload: cachedResult, meta: { cached: true } }));
    }

    const categories = [];
    for (const category of Object.keys(GAME_CATEGORIES)) {
      const total = await JSGame.count({ where: { is_active: true, ...(await buildCategoryFilter(category)) } });
      const prioritized = await PrioritizedCategory.findOne({ where: { category } });
      categories.push({
        category,
        total_games: total,
        prioritized_count: parseGameIds(prioritized?.game_ids).length,
      });
    }

    const response = { categories };
    cache.set(cacheKey, response);
    return res.json(GameResponseHandler.handleSuccessResponse({ payload: response, meta: { cached: false } }));
  } catch (error) {
    GameResponseHandler.logErrorDetails('getGameCategories', error);
    res.status(500).json(GameResponseHandler.handleErrorResponse(10004, 'Error fetching game categories'));
  }
}

async function getCategoryPriority(req, res) {
  try {
    const { category } = req.params;
    if (!GAME_CATEGORIES[category]) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(
        10006, `Invalid category. Allowed categories: ${Object.keys(GAME_CATEGORIES).join(', ')}`
      ));
    }

    const prioritized = await PrioritizedCategory.findOne({ where: { category } });
    const gameIds = parseGameIds(prioritized?.game_ids);

    let games = [];
    if (gameIds.length > 0) {
      games = await JSGame.findAll({
        where: { id: { [Op.in]: gameIds } },
        order: sequelize.literal(`CASE ${gameIds.map((id, i) => `WHEN id = ${id} THEN ${i}`).join(' ')} ELSE ${gameIds.length} END`),
      });
    }

    return res.json(GameResponseHandler.handleSuccessResponse({
      payload: { category, game_ids: gameIds, games }
    }));
  } catch (error) {
    GameResponseHandler.logErrorDetails('getCategoryPriority', error);
    res.status(500).json(GameResponseHandler.handleErrorResponse(10004, 'Error fetching category priority'));
  }
}

async function setCategoryPriority(req, res) {
  try {
    const { category } = req.params;
    const { game_ids } = req.body;

    // The slot queue is derived from the provider groups — editing it directly
    // would be overwritten on the next group save.
    // A category that uses provider groups derives its queue from them, so
    // writing the flat list directly would be overwritten on the next group
    // save. Categories with no groups stay directly editable, as they always were.
    if (await hasProviderGroups(category)) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(
        10006, `The ${category} queue is built from provider groups — use /admin/category/${category}/providers/:provider/games`
      ));
    }

    if (!GAME_CATEGORIES[category]) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(
        10006, `Invalid category. Allowed categories: ${Object.keys(GAME_CATEGORIES).join(', ')}`
      ));
    }

    // Accept either an array of ids or a comma-separated string
    const gameIds = Array.isArray(game_ids)
      ? game_ids.map(id => parseInt(id)).filter(id => Number.isInteger(id))
      : parseGameIds(game_ids);

    if (gameIds.length > 0) {
      const found = await JSGame.findAll({
        where: { id: { [Op.in]: gameIds }, ...(await buildCategoryFilter(category)) },
        attributes: ['id'],
      });
      const foundIds = new Set(found.map(g => g.id));
      const invalid = gameIds.filter(id => !foundIds.has(id));
      if (invalid.length > 0) {
        return res.status(400).json(GameResponseHandler.handleErrorResponse(
          10007, `Game ids not found in category '${category}': ${invalid.join(', ')}`
        ));
      }
    }

    const [record, created] = await PrioritizedCategory.findOrCreate({
      where: { category },
      defaults: { category, game_ids: gameIds.join(',') },
    });
    if (!created) {
      await record.update({ game_ids: gameIds.join(',') });
    }

    cache.flushAll();

    return res.json(GameResponseHandler.handleSuccessResponse({
      payload: { category, game_ids: gameIds }
    }));
  } catch (error) {
    GameResponseHandler.logErrorDetails('setCategoryPriority', error);
    res.status(500).json(GameResponseHandler.handleErrorResponse(10004, 'Error setting category priority'));
  }
}

async function searchGames(req, res) {
  try {
    let { keyword = '', page = 1, per_page = 20, vendor = null } = req.query;
    keyword = keyword.trim().toLowerCase();
    const pageNum = Math.max(1, parseInt(page));
    const perPageNum = Math.min(50, Math.max(1, parseInt(per_page)));
    const offset = (pageNum - 1) * perPageNum;

    const cacheKey = `games_search_${keyword}_${vendor || 'all'}_${pageNum}_${perPageNum}`;
    const cachedResult = cache.get(cacheKey);
    if (cachedResult) {
      return res.json(GameResponseHandler.handleSuccessResponse({ payload: cachedResult, meta: { cached: true } }));
    }

    const where = { is_active: true };
    if (vendor) where.vendor = vendor;
    if (keyword) {
      where[Op.or] = [
        { game_name: { [Op.iLike]: `%${keyword}%` } },
        { vendor: { [Op.iLike]: `%${keyword}%` } },
        { game_type: { [Op.iLike]: `%${keyword}%` } },
      ];
    }

    const { count: total, rows: games } = await JSGame.findAndCountAll({
      where, order: [['id', 'ASC']], limit: perPageNum, offset,
    });
    const totalPages = Math.ceil(total / perPageNum);

    const response = {
      games,
      pagination: { current_page: pageNum, per_page: perPageNum, total, total_pages: totalPages },
      meta: { query: keyword, searchFields: ['game_name', 'vendor', 'game_type'] }
    };
    cache.set(cacheKey, response);

    res.json(GameResponseHandler.handleSuccessResponse({ payload: response, meta: { cached: false } }));
  } catch (error) {
    GameResponseHandler.logErrorDetails('searchGames', error);
    res.status(500).json(GameResponseHandler.handleErrorResponse(10005, 'Error searching games'));
  }
}

// --- Admin: full catalog management ---

// Fields an admin may edit on a game. game_uid, vendor and id are identity —
// they come from the provider feed and must not be editable.
const EDITABLE_GAME_FIELDS = ['game_name', 'game_icon', 'game_type', 'description', 'is_active'];

async function listAdminGames(req, res) {
  try {
    const { keyword = '', vendor, game_type, category, is_active, slot_provider, page = 1, per_page = 20 } = req.query;
    const pageNum = Math.max(1, parseInt(page));
    const perPageNum = Math.min(100, Math.max(1, parseInt(per_page)));
    const offset = (pageNum - 1) * perPageNum;

    if (category && !GAME_CATEGORIES[category]) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(
        10006, `Invalid category. Allowed categories: ${Object.keys(GAME_CATEGORIES).join(', ')}`
      ));
    }

    // Unlike the public listing, admins see inactive games unless filtered
    const where = {};
    if (vendor) where.vendor = vendor;
    if (game_type) where.game_type = { [Op.iLike]: `%${game_type}%` };
    if (is_active === 'true') where.is_active = true;
    if (is_active === 'false') where.is_active = false;
    if (category) Object.assign(where, await buildCategoryFilter(category));

    // Filter by provider group: a slug, `ungrouped` (in the slot queue but in no
    // group) or `none` (in no group at all).
    if (slot_provider) {
      // Which category's groups to filter against: the one being browsed, or
      // slot when the catalog tab is open (it has no category of its own).
      const groupCategory = category && isKnownCategory(category) ? category : 'slot';
      if (slot_provider === 'none' || slot_provider === UNGROUPED) {
        const grouped = (await loadProviders(groupCategory)).flatMap(p => parseGameIds(p.game_ids));
        if (slot_provider === UNGROUPED) {
          where.id = { [Op.in]: await ungroupedIds(groupCategory) };
        } else if (grouped.length) {
          where.id = { [Op.notIn]: grouped };
        }
      } else {
        const row = await resolveProvider(groupCategory, slot_provider);
        if (!row) {
          return res.status(404).json(GameResponseHandler.handleErrorResponse(10008, `Unknown provider '${slot_provider}'`));
        }
        where.id = { [Op.in]: parseGameIds(row.game_ids) };
      }
    }

    if (keyword.trim()) {
      where[Op.and] = [{
        [Op.or]: [
          { game_name: { [Op.iLike]: `%${keyword.trim()}%` } },
          { vendor: { [Op.iLike]: `%${keyword.trim()}%` } },
        ],
      }];
    }

    const { count: total, rows: games } = await JSGame.findAndCountAll({
      where, order: [['id', 'ASC']], limit: perPageNum, offset,
    });

    return res.json(GameResponseHandler.handleSuccessResponse({
      payload: {
        games: await withGroupInfo(games),
        pagination: { current_page: pageNum, per_page: perPageNum, total, total_pages: Math.ceil(total / perPageNum) },
      }
    }));
  } catch (error) {
    GameResponseHandler.logErrorDetails('listAdminGames', error);
    res.status(500).json(GameResponseHandler.handleErrorResponse(10004, 'Error fetching admin game list'));
  }
}

async function updateGame(req, res) {
  try {
    const id = parseInt(req.params.id);
    if (!Number.isInteger(id)) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(10006, 'Invalid game id'));
    }

    const game = await JSGame.findByPk(id);
    if (!game) {
      return res.status(404).json(GameResponseHandler.handleErrorResponse(10008, 'Game not found'));
    }

    const updates = {};
    for (const field of EDITABLE_GAME_FIELDS) {
      if (Object.prototype.hasOwnProperty.call(req.body, field)) {
        updates[field] = req.body[field];
      }
    }
    if (Object.keys(updates).length === 0) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(
        10006, `No editable fields provided. Editable: ${EDITABLE_GAME_FIELDS.join(', ')}`
      ));
    }
    if ('is_active' in updates) updates.is_active = updates.is_active === true || updates.is_active === 'true';

    await game.update(updates);
    cache.flushAll();

    return res.json(GameResponseHandler.handleSuccessResponse({ payload: { game: await withGroupInfo(game) } }));
  } catch (error) {
    GameResponseHandler.logErrorDetails('updateGame', error);
    res.status(500).json(GameResponseHandler.handleErrorResponse(10004, 'Error updating game'));
  }
}

// Replace a game's manual category membership. Body: { categories: [...] }.
// Adds the game id to each selected category's membership row and removes it
// from the deselected ones — so the same call both adds and un-adds.
async function setGameCategories(req, res) {
  try {
    const id = parseInt(req.params.id);
    if (!Number.isInteger(id)) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(10006, 'Invalid game id'));
    }

    const game = await JSGame.findByPk(id);
    if (!game) {
      return res.status(404).json(GameResponseHandler.handleErrorResponse(10008, 'Game not found'));
    }

    let { categories } = req.body;
    if (!Array.isArray(categories)) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(10006, 'categories must be an array'));
    }
    categories = [...new Set(categories)];
    const invalid = categories.filter(c => !GAME_CATEGORIES[c]);
    if (invalid.length > 0) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(
        10006, `Invalid category. Allowed categories: ${Object.keys(GAME_CATEGORIES).join(', ')}`
      ));
    }

    for (const category of Object.keys(GAME_CATEGORIES)) {
      const [record] = await CategoryMembership.findOrCreate({
        where: { category },
        defaults: { category, game_ids: '' },
      });
      const ids = parseGameIds(record.game_ids);
      const has = ids.includes(id);
      const want = categories.includes(category);
      if (want && !has) {
        await record.update({ game_ids: [...ids, id].join(',') });
      } else if (!want && has) {
        await record.update({ game_ids: ids.filter(x => x !== id).join(',') });
      }
    }

    cache.flushAll();

    return res.json(GameResponseHandler.handleSuccessResponse({ payload: { game: await withGroupInfo(game) } }));
  } catch (error) {
    GameResponseHandler.logErrorDetails('setGameCategories', error);
    res.status(500).json(GameResponseHandler.handleErrorResponse(10004, 'Error updating game categories'));
  }
}

// --- Slot provider groups: read + admin management ---

// Public: the provider strip for the slot tab. Counts are of active games.
async function listSlotProviders(req, res) {
  try {
    const category = requestCategory(req);
    if (!isKnownCategory(category)) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(
        10006, `Invalid category. Allowed categories: ${Object.keys(GAME_CATEGORIES).join(', ')}`));
    }
    const includeEmpty = req.query.include_empty !== 'false';
    const withIds = req.query.with_ids === 'true';
    const cacheKey = `providers_${category}_${includeEmpty}_${withIds}`;
    const cached = cache.get(cacheKey);
    if (cached) {
      return res.json(GameResponseHandler.handleSuccessResponse({ payload: cached, meta: { cached: true } }));
    }

    const rows = await loadProviders(category);
    const providers = [];
    for (const row of rows) {
      const ids = parseGameIds(row.game_ids);
      const categories = await loadProviderCategories(row.provider);

      // One active-id lookup per provider covers the group and every tab in it
      const lookup = [...new Set([...ids, ...categories.flatMap(c => parseGameIds(c.game_ids))])];
      const activeIds = lookup.length
        ? new Set((await JSGame.findAll({
            where: { id: { [Op.in]: lookup }, is_active: true }, attributes: ['id'], raw: true,
          })).map(g => g.id))
        : new Set();

      const activeCount = ids.filter(id => activeIds.has(id)).length;
      if (!includeEmpty && activeCount === 0) continue;

      // Empty tabs are never dropped — the reference site shows them and so do
      // we; hiding one is an explicit owner action, not a side effect of a count
      const categorySummary = categories.map(c => {
        const catIds = parseGameIds(c.game_ids);
        return {
          slug: c.slug,
          label: c.label,
          sort_order: c.sort_order,
          total_games: catIds.length,
          active_games: catIds.filter(id => activeIds.has(id)).length,
          ...(withIds ? { game_ids: catIds } : {}),
        };
      });

      providers.push({
        id: row.ext_id ?? null,
        provider: row.provider,
        label: row.label,
        sort_order: row.sort_order,
        total_games: ids.length,
        active_games: activeCount,
        categories: categorySummary,
        uncategorized_games: (await uncategorizedIds(row, categories)).length,
        ...(withIds ? { game_ids: ids } : {}),
      });
    }

    const response = { providers, ungrouped_games: (await ungroupedIds(category)).length };
    cache.set(cacheKey, response);
    return res.json(GameResponseHandler.handleSuccessResponse({ payload: response, meta: { cached: false } }));
  } catch (error) {
    GameResponseHandler.logErrorDetails('listSlotProviders', error);
    res.status(500).json(GameResponseHandler.handleErrorResponse(10004, 'Error fetching slot providers'));
  }
}

// Admin: the full ordered group, inactive games included.
// The pseudo-provider `ungrouped` lists prioritized slot games with no group.
async function getSlotProviderGames(req, res) {
  try {
    const category = requestCategory(req);
    if (!isKnownCategory(category)) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(
        10006, `Invalid category. Allowed categories: ${Object.keys(GAME_CATEGORIES).join(', ')}`));
    }
    const { provider } = req.params;

    if (provider === UNGROUPED) {
      const ids = await ungroupedIds(category);
      return res.json(GameResponseHandler.handleSuccessResponse({
        payload: { provider: UNGROUPED, label: 'Ungrouped', game_ids: ids, games: await findGamesInOrder(ids) }
      }));
    }

    const row = await resolveProvider(category, provider);
    if (!row) {
      return res.status(404).json(GameResponseHandler.handleErrorResponse(10008, `Unknown ${category} provider '${provider}'`));
    }
    const ids = parseGameIds(row.game_ids);
    return res.json(GameResponseHandler.handleSuccessResponse({
      payload: { category, provider: row.provider, label: row.label, game_ids: ids, games: await findGamesInOrder(ids) }
    }));
  } catch (error) {
    GameResponseHandler.logErrorDetails('getSlotProviderGames', error);
    res.status(500).json(GameResponseHandler.handleErrorResponse(10004, 'Error fetching slot provider games'));
  }
}

// Admin: replace a group's ordered game list. Ids are validated against the
// slot category and pulled out of every other group — one game, one provider.
async function setSlotProviderGames(req, res) {
  try {
    const category = requestCategory(req);
    if (!isKnownCategory(category)) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(
        10006, `Invalid category. Allowed categories: ${Object.keys(GAME_CATEGORIES).join(', ')}`));
    }
    const { provider } = req.params;
    const row = await resolveProvider(category, provider);
    if (!row) {
      return res.status(404).json(GameResponseHandler.handleErrorResponse(10008, `Unknown ${category} provider '${provider}'`));
    }

    const { game_ids } = req.body;
    const rawIds = Array.isArray(game_ids)
      ? game_ids.map(id => parseInt(id)).filter(id => Number.isInteger(id))
      : parseGameIds(game_ids);
    const gameIds = [...new Set(rawIds)];

    if (gameIds.length > 0) {
      const found = await JSGame.findAll({
        where: { id: { [Op.in]: gameIds }, ...(await buildCategoryFilter(category)) },
        attributes: ['id'],
      });
      const foundIds = new Set(found.map(g => g.id));
      const invalid = gameIds.filter(id => !foundIds.has(id));
      if (invalid.length > 0) {
        return res.status(400).json(GameResponseHandler.handleErrorResponse(
          10007, `Game ids not found in the ${category} category: ${invalid.join(', ')}`
        ));
      }
    }

    const claimed = new Set(gameIds);
    for (const other of await loadProviders(category)) {
      if (other.provider === provider) continue;
      const ids = parseGameIds(other.game_ids);
      const kept = ids.filter(id => !claimed.has(id));
      if (kept.length !== ids.length) {
        await other.update({ game_ids: kept.join(',') });
        await pruneProviderCategories(other);
      }
    }

    await row.update({ game_ids: gameIds.join(',') });
    // A game that left the group leaves its tabs too; the flat list is then
    // re-derived from the tabs, so on a provider with tabs the sent order only
    // decides where the still-uncategorized games sit.
    await pruneProviderCategories(row);
    const finalIds = await rebuildProviderGameIds(row);
    await rebuildCategoryQueue(category);
    cache.flushAll();

    return res.json(GameResponseHandler.handleSuccessResponse({
      payload: { provider: row.provider, label: row.label, game_ids: finalIds }
    }));
  } catch (error) {
    GameResponseHandler.logErrorDetails('setSlotProviderGames', error);
    res.status(500).json(GameResponseHandler.handleErrorResponse(10004, 'Error setting slot provider games'));
  }
}

// Admin: add a provider group. Slug is derived from the label.
async function createSlotProvider(req, res) {
  try {
    const category = requestCategory(req);
    if (!isKnownCategory(category)) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(
        10006, `Invalid category. Allowed categories: ${Object.keys(GAME_CATEGORIES).join(', ')}`));
    }
    const label = String(req.body.label || '').trim();
    const base = slugifyProvider(req.body.provider || label);
    if (!label || !base) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(10006, 'label is required'));
    }

    // The slug is the primary key, so it is unique across every category. Two
    // categories can still both have a "Kingmidas": the second one becomes
    // `kingmidas-fantasy`. The label the owner typed is kept either way.
    const taken = await SlotProvider.findByPk(base);
    if (taken && taken.category === category) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(
        10006, `Provider '${label}' already exists in ${category}`));
    }
    let provider = base;
    if (taken) {
      provider = `${base}-${category}`;
      for (let n = 2; await SlotProvider.findByPk(provider); n++) provider = `${base}-${category}-${n}`;
    }

    const max = await SlotProvider.max('sort_order', { where: { category } });
    const row = await SlotProvider.create({
      category, provider, label, game_ids: '',
      sort_order: Number.isInteger(max) ? max + 1 : 0,
    });
    cache.flushAll();

    return res.json(GameResponseHandler.handleSuccessResponse({
      payload: { category, provider: row.provider, label: row.label } }));
  } catch (error) {
    GameResponseHandler.logErrorDetails('createSlotProvider', error);
    res.status(500).json(GameResponseHandler.handleErrorResponse(10004, 'Error creating slot provider'));
  }
}

// Admin: rename a provider group (the slug stays put — it is the id).
async function updateSlotProvider(req, res) {
  try {
    const category = requestCategory(req);
    if (!isKnownCategory(category)) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(
        10006, `Invalid category. Allowed categories: ${Object.keys(GAME_CATEGORIES).join(', ')}`));
    }
    const row = await resolveProvider(category, req.params.provider);
    if (!row) {
      return res.status(404).json(GameResponseHandler.handleErrorResponse(10008, 'Unknown provider'));
    }
    const label = String(req.body.label || '').trim();
    if (!label) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(10006, 'label is required'));
    }
    await row.update({ label });
    cache.flushAll();
    return res.json(GameResponseHandler.handleSuccessResponse({ payload: { provider: row.provider, label: row.label } }));
  } catch (error) {
    GameResponseHandler.logErrorDetails('updateSlotProvider', error);
    res.status(500).json(GameResponseHandler.handleErrorResponse(10004, 'Error updating slot provider'));
  }
}

// Admin: delete a provider group. Its games stay in the slot queue as ungrouped.
async function deleteSlotProvider(req, res) {
  try {
    const category = requestCategory(req);
    if (!isKnownCategory(category)) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(
        10006, `Invalid category. Allowed categories: ${Object.keys(GAME_CATEGORIES).join(', ')}`));
    }
    const row = await resolveProvider(category, req.params.provider);
    if (!row) {
      return res.status(404).json(GameResponseHandler.handleErrorResponse(10008, 'Unknown provider'));
    }
    await SlotProviderCategory.destroy({ where: { provider: row.provider } });
    await row.destroy();
    await rebuildCategoryQueue(category);
    cache.flushAll();
    return res.json(GameResponseHandler.handleSuccessResponse({ payload: { provider: req.params.provider, deleted: true } }));
  } catch (error) {
    GameResponseHandler.logErrorDetails('deleteSlotProvider', error);
    res.status(500).json(GameResponseHandler.handleErrorResponse(10004, 'Error deleting slot provider'));
  }
}

// Admin: reorder the provider strip. Body: { providers: ['jili', 'amigo', ...] }
// Provider order is also slot queue order, so this reshuffles the app listing.
async function reorderSlotProviders(req, res) {
  try {
    const category = requestCategory(req);
    if (!isKnownCategory(category)) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(
        10006, `Invalid category. Allowed categories: ${Object.keys(GAME_CATEGORIES).join(', ')}`));
    }
    const { providers } = req.body;
    if (!Array.isArray(providers) || providers.length === 0) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(10006, 'providers must be a non-empty array'));
    }

    const rows = await loadProviders(category);
    const known = new Set(rows.map(r => r.provider));
    const unknown = providers.filter(p => !known.has(p));
    if (unknown.length) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(10008, `Unknown ${category} providers: ${unknown.join(', ')}`));
    }

    // Anything the client left out keeps its relative order behind the rest
    const ordered = [...providers, ...rows.map(r => r.provider).filter(p => !providers.includes(p))];
    for (let i = 0; i < ordered.length; i++) {
      await SlotProvider.update({ sort_order: i }, { where: { provider: ordered[i] } });
    }
    await rebuildCategoryQueue(category);
    cache.flushAll();

    return res.json(GameResponseHandler.handleSuccessResponse({ payload: { providers: ordered } }));
  } catch (error) {
    GameResponseHandler.logErrorDetails('reorderSlotProviders', error);
    res.status(500).json(GameResponseHandler.handleErrorResponse(10004, 'Error reordering slot providers'));
  }
}

// Admin: move one game into a provider group (or out of every group with
// provider: null). Same one-game-one-group rule as setSlotProviderGames, just
// reachable from the catalog list instead of the group queue.
async function setGameSlotProvider(req, res) {
  try {
    const category = req.body.game_category || requestCategory(req);
    if (!isKnownCategory(category)) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(
        10006, `Invalid category. Allowed categories: ${Object.keys(GAME_CATEGORIES).join(', ')}`));
    }
    const id = parseInt(req.params.id);
    if (!Number.isInteger(id)) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(10006, 'Invalid game id'));
    }

    const game = await JSGame.findByPk(id);
    if (!game) {
      return res.status(404).json(GameResponseHandler.handleErrorResponse(10008, 'Game not found'));
    }

    const target = req.body.provider || null;
    let targetRow = null;
    if (target) {
      targetRow = await resolveProvider(category, target);
      if (!targetRow) {
        return res.status(404).json(GameResponseHandler.handleErrorResponse(
          10008, `Unknown ${category} provider '${target}'`));
      }
      const inCategory = await JSGame.findOne({ where: { id, ...(await buildCategoryFilter(category)) }, attributes: ['id'] });
      if (!inCategory) {
        return res.status(400).json(GameResponseHandler.handleErrorResponse(
          10007, `Game #${id} is not in the ${category} category — add it to ${category} first`
        ));
      }
    }

    // Optional second step: which tab inside that provider. Omit the key to
    // leave the game's tab alone, send null to drop it to uncategorized.
    const wantsCategory = Object.prototype.hasOwnProperty.call(req.body, 'category');
    const targetCategorySlug = wantsCategory ? (req.body.category || null) : undefined;
    let targetCategory = null;
    if (targetCategorySlug) {
      if (!targetRow) {
        return res.status(400).json(GameResponseHandler.handleErrorResponse(
          10006, 'category requires a provider'));
      }
      targetCategory = await SlotProviderCategory.findOne({
        where: { provider: targetRow.provider, slug: targetCategorySlug },
      });
      if (!targetCategory) {
        return res.status(404).json(GameResponseHandler.handleErrorResponse(
          10008, `Unknown category '${targetCategorySlug}' in provider '${targetRow.provider}'`));
      }
    }

    for (const row of await loadProviders(category)) {
      const ids = parseGameIds(row.game_ids);
      if (row.provider === target) {
        if (!ids.includes(id)) await row.update({ game_ids: [...ids, id].join(',') });
      } else if (ids.includes(id)) {
        await row.update({ game_ids: ids.filter(x => x !== id).join(',') });
      }
    }

    if (targetCategory) {
      await releaseFromTabs(category, [id], { exceptId: targetCategory.id });
      const catIds = parseGameIds(targetCategory.game_ids);
      if (!catIds.includes(id)) await targetCategory.update({ game_ids: [...catIds, id].join(',') });
    } else if (wantsCategory || !target) {
      // Explicitly untabbed, or out of every group — either way, no tab
      await releaseFromTabs(category, [id]);
    } else {
      // Provider changed without naming a tab: only the tabs it no longer
      // belongs to let go, so a move inside the same provider keeps its tab.
      const stale = (await SlotProviderCategory.findAll())
        .filter(c => c.provider !== target && parseGameIds(c.game_ids).includes(id));
      for (const c of stale) {
        await c.update({ game_ids: parseGameIds(c.game_ids).filter(x => x !== id).join(',') });
      }
    }

    for (const row of await loadProviders(category)) {
      await pruneProviderCategories(row);
      await rebuildProviderGameIds(row);
    }

    await rebuildCategoryQueue(category);
    cache.flushAll();

    return res.json(GameResponseHandler.handleSuccessResponse({ payload: { game: await withGroupInfo(game) } }));
  } catch (error) {
    GameResponseHandler.logErrorDetails('setGameSlotProvider', error);
    res.status(500).json(GameResponseHandler.handleErrorResponse(10004, 'Error setting game provider'));
  }
}

// --- Slot provider sub-categories ---

// Public: one provider, every tab, every tab's games — the whole /slot/:id page
// in one request. `:provider` takes the slug or the numeric id. Inactive games
// are omitted, empty tabs are not.
async function getSlotProviderCategories(req, res) {
  try {
    const category = requestCategory(req);
    if (!isKnownCategory(category)) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(
        10006, `Invalid category. Allowed categories: ${Object.keys(GAME_CATEGORIES).join(', ')}`));
    }
    const providerRow = await resolveProvider(category, req.params.provider);
    if (!providerRow) {
      return res.status(404).json(GameResponseHandler.handleErrorResponse(
        10008, `Unknown ${category} provider '${req.params.provider}'`));
    }

    const includeUncategorized = req.query.include_uncategorized !== 'false';
    const cacheKey = `provider_categories_${category}_${providerRow.provider}_${includeUncategorized}`;
    const cached = cache.get(cacheKey);
    if (cached) {
      return res.json(GameResponseHandler.handleSuccessResponse({ payload: cached, meta: { cached: true } }));
    }

    // `art` is the curated tile the site paints, which is not js_games.game_icon
    // (that points at the aggregator's S3). Until an art column exists it stays
    // null and the frontend keeps serving the tile from its own assets;
    // game_icon rides along so a client that wants the aggregator art has it.
    const toPublicGame = (game) => ({
      game_id: game.id,
      game_uid: game.game_uid,
      game_name: game.game_name,
      game_type: game.game_type,
      vendor: game.vendor,
      art: null,
      game_icon: game.game_icon,
      is_active: game.is_active,
    });

    const rows = await loadProviderCategories(providerRow.provider);
    const categories = [];
    for (const row of rows) {
      categories.push({
        slug: row.slug,
        label: row.label,
        sort_order: row.sort_order,
        games: (await findGamesInOrder(parseGameIds(row.game_ids), { is_active: true })).map(toPublicGame),
      });
    }

    // Games in the group that no tab claims would otherwise vanish from the app,
    // so they are served as a trailing tab the client can style or drop.
    if (includeUncategorized) {
      const leftover = await uncategorizedIds(providerRow, rows);
      const games = (await findGamesInOrder(leftover, { is_active: true })).map(toPublicGame);
      if (games.length) {
        categories.push({
          slug: rows.length ? 'more-games' : 'all-games',
          label: rows.length ? 'More Games' : 'All Games',
          sort_order: categories.length,
          is_uncategorized: true,
          games,
        });
      }
    }

    const response = {
      provider: { id: providerRow.ext_id ?? null, provider: providerRow.provider, label: providerRow.label },
      categories,
    };
    cache.set(cacheKey, response);
    return res.json(GameResponseHandler.handleSuccessResponse({ payload: response, meta: { cached: false } }));
  } catch (error) {
    GameResponseHandler.logErrorDetails('getSlotProviderCategories', error);
    res.status(500).json(GameResponseHandler.handleErrorResponse(10004, 'Error fetching slot provider categories'));
  }
}

// Admin: the tab strip with counts, inactive games included.
async function listSlotProviderCategoriesAdmin(req, res) {
  try {
    const category = requestCategory(req);
    if (!isKnownCategory(category)) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(
        10006, `Invalid category. Allowed categories: ${Object.keys(GAME_CATEGORIES).join(', ')}`));
    }
    const providerRow = await resolveProvider(category, req.params.provider);
    if (!providerRow) {
      return res.status(404).json(GameResponseHandler.handleErrorResponse(
        10008, `Unknown ${category} provider '${req.params.provider}'`));
    }

    const rows = await loadProviderCategories(providerRow.provider);
    const categories = rows.map(row => {
      const ids = parseGameIds(row.game_ids);
      return {
        id: row.id,
        slug: row.slug,
        label: row.label,
        sort_order: row.sort_order,
        total_games: ids.length,
        game_ids: ids,
      };
    });

    return res.json(GameResponseHandler.handleSuccessResponse({
      payload: {
        provider: { id: providerRow.ext_id ?? null, provider: providerRow.provider, label: providerRow.label },
        categories,
        uncategorized_games: (await uncategorizedIds(providerRow, rows)).length,
      }
    }));
  } catch (error) {
    GameResponseHandler.logErrorDetails('listSlotProviderCategoriesAdmin', error);
    res.status(500).json(GameResponseHandler.handleErrorResponse(10004, 'Error fetching slot provider categories'));
  }
}

// Admin: one tab's full ordered list, inactive included. The pseudo-slug
// `uncategorized` lists the group's games that no tab claims.
async function getSlotProviderCategoryGames(req, res) {
  try {
    const category = requestCategory(req);
    if (!isKnownCategory(category)) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(
        10006, `Invalid category. Allowed categories: ${Object.keys(GAME_CATEGORIES).join(', ')}`));
    }
    const providerRow = await resolveProvider(category, req.params.provider);
    if (!providerRow) {
      return res.status(404).json(GameResponseHandler.handleErrorResponse(
        10008, `Unknown ${category} provider '${req.params.provider}'`));
    }

    if (req.params.slug === UNCATEGORIZED) {
      const ids = await uncategorizedIds(providerRow);
      return res.json(GameResponseHandler.handleSuccessResponse({
        payload: {
          provider: { provider: providerRow.provider, label: providerRow.label },
          category: { slug: UNCATEGORIZED, label: 'Uncategorized' },
          game_ids: ids,
          games: await findGamesInOrder(ids),
        }
      }));
    }

    const row = await SlotProviderCategory.findOne({
      where: { provider: providerRow.provider, slug: req.params.slug },
    });
    if (!row) {
      return res.status(404).json(GameResponseHandler.handleErrorResponse(
        10008, `Unknown category '${req.params.slug}' in provider '${providerRow.provider}'`));
    }

    const ids = parseGameIds(row.game_ids);
    return res.json(GameResponseHandler.handleSuccessResponse({
      payload: {
        provider: { provider: providerRow.provider, label: providerRow.label },
        category: { id: row.id, slug: row.slug, label: row.label, sort_order: row.sort_order },
        game_ids: ids,
        games: await findGamesInOrder(ids),
      }
    }));
  } catch (error) {
    GameResponseHandler.logErrorDetails('getSlotProviderCategoryGames', error);
    res.status(500).json(GameResponseHandler.handleErrorResponse(10004, 'Error fetching category games'));
  }
}

// Admin: replace one tab's ordered game list. Ids are pulled out of every other
// tab and every other provider group, so a game lands in exactly one place.
// Slug `uncategorized` sets the group's untabbed tail instead — dropping a game
// from that list drops it out of the provider group entirely.
async function setSlotProviderCategoryGames(req, res) {
  try {
    const category = requestCategory(req);
    if (!isKnownCategory(category)) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(
        10006, `Invalid category. Allowed categories: ${Object.keys(GAME_CATEGORIES).join(', ')}`));
    }
    const providerRow = await resolveProvider(category, req.params.provider);
    if (!providerRow) {
      return res.status(404).json(GameResponseHandler.handleErrorResponse(
        10008, `Unknown ${category} provider '${req.params.provider}'`));
    }

    const isUncategorized = req.params.slug === UNCATEGORIZED;
    const row = isUncategorized ? null : await SlotProviderCategory.findOne({
      where: { provider: providerRow.provider, slug: req.params.slug },
    });
    if (!isUncategorized && !row) {
      return res.status(404).json(GameResponseHandler.handleErrorResponse(
        10008, `Unknown category '${req.params.slug}' in provider '${providerRow.provider}'`));
    }

    const { game_ids } = req.body;
    const rawIds = Array.isArray(game_ids)
      ? game_ids.map(id => parseInt(id)).filter(id => Number.isInteger(id))
      : parseGameIds(game_ids);
    const gameIds = [...new Set(rawIds)];

    const invalid = await rejectIdsOutsideCategory(category, gameIds);
    if (invalid.length > 0) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(
        10007, `Game ids not found in the ${category} category: ${invalid.join(', ')}`));
    }

    await claimGamesForProvider(providerRow, gameIds);

    if (isUncategorized) {
      // The sent list is the group's untabbed games, in the order they should
      // sit: anything the group holds that is neither tabbed nor sent is out.
      // Tabbed games keep their exact position in the flat list — only the
      // untabbed slots are refilled, so nothing an owner curated is reshuffled.
      await releaseFromTabs(category, gameIds);
      const tabbed = new Set(
        (await loadProviderCategories(providerRow.provider)).flatMap(c => parseGameIds(c.game_ids))
      );
      const sent = [...gameIds];
      const ordered = [];
      for (const id of parseGameIds(providerRow.game_ids)) {
        if (tabbed.has(id)) ordered.push(id);
        else if (sent.length) ordered.push(sent.shift());
      }
      ordered.push(...sent); // ids the group did not have yet
      await providerRow.update({ game_ids: ordered.join(',') });
    } else {
      await releaseFromTabs(category, gameIds, { exceptId: row.id });
      await row.update({ game_ids: gameIds.join(',') });
      await rebuildProviderGameIds(providerRow);
    }

    await rebuildCategoryQueue(category);
    cache.flushAll();

    return res.json(GameResponseHandler.handleSuccessResponse({
      payload: {
        provider: providerRow.provider,
        category: isUncategorized ? UNCATEGORIZED : row.slug,
        game_ids: gameIds,
      }
    }));
  } catch (error) {
    GameResponseHandler.logErrorDetails('setSlotProviderCategoryGames', error);
    res.status(500).json(GameResponseHandler.handleErrorResponse(10004, 'Error setting category games'));
  }
}

// Admin: add a tab to a provider. Slug is derived from the label.
async function createSlotProviderCategory(req, res) {
  try {
    const category = requestCategory(req);
    if (!isKnownCategory(category)) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(
        10006, `Invalid category. Allowed categories: ${Object.keys(GAME_CATEGORIES).join(', ')}`));
    }
    const providerRow = await resolveProvider(category, req.params.provider);
    if (!providerRow) {
      return res.status(404).json(GameResponseHandler.handleErrorResponse(
        10008, `Unknown ${category} provider '${req.params.provider}'`));
    }

    const label = String(req.body.label || '').trim();
    const slug = slugifyProvider(req.body.slug || label);
    if (!label || !slug) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(10006, 'label is required'));
    }

    const clash = await SlotProviderCategory.findOne({ where: { provider: providerRow.provider, slug } });
    if (clash) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(
        10006, `Category '${slug}' already exists in ${providerRow.label}`));
    }

    const max = await SlotProviderCategory.max('sort_order', { where: { provider: providerRow.provider } });
    const row = await SlotProviderCategory.create({
      category,
      provider: providerRow.provider,
      slug,
      label,
      game_ids: '',
      sort_order: Number.isInteger(max) ? max + 1 : 0,
    });
    cache.flushAll();

    return res.json(GameResponseHandler.handleSuccessResponse({
      payload: { provider: providerRow.provider, category: { id: row.id, slug: row.slug, label: row.label } }
    }));
  } catch (error) {
    GameResponseHandler.logErrorDetails('createSlotProviderCategory', error);
    res.status(500).json(GameResponseHandler.handleErrorResponse(10004, 'Error creating category'));
  }
}

// Admin: rename a tab. The slug stays put — it is the id the app links to.
async function updateSlotProviderCategory(req, res) {
  try {
    const category = requestCategory(req);
    if (!isKnownCategory(category)) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(
        10006, `Invalid category. Allowed categories: ${Object.keys(GAME_CATEGORIES).join(', ')}`));
    }
    const providerRow = await resolveProvider(category, req.params.provider);
    if (!providerRow) {
      return res.status(404).json(GameResponseHandler.handleErrorResponse(
        10008, `Unknown ${category} provider '${req.params.provider}'`));
    }
    const row = await SlotProviderCategory.findOne({
      where: { provider: providerRow.provider, slug: req.params.slug },
    });
    if (!row) {
      return res.status(404).json(GameResponseHandler.handleErrorResponse(10008, 'Unknown category'));
    }

    const label = String(req.body.label || '').trim();
    if (!label) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(10006, 'label is required'));
    }
    await row.update({ label });
    cache.flushAll();

    return res.json(GameResponseHandler.handleSuccessResponse({
      payload: { provider: providerRow.provider, category: { id: row.id, slug: row.slug, label: row.label } }
    }));
  } catch (error) {
    GameResponseHandler.logErrorDetails('updateSlotProviderCategory', error);
    res.status(500).json(GameResponseHandler.handleErrorResponse(10004, 'Error updating category'));
  }
}

// Admin: delete a tab. Its games stay in the provider group as uncategorized —
// they keep showing in the app, they just lose their tab.
async function deleteSlotProviderCategory(req, res) {
  try {
    const category = requestCategory(req);
    if (!isKnownCategory(category)) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(
        10006, `Invalid category. Allowed categories: ${Object.keys(GAME_CATEGORIES).join(', ')}`));
    }
    const providerRow = await resolveProvider(category, req.params.provider);
    if (!providerRow) {
      return res.status(404).json(GameResponseHandler.handleErrorResponse(
        10008, `Unknown ${category} provider '${req.params.provider}'`));
    }
    const row = await SlotProviderCategory.findOne({
      where: { provider: providerRow.provider, slug: req.params.slug },
    });
    if (!row) {
      return res.status(404).json(GameResponseHandler.handleErrorResponse(10008, 'Unknown category'));
    }

    await row.destroy();
    await rebuildProviderGameIds(providerRow);
    await rebuildCategoryQueue(category);
    cache.flushAll();

    return res.json(GameResponseHandler.handleSuccessResponse({
      payload: { provider: providerRow.provider, category: req.params.slug, deleted: true }
    }));
  } catch (error) {
    GameResponseHandler.logErrorDetails('deleteSlotProviderCategory', error);
    res.status(500).json(GameResponseHandler.handleErrorResponse(10004, 'Error deleting category'));
  }
}

// Admin: reorder a provider's tabs. Body: { categories: ['slot-game', ...] }
// This orders the tab strip on the slot page — which tab opens first and in what
// sequence. It deliberately leaves the provider's flat listing order alone.
async function reorderSlotProviderCategories(req, res) {
  try {
    const category = requestCategory(req);
    if (!isKnownCategory(category)) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(
        10006, `Invalid category. Allowed categories: ${Object.keys(GAME_CATEGORIES).join(', ')}`));
    }
    const providerRow = await resolveProvider(category, req.params.provider);
    if (!providerRow) {
      return res.status(404).json(GameResponseHandler.handleErrorResponse(
        10008, `Unknown ${category} provider '${req.params.provider}'`));
    }

    const { categories } = req.body;
    if (!Array.isArray(categories) || categories.length === 0) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(10006, 'categories must be a non-empty array'));
    }

    const rows = await loadProviderCategories(providerRow.provider);
    const known = new Set(rows.map(r => r.slug));
    const unknown = categories.filter(c => !known.has(c));
    if (unknown.length) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(
        10008, `Unknown categories: ${unknown.join(', ')}`));
    }

    // Anything the client left out keeps its relative order behind the rest
    const ordered = [...categories, ...rows.map(r => r.slug).filter(slug => !categories.includes(slug))];
    for (let i = 0; i < ordered.length; i++) {
      await SlotProviderCategory.update(
        { sort_order: i },
        { where: { provider: providerRow.provider, slug: ordered[i] } },
      );
    }
    await rebuildProviderGameIds(providerRow);
    await rebuildCategoryQueue(category);
    cache.flushAll();

    return res.json(GameResponseHandler.handleSuccessResponse({
      payload: { provider: providerRow.provider, categories: ordered }
    }));
  } catch (error) {
    GameResponseHandler.logErrorDetails('reorderSlotProviderCategories', error);
    res.status(500).json(GameResponseHandler.handleErrorResponse(10004, 'Error reordering categories'));
  }
}

async function getVendors(req, res) {
  try {
    const { category } = req.query;
    if (category && !GAME_CATEGORIES[category]) {
      return res.status(400).json(GameResponseHandler.handleErrorResponse(
        10006, `Invalid category. Allowed categories: ${Object.keys(GAME_CATEGORIES).join(', ')}`
      ));
    }
    const where = category ? await buildCategoryFilter(category) : {};
    const vendors = await JSGame.findAll({
      where,
      attributes: ['vendor', [sequelize.fn('COUNT', sequelize.col('id')), 'game_count']],
      group: ['vendor'],
      order: [[sequelize.fn('COUNT', sequelize.col('id')), 'DESC']],
      raw: true,
    });
    return res.json(GameResponseHandler.handleSuccessResponse({ payload: { vendors } }));
  } catch (error) {
    GameResponseHandler.logErrorDetails('getVendors', error);
    res.status(500).json(GameResponseHandler.handleErrorResponse(10004, 'Error fetching vendors'));
  }
}

export default {
  getGameLaunchURL,
  processBetCallback,
  processGameTransfer,
  getTransactionRecords,
  getActiveGames,
  searchGames,
  getGameCategories,
  getCategoryPriority,
  setCategoryPriority,
  listAdminGames,
  updateGame,
  setGameCategories,
  setGameSlotProvider,
  getVendors,
  listSlotProviders,
  getSlotProviderCategories,
  listSlotProviderCategoriesAdmin,
  getSlotProviderCategoryGames,
  setSlotProviderCategoryGames,
  createSlotProviderCategory,
  updateSlotProviderCategory,
  deleteSlotProviderCategory,
  reorderSlotProviderCategories,
  getSlotProviderGames,
  setSlotProviderGames,
  createSlotProvider,
  updateSlotProvider,
  deleteSlotProvider,
  reorderSlotProviders,
};
