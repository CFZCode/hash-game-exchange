import express from 'express';
import GameController from './controller.js';
import authMiddleware from '../middleware/authMiddleware.js';
import { requireOwner } from '../middleware/permissionMiddleware.js';
const router = express.Router();

// The provider/tab endpoints are generic over the four categories. The slot-era
// paths below (`/games/slot-providers…`, `/admin/slot-providers…`) predate that
// and are still what the player frontend and the published docs call, so they
// stay as thin aliases that pin the category to `slot`.
const asSlot = (handler) => (req, res) => {
  req.params.category = 'slot';
  return handler(req, res);
};

// Priority queues and the game catalog are managed from the owner-only
// Game Priority panel — requireOwner blocks staff and executives too.

// 1. Get Game Launch URL (SEAMLESS)
router.post('/game/launch', async (req, res) => {
    await GameController.getGameLaunchURL(req, res);
});

// 2. Bet Callback (External API Callback)
router.post('/game/bet-callback', async (req, res) => {
    await GameController.processBetCallback(req, res);
});

// 3. Game Transfer (Deposit/Withdrawal)
router.post('/game/transfer', async (req, res) => {
    await GameController.processGameTransfer(req, res);
});

// 4. Get Transaction Records
router.post('/game/transactions', async (req, res) => {
    await GameController.getTransactionRecords(req, res);
});

// 5. Get active games with pagination (supports ?category=crash|lottery|slot|fantasy)
router.get('/games', async (req, res) => {
    await GameController.getActiveGames(req, res);
});

// 6. Search games
router.get('/games/search', async (req, res) => {
    await GameController.searchGames(req, res);
});

// 7. List game categories with counts
router.get('/games/categories', async (req, res) => {
    await GameController.getGameCategories(req, res);
});

// 8. Games of one category, priority queue first
router.get('/games/category/:category', async (req, res) => {
    req.query.category = req.params.category;
    await GameController.getActiveGames(req, res);
});

// 9. View a category's priority queue
router.get('/games/category/:category/priority', async (req, res) => {
    await GameController.getCategoryPriority(req, res);
});

// 10. Set/replace a category's priority queue (owner only)
router.post('/games/category/:category/priority', authMiddleware, requireOwner, async (req, res) => {
    await GameController.setCategoryPriority(req, res);
});

// --- Slot provider groups ---
// The slot category is split into provider groups (jili, amigo, red-tiger, ...).
// Group order is slot queue order, so reordering providers reorders the app.

// 10a. Provider strip with counts (public)
router.get('/games/slot-providers', asSlot(GameController.listSlotProviders));

// 10b. Games of one provider group, in group order (public)
router.get('/games/slot-providers/:provider/games', async (req, res) => {
    req.query.category = 'slot';
    req.query.provider = req.params.provider;
    await GameController.getActiveGames(req, res);
});

// 10b2. One provider, every sub-category and its games (public).
// `:provider` takes the slug (`red-tiger`) or the numeric id (`24`).
router.get('/games/slot-providers/:provider/categories', asSlot(GameController.getSlotProviderCategories));

// 10c. Full ordered group incl. inactive; `ungrouped` lists unassigned games (owner only)
router.get('/admin/slot-providers/:provider/games', authMiddleware, requireOwner, asSlot(GameController.getSlotProviderGames));

// 10d. Replace a group's ordered game list (owner only)
router.post('/admin/slot-providers/:provider/games', authMiddleware, requireOwner, asSlot(GameController.setSlotProviderGames));

// 10e. Create a provider group (owner only)
router.post('/admin/slot-providers', authMiddleware, requireOwner, asSlot(GameController.createSlotProvider));

// 10f. Reorder the provider strip (owner only) — must precede /:provider
router.put('/admin/slot-providers/order', authMiddleware, requireOwner, asSlot(GameController.reorderSlotProviders));

// 10g. Rename a provider group (owner only)
router.put('/admin/slot-providers/:provider', authMiddleware, requireOwner, asSlot(GameController.updateSlotProvider));

// 10h. Delete a provider group — its games become ungrouped (owner only)
router.delete('/admin/slot-providers/:provider', authMiddleware, requireOwner, asSlot(GameController.deleteSlotProvider));

// --- Sub-categories inside a provider group (owner only) ---
// Jili is Slot Game / Table Game / Fish Game / Crash Game, Red Tiger is
// New Slots / 3REEL…7REEL. Tab order is the order those games appear in the
// provider's flat list, so it reorders the app the same way provider order does.

// 10i. Tab strip with counts, inactive games included
router.get('/admin/slot-providers/:provider/categories', authMiddleware, requireOwner, asSlot(GameController.listSlotProviderCategoriesAdmin));

// 10j. Create a tab
router.post('/admin/slot-providers/:provider/categories', authMiddleware, requireOwner, asSlot(GameController.createSlotProviderCategory));

// 10k. Reorder the tab strip — must precede /:slug
router.put('/admin/slot-providers/:provider/categories/order', authMiddleware, requireOwner, asSlot(GameController.reorderSlotProviderCategories));

// 10l. One tab's ordered games incl. inactive; `uncategorized` lists the
// group's games no tab claims
router.get('/admin/slot-providers/:provider/categories/:slug/games', authMiddleware, requireOwner, asSlot(GameController.getSlotProviderCategoryGames));

// 10m. Replace one tab's ordered game list
router.post('/admin/slot-providers/:provider/categories/:slug/games', authMiddleware, requireOwner, asSlot(GameController.setSlotProviderCategoryGames));

// 10n. Rename a tab (slug never changes)
router.put('/admin/slot-providers/:provider/categories/:slug', authMiddleware, requireOwner, asSlot(GameController.updateSlotProviderCategory));

// 10o. Delete a tab — its games stay in the group, uncategorized
router.delete('/admin/slot-providers/:provider/categories/:slug', authMiddleware, requireOwner, asSlot(GameController.deleteSlotProviderCategory));

// --- Provider groups and tabs, for ANY category ---
// Same machinery as the slot routes above, with the category in the path:
//   /games/category/fantasy/providers
//   /admin/category/fantasy/providers/saba/categories/sportsbook/games
// A category with no groups is untouched by all of this — it keeps its single
// flat priority queue, exactly as before.

// 14a. Provider strip with counts and tabs (public)
router.get('/games/category/:category/providers', async (req, res) => {
    await GameController.listSlotProviders(req, res);
});

// 14b. Games of one provider group, in group order (public)
router.get('/games/category/:category/providers/:provider/games', async (req, res) => {
    req.query.category = req.params.category;
    req.query.provider = req.params.provider;
    await GameController.getActiveGames(req, res);
});

// 14c. One provider, every tab and its games (public)
router.get('/games/category/:category/providers/:provider/categories', async (req, res) => {
    await GameController.getSlotProviderCategories(req, res);
});

// 14d. Full ordered group incl. inactive; `ungrouped` lists unassigned (owner only)
router.get('/admin/category/:category/providers/:provider/games', authMiddleware, requireOwner, async (req, res) => {
    await GameController.getSlotProviderGames(req, res);
});

// 14e. Replace a group's ordered game list (owner only)
router.post('/admin/category/:category/providers/:provider/games', authMiddleware, requireOwner, async (req, res) => {
    await GameController.setSlotProviderGames(req, res);
});

// 14f. Create a provider group (owner only)
router.post('/admin/category/:category/providers', authMiddleware, requireOwner, async (req, res) => {
    await GameController.createSlotProvider(req, res);
});

// 14g. Reorder the provider strip (owner only) — must precede /:provider
router.put('/admin/category/:category/providers/order', authMiddleware, requireOwner, async (req, res) => {
    await GameController.reorderSlotProviders(req, res);
});

// 14h. Rename a provider group (owner only)
router.put('/admin/category/:category/providers/:provider', authMiddleware, requireOwner, async (req, res) => {
    await GameController.updateSlotProvider(req, res);
});

// 14i. Delete a provider group — its games become ungrouped (owner only)
router.delete('/admin/category/:category/providers/:provider', authMiddleware, requireOwner, async (req, res) => {
    await GameController.deleteSlotProvider(req, res);
});

// 14j. Tab strip with counts, inactive included (owner only)
router.get('/admin/category/:category/providers/:provider/categories', authMiddleware, requireOwner, async (req, res) => {
    await GameController.listSlotProviderCategoriesAdmin(req, res);
});

// 14k. Create a tab (owner only)
router.post('/admin/category/:category/providers/:provider/categories', authMiddleware, requireOwner, async (req, res) => {
    await GameController.createSlotProviderCategory(req, res);
});

// 14l. Reorder the tab strip (owner only) — must precede /:slug
router.put('/admin/category/:category/providers/:provider/categories/order', authMiddleware, requireOwner, async (req, res) => {
    await GameController.reorderSlotProviderCategories(req, res);
});

// 14m. One tab's ordered games incl. inactive; `uncategorized` = untabbed (owner only)
router.get('/admin/category/:category/providers/:provider/categories/:slug/games', authMiddleware, requireOwner, async (req, res) => {
    await GameController.getSlotProviderCategoryGames(req, res);
});

// 14n. Replace one tab's ordered game list (owner only)
router.post('/admin/category/:category/providers/:provider/categories/:slug/games', authMiddleware, requireOwner, async (req, res) => {
    await GameController.setSlotProviderCategoryGames(req, res);
});

// 14o. Rename a tab (owner only)
router.put('/admin/category/:category/providers/:provider/categories/:slug', authMiddleware, requireOwner, async (req, res) => {
    await GameController.updateSlotProviderCategory(req, res);
});

// 14p. Delete a tab — its games stay in the group, untabbed (owner only)
router.delete('/admin/category/:category/providers/:provider/categories/:slug', authMiddleware, requireOwner, async (req, res) => {
    await GameController.deleteSlotProviderCategory(req, res);
});

// --- Admin catalog management ---

// 11. Full game list incl. inactive (owner only)
router.get('/admin/games', authMiddleware, requireOwner, async (req, res) => {
    await GameController.listAdminGames(req, res);
});

// 12. Edit a game — name / icon / type / description / active (owner only)
router.put('/admin/games/:id', authMiddleware, requireOwner, async (req, res) => {
    await GameController.updateGame(req, res);
});

// 12b. Set a game's manual category membership (owner only)
router.put('/admin/games/:id/categories', authMiddleware, requireOwner, async (req, res) => {
    await GameController.setGameCategories(req, res);
});

// 12c. Move a game into a provider group, optionally into one of its tabs.
// Body: { provider: 'jili' | null, category?: 'slot-game' | null, game_category?: 'slot' }
// `category` here is the TAB slug (slot-era naming); `game_category` is the
// top-level category and defaults to slot. (owner only)
router.put('/admin/games/:id/slot-provider', authMiddleware, requireOwner, async (req, res) => {
    await GameController.setGameSlotProvider(req, res);
});

// 12d. Same move, with the top-level category in the path (owner only)
router.put('/admin/category/:category/games/:id/provider', authMiddleware, requireOwner, async (req, res) => {
    req.body.game_category = req.params.category;
    await GameController.setGameSlotProvider(req, res);
});

// 13. Distinct vendors with counts, optional ?category= (owner only)
router.get('/admin/vendors', authMiddleware, requireOwner, async (req, res) => {
    await GameController.getVendors(req, res);
});

export default router;
