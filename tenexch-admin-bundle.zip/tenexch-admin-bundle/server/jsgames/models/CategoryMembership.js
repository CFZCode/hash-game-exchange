import { DataTypes } from 'sequelize';
import sequelize from '../../config/db.js';

// Manual category membership per category (crash / lottery / slot / fantasy).
// Categories are normally DERIVED from game_type via ILIKE patterns; this table
// lets an admin explicitly pin any game into a category regardless of its type.
// game_ids is a comma-separated list of js_games.id — order does not matter here
// (ordering is owned by prioritized_categories, this is membership only).
const CategoryMembership = sequelize.define('CategoryMembership', {
  category: {
    type: DataTypes.STRING,
    primaryKey: true,
  },
  game_ids: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
}, {
  tableName: 'category_memberships',
  timestamps: false,
});

export default CategoryMembership;
