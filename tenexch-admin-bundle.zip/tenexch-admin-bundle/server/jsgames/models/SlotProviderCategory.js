import { DataTypes } from 'sequelize';
import sequelize from '../../config/db.js';

// Sub-categories inside one slot provider group — the tab strip the player sees
// after picking a provider (Jili → Slot Game / Table Game / Fish Game / Crash
// Game, Red Tiger → New Slots / 3REEL…7REEL, EGT → All Games).
//
// They cannot be derived from js_games.game_type: Jili's rows come back as
// "Slot Game", "Slot" and "slot" while the site shows four clean tabs, and every
// Red Tiger row is "Slot" while the site shows six. So the list is curated, the
// same way provider groups are.
//
// Rules, mirroring the provider level one step down:
//   - a game belongs to at most one category inside its provider
//   - game_ids order IS the grid order, sort_order IS the tab order
//   - the provider's flat game_ids is derived: its categories concatenated in
//     sort_order, then whatever the provider holds that no category claims
const SlotProviderCategory = sequelize.define('SlotProviderCategory', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  // Denormalized from the owning provider so "one game, one tab" can be scoped
  // to a category without a join. A tab never moves between providers, so this
  // is set once at creation and never drifts.
  category: {
    type: DataTypes.STRING,
    allowNull: false,
    defaultValue: 'slot',
  },
  provider: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  slug: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  label: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  game_ids: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  sort_order: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 0,
  },
}, {
  tableName: 'slot_provider_categories',
  timestamps: false,
  // Named so sync({ alter: true }) matches it instead of re-adding it every boot
  indexes: [
    { name: 'slot_provider_categories_provider_slug', unique: true, fields: ['provider', 'slug'] },
    { name: 'slot_provider_categories_provider', fields: ['provider'] },
    { name: 'slot_provider_categories_category', fields: ['category'] },
  ],
});

export default SlotProviderCategory;
