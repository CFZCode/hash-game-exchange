import { DataTypes } from 'sequelize';
import sequelize from '../../config/db.js';

// Provider groups inside the "slot" category.
// A slot game belongs to exactly one provider group; game_ids is a
// comma-separated list of js_games.id and its order IS the in-group order.
// The flat slot queue (prioritized_categories.slot) is rebuilt from these
// groups, concatenated in sort_order — so provider order drives app order.
const SlotProvider = sequelize.define('SlotProvider', {
  // Which top-level category these groups live in (crash / lottery / slot /
  // fantasy). Defaults to slot because slot is where the feature started and
  // every existing row belongs to it. `provider` stays the primary key, so a
  // slug is unique across all categories — createSlotProvider suffixes the
  // category when two categories want the same name.
  category: {
    type: DataTypes.STRING,
    allowNull: false,
    defaultValue: 'slot',
  },
  provider: {
    type: DataTypes.STRING,
    primaryKey: true,
  },
  // The number in the player-facing /slot/:id URL. These are the live site's
  // own ids (1X2 is 1, Jili is 64, Kingmidas is 99) — not a sequence, already
  // public as links, so they are seeded verbatim and never renumbered.
  // Uniqueness is enforced in the controller, not by a DB constraint, because
  // sync({ alter: true }) re-adds column-level unique constraints on every boot.
  ext_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  label: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  game_ids: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  sort_order: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 0,
  },
}, {
  tableName: 'slot_providers',
  timestamps: false,
  indexes: [
    { name: 'slot_providers_category', fields: ['category'] },
  ],
});

export default SlotProvider;
