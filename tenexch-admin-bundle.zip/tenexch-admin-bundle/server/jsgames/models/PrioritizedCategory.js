import { DataTypes } from 'sequelize';
import sequelize from '../../config/db.js';

// Priority queue per game category (crash / lottery / slot / fantasy).
// game_ids is a comma-separated list of js_games.id — list order IS the queue order.
const PrioritizedCategory = sequelize.define('PrioritizedCategory', {
  category: {
    type: DataTypes.STRING,
    primaryKey: true,
  },
  game_ids: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
}, {
  tableName: 'prioritized_categories',
  timestamps: false,
});

export default PrioritizedCategory;
