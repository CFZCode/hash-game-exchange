
import express from "express";
import axios from "axios";
import bcrypt from "bcrypt";
import authMiddleware from "../middleware/authMiddleware.js";
import { requireOwner } from "../middleware/permissionMiddleware.js";
import verifyTransactionPassword from "../middleware/transactionPasswordMiddleware.js";
const router = express.Router();
import controller from "./controller.js";

// Manual settlement is an owner-only workflow — no staff hierarchy, no executives.
router.get('/momatches', authMiddleware, requireOwner, controller.getMoMatches);
router.get('/fanmatches', authMiddleware, requireOwner, controller.getFanOpenBets);
router.post('/declareresult', authMiddleware, requireOwner, controller.declareResult);
router.post('/void', authMiddleware, requireOwner, controller.voidResult);
router.get('/open-bets', authMiddleware, requireOwner, controller.getOpenBetsForMarket);
router.post('/void-single-bet', authMiddleware, requireOwner, controller.voidSingleOpenBet);

// Void audit trail — every voided bet with its pre/after wallet + exposure.
// Read-only report, so no transaction password; still owner-only like the rest.
router.get('/void-audit', authMiddleware, requireOwner, controller.getVoidAudit);

// Casino — unsettled (stuck) bets list + void. Owner-only, aur void par
// transaction password bhi, kyunki ye seedha user ke cash me paisa wapas karta hai.
router.get('/casino-open-bets', authMiddleware, requireOwner, controller.getCasinoOpenBets);
router.post('/void-casino-bets', authMiddleware, requireOwner, verifyTransactionPassword, controller.voidCasinoOpenBets);

// Casino — settle ho chuki bets ka void (case 2: cash + inr dono badalte hain)
router.get('/casino-settled-bets', authMiddleware, requireOwner, controller.getCasinoSettledBets);
router.post('/void-settled-casino-bet', authMiddleware, requireOwner, verifyTransactionPassword, controller.voidSettledCasinoBet);

// Sports — settle ho chuke markets ka void (admin "Void Bets (After Settlement)" page).
// Ye chaar routes frontend me pehle se call ho rahe the par server par the hi nahi.
router.get('/settled-markets', authMiddleware, requireOwner, controller.getSettledMarkets);
router.get('/settled-bets', authMiddleware, requireOwner, controller.getSettledBets);
router.post('/void-bet-after-settlement', authMiddleware, requireOwner, verifyTransactionPassword, controller.voidBetAfterSettlement);
router.post('/void-market-after-settlement', authMiddleware, requireOwner, verifyTransactionPassword, controller.voidMarketAfterSettlement);




// module.exports = router;
export default router;
