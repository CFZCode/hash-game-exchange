

import Wallet from "../model/admin/Wallet.js";
import SportsBet from "../model/user/SportsBet.js";
import UserExposure from "../model/user/UserExposure.js";
import { exposureIdentity, isLineMarket } from "../helper/lineMarket.js";
import { isBadloBet, BADLO_EXPOSURE_GAME_TYPE } from "../helper/badloMarket.js";
// Exposure bucketing (per-market vs per-selection) lives in one place so the
// void paths, placement and the snapshot writer cannot drift apart.
import {
    isPerSelectionMarket,
    selectionExposureRows,
    releasableLiability,
    additiveBucketLiability,
} from "../helper/exposureBucket.js";
import { recalcTotalExposure } from "../helper/totalExposure.js";
// Settlement-queue plumbing shared with the results cron (newjobv2.js) — a bet
// only settles once it has a SportsEventSettlementJob row.
import { enqueueManualBets } from "../sportsbet/betresult/settlementQueue.js";
import TotalExposure from "../model/user/TotalExposure.js";
import BetVoidAudit from "../model/admin/BetVoidAudit.js";
import CreditsLedger from "../model/user/CreditsLedger.js";
import User from "../model/user/User.js";

import sequelize from "../config/db.js";

import MannualResult from '../model/admin/manualresult.js'

import { Op, Sequelize } from "sequelize";

import { fn, col, literal } from "sequelize";

import { listUnsettledCasinoBets, voidCasinoBets, listSettledCasinoBets, voidSettledCasinoBet } from "../services/admin/casinoVoidService.js";
import ActivityLogService from "../services/admin/ActivityLogService.js";
import {
    recordVoidAudit,
    newVoidGroupId,
    actorFrom,
    VOID_TYPES,
} from "../services/admin/voidAuditService.js";
import { voidOpenMarket, recordVoidRefund } from "../services/admin/sportsMarketVoidService.js";
import {
    listSettledMarkets,
    listSettledBets,
    voidSettledLedgerEntry,
    voidSettledMarket,
} from "../services/admin/sportsVoidService.js";

/**
 * Record a manual void's exposure release in credits_ledger.
 * Implementation moved to services/admin/sportsMarketVoidService.js
 * (recordVoidRefund) on 2026-09-16 so the auto-void timer writes the identical
 * row. Kept under its old name for voidSingleOpenBet below.
 */
const recordManualVoidRefund = (args, t) => recordVoidRefund(args, t);

let cachedUsdRate = 0;
let cachedAt = 0;

/**
 * MAX(runners::text) comes back as a JSON string (or null on rows written
 * before the column existed). Anything unparseable degrades to null, which
 * leaves the declare modal on its team_one/team_two fallback rather than
 * breaking the whole match list.
 */
const parseRunners = (raw) => {
    if (!raw) return null;
    if (Array.isArray(raw)) return raw.length ? raw : null;
    try {
        const parsed = JSON.parse(raw);
        return Array.isArray(parsed) && parsed.length ? parsed : null;
    } catch {
        return null;
    }
};

const getMoMatches = async (req, res) => {
    const limit = parseInt(req.query.limit, 10) || 100;
    const offset = parseInt(req.query.offset, 10) || 0;

    try {
        const rows = await SportsBet.findAll({
            attributes: [
                'match_id',
                'eventid',
                'game_type',
                'market_type',
                [fn('MAX', col('match_title')), 'match_title'],
                [fn('MAX', col('team_one')), 'team_one'],
                [fn('MAX', col('team_two')), 'team_two'],
                [fn('COUNT', col('*')), 'totalbets'],
                [fn('MAX', col('counts')), 'counts'],
                // Same bug getFanOpenBets fixed below: without the runner list
                // the declare modal falls back to [team_one, team_two], so a
                // 3-way market's draw has no button and cannot be declared.
                // `runners` is json, which has no MAX aggregate in Postgres —
                // cast to text here and parse it back in the mapper.
                [literal('MAX(runners::text)'), 'runners']
            ],
            where: {
                game_type: { [Op.or]: ['MO', 'BM'] },
                status: 'open',
                match_id: { [Op.ne]: null },
                eventid: { [Op.ne]: null }
            },
            group: ['match_id', 'eventid', 'game_type', 'market_type'],
            order: [[fn('MAX', col('created_at')), 'DESC']],
            limit,
            offset,
            raw: true
        });

        const payload = rows.map(r => ({
            matchId: r.match_id,
            eventId: r.eventid,
            gameType: r.game_type,
            marketType: r.market_type,
            matchTitle: r.match_title,
            teamOne: r.team_one,
            teamTwo: r.team_two,
            totalBets: parseInt(r.totalbets, 10),
            counts: r.counts !== null ? Number(r.counts) : null,
            runners: parseRunners(r.runners)
        }));

        return res.json({ success: true, data: payload });
    } catch (err) {
        console.error('getMoMatches error:', err);
        return res.status(500).json({ success: false, error: err.message });
    }
};

// ------------------------ EXPORT ------------------------
const getFanOpenBets = async (req, res) => {
    // Optional paging. The admin Fancy Settlement page sends none and pages
    // each tab itself, so by default every open group comes back — a fixed
    // 100 cut across ALL tabs used to hide most of the Normal tab.
    const limit = parseInt(req.query.limit, 10) || undefined;
    const offset = parseInt(req.query.offset, 10) || undefined;

    const marketsforfancy = [
        '1st Innings 6 Overs Line',
        '2nd Innings 6 Overs Line',
        '3rd Innings 6 Overs Line',
        '1st Innings 50 Overs Line',
        '2nd Innings 50 Overs Line',
        '3rd Innings 50 Overs Line',
        '1st Innings 40 Overs Line',
        '2nd Innings 40 Overs Line',
        '3rd Innings 40 Overs Line',
        '1st Innings 30 Overs Line',
        '2nd Innings 30 Overs Line',
        '3rd Innings 30 Overs Line',
        '1st Innings 20 Overs Line',
        '2nd Innings 20 Overs Line',
        '3rd Innings 20 Overs Line',
        '1st Innings 10 Overs Line',
        '2nd Innings 10 Overs Line',
        '3rd Innings 10 Overs Line',
        'Over By Over',
        'Ball By Ball',
        'Normal',
        'khado',
        'meter',
        'fancy1',
        'oddeven',
        'badlo'
    ];

    try {
        // 1. Get Aggregated Groups
        const groups = await SportsBet.findAll({
            attributes: [
                'match_id',
                'eventid',
                'match_id',
                'eventid',
                'market_type',
                'selection_name',
                'game_type',
                [fn('MAX', col('match_title')), 'match_title'],
                [fn('COUNT', col('*')), 'totalbets'],
                [fn('MAX', col('counts')), 'counts']
            ],
            where: {
                // game_type: 'FAN', // Removed to follow previous pattern if user wants mo/bm here too? NO, user said "getFanOpenBets". Let's assume FAN only unless told.
                // Wait, "gametype should come proper".
                // I will include game_type in attributes.
                game_type: 'FAN',
                status: 'open',
                match_id: { [Op.ne]: null },
                eventid: { [Op.ne]: null }
                // removed strict market_type filter to include others
            },
            group: ['match_id', 'eventid', 'market_type', 'selection_name', 'game_type'],
            order: [[fn('MAX', col('created_at')), 'DESC']],
            limit,
            offset,
            raw: true
        });

        if (!groups.length) {
            return res.json({ success: true, data: { fancy1: [], others: [] } });
        }

        // 2. Build Criteria for Details
        const criteria = groups.map(g => ({
            match_id: g.match_id,
            eventid: g.eventid,
            market_type: g.market_type,
            selection_name: g.selection_name,
            game_type: g.game_type
        }));

        // Unpaged, every open FAN bet belongs to a returned group, so the
        // groups' own filter replaces a (~300-term) OR over the criteria.
        const bets = await SportsBet.findAll({
            where: limit
                ? { status: 'open', [Op.or]: criteria }
                : { game_type: 'FAN', status: 'open', match_id: { [Op.ne]: null }, eventid: { [Op.ne]: null } },
            order: [['created_at', 'ASC']],
            raw: true
        });

        // 3. Grouping Map
        const groupMap = new Map();
        groups.forEach(g => {
            let mType = g.market_type;
            let groupKey = mType; // Default: use the market type itself

            if (!marketsforfancy.includes(mType)) {
                // Keep original mType, but group under 'others'
                groupKey = 'others';
            }

            // Unique key for the map entry - use original mType to keep distinct groups
            const key = `${g.match_id}||${g.eventid}||${mType}||${g.game_type}||${g.selection_name}`;

            if (groupMap.has(key)) {
                const existing = groupMap.get(key);
                existing.totalBets += parseInt(g.totalbets, 10);
            } else {
                groupMap.set(key, {
                    groupKey,
                    matchId: g.match_id,
                    eventId: g.eventid,
                    matchTitle: g.match_title,
                    marketType: mType, // Original type
                    selectionName: g.selection_name,
                    gameType: g.game_type,
                    totalBets: parseInt(g.totalbets, 10),
                    counts: g.counts !== null ? Number(g.counts) : null,
                    bets: []
                });
            }
        });

        // 4. Attach Bets
        bets.forEach(b => {
            let mType = b.market_type;
            // Previously we overwrote mType to 'Others' here too if not in list.
            // Now we don't, because we want to key off the original type.

            const key = `${b.match_id}||${b.eventid}||${mType}||${b.game_type}||${b.selection_name}`;
            const bucket = groupMap.get(key);
            if (bucket) {
                bucket.bets.push({
                    id: b.id,
                    userId: b.user_id,
                    betType: b.bet_type,
                    selectionName: b.selection_name,
                    marketType: b.market_type,
                    gameType: b.game_type,
                    teamOne: b.team_one,
                    teamTwo: b.team_two,
                    odds: b.odds !== null ? Number(b.odds) : null,
                    stakeAmount: b.stake_amount !== null ? Number(b.stake_amount) : null,
                    originalCurrency: b.original_currency,
                    originalAmount: b.original_amount !== null ? Number(b.original_amount) : null,
                    usdAmount: b.usd_amount !== null ? Number(b.usd_amount) : null,
                    liability: b.liability !== null ? Number(b.liability) : null,
                    status: b.status,
                    createdAt: b.created_at,
                    counts: b.counts !== null ? Number(b.counts) : null,
                    // The declare modal offers ONE BUTTON PER RUNNER when the
                    // bet carries a runner list ("0 Number" … "9 Number", a
                    // 10-way market). Without this field it saw `undefined`,
                    // fell back to [team_one, 'Draw', team_two] on counts >= 3,
                    // and an operator could only ever declare the first runner,
                    // a draw, or the second — the other 8 were unreachable.
                    // Sequelize returns this JSON column already parsed.
                    runners: b.runners || null
                });
            }
        });

        // 5. Final Payload
        const payload = {};
        // Initialize payload keys
        marketsforfancy.forEach(m => {
            payload[m] = [];
        });
        payload['others'] = [];

        for (const val of groupMap.values()) {
            const listKey = val.groupKey;
            delete val.groupKey;

            if (payload[listKey]) {
                payload[listKey].push(val);
            } else {
                // strict fallback, though if logic holds it should already be 'others'
                payload['others'].push(val);
            }
        }

        return res.json({ success: true, data: payload });

    } catch (err) {
        console.error('getFanOpenBets error:', err);
        return res.status(500).json({ success: false, error: err.message });
    }
};




const declareResult = async (req, res) => {
    const { eventid, match_id, match_title, game_type, market_type, winnerName, winnerId, fancyName } = req.body;

    // 1. Basic Validation
    if (!eventid || !match_id || !match_title || !game_type || !market_type) {
        return res.status(400).json({
            success: false,
            error: "Missing required fields: eventid, match_id, match_title, game_type, market_type"
        });
    }

    // Specific Validation based on Game Type
    if (['MO', 'BM'].includes(game_type)) {
        if (!winnerName) {
            return res.status(400).json({ success: false, error: "winnerName is required for MO and BM" });
        }
    } else if (game_type === 'FAN') {
        // fancyName is always essential for FAN

        const marketsforfancy = [
            '1st Innings 6 Overs Line',
            '2nd Innings 6 Overs Line',
            '3rd Innings 6 Overs Line',
            '1st Innings 50 Overs Line',
            '2nd Innings 50 Overs Line',
            '3rd Innings 50 Overs Line',
            '1st Innings 40 Overs Line',
            '2nd Innings 40 Overs Line',
            '3rd Innings 40 Overs Line',
            '1st Innings 30 Overs Line',
            '2nd Innings 30 Overs Line',
            '3rd Innings 30 Overs Line',
            '1st Innings 20 Overs Line',
            '2nd Innings 20 Overs Line',
            '3rd Innings 20 Overs Line',
            '1st Innings 10 Overs Line',
            '2nd Innings 10 Overs Line',
            '3rd Innings 10 Overs Line',
            'Over By Over',
            'Ball By Ball',
            'Normal',
            'khado',
            'meter',
            'badlo',

        ];

        // Every "... Line" market settles on a run total, not only the over
        // counts named above — "1st Innings 15 Overs Line" and the team-prefixed
        // / whole-innings lines used to fall to the winnerName branch and 400,
        // because the admin modal sends a winnerId for them.
        const lineMarket = isLineMarket(market_type);
        if (lineMarket && !/^\d+$/.test(String(winnerId ?? '').trim())) {
            return res.status(400).json({ success: false, error: "winnerId must be the run total (a whole number) for a line market" });
        }

        if (marketsforfancy.includes(market_type) || lineMarket) {
            if (['fancy1', 'oddeven'].includes(market_type)) {
                if (!winnerName) {
                    return res.status(400).json({ success: false, error: "winnerName is required for this fancy market" });
                }
            } else {
                if (!winnerId) {
                    return res.status(400).json({ success: false, error: "winnerId is required for this fancy market" });
                }
            }

            if (!fancyName) {
                return res.status(400).json({ success: false, error: "fancyName is required for this fancy market" });
            }
        } else {
            // Fancy but not in the list -> WinnerName essential
            if (!winnerName) {
                return res.status(400).json({ success: false, error: "winnerName is required for this fancy market" });
            }
        }
    }

    const t = await sequelize.transaction();

    try {
        // 2. Insert into MannualResult
        // Updated column names: winnerName, winnerId, fancyName
        const newResult = await MannualResult.create({
            eventid,
            match_id,
            match_title,
            game_type,
            market_type,
            winnerName: winnerName || null,
            winnerId: winnerId || null,
            fancyName: fancyName || null
        }, { transaction: t });

        // 3. Update SportsBet status to 'manual'
        const [updatedCount] = await SportsBet.update(
            { status: 'manual' },
            {
                where: {
                    match_id: match_id,
                    market_type: market_type,
                    game_type: game_type,
                    status: 'open',
                    ...(['fancy1', 'oddeven', 'Over By Over', 'Ball By Ball', 'khado', 'meter', 'Normal', 'badlo'].includes(market_type)
                        ? { selection_name: fancyName }
                        : {})
                },
                transaction: t
            }
        );

        await t.commit();

        // Queue the bets we just flipped, then wake the settlement worker.
        //
        // Without this a manual declare only marks the bets and waits for the
        // results cron to enqueue them on its next full scan — and that scan
        // hits the upstream feed per event, so when the feed is slow it takes
        // minutes (8m 45s observed on 2026-09-20). Worse, the cron snapshots
        // its bet list at the start of a pass, so a bet declared mid-scan is
        // invisible until the pass AFTER next. The owner had already made the
        // decision; it should not queue behind a third-party timeout.
        //
        // Best-effort on purpose: the cron remains the safety net, so a failure
        // here delays settlement rather than losing it, and must never fail a
        // declare that is already committed.
        let settlement = null;
        try {
            settlement = await enqueueManualBets({
                eventid,
                match_id,
                market_type,
                log: { info: console.log, error: console.error, debug: () => { } },
            });
        } catch (e) {
            console.error('declareResult: settlement enqueue failed', e.message);
        }

        return res.json({
            success: true,
            message: "Result declared successfully",
            data: {
                manualResult: newResult,
                updatedBets: updatedCount,
                settlement
            }
        });

    } catch (error) {
        await t.rollback();
        console.error("declareResult error:", error);
        return res.status(500).json({
            success: false,
            error: error.message || "Internal Server Error"
        });
    }
};

const voidResult = async (req, res) => {
    const { eventid, match_id, market_type, gametype, selection_name } = req.body;

    // 1. Basic Validation
    if (!eventid || !match_id || !market_type) {
        return res.status(400).json({
            success: false,
            error: "Missing required fields: eventid, match_id, market_type"
        });
    }

    try {
        // The void itself (bucket rules, refund, ledger, audit) lives in
        // services/admin/sportsMarketVoidService.js — shared with the
        // auto-void timer (sportsbet/betresult/autoVoid.js).
        const { userIds, betsVoided, voidGroupId } = await voidOpenMarket({
            match_id,
            market_type,
            gametype,
            selection_name,
            voidType: VOID_TYPES.MARKET,
            context: actorFrom(req),
        });

        return res.json({
            success: true,
            message: "Voided successfully",
            count: userIds.length,
            betsVoided,
            voidGroupId,
        });

    } catch (error) {
        console.error("voidResult error:", error);
        return res.status(500).json({
            success: false,
            error: error.message || "Internal Server Error"
        });
    }
};

// ---------------------------------------------------------------------------
// GET /open-bets — list every open bet of one market (shown before per-bet void)
// Read-only. No DB writes.
// ---------------------------------------------------------------------------
const getOpenBetsForMarket = async (req, res) => {
    const { match_id, market_type, game_type, selection_name } = req.query;

    if (!match_id || !market_type) {
        return res.status(400).json({
            success: false,
            error: "match_id and market_type are required"
        });
    }

    try {
        const whereClause = { match_id, market_type, status: 'open' };
        if (game_type) whereClause.game_type = game_type;
        if (selection_name) whereClause.selection_name = selection_name;

        const bets = await SportsBet.findAll({
            where: whereClause,
            order: [['created_at', 'DESC']],
            raw: true
        });

        // Resolve usernames with a single IN query (avoids N+1)
        const userIds = [...new Set(bets.map(b => b.user_id).filter(Boolean))];
        const userMap = {};
        if (userIds.length > 0) {
            const users = await User.findAll({
                where: { user_id: { [Op.in]: userIds } },
                attributes: ['user_id', 'username'],
                raw: true
            });
            users.forEach(u => { userMap[u.user_id] = u.username; });
        }

        const data = bets.map(b => ({
            id: b.id,
            userId: b.user_id,
            username: userMap[b.user_id] || null,
            betType: b.bet_type,
            selectionName: b.selection_name,
            marketType: b.market_type,
            gameType: b.game_type,
            odds: b.odds !== null ? Number(b.odds) : null,
            stakeAmount: b.stake_amount !== null ? Number(b.stake_amount) : null,
            liability: b.liability !== null ? Number(b.liability) : null,
            status: b.status,
            matchId: b.match_id,
            eventId: b.eventid,
            createdAt: b.created_at
        }));

        return res.json({ success: true, data });

    } catch (error) {
        console.error('getOpenBetsForMarket error:', error);
        return res.status(500).json({
            success: false,
            error: error.message || "Internal Server Error"
        });
    }
};

// ---------------------------------------------------------------------------
// POST /void-single-bet — void one bet. Whole thing runs in a transaction.
// Exposure is only refunded when this was the user's LAST open bet on the
// market, because exposure is tracked per market, not per bet.
// ---------------------------------------------------------------------------
const voidSingleOpenBet = async (req, res) => {
    const { bet_id } = req.body;

    if (!bet_id) {
        return res.status(400).json({ success: false, error: "bet_id is required" });
    }

    const t = await sequelize.transaction();

    try {
        // 1. Only an 'open' bet can be voided — makes this idempotent
        const bet = await SportsBet.findOne({
            where: { id: bet_id, status: 'open' },
            transaction: t
        });

        if (!bet) {
            await t.rollback();
            return res.status(404).json({ success: false, error: "Open bet not found" });
        }

        const uid = bet.user_id;
        const match_id = bet.match_id;
        const market_type = bet.market_type;

        // Wallet + snapshot as they stand BEFORE anything moves. Read on this
        // transaction so the audit row records the true pre-state even if a
        // concurrent write lands between now and the commit.
        const walletBefore = await Wallet.findOne({
            where: { user_id: uid },
            attributes: ['cash', 'inr_balance'],
            transaction: t,
        });
        const snapBefore = await TotalExposure.findOne({
            where: { user_id: uid }, attributes: ['total_exposure'], transaction: t,
        });

        // 2. Which exposure bucket does this bet's money sit in?
        const badlo = isBadloBet(bet);
        const { game_type: expGameType, team_name: sel } = exposureIdentity({
            marketType: market_type,
            selectionName: bet.selection_name,
            badlo,
        });
        const perSelection = isPerSelectionMarket(market_type) || badlo;

        // Any other open bet of this user still holding that SAME bucket?
        // Scoping this to match_id + market_type alone is wrong for the fancy
        // family — each selection holds its own money, so an unrelated open bet
        // on another session made the gate false and the void released nothing
        // (see isPerSelectionMarket above).
        const otherBets = await SportsBet.count({
            where: {
                match_id,
                market_type,
                user_id: uid,
                status: 'open',
                id: { [Op.ne]: bet_id },
                ...(perSelection
                    ? { selection_name: bet.selection_name, badlo }
                    : {}),
            },
            transaction: t
        });

        // Carried out of the branch below so the audit row can report what the
        // void actually did, including when it deliberately did nothing.
        let refundAmount = 0;
        let ledgerId = null;
        let exposureRowsDeleted = 0;
        let exposureBefore = null;

        // 3. Refund exposure only when nothing else is holding it
        if (otherBets === 0) {
            // NOTE: UserExposure.game_type stores the market_type value.
            const exposureWhere = {
                user_id: uid,
                match_id: match_id,
                // Line markets file their rows under 'fancy2', keyed by the
                // market name rather than the runner — see helper/lineMarket.js.
                game_type: expGameType,
                // …and for a per-selection market, ONLY this selection's four
                // rows. Without this the destroy would wipe every other open
                // session of the same market_type and leave them unblocked.
                ...(perSelection
                    ? { team_name: { [Op.in]: selectionExposureRows(sel) } }
                    : {}),
            };

            const exposures = await UserExposure.findAll({
                where: exposureWhere,
                transaction: t
            });

            if (exposures.length > 0) {
                // The liability that was actually blocked at placement
                const minExp = releasableLiability(exposures, { perSelection, sel });
                exposureBefore = minExp;

                if (minExp < 0) {
                    refundAmount = Math.abs(minExp);
                    await Wallet.increment('cash', {
                        by: refundAmount,
                        where: { user_id: uid },
                        transaction: t
                    });
                    ledgerId = await recordManualVoidRefund({
                        uid,
                        refundAmount,
                        bet,   // the single bet being voided
                        actor: req.user?.actor?.username || req.user?.username,
                    }, t);
                }

                exposureRowsDeleted = await UserExposure.destroy({ where: exposureWhere, transaction: t });
            }
        }

        // 4. Close the bet
        await SportsBet.update(
            {
                status: 'closed',
                result_status: 'refunded',
                match_end_time: new Date()
            },
            { where: { id: bet_id }, transaction: t }
        );

        // 5. Snapshot follows the rows (see voidResult).
        // Runs even when step 3 was skipped — the user's other open bets still
        // hold this market, so the recompute simply lands on the same number.
        const totalAfter = await recalcTotalExposure(uid, t);

        // 6. Audit — inside the transaction, so a rolled-back void leaves no row
        // claiming it happened and a committed one can never be missing its row.
        const walletAfter = await Wallet.findOne({
            where: { user_id: uid },
            attributes: ['cash', 'inr_balance'],
            transaction: t,
        });
        await recordVoidAudit({
            voidGroupId: newVoidGroupId(),
            voidType: VOID_TYPES.OPEN_BET,
            bets: [bet],
            representativeBetId: bet.id,
            before: {
                status: 'open',
                resultStatus: bet.result_status,
                cash: walletBefore?.cash,
                inr: walletBefore?.inr_balance,
                exposure: exposureBefore,
                totalExposure: snapBefore?.total_exposure,
            },
            after: {
                status: 'closed',
                resultStatus: 'refunded',
                cash: walletAfter?.cash,
                inr: walletAfter?.inr_balance,
                // The bucket is gone when rows were destroyed; when the gate
                // held it is untouched and still equals the pre value.
                exposure: exposureRowsDeleted > 0 ? 0 : exposureBefore,
                totalExposure: totalAfter,
            },
            refundAmount,
            exposureRowsDeleted,
            ledgerId,
            context: {
                ...actorFrom(req),
                note: otherBets > 0
                    ? `exposure retained — ${otherBets} other open bet(s) still hold this bucket`
                    : null,
            },
        }, t);

        await t.commit();

        return res.json({
            success: true,
            message: "Bet voided successfully",
            betId: bet_id,
            userId: uid,
            refunded: refundAmount,
        });

    } catch (error) {
        await t.rollback();
        console.error('voidSingleOpenBet error:', error);
        return res.status(500).json({
            success: false,
            error: error.message || "Internal Server Error"
        });
    }
};

/* ──────────────────────────────────────────────────────────────────────────
 * CASINO — unsettled bets ka void (admin panel "Void Bets" ka Casino tab)
 * Money logic services/admin/casinoVoidService.js me hai; ye sirf HTTP shell.
 * ────────────────────────────────────────────────────────────────────────── */

// GET /api/internalsettle/casino-open-bets
const getCasinoOpenBets = async (req, res) => {
    try {
        const rounds = await listUnsettledCasinoBets();
        return res.json({ success: true, data: rounds });
    } catch (error) {
        console.error('getCasinoOpenBets error:', error);
        return res.status(500).json({ success: false, error: error.message || "Internal Server Error" });
    }
};

// POST /api/internalsettle/void-casino-bets   { bet_ids: [1,2], transactionPassword }
// Ek round ke saare unsettled bets ek saath bhejne hote hain — service partial
// round reject karti hai (exposure row poore market ka min() hota hai).
const voidCasinoOpenBets = async (req, res) => {
    const betIds = req.body?.bet_ids ?? (req.body?.bet_id != null ? [req.body.bet_id] : []);

    if (!Array.isArray(betIds) || betIds.length === 0) {
        return res.status(400).json({ success: false, error: "bet_ids is required" });
    }

    try {
        const result = await voidCasinoBets(betIds);

        // Paise wala action hai — kisne kiya, kitna refund hua, log me jaana chahiye
        await ActivityLogService.log({
            req,
            user: { id: req.user?.account?.id, username: req.user?.username, role: req.user?.role },
            action: 'CASINO_BET_VOID',
            details: result.refunds,
        });

        return res.json({
            success: true,
            message: `${result.voided} casino bet(s) voided across ${result.rounds} round(s)`,
            ...result,
        });
    } catch (error) {
        console.error('voidCasinoOpenBets error:', error);
        return res.status(400).json({ success: false, error: error.message || "Internal Server Error" });
    }
};

// GET /api/internalsettle/casino-settled-bets?search=&limit=&offset=
const getCasinoSettledBets = async (req, res) => {
    try {
        const data = await listSettledCasinoBets({
            search: req.query.search || '',
            result: req.query.result || '',
            limit: req.query.limit,
            offset: req.query.offset,
        });
        return res.json({ success: true, ...data });
    } catch (error) {
        console.error('getCasinoSettledBets error:', error);
        return res.status(500).json({ success: false, error: error.message || "Internal Server Error" });
    }
};

// POST /api/internalsettle/void-settled-casino-bet   { bet_id, transactionPassword }
// Settlement ke BAAD ka void — cash + inr_balance dono badalte hain, saath me
// P/L counters, credits ledger, staff bal_up aur all_point chain bhi ulti hoti hai.
const voidSettledCasinoBetHandler = async (req, res) => {
    const betId = req.body?.bet_id;
    if (!betId) {
        return res.status(400).json({ success: false, error: "bet_id is required" });
    }

    try {
        const result = await voidSettledCasinoBet(betId);

        await ActivityLogService.log({
            req,
            user: { id: req.user?.account?.id, username: req.user?.username, role: req.user?.role },
            action: 'CASINO_BET_VOID_AFTER_SETTLEMENT',
            details: result,
        });

        return res.json({
            success: true,
            message: `Bet #${result.betId} voided (was ${result.resultStatus}) — cash ${result.cashBefore} → ${result.cashAfter}, inr ${result.inrBefore} → ${result.inrAfter}`,
            ...result,
        });
    } catch (error) {
        console.error('voidSettledCasinoBet error:', error);
        return res.status(400).json({ success: false, error: error.message || "Internal Server Error" });
    }
};

/* SPORTS — settle ho chuke markets ka void ("Void Bets (After Settlement)").
 * Money logic services/admin/sportsVoidService.js me; ye sirf HTTP shell. */

// GET /api/internalsettle/settled-markets?limit=&offset=&search=
const getSettledMarkets = async (req, res) => {
    try {
        const { data, windowHours } = await listSettledMarkets({
            search: req.query.search || '',
            limit: req.query.limit,
            offset: req.query.offset,
        });
        return res.json({ success: true, windowHours, data });
    } catch (error) {
        console.error('getSettledMarkets error:', error);
        return res.status(500).json({ success: false, error: error.message || "Internal Server Error" });
    }
};

// GET /api/internalsettle/settled-bets?match_id=&market_type=
const getSettledBets = async (req, res) => {
    try {
        const data = await listSettledBets({
            matchId: req.query.match_id,
            marketType: req.query.market_type,
        });
        return res.json({ success: true, data });
    } catch (error) {
        console.error('getSettledBets error:', error);
        return res.status(400).json({ success: false, error: error.message || "Internal Server Error" });
    }
};

// POST /api/internalsettle/void-bet-after-settlement
//   { ledger_id, write_statement, transactionPassword }
//
// write_statement (admin dialog ka switch, default ON): ON = user ke statement
// me "… -void" wali ek nayi debit line banti hai. OFF = silent void — settlement
// aur commission ki entries statement se MITA di jaati hain. Paisa dono me ek
// jaisa wapas jaata hai; sirf trail ka farq hai (audit + activity log hamesha).
const voidBetAfterSettlement = async (req, res) => {
    const ledgerId = req.body?.ledger_id;
    const writeStatement = req.body?.write_statement !== false;
    if (!ledgerId) return res.status(400).json({ success: false, error: "ledger_id is required" });
    try {
        const result = await voidSettledLedgerEntry(ledgerId, null, { writeStatement });
        await ActivityLogService.log({
            req,
            user: { id: req.user?.account?.id, username: req.user?.username, role: req.user?.role },
            action: 'SPORTS_BET_VOID_AFTER_SETTLEMENT',
            details: result,
        });
        return res.json({
            success: true,
            message: `Settlement voided — cash ${result.cashBefore} -> ${result.cashAfter}, inr ${result.inrBefore} -> ${result.inrAfter}, ${result.betsVoided} bet(s) marked void`,
            ...result,
        });
    } catch (error) {
        console.error('voidBetAfterSettlement error:', error);
        return res.status(400).json({ success: false, error: error.message || "Internal Server Error" });
    }
};

// POST /api/internalsettle/void-market-after-settlement
//   { match_id, market_type, write_statement, transactionPassword }
const voidMarketAfterSettlement = async (req, res) => {
    const { match_id, market_type } = req.body || {};
    const writeStatement = req.body?.write_statement !== false;
    if (!match_id) return res.status(400).json({ success: false, error: "match_id is required" });
    try {
        const result = await voidSettledMarket({ matchId: match_id, marketType: market_type, writeStatement });
        await ActivityLogService.log({
            req,
            user: { id: req.user?.account?.id, username: req.user?.username, role: req.user?.role },
            action: 'SPORTS_MARKET_VOID_AFTER_SETTLEMENT',
            details: { match_id, market_type, writeStatement, affectedUsers: result.affectedUsers, entries: result.entries },
        });
        return res.json({
            success: true,
            message: `${result.entries} settlement entries voided across ${result.affectedUsers} user(s)`,
            ...result,
        });
    } catch (error) {
        console.error('voidMarketAfterSettlement error:', error);
        return res.status(400).json({ success: false, error: error.message || "Internal Server Error" });
    }
};

/* ────────────────────────────────────────────────────────────────────────────
 * VOID AUDIT REPORT — GET /api/internalsettle/void-audit
 *
 * Reads bet_void_audit. One row per bet; `void_group_id` ties a group together.
 *
 * MONEY MUST BE SUMMED PER GROUP, NOT PER ROW. `refund_amount` is the amount
 * released for the whole group and is repeated on every row of it, so a naive
 * SUM(refund_amount) over a 4-bet group reports 4x the real figure. The summary
 * below therefore aggregates over DISTINCT void_group_id.
 *
 * Query params: from, to (ISO dates), user_id, actor, void_type, bet_kind,
 *               group_id, page, limit.
 * ──────────────────────────────────────────────────────────────────────────── */
const getVoidAudit = async (req, res) => {
    try {
        const {
            from, to, user_id, actor, void_type, bet_kind, group_id,
            page = 1, limit = 50,
        } = req.query;

        const lim = Math.min(Math.max(parseInt(limit, 10) || 50, 1), 500);
        const pg = Math.max(parseInt(page, 10) || 1, 1);
        const off = (pg - 1) * lim;

        const where = {};
        if (from || to) {
            where.created_at = {};
            if (from) where.created_at[Op.gte] = new Date(from);
            // `to` arrives as a plain date from a picker. Without this it means
            // 00:00 on that day, which silently drops the whole last day.
            if (to) {
                const end = new Date(to);
                if (/^\d{4}-\d{2}-\d{2}$/.test(String(to))) end.setHours(23, 59, 59, 999);
                where.created_at[Op.lte] = end;
            }
        }
        if (user_id) where.user_id = user_id;
        if (actor) where.actor = { [Op.iLike]: `%${actor}%` };
        if (void_type) where.void_type = void_type;
        if (bet_kind) where.bet_kind = bet_kind;
        if (group_id) where.void_group_id = group_id;

        const { rows, count } = await BetVoidAudit.findAndCountAll({
            where,
            order: [['created_at', 'DESC'], ['bet_id', 'ASC']],
            limit: lim,
            offset: off,
        });

        // Summary covers the WHOLE filtered set, not just this page. MAX() per
        // group (not SUM) because refund_amount is repeated across the group.
        const groups = await BetVoidAudit.findAll({
            where,
            attributes: [
                'void_group_id',
                [fn('MAX', col('refund_amount')), 'refund_amount'],
            ],
            group: ['void_group_id'],
            raw: true,
        });
        const totalRefunded = groups.reduce((sum, g) => sum + Number(g.refund_amount || 0), 0);

        return res.json({
            success: true,
            data: rows,
            pagination: { page: pg, limit: lim, total: count, pages: Math.ceil(count / lim) },
            summary: {
                bets_voided: count,
                void_operations: groups.length,
                total_refunded: Math.round(totalRefunded * 100) / 100,
            },
        });
    } catch (error) {
        console.error('getVoidAudit error:', error);
        return res.status(500).json({ success: false, error: error.message });
    }
};

const controller = {
    getVoidAudit,
    getMoMatches,
    getFanOpenBets,
    declareResult,
    voidResult,
    getOpenBetsForMarket,
    voidSingleOpenBet,
    getCasinoOpenBets,
    voidCasinoOpenBets,
    getCasinoSettledBets,
    voidSettledCasinoBet: voidSettledCasinoBetHandler,
    getSettledMarkets,
    getSettledBets,
    voidBetAfterSettlement,
    voidMarketAfterSettlement
};

export default controller;
