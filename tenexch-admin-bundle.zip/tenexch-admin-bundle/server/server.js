
import express from 'express';
import dotenv from 'dotenv';
import cors from 'cors';
import { createServer } from 'http';
import { Server } from 'socket.io';

import setupAssociations from "./model/associations.js";
setupAssociations();

//cronjob for daily profit loss
import './jobs/dailyProfitLossJob.js';
// cronjob that purges a finished match's min/max overrides after the grace window
import './jobs/betLimitCleanupJob.js';

// Route Imports
import { rateLimit } from './middleware/rateLimit.js';
import { responseCrypto } from './middleware/responseCrypto.js';
import csRoutes from './routes/csRoutes.js';
import { attachSocketCrypto, sealBroadcast } from './services/secureChannelService.js';
import { createAdapter } from '@socket.io/redis-adapter';
import { isPrimary, ROLE } from './config/role.js';
import sequelize from './config/db.js';
import telegram2faRoutes from './routes/user/telegram2faRoutes.js';
import googleAuthRoutes from './routes/user/googleAuthRoutes.js';
import androidAuthRoutes from './routes/user/androidAuthRoutes.js';
import userAuthRoutes from './routes/user/userAuthRoutes.js';
import userActivityLogRoutes from './routes/user/userActivityLogRoutes.js';
import getResultRoute from './routes/user/getResultRoute.js';
import getResultRouteV2 from './routes/user/getResultRouteV2.js';
import userStatementRoutes from './routes/user/userStatementRoutes.js';
import ownerAuthRoutes from './routes/admin/ownerAuthRoutes.js';
import agentAuthRoutes from './routes/admin/agentAuthRoutes.js';
import transactionRoutes from './routes/admin/transactionRoutes.js';
import ownerRoutes from './routes/admin/ownerRoutes.js';
import userRoutes from './routes/admin/userRoutes.js';
import agentRoutes from './routes/admin/agentRoutes.js';
import adminWalletRoutes from './routes/admin/adminWalletRoutes.js';
import userWalletRoutes from './routes/user/userWalletRoutes.js';
import withdrawalRoutes from './routes/admin/withdrawalRoutes.js';
import affiliateRoutes from './routes/admin/affiliateRoutes.js';
import stakeButtonValueRoutes from './routes/user/stakeButtonValueRoutes.js';
import oneClickButtonRoutes from './routes/user/oneClickButtonRoutes.js';
import depositRoutes from './routes/admin/depositRoutes.js';
import fileRoutes from './routes/admin/fileRoutes.js';
import bankRoutes from './routes/admin/bankRoutes.js';
import carouselRoutes from './routes/admin/carouselRoutes.js';
import secureAuthConfigRoutes from './routes/admin/secureAuthConfigRoutes.js';
import secureAuthSelfRoutes from './routes/admin/secureAuthSelfRoutes.js';
import posterRoutes from './routes/admin/posterRoutes.js';
import bannerSyncRoutes from './routes/admin/bannerSyncRoutes.js';
import fixturesRoutes from './routes/admin/fixturesRoutes.js';
import casinoManageRoutes from './routes/admin/casinoManageRoutes.js';
import casinoManagePublicRoutes from './routes/user/casinoManageRoutes.js';
import homeSliderRoutes from './routes/admin/homeSliderRoutes.js';
import homeSliderPublicRoutes from './routes/user/homeSliderRoutes.js';
import bettingConfigRoutes from './routes/admin/bettingConfigRoutes.js';
import commissionConfigRoutes from './routes/admin/commissionConfigRoutes.js';
import thirdPartyLimitRoutes from './routes/admin/thirdPartyLimitRoutes.js';
import bettingConfigPublicRoutes from './routes/user/bettingConfigRoutes.js';
import casinoRoutes from './routes/user/casinoRoutes.js';
import systemTrackerRoutes from './systemTracker/router.js';
import gamesRoutes from './routes/user/gamesRoutes.js';
import betLockRoutes from './routes/admin/betLockRoutes.js';
import creditLedgerRoutes from './routes/admin/creditLedgerRoutes.js';
import platformGamesLockRoute from './routes/admin/platformGamesLockRoute.js';
import riskManagementRoutes from './routes/admin/riskManagementRoutes.js';
import profitLossRoutes from './routes/admin/profitLossRoutes.js';
import activityLogRoutes from './routes/admin/activityLogRoutes.js';
import reportsRoutes from './routes/admin/reportsRoutes.js';
import ipDetailRoutes from './routes/admin/ipDetailRoutes.js';
import tableCasinoRoutes from './routes/admin/tableCasinoRoutes.js';
import executiveAuthRoutes from "./routes/executive/executiveAuthRoutes.js";
import executiveRoutes from "./routes/executive/executiveRoutes.js";
import sportsLockRoutes from './routes/admin/sportsLockRoutes.js';


import staffRoutes from './routes/admin/staffRoutes.js';

import staffAuthRoutes from './routes/admin/staffAuthRoutes.js'
import transactionPasswordRoutes from './routes/admin/transactionPasswordRoutes.js';

// d99 routes
import d99BetListRoutes from './d99/routes/betList.routes.js';

import sportsbetRoutes from './sportsbet/routes.js';
import sportsapiRoutes from './sportsapi/sportsapiroutes.js';

import jsGamesRoutes from './jsgames/routes.js';
import jsGamesv2 from './jsgamesv2/gameRoutes.js';
import { setupSocketHandlers } from './socket/socketHandler.js';
import { BALANCE_UPDATES_CHANNEL, CASINO_FEED_CHANNEL, SUPEROVER_SCORECARD_CHANNEL, casinoRoom } from './utils/socketUtils.js';
import redisClient from './config/redisClient.js';
import mannualSettleRoutes from './mannualSettle/routes.js';

// Import Telegram Bot
import startBot from './2FA_telegram_bot/index.js';


dotenv.config();


// platform  domain only  
const allowedOrigins = [
  // live domains
  'https://tenexchn.com',
  'https://www.tenexchn.com',
  'https://admin.tenexchn.com',
  // legacy codefactory domains — still served, kept working
  'https://tenexch.codefactory.games',
  'https://admin.tenexch.codefactory.games',
  'https://admintenexch.codefactory.games'
];

const checkOrigin = (origin, callback) => {
  // Allow requests with no origin (like mobile apps or curl requests)
  if (!origin) return callback(null, true);

  // private LAN IPs (192.168.x.x, 10.x.x.x, 172.16-31.x.x) for local device testing
  const isLanOrigin = /^http:\/\/(192\.168\.\d{1,3}\.\d{1,3}|10\.\d{1,3}\.\d{1,3}\.\d{1,3}|172\.(1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3})(:\d+)?$/.test(origin);

  if (allowedOrigins.includes(origin) ||
    isLanOrigin ||
    origin.startsWith('http://localhost:') ||
    origin.startsWith('http://127.0.0.1:') ||
    origin.startsWith('http://82.180.146.91:')||
    origin.startsWith('http://217.216.78.106:')

  ) {
    callback(null, true);
  } else {
    console.log("Blocked by CORS:", origin);
    callback(new Error('Not allowed by CORS'));
  }
};

const app = express();
// Behind nginx/CDN: without this req.protocol is always 'http', so absolute
// URLs we build (casino-manage tile art) come out http:// and the https site
// blocks them as mixed content.
// 'loopback', not true: only Apache on 127.0.0.1 is trusted. With `true` every
// X-Forwarded-For hop is trusted, so a client could pick its own req.ip and
// dodge the rate limiter (and fake the IP stored on bets).
// Production (2 servers): TRUST_PROXY=loopback,10.20.0.0/24 — the other server
// forwards money requests through the WireGuard tunnel, and its Apache is the
// hop that knows the real visitor IP. Never put a public range here.
app.set('trust proxy', process.env.TRUST_PROXY || 'loopback');
const server = createServer(app);
const io = new Server(server, {
  cors: {
    origin: checkOrigin,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    credentials: true,
  },
  path: '/socket.io',
  allowEIO3: true,
  transports: ['websocket', 'polling'],
});

const PORT = process.env.PORT || 5000;

// ======================
// Socket.IO Setup
// ======================
// Registers the 'authenticate' (join user_<id> room) and 'getBalance'
// handlers — without this no client ever joins its room, so every
// emitBalanceUpdate() push goes to an empty room and the header
// balance/exposure never updates in real time.
// More than one server: an emit on this server (forceLogout, balanceUpdate from
// an API request) must also reach sockets connected to the other one. The key
// prefixes the Redis pub/sub channels — pub/sub ignores the DB number, so it
// must be unique per project on a shared Redis. Relays below that every server
// runs for its OWN sockets use io.local, or users would get each push twice.
io.adapter(createAdapter(redisClient.duplicate(), redisClient.duplicate(), {
  key: process.env.SOCKET_ADAPTER_KEY || 'tenexch-io',
}));

// Secure channel for sockets: must be wired before the app's own handlers.
attachSocketCrypto(io);
setupSocketHandlers(io);

// Relay balanceUpdate payloads published by WORKER_MODE processes (settlement
// workers have no io — see utils/socketUtils.js). A subscriber-mode ioredis
// client can't run other commands, so this needs its own duplicate connection.
const balanceUpdatesSub = redisClient.duplicate();
balanceUpdatesSub.subscribe(BALANCE_UPDATES_CHANNEL).catch((err) => {
  console.error('❌ Failed to subscribe to balance updates channel:', err.message);
});
balanceUpdatesSub.on('message', (channel, message) => {
  if (channel !== BALANCE_UPDATES_CHANNEL) return;
  try {
    const payload = JSON.parse(message);
    if (payload && payload.userId != null) {
      io.local.to(`user_${payload.userId}`).emit('balanceUpdate', sealBroadcast(payload));
    }
  } catch (err) {
    console.error('❌ Bad balance update payload from worker:', err.message);
  }
});

// Relay casino table feeds published by the warmer (casinobet/cron/
// casinoAllDataCron.js runs as its own pm2 process and has no io). It publishes
// a table only when that table's payload actually changed, so this fires at the
// vendor's real cadence — roughly once a second per table someone is watching,
// not once per warmer pass.
//
// Needs its own duplicate connection for the same reason as the balance
// subscriber above: a subscriber-mode ioredis client can't run other commands.
const casinoFeedSub = redisClient.duplicate();
casinoFeedSub.subscribe(CASINO_FEED_CHANNEL).catch((err) => {
  console.error('❌ Failed to subscribe to casino feed channel:', err.message);
});
casinoFeedSub.on('message', (channel, message) => {
  if (channel !== CASINO_FEED_CHANNEL) return;
  try {
    const { type, data } = JSON.parse(message);
    if (!type) return;
    // Nobody has this table open — skip the emit entirely rather than let
    // socket.io walk an empty room 97 times a second.
    const room = casinoRoom(type);
    if (!io.sockets.adapter.rooms.get(room)) return;
    io.local.to(room).emit('casinoData', sealBroadcast({ type, data }));
  } catch (err) {
    console.error('❌ Bad casino feed payload from warmer:', err.message);
  }
});

// SuperOver scorecard: its own poller (superOverScorecardCron.js) publishes the
// accumulated two-innings scorecard here; relay it to the same casino_<type>
// room as a SEPARATE `superoverScorecard` event so only SuperOver viewers get
// it and the shared feed path stays untouched.
const superOverScoreSub = redisClient.duplicate();
superOverScoreSub.subscribe(SUPEROVER_SCORECARD_CHANNEL).catch((err) => {
  console.error('❌ Failed to subscribe to superover scorecard channel:', err.message);
});
superOverScoreSub.on('message', (channel, message) => {
  if (channel !== SUPEROVER_SCORECARD_CHANNEL) return;
  try {
    const { type, scorecard } = JSON.parse(message);
    if (!type) return;
    const room = casinoRoom(type);
    if (!io.sockets.adapter.rooms.get(room)) return; // nobody watching this table
    io.local.to(room).emit('superoverScorecard', sealBroadcast({ type, scorecard }));
  } catch (err) {
    console.error('❌ Bad superover scorecard payload:', err.message);
  }
});

export { io };

// ======================
// Middleware
// ======================
app.use(cors({
  origin: checkOrigin,
  credentials: true,
  // Without this the browser is told nothing, so it caches the preflight for
  // its own default of 5 SECONDS — at a 500ms casino poll that put an extra
  // OPTIONS round-trip in front of a real request every few seconds, and made
  // OPTIONS ~14% of everything this API served. A day is the ceiling Chrome
  // honours; the CORS rules here change about never.
  maxAge: 86400,
  // The secure channel marks encrypted bodies with X-Enc; the browser only
  // sees response headers that are exposed here.
  exposedHeaders: ['X-Enc', 'Retry-After'],
}));
// 10mb: Casino Manage saves uploaded tile art as base64 data URLs in the
// request body (a 5MB image is ~6.8MB of base64); the express default
// (100kb) rejected any real image.
app.use(express.json({ limit: '10mb' }));
// app.options("*", cors());

// Off by default. This logs EVERY request and its body, synchronously, into the
// pm2 log file — at a 500ms casino poll that is thousands of blocking stdout
// writes a second (and a log file that grows without bound). Set
// REQUEST_LOG=true in server/.env when debugging, and turn it back off.
if (process.env.REQUEST_LOG === "true") {
  app.use((req, res, next) => {
    console.log(`[${req.method}] ${req.originalUrl}`, req.body);
    next();
  });
}

// Rate limiting (RATE_LIMIT_MODE off|log|enforce, default off). After the body
// parser (login limits key on the username), before every route.
app.use(rateLimit);

// Secure channel (API_ENCRYPTION=on): key exchange + encrypted JSON responses.
app.use('/api/cs', csRoutes);
app.use(responseCrypto);



// ======================
// Health Check Route
// ======================
// Deep check for the load balancer: 200 only when this server can really serve
// (database query + Redis ping, 2 s limit each), 503 otherwise, so Cloudflare
// takes a broken server out — not only a dead one. Cached 2 s: health probes
// from many Cloudflare locations must not add load.
const HEALTH_TIMEOUT_MS = 2000;
let lastHealth = { at: 0, ok: false, checks: {} };
const withTimeout = (p) => Promise.race([
  p,
  new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), HEALTH_TIMEOUT_MS).unref()),
]);
app.get('/api/health', async (req, res) => {
  if (Date.now() - lastHealth.at > 2000) {
    const checks = {};
    await Promise.all([
      withTimeout(sequelize.query('SELECT 1')).then(() => { checks.db = 'ok'; }, (e) => { checks.db = e.message; }),
      withTimeout(redisClient.ping()).then(() => { checks.redis = 'ok'; }, (e) => { checks.redis = e.message; }),
    ]);
    lastHealth = { at: Date.now(), ok: checks.db === 'ok' && checks.redis === 'ok', checks };
  }
  res.status(lastHealth.ok ? 200 : 503).json({
    status: lastHealth.ok
      ? `Server is healthy for ${process.env.PROJECT_NAME}`
      : `Server is NOT healthy for ${process.env.PROJECT_NAME}`,
    role: ROLE,
    checks: lastHealth.checks,
  });
});

// =============================================
// Routes
// =============================================

//user management
app.use("/api/executive", executiveAuthRoutes);
app.use("/api/executive", executiveRoutes);

app.use('/api/admin', ownerRoutes);            // modified : owner management
app.use('/api/admin', userRoutes);             // modified : user management
app.use('/api/admin', staffRoutes);            // new      : staff management
app.use('/api/admin', affiliateRoutes);        // not implemented yet 

//authentification
app.use('/api/2fa/telegram', telegram2faRoutes); // new: telegram 2fa
app.use('/api/2fa/google', googleAuthRoutes); // google authenticator (TOTP) 2fa
app.use('/api/2fa/android', androidAuthRoutes); // 'Secure Auth Verification App' (TOTP) 2fa
app.use('/api/user', userAuthRoutes);          // modified
app.use('/api/admin', ownerAuthRoutes);        // modified
app.use('/api/admin', staffAuthRoutes);        //agent  replaced with  staff concept
app.use('/api/admin', transactionPasswordRoutes);  // new: transaction password management


// platform
app.use('/api/admin', betLockRoutes);          //  new : lock individual user to place bet 
app.use('/api/admin', platformGamesLockRoute); // new : lock platform selected games  for all users
app.use('/api/admin', riskManagementRoutes); // new: risk management
app.use('/api/admin', fileRoutes);             // need to figure it out 
app.use('/api/admin', bankRoutes);             // platform bank account table:  CRUD
app.use('/api/admin', secureAuthConfigRoutes); // owner-only: secure-auth telegram bot settings
app.use('/api/admin', secureAuthSelfRoutes);   // owner/staff: enable-disable secure auth on their OWN login
app.use('/api/admin', carouselRoutes);         // new : homepage carousel management (image link + sports/casino target)
app.use('/api/admin', fixturesRoutes);         // new : upcoming fixtures from the auto-update collector (header ticker + owner Fixtures page)
app.use('/api/admin', posterRoutes);           // new : welcome poster link (single editable image url)   
app.use('/api/admin', bannerSyncRoutes);       // new : 4-hourly carousel + poster mirror from the reference site (status + Update now)
app.use('/api/admin', casinoManageRoutes);     // new : Casino Manage (owner-only VIP/Virtual/Premium switchboard)
app.use('/api/user', casinoManagePublicRoutes); // new : enabled VIP/Virtual/Premium games for the frontend tabs
app.use('/api/admin', homeSliderRoutes);       // new : Home Sliders (owner-only 'Our Casino' / 'New Games' mobile home strips)
app.use('/api/user', homeSliderPublicRoutes);  // new : enabled home-strip tiles for the frontend
app.use('/api/admin', bettingConfigRoutes);     // new : owner-only buffer time + min/max stake limits (sports & casino)
app.use('/api/admin', commissionConfigRoutes);  // new : owner-only sports win commission per sport x market type
app.use('/api/admin', thirdPartyLimitRoutes);   // new : owner-only per-bet stake cap for third-party (JS) games, inherited down the hierarchy
app.use('/api/user', bettingConfigPublicRoutes); // new : buffer time + limit overrides the player panel reads (redis-cached)

//wallet & transactions
app.use('/api/admin', adminWalletRoutes);      //modified :  cash /credit transactions (only done by owner/staff)  
app.use('/api/user', userWalletRoutes);        // need to modify : user fetch their wallets
app.use('/api/admin', transactionRoutes);      // new:  transactions: between every type of user(owner/staff/user)
app.use('/api/admin', creditLedgerRoutes);     //  new : all the sports bet settlement transactions record 
app.use('/api/user', withdrawalRoutes);        //for users making withdraw request 
app.use('/api/admin', withdrawalRoutes);       // for admin settling withdrawals manualy
app.use('/api/admin', profitLossRoutes);
app.use('/api/admin', activityLogRoutes);      // new: user activity logs
app.use('/api/admin', ipDetailRoutes);         // new: ip geo lookup for user-history detail modal
app.use('/api/admin/reports', reportsRoutes);  // new: reports
app.use('/api/admin/table-casino', tableCasinoRoutes); // new: table casino locks
app.use('/api/admin/sports-lock', sportsLockRoutes);   // new: dynamic sports locks


// System Tracker — mother-admin (Owner) wallet/settlement integrity tool (read-only)
app.use('/api/system-tracker', systemTrackerRoutes);

//sports and casino
app.use('/api/casino', casinoRoutes);            //  CASINO:  related data: 50 games
app.use('/api/user', gamesRoutes);             // SPORTS: particular game
app.use('/api/user', getResultRoute);          // SPORTS:  result (Diamond/old)
app.use('/api/result', getResultRoute);        // SPORTS: result for internal use (Diamond/old)
app.use('/api/user', getResultRouteV2);        // SPORTS:  result v2 (AVRKHUB)
app.use('/api/result', getResultRouteV2);      // SPORTS: result v2 for internal use (AVRKHUB)
app.use('/api/user', sportsbetRoutes);         // 
app.use('/api/user', userActivityLogRoutes);   // new: user activity logs for frontend
app.use('/api/user', userStatementRoutes);     // new: dedicated user statement
app.use('/api/user', stakeButtonValueRoutes);
app.use('/api/user', oneClickButtonRoutes);
app.use('/api', sportsapiRoutes);              // need to figure it out 

app.use('/api/jsGames', jsGamesRoutes);        // live casino
app.use('/api/jsGamesv2', jsGamesv2);          // live casino
// Provider posts bet-callback without /api prefix — alias mount.
app.use('/jsGamesv2', jsGamesv2);

// d99 sub-module routes
app.use('/api/d99', d99BetListRoutes);


// manual settle 

app.use('/api/internalsettle', mannualSettleRoutes)

// ======================
// ✅ Start Server
// ======================
import { initializeDatabase } from './config/dbInit.js';
import { startDemoCleanupLoop } from './demo/demoCleanup.js';
import BannerSyncService from './services/BannerSyncService.js';

const startServer = async () => {
  try {
    // Schema setup + seeding runs only on the primary (config/role.js); a
    // replica just checks it can reach the database.
    if (isPrimary) {
      await initializeDatabase();
    } else {
      await sequelize.authenticate();
      console.log('Connected to PostgreSQL database (replica role: schema setup skipped).');
    }

    // Start HTTP server
    server.listen(PORT, () => {
      console.log(`🚀 Server running at http://localhost:${PORT}`);
      console.log(`🚀 Server running at http://localhost:${PORT}`);
      console.log(`⚡ Socket.IO server ready for real-time connections`);

      console.log(`🧭 Role: ${ROLE}`);
      // Once-only loops: only the primary runs them (two Telegram pollers knock
      // each other off; the cleanups and the mirror would run twice).
      if (isPrimary) {
        // Start Telegram Bot
        startBot();

        // Demo accounts: deactivate expired, purge old (server/demo/README.md)
        startDemoCleanupLoop();

        // Carousel + welcome poster mirror from the reference site, every 4 h
        BannerSyncService.startLoop();
      }
    });
  } catch (error) {
    console.error('❌ Failed to start server:', error.message);
    console.error('Stack trace:', error.stack);
    process.exit(1);
  }
};

// ======================
// Graceful Shutdown
// ======================
const gracefulShutdown = (signal) => {
  console.log(`\n⚠️  Received ${signal}. Shutting down gracefully...`);
  server.close(() => {
    console.log('✅ HTTP server closed.');
    process.exit(0);
  });
  // Force exit if server hasn't closed in 5 seconds
  setTimeout(() => {
    console.error('⚠️  Forcing shutdown after timeout.');
    process.exit(1);
  }, 5000);
};

process.on('SIGINT', () => gracefulShutdown('SIGINT'));
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));

process.on('uncaughtException', (err) => {
  console.error('❌ Uncaught Exception:', err);
  gracefulShutdown('uncaughtException');
});

process.on('unhandledRejection', (reason) => {
  console.error('❌ Unhandled Rejection:', reason);
});

// Only start HTTP listener when NOT imported as a module by workers.
// Workers set WORKER_MODE env or their argv[1] won't be server.js.
if (!process.env.WORKER_MODE) {
  startServer();
}