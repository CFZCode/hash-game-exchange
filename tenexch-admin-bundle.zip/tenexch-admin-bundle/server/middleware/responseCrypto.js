// Encrypts every JSON response for the browser (API_ENCRYPTION=on).
// Plan: docs/plans/2026-10-14-api-response-encryption.md
//
// The session is checked BEFORE the route runs: a missing/expired X-CS-Id gets
// 409 CS_REHANDSHAKE and the route is not executed, so the client's automatic
// retry can never place a bet twice.
//
// Only res.json / res.send(object) are encrypted. Files, redirects and plain
// strings pass through. Server-to-server routes are never touched.
import { MESSAGES } from '../constants/messages.js';
import { isServerToServerRoute } from '../config/serverToServerRoutes.js';
import { ENABLED, getSession, sealForSession } from '../services/secureChannelService.js';

const HANDSHAKE_PATH = '/api/cs/handshake';
// GET routes that answer with an IMAGE or FILE, loaded by <img src> / links. A
// browser cannot attach the X-CS-Id header to those, so the session check would
// answer 409 instead of the picture (broke the home strips, casino tile art and
// deposit screenshots, 2026-10-15). They return no JSON, so there is nothing to
// encrypt — they pass exactly as before encryption existed.
const FILE_ROUTES = [
  /^\/api\/user\/home-slider\/img\/[^/]+$/,
  /^\/api\/user\/casino-manage\/img\/[^/]+$/,
  /^\/api\/admin\/file\/[^/]+$/,
];
const isFileRoute = (req) => req.method === 'GET' && FILE_ROUTES.some((r) => r.test(req.path));
// A request carrying this secret header gets plain JSON (debugging staging /
// production). Keep it out of every frontend build.
const DEBUG_TOKEN = process.env.DEBUG_PLAIN_TOKEN || '';

export const responseCrypto = async (req, res, next) => {
  if (!ENABLED || req.method === 'OPTIONS' || req.path === HANDSHAKE_PATH
    || !req.path.startsWith('/api/') || isServerToServerRoute(req.path) || isFileRoute(req)) return next();
  if (DEBUG_TOKEN && req.get('X-Debug-Plain') === DEBUG_TOKEN) return next();

  let session;
  try {
    session = await getSession(req.get('X-CS-Id'));
  } catch (err) {
    // Redis failing: answer plain rather than take the whole API down.
    console.error('[responseCrypto] session lookup failed, answering plain:', err.message);
    return next();
  }
  if (!session) {
    return res.status(409).json({ success: false, code: 'CS_REHANDSHAKE', error: MESSAGES.AUTH.CS_REHANDSHAKE });
  }

  res.json = (body) => {
    res.set('Content-Type', 'application/octet-stream');
    res.set('X-Enc', '1');
    return res.send(sealForSession(session, body));
  };
  return next();
};
