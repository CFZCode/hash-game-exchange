// Request rate limiting. Plan: docs/plans/2026-10-14-api-rate-limit.md
//
// RATE_LIMIT_MODE (server/.env):
//   off      (default) — nothing is counted
//   log      — counted; a would-be block is written to the log, the request passes
//   enforce  — over the limit gets 429 + Retry-After
//
// Counters live in Redis, so every server behind the load balancer shares one
// count. Redis trouble fails OPEN: the request passes and the error is logged.
//
// Who is counted:
//   - a request with a VALID JWT counts against its account (many mobile users
//     share one carrier IP, so a per-IP cap would hit them together);
//   - anything else counts against the client IP (req.ip — see `trust proxy`
//     in server.js). A forged token is "anything else".
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import jwt from 'jsonwebtoken';
import { RateLimiterRedis } from 'rate-limiter-flexible';
import redis from '../config/redisClient.js';
import { MESSAGES } from '../constants/messages.js';
import { clientIp } from '../utils/clientIp.js';
import { isServerToServerRoute } from '../config/serverToServerRoutes.js';

const MODE = ['log', 'enforce'].includes(process.env.RATE_LIMIT_MODE) ? process.env.RATE_LIMIT_MODE : 'off';
const num = (name, fallback) => Number(process.env[name]) > 0 ? Number(process.env[name]) : fallback;


// Login / 2FA / password buckets count only FAILED attempts (a 4xx answer), so
// a correct password never uses the limit up while guessing is stopped fast.
// Every other bucket counts every request.
const BUCKETS = {
  login: {
    match: /^\/api\/(user\/(login|demo-login)|admin\/(login-owner|staff\/login)|executive\/login)$/,
    points: num('RATE_LIMIT_LOGIN_POINTS', 10), duration: 15 * 60, failuresOnly: true,
    key: (req) => `login:${clientIp(req)}:${loginName(req)}`,
  },
  loginIp: { // same routes, any username: stops spraying many accounts from one IP
    match: null, points: num('RATE_LIMIT_LOGIN_IP_POINTS', 50), duration: 15 * 60, failuresOnly: true,
    key: (req) => `loginip:${clientIp(req)}`,
  },
  twoFa: {
    match: /^\/api\/(user\/(verify-2fa|resend-2fa-otp)|admin\/(owner|staff)\/(verify-2fa|resend-2fa-otp)|2fa\/android\/claim)$/,
    points: num('RATE_LIMIT_2FA_POINTS', 10), duration: 15 * 60, failuresOnly: true,
    key: (req) => `2fa:${clientIp(req)}:${String(req.body?.userId ?? req.body?.ownerId ?? req.body?.staffId ?? '')}`,
  },
  password: {
    match: /^\/api\/(user\/change-password|admin\/(owner\/update-password|agent\/update-password|transaction-password\/verify|secure-auth\/verify-password)|2fa\/telegram\/verify-password|executive\/[^/]+\/password)$/,
    points: num('RATE_LIMIT_PASSWORD_POINTS', 5), duration: 15 * 60, failuresOnly: true,
    key: (req, who) => `pw:${who}`,
  },
  csHandshake: { // secure-channel key exchange (one per page load)
    match: /^\/api\/cs\/handshake$/,
    points: num('RATE_LIMIT_HANDSHAKE_POINTS', 60), duration: 60,
    key: (req) => `cs:${clientIp(req)}`,
  },
  placeBet: {
    match: /^\/api\/user\/(place|place-combined)$/,
    points: num('RATE_LIMIT_BET_POINTS', 60), duration: 60,
    key: (req, who) => `bet:${who}`,
  },
  general: {
    match: /^\/api\//,
    points: num('RATE_LIMIT_GENERAL_POINTS', 3000), duration: num('RATE_LIMIT_GENERAL_SECONDS', 180),
    key: (req, who) => `gen:${who}`,
  },
};

const limiters = {};
for (const [name, b] of Object.entries(BUCKETS)) {
  limiters[name] = new RateLimiterRedis({
    storeClient: redis,
    keyPrefix: `rl:${name}`,
    points: b.points,
    duration: b.duration,
  });
}

const loginName = (req) =>
  String(req.body?.username ?? req.body?.email ?? req.body?.site_email_address ?? '').trim().toLowerCase().slice(0, 64);

// `u:<type>:<id>` for a valid token, `ip:<addr>` otherwise.
const whoIs = (req) => {
  const auth = req.headers.authorization;
  if (auth && auth.startsWith('Bearer ')) {
    try {
      const d = jwt.verify(auth.slice(7).trim(), process.env.JWT_SECRET);
      const id = d.account?.id ?? d.owner_id ?? d.staff_id ?? d.user_id;
      const type = d.account?.type ?? (d.owner_id ? 'OWNER' : d.staff_id ? 'STAFF' : 'USER');
      if (id != null) return `u:${type}:${id}`;
    } catch { /* invalid or expired token: count by IP */ }
  }
  return `ip:${clientIp(req)}`;
};

const LOG_FILE = process.env.RATE_LIMIT_LOG_FILE
  || path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'logs', 'rate-limit.log');
try { fs.mkdirSync(path.dirname(LOG_FILE), { recursive: true }); } catch { /* logged on first write */ }

const logBlock = (entry) => {
  fs.appendFile(LOG_FILE, JSON.stringify({ t: new Date().toISOString(), mode: MODE, ...entry }) + '\n', (err) => {
    if (err) console.error('[rateLimit] log write failed:', err.message);
  });
};

// One block decision. Returns the seconds to wait, or 0 when the request may pass.
// `over` is checked BEFORE counting for failure-only buckets (the failure is
// counted when the response finishes), and AFTER counting for the others.
const check = async (name, req, key) => {
  const b = BUCKETS[name];
  const limiter = limiters[name];
  if (b.failuresOnly) {
    const res = await limiter.get(key);
    if (res && res.consumedPoints >= b.points) {
      logBlock({ bucket: name, key, ip: clientIp(req), method: req.method, path: req.path, count: res.consumedPoints, limit: b.points });
      return Math.ceil(res.msBeforeNext / 1000) || 1;
    }
    return 0;
  }
  try {
    await limiter.consume(key);
    return 0;
  } catch (res) {
    if (res instanceof Error) throw res;
    // log the first request over the limit in each window, not every one after it
    if (res.consumedPoints === b.points + 1) {
      logBlock({ bucket: name, key, ip: clientIp(req), method: req.method, path: req.path, count: res.consumedPoints, limit: b.points });
    }
    return Math.ceil(res.msBeforeNext / 1000) || 1;
  }
};

// The shared ioredis client queues commands while Redis is unreachable instead
// of failing, which would stall every request. Give up after CHECK_TIMEOUT_MS
// and let the request through.
const CHECK_TIMEOUT_MS = num('RATE_LIMIT_TIMEOUT_MS', 300);
const withTimeout = (p) => Promise.race([
  p,
  new Promise((_, reject) => setTimeout(() => reject(new Error(`redis check over ${CHECK_TIMEOUT_MS}ms`)), CHECK_TIMEOUT_MS).unref()),
]);

const countFailure = (name, key) => (res) => {
  if (res.statusCode >= 400 && res.statusCode < 500 && res.statusCode !== 429) {
    limiters[name].consume(key).catch((e) => {
      if (e instanceof Error) console.error('[rateLimit] count failed:', e.message);
    });
  }
};

export const rateLimit = async (req, res, next) => {
  if (MODE === 'off' || req.method === 'OPTIONS' || isServerToServerRoute(req.path)) return next();
  try {
    const who = whoIs(req);
    const names = [];
    if (BUCKETS.login.match.test(req.path)) names.push('login', 'loginIp');
    else if (BUCKETS.twoFa.match.test(req.path)) names.push('twoFa');
    else if (BUCKETS.password.match.test(req.path)) names.push('password');
    else if (BUCKETS.csHandshake.match.test(req.path)) names.push('csHandshake');
    else if (BUCKETS.placeBet.match.test(req.path)) names.push('placeBet');
    if (BUCKETS.general.match.test(req.path)) names.push('general');

    let wait = 0;
    for (const name of names) {
      const key = BUCKETS[name].key(req, who);
      wait = Math.max(wait, await withTimeout(check(name, req, key)));
      if (BUCKETS[name].failuresOnly) res.on('finish', () => countFailure(name, key)(res));
    }
    if (wait > 0 && MODE === 'enforce') {
      res.set('Retry-After', String(wait));
      const message = MESSAGES.AUTH.RATE_LIMITED(wait);
      return res.status(429).json({ success: false, error: message, message, retryAfter: wait });
    }
  } catch (err) {
    console.error('[rateLimit] failing open:', err.message);
  }
  return next();
};

export const RATE_LIMIT_MODE = MODE;
