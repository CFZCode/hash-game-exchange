import { verifyTxnPasswordWithAttempts } from '../services/admin/transactionPasswordService.js';

const verifyTransactionPassword = async (req, res, next) => {
  try {
    // Expect transaction password in request body
    const { transactionPassword } = req.body;

    // User should be authenticated via authMiddleware before this
    const result = await verifyTxnPasswordWithAttempts(req.user, transactionPassword);

    if (!result.ok) {
      return res.status(result.status).json({
        success: false,
        message: result.message,
        attemptsLeft: result.attemptsLeft,
      });
    }

    // Valid
    next();
  } catch (error) {
    console.error('❌ Transaction password verification error:', error);
    res.status(500).json({ success: false, message: 'Internal server error during verification' });
  }
};

/**
 * Same check, different wording for the "wrong code" case.
 *
 * Bet Lock's toast is `Master Password not valid.` while every other
 * transaction-code route answers `transaction code not valid. You have
 * Nattempt left.` — so the caller passes the string it wants and nothing else
 * changes: the attempts counter still decrements, a used-up allowance still
 * answers LIMIT_REACHED / `Unauthorized access`, and a MISSING code still
 * answers REQUIRED (the admin blocks that case client-side anyway).
 *
 *   router.post('/…', authMiddleware, requireBackoffice,
 *     verifyTransactionPasswordAs(MESSAGES.ADMIN.TXN.MASTER_NOT_VALID), handler)
 */
export const verifyTransactionPasswordAs = (notValidMessage) => async (req, res, next) => {
  try {
    const { transactionPassword } = req.body;
    const result = await verifyTxnPasswordWithAttempts(req.user, transactionPassword);

    if (!result.ok) {
      // only the wrong-password answer is reworded; missing / locked out keep
      // the shared wording
      const wrongPassword = result.status === 400 && !!transactionPassword;
      return res.status(result.status).json({
        success: false,
        message: wrongPassword ? notValidMessage : result.message,
        attemptsLeft: result.attemptsLeft,
      });
    }

    next();
  } catch (error) {
    console.error('❌ Transaction password verification error:', error);
    res.status(500).json({ success: false, message: 'Internal server error during verification' });
  }
};

export default verifyTransactionPassword;
