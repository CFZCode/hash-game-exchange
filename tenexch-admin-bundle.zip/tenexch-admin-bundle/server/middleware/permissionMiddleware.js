/**
 * permissionMiddleware.js
 * ---------------------------------------------------------------------------
 * requirePermission(key) — the REAL enforcement of the executive permission
 * map. Attach it to any business route that an executive should only reach
 * when granted the matching feature flag.
 *
 *   router.post("/withdraw", authMiddleware, requirePermission("withdraw"), handler)
 *   router.get ("/users",    authMiddleware, requirePermission("userList"), handler)
 *   router.post("/x", authMiddleware, requirePermission(["deposit","withdraw"]), handler) // any-of
 *
 * Owners and staff are NOT executives, so they bypass every check (next()).
 * Only EXECUTIVE actors are gated, against the `permissions` object that the
 * auth middleware refreshes from the DB on every request.
 *
 * The matching frontend gate lives in d99-admin/src/utils/permissions.js and
 * MUST use byte-identical key strings.
 */
const requirePermission = (key) => (req, res, next) => {
  const actorType = req.user?.actor?.type;

  // Owners / staff (and anyone not an executive) bypass entirely.
  if (actorType !== "EXECUTIVE") return next();

  const permissions = req.user?.permissions || {};

  const allowed = Array.isArray(key)
    ? key.some((k) => !!permissions[k]) // any-of
    : !!permissions[key];

  if (!allowed) {
    return res.status(403).json({
      success: false,
      message: `Permission denied: requires '${Array.isArray(key) ? key.join("' or '") : key}'`
    });
  }

  return next();
};

/**
 * denyExecutives — route-level hard block for endpoints no executive may ever
 * reach regardless of its permission map (e.g. executive management itself).
 * Placed BEFORE verifyTransactionPassword so a probing executive can't burn
 * the parent account's transaction-password attempts.
 */
const denyExecutives = (req, res, next) => {
  if (req.user?.actor?.type === "EXECUTIVE") {
    return res.status(403).json({
      success: false,
      message: "Executives are not allowed to manage executives"
    });
  }
  return next();
};

/**
 * requireOwner — hard gate for owner-only workflows (manual settlement,
 * carousel, game priority). Only the OWNER actor passes; staff hierarchy and
 * executives get 403. Client mirror: isOwner() / OWNER_ONLY_ROUTES in
 * admin/src/utils/permissions.js.
 */
const requireOwner = (req, res, next) => {
  if (req.user?.actor?.type !== "OWNER") {
    return res.status(403).json({
      success: false,
      message: "Access denied. Owner only."
    });
  }
  return next();
};

/**
 * requireBackoffice — hard gate for every admin-panel route that a PLAYER
 * token must never reach. authMiddleware only proves the JWT is valid; a
 * player (or demo-login) token is a valid JWT too, and on 2026-09-14 a scanner
 * used one to POST /api/admin/betlock/lock/all/* and read admin reports.
 * OWNER, STAFF and EXECUTIVE actors pass (executives are still subject to
 * requirePermission on the same route); USER / unknown actors get 403.
 */
const requireBackoffice = (req, res, next) => {
  const actorType = req.user?.actor?.type;
  if (actorType !== "OWNER" && actorType !== "STAFF" && actorType !== "EXECUTIVE") {
    return res.status(403).json({
      success: false,
      message: "Access denied. Back-office accounts only."
    });
  }
  return next();
};

export default requirePermission;
export { requirePermission, denyExecutives, requireOwner, requireBackoffice };
