// 🔐 Report statement guard — fromDate/toDate (req.body, "YYYY-MM-DD") must be
// a max 10-day window, and the window must fall within the last 3 months.
const DATE_RANGE_ERROR =
  "Sorry for inconvenience! You will see statement of 10 days date range in 3 months timeslot.";

const MS_PER_DAY = 1000 * 60 * 60 * 24;

const dateRangeMiddleware = (req, res, next) => {
  const { fromDate, toDate } = req.body || {};

  const from = new Date(fromDate);
  const to = new Date(toDate);
  if (!fromDate || !toDate || isNaN(from.getTime()) || isNaN(to.getTime())) {
    return res.status(400).json({ success: false, message: DATE_RANGE_ERROR });
  }

  // Max 10-day window (and from must not be after to)
  const rangeDays = (to - from) / MS_PER_DAY;
  if (rangeDays < 0 || rangeDays > 10) {
    return res.status(400).json({ success: false, message: DATE_RANGE_ERROR });
  }

  // Window must be within the last 3 months from today
  const threeMonthsAgo = new Date();
  threeMonthsAgo.setMonth(threeMonthsAgo.getMonth() - 3);
  threeMonthsAgo.setHours(0, 0, 0, 0);
  if (from < threeMonthsAgo) {
    return res.status(400).json({ success: false, message: DATE_RANGE_ERROR });
  }

  next();
};

export default dateRangeMiddleware;

export const maxDateRange = (maxDays) => (req, res, next) => {
  try {
    const { fromDate, toDate } = req.body || {};

    const from = new Date(fromDate);
    const to = new Date(toDate);
    if (!fromDate || !toDate || isNaN(from.getTime()) || isNaN(to.getTime())) {
      return res.status(400).json({ success: false, message: 'fromDate and toDate are required (YYYY-MM-DD).' });
    }

    const rangeDays = (to - from) / MS_PER_DAY;
    if (rangeDays < 0) {
      return res.status(400).json({ success: false, message: 'fromDate cannot be after toDate.' });
    }
    if (rangeDays > maxDays) {
      return res.status(400).json({ success: false, message: `Date range cannot be more than ${maxDays} days.` });
    }

    next();
  } catch (error) {
    console.error('❌ [maxDateRange] error:', error);
    return res.status(500).json({ success: false, message: 'Server error while validating date range.' });
  }
};
