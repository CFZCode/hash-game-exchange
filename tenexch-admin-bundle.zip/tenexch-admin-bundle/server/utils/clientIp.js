// The caller's real IP. Express derives req.ip from X-Forwarded-For using the
// `trust proxy` setting in server.js ('loopback': only Apache on 127.0.0.1 is
// trusted), so a client cannot choose it. Never read X-Forwarded-For directly:
// its left-most entry is written by the client and can be anything.
export const clientIp = (req) => {
  const ip = req?.ip || req?.socket?.remoteAddress || null;
  // IPv4 clients reach a dual-stack socket as ::ffff:1.2.3.4
  return ip && ip.startsWith('::ffff:') ? ip.slice(7) : ip;
};
