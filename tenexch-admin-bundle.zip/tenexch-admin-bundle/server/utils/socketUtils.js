import { sealBroadcast } from '../services/secureChannelService.js';
// Lazy-import io only when running as the main server (not in worker processes).
// Importing server.js from workers causes the HTTP listener to start on the same port,
// leading to EADDRINUSE crash loops.
let _io = null;

async function getIO() {
  if (_io) return _io;
  if (process.env.WORKER_MODE) return null;
  try {
    const mod = await import('../server.js');
    _io = mod.io;
  } catch {
    _io = null;
  }
  return _io;
}

// Redis channel that carries balanceUpdate payloads from worker processes
// (settlement workers run with WORKER_MODE=1 and have no io) to the main
// server, which relays them to the user's socket room. See server.js.
export const BALANCE_UPDATES_CHANNEL = 'socket:balance_updates';

// Redis channel that carries casino table feeds from the warmer
// (casinobet/cron/casinoAllDataCron.js, its own pm2 process with no io) to the
// main server, which relays each one to the casino_<type> room. Same shape of
// problem as BALANCE_UPDATES_CHANNEL above, so it uses the same mechanism.
//
// The warmer publishes ONLY when a table's payload actually changed. Publishing
// every pass would be 97 messages twice a second to every connected client —
// strictly worse than the 500ms poll this replaces.
export const CASINO_FEED_CHANNEL = 'socket:casino_feed';

// Socket.IO room holding everyone currently watching one casino table.
export const casinoRoom = (type) => `casino_${type}`;

// Socket.IO room holding everyone on one match/race detail page. The server's
// matchWatchService pushes `matchGone` here (see services/matchWatchService.js).
export const matchRoom = (sid, gmid) => `match_${sid}_${gmid}`;

// Redis channel that carries the SuperOver two-innings scorecard from its own
// poller (casinobet/cron/superOverScorecardCron.js) to the main server, which
// relays it to the same casino_<type> room as a separate `superoverScorecard`
// event. Kept OFF the feed channel/warmer on purpose: the scorecard is
// accumulated per round and only concerns SuperOver tables, so it rides its own
// dedicated channel and event rather than bloating the shared feed path.
export const SUPEROVER_SCORECARD_CHANNEL = 'socket:superover_scorecard';

// Lazy-import the shared redis client the same way as io — only resolved the
// first time a worker actually needs to publish.
let _pub = null;

async function getPublisher() {
  if (_pub) return _pub;
  try {
    const mod = await import('../config/redisClient.js');
    _pub = mod.default;
  } catch {
    _pub = null;
  }
  return _pub;
}

/**
 * Emit balance update to a specific user
 * @param {number} userId - The user ID to emit to
 * @param {Object} balanceData - The balance data to emit
 * @param {number} balanceData.inr_balance - INR balance
 * @param {number} balanceData.exposure - Total exposure amount (from total_exposures table)
 */
export const emitBalanceUpdate = async (userId, balanceData) => {
  /* A field the caller did not supply is OMITTED, never sent as null.
     `exposure: … : null` looked harmless and was not: several callers emit one
     field only — walletService's point-hierarchy update sends `{ all_point }`,
     and the player's own wallet is the first entry in that loop — so every one
     of those pushed an explicit `exposure: null` to the player's header. The
     client wrote it (its guard tested `undefined`) and rendered `?? 0`, so a
     real figure was replaced by a literal 0 for the ~120 ms until the true emit
     arrived. Measured on a 60fps capture: -4546.89 → 0 → -4046.89.
     Omitting says "this message has nothing to say about that field", which is
     the truth. A real zero is still the number 0 and is still sent.
     Same for inr_balance, which had the identical hole. */
  const payload = {
    userId,
    balance: {
      ...(balanceData.inr_balance != null && { inr_balance: balanceData.inr_balance }),
      // Raw exposure value (negative = liability)
      ...(balanceData.exposure != null && { exposure: parseFloat(balanceData.exposure) }),
    },
    // Casino settlement only: which round this push settled ({ game, round }),
    // so the open table can drop that round's book in the same message that
    // moves the header. Plan: docs/plans/2026-10-09-casino-book-clears-with-settlement-push.md
    ...(balanceData.settled && { settled: balanceData.settled }),
    timestamp: new Date().toISOString()
  };

  const io = await getIO();
  if (io) {
    io.to(`user_${userId}`).emit('balanceUpdate', sealBroadcast(payload));
    return;
  }

  // Worker process (WORKER_MODE) — no io here. Publish over Redis so the main
  // server can push it to the browser; without this, settlement wins/losses
  // never reach the header until the client polls or refreshes.
  const pub = await getPublisher();
  if (pub) {
    try {
      await pub.publish(BALANCE_UPDATES_CHANNEL, JSON.stringify(payload));
    } catch (err) {
      // UI-sync failure must never affect the committed settlement.
      console.error('emitBalanceUpdate: redis publish failed:', err.message);
    }
  }
};

/**
 * Push `forceLogout` to players whose sessions were just revoked by an upline
 * lock (helper/accountLockChain.js). The token is already dead server-side;
 * this only makes the logout instant instead of waiting for the next API 401.
 * Main-server only: the lock toggle is an HTTP request, never a worker.
 * @param {number[]} userIds
 * @param {string} message - shown to the player as the logout reason
 */
/**
 * Same push, for staff/admin sessions revoked by an upline lock. Their token is
 * killed in the same transaction as the players', but nothing told their screen
 * — so an admin stayed on the page until its next request 401'd, which is why
 * the logout only appeared once you navigated somewhere.
 * @param {number[]} staffIds
 * @param {string} message - shown as the logout reason
 */
/** Same push for owner sessions. @param {number[]} ownerIds */
export const emitOwnerForceLogout = async (ownerIds, message) => {
  try {
    const io = await getIO();
    if (!io) return;
    for (const ownerId of ownerIds) {
      io.to(`owner_${ownerId}`).emit('forceLogout', sealBroadcast({ ownerId, message }));
    }
  } catch (err) {
    console.error('emitOwnerForceLogout failed:', err.message);
  }
};

export const emitAdminForceLogout = async (staffIds, message) => {
  try {
    const io = await getIO();
    if (!io) return;
    for (const staffId of staffIds) {
      io.to(`admin_${staffId}`).emit('forceLogout', sealBroadcast({ staffId, message }));
    }
  } catch (err) {
    // The lock is already committed; a failed push falls back to the 401.
    console.error('emitAdminForceLogout failed:', err.message);
  }
};

export const emitForceLogout = async (userIds, message) => {
  try {
    const io = await getIO();
    if (!io) return;
    for (const userId of userIds) {
      io.to(`user_${userId}`).emit('forceLogout', sealBroadcast({ userId, message }));
    }
  } catch (err) {
    // The lock is already committed; a failed push falls back to the 401.
    console.error('emitForceLogout failed:', err.message);
  }
};
