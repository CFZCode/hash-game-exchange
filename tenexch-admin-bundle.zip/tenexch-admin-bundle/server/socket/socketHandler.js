import { verifyToken } from '../utils/jwt.js';
import WalletService from '../services/walletService.js';
import { getUserTotalExposure } from '../services/ExposureService.js';
import { getOwnerProfileForSocket, invalidateOwnerProfile } from '../controller/admin/userController.js';
import { getStaffProfileForSocket, invalidateStaffProfile } from '../services/admin/staffAuthService.js';
import { casinoRoom } from '../utils/socketUtils.js';
import redis from '../config/redisClient.js';
import { casinoTickerShouldSkip } from '../helper/casinoSettlingFlag.js';
import { sealBroadcast } from '../services/secureChannelService.js';
// Parked with the subscribeMatch handler below — see the note there.
// import { ensureWatch, goneEvent } from '../services/matchWatchService.js';

// How often an admin dashboard gets a fresh owner profile pushed to it.
const OWNER_PROFILE_INTERVAL_MS = 2000;

// How often a logged-in player gets a fresh balance+exposure pushed.
const BALANCE_INTERVAL_MS = 3000;

export const setupSocketHandlers = (io) => {
  io.on('connection', (socket) => {
    // Handle user authentication and join user-specific room
    socket.on('authenticate', (data) => {
      const { userId, token } = data;
      if (userId) {
        socket.join(`user_${userId}`);
        socket.userId = userId;
      }
    });

    /* Admin/staff sessions get their OWN room, deliberately not `user_<id>`:
       staff ids and player ids are separate sequences, so staff #5 and player
       #5 would land in the same room and each would receive the other's
       pushes. Only staff-shaped sessions need this — an owner sits at the top
       of the chain and cannot be locked by an upline. */
    socket.on('authenticateAdmin', (data) => {
      const { staffId, ownerId } = data || {};
      if (staffId) {
        socket.join(`admin_${staffId}`);
        socket.staffId = staffId;
      }
      // Owners carry a login_id too, so a login elsewhere takes their session
      // over just the same. Separate room again: owner ids and staff ids are
      // separate sequences.
      if (ownerId) {
        socket.join(`owner_${ownerId}`);
        socket.ownerId = ownerId;
      }
    });

    // Handle real-time balance request
    socket.on('getBalance', async (data) => {
      try {
        // Get token from socket auth or event data
        const token = socket.handshake.auth.token || data?.token;
        if (!token) {
          socket.emit('balanceUpdate', sealBroadcast({ error: 'No token provided' }));
          return;
        }
        const decoded = verifyToken(token);
        const userId = decoded.user_id;
        // WalletService has no getBalance — getUserWallet is the real API
        // (it expects the UPPERCASE user_type, e.g. 'USER')
        const userRole = (decoded.role || 'USER').toUpperCase();
        const balance = await WalletService.getUserWallet(userId, userRole);
        // Get total_exposure from ExposureService
        const total_exposure = await getUserTotalExposure(userId);
        const balanceData = {
          userId,
          balance: {
            inr_balance: balance.inr_balance,
            exposure: total_exposure !== null ? total_exposure : null   // its total exposure of user of diffrent games combined
          },
          timestamp: new Date().toISOString()
        };
        socket.emit('balanceUpdate', sealBroadcast(balanceData));
      } catch (err) {
        console.error('Error in getBalance socket event:', err);
        socket.emit('balanceUpdate', sealBroadcast({ error: 'Failed to fetch balance', details: err.message }));
      }
    });

    // ── Player header: live balance+exposure every 3s ───────────────────────
    // Replaces the client's per-tick `getBalance` emit: the server owns the
    // clock, so the payload rides the poll request the transport is already
    // holding open instead of costing an emit + response round trip per tick.
    // The payload is byte-for-byte what the getBalance handler above returns,
    // so the same `balanceUpdate` listener consumes it unchanged.
    socket.on('subscribeBalance', async (data) => {
      try {
        const token = socket.handshake.auth.token || data?.token;
        if (!token) return;

        const decoded = verifyToken(token);
        const userId = decoded.user_id;
        // Same UPPERCASE user_type getUserWallet expects (see getBalance above).
        const userRole = (decoded.role || 'USER').toUpperCase();

        // inFlight: the exposure sweep can outrun a 3s tick, so skip the next
        // one instead of stacking overlapping queries on the DB.
        let inFlight = false;
        const tick = async () => {
          if (inFlight || !socket.connected) return;
          inFlight = true;
          try {
            const readStartedAt = Date.now();
            const balance = await WalletService.getUserWallet(userId, userRole);
            const total_exposure = await getUserTotalExposure(userId);
            if (!socket.connected) return;
            // Casino settlement mid-batch (or its final push newer than these
            // reads): drop this tick — it would paint a half-settled balance.
            // The worker's own push carries the final figure.
            // docs/plans/2026-10-13-casino-settlement-single-balance-step.md
            if (await casinoTickerShouldSkip(redis, userId, readStartedAt)) return;
            // Omit what we do not have rather than sending null — same rule as
            // utils/socketUtils.js emitBalanceUpdate, and for the same reason:
            // a null here overwrites a real figure on the client and paints 0.
            socket.emit('balanceUpdate', sealBroadcast({
              userId,
              balance: {
                ...(balance.inr_balance != null && { inr_balance: balance.inr_balance }),
                ...(total_exposure != null && { exposure: total_exposure }),
              },
              timestamp: new Date().toISOString()
            }));
          } catch (err) {
            console.error('Error in balance tick:', err.message);
          } finally {
            inFlight = false;
          }
        };

        // Idempotent: a reconnect (or the header heartbeat re-arming, or a
        // double subscribe from React StrictMode) must not leave a second
        // timer running against the same socket.
        if (socket.balanceTimer) clearInterval(socket.balanceTimer);
        await tick();                     // first payload immediately, no 3s gap
        socket.balanceTimer = setInterval(tick, BALANCE_INTERVAL_MS);
      } catch (err) {
        console.error('Error in subscribeBalance socket event:', err.message);
      }
    });

    socket.on('unsubscribeBalance', () => {
      if (socket.balanceTimer) {
        clearInterval(socket.balanceTimer);
        socket.balanceTimer = null;
      }
    });

    // ── Admin dashboard: live owner profile every 2s ────────────────────────
    // The admin panel renders its header + dashboard cards (pts, exposure,
    // credit, settlement pts, sports/casino/thirdparty P&L) off the profile it
    // fetched from GET /admin/owner/profile, which only refreshed on a route
    // change. Subscribing here replaces that with a push on a fixed tick.
    //
    // The payload is byte-for-byte what the REST endpoint returns (same
    // buildOwnerProfile), so a client can feed it into the exact same reducer.
    //
    // Cost control: getOwnerProfileForSocket memoises per owner, so ten open
    // tabs of the same account cost one set of queries per tick, and the
    // expensive downline max-win sweep is on its own slower clock inside.
    socket.on('subscribeOwnerProfile', async (data) => {
      try {
        const token = socket.handshake.auth.token || data?.token;
        if (!token) {
          socket.emit('ownerProfileUpdate', sealBroadcast({ success: false, error: 'No token provided' }));
          return;
        }

        const decoded = verifyToken(token);
        // OWNER and STAFF sessions, plus executives — an executive token carries
        // its parent's account = { type, id: parent_id }, exactly what the REST
        // profile endpoints read from req.user.account. The event names still
        // say "owner" for history; a STAFF account gets the staff profile
        // (same payload as GET /admin/staff/profile).
        const accountType = decoded?.account?.type;
        const accountId = decoded?.account?.id;
        const isStaff = accountType === 'STAFF';
        if (!accountId || (accountType !== 'OWNER' && !isStaff)) {
          socket.emit('ownerProfileUpdate', sealBroadcast({ success: false, error: 'Not an admin account' }));
          return;
        }
        const loadProfile = isStaff ? getStaffProfileForSocket : getOwnerProfileForSocket;

        // inFlight: if one tick's queries run longer than the interval, skip
        // the next tick instead of stacking overlapping sweeps on the DB.
        let inFlight = false;
        const tick = async () => {
          if (inFlight) return;
          inFlight = true;
          try {
            const user = await loadProfile(accountId);
            if (!socket.connected) return;
            if (!user) {
              socket.emit('ownerProfileUpdate', sealBroadcast({ success: false, error: 'Account not found' }));
              return;
            }
            socket.emit('ownerProfileUpdate', sealBroadcast({
              success: true,
              data: { user },
              timestamp: new Date().toISOString(),
            }));
          } catch (err) {
            console.error('Error in ownerProfile tick:', err.message);
            if (socket.connected) {
              socket.emit('ownerProfileUpdate', sealBroadcast({ success: false, error: 'Failed to fetch owner profile' }));
            }
          } finally {
            inFlight = false;
          }
        };

        // Idempotent: a reconnect (or a double subscribe from React StrictMode)
        // must not leave a second timer running against the same socket.
        if (socket.ownerProfileTimer) clearInterval(socket.ownerProfileTimer);
        socket.ownerProfileId = accountId;
        socket.ownerProfileIsStaff = isStaff; // picks the cache to drop on refresh
        socket.ownerProfileTick = tick;     // reused by the on-demand refresh below
        await tick();                       // first payload immediately, no 2s blank header
        socket.ownerProfileTimer = setInterval(tick, OWNER_PROFILE_INTERVAL_MS);
      } catch (err) {
        console.error('Error in subscribeOwnerProfile socket event:', err.message);
        socket.emit('ownerProfileUpdate', sealBroadcast({ success: false, error: 'Invalid or expired token' }));
      }
    });

    // On-demand tick: the client asks for one the instant it MOVES money
    // (credit deposit/withdraw), so the admin never waits out the interval for
    // a number it just changed itself. Replaces the REST re-fetch the credit
    // flow used to do.
    socket.on('refreshOwnerProfile', async () => {
      if (!socket.ownerProfileTick) return;   // not subscribed
      if (socket.ownerProfileIsStaff) invalidateStaffProfile(socket.ownerProfileId);
      else invalidateOwnerProfile(socket.ownerProfileId);
      await socket.ownerProfileTick();
    });

    socket.on('unsubscribeOwnerProfile', () => {
      if (socket.ownerProfileTimer) {
        clearInterval(socket.ownerProfileTimer);
        socket.ownerProfileTimer = null;
      }
      socket.ownerProfileTick = null;
    });

    // ── Casino table feed: push instead of the client's 500ms poll ──────────
    // /casino/all-data is PUBLIC, so this deliberately takes no token — a
    // logged-out player browsing a table gets the same pushes. The payload is
    // byte-for-byte what the REST endpoint returns, so the client can feed it
    // straight into the cache that endpoint already fills.
    //
    // One room per table: the warmer publishes ~97 tables and a player watches
    // one, so the room is what keeps this from becoming a broadcast.
    socket.on('subscribeCasino', (data) => {
      const type = typeof data === 'string' ? data : data?.type;
      if (!type) return;
      // Leave the previous table first — navigating between tables on a SPA
      // reuses the socket, and without this a player accumulates a room per
      // table they ever opened and keeps paying for all of them.
      if (socket.casinoType && socket.casinoType !== type) {
        socket.leave(casinoRoom(socket.casinoType));
      }
      socket.casinoType = type;
      socket.join(casinoRoom(type));
    });

    socket.on('unsubscribeCasino', () => {
      if (!socket.casinoType) return;
      socket.leave(casinoRoom(socket.casinoType));
      socket.casinoType = null;
    });

    /* ── Match/race detail page watcher — PARKED, not deleted ──────────────
       The whole server-side liveness path is switched off. No client subscribes
       any more: the detail pages decide for themselves whether a match is gone,
       from the private-data poll they already run plus one match-list check
       (frontend/src/utils/matchGoneConfirm.js).

       Why it is off rather than gone: it was a second, slower copy of that same
       decision — a 60 s dwell plus its own confirmation — and two independent
       systems deciding when to evict a player is one more than can be reasoned
       about. A replacement is planned; when it lands it should own this block.

       services/matchWatchService.js is left in place and still exports
       classify / classifyError / confirmGone, all unit-tested. With nothing
       calling ensureWatch, no watcher ever starts and the server makes no
       per-gmid upstream calls for detail pages.

       To restore: uncomment, and re-add useMatchGoneSocket to the three detail
       pages (git history has the call sites).

    socket.on('subscribeMatch', (data) => {
      const gmid = data?.gmid;
      const sid = data?.sid;
      if (!gmid || !sid) return;
      const room = matchRoom(sid, gmid);
      if (socket.matchRoom && socket.matchRoom !== room) socket.leave(socket.matchRoom);
      socket.matchRoom = room;
      socket.join(room);
      const { gone, last } = ensureWatch(io, gmid, sid);
      if (last) socket.emit('matchData', sealBroadcast({ gmid, sid, data: last }));
      if (gone) socket.emit('matchGone', sealBroadcast(goneEvent(gmid, sid)));
    });

    socket.on('unsubscribeMatch', () => {
      if (!socket.matchRoom) return;
      socket.leave(socket.matchRoom);
      socket.matchRoom = null;
    });
    */

    // Handle disconnect
    socket.on('disconnect', () => {
      // Without this the 2s timer outlives the socket and keeps querying
      // forever for a dashboard nobody is watching.
      if (socket.ownerProfileTimer) {
        clearInterval(socket.ownerProfileTimer);
        socket.ownerProfileTimer = null;
      }
      // Same for the player balance tick — otherwise it keeps hitting the
      // wallet + exposure queries for a header nobody is looking at.
      if (socket.balanceTimer) {
        clearInterval(socket.balanceTimer);
        socket.balanceTimer = null;
      }
    });
  });

  // Add error handling for socket.io
  io.engine.on('connection_error', (err) => {
    // Log the fields only. `err` carries err.req (a circular IncomingMessage),
    // so console.error(err) dumped ~500 lines per event and grew
    // tenexch-server-error.log to 541 MB. code 1 = 'Session ID unknown', which
    // is a client polling with a sid from before the last restart, not a bug.
    console.error(
      'Socket.IO connection error:',
      err.code, err.message, err.context?.sid || ''
    );
  });
}; 


// can use profile in socket which contains all necaesary user data


// import { verifyToken } from '../utils/jwt.js';
// import WalletService from '../services/walletService.js';
// import { getUserTotalExposure } from '../services/ExposureService.js';
// import UserController from '../controller/admin/userController.js'; 

// export const setupSocketHandlers = (io) => {
//   // Middleware to authenticate every socket connection
//   io.use(async (socket, next) => {
//     try {
//       const token = socket.handshake.auth.token || socket.handshake.headers.authorization?.split(' ')[1];

//       if (!token) {
//         return next(new Error('Authentication error: No token provided'));
//       }

//       const decoded = verifyToken(token);
//       if (!decoded || !decoded.user_id) {
//         return next(new Error('Authentication error: Invalid token'));
//       }

//       // Attach user to socket
//       socket.user = decoded; // { user_id, role, etc. }
//       next();
//     } catch (err) {
//       console.error('Socket authentication error:', err.message);
//       next(new Error('Authentication error'));
//     }
//   });

//   io.on('connection', async (socket) => {
//     const userId = socket.user.user_id;
//     const userRole = socket.user.role || 'User';

//     // Join user to their private room
//     socket.join(`user_${userId}`);
//     socket.userId = userId; // for backward compatibility if needed

//     console.log(`User ${userId} connected via socket`);

//     try {
//       // Fetch full user profile using your existing UserController
//       const userProfile = await UserController.getUserById(userId); 
//       // Or if your method is different, e.g.:
//       // const userProfile = await UserController.getUserProfile(userId);

//       if (!userProfile) {
//         socket.emit('error', { message: 'User profile not found' });
//       } else {
//         // Send complete user profile immediately on connect
//         socket.emit('userProfile', {
//           success: true,
//           user: userProfile, // This contains name, email, phone, kyc status, etc.
//           timestamp: new Date().toISOString()
//         });
//       }
//     } catch (err) {
//       console.error('Error fetching user profile on socket connect:', err);
//       socket.emit('error', { message: 'Failed to load user profile' });
//     }

//     // ================================
//     // Keep your existing getBalance handler (secure & working)
//     // ================================
//     socket.on('getBalance', async () => {
//       try {
//         const balance = await WalletService.getBalance(userId, userRole);
//         const total_exposure = await getUserTotalExposure(userId);

//         const balanceData = {
//           userId,
//           balance: {
//             inr_balance: balance.inr_balance,
//             exposure: total_exposure ?? null
//           },
//           timestamp: new Date().toISOString()
//         };

//         socket.emit('balanceUpdate', balanceData);
//       } catch (err) {
//         console.error('Error in getBalance socket event:', err);
//         socket.emit('balanceUpdate', { 
//           error: 'Failed to fetch balance', 
//           details: err.message 
//         });
//       }
//     });

//     // Optional: Re-emit profile on demand
//     socket.on('refreshProfile', async () => {
//       try {
//         const userProfile = await UserController.getUserById(userId);
//         socket.emit('userProfile', {
//           success: true,
//           user: userProfile,
//           timestamp: new Date().toISOString()
//         });
//       } catch (err) {
//         socket.emit('userProfile', { success: false, error: err.message });
//       }
//     });

//     // Handle disconnect
//     socket.on('disconnect', (reason) => {
//       console.log(`User ${userId} disconnected: ${reason}`);
//     });
//   });

//   // Global connection error handling
//   io.engine.on('connection_error', (err) => {
//     console.error('Socket.IO connection error:', err.req, err.code, err.message, err.context);
//   });
// };