
import { Telegraf } from 'telegraf';
import https from 'https';
import dotenv from 'dotenv';
import SecureAuthConfigService from '../services/user/SecureAuthConfigService.js';
import { linkTelegramAccount } from '../controller/user/telegram2faController.js';
dotenv.config({ path: '../.env' }); // Adjust path if needed

// IPv6 to api.telegram.org fails intermittently on this host (curl -6 times out
// while IPv4 answers in 130ms). Node resolves AAAA first, so a bad moment left
// launch()'s first call hanging on a socket that never spoke — the bot then sat
// dead, silently, until the next deploy. Pin Telegram traffic to IPv4.
const telegramAgent = new https.Agent({ family: 4, keepAlive: true });

const STARTUP_TIMEOUT_MS = 15 * 1000;
const RETRY_DELAY_MS = 60 * 1000;
const HEALTH_CHECK_MS = 10 * 60 * 1000;

/** Reject instead of hanging for ever when Telegram accepts a socket and stalls. */
const withTimeout = (promise, ms, label) => Promise.race([
  promise,
  new Promise((_, reject) => setTimeout(() => reject(new Error(`${label} timed out after ${ms}ms`)), ms)),
]);

// The running polling instance, so restartBot() can stop it before starting a
// new one when the owner swaps the token in the admin panel.
let runningBot = null;
let runningToken = null;
let signalHandlersBound = false;

/**
 * Pull the code argument out of a command message.
 *
 * A plain `text.split(' ')` broke every PASTED code: copying "/connect ABCD1234"
 * off the site carries a non-breaking space (or a double space, or a trailing
 * newline) and the split then yields an empty argument — the bot answered
 * "Please provide your code" or linked nothing, while the same code typed BY
 * HAND worked. Normalise every kind of whitespace, then keep only the
 * characters a code can contain.
 */
const codeFromCommand = (text) => {
  const rest = String(text || '')
    .replace(/[\u00A0\u2007\u202F\u200B\uFEFF]/g, ' ')  // nbsp / zero-width
    .trim()
    // Drop the command itself. Matching the WORD (not `\w+`) is what lets
    // "/connectZ7FRNHJP" — no space, as a paste can produce — still yield the
    // code; a greedy `\w+` swallowed the code with it.
    .replace(/^\/?\s*(connect|start)(@[\w_]+)?/i, '');
  const token = rest.trim().split(/\s+/)[0] || '';
  return token.replace(/[^A-Za-z0-9_-]/g, '');
};

const startBot = async (tokenOverride) => {
  try {
    // Token comes from the DB (admin panel) and falls back to .env.
    const BOT_TOKEN = tokenOverride
      || (await SecureAuthConfigService.getBotToken())
      || process.env.TELEGRAM_BOT_TOKEN;

    console.log('🤖 Initializing Telegram Bot...');

    if (!BOT_TOKEN) {
      console.warn('⚠️ No Telegram bot token configured (admin panel or .env). Bot will not start.');
      return;
    }

    const bot = new Telegraf(BOT_TOKEN, { telegram: { agent: telegramAgent } });
    runningBot = bot;
    runningToken = BOT_TOKEN;

    // Debug middleware to log every update
    bot.use((ctx, next) => {
        console.log(`📩 [Bot Debug] Update received: ${ctx.updateType}`);
        if (ctx.message) console.log(`📩 [Bot Debug] Message text: ${ctx.message.text}`);
        return next();
    });

    bot.start(async (ctx) => {
      console.log('📩 Bot received command:', ctx.message.text);
      // Support /start <code> as legacy/fallback
      const code = codeFromCommand(ctx.message.text);
      if (code) {
        await verifyLink(ctx, code);
      } else {
        await ctx.reply('Hey! You are 1 step away from 2-Step Verification.\nNow please proceed for further step:\n/connect your_id\nto enable it for your account.');
      }
    });

    bot.command('connect', async (ctx) => {
        console.log('📩 Bot received command:', ctx.message.text);
        const code = codeFromCommand(ctx.message.text);
        if (code) {
            await verifyLink(ctx, code);
        } else {
            await ctx.reply('⚠️ Please provide your code.\nUsage: /connect <your_code>');
        }
    });

    // Telegram only fires bot.command() when it TAGGED the text as a
    // bot_command entity. A pasted "/connect CODE" often arrives as plain text
    // (the chat shows it black, not blue) and then no handler ran at all — the
    // bot stayed silent, which is exactly what the user saw. This catches any
    // message that starts with connect/start whatever Telegram decided, and a
    // bare code pasted on its own, so the player always gets an answer.
    bot.on('text', async (ctx) => {
        const text = String(ctx.message?.text || '');
        const looksLikeCommand = /^\s*\/?\s*(connect|start)\b/i.test(text)
            || /^\s*\/?\s*(connect|start)[A-Za-z0-9_-]+\s*$/i.test(text);
        const bareCode = text.trim().replace(/[\u00A0\u2007\u202F\u200B\uFEFF]/g, '');
        const isBareCode = /^[A-Za-z0-9_-]{6,12}$/.test(bareCode);
        if (!looksLikeCommand && !isBareCode) return;

        console.log('📩 Bot received (untagged):', text);
        const code = looksLikeCommand ? codeFromCommand(text) : bareCode;
        if (code) await verifyLink(ctx, code);
        else await ctx.reply('⚠️ Please provide your code.\nUsage: /connect <your_code>');
    });

    // Clear any existing webhook to ensure polling works. Non-fatal: a stalled
    // deleteWebhook used to swallow the whole startup chain, so launch() was
    // never reached and nothing was logged.
    withTimeout(bot.telegram.deleteWebhook(), STARTUP_TIMEOUT_MS, 'deleteWebhook')
      .then(() => console.log('🧹 Previous webhook deleted'))
      .catch((err) => console.warn(`⚠️ deleteWebhook skipped: ${err.message}`))
      .then(() => {
        // launch() resolves only when the bot STOPS, so it can never confirm a
        // successful start — `bot.polling` (set by Telegraf once the loop is
        // up) is the signal, checked by the watchdog below.
        bot.launch().catch((err) => console.error(`❌ Bot polling stopped: ${err.message}`));

        setTimeout(() => {
          if (runningBot !== bot) return; // superseded by a newer token
          if (bot.polling) {
            console.log('🤖 Telegram Bot is running...');
            return;
          }
          console.error(`⚠️ Telegram Bot did not start within ${STARTUP_TIMEOUT_MS}ms — retrying in ${RETRY_DELAY_MS / 1000}s`);
          setTimeout(() => { if (runningBot === bot) restartBot({ force: true }); }, RETRY_DELAY_MS);
        }, STARTUP_TIMEOUT_MS);
      });

    startHealthCheck();

    // Enable graceful stop. Registered once for the process, not per start —
    // restartBot() would otherwise pile up a listener on every token change.
    if (!signalHandlersBound) {
      signalHandlersBound = true;
      // Telegraf's stop() throws SYNCHRONOUSLY with 'Bot is not running!' when
      // launch() never succeeded (bad/absent token — the .catch above swallows it
      // but runningBot stays set). Unguarded in a signal handler that throw became
      // an uncaughtException -> gracefulShutdown -> non-zero exit -> pm2 restart,
      // which is what drove tenexch-server to 417 restarts.
      const safeStop = (signal) => {
        try { runningBot?.stop(signal); } catch { /* bot never launched */ }
      };
      process.once('SIGINT', () => safeStop('SIGINT'));
      process.once('SIGTERM', () => safeStop('SIGTERM'));
    }
  } catch (error) {
    console.error('⚠️ Unexpected error in Telegram Bot setup. Server continuing.');
    console.error(error);
  }
};

// The bot runs inside the API process, so the link is done by calling the
// controller directly. It used to POST to the server's own public URL, which
// meant /connect silently did nothing whenever that base url was unset (the
// old default pointed at port 9299 while the API listens on PORT/5005) or the
// host could not reach its own public address.
async function verifyLink(ctx, code) {
  try {
    const result = await linkTelegramAccount({
      code,
      telegramId: ctx.from.id,
      username: ctx.from.username || '',
    });
    // On success the server posts the "2-Step Verification is enabled…" line
    // itself (same as the reference bot), so nothing to add here.
    if (!result.ok) await ctx.reply(`❌ Link Failed: ${result.error || 'Unknown error'}`);
  } catch (error) {
    console.error('Link Error:', error);
    await ctx.reply('❌ Server Error. Please try again later.');
  }
}

/**
 * A dead bot is invisible: nobody complains until a login needs a code. Poll our
 * own state every 10 minutes and relaunch when the loop is gone, so a hang costs
 * minutes rather than days. Bound once per process.
 */
let healthTimer = null;
const startHealthCheck = () => {
  if (healthTimer) return;
  healthTimer = setInterval(async () => {
    if (runningBot?.polling) return;
    console.warn('⚠️ Telegram Bot health check: polling is down — restarting');
    await restartBot({ force: true });
  }, HEALTH_CHECK_MS);
  healthTimer.unref?.();
};

/**
 * Stop the current polling bot and start one on the newly saved token.
 * Called by the admin save so an owner does not have to restart the server.
 * Never throws — a bad token must not take the API down with it.
 */
export const restartBot = async ({ force = false } = {}) => {
  try {
    const token = await SecureAuthConfigService.getBotToken();
    // `runningBot` only says a Telegraf instance was CREATED — polling may have
    // died (or launch() may have failed) while it stays set, and then this
    // shortcut left the site with a bot nobody was listening on. An explicit
    // save always restarts; the shortcut is kept for incidental callers.
    if (!force && runningBot && token === runningToken) return; // nothing changed

    if (runningBot) {
      try {
        runningBot.stop('config-change');
      } catch (stopError) {
        console.warn('⚠️ Old Telegram bot did not stop cleanly:', stopError.message);
      }
      runningBot = null;
      runningToken = null;
    }

    await startBot(token);
  } catch (error) {
    console.error('❌ Telegram bot restart failed:', error.message);
  }
};

export default startBot;