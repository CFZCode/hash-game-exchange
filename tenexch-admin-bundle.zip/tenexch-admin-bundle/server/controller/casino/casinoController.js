import axios from "axios";

import dotenv from "dotenv";
dotenv.config();
import CasinoService from "../../services/CasinoService.js";
import { placeBet } from "../../sportsbet/sportbetscontroller.js";
import TableCasino from "../../model/admin/TableCasino.js";
import BettingConfigService from "../../services/BettingConfigService.js";
import UserTableLock from "../../model/admin/UserTableLock.js";
import StaffTableLock from "../../model/admin/StaffTableLock.js";
import BetLockService from "../../services/BetLockService.js";
import { MESSAGES } from "../../constants/messages.js";
import User from "../../model/user/User.js";
import Staff from "../../model/admin/Staff.js";
import { Op } from "sequelize";
import { getLatestScorecard } from "../../helper/superOverStore.js";
import { clientIp } from '../../utils/clientIp.js';

// Games whose payout is a multiple of the stake.
const CASINO_MULTIPLIER_GAMES = {
    cmeter1: 12,
    cmeter: 50,
};

const CasinoController = {
    fetchAllData: async (req, res) => {
        const { type } = req.body;

        if (!type) {
            return res.status(400).json({
                success: false,
                error: "Type and data are required"
            });
        }

        try {
            const casinoData = await CasinoService.fetchAllData(type);

            return res.status(200).json({
                success: true,
                data: casinoData
            });
        } catch (error) {
            console.error("❌ Error:", error.message);

            return res.status(500).json({
                success: false,
                error: error.message
            });
        }
    },

    // Initial SuperOver scorecard for a table — the warm start on page load. The
    // poller (superOverScorecardCron.js) keeps `superovercard:<type>` fresh in
    // redis and pushes live updates over the `superoverScorecard` socket event;
    // this endpoint just hands the client the current value so it doesn't wait a
    // tick. Returns { success, data: <scorecard|null> }.
    fetchSuperOverScorecard: async (req, res) => {
        const { type } = req.body;
        if (!type) {
            return res.status(400).json({ success: false, error: "Type is required" });
        }
        try {
            const scorecard = await getLatestScorecard(type);
            return res.status(200).json({ success: true, data: scorecard });
        } catch (error) {
            console.error("❌ superover-scorecard:", error.message);
            return res.status(500).json({ success: false, error: error.message });
        }
    },

    fetchLastResults: async (req, res) => {
        const { type } = req.body;

        if (!type) {
            return res.status(400).json({
                success: false,
                error: "Type is required to fetch casino results"
            });
        }

        try {
            const lastResults = await CasinoService.fetchCasinolastResults(type);

            return res.status(200).json({
                success: true,
                data: lastResults
            });
        } catch (error) {
            console.error("❌ Error:", error.message);

            return res.status(500).json({
                success: false,
                error: error.message
            });
        }
    },

    // /report/casinoresult. `date` (YYYY-MM-DD, IST calendar din) optional hai:
    // diya ho to usi din ke saare rounds casino_result_archive se aate hain,
    // warna latest N. Frontend hi paginate/search karta hai, isliye poora din
    // ek hi response me jaata hai (sabse tez table ~1700 rounds/din).
    fetchResultReport: async (req, res) => {
        const { type, date, limit } = req.body;

        if (!type) {
            return res.status(400).json({
                success: false,
                error: "Type is required to fetch casino result report"
            });
        }

        // Kuch bhi aur aaye to date ko ignore karo — DB me `date` column par
        // galat string bind hone se query hi phat jaati.
        const day = /^\d{4}-\d{2}-\d{2}$/.test(String(date || "")) ? String(date) : null;

        try {
            const report = await CasinoService.fetchCasinoResultReport(type, { date: day, limit });

            return res.status(200).json({
                success: true,
                data: report,
                total: report?.total ?? 0
            });
        } catch (error) {
            console.error("❌ Error:", error.message);

            return res.status(500).json({
                success: false,
                error: error.message
            });
        }
    },

    fetchDetailResults: async (req, res) => {
        const { type, mid } = req.body;

        if (!type || !mid) {
            return res.status(400).json({
                success: false,
                error: "Type and ID are required to fetch casino results"
            });
        }

        try {
            const detailResults = await CasinoService.fetchCasionDetailResults(type, mid);

            return res.status(200).json({
                success: true,
                data: detailResults
            });
        } catch (error) {
            console.error("❌ Error:", error.message);

            return res.status(500).json({
                success: false,
                error: error.message
            });
        }
    },

    fetchCasionDetailsData: async (req, res) => {
        const { gmid, sid } = req.body;

        if (!gmid || !sid) {
            return res.status(400).json({
                success: false,
                error: "Type and ID are required to fetch casino details"
            });
        }

        try {
            const detailData = await CasinoService.fetchCasionDetailsData(gmid, sid);

            return res.status(200).json({
                success: true,
                data: detailData
            });
        } catch (error) {
            console.error("❌ Error:", error.message);

            return res.status(500).json({
                success: false,
                error: error.message
            });
        }
    },

    placeBet: async (req, res) => {
        // Identity comes from the TOKEN (authMiddleware on the route) — the
        // body's userId is ignored. Only player accounts place casino bets.
        const account = req.user?.account;

        if (!account?.id || String(account.type).toUpperCase() !== "USER") {
            return res.status(403).json({
                success: false,
                error: "Only player accounts can place bets."
            });
        }

        const userId = account.id;

        let {
            player_name,
            gameId,
            gameName,
            amount,
            odds,
            selection,
            roundId = 0,
            type,
            mtype,
            browser
        } = req.body;

        // ab3 / ab4 (Andar Bahar 50 / 150 cards) pay a flat 100% of the stake.
        // The feed's per-card fields are a bettable flag (`b`) and the shoe
        // count (`l`) — neither is a price — so pin the decimal here, before
        // exposure is computed, so a stale or tampered client cannot book a
        // bogus odds value. (Feed check: sub[0].b reads 2 whenever the market
        // is OPEN.)
        if (["ab3", "ab4"].includes(gameName)) {
            odds = 2;
        }

        const ipAddress = clientIp(req) || "";

        const browserInfo = browser || req.headers["user-agent"] || "";

        if (!gameId || !amount || !selection || !odds || !player_name) {
            return res.status(400).json({
                success: false,
                error: "gameId, amount, odds, and selection are required"
            });
        }

        // Bet lock on this player or any staff above them — the same rule
        // sports bets enforce (services/BetLockService.js).
        if (!(await BetLockService.isBettingAllowed(userId))) {
            return res.status(403).json({
                success: false,
                error: MESSAGES.BET.LOCKED_CONTACT_UPLINE
            });
        }

        let exposer = 0;
        let libality = 0;

        // Lay exposure must use decimal odds for every casino game,
        // including tables labelled as "fancy".
        if (type === "lay") {
            const value = odds - 1;
            exposer = -value * amount;
            libality = -amount;
        } else {
            exposer = -amount;
            libality = -amount;
        }

        // Reserve the maximum possible loss for multiplier-based games.
        if (CASINO_MULTIPLIER_GAMES[gameName]) {
            const maxRate = CASINO_MULTIPLIER_GAMES[gameName];
            exposer = -maxRate * amount;
            libality = -maxRate * amount;
        }

        const eventId = gameId;

        try {
            const table = await TableCasino.findOne({
                where: {
                    [Op.or]: [
                        { tableid: gameId },
                        { tableid: gameName }
                    ]
                }
            });

            if (table) {
                const tableId = table.id;

                const userLock = await UserTableLock.findOne({
                    where: {
                        user_id: userId,
                        table_casino_id: tableId,
                        is_locked: true
                    }
                });

                if (userLock) {
                    return res.status(403).json({
                        success: false,
                        error: "This game is locked for you."
                    });
                }

                const user = await User.findByPk(userId);

                if (user) {
                    let currentStaffId = user.parent_staff_id;
                    const currentOwnerId = user.parent_owner_id;

                    const checkPrivilegedLock = async (staffId, ownerId) => {
                        const whereClause = {
                            table_casino_id: tableId,
                            is_locked: true
                        };

                        if (staffId) whereClause.staff_id = staffId;
                        if (ownerId) whereClause.owner_id = ownerId;

                        return StaffTableLock.findOne({ where: whereClause });
                    };

                    if (currentOwnerId) {
                        const ownerLock = await checkPrivilegedLock(
                            null,
                            currentOwnerId
                        );

                        if (ownerLock) {
                            return res.status(403).json({
                                success: false,
                                error: "This game is locked by your upline."
                            });
                        }
                    }

                    while (currentStaffId) {
                        const staffLock = await checkPrivilegedLock(
                            currentStaffId,
                            null
                        );

                        if (staffLock) {
                            return res.status(403).json({
                                success: false,
                                error: "This game is locked by your upline."
                            });
                        }

                        const currentStaff = await Staff.findByPk(currentStaffId);

                        if (!currentStaff) break;

                        if (currentStaff.parent_owner_id) {
                            const ownerLock = await checkPrivilegedLock(
                                null,
                                currentStaff.parent_owner_id
                            );

                            if (ownerLock) {
                                return res.status(403).json({
                                    success: false,
                                    error: "This game is locked by your upline."
                                });
                            }
                        }

                        currentStaffId = currentStaff.parent_id;
                    }
                }
            }
        } catch (lockError) {
            console.error("❌ Lock Check Error:", lockError);
        }

        //=====================================================================
        // MIN / MAX STAKE VALIDATION (server-side)
        //=====================================================================
        // The casino tables quote their own min/max per runner in the feed and
        // useCasinoBet enforces them in the browser, but until now nothing
        // re-checked them here — a request built by hand could stake any
        // amount. The owner's per-game override (admin > Bet Limits > Casino)
        // is the authority when set; it is read through the Redis cache layer
        // and fails open, so a config problem can never block betting.
        try {
            const limits = await BettingConfigService.getCasinoLimits(gameName);
            const stakeNum = Number(amount);
            if (Number(limits?.min) > 0 && stakeNum < Number(limits.min)) {
                return res.status(400).json({
                    success: false,
                    error: `Minimum bet amount is ${Number(limits.min)}`
                });
            }
            if (Number(limits?.max) > 0 && stakeNum > Number(limits.max)) {
                return res.status(400).json({
                    success: false,
                    error: `Maximum bet amount is ${Number(limits.max)}`
                });
            }
        } catch (limitError) {
            console.warn("[casino placeBet] limit lookup failed (non-blocking):", limitError.message);
        }

        try {
            const betResult = await CasinoService.placeBet({
                userId,
                player_name,
                gameName,
                amount,
                odds,
                selection,
                exposer,
                libality,
                eventId,
                roundId,
                type,
                mtype,
                ip_address: ipAddress,
                browser: browserInfo
            });

            console.log("✅ Bet Placed Successfully:", betResult);

            return res.status(200).json({
                success: true,
                message: "Bet placed successfully",
                data: betResult
            });
        } catch (error) {
            console.error("❌ Place Bet Error:", error.message);

            // statusCode = a business rejection (e.g. OPPOSITE_SIDE_EXISTS) → 400.
            return res.status(error.statusCode || 500).json({
                success: false,
                error: error.message,
                // machine-readable reason for the UI (e.g. close the bet slip)
                ...(error.code ? { code: error.code } : {})
            });
        }
    },

    // Player-facing undo of open bets on a still-open round — this moves
    // money, so identity comes from the TOKEN (authMiddleware on the route),
    // never from the body, and only player accounts qualify.
    undoBet: async (req, res) => {
        const account = req.user?.account;

        if (!account?.id || String(account.type).toUpperCase() !== "USER") {
            return res.status(403).json({
                success: false,
                error: "Only player accounts can undo bets."
            });
        }

        const { gameName, roundId, all } = req.body;

        if (!gameName || !roundId) {
            return res.status(400).json({
                success: false,
                error: "gameName and roundId are required"
            });
        }

        try {
            const result = await CasinoService.undoBet({
                userId: account.id,
                gameName,
                roundId,
                all: all === true
            });

            return res.status(200).json({
                success: true,
                message: all === true ? "Bets cleared" : "Bet cancelled",
                data: result
            });
        } catch (error) {
            console.error("❌ Undo Bet Error:", error.message);

            return res.status(400).json({
                success: false,
                error: error.message
            });
        }
    },

    getUserBets: async (req, res) => {
        try {
            const { user_id, match_id } = req.body;
            const userId = user_id;

            if (!userId) {
                return res.status(400).json({
                    success: false,
                    error: "User ID is required"
                });
            }

            const bets = await CasinoService.UserBets(userId, match_id);

            return res.status(200).json({
                success: true,
                bets
            });
        } catch (error) {
            console.error("❌ getUserBets error:", error);

            return res.status(500).json({
                success: false,
                error: error.message
            });
        }
    },

    UserBets: async (req, res) => {
        try {
            const { user_id } = req.body;
            const userId = user_id;

            if (!userId) {
                return res.status(400).json({
                    success: false,
                    error: "User ID is required"
                });
            }

            const bets = await CasinoService.UserBetsHistory(userId);

            return res.status(200).json({
                success: true,
                bets
            });
        } catch (error) {
            console.error("❌ getUserBets error:", error);

            return res.status(500).json({
                success: false,
                error: error.message
            });
        }
    }
};

export default CasinoController;