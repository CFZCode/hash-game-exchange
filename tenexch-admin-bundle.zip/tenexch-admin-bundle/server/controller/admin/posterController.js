import Poster from '../../model/admin/Poster.js'; // Adjust the path as needed

const LIST_ORDER = [['is_mobile', 'ASC'], ['poster_id', 'ASC']];

const PosterController = {
    // Admin: get both poster variants (array; a variant is absent until set)
    getPoster: async (req, res) => {
        try {
            const posters = await Poster.findAll({ order: LIST_ORDER });

            res.status(200).json({ success: true, data: posters });
        } catch (error) {
            console.error('Error in getPoster:', error);
            res.status(500).json({ success: false, error: error.message });
        }
    },

    // Admin: set or update a poster link (upsert per variant, keyed by is_mobile)
    upsertPoster: async (req, res) => {
        try {
            const { image_url, is_mobile } = req.body;

            if (!image_url || typeof image_url !== 'string' || !image_url.trim()) {
                return res.status(400).json({ success: false, error: 'image_url is required' });
            }

            const mobile = is_mobile === true || is_mobile === 'true';

            let poster = await Poster.findOne({ where: { is_mobile: mobile } });

            if (poster) {
                await poster.update({ image_url: image_url.trim() });
            } else {
                poster = await Poster.create({ image_url: image_url.trim(), is_mobile: mobile });
            }

            res.status(200).json({ success: true, data: poster });
        } catch (error) {
            console.error('Error in upsertPoster:', error);
            res.status(500).json({ success: false, error: error.message });
        }
    },

    // Public: the frontend endpoint — [{ img, is_mobile }]; pick is_mobile true
    // for mobile view, false for web
    getPublicPoster: async (req, res) => {
        try {
            const posters = await Poster.findAll({ order: LIST_ORDER });

            res.status(200).json({
                success: true,
                data: posters.map((p) => ({ img: p.image_url, is_mobile: p.is_mobile })),
            });
        } catch (error) {
            console.error('Error in getPublicPoster:', error);
            res.status(500).json({ success: false, error: error.message });
        }
    },
};

export default PosterController;
