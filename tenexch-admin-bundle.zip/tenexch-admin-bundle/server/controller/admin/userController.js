import User from '../../model/user/User.js';
import { Op } from 'sequelize';
import { seedForUser as seedStakeButtons } from '../../services/user/StakeButtonService.js';

import PasswordService from '../../services/passwordService.js';
import sequelize from '../../config/db.js';
import WalletService from '../../services/walletService.js';
import Bank from '../../model/admin/Bank.js'; // Import the Bank model to fetch exchange rate
import BetLock from '../../model/admin/BetLock.js';
import UserSportsLock from '../../model/admin/UserSportsLock.js';
import StaffSportsLock from '../../model/admin/StaffSportsLock.js';
import { getSportNameById } from '../../utils/sportsNames.js';

import Staff from '../../model/admin/Staff.js';

import Role from '../../model/admin/Role.js';

import Wallet from '../../model/admin/Wallet.js';
import Transaction from '../../model/admin/Transaction.js';
import PointLedger from '../../model/admin/PointLedger.js';
import { POINT_EVENT, pointEntryRef } from '../../constants/pointLedger.js';
import TotalExposure from '../../model/user/TotalExposure.js';
import { getTotalExposureByHierarchy, getDescendantStaffIds } from '../../helper/getuserids.js';
import { calculateMaxWinExposure } from '../../helper/netExposureHelper.js';
import { memoise } from '../../helper/ttlMemo.js';
import UserNetExposure from '../../model/user/UserNetExposure.js';
import UserExposure from '../../model/user/UserExposure.js';
import CreditsLedger from "../../model/user/CreditsLedger.js";
import Owner from '../../model/admin/Owner.js';
import { body } from 'express-validator';
import ActivityLogService from '../../services/admin/ActivityLogService.js';
import { MAX_TXN_PASSWORD_ATTEMPTS } from '../../services/admin/transactionPasswordService.js';
import { getRulesAccepted } from '../../helper/rulesAccepted.js';
import { collectAffectedAccounts, revokeSessions } from '../../helper/accountLockChain.js';
import { emitForceLogout, emitAdminForceLogout } from '../../utils/socketUtils.js';
import { MESSAGES } from '../../constants/messages.js';

// Upline password reset switches off every secure-auth method. securityAuthType
// covers Google/Android; telegram2FAEnabled + telegramChatId cover Telegram
// (checked separately at login).
const TWO_FA_OFF = { securityAuthType: null, googleAuthSecret: null, telegram2FAEnabled: false, telegramChatId: null };



// helper ffunction to get user id for given role and username 

/**
 * Resolve all USER IDs under a given role + username hierarchy
 * @param {string} role
 * @param {string} username
 * @returns {number[]} user_ids
 */
export const getUserIdsByHierarchy = async (role, username) => {
  const upperRole = role.toUpperCase();

  let ownerId = null;
  let rootStaffId = null;

  /* ───────── OWNER CASE ───────── */
  if (upperRole === 'OWNER') {
    const owner = await Owner.findOne({
      where: { username },
      attributes: ['owner_id'],
      raw: true
    });

    if (!owner) return [];

    ownerId = owner.owner_id;

    // 1️⃣ All staff under this owner
    const staffRows = await Staff.findAll({
      where: { parent_owner_id: ownerId },
      attributes: ['staff_id'],
      raw: true
    });

    const staffIds = staffRows.map(s => s.staff_id);

    // 2️⃣ All users under owner OR under those staff
    const users = await User.findAll({
      where: {
        [Op.or]: [
          { parent_owner_id: ownerId },
          staffIds.length
            ? { parent_staff_id: { [Op.in]: staffIds } }
            : null
        ].filter(Boolean)
      },
      attributes: ['user_id'],
      raw: true
    });

    return users.map(u => u.user_id);
  }

  /* ───────── STAFF ROLES CASE ───────── */
  // SUPERADMIN, ADMIN, COMPANY, SUPERMASTER, MASTER, AGENT
  const staff = await Staff.findOne({
    where: { username },
    attributes: ['staff_id'],
    raw: true
  });

  if (!staff) return [];

  rootStaffId = staff.staff_id;

  // 🔁 Get all descendant staff (including self)
  const allStaffIds = [];
  let queue = [rootStaffId];

  while (queue.length) {
    const children = await Staff.findAll({
      where: { parent_id: { [Op.in]: queue } },
      attributes: ['staff_id'],
      raw: true
    });

    const childIds = children.map(c => c.staff_id);
    allStaffIds.push(...queue);
    queue = childIds;
  }

  // Include root staff
  if (!allStaffIds.includes(rootStaffId)) {
    allStaffIds.push(rootStaffId);
  }

  // 🔎 Final users under all staff
  const users = await User.findAll({
    where: {
      parent_staff_id: { [Op.in]: allStaffIds }
    },
    attributes: ['user_id'],
    raw: true
  });

  return users.map(u => u.user_id);
};

// ✅ Helper function — sum all credits from CreditsLedger for a user
const getUserTotalCredits = async (userId) => {
  try {
    // Force cast to string since credits_ledger.user_id is TEXT
    const total = await CreditsLedger.sum("amount", {
      where: { user_id: String(userId) },
    });
    return parseFloat(total || 0);
  } catch (error) {
    console.error("Error in getUserTotalCredits:", error);
    return 0;
  }
};


// Helper to get all descendant staff IDs recursively
const getAllDescendantStaffIds = async (staffId) => {
  let allIds = [staffId];
  let currentIds = [staffId];

  while (currentIds.length > 0) {
    const children = await Staff.findAll({
      where: { parent_id: { [Op.in]: currentIds } },
      attributes: ['staff_id'],
      raw: true
    });

    if (children.length === 0) break;

    const childIds = children.map(c => c.staff_id);
    allIds = [...allIds, ...childIds];
    currentIds = childIds;
  }
  return allIds;
};





// ─────────────────────────────────────────────────────────────────────────────
// Owner profile snapshot
//
// Single source of truth behind BOTH:
//   • GET /admin/owner/profile              (getLoggedInOwnerDetailsV2)
//   • the 2-second `ownerProfileUpdate` socket push (socket/socketHandler.js)
// so the REST answer and the live push can never drift apart.
//
// COST NOTE: the wallet read is a single indexed row, but `total_exposure` is a
// live MAX-WIN sweep over the owner's ENTIRE downline (hierarchy walk +
// user_exposures aggregate). Recomputing that every 2s per connected admin is
// what would actually hurt, so the two halves are cached on different clocks:
//   - wallet/owner row → recomputed every tick (money must look live)
//   - max-win exposure → memoised per owner for MAXWIN_TTL_MS
// REST callers pass no TTL, so they always get a fully fresh snapshot (the
// credit deposit/withdraw flow re-reads the profile immediately after moving
// money and must not see a stale number).
// ─────────────────────────────────────────────────────────────────────────────
const MAXWIN_TTL_MS = 10000;   // max-win exposure: recomputed at most every 10s
const PROFILE_TTL_MS = 1500;   // whole snapshot: shared by an owner's open tabs

const maxWinCache = new Map();   // owner_id -> { at, promise }
const profileCache = new Map();  // owner_id -> { at, promise }

// memoise / pruneCache live in helper/ttlMemo.js (shared with the staff profile push).

// MAX WIN across the owner's whole hierarchy — the most every end-user in the
// downline can win off the book (best outcome per market, clamped at 0, summed).
// Deliberately NOT the total_exposures snapshot: that snapshot is the MIN side
// (worst-case loss, negative) and it is what the player header and the admin
// Users list read. This reports the owner's payout risk instead, so it is a
// positive number and can differ from the list.
const computeMaxWin = (ownerUsername) =>
  getUserIdsByHierarchy('OWNER', ownerUsername).then((userIds) => calculateMaxWinExposure(userIds));

/**
 * Build the owner profile payload.
 * @param {number|string} ownerId
 * @param {{ maxWinTtlMs?: number }} [opts] maxWinTtlMs > 0 allows reusing a
 *        recently computed max-win exposure instead of recomputing it.
 * @returns {Promise<object|null>} null when the owner row does not exist
 */
export const buildOwnerProfile = async (ownerId, { maxWinTtlMs = 0 } = {}) => {
  // Step 1: Fetch Owner details directly from Owner table
  const owner = await Owner.findOne({
    where: { owner_id: ownerId },
    attributes: [
      'owner_id',
      'username',
      'website_name',
      'domain_name',
      'website_ui',
      'country',
      'logo',
      'favicon',
      'subscription_plan',
      'platform_name',
      'site_email_address',
      'account_status',
      'createdAt',
      'updatedAt'
    ],
    // No need for include — everything is in Owner table
    raw: false,
  });

  if (!owner) return null;

  const plainOwner = owner.get({ plain: true });

  // Steps 2-3 are independent, so they run concurrently.
  const [ownerWallet, maxWinExposure] = await Promise.all([

    // Step 2: Fetch owner's wallet (sirf jo keys response me chahiye)
    Wallet.findOne({
      where: { owner_id: ownerId, user_type: 'OWNER' },
      attributes: ['inr_balance', 'credit', 'all_point', 'upper_point', 'down_point', 'sports_pts', 'casino_pts', 'thirdparty_pts'],
      raw: true,
    }),

    // Step 3: payout risk — memoised only when the caller opted in (socket).
    maxWinTtlMs > 0
      ? memoise(maxWinCache, String(ownerId), maxWinTtlMs, () => computeMaxWin(plainOwner.username))
      : computeMaxWin(plainOwner.username),
  ]);

  const allPoint = ownerWallet ? parseFloat(ownerWallet.all_point || 0) : 0;
  const walletCredit = ownerWallet ? parseFloat(ownerWallet.credit || 0) : 0;

  // Step 4: Final response — clean & consistent with staff endpoint
  return {
    owner_id: plainOwner.owner_id,
    username: plainOwner.username,
    website_name: plainOwner.website_name,
    domain_name: plainOwner.domain_name,
    website_ui: plainOwner.website_ui,
    country: plainOwner.country,
    logo: plainOwner.logo,
    favicon: plainOwner.favicon,
    subscription_plan: plainOwner.subscription_plan,
    platform_name: plainOwner.platform_name,
    site_email_address: plainOwner.site_email_address,
    account_status: plainOwner.account_status,
    role: 'OWNER',
    level: null,
    percentage: null, // Owners don't have downline percentage
    inr_balance: ownerWallet ? parseFloat(ownerWallet.inr_balance || 0) : 0,
    // Positive: the most the whole downline can win off the book (payout
    // risk). 0 when no open market can pay out.
    total_exposure: maxWinExposure,
    credit: walletCredit,
    all_point: allPoint,
    upper_point: ownerWallet ? parseFloat(ownerWallet.upper_point || 0) : 0,
    down_point: ownerWallet ? parseFloat(ownerWallet.down_point || 0) : 0,
    // Settlement pts derived hai — alag column nahi: all_point − credit
    settlement_points: Math.round((allPoint - walletCredit) * 100) / 100,
    sports_pts: ownerWallet ? parseFloat(ownerWallet.sports_pts || 0) : 0,
    casino_pts: ownerWallet ? parseFloat(ownerWallet.casino_pts || 0) : 0,
    thirdparty_pts: ownerWallet ? parseFloat(ownerWallet.thirdparty_pts || 0) : 0,
    createdAt: plainOwner.createdAt,
    updatedAt: plainOwner.updatedAt,
  };
};

/**
 * Socket-side reader: one snapshot per owner per PROFILE_TTL_MS, so N open
 * admin tabs (and the reconnect storm after a deploy) cost one set of queries
 * instead of N. Never used by the REST endpoint.
 */
export const getOwnerProfileForSocket = (ownerId) =>
  memoise(profileCache, String(ownerId), PROFILE_TTL_MS, () =>
    buildOwnerProfile(ownerId, { maxWinTtlMs: MAXWIN_TTL_MS })
  );

/**
 * Drop the memoised snapshot so the very next socket tick re-reads the wallet.
 * Used by the `refreshOwnerProfile` socket event: after a credit deposit /
 * withdraw the admin must see the new number NOW, not up to PROFILE_TTL_MS
 * later. The max-win cache is deliberately left alone — moving credit between
 * accounts does not change what the downline can win off the book.
 */
export const invalidateOwnerProfile = (ownerId) => {
  profileCache.delete(String(ownerId));
};


const UserController = {

  // 🔎 Live username availability check across USERS, STAFF and OWNERS.
  // A username must be globally unique so it can never collide between a
  // player and an admin/staff/owner account.
  // Contract: 200 = available, 202 = taken (frontend keys off the status code).
  // Single round-trip: UNION ALL + outer LIMIT 1 lets Postgres stop at the
  // first hit; each branch is an index-only probe on lower(username).
  checkUsername: async (req, res) => {
    try {
      const username = String(req.query.username || '').trim().toLowerCase();
      if (username.length < 3 || username.length > 50) {
        return res.status(400).json({ available: false, error: 'username must be 3-50 characters' });
      }
      const rows = await sequelize.query(
        `SELECT 1 AS hit FROM users  WHERE lower(username) = :u
         UNION ALL
         SELECT 1 AS hit FROM staff  WHERE lower(username) = :u
         UNION ALL
         SELECT 1 AS hit FROM "Owners" WHERE lower(username) = :u
         LIMIT 1`,
        { replacements: { u: username }, type: sequelize.QueryTypes.SELECT }
      );
      const taken = rows.length > 0;
      res.set('Cache-Control', 'no-store');
      return res.status(taken ? 202 : 200).json({
        available: !taken,
        username,
        // The admin toasts this on Submit — the text lives here, not in the UI.
        ...(taken ? { message: MESSAGES.ADMIN.USERS.USERNAME_EXISTS } : {}),
      });
    } catch (error) {
      console.error('❌ checkUsername error:', error.message);
      return res.status(500).json({ available: false, error: error.message });
    }
  },

  createUserUnderParent: async (req, res) => {
    const transaction = await sequelize.transaction();
    try {
      const {
        username,
        fullname,
        email,
        password,
        phone_number,
        country,
        city,
        cash = 0,
        credit_ref = 0,
        // "User Rate" on the admin create-account form (users.percentage).
        percentage = 0,
        // "Password Change" tick on the admin create-account form. Ticked
        // stores false = this player may not change their own password after
        // the forced first-login change.
        passwordChangeAllowed = true,
      } = req.body;

      // A blank Credit Amount means 0 and is accepted (user, 2026-09-21), so
      // whitespace is trimmed off before deciding whether anything was typed.
      const rawCredit = typeof credit_ref === 'string' ? credit_ref.trim() : credit_ref;
      const credit = parseFloat(rawCredit) || 0;

      // Credit can be 0 but never negative, and never a non-number: a "-37"
      // typed into Credit Amount used to sail through and open the account
      // with a negative wallet. The reference refuses it with this exact text.
      if (rawCredit !== undefined && rawCredit !== null && rawCredit !== ''
          // plain number, max 2 decimals: "100abc"/"1e3"/"1,000"/"0.005" (DB rounds it up to 0.01) refused
          && (!['number', 'string'].includes(typeof rawCredit) || !/^\d+(\.\d{1,2})?$/.test(String(rawCredit)))) {
        await transaction.rollback();
        return res.status(400).json({ success: false, message: MESSAGES.ADMIN.USERS.CREDIT_AMOUNT_INVALID, error: MESSAGES.ADMIN.USERS.CREDIT_AMOUNT_INVALID });
      }
      console.log("api called: from  user controller", req?.user)



      // 🧠 Logged-in staff/owner/admin from auth middleware

      const parentRole = req.user?.role?.toUpperCase();
      const parentId = req.user.account.id; //could be ownerid or staff id defined in auth middleware from token decode

      if (!parentId || !parentRole) {
        throw new Error('parentID, parentRole are required.');
      }

      if (!username || !password) {
        throw new Error('Username and password are required.');
      }

      let parent = null;

      // Validate parent existence: either owner or staff
      if (parentRole === "OWNER") {
        parent = await Owner.findByPk(parentId, { transaction });
        if (!parent) {
          await transaction.rollback();
          return res.status(400).json({ message: 'Owner not found.' });
        }
      } else {
        parent = await Staff.findByPk(parentId, { transaction });
        if (!parent) {
          await transaction.rollback();
          return res.status(400).json({ message: 'Staff not found.' });
        }
      }

      console.log("Parent found:", parent);

      // 🧾 Validate password strength
      const { isValid, errors } = PasswordService.validatePasswordStrength(password);
      if (!isValid) {
        await transaction.rollback();
        return res.status(400).json({
          success: false,
          message: 'Weak password',
          errors,
        });
      }

      // 🔐 Hash password
      const hashedPassword = await PasswordService.hashPassword(password);

      // 🎯 Get user role ID (if role table exists)
      let roleId = 8; // by default user role id
      const userRole = await Role.findOne({ where: { role: 'USER' }, transaction });
      if (userRole) roleId = userRole.role_id;

      // 🧩 Determine correct parent_id either it is from  owner or staff
      let parent_staff_id = null;
      let parent_owner_id = null
      if (parentRole === 'OWNER') { parent_owner_id = parentId; }
      else { parent_staff_id = parentId }

      // validating user already exist or not
      // 🔒 Username must be globally unique across USERS, STAFF and OWNERS
      // (case-insensitive), so a player can never reuse a staff/owner name.
      const nameWhere = { username: { [Op.iLike]: username } };
      const [userNameDup, staffNameDup, ownerNameDup] = await Promise.all([
        User.findOne({ where: nameWhere, attributes: ['user_id'], raw: true }),
        Staff.findOne({ where: nameWhere, attributes: ['staff_id'], raw: true }),
        Owner.findOne({ where: nameWhere, attributes: ['owner_id'], raw: true }),
      ]);
      if (userNameDup || staffNameDup || ownerNameDup) {
        throw new Error(MESSAGES.ADMIN.USERS.USERNAME_EXISTS);
      }

      // Email uniqueness (within users)
      if (email) {
        const emailDup = await User.findOne({ where: { email }, attributes: ['user_id'], raw: true });
        if (emailDup) throw new Error('Email already exists');
      }

      // 🧱 Create user
      const newUser = await User.create(
        {
          username,
          fullname: fullname || null,
          email,
          password: hashedPassword,
          phone_number,
          country,
          city: city || null,
          parent_staff_id: parent_staff_id,
          parent_owner_id: parent_owner_id,
          role_id: roleId,
          role: 'USER',
          status: 'Active',
          percentage: parseFloat(percentage) || 0,
          passwordChangeAllowed: passwordChangeAllowed !== false,
        },
        { transaction }
      );

      // 💰 Create wallet for user
      // Every new account starts with the reference stake ladders (1k…25k /
      // 10…500) already in the database, so the Set Button Value modal opens
      // populated instead of falling back to client-side constants.
      await seedStakeButtons(newUser.user_id, transaction);

      const userWallet = await WalletService.createWallet(
        newUser.user_id,
        'USER',
        transaction,
        newUser.username,
      );

      // Save credit_ref as credit to user wallet
      // Set when the parent is short: account is still created, with 0 credit.
      let insufficientBal = null;
      if (credit > 0) {

        // Sender = logged-in parent (owner or staff) who is handing out the credit
        const senderType = parentRole;                                     // OWNER | ADMIN | MASTER ...
        const senderId = parentId;
        const senderField = WalletService.getWalletQueryField(senderType); // owner_id | staff_id

        const senderWallet = await Wallet.findOne({
          where: { [senderField]: senderId, user_type: senderType },
          transaction,
          lock: transaction.LOCK.UPDATE
        });
        if (!senderWallet) throw new Error('Sender wallet not found');

        const currentBal = Number(senderWallet.inr_balance || 0);
       // const currentCredit = Number(senderWallet.credit || 0);
        const deductAmount = Number(credit);

        const extraPoint = Math.round((parseFloat(senderWallet?.upper_point || 0) + parseFloat(senderWallet?.down_point || 0)) * 100) / 100;
        const balanceWithoutExtraPoint = extraPoint > 0 ? Math.round((currentBal - extraPoint) * 100) / 100 : currentBal;
        
        if (currentBal < deductAmount) {
          // Parent is short — create the account anyway with 0 credit.
          // Nothing moves, so no ledger / transaction rows.
          insufficientBal = currentBal;
        } 
        else if(balanceWithoutExtraPoint < deductAmount){
           insufficientBal = balanceWithoutExtraPoint;
        }
        else {
          senderWallet.inr_balance = currentBal - deductAmount;

          await senderWallet.save({ transaction });

          // 💳 Hand the credit over to the newly created user
          userWallet.credit       = credit;
          userWallet.cash         = credit;
          userWallet.inr_balance  = credit;
          userWallet.all_point    = credit;
          await userWallet.save({ transaction });

          // Opening balance ki point_ledger entry — naya user day-one se ledger me matched rahe
          await PointLedger.create({
            entry_ref: pointEntryRef.opening(userWallet.wallet_id),
            event_type: POINT_EVENT.USER_CREATION,
            wallet_id: userWallet.wallet_id,
            username: newUser.username,
            settled_with_wallet_id: senderWallet.wallet_id,
            delta: credit,
            all_point_after: credit,
            closing_inr_balance: credit,
            closing_inr_balance_parent: currentBal - deductAmount,
            remark: `${POINT_EVENT.USER_CREATION}#${senderWallet?.username}/${newUser?.username}`,
          }, { transaction });


          //This is for user Staff/Owner
           await Transaction.create({
            wallet_id: senderWallet.wallet_id,
            user_id: newUser?.user_id,
            staff_id: senderType.toUpperCase() === 'OWNER'?null:senderId,
            owner_id: senderType.toUpperCase() === 'OWNER' ? senderId : null,
            username: senderWallet?.username,
            type: "DEBIT_FOR_CREDIT",
            amount: deductAmount,
            previous_balance: currentBal,
            new_balance: currentBal - deductAmount,
            balance: currentBal - deductAmount,
            credit: newUser?.username,
            debit: senderWallet?.username,
            initiated_by: senderWallet.username,
          }, { transaction });


          //This is for user transaction
           await Transaction.create({
            wallet_id: userWallet?.wallet_id,
            user_id: newUser?.user_id,
            staff_id: senderType.toUpperCase() === 'OWNER'?null:senderId,
            owner_id: senderType.toUpperCase() === 'OWNER' ? senderId : null,
            username: newUser?.username,
            type: "ADD_CREDIT",
            amount: credit,
            previous_balance: 0,
            new_balance:  credit,
            balance: credit,
            credit: newUser?.username,
            debit: senderWallet?.username,
            initiated_by: senderWallet.username,
          }, { transaction });
        }
      }

      // 🔐 Create BetLock for user (within transaction to avoid FK constraint issues)
      await BetLock.create(
        {
          user_id: newUser.user_id,
          MatchOdds: false,
          OtherMarkets: false,
        },
        { transaction }
      );

      await transaction.commit();

      return res.status(201).json({
        success: true,
        message: insufficientBal !== null
          ? MESSAGES.ADMIN.USERS.CREATED_INSUFFICIENT_CREDIT(insufficientBal)
          : 'User created successfully under parent',
        creditSkipped: insufficientBal !== null,
        data: {
          user_id: newUser.user_id,
          username: newUser.username,
          email: newUser.email,
          parent_staff_id: newUser.parent_staff_id,
          parent_owner_id: newUser.parent_owner_id,
          owner_id: newUser.owner_id,
        },
      });
    } catch (error) {
      await transaction.rollback();
      console.error('❌ createUserUnderParent error:', error);
      return res.status(400).json({
        success: false,
        message: 'Failed to create user under parent',
        error: error.message,
      });
    }
  },

  // Register a new user (without initial balance)
  registerUser: async (req, res) => {
    const transaction = await sequelize.transaction(); // Start a transaction
    try {
      const userData = req.body;
      const { ...userDetails } = userData;

      // Validate password strength before hashing
      if (userDetails.password) {
        const passwordValidation = PasswordService.validatePasswordStrength(userDetails.password);
        if (!passwordValidation.isValid) {
          return res.status(400).json({
            success: false,
            error: `Password validation failed: ${passwordValidation.errors.join(', ')}`
          });
        }

        // Hash the password using PasswordService
        userDetails.password = await PasswordService.hashPassword(userDetails.password);
      }

      // Create a new user
      const user = await User.create(userDetails, { transaction });

      // Same default stake ladders as createUser above.
      await seedStakeButtons(user.user_id, transaction);

      // Create a wallet for the user
      await WalletService.createWallet(user.user_id, 'User', transaction, user.username);

      await transaction.commit(); // Commit the transaction
      res.status(201).json({ success: true, data: user });
    } catch (error) {
      await transaction.rollback(); // Rollback the transaction on error
      console.error('Error in registerUser:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  },

  // Get all users
  getAllUsers: async (req, res) => {
    try {
      const users = await User.findAll();
      res.status(200).json(users);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  },

  // Update password loged in user
  updatePassword: async (req, res) => {
    const transaction = await sequelize.transaction(); // Start a transaction
    try {
      const userId = req.user.account.id; // Assuming user ID is available in req.user
      const { currentPassword, newPassword } = req.body;

      if (!currentPassword || !newPassword) {
        return res.status(400).json({ success: false, error: 'Password fields cannot be empty' });
      }

      // Find the user
      const user = await User.findOne({ where: { user_id: userId } });
      if (!user) {
        return res.status(404).json({ success: false, error: 'User not found' });
      }

      // Verify the current password using PasswordService
      const isPasswordValid = await PasswordService.comparePassword(currentPassword, user.password);
      if (!isPasswordValid) {
        return res.status(400).json({ success: false, error: 'Current password is incorrect' });
      }

      // Validate new password strength
      const passwordValidation = PasswordService.validatePasswordStrength(newPassword);
      if (!passwordValidation.isValid) {
        return res.status(400).json({
          success: false,
          error: `New password validation failed: ${passwordValidation.errors.join(', ')}`
        });
      }

      // Hash the new password using PasswordService
      const hashedNewPassword = await PasswordService.hashPassword(newPassword);

      // Update the user's password with hashed password
      await user.update({ password: hashedNewPassword }, { transaction });

      await transaction.commit(); // Commit the transaction

      // 📝 Feeds the admin "Change Password History" report
      await ActivityLogService.log({
        req,
        user: { username: user.username, user_type: 'USER', user_id: user.user_id },
        action: 'PASSWORD_CHANGE',
        details: { changed_by: user.username },
      });

      res.status(200).json({ success: true, message: 'Password updated successfully' });
    } catch (error) {
      await transaction.rollback(); // Rollback the transaction on error
      console.error('Error in updatePassword:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  },

  // Update password loged in staff
  updateStaffPassword: async (req, res) => {
    const transaction = await sequelize.transaction(); // Start a transaction
    try {
      const staff_id = req.user.account.id;// Assuming user ID is available in req.user
      const { newPassword } = req.body;

      if (!newPassword) {
        return res.status(400).json({ success: false, error: 'Password fields cannot be empty' });
      }

      // Find the user
      const staff = await Staff.findOne({ where: { staff_id } });
      if (!staff) {
        return res.status(404).json({ success: false, error: 'User not found' });
      }


      // Validate new password strength
      const passwordValidation = PasswordService.validatePasswordStrength(newPassword);
      if (!passwordValidation.isValid) {
        return res.status(400).json({
          success: false,
          error: `New password validation failed: ${passwordValidation.errors.join(', ')}`
        });
      }

      // Hash the new password using PasswordService
      const hashedNewPassword = await PasswordService.hashPassword(newPassword);

      // 🔐 Changing the login password also rotates the transaction password.
      // We generate a fresh 6-digit code and return it so the UI can show it.
      const newTransactionPassword = Math.floor(100000 + Math.random() * 900000).toString();
      await staff.update({ password: hashedNewPassword, transaction_password: newTransactionPassword }, { transaction });

      await transaction.commit(); // Commit the transaction

      // 📝 Feeds the admin "Change Password History" report
      await ActivityLogService.log({
        req,
        user: { username: staff.username, user_type: 'STAFF', staff_id },
        action: 'PASSWORD_CHANGE',
        details: { changed_by: staff.username },
      });

      res.status(200).json({ success: true, message: 'Password updated successfully', transactionPassword: newTransactionPassword });
    } catch (error) {
      await transaction.rollback(); // Rollback the transaction on error
      console.error('Error in updatePassword:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  },




  // newly added password and status(active/true)
  updateStaffAndUser: async (req, res) => {
    console.log("req body for newly added update password=====>> ", req.body);

    const { user_type, newPassword, staff_id, user_id, active, status } = req.body;
    // Frontend sends this field as `bet_lock`; older callers used `betlock`.
    const betlock = req.body.betlock ?? req.body.bet_lock;
    // Toggles arrive as booleans; older callers send 'true'/'1'.
    const isOn = (v) => v === true || v === 'true' || v === 1 || v === '1';

    console.log("fetched details: update user/staff pass===>", {
      user_type,
      newPassword,
      staff_id,
      user_id,
    });

    if (!newPassword && active == null && status == null && betlock == null) {
      return res
        .status(400)
        .json({ success: false, error: "At least one field (password, status, or betlock) must be provided" });
    }

    const transaction = await sequelize.transaction();

    try {
      let updated = false;
      let message = "";
      let transactionPassword = null; // rotated + returned when a STAFF password changes
      // Set only on a LOCK transition (unlocks never log anyone out). The admin
      // screens send bet_lock AND status/active on every toggle, so compare
      // against the stored value, not just the payload.
      let lockReason = null;
      let passwordTarget = null; // set when a password actually changed → PASSWORD_CHANGE log

      if (user_type === "USER") {
        // Find the user
        const user = await User.findOne({ where: { user_id }, transaction });
        if (!user) {
          await transaction.rollback();
          return res.status(404).json({ success: false, error: "User not found" });
        }

        // Update password if provided
        if (newPassword != null) {
          const passwordValidation = PasswordService.validatePasswordStrength(newPassword);
          if (!passwordValidation.isValid) {
            await transaction.rollback();
            return res.status(400).json({
              success: false,
              error: `New password validation failed: ${passwordValidation.errors.join(", ")}`,
            });
          }

          const hashedNewPassword = await PasswordService.hashPassword(newPassword);
          // Admin-set password → force the user to set their own on next login.
          await user.update({ password: hashedNewPassword, passwordChanged: false, ...TWO_FA_OFF }, { transaction });
          updated = true;
          passwordTarget = { username: user.username, user_type: 'USER', user_id: user.user_id };
          message += "Password updated successfully. ";
        }

        // Update status if provided
        if (status != null) {
          if (user.status === 'Active' && status !== 'Active') {
            lockReason = MESSAGES.AUTH.USER_LOCKED_CONTACT_UPLINE;
          }
          await user.update({ status }, { transaction });
          updated = true;
          message += "Status updated successfully.";
        }
        if (betlock != null) {
          if (!user.bet_locked && isOn(betlock)) {
            lockReason = lockReason || MESSAGES.BET.LOCKED_CONTACT_UPLINE;
          }
          await user.update({ bet_locked: betlock }, { transaction });
          updated = true;
          message += "Betlock updated successfully.";
        }
      } else {
        // STAFF handling
        const staff = await Staff.findOne({ where: { staff_id }, transaction });
        if (!staff) {
          await transaction.rollback();
          return res.status(404).json({ success: false, error: "Staff not found" });
        }

        // Update password if provided
        if (newPassword != null) {
          const passwordValidation = PasswordService.validatePasswordStrength(newPassword);
          if (!passwordValidation.isValid) {
            await transaction.rollback();
            return res.status(400).json({
              success: false,
              error: `New password validation failed: ${passwordValidation.errors.join(", ")}`,
            });
          }

          const hashedNewPassword = await PasswordService.hashPassword(newPassword);
          // 🔐 Changing the staff's login password also rotates their
          // transaction password; it is returned so the admin can relay it.
          transactionPassword = Math.floor(100000 + Math.random() * 900000).toString();
          await staff.update(
            { password: hashedNewPassword, first_login: false, transaction_password: transactionPassword, txn_password_attempts: MAX_TXN_PASSWORD_ATTEMPTS, ...TWO_FA_OFF },
            { transaction }
          );
          updated = true;
          passwordTarget = { username: staff.username, user_type: 'STAFF', staff_id: staff.staff_id };
          message += "Password updated successfully. ";
        }

        // Update active status if provided
        if (active != null) {
          if (staff.active && !isOn(active)) {
            lockReason = MESSAGES.AUTH.USER_LOCKED_CONTACT_UPLINE;
          }
          const statusUpdates = { active };
          // Reactivating does NOT restore the transaction-password attempt
          // allowance: attempts = 0 is its own lock (see staffAuthService),
          // and the only way out is the parent changing this staff's login
          // password, which rotates the transaction password and resets the
          // counter above.
          await staff.update(statusUpdates, { transaction });
          updated = true;
          message += "Status updated successfully.";
        }
        if (betlock != null) {
          if (!staff.bet_locked && isOn(betlock)) {
            lockReason = lockReason || MESSAGES.BET.LOCKED_CONTACT_UPLINE;
          }
          await staff.update({ bet_locked: betlock }, { transaction });
          updated = true;
          message += "Betlock updated successfully.";
        }
      }

      // Commit only if something was updated
      if (updated) {
        // A lock logs out the account and, for a staff account, its whole
        // downline (helper/accountLockChain.js). Revoked inside the transaction
        // so the sessions die together with the lock, or not at all.
        let kickedUserIds = [];
        let kickedStaffIds = [];
        if (lockReason) {
          const target = user_type === "USER"
            ? { type: 'USER', id: user_id }
            : { type: 'STAFF', id: staff_id };
          const affected = await collectAffectedAccounts(target);
          await revokeSessions(affected, transaction);
          kickedUserIds = affected.userIds;
          kickedStaffIds = affected.staffIds;
          console.log(
            `[AccountLock] ${target.type} #${target.id} locked → revoked ${affected.userIds.length} user / ${affected.staffIds.length} staff sessions`
          );
        }

        await transaction.commit();

        // Instant logout for open player tabs; the dead token is the backstop.
        if (kickedUserIds.length) await emitForceLogout(kickedUserIds, lockReason);
        // Staff sessions were revoked in the same transaction but were never
        // told, so an admin only found out at its next request. Push to them too.
        if (kickedStaffIds.length) await emitAdminForceLogout(kickedStaffIds, lockReason);

        // 📝 Log Activity
        // We log who performed the action (req.user)
        if (req.user) {
          const targetType = user_type === "USER" ? "User" : "Staff";
          const targetId = user_type === "USER" ? user_id : staff_id;
          await ActivityLogService.log({
            req,
            user: req.user,
            action: 'UPDATE_ACCOUNT',
            details: `${message.trim()} (Target: ${targetType} #${targetId})`,
          });
        }

        // 📝 PASSWORD_CHANGE against the TARGET account — feeds the admin
        // "Change Password History" report (changed_by = acting admin).
        if (passwordTarget) {
          await ActivityLogService.log({
            req,
            user: passwordTarget,
            action: 'PASSWORD_CHANGE',
            details: { changed_by: req.user?.username || null },
          });
        }

        return res.status(200).json({ success: true, message: message.trim(), transactionPassword });
      } else {
        await transaction.rollback();
        return res.status(400).json({ success: false, error: "No valid fields provided to update" });
      }
    } catch (error) {
      await transaction.rollback();
      console.error("Error in update staff/user:", error);
      res.status(500).json({ success: false, error: error.message });
    }
  },

  // Get a user by ID (fetched from req.user)
  getUser: async (req, res) => {
    try {
      const userId = req.user.account.id; // Assuming user ID is available in req.user
      const Role = req.user.role; // Contains the role of the user who made the request

      // Find the user by ID
      const user = await User.findOne({ where: { user_id: userId } });
      if (!user) {
        return res.status(404).json({ success: false, error: 'User not found' });
      }

      // Return the user details (excluding sensitive information like password)
      const userDetails = {
        user_id: user.user_id,
        username: user.username,
        email: user.email,
        createdAt: user.createdAt,
        updatedAt: user.updatedAt,
        requestRole: Role,
      };

      res.status(200).json({ success: true, user: userDetails });
    } catch (error) {
      console.error('Error in getUser:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  },





  getUserAllDetails: async (req, res) => {
    try {
      const page = parseInt(req.query.page) || 1;
      const limit = parseInt(req.query.limit) || 10;
      const offset = (page - 1) * limit;
      const search = req.query.search || '';
      const exact = req.query.exact || ''; // Exact username match
      const type = req.query.type?.toUpperCase(); // Optional: USER, STAFF, or none
      const parentId = req.query.parentId || null; // Drill-down: is staff ke direct children dikhao

      const STAFF_TYPES = ['SUPERADMIN', 'ADMIN', 'SUPERMASTER', 'MASTER', 'AGENT', 'OWNER', 'COMPANY'];

      let wallets = [];
      let totalWallets = 0;

      // 1. Determine Scope — hamesha sirf DIRECT children:
      //    bina parentId ke → apne (logged-in ke), parentId ke saath → us staff ke (drill-down)
      const loggedInRole = req.user?.role?.toUpperCase();
      const loggedInId = req.user.account.id;

      let parentStaffWhere;
      let directUserWhere;

      if (parentId) {
        const targetId = parseInt(parentId);
        const targetStaff = await Staff.findByPk(targetId, { attributes: ['staff_id', 'parent_owner_id'], raw: true });
        if (!targetStaff) {
          return res.status(404).json({ success: false, message: 'Staff not found' });
        }

        // Security: parentId meri apni hierarchy ka hi hona chahiye
        let inScope = false;
        if (loggedInRole === 'OWNER') {
          inScope = Number(targetStaff.parent_owner_id) === Number(loggedInId);
        } else {
          const myDownlineIds = await getDescendantStaffIds(loggedInId);
          inScope = targetId === Number(loggedInId) || myDownlineIds.includes(targetId);
        }
        if (!inScope) {
          return res.status(403).json({ success: false, message: 'Unauthorized access to this downline' });
        }

        parentStaffWhere = { parent_id: targetId };
        directUserWhere = { parent_staff_id: targetId };
      } else {
        parentStaffWhere = loggedInRole === 'OWNER'
          ? { parent_owner_id: loggedInId, parent_id: null }   // owner ke seedha neeche wale staff
          : { parent_id: loggedInId };                          // staff ke apne banaye staff
        directUserWhere = loggedInRole === 'OWNER'
          ? { parent_owner_id: loggedInId, parent_staff_id: null }
          : { parent_staff_id: loggedInId };
      }

      const directStaff = await Staff.findAll({
        where: parentStaffWhere,
        attributes: ['staff_id'],
        raw: true
      });
      const allowedStaffIds = directStaff.map(s => s.staff_id);

      // 2. Build Base Where Clause
      let baseWhere = {};
      if (exact) {
        baseWhere.username = exact;
      } else if (search) {
        baseWhere.username = { [Op.like]: `%${search}%` };
      }

      // ────── CASE: Return ALL users (staff + bettors) → DEFAULT behavior ──────
      if (!type) {
        // Direct users nikalo (owner ke khud ke ya staff ke apne)
        const directUsers = await User.findAll({
          where: directUserWhere,
          attributes: ['user_id'],
          raw: true
        });
        const allowedUserIds = directUsers.map(u => u.user_id);

        // Sirf direct children ke wallets — apna wallet apne aap bahar
        // (khud ka staff_id/user_id in lists me kabhi nahi hota)
        baseWhere[Op.and] = [
          {
            [Op.or]: [
              { staff_id: { [Op.in]: allowedStaffIds } },
              { user_id: { [Op.in]: allowedUserIds } }
            ]
          }
        ];

        // We can still include Staff for extra details if needed, but let's keep it simple to avoid errors.
        // If we need staff details (percentage, etc), we can fetch separately or try include again for Staff only.
        // The original code included Staff. Let's keep it if it works, or remove if risk.
        // Let's remove includes for now to be safe and just return wallet data.

        const allData = await Wallet.findAll({
          where: baseWhere,
          attributes: [
            'wallet_id', 'user_id', 'staff_id', 'username', 'user_type',
            'inr_balance', 'cash', 'credit', 'all_point', 'upper_point', 'down_point',
            'createdAt', 'updatedAt'
          ],
          include: [{
            model: Staff,
            as: 'staff',
            attributes: ['percentage', 'level', 'role', 'active', 'bet_locked', 'fullname', 'city', 'phone_number'],
            required: false,
          }, {
            model: User,
            as: 'user',
            attributes: ['status', 'bet_locked', 'phone_number', 'country', 'fullname', 'city', 'securityAuthType', 'percentage'],
            required: false,
          }],
          limit,
          offset,
          order: [[sequelize.fn('LOWER', sequelize.col('Wallet.username')), 'ASC'], ['wallet_id', 'ASC']],
          raw: true,
        });

        totalWallets = await Wallet.count({
          where: baseWhere,
        });

        // Exposure snapshot for the USER rows on this page — the SAME
        // total_exposures row the player header reads. Batched into one query
        // (a per-row hierarchy lookup would be N+1 on every page load).
        // The admin list used to send no exposure field at all, so the UI's
        // `account.exposure ?? account.total_exposure ?? 0` always fell through
        // to 0 and the Exposure column read 0 for everyone.
        const pageUserIds = allData.map(p => p.user_id).filter(Boolean);
        const exposureRows = pageUserIds.length
          ? await TotalExposure.findAll({ where: { user_id: { [Op.in]: pageUserIds } }, raw: true })
          : [];
        // Stored signed (liability is negative); the column shows magnitude.
        const exposureByUser = new Map(
          exposureRows.map(e => [Number(e.user_id), Math.abs(parseFloat(e.total_exposure || 0))])
        );

        // Saara data seedha wallet columns se — dashboard wali hi keys, koi BFS/recompute nahi
        wallets = allData.map(p => {
          const isStaff = STAFF_TYPES.includes(p.user_type);
          const allPoint = parseFloat(p.all_point || 0);
          const credit = parseFloat(p.credit || 0);

          return {
            wallet_id: p.wallet_id,
            user_id: p.user_id,
            staff_id: p.staff_id,
            username: p.username,
            user_type: p.user_type,
            role: isStaff ? (p['staff.role'] || p.user_type) : 'USER',
            level: isStaff ? p['staff.level'] : null,
            percentage: isStaff ? (p['staff.percentage'] ? parseFloat(p['staff.percentage']) : null) : (p['user.percentage'] != null ? parseFloat(p['user.percentage']) : 0),
            inr_balance: parseFloat(p.inr_balance || 0),
            credit,
            all_point: allPoint,
            upper_point: parseFloat(p.upper_point || 0),
            down_point: parseFloat(p.down_point || 0),
            settlement_points: Math.round((allPoint - credit) * 100) / 100,
            // Staff have no per-account exposure snapshot (theirs is the sum of
            // their downline), so they stay 0 here rather than showing a wrong number.
            exposure: isStaff ? 0 : (exposureByUser.get(Number(p.user_id)) || 0),
            // available_points: user ke liye cash, staff ke liye inr_balance
            available_points: isStaff ? parseFloat(p.inr_balance || 0) : parseFloat(p.cash || 0),
            createdAt: p.createdAt,
            updatedAt: p.updatedAt,
            status: p.user_type === 'USER' ? (p['user.status'] || 'Active') : (p['staff.active'] ? 'Active' : 'InActive'),
            active: isStaff ? (p['staff.active'] === 1 || p['staff.active'] === true) : (p['user.status'] === 'Active'),
            bet_locked: isStaff ? (p['staff.bet_locked'] === 1 || p['staff.bet_locked'] === true) : (p['user.bet_locked'] === 1 || p['user.bet_locked'] === true),
            // Staff keep theirs in staff.phone_number since 2026-09-21; before
            // that the column did not exist and this line hard-coded null.
            phone_number: isStaff ? (p['staff.phone_number'] || null) : (p['user.phone_number'] || null),
            country: isStaff ? null : (p['user.country'] || null),
            fullname: isStaff ? (p['staff.fullname'] || null) : (p['user.fullname'] || null),
            city: isStaff ? (p['staff.city'] || null) : (p['user.city'] || null),
            // 'telegram' | 'google' | 'android' | null — drives the admin
            // User Authentication report. Staff 2FA is managed separately.
            securityAuthType: isStaff ? null : (p['user.securityAuthType'] || null),
          };
        });
      }

      // ────── CASE: Only STAFF ──────
      else if (type === 'STAFF') {
        baseWhere.user_type = { [Op.in]: STAFF_TYPES };
        // Sirf direct staff
        baseWhere.staff_id = { [Op.in]: allowedStaffIds };

        const staffData = await Wallet.findAll({
          where: baseWhere,
          attributes: ['wallet_id', 'user_id', 'staff_id', 'username', 'user_type', 'inr_balance', 'credit', 'all_point', 'upper_point', 'down_point', 'createdAt', 'updatedAt'],
          include: [{ model: Staff, as: 'staff', attributes: ['percentage', 'level', 'role', 'active', 'bet_locked', 'fullname', 'city'], required: false }],
          limit, offset, order: [[sequelize.fn('LOWER', sequelize.col('Wallet.username')), 'ASC'], ['wallet_id', 'ASC']], raw: false,
        });

        totalWallets = await Wallet.count({ where: baseWhere });

        // Seedha wallet columns se — dashboard wali hi keys
        wallets = staffData.map(item => item.get({ plain: true })).map(p => {
          const allPoint = parseFloat(p.all_point || 0);
          const credit = parseFloat(p.credit || 0);
          return {
            wallet_id: p.wallet_id,
            user_id: p.user_id,
            staff_id: p.staff_id,
            username: p.username,
            user_type: p.user_type,
            role: p.staff?.role || p.user_type,
            level: p.staff?.level,
            percentage: p.staff?.percentage ? parseFloat(p.staff.percentage) : null,
            inr_balance: parseFloat(p.inr_balance || 0),
            credit,
            all_point: allPoint,
            upper_point: parseFloat(p.upper_point || 0),
            down_point: parseFloat(p.down_point || 0),
            settlement_points: Math.round((allPoint - credit) * 100) / 100,
            available_points: parseFloat(p.inr_balance || 0),
            createdAt: p.createdAt,
            updatedAt: p.updatedAt,
            status: p.staff?.active ? 'Active' : 'InActive',
            active: p.staff?.active,
            bet_locked: p.staff?.bet_locked === 1 || p.staff?.bet_locked === true,
            fullname: p.staff?.fullname || null,
            city: p.staff?.city || null,
          };
        });
      }

      // ────── CASE: Only BETTORS (USER) ──────
      else if (type === 'USER') {
        baseWhere.user_type = 'USER';

        // Sirf apne DIRECT users (inner join se filter enforce hota hai)
        const userInclude = [{
          model: User,
          as: 'user',
          attributes: ['status', 'bet_locked', 'phone_number', 'country', 'fullname', 'city', 'securityAuthType', 'percentage'],
          where: directUserWhere,
          required: true
        }];

        wallets = await Wallet.findAll({
          where: baseWhere,
          attributes: ['wallet_id', 'user_id', 'staff_id', 'username', 'user_type', 'inr_balance', 'cash', 'credit', 'all_point', 'upper_point', 'down_point', 'createdAt', 'updatedAt'],
          include: userInclude,
          limit, offset, order: [[sequelize.fn('LOWER', sequelize.col('Wallet.username')), 'ASC'], ['wallet_id', 'ASC']], raw: true,
        });

        totalWallets = await Wallet.count({
          where: baseWhere,
          include: userInclude
        });

        wallets = wallets.map(w => ({
          ...w,
          role: 'USER',
          level: null,
          percentage: w['user.percentage'] != null ? parseFloat(w['user.percentage']) : 0,
          inr_balance: parseFloat(w.inr_balance || 0),
          credit: parseFloat(w.credit || 0),
          all_point: parseFloat(w.all_point || 0),
          upper_point: parseFloat(w.upper_point || 0),
          down_point: parseFloat(w.down_point || 0),
          settlement_points: Math.round((parseFloat(w.all_point || 0) - parseFloat(w.credit || 0)) * 100) / 100,
          available_points: parseFloat(w.cash || 0),
          status: w['user.status'] || 'Active',
          active: w['user.status'] === 'Active',
          bet_locked: w['user.bet_locked'] === 1 || w['user.bet_locked'] === true,
          phone_number: w['user.phone_number'] || null,
          country: w['user.country'] || null,
          fullname: w['user.fullname'] || null,
          city: w['user.city'] || null,
          // Same field as the default branch, so the User Authentication
          // report reads the same key whichever branch served the page.
          securityAuthType: w['user.securityAuthType'] || null,
        }));

      }

      const totalPages = Math.ceil(totalWallets / limit);
      if (wallets.length === 0) {
        return res.status(200).json({
          success: true,
          data: { wallets: [], pagination: { current_page: page, total_pages: totalPages, total_wallets: totalWallets, per_page: limit } },
        });
      }

      // Har staff row ke liye check: iske neeche koi hai? (frontend isi se drill-down button dikhata hai)
      const staffIdsInResult = wallets.filter(w => w.staff_id && STAFF_TYPES.includes(w.user_type)).map(w => w.staff_id);
      const childrenCounts = {};
      if (staffIdsInResult.length > 0) {
        const staffChildren = await Staff.findAll({
          attributes: ['parent_id', [sequelize.fn('COUNT', sequelize.col('staff_id')), 'count']],
          where: { parent_id: { [Op.in]: staffIdsInResult } },
          group: ['parent_id'],
          raw: true
        });
        const userChildren = await User.findAll({
          attributes: ['parent_staff_id', [sequelize.fn('COUNT', sequelize.col('user_id')), 'count']],
          where: { parent_staff_id: { [Op.in]: staffIdsInResult } },
          group: ['parent_staff_id'],
          raw: true
        });
        staffChildren.forEach(c => { childrenCounts[c.parent_id] = (childrenCounts[c.parent_id] || 0) + parseInt(c.count); });
        userChildren.forEach(c => { childrenCounts[c.parent_staff_id] = (childrenCounts[c.parent_staff_id] || 0) + parseInt(c.count); });
      }

      // Exposure — total_exposures table se:
      //   USER row  → uska apna exposure
      //   STAFF row → uske poore downline users ka total (getTotalExposureByHierarchy)
      const bettorIds = wallets.filter(w => w.user_type === 'USER' && w.user_id).map(w => w.user_id);
      const exposures = bettorIds.length > 0 ? await TotalExposure.findAll({
        where: { user_id: { [Op.in]: bettorIds } },
        attributes: ['user_id', 'total_exposure'],
        raw: true
      }) : [];

      const exposureMap = exposures.reduce((acc, curr) => {
        acc[curr.user_id] = parseFloat(curr.total_exposure);
        return acc;
      }, {});

      const finalWallets = await Promise.all(wallets.map(async (w) => {
        let exposure = 0;
        if (w.user_type === 'USER') {
          exposure = exposureMap[w.user_id] || 0;
        } else if (w.staff_id) {
          exposure = await getTotalExposureByHierarchy(w.role || w.user_type, w.username);
        }
        return {
          ...w,
          exposure,
          downline: !!(w.staff_id && childrenCounts[w.staff_id]),   // true = iske neeche aur log hain
        };
      }));

      res.status(200).json({
        success: true,
        data: {
          wallets: finalWallets,
          pagination: {
            current_page: page,
            total_pages: totalPages,
            total_wallets: totalWallets,
            per_page: limit,
          },
        },
      });

    } catch (error) {
      console.error('Error fetching user details:', error);
      res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
  },









  /**
   * ONE account's own details — the fields the More → Additional Information
   * panel shows, read fresh from users/staff rather than from whatever the
   * list row happened to carry.
   *
   * GET /admin/users/account-details/:accountType/:id   (accountType: USER|STAFF)
   *
   * Scope: an OWNER may read anything under its own owner_id; a staff account
   * may read ITSELF or anything in its subtree. Anything else is 403 — the id
   * comes from the client, so it is never trusted on its own.
   */
  getAccountDetails: async (req, res) => {
    try {
      const accountType = String(req.params.accountType || '').toUpperCase();
      const id = parseInt(req.params.id, 10);
      if (!['USER', 'STAFF'].includes(accountType) || !Number.isInteger(id)) {
        return res.status(400).json({ success: false, error: 'accountType (USER|STAFF) and a numeric id are required' });
      }

      const loggedInRole = req.user?.role?.toUpperCase();
      const loggedInId = req.user?.account?.id;
      if (!loggedInId) return res.status(401).json({ success: false, error: 'Unauthorized' });

      const isOwner = loggedInRole === 'OWNER';
      // Every staff the caller is allowed to see (itself + its whole subtree).
      const allowedStaffIds = isOwner ? null : await getAllDescendantStaffIds(loggedInId);

      let account = null;

      if (accountType === 'USER') {
        const user = await User.findByPk(id, {
          attributes: [
            'user_id', 'username', 'fullname', 'email', 'phone_number', 'country', 'city',
            'status', 'bet_locked', 'percentage', 'securityAuthType', 'parent_staff_id',
            'parent_owner_id', 'passwordChangeAllowed', 'createdAt', 'updatedAt',
          ],
          raw: true,
        });
        if (!user) return res.status(404).json({ success: false, error: 'Account not found' });

        const inScope = isOwner
          ? (!user.parent_owner_id || user.parent_owner_id === loggedInId)
          : allowedStaffIds.includes(user.parent_staff_id);
        if (!inScope) return res.status(403).json({ success: false, error: 'Not allowed for this account' });

        account = {
          account_type: 'USER',
          user_id: user.user_id,
          staff_id: null,
          username: user.username,
          fullname: user.fullname || null,
          email: user.email || null,
          phone_number: user.phone_number || null,
          country: user.country || null,
          city: user.city || null,
          role: 'USER',
          level: null,
          percentage: user.percentage != null ? parseFloat(user.percentage) : 0,
          status: user.status || 'Active',
          active: user.status === 'Active',
          bet_locked: user.bet_locked === true || user.bet_locked === 1,
          securityAuthType: user.securityAuthType || null,
          passwordChangeAllowed: user.passwordChangeAllowed !== false,
          createdAt: user.createdAt,
          updatedAt: user.updatedAt,
        };
      } else {
        const staff = await Staff.findByPk(id, {
          attributes: [
            // phone_number exists on staff since 2026-09-21
            // (ensureStaffPhoneNumberColumn in config/dbInit.js). Accounts
            // created before that have it NULL — the form's value had nowhere
            // to go — so those read blank until someone edits them.
            'staff_id', 'username', 'fullname', 'email', 'city', 'phone_number',
            'role', 'level', 'percentage', 'active', 'bet_locked', 'securityAuthType',
            'parent_id', 'parent_owner_id', 'passwordChangeAllowed', 'createdAt', 'updatedAt',
          ],
          raw: true,
        });
        if (!staff) return res.status(404).json({ success: false, error: 'Account not found' });

        const inScope = isOwner
          ? (!staff.parent_owner_id || staff.parent_owner_id === loggedInId)
          : allowedStaffIds.includes(staff.staff_id);
        if (!inScope) return res.status(403).json({ success: false, error: 'Not allowed for this account' });

        account = {
          account_type: 'STAFF',
          user_id: null,
          staff_id: staff.staff_id,
          username: staff.username,
          fullname: staff.fullname || null,
          email: staff.email || null,
          phone_number: staff.phone_number || null,
          country: null,
          city: staff.city || null,
          role: staff.role || null,
          level: staff.level || null,
          percentage: staff.percentage != null ? parseFloat(staff.percentage) : 0,
          status: staff.active ? 'Active' : 'Inactive',
          active: !!staff.active,
          bet_locked: staff.bet_locked === true || staff.bet_locked === 1,
          securityAuthType: staff.securityAuthType || null,
          passwordChangeAllowed: staff.passwordChangeAllowed !== false,
          createdAt: staff.createdAt,
          updatedAt: staff.updatedAt,
        };
      }

      // The wallet numbers the panel prints next to the profile.
      const wallet = await Wallet.findOne({
        where: accountType === 'USER' ? { user_id: id } : { staff_id: id },
        attributes: ['wallet_id', 'inr_balance', 'cash', 'credit', 'all_point', 'upper_point', 'down_point'],
        raw: true,
      });
      if (wallet) {
        account.wallet_id = wallet.wallet_id;
        account.inr_balance = parseFloat(wallet.inr_balance || 0);
        account.credit = parseFloat(wallet.credit || 0);
        account.all_point = parseFloat(wallet.all_point || 0);
        account.upper_point = parseFloat(wallet.upper_point || 0);
        account.down_point = parseFloat(wallet.down_point || 0);
        account.available_points = parseFloat(wallet.cash || 0);
        account.settlement_points = Math.round((parseFloat(wallet.all_point || 0) - parseFloat(wallet.credit || 0)) * 100) / 100;
      }

      return res.status(200).json({ success: true, data: account });
    } catch (error) {
      console.error('getAccountDetails error:', error);
      return res.status(500).json({ success: false, error: 'Server error' });
    }
  },

  searchUsersByUsername: async (req, res) => {
    try {
      const { username, page = 1, limit = 25 } = req.query;

      // Validation: username is required and must be at least 1 char
      if (!username || username.trim().length === 0) {
        return res.status(400).json({
          success: false,
          error: 'Username query parameter is required for search',
        });
      }

      const searchTerm = username.trim();
      const pageNum = parseInt(page);
      const limitNum = parseInt(limit);
      const offset = (pageNum - 1) * limitNum;

      // 1. Determine Scope (Hierarchy Check)
      const loggedInRole = req.user?.role.toUpperCase();
      const loggedInId = req.user.account.id;

      let allowedStaffIds = null; // null means ALL (Owner)
      let allowedUserIds = [];

      if (loggedInRole !== 'OWNER') {
        // Search has to reach every level below the logged-in account, not just
        // direct children — a master's players usually sit under its agents.
        const descendants = [];
        const seen = new Set([String(loggedInId)]);
        let queue = [loggedInId];
        while (queue.length) {
          const children = await Staff.findAll({
            where: { parent_id: { [Op.in]: queue } },
            attributes: ['staff_id'],
            raw: true
          });
          const childIds = children
            .map(c => c.staff_id)
            .filter(id => !seen.has(String(id)) && seen.add(String(id)));
          descendants.push(...childIds);
          queue = childIds;
        }
        allowedStaffIds = descendants;

        // Players hang off any staff in the subtree, plus this account's own.
        const usersUnderStaff = await User.findAll({
          where: { parent_staff_id: { [Op.in]: [loggedInId, ...descendants] } },
          attributes: ['user_id'],
          raw: true
        });
        allowedUserIds = usersUnderStaff.map(u => u.user_id);
      } else if (allowedStaffIds) {
        // Owner case with specific staff restriction
        const usersUnderStaff = await User.findAll({
          where: { parent_staff_id: { [Op.in]: allowedStaffIds } },
          attributes: ['user_id'],
          raw: true
        });
        allowedUserIds = usersUnderStaff.map(u => u.user_id);
      }

      // Build Where Clause
      let whereClause = {
        username: {
          [Op.iLike]: `%${searchTerm}%`,
        },
      };

      if (loggedInRole !== 'OWNER') {
        // Filter search to: (direct staff OR direct users) AND NOT self
        whereClause[Op.and] = [
          {
            [Op.or]: [
              { staff_id: { [Op.in]: allowedStaffIds || [] } },
              { user_id: { [Op.in]: allowedUserIds || [] } }
            ]
          },
          {
            [Op.or]: [
              { staff_id: { [Op.ne]: loggedInId } },
              { staff_id: null }
            ]
          }
        ];
      } else if (allowedStaffIds) {
        // Owner case with restriction
        whereClause[Op.and] = [
          {
            [Op.or]: [
              { staff_id: { [Op.in]: allowedStaffIds } },
              ...(allowedUserIds.length > 0 ? [{ user_id: { [Op.in]: allowedUserIds } }] : [])
            ]
          },
          {
            [Op.or]: [
              { staff_id: { [Op.ne]: loggedInId } },
              { staff_id: null }
            ]
          }
        ];
      } else {
        // Owner case, show everything but self
        whereClause[Op.and] = [
          {
            [Op.or]: [
              { staff_id: { [Op.ne]: loggedInId } },
              { staff_id: null }
            ]
          }
        ];
      }

      // Step 1: Search wallets with partial username match (case-insensitive)
      const wallets = await Wallet.findAll({
        where: whereClause,
        attributes: [
          'wallet_id',
          'user_id',
          'staff_id',
          'username',
          'user_type',
          'inr_balance',
          'cash',
          'credit',
          'cash_received',
          'totalCommission',
          'profit_loss',
          'verdict',
          'createdAt',
          'updatedAt'
        ],
        include: [{
          model: Staff,
          as: 'staff',
          attributes: ['active', 'bet_locked', 'parent_id'],
          required: false,
        }, {
          model: User,
          as: 'user',
          attributes: ['status', 'bet_locked', 'parent_staff_id'],
          required: false,
        }],
        limit: limitNum,
        offset,
        order: [['username', 'ASC']],
        raw: true,
      });

      if (wallets.length === 0) {
        return res.status(200).json({
          success: true,
          data: {
            results: [],
            pagination: {
              current_page: pageNum,
              total_pages: 0,
              total_results: 0,
              per_page: limitNum,
            },
          },
        });
      }

      // Step 2: Extract user_ids for exposure lookup
      const userIds = wallets
        .map(w => w.user_id)
        .filter(id => id != null);

      // Step 3: Fetch exposures in bulk
      let exposureMap = {};
      if (userIds.length > 0) {
        // same total_exposures snapshot the user list and the player header
        // read (user_net_exposure has no worker on tenexch, so it read 0)
        const exposures = await TotalExposure.findAll({
          where: { user_id: { [Op.in]: userIds } },
          attributes: ['user_id', 'total_exposure'],
          raw: true,
        });
        exposureMap = Object.fromEntries(
          exposures.map(e => [e.user_id, parseFloat(e.total_exposure || 0)])
        );
      }

      // User Lock + Game Lock in the Search User modal follow the WHOLE upline
      // chain (user, 2026-10-11 — replaces the 09-19 "direct parent only"):
      // direct parent first, climbing parent_id, and stopping at the
      // logged-in account so nobody sees masters above themselves.
      const parentIdOf = (w) => w['user.parent_staff_id'] ?? w['staff.parent_id'] ?? null;
      // owners live in their own table — an owner id can equal a staff_id
      const stopAt = loggedInRole === 'OWNER' ? null : String(loggedInId);
      const staffById = new Map();
      let toLoad = [...new Set(wallets.map(parentIdOf).filter(Boolean).map(String))];
      for (let depth = 0; toLoad.length && depth < 10; depth++) {
        const rows = await Staff.findAll({
          where: { staff_id: { [Op.in]: toLoad } },
          attributes: ['staff_id', 'username', 'active', 'bet_locked', 'parent_id'],
          raw: true,
        });
        rows.forEach(r => staffById.set(String(r.staff_id), r));
        toLoad = [...new Set(rows
          .filter(r => String(r.staff_id) !== stopAt && r.parent_id != null)
          .map(r => String(r.parent_id))
          .filter(id => !staffById.has(id)))];
      }
      const uplineOf = (w) => {
        const chain = [];
        let id = parentIdOf(w);
        while (id != null && staffById.has(String(id)) && chain.length < 10) {
          const st = staffById.get(String(id));
          chain.push(st);
          if (String(st.staff_id) === stopAt) break;
          id = st.parent_id;
        }
        return chain;
      };
      const flagOf = (v) => v === true || v === 1;

      // Game Lock = sport-level General Locks (lock_type SPORT) on the account
      // itself (master = its direct parent, who set it) and on every upline
      // master in the chain above (master = that master).
      const chainStaffIds = [...staffById.keys()];
      const lockUserIds = wallets.filter(w => w.user_id != null).map(w => w.user_id);
      const lockStaffIds = [...new Set([...wallets.filter(w => w.staff_id != null).map(w => String(w.staff_id)), ...chainStaffIds])];
      const [userSportLocks, staffSportLocks] = await Promise.all([
        lockUserIds.length
          ? UserSportsLock.findAll({ where: { user_id: { [Op.in]: lockUserIds }, lock_type: 'SPORT', is_locked: true }, order: [['id', 'ASC']], raw: true })
          : [],
        lockStaffIds.length
          ? StaffSportsLock.findAll({ where: { staff_id: { [Op.in]: lockStaffIds }, lock_type: 'SPORT', is_locked: true }, order: [['id', 'ASC']], raw: true })
          : [],
      ]);
      const groupBy = (rows, key) => rows.reduce((m, r) => { (m[r[key]] ||= []).push(r); return m; }, {});
      const userLocksById = groupBy(userSportLocks, 'user_id');
      const staffLocksById = groupBy(staffSportLocks, 'staff_id');
      const lockRow = (master, r) => ({
        master_name: master || '',
        bet_lock: true,
        event_name: getSportNameById(r.sport_id) || String(r.sport_id),
      });
      const gameLocksOf = (w, isStaff, chain) => {
        const own = isStaff ? (staffLocksById[w.staff_id] || []) : (userLocksById[w.user_id] || []);
        return [
          ...own.map(r => lockRow(chain[0]?.username, r)),
          ...chain.flatMap(st => (staffLocksById[st.staff_id] || []).map(r => lockRow(st.username, r))),
        ];
      };

      // Step 4: Merge exposure + status into results
      const STAFF_TYPES = ['SUPERADMIN', 'ADMIN', 'SUPERMASTER', 'MASTER', 'AGENT', 'OWNER', 'COMPANY'];
      const results = wallets.map(w => {
        const isStaff = STAFF_TYPES.includes(w.user_type);
        const chain = uplineOf(w);
        const uplines = chain.map(st => ({
          username: st.username,
          active: flagOf(st.active),
          bet_locked: flagOf(st.bet_locked),
        }));
        return {
          ...w,
          parent: uplines[0] || null,
          uplines,
          game_locks: gameLocksOf(w, isStaff, chain),
          total_exposure: w.user_id ? (exposureMap[w.user_id] ?? 0) : 0,
          status: isStaff ? (w['staff.active'] ? 'Active' : 'InActive') : (w['user.status'] || 'Active'),
          active: isStaff ? (w['staff.active'] === true || w['staff.active'] === 1) : (w['user.status'] === 'Active'),
          bet_locked: isStaff ? (w['staff.bet_locked'] === true || w['staff.bet_locked'] === 1) : (w['user.bet_locked'] === true || w['user.bet_locked'] === 1),
        };
      });

      // Step 5: Get total count for pagination
      const totalResults = await Wallet.count({
        where: whereClause,
      });

      const totalPages = Math.ceil(totalResults / limitNum);

      // Final Response
      return res.status(200).json({
        success: true,
        data: {
          results,
          pagination: {
            current_page: pageNum,
            total_pages: totalPages,
            total_results: totalResults,
            per_page: limitNum,
            search_term: searchTerm,
          },
        },
      });
    } catch (error) {
      console.error('Error in searchUsersByUsername:', error);
      return res.status(500).json({ success: false, error: error.message });
    }
  },






  // staff
  getLoggedInStaffDetails: async (req, res) => {
    try {
      const userId = req.user.account.id; // from your auth middleware (staff_id)

      if (!userId) {
        return res.status(401).json({
          success: false,
          error: 'Unauthorized: User not authenticated',
        });
      }

      // Step 1: Fetch wallet + join with Staff table to get percentage, level, role
      const wallet = await Wallet.findOne({
        where: { staff_id: userId },
        attributes: [
          'wallet_id',
          'staff_id',
          'username',
          'user_type',
          'inr_balance',
          'cash',
          'cash_received',
          'totalCommission',
          'profit_loss',
          'verdict',
          'createdAt',
          'updatedAt'
        ],
        include: [
          {
            model: Staff,
            as: 'staff',
            attributes: ['percentage', 'level', 'role'], // ← This brings the percentage
            required: false,
          },
        ],
        raw: false, // Keep as object so include works
      });

      if (!wallet) {
        return res.status(404).json({
          success: false,
          error: 'Wallet not found for this staff member',
        });
      }

      const plainWallet = wallet.get({ plain: true });

      // Step 2: Exposure (user_net_exposure synced every 1s by bgworker)
      let totalExposure = 0;
      if (plainWallet.user_type === 'USER' && plainWallet.user_id) {
        const exposureRecord = await UserNetExposure.findOne({
          where: { user_id: plainWallet.user_id },
          attributes: ['net_exposure'],
        });
        totalExposure = exposureRecord ? parseFloat(exposureRecord.net_exposure) : 0;
      }

      // Step 3: Calculate DownOb & DownPL (sum of inr_balance / profit_loss for direct children)
      // let DownOb = 0;
      // let DownCredit = 0;
      // let DownPL = 0;
      // // Direct children staff
      // const directStaff = await Staff.findAll({
      //   where: { parent_id: userId },
      //   attributes: ['staff_id'],
      //   raw: true
      // });
      // const childStaffIds = directStaff.map(s => s.staff_id);

      // // Direct children users
      // const directUsers = await User.findAll({
      //   where: { parent_staff_id: userId },
      //   attributes: ['user_id'],
      //   raw: true
      // });
      // const childUserIds = directUsers.map(u => u.user_id);

      // if (childStaffIds.length > 0 || childUserIds.length > 0) {
      //   const orConditions = [];
      //   if (childStaffIds.length > 0) orConditions.push({ staff_id: { [Op.in]: childStaffIds } });
      //   if (childUserIds.length > 0) orConditions.push({ user_id: { [Op.in]: childUserIds } });

      //   const childWallets = await Wallet.findAll({
      //     where: { [Op.or]: orConditions },
      //     attributes: ['inr_balance', 'cash_received', 'profit_loss'],
      //     raw: true
      //   });
      //   DownOb = childWallets.reduce((sum, w) => sum + (parseFloat(w.inr_balance) || 0), 0);
      //   DownCredit = childWallets.reduce((sum, w) => sum + (parseFloat(w.cash_received) || 0), 0);
      //   DownPL = childWallets.reduce((sum, w) => sum + (parseFloat(w.profit_loss) || 0), 0);
      // }
      //=================================================  replaced step 3 v2  ============
      // Step 3: Calculate DownOb & DownCredit
      //
      // Rule (peer-to-peer borrow model):
      //   DownOb     = ALL descendants' inr_balance  (total money alive in subtree)
      //   DownCredit = DIRECT children's cash_received ONLY
      //                (what this node personally gave out; sub-distributions are
      //                 already inside the direct child's own balance — counting
      //                 them again would double-count and inflate DownCredit)
      let DownOb = 0;
      let DownCredit = 0;

      // --- DownOb: sum inr_balance of ALL descendant staff + users ---
      const allDescendantStaffIds = await getAllDescendantStaffIds(userId);
      const childStaffIds = allDescendantStaffIds.filter(id => id !== userId);

      const allUsers = await User.findAll({
        where: { parent_staff_id: { [Op.in]: childStaffIds.length > 0 ? childStaffIds : [userId] } },
        attributes: ['user_id'],
        raw: true
      });
      const directUsersForOb = await User.findAll({
        where: { parent_staff_id: userId },
        attributes: ['user_id'],
        raw: true
      });
      const allUserIds = [...new Set([...allUsers.map(u => u.user_id), ...directUsersForOb.map(u => u.user_id)])];

      const obConditions = [];
      if (childStaffIds.length > 0) obConditions.push({ staff_id: { [Op.in]: childStaffIds } });
      if (allUserIds.length > 0) obConditions.push({ user_id: { [Op.in]: allUserIds } });

      if (obConditions.length > 0) {
        const allDescWallets = await Wallet.findAll({
          where: { [Op.or]: obConditions },
          attributes: ['inr_balance'],
          raw: true
        });
        DownOb = allDescWallets.reduce((sum, w) => sum + (parseFloat(w.inr_balance) || 0), 0);
      }

      // --- DownCredit: sum cash_received of DIRECT children only ---
      const directChildStaff = await Staff.findAll({
        where: { parent_id: userId },
        attributes: ['staff_id'],
        raw: true
      });
      const directChildStaffIds = directChildStaff.map(s => s.staff_id);

      const directChildUsers = await User.findAll({
        where: { parent_staff_id: userId },
        attributes: ['user_id'],
        raw: true
      });
      const directChildUserIds = directChildUsers.map(u => u.user_id);

      const creditConditions = [];
      if (directChildStaffIds.length > 0) creditConditions.push({ staff_id: { [Op.in]: directChildStaffIds } });
      if (directChildUserIds.length > 0) creditConditions.push({ user_id: { [Op.in]: directChildUserIds } });

      if (creditConditions.length > 0) {
        const directWallets = await Wallet.findAll({
          where: { [Op.or]: creditConditions },
          attributes: ['cash_received'],
          raw: true
        });
        DownCredit = directWallets.reduce((sum, w) => sum + (parseFloat(w.cash_received) || 0), 0);
      }

      const DownPL = DownOb - DownCredit;

      //===============================================================================

      // Step 4: Final merged response with percentage
      const cash = parseFloat(plainWallet.cash || 0);
      const cashReceived = parseFloat(plainWallet.cash_received || 0);

      const userDetails = {
        wallet_id: plainWallet.wallet_id,
        staff_id: plainWallet.staff_id,
        username: plainWallet.username,
        user_type: plainWallet.user_type,
        role: plainWallet.staff?.role || plainWallet.user_type,
        level: plainWallet.staff?.level || null,
        percentage: plainWallet.staff?.percentage ? parseFloat(plainWallet.staff.percentage) : null,
        inr_balance: parseFloat(plainWallet.inr_balance || 0),
        cash: cash,
        cash_received: cashReceived,
        totalCommission: parseFloat(plainWallet.totalCommission || 0),
        profit_loss: parseFloat(plainWallet.profit_loss || 0),
        verdict: plainWallet.verdict,
        total_exposure: totalExposure,
        DownOb,
        DownPL,
        DownCredit,
        createdAt: plainWallet.createdAt,
        updatedAt: plainWallet.updatedAt,

        // Exact explicit keys for frontend Users2 UI
        UpperLevelCreditReference: cashReceived,
        TotalMasterBalance: cash + DownOb,
        UpperLevel: cashReceived - (cash + DownOb),
        DownLevelOccupyBalance: DownOb,
        DownLevelCreditReference: DownCredit,
        DownLevelProfitLoss: DownOb - DownCredit,
        AvailableBalance: cash,
        AvailableBalanceWithProfitLoss: cash,
        MyProfitLoss: 0
      };

      return res.status(200).json({
        success: true,
        data: {
          user: userDetails,
        },
      });

    } catch (error) {
      console.error('Error in getLoggedInStaffDetails:', error);
      return res.status(500).json({ success: false, error: error.message });
    }
  },

  // user
  getLoggedInUserDetails: async (req, res) => {

    console.log("logged in user profile", req.body,)
    try {
      const userId = req.user.account.id; // Ensure auth middleware sets req.user
      console.log("logged in user id", userId)

      if (!userId) {
        return res.status(401).json({
          success: false,
          error: 'Unauthorized: User not authenticated',
        });
      }

      // Step 1: Fetch wallet for the logged-in user
      const wallet = await Wallet.findOne({
        where: { user_id: userId },
        attributes: [
          'wallet_id',
          'user_id',
          'username',
          'user_type',
          'inr_balance',
          'cash',
          'cash_received',
          'totalCommission',
          'profit_loss',
          'verdict',
          'createdAt',
          'updatedAt'
        ],
        raw: true,
      });

      if (!wallet) {
        // Auto-create missing wallet for this user
        try {
          const userRecord2 = await User.findByPk(userId, { attributes: ['username'], raw: true });
          await WalletService.createWallet(userId, 'User', null, userRecord2?.username || `user_${userId}`);
          wallet = await Wallet.findOne({
            where: { user_id: userId },
            attributes: ['wallet_id', 'user_id', 'username', 'user_type', 'inr_balance', 'cash', 'profit_loss', 'verdict', 'createdAt', 'updatedAt','credit'],
            raw: true,
          });
        } catch (walletErr) {
          console.error('Failed to auto-create wallet:', walletErr.message);
          return res.status(404).json({ success: false, error: 'Wallet not found and could not be created' });
        }
      }

      // Step 2: Fetch total exposure from user_net_exposure (synced every 1s by bgworker - most reliable)
      const exposureRecord = await UserNetExposure.findOne({
        where: { user_id: userId },
        attributes: ['net_exposure'],
        raw: true,
      });

      const totalExposure = exposureRecord
        ? parseFloat(exposureRecord.net_exposure)
        : 0;

      // Step 2.5: Fetch User details for 2FA status
      const userRecord = await User.findOne({
        where: { user_id: userId },
        attributes: ['telegram2FAEnabled', 'telegramChatId', 'securityAuthType', 'is_demo', 'demo_expires_at'],
        raw: true
      });

      // Step 3: Merge wallet + exposure + user details
      const userDetails = {
        ...wallet,
        total_exposure: totalExposure,
        // Demo account flag + session end — the frontend keeps its demo-only UI
        // (reduced menu, no password change, auto-logout timer) off these.
        is_demo: !!userRecord?.is_demo,
        demo_expires_at: userRecord?.demo_expires_at || null,
        telegram2FAEnabled: userRecord?.telegram2FAEnabled || false,
        telegramChatId: userRecord?.telegramChatId || null,
        // 'android' | 'telegram' | 'google' | null — drives the Secure Auth page
        securityAuthType: userRecord?.securityAuthType || null,
        rules_accepted: await getRulesAccepted(User, 'user_id', userId)
      };

      // ✅ Final Response
      return res.status(200).json({
        success: true,
        data: {
          user: userDetails,
        },
      });
    } catch (error) {
      console.error('Error in getLoggedInUserDetails:', error);
      return res.status(500).json({ success: false, error: error.message });
    }
  },

  getLoggedInOwnerDetails: async (req, res) => {
    try {
      const ownerId = req.user.account.id; // Your auth middleware should set req.user.id = owner_id

      if (!ownerId) {
        return res.status(401).json({
          success: false,
          error: 'Unauthorized: Owner not authenticated',
        });
      }

      // Step 1: Fetch Owner details directly from Owner table
      const plainOwner = await Owner.findOne({
        where: { owner_id: ownerId },
        attributes: [
          'owner_id',
          'username',
          'website_name',
          'domain_name',
          'website_ui',
          'country',
          'logo',
          'favicon',
          'subscription_plan',
          'platform_name',
          'site_email_address',
          'account_status',
          'createdAt',
          'updatedAt'
        ],
        // No need for include — everything is in Owner table
        raw: true,
      });

      if (!plainOwner) {
        return res.status(404).json({
          success: false,
          error: 'Owner account not found',
        });
      }

      // Steps 2-4 are independent of each other, so they run concurrently.
      // Each returns a single aggregate row — no row sets are pulled into JS.
      const [ownerWallet, downlineTotals, totalExposure] = await Promise.all([

        // Step 2: owner's own wallet
        Wallet.findOne({
          where: { user_type: 'OWNER' },
          attributes: ['inr_balance', 'cash', 'cash_received', 'totalCommission', 'profit_loss', 'verdict'],
          raw: true,
        }),

        // Step 3: direct-staff totals (parent_owner_id = ownerId AND parent_id IS NULL).
        // Summed in SQL instead of fetching every wallet row and reduce()-ing in JS.
        Wallet.findOne({
          include: [{
            model: Staff,
            as: 'staff',
            where: { parent_owner_id: ownerId, parent_id: null },
            required: true,
            attributes: []
          }],
          attributes: [
            [sequelize.fn('COALESCE', sequelize.fn('SUM', sequelize.col('Wallet.inr_balance')), 0), 'downOb'],
            [sequelize.fn('COALESCE', sequelize.fn('SUM', sequelize.col('Wallet.cash_received')), 0), 'downCredit'],
            // Derived in SQL, not read from the stored column. This is an aggregate, so the
            // model's afterFind hook cannot correct it — SUM() runs in the database over the
            // raw column, which increment()/bulk-update paths can leave stale.
            // See model/admin/Wallet.js: profit_loss = inr_balance − cash_received.
            [sequelize.fn('COALESCE', sequelize.fn('SUM',
              sequelize.literal('"Wallet"."inr_balance" - "Wallet"."cash_received"')), 0), 'downPL'],
          ],
          subQuery: false,
          raw: true
        }),

        // Step 4: downline exposure across the owner's whole hierarchy = sum of
        // every end-user's own exposure (total_exposures snapshot). Same helper
        // the Users list uses for a staff row, so the dashboard card and the
        // list always agree.
        getTotalExposureByHierarchy('OWNER', plainOwner.username),
      ]);

      const cash = ownerWallet ? parseFloat(ownerWallet.cash || 0) : 0;
      const cashReceived = ownerWallet ? parseFloat(ownerWallet.cash_received || 0) : 0;

      const DownOb = parseFloat(downlineTotals?.downOb) || 0;
      const DownCredit = parseFloat(downlineTotals?.downCredit) || 0;
      const DownPL = parseFloat(downlineTotals?.downPL) || 0;

      // Step 5: Final response — clean & consistent with staff endpoint
      const ownerDetails = {
        owner_id: plainOwner.owner_id,
        username: plainOwner.username,
        website_name: plainOwner.website_name,
        domain_name: plainOwner.domain_name,
        website_ui: plainOwner.website_ui,
        country: plainOwner.country,
        logo: plainOwner.logo,
        favicon: plainOwner.favicon,
        subscription_plan: plainOwner.subscription_plan,
        platform_name: plainOwner.platform_name,
        site_email_address: plainOwner.site_email_address,
        account_status: plainOwner.account_status,
        role: 'OWNER',
        level: null,
        percentage: null, // Owners don't have downline percentage
        inr_balance: ownerWallet ? parseFloat(ownerWallet.inr_balance || 0) : 0,
        cash: cash,
        cash_received: cashReceived,
        totalCommission: ownerWallet ? parseFloat(ownerWallet.totalCommission || 0) : 0,
        profit_loss: ownerWallet ? parseFloat(ownerWallet.profit_loss || 0) : 0,
        verdict: ownerWallet ? (ownerWallet.verdict || 'profit') : 'profit',
        // Downline exposure (negative = liability); 0 when nothing is at risk.
        total_exposure: totalExposure,
        exposure: totalExposure,
        DownOb,
        DownCredit,
        DownPL,
        createdAt: plainOwner.createdAt,
        updatedAt: plainOwner.updatedAt,

        // Exact explicit keys for frontend Users2 UI
        UpperLevelCreditReference: cashReceived,
        TotalMasterBalance: cash + DownOb,
        UpperLevel: cashReceived - (cash + DownOb),
        DownLevelOccupyBalance: DownOb,
        DownLevelCreditReference: DownCredit,
        DownLevelProfitLoss: DownOb - DownCredit,
        AvailableBalance: cash,
        AvailableBalanceWithProfitLoss: cash,
        MyProfitLoss: 0
      };

      return res.status(200).json({
        success: true,
        data: {
          user: ownerDetails,
        },
      });

    } catch (error) {
      console.error('Error in getLoggedInOwnerDetails:', error);
      return res.status(500).json({
        success: false,
        error: 'Internal server error',
      });
    }
  },

  getUserExposures: async (req, res) => {
    try {
      const userId = req.params.userId || req.user.account.id;

      const exposures = await UserExposure.findAll({
        where: { user_id: userId },
        raw: true
      });

      const formattedExposures = {};

      exposures.forEach(exp => {
        if (!formattedExposures[exp.match_id]) {
          formattedExposures[exp.match_id] = {
            match_title: exp.match_title,
            teams: {},
            markets: {}
          };
        }
        // Flat teams (backward compat)
        formattedExposures[exp.match_id].teams[exp.team_name] = parseFloat(exp.exposure_amount);
        // Grouped by game_type
        const marketName = exp.game_type || 'MATCH_ODDS';
        if (!formattedExposures[exp.match_id].markets[marketName]) {
          formattedExposures[exp.match_id].markets[marketName] = {};
        }
        formattedExposures[exp.match_id].markets[marketName][exp.team_name] = parseFloat(exp.exposure_amount);
      });

      return res.json({
        success: true,
        exposures: formattedExposures
      });

    } catch (error) {
      console.error('Error in getUserExposures:', error);
      return res.status(500).json({ success: false, error: error.message });
    }
  },
  getNetExposures: async (req, res) => {
    try {
      const userId = req.params.userId || req.user.account?.id || req.user.user_id;

      // Read from user_net_exposure — synced every 1s by the background worker (most reliable)
      const record = await UserNetExposure.findOne({
        where: { user_id: userId },
        raw: true
      });

      return res.json({
        success: true,
        exposures: record ? parseFloat(record.net_exposure) : 0
      });

    } catch (error) {
      console.error('Error in getNetExposures:', error);
      return res.status(500).json({
        success: false,
        error: error.message
      });
    }
  },


  getUserExposuresByHierarchyAndMatch: async (req, res) => {
    try {
      console.log("📥 getUserExposuresByHierarchyAndMatch req.body:", req.body);

      const { role, username, matchId } = req.body;

      // 🔎 Validation
      if (!role || !username || !matchId) {
        return res.status(400).json({
          success: false,
          message: 'role, username, and matchId are required',
        });
      }

      // 1️⃣ Resolve all user_ids under hierarchy
      const userIds = await getUserIdsByHierarchy(role, username);
      console.log(`🔍 Resolved ${userIds.length} user IDs under hierarchy for role=${role}, username=${username}`);

      if (!userIds || userIds.length === 0) {
        return res.status(200).json({
          success: true,
          data: [],
          message: 'No users found under given hierarchy',
        });
      }

      // 2️⃣ Fetch exposures for those users & match
      const exposures = await UserExposure.findAll({
        where: {
          user_id: { [Op.in]: userIds },
          match_id: matchId,
        },
        attributes: [
          'id',
          'user_id',
          'match_id',
          'team_name',
          'exposure_amount',
          'match_title',
          'game_type',
          'created_at',
          'updated_at',
        ],
        order: [['user_id', 'ASC']],
        raw: true,
      });

      // ✅ Success response
      return res.status(200).json({
        success: true,
        data: exposures,
        meta: {
          role,
          username,
          match_id: matchId,
          total_users: userIds.length,
          total_records: exposures.length,
        },
      });

    } catch (error) {
      console.error('❌ Error in getUserExposuresByHierarchyAndMatch:', error);

      return res.status(500).json({
        success: false,
        message: 'Failed to fetch user exposures',
        error: error.message,
      });
    }
  },

   // Thin wrapper — the payload itself is built by buildOwnerProfile() above,
   // which the 2-second socket push shares so the two can never drift.
   getLoggedInOwnerDetailsV2: async (req, res) => {
    try {
      const ownerId = req.user.account.id; // auth middleware sets req.user.account = { type: 'OWNER', id }

      if (!ownerId) {
        return res.status(401).json({
          success: false,
          error: 'Unauthorized: Owner not authenticated',
        });
      }

      // No TTL: a REST read must be fully fresh (credit deposit/withdraw
      // re-reads this the instant money moves).
      const ownerDetails = await buildOwnerProfile(ownerId);

      if (!ownerDetails) {
        return res.status(404).json({
          success: false,
          error: 'Owner account not found',
        });
      }

      return res.status(200).json({
        success: true,
        data: {
          user: ownerDetails,
        },
      });

    } catch (error) {
      console.error('Error in getLoggedInOwnerDetails:', error);
      return res.status(500).json({
        success: false,
        error: 'Internal server error',
      });
    }
  },

};

export default UserController;


