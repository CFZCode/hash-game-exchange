import FixturesService from '../../services/FixturesService.js';

const FixturesController = {
    // Backoffice: collected upcoming fixtures + collector freshness.
    // Always 200 so the header ticker degrades to empty instead of erroring.
    getFixtures: async (req, res) => {
        const result = await FixturesService.getFixtures();
        if (!result.ok) console.error('Error in getFixtures:', result.error);
        res.status(200).json({ success: result.ok, data: result.data, meta: result.meta });
    },
};

export default FixturesController;
