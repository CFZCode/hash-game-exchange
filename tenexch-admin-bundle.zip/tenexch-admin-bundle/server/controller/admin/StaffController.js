import Staff from '../../model/admin/Staff.js';
import Role from '../../model/admin/Role.js';
import WalletService from '../../services/walletService.js';
import PasswordService from '../../services/passwordService.js';
import sequelize from '../../config/db.js';
import Wallet from '../../model/admin/Wallet.js';
import Transaction from '../../model/admin/Transaction.js';
import PointLedger from '../../model/admin/PointLedger.js';
import { POINT_EVENT, pointEntryRef } from '../../constants/pointLedger.js';
import User from '../../model/user/User.js';
import { Op } from 'sequelize';
import { getDescendantStaffIds } from '../../helper/getuserids.js';
import ThirdPartyLimitService from '../../services/ThirdPartyLimitService.js';
import { canChangePassword } from '../../helper/passwordChangePermission.js';
import { MESSAGES } from '../../constants/messages.js';
import { verifyTxnPasswordWithAttempts } from '../../services/admin/transactionPasswordService.js';

// Helper: validation error that carries its exact HTTP response. Thrown (not
// returned) inside a transaction so the catch block always rolls it back —
// an early `return res...` left the transaction open and leaked a pool connection.
const httpError = (status, body) =>
  Object.assign(new Error(body.message), { httpStatus: status, httpBody: body });

// Helper: Validate role exists
const getRoleOrFail = async (roleName) => {
  const role = await Role.findOne({ where: { role: roleName } });
  if (!role) throw new Error(`Role '${roleName}' not found`);
  return role;
};

// CREATE STAFF
// export const createStaff = async (req, res) => {
//   const t = await sequelize.transaction();
//   try {
//     const { username, email, password, role, parent_id, percentage, credit = 0, cash = 0 } = req.body;

//     if (!username || !email || !password || !role) {
//       return res.status(400).json({ message: 'Missing required fields' });
//     }

//     // Validate password strength
//     const { isValid, errors } = PasswordService.validatePasswordStrength(password);
//     if (!isValid) {
//       return res.status(400).json({ message: 'Password too weak', errors });
//     }

//     const roleRecord = await getRoleOrFail(role);

//     // Validate parent exists
//     let parent = null;

//     if (role != "COMPANY") {
//       parent = await Staff.findByPk(parent_id, { transaction: t });
//       if (!parent) return res.status(400).json({ message: 'Parent staff not found' });
//     }

// // validation: parent level must be higher than new staff level
//       if (parent_id) {
//     const parent = await Staff.findByPk(parent_id);
//     const parentLevel = parseInt(parent.level.slice(1));
//     const myLevel = parseInt(roleRecord.level.slice(1));

//     if (myLevel <= parentLevel) {
//         return res.status(400).json({
//             message: `Cannot create ${role} under ${parent.role}. Parent must be higher level.`
//         });
//     }
// }



//     // Hash password via service
//     const hashedPassword = await PasswordService.hashPassword(password);

//     // Create staff
//     const staff = await Staff.create({
//       username,
//       email,
//       password: hashedPassword,
//       role_id: roleRecord.role_id,
//       role: roleRecord.role,
//       level: roleRecord.level,
//       parent_id: parent_id || null,
//       percentage: percentage || null,
//     }, { transaction: t });

//     // Create wallet with opening balance : cash/credit
//     const wallet = await WalletService.createWallet(
//       staff.staff_id,
//       roleRecord.role, // use role as userType
//       t,
//       username,
//       credit,
//       cash
//     );

//     // If opening_balance > 0, credit it
//     if (parseFloat(opening_balance) > 0) {
//       await WalletService.creditBalance(
//         staff.staff_id,
//         opening_balance,
//         roleRecord.role,
//         t,
//         req.user?.username || 'system' // logged in user
//       );
//     }

//     await t.commit();

//     const { password: _, ...safeStaff } = staff.toJSON();
//     res.status(201).json({ staff: safeStaff, wallet });
//   } catch (err) {
//     await t.rollback();
//     res.status(400).json({ message: err.message });
//   }
// };

// CREATE STAFF
export const createStaff = async (req, res) => {
  const t = await sequelize.transaction();
  try {
   let {
      username,
      fullname,
      email,
      password,
      role,
      parent_id,
      parent_owner_id,
      percentage,
      city,
      // "Mobile Number" on the create-account form. It was never destructured
      // here, so even after the column existed it would not have been saved.
      phone_number,
      cash = 0,
      credit_ref = 0,
      // "Password Change" tick on the admin create-account form. Ticked stores
      // false = this staff may not change its own password after first login.
      passwordChangeAllowed = true
    } = req.body;

    // Blank / null Credit Amount counts as 0 and is accepted (user,
    // 2026-09-21); whitespace is trimmed so " " still counts as blank.
    const rawCredit = typeof credit_ref === 'string' ? credit_ref.trim() : credit_ref;
    const credit = parseFloat(rawCredit) || 0;

    // Same rule as the player create route: 0 is fine, negative or
    // non-numeric is refused with the reference's own wording. Parsed from
    // rawCredit, not `credit` above — that one is already flattened to 0 and
    // could no longer tell "abc" from a real 0.
    if (rawCredit !== undefined && rawCredit !== null && rawCredit !== ''
        // plain number, max 2 decimals: "100abc"/"1e3"/"1,000"/"0.005" (DB rounds it up to 0.01) refused
        && (!['number', 'string'].includes(typeof rawCredit) || !/^\d+(\.\d{1,2})?$/.test(String(rawCredit)))) {
      throw httpError(400, { success: false, message: MESSAGES.ADMIN.USERS.CREDIT_AMOUNT_INVALID, error: MESSAGES.ADMIN.USERS.CREDIT_AMOUNT_INVALID });
    }

    // The role comes from the "User Type" select. Missing or unknown → the
    // reference's own toast, from the server (user, 2026-09-21).
    if (!role || !String(role).trim()) {
      throw httpError(400, { success: false, message: MESSAGES.ADMIN.USERS.SELECT_PROPER_USER_TYPE, error: MESSAGES.ADMIN.USERS.SELECT_PROPER_USER_TYPE });
    }

    if (!username || !password) {
      throw httpError(400, { message: 'Missing required fields' });
    }

    // ✅ Validate password
    const { isValid, errors } = PasswordService.validatePasswordStrength(password);
    if (!isValid) {
      throw httpError(400, { message: 'Password too weak', errors });
    }

    // 🔒 Username must be globally unique across USERS, STAFF and OWNERS
    // (case-insensitive). Pre-check so we return a clean message and never
    // create a staff name that collides with a player/owner.
    const nameWhere = { username: { [Op.iLike]: username } };
    const [userNameDup, staffNameDup, ownerNameDup] = await Promise.all([
      User.findOne({ where: nameWhere, attributes: ['user_id'], raw: true }),
      Staff.findOne({ where: nameWhere, attributes: ['staff_id'], raw: true }),
      Owner.findOne({ where: nameWhere, attributes: ['owner_id'], raw: true }),
    ]);
    if (userNameDup || staffNameDup || ownerNameDup) {
      await t.rollback();
      return res.status(409).json({ message: MESSAGES.ADMIN.USERS.USERNAME_EXISTS });
    }

    // ✅ Get role details — an unknown role is a bad "User Type" pick, so it
    // answers with the same reference text rather than a raw "Role 'x' not found".
    const roleRecord = await Role.findOne({ where: { role } });
    if (!roleRecord) {
      throw httpError(400, { success: false, message: MESSAGES.ADMIN.USERS.SELECT_PROPER_USER_TYPE, error: MESSAGES.ADMIN.USERS.SELECT_PROPER_USER_TYPE });
    }

    // Parent verification is now handled by validateParent middleware
    // It ensures parent exists (if not OWNER) and sets parent_id correctly
    
    // ✅ Validate if parent is not owner (Hierarchy check handled by validateHierarchy middleware)
    // We can skip the manual level checks here as validateHierarchy does it more robustly

   

    // ✅ Hash password
    const hashedPassword = await PasswordService.hashPassword(password);

    // ✅ Create staff record
    const staff = await Staff.create(
      {
        username,
        fullname: fullname || null,
        email,
        password: hashedPassword,
        role_id: roleRecord.role_id,
        role: roleRecord.role,
        level: roleRecord.level,
        parent_id: parent_id || null,
        parent_owner_id: parent_owner_id || null, // ✅ Save parent_owner_id
        percentage: percentage || null,
        city: city || null,
        // The form has always posted this; before the staff table had the
        // column it was silently dropped (user, 2026-09-21).
        phone_number: phone_number || null,
        passwordChangeAllowed: passwordChangeAllowed !== false,
      },
      { transaction: t }
    );

    // ✅ Create wallet for the staff
    const wallet = await WalletService.createWallet(
      staff.staff_id,
      roleRecord.role,
      t,
      username,
    );

    // Save credit_ref as cash_received and transfer it from the parent's
    // wallet — same credit flow as createUserUnderParent.
    // Set when the parent is short: staff is still created, with 0 credit.
    let insufficientBal = null;
    if (credit > 0) {

      // Sender = logged-in parent (owner or staff) who is handing out the credit
      const senderType = (req.user?.role || req.user?.user_type || '').toUpperCase(); // OWNER | ADMIN | MASTER ...
      const senderId = req.user?.account?.id || req.user?.actor?.id || req.user?.id;
      const senderField = WalletService.getWalletQueryField(senderType); // owner_id | staff_id

      const senderWallet = await Wallet.findOne({
        where: { [senderField]: senderId, user_type: senderType },
        transaction: t,
        lock: t.LOCK.UPDATE
      });
      if (!senderWallet) throw new Error('Sender wallet not found');

      const currentBal = Number(senderWallet.inr_balance || 0);
      const deductAmount = Number(credit);

      // Extra (settlement) points opening credit me nahi ja sakte — same rule as addDeposit.
      const extraPoint = Math.round((parseFloat(senderWallet?.upper_point || 0) + parseFloat(senderWallet?.down_point || 0)) * 100) / 100;
      const balanceWithoutExtraPoint = extraPoint > 0 ? Math.round((currentBal - extraPoint) * 100) / 100 : currentBal;

      if (currentBal < deductAmount) {
        // Parent is short — create the staff anyway with 0 credit.
        // Nothing moves, so no ledger / transaction rows.
        insufficientBal = currentBal;
      } else if (balanceWithoutExtraPoint < deductAmount) {
        // Balance hai, par sirf extra point se poora hota hai — wo bhi "short" maana jaayega.
        insufficientBal = balanceWithoutExtraPoint;
      } else {
        senderWallet.inr_balance = currentBal - deductAmount;

        await senderWallet.save({ transaction: t });

        // 💳 Hand the credit over to the newly created staff
        wallet.credit        = credit;
       // wallet.cash          = credit;
        wallet.inr_balance   = credit;
       // wallet.cash_received = credit;
        wallet.all_point     = credit;
        await wallet.save({ transaction: t });

        // Opening balance ki point_ledger entry — naya staff day-one se ledger me matched rahe
        await PointLedger.create({
          entry_ref: pointEntryRef.opening(wallet.wallet_id),
          event_type: POINT_EVENT.USER_CREATION,
          wallet_id: wallet.wallet_id,
          username,
          settled_with_wallet_id: senderWallet?.wallet_id,
          delta: credit,
          all_point_after: credit,
          closing_inr_balance: credit,
          closing_inr_balance_parent: currentBal - deductAmount,
          remark: `${POINT_EVENT.USER_CREATION}#${senderWallet?.username}/${wallet?.username}`,
        }, { transaction: t });

        // This is for the sender Staff/Owner
        await Transaction.create({
          wallet_id: senderWallet.wallet_id,
          user_id: null,
          staff_id: senderType === 'OWNER' ? null : senderId,
          owner_id: senderType === 'OWNER' ? senderId : null,
          username: senderWallet?.username,
          type: "DEBIT_FOR_CREDIT",
          amount: deductAmount,
          previous_balance: currentBal,
          new_balance: currentBal - deductAmount,
          balance: currentBal - deductAmount,
          credit: staff?.username,
          debit: senderWallet?.username,
          initiated_by: senderWallet.username,
        }, { transaction: t });

        // This is for the newly created staff
        await Transaction.create({
          wallet_id: wallet?.wallet_id,
          user_id: null,
          staff_id: staff.staff_id,
          owner_id: null,
          username: staff?.username,
          type: "ADD_CREDIT",
          amount: credit,
          previous_balance: 0,
          new_balance: credit,
          balance: credit,
          credit: staff?.username,
          debit: senderWallet?.username,
          initiated_by: senderWallet.username,
        }, { transaction: t });
      }
    }



    await t.commit();

    const { password: _, ...safeStaff } = staff.toJSON();
    // const userWallet = await WalletService.getUserWallet(staff.staff_id, role);

    res.status(201).json({
      success: true,
      message: insufficientBal !== null
        ? MESSAGES.ADMIN.USERS.CREATED_INSUFFICIENT_CREDIT(insufficientBal)
        : "Staff created successfully",
      creditSkipped: insufficientBal !== null,
      staff: safeStaff,
      wallet: wallet,
    });

  } catch (err) {
    await t.rollback();
    if (err.httpBody) return res.status(err.httpStatus).json(err.httpBody);
    console.error("❌ createStaff error:", err);

    if (err.name === 'SequelizeUniqueConstraintError') {
      const field = err.errors?.[0]?.path || 'field';
      return res.status(409).json({ message: `${field} already exists` });
    }

    res.status(400).json({ message: err.message });
  }
};


// GET ALL STAFF
export const getAllStaff = async (req, res) => {
  try {
    const staff = await Staff.findAll({
      attributes: { exclude: ['password'] },
      include: [
        { model: Role, as: 'roleDetails', attributes: ['role', 'level', 'power'] },
        { model: Staff, as: 'parent', attributes: ['staff_id', 'username'] },
      ],
      order: [['createdAt', 'DESC']],
    });
    res.json(staff);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// GET ONE STAFF
export const getStaffById = async (req, res) => {
  try {
    const { id } = req.params;
    const staff = await Staff.findByPk(id, {
      attributes: { exclude: ['password'] },
      include: [
        { model: Role, as: 'roleDetails', attributes: ['role', 'level', 'power'] },
        { model: Staff, as: 'parent', attributes: ['staff_id', 'username'] },
        { model: Staff, as: 'children', attributes: ['staff_id', 'username', 'role'] },
      ],
    });

    if (!staff) return res.status(404).json({ message: 'Staff not found' });
    res.json(staff);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// UPDATE STAFF
export const updateStaff = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const { id } = req.params;
    const updates = req.body;

    const staff = await Staff.findByPk(id, { transaction: t });
    if (!staff) return res.status(404).json({ message: 'Staff not found' });

    // Role change
    if (updates.role) {
      const roleRecord = await getRoleOrFail(updates.role);
      updates.role_id = roleRecord.role_id;
      updates.level = roleRecord.level;
    }

    // Password change
    if (updates.password) {
      const { isValid, errors } = PasswordService.validatePasswordStrength(updates.password);
      if (!isValid) return res.status(400).json({ message: 'Password too weak', errors });
      updates.password = await PasswordService.hashPassword(updates.password);
    }

    // Percentage
    if (updates.percentage !== undefined) {
      updates.percentage = updates.percentage === null ? null : parseFloat(updates.percentage);
    }

    await staff.update(updates, { transaction: t });
    await t.commit();

    const { password: _, ...safeStaff } = staff.toJSON();
    res.json(safeStaff);
  } catch (err) {
    await t.rollback();
    res.status(400).json({ message: err.message });
  }
};

// GET STAFF BY ROLE
export const getStaffByRole = async (req, res) => {
  try {
    const { role } = req.params;
    const staff = await Staff.findAll({
      where: { role },
      attributes: { exclude: ['password'] },
      include: [
        { model: Role, as: 'roleDetails', attributes: ['power'] },
        { model: Staff, as: 'parent', attributes: ['username'] },
      ],
    });
    res.json(staff);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// GET STAFF UNDER PARENT
export const getStaffUnderParent = async (req, res) => {
  try {
    const { parentId } = req.params;
    const staff = await Staff.findAll({
      where: { parent_id: parentId },
      attributes: { exclude: ['password'] },
      include: [
        { model: Role, as: 'roleDetails', attributes: ['role', 'level'] },
      ],
      order: [['createdAt', 'DESC']],
    });
    res.json(staff);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// DELETE STAFF (with hierarchy fix)
export const deleteStaff = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const { id } = req.params;
    const staff = await Staff.findByPk(id, { transaction: t });
    if (!staff) return res.status(404).json({ message: 'Staff not found' });

    const parentOfDeleted = staff.parent_id;

    // This delete re-hangs the sub-tree, so every player under it ends up with a
    // different ancestor chain. Collect them BEFORE the tree moves — afterwards
    // the old shape is gone. Only ids, only for the cache drop below.
    const affectedStaffIds = [Number(id), ...(await getDescendantStaffIds(id))];
    const affectedUsers = await User.findAll({
      where: { parent_staff_id: { [Op.in]: affectedStaffIds } },
      attributes: ['user_id'],
      transaction: t,
      raw: true,
    });

    // Update children: set their parent_id = deleted.parent_id
    await Staff.update(
      { parent_id: parentOfDeleted },
      { where: { parent_id: id }, transaction: t }
    );

    // Soft delete the staff
    await staff.destroy({ transaction: t });

    await t.commit();

    // Best-effort cache maintenance, AFTER the commit so it can never fail or
    // slow the delete: drop the cached Third Party Game Limit chains for the
    // players that just moved. Without it they would keep resolving against
    // their old ancestors until the chain TTL expires (10 min).
    try {
      await Promise.all(
        affectedUsers.map((u) => ThirdPartyLimitService.invalidateUserChain(u.user_id))
      );
    } catch (cacheErr) {
      console.warn('deleteStaff: third-party limit chain invalidation failed:', cacheErr.message);
    }

    res.json({ message: 'Staff deleted and hierarchy updated' });
  } catch (err) {
    await t.rollback();
    res.status(500).json({ message: err.message });
  }
};

// ===================================================================
// UPDATE STAFF/OWNER PASSWORD
// ===================================================================
import Owner from '../../model/admin/Owner.js';

export const updateStaffPassword = async (req, res) => {
  const transaction = await sequelize.transaction();
  try {
    // req.user is set by authMiddleware
    // It usually contains { user_id, role, ... }
    const userId = req.user.account.id|| req.user.staff_id || req.user.owner_id;
    const userRole = req.user.role; // 'OWNER', 'admin', 'master', etc.

    // Two callers: the header Change Password modal sends the account's
    // TRANSACTION CODE (reference: "Transaction Code" box), the first-login
    // page sends the old LOGIN password. 2026-10-11.
    const { oldPassword, transactionPassword: txnCode, newPassword } = req.body;

    if ((!oldPassword && !txnCode) || !newPassword) {
      await transaction.rollback();
      return res.status(400).json({ success: false, message: 'Both old and new passwords are required' });
    }

    let user;
    let isOwner = false;

    // Determine if user is Owner or Staff
    if (userRole === 'OWNER' || userRole === 'Owner') {
      isOwner = true;
      user = await Owner.findOne({ where: { owner_id: userId } });
    } else {
      user = await Staff.findByPk(userId);
    }

    if (!user) {
      await transaction.rollback();
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    // Permission check — an operator can be created with the "Password Change"
    // box ticked, and a blocked parent blocks the staff it created. Owners are
    // never blocked: they are the top of the tree and carry no flag. The
    // mandatory first-login change (first_login === false) is exempt, which the
    // helper handles.
    if (!isOwner) {
      const permission = await canChangePassword({ type: 'STAFF', account: user });
      if (!permission.allowed) {
        await transaction.rollback();
        return res.status(403).json({ success: false, message: permission.reason });
      }
    }

    if (txnCode) {
      // Same check (and 10-attempt lock) as every other transaction-code route
      const txn = await verifyTxnPasswordWithAttempts(req.user, txnCode);
      if (!txn.ok) {
        await transaction.rollback();
        return res.status(txn.status).json({ success: false, message: txn.message, attemptsLeft: txn.attemptsLeft });
      }
    } else {
      // Verify old password
      const isValid = await PasswordService.comparePassword(oldPassword, user.password);
      if (!isValid) {
        await transaction.rollback();
        return res.status(400).json({ success: false, message: 'Old password is incorrect' });
      }
    }

    // New password must differ from the one already on the account.
    const isSameAsOld = await PasswordService.comparePassword(newPassword, user.password);
    if (isSameAsOld) {
      await transaction.rollback();
      return res.status(400).json({ success: false, message: MESSAGES.AUTH.PASSWORD_SAME_AS_OLD });
    }

    // Validate new password strength
    const validation = PasswordService.validatePasswordStrength(newPassword);
    if (!validation.isValid) {
      await transaction.rollback();
      return res.status(400).json({
        success: false,
        message: `New password too weak: ${validation.errors.join(', ')}`,
      });
    }

    // Hash new password
    const hashedPassword = await PasswordService.hashPassword(newPassword);

    let transactionPassword = null;
    // Check if this is the first login reset
    if (!user.first_login) {
        // Generate 6-digit random number
        transactionPassword = Math.floor(100000 + Math.random() * 900000).toString();
        
        // Update user with new password, set first_login to true, and save transaction password
        await user.update({ 
            password: hashedPassword, 
            first_login: true,
            transaction_password: transactionPassword 
        }, { transaction });
    } else {
        // Normal password update
        await user.update({ password: hashedPassword }, { transaction });
    }

    await transaction.commit();
    
    const response = { success: true, message: 'Password updated successfully' };
    if (transactionPassword) {
        response.transactionPassword = transactionPassword;
    }
    
    res.status(200).json(response);

  } catch (error) {
    await transaction.rollback();
    console.error('Error in updateStaffPassword:', error);
    res.status(500).json({ success: false, message: error.message });
  }
};