import StaffAuthService from '../../services/admin/staffAuthService.js';
import Staff from '../../model/admin/Staff.js';
import { getRulesAccepted, setRulesAccepted } from '../../helper/rulesAccepted.js';

import ActivityLogService from '../../services/admin/ActivityLogService.js';
import { MESSAGES } from '../../constants/messages.js';

const StaffAuthController = {
  // 🧩 Login handler
  login: async (req, res) => {
    try {
      const { email, username, password, deviceId } = req.body;

      // Allow either email OR username
      const identifier = email || username;

      if (!identifier || !password)
        return res.status(400).json({ success: false, error: MESSAGES.AUTH.CREDENTIALS_REQUIRED });

      const result = await StaffAuthService.login(identifier, password, deviceId);

      if (result.require2FA) {
        return res.status(200).json({
          success: true,
          require2FA: true,
          // See ownerAuthController — the client routes on this.
          method: result.method || 'telegram',
          staffId: result.staffId,
          message: result.message
        });
      }

      // 📝 Log Activity
      await ActivityLogService.log({
        req,
        user: result.staff,
        action: 'LOGIN',
        details: MESSAGES.ADMIN.ACTIVITY.STAFF_LOGIN,
      });

      res.status(200).json({
        success: true,
        message: MESSAGES.AUTH.LOGIN_SUCCESS,
        token: result.token,
        first_login: result.staff.first_login,
        rules_accepted: await getRulesAccepted(Staff, 'staff_id', result.staff.id),
      });
    } catch (error) {
      console.error('❌ Staff login error:', error);
      res.status(401).json({ success: false, error: error.message });
    }
  },

  // 🔐 Verify 2FA Logic
  // 🔁 Re-send the login OTP (the 2FA screen calls this on a refresh)
  resend2FA: async (req, res) => {
    try {
      const { staffId } = req.body;
      if (!staffId) return res.status(400).json({ success: false, error: MESSAGES.ADMIN.AUTH.MISSING_STAFFID_OR_OTP });

      await StaffAuthService.resend2FA(staffId);
      res.status(200).json({ success: true, message: MESSAGES.AUTH.OTP_RESENT });
    } catch (error) {
      console.error('❌ Staff Resend 2FA Error:', error);
      res.status(400).json({ success: false, error: error.message });
    }
  },

  verify2FA: async (req, res) => {
    try {
      const { staffId, otp, deviceId } = req.body;
      if (!staffId || !otp) return res.status(400).json({ success: false, error: MESSAGES.ADMIN.AUTH.MISSING_STAFFID_OR_OTP });

      const result = await StaffAuthService.verify2FA(staffId, otp, deviceId);

      // 📝 Log Activity
      await ActivityLogService.log({
        req,
        user: result.staff,
        action: 'LOGIN_2FA',
        details: MESSAGES.ADMIN.ACTIVITY.STAFF_2FA,
      });

      res.json({
        success: true,
        message: MESSAGES.AUTH.TWO_FA_VERIFIED,
        token: result.token,
        first_login: result.staff.first_login,
        rules_accepted: await getRulesAccepted(Staff, 'staff_id', result.staff.id)
      });

    } catch (error) {
      console.error('❌ Staff Verify 2FA Error:', error);
      res.status(400).json({ success: false, error: error.message });
    }
  },

  // 🚪 Logout handler
  logout: async (req, res) => {
    try {
      const token = req.header('Authorization')?.replace('Bearer ', '');
      if (!token)
        return res.status(400).json({ success: false, error: MESSAGES.AUTH.TOKEN_NOT_PROVIDED });

      await StaffAuthService.logout(token);
      res.status(200).json({ success: true, message: MESSAGES.AUTH.LOGOUT_SUCCESS });
    } catch (error) {
      console.error('❌ Staff logout error:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  },
  // 👤 Get Profile handler
  getProfile: async (req, res) => {
    try {
      // req.user is populated by authMiddleware
      const  staff_id  = req.user.account.id;
      
      if (!staff_id) {
        return res.status(400).json({ success: false, error: MESSAGES.ADMIN.AUTH.STAFF_ID_MISSING_TOKEN });
      }

      const data = await StaffAuthService.getProfile(staff_id);
      res.status(200).json({
        success: true,
        data: { user: data }, // Wrap in user object to match frontend expectation
      });
    } catch (error) {
      console.error('❌ Staff getProfile error:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  },

  // ✅ Accept Rules (sets the rules_accepted flag returned by the profile API)
  acceptRules: async (req, res) => {
    try {
      // Prefer the explicit id from the request payload; fall back to the token
      const staff_id = Number(req.body?.staff_id) || req.user.account.id;

      if (!staff_id) {
        return res.status(400).json({ success: false, error: MESSAGES.ADMIN.AUTH.STAFF_ID_MISSING });
      }

      const { accepted, updatedRows } = await setRulesAccepted(Staff, 'staff_id', staff_id);

      res.status(200).json({ success: accepted, rules_accepted: accepted, staff_id, updated_rows: updatedRows });
    } catch (error) {
      console.error('❌ Staff acceptRules error:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  },
};

export default StaffAuthController;
