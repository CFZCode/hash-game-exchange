import CommissionConfig from '../../model/admin/CommissionConfig.js';
import CommissionConfigService from '../../services/CommissionConfigService.js';
import SportsConfig from '../../model/user/SportsConfig.js';
import { SPORTS_LIST } from '../../constants/sportsList.js';
import {
    DEFAULT_LEAGUE_KEY,
    leagueOptionsForSport,
    isValidLeagueKey,
} from '../../constants/commissionLeagues.js';

// Owner-only control panel for the sports win commission: one cell per
// sport × league × market, each cell = ON/OFF + percent.
// Same pattern as the Buffer Time screen (bettingConfigController.js).
// Plan: docs/plans/2026-09-12-commission-market-league-split.md
//
// Two things this screen exists to express that the old sport × gtype grid
// could not:
//   * "Match Odds" really means the market named Match Odds — gtype 'match'
//     also carries Over/Under, Correct Score, Match Result, Inning EvenOdd and
//     "3rd Ball Of Match", which the owner does not want to charge.
//   * cricket's E-Cricket / T10 XI / T5 XI / Virtual Cricket League arrive as
//     sport_id 4, so they need their own rows.
//
// A variant-league cell with no row INHERITS the sport's 'default' row, so the
// payload reports a per-cell `state` of 'on' | 'off' | 'inherit' rather than a
// bare boolean. DELETE puts a cell back to 'inherit'.

const MARKETS = CommissionConfig.MARKETS;
const MARKET_KEYS = CommissionConfig.MARKET_KEYS;
const MAX_PERCENT = CommissionConfig.MAX_PERCENT;
const DEFAULT_PERCENT = CommissionConfig.DEFAULT_PERCENT;

const fail = (res, code, message) => res.status(code).json({ success: false, error: message });

const parsePercent = (raw) => {
    const n = Number(raw);
    if (!Number.isFinite(n) || n < 0 || n > MAX_PERCENT) return null;
    return Math.round(n * 100) / 100;
};

const parseBool = (v) => v === true || v === 'true' || v === 1 || v === '1';

/**
 * Validate one cell write. Returns { error } or the clean values.
 * `market_key` accepts the pre-2026-09-12 `gtype` spelling so an older admin
 * bundle cached in a browser keeps working: 'match' and 'match1' are ambiguous
 * now, so they are refused with a message that names the replacements.
 */
const parseCell = (body) => {
    const sportId = Number(body?.sport_id);
    const leagueKey = String(body?.league_key || DEFAULT_LEAGUE_KEY).toLowerCase().trim();
    const marketKey = String(body?.market_key || body?.gtype || '').toLowerCase().trim();
    const percent = parsePercent(body?.percent);

    if (!Number.isInteger(sportId) || sportId <= 0) return { error: 'sport_id is required' };
    if (CommissionConfig.LEGACY_GTYPE_EXPANSION[marketKey]) {
        return {
            error: `'${marketKey}' is no longer a single market — use ${CommissionConfig.LEGACY_GTYPE_EXPANSION[marketKey].join(' or ')}`,
        };
    }
    if (!MARKET_KEYS.includes(marketKey)) {
        return { error: `market_key must be one of ${MARKET_KEYS.join(', ')}` };
    }
    if (!isValidLeagueKey(sportId, leagueKey)) {
        const allowed = leagueOptionsForSport(sportId).map((l) => l.key).join(', ');
        return { error: `league_key '${leagueKey}' is not configured for sport ${sportId} (allowed: ${allowed})` };
    }
    if (percent === null) return { error: `percent must be between 0 and ${MAX_PERCENT}` };

    return { sportId, leagueKey, marketKey, percent, enabled: parseBool(body?.enabled) };
};

const upsertCell = async ({ sportId, leagueKey, marketKey, enabled, percent }) => {
    const where = { sport_id: sportId, league_key: leagueKey, market_key: marketKey };
    const existing = await CommissionConfig.findOne({ where });
    if (existing) {
        await existing.update({ enabled, percent });
    } else {
        await CommissionConfig.create({ ...where, enabled, percent });
    }
};

// GET /api/admin/commission-config/sports
const getSportsCommission = async (req, res) => {
    try {
        const rows = await CommissionConfig.findAll({
            attributes: ['sport_id', 'league_key', 'market_key', 'enabled', 'percent'],
            raw: true,
        });
        const saved = new Map();
        for (const row of rows) {
            saved.set(`${row.sport_id}:${row.league_key}:${row.market_key}`, {
                enabled: !!row.enabled,
                percent: Number(row.percent) || 0,
            });
        }

        // Sports the platform has actually enabled float to the top; the rest
        // stay listed so a sport can be configured before it is switched on.
        let enabledSports = new Set();
        try {
            const cfg = await SportsConfig.findAll({
                where: { enabled: true }, attributes: ['game_id'], raw: true,
            });
            enabledSports = new Set(cfg.map((c) => String(c.game_id)));
        } catch { /* SportsConfig unavailable — list everything, unsorted */ }

        const sports = SPORTS_LIST.map(([sportId, name]) => {
            const leagues = leagueOptionsForSport(sportId).map((league) => {
                const rules = {};
                for (const marketKey of MARKET_KEYS) {
                    const hit = saved.get(`${sportId}:${league.key}:${marketKey}`);
                    const inherited = league.is_default
                        ? null
                        : saved.get(`${sportId}:${DEFAULT_LEAGUE_KEY}:${marketKey}`) || null;

                    if (hit) {
                        rules[marketKey] = {
                            state: hit.enabled ? 'on' : 'off',
                            percent: hit.percent,
                            // What this cell would fall back to if reset.
                            inherited: inherited
                                ? { state: inherited.enabled ? 'on' : 'off', percent: inherited.percent }
                                : null,
                        };
                    } else if (league.is_default) {
                        // No row on `default` means no commission, full stop.
                        rules[marketKey] = { state: 'off', percent: DEFAULT_PERCENT, inherited: null };
                    } else {
                        rules[marketKey] = {
                            state: 'inherit',
                            percent: inherited?.percent ?? DEFAULT_PERCENT,
                            inherited: inherited
                                ? { state: inherited.enabled ? 'on' : 'off', percent: inherited.percent }
                                : { state: 'off', percent: DEFAULT_PERCENT },
                        };
                    }
                }
                // What settlement would actually do for this league, after
                // inheritance — this is what the screen summarises per sport.
                const activeCount = MARKET_KEYS.filter((k) => {
                    const r = rules[k];
                    if (r.state === 'on') return true;
                    if (r.state === 'inherit') return r.inherited?.state === 'on';
                    return false;
                }).length;
                return { ...league, rules, active_count: activeCount };
            });

            return {
                sport_id: Number(sportId),
                name,
                enabled: enabledSports.has(sportId),
                leagues,
                active_count: leagues[0]?.active_count || 0,
            };
        }).sort((a, b) => (b.enabled === a.enabled ? 0 : b.enabled ? 1 : -1));

        return res.json({
            success: true,
            markets: MARKETS,
            market_keys: MARKET_KEYS,
            default_league_key: DEFAULT_LEAGUE_KEY,
            max_percent: MAX_PERCENT,
            default_percent: DEFAULT_PERCENT,
            sports,
        });
    } catch (err) {
        console.error('getSportsCommission error:', err);
        return fail(res, 500, 'Failed to load commission configuration');
    }
};

// POST /api/admin/commission-config/sports
// { sport_id, league_key?, market_key, enabled, percent }
const saveSportsCommission = async (req, res) => {
    try {
        const cell = parseCell(req.body);
        if (cell.error) return fail(res, 400, cell.error);

        await upsertCell(cell);
        await CommissionConfigService.invalidate();

        return res.json({
            success: true,
            sport_id: cell.sportId,
            league_key: cell.leagueKey,
            market_key: cell.marketKey,
            enabled: cell.enabled,
            percent: cell.percent,
        });
    } catch (err) {
        console.error('saveSportsCommission error:', err);
        return fail(res, 500, 'Failed to save commission setting');
    }
};

// POST /api/admin/commission-config/sports/bulk
// { items: [{ sport_id, league_key?, market_key, enabled, percent }, …] }
//
// The screen saves every dirty cell at once — the old one-Save-per-cell flow
// meant dozens of clicks now that the grid has a league dimension. Validated
// as a whole first: one bad cell rejects the batch rather than leaving the
// grid half applied.
const BULK_LIMIT = 500;
const saveSportsCommissionBulk = async (req, res) => {
    try {
        const items = Array.isArray(req.body?.items) ? req.body.items : null;
        if (!items || items.length === 0) return fail(res, 400, 'items must be a non-empty array');
        if (items.length > BULK_LIMIT) return fail(res, 400, `items may not exceed ${BULK_LIMIT} cells`);

        const cells = [];
        for (let i = 0; i < items.length; i += 1) {
            const cell = parseCell(items[i]);
            if (cell.error) return fail(res, 400, `item ${i}: ${cell.error}`);
            cells.push(cell);
        }

        for (const cell of cells) await upsertCell(cell);
        await CommissionConfigService.invalidate();

        return res.json({ success: true, saved: cells.length });
    } catch (err) {
        console.error('saveSportsCommissionBulk error:', err);
        return fail(res, 500, 'Failed to save commission settings');
    }
};

// DELETE /api/admin/commission-config/sports
// { sport_id, league_key, market_key }  → the cell goes back to INHERIT.
//
// Only meaningful on a variant league: deleting a 'default' row is the same as
// switching it off, so that is refused to keep the screen honest.
const resetSportsCommission = async (req, res) => {
    try {
        const sportId = Number(req.body?.sport_id);
        const leagueKey = String(req.body?.league_key || '').toLowerCase().trim();
        const marketKey = String(req.body?.market_key || req.body?.gtype || '').toLowerCase().trim();

        if (!Number.isInteger(sportId) || sportId <= 0) return fail(res, 400, 'sport_id is required');
        if (!MARKET_KEYS.includes(marketKey)) return fail(res, 400, `market_key must be one of ${MARKET_KEYS.join(', ')}`);
        if (!leagueKey || leagueKey === DEFAULT_LEAGUE_KEY) {
            return fail(res, 400, 'only a league override can be reset — switch the default cell OFF instead');
        }
        if (!isValidLeagueKey(sportId, leagueKey)) {
            return fail(res, 400, `league_key '${leagueKey}' is not configured for sport ${sportId}`);
        }

        const removed = await CommissionConfig.destroy({
            where: { sport_id: sportId, league_key: leagueKey, market_key: marketKey },
        });
        await CommissionConfigService.invalidate();

        return res.json({ success: true, removed, sport_id: sportId, league_key: leagueKey, market_key: marketKey });
    } catch (err) {
        console.error('resetSportsCommission error:', err);
        return fail(res, 500, 'Failed to reset commission setting');
    }
};

export default {
    getSportsCommission,
    saveSportsCommission,
    saveSportsCommissionBulk,
    resetSportsCommission,
};
