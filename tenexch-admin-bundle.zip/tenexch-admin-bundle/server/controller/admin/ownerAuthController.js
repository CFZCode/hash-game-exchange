

import OwnerAuthService from '../../services/admin/ownerAuthService.js';
import Owner from '../../model/admin/Owner.js';
import { getRulesAccepted, setRulesAccepted } from '../../helper/rulesAccepted.js';

import ActivityLogService from '../../services/admin/ActivityLogService.js';
import { MESSAGES } from '../../constants/messages.js';

const OwnerAuthController = {
  // 🧩 Login
  login: async (req, res) => {
    try {
      const { site_email_address, email, username, password, deviceId } = req.body;

      // Allow site_email_address, email, OR username
      const identifier = site_email_address || email || username;

      if (!identifier || !password)
        return res.status(400).json({ success: false, error: MESSAGES.AUTH.CREDENTIALS_REQUIRED });

      const result = await OwnerAuthService.login(identifier, password, deviceId);

      if (result.require2FA) {
        return res.status(200).json({
          success: true,
          require2FA: true,
          // Which second factor this account uses: 'google' | 'telegram'. The
          // admin client routes on it (/loginauth/3 vs /2) and hides Resend for
          // Google, so it MUST be forwarded — this response is hand-built, so
          // anything the service returns is dropped unless listed here.
          method: result.method || 'telegram',
          ownerId: result.ownerId,
          message: result.message
        });
      }

      // 📝 Log Activity
      await ActivityLogService.log({
        req,
        user: result.owner,
        action: 'LOGIN',
        details: MESSAGES.ADMIN.ACTIVITY.OWNER_LOGIN,
      });

      res.status(200).json({
        success: true,
        message: MESSAGES.AUTH.LOGIN_SUCCESS,
        token: result.token,
        first_login: result.owner.first_login,
        rules_accepted: await getRulesAccepted(Owner, 'owner_id', result.owner.id),
      });
    } catch (error) {
      console.error('❌ Owner login error:', error);
      res.status(401).json({ success: false, error: error.message });
    }
  },

  // 🔁 Re-send the login OTP (the 2FA screen calls this on a refresh)
  resend2FA: async (req, res) => {
    try {
      const { ownerId } = req.body;
      if (!ownerId) return res.status(400).json({ success: false, error: MESSAGES.ADMIN.AUTH.MISSING_OWNERID_OR_OTP });

      await OwnerAuthService.resend2FA(ownerId);
      res.status(200).json({ success: true, message: MESSAGES.AUTH.OTP_RESENT });
    } catch (error) {
      console.error('❌ Owner Resend 2FA Error:', error);
      res.status(400).json({ success: false, error: error.message });
    }
  },

  // 🔐 Verify 2FA Logic
  verify2FA: async (req, res) => {
    try {
      const { ownerId, otp, deviceId } = req.body;
      if (!ownerId || !otp) return res.status(400).json({ success: false, error: MESSAGES.ADMIN.AUTH.MISSING_OWNERID_OR_OTP });

      const result = await OwnerAuthService.verify2FA(ownerId, otp, deviceId);

      // 📝 Log Activity
      await ActivityLogService.log({
        req,
        user: result.owner,
        action: 'LOGIN_2FA',
        details: MESSAGES.ADMIN.ACTIVITY.OWNER_2FA,
      });

      res.json({
        success: true,
        message: MESSAGES.AUTH.TWO_FA_VERIFIED,
        token: result.token,
        first_login: result.owner.first_login,
        rules_accepted: await getRulesAccepted(Owner, 'owner_id', result.owner.id)
      });

    } catch (error) {
      console.error('❌ Owner Verify 2FA Error:', error);
      res.status(400).json({ success: false, error: error.message });
    }
  },

  // 🚪 Logout
  logout: async (req, res) => {
    try {
      const token = req.header('Authorization')?.replace('Bearer ', '');
      if (!token)
        return res.status(400).json({ success: false, error: MESSAGES.AUTH.TOKEN_NOT_PROVIDED });

      await OwnerAuthService.logout(token);
      res.status(200).json({ success: true, message: MESSAGES.AUTH.LOGOUT_SUCCESS });
    } catch (error) {
      console.error('❌ Owner logout error:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  },

  // 👤 Get Profile
  getProfile: async (req, res) => {
    try {
      // req.user is populated by authMiddleware
      const owner_id  = req.user.account.id;
      
      if (!owner_id) {
        return res.status(400).json({ success: false, error: MESSAGES.ADMIN.AUTH.OWNER_ID_MISSING_TOKEN });
      }

      const profile = await OwnerAuthService.getProfile(owner_id);
      
      res.status(200).json({
        success: true,
        data: profile,
      });
    } catch (error) {
      console.error('❌ Owner getProfile error:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  },

  // ✅ Accept Rules (sets the rules_accepted flag returned by the profile API)
  acceptRules: async (req, res) => {
    try {
      // Prefer the explicit id from the request payload; fall back to the token
      const owner_id = Number(req.body?.owner_id) || req.user.account.id;

      if (!owner_id) {
        return res.status(400).json({ success: false, error: MESSAGES.ADMIN.AUTH.OWNER_ID_MISSING });
      }

      const { accepted, updatedRows } = await setRulesAccepted(Owner, 'owner_id', owner_id);

      res.status(200).json({ success: accepted, rules_accepted: accepted, owner_id, updated_rows: updatedRows });
    } catch (error) {
      console.error('❌ Owner acceptRules error:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  },
  // ⚙️ Update Platform Configurations
  updatePlatformConfigurations: async (req, res) => {
    try {
      const owner_id = req.user.account?.id;
      const { platform_configurations } = req.body;

      if (!owner_id) {
        return res.status(400).json({ success: false, error: MESSAGES.ADMIN.AUTH.OWNER_ID_MISSING_TOKEN });
      }

      if (!platform_configurations) {
        return res.status(400).json({ success: false, error: MESSAGES.ADMIN.SETTINGS.PLATFORM_CONFIG_REQUIRED });
      }

      const updatedConfig = await OwnerAuthService.updatePlatformConfigurations(owner_id, platform_configurations);

      res.status(200).json({
        success: true,
        message: MESSAGES.ADMIN.SETTINGS.PLATFORM_CONFIG_UPDATED,
        data: updatedConfig,
      });
    } catch (error) {
      console.error('❌ Owner updatePlatformConfigurations error:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  },
};

export default OwnerAuthController;
