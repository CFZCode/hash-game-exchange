import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import HomeSlider from '../../model/admin/HomeSlider.js';

// Where filename-typed slider art lives on disk (the frontend's asset folder,
// a sibling of server/ in the repo) — served through the API so EVERY tile
// image reaches clients as one exact server URL, whether the row stores a
// base64 data: URI or just "mogambo.jpg". Same arrangement as
// casinoManageController, pointed at the home-strip banners instead.
const SLIDER_ASSETS_DIR = path.resolve(
    path.dirname(fileURLToPath(import.meta.url)),
    '../../../frontend/public/assets/casino/sidebanners'
);

// Home Sliders — the owner's control over the two mobile home-page strips:
//   * /api/admin/home-slider/*      (owner-only) — full list + CRUD + reorder
//   * /api/user/home-slider/list    (public)     — enabled rows the frontend
//     renders under "Our Casino" and "New Games".

const VALID_SECTIONS = HomeSlider.SECTIONS;

// Display order. sort_order is per section and owner-controlled (see the
// reorder endpoint below); id is the tiebreak so rows that share a position —
// only possible on a row created outside the reorder flow — stay deterministic.
// casinoManageController.js:27 has the identical constant for the same reason.
const LIST_ORDER = [['section', 'ASC'], ['sort_order', 'ASC'], ['id', 'ASC']];

// A tile image may be a bare filename (served from /assets/casino/sidebanners),
// an http(s) URL, or a base64 data: URI produced by the admin uploader. Reject
// anything that doesn't look like one of those — especially script-ish URIs.
const isValidImg = (img) =>
    typeof img === 'string' &&
    img.length <= 8 * 1024 * 1024 &&
    (/^data:image\/[a-z0-9.+-]+;base64,/i.test(img) ||
        /^https?:\/\//i.test(img) ||
        /^[\w][\w .-]*\.(png|jpe?g|gif|webp|svg)$/i.test(img));

// Routes are app paths, not URLs — the frontend hands them straight to
// react-router. Empty is allowed and means "image only, no link".
const isValidRoute = (route) => route === '' || /^\/[\w\/-]*$/.test(route);

// Every stored image — base64 data: URI or bare filename — is presented to
// clients as ONE exact server URL onto serveSliderImage below, so list
// payloads stay light and no client needs the file shipped in its own build.
// Only full http(s) URLs pass through untouched. The URL is absolute (built
// from the request) so the admin panel — a different origin — renders it as-is.
// Scheme: this deploy's proxy doesn't pass X-Forwarded-Proto, so req.protocol
// reads http even though the site is https — and Safari blocks http images on
// an https page as mixed content. Honour the header when present, otherwise
// assume https for anything that isn't a private/local host.
const publicBaseFor = (req) => {
    const host = req.get('host') || '';
    const forwarded = (req.get('x-forwarded-proto') || '').split(',')[0].trim();
    const isLocal = /^(localhost|127\.|0\.0\.0\.0|192\.168\.|10\.|172\.(1[6-9]|2\d|3[01])\.)/.test(host);
    const proto = forwarded || (req.secure ? 'https' : isLocal ? 'http' : 'https');
    return `${proto}://${host}`;
};

// The serving URL is keyed on the row id, so replacing a tile's art does NOT
// change it — and the response is long-cached, so browsers would keep showing
// the OLD picture for a full day after an upload (ETag/Last-Modified never get
// consulted: max-age means no revalidation at all). Stamping updatedAt into
// the query string makes every save a NEW url, which fetches immediately while
// unchanged art still caches hard.
const publicImgFor = (req, row) => {
    if (row.img && !/^https?:\/\//i.test(row.img)) {
        const version = row.updatedAt ? new Date(row.updatedAt).getTime() : 0;
        return `${publicBaseFor(req)}/api/user/home-slider/img/${row.id}?v=${version}`;
    }
    return row.img;
};

const withImgUrl = (req) => (slider) => {
    const s = slider.toJSON();
    s.img = publicImgFor(req, s);
    return s;
};

// Streams a row's tile art as a real image response, long-cached. Stored
// base64 decodes from the row; a bare filename is read from the frontend's
// asset folder on disk — either way the client sees the same URL shape.
export const serveSliderImage = async (req, res) => {
    try {
        const slider = await HomeSlider.findByPk(req.params.id, { attributes: ['id', 'img', 'updatedAt'] });
        if (!slider || !slider.img) return res.status(404).end();

        if (slider.img.startsWith('data:')) {
            const match = slider.img.match(/^data:(image\/[a-z0-9.+-]+);base64,(.*)$/is);
            if (!match) return res.status(404).end();
            const buffer = Buffer.from(match[2], 'base64');
            res.set('Content-Type', match[1]);
            res.set('Cache-Control', 'public, max-age=86400');
            res.set('Last-Modified', new Date(slider.updatedAt).toUTCString());
            return res.send(buffer);
        }

        // Filename row: basename() strips any traversal, sendFile sets the type.
        const file = path.join(SLIDER_ASSETS_DIR, path.basename(slider.img));
        if (!fs.existsSync(file)) return res.status(404).end();
        res.set('Cache-Control', 'public, max-age=86400');
        return res.sendFile(file);
    } catch (error) {
        console.error('home-slider image error:', error);
        return res.status(500).end();
    }
};

// Multipart upload → base64 data URL. The admin panel posts the picked file
// here (multer memoryStorage, image/* only, 5MB cap enforced at the route)
// and gets back a dataUrl it can preview and save onto a slider row.
export const uploadSliderImage = async (req, res) => {
    if (!req.file) {
        return res.status(400).json({ success: false, error: 'No file uploaded' });
    }
    const dataUrl = `data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}`;
    return res.json({
        success: true,
        name: req.file.originalname,
        size: req.file.size,
        dataUrl,
    });
};

// Owner table: every tile of both sections, disabled ones included.
export const listSliders = async (req, res) => {
    try {
        const sliders = await HomeSlider.findAll({ order: LIST_ORDER });
        return res.json({ success: true, data: sliders.map(withImgUrl(req)) });
    } catch (error) {
        console.error('home-slider list error:', error);
        return res.status(500).json({ success: false, error: 'Failed to load home sliders.' });
    }
};

// Add a tile. It lands at the END of its section's strip, where the owner can
// then move it up — casinoManageController.createGame does the same.
export const createSlider = async (req, res) => {
    try {
        const section = req.body.section;
        if (!VALID_SECTIONS.includes(section)) {
            return res.status(400).json({ success: false, error: `section must be one of ${VALID_SECTIONS.join(', ')}.` });
        }
        const title = String(req.body.title || '').trim();
        if (!title || title.length > 80) {
            return res.status(400).json({ success: false, error: 'title must be 1–80 characters.' });
        }
        const route = String(req.body.route || '').trim();
        if (!isValidRoute(route)) {
            return res.status(400).json({ success: false, error: 'route must be an app path like /casino/teen20.' });
        }
        if (!req.body.img || !isValidImg(req.body.img)) {
            return res.status(400).json({ success: false, error: 'img must be a filename, http(s) URL, or base64 image data URI (≤8MB).' });
        }

        const maxOrder = await HomeSlider.max('sort_order', { where: { section } });
        const sortOrder = Number.isFinite(maxOrder) ? maxOrder + 1 : 0;

        const slider = await HomeSlider.create({
            section,
            title,
            route,
            img: req.body.img,
            enabled: req.body.enabled === false ? false : true,
            sort_order: sortOrder,
        });
        return res.status(201).json({ success: true, data: withImgUrl(req)(slider) });
    } catch (error) {
        console.error('home-slider create error:', error);
        return res.status(500).json({ success: false, error: 'Failed to add the slider.' });
    }
};

// Single-row edit. Every field is a partial: the panel PUTs only what the
// owner actually changed, so an untouched img is never echoed back (the list
// API hands out a SERVING url, and saving that would overwrite the real
// image with a pointer to itself). section stays fixed — it's identity.
export const updateSlider = async (req, res) => {
    try {
        const slider = await HomeSlider.findByPk(req.params.id);
        if (!slider) {
            return res.status(404).json({ success: false, error: 'Slider not found.' });
        }

        const updates = {};
        if (typeof req.body.enabled === 'boolean') {
            updates.enabled = req.body.enabled;
        }
        if (req.body.title !== undefined) {
            const title = String(req.body.title).trim();
            if (!title || title.length > 80) {
                return res.status(400).json({ success: false, error: 'title must be 1–80 characters.' });
            }
            updates.title = title;
        }
        if (req.body.route !== undefined) {
            const route = String(req.body.route).trim();
            if (!isValidRoute(route)) {
                return res.status(400).json({ success: false, error: 'route must be an app path like /casino/teen20.' });
            }
            updates.route = route;
        }
        if (req.body.img !== undefined) {
            if (!isValidImg(req.body.img)) {
                return res.status(400).json({ success: false, error: 'img must be a filename, http(s) URL, or base64 image data URI (≤8MB).' });
            }
            updates.img = req.body.img;
        }
        if (Object.keys(updates).length === 0) {
            return res.status(400).json({ success: false, error: 'Nothing to update.' });
        }

        await slider.update(updates);
        return res.json({ success: true, data: withImgUrl(req)(slider) });
    } catch (error) {
        console.error('home-slider update error:', error);
        return res.status(500).json({ success: false, error: 'Failed to update the slider.' });
    }
};

// Rearrange one section's strip. The panel shows a single section at a time
// and posts that tab's ids in their new order; position = index in the array.
// Scoped to a section on purpose: reordering New Games must never renumber
// Our Casino, so ids are verified to belong to the posted section before
// anything is written. Modelled on casinoManageController.reorderGames.
export const reorderSliders = async (req, res) => {
    try {
        const { section, order } = req.body;

        if (!VALID_SECTIONS.includes(section)) {
            return res.status(400).json({ success: false, error: `section must be one of ${VALID_SECTIONS.join(', ')}.` });
        }
        if (!Array.isArray(order) || order.length === 0 || order.some((id) => !Number.isInteger(Number(id)))) {
            return res.status(400).json({ success: false, error: 'order must be a non-empty array of slider ids.' });
        }
        const ids = order.map(Number);
        if (new Set(ids).size !== ids.length) {
            return res.status(400).json({ success: false, error: 'order must not repeat an id.' });
        }

        // Every id has to be a row of THIS section. A short count means the
        // payload carried an unknown id or one from the other strip — reject
        // the whole thing rather than half-applying it.
        const rows = await HomeSlider.findAll({ where: { id: ids, section }, attributes: ['id'] });
        if (rows.length !== ids.length) {
            return res.status(400).json({ success: false, error: `order must contain only ids from the '${section}' section.` });
        }

        await Promise.all(
            ids.map((id, index) => HomeSlider.update({ sort_order: index }, { where: { id } }))
        );

        const sliders = await HomeSlider.findAll({ where: { section }, order: LIST_ORDER });
        return res.json({ success: true, data: sliders.map(withImgUrl(req)) });
    } catch (error) {
        console.error('home-slider reorder error:', error);
        return res.status(500).json({ success: false, error: 'Failed to reorder the sliders.' });
    }
};

// Delete a tile outright. The enable toggle is the reversible option; this is
// for art that is never coming back.
export const deleteSlider = async (req, res) => {
    try {
        const slider = await HomeSlider.findByPk(req.params.id);
        if (!slider) {
            return res.status(404).json({ success: false, error: 'Slider not found.' });
        }
        await slider.destroy();
        return res.json({ success: true, message: 'Slider deleted successfully' });
    } catch (error) {
        console.error('home-slider delete error:', error);
        return res.status(500).json({ success: false, error: 'Failed to delete the slider.' });
    }
};

// Frontend list. Public, but the strips only render after login anyway.
// Disabled rows are filtered out here (unlike casino-manage, which ships
// them so the grid can hide a game): nothing downstream needs to know a
// banner exists but is switched off.
export const listPublicSliders = async (req, res) => {
    try {
        const sliders = await HomeSlider.findAll({
            where: { enabled: true },
            // updatedAt rides along purely to version the image url (publicImgFor).
            attributes: ['id', 'section', 'title', 'route', 'img', 'sort_order', 'updatedAt'],
            order: LIST_ORDER,
        });
        return res.json({ success: true, data: sliders.map(withImgUrl(req)) });
    } catch (error) {
        console.error('home-slider public list error:', error);
        return res.status(500).json({ success: false, error: 'Failed to load home sliders.' });
    }
};
