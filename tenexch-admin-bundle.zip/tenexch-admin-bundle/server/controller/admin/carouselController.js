import Carousel from '../../model/admin/Carousel.js'; // Adjust the path as needed

// Shape a DB row into the public payload:
// sports     -> { img, category, sports: { sportId, eventId } }
// casino     -> { img, category, casino: { gameName } }
// thirdparty -> { img, category, thirdParty: { gameUid } }
// others     -> { img, category }
const formatCarousel = (item) => {
    const base = {
        id: item.carousel_id,
        img: item.image_url,
        category: item.category,
    };
    if (item.category === 'sports') {
        return { ...base, sports: { sportId: item.sport_id, eventId: item.event_id } };
    }
    if (item.category === 'casino') {
        return { ...base, casino: { gameName: item.game_name } };
    }
    if (item.category === 'thirdparty') {
        return { ...base, thirdParty: { gameUid: item.game_uid } };
    }
    return base;
};

const LIST_ORDER = [['sort_order', 'ASC'], ['carousel_id', 'ASC']];

// Validate a create/update body. Returns an error string, or null and fills `out`
// with the normalized column values.
const validateCarouselBody = (body, out) => {
    const { image_url, category, sport_id, event_id, game_name, game_uid } = body;

    if (!image_url || typeof image_url !== 'string' || !image_url.trim()) {
        return 'image_url is required';
    }

    if (!['sports', 'casino', 'others', 'thirdparty'].includes(category)) {
        return "category must be 'sports', 'casino', 'thirdparty' or 'others'";
    }

    if (category === 'sports' && (!sport_id || !event_id)) {
        return 'sport_id and event_id are required for sports category';
    }

    if (category === 'casino' && (!game_name || !String(game_name).trim())) {
        return 'game_name is required for casino category';
    }

    // A thirdparty banner with no id is indistinguishable from a working one
    // until someone taps it, so block it at write time.
    if (category === 'thirdparty' && (!game_uid || !String(game_uid).trim())) {
        return 'game_uid is required for thirdparty category';
    }

    out.image_url = image_url.trim();
    out.category = category;
    out.sport_id = category === 'sports' ? String(sport_id).trim() : null;
    out.event_id = category === 'sports' ? String(event_id).trim() : null;
    out.game_name = category === 'casino' ? String(game_name).trim() : null;
    out.game_uid = category === 'thirdparty' ? String(game_uid).trim() : null;
    return null;
};

const CarouselController = {
    // Create a new carousel entry (appended at the end of the display order)
    createCarousel: async (req, res) => {
        try {
            const values = {};
            const validationError = validateCarouselBody(req.body, values);
            if (validationError) {
                return res.status(400).json({ success: false, error: validationError });
            }

            const maxOrder = await Carousel.max('sort_order');
            values.sort_order = Number.isFinite(maxOrder) ? maxOrder + 1 : 0;

            const newCarousel = await Carousel.create(values);

            res.status(201).json({ success: true, data: newCarousel });
        } catch (error) {
            console.error('Error in createCarousel:', error);
            res.status(500).json({ success: false, error: error.message });
        }
    },

    // Update an existing carousel entry (all content fields; order is separate)
    updateCarousel: async (req, res) => {
        try {
            const { carousel_id } = req.params;

            const carousel = await Carousel.findOne({ where: { carousel_id } });
            if (!carousel) {
                return res.status(404).json({ success: false, error: 'Carousel not found' });
            }

            const values = {};
            const validationError = validateCarouselBody(req.body, values);
            if (validationError) {
                return res.status(400).json({ success: false, error: validationError });
            }

            await carousel.update(values);

            res.status(200).json({ success: true, data: carousel });
        } catch (error) {
            console.error('Error in updateCarousel:', error);
            res.status(500).json({ success: false, error: error.message });
        }
    },

    // Rearrange display order: body { order: [carousel_id, ...] } first-to-last
    reorderCarousels: async (req, res) => {
        try {
            const { order } = req.body;

            if (!Array.isArray(order) || order.length === 0 || order.some((id) => !Number.isInteger(Number(id)))) {
                return res.status(400).json({ success: false, error: 'order must be a non-empty array of carousel ids' });
            }

            await Promise.all(
                order.map((id, index) =>
                    Carousel.update({ sort_order: index }, { where: { carousel_id: id } })
                )
            );

            const carousels = await Carousel.findAll({ order: LIST_ORDER });

            res.status(200).json({ success: true, data: carousels });
        } catch (error) {
            console.error('Error in reorderCarousels:', error);
            res.status(500).json({ success: false, error: error.message });
        }
    },

    // Admin list: raw rows for the management table
    getAllCarousels: async (req, res) => {
        try {
            const carousels = await Carousel.findAll({ order: LIST_ORDER });

            res.status(200).json({ success: true, data: carousels });
        } catch (error) {
            console.error('Error in getAllCarousels:', error);
            res.status(500).json({ success: false, error: error.message });
        }
    },

    // Public list: formatted payload consumed by the frontend carousel
    getPublicCarousels: async (req, res) => {
        try {
            const carousels = await Carousel.findAll({ order: LIST_ORDER });

            res.status(200).json({ success: true, data: carousels.map(formatCarousel) });
        } catch (error) {
            console.error('Error in getPublicCarousels:', error);
            res.status(500).json({ success: false, error: error.message });
        }
    },

    // Delete a carousel entry by carousel_id
    deleteCarousel: async (req, res) => {
        try {
            const { carousel_id } = req.params;

            const carousel = await Carousel.findOne({
                where: { carousel_id },
            });

            if (!carousel) {
                return res.status(404).json({ success: false, error: 'Carousel not found' });
            }

            await carousel.destroy();

            res.status(200).json({ success: true, message: 'Carousel deleted successfully' });
        } catch (error) {
            console.error('Error in deleteCarousel:', error);
            res.status(500).json({ success: false, error: error.message });
        }
    },
};

export default CarouselController;
