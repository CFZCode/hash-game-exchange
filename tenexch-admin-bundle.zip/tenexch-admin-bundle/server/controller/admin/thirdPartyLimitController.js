import { Op } from 'sequelize';
import Staff from '../../model/admin/Staff.js';
import User from '../../model/user/User.js';
import Owner from '../../model/admin/Owner.js';
import ThirdPartyLimitService, { holderKey } from '../../services/ThirdPartyLimitService.js';

// Third Party Game Limit — owner-only screen.
//
// Lists the logged-in owner's DIRECT downline (staff + users) with, per row,
// the limit set on that row itself and the limit that is actually in force
// (inherited from the nearest ancestor that has one). A staff row can be
// drilled into with ?parentId=<staff_id>, exactly like the Users page.
//
// Every route here is behind authMiddleware + requireOwner, so req.user.account
// is always the OWNER actor and no staff/executive can reach these handlers.

const STAFF_ROW_ATTRS = ['staff_id', 'username', 'role', 'level', 'active'];
const USER_ROW_ATTRS = ['user_id', 'username', 'status'];

// Is this staff inside the logged-in owner's tree? Every staff row carries the
// root owner id (deep ones included — verified on prod data), so this is one
// read regardless of depth. Same rule userController's drill-down uses.
const staffBelongsToOwner = (staff, ownerId) =>
    !!staff && Number(staff.parent_owner_id) === Number(ownerId);

const usernameFilter = (search) =>
    search ? { username: { [Op.iLike]: `%${search}%` } } : {};

/**
 * GET /api/admin/third-party-limit/list
 * Query: page, limit, search, parentId (drill-down into one of my staff)
 */
const listDownline = async (req, res) => {
    try {
        const ownerId = Number(req.user.account.id);
        const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
        const pageSize = Math.min(Math.max(parseInt(req.query.limit, 10) || 50, 1), 200);
        const offset = (page - 1) * pageSize;
        const search = (req.query.search || '').trim();
        const parentId = req.query.parentId ? parseInt(req.query.parentId, 10) : null;

        // ── Scope: whose direct children are we listing? ────────────────────
        let parentNode; // { type, id, username, label }
        let staffWhere;
        let userWhere;

        if (parentId) {
            const targetStaff = await Staff.findByPk(parentId, {
                attributes: ['staff_id', 'username', 'role', 'parent_owner_id'],
                raw: true,
            });
            if (!targetStaff) {
                return res.status(404).json({ success: false, message: 'Staff not found' });
            }
            if (!staffBelongsToOwner(targetStaff, ownerId)) {
                return res.status(403).json({ success: false, message: 'Unauthorized access to this downline' });
            }
            parentNode = {
                type: 'STAFF',
                id: targetStaff.staff_id,
                username: targetStaff.username,
                label: targetStaff.role,
            };
            staffWhere = { parent_id: parentId };
            userWhere = { parent_staff_id: parentId };
        } else {
            const owner = await Owner.findByPk(ownerId, { attributes: ['owner_id', 'username'], raw: true });
            parentNode = {
                type: 'OWNER',
                id: ownerId,
                username: owner?.username || 'Owner',
                label: 'OWNER',
            };
            // Owner ke seedha neeche wale — parent_id null wale hi direct hain,
            // baaki deep staff bhi parent_owner_id carry karte hain.
            staffWhere = { parent_owner_id: ownerId, parent_id: null };
            userWhere = { parent_owner_id: ownerId, parent_staff_id: null };
        }

        staffWhere = { ...staffWhere, ...usernameFilter(search) };
        userWhere = { ...userWhere, ...usernameFilter(search) };

        // ── One page across [staff…, users…] ────────────────────────────────
        const [staffCount, userCount] = await Promise.all([
            Staff.count({ where: staffWhere }),
            User.count({ where: userWhere }),
        ]);

        const staffRows = offset < staffCount
            ? await Staff.findAll({
                where: staffWhere,
                attributes: STAFF_ROW_ATTRS,
                order: [['username', 'ASC']],
                offset,
                limit: pageSize,
                raw: true,
            })
            : [];

        const remaining = pageSize - staffRows.length;
        const userRows = remaining > 0
            ? await User.findAll({
                where: userWhere,
                attributes: USER_ROW_ATTRS,
                order: [['username', 'ASC']],
                offset: Math.max(0, offset - staffCount),
                limit: remaining,
                raw: true,
            })
            : [];

        // ── Limits ──────────────────────────────────────────────────────────
        // The parent's effective limit is what every row inherits unless it has
        // its own, so one chain walk covers the whole page.
        const [limitMap, parentEffective] = await Promise.all([
            ThirdPartyLimitService.getLimitMap(),
            ThirdPartyLimitService.getEffectiveForHolder(parentNode.type, parentNode.id),
        ]);

        const rowFor = (type, id, username, role, active) => {
            const ownLimit = limitMap[holderKey(type, id)] || 0;
            return {
                holder_type: type,
                holder_id: id,
                username,
                role,
                active,
                // What the owner typed on THIS row (0 = nothing set here).
                own_limit: ownLimit,
                // What actually applies to this account's bets right now.
                effective_limit: ownLimit > 0 ? ownLimit : parentEffective,
                // True when the number shown comes from an ancestor.
                inherited: ownLimit <= 0 && parentEffective > 0,
            };
        };

        const rows = [
            ...staffRows.map((s) => rowFor('STAFF', s.staff_id, s.username, s.role, s.active !== false)),
            ...userRows.map((u) => rowFor('USER', u.user_id, u.username, 'USER', u.status === 'Active')),
        ];

        return res.json({
            success: true,
            // The node the list hangs off. Its own_limit is the "apply to my
            // whole hierarchy" box at the top of the screen.
            parent: {
                ...parentNode,
                own_limit: limitMap[holderKey(parentNode.type, parentNode.id)] || 0,
                effective_limit: parentEffective,
            },
            data: rows,
            pagination: {
                page,
                limit: pageSize,
                total: staffCount + userCount,
                totalPages: Math.ceil((staffCount + userCount) / pageSize) || 1,
            },
        });
    } catch (error) {
        console.error('listDownline (third-party limit) error:', error);
        return res.status(500).json({ success: false, message: 'Failed to load third party game limits' });
    }
};

/**
 * POST /api/admin/third-party-limit/set
 * Body: { holder_type: 'OWNER'|'STAFF'|'USER', holder_id, max_amount }
 * max_amount 0 clears the row, so that node inherits from above again.
 */
const saveLimit = async (req, res) => {
    try {
        const ownerId = Number(req.user.account.id);
        const holderType = String(req.body.holder_type || '').toUpperCase();
        const holderId = Number(req.body.holder_id);
        const maxAmount = Number(req.body.max_amount);

        if (!['OWNER', 'STAFF', 'USER'].includes(holderType)) {
            return res.status(400).json({ success: false, message: 'Invalid holder_type' });
        }
        if (!Number.isInteger(holderId) || holderId <= 0) {
            return res.status(400).json({ success: false, message: 'Invalid holder_id' });
        }
        if (!Number.isFinite(maxAmount) || maxAmount < 0) {
            return res.status(400).json({ success: false, message: 'Max amount must be 0 or more' });
        }

        // ── Ownership: the target must live in MY tree ──────────────────────
        if (holderType === 'OWNER') {
            if (holderId !== ownerId) {
                return res.status(403).json({ success: false, message: 'Cannot set a limit for another owner' });
            }
        } else if (holderType === 'STAFF') {
            const staff = await Staff.findByPk(holderId, {
                attributes: ['staff_id', 'parent_owner_id'],
                raw: true,
            });
            if (!staff) return res.status(404).json({ success: false, message: 'Staff not found' });
            if (!staffBelongsToOwner(staff, ownerId)) {
                return res.status(403).json({ success: false, message: 'This account is not in your hierarchy' });
            }
        } else {
            const user = await User.findByPk(holderId, {
                attributes: ['user_id', 'parent_staff_id', 'parent_owner_id'],
                raw: true,
            });
            if (!user) return res.status(404).json({ success: false, message: 'User not found' });

            let inScope = Number(user.parent_owner_id) === ownerId;
            if (!inScope && user.parent_staff_id) {
                const parentStaff = await Staff.findByPk(user.parent_staff_id, {
                    attributes: ['staff_id', 'parent_owner_id'],
                    raw: true,
                });
                inScope = staffBelongsToOwner(parentStaff, ownerId);
            }
            if (!inScope) {
                return res.status(403).json({ success: false, message: 'This account is not in your hierarchy' });
            }
        }

        const saved = await ThirdPartyLimitService.setLimit({
            holderType,
            holderId,
            maxAmount,
            setByType: 'OWNER',
            setById: ownerId,
        });

        // Recomputed AFTER the cache drop, so the screen shows the number that
        // is actually live now (own value, or what it fell back to on a clear).
        const effective = await ThirdPartyLimitService.getEffectiveForHolder(holderType, holderId);

        return res.json({
            success: true,
            message: saved > 0
                ? `Limit set to ${saved} for this account and everyone below it`
                : 'Limit cleared — this account now follows the limit set above it',
            data: {
                holder_type: holderType,
                holder_id: holderId,
                own_limit: saved,
                effective_limit: effective,
                inherited: saved <= 0 && effective > 0,
            },
        });
    } catch (error) {
        console.error('saveLimit (third-party limit) error:', error);
        return res.status(500).json({ success: false, message: error.message || 'Failed to save limit' });
    }
};

export default { listDownline, saveLimit };
