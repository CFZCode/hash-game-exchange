import axios from 'axios';

// Basic IPv4 / IPv6 shape check — enough to keep arbitrary strings from
// being forwarded to the upstream geo service.
const IP_REGEX = /^([0-9]{1,3}\.){3}[0-9]{1,3}$|^[0-9a-fA-F:]+$/;

const IpDetailController = {
  // GET /api/admin/ip-detail?ip=<ip>
  // Backend proxy for the User History "Detail" (eye) modal — the free
  // ip-api.com tier is HTTP-only, so the browser can't call it from an
  // HTTPS page; the server fetches and returns just the 4 fields the
  // modal shows: { ip, city, country, mobile }.
  getIpDetail: async (req, res) => {
    try {
      const ip = String(req.query.ip || '').trim();
      if (!ip || !IP_REGEX.test(ip)) {
        return res.status(400).json({ success: false, message: 'Valid ip query param is required' });
      }

      const { data } = await axios.get(
        `http://ip-api.com/json/${encodeURIComponent(ip)}`,
        { params: { fields: 'status,message,country,city,mobile,query' }, timeout: 7000 }
      );

      if (!data || data.status !== 'success') {
        // Private/reserved ranges land here too — return placeholders so the
        // modal still renders instead of erroring.
        return res.status(200).json({
          success: true,
          data: { ip, city: '-', country: '-', mobile: false },
          message: data?.message || 'lookup failed',
        });
      }

      return res.status(200).json({
        success: true,
        data: {
          ip: data.query || ip,
          city: data.city || '-',
          country: data.country || '-',
          mobile: !!data.mobile,
        },
      });
    } catch (error) {
      console.error('❌ getIpDetail error:', error.message);
      return res.status(500).json({ success: false, error: error.message });
    }
  },
};

export default IpDetailController;
