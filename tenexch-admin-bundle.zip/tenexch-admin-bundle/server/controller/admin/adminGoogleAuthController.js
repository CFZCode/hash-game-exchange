/**
 * Google Authenticator (TOTP) secure auth for OWNER / STAFF accounts.
 *
 * The admin twin of controller/user/googleAuthController.js. Same three steps,
 * same shared GoogleAuthService — only the principal lookup differs, because an
 * admin token resolves to an Owner or a Staff row rather than a User.
 *
 *   1. POST /admin/secure-auth/google/setup   { password } → QR + setup code
 *   2. POST /admin/secure-auth/google/enable  { otp }      → securityAuthType = 'google'
 *   3. POST /admin/secure-auth/google/disable { otp }      → securityAuthType = null
 *
 * Login-time verification lives in staffAuthService/ownerAuthService.verify2FA,
 * so the client keeps using the single verify-2fa endpoint per role.
 */
import Staff from '../../model/admin/Staff.js';
import Owner from '../../model/admin/Owner.js';
import GoogleAuthService from '../../services/user/GoogleAuthService.js';
import PasswordService from '../../services/passwordService.js';
import { MESSAGES } from '../../constants/messages.js';

const ISSUER = (process.env.PROJECT_NAME || 'TENEXCH').toUpperCase();

/**
 * Resolve the admin principal from the token.
 *
 * Same rules as telegram2faController.getUserModelAndId: switch on
 * `account.type` (every principal has an `account.id`, so a truthiness check
 * would match the wrong model), and refuse EXECUTIVE — an executive acts AS its
 * parent, but secure auth belongs to the account itself.
 */
const resolvePrincipal = async (req) => {
    if (req.user?.actor?.type === 'EXECUTIVE') return null;

    const type = req.user?.account?.type;
    const id = req.user?.account?.id;
    if (!id) return null;

    if (type === 'STAFF') return { account: await Staff.findByPk(id), label: 'staff' };
    if (type === 'OWNER') return { account: await Owner.findByPk(id), label: 'owner' };
    return null;
};

const AdminGoogleAuthController = {
    // 1️⃣ Password check → issue a fresh secret + QR
    setup: async (req, res) => {
        try {
            const { password } = req.body;
            if (!password) return res.status(400).json({ success: false, error: MESSAGES.VALIDATION.PASSWORD_REQUIRED });

            const principal = await resolvePrincipal(req);
            if (!principal) return res.status(401).json({ success: false, error: 'Unauthorized' });
            const { account } = principal;
            if (!account) return res.status(404).json({ success: false, error: MESSAGES.ADMIN.AUTH.ACCOUNT_NOT_AVAILABLE });

            const isMatch = await PasswordService.comparePassword(password, account.password);
            // Reference-site wording, same as the Telegram verify-password step.
            if (!isMatch) return res.status(400).json({ success: false, error: 'User Password Not Valid.' });

            // One method at a time — never layer Google on top of a live
            // Telegram link (or vice versa).
            if (account.securityAuthType || account.telegram2FAEnabled) {
                return res.status(400).json({ success: false, error: MESSAGES.AUTH.SECURE_AUTH_ALREADY_ENABLED });
            }

            // A fresh secret per attempt: an abandoned QR can never be used
            // later, because the next attempt overwrites it.
            const secret = GoogleAuthService.generateSecret();
            const otpAuthUrl = GoogleAuthService.buildOtpAuthUrl(secret, account.username, ISSUER);
            const qrCode = await GoogleAuthService.buildQrDataUrl(otpAuthUrl);

            account.googleAuthSecret = secret;
            await account.save();

            return res.status(200).json({
                success: true,
                message: MESSAGES.AUTH.GOOGLE_AUTH_SETUP_READY,
                qrCode,          // PNG data URI for <img src>
                secret,          // "Setup Code" for manual entry
                otpAuthUrl,
            });
        } catch (error) {
            console.error('❌ Admin Google Auth setup error:', error);
            return res.status(500).json({ success: false, error: 'Server error' });
        }
    },

    // 2️⃣ Confirm the app is in sync, then switch the account over
    enable: async (req, res) => {
        try {
            const { otp } = req.body;
            if (!otp) return res.status(400).json({ success: false, error: MESSAGES.AUTH.GOOGLE_AUTH_CODE_REQUIRED });

            const principal = await resolvePrincipal(req);
            if (!principal) return res.status(401).json({ success: false, error: 'Unauthorized' });
            const { account, label } = principal;
            if (!account) return res.status(404).json({ success: false, error: MESSAGES.ADMIN.AUTH.ACCOUNT_NOT_AVAILABLE });

            if (!account.googleAuthSecret) {
                return res.status(400).json({ success: false, error: MESSAGES.AUTH.GOOGLE_AUTH_NOT_SETUP });
            }
            if (account.securityAuthType) {
                return res.status(400).json({ success: false, error: MESSAGES.AUTH.SECURE_AUTH_ALREADY_ENABLED });
            }

            if (!GoogleAuthService.verifyToken(account.googleAuthSecret, otp)) {
                return res.status(400).json({ success: false, error: MESSAGES.AUTH.GOOGLE_AUTH_INVALID_CODE });
            }

            account.securityAuthType = 'google';
            await account.save();

            console.log(`✅ Google Auth enabled for ${label} ${account.username}`);
            return res.status(200).json({ success: true, message: MESSAGES.AUTH.GOOGLE_AUTH_ENABLED });
        } catch (error) {
            console.error('❌ Admin Google Auth enable error:', error);
            return res.status(500).json({ success: false, error: 'Server error' });
        }
    },

    // 3️⃣ Turn it off — still requires a live code from the app
    disable: async (req, res) => {
        try {
            const { otp } = req.body;
            if (!otp) return res.status(400).json({ success: false, error: MESSAGES.AUTH.GOOGLE_AUTH_CODE_REQUIRED });

            const principal = await resolvePrincipal(req);
            if (!principal) return res.status(401).json({ success: false, error: 'Unauthorized' });
            const { account, label } = principal;
            if (!account) return res.status(404).json({ success: false, error: MESSAGES.ADMIN.AUTH.ACCOUNT_NOT_AVAILABLE });

            if (account.securityAuthType !== 'google' || !account.googleAuthSecret) {
                return res.status(400).json({ success: false, error: MESSAGES.AUTH.GOOGLE_AUTH_NOT_ENABLED });
            }

            if (!GoogleAuthService.verifyToken(account.googleAuthSecret, otp)) {
                return res.status(400).json({ success: false, error: MESSAGES.AUTH.GOOGLE_AUTH_INVALID_CODE });
            }

            account.securityAuthType = null;
            account.googleAuthSecret = null;
            await account.save();

            console.log(`🛑 Google Auth disabled for ${label} ${account.username}`);
            return res.status(200).json({ success: true, message: MESSAGES.AUTH.GOOGLE_AUTH_DISABLED });
        } catch (error) {
            console.error('❌ Admin Google Auth disable error:', error);
            return res.status(500).json({ success: false, error: 'Server error' });
        }
    },
};

export default AdminGoogleAuthController;
