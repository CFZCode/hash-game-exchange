import Transaction from '../../model/admin/Transaction.js';
import Wallet from '../../model/admin/Wallet.js';
import PointLedger from '../../model/admin/PointLedger.js';
import User from '../../model/user/User.js';
import Staff from '../../model/admin/Staff.js';
import Owner from '../../model/admin/Owner.js';
import CreditsLedger from '../../model/user/CreditsLedger.js';
import TransactionReportService from '../../services/TransactionReportService.js';
import { Op } from 'sequelize';

import sequelize from '../../config/db.js';
import { getUserIdsByHierarchy } from './userController.js';
import SportsBet from '../../model/user/SportsBet.js';
import CasinoBet from '../../model/user/casino.js';
import UserExposure from '../../model/user/UserExposure.js';
import { isMeterMarket } from '../../helper/meterMarket.js';
import { isLineMarket } from '../../helper/lineMarket.js';
import { isBadloBet } from '../../helper/badloMarket.js';
import { loadFanSettlementNet } from '../../services/statement/StatementBuilder.js';
import { toNaiveLocalTime } from '../../helper/naiveLocalTime.js';
import { isFancyMarket } from '../../systemTracker/sportsRule.js';
import UserActivityLog from '../../model/admin/UserActivityLog.js';
import Affiliate from '../../model/admin/Affiliate.js';
import { getSportNameById } from '../../utils/sportsNames.js';
import { buildStatementBetExport, buildStatementBetDetail } from '../../services/admin/statementBetExportService.js';
import { getCasinoRoundBets } from '../../services/admin/casinoRoundBetsService.js';

/**
 * user_exposures carries three bookkeeping rows per fancy selection alongside the
 * real one: `{sel}back`, `{sel}lay` and `{sel}totalstake`. They are internal
 * accounting keys, not runners, and every other consumer already excludes them —
 * sportbetscontroller.js, betresult/settlementv2.js, and systemTracker/scanner.js
 * (where the same predicate is named NOT_BACKLAY). Market Analysis was the one
 * place that forgot, so every fancy block rendered four rows per selection instead
 * of one and looked nothing like the reference page.
 */
const EXCLUDE_HELPER_KEYS = {
  [Op.and]: [
    { team_name: { [Op.notILike]: '%back' } },
    { team_name: { [Op.notILike]: '%lay' } },
    { team_name: { [Op.notILike]: '%totalstake' } },
  ],
};

/**
 * All descendant STAFF ids under the logged-in admin (self included for
 * staff roles). Mirrors getUserIdsByHierarchy but returns staff ids, so
 * the history endpoints can scope STAFF targets too — not just USERs.
 */
const getDownlineStaffIds = async (role, username) => {
  const upperRole = (role || '').toUpperCase();

  let queue = [];
  if (upperRole === 'OWNER') {
    const owner = await Owner.findOne({ where: { username }, attributes: ['owner_id'], raw: true });
    if (!owner) return [];
    const topStaff = await Staff.findAll({
      where: { parent_owner_id: owner.owner_id },
      attributes: ['staff_id'],
      raw: true,
    });
    queue = topStaff.map(s => s.staff_id);
  } else {
    const staff = await Staff.findOne({ where: { username }, attributes: ['staff_id'], raw: true });
    if (!staff) return [];
    queue = [staff.staff_id];
  }

  const allIds = [];
  while (queue.length) {
    allIds.push(...queue);
    const children = await Staff.findAll({
      where: { parent_id: { [Op.in]: queue } },
      attributes: ['staff_id'],
      raw: true,
    });
    queue = children.map(c => c.staff_id);
  }
  return allIds;
};

/**
 * Resolve a username to a USER or STAFF account and enforce that it falls
 * inside the logged-in admin's hierarchy.
 * Returns { type, id, username } or { error: 'not_found' | 'not_downline' }.
 */
const resolveHistoryTarget = async (req, targetUsername) => {
  const role = req.user?.role;
  const loggedInUsername = req.user?.username;
  const name = targetUsername.trim();

  const user = await User.findOne({
    where: { username: { [Op.iLike]: name } },
    attributes: ['user_id', 'username'],
    raw: true,
  });
  if (user) {
    const downlineUserIds = await getUserIdsByHierarchy(role, loggedInUsername);
    if (!downlineUserIds.map(Number).includes(Number(user.user_id))) {
      return { error: 'not_downline' };
    }
    return { type: 'USER', id: user.user_id, username: user.username };
  }

  const staff = await Staff.findOne({
    where: { username: { [Op.iLike]: name } },
    attributes: ['staff_id', 'username'],
    raw: true,
  });
  if (staff) {
    const downlineStaffIds = await getDownlineStaffIds(role, loggedInUsername);
    if (!downlineStaffIds.map(Number).includes(Number(staff.staff_id))) {
      return { error: 'not_downline' };
    }
    return { type: 'STAFF', id: staff.staff_id, username: staff.username };
  }

  // OWNER ka apna account: owner koi staff/user row nahi hai, isliye upar ke dono
  // lookups miss karte the aur owner ko apni hi history "User not found" milti thi.
  // user_activity_logs me owner logins owner_id + user_type 'OWNER' se padte hain.
  // Sirf KHUD ka account — kisi doosre owner ki history alag hierarchy hai.
  const owner = await Owner.findOne({
    where: { username: { [Op.iLike]: name } },
    attributes: ['owner_id', 'username'],
    raw: true,
  });
  if (owner) {
    const isSelf =
      req.user?.account?.type === 'OWNER' &&
      String(loggedInUsername || '').toLowerCase() === String(owner.username).toLowerCase();
    if (!isSelf) {
      return { error: 'not_downline' };
    }
    return { type: 'OWNER', id: owner.owner_id, username: owner.username };
  }

  return { error: 'not_found' };
};

// ip_address is stored raw from x-forwarded-for ("client, proxy1, ...")
// or the socket ("::ffff:1.2.3.4") — reduce to the plain client IP.
const normalizeIp = (raw) => {
  if (!raw) return '';
  return String(raw).split(',')[0].trim().replace(/^::ffff:/i, '');
};

// frontend se gtype "Match"/"Fancy" aata hai, DB me lowercase ("match") store hota hai
const normalizeGtype = (val) => String(val || '').trim().toLowerCase();



// point_ledger.category → report column mapping (Wallet ke *_pts counters jaisa)
const POINT_CATEGORY_FIELD = {
  CASINO: 'casino_pts',
  SPORTS: 'sports_pts',
  THIRD_PARTY: 'thirdparty_pts',
  SPORTSBOOK: 'sportsbook_pts',
};

const ReportsController = {
  // Category-wise point report — point_ledger se hierarchy ke users ki
  // SUM(delta) per category. clientName = downline staff → uski hierarchy,
  // ya single user. delta signed hai (jeet +, haar −), SUM hi net deta hai.
  getPointCategoryReport: async (req, res) => {
    try {
      const { clientName, fromDate, toDate } = req.body;
      const role = (req.user?.role || '').toUpperCase();
      const username = req.user?.username;

      const emptyTotals = () => ({
        casino_pts: 0, sports_pts: 0, thirdparty_pts: 0, sportsbook_pts: 0, total: 0,
      });

      // Logged-in admin ki poori hierarchy — security boundary bhi yahi hai
      const hierarchyUserIds = await getUserIdsByHierarchy(role, username);
      if (!hierarchyUserIds || hierarchyUserIds.length === 0) {
        return res.status(200).json({ success: true, data: [], totals: emptyTotals() });
      }

      let userIds = hierarchyUserIds;

      if (clientName && clientName !== 'all') {
        const name = String(clientName).trim();

        // Pehle staff — uski apni hierarchy ke users; warna single user
        const staff = await Staff.findOne({
          where: { username: { [Op.iLike]: name } },
          attributes: ['staff_id', 'username', 'role'],
          raw: true,
        });

        if (staff) {
          const staffUserIds = await getUserIdsByHierarchy(staff.role || 'STAFF', staff.username);
          // Apni hierarchy ke bahar ka staff pass kar diya toh intersection khali rahega
          const allowed = new Set(hierarchyUserIds);
          userIds = staffUserIds.filter((id) => allowed.has(id));
        } else {
          const user = await User.findOne({
            where: { username: { [Op.iLike]: name } },
            attributes: ['user_id'],
            raw: true,
          });
          userIds = user && hierarchyUserIds.includes(user.user_id) ? [user.user_id] : [];
        }

        if (userIds.length === 0) {
          return res.status(200).json({ success: true, data: [], totals: emptyTotals() });
        }
      }

      // point_ledger wallet_id se likha jata hai — user ids ko wallet ids me map karo
      const wallets = await Wallet.findAll({
        where: { user_id: { [Op.in]: userIds } },
        attributes: ['wallet_id', 'user_id', 'username'],
        raw: true,
      });

      if (wallets.length === 0) {
        return res.status(200).json({ success: true, data: [], totals: emptyTotals() });
      }

      const walletMap = {};
      for (const w of wallets) walletMap[w.wallet_id] = w;

      const where = {
        wallet_id: { [Op.in]: wallets.map((w) => w.wallet_id) },
        category: { [Op.in]: Object.keys(POINT_CATEGORY_FIELD) },
      };
      if (fromDate && toDate) {
        where.created_at = {
          [Op.between]: [new Date(fromDate), new Date(toDate + 'T23:59:59.999Z')],
        };
      } else if (fromDate) {
        where.created_at = { [Op.gte]: new Date(fromDate) };
      } else if (toDate) {
        where.created_at = { [Op.lte]: new Date(toDate + 'T23:59:59.999Z') };
      }

      const sums = await PointLedger.findAll({
        attributes: [
          'wallet_id',
          'category',
          [sequelize.fn('SUM', sequelize.col('delta')), 'total_delta'],
        ],
        where,
        group: ['wallet_id', 'category'],
        raw: true,
      });

      const r2 = (v) => Math.round((parseFloat(v) || 0) * 100) / 100;

      const perUser = {};
      const totals = emptyTotals();

      for (const row of sums) {
        const wallet = walletMap[row.wallet_id];
        if (!wallet) continue;

        if (!perUser[wallet.user_id]) {
          perUser[wallet.user_id] = {
            user_id: wallet.user_id,
            username: wallet.username,
            ...emptyTotals(),
          };
        }

        const field = POINT_CATEGORY_FIELD[row.category];
        const amount = r2(row.total_delta);
        perUser[wallet.user_id][field] = r2(perUser[wallet.user_id][field] + amount);
        perUser[wallet.user_id].total = r2(perUser[wallet.user_id].total + amount);
        totals[field] = r2(totals[field] + amount);
        totals.total = r2(totals.total + amount);
      }

      const data = Object.values(perUser).sort((a, b) => b.total - a.total);

      return res.status(200).json({ success: true, data, totals });
    } catch (error) {
      console.error('❌ Get Point Category Report Error:', error);
      return res.status(500).json({ success: false, error: error.message });
    }
  },

  // User Registration Report — hierarchy ke users ki registration/login/deposit
  // detail + wallet ke category balances. clientName = staff → uska downline,
  // user → sirf wahi. type: 1=All, 2=Created Date, 3=Last Login Date (sort).
  getUserRegisterDetail: async (req, res) => {
    try {
      const { page = 1, limit = 25, username: clientParam, clientName: clientAlt, type = '1' } = req.query;
      const role = (req.user?.role || '').toUpperCase();
      const loginUsername = req.user?.username;

      const emptyResult = (p, l) => res.status(200).json({
        success: true, data: [],
        pagination: { total: 0, totalPages: 1, page: p, limit: l },
      });

      const p = Math.max(1, parseInt(page, 10) || 1);
      const l = Math.min(200, Math.max(1, parseInt(limit, 10) || 25));

      const hierarchyUserIds = await getUserIdsByHierarchy(role, loginUsername);
      if (!hierarchyUserIds || hierarchyUserIds.length === 0) return emptyResult(p, l);

      let userIds = hierarchyUserIds;

      const clientName = String(clientParam || clientAlt || '').trim();
      if (clientName && clientName.toLowerCase() !== 'all') {
        const staff = await Staff.findOne({
          where: { username: { [Op.iLike]: clientName } },
          attributes: ['staff_id', 'username', 'role'],
          raw: true,
        });

        if (staff) {
          const staffUserIds = await getUserIdsByHierarchy(staff.role || 'STAFF', staff.username);
          const allowed = new Set(hierarchyUserIds);
          userIds = staffUserIds.filter((id) => allowed.has(id));
        } else {
          const target = await User.findOne({
            where: { username: { [Op.iLike]: clientName } },
            attributes: ['user_id'],
            raw: true,
          });
          userIds = target && hierarchyUserIds.includes(target.user_id) ? [target.user_id] : [];
        }

        if (userIds.length === 0) return emptyResult(p, l);
      }

      const users = await User.findAll({
        where: { user_id: { [Op.in]: userIds } },
        attributes: ['user_id', 'username', 'phone_number', 'parent_staff_id', 'parent_owner_id', 'createdAt'],
        raw: true,
      });
      if (users.length === 0) return emptyResult(p, l);

      const staffIds = [...new Set(users.map((u) => u.parent_staff_id).filter(Boolean))];
      const ownerIds = [...new Set(users.map((u) => u.parent_owner_id).filter(Boolean))];

      const [staffRows, ownerRows, wallets, logins, deposits, affiliates] = await Promise.all([
        staffIds.length
          ? Staff.findAll({ where: { staff_id: { [Op.in]: staffIds } }, attributes: ['staff_id', 'username'], raw: true })
          : [],
        ownerIds.length
          ? Owner.findAll({ where: { owner_id: { [Op.in]: ownerIds } }, attributes: ['owner_id', 'username'], raw: true })
          : [],
        Wallet.findAll({
          where: { user_id: { [Op.in]: userIds } },
          attributes: ['user_id', 'sports_pts', 'casino_pts', 'thirdparty_pts', 'sportsbook_pts'],
          raw: true,
        }),
        UserActivityLog.findAll({
          attributes: ['user_id', [sequelize.fn('MAX', sequelize.col('createdAt')), 'last_login']],
          where: { user_type: 'USER', action: 'LOGIN', user_id: { [Op.in]: userIds } },
          group: ['user_id'],
          raw: true,
        }),
        // ADD_CREDIT bhi deposit hai — user creation ka opening credit isi type se aata hai
        Transaction.findAll({
          attributes: [
            'user_id',
            [sequelize.fn('MIN', sequelize.col('createdAt')), 'first_dep'],
            [sequelize.fn('MAX', sequelize.col('createdAt')), 'last_dep'],
          ],
          where: { user_id: { [Op.in]: userIds }, type: { [Op.in]: ['DEPOSIT', 'ADD_CREDIT'] } },
          group: ['user_id'],
          raw: true,
        }),
        Affiliate.findAll({
          where: { user_id: { [Op.in]: userIds } },
          attributes: ['user_id', 'referral_code'],
          raw: true,
        }).catch(() => []),
      ]);

      const staffMap = Object.fromEntries(staffRows.map((s) => [s.staff_id, s.username]));
      const ownerMap = Object.fromEntries(ownerRows.map((o) => [o.owner_id, o.username]));
      const walletMap = Object.fromEntries(wallets.map((w) => [w.user_id, w]));
      const loginMap = Object.fromEntries(logins.map((r) => [r.user_id, r.last_login]));
      const depositMap = Object.fromEntries(deposits.map((r) => [r.user_id, r]));
      const affiliateMap = Object.fromEntries(affiliates.map((a) => [a.user_id, a.referral_code]));

      const r2 = (v) => Math.round((parseFloat(v) || 0) * 100) / 100;
      // "26/07/2026 03:09:30" — IST me
      const fmtDate = (d) => {
        if (!d) return '';
        return new Intl.DateTimeFormat('en-GB', {
          timeZone: 'Asia/Kolkata',
          day: '2-digit', month: '2-digit', year: 'numeric',
          hour: '2-digit', minute: '2-digit', second: '2-digit',
          hour12: false,
        }).format(new Date(d)).replace(',', '');
      };

      let rows = users.map((u) => {
        const w = walletMap[u.user_id] || {};
        const dep = depositMap[u.user_id] || {};
        return {
          user_id: u.user_id,
          username: u.username,
          agentName: staffMap[u.parent_staff_id] || ownerMap[u.parent_owner_id] || '',
          mobile: u.phone_number || '',
          createdDate: fmtDate(u.createdAt),
          lastLogin: fmtDate(loginMap[u.user_id]),
          firstDepositDate: fmtDate(dep.first_dep),
          lastDepositDate: fmtDate(dep.last_dep),
          deposit: 'No Deposit',
          sportsBalance: r2(w.sports_pts),
          casinoBalance: r2(w.casino_pts),
          thirdPartyCreditBalance: r2(w.thirdparty_pts),
          sportBookBalance: r2(w.sportsbook_pts),
          referralCode: affiliateMap[u.user_id] || '',
          // sort keys — response me bhi kaam aa sakte hain
          _createdAt: u.createdAt ? new Date(u.createdAt).getTime() : 0,
          _lastLogin: loginMap[u.user_id] ? new Date(loginMap[u.user_id]).getTime() : 0,
        };
      });

      if (String(type) === '3') {
        rows.sort((a, b) => b._lastLogin - a._lastLogin);
      } else {
        rows.sort((a, b) => b._createdAt - a._createdAt);
      }
      rows = rows.map(({ _createdAt, _lastLogin, ...rest }) => rest);

      const total = rows.length;
      const totalPages = Math.max(1, Math.ceil(total / l));
      const data = rows.slice((p - 1) * l, p * l);

      return res.status(200).json({
        success: true, data,
        pagination: { total, totalPages, page: p, limit: l },
      });
    } catch (error) {
      console.error('❌ Get User Register Detail Error:', error);
      return res.status(500).json({ success: false, error: error.message });
    }
  },

  getUserWinLoss: async (req, res) => {
    try {
      const { clientName, fromDate, toDate } = req.body;
      const role = req.user?.role?.toUpperCase();
      const username = req.user?.username;

      // Get all user IDs under hierarchy
      const userIds = await getUserIdsByHierarchy(role, username);

      if (!userIds || userIds.length === 0) {
        return res.status(200).json({ success: true, data: [] });
      }

      // If a specific client is selected, filter to that user only
      let filteredUserIds = userIds;
      if (clientName && clientName !== 'all') {
        const user = await User.findOne({
          where: { username: { [Op.iLike]: clientName } },
          attributes: ['user_id'],
          raw: true
        });
        if (!user || !userIds.includes(user.user_id)) {
          return res.status(200).json({ success: true, data: [] });
        }
        filteredUserIds = [user.user_id];
      }

      // Build date filter
      const dateFilter = {};
      if (fromDate && toDate) {
        dateFilter.created_at = {
          [Op.between]: [new Date(fromDate), new Date(toDate + 'T23:59:59.999Z')]
        };
      }

      const userMap = {};
      const ensure = (uid) => {
        if (!userMap[uid]) userMap[uid] = { SPORTS: 0, CASINO: 0, THIRD_PARTY_CASINO: 0 };
        return userMap[uid];
      };

      // ── SPORTS P/L ──
      // Derived directly from SportsBet table rather than CreditsLedger
      // profit/loss columns. Pre-fix settlement (commit 814e717) wrote
      // only ONE market-level ledger row per market using `winnerExposure`
      // from UserExposure — for mixed back+lay positions this lost the
      // offsetting legs, over/under-reporting P/L. SportsBet has every
      // settled bet with stake/odds/liability/result, so the per-bet
      // formula below mirrors settlement math and gives accurate totals
      // for both historical and future data.
      const sportsBetWhere = {
        user_id: { [Op.in]: filteredUserIds },
        fixed: 1,
        result_status: { [Op.in]: ['won', 'loss'] },
      };
      // Date filter uses placement time (created_at). updated_at is
      // unreliable because the 2026-04-22 `fixed=1` backfill commit
      // touched every historical row, pulling bets months old into
      // any recent window.
      if (fromDate && toDate) {
        sportsBetWhere.created_at = {
          [Op.between]: [new Date(fromDate), new Date(toDate + 'T23:59:59.999Z')]
        };
      }
      const sportsBets = await SportsBet.findAll({
        where: sportsBetWhere,
        attributes: ['id','user_id','stake_amount','liability','odds','size','bet_type','game_type','market_type','result_status'],
        raw: true,
      });
      // Settlement's own per-bet payout for FAN bets — meter and badlo price
      // off the RESULT runs, which this row does not carry, so the formula
      // below can never get those right on its own. Same loader the user
      // statement uses, so the two reports cannot drift apart.
      const fanNetPL = await loadFanSettlementNet(null, sportsBets);
      for (const b of sportsBets) {
        const stake = parseFloat(b.stake_amount) || 0;
        const liab  = parseFloat(b.liability)   || 0;
        const odds  = parseFloat(b.odds)        || 0;
        const size  = parseFloat(b.size)        || 0;
        const bt    = String(b.bet_type || '').toLowerCase();
        const gt    = String(b.game_type || '').toUpperCase();
        const mt    = String(b.market_type || '').toLowerCase();
        const res   = String(b.result_status || '').toLowerCase();
        const isBack = bt === 'back' || bt === 'yes';
        const isLay  = bt === 'lay'  || bt === 'no';

        let pl = 0;
        const ledgerNet = gt === 'FAN' ? fanNetPL.get(String(b.id)) : undefined;
        // Only meter/badlo/oddeven/fancy1 have a trustworthy settlement
        // netamount; every other FAN market re-derives from the formula below.
        // Settlement writes GROSS on a Tied-Match win and 0 on a loss, so
        // trusting netamount made the P/L report show 101 (not 1) and 0 (not
        // -100). Mirrors StatementBuilder.sportsNet — keep the two in step.
        const netFromLedger = gt === 'FAN'
          && (isMeterMarket(b.market_type) || isBadloBet(b) || mt === 'oddeven' || mt === 'fancy1');
        if (netFromLedger && ledgerNet != null && Number.isFinite(Number(ledgerNet))) {
          ensure(b.user_id).SPORTS += Math.round(Number(ledgerNet) * 100) / 100;
          continue;
        }
        if (res === 'won') {
          if (isBack) {
            if (gt === 'BM')                 pl = stake * (odds / 100);
            else if (mt === 'tied match')    pl = stake * (odds / 100);
            else if (gt === 'FAN') {
              // Mirrors StatementBuilder.sportsNet — keep the two in step.
              if (mt === 'fancy1')           pl = stake;
              // Line markets are EVENS both sides; they persist size 0 and put
              // the RUN LINE in `odds`, so the bhav fallback paid a winning
              // 100 on the 45-run line 45 instead of 100.
              else if (isLineMarket(b.market_type)) pl = stake;
              else pl = size > 0 ? stake * (size / 100) : stake * (odds / 100);
            }
            else                             pl = stake * (odds - 1);
          } else if (isLay) {
            pl = stake;
          }
        } else if (res === 'loss') {
          if (isBack)      pl = -stake;
          else if (isLay)  pl = -liab;
        }
        ensure(b.user_id).SPORTS += pl;
      }

      // ── SPORTS win commission — a user LOSS (and its void reversal) ──
      // The SPORTS column above is bet-derived, so the commission rows the
      // settlement writes (reason 'commission', loss = -comm) must be added
      // here explicitly. Same date window (ledger created_at).
      const commissionRows = await CreditsLedger.findAll({
        where: {
          user_id: { [Op.in]: filteredUserIds.map(id => String(id)) },
          category: 'SPORTS',
          reason: { [Op.in]: ['commission', 'commission_void'] },
          ...dateFilter
        },
        attributes: [
          'user_id',
          [sequelize.fn('COALESCE', sequelize.fn('SUM', sequelize.col('profit')), 0), 'total_profit'],
          [sequelize.fn('COALESCE', sequelize.fn('SUM', sequelize.col('loss')), 0), 'total_loss']
        ],
        group: ['user_id'],
        raw: true,
      });
      for (const row of commissionRows) {
        const net = (parseFloat(row.total_profit) || 0) + (parseFloat(row.total_loss) || 0);
        if (net !== 0) ensure(Number(row.user_id)).SPORTS += net;
      }

      // ── CASINO + THIRD_PARTY_CASINO P/L ──
      // Both write per-bet/session CreditsLedger rows correctly, so the
      // profit/loss column aggregation is accurate for these categories.
      const ledgerData = await CreditsLedger.findAll({
        where: {
          user_id: { [Op.in]: filteredUserIds.map(id => String(id)) },
          category: { [Op.in]: ['CASINO', 'THIRD_PARTY_CASINO'] },
          ...dateFilter
        },
        attributes: [
          'user_id',
          'category',
          [sequelize.fn('COALESCE', sequelize.fn('SUM', sequelize.col('profit')), 0), 'total_profit'],
          [sequelize.fn('COALESCE', sequelize.fn('SUM', sequelize.col('loss')), 0), 'total_loss']
        ],
        group: ['user_id', 'category'],
        raw: true
      });
      for (const row of ledgerData) {
        const cat = row.category;
        if (cat !== 'CASINO' && cat !== 'THIRD_PARTY_CASINO') continue;
        const profit = parseFloat(row.total_profit) || 0;
        const loss = Math.abs(parseFloat(row.total_loss) || 0);
        ensure(Number(row.user_id))[cat] = profit - loss;
      }

      // Get usernames for all user_ids that have data
      const userIdsWithData = Object.keys(userMap).map(Number);
      if (userIdsWithData.length === 0) {
        return res.status(200).json({ success: true, data: [] });
      }

      const users = await User.findAll({
        where: { user_id: { [Op.in]: userIdsWithData } },
        attributes: ['user_id', 'username'],
        raw: true
      });

      const usernameMap = {};
      users.forEach(u => { usernameMap[u.user_id] = u.username; });

      // Build response data
      const data = userIdsWithData.map(uid => {
        const cats = userMap[uid];
        const sport = cats.SPORTS || 0;
        const casino = cats.CASINO || 0;
        const thirdParty = cats.THIRD_PARTY_CASINO || 0;
        return {
          user_id: uid,
          username: usernameMap[uid] || `User ${uid}`,
          sport: parseFloat(sport.toFixed(2)),
          casino: parseFloat(casino.toFixed(2)),
          third_party: parseFloat(thirdParty.toFixed(2)),
          profit_loss: parseFloat((sport + casino + thirdParty).toFixed(2))
        };
      });

      // Sort by profit_loss descending
      data.sort((a, b) => b.profit_loss - a.profit_loss);

      return res.status(200).json({ success: true, data });

    } catch (error) {
      console.error('❌ Get User Win Loss Error:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  },
  getAccountStatement: async (req, res) => {
    try {
      console.log('📝 [ReportsController] getAccountStatement request:', req.body);
      const { clientName } = req.body;

      let target = null;

      if (clientName) {
        // Case-insensitive search for User
        const user = await User.findOne({
          where: { username: { [Op.iLike]: clientName } }
        });

        if (user) {
          target = { id: user.user_id, type: 'USER', username: user.username };
        } else {
          // If not found in User, try Staff
          const staff = await Staff.findOne({
            where: { username: { [Op.iLike]: clientName } }
          });
          if (staff) {
            target = { id: staff.staff_id, type: 'STAFF', username: staff.username };
          }
        }
      } else if (req.user) {
        // Self-Report
        if (req.user.role === 'USER') {
          target = { id: req.user.user_id || req?.user?.account?.id, type: 'USER', username: req.user.username };
        } else {
          // Staff or Owner
          const id = req.user.staff_id || req.user.owner_id;
          target = { id: id, type: req.user.role, username: req.user.username };
        }
      }

      if (!target) {
        return res.status(200).json({
          success: true,
          data: [],
          total: 0,
          totalPages: 0,
          currentPage: 1,
          message: clientName ? "User not found" : "Please enter a valid Client Name"
        });
      }

      // Delegate to Service
      const result = await TransactionReportService.getStatement(target, req.body);
      return res.status(200).json(result);

    } catch (error) {
      console.error('❌ Get Account Statement Error:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  },

  // Settlement report V2 — point_ledger se: login wale ki apni entries
  // (wallet_id) + jo usne settle ki hain (settled_with_wallet_id)
  getStatementV2: async (req, res) => {
    try {
      console.log('📝 [ReportsController] getStatementV2 request:', req.body);

      const {clientName}= req.body
      const role = (req.user?.role || '').toUpperCase();
      if (role === 'USER') {
        return res.status(403).json({ success: false, message: 'Only staff/owner can view this report' });
      }

      // reportType compulsory — sirf ye do hi allowed
      const { reportType } = req.body;
      if (reportType !== 'TRANSACTION' && reportType !== 'SPORTS') {
        return res.status(400).json({ success: false, message: "reportType required" });
      }

      const id = req.user.staff_id || req.user.owner_id || req.user?.account?.id;

      // clientName aaya ho to us client ki wallet, warna login wale ki apni wallet
      let wallet = null;
      if (clientName?.trim()) {
        wallet = await Wallet.findOne({
          where: { username: { [Op.iLike]: clientName.trim() } },
          attributes: ['wallet_id', 'username'],
          raw: true,
        });
      } else {
        wallet = await Wallet.findOne({
          where: role === 'OWNER' ? { owner_id: id, user_type: 'OWNER' } : { staff_id: id },
          attributes: ['wallet_id', 'username'],
          raw: true,
        });
      }

      if (!wallet) {
        return res.status(404).json({ success: false, message: 'Wallet not found' });
      }

      const target = { id, type: role, username: req.user.username, walletId: wallet.wallet_id };
      const result = await TransactionReportService.getStatementV2(target, req.body);
      return res.status(200).json(result);
    } catch (error) {
      console.error('❌ Get SettlementV2 Error:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  },

  getCurrentBets: async (req, res) => {
    try {
      const {
        page = 1,
        limit = 20,
        search = '',
        sport,
        gameType,
        betType,
        minAmount,
        maxAmount,
        eventId,
        matchId
      } = req.query;

      const offset = (page - 1) * limit;
      const where = {
        status: { [Op.in]: ['OPEN', 'PENDING', 'open', 'pending', 'matched', 'Match', 'MATCHED'] },
        result_status: 'pending'
      };

      // 1. Hierarchy Check
      const loggedInRole = req.user?.role?.toUpperCase();
      const loggedInId = req.user.account.id; // owner_id or staff_id

      if (loggedInRole !== 'OWNER') {
        // Helper to get all descendant staff IDs
        const getAllDescendantStaffIds = async (staffId) => {
          let allIds = [staffId];
          let currentIds = [staffId];

          while (currentIds.length > 0) {
            const children = await Staff.findAll({
              where: { parent_id: { [Op.in]: currentIds } },
              attributes: ['staff_id'],
              raw: true
            });

            if (children.length === 0) break;

            const childIds = children.map(c => c.staff_id);
            allIds = [...allIds, ...childIds];
            currentIds = childIds;
          }
          return allIds;
        };

        const allowedStaffIds = await getAllDescendantStaffIds(loggedInId);

        // Find all users belonging to these staff members
        const usersUnderStaff = await User.findAll({
          where: { parent_staff_id: { [Op.in]: allowedStaffIds } },
          attributes: ['user_id'],
          raw: true
        });

        const allowedUserIds = usersUnderStaff.map(u => u.user_id);

        // Add to where clause
        where.user_id = { [Op.in]: allowedUserIds };
      }

      // 2. Apply Filters
      if (search) {
        where[Op.or] = [
          { match_title: { [Op.iLike]: `%${search}%` } },
          { selection_name: { [Op.iLike]: `%${search}%` } },
          { market_name: { [Op.iLike]: `%${search}%` } }
        ];
      }

      if (sport) {
        where.sport_id = sport;
      }

      if (gameType) {
        if (gameType === 'sports') {
          // Assuming sports have numeric IDs or specific types.
          // If 'casino' is a game_type, then sports are everything else?
          // Or maybe we just don't filter if it's sports, relying on sport_id?
          // Let's assume for now we filter by exclusion of casino if needed,
          // or just pass the specific game_type if known.
          // Actually, the frontend tabs are 'sports' and 'casino'.
          // Let's check what values are in DB.
          // For now, I'll allow direct filtering if gameType is passed.
          // If gameType is 'casino', we might filter game_type = 'casino'.
          // If gameType is 'sports', we might filter game_type != 'casino'.
          where.game_type = { [Op.ne]: 'casino' };
        } else if (gameType === 'casino') {
          where.game_type = 'casino';
        } else {
          where.game_type = gameType;
        }
      }

      if (betType) {
        where.bet_type = betType;
      }

      if (minAmount || maxAmount) {
        where.stake_amount = {};
        if (minAmount) where.stake_amount[Op.gte] = minAmount;
        if (maxAmount) where.stake_amount[Op.lte] = maxAmount;
      }

      if (eventId) {
        where.eventid = eventId;
      }

      if (matchId) {
        where.match_id = matchId;
      }

      // 3. Fetch Bets
      const { count, rows } = await import('../../model/user/SportsBet.js').then(m => m.default.findAndCountAll({
        where,
        include: [{
          model: User,
          as: 'user',
          attributes: ['username'],
          required: true
        }],
        limit: parseInt(limit),
        offset: parseInt(offset),
        order: [['created_at', 'DESC']]
      }));

      const data = rows.map((row) => {
        const bet = row.toJSON();
        bet.sport_name = getSportNameById(bet.sport_id);
        return bet;
      });

      return res.status(200).json({
        success: true,
        data,
        pagination: {
          total: count,
          page: parseInt(page),
          limit: parseInt(limit),
          totalPages: Math.ceil(count / limit)
        }
      });

    } catch (error) {
      console.error('❌ Get Current Bets Error:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  },
  getCasinoReport: async (req, res) => {
    try {
      console.log('📥 casinoReports req.body:', req.body);

      const { role, username, type, vendor } = req.body;

      // 🔎 Validation
      if (!role || !username || !type || !vendor) {
        return res.status(400).json({
          success: false,
          message: 'role, username, type, and vendor are required',
        });
      }

      if (!['SETTLEBET', 'UNSETTLEBET'].includes(type.toUpperCase())) {
        return res.status(400).json({
          success: false,
          message: 'type must be SettleBet or UnsettleBet',
        });
      }

      // 1️⃣ Resolve users under hierarchy
      const userIds = await getUserIdsByHierarchy(role, username);

      if (!userIds.length) {
        return res.status(200).json({
          success: true,
          data: [],
          message: 'No users found under given hierarchy',
        });
      }

      // 2️⃣ Transaction status condition
      let transactionStatusCondition = {};
      if (type.toUpperCase() === 'SETTLEBET') {
        transactionStatusCondition = { transaction_status: 'processed' };
      } else {
        transactionStatusCondition = {
          transaction_status: { [Op.ne]: 'processed' },
        };
      }

      // 3️⃣ Fetch casino transactions + game details
      const reports = await sequelize.query(
        `
        SELECT
          t.id,
          t.user_id,
          t.game_uid,
          t.transaction_type,
          t.amount,
          t.currency,
          t.transaction_status,
          t.external_transaction_id,
          t.serial_number,
          t.timestamp,

          g.game_name,
          g.game_type,
          g.game_icon,
          g.vendor

        FROM js_game_transactions t
        INNER JOIN js_games g
          ON g.game_uid = t.game_uid

        WHERE
          t.user_id IN (:userIds)
          AND ${type.toUpperCase() === 'SETTLEBET'
          ? `t.transaction_status = 'processed'`
          : `t.transaction_status <> 'processed'`}
          AND g.vendor = :vendor

        ORDER BY t.timestamp DESC
        `,
        {
          replacements: {
            userIds,
            vendor,
          },
          type: sequelize.QueryTypes.SELECT,
        }
      );

      // ✅ Final response
      return res.status(200).json({
        success: true,
        data: reports,
        meta: {
          role,
          username,
          vendor,
          type,
          total_users: userIds.length,
          total_records: reports.length,
        },
      });

    } catch (error) {
      console.error('❌ Error in casinoReports:', error);
      return res.status(500).json({
        success: false,
        message: 'Failed to fetch casino reports',
        error: error.message,
      });
    }
  },
  getMarketAnalysis: async (req, res) => {
    try {
      const username = req.user.username;
      const role = req.user.role;
      // Optional scoping — the game-details page asks for a single event
      const { eventid, match_id } = req.body || {};

      const userIds = await getUserIdsByHierarchy(role, username);

      if (!userIds || userIds.length === 0) {
        return res.json({ success: true, count: 0, data: [] });
      }

      const where = { ...EXCLUDE_HELPER_KEYS, user_id: { [Op.in]: userIds.map(id => Number(id)) } };
      if (eventid) where.event_id = String(eventid);
      if (match_id) where.match_id = String(match_id);

      const exposures = await UserExposure.findAll({
        where,
        raw: true,
        // row id = order the runners were written (feed runner order) — the
        // reference lists rows inside a card in this order
        order: [['id', 'ASC']],
      });

      // Group by match_id -> game_type -> team_name (sum across all users)
      const grouped = {};

      for (const exp of exposures) {
        const matchId = exp.match_id;

        if (!grouped[matchId]) {
          grouped[matchId] = {
            match_id: matchId,
            event_id: exp.event_id,
            match_title: exp.match_title,
            markets: {},
            last_updated: 0,
          };
        }
        grouped[matchId].last_updated = Math.max(grouped[matchId].last_updated, new Date(exp.updated_at).getTime());

        const gameType = exp.game_type || 'MATCH_ODDS';
        if (!grouped[matchId].markets[gameType]) {
          grouped[matchId].markets[gameType] = {};
        }

        const teamName = exp.team_name;
        if (!grouped[matchId].markets[gameType][teamName]) {
          grouped[matchId].markets[gameType][teamName] = 0;
        }
        grouped[matchId].markets[gameType][teamName] += parseFloat(exp.exposure_amount || 0);
      }

      // Fetch sport_id mapping from SportsBet for all event_ids
      const eventIds = [...new Set(Object.values(grouped).map(m => m.event_id).filter(Boolean))];
      const sportIdMap = {};
      // event_date usi query se — har event ka match_start_time (bets pe stored).
      // Pehle hardcoded null ja raha tha, isliye UI pe date kabhi render nahi hoti thi.
      const startTimeMap = {};
      if (eventIds.length > 0) {
        const sportRows = await SportsBet.findAll({
          where: { eventid: { [Op.in]: eventIds } },
          attributes: [
            'eventid',
            'sport_id',
            [sequelize.fn('MAX', sequelize.col('match_start_time')), 'match_start_time'],
          ],
          group: ['eventid', 'sport_id'],
          raw: true,
        });
        for (const row of sportRows) {
          sportIdMap[row.eventid] = row.sport_id;
          const startedAt = toNaiveLocalTime(row.match_start_time);
          if (startedAt) startTimeMap[row.eventid] = startedAt;
        }
      }

      // events: most recently active first (unchanged behaviour);
      // cards inside an event: market id ascending, like the reference
      const eventKey = (m) => String(m.event_id || m.match_id);
      const eventLast = {};
      for (const m of Object.values(grouped)) {
        eventLast[eventKey(m)] = Math.max(eventLast[eventKey(m)] || 0, m.last_updated);
      }
      const ordered = Object.values(grouped).sort((a, b) =>
        (eventLast[eventKey(b)] - eventLast[eventKey(a)])
        || eventKey(a).localeCompare(eventKey(b))
        || String(a.match_id).localeCompare(String(b.match_id), undefined, { numeric: true }));

      const data = ordered.map(match => ({
        match_id: match.match_id,
        match_title: match.match_title || `Match ${match.match_id}`,
        eventid: match.event_id || match.match_id,
        sport_id: sportIdMap[match.event_id] || null,
        event_date: startTimeMap[match.event_id] || null,
        markets: Object.entries(match.markets).map(([name, teams]) => ({
          name,
          game_type: name,
          rows: Object.entries(teams).map(([label, value]) => ({
            label,
            // MO/BM: invert (book-side P/L). Fancy: the reference shows the
            // player's own exposure as-is (-100 on a 100 stake), 2026-10-11.
            value: (parseFloat(value) === 0 ? 0
              : isFancyMarket({ market_type: name }) ? parseFloat(value) : -parseFloat(value)).toFixed(2),
          })),
        })),
      }));

      return res.json({ success: true, count: data.length, data });

    } catch (error) {
      console.error('getMarketAnalysis error:', error);
      return res.status(500).json({ success: false, message: 'Something went wrong' });
    }
  },

  // Market Analysis dashboard — same exposure data as getMarketAnalysis, but
  // grouped by EVENT (event_id) instead of match_id. Ek event ke saare markets
  // (Normal, MATCH_ODDS, …) ek hi entry me aate hain, taaki UI pe ek event = ek
  // card-container jisme andar multiple market tables. (getMarketAnalysis har
  // market_id ko alag entry deta tha → same eventid ki multiple entries.)
  getMarketAnalysisDashboard: async (req, res) => {
    try {
      const username = req.user.username;
      const role = req.user.role;

      let userIds = await getUserIdsByHierarchy(role, username);

      if (!userIds || userIds.length === 0) {
        return res.json({ success: true, count: 0, data: [] });
      }

      // Optional `username` in the body narrows the same report to ONE account
      // — the header's Search User pick opens it as the "My Market" modal
      // (reference: report/searchanalysis). A player → that player's rows; a
      // staff → its whole downline. Either way only what the caller could see
      // anyway: the target's ids are intersected with the caller's hierarchy,
      // so a name outside it (or unknown) answers an empty report, never 403
      // and never someone else's book. Same guard as getTotalProfitLoss.
      const scopeName = String(req.body?.username || '').trim();
      if (scopeName) {
        const own = new Set(userIds.map(id => Number(id)));
        const player = await User.findOne({
          where: { username: { [Op.iLike]: scopeName } }, attributes: ['user_id'], raw: true,
        });
        if (player) {
          userIds = own.has(Number(player.user_id)) ? [player.user_id] : [];
        } else {
          const staff = await Staff.findOne({
            where: { username: { [Op.iLike]: scopeName } }, attributes: ['role', 'username'], raw: true,
          });
          const downline = staff ? await getUserIdsByHierarchy(staff.role, staff.username) : [];
          userIds = (downline || []).filter(id => own.has(Number(id)));
        }
        if (userIds.length === 0) {
          return res.json({ success: true, count: 0, data: [] });
        }
      }

      const where = { ...EXCLUDE_HELPER_KEYS, user_id: { [Op.in]: userIds.map(id => Number(id)) } };

      const exposures = await UserExposure.findAll({
        where,
        raw: true,
        // row id = feed runner order — same as getMarketAnalysis
        order: [['id', 'ASC']],
      });

      // Group by event_id -> game_type -> team_name (sum across all users & match_ids)
      const grouped = {};

      for (const exp of exposures) {
        // fall back to match_id when an exposure row has no event_id
        const eventKey = exp.event_id || exp.match_id;
        if (!eventKey) continue;

        if (!grouped[eventKey]) {
          grouped[eventKey] = {
            event_id: exp.event_id || exp.match_id,
            match_id: exp.match_id,
            match_title: exp.match_title,
            markets: {},
            marketIds: {},
          };
        }

        const gameType = exp.game_type || 'MATCH_ODDS';
        if (!grouped[eventKey].markets[gameType]) {
          grouped[eventKey].markets[gameType] = {};
        }
        // lowest market id per card — cards sort by it, like the reference
        const mid = String(exp.match_id || '');
        const prev = grouped[eventKey].marketIds[gameType];
        if (prev === undefined || mid.localeCompare(prev, undefined, { numeric: true }) < 0) {
          grouped[eventKey].marketIds[gameType] = mid;
        }

        const teamName = exp.team_name;
        if (!grouped[eventKey].markets[gameType][teamName]) {
          grouped[eventKey].markets[gameType][teamName] = 0;
        }
        grouped[eventKey].markets[gameType][teamName] += parseFloat(exp.exposure_amount || 0);
      }

      // Fetch sport_id mapping from SportsBet for all event_ids
      const eventIds = [...new Set(Object.values(grouped).map(m => m.event_id).filter(Boolean))];
      const sportIdMap = {};
      // event_date usi query se — har event ka match_start_time (bets pe stored).
      // Pehle hardcoded null ja raha tha, isliye UI pe date kabhi render nahi hoti thi.
      const startTimeMap = {};
      if (eventIds.length > 0) {
        const sportRows = await SportsBet.findAll({
          where: { eventid: { [Op.in]: eventIds } },
          attributes: [
            'eventid',
            'sport_id',
            [sequelize.fn('MAX', sequelize.col('match_start_time')), 'match_start_time'],
          ],
          group: ['eventid', 'sport_id'],
          raw: true,
        });
        for (const row of sportRows) {
          sportIdMap[row.eventid] = row.sport_id;
          const startedAt = toNaiveLocalTime(row.match_start_time);
          if (startedAt) startTimeMap[row.eventid] = startedAt;
        }
      }

      const data = Object.values(grouped).map(event => ({
        match_id: event.match_id,
        match_title: event.match_title || `Match ${event.match_id}`,
        eventid: event.event_id || event.match_id,
        sport_id: sportIdMap[event.event_id] || null,
        event_date: startTimeMap[event.event_id] || null,
        markets: Object.entries(event.markets)
          .sort(([a], [b]) => String(event.marketIds[a] || '')
            .localeCompare(String(event.marketIds[b] || ''), undefined, { numeric: true }))
          .map(([name, teams]) => ({
            name,
            game_type: name,
            rows: Object.entries(teams).map(([label, value]) => ({
              label,
              // Dashboard: invert sign (user-side exposure is book-side P/L).
              // Search-user modal (scopeName): the reference shows the
              // account's own side (-100), so send it as stored.
              value: (parseFloat(value) === 0 ? 0 : (scopeName ? 1 : -1) * parseFloat(value)).toFixed(2),
            })),
          })),
      }));

      return res.json({ success: true, count: data.length, data });

    } catch (error) {
      console.error('getMarketAnalysisDashboard error:', error);
      return res.status(500).json({ success: false, message: 'Something went wrong' });
    }
  },

  getTotalProfitLoss: async (req, res) => {
    try {
      const username = req.user.username;
      const role = req.user.role;
      const { clientName, fromDate, toDate, type } = req.body;

      // Get all user IDs under logged-in user's hierarchy
      const userIds = await getUserIdsByHierarchy(role, username);

      if (!userIds || userIds.length === 0) {
        return res.json({ success: true, sports: [], casino: [], thirdParty: [] });
      }

      // If a specific client is selected, filter to that user only
      let filteredUserIds = userIds;
      if (clientName && clientName !== '' && clientName !== 'all') {
        const user = await User.findOne({
          where: { username: { [Op.iLike]: clientName } },
          attributes: ['user_id'],
          raw: true
        });
        if (!user || !userIds.includes(user.user_id)) {
          return res.json({ success: true, sports: [], casino: [], thirdParty: [] });
        }
        filteredUserIds = [user.user_id];
      }

      // Build where clause
      const where = {
        user_id: { [Op.in]: filteredUserIds.map(id => String(id)) },
      };

      if (fromDate && toDate) {
        where.created_at = {
          [Op.between]: [new Date(fromDate), new Date(toDate + 'T23:59:59.999Z')]
        };
      } else if (fromDate) {
        where.created_at = { [Op.gte]: new Date(fromDate) };
      } else if (toDate) {
        where.created_at = { [Op.lte]: new Date(toDate + 'T23:59:59.999Z') };
      }

      // Filter by category type if specified
      const categoryFilter = [];
      if (!type || type === '0') {
        // All
      } else if (type === '2') {
        categoryFilter.push('SPORTS');
      } else if (type === '3') {
        categoryFilter.push('CASINO');
      } else if (type === '4') {
        categoryFilter.push('THIRD_PARTY_CASINO');
      }
      if (categoryFilter.length > 0) {
        where.category = { [Op.in]: categoryFilter };
      }

      // Fetch all matching ledger entries
      const ledgerRows = await CreditsLedger.findAll({
        where,
        attributes: ['eventid', 'match_id', 'category', 'market_type', 'profit', 'loss', 'sport_id', 'meta', 'bet_id'],
        raw: true,
      });

      // Resolve gtype for sports rows from the originating bet (SportsBet.gtype)
      const sportsBetIds = [...new Set(
        ledgerRows
          .filter(r => (r.category || 'SPORTS').toUpperCase() === 'SPORTS')
          .map(r => r.bet_id)
          .filter(Boolean)
      )];
      const gtypeByBetId = {};
      if (sportsBetIds.length > 0) {
        const bets = await SportsBet.findAll({
          where: { id: { [Op.in]: sportsBetIds } },
          attributes: ['id', 'gtype'],
          raw: true,
        });
        for (const b of bets) gtypeByBetId[b.id] = b.gtype;
      }

      // Group by category
      const sportsMap = {};
      const casinoMap = {};
      const thirdPartyMap = {};

      for (const row of ledgerRows) {
        const profitAmt = parseFloat(row.profit) || 0;
        const lossAmt = Math.abs(parseFloat(row.loss) || 0);
        const cat = (row.category || 'SPORTS').toUpperCase();

        if (cat === 'SPORTS') {
          // Group by sport name (from sport_id via sportsNames map) + gtype — NOT market_type
          const sportName = getSportNameById(row.sport_id) || 'Other';
          const gtype = gtypeByBetId[row.bet_id] || 'Other';
          const key = `${sportName}__${gtype}`;
          if (!sportsMap[key]) {
            sportsMap[key] = { sport_name: sportName, gtype, totalProfit: 0, totalLoss: 0 };
          }
          sportsMap[key].totalProfit += profitAmt;
          sportsMap[key].totalLoss += lossAmt;
        // } else if (cat === 'CASINO') {
        //   const gameName = row.match_id || 'Casino';
        //   if (!casinoMap[gameName]) {
        //     casinoMap[gameName] = { name: gameName, totalProfit: 0, totalLoss: 0 };
        //   }
        //   casinoMap[gameName].totalProfit += profitAmt;
        //   casinoMap[gameName].totalLoss += lossAmt;
        } else if (cat === 'THIRD_PARTY_CASINO') {
          // jsgamesv2: match_id is null; game name lives in meta.game_name.
          // Group by "provider / game" so multiple providers with the same game
          // name don't collide.
          const meta = row.meta || {};
          const provider = meta.provider || row.sport_id || 'Third Party';
          const gameName = meta.game_name || row.match_id || 'Unknown Game';
          const key = `${provider} / ${gameName}`;
          if (!thirdPartyMap[key]) {
            thirdPartyMap[key] = { name: key, totalProfit: 0, totalLoss: 0 };
          }
          thirdPartyMap[key].totalProfit += profitAmt;
          thirdPartyMap[key].totalLoss += lossAmt;
        }
      }

      const buildRow = (s) => ({
        opening: parseFloat(s.totalLoss.toFixed(2)),
        closing: parseFloat(s.totalProfit.toFixed(2)),
        profit_loss: parseFloat((s.totalProfit - s.totalLoss).toFixed(2)),
      });

      const sports = Object.values(sportsMap).map(s => ({
        event_name: s.sport_name,
        game_type: s.gtype,
        ...buildRow(s),
      }));

      // Casino report disabled — not shown in total profit loss
      // const casino = Object.values(casinoMap).map(c => ({
      //   casino_name: c.name,
      //   ...buildRow(c),
      // }));
      const casino = [];

      const thirdParty = Object.values(thirdPartyMap).map(t => ({
        third_party_name: t.name,
        ...buildRow(t),
      }));

      return res.json({ success: true, sports, casino, thirdParty });

    } catch (error) {
      console.error('getTotalProfitLoss error:', error);
      return res.status(500).json({ success: false, message: 'Something went wrong' });
    }
  },

  // 🔐 Get all OPEN/pending bets for a specific match (event) — used by the
  //    game-details page (main "My Bets" section + any per-match panels).
  //    Strict hierarchy filter using the shared getUserIdsByHierarchy helper:
  //      OWNER  → sees every user under their tree
  //      STAFF  → sees only users in their descendant chain
  //    This is intentionally a separate endpoint from getCurrentBets so it
  //    cannot affect the Current Bets report behavior.
  // 🔐 Per-user book for one market — the "User Book" popup on game-details.
  // Rows are downline users, columns are the market's runners. Values use the
  // same book-side sign convention as getMarketAnalysis.
  getUserBook: async (req, res) => {
    try {
      const { eventid, match_id, game_type } = req.body || {};

      if (!eventid && !match_id) {
        return res.status(400).json({ success: false, message: 'eventid or match_id is required' });
      }

      const userIds = await getUserIdsByHierarchy(req.user?.role, req.user?.username);
      if (!userIds || userIds.length === 0) {
        return res.json({ success: true, runners: [], data: [] });
      }

      const where = { user_id: { [Op.in]: userIds.map(id => Number(id)) }, ...EXCLUDE_HELPER_KEYS };
      if (eventid) where.event_id = String(eventid);
      if (match_id) where.match_id = String(match_id);
      if (game_type) where.game_type = String(game_type);

      const exposures = await UserExposure.findAll({ where, raw: true });
      if (exposures.length === 0) {
        return res.json({ success: true, runners: [], data: [], tree: [] });
      }

      const users = await User.findAll({
        where: { user_id: { [Op.in]: [...new Set(exposures.map(e => Number(e.user_id)))] } },
        attributes: ['user_id', 'username', 'parent_staff_id'],
        raw: true,
      });
      const usernameById = Object.fromEntries(users.map(u => [String(u.user_id), u.username]));

      // Column order follows first appearance so every row lines up
      const runners = [];
      const rowsByUser = {};

      for (const exp of exposures) {
        const runner = String(exp.team_name || '').trim();
        if (!runners.includes(runner)) runners.push(runner);

        const uid = String(exp.user_id);
        if (!rowsByUser[uid]) {
          rowsByUser[uid] = { user_id: uid, username: usernameById[uid] || `User ${uid}`, values: {} };
        }
        const amount = parseFloat(exp.exposure_amount || 0);
        rowsByUser[uid].values[runner] = (rowsByUser[uid].values[runner] || 0) + amount;
      }

      const data = Object.values(rowsByUser).map(row => ({
        user_id: row.user_id,
        username: row.username,
        values: runners.map(runner => {
          const amount = row.values[runner];
          if (amount == null) return null;
          // Invert sign: user-side exposure is book-side profit/loss
          return Number((amount === 0 ? 0 : -amount).toFixed(2));
        }),
      }));

      // Hierarchy tree, like the reference `game/allbook` (t1 rows nested by
      // subid): the viewer's direct children at the top, each staff row the
      // book of everyone under it (sign flipped, upline side), each end user
      // their own P&L as stored. Full amounts, no partnership share.
      const viewerStaffId = (req.user?.role || '').toUpperCase() === 'OWNER'
        ? null
        : (await Staff.findOne({ where: { username: req.user?.username }, attributes: ['staff_id'], raw: true }))?.staff_id ?? null;

      const staffById = {};
      let pending = [...new Set(users.map(u => u.parent_staff_id).filter(Boolean).map(Number))];
      while (pending.length) {
        const rows = await Staff.findAll({
          where: { staff_id: { [Op.in]: pending } },
          attributes: ['staff_id', 'username', 'parent_id'],
          raw: true,
        });
        rows.forEach(s => { staffById[s.staff_id] = s; });
        pending = [...new Set(rows
          .filter(s => Number(s.staff_id) !== Number(viewerStaffId))
          .map(s => s.parent_id).filter(Boolean).map(Number))]
          .filter(id => !staffById[id]);
      }

      const roots = [];
      const staffNodes = {};
      const staffNode = (staffId) => {
        if (!staffId || Number(staffId) === Number(viewerStaffId) || !staffById[staffId]) return null;
        if (staffNodes[staffId]) return staffNodes[staffId];
        const s = staffById[staffId];
        const node = { id: `S${s.staff_id}`, username: s.username, sums: runners.map(() => null), children: [] };
        staffNodes[staffId] = node;
        const parent = staffNode(s.parent_id);
        (parent ? parent.children : roots).push(node);
        return node;
      };

      for (const u of users) {
        const own = rowsByUser[String(u.user_id)];
        if (!own) continue;
        const raw = runners.map(r => (own.values[r] == null ? null : own.values[r]));
        const leaf = {
          id: `U${u.user_id}`,
          username: own.username,
          values: raw.map(v => (v == null ? null : Number(v.toFixed(2)))),
        };
        const parent = staffNode(u.parent_staff_id);
        (parent ? parent.children : roots).push(leaf);
        for (let p = parent, sid = u.parent_staff_id; p; sid = staffById[sid]?.parent_id, p = staffNode(sid)) {
          raw.forEach((v, i) => { if (v != null) p.sums[i] = (p.sums[i] || 0) + v; });
        }
      }

      const finish = (node) => {
        if (!node.children) return node;
        const { sums, ...rest } = node;
        return {
          ...rest,
          values: sums.map(v => (v == null ? null : Number((v === 0 ? 0 : -v).toFixed(2)))),
          children: node.children.map(finish),
        };
      };
      const tree = roots.map(finish);

      return res.json({ success: true, runners, count: data.length, data, tree });
    } catch (error) {
      console.error('getUserBook error:', error);
      return res.status(500).json({ success: false, message: 'Something went wrong' });
    }
  },

  getMatchDownlineBets: async (req, res) => {
    try {
      const {
        eventId,
        matchId,
        page = 1,
        limit = 100,
        betType,
      } = req.query;

      if (!eventId && !matchId) {
        return res.status(400).json({
          success: false,
          message: 'eventId or matchId is required',
        });
      }

      const loggedInRole = req.user?.role;
      const loggedInUsername = req.user?.username;

      // Hierarchy guard — only downline users (owner sees full tree)
      const allowedUserIds = await getUserIdsByHierarchy(loggedInRole, loggedInUsername);
      if (!allowedUserIds || allowedUserIds.length === 0) {
        return res.status(200).json({
          success: true,
          data: [],
          pagination: { total: 0, page: parseInt(page), limit: parseInt(limit), totalPages: 0 },
        });
      }

      const offset = (parseInt(page) - 1) * parseInt(limit);
      const where = {
        user_id: { [Op.in]: allowedUserIds },
        status: { [Op.in]: ['OPEN', 'PENDING', 'open', 'pending', 'matched', 'Match', 'MATCHED'] },
        result_status: 'pending',
      };

      if (eventId) where.eventid = eventId;
      if (matchId) where.match_id = matchId;
      if (betType && betType !== 'all') where.bet_type = betType;

      const { count, rows } = await SportsBet.findAndCountAll({
        where,
        include: [{
          model: User,
          as: 'user',
          attributes: ['username'],
          required: true,
        }],
        limit: parseInt(limit),
        offset,
        order: [['created_at', 'DESC']],
      });

      return res.status(200).json({
        success: true,
        data: rows,
        pagination: {
          total: count,
          page: parseInt(page),
          limit: parseInt(limit),
          totalPages: Math.ceil(count / parseInt(limit)),
        },
      });
    } catch (error) {
      console.error('❌ getMatchDownlineBets error:', error);
      return res.status(500).json({ success: false, error: error.message });
    }
  },

  // 🔐 Get bet history for a particular downline user from the SportsBet table.
  // Requires `username` query param. The user MUST be in the requesting
  // admin's downline hierarchy, otherwise an empty result is returned.
  getUserBetHistory: async (req, res) => {
    try {
      const loggedInUsername = req.user?.username;
      const loggedInRole = req.user?.role;
      const {
        username,
        page = 1,
        limit = 25,
        fromDate,
        toDate,
        betType,
        status,
      } = req.query;

      if (!username || !username.trim()) {
        return res.status(200).json({
          success: true,
          data: [],
          pagination: { total: 0, page: 1, limit: parseInt(limit), totalPages: 0 },
          message: 'Please select a user',
        });
      }

      // 1️⃣ Get downline user ids of the logged-in admin
      const downlineUserIds = await getUserIdsByHierarchy(loggedInRole, loggedInUsername);
      if (!downlineUserIds || downlineUserIds.length === 0) {
        return res.status(200).json({
          success: true,
          data: [],
          pagination: { total: 0, page: 1, limit: parseInt(limit), totalPages: 0 },
        });
      }

      // 2️⃣ Resolve username -> user_id
      const targetUser = await User.findOne({
        where: { username: { [Op.iLike]: username.trim() } },
        attributes: ['user_id', 'username'],
        raw: true,
      });

      if (!targetUser) {
        return res.status(200).json({
          success: true,
          data: [],
          pagination: { total: 0, page: 1, limit: parseInt(limit), totalPages: 0 },
          message: 'User not found',
        });
      }

      // 3️⃣ Hierarchy guard — must be in downline
      const downlineSet = new Set(downlineUserIds.map(id => Number(id)));
      if (!downlineSet.has(Number(targetUser.user_id))) {
        return res.status(403).json({
          success: false,
          message: 'User is not in your downline',
        });
      }

      // 4️⃣ Build SportsBet query
      const offset = (parseInt(page) - 1) * parseInt(limit);
      const where = { user_id: targetUser.user_id };

      if (fromDate && toDate) {
        where.created_at = {
          [Op.between]: [new Date(fromDate), new Date(toDate + 'T23:59:59.999Z')],
        };
      } else if (fromDate) {
        where.created_at = { [Op.gte]: new Date(fromDate) };
      } else if (toDate) {
        where.created_at = { [Op.lte]: new Date(toDate + 'T23:59:59.999Z') };
      }

      if (betType && betType !== 'all') {
        where.bet_type = betType;
      }
      if (status && status !== 'all') {
        where.result_status = status;
      }

      const { count, rows } = await SportsBet.findAndCountAll({
        where,
        limit: parseInt(limit),
        offset,
        order: [['created_at', 'DESC']],
      });

      // 5️⃣ Enrich each bet with derived debit / credit / refund / P/L.
      //
      //    Approach (after verifying that ledger entries can't be trusted for
      //    cosmetic display — see note below):
      //
      //    • debit, credit, refund, profit_loss → derived from the raw
      //      SportsBet row (stake / liability / odds / size / bet_type /
      //      result_status). This is the SAME source of truth that the user
      //      panel and user account-statement use, so the admin display can
      //      never disagree with what the user sees.
      //
      //    • closing_balance → pulled from the FIRST CreditsLedger entry
      //      per bet (placement-time snapshot). We deliberately do NOT use
      //      the latest entry, because that would be the post-settlement
      //      wallet for settled bets — and since settlements often happen
      //      later in time (or in batches), it produces non-monotonic
      //      closings when the rows are sorted by placement time.
      //      Placement closing is consistent with the placement-time DESC
      //      order the API returns.
      //
      //    Why we don't sum ledger amounts:
      //    The settlement code performs TWO wallet updates per FAN bet (one
      //    for exposure release / stake refund, one for netamount profit) but
      //    only writes ONE CreditsLedger row whose `amount` column carries the
      //    netamount portion only. Summing `amount` therefore under-reports
      //    actual wallet credit (e.g. a +200 wallet credit shows as 100). The
      //    raw bet outcome formula matches the real wallet movement.
      //
      //    Hedging bets create a 0-amount bet_placed row plus an
      //    exposure_release row, both with the same `closing`. The first
      //    row's stale closing also breaks any "opening balance" derived
      //    from `firstClosing - firstAmount`, so we no longer expose
      //    opening_balance at all.

      // Pull per-bet ledger data:
      //   • placementCashByBetId → signed sum of amounts from placement-time
      //     entries (bet_placed + exposure_release). This is the REAL cash
      //     impact at placement, which captures hedging releases (e.g. a
      //     LAY bet that frees up cash from a previously locked BACK).
      //     Negative = cash deducted (debit), positive = cash returned (credit).
      //   • closingByBetId → closing column from the FIRST ledger entry per
      //     bet (placement-time wallet snapshot). Used as the row's
      //     "closing balance" so the trail stays consistent with the
      //     placement-time DESC sort.
      const betIds = rows.map(r => r.id).filter(Boolean);
      const closingByBetId = {};
      const placementCashByBetId = {};
      // Meter settles on a RAMP (the run difference x stake), so its realised
      // P&L cannot be rebuilt from stake/odds/size the way every other market
      // can — the settled run is not on the bet row. The settlement worker
      // already wrote the exact signed figure to the ledger; read it back.
      const settledNetByBetId = {};
      if (betIds.length > 0) {
        const ledgerRows = await CreditsLedger.findAll({
          where: {
            bet_id: { [Op.in]: betIds },
            user_id: String(targetUser.user_id),
          },
          attributes: ['bet_id', 'closing', 'balance', 'amount', 'netamount', 'reason', 'created_at'],
          order: [['bet_id', 'ASC'], ['created_at', 'ASC'], ['id', 'ASC']],
          raw: true,
        });
        for (const lr of ledgerRows) {
          const bid = String(lr.bet_id);

          // First entry per bet → placement closing snapshot
          if (!(bid in closingByBetId)) {
            const closing = lr.closing != null
              ? parseFloat(lr.closing)
              : (lr.balance != null ? parseFloat(lr.balance) : null);
            if (closing != null) closingByBetId[bid] = closing;
          }

          // Sum placement-time amounts (bet_placed + exposure_release).
          // These are the only ledger reasons that can fire at placement
          // time and they carry the true cash delta (hedge releases too).
          const reason = (lr.reason || '').toLowerCase();
          if (reason === 'bet_placed' || reason === 'exposure_release') {
            placementCashByBetId[bid] = (placementCashByBetId[bid] || 0)
              + (parseFloat(lr.amount) || 0);
          }

          // Realised P&L, written once per bet at settlement.
          if (reason === 'settlement' && lr.netamount != null && !(bid in settledNetByBetId)) {
            settledNetByBetId[bid] = parseFloat(lr.netamount) || 0;
          }
        }
      }

      // Outcome → debit / credit / refund derivation. Mirrors the same
      // formulas the settlement code uses to compute wallet impact:
      //   • back/yes wins:  stake placed back, gets stake + profit
      //   • lay/no  wins:  liability placed back, gets liability + matched stake
      //   • losses:        nothing returned
      //   • void/refund:   placed amount returned (no profit/loss)
      const isLikeBack = (t) => t === 'back' || t === 'yes';
      const isLikeFancy = (t) => t === 'yes' || t === 'no';

      // Profit on a winning bet — handles all three odds conventions
      // present in this codebase:
      //   1. Bookmaker (BM): odds stored as bps (42 means decimal 1.42),
      //      profit = stake × (odds / 100)
      //   2. Fancy session (FAN with size > 0, e.g. "Normal" run-line
      //      markets): profit = stake × (size / 100)
      //   3. Everything else (MO MATCH_ODDS, fancy1, fancy special markets
      //      like Game Winner / Under-Over / TIED_MATCH): decimal odds,
      //      profit = stake × (odds - 1)
      // Lay/No on win pays the matched back stake regardless of convention.
      const computeProfit = (bet) => {
        const stake = parseFloat(bet.stake_amount) || 0;
        const odds = parseFloat(bet.odds) || 0;
        const size = parseFloat(bet.size) || 0;
        const t = (bet.bet_type || '').toLowerCase();
        const gt = (bet.game_type || '').toUpperCase();
        const mt = (bet.market_type || '');
        const isBack = isLikeBack(t);
        const isFancy = isLikeFancy(t);

        if (!isBack) return stake; // lay/no win → matched back stake

        // ── Three mutually-exclusive cases (mirrors settlementv2.js) ──
        //
        // CASE 1 — Bookmaker (BM): odds are bps (e.g. 42 means 1.42).
        //          profit = stake × (odds / 100)
        //
        // CASE 2 — NON-DECIMAL / SESSION RATE (fancy "Normal" run-line):
        //          `size` is the rate in bps; `odds` is NOT a decimal.
        //          e.g. stake=12000 size=175 → profit = 12000×175/100 = 21000
        //          profit = stake × (size / 100)
        //
        // CASE 3 — DECIMAL odds (MO, fancy1, TIED_MATCH, etc.):
        //          odds is a true decimal (e.g. 1.96). size may be present
        //          on fancy1 as a max-stake cap but is NOT a rate.
        //          profit = stake × (odds - 1)

        // CASE 1
        if (gt === 'BM' || /bookmaker/i.test(mt)) {
          return stake * (odds / 100);
        }
        // CASE 2 — fancy session (Normal). fancy1 is explicitly excluded:
        // its odds are decimal even though bet_type is yes/no.
        if (isFancy && mt !== 'fancy1' && size > 0) {
          return stake * (size / 100);
        }
        // CASE 3 — decimal (default)
        return stake * (odds - 1);
      };

      const computeBetFinancials = (bet, placementCash, settledNet) => {
        const stake = parseFloat(bet.stake_amount) || 0;
        const liability = parseFloat(bet.liability) || 0;
        const t = (bet.bet_type || '').toLowerCase();
        const status = (bet.result_status || '').toLowerCase();
        const isBack = isLikeBack(t);

        // standaloneLock = the bet's individual risk amount (what would be
        // locked in the wallet if this were the only bet on the market).
        //   • back/yes → full stake
        //   • lay/no   → liability (stake × (odds-1) for decimal,
        //                stake × (odds/100) for BM bps,
        //                stake × (size/100) for fancy session)
        // We always use this for `debit` so that the row math
        // `credit - debit` produces the correct P/L for settled bets,
        // regardless of whether the actual wallet was locked or released
        // at placement (the hedging effect is shown separately in
        // `released`).
        const standaloneLock = isBack ? stake : (liability || stake);

        // Placement-time hedge release. Only fires when the bet's market
        // already had exposure that this bet hedged out, freeing cash.
        let placementRelease = 0;
        if (typeof placementCash === 'number' && placementCash > 0) {
          placementRelease = placementCash;
        }

        // Settlement-time credit / refund / P/L (derived from bet outcome).
        let settlementCredit = 0;
        let voidRefund = 0;
        let profit_loss = 0;

        // Meter pays the run DIFFERENCE, so its win is not `standaloneLock +
        // computeProfit` and its loss is not the whole lock — a no @24 that
        // settles on 26 loses 2 runs, not the 150-run tail it had blocked.
        // The ledger carries the real number; everything else stays as-is.
        if (isMeterMarket(bet.market_type) && typeof settledNet === 'number'
            && !['refund', 'refunded', 'void', 'cancelled'].includes(status)) {
          return {
            debit: standaloneLock,
            credit: settledNet > 0 ? standaloneLock + settledNet : 0,
            refund: placementRelease + (settledNet <= 0 ? standaloneLock + settledNet : 0),
            profit_loss: settledNet,
          };
        }

        if (status === 'won' || status === 'win') {
          const profit = computeProfit(bet);
          settlementCredit = standaloneLock + profit; // stake refund + profit
          profit_loss = profit;
        } else if (['loss', 'lost', 'lose'].includes(status)) {
          settlementCredit = 0;
          profit_loss = -standaloneLock;
        } else if (['refund', 'refunded', 'void', 'cancelled'].includes(status)) {
          voidRefund = standaloneLock;
          profit_loss = 0;
        }

        return {
          debit: standaloneLock,
          credit: settlementCredit, // settlement-time win return only
          // `refund` field carries any cash returned that is NOT a win:
          //   • placementRelease (hedge release at placement)
          //   • voidRefund (stake refund on void/cancel)
          // Frontend labels this column "Released".
          refund: placementRelease + voidRefund,
          profit_loss,
        };
      };

      // Round to 2 decimals to avoid JS float precision noise
      // (e.g. 40.99999999999999 → 41.00) on amounts the UI surfaces.
      const r2 = (v) => v == null ? v : Math.round(v * 100) / 100;

      const enriched = rows.map(b => {
        const plain = b.toJSON ? b.toJSON() : b;
        const placementCash = placementCashByBetId[String(plain.id)];
        const fin = computeBetFinancials(plain, placementCash, settledNetByBetId[String(plain.id)]);
        plain.debit = r2(fin.debit);
        plain.credit = r2(fin.credit);
        plain.refund = r2(fin.refund);
        plain.profit_loss = r2(fin.profit_loss);
        plain.closing_balance = closingByBetId[String(plain.id)] ?? null;

        // exposure_held = REAL wallet exposure this bet locked at placement.
        // For normal bets it's the cash that was deducted. For hedge bets
        // (placementCash > 0, i.e. cash was actually released back to the
        // wallet because the new bet reduced max liability), exposure_held
        // is 0 — the bet did not hold any exposure, it freed it. The
        // user-facing distinction matters: showing exposure_held=360 next
        // to released=1000 for the same bet is contradictory.
        if (typeof placementCash === 'number') {
          plain.exposure_held = r2(placementCash < 0 ? Math.abs(placementCash) : 0);
        } else {
          // Legacy bets without placement entries → fallback to raw liability
          plain.exposure_held = plain.liability != null ? r2(parseFloat(plain.liability)) : null;
        }
        return plain;
      });

      // === EVENT-WISE SUMMARY ===
      // Group enriched bets by (match_id + game_type + market_type) so the
      // admin can see at-a-glance how the user did on each event/market.
      // We need ALL of the user's bets in the date range for an accurate
      // summary, not just the current page — re-query without limit/offset.
      const allRowsForSummary = await SportsBet.findAll({
        where, // same date/status/betType filters as the paged query
        order: [['created_at', 'ASC']],
        raw: true,
      });
      // The ledger maps above were built from the PAGED bet ids. This summary
      // covers the whole range, so any meter bet outside that page has no
      // settled net yet — and meter is the one market that cannot be rebuilt
      // without it. Top those up before enriching.
      const missingMeterIds = allRowsForSummary
        .filter(b => isMeterMarket(b.market_type) && !(String(b.id) in settledNetByBetId))
        .map(b => b.id)
        .filter(Boolean);
      if (missingMeterIds.length > 0) {
        const meterLedgerRows = await CreditsLedger.findAll({
          where: {
            bet_id: { [Op.in]: missingMeterIds },
            user_id: String(targetUser.user_id),
            reason: 'settlement',
          },
          attributes: ['bet_id', 'netamount'],
          order: [['bet_id', 'ASC'], ['created_at', 'ASC'], ['id', 'ASC']],
          raw: true,
        });
        for (const lr of meterLedgerRows) {
          const bid = String(lr.bet_id);
          if (lr.netamount != null && !(bid in settledNetByBetId)) {
            settledNetByBetId[bid] = parseFloat(lr.netamount) || 0;
          }
        }
      }

      const enrichedAll = allRowsForSummary.map(b => {
        const placementCash = placementCashByBetId[String(b.id)];
        const fin = computeBetFinancials(b, placementCash, settledNetByBetId[String(b.id)]);
        return {
          id: b.id,
          match_id: b.match_id,
          eventid: b.eventid,
          match_title: b.match_title,
          game_type: b.game_type,
          market_type: b.market_type,
          sport_id: b.sport_id,
          result_status: b.result_status,
          stake: parseFloat(b.stake_amount) || 0,
          debit: r2(fin.debit),
          credit: r2(fin.credit),
          refund: r2(fin.refund),
          profit_loss: r2(fin.profit_loss),
        };
      });

      const groupKey = (b) =>
        `${b.eventid || b.match_id || '-'}|${b.game_type || '-'}|${b.market_type || '-'}`;
      // Event-level key (no market breakdown)
      const eventKey = (b) => `${b.eventid || b.match_id || '-'}`;
      const groups = new Map();
      const eventGroups = new Map();
      for (const b of enrichedAll) {
        const key = groupKey(b);
        if (!groups.has(key)) {
          groups.set(key, {
            match_id: b.match_id,
            match_title: b.match_title,
            game_type: b.game_type,
            market_type: b.market_type,
            sport_id: b.sport_id,
            bet_count: 0,
            won_count: 0,
            loss_count: 0,
            pending_count: 0,
            refund_count: 0,
            total_stake: 0,
            total_debit: 0,
            total_credit: 0,
            total_released: 0,
            total_pl: 0,
            net_wallet_impact: 0,
            bet_ids: [],
            first_bet_at: null,
          });
        }
        const g = groups.get(key);
        g.bet_count += 1;
        const status = (b.result_status || '').toLowerCase();
        if (status === 'won' || status === 'win') g.won_count += 1;
        else if (['loss', 'lost', 'lose'].includes(status)) g.loss_count += 1;
        else if (['refund', 'refunded', 'void', 'cancelled'].includes(status)) g.refund_count += 1;
        else g.pending_count += 1;
        g.total_stake += b.stake;
        g.total_debit += b.debit || 0;
        g.total_credit += b.credit || 0;
        g.total_released += b.refund || 0;
        g.total_pl += b.profit_loss || 0;
        g.bet_ids.push(b.id);

        // Also accumulate into event-level groups (no market breakdown)
        const ekey = eventKey(b);
        if (!eventGroups.has(ekey)) {
          eventGroups.set(ekey, {
            match_id: b.match_id,
            match_title: b.match_title,
            sport_id: b.sport_id,
            market_count: new Set(),
            bet_count: 0,
            won_count: 0,
            loss_count: 0,
            pending_count: 0,
            refund_count: 0,
            total_stake: 0,
            total_released: 0,
            total_pl: 0,
            net_wallet_impact: 0,
            bet_ids: [],
          });
        }
        const eg = eventGroups.get(ekey);
        eg.bet_count += 1;
        if (status === 'won' || status === 'win') eg.won_count += 1;
        else if (['loss', 'lost', 'lose'].includes(status)) eg.loss_count += 1;
        else if (['refund', 'refunded', 'void', 'cancelled'].includes(status)) eg.refund_count += 1;
        else eg.pending_count += 1;
        eg.total_stake += b.stake;
        eg.total_released += b.refund || 0;
        eg.total_pl += b.profit_loss || 0;
        eg.market_count.add(b.market_type || b.game_type || '-');
        eg.bet_ids.push(b.id);
      }

      // For pending bets we need to know currently-locked amount per group.
      // Walk enrichedAll again and split bets by status.
      const lockedByGroup = new Map();
      const lockedByEvent = new Map();
      for (const b of enrichedAll) {
        const key = groupKey(b);
        const ekey = eventKey(b);
        const status = (b.result_status || '').toLowerCase();
        const isPending = !['won', 'win', 'loss', 'lost', 'lose', 'refund', 'refunded', 'void', 'cancelled'].includes(status);
        if (isPending) {
          lockedByGroup.set(key, (lockedByGroup.get(key) || 0) + (b.debit || 0));
          lockedByEvent.set(ekey, (lockedByEvent.get(ekey) || 0) + (b.debit || 0));
        }
      }

      const by_event = [];
      const totals = {
        bet_count: 0,
        won_count: 0,
        loss_count: 0,
        pending_count: 0,
        refund_count: 0,
        total_stake: 0,
        total_pl: 0,
        total_released: 0,
        total_locked: 0,
        net_wallet_impact: 0,
      };
      for (const [key, g] of groups) {
        // Net wallet impact for the group:
        //   = sum of realized P/Ls (settled bets)
        //     + sum of currently-locked amounts (pending bets, NEGATIVE)
        //
        // We DELIBERATELY do NOT add `released` here. A hedge release
        // (e.g. +1000 on bet 95) is the offset of the EARLIER bet's lock
        // (-1000 on bet 94 in the same market) — including released would
        // double-count that offset against the bets' own P/L. Sum of
        // individual bet P/Ls already equals the correct market net.
        // `released` is shown separately for transparency only.
        const locked = lockedByGroup.get(key) || 0;
        g.total_locked = r2(-locked); // negative = locked away from wallet
        g.net_wallet_impact = r2(g.total_pl + g.total_locked);

        g.total_stake = r2(g.total_stake);
        g.total_debit = r2(g.total_debit);
        g.total_credit = r2(g.total_credit);
        g.total_released = r2(g.total_released);
        g.total_pl = r2(g.total_pl);
        by_event.push(g);

        totals.bet_count += g.bet_count;
        totals.won_count += g.won_count;
        totals.loss_count += g.loss_count;
        totals.pending_count += g.pending_count;
        totals.refund_count += g.refund_count;
        totals.total_stake += g.total_stake;
        totals.total_pl += g.total_pl;
        totals.total_released += g.total_released;
        totals.total_locked += g.total_locked;
        totals.net_wallet_impact += g.net_wallet_impact;
      }
      // Newest event first (sort by max bet id within the group)
      by_event.sort((a, b) => Math.max(...b.bet_ids) - Math.max(...a.bet_ids));
      totals.total_stake = r2(totals.total_stake);
      totals.total_pl = r2(totals.total_pl);
      totals.total_released = r2(totals.total_released);
      totals.total_locked = r2(totals.total_locked);
      totals.net_wallet_impact = r2(totals.net_wallet_impact);

      // === EVENT-ONLY SUMMARY (by_match) ===
      // Aggregates all markets for the same match into a single row.
      const by_match = [];
      const matchTotals = {
        bet_count: 0, won_count: 0, loss_count: 0,
        pending_count: 0, refund_count: 0,
        total_stake: 0, total_pl: 0, total_released: 0,
        total_locked: 0, net_wallet_impact: 0,
      };
      for (const [ekey, eg] of eventGroups) {
        const locked = lockedByEvent.get(ekey) || 0;
        eg.total_locked = r2(-locked);
        eg.net_wallet_impact = r2(eg.total_pl + eg.total_locked);
        eg.total_stake = r2(eg.total_stake);
        eg.total_released = r2(eg.total_released);
        eg.total_pl = r2(eg.total_pl);
        eg.market_count = eg.market_count.size; // convert Set → count
        by_match.push(eg);

        matchTotals.bet_count += eg.bet_count;
        matchTotals.won_count += eg.won_count;
        matchTotals.loss_count += eg.loss_count;
        matchTotals.pending_count += eg.pending_count;
        matchTotals.refund_count += eg.refund_count;
        matchTotals.total_stake += eg.total_stake;
        matchTotals.total_pl += eg.total_pl;
        matchTotals.total_released += eg.total_released;
        matchTotals.total_locked += eg.total_locked;
        matchTotals.net_wallet_impact += eg.net_wallet_impact;
      }
      by_match.sort((a, b) => Math.max(...b.bet_ids) - Math.max(...a.bet_ids));
      matchTotals.total_stake = r2(matchTotals.total_stake);
      matchTotals.total_pl = r2(matchTotals.total_pl);
      matchTotals.total_released = r2(matchTotals.total_released);
      matchTotals.total_locked = r2(matchTotals.total_locked);
      matchTotals.net_wallet_impact = r2(matchTotals.net_wallet_impact);

      return res.status(200).json({
        success: true,
        data: enriched,
        summary: { by_event, totals, by_match, match_totals: matchTotals },
        user: { user_id: targetUser.user_id, username: targetUser.username },
        pagination: {
          total: count,
          page: parseInt(page),
          limit: parseInt(limit),
          totalPages: Math.ceil(count / parseInt(limit)),
        },
      });
    } catch (error) {
      console.error('❌ getUserBetHistory error:', error);
      return res.status(500).json({ success: false, error: error.message });
    }
  },

  // 📜 Login History — /admin/reports/user-history page (Login History tab).
  // Rows come from user_activity_logs (action LOGIN / LOGIN_2FA), which the
  // auth controllers have been writing for USER, STAFF and OWNER logins.
  getLoginHistory: async (req, res) => {
    try {
      const { username, page = 1, limit = 25, fromDate, toDate } = req.query;

      if (!username || !username.trim()) {
        return res.status(200).json({
          success: true,
          data: [],
          pagination: { total: 0, page: 1, limit: parseInt(limit), totalPages: 0 },
          message: 'Please select a user',
        });
      }

      const target = await resolveHistoryTarget(req, username);
      if (target.error === 'not_downline') {
        return res.status(403).json({ success: false, message: 'User is not in your downline' });
      }
      if (target.error === 'not_found') {
        return res.status(200).json({
          success: true,
          data: [],
          pagination: { total: 0, page: 1, limit: parseInt(limit), totalPages: 0 },
          message: 'User not found',
        });
      }

      const where = {
        // LOGIN_2FA is the completed login for 2FA-enabled accounts (the
        // plain LOGIN action is skipped for them), so both count as logins.
        action: { [Op.in]: ['LOGIN', 'LOGIN_2FA'] },
        user_type: target.type,
        ...(target.type === 'USER'
          ? { user_id: target.id }
          : target.type === 'OWNER'
            ? { owner_id: target.id }
            : { staff_id: target.id }),
      };
      if (fromDate && toDate) {
        where.createdAt = { [Op.between]: [new Date(fromDate), new Date(toDate + 'T23:59:59.999Z')] };
      } else if (fromDate) {
        where.createdAt = { [Op.gte]: new Date(fromDate) };
      } else if (toDate) {
        where.createdAt = { [Op.lte]: new Date(toDate + 'T23:59:59.999Z') };
      }

      const offset = (parseInt(page) - 1) * parseInt(limit);
      const { count, rows } = await UserActivityLog.findAndCountAll({
        where,
        attributes: ['id', 'username', 'ip_address', 'createdAt'],
        order: [['createdAt', 'DESC']],
        limit: parseInt(limit),
        offset,
        raw: true,
      });

      return res.status(200).json({
        success: true,
        data: rows.map(r => ({
          id: r.id,
          username: r.username,
          login_at: r.createdAt,
          ip: normalizeIp(r.ip_address),
        })),
        pagination: {
          total: count,
          page: parseInt(page),
          limit: parseInt(limit),
          totalPages: Math.ceil(count / parseInt(limit)),
        },
      });
    } catch (error) {
      console.error('❌ getLoginHistory error:', error);
      return res.status(500).json({ success: false, error: error.message });
    }
  },

  // 📜 Change Password History — /admin/reports/user-history page (2nd tab).
  // Rows come from user_activity_logs action PASSWORD_CHANGE, logged against
  // the account whose password changed; details JSON carries changed_by.
  getPasswordHistory: async (req, res) => {
    try {
      const { username, page = 1, limit = 25, fromDate, toDate } = req.query;

      if (!username || !username.trim()) {
        return res.status(200).json({
          success: true,
          data: [],
          pagination: { total: 0, page: 1, limit: parseInt(limit), totalPages: 0 },
          message: 'Please select a user',
        });
      }

      const target = await resolveHistoryTarget(req, username);
      if (target.error === 'not_downline') {
        return res.status(403).json({ success: false, message: 'User is not in your downline' });
      }
      if (target.error === 'not_found') {
        return res.status(200).json({
          success: true,
          data: [],
          pagination: { total: 0, page: 1, limit: parseInt(limit), totalPages: 0 },
          message: 'User not found',
        });
      }

      const where = {
        action: 'PASSWORD_CHANGE',
        user_type: target.type,
        ...(target.type === 'USER'
          ? { user_id: target.id }
          : target.type === 'OWNER'
            ? { owner_id: target.id }
            : { staff_id: target.id }),
      };
      if (fromDate && toDate) {
        where.createdAt = { [Op.between]: [new Date(fromDate), new Date(toDate + 'T23:59:59.999Z')] };
      } else if (fromDate) {
        where.createdAt = { [Op.gte]: new Date(fromDate) };
      } else if (toDate) {
        where.createdAt = { [Op.lte]: new Date(toDate + 'T23:59:59.999Z') };
      }

      const offset = (parseInt(page) - 1) * parseInt(limit);
      const { count, rows } = await UserActivityLog.findAndCountAll({
        where,
        attributes: ['id', 'username', 'ip_address', 'details', 'createdAt'],
        order: [['createdAt', 'DESC']],
        limit: parseInt(limit),
        offset,
        raw: true,
      });

      return res.status(200).json({
        success: true,
        data: rows.map(r => {
          let changedBy = null;
          try {
            changedBy = JSON.parse(r.details)?.changed_by || null;
          } catch { /* details not JSON — self change fallback below */ }
          return {
            id: r.id,
            username: r.username,
            changed_at: r.createdAt,
            ip: normalizeIp(r.ip_address),
            changed_by: changedBy || r.username,
          };
        }),
        pagination: {
          total: count,
          page: parseInt(page),
          limit: parseInt(limit),
          totalPages: Math.ceil(count / parseInt(limit)),
        },
      });
    } catch (error) {
      console.error('❌ getPasswordHistory error:', error);
      return res.status(500).json({ success: false, error: error.message });
    }
  },

  // Turnover Report - login user ki hierarchy ke sare users ki bets (sports ya casino)
  getTurnoverReport: async (req, res) => {
    try {
      const { type, fromDate, toDate, user_id, sport_id, gtype, game_name } = req.body;

      // type compulsory hai
      if (type !== 'sports' && type !== 'casino') {
        return res.status(400).json({ success: false, message: 'type is required (sports/casino)' });
      }

      // sports me sport_id bhi compulsory hai
      if (type === 'sports' && !sport_id) {
        return res.status(400).json({ success: false, message: 'sport_id is required for sports type' });
      }

      let userIds = [];

      if (user_id) {
        const staff = await Staff.findByPk(user_id, { attributes: ['staff_id', 'username'], raw: true });
        if (staff) {
          userIds = await getUserIdsByHierarchy('STAFF', staff.username);
        } else {
          userIds = [Number(user_id)];
        }
      } else {
        // user_id nahi aayi to login wale ki puri hierarchy
        userIds = await getUserIdsByHierarchy(req.user?.role, req.user?.username);
      }

      const where = {
        user_id: { [Op.in]: userIds },
        created_at: {
          [Op.between]: [new Date(fromDate), new Date(toDate + 'T23:59:59.999Z')],
        },
      };

      let bets = [];

      if (type === 'sports') {
        if (sport_id) where.sport_id = sport_id;
        // gtype normalize karke match (iLike = case-insensitive)
        if (gtype) where.gtype = { [Op.iLike]: normalizeGtype(gtype) };
        bets = await SportsBet.findAll({ where, order: [['created_at', 'DESC']], raw: true });
      } else {
        if (game_name) where.game_name = game_name;
        bets = await CasinoBet.findAll({ where, order: [['created_at', 'DESC']], raw: true });
      }

      // win / loss bets alag alag array me
      const winBets = [];
      const lossBets = [];
      for (const bet of bets) {
        // sports me 'loss' aata hai, casino me 'lost'
        if (bet.result_status === 'won') winBets.push(bet);
        else if (bet.result_status === 'loss' || bet.result_status === 'lost') lossBets.push(bet);
      }

      // sari bets ka credit ledger ek hi query me
      const betIds = bets.map(bet => bet.id);
      const ledger = await CreditsLedger.findAll({
        where: {
          bet_id: { [Op.in]: betIds },
          category: type === 'sports' ? 'SPORTS' : 'CASINO',
        },
        raw: true,
      });

      // Win = profit ka sum, Loss = loss ka sum (ledger me loss negative hota hai)
      let win = 0;
      let loss = 0;
      for (const row of ledger) {
        win += parseFloat(row.profit) || 0;
        loss += parseFloat(row.loss) || 0;
      }
      loss = Math.abs(loss);

      // Turn Over = liability ka sum
      let winTurnover = 0;
      for (const bet of winBets) {
        winTurnover += Math.abs(parseFloat(type === 'sports' ? bet.liability : bet.libality) || 0);
      }
      let lossTurnover = 0;
      for (const bet of lossBets) {
        lossTurnover += Math.abs(parseFloat(type === 'sports' ? bet.liability : bet.libality) || 0);
      }

      const round = (n) => Math.round(n * 100) / 100;

      return res.status(200).json({
        success: true,
        loss_turnover: round(lossTurnover),
        loss: round(loss),
        win_turnover: round(winTurnover),
        win: round(win),
        total_turnover: round(winTurnover + lossTurnover),
        total_pl: round(win - loss),
      });
    } catch (error) {
      console.error('❌ getTurnoverReport error:', error);
      return res.status(500).json({ success: false, message: 'Internal server error' });
    }
  },

  // Account Statement ki game row ke saamne wala Excel icon — us row ke peeche
  // ke saare bets CSV ke liye. Row se sirf betId + category aati hai; kiska bet
  // hai aur uske saath aur kaun si bets thi, wo service resolve karti hai.
  getStatementBetExport: async (req, res) => {
    try {
      const role = (req.user?.role || '').toUpperCase();
      if (role === 'USER') {
        return res.status(403).json({ success: false, message: 'Only staff/owner can view this report' });
      }

      const result = await buildStatementBetExport(
        { role, username: req.user.username },
        { betId: req.body?.betId, category: req.body?.category },
      );

      if (!result?.success) {
        return res.status(result?.status || 400).json({ success: false, message: result?.message });
      }
      return res.status(200).json(result);
    } catch (error) {
      console.error('\u274c Get Statement Bet Export Error:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  },

  // Account Statement ki game row par click — "Details" modal ke bets.
  // Wahi resolver jo Excel icon use karta hai, bas JSON shape modal wala.
  // Casino Result modal (admin): the requester's downline bets on one round.
  // Plan: docs/plans/2026-10-09-admin-casino-result-round-bets.md
  getCasinoRoundBets: async (req, res) => {
    try {
      const role = (req.user?.role || '').toUpperCase();
      if (role === 'USER') {
        return res.status(403).json({ success: false, message: 'Only staff/owner can view this report' });
      }

      const result = await getCasinoRoundBets(
        { role, username: req.user.username },
        { gameName: req.query?.gameName, roundId: req.query?.roundId },
      );

      if (!result?.success) {
        return res.status(result?.status || 400).json({ success: false, message: result?.message });
      }
      return res.status(200).json(result);
    } catch (error) {
      console.error('❌ Get Casino Round Bets Error:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  },

  getStatementBetDetail: async (req, res) => {
    try {
      const role = (req.user?.role || '').toUpperCase();
      if (role === 'USER') {
        return res.status(403).json({ success: false, message: 'Only staff/owner can view this report' });
      }

      const result = await buildStatementBetDetail(
        { role, username: req.user.username },
        { betId: req.body?.betId, category: req.body?.category },
      );

      if (!result?.success) {
        return res.status(result?.status || 400).json({ success: false, message: result?.message });
      }
      return res.status(200).json(result);
    } catch (error) {
      console.error('\u274c Get Statement Bet Detail Error:', error);
      res.status(500).json({ success: false, error: error.message });
    }
  },
};

export default ReportsController;