import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import CasinoGameManage from '../../model/admin/CasinoGameManage.js';

// Where filename-typed tile art lives on disk (the frontend's asset folder,
// a sibling of server/ in the repo) — served through the API so EVERY tile
// image reaches clients as one exact server URL, whether the row stores a
// base64 data: URI or just "teen20.jpg".
const TILE_ASSETS_DIR = path.resolve(
    path.dirname(fileURLToPath(import.meta.url)),
    '../../../frontend/public/assets/casino/games'
);

// Casino Manage — the owner's switchboard for the VIP / Virtual / Premium
// tables. Two audiences:
//   * /api/admin/casino-manage/*  (owner-only) — full list + edits
//   * /api/user/casino-manage/games (public)   — enabled rows only, the
//     frontend's source for those provider tabs and their entry thresholds.

const VALID_CATEGORIES = ['our', 'vip', 'virtual', 'premium'];

// Display order. sort_order is per category and owner-controlled (see the
// reorder endpoint below); id is the tiebreak so rows that share a position —
// only possible on a row created outside the reorder flow — stay deterministic.
// carouselController.js:22 has the identical constant for the same reason.
const LIST_ORDER = [['category', 'ASC'], ['sort_order', 'ASC'], ['id', 'ASC']];

// A tile image may be a bare filename (served from /assets/casino/games), an
// http(s) URL, or a base64 data: URI produced by the admin uploader. Reject
// anything that doesn't look like one of those — especially script-ish URIs.
const isValidImg = (img) =>
    typeof img === 'string' &&
    img.length <= 8 * 1024 * 1024 &&
    (/^data:image\/[a-z0-9.+-]+;base64,/i.test(img) ||
        /^https?:\/\//i.test(img) ||
        /^[\w][\w .-]*\.(png|jpe?g|gif|webp|svg)$/i.test(img));

// Every stored image — base64 data: URI or bare filename — is presented to
// clients as ONE exact server URL onto serveGameImage below. Base64 rows are
// heavy (hundreds of KB each), so lists must never inline them; filename rows
// are served from disk so no client ever needs the file shipped in its own
// build. Only full http(s) URLs pass through untouched. The URL is absolute
// (built from the request) so the admin panel — a different origin — renders
// it as-is.
// Scheme: this deploy's nginx doesn't pass X-Forwarded-Proto, so req.protocol
// reads http even though the site is https — and Safari blocks http images on
// an https page as mixed content. Honour the header when present, otherwise
// assume https for anything that isn't a private/local host (which is exactly
// where plain http is real: dev machines and LAN testing).
const publicBaseFor = (req) => {
    const host = req.get('host') || '';
    const forwarded = (req.get('x-forwarded-proto') || '').split(',')[0].trim();
    const isLocal = /^(localhost|127\.|0\.0\.0\.0|192\.168\.|10\.|172\.(1[6-9]|2\d|3[01])\.)/.test(host);
    const proto = forwarded || (req.secure ? 'https' : isLocal ? 'http' : 'https');
    return `${proto}://${host}`;
};

// The serving URL is keyed on the row id, so replacing a tile's art does NOT
// change it — and the response below is long-cached (max-age=86400), which
// means the browser never even asks again: the ETag and Last-Modified sitting
// on that response are never consulted. Measured on the live server
// (2026-09-14): a new upload landed on row 29 (Content-Length 12136 -> 37042,
// md5 matching the uploaded file) while the url stayed
// `/api/user/casino-manage/img/29` — so the admin panel and the player site both
// kept showing yesterday's picture for a full day after a save. Stamping
// updatedAt into the query string makes every save a NEW url, which fetches
// immediately while unchanged art still caches hard. Same fix, same reason, as
// home-slider (homeSliderController.js).
const publicImgFor = (req, row) => {
    if (row.img && !/^https?:\/\//i.test(row.img)) {
        const version = row.updatedAt ? new Date(row.updatedAt).getTime() : 0;
        return `${publicBaseFor(req)}/api/user/casino-manage/img/${row.id}?v=${version}`;
    }
    return row.img;
};
const withImgUrl = (req) => (game) => {
    const g = game.toJSON();
    g.img = publicImgFor(req, g);
    return g;
};

// Streams a row's tile art as a real image response, long-cached. Stored
// base64 decodes from the row; a bare filename is read from the frontend's
// asset folder on disk — either way the client sees the same URL shape.
export const serveGameImage = async (req, res) => {
    try {
        const game = await CasinoGameManage.findByPk(req.params.id, { attributes: ['id', 'img', 'updatedAt'] });
        if (!game || !game.img) return res.status(404).end();

        if (game.img.startsWith('data:')) {
            const match = game.img.match(/^data:(image\/[a-z0-9.+-]+);base64,(.*)$/is);
            if (!match) return res.status(404).end();
            const buffer = Buffer.from(match[2], 'base64');
            res.set('Content-Type', match[1]);
            res.set('Cache-Control', 'public, max-age=86400');
            res.set('Last-Modified', new Date(game.updatedAt).toUTCString());
            return res.send(buffer);
        }

        // Filename row: basename() strips any traversal, sendFile sets the type.
        const file = path.join(TILE_ASSETS_DIR, path.basename(game.img));
        if (!fs.existsSync(file)) return res.status(404).end();
        res.set('Cache-Control', 'public, max-age=86400');
        return res.sendFile(file);
    } catch (error) {
        console.error('casino-manage image error:', error);
        return res.status(500).end();
    }
};

// Multipart upload → base64 data URL. The admin panel posts the picked file
// here (multer memoryStorage, image/* only, 5MB cap enforced at the route)
// and gets back a dataUrl it can preview and save onto a game row.
export const uploadGameImage = async (req, res) => {
    if (!req.file) {
        return res.status(400).json({ success: false, error: 'No file uploaded' });
    }
    const dataUrl = `data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}`;
    return res.json({
        success: true,
        name: req.file.originalname,
        size: req.file.size,
        dataUrl,
    });
};

// Owner table: every game, every category, disabled ones included.
export const listGames = async (req, res) => {
    try {
        const games = await CasinoGameManage.findAll({ order: LIST_ORDER });
        return res.json({ success: true, data: games.map(withImgUrl(req)) });
    } catch (error) {
        console.error('casino-manage list error:', error);
        return res.status(500).json({ success: false, error: 'Failed to load casino games.' });
    }
};

// Single-row edit. enabled/min_balance are the switchboard knobs; name, route,
// tile_category and img are editable too so the owner can correct a tile
// without redeploying. game_type and category stay fixed — they're identity.
export const updateGame = async (req, res) => {
    try {
        const { id } = req.params;
        const game = await CasinoGameManage.findByPk(id);
        if (!game) {
            return res.status(404).json({ success: false, error: 'Game not found.' });
        }

        const updates = {};
        if (typeof req.body.enabled === 'boolean') {
            updates.enabled = req.body.enabled;
        }
        if (req.body.min_balance !== undefined) {
            const minBalance = Number(req.body.min_balance);
            if (!Number.isFinite(minBalance) || minBalance < 0) {
                return res.status(400).json({ success: false, error: 'min_balance must be a number ≥ 0.' });
            }
            updates.min_balance = minBalance;
        }
        if (req.body.name !== undefined) {
            const name = String(req.body.name).trim();
            if (!name || name.length > 80) {
                return res.status(400).json({ success: false, error: 'name must be 1–80 characters.' });
            }
            updates.name = name;
        }
        if (req.body.route !== undefined) {
            const route = String(req.body.route).trim();
            if (route && !/^\/[\w\/-]*$/.test(route)) {
                return res.status(400).json({ success: false, error: 'route must be an app path like /casino/teen20.' });
            }
            updates.route = route;
        }
        if (req.body.tile_category !== undefined) {
            const tileCategory = String(req.body.tile_category || '').trim().toLowerCase();
            updates.tile_category = tileCategory || null;
        }
        if (req.body.img !== undefined) {
            if (req.body.img === null || req.body.img === '') {
                updates.img = null;
            } else if (isValidImg(req.body.img)) {
                updates.img = req.body.img;
            } else {
                return res.status(400).json({ success: false, error: 'img must be a filename, http(s) URL, or base64 image data URI (≤4MB).' });
            }
        }
        // Validated against the row's CURRENT values so a partial edit — e.g.
        // flipping launch_type without resending game_uid — is judged on what
        // the row will actually look like afterwards. resolveLaunchFields is a
        // const declared below; that is fine, this runs per request, long after
        // the module finished evaluating.
        if (req.body.launch_type !== undefined || req.body.game_uid !== undefined) {
            const launch = resolveLaunchFields(req.body, {
                launch_type: game.launch_type,
                game_uid: game.game_uid,
            });
            if (launch.error) {
                return res.status(400).json({ success: false, error: launch.error });
            }
            Object.assign(updates, launch.updates);
        }

        if (Object.keys(updates).length === 0) {
            return res.status(400).json({ success: false, error: 'Nothing to update.' });
        }

        await game.update(updates);
        return res.json({ success: true, data: withImgUrl(req)(game) });
    } catch (error) {
        console.error('casino-manage update error:', error);
        return res.status(500).json({ success: false, error: 'Failed to update the game.' });
    }
};

// Add a game (Our Casino grid primarily, but any category works). game_type is
// derived server-side and de-duplicated — the panel never sends one.
const VALID_LAUNCH_TYPES = ['table', 'third_party'];

// A third-party tile's route is DERIVED, never typed. The owner picks the type
// and pastes the game id; the path follows from the id, so there is nothing to
// get wrong and nothing to collide with an in-house table route. The frontend
// reads the id straight back out of the path, which is what lets a bookmark or
// a pasted link launch the game without first loading the catalog.
export const thirdPartyRoute = (gameUid) => `/casino/slot/${gameUid}`;

// Resolves launch_type + game_uid against what the row will look like AFTER
// the write, not just what this request carried — an update that flips
// launch_type to 'third_party' without resending game_uid is still valid if the
// row already has one, and one that clears game_uid on an existing third-party
// row must be rejected.
//
// Blocking the empty combination here is deliberate: a third-party tile with no
// game_uid renders and clicks exactly like a working one and then launches
// nothing, which is indistinguishable from an outage from the player's side.
const resolveLaunchFields = (body, current = {}) => {
    const updates = {};

    if (body.launch_type !== undefined) {
        const launchType = String(body.launch_type).trim();
        if (!VALID_LAUNCH_TYPES.includes(launchType)) {
            return { error: "launch_type must be 'table' or 'third_party'." };
        }
        updates.launch_type = launchType;
    }

    if (body.game_uid !== undefined) {
        const gameUid = String(body.game_uid || '').trim();
        if (gameUid.length > 255) {
            return { error: 'game_uid must be 255 characters or fewer.' };
        }
        updates.game_uid = gameUid || null;
    }

    const finalType = updates.launch_type ?? current.launch_type ?? 'table';
    const finalUid = updates.game_uid !== undefined ? updates.game_uid : (current.game_uid ?? null);
    if (finalType === 'third_party' && !finalUid) {
        return { error: 'game_uid is required when launch type is 3rd party casino.' };
    }
    // A table row keeps no stale uid — otherwise flipping back and forth leaves
    // a uid behind that nothing reads but the edit form still shows.
    if (finalType === 'table' && updates.launch_type === 'table') {
        updates.game_uid = null;
    }

    // Derived, so it always matches the id currently on the row — including
    // when only the id changed. Returned as `route` so the caller can let it
    // overwrite whatever the panel sent.
    if (finalType === 'third_party') {
        updates.route = thirdPartyRoute(finalUid);
    }

    return { updates };
};

export const createGame = async (req, res) => {
    try {
        const name = String(req.body.name || '').trim();
        if (!name || name.length > 80) {
            return res.status(400).json({ success: false, error: 'name must be 1–80 characters.' });
        }
        const category = VALID_CATEGORIES.includes(req.body.category) ? req.body.category : 'our';
        const route = String(req.body.route || '').trim();
        if (route && !/^\/[\w\/-]*$/.test(route)) {
            return res.status(400).json({ success: false, error: 'route must be an app path like /casino/teen20.' });
        }
        let img = null;
        if (req.body.img) {
            if (!isValidImg(req.body.img)) {
                return res.status(400).json({ success: false, error: 'img must be a filename, http(s) URL, or base64 image data URI (≤4MB).' });
            }
            img = req.body.img;
        }
        const minBalance = Number(req.body.min_balance ?? 0);
        if (!Number.isFinite(minBalance) || minBalance < 0) {
            return res.status(400).json({ success: false, error: 'min_balance must be a number ≥ 0.' });
        }
        const tileCategory = String(req.body.tile_category || '').trim().toLowerCase() || null;

        // Unique key from the route segment (or the name), suffixed on clash.
        const seg = (route.split('/').filter(Boolean).pop() || name)
            .toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 30) || 'game';
        let gameType = `${category}-${seg}`;
        for (let n = 2; await CasinoGameManage.findOne({ where: { game_type: gameType } }); n += 1) {
            gameType = `${category}-${seg}-${n}`;
        }

        // A new game lands at the END of its category's grid, where the owner
        // can then move it up. carouselController.js:63 does the same.
        const maxOrder = await CasinoGameManage.max('sort_order', { where: { category } });
        const sortOrder = Number.isFinite(maxOrder) ? maxOrder + 1 : 0;

        const launch = resolveLaunchFields(req.body);
        if (launch.error) {
            return res.status(400).json({ success: false, error: launch.error });
        }

        const game = await CasinoGameManage.create({
            game_type: gameType,
            name,
            route,
            category,
            tile_category: tileCategory,
            img,
            min_balance: minBalance,
            enabled: req.body.enabled === false ? false : true,
            sort_order: sortOrder,
            ...launch.updates,
        });
        return res.status(201).json({ success: true, data: withImgUrl(req)(game) });
    } catch (error) {
        console.error('casino-manage create error:', error);
        return res.status(500).json({ success: false, error: 'Failed to add the game.' });
    }
};

// Rearrange one category's grid. The panel shows a single category at a time
// and posts that tab's ids in their new order; position = index in the array.
// Scoped to a category on purpose: reordering Virtual must never renumber the
// Our Casino grid, so ids are verified to belong to the posted category before
// anything is written. Modelled on carouselController.reorderCarousels.
export const reorderGames = async (req, res) => {
    try {
        const { category, order } = req.body;

        if (!VALID_CATEGORIES.includes(category)) {
            return res.status(400).json({ success: false, error: `category must be one of ${VALID_CATEGORIES.join(', ')}.` });
        }
        if (!Array.isArray(order) || order.length === 0 || order.some((id) => !Number.isInteger(Number(id)))) {
            return res.status(400).json({ success: false, error: 'order must be a non-empty array of game ids.' });
        }
        const ids = order.map(Number);
        if (new Set(ids).size !== ids.length) {
            return res.status(400).json({ success: false, error: 'order must not repeat an id.' });
        }

        // Every id has to be a row of THIS category. A short count means the
        // payload carried an unknown id or one from another tab — reject the
        // whole thing rather than half-applying it.
        const rows = await CasinoGameManage.findAll({
            where: { id: ids, category },
            attributes: ['id'],
        });
        if (rows.length !== ids.length) {
            return res.status(400).json({ success: false, error: `order must contain only ids from the '${category}' category.` });
        }

        await Promise.all(
            ids.map((id, index) => CasinoGameManage.update({ sort_order: index }, { where: { id } }))
        );

        const games = await CasinoGameManage.findAll({ where: { category }, order: LIST_ORDER });
        return res.json({ success: true, data: games.map(withImgUrl(req)) });
    } catch (error) {
        console.error('casino-manage reorder error:', error);
        return res.status(500).json({ success: false, error: 'Failed to reorder the games.' });
    }
};

// Frontend list. Public on purpose — the /o_casino page shows tiles before
// login too (entering is what needs auth + balance, not looking). Disabled
// rows ARE included, carrying enabled:false: the frontend needs them to hide
// a managed game from the main Our Casino grid as well (teen20v1 lives in
// both lists), which a filtered response couldn't distinguish from a game
// that simply isn't managed.
export const listPublicGames = async (req, res) => {
    try {
        const games = await CasinoGameManage.findAll({
            // updatedAt rides along purely to version the image url (publicImgFor).
            attributes: ['id', 'game_type', 'name', 'route', 'category', 'tile_category', 'min_balance', 'img', 'enabled', 'sort_order', 'launch_type', 'game_uid', 'updatedAt'],
            order: LIST_ORDER,
        });
        return res.json({ success: true, data: games.map(withImgUrl(req)) });
    } catch (error) {
        console.error('casino-manage public list error:', error);
        return res.status(500).json({ success: false, error: 'Failed to load casino games.' });
    }
};
