import { Op } from 'sequelize';
import BetBufferConfig from '../../model/admin/BetBufferConfig.js';
import BetLimitOverride from '../../model/admin/BetLimitOverride.js';
import MaxOddsConfig from '../../model/admin/MaxOddsConfig.js';
import { getAutoVoidConfig, AUTO_VOID_MIN_DELAY, AUTO_VOID_MAX_DELAY } from '../../model/admin/AutoVoidConfig.js';
import { voidDueAt } from '../../sportsbet/betresult/autoVoid.js';
import ResultSourceLink, { ensureResultSourceLinks } from '../../model/admin/ResultSourceLink.js';
import { isPerSelectionMarket } from '../../helper/exposureBucket.js';
import { QueryTypes } from 'sequelize';
import sequelize from '../../config/db.js';
import VirtualBetLimit, { virtualLeagues, seedVirtualBetLimits } from '../../model/admin/VirtualBetLimit.js';
import CasinoGameManage from '../../model/admin/CasinoGameManage.js';
import TableCasino from '../../model/admin/TableCasino.js';
import CricketService from '../../services/CricketService.js';
import BettingConfigService from '../../services/BettingConfigService.js';
import SportsConfig from '../../model/user/SportsConfig.js';
import { SPORTS_LIST, sportNameById } from '../../constants/sportsList.js';
import {
    DEFAULT_LEAGUE_KEY,
    leagueOptionsForSport,
    isValidLeagueKey,
} from '../../constants/commissionLeagues.js';

// Owner-only control panel for:
//   * Buffer Time  — seconds the bet slip watches the price before booking,
//                    per sport × league × market (the Commission grid's keys)
//                    and per casino game.
//   * Bet Limits   — min / max stake overrides, per live-match market and per
//                    casino game.
//   * Max Odds     — highest rate a bet may be placed at, per sport ×
//                    (match_odds | bookmaker); cricket cells may be limited
//                    to Oneday / T20 (Test exempt).
//
// Every write invalidates the matching Redis key in BettingConfigService, so
// the player-facing endpoints pick the change up on their next read without a
// restart. Reads here go straight to the DB on purpose: the admin must always
// see what is actually stored, never a cached copy.

const BUFFER_MARKETS = BetBufferConfig.MARKETS; // the Commission grid's market list
const BUFFER_MARKET_KEYS = BetBufferConfig.MARKET_KEYS;
const MAX_BUFFER_SECONDS = 60;
const BULK_LIMIT = 500;

const fail = (res, code, message) => res.status(code).json({ success: false, error: message });

// Buffer input: 0 clears the setting (falls back to platform/env default).
const parseBuffer = (raw) => {
    const n = Number(raw);
    if (!Number.isFinite(n) || n < 0 || n > MAX_BUFFER_SECONDS) return null;
    return Math.round(n * 100) / 100;
};

// Limit input: '' / null / 0 all mean "not overridden" and store NULL.
const parseLimit = (raw) => {
    if (raw === undefined || raw === null || raw === '') return null;
    const n = Number(raw);
    if (!Number.isFinite(n) || n < 0) return undefined; // undefined = invalid
    return n > 0 ? Math.round(n * 100) / 100 : null;
};

// The catalog of casino games an owner can configure: the Casino Manage rows
// (VIP / Virtual / Premium / Our) plus the fixed Our-Casino table list, keyed
// by the SAME string /casino/placebet receives as `gameName`. Casino Manage
// prefixes its Our-Casino rows with "our-" for uniqueness inside that table,
// but the bet payload never carries the prefix — so it is stripped here.
const casinoGameCatalog = async () => {
    const byKey = new Map();

    for (const table of TableCasino.FIXED_TABLES || []) {
        const key = String(table.tableid || '').toLowerCase();
        if (!key) continue;
        byKey.set(key, { game_name: key, name: table.tablename || key, category: 'our' });
    }

    try {
        const rows = await CasinoGameManage.findAll({
            attributes: ['game_type', 'name', 'category'],
            raw: true,
        });
        for (const row of rows) {
            const key = String(row.game_type || '').replace(/^our-/, '').toLowerCase();
            if (!key) continue;
            // A Casino Manage row is the better label (it is what the player
            // sees on the tile), so it wins over the fixed-table name.
            byKey.set(key, { game_name: key, name: row.name || key, category: row.category || 'our' });
        }
    } catch (err) {
        console.warn('[bettingConfig] casino catalog read failed:', err.message);
    }

    const order = { our: 0, vip: 1, virtual: 2, premium: 3 };
    return [...byKey.values()].sort(
        (a, b) => (order[a.category] ?? 9) - (order[b.category] ?? 9) || a.name.localeCompare(b.name)
    );
};

//======================================================================
// BUFFER TIME
//======================================================================

// GET /api/admin/betting-config/buffer/sports
// Every sport → its leagues ('default' + the variants in
// constants/commissionLeagues.js) → every market — the Commission grid.
// Per cell: { state: 'set' | 'inherit', seconds, inherited }
//   default league → always 'set'; 0 = the site default.
//   variant league → 'inherit' when it has no row (seconds = the main tab's
//   value it follows), 'set' when it has its own row (0 included).
const getSportsBuffers = async (req, res) => {
    try {
        const rows = await BetBufferConfig.findAll({
            where: { scope: 'sports' },
            attributes: ['sport_id', 'league_key', 'category', 'buffer_seconds'],
            raw: true,
        });

        const saved = new Map();
        for (const row of rows) {
            saved.set(
                `${row.sport_id}:${row.league_key || DEFAULT_LEAGUE_KEY}:${row.category}`,
                Number(row.buffer_seconds) || 0
            );
        }

        // Sports the platform has actually enabled float to the top; the rest
        // stay listed so a sport can be tuned before it is switched on.
        let enabled = new Set();
        try {
            const cfg = await SportsConfig.findAll({
                where: { enabled: true }, attributes: ['game_id'], raw: true,
            });
            enabled = new Set(cfg.map((c) => String(c.game_id)));
        } catch { /* SportsConfig unavailable — list everything, unsorted */ }

        const sports = SPORTS_LIST.map(([sportId, name]) => {
            const leagues = leagueOptionsForSport(sportId).map((league) => {
                const cells = {};
                for (const marketKey of BUFFER_MARKET_KEYS) {
                    const parent = saved.get(`${sportId}:${DEFAULT_LEAGUE_KEY}:${marketKey}`) || 0;
                    const own = saved.get(`${sportId}:${league.key}:${marketKey}`);
                    if (league.is_default) {
                        cells[marketKey] = { state: 'set', seconds: own || 0, inherited: null };
                    } else if (own !== undefined) {
                        cells[marketKey] = { state: 'set', seconds: own, inherited: parent };
                    } else {
                        cells[marketKey] = { state: 'inherit', seconds: parent, inherited: parent };
                    }
                }
                const configuredCount = BUFFER_MARKET_KEYS.filter((k) => cells[k].seconds > 0).length;
                return { ...league, cells, configured_count: configuredCount };
            });
            return { sport_id: Number(sportId), name, enabled: enabled.has(sportId), leagues };
        }).sort((a, b) => (b.enabled === a.enabled ? 0 : b.enabled ? 1 : -1));

        return res.json({
            success: true,
            markets: BUFFER_MARKETS,
            market_keys: BUFFER_MARKET_KEYS,
            default_league_key: DEFAULT_LEAGUE_KEY,
            max_seconds: MAX_BUFFER_SECONDS,
            sports,
        });
    } catch (err) {
        console.error('getSportsBuffers error:', err);
        return fail(res, 500, 'Failed to load sports buffer configuration');
    }
};

/**
 * Validate one sports buffer cell. Returns { error } or the clean values.
 * The pre-2026-09-15 `category` field is still read, so an admin bundle cached
 * in a browser gets a clear refusal: 'match_odds' is two markets now.
 */
const parseBufferCell = (body) => {
    const sportId = Number(body?.sport_id);
    const leagueKey = String(body?.league_key || DEFAULT_LEAGUE_KEY).toLowerCase().trim();
    const marketKey = String(body?.market_key || body?.category || '').toLowerCase().trim();
    const seconds = parseBuffer(body?.buffer_seconds);

    if (!Number.isInteger(sportId) || sportId <= 0) return { error: 'sport_id is required' };
    if (!BUFFER_MARKET_KEYS.includes(marketKey)) {
        const legacy = BetBufferConfig.LEGACY_CATEGORY_EXPANSION[marketKey];
        return {
            error: legacy
                ? `'${marketKey}' is no longer a single market — use ${legacy.join(' or ')}`
                : `market_key must be one of ${BUFFER_MARKET_KEYS.join(', ')}`,
        };
    }
    if (!isValidLeagueKey(sportId, leagueKey)) {
        const allowed = leagueOptionsForSport(sportId).map((l) => l.key).join(', ');
        return { error: `league_key '${leagueKey}' is not configured for sport ${sportId} (allowed: ${allowed})` };
    }
    if (seconds === null) return { error: `buffer_seconds must be between 0 and ${MAX_BUFFER_SECONDS}` };

    return { sportId, leagueKey, marketKey, seconds };
};

const upsertBufferCell = async ({ sportId, leagueKey, marketKey, seconds }) => {
    const where = { scope: 'sports', sport_id: sportId, league_key: leagueKey, category: marketKey };
    const existing = await BetBufferConfig.findOne({ where });
    if (existing) {
        await existing.update({ buffer_seconds: seconds });
    } else {
        await BetBufferConfig.create({ ...where, game_name: null, buffer_seconds: seconds });
    }
};

// POST /api/admin/betting-config/buffer/sports
// { sport_id, league_key?, market_key, buffer_seconds }  — 0 = the site default.
const saveSportsBuffer = async (req, res) => {
    try {
        const cell = parseBufferCell(req.body);
        if (cell.error) return fail(res, 400, cell.error);

        await upsertBufferCell(cell);
        await BettingConfigService.invalidateBuffers();

        return res.json({
            success: true,
            sport_id: cell.sportId,
            league_key: cell.leagueKey,
            market_key: cell.marketKey,
            buffer_seconds: cell.seconds,
        });
    } catch (err) {
        console.error('saveSportsBuffer error:', err);
        return fail(res, 500, 'Failed to save buffer time');
    }
};

// POST /api/admin/betting-config/buffer/sports/bulk
// { items: [{ sport_id, league_key?, market_key, buffer_seconds }, …] }
// The screen saves every dirty cell at once. Validated as a whole first: one
// bad cell rejects the batch rather than leaving the grid half applied.
const saveSportsBufferBulk = async (req, res) => {
    try {
        const items = Array.isArray(req.body?.items) ? req.body.items : null;
        if (!items || items.length === 0) return fail(res, 400, 'items must be a non-empty array');
        if (items.length > BULK_LIMIT) return fail(res, 400, `items may not exceed ${BULK_LIMIT} cells`);

        const cells = [];
        for (let i = 0; i < items.length; i += 1) {
            const cell = parseBufferCell(items[i]);
            if (cell.error) return fail(res, 400, `item ${i}: ${cell.error}`);
            cells.push(cell);
        }

        for (const cell of cells) await upsertBufferCell(cell);
        await BettingConfigService.invalidateBuffers();

        return res.json({ success: true, saved: cells.length });
    } catch (err) {
        console.error('saveSportsBufferBulk error:', err);
        return fail(res, 500, 'Failed to save buffer times');
    }
};

// DELETE /api/admin/betting-config/buffer/sports
// { sport_id, league_key, market_key }  → the cell goes back to INHERIT.
// Only a league override can be reset; a default cell is cleared by saving 0.
const resetSportsBuffer = async (req, res) => {
    try {
        const sportId = Number(req.body?.sport_id);
        const leagueKey = String(req.body?.league_key || '').toLowerCase().trim();
        const marketKey = String(req.body?.market_key || '').toLowerCase().trim();

        if (!Number.isInteger(sportId) || sportId <= 0) return fail(res, 400, 'sport_id is required');
        if (!BUFFER_MARKET_KEYS.includes(marketKey)) {
            return fail(res, 400, `market_key must be one of ${BUFFER_MARKET_KEYS.join(', ')}`);
        }
        if (!leagueKey || leagueKey === DEFAULT_LEAGUE_KEY) {
            return fail(res, 400, 'only a league override can be reset — save 0 on the default cell instead');
        }
        if (!isValidLeagueKey(sportId, leagueKey)) {
            return fail(res, 400, `league_key '${leagueKey}' is not configured for sport ${sportId}`);
        }

        const removed = await BetBufferConfig.destroy({
            where: { scope: 'sports', sport_id: sportId, league_key: leagueKey, category: marketKey },
        });
        await BettingConfigService.invalidateBuffers();

        return res.json({ success: true, removed, sport_id: sportId, league_key: leagueKey, market_key: marketKey });
    } catch (err) {
        console.error('resetSportsBuffer error:', err);
        return fail(res, 500, 'Failed to reset buffer time');
    }
};

// GET /api/admin/betting-config/buffer/casino
const getCasinoBuffers = async (req, res) => {
    try {
        const [catalog, rows] = await Promise.all([
            casinoGameCatalog(),
            BetBufferConfig.findAll({
                where: { scope: 'casino' },
                attributes: ['game_name', 'buffer_seconds'],
                raw: true,
            }),
        ]);

        const saved = new Map(
            rows.map((r) => [String(r.game_name || '').toLowerCase(), Number(r.buffer_seconds) || 0])
        );

        const games = catalog.map((game) => ({
            ...game,
            buffer_seconds: saved.get(game.game_name) || 0,
        }));

        return res.json({ success: true, max_seconds: MAX_BUFFER_SECONDS, games });
    } catch (err) {
        console.error('getCasinoBuffers error:', err);
        return fail(res, 500, 'Failed to load casino buffer configuration');
    }
};

// POST /api/admin/betting-config/buffer/casino  { game_name, buffer_seconds }
const saveCasinoBuffer = async (req, res) => {
    try {
        const gameName = String(req.body?.game_name || '').trim().toLowerCase();
        const seconds = parseBuffer(req.body?.buffer_seconds);

        if (!gameName) return fail(res, 400, 'game_name is required');
        if (gameName.length > 60) return fail(res, 400, 'game_name is too long');
        if (seconds === null) return fail(res, 400, `buffer_seconds must be between 0 and ${MAX_BUFFER_SECONDS}`);

        const where = { scope: 'casino', game_name: gameName };
        const existing = await BetBufferConfig.findOne({ where });

        if (existing) {
            await existing.update({ buffer_seconds: seconds });
        } else {
            await BetBufferConfig.create({ ...where, sport_id: null, category: null, buffer_seconds: seconds });
        }

        await BettingConfigService.invalidateBuffers();
        return res.json({ success: true, game_name: gameName, buffer_seconds: seconds });
    } catch (err) {
        console.error('saveCasinoBuffer error:', err);
        return fail(res, 500, 'Failed to save buffer time');
    }
};

//======================================================================
// BET LIMITS — SPORTS
//======================================================================

// Racing (horse 10 / greyhound 65) nests country > venue > race instead of the
// flat t1/t2 match list; the same walk placeBet's race-window helper does.
const flattenEvents = (nodes, out = []) => {
    for (const node of nodes || []) {
        if (node?.gmid) out.push(node);
        if (Array.isArray(node?.children)) flattenEvents(node.children, out);
    }
    return out;
};

// GET /api/admin/betting-config/bet-limits/inplay[?sport_id=4]
// Live + upcoming events from the (redis-cached) board feed, so the owner can
// pick the match to tune. No new upstream traffic: fetchCricketData is the
// same cached call the player board makes.
const getInplayEvents = async (req, res) => {
    try {
        const requested = req.query?.sport_id ? [String(req.query.sport_id)] : null;

        let sportIds = requested;
        if (!sportIds) {
            try {
                const cfg = await SportsConfig.findAll({
                    where: { enabled: true }, attributes: ['game_id'], raw: true,
                });
                sportIds = cfg.map((c) => String(c.game_id));
            } catch { sportIds = []; }
            if (!sportIds.length) sportIds = SPORTS_LIST.map(([id]) => id);
        }

        const boards = await Promise.all(
            sportIds.map((sid) =>
                CricketService.fetchCricketData(sid)
                    .then((data) => ({ sid, data }))
                    .catch(() => ({ sid, data: null }))
            )
        );

        const events = [];
        for (const { sid, data } of boards) {
            const t1 = Array.isArray(data?.data?.t1) ? data.data.t1 : [];
            const t2 = Array.isArray(data?.data?.t2) ? data.data.t2 : [];
            for (const event of flattenEvents([...t1, ...t2])) {
                events.push({
                    event_id: String(event.gmid),
                    sport_id: Number(event.etid || sid),
                    sport_name: sportNameById(event.etid || sid),
                    event_name: event.ename || event.name || '',
                    competition: event.cname || '',
                    start_time: event.stime || null,
                    inplay: !!event.iplay,
                });
            }
        }

        // Live first, then by start time — the owner is almost always after a
        // match that is already running.
        events.sort((a, b) => (b.inplay === a.inplay ? 0 : b.inplay ? 1 : -1));

        // Which of these already carry an override, so the list can flag them.
        const configured = await BetLimitOverride.findAll({
            where: { scope: 'sports', is_active: true, event_id: { [Op.in]: events.map((e) => e.event_id) } },
            attributes: ['event_id'],
            raw: true,
        });
        const configuredIds = new Set(configured.map((c) => String(c.event_id)));

        return res.json({
            success: true,
            events: events.map((e) => ({ ...e, has_overrides: configuredIds.has(e.event_id) })),
        });
    } catch (err) {
        console.error('getInplayEvents error:', err);
        return fail(res, 500, 'Failed to load inplay events');
    }
};

// GET /api/admin/betting-config/bet-limits/event/:event_id?sport_id=4
// Every market of the event with the limits the FEED quotes (shown greyed as
// the default) alongside the saved override.
const getEventMarkets = async (req, res) => {
    try {
        const eventId = String(req.params.event_id || '');
        const sportId = req.query?.sport_id;
        if (!eventId) return fail(res, 400, 'event_id is required');

        const [privateData, overrides] = await Promise.all([
            CricketService.GetMatchPrivateData(eventId, sportId).catch(() => null),
            BetLimitOverride.findAll({
                where: { scope: 'sports', event_id: eventId },
                raw: true,
            }),
        ]);

        const byMarket = new Map(overrides.map((o) => [String(o.market_id), o]));
        const markets = Array.isArray(privateData?.data) ? privateData.data : [];

        // Feed precedence copied from resolveMarketLimits() so the numbers the
        // owner sees as "default" are the ones actually enforced today.
        // Racing's maxb is a flag (always 1), never a stake cap.
        const isRacing = String(sportId) === '10' || String(sportId) === '65';

        const rows = markets.map((market) => {
            const section = Array.isArray(market.section) ? market.section : [];
            const feedMax = (!isRacing && Number(market.maxb) > 0)
                ? Number(market.maxb)
                : (Number(market.max) > 0 ? Number(market.max) : Number(section[0]?.max) || 0);
            const feedMin = Number(section[0]?.min) > 0 ? Number(section[0].min) : Number(market.min) || 0;

            const override = byMarket.get(String(market.mid));
            return {
                market_id: String(market.mid),
                market_name: market.mname || '',
                gtype: market.gtype || '',
                category: BetBufferConfig.categoryFromGtype(market.gtype),
                feed_min: feedMin,
                feed_max: feedMax,
                override_id: override?.id ?? null,
                min_stake: override?.min_stake != null ? Number(override.min_stake) : null,
                max_stake: override?.max_stake != null ? Number(override.max_stake) : null,
                is_active: override ? !!override.is_active : true,
            };
        });

        return res.json({ success: true, event_id: eventId, markets: rows });
    } catch (err) {
        console.error('getEventMarkets error:', err);
        return fail(res, 500, 'Failed to load event markets');
    }
};

// POST /api/admin/betting-config/bet-limits/event
// { sport_id, event_id, market_id, market_name, gtype, event_name,
//   min_stake, max_stake }  — send '' / 0 / null on a side to clear it.
const saveEventLimit = async (req, res) => {
    try {
        const eventId = String(req.body?.event_id || '').trim();
        const marketId = String(req.body?.market_id || '').trim();
        if (!eventId) return fail(res, 400, 'event_id is required');
        if (!marketId) return fail(res, 400, 'market_id is required');

        const minStake = parseLimit(req.body?.min_stake);
        const maxStake = parseLimit(req.body?.max_stake);
        if (minStake === undefined) return fail(res, 400, 'min_stake must be a positive number');
        if (maxStake === undefined) return fail(res, 400, 'max_stake must be a positive number');
        if (minStake !== null && maxStake !== null && minStake >= maxStake) {
            return fail(res, 400, 'min_stake must be lower than max_stake');
        }

        const where = { scope: 'sports', event_id: eventId, market_id: marketId };
        const values = {
            sport_id: req.body?.sport_id ? Number(req.body.sport_id) : null,
            market_name: req.body?.market_name ? String(req.body.market_name).slice(0, 120) : null,
            gtype: req.body?.gtype ? String(req.body.gtype).slice(0, 30) : null,
            event_name: req.body?.event_name ? String(req.body.event_name).slice(0, 200) : null,
            min_stake: minStake,
            max_stake: maxStake,
            // Both sides cleared → the row stays but stops applying, which is
            // the same as deleting it and keeps the audit trail.
            is_active: !(minStake === null && maxStake === null),
        };

        const existing = await BetLimitOverride.findOne({ where });
        let row;
        if (existing) {
            row = await existing.update(values);
        } else {
            row = await BetLimitOverride.create({ ...where, game_name: null, ...values });
        }

        await BettingConfigService.invalidateEventLimits(eventId);
        return res.json({ success: true, override: row });
    } catch (err) {
        console.error('saveEventLimit error:', err);
        return fail(res, 500, 'Failed to save bet limit');
    }
};

// DELETE /api/admin/betting-config/bet-limits/event/:id — back to feed values.
const deleteEventLimit = async (req, res) => {
    try {
        const row = await BetLimitOverride.findOne({
            where: { id: Number(req.params.id), scope: 'sports' },
        });
        if (!row) return fail(res, 404, 'Override not found');

        const eventId = row.event_id;
        await row.destroy();
        await BettingConfigService.invalidateEventLimits(eventId);
        return res.json({ success: true });
    } catch (err) {
        console.error('deleteEventLimit error:', err);
        return fail(res, 500, 'Failed to clear bet limit');
    }
};

//======================================================================
// BET LIMITS — CASINO
//======================================================================

// GET /api/admin/betting-config/bet-limits/casino
const getCasinoLimits = async (req, res) => {
    try {
        const [catalog, rows] = await Promise.all([
            casinoGameCatalog(),
            BetLimitOverride.findAll({ where: { scope: 'casino' }, raw: true }),
        ]);

        const saved = new Map(rows.map((r) => [String(r.game_name || '').toLowerCase(), r]));

        const games = catalog.map((game) => {
            const override = saved.get(game.game_name);
            return {
                ...game,
                override_id: override?.id ?? null,
                min_stake: override?.min_stake != null ? Number(override.min_stake) : null,
                max_stake: override?.max_stake != null ? Number(override.max_stake) : null,
                is_active: override ? !!override.is_active : true,
            };
        });

        return res.json({ success: true, games });
    } catch (err) {
        console.error('getCasinoLimits error:', err);
        return fail(res, 500, 'Failed to load casino bet limits');
    }
};

// POST /api/admin/betting-config/bet-limits/casino
// { game_name, min_stake, max_stake }
const saveCasinoLimit = async (req, res) => {
    try {
        const gameName = String(req.body?.game_name || '').trim().toLowerCase();
        if (!gameName) return fail(res, 400, 'game_name is required');
        if (gameName.length > 60) return fail(res, 400, 'game_name is too long');

        const minStake = parseLimit(req.body?.min_stake);
        const maxStake = parseLimit(req.body?.max_stake);
        if (minStake === undefined) return fail(res, 400, 'min_stake must be a positive number');
        if (maxStake === undefined) return fail(res, 400, 'max_stake must be a positive number');
        if (minStake !== null && maxStake !== null && minStake >= maxStake) {
            return fail(res, 400, 'min_stake must be lower than max_stake');
        }

        const where = { scope: 'casino', game_name: gameName };
        const values = {
            min_stake: minStake,
            max_stake: maxStake,
            is_active: !(minStake === null && maxStake === null),
        };

        const existing = await BetLimitOverride.findOne({ where });
        let row;
        if (existing) {
            row = await existing.update(values);
        } else {
            row = await BetLimitOverride.create({
                ...where, sport_id: null, event_id: null, market_id: null, ...values,
            });
        }

        await BettingConfigService.invalidateCasinoLimits();
        return res.json({ success: true, override: row });
    } catch (err) {
        console.error('saveCasinoLimit error:', err);
        return fail(res, 500, 'Failed to save casino bet limit');
    }
};

// DELETE /api/admin/betting-config/bet-limits/casino/:id
const deleteCasinoLimit = async (req, res) => {
    try {
        const row = await BetLimitOverride.findOne({
            where: { id: Number(req.params.id), scope: 'casino' },
        });
        if (!row) return fail(res, 404, 'Override not found');

        await row.destroy();
        await BettingConfigService.invalidateCasinoLimits();
        return res.json({ success: true });
    } catch (err) {
        console.error('deleteCasinoLimit error:', err);
        return fail(res, 500, 'Failed to clear casino bet limit');
    }
};

//======================================================================
// MAX ODDS
//======================================================================

// Rate input: '' / null / 0 all clear the cap (stored as 0).
const parseMaxOdds = (raw) => {
    if (raw === undefined || raw === null || raw === '') return 0;
    const n = Number(raw);
    if (!Number.isFinite(n) || n < 0 || n > MaxOddsConfig.MAX_VALUE) return null;
    return Math.round(n * 100) / 100;
};

const EMPTY_MAX_ODDS = Object.freeze({ max_odds: 0, limited_overs_only: false });

// GET /api/admin/betting-config/max-odds/sports
// Every sport → its leagues ('default' + the variants in
// constants/commissionLeagues.js) × (match_odds | bookmaker).
// Per cell: { state: 'set' | 'inherit', max_odds, limited_overs_only, inherited }
//   default league → always 'set'; max_odds 0 = no cap.
//   variant league → 'inherit' when it has no row (values = the sport's cell it
//   follows), 'set' when it has its own row (max_odds 0 = no cap there).
// The sport's `rules` is its default league, the pre-2026-09-15 shape.
const getSportsMaxOdds = async (req, res) => {
    try {
        const rows = await MaxOddsConfig.findAll({
            attributes: ['sport_id', 'league_key', 'category', 'max_odds', 'limited_overs_only'],
            raw: true,
        });

        const saved = new Map();
        for (const row of rows) {
            saved.set(`${row.sport_id}:${row.league_key || DEFAULT_LEAGUE_KEY}:${row.category}`, {
                max_odds: Number(row.max_odds) || 0,
                limited_overs_only: !!row.limited_overs_only,
            });
        }

        // Sports the platform has actually enabled float to the top; the rest
        // stay listed so a sport can be capped before it is switched on.
        let enabled = new Set();
        try {
            const cfg = await SportsConfig.findAll({
                where: { enabled: true }, attributes: ['game_id'], raw: true,
            });
            enabled = new Set(cfg.map((c) => String(c.game_id)));
        } catch { /* SportsConfig unavailable — list everything, unsorted */ }

        const sports = SPORTS_LIST.map(([sportId, name]) => {
            const leagues = leagueOptionsForSport(sportId).map((league) => {
                const rules = {};
                for (const category of MaxOddsConfig.CATEGORIES) {
                    const parent = saved.get(`${sportId}:${DEFAULT_LEAGUE_KEY}:${category}`) || { ...EMPTY_MAX_ODDS };
                    const own = saved.get(`${sportId}:${league.key}:${category}`);
                    if (league.is_default) {
                        rules[category] = { state: 'set', ...(own || EMPTY_MAX_ODDS), inherited: null };
                    } else if (own) {
                        rules[category] = { state: 'set', ...own, inherited: parent };
                    } else {
                        rules[category] = { state: 'inherit', ...parent, inherited: parent };
                    }
                }
                return { ...league, rules };
            });
            return {
                sport_id: Number(sportId),
                name,
                enabled: enabled.has(sportId),
                rules: leagues[0].rules,
                leagues,
            };
        }).sort((a, b) => (b.enabled === a.enabled ? 0 : b.enabled ? 1 : -1));

        return res.json({
            success: true,
            categories: MaxOddsConfig.CATEGORIES,
            max_value: MaxOddsConfig.MAX_VALUE,
            limited_overs_sport_id: MaxOddsConfig.LIMITED_OVERS_SPORT_ID,
            default_league_key: DEFAULT_LEAGUE_KEY,
            sports,
        });
    } catch (err) {
        console.error('getSportsMaxOdds error:', err);
        return fail(res, 500, 'Failed to load max odds configuration');
    }
};

// POST /api/admin/betting-config/max-odds/sports
// { sport_id, league_key?, category, max_odds, limited_overs_only }
// max_odds 0 = no cap (on a league row: no cap for that league).
// limited_overs_only is honoured for cricket only.
const saveSportsMaxOdds = async (req, res) => {
    try {
        const sportId = Number(req.body?.sport_id);
        const leagueKey = String(req.body?.league_key || DEFAULT_LEAGUE_KEY).toLowerCase().trim();
        const category = String(req.body?.category || '');
        const maxOdds = parseMaxOdds(req.body?.max_odds);
        const flag = req.body?.limited_overs_only;
        const limitedOversOnly = sportId === MaxOddsConfig.LIMITED_OVERS_SPORT_ID
            && (flag === true || flag === 'true' || flag === 1);

        if (!Number.isInteger(sportId) || sportId <= 0) return fail(res, 400, 'sport_id is required');
        if (!MaxOddsConfig.CATEGORIES.includes(category)) {
            return fail(res, 400, `category must be one of ${MaxOddsConfig.CATEGORIES.join(', ')}`);
        }
        if (!isValidLeagueKey(sportId, leagueKey)) {
            const allowed = leagueOptionsForSport(sportId).map((l) => l.key).join(', ');
            return fail(res, 400, `league_key '${leagueKey}' is not configured for sport ${sportId} (allowed: ${allowed})`);
        }
        if (maxOdds === null) return fail(res, 400, `max_odds must be between 0 and ${MaxOddsConfig.MAX_VALUE}`);

        const where = { sport_id: sportId, league_key: leagueKey, category };
        const values = { max_odds: maxOdds, limited_overs_only: limitedOversOnly };
        const existing = await MaxOddsConfig.findOne({ where });
        if (existing) {
            await existing.update(values);
        } else {
            await MaxOddsConfig.create({ ...where, ...values });
        }

        await BettingConfigService.invalidateMaxOdds();
        return res.json({ success: true, sport_id: sportId, league_key: leagueKey, category, ...values });
    } catch (err) {
        console.error('saveSportsMaxOdds error:', err);
        return fail(res, 500, 'Failed to save max odds');
    }
};

// DELETE /api/admin/betting-config/max-odds/sports
// { sport_id, league_key, category }  → the league cell follows the sport's cap
// again. A default cell is cleared by saving 0, never deleted here.
const resetSportsMaxOdds = async (req, res) => {
    try {
        const sportId = Number(req.body?.sport_id);
        const leagueKey = String(req.body?.league_key || '').toLowerCase().trim();
        const category = String(req.body?.category || '');

        if (!Number.isInteger(sportId) || sportId <= 0) return fail(res, 400, 'sport_id is required');
        if (!MaxOddsConfig.CATEGORIES.includes(category)) {
            return fail(res, 400, `category must be one of ${MaxOddsConfig.CATEGORIES.join(', ')}`);
        }
        if (!leagueKey || leagueKey === DEFAULT_LEAGUE_KEY) {
            return fail(res, 400, 'only a league override can be reset — save 0 on the sport row instead');
        }
        if (!isValidLeagueKey(sportId, leagueKey)) {
            return fail(res, 400, `league_key '${leagueKey}' is not configured for sport ${sportId}`);
        }

        const removed = await MaxOddsConfig.destroy({
            where: { sport_id: sportId, league_key: leagueKey, category },
        });
        await BettingConfigService.invalidateMaxOdds();

        return res.json({ success: true, removed, sport_id: sportId, league_key: leagueKey, category });
    } catch (err) {
        console.error('resetSportsMaxOdds error:', err);
        return fail(res, 500, 'Failed to reset max odds');
    }
};

// ── Auto Void ──────────────────────────────────────────────────────────────
// One row. The results detector (sportsbet/betresult/autoVoid.js) re-reads it
// every few seconds, so a save takes effect without a restart and no cache
// key is involved.
const autoVoidPayload = (row) => ({
    enabled: !!row.enabled,
    delay_seconds: Number(row.delay_seconds),
    on_match_odds: !!row.on_match_odds,
    on_bookmaker: !!row.on_bookmaker,
    min_delay_seconds: AUTO_VOID_MIN_DELAY,
    max_delay_seconds: AUTO_VOID_MAX_DELAY,
    enabled_at: row.enabled_at || null,
    updated_at: row.updatedAt || row.updated_at || null,
});

const getAutoVoid = async (req, res) => {
    try {
        const row = await getAutoVoidConfig();
        return res.json({ success: true, data: autoVoidPayload(row) });
    } catch (err) {
        console.error('getAutoVoid error:', err);
        return fail(res, 500, 'Failed to load auto void settings');
    }
};

const saveAutoVoid = async (req, res) => {
    try {
        const { enabled, delay_seconds, on_match_odds, on_bookmaker } = req.body || {};
        const patch = {};

        if (enabled !== undefined) patch.enabled = enabled === true || enabled === 'true' || enabled === 1;
        if (on_match_odds !== undefined) patch.on_match_odds = on_match_odds === true || on_match_odds === 'true' || on_match_odds === 1;
        if (on_bookmaker !== undefined) patch.on_bookmaker = on_bookmaker === true || on_bookmaker === 'true' || on_bookmaker === 1;

        if (delay_seconds !== undefined) {
            const n = Number(delay_seconds);
            if (!Number.isInteger(n) || n < AUTO_VOID_MIN_DELAY || n > AUTO_VOID_MAX_DELAY) {
                return fail(res, 400, `Delay must be a whole number of seconds between ${AUTO_VOID_MIN_DELAY} and ${AUTO_VOID_MAX_DELAY}`);
            }
            patch.delay_seconds = n;
        }

        if (!Object.keys(patch).length) return fail(res, 400, 'Nothing to update');

        const row = await getAutoVoidConfig();
        const next = { ...row.get({ plain: true }), ...patch };
        if (next.enabled && !next.on_match_odds && !next.on_bookmaker) {
            return fail(res, 400, 'Pick at least one market (Match Odds or Bookmaker) to start the timer');
        }

        // OFF -> ON restarts every armed event's countdown from now (see voidDueAt).
        if (next.enabled && !row.enabled) patch.enabled_at = new Date();

        await row.update(patch);
        return res.json({ success: true, message: 'Auto void settings saved', data: autoVoidPayload(row) });
    } catch (err) {
        console.error('saveAutoVoid error:', err);
        return fail(res, 500, 'Failed to save auto void settings');
    }
};

// ── Pending Result Tracker ─────────────────────────────────────────────────
// Every event whose Match Odds / Bookmaker the feed has declared (a row in
// sports_auto_void_state, armed by the results detector even with Auto Void
// OFF) that still has unsettled bets. The team finds those results before
// void_at; after it, Auto Void refunds them. 'manual' bets are never
// auto-voided, so they are flagged for hand settlement.
const TRACKER_LOOKBACK_DAYS = 3;

const getAutoVoidTracker = async (req, res) => {
    try {
        const cfg = (await getAutoVoidConfig()).get({ plain: true });
        const rows = await sequelize.query(
            `SELECT s.eventid, s.match_title, s.sport_id, s.anchor_market, s.anchor_status,
                    s.anchor_seen_at, s.last_fired_at, s.last_error,
                    b.id AS bet_id, b.user_id, u.username, b.game_type, b.market_type,
                    b.selection_name, b.fancy_name, b.bet_type, b.odds, b.stake_amount,
                    b.liability, b.status, b.unmatched, b.created_at, b.match_id
               FROM sports_auto_void_state s
               JOIN "SportsBet" b ON b.eventid = s.eventid AND b.status IN ('open', 'manual')
               LEFT JOIN users u ON u.user_id = b.user_id
              WHERE s.anchor_seen_at > NOW() - (:days || ' days')::interval
              ORDER BY s.anchor_seen_at ASC, b.match_id, b.market_type, b.selection_name, b.id`,
            { type: QueryTypes.SELECT, replacements: { days: String(TRACKER_LOOKBACK_DAYS) } }
        );

        const now = Date.now();
        const events = new Map();
        for (const r of rows) {
            let ev = events.get(r.eventid);
            if (!ev) {
                const due = voidDueAt(r.anchor_seen_at, cfg);
                ev = {
                    eventid: r.eventid,
                    match_title: r.match_title,
                    sport_id: r.sport_id,
                    anchor_market: r.anchor_market,
                    anchor_status: r.anchor_status,
                    anchor_seen_at: r.anchor_seen_at,
                    void_at: due,
                    seconds_left: Math.round((due.getTime() - now) / 1000),
                    last_fired_at: r.last_fired_at,
                    last_error: r.last_error,
                    bet_count: 0,
                    manual_count: 0,
                    total_stake: 0,
                    users: new Set(),
                    markets: new Map(),
                };
                events.set(r.eventid, ev);
            }
            const perSel = isPerSelectionMarket(r.market_type);
            const mKey = [r.match_id, r.market_type, r.game_type, perSel ? r.selection_name : ''].join('|');
            let m = ev.markets.get(mKey);
            if (!m) {
                m = {
                    match_id: r.match_id,
                    game_type: r.game_type,
                    market_type: r.market_type,
                    market_name: perSel ? r.selection_name : (r.fancy_name && r.fancy_name !== 'NULL' ? r.fancy_name : r.market_type),
                    bet_count: 0,
                    manual_count: 0,
                    total_stake: 0,
                    users: new Set(),
                    bets: [],
                };
                ev.markets.set(mKey, m);
            }
            const stake = Number(r.stake_amount) || 0;
            const manual = r.status === 'manual';
            m.bets.push({
                id: r.bet_id,
                user_id: r.user_id,
                username: r.username,
                selection_name: r.selection_name,
                bet_type: r.bet_type,
                odds: Number(r.odds),
                stake,
                status: r.status,
                unmatched: !!r.unmatched,
                created_at: r.created_at,
            });
            for (const t of [m, ev]) {
                t.bet_count++;
                t.total_stake += stake;
                t.users.add(r.user_id);
                if (manual) t.manual_count++;
            }
        }

        const data = [...events.values()].map((ev) => ({
            ...ev,
            users: ev.users.size,
            markets: [...ev.markets.values()].map((m) => ({ ...m, users: m.users.size })),
        }));
        await ensureResultSourceLinks();
        const links = await ResultSourceLink.findAll({
            where: { active: true },
            attributes: ['id', 'name', 'url', 'sport_id'],
            order: [['sort_order', 'ASC'], ['id', 'ASC']],
            raw: true,
        });
        return res.json({
            success: true,
            data: {
                enabled: !!cfg.enabled,
                delay_seconds: Number(cfg.delay_seconds),
                server_time: new Date(now),
                events: data,
                links,
            },
        });
    } catch (err) {
        console.error('getAutoVoidTracker error:', err);
        return fail(res, 500, 'Failed to load pending result tracker');
    }
};

// ── Result Source Links (tracker look-up sites) ───────────────────────────
// Rendered as <a href>, so only http(s) URLs are accepted — never javascript:.
const cleanLink = (body = {}) => {
    const name = String(body.name ?? '').trim();
    const url = String(body.url ?? '').trim();
    if (!name || name.length > 60) return { error: 'Name is required (max 60 characters)' };
    if (!/^https?:\/\/[^\s]+$/i.test(url) || url.length > 1000) return { error: 'URL must start with http:// or https://' };
    const sport = body.sport_id === undefined || body.sport_id === null || body.sport_id === '' ? null : String(body.sport_id);
    if (sport !== null && !SPORTS_LIST.some(([sid]) => sid === sport)) return { error: 'Unknown sport' };
    const order = Number(body.sort_order ?? 0);
    return {
        row: {
            name,
            url,
            sport_id: sport,
            sort_order: Number.isFinite(order) ? Math.trunc(order) : 0,
            active: body.active === undefined ? true : body.active === true || body.active === 'true' || body.active === 1,
        },
    };
};

const listResultLinks = async (req, res) => {
    try {
        await ensureResultSourceLinks();
        const rows = await ResultSourceLink.findAll({ order: [['sort_order', 'ASC'], ['id', 'ASC']], raw: true });
        return res.json({ success: true, data: rows });
    } catch (err) {
        console.error('listResultLinks error:', err);
        return fail(res, 500, 'Failed to load result links');
    }
};

const createResultLink = async (req, res) => {
    try {
        await ensureResultSourceLinks();
        const { row, error } = cleanLink(req.body);
        if (error) return fail(res, 400, error);
        const created = await ResultSourceLink.create(row);
        return res.json({ success: true, message: 'Link added', data: created });
    } catch (err) {
        console.error('createResultLink error:', err);
        return fail(res, 500, 'Failed to add link');
    }
};

const updateResultLink = async (req, res) => {
    try {
        await ensureResultSourceLinks();
        const link = await ResultSourceLink.findByPk(req.params.id);
        if (!link) return fail(res, 404, 'Link not found');
        const { row, error } = cleanLink({ ...link.get({ plain: true }), ...req.body });
        if (error) return fail(res, 400, error);
        await link.update(row);
        return res.json({ success: true, message: 'Link saved', data: link });
    } catch (err) {
        console.error('updateResultLink error:', err);
        return fail(res, 500, 'Failed to save link');
    }
};

const deleteResultLink = async (req, res) => {
    try {
        await ensureResultSourceLinks();
        const removed = await ResultSourceLink.destroy({ where: { id: req.params.id } });
        if (!removed) return fail(res, 404, 'Link not found');
        return res.json({ success: true, message: 'Link deleted' });
    } catch (err) {
        console.error('deleteResultLink error:', err);
        return fail(res, 500, 'Failed to delete link');
    }
};

// ── Virtual Bet Limits ─────────────────────────────────────────────────────
// One row per virtual league (Dim / T5 XI / T10 XI / VCL / WWE Virtual).
// 0 on a side = not set → the feed's own limit applies.
const VIRTUAL_MAX_STAKE = 10000000;

const virtualLimitsPayload = async () => {
    await seedVirtualBetLimits();
    const rows = await VirtualBetLimit.findAll({ raw: true });
    const byKey = new Map(rows.map((r) => [`${r.sport_id}:${r.league_key}`, r]));
    return virtualLeagues().map(({ sport_id, league_key, label }) => {
        const r = byKey.get(`${sport_id}:${league_key}`) || {};
        return {
            sport_id,
            sport_name: sportNameById(sport_id),
            league_key,
            label,
            min_stake: Number(r.min_stake) || 0,
            max_stake: Number(r.max_stake) || 0,
            updated_at: r.updatedAt || r.updated_at || null,
        };
    });
};

const getVirtualLimits = async (req, res) => {
    try {
        return res.json({ success: true, data: await virtualLimitsPayload() });
    } catch (err) {
        console.error('getVirtualLimits error:', err);
        return fail(res, 500, 'Failed to load virtual bet limits');
    }
};

// PUT body: { rows: [{ sport_id, league_key, min_stake, max_stake }] }
const saveVirtualLimits = async (req, res) => {
    try {
        const rows = Array.isArray(req.body?.rows) ? req.body.rows : null;
        if (!rows || !rows.length) return fail(res, 400, 'Nothing to update');

        const known = new Set(virtualLeagues().map((l) => `${l.sport_id}:${l.league_key}`));
        const clean = [];
        for (const row of rows) {
            const sportId = Number(row?.sport_id);
            const leagueKey = String(row?.league_key || '');
            if (!known.has(`${sportId}:${leagueKey}`)) return fail(res, 400, `Unknown league ${leagueKey}`);
            const min = Number(row.min_stake ?? 0);
            const max = Number(row.max_stake ?? 0);
            if (!Number.isFinite(min) || min < 0 || min > VIRTUAL_MAX_STAKE
                || !Number.isFinite(max) || max < 0 || max > VIRTUAL_MAX_STAKE) {
                return fail(res, 400, 'Min and Max must be numbers between 0 and 1,00,00,000');
            }
            if (min > 0 && max > 0 && min > max) {
                return fail(res, 400, 'Min cannot be more than Max');
            }
            clean.push({ sport_id: sportId, league_key: leagueKey, min_stake: min, max_stake: max });
        }

        await seedVirtualBetLimits();
        for (const r of clean) {
            await VirtualBetLimit.update(
                { min_stake: r.min_stake, max_stake: r.max_stake },
                { where: { sport_id: r.sport_id, league_key: r.league_key } },
            );
        }
        await BettingConfigService.invalidateVirtualLimits();
        return res.json({ success: true, message: 'Virtual bet limits saved', data: await virtualLimitsPayload() });
    } catch (err) {
        console.error('saveVirtualLimits error:', err);
        return fail(res, 500, 'Failed to save virtual bet limits');
    }
};

export default {
    getSportsBuffers,
    saveSportsBuffer,
    saveSportsBufferBulk,
    resetSportsBuffer,
    getCasinoBuffers,
    saveCasinoBuffer,
    getInplayEvents,
    getEventMarkets,
    saveEventLimit,
    deleteEventLimit,
    getCasinoLimits,
    saveCasinoLimit,
    deleteCasinoLimit,
    getSportsMaxOdds,
    saveSportsMaxOdds,
    resetSportsMaxOdds,
    getAutoVoid,
    saveAutoVoid,
    getAutoVoidTracker,
    listResultLinks,
    createResultLink,
    updateResultLink,
    deleteResultLink,
    getVirtualLimits,
    saveVirtualLimits,
};
