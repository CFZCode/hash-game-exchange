import BannerSyncService from '../../services/BannerSyncService.js';

const BannerSyncController = {
    // Owner: last/next auto-update of the carousel + poster mirror.
    getStatus: async (req, res) => {
        try {
            const data = await BannerSyncService.getStatus();
            res.status(200).json({ success: true, data });
        } catch (error) {
            console.error('Error in banner sync getStatus:', error);
            res.status(500).json({ success: false, error: error.message });
        }
    },

    // Owner: "Update now". Waits for the run (~15-60 s) and returns the new
    // status; the next scheduled run moves to 4 h from now.
    runNow: async (req, res) => {
        try {
            await BannerSyncService.run('manual');
            const data = await BannerSyncService.getStatus();
            res.status(200).json({ success: data.status !== 'error', data, error: data.error || undefined });
        } catch (error) {
            console.error('Error in banner sync runNow:', error);
            res.status(500).json({ success: false, error: error.message });
        }
    },
};

export default BannerSyncController;
