/**
 * Owner-only settings for the secure-auth Telegram bot.
 *
 * The token is a credential: it is stored in full but never returned in full —
 * the panel shows a masked preview so an owner can tell WHICH bot is configured
 * without the value being readable from a screen share or a proxy log.
 */
import SecureAuthConfigService from '../../services/user/SecureAuthConfigService.js';
import { restartBot } from '../../2FA_telegram_bot/index.js';

// 8565590052:AAHCgp… → 8565590052:AAH…fCY
const maskToken = (token) => {
    if (!token) return null;
    const [id, secret] = String(token).split(':');
    if (!secret) return `${String(token).slice(0, 4)}…`;
    return `${id}:${secret.slice(0, 3)}…${secret.slice(-3)}`;
};

const SecureAuthConfigController = {
    get: async (req, res) => {
        try {
            const config = await SecureAuthConfigService.get();
            return res.status(200).json({
                success: true,
                data: {
                    bot_username: config.bot_username || '',
                    bot_link: config.bot_username ? `https://t.me/${config.bot_username}` : '',
                    bot_token_masked: maskToken(config.bot_token),
                    has_token: !!config.bot_token,
                },
            });
        } catch (error) {
            console.error('❌ SecureAuthConfig get error:', error);
            return res.status(500).json({ success: false, error: 'Server error' });
        }
    },

    update: async (req, res) => {
        try {
            const { bot_username, bot_token } = req.body;

            if (bot_username === undefined && bot_token === undefined) {
                return res.status(400).json({ success: false, error: 'Nothing to update' });
            }

            // Telegram handles: 5-32 chars, letters/digits/underscore, must end in "bot".
            if (bot_username !== undefined) {
                const handle = String(bot_username || '')
                    .trim()
                    .replace(/^https?:\/\/t\.me\//i, '')
                    .replace(/^@/, '');
                if (handle && !/^[A-Za-z0-9_]{5,32}$/.test(handle)) {
                    return res.status(400).json({
                        success: false,
                        error: 'Bot username must be 5-32 characters, letters/numbers/underscore only',
                    });
                }
            }

            // BotFather tokens look like 1234567890:AA... — reject obvious typos
            // early rather than silently breaking OTP delivery.
            if (bot_token !== undefined && String(bot_token || '').trim()) {
                if (!/^\d{6,}:[A-Za-z0-9_-]{20,}$/.test(String(bot_token).trim())) {
                    return res.status(400).json({
                        success: false,
                        error: 'Bot token looks invalid. Expected the format 1234567890:AA... from BotFather.',
                    });
                }
            }

            // A dead token used to save happily and 2FA simply stopped working —
            // no code ever arrived and nothing said why. Ask Telegram who the
            // token belongs to before storing it; getMe is the cheapest check
            // and its answer also becomes the stored handle (see save()).
            if (bot_token !== undefined && String(bot_token || '').trim()) {
                const resolved = await SecureAuthConfigService.resolveUsernameFromToken(String(bot_token).trim());
                if (!resolved) {
                    return res.status(400).json({
                        success: false,
                        error: 'Telegram rejected this bot token. Check it in BotFather (/mybots → API Token) and try again.',
                    });
                }
            }

            await SecureAuthConfigService.save({ bot_username, bot_token });

            // Pick up a new token without a server restart. Forced, because the
            // poller can be dead while `runningBot` still looks alive, and then
            // the "token unchanged" shortcut would skip the restart. Fire-and-
            // forget: saving must succeed even if Telegram is unreachable.
            restartBot({ force: true }).catch((error) => console.error('❌ Bot restart after save:', error.message));

            const config = await SecureAuthConfigService.get();
            return res.status(200).json({
                success: true,
                message: 'Secure auth bot settings updated',
                data: {
                    bot_username: config.bot_username || '',
                    bot_link: config.bot_username ? `https://t.me/${config.bot_username}` : '',
                    bot_token_masked: maskToken(config.bot_token),
                    has_token: !!config.bot_token,
                },
            });
        } catch (error) {
            console.error('❌ SecureAuthConfig update error:', error);
            return res.status(500).json({ success: false, error: 'Server error' });
        }
    },
};

export default SecureAuthConfigController;
