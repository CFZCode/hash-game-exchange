import AuthService from '../../services/admin/agentAuthService.js';
import { MESSAGES } from '../../constants/messages.js';

const AuthController = {
    login: async (req, res) => {
        try {
            const { email, password } = req.body;

            if (!email || !password) {
                return res.status(400).json({ success: false, error: MESSAGES.AUTH.CREDENTIALS_REQUIRED });
            }

            const token = await AuthService.login(email, password);
            res.status(200).json({ token });
        } catch (error) {
            res.status(500).json({ success: false, error: error.message });
        }
    },

    logout: async (req, res) => {
        try {
            const token = req.header('Authorization')?.replace('Bearer ', '');
            if (!token) {
                return res.status(400).json({ success: false, error: MESSAGES.AUTH.TOKEN_NOT_PROVIDED });
            }

            await AuthService.logout(token);
            res.status(200).json({ success: true, message: MESSAGES.AUTH.LOGOUT_SUCCESS });
        } catch (error) {
            res.status(500).json({ success: false, error: error.message });
        }
    },
};

export default AuthController;