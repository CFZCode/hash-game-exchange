
import crypto from 'crypto';
import { nanoid } from 'nanoid';
import User from '../../model/user/User.js';
import Staff from '../../model/admin/Staff.js';
import Owner from '../../model/admin/Owner.js';
import TelegramBotService from '../../services/user/TelegramBotService.js';
import PasswordService from '../../services/passwordService.js';
import SecureAuthConfigService from '../../services/user/SecureAuthConfigService.js';
import { MESSAGES } from '../../constants/messages.js';
import { emitForceLogout, emitAdminForceLogout, emitOwnerForceLogout } from '../../utils/socketUtils.js';

const pendingCodes = {}; // { code: { userId, role, expires } }

/**
 * End every live session of an account: rotate its `login_id` so the tokens it
 * handed out stop matching (authMiddleware rejects them), then push the
 * `forceLogout` socket event so an open tab drops to the home page at once.
 * Never throws — the rotation is what actually secures it.
 */
export const endSessionsFor = async (role, id) => {
    const freshSid = crypto.randomUUID();
    try {
        if (role === 'USER') {
            await User.update({ login_id: freshSid }, { where: { user_id: id } });
            await emitForceLogout([id]);
        } else if (role === 'STAFF') {
            await Staff.update({ login_id: freshSid }, { where: { staff_id: id } });
            await emitAdminForceLogout([id]);
        } else {
            await Owner.update({ login_id: freshSid }, { where: { owner_id: id } });
            await emitOwnerForceLogout([id]);
        }
    } catch (error) {
        console.error('⚠️ Could not end sessions after enabling secure auth:', error?.message);
    }
};

/**
 * Link a Telegram chat to the account that generated `code`.
 *
 * Shared by the HTTP webhook and by the in-process bot, so both paths behave
 * identically. Returns { ok } or { ok: false, error } — it never throws at the
 * caller, and never leaks which account a code belonged to.
 */
export const linkTelegramAccount = async ({ code, telegramId, username }) => {
    if (!code || !telegramId) return { ok: false, error: 'Missing data' };

    const key = String(code).trim().toUpperCase();
    const record = pendingCodes[key];
    if (!record) return { ok: false, error: 'Invalid or expired code' };
    if (record.expires && record.expires < Date.now()) {
        delete pendingCodes[key];
        return { ok: false, error: 'Invalid or expired code' };
    }

    const Model = record.role === 'USER' ? User : (record.role === 'STAFF' ? Staff : Owner);
    const idField = record.role === 'USER' ? 'user_id' : (record.role === 'STAFF' ? 'staff_id' : 'owner_id');

    await Model.update({
        telegramChatId: telegramId.toString(),
        telegram2FAEnabled: true,
        // securityAuthType is the source of truth for which method the login
        // flow uses — keep it in step with the Telegram link. Set for
        // STAFF/OWNER too: their login branches on it to tell Telegram from
        // Google.
        securityAuthType: 'telegram'
    }, { where: { [idField]: record.userId } });

    console.log(`✅ Telegram linked for ${record.role} ${record.userId}${username ? ` (@${username})` : ''}`);

    // Turning secure auth ON changes how this account logs in, so the session
    // that asked for it must end — on the SERVER, not just in the tab that is
    // watching. The page used to poll its own profile and log itself out, so a
    // player who switched to the Telegram app (or another tab, or refreshed)
    // stayed logged in with 2FA already enabled. Rotating login_id makes every
    // existing token fail authMiddleware's session check immediately; the push
    // below just makes an open tab react at once instead of on its next call.
    // No message with it: the reference drops to the home page silently.
    await endSessionsFor(record.role, record.userId);

    await TelegramBotService.sendMessage(telegramId, MESSAGES.AUTH.TELEGRAM_2FA_ENABLED);
    delete pendingCodes[key];
    return { ok: true };
};

// Helper to get Model and ID based on req.user
//
// Resolve off `account.type`, never off "is there an id" — authMiddleware gives
// EVERY principal an `account.id`, so a truthiness check matched a staff/owner
// token and handed back the User model with the staff's id, pointing the whole
// flow at whichever user row happened to share that number. Harmless while only
// the player routes mounted this controller; not harmless now that the admin
// routes do too.
//
// idField MUST be the model's real PK: the users table has no `id` column. With
// 'id' here, sendDisableCode wrote the OTP to otpCache[undefined] while
// disable2FA read otpCache[<user_id>], so a correct code always came back
// "invalid" — and the final UPDATE ran `where: { id }` against a column that
// does not exist.
const getUserModelAndId = async (req) => {
    // An executive acts AS its parent (account.type is OWNER/STAFF), but secure
    // auth belongs to the account itself — it must not be able to turn its
    // parent's 2FA on or off. The admin menu hides it for executives too.
    if (req.user?.actor?.type === 'EXECUTIVE') return null;

    const type = req.user?.account?.type;
    const id = req.user?.account?.id;
    if (!id) return null;

    if (type === 'USER') return { Model: User, id, role: 'USER', idField: 'user_id' };
    if (type === 'STAFF') return { Model: Staff, id, role: 'STAFF', idField: 'staff_id' };
    if (type === 'OWNER') return { Model: Owner, id, role: 'OWNER', idField: 'owner_id' };

    // Legacy tokens that predate the actor/account shape.
    if (req.user?.user_id) return { Model: User, id: req.user.user_id, role: 'USER', idField: 'user_id' };
    if (req.user?.staff_id) return { Model: Staff, id: req.user.staff_id, role: 'STAFF', idField: 'staff_id' };
    if (req.user?.owner_id) return { Model: Owner, id: req.user.owner_id, role: 'OWNER', idField: 'owner_id' };

    return null;
};

const Telegram2FAController = {
    // 🔗 Generate Link Code
    // 🔐 Verify Password (Step 1)
    verifyPassword: async (req, res) => {
        try {
            const { password } = req.body;
            if (!password) return res.status(400).json({ success: false, error: 'Password is required' });

            const meta = await getUserModelAndId(req);
            if (!meta) return res.status(401).json({ success: false, error: 'Unauthorized type' });

            const user = await meta.Model.findByPk(meta.id);
            if (!user) {
                return res.status(404).json({ success: false, error: 'User not found' });
            }

            const isMatch = await PasswordService.comparePassword(password, user.password);
            // Reference-site wording — the frontend toast prints this as-is.
            if (!isMatch) return res.status(400).json({ success: false, error: 'User Password Not Valid.' });

            res.json({ success: true });
        } catch (error) {
            console.error('Verify Password Error:', error);
            res.status(500).json({ success: false, error: 'Server error' });
        }
    },

    // 🔗 Generate Link Code (Step 2)
    generateLinkCode: async (req, res) => {
        try {
            const meta = await getUserModelAndId(req);
            if (!meta) return res.status(401).json({ success: false, error: 'Unauthorized' });

            // Clean expired codes
            const now = Date.now();
            for (const c in pendingCodes) {
                if (pendingCodes[c].expires < now) delete pendingCodes[c];
            }

            const code = nanoid(8).toUpperCase();
            pendingCodes[code] = {
                userId: meta.id,
                role: meta.role,
                expires: now + 10 * 60 * 1000
            };

            // The instructions screen renders the bot handle, so it must come
            // from the owner's configured bot — never hardcoded in the client.
            const botUsername = await SecureAuthConfigService.getBotUsername();
            const botLink = await SecureAuthConfigService.getBotLink();

            res.status(200).json({ success: true, code, botUsername, botLink });
        } catch (error) {
            console.error('❌ Generate Link Code Error:', error);
            res.status(500).json({ success: false, error: 'Server error' });
        }
    },

    // 🤖 Webhook for Bot to Verify Link
    //
    // Kept for any out-of-process caller; the bundled bot
    // (2FA_telegram_bot/index.js) runs inside THIS process and calls
    // linkTelegramAccount() below directly — no HTTP hop, so a wrong/missing
    // PROJECT_BASE_URL can no longer silently break /connect.
    verifyLinkWebhook: async (req, res) => {
        try {
            const { code, telegramId, username } = req.body;
            if (!code || !telegramId) {
                return res.status(400).json({ success: false, error: 'Missing data' });
            }
            const result = await linkTelegramAccount({ code, telegramId, username });
            if (!result.ok) return res.status(400).json({ success: false, error: result.error });
            res.status(200).json({ success: true, message: 'Linked successfully' });
        } catch (error) {
            console.error('❌ Verify Link Webhook Error:', error);
            res.status(500).json({ success: false, error: 'Server error' });
        }
    },

    //  Send Disable Code
    sendDisableCode: async (req, res) => {
        try {
            const meta = await getUserModelAndId(req);
            if (!meta) return res.status(401).json({ success: false, error: 'Unauthorized' });

            const user = await meta.Model.findByPk(meta.id);
            if (!user) return res.status(404).json({ success: false, error: 'User not found' });
            if (!user.telegramChatId || !user.telegram2FAEnabled) return res.status(400).json({ success: false, error: '2FA not enabled' });

            const otp = Math.floor(100000 + Math.random() * 900000).toString();

            // Prefix key with type to avoid collision if IDs overlap (though unlikely across diff tables vs diff cache keys)
            // But verify2FA usually checks by ID.
            // For disable, we use the same cache key convention or just ID if we separate handling.
            // Let's use a consistent key: `${role}_${id}`?
            // Existing USER logic uses just ID. We should stick to that for USER to avoid breaking changes,
            // or update USER logic too.
            // BUT: modify existing code minimally.
            // If I change cache key logic for USER, I break login verify.

            // Let's use specific keys for admin types, and keep simple ID for USER if that's what was used.
            // Wait, I updated StaffAuthService to use `staff_${id}`.

            let cacheKey = user[meta.idField];
            if (meta.role === 'STAFF') cacheKey = `staff_${cacheKey}`;
            if (meta.role === 'OWNER') cacheKey = `owner_${cacheKey}`;

            global.otpCache = global.otpCache || {};
            global.otpCache[cacheKey] = { otp, expires: Date.now() + 5 * 60 * 1000 };

            // The reference bot sends the SAME "Login Code: …" line for the disable
            // code as for a login code (recording `removing.MP4`, 2026-09-20).
            await TelegramBotService.sendMessage(user.telegramChatId, MESSAGES.AUTH.TELEGRAM_LOGIN_CODE(otp, user.username));

            // Reference wording, from the shared constants — the same string the
            // login OTP announces. Was hardcoded here and out of step with it.
            res.json({ success: true, message: MESSAGES.AUTH.OTP_SENT });
        } catch (error) {
            console.error('Send Disable Code Error:', error);
            res.status(500).json({ success: false, error: 'Server error' });
        }
    },

    // 🛑 Disable 2FA
    disable2FA: async (req, res) => {
        try {
            const { otp } = req.body;
            if (!otp) return res.status(400).json({ success: false, error: 'OTP is required' });

            const meta = await getUserModelAndId(req);
            if (!meta) return res.status(401).json({ success: false, error: 'Unauthorized' });

            let cacheKey = meta.id;
            if (meta.role === 'STAFF') cacheKey = `staff_${cacheKey}`;
            if (meta.role === 'OWNER') cacheKey = `owner_${cacheKey}`;

            const record = global.otpCache && global.otpCache[cacheKey];

            if (!record) return res.status(400).json({ success: false, error: 'OTP expired or not requested' });
            if (record.otp !== otp) return res.status(400).json({ success: false, error: 'Invalid OTP' });

            // Read the chat id BEFORE the update nulls it — the reference bot
            // posts "2-Step Verification is disabled for your account." on the
            // same chat right after a successful disable.
            const linkedChatId = (await meta.Model.findByPk(meta.id))?.telegramChatId;

            await meta.Model.update({
                telegram2FAEnabled: false,
                telegramChatId: null,
                securityAuthType: null
            }, { where: { [meta.idField]: meta.id } });

            if (linkedChatId) {
                // Never let a bot hiccup fail the disable itself.
                try {
                    await TelegramBotService.sendMessage(linkedChatId, MESSAGES.AUTH.TELEGRAM_2FA_DISABLED);
                } catch (notifyError) {
                    console.error('⚠️ 2FA disabled notice not delivered:', notifyError?.message);
                }
            }

            delete global.otpCache[cacheKey]; // Cleanup

            res.json({ success: true, message: '2FA Disabled successfully' });
        } catch (error) {
            console.error('Disable 2FA Error:', error);
            res.status(500).json({ success: false, error: 'Server error' });
        }
    }
};

export default Telegram2FAController;
