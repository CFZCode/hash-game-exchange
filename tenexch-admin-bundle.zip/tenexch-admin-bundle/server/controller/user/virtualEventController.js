import axios from "axios";
import dotenv from "dotenv";
dotenv.config();

// Virtual-game media resolver. Given a virtual round's gmid + etid the provider
// answers with the two urls the detail page needs:
//   { stream: ".../event-player.php?id=<streamId>",
//     score:  ".../score.html?etid=<etid>&gmid=<providerGmid>" }
// Both carry PROVIDER-side ids that differ from our route gmid (the score
// url's gmid is the provider's internal scorecard id), which is why the page
// cannot build them itself. Proxied here: the upstream sits behind Cloudflare
// with no CORS headers, and the host stays out of the frontend bundle.
const VIRTUAL_EVENT_DATA_URL =
  process.env.VIRTUAL_EVENT_DATA_URL || "https://e-event-data.uhdmovies.online/";

const CACHE_TTL_MS = 30 * 1000;
const MAX_ENTRIES = 500;
const cache = new Map(); // "etid:gmid" -> { at, data }

// The upstream resolver flaps (observed: long runs of Cloudflare 502s while the
// score/stream hosts it points at stay up). A round's provider ids do not change
// once assigned, so a cached entry NEVER expires as a fallback — TTL only decides
// when to try a refresh. Eviction is therefore by insertion order (oldest first),
// not by age: dropping a live round's entry mid-outage is exactly what we must
// not do. Map preserves insertion order, so the first keys are the oldest.
function evictOldest() {
  for (const k of cache.keys()) {
    if (cache.size <= MAX_ENTRIES) break;
    cache.delete(k);
  }
}

// XI virtual (T5 XI / T10 XI) live ball cards + countdown. Upstream answers
//   { data: { data: { t1: { card: "4SS|3SS|JSS,ASS|1|1|1", ft: 30, lt: 19 } } } }
// card = the current over, one "|" slot per ball ("1" = not drawn yet; a wide
// and its re-ball share a slot, comma-joined); ft = full countdown, lt = seconds
// left. gtype picks the league: T5 XI = cricketv, T10 XI = cricketv2. gmid is
// required upstream but (as of 2026-10-08) ignored — every gmid gets the live
// table state. Still part of the cache key so a vendor fix can't cross matches.
// The key is CASINO_API_KEY, so this must never be called from the browser.
const CRICKETV_CARDS_URL =
  process.env.CRICKETV_CARDS_URL || "http://138.68.178.21:9000/cricketvdata2";
const CRICKETV_GTYPES = new Set(["cricketv", "cricketv2"]);
// Stale-while-revalidate: players poll every 500ms and get the cached value at
// once, never waiting on the ~0.7s upstream call; a request that finds it older
// than CARDS_REFRESH_MS starts one background refresh shared by every viewer.
// Past CARDS_MAX_AGE_MS (nobody watched for a while) the request waits for
// fresh data instead of serving an old over.
const CARDS_REFRESH_MS = 300;
const CARDS_MAX_AGE_MS = 10 * 1000;
const cardsCache = new Map(); // "gtype:gmid" -> { at, data }
const cardsInflight = new Map(); // "gtype:gmid" -> Promise<data>

async function fetchCricketVCards(gtype, gmid) {
  const { data } = await axios.get(CRICKETV_CARDS_URL, {
    params: { gmid, gtype, key: process.env.CASINO_API_KEY },
    timeout: 5000,
  });
  const t1 = data?.data?.data?.t1;
  if (!t1 || typeof t1.card !== "string") throw new Error("upstream returned no t1");
  return { card: t1.card, ft: Number(t1.ft) || 0, lt: Number(t1.lt) || 0 };
}

function refreshCricketVCards(key, gtype, gmid) {
  let pending = cardsInflight.get(key);
  if (!pending) {
    pending = fetchCricketVCards(gtype, gmid)
      .then((data) => {
        cardsCache.delete(key);
        cardsCache.set(key, { at: Date.now(), data });
        while (cardsCache.size > MAX_ENTRIES) cardsCache.delete(cardsCache.keys().next().value);
        return data;
      })
      .finally(() => cardsInflight.delete(key));
    cardsInflight.set(key, pending);
  }
  return pending;
}

const VirtualEventController = {
  // GET /api/user/virtual/event-media?gmid=502328386&etid=69
  // -> { success, data: { gmid, etid, stream, score } | null }
  getEventMedia: async (req, res) => {
    const gmid = String(req.query.gmid ?? "").trim();
    // etid = the round's sport id (the page's route sid). The resolver answers
    // 502 without it, and with a wrong one. Optional here so a client that does
    // not send it yet keeps today's behaviour instead of getting a new 400.
    const etid = String(req.query.etid ?? "").trim();
    // Digits only: these values are interpolated into the upstream request, and
    // a stray "&"/"?" would let a caller rewrite it.
    if (!/^\d{1,20}$/.test(gmid)) {
      return res.status(400).json({ success: false, error: "A numeric gmid is required" });
    }
    if (etid && !/^\d{1,6}$/.test(etid)) {
      return res.status(400).json({ success: false, error: "etid must be numeric" });
    }

    // etid is part of the key: a wrong etid must never be served the right
    // round's urls, and the stale fallback stays scoped to the same pair.
    const key = `${etid}:${gmid}`;
    const now = Date.now();
    const hit = cache.get(key);
    if (hit && now - hit.at < CACHE_TTL_MS) {
      return res.json({ success: true, data: hit.data, cached: true });
    }

    try {
      // The resolver fails FAST when it fails (~0.1s Cloudflare 502), so one
      // immediate retry costs almost nothing and rides out a flapping origin.
      let data;
      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          ({ data } = await axios.get(VIRTUAL_EVENT_DATA_URL, {
            params: etid ? { data: gmid, etid } : { data: gmid },
            timeout: 8000,
          }));
          break;
        } catch (e) {
          if (attempt === 1) throw e;
        }
      }

      // The upstream can answer 200 with a Cloudflare error page, so accept the
      // body only when it actually carries a url — otherwise fall through to
      // the stale/failure path instead of caching garbage.
      const stream = typeof data?.stream === "string" ? data.stream : null;
      const score = typeof data?.score === "string" ? data.score : null;
      if (!stream && !score) throw new Error("upstream returned no stream/score");

      const media = { gmid, etid: etid || null, stream, score };
      cache.delete(key);               // re-insert so a hot key moves to newest
      cache.set(key, { at: now, data: media });
      evictOldest();
      return res.json({ success: true, data: media });
    } catch (err) {
      console.error(`[VirtualEventMedia] etid=${etid} gmid=${gmid} failed:`, err.message);
      // A 502 blip upstream must not blank out a running video/scorecard.
      if (hit) return res.json({ success: true, data: hit.data, stale: true });
      return res.json({ success: false, data: null, error: err.message });
    }
  },

  // GET /api/user/virtual/cricketv-cards?gmid=64835120&gtype=cricketv2
  // -> { success, data: { card, ft, lt } | null }
  getCricketVCards: async (req, res) => {
    const gmid = String(req.query.gmid ?? "").trim();
    const gtype = String(req.query.gtype ?? "").trim();
    if (!/^\d{1,20}$/.test(gmid)) {
      return res.status(400).json({ success: false, error: "A numeric gmid is required" });
    }
    if (!CRICKETV_GTYPES.has(gtype)) {
      return res.status(400).json({ success: false, error: "gtype must be cricketv or cricketv2" });
    }

    const key = `${gtype}:${gmid}`;
    const hit = cardsCache.get(key);
    const age = hit ? Date.now() - hit.at : Infinity;
    if (age < CARDS_MAX_AGE_MS) {
      if (age > CARDS_REFRESH_MS) {
        refreshCricketVCards(key, gtype, gmid).catch((err) =>
          console.error(`[CricketVCards] gtype=${gtype} gmid=${gmid} refresh failed:`, err.message)
        );
      }
      return res.json({ success: true, data: hit.data, cached: true });
    }

    try {
      const data = await refreshCricketVCards(key, gtype, gmid);
      return res.json({ success: true, data });
    } catch (err) {
      console.error(`[CricketVCards] gtype=${gtype} gmid=${gmid} failed:`, err.message);
      // The feed drops the odd request; keep the last cards on screen.
      if (hit) return res.json({ success: true, data: hit.data, stale: true });
      return res.json({ success: false, data: null, error: err.message });
    }
  },
};

export default VirtualEventController;
