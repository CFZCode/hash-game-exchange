/**
 * "Secure Auth Verification App" (Android) secure auth — pair, claim, enable, disable.
 *
 * The app is an OFFLINE TOTP authenticator: the phone holds the shared secret and
 * derives the 6-digit login code from it, exactly the way Google Authenticator does.
 * That is why this controller leans on the existing GoogleAuthService instead of a
 * push service — there is nothing to deliver at login, so no FCM, no device tokens,
 * and the secret can live in the column the Google flow already uses
 * (`googleAuthSecret`). The only thing that distinguishes the two methods is
 * `securityAuthType`, which is 'android' here and 'google' there.
 *
 * Flow the two Secure Auth pages drive (player + admin):
 *   1. POST /pair    {} (auth)              → 6-digit PAIRING code, shown the moment
 *                                             the Android App tab opens (no password
 *                                             step — same as the reference site)
 *   2. POST /claim   { username, password, code } (NO auth)
 *                                           → the APP exchanges that code for the secret,
 *                                             which ALSO switches secure auth on
 *                                             (securityAuthType = 'android') and ends
 *                                             every live session, so the site logs out
 *   3. POST /enable  { otp }     (auth)     → manual fallback, no longer used by the pages
 *   4. POST /disable { otp }     (auth)     → securityAuthType = null      → logged out
 *
 * Login-time verification lives in the three *AuthService.verify2FA functions, which
 * treat 'android' and 'google' alike (GoogleAuthService.isTotpType) — so the client
 * keeps using the single verify-2fa endpoint per role.
 *
 * Deliberately ONE controller for players and admins, the same way
 * telegram2faController is shared: step 2 is unauthenticated, so it has to resolve
 * the account from the pairing code alone, and two copies would mean two pending
 * tables the app would have to guess between.
 */
import crypto from 'crypto';
import User from '../../model/user/User.js';
import Staff from '../../model/admin/Staff.js';
import Owner from '../../model/admin/Owner.js';
import GoogleAuthService from '../../services/user/GoogleAuthService.js';
import PasswordService from '../../services/passwordService.js';
import { MESSAGES } from '../../constants/messages.js';
import { endSessionsFor } from './telegram2faController.js';

const ISSUER = (process.env.PROJECT_NAME || 'SECUREAUTH').toUpperCase();

const PAIR_TTL_MS = 10 * 60 * 1000;     // the on-screen code is good for 10 minutes
const CLAIM_WINDOW_MS = 60 * 1000;      // rate-limit window for the open endpoint

// { code: { role, id, username, expires } } — in memory, like the Telegram link
// codes in telegram2faController. A restart drops pending pairings; the user just
// presses the button again, and nothing half-enabled is left behind because the
// account only flips on `enable`.
const pendingPairs = {};

// Brute-force guard for `claim`, the one route without a session.
//
// It counts FAILURES only, never successful pairings: a real user's claim
// succeeds, so nothing they do can ever use up the budget, while an attacker
// guessing 6-digit codes does nothing but fail.
//
// Two buckets, because `app.set('trust proxy', true)` (server.js) means req.ip
// is whatever X-Forwarded-For says — good enough to stop the naive case, but a
// client can rotate it. The global bucket is the one no header can dodge:
// 60 wrong codes a minute against a million combinations that only exist for
// ten minutes at a time is not a guessing attack anybody finishes. Legitimate
// pairings keep working even while the global bucket is exhausted, because a
// correct code is never counted here.
const claimFailuresByIp = {};              // { ip: { count, resetAt } }
let claimFailuresGlobal = { count: 0, resetAt: 0 };

const CLAIM_MAX_FAILURES_PER_IP = 10;
const CLAIM_MAX_FAILURES_GLOBAL = 60;

const ROLE_MODELS = {
    USER: { Model: User, idField: 'user_id' },
    STAFF: { Model: Staff, idField: 'staff_id' },
    OWNER: { Model: Owner, idField: 'owner_id' },
};

/**
 * Resolve the principal from the token — same rules as
 * telegram2faController.getUserModelAndId: switch on `account.type` (every
 * principal has an `account.id`, so a truthiness check picks the wrong model),
 * and refuse EXECUTIVE, which acts AS its parent but must not touch the parent's
 * secure auth.
 */
const resolvePrincipal = async (req) => {
    if (req.user?.actor?.type === 'EXECUTIVE') return null;

    const type = req.user?.account?.type;
    const id = req.user?.account?.id ?? req.user?.user_id;
    if (!id) return null;

    const entry = ROLE_MODELS[type] || (req.user?.user_id ? ROLE_MODELS.USER : null);
    if (!entry) return null;

    const account = await entry.Model.findByPk(id);
    if (!account) return null;

    return { account, role: type in ROLE_MODELS ? type : 'USER', id };
};

const sweepExpired = () => {
    const now = Date.now();
    for (const code of Object.keys(pendingPairs)) {
        if (pendingPairs[code].expires < now) delete pendingPairs[code];
    }
};

/** A 6-digit code that is not already pending. Crypto-grade, not Math.random(). */
const issuePairingCode = () => {
    let code;
    do {
        code = String(crypto.randomInt(0, 1000000)).padStart(6, '0');
    } while (pendingPairs[code]);
    return code;
};

/** One pending pairing per account — a second "Get Auth Code" retires the first. */
const dropPairsFor = (role, id) => {
    for (const code of Object.keys(pendingPairs)) {
        const pending = pendingPairs[code];
        if (pending.role === role && String(pending.id) === String(id)) delete pendingPairs[code];
    }
};

const claimIp = (req) => req.ip || req.connection?.remoteAddress || 'unknown';

/** False when this caller (or the server as a whole) has failed too often lately. */
const claimAllowed = (req) => {
    const now = Date.now();

    if (claimFailuresGlobal.resetAt >= now && claimFailuresGlobal.count >= CLAIM_MAX_FAILURES_GLOBAL) {
        return false;
    }

    const bucket = claimFailuresByIp[claimIp(req)];
    return !(bucket && bucket.resetAt >= now && bucket.count >= CLAIM_MAX_FAILURES_PER_IP);
};

/** Every rejected claim — bad code, expired code, already-enabled account. */
const noteClaimFailure = (req) => {
    const now = Date.now();
    const ip = claimIp(req);

    // The per-IP map would otherwise keep an entry for every IP that ever
    // failed. Sweeping only when it grows keeps the common path free of the walk.
    if (Object.keys(claimFailuresByIp).length > 5000) {
        for (const key of Object.keys(claimFailuresByIp)) {
            if (claimFailuresByIp[key].resetAt < now) delete claimFailuresByIp[key];
        }
    }

    const bucket = claimFailuresByIp[ip];
    if (!bucket || bucket.resetAt < now) {
        claimFailuresByIp[ip] = { count: 1, resetAt: now + CLAIM_WINDOW_MS };
    } else {
        bucket.count += 1;
    }

    if (claimFailuresGlobal.resetAt < now) {
        claimFailuresGlobal = { count: 1, resetAt: now + CLAIM_WINDOW_MS };
    } else {
        claimFailuresGlobal.count += 1;
    }
};

const AndroidAuthController = {
    // 1️⃣ Fresh secret on the account + the pairing code on screen.
    //
    // No password here: the reference shows the code the instant the tab opens.
    // What protects the pairing is the other end — the app has to present the
    // account's username AND password together with this code, so the code on
    // its own is worth nothing to anyone who reads it off the screen.
    pair: async (req, res) => {
        try {
            const principal = await resolvePrincipal(req);
            if (!principal) return res.status(401).json({ success: false, error: 'Unauthorized' });
            const { account, role, id } = principal;

            // One method at a time — never layer the app on top of a live
            // Telegram link or an Authenticator secret.
            if (account.securityAuthType || account.telegram2FAEnabled) {
                return res.status(400).json({ success: false, error: MESSAGES.AUTH.SECURE_AUTH_ALREADY_ENABLED });
            }

            // A fresh secret per attempt: an abandoned pairing can never be used
            // later, because the next attempt overwrites it.
            const secret = GoogleAuthService.generateSecret();
            account.googleAuthSecret = secret;
            await account.save();

            sweepExpired();
            dropPairsFor(role, id);

            const code = issuePairingCode();
            pendingPairs[code] = {
                role,
                id,
                username: account.username,
                expires: Date.now() + PAIR_TTL_MS,
            };

            return res.status(200).json({
                success: true,
                message: MESSAGES.AUTH.ANDROID_AUTH_PAIR_READY,
                code,
                expiresIn: Math.floor(PAIR_TTL_MS / 1000),
            });
        } catch (error) {
            console.error('❌ Android Auth pair error:', error);
            return res.status(500).json({ success: false, error: 'Server error' });
        }
    },

    /**
     * 2️⃣ The APP exchanges the on-screen code for the secret.
     *
     * Unauthenticated by necessity: the phone has no website session. What keeps
     * it safe is that the code is server-issued, single-use, short-lived and
     * rate-limited — and that holding the secret alone still cannot switch the
     * account on, because `enable` below needs the logged-in session.
     */
    claim: async (req, res) => {
        try {
            if (!claimAllowed(req)) {
                return res.status(429).json({ success: false, error: MESSAGES.AUTH.ANDROID_AUTH_TOO_MANY_ATTEMPTS });
            }

            const code = String(req.body?.code || '').replace(/\s+/g, '');
            const username = String(req.body?.username || '').trim();
            const password = String(req.body?.password || '');

            // The app asks for all three. The credentials are what stop a
            // stolen or shoulder-surfed pairing code from being worth anything
            // on its own — the code alone no longer yields a secret.
            if (!username || !password) {
                noteClaimFailure(req);
                return res.status(400).json({ success: false, error: MESSAGES.AUTH.ANDROID_AUTH_CREDENTIALS_REQUIRED });
            }
            if (!/^\d{6}$/.test(code)) {
                noteClaimFailure(req);
                return res.status(400).json({ success: false, error: MESSAGES.AUTH.ANDROID_AUTH_CODE_REQUIRED });
            }

            sweepExpired();
            const pending = pendingPairs[code];
            if (!pending) {
                noteClaimFailure(req);
                return res.status(400).json({ success: false, error: MESSAGES.AUTH.ANDROID_AUTH_PAIR_INVALID });
            }

            const entry = ROLE_MODELS[pending.role];
            const account = entry ? await entry.Model.findByPk(pending.id) : null;
            if (!account || !account.googleAuthSecret) {
                delete pendingPairs[code];
                noteClaimFailure(req);
                return res.status(400).json({ success: false, error: MESSAGES.AUTH.ANDROID_AUTH_PAIR_INVALID });
            }

            // The code is NOT spent on a credential mismatch — a user who
            // fat-fingers their password would otherwise have to go back to the
            // website for a new code. The rate limiter is what bounds retries.
            const nameMatches = String(account.username || '').toLowerCase() === username.toLowerCase();
            const passwordMatches = nameMatches && await PasswordService.comparePassword(password, account.password);
            if (!nameMatches || !passwordMatches) {
                noteClaimFailure(req);
                return res.status(400).json({ success: false, error: MESSAGES.AUTH.ANDROID_AUTH_CREDENTIALS_INVALID });
            }

            if (account.securityAuthType) {
                delete pendingPairs[code];
                noteClaimFailure(req);
                return res.status(400).json({ success: false, error: MESSAGES.AUTH.SECURE_AUTH_ALREADY_ENABLED });
            }

            // Pairing IS enabling: once the phone holds the secret the account
            // switches over at once, with nothing to type back on the website.
            // endSessionsFor rotates login_id (authMiddleware pins each token's
            // `sid` to it) and pushes forceLogout, so the site that showed this
            // code logs itself out, exactly like the reference — the same path
            // a Telegram link takes. The next login then asks for the app's code.
            account.securityAuthType = 'android';
            await account.save();
            await endSessionsFor(pending.role, pending.id);

            // Single use — only now that it has actually been honoured.
            delete pendingPairs[code];

            console.log(`📱 Secure Auth App paired + enabled for ${pending.role} ${account.username}`);

            // Everything the app needs to generate codes offline from here on.
            return res.status(200).json({
                success: true,
                message: MESSAGES.AUTH.ANDROID_AUTH_PAIRED,
                enabled: true,
                secret: account.googleAuthSecret,
                account: account.username,
                issuer: ISSUER,
                period: GoogleAuthService.PERIOD,
                digits: 6,
                algorithm: 'SHA1',
            });
        } catch (error) {
            console.error('❌ Android Auth claim error:', error);
            return res.status(500).json({ success: false, error: 'Server error' });
        }
    },

    // 3️⃣ Confirm the phone is in sync, then switch the account over
    enable: async (req, res) => {
        try {
            const { otp } = req.body;
            if (!otp) return res.status(400).json({ success: false, error: MESSAGES.AUTH.GOOGLE_AUTH_CODE_REQUIRED });

            const principal = await resolvePrincipal(req);
            if (!principal) return res.status(401).json({ success: false, error: 'Unauthorized' });
            const { account, role } = principal;

            if (!account.googleAuthSecret) {
                return res.status(400).json({ success: false, error: MESSAGES.AUTH.ANDROID_AUTH_NOT_PAIRED });
            }
            if (account.securityAuthType) {
                return res.status(400).json({ success: false, error: MESSAGES.AUTH.SECURE_AUTH_ALREADY_ENABLED });
            }

            if (!GoogleAuthService.verifyCodeForType('android', account.googleAuthSecret, otp)) {
                return res.status(400).json({ success: false, error: MESSAGES.AUTH.GOOGLE_AUTH_INVALID_CODE });
            }

            account.securityAuthType = 'android';
            await account.save();

            console.log(`✅ Secure Auth App enabled for ${role} ${account.username}`);
            return res.status(200).json({ success: true, message: MESSAGES.AUTH.ANDROID_AUTH_ENABLED });
        } catch (error) {
            console.error('❌ Android Auth enable error:', error);
            return res.status(500).json({ success: false, error: 'Server error' });
        }
    },

    // 4️⃣ Turn it off — still requires a live code from the app
    disable: async (req, res) => {
        try {
            const { otp } = req.body;
            if (!otp) return res.status(400).json({ success: false, error: MESSAGES.AUTH.GOOGLE_AUTH_CODE_REQUIRED });

            const principal = await resolvePrincipal(req);
            if (!principal) return res.status(401).json({ success: false, error: 'Unauthorized' });
            const { account, role, id } = principal;

            if (account.securityAuthType !== 'android' || !account.googleAuthSecret) {
                return res.status(400).json({ success: false, error: MESSAGES.AUTH.ANDROID_AUTH_NOT_ENABLED });
            }

            if (!GoogleAuthService.verifyCodeForType('android', account.googleAuthSecret, otp)) {
                return res.status(400).json({ success: false, error: MESSAGES.AUTH.GOOGLE_AUTH_INVALID_CODE });
            }

            account.securityAuthType = null;
            account.googleAuthSecret = null;
            await account.save();
            dropPairsFor(role, id);

            console.log(`🛑 Secure Auth App disabled for ${role} ${account.username}`);
            return res.status(200).json({ success: true, message: MESSAGES.AUTH.ANDROID_AUTH_DISABLED });
        } catch (error) {
            console.error('❌ Android Auth disable error:', error);
            return res.status(500).json({ success: false, error: 'Server error' });
        }
    },
};

export default AndroidAuthController;
