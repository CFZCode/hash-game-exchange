/**
 * Google Authenticator (TOTP) secure auth — setup, enable, disable.
 *
 * Flow the frontend drives (frontend/src/pages/SecurityAuth.jsx, Google Auth tab):
 *   1. POST /setup   { password }  → QR + setup code (secret saved, NOT active)
 *   2. POST /enable  { otp }       → securityAuthType = 'google'  → user is logged out
 *   3. POST /disable { otp }       → securityAuthType = null      → user is logged out
 *
 * Login-time verification lives in services/user/userAuthService.js (verify2FA),
 * so the client keeps using the single /user/verify-2fa endpoint.
 */
import User from '../../model/user/User.js';
import GoogleAuthService from '../../services/user/GoogleAuthService.js';
import PasswordService from '../../services/passwordService.js';
import { MESSAGES } from '../../constants/messages.js';
import { emitForceLogout } from '../../utils/socketUtils.js';
import crypto from 'crypto';

const ISSUER = (process.env.PROJECT_NAME || 'TENEXCH').toUpperCase();

// req.user shape matches telegram2faController's helper — one user id source.
const getUserId = (req) => req.user?.user_id ?? req?.user?.account?.id ?? null;

const GoogleAuthController = {
    // 1️⃣ Password check → issue a fresh secret + QR
    setup: async (req, res) => {
        try {
            const { password } = req.body;
            if (!password) return res.status(400).json({ success: false, error: MESSAGES.VALIDATION.PASSWORD_REQUIRED });

            const userId = getUserId(req);
            if (!userId) return res.status(401).json({ success: false, error: 'Unauthorized' });

            const user = await User.findByPk(userId);
            if (!user) return res.status(404).json({ success: false, error: MESSAGES.AUTH.USER_NOT_FOUND });

            const isMatch = await PasswordService.comparePassword(password, user.password);
            // Reference-site wording, same as the Telegram verify-password
            // endpoint — NOT the shared AUTH.PASSWORD_WRONG (login keeps that).
            if (!isMatch) return res.status(400).json({ success: false, error: 'User Password Not Valid.' });

            // Never let a second method be layered on top of an active one —
            // the account has exactly one securityAuthType.
            if (user.securityAuthType) {
                return res.status(400).json({ success: false, error: MESSAGES.AUTH.SECURE_AUTH_ALREADY_ENABLED });
            }

            // A fresh secret per setup attempt: an abandoned QR can never be
            // used later, because the next attempt overwrites it.
            const secret = GoogleAuthService.generateSecret();
            const otpAuthUrl = GoogleAuthService.buildOtpAuthUrl(secret, user.username, ISSUER);
            const qrCode = await GoogleAuthService.buildQrDataUrl(otpAuthUrl);

            user.googleAuthSecret = secret;
            await user.save();

            return res.status(200).json({
                success: true,
                message: MESSAGES.AUTH.GOOGLE_AUTH_SETUP_READY,
                qrCode,          // PNG data URI for <img src>
                secret,          // "Setup Code" for manual entry
                otpAuthUrl,
            });
        } catch (error) {
            console.error('❌ Google Auth setup error:', error);
            return res.status(500).json({ success: false, error: 'Server error' });
        }
    },

    // 2️⃣ Confirm the app is in sync, then switch the account over
    enable: async (req, res) => {
        try {
            const { otp } = req.body;
            if (!otp) return res.status(400).json({ success: false, error: MESSAGES.AUTH.GOOGLE_AUTH_CODE_REQUIRED });

            const userId = getUserId(req);
            if (!userId) return res.status(401).json({ success: false, error: 'Unauthorized' });

            const user = await User.findByPk(userId);
            if (!user) return res.status(404).json({ success: false, error: MESSAGES.AUTH.USER_NOT_FOUND });
            if (!user.googleAuthSecret) {
                return res.status(400).json({ success: false, error: MESSAGES.AUTH.GOOGLE_AUTH_NOT_SETUP });
            }
            if (user.securityAuthType) {
                return res.status(400).json({ success: false, error: MESSAGES.AUTH.SECURE_AUTH_ALREADY_ENABLED });
            }

            if (!GoogleAuthService.verifyToken(user.googleAuthSecret, otp)) {
                return res.status(400).json({ success: false, error: MESSAGES.AUTH.GOOGLE_AUTH_INVALID_CODE });
            }

            user.securityAuthType = 'google';
            // Same rule as the Telegram link (telegram2faController.
            // endSessionsFor): enabling secure auth ends the current session
            // server-side, so a tab that navigated away cannot keep using its
            // old token. Rotating login_id invalidates it; the push makes an
            // open tab land on the home page right away.
            user.login_id = crypto.randomUUID();
            await user.save();
            await emitForceLogout([user.user_id]);

            console.log(`✅ Google Auth enabled for user ${user.username}`);
            return res.status(200).json({ success: true, message: MESSAGES.AUTH.GOOGLE_AUTH_ENABLED });
        } catch (error) {
            console.error('❌ Google Auth enable error:', error);
            return res.status(500).json({ success: false, error: 'Server error' });
        }
    },

    // 3️⃣ Turn it off — still requires a live code from the app
    disable: async (req, res) => {
        try {
            const { otp } = req.body;
            if (!otp) return res.status(400).json({ success: false, error: MESSAGES.AUTH.GOOGLE_AUTH_CODE_REQUIRED });

            const userId = getUserId(req);
            if (!userId) return res.status(401).json({ success: false, error: 'Unauthorized' });

            const user = await User.findByPk(userId);
            if (!user) return res.status(404).json({ success: false, error: MESSAGES.AUTH.USER_NOT_FOUND });
            if (user.securityAuthType !== 'google' || !user.googleAuthSecret) {
                return res.status(400).json({ success: false, error: MESSAGES.AUTH.GOOGLE_AUTH_NOT_ENABLED });
            }

            if (!GoogleAuthService.verifyToken(user.googleAuthSecret, otp)) {
                return res.status(400).json({ success: false, error: MESSAGES.AUTH.GOOGLE_AUTH_INVALID_CODE });
            }

            user.securityAuthType = null;
            user.googleAuthSecret = null;
            await user.save();

            console.log(`🛑 Google Auth disabled for user ${user.username}`);
            return res.status(200).json({ success: true, message: MESSAGES.AUTH.GOOGLE_AUTH_DISABLED });
        } catch (error) {
            console.error('❌ Google Auth disable error:', error);
            return res.status(500).json({ success: false, error: 'Server error' });
        }
    },
};

export default GoogleAuthController;
