// Robust rules_accepted read/write that works even if the Sequelize model on a
// deployment doesn't (yet) declare the column: raw SQL against Postgres, and
// the column is created on first use if missing. Model.update() silently drops
// attributes it doesn't know, which made accept-rules a no-op — hence raw SQL.
import sequelize from '../config/db.js';
import { DataTypes } from 'sequelize';

const ensuredTables = new Set();

const tableNameOf = (model) => {
  const t = model.getTableName();
  return typeof t === 'object' ? t.tableName : t;
};

const ensureColumn = async (model) => {
  const table = tableNameOf(model);
  if (ensuredTables.has(table)) return table;
  const qi = sequelize.getQueryInterface();
  const desc = await qi.describeTable(table);
  if (!desc.rules_accepted) {
    await qi.addColumn(table, 'rules_accepted', {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
      allowNull: true,
    });
    console.log(`✅ Added rules_accepted column to "${table}"`);
  }
  ensuredTables.add(table);
  return table;
};

export const getRulesAccepted = async (model, idField, id) => {
  try {
    if (id === undefined || id === null) {
      console.error(`❌ getRulesAccepted: ${idField} is ${id} — caller passed no id`);
      return false;
    }
    const table = await ensureColumn(model);
    const [rows] = await sequelize.query(
      `SELECT "rules_accepted" FROM "${table}" WHERE "${idField}" = $1`,
      { bind: [id] }
    );

    console.log("::::::::::::rules :::::::::>>>>>>>>:::::::::::>>>>>>>>>>>>",rows)
    return rows?.[0]?.rules_accepted === true;
  } catch (error) {
    console.error('❌ getRulesAccepted error:', error.message);
    return false;
  }
};

export const setRulesAccepted = async (model, idField, id) => {
  const table = await ensureColumn(model);
  const [, meta] = await sequelize.query(
    `UPDATE "${table}" SET "rules_accepted" = true WHERE "${idField}" = $1`,
    { bind: [id] }
  );
  const updatedRows = meta?.rowCount ?? 0;
  console.log(`🔐 acceptRules: UPDATE "${table}" ${idField}=${id} → ${updatedRows} row(s)`);
  // Verify from the DB so the API can never claim success without persistence
  const accepted = await getRulesAccepted(model, idField, id);
  return { accepted, updatedRows };
};
