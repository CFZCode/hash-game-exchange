// Casino side markets where a player may hold only ONE side per round.
// tenexch.com rejects an Over 7 bet once the player has Under 7 open in the
// same round (and the reverse) with "Bet not confirmed bet already exists on
// Under 7". Enforced in CasinoService.placeBet before anything is written.
// Plan: docs/plans/2026-10-08-casino-under7-over7-exclusive.md
//
// Keys are casino_bets.game_name; selections are the feed nat exactly as stored.
const UNDER_OVER_7 = ["Under 7", "Over 7"];
const LOW_HIGH_CARD = ["Low Card", "High Card"];
const DRAGON_TIGER = ["Dragon", "Tiger"];

export const EXCLUSIVE_SIDE_PAIRS = {
  aaa: [UNDER_OVER_7],
  aaa2: [UNDER_OVER_7],
  vaaa: [UNDER_OVER_7],
  // 1 CARD ONE-DAY: 7 Up / 7 Down are exclusive per card; Player and Dealer
  // cards stay independent. Plan: docs/plans/2026-10-09-teen1-7updown-exclusive-and-book-clear.md
  teen1: [
    ["7 Up Player", "7 Down Player"],
    ["7 Up Dealer", "7 Down Dealer"],
  ],
  // 1 CARD 20-20: back-only Player / Dealer — one side per round (Tie / Pair free).
  teen120: [["Player", "Dealer"]],
  // 20-20 TEENPATTI: Total A / Total B one side per round (other markets free).
  teen20: [["Total A", "Total B"]],
  // 20-20 TEENPATTI B: Total A / Total B one side per round (other markets free).
  teen20b: [["Total A", "Total B"]],
  // 20-20 TEENPATTI C: same Total market as B (user 2026-10-14: apply the
  // teen20b fixes that fit). Other markets free.
  teen20c: [["Total A", "Total B"]],
  // Lucky 7 family: Low Card / High Card one side per round (other markets
  // free). Lucky 7 C first (docs/plans/2026-10-10-lucky7c-high-low-exclusive.md),
  // then every table with the market, like Under 7 / Over 7 on aaa
  // (docs/plans/2026-10-11-lucky7-family-low-high-exclusive.md). Feed nat is
  // "Low Card" / "High Card" on all of them (all-data checked 2026-10-11).
  lucky7: [LOW_HIGH_CARD],      // Lucky 7 - A
  lucky7eu: [LOW_HIGH_CARD],    // Lucky 7 - B
  lucky7eu2: [LOW_HIGH_CARD],   // Lucky 7 - C
  plucky7: [LOW_HIGH_CARD],     // Premium Lucky 7
  lucky5: [LOW_HIGH_CARD],      // Lucky 6
  vlucky7: [LOW_HIGH_CARD],     // Virtual Lucky 7
  // DRAGON TIGER family: Dragon / Tiger one side per round (Tie, Pair and the
  // Dragon/Tiger side markets stay free). Feed nats "Dragon" / "Tiger" on every
  // table (all-data checked 2026-10-11). dt202 first
  // (docs/plans/2026-10-11-dt202-dragon-tiger-exclusive.md), then every Dragon
  // Tiger table (docs/plans/2026-10-11-dragon-tiger-family-exclusive.md).
  // Dragon Tiger Lion (dtl20) is a different game and is not included.
  // 1 Day Dragon Tiger (dt6) is NOT restricted: Dragon and Tiger may both be
  // held in one round; its two-runner book nets them
  // (docs/plans/2026-10-12-dt6-allow-dragon-and-tiger.md).
  dt20: [DRAGON_TIGER],     // 20-20 Dragon Tiger
  dt202: [DRAGON_TIGER],    // 20-20 Dragon Tiger 2
  pdt6: [DRAGON_TIGER],     // Premium 1 Day Dragon Tiger
  pdt20: [DRAGON_TIGER],    // Premium 20-20 Dragon Tiger
  vdt6: [DRAGON_TIGER],     // Virtual 1 Day Dragon Tiger
};

/**
 * The selections that may NOT be held together with `selection` in the same
 * round of `gameName`. Empty array → no restriction.
 */
export function oppositeSides(gameName, selection) {
  const pairs = EXCLUSIVE_SIDE_PAIRS[String(gameName || "").trim().toLowerCase()];
  if (!pairs) return [];
  const sel = String(selection || "").trim();
  const pair = pairs.find((p) => p.includes(sel));
  return pair ? pair.filter((s) => s !== sel) : [];
}
