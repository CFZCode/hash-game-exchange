// Andar Bahar 150 cards (ab4) — decide one bet from the dealt cards.
// Plan: docs/plans/2026-10-12-ab4-card-by-card-settlement.md (approved 2026-10-12).
//
// Reference rules (frontend/src/components/casino/rules/AB4Rules.jsx):
//  - card #1 → Bahar, #2 → Andar, alternating (even index = Bahar);
//  - a bet is placed AT a deal position N (stored "Andar 8/23" in player_name):
//    only cards from #N onward decide it — the first card of its rank wins it
//    (bet's side) or loses it (other side), 100%;
//  - if card #N ITSELF is that rank on the other side, the bet loses only 80%
//    (20% refund). User 2026-10-12: "only the very next card";
//  - after card #149 opens, undecided Andar bets are pushed; after #150 (end of
//    the game) undecided Bahar bets are pushed.
// Pure: no I/O, so the worker and the jest test share it.

import { rankOf, parseSelection, parsePosition, decidingIndex } from "./ab50Settle.js";

const ANDAR_LAST_CARD = 149;
const BAHAR_LAST_CARD = 150;
// Loss share when the very next card is the bet's rank on the other side.
export const NEXT_CARD_LOSS_RATE = 0.8;

/**
 * @param {object} p
 * @param {string} p.selection   "Andar 8"
 * @param {string} p.playerName  "Andar 8/23" (position optional)
 * @param {string} p.type        "back" | "lay"
 * @param {string[]} p.cards     dealt cards in deal order (padding "1"/"0" = not dealt)
 * @param {boolean} p.complete   true when the deal is over (detail result)
 * @returns {null | "void" | boolean | { won: false, rate: number }}
 *   null   → not decided yet (keep the bet open)
 *   "void" → push (bad selection, lay, or undecided by the side's last card)
 *   rate   → partial loss: stake × rate
 */
export function decideAb4Bet({ selection, playerName, type, cards, complete }) {
  const sel = parseSelection(selection);
  if (!sel) return "void";
  // The table offers back only; a lay has no rule to settle by.
  if (String(type || "back").toLowerCase() === "lay") return "void";

  const position = parsePosition(playerName);
  const start = position ? position - 1 : 0;
  const lastCard = sel.side === "ANDAR" ? ANDAR_LAST_CARD : BAHAR_LAST_CARD;
  const list = cards || [];

  for (let i = start; i < lastCard; i += 1) {
    if (i >= list.length) break;
    const r = rankOf(list[i]);
    if (r === null) {
      // The deal has not reached this slot yet.
      if (complete) continue;
      return null;
    }
    if (r !== sel.rank) continue;

    const side = i % 2 === 0 ? "BAHAR" : "ANDAR";
    if (side === sel.side) return true;
    return i === start ? { won: false, rate: NEXT_CARD_LOSS_RATE } : false;
  }

  // Undecided: pushed once the side's last card is out (or the deal is over).
  const dealt = list.filter((c) => rankOf(c) !== null).length;
  if (complete || dealt >= lastCard) return "void";
  return null;
}

/**
 * Deal index (0-based) of the card that decides this bet — the statement
 * groups bets decided by the SAME dealt card into one row (as ab3). Same as
 * ab50's decidingIndex, except a match past the side's last card (#149 Andar,
 * #150 Bahar) decides nothing: that bet was pushed → null (its own row).
 */
export function ab4DecidingIndex({ selection, playerName, cards }) {
  const idx = decidingIndex({ selection, playerName, cards });
  if (idx == null) return null;
  const sel = parseSelection(selection);
  const lastCard = sel.side === "ANDAR" ? ANDAR_LAST_CARD : BAHAR_LAST_CARD;
  return idx < lastCard ? idx : null;
}
