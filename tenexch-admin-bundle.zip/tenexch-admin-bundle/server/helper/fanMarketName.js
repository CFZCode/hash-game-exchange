/**
 * The name of the fancy market a FAN bet belongs to.
 *
 * khado stores the columns the other way round from every other fancy: the
 * market ("6 over Khado run BT adv") is in selection_name and fancy_name holds
 * only the khado span ("8"). Reading fancy_name first there labelled the
 * statement "… / khado / 8 / 24" and merged every khado market that shared a
 * span into one row / one Result modal.
 */
export const isKhadoBet = (bet) => String(bet?.market_type || '').toLowerCase() === 'khado';

export const fanMarketName = (bet) => (isKhadoBet(bet)
  ? (bet?.selection_name || bet?.fancy_name || null)
  : (bet?.fancy_name || bet?.selection_name || null));
