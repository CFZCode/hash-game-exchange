// Casino placement guard: a bet must be on the round the live feed is showing
// RIGHT NOW, on a market the feed has OPEN. The server used to book whatever
// round / selection / deal position the client sent, so a hand-made request
// could bet a round that was already over, a market that had closed while its
// cards were being revealed, or (Andar Bahar 50 / 150) claim an early deal
// position and be decided by cards it had already seen.
// Plan: docs/plans/2026-10-14-casino-placement-feed-check.md
// Pure: no I/O, so CasinoService and the jest test share it.

// The feed comes wrapped zero, one or two levels deep ({ data: { data: {...} } }).
export function feedRoot(feed) {
  let root = feed ?? null;
  for (let i = 0; i < 3 && root && typeof root === "object"; i += 1) {
    if (root.mid != null || root.t1 || root.sub || root.child) return root;
    root = root.data ?? null;
  }
  return root && typeof root === "object" ? root : null;
}

// The live round id: most tables carry `mid` at the root; Super Over / 5Five
// cricket carry `t1.gmid` (their pages bet with that id).
export function liveRoundId(root) {
  if (!root) return null;
  if (root.mid != null && root.mid !== "") return String(root.mid);
  if (root.gmid != null && root.gmid !== "") return String(root.gmid);
  const t1 = Array.isArray(root.t1) ? root.t1[0] : root.t1;
  if (t1?.gmid != null && t1.gmid !== "") return String(t1.gmid);
  if (t1?.mid != null && t1.mid !== "") return String(t1.mid);
  return null;
}

const norm = (s) => String(s ?? "").replace(/\s+/g, " ").trim().toLowerCase();

// Every bettable item the feed lists, as { nat, open }.
//  - `sub` items: gstatus OPEN / ACTIVE (roulette has `s` = 1 instead);
//  - `child` items (Andar Bahar 50 / 150 ranks): `b` is the bettable flag and
//    `l` the cards of that rank left in the shoe — open only with both > 0;
//  - `t2[].section` (Super Over, 5Five cricket): gstatus ACTIVE / OPEN.
export function feedItems(root) {
  const out = [];
  const statusOpen = (it) => {
    const g = String(it?.gstatus ?? "").toUpperCase();
    if (g) return g === "OPEN" || g === "ACTIVE";
    if (it?.s != null) return Number(it.s) === 1;
    return Number(it?.b) > 0;
  };
  for (const it of Array.isArray(root?.sub) ? root.sub : []) {
    out.push({ nat: it?.nat ?? it?.n ?? "", open: statusOpen(it) });
  }
  for (const it of Array.isArray(root?.child) ? root.child : []) {
    out.push({ nat: it?.nat ?? "", open: Number(it?.b) > 0 && (it?.l == null || Number(it.l) > 0) });
  }
  for (const m of Array.isArray(root?.t2) ? root.t2 : []) {
    for (const it of Array.isArray(m?.section) ? m.section : []) {
      out.push({ nat: it?.nat ?? "", open: statusOpen(it) });
    }
  }
  return out;
}

// Doli Dana: one match (root `mid`) has many rolls. Player A / B belong to the
// match; every other market belongs to ONE roll, and the feed gives that roll
// as the market's own `mid` (= match mid + 3-digit roll no., e.g.
// 193261015014558004). It moves to the next roll exactly when betting reopens
// (measured 2026-10-15), so it is the roll the bet is for — taken from the
// feed, never from the client. Settlement decides the bet on that roll.
// Plan: docs/plans/2026-10-15-dolidana-side-markets-per-roll.md
export const ROLL_ROUND_GAMES = new Set(["dolidana"]);

// The roll mid of `selection` on a roll-round table, "" for a match-level
// market (its mid is the match), null when the feed has no usable roll.
export function feedRollMid(root, selection, live) {
  const sel = norm(selection);
  const item = (Array.isArray(root?.sub) ? root.sub : []).find((it) => norm(it?.nat) === sel);
  const mid = item?.mid != null ? String(item.mid) : "";
  if (!mid || mid === live) return "";
  return mid.length === live.length + 3 && mid.startsWith(live) && /^\d+$/.test(mid) ? mid : null;
}

// Andar Bahar 50 / 150: the deal position comes from the feed ("Card N" = the
// next card to be dealt), never from the client. Bets close after the rules'
// last bettable card.
export const AB_DEAL_GAMES = { ab3: { lastBetCard: 46 }, ab4: { lastBetCard: 144 } };

/**
 * @param {object} p
 * @param {string} p.gameName
 * @param {string} p.selection
 * @param {string|number} p.roundId  the round the client says it bet on
 * @param {object} p.feed            CasinoService.fetchAllData(gameName)
 * @returns {{ ok: true, position?: number, rollMid?: string, unchecked?: string } | { ok: false, reason: string }}
 *   ok + position → Andar Bahar: store "<selection>/<position>" as player_name
 *   ok + rollMid  → Doli Dana per-roll market: store it as the bet's round_id
 *   ok + unchecked → the feed's shape has no round id; let it through (logged)
 *   reason: "no-feed" | "round" | "closed" | "position" | "roll"
 */
export function checkCasinoBetOffered({ gameName, selection, roundId, feed }) {
  const root = feedRoot(feed);
  if (!root) return { ok: false, reason: "no-feed" };

  const live = liveRoundId(root);
  if (live == null) return { ok: true, unchecked: "no round id in feed" };
  if (String(roundId ?? "") !== live) return { ok: false, reason: "round" };

  const items = feedItems(root);
  if (items.length) {
    // The clicked item by name: exact nat, else "<nat> <line number>" (Super
    // Over fancy "1 over run IND 13", "3 Card Total 12", lottery "Single 5").
    // Names the table builds itself ("Card 1 Odd", "Dragon Card A", worli
    // "pana-123") match no item → any open item, so the round must still be
    // taking bets.
    const sel = norm(selection);
    let pool = items.filter((it) => norm(it.nat) && norm(it.nat) === sel);
    if (!pool.length) {
      pool = items.filter((it) => {
        const nat = norm(it.nat);
        return nat && sel.startsWith(`${nat} `) && /^\d+(\.\d+)?$/.test(sel.slice(nat.length + 1));
      });
    }
    if (!pool.length) pool = items;
    if (!pool.some((it) => it.open)) return { ok: false, reason: "closed" };
  }

  const ab = AB_DEAL_GAMES[String(gameName || "").toLowerCase()];
  if (ab) {
    const sub0 = Array.isArray(root.sub) ? root.sub[0] : null;
    const m = String(sub0?.nat ?? "").match(/(\d+)/);
    const position = m ? Number(m[1]) : null;
    if (!position || position > ab.lastBetCard) return { ok: false, reason: "position" };
    return { ok: true, position };
  }
  if (ROLL_ROUND_GAMES.has(String(gameName || "").toLowerCase())) {
    const rollMid = feedRollMid(root, selection, live);
    if (rollMid === null) return { ok: false, reason: "roll" };
    if (rollMid) return { ok: true, rollMid };
  }
  return { ok: true };
}
