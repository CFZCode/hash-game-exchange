/**
 * Canonical `total_exposures` writer for every path that ADDS or REMOVES
 * `user_exposures` rows.
 *
 * The snapshot is what the player's header reads (socket `getBalance` ->
 * `getUserTotalExposure`); it is NOT recomputed on read. So any deleter that
 * skips this leaves phantom exposure behind — a non-zero snapshot with no rows
 * under it, which keeps eating the player's balance forever. That is exactly
 * how saluser1 (user 24) sat at -1100 while the live formula said -200: six
 * manual voids on 2026-08-28 released 900 of exposure and never wrote back.
 *
 * TOTAL_EXPOSURE_SQL below is the ONLY copy of this query. Every writer —
 * casino placement/undo/void (services/CasinoService.js re-exports it), casino
 * settlement (casinobet/settlementCasinoWorker.js), sports placement/cancel
 * (sportsbet/sportbetscontroller.js), sports settlement (settlementv2.js),
 * manual settle and the void services — imports it from here. Do not inline a
 * copy again: until 2026-10-07 five copies existed and they disagreed on casino
 * book markets, so the header flipped with whichever writer ran last
 * (1 Card One-Day showed -102 / -300 / -102 for a real -200 / -300 / -200).
 * See docs/plans/2026-10-07-casino-exposure-sql-and-hedge-cash.md.
 *
 * Casino book markets (`game_type` like `teen1:main`, see
 * helper/casinoMarketBook.js casinoMarketGameType) hold one row per runner
 * (e.g. Player +98 / Dealer -100). Only the worst runner is at risk, so they
 * are GROUPED (MIN per market) like sports team markets. Every other casino
 * row is an independent single-row lock and stays additive.
 */
import { QueryTypes } from 'sequelize';
import sequelize from '../config/db.js';
import TotalExposure from '../model/user/TotalExposure.js';

export const TOTAL_EXPOSURE_SQL = `
  SELECT COALESCE(SUM(market_exposure), 0) AS total_exposure
  FROM (
    /* Sports markets and casino book markets, grouped by market.
       A casino book market that is in profit on every runner risks nothing:
       count 0, not the profit (placement locks Math.min(0, worst) the same way
       — CasinoService.placeBet worstOf). Sports keep their MIN unchanged. */
    SELECT CASE
             WHEN MAX(category) = 'casino' THEN LEAST(MIN(exposure_amount), 0)
             ELSE MIN(exposure_amount)
           END AS market_exposure
    FROM user_exposures
    WHERE
      user_id = :user_id
      AND game_type IS NOT NULL
      AND (category <> 'casino' OR game_type LIKE '%:%')
      AND game_type NOT IN (
        'Normal', 'Ball By Ball', 'Over By Over',
        'khado', 'meter', 'fancy1', 'oddeven', 'fancy2', 'badlo'
      )
      AND game_type NOT LIKE '%Overs Line%'
      AND NOT (
        team_name ILIKE '%back'
        OR team_name ILIKE '%lay'
        OR team_name ILIKE '%totalstake'
      )
    GROUP BY match_id, game_type, event_id

    UNION ALL

    /* Independent casino rows and independent sports rows. */
    SELECT exposure_amount AS market_exposure
    FROM user_exposures
    WHERE
      user_id = :user_id
      AND (
        (
          category = 'casino'
          AND (game_type IS NULL OR game_type NOT LIKE '%:%')
        )
        OR game_type IS NULL
        OR game_type IN (
          'Normal', 'Ball By Ball', 'Over By Over',
          'khado', 'meter', 'fancy1', 'oddeven', 'fancy2', 'badlo'
        )
        OR game_type LIKE '%Overs Line%'
      )
      AND (
        category = 'casino'
        OR NOT (
          team_name ILIKE '%back'
          OR team_name ILIKE '%lay'
          OR team_name ILIKE '%totalstake'
        )
      )
  ) subquery;
`;

/**
 * Recompute and persist one user's exposure snapshot.
 *
 * Pass the caller's transaction so the snapshot commits atomically with the
 * void — a recompute run outside the tx can still see the rows the void is
 * about to delete, and would write back the number it was meant to clear.
 *
 * @param {number|string} userId
 * @param {import('sequelize').Transaction|null} transaction
 * @returns {Promise<number>} the value written
 */
export const recalcTotalExposure = async (userId, transaction = null) => {
  const opts = transaction ? { transaction } : {};
  const rows = await sequelize.query(TOTAL_EXPOSURE_SQL, {
    replacements: { user_id: String(userId) },
    type: QueryTypes.SELECT,
    ...opts,
  });
  // SUM over zero rows is NULL -> a fully voided user correctly lands on 0
  const total = parseFloat(rows[0]?.total_exposure) || 0;
  await TotalExposure.upsert(
    { user_id: Number(userId), total_exposure: total },
    opts
  );
  return total;
};

export default { TOTAL_EXPOSURE_SQL, recalcTotalExposure };
