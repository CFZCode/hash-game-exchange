// Andar Bahar 50 cards (ab3) — decide one bet from the dealt cards.
// Plan: docs/plans/2026-10-08-ab50-settlement.md (approved 2026-10-08, "go bhai go").
//
// Reference rules (frontend/src/components/casino/rules/AB3Rules.jsx):
//  - card #1 → Bahar, #2 → Andar, alternating (even index = Bahar), up to #50;
//  - a bet is placed AT a deal position N (stored "Andar Q/7" in player_name):
//    only cards from #N onward decide it;
//  - a Bahar bet that wins on card #N itself, when #N is a Bahar card, pays 25%
//    (N 1–31) or 20% (N 33–45); every other win pays 100%;
//  - still undecided after the 50th card → pushed (void).
// Pure: no I/O, so the worker and the jest test share it.

const RANKS = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];

// "QSS" / "10HH" / "AD" → rank; feed padding ("1", "0", "") → null (not dealt).
export function rankOf(card) {
  const c = String(card || "").trim().toUpperCase();
  if (!c || c === "1" || c === "0") return null;
  const m = c.match(/^(10|[2-9]|[AJQK])/);
  return m ? m[1] : null;
}

// "Andar Q" → { side: "ANDAR", rank: "Q" }; anything else → null.
export function parseSelection(selection) {
  const m = String(selection || "").trim().toUpperCase().match(/^(ANDAR|BAHAR)\s+(10|[2-9]|[AJQK])$/);
  return m ? { side: m[1], rank: m[2] } : null;
}

// "Andar Q/7" → 7; no "/N" (old bets) → null.
export function parsePosition(playerName) {
  const m = String(playerName || "").match(/\/\s*(\d+)\s*$/);
  const n = m ? Number(m[1]) : null;
  return n && n > 0 ? n : null;
}

// Net payout ratio for a winning Bahar bet decided on its own first card.
export function firstCardRate(position) {
  if (position >= 1 && position <= 31) return 0.25;
  if (position >= 33 && position <= 45) return 0.2;
  return null;
}

/**
 * @param {object} p
 * @param {string} p.selection   "Andar Q"
 * @param {string} p.playerName  "Andar Q/7" (position optional)
 * @param {string} p.type        "back" | "lay"
 * @param {string[]} p.cards     dealt cards in deal order; undealt slots padded
 * @param {boolean} p.complete   true when the deal is over (detail result)
 * @returns {null | "void" | boolean | { won: true, rate: number }}
 *   null   → not decided yet (keep the bet open)
 *   "void" → push (bad selection, or never dealt by the end)
 *   rate   → net profit ratio BEFORE the worker's commission adjustment
 */
export function decideAb50Bet({ selection, playerName, type, cards, complete }) {
  const sel = parseSelection(selection);
  if (!sel || !RANKS.includes(sel.rank)) return "void";

  const position = parsePosition(playerName);
  const start = position ? position - 1 : 0;
  const isLay = String(type || "back").toLowerCase() === "lay";

  for (let i = start; i < (cards || []).length; i += 1) {
    const r = rankOf(cards[i]);
    if (r === null) {
      // The deal has not reached this slot yet.
      if (complete) continue;
      return null;
    }
    if (r !== sel.rank) continue;

    const side = i % 2 === 0 ? "BAHAR" : "ANDAR";
    const marketWin = side === sel.side;
    const userWon = isLay ? !marketWin : marketWin;
    if (!userWon) return false;

    // 25% / 20%: a Bahar back bet won on its very first card, that card a Bahar card.
    if (!isLay && position && sel.side === "BAHAR" && i === start && i % 2 === 0) {
      const rate = firstCardRate(position);
      if (rate) return { won: true, rate };
    }
    return true;
  }

  // Rank not dealt at/after the bet's position.
  return complete ? "void" : null;
}

/**
 * Deal index (0-based) of the card that decides this bet: the first card of
 * its rank at/after its position, whichever side it falls on. null while that
 * card has not been dealt (or the selection is unreadable). The statement uses
 * it to group bets the reference shows as one row — bets decided by the SAME
 * dealt card (e.g. "Bahar 9/25" + "Andar 9/33" both decided by the 9 at #34).
 */
export function decidingIndex({ selection, playerName, cards }) {
  const sel = parseSelection(selection);
  if (!sel) return null;
  const position = parsePosition(playerName);
  const start = position ? position - 1 : 0;
  for (let i = start; i < (cards || []).length; i += 1) {
    const r = rankOf(cards[i]);
    if (r === null) return null;
    if (r === sel.rank) return i;
  }
  return null;
}
