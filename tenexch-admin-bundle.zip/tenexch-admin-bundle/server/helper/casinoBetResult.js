// Per-bet outcome of a casino_bets row, as the reports show it: side, the
// player's net P/L (win) and whether the bet counts as deleted. Shared by the
// Account Statement "Details" (UserStatementService.getStatementCasinoBets) and
// the admin casino Result modal round-bets list (casinoRoundBetsService).
// Plan: docs/plans/2026-10-09-admin-casino-result-round-bets.md

const round2 = (n) => Math.round(Number(n || 0) * 100) / 100;

export const CASINO_DELETED_STATES = ['refund', 'void', 'deleted', 'cancelled'];

/**
 * @param {Object} b - raw casino_bets row
 * @param {{ refunded?: boolean }} [opts] - refunded: settlement refunded the
 *   bet (a tie — it has a BET_REFUND ledger row, see helper/casinoRefundedBets.js).
 *   Such a void is a settled bet with Win 0, as on the reference — not a
 *   deleted one (user Undo/Clear and admin open voids leave no such row).
 * @returns {{ side: 'BACK'|'LAY'|null, win: number|null, deleted: boolean }}
 *   win is null while the bet is unsettled (or void).
 */
export function casinoBetOutcome(b, { refunded = false } = {}) {
  const type = String(b.type || '').toLowerCase();
  const side = type === 'back' ? 'BACK' : type === 'lay' ? 'LAY' : null;
  const rs = String(b.result_status || '').toLowerCase();
  if (refunded) return { side, win: 0, deleted: false };
  const deleted = CASINO_DELETED_STATES.includes(rs)
    || CASINO_DELETED_STATES.includes(String(b.status || '').toLowerCase());

  // Net P/L: won → payout (credit_amt) minus the bet's OWN liability;
  // lost → -credit_amt (worker stores the debited amount there).
  // settlementCasinoWorker pays a normal win as credit_amt = stake × odds
  // and books netProfit = credit_amt − (lay ? stake×(odds−1) : stake), so
  // subtract that same liability. Only cmeter1 (payoutRate path) pays
  // credit_amt = |exposer| + netProfit, so it keeps the placement lock.
  // Using |exposer| for every game was wrong for a HEDGE: the second bet
  // of a book (e.g. teen3 Player A then Player B) locks less than its
  // stake, so its win showed inflated (54 instead of 49.04).
  const stake = Number(b.stake || 0);
  const odds = Number(b.odds || 0);
  const ownLiability = type === 'lay' ? round2(stake * (odds - 1)) : stake;
  const exposure = String(b.game_name || '').toLowerCase() === 'cmeter1' && Number(b.exposer)
    ? Math.abs(Number(b.exposer))
    : ownLiability;
  const win = rs === 'won' ? round2(Number(b.credit_amt) - exposure)
    : (rs === 'lost' || rs === 'loss') ? -round2(b.credit_amt)
    : null;

  return { side, win, deleted };
}
