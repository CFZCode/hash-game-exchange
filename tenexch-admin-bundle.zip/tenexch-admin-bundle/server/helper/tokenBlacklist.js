import crypto from 'crypto';
import { Op } from 'sequelize';
import TokenBlacklist from '../model/admin/TokenBlacklist.js';

/**
 * Revoked-token list, keyed by a HASH of the token rather than the token.
 *
 * Why a hash. `TokenBlacklist.token` is `DataTypes.STRING` — VARCHAR(255) — and
 * a JWT this app issues is 343 characters (measured 2026-09-13 against
 * api.tenexchn.com). Every `create` therefore failed with "value too long", the
 * logout route answered 500 "Failed to logout user", and the token kept working
 * afterwards: the session was never actually revoked. A SHA-256 hex digest is
 * 64 characters, so it fits the column as it stands and no migration has to run
 * against the live database.
 *
 * Two things fall out of it for free: the unique index shrinks from 343 bytes to
 * 64 on a table `authMiddleware` reads on EVERY authenticated request, and the
 * table stops being a pile of live bearer tokens — anyone who could read it
 * could previously use what they found.
 *
 * A hash cannot be reversed, which is all this table needs: it only ever asks
 * "have I seen this exact token before".
 */

const hash = (token) => crypto.createHash('sha256').update(String(token)).digest('hex');

/** Revoke a token until it expires on its own. */
export const blacklistToken = async (token, expiresAt) => {
  await TokenBlacklist.create({ token: hash(token), expiresAt });
};

/**
 * Has this token been revoked?
 *
 * Matches the hash OR the raw token, because rows written before this change
 * hold the token itself. Short-lived by nature — every such row carries an
 * `expiresAt` and is dead once that passes — but while they exist they must
 * keep revoking, or logging out and back in would quietly un-revoke a session
 * somebody deliberately killed. Drop the raw arm once no pre-change row can
 * still be live (JWT_EXPIRATION after deploy; the default is 1 day).
 */
export const isTokenBlacklisted = async (token) => {
  const row = await TokenBlacklist.findOne({
    where: { token: { [Op.in]: [hash(token), token] } },
  });
  return !!row;
};

export default { blacklistToken, isTokenBlacklisted };
