// Meter is a SPREAD market, not a line: it pays the RUN DIFFERENCE per unit of
// stake instead of a flat win/lose. `yes` gains as runs climb past the line,
// `no` gains as they fall short. The ramp FLATTENS METER_MAX_RUNS past the
// line — that flat is the whole worst case on the no side (150 x stake), and
// it is what the Run Amount ladder draws.
//
// Every meter money spot goes through here — the exposure blocked at placement,
// the per-bet liability, the settlement payout and the admin statement — so the
// ramp can never drift between them.
export const METER_MAX_RUNS = 150;

export const isMeterMarket = (marketType) =>
  ['meter', 'meters'].includes(String(marketType || '').toLowerCase());

const isYesSide = (betType) => ['yes', 'back'].includes(String(betType || '').toLowerCase());

// Signed P&L of ONE meter bet if the market settles on `runs`.
export function meterPnl({ runs, line, stake, betType }) {
  const capped = Math.min(Number(runs), Number(line) + METER_MAX_RUNS);
  const diff = (capped - Number(line)) * Number(stake);
  const signed = isYesSide(betType) ? diff : -diff;
  // `-0` on the no side exactly at the line would render as "-0" in the ladder.
  return signed === 0 ? 0 : signed;
}

// Money to block for ONE meter bet — the ramp's low point:
//   no  -> the capped tail at line+150, 150 x stake
//   yes -> runs = 0,                    line x stake
export function meterLiability({ line, stake, betType }) {
  return isYesSide(betType) ? Number(line) * Number(stake) : METER_MAX_RUNS * Number(stake);
}
