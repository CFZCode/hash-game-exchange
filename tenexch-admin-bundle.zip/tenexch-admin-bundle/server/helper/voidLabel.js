// Void rows ka statement label: "<market ka naam> -void".
//
// Purane voids remark/description me "VOID after settlement — X" likhte the,
// naye seedha "X -void". User panel (UserStatementService) aur admin panel
// (TransactionReportService) DONO yahi helper use karte hain — wording kabhi
// alag na ho, warna wahi purana jaal: do verbatim copies jo alag-alag khisak
// jaati hain.
import { POINT_EVENT } from '../constants/pointLedger.js';

export const VOID_SUFFIX = '-void';

// point_ledger ki ulti entry: settlement ka REVERSAL ya commission ka
// reverse:commission:* — dono ka entry_ref 'reverse:' se shuru hota hai.
export const isVoidRow = (row) =>
  row?.event_type === POINT_EVENT.REVERSAL ||
  String(row?.entry_ref || '').startsWith('reverse:');

export const stripVoidPrefix = (text) =>
  String(text || '').replace(/^VOID after settlement\s*[—-]\s*/i, '').trim();

export const withVoidSuffix = (text) => {
  const s = stripVoidPrefix(text);
  if (!s) return VOID_SUFFIX;
  return s.endsWith(VOID_SUFFIX) ? s : `${s} ${VOID_SUFFIX}`;
};

export default { VOID_SUFFIX, isVoidRow, stripVoidPrefix, withVoidSuffix };
