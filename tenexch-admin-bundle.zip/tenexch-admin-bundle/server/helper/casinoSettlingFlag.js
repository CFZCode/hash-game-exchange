// Casino settlement ↔ header balance ticker handshake.
// Plan: docs/plans/2026-10-13-casino-settlement-single-balance-step.md
//
// The settlement worker commits one bet at a time, then sends ONE balance push per
// user/round. The 3 s header ticker (socket/socketHandler.js subscribeBalance)
// reads the wallet from the DB, so a tick that lands mid-batch painted a
// half-settled balance (mixed win/loss rounds stepped in the header).
//
// One Redis key per user:
//   "busy"        — the worker is settling this user's bets right now
//   "done:<ms>"   — the worker's final push went out at <ms>
// The ticker drops its push while "busy", and also when "done" is newer than the
// moment it started reading (its figures may predate the final push). The TTL
// means a crashed worker can never silence a header for long.
// Best effort: any Redis error behaves exactly like no key (today's behaviour).

const TTL_SEC = 15;

export const casinoSettlingKey = (userId) => `casino:settling:${userId}`;

export async function markCasinoSettling(redis, userIds) {
  if (!userIds.length) return;
  try {
    const p = redis.pipeline();
    userIds.forEach((u) => p.set(casinoSettlingKey(u), "busy", "EX", TTL_SEC));
    await p.exec();
  } catch (e) {
    console.warn("[Settlement] settling flag set failed", e.message);
  }
}

export async function markCasinoSettled(redis, userIds) {
  if (!userIds.length) return;
  try {
    const p = redis.pipeline();
    const value = `done:${Date.now()}`;
    userIds.forEach((u) => p.set(casinoSettlingKey(u), value, "EX", TTL_SEC));
    await p.exec();
  } catch (e) {
    console.warn("[Settlement] settling flag clear failed", e.message);
  }
}

/**
 * Should a ticker push whose reads started at `readStartedAt` (ms) be dropped?
 * Pure, so the jest test covers it without Redis.
 */
export function tickerShouldSkip(flagValue, readStartedAt) {
  const v = String(flagValue || "");
  if (v === "busy") return true;
  const m = v.match(/^done:(\d+)$/);
  return m ? Number(m[1]) >= readStartedAt : false;
}

export async function casinoTickerShouldSkip(redis, userId, readStartedAt) {
  try {
    return tickerShouldSkip(await redis.get(casinoSettlingKey(userId)), readStartedAt);
  } catch {
    return false;
  }
}
