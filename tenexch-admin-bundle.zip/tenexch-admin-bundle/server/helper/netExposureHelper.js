
import UserExposure from "../model/user/UserExposure.js";
import sequelize from "../config/db.js";

/**
 * Calculates the net exposure for all users present in the UserExposure table.
 * Logic:
 * 1. Group by user_id and match_id (market).
 * 2. Find the MIN(exposure_amount) for each market (worst-case scenario).
 * 3. Sum these minimums for each user to get total net exposure.
 * 
 * @returns {Promise<Object>} A map of user_id -> net_exposure
 */
export const calculateNetExposure = async () => {
  try {
    // 1. Get all exposures grouped by user and match/market
    // We need to fetch all rows to perform the logic correctly in JS, 
    // or use a complex SQL query. Given the complexity, a raw query is best.

    // Query:
    // SELECT user_id, SUM(market_exposure) as total_exposure
    // FROM (
    //   SELECT user_id, match_id, game_type, event_id, MIN(exposure_amount) as market_exposure
    //   FROM user_exposures
    //   GROUP BY user_id, match_id, game_type, event_id
    // ) as subquery
    // GROUP BY user_id

    // ── LIABILITY-ONLY net exposure ──────────────────────────────────────
    // We clamp positive market_exposure to 0 with LEAST(..., 0). Rationale:
    // "net_exposure" is a *liability* metric — it should reflect the worst
    // case LOSS the user can take (a negative number) so the admin UI can
    // show how much of the user's wallet is at risk. When a user has hedged
    // / profit-booked, every team's exposure is positive (guaranteed P/L),
    // there is no liability, so the value must be 0 — not the smaller
    // positive (which previously made the UI display "+50" instead of "0"
    // for fully-locked profit markets).
    //
    // Locked profits intentionally do NOT inflate this number. There is no
    // GT/balance formula in the codebase that uses net_exposure
    // arithmetically — it is read purely for display in admin lists.
    const query = `
    SELECT user_id, SUM(market_exposure) AS total_exposure
FROM (

  /* 1️⃣ GROUPED SPORTS MARKETS (Worst-case per market, clamped to ≤ 0) */
  SELECT
    user_id,
    match_id,
    game_type,
    event_id,
    LEAST(MIN(exposure_amount), 0) AS market_exposure
  FROM user_exposures
  WHERE
    category <> 'casino'
    AND game_type IS NOT NULL
    AND game_type NOT IN ('Normal', 'Ball By Ball', 'Over By Over', 'khado', 'meter' , 'fancy1', 'oddeven', 'fancy2', 'badlo')
    AND game_type NOT LIKE '%Overs Line%'
    AND NOT (team_name ILIKE '%back' OR team_name ILIKE '%lay' OR team_name ILIKE '%totalstake')
  GROUP BY user_id, match_id, game_type, event_id

  UNION ALL

  /* 2️⃣ INDEPENDENT MARKETS (Additive Exposure, clamped to ≤ 0) */
  SELECT
    user_id,
    NULL AS match_id,
    game_type,
    event_id,
    LEAST(exposure_amount, 0) AS market_exposure
  FROM user_exposures
  WHERE
    (
      category = 'casino'
      OR game_type IS NULL
      OR game_type IN ('Normal', 'Ball By Ball', 'Over By Over', 'khado', 'meter', 'fancy1', 'oddeven', 'fancy2', 'badlo')
      OR game_type LIKE '%Overs Line%'
    )
    AND NOT (team_name ILIKE '%back' OR team_name ILIKE '%lay' OR team_name ILIKE '%totalstake')

) subquery
GROUP BY user_id;

    `;

    const results = await sequelize.query(query, {
      type: sequelize.QueryTypes.SELECT
    });

    // Transform into a map
    const exposureMap = {};
    for (const record of results) {
      // Ensure we only sum negative exposures (losses). 
      // Usually exposure is negative. If min is positive, it means guaranteed profit, so exposure is 0.
      // However, standard practice is often just sum(min). Let's stick to sum(min).
      // If min is positive, it adds to "exposure" which might be wrong if exposure means "liability".
      // But usually "Net Exposure" includes locked profit. 
      // Let's assume standard behavior: Sum of worst case scenarios.
      // If worst case is +100, then it contributes +100 to "Available Balance" calculation?
      // Wait, User GT = Credit - Limit + NetExposure.
      // If NetExposure is -100, GT decreases.
      // If NetExposure is +100 (guaranteed win), GT increases.
      // So Sum(Min) is correct.

      let net = parseFloat(record.total_exposure) || 0;

      // Safety check: Exposure should generally not exceed 0 (be positive) unless it's a guaranteed win across all markets.
      // But usually we only care about liability. 
      // Let's keep it as is.

      exposureMap[record.user_id] = net;
    }

    // console.log("exposureMap from net exposure helper", exposureMap);

    return exposureMap;
  } catch (error) {
    console.error("Error calculating net exposure:", error);
    throw error;
  }
};

/* ────────────────────────────────────────────────────────────────────────────
 * PROFIT-SIDE ("max win" / book liability) exposure
 * ──────────────────────────────────────────────────────────────────────────*/

// Market classification is kept byte-identical to calculateNetExposure above so
// both metrics slice the same rows the same way — only the direction changes.
const INDEPENDENT_GAME_TYPES = `'Normal', 'Ball By Ball', 'Over By Over', 'khado', 'meter', 'fancy1', 'oddeven', 'fancy2', 'badlo'`;

/**
 * MAX WIN for a set of users = the most those users can take off the book.
 *
 * Mirror image of calculateNetExposure():
 *   - calculateNetExposure  -> LEAST(MIN(exposure_amount), 0)      user's worst case (user loss / admin profit)
 *   - calculateMaxWinExposure -> GREATEST(MAX(exposure_amount), 0) user's best case  (user profit / ADMIN LOSS)
 *
 * Returned POSITIVE — it is money the users can win, which is what the admin
 * owner dashboard card shows. calculateProfitExposure() below is the same
 * number negated, for callers that want the "exposure is always <= 0" sign.
 *
 * Three row shapes, because user_exposures does not store the upside the same
 * way for all of them:
 *
 *  1. GROUPED books — sports markets (Match Odds, Bookmaker, Toss …) and casino
 *     book markets (game_type 'game:market'). Every runner has its own row and
 *     exactly ONE settles, so the payout is the single best row: MAX per market.
 *     The {sel}back/{sel}lay/{sel}totalstake helper-key filter is NOT applied to
 *     casino rows — real casino runners ("Player A") contain 'lay' as a
 *     substring and would be dropped (see the same guard in TOTAL_EXPOSURE_SQL).
 *
 *  2. LADDER selections — fancy/session (Normal, Ball By Ball, Over By Over,
 *     khado, meter, fancy1, oddeven) and the Overs Line markets. Here the BASE
 *     row deliberately holds the WORST case (sportbetscontroller writes the
 *     ladder's minimum P&L into it), so the upside only exists on the
 *     {sel}back / {sel}lay helper rows. Each selection settles on its own, so
 *     they are grouped per selection (suffix stripped), not per match.
 *
 *  3. INDEPENDENT single rows — legacy casino games and game_type-less rows
 *     carry only money at risk (negative) with no upside stored, so they
 *     contribute 0 unless the row itself is already in profit.
 *
 * Every market is clamped to >= 0: one where every outcome loses for the user
 * carries no payout risk for the book, so it contributes 0 rather than a
 * negative offset.
 *
 * @param {Array<number|string>} userIds - user_ids to scope to; [] returns 0
 * @returns {Promise<number>} total the users can win, as a POSITIVE number (0 when nothing is at risk)
 */
export const calculateMaxWinExposure = async (userIds) => {
  if (!Array.isArray(userIds) || userIds.length === 0) return 0;

  // Single aggregate row — the per-user rows never leave Postgres. The `scoped`
  // CTE narrows to the hierarchy once (hits the user_id-leading index) and all
  // three branches read from that materialised set instead of scanning thrice.
  const query = `
    WITH scoped AS (
      SELECT user_id, match_id, event_id, game_type, category, team_name, exposure_amount
      FROM user_exposures
      WHERE user_id = ANY($userIds::bigint[])
    )
    SELECT COALESCE(SUM(max_win), 0) AS max_win
    FROM (

      /* 1️⃣ GROUPED BOOKS — one runner settles: best row per market */
      SELECT GREATEST(MAX(exposure_amount), 0) AS max_win
      FROM scoped
      WHERE
        game_type IS NOT NULL
        AND (category <> 'casino' OR game_type LIKE '%:%')
        AND game_type NOT IN (${INDEPENDENT_GAME_TYPES})
        AND game_type NOT LIKE '%Overs Line%'
        AND (
          category = 'casino'
          OR NOT (team_name ILIKE '%back' OR team_name ILIKE '%lay' OR team_name ILIKE '%totalstake')
        )
      GROUP BY user_id, match_id, game_type, event_id

      UNION ALL

      /* 2️⃣ LADDER SELECTIONS — upside lives on the {sel}back/{sel}lay rows,
             one region settles per selection */
      SELECT GREATEST(MAX(exposure_amount), 0) AS max_win
      FROM scoped
      WHERE
        category <> 'casino'
        AND (
          game_type IN (${INDEPENDENT_GAME_TYPES})
          OR game_type LIKE '%Overs Line%'
        )
        AND (team_name ILIKE '%back' OR team_name ILIKE '%lay')
        AND team_name NOT ILIKE '%totalstake'
      GROUP BY user_id, match_id, game_type, event_id,
               regexp_replace(team_name, '(back|lay)$', '', 'i')

      UNION ALL

      /* 3️⃣ INDEPENDENT SINGLE ROWS — legacy casino / game_type-less: risk only */
      SELECT GREATEST(exposure_amount, 0) AS max_win
      FROM scoped
      WHERE
        (category = 'casino' AND (game_type IS NULL OR game_type NOT LIKE '%:%'))
        OR (category <> 'casino' AND game_type IS NULL)

    ) markets;
  `;

  try {
    const [row] = await sequelize.query(query, {
      // bound as a bigint[] so a 10k-user hierarchy stays one small parameter
      // instead of a 10k-term IN (...) list
      bind: { userIds: userIds.map(String) },
      type: sequelize.QueryTypes.SELECT,
    });

    const maxWin = parseFloat(row?.max_win) || 0;
    return Math.round(maxWin * 100) / 100;
  } catch (error) {
    console.error("Error calculating max win exposure:", error);
    throw error;
  }
};

/**
 * Same figure as calculateMaxWinExposure(), NEGATED — the users' upside is the
 * book's downside, so this carries the "exposure is always <= 0" sign
 * convention of calculateNetExposure(). Example: markets worth +197, +143 and
 * +116 to the users return -456.
 *
 * @param {Array<number|string>} userIds - user_ids to scope to; [] returns 0
 * @returns {Promise<number>} payout liability as a NEGATIVE number (0 when nothing is at risk)
 */
export const calculateProfitExposure = async (userIds) => {
  const maxWin = await calculateMaxWinExposure(userIds);
  // Guarded so a zero liability stays 0 instead of -0.
  return maxWin === 0 ? 0 : -maxWin;
};
