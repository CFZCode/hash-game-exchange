import crypto from 'crypto';
import { Op } from 'sequelize';
import User from '../model/user/User.js';
import Staff from '../model/admin/Staff.js';
import { getDescendantStaffIds } from './getuserids.js';

// Upline lock rules shared by login and the admin lock toggle.
//
// An account is LOGIN-locked when it, or any staff above it, has been switched
// off: a player whose status is not 'Active', or a staff row with
// active = false. Owners are the top of the tree and carry no flag, so the walk
// ends there. A staff row with role OWNER is never treated as locked — the same
// exemption staff login has always had. (Bet lock is a separate rule and does
// NOT block login: see services/BetLockService.js.)

const isStaffSwitchedOff = (staff) =>
  String(staff.role || '').toUpperCase() !== 'OWNER' && !staff.active;

/**
 * @param {{ type: 'USER'|'STAFF', id: number }} account
 * @returns {Promise<boolean>} true when login must be refused
 */
export const isLoginLockedInChain = async ({ type, id }) => {
  let staffId = null;

  if (type === 'USER') {
    const user = await User.findByPk(id, { attributes: ['user_id', 'status', 'parent_staff_id'] });
    // Not-found is the caller's error to report, not a lock.
    if (!user) return false;
    if (user.status !== 'Active') return true;
    staffId = user.parent_staff_id;
  } else {
    staffId = id;
  }

  // `seen` guards against a parent_id cycle in bad data.
  const seen = new Set();
  while (staffId && !seen.has(staffId)) {
    seen.add(staffId);
    const staff = await Staff.findByPk(staffId, { attributes: ['staff_id', 'role', 'active', 'parent_id'] });
    // A broken parent reference fails open, same as BetLockService.
    if (!staff) break;
    if (isStaffSwitchedOff(staff)) return true;
    staffId = staff.parent_id;
  }

  return false;
};

/**
 * Everyone who must be logged out when `account` is locked: the account itself,
 * and for a staff account its whole downline (staff and players).
 * @returns {Promise<{ userIds: number[], staffIds: number[] }>}
 */
export const collectAffectedAccounts = async ({ type, id }) => {
  if (type === 'USER') return { userIds: [id], staffIds: [] };

  const staffIds = [id, ...(await getDescendantStaffIds(id))];
  const users = await User.findAll({
    where: { parent_staff_id: { [Op.in]: staffIds } },
    attributes: ['user_id'],
    raw: true,
  });
  return { userIds: users.map((u) => u.user_id), staffIds };
};

/**
 * Kill every issued token of these accounts. authMiddleware rejects a token
 * whose `sid` differs from the row's login_id, so writing a fresh value is
 * enough. It must NOT be NULL — a NULL login_id switches that check off.
 */
export const revokeSessions = async ({ userIds, staffIds }, transaction) => {
  const login_id = crypto.randomUUID();
  if (userIds.length) {
    await User.update({ login_id }, { where: { user_id: { [Op.in]: userIds } }, transaction });
  }
  if (staffIds.length) {
    await Staff.update({ login_id }, { where: { staff_id: { [Op.in]: staffIds } }, transaction });
  }
};
