// Redis keys + reads for the SuperOver scorecard. Side-effect free (no poller,
// no self-start) so both the poller cron and the HTTP controller can import it
// without accidentally starting a second poller inside the API process.

import redis from "../config/redisClient.js";

// Per-round accumulator (the two innings so far), keyed by table + gmid.
export const superOverAccKey = (type, gmid) => `superoverscore:${type}:${gmid}`;
// Latest derived scorecard for a table — a warm start for the HTTP initial
// fetch; the socket carries live updates after that.
export const superOverCardKey = (type) => `superovercard:${type}`;

export const ACC_TTL = Number(process.env.SUPEROVER_SCORE_TTL || 600);
export const CARD_TTL = Number(process.env.SUPEROVER_CARD_TTL || 30);

// Latest scorecard for a table, or null when none is cached (poller off, or no
// SuperOver round running). Never throws — the caller returns null on a miss.
export async function getLatestScorecard(type) {
  try {
    const raw = await redis.get(superOverCardKey(type));
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}
