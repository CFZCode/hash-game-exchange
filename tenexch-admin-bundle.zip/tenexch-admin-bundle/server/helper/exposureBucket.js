/**
 * WHICH BETS SHARE ONE POT OF BLOCKED MONEY?
 *
 * Every void path has to answer this before it touches a wallet, and getting it
 * wrong costs a punter real money in one of two directions:
 *
 *   too WIDE  -> a void releases (or destroys) exposure that other, still-open
 *                bets are holding, leaving them unblocked.
 *   too NARROW-> a void releases nothing, and the punter's stake stays locked
 *                behind a bet that already reads 'refunded'.
 *
 * There are two shapes in this system:
 *
 *   PER-MARKET (MO / BM). One book per match+market_type. Every runner row is
 *   part of the same ladder and the cash blocked is the WORST row across it.
 *   Voiding one bet only frees money once every other open bet of that market
 *   is gone.
 *
 *   PER-SELECTION (the fancy family). Each session holds its OWN money and its
 *   own four rows. Placement proves it: the fancy branch of
 *   sportbetscontroller.js computes the wallet delta from the `sel` row alone
 *   (`key === sel`), and helper/totalExposure.js counts those rows ADDITIVELY
 *   rather than grouping them per market. A punter with 60 fancy1 bets on one
 *   match has 60 independent pots, not one.
 *
 * Treating the second as the first is what stranded bet 1907 (Top Batsman ZIM
 * T Tsiga, 10000 on match 549011228324): the void asked "any other open bet on
 * this match+market_type?", found 59 unrelated fancy1 sessions, and skipped the
 * refund and the row destroy entirely. The bet closed as 'refunded' with the
 * money still blocked.
 *
 * Keep PER_SELECTION_MARKETS in step with `marketsforfancy` in
 * sportsbet/sportbetscontroller.js and the additive branch of
 * helper/totalExposure.js. Those three lists ARE the same fact written down
 * three times; when they disagree, money goes missing.
 */
import { isLineMarket } from './lineMarket.js';

export const PER_SELECTION_MARKETS = new Set([
    'Normal', 'Ball By Ball', 'Over By Over', 'khado', 'meter',
    'fancy1', 'oddeven', 'badlo',
]);

// Line markets are per-selection too — they just key their pot by the MARKET
// name instead of the runner (see exposureIdentity in helper/lineMarket.js).
export const isPerSelectionMarket = (marketType) =>
    PER_SELECTION_MARKETS.has(String(marketType || '')) || isLineMarket(marketType);

// The four user_exposures rows one selection owns. Always feed this the
// team_name exposureIdentity() returned, never a raw selection_name — line
// markets stem off the market name and badlo off the runner.
export const selectionExposureRows = (sel) =>
    [sel, `${sel}lay`, `${sel}back`, `${sel}totalstake`];

// The lay/back/totalstake rows are legacy aggregates kept for other consumers,
// NOT money. Only the base `sel` row is the liability — the same filter
// helper/totalExposure.js applies before it sums anything.
export const isHelperExposureRow = (teamName) =>
    /(?:lay|back|totalstake)$/i.test(String(teamName || ''));

/**
 * Signed cash to release when an exposure bucket is torn down (<= 0).
 *
 *   per-selection -> the `sel` row alone, which is exactly what placement
 *                    blocked. fancy1/oddeven already store
 *                    sel = min(layExp, backExp), so it IS the worst case;
 *                    min-ing the lay/back aggregates back in would over-refund
 *                    a hedged ladder.
 *   per-market    -> the worst row across the whole book (MO/BM).
 */
export const releasableLiability = (exposures, { perSelection, sel } = {}) => {
    if (perSelection) {
        const base = exposures.find((e) => e.team_name === sel);
        return Math.min(0, parseFloat(base?.exposure_amount || 0));
    }
    return exposures.reduce(
        (min, e) => Math.min(min, parseFloat(e.exposure_amount || 0)),
        0,
    );
};

/**
 * Sum of every selection's liability in a bucket (<= 0). Used when a
 * per-selection market is torn down WHOLESALE: fancy money is additive across
 * selections, so a single min() would refund one session and swallow the rest.
 */
export const additiveBucketLiability = (exposures) =>
    exposures.reduce((sum, e) => {
        if (isHelperExposureRow(e.team_name)) return sum;
        const val = parseFloat(e.exposure_amount || 0);
        return val < 0 ? sum + val : sum;
    }, 0);

/**
 * A bet that actually went through settlement. Open bets were never covered by
 * a settlement ledger row, so no settlement-void may ever close them — doing so
 * kills a live bet AND orphans the exposure it is still holding.
 */
// 'lost' is the casino spelling; sports writes 'loss'. Accept both so a clone
// with the other spelling is not silently skipped.
export const SETTLED_RESULT_STATUSES = ['won', 'loss', 'lost'];
