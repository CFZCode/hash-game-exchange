/**
 * Per-runner exposure book for casino tables.
 *
 * WHY: casino placement used to write a SINGLE user_exposures row — the backed
 * runner holding the wallet liability (−stake). The exchange shows a *book*
 * instead: the backed runner carries the potential profit and every other runner
 * in the same market carries the loss. With one row the frontend could only
 * print "−stake" under the selected player and nothing under the others, which
 * is the opposite of what the live site shows.
 *
 * The math is the same one the sports side already uses in
 * sportsbet/sportbetscontroller.js → calculateRunnerExposure, and it matches how
 * casinobet/settlementCasinoWorker.js pays out:
 *   back win  → +stake*(odds−1)   back loss → −stake
 *   lay  win  → +stake            lay  loss → −stake*(odds−1)
 *
 * Rows written for a book market carry game_type = `${gameName}:${marketKey}`.
 * That tag is what makes net exposure treat them as ONE market (worst case =
 * MIN over its runners) instead of summing every row — see
 * helper/netExposureHelper.js. Games absent from both MARKETS and
 * DYNAMIC_MARKETS keep the legacy single-row behaviour, so this is opt-in per
 * game.
 */

const round2 = (n) => Math.round((Number(n) || 0) * 100) / 100;

// Runner sets mirror how settlementCasinoWorker resolves each game: every group
// below settles independently, so every group is its own book.
// aaa and aaa2 are the same table (same 22 runners, same back/lay layout — only
// the main players take a lay), so they share one definition.
//
// ONLY the main market books across its runners. The live site shows the side
// markets (Even/Odd, Red/Black, Under 7/Over 7, Card A–K) as a plain worst-case
// figure under the selected runner alone, with nothing under its opposite — so
// those selections deliberately stay OUT of this registry and fall through to
// the legacy single-row path in CasinoService.placeBet.
const AAA_MARKETS = [
    { key: "main", runners: ["Amar", "Akbar", "Anthony"] },
];

// teen1 — 1 CARD ONE-DAY. ONLY the main Player/Dealer bet books (back AND lay);
// a TIE returns it, which cannot improve the worst case, so the plain two-runner
// shape holds. The 7Up/7Down pairs stay out on purpose — like the other side
// markets above, the live site prints a single worst-case figure under the
// backed side and nothing under its opposite, which is the legacy single-row
// path in CasinoService.placeBet.
const TEEN1_MARKETS = [
    { key: "main", runners: ["Player", "Dealer"] },
];

// 1 Day Dragon Tiger (dt6) — ONLY the main two-way Dragon vs Tiger bet books
// across both runners (feed etype "match", subtype "dt6"). Back Dragon →
// Dragon:+stake*(odds−1) (the profit, shown under the backed runner), Tiger:−stake
// (the worst-case loss, shown under the other runner); lay is the inverse. The
// Pair bet and the Dragon/Tiger odd-even/colour/suit props are feed etype
// "fancy" — single-outcome selections that stay OUT of the registry and keep the
// legacy single-row path (one figure under the backed side, nothing opposite).
// dt6 — 1 Day Dragon Tiger. Dragon vs Tiger, but a TIE is a real third outcome
// (data.winner === "TIE" → BOTH Dragon and Tiger lose) with no bettable runner on
// the feed. A plain two-way [Dragon, Tiger] book would UNDER-LOCK a hedged
// Dragon+Tiger position: it locks min(Dragon, Tiger) but a tie loses BOTH stakes.
// Adding the non-bettable "Tie" outcome makes the market EXHAUSTIVE — backing
// Dragon books Dragon:+profit / Tiger:−stake / Tie:−stake, so the worst-case lock
// includes the tie (a hedge now correctly reserves −2·stake) while the FE, which
// has no Tie cell, still shows only the Dragon/Tiger profit book. Tie is never
// bet (absent from the feed) so resolveDt6 is unaffected.
// 2026-10-11: the phantom "Tie" runner is GONE. 1 Day Dragon Tiger is played
// with ONE deck (rules image dt6.jpg: "played with one deck (52 Cards)"; same
// rank is decided by the suit order ♠ > ♥ > ♣ > ♦), so two identical cards —
// the only tie — cannot happen and the feed never reports one. With the Tie row
// a Dragon + Tiger hedge locked −2·stake (sum) where the reference locks the
// net (back 100 @1.98 each → −2); the row book on the page already netted. The
// 8-deck 20-20 tables (dt20 / dt202) are not in this registry and keep their
// own rules. Plan: docs/plans/2026-10-11-dt6-dragon-tiger-net-header.md
const DT6_MARKETS = [
    { key: "main", runners: ["Dragon", "Tiger"] },
];

// trap — THE TRAP. ONLY the main Player A / Player B bet books across both
// runners, so the backed side shows the profit and the other side shows the
// worst-case loss (the exchange book) instead of the old single worst-case row
// under the backed player alone. Back A → A:+stake*(odds−1), B:−stake; lay is
// the inverse. The Card High/Low and JQK side markets stay OUT of the registry
// on purpose — like aaa/teen1's side markets they keep the legacy single-row
// path (one worst-case figure under the backed side, nothing under its opposite).
const TRAP_MARKETS = [
    { key: "main", runners: ["Player A", "Player B"] },
];

// race20 — RACE TO 20. ONLY the main market books: which King's suit reaches 20
// first. It has FOUR runners, so the backed King shows the profit and the other
// three each show the worst-case loss (−stake) — the exchange book — instead of
// the old single worst-case row under the backed King alone. Back K → K wins:
// +stake*(odds−1); any other King wins: −stake; lay is the inverse. The Win-with
// N, Total points and Total cards markets settle independently (see
// settlementCasinoWorker.resolveRace20) and stay OUT of the registry on purpose —
// like the aaa/trap/teen1 side markets they keep the legacy single-row path (one
// worst-case figure under the backed selection, nothing under any other).
const RACE20_MARKETS = [
    {
        key: "main",
        runners: ["K of spade", "K of heart", "K of club", "K of diamond"],
    },
];

// queen — QUEEN (21-card lane race). ONLY the main market books: four lanes
// ("Total 0"–"Total 3") race to reach the winning total, exactly ONE lane wins
// (settlementCasinoWorker.resolveQueen matches the backed lane's number against
// the winning lane). Four runners, so the backed lane shows the profit and the
// other three each show the worst-case loss (−stake) — the exchange book —
// instead of the old single worst-case row under the backed lane alone. Back a
// lane → that lane wins: +stake*(odds−1); any other lane wins: −stake; lay is
// the inverse.
const QUEEN_MARKETS = [
    { key: "main", runners: ["Total 0", "Total 1", "Total 2", "Total 3"] },
];

// teen6 — TEENPATTI 2.0. ONLY the main Player A / Player B bet books across both
// runners, so the backed side shows the profit and the other side shows the
// worst-case loss (the exchange book) instead of the old single worst-case row
// under the backed player alone. Back A → A:+stake*(odds−1), B:−stake; lay is
// the inverse (settlementCasinoWorker.resolveTeen6 pays exactly one of A/B). The
// side markets — Player A/B Under 21 / Over 22 and the per-card
// suit/odd-even/value bets — settle independently and stay OUT of the registry
// on purpose, keeping the legacy single-row path (one worst-case figure under the
// backed selection, nothing under any other).
const TEEN6_MARKETS = [
    { key: "main", runners: ["Player A", "Player B"] },
];

// patti2 — 2 CARDS TEENPATTI. The main Player A / Player B bet (back AND lay)
// books as ONE two-runner market so A and B net against each other in the
// header like the reference (back A 112 @1.98 + back B 112 @1.98 → −2.24, was
// −224 summed; user, 2026-10-09). KNOWN GAP, accepted by the user: a main TIE
// (winnat "Tie", ~0.46% of rounds) loses BOTH Player bets in
// settlementCasinoWorker.resolvePatti2, and this book has no Tie runner (unlike
// dt6), so a hedged A+B position locks less than a tie costs. The reference's
// tie rule is unconfirmed. Mini Baccarat / Total / Color Plus settle
// independently and stay on the legacy single-row path.
const PATTI2_MARKETS = [
    { key: "main", runners: ["Player A", "Player B"] },
];

// btable — BOLLYWOOD CASINO. ONLY the main 6-movie market books (back AND lay):
// exactly one movie wins (settlementCasinoWorker win=1..6 → Don / Amar Akbar
// Anthony / Sahib Bibi Aur Ghulam / Dharam Veer / Kis Kis Ko Pyaar Karoon /
// Ghulam), so the backed movie shows the profit and the other five each show the
// worst-case loss (−stake) — the exchange book — instead of the old single row
// under the backed movie alone. Back Don → Don:+stake*(odds−1), others:−stake;
// lay is the inverse. Names are the feed's exact `nat` values so the stored rows
// line up with what BetTableBtable renders. The Odd/Red/Black/Card/Dulha/Barati
// side markets settle independently and stay OUT of the registry, keeping the
// legacy single-row path (one worst-case figure under the backed selection).
const BTABLE_MARKETS = [
    {
        key: "main",
        runners: [
            "Don",
            "Amar Akbar Anthony",
            "Sahib Bibi Aur Ghulam",
            "Dharam Veer",
            "Kis Kis Ko Pyaar Karoon",
            "Ghulam",
        ],
    },
];

// card32 / card32eu — 32 CARDS A / B. ONLY the main 4-player market books (back
// AND lay): exactly one player wins (settlementCasinoWorker win=1..4 → Player 8 /
// 9 / 10 / 11), so the backed player shows the profit and the other three each
// show the worst-case loss (−stake) — the exchange book — instead of the old
// single row under the backed player alone. Back Player 8 → 8:+stake*(odds−1),
// others:−stake; lay is the inverse. Names are the feed's exact `nat`s. card32eu's
// side markets (Player N Odd/Even, Single N, Any Three Card, Totals, …) don't
// match these runner names, so they stay OUT of the book on the legacy single-row
// path (one worst-case figure under the backed selection).
const CARD32_MARKETS = [
    { key: "main", runners: ["Player 8", "Player 9", "Player 10", "Player 11"] },
];

// poker — POKER 1-DAY. ONLY the main Player A / Player B market books (back AND
// lay): exactly one player wins (settlementCasinoWorker matches winnat to Player
// A/B), so the backed player shows the profit and the other shows the worst-case
// loss (−stake) — the exchange book — instead of a single −stake row under the
// backed player (which read as a wrong liability with nothing on the opponent).
// Back Player A → A:+stake*(odds−1), B:−stake; lay is the inverse. The 2-card /
// 7-card Bonus side bets (nats "Player A 2 card Bonus", …) don't match these
// runner names, so they stay OUT of the book on the legacy single-row path.
const POKER_MARKETS = [
    { key: "main", runners: ["Player A", "Player B"] },
];

// teen9 — TEENPATTI TEST. ONLY the main Winner market books: exactly one animal
// wins (settlementCasinoWorker matches winnerAnimal to Tiger/Lion/Dragon), so the
// backed animal shows the profit and the other two show the worst-case loss
// (−stake) — the exchange book — instead of a single −stake row (which read as a
// wrong liability with nothing on the others). Back Tiger Winner → +stake*(odds−1),
// the others −stake. Runner names are the feed's exact `nat`s ("Tiger Winner", …).
// The per-animal hand side bets (Pair/Flush/Straight/Trio/Straight Flush) are
// independent, so they stay OUT of the book on the legacy single-row path.
// NOT in the book map since 2026-10-13 (header = sum of bets, like the reference) —
// kept for the record / a possible revert. docs/plans/2026-10-13-teen9-exposure-sum.md
const TEEN9_MARKETS = [
    { key: "winner", runners: ["Tiger Winner", "Lion Winner", "Dragon Winner"] },
];

// teen32 — INSTANT TEENPATTI 2.0. A single two-way market: Player A vs Player B
// (exactly one wins; settlement matches selection to winnat). Backing A books
// A:+stake*(odds−1) / B:−stake, lay is the inverse — so the backed player shows
// the profit and the other the worst-case loss, instead of the legacy single
// −stake row that put the loss only under the placed player.
const TEEN32_MARKETS = [
    { key: "main", runners: ["Player A", "Player B"] },
];

// teen33 — INSTANT TEENPATTI 3.0. ONLY the main Player A / Player B market books
// (back AND lay): exactly one player wins (settlementCasinoWorker.resolveTeen33
// matches the selection against t1.winnat, which is only ever "Player A" /
// "Player B"), so the backed player shows the profit and the other the worst-case
// loss — the exchange book — instead of the legacy single −stake row that put a
// figure only under the placed player and nothing under its opponent. Back A →
// A:+stake*(odds−1), B:−stake; lay A is the inverse (A:−stake*(odds−1), B:+stake).
// The Player B Under 21 / Over 21 side bets are back-only, settle independently
// and don't match these runner names, so they stay OUT of the book on the legacy
// single-row path (one worst-case figure under the backed selection).
const TEEN33_MARKETS = [
    { key: "main", runners: ["Player A", "Player B"] },
];

// teen42 — JACK TOP OPEN TEENPATTI. ONLY the main Player A / Player B market
// books (back AND lay): exactly one player wins — settlement routes teen42 to
// resolveTeen41, which matches the selection against t1.winnat, and the feed only
// ever returns "Player A" / "Player B" there. So the backed player shows the
// profit and the other the worst-case loss — the exchange book — instead of the
// legacy single row that put one figure under the placed player and nothing under
// its opponent. Back A → A:+stake*(odds−1), B:−stake; lay A is the inverse
// (A:−stake*(odds−1), B:+stake). The Player B Under 21 / Over 21 side bets are
// back-only, settle independently off rdesc, and don't match these runner names,
// so they stay OUT of the book on the legacy single-row path.
const TEEN42_MARKETS = [
    { key: "main", runners: ["Player A", "Player B"] },
];

// teen41 — QUEEN TOP OPEN TEENPATTI. Same shape as teen42 above (they share
// resolveTeen41 and BetTableTeen41): ONLY the main Player A / Player B market
// books (back AND lay), exactly one player wins via t1.winnat, so the backed
// player shows the profit and the other the worst-case loss. Back A →
// A:+stake*(odds−1), B:−stake; lay A is the inverse. The Player B Under 21 /
// Over 21 side bets stay OUT on the legacy single-row path.
const TEEN41_MARKETS = [
    { key: "main", runners: ["Player A", "Player B"] },
];

// lucky15 — LUCKY 15. ONE six-way market: what the next ball produces. Exactly
// one outcome lands — resolveLucky15 parses t1.rdesc/winnat ("4 Run") down to a
// single key and matches it against the selection, with the valid set being
// exactly these six nats — so the backed runner shows the profit and the other
// five each show the worst-case loss (−stake), the exchange book, instead of the
// legacy single row under the backed runner alone. Back "6 Runs" →
// 6 Runs:+stake*(odds−1), every other runner:−stake.
//
// Names are the feed's exact `nat`s: note the runners are plural ("4 Runs")
// while the RESULT comes back singular ("4 Run"). That mismatch is already
// handled inside resolveLucky15 (it extracts the digit), and it never reaches
// here — findCasinoMarket matches the SELECTION, which is the feed nat.
//
// The table is back-only (`l` is 0 on every runner), so the lay branch of
// calculateCasinoBook is unreachable in practice; it stays correct regardless.
const LUCKY15_MARKETS = [
    {
        key: "main",
        runners: ["0 Runs", "1 Runs", "2 Runs", "4 Runs", "6 Runs", "Wicket"],
    },
];

// btable2 — BOLLYWOOD CASINO 2. Same six-movie main market as btable and the
// same settlement shape: resolveBtable2 parses the movie out of rdesc and exactly
// one wins, so the backed movie shows the profit and the other five each show the
// worst-case loss (−stake) — the exchange book — instead of the legacy single row
// under the backed movie alone. Back Don → Don:+stake*(odds−1), others:−stake;
// lay is the inverse.
//
// NOT shared with BTABLE_MARKETS on purpose: the two feeds disagree on casing —
// btable sends "Kis Kis Ko Pyaar Karoon", btable2 sends "Kis Kis ko Pyaar
// Karoon". findCasinoMarket normalizes so either would MATCH, but
// calculateCasinoBook writes the row under the REGISTRY's spelling, which would
// then differ from the nat BetTableBtable2 looks up. It only survives today via
// that component's .toLowerCase() fallback; storing the feed's exact nat removes
// the dependency.
//
// The Odd / Red / Black / Card / Dulha Dulhan / Barati side markets settle
// independently and stay OUT of the registry, keeping the legacy single-row path.
const BTABLE2_MARKETS = [
    {
        key: "main",
        runners: [
            "Don",
            "Amar Akbar Anthony",
            "Sahib Bibi Aur Ghulam",
            "Dharam Veer",
            "Kis Kis ko Pyaar Karoon",
            "Ghulam",
        ],
    },
];

// joker1 — UNLIMITED JOKER ONE DAY. A single two-way market: Player A vs Player
// B. Exactly one wins — resolveJoker1 reads the winner out of t1.rdesc ("Player
// A" / "Player B") and matches it against the selection, rejecting anything else
// — so the backed player shows the profit and the other the worst-case loss (the
// exchange book), instead of the legacy single row that put one figure under the
// backed player and nothing under the opponent. Back A → A:+stake*(odds−1),
// B:−stake; lay is the inverse. The feed offers back only (`l` is 0 on both
// runners), so the lay branch is unreachable in practice but stays correct.
const JOKER1_MARKETS = [
    { key: "main", runners: ["Player A", "Player B"] },
];

// joker20 / teenjoker — TEENPATTI JOKER 20-20. ONE booked market: the Player A
// vs Player B winner (resolveTeenjoker matches the selection against t1.winnat,
// BACK & LAY), so the backed player shows the profit and the other the
// worst-case loss (the exchange book) — back A → A:+stake*(odds−1), B:−stake;
// lay is the inverse — instead of the legacy single row that put one figure
// under the backed player and nothing under the opponent.
//
// The table also carries the Joker side markets (Even/Odd, Red/Black, the four
// suits) — each an INDEPENDENT back-only Yes/No line that settles on its own,
// so none is a two-outcome book. They are deliberately NOT registered here and
// stay on the legacy single-row path (their own profit under their own row),
// exactly as they render today. Only "Player A" / "Player B" match this market.
//
// Unlike joker1/joker120 the feed here quotes LAY on both runners, so the lay
// branch is reachable; a tie (neither player wins) never under-locks because
// the worst case is already −stake for a back and −stake*(odds−1) for a lay.
const JOKER20_MARKETS = [
    { key: "main", runners: ["Player A", "Player B"] },
];

// race2 — RACE TO 2ND. ONE four-way market: which player reaches 2nd place.
// Exactly one wins — resolveRace2 matches the selection against t1.winnat /
// rdesc and accepts only these four nats — so the backed player shows the profit
// and the other three each show the worst-case loss (−stake), the exchange book,
// instead of the legacy single row under the backed player alone. Back A →
// A:+stake*(odds−1), B/C/D:−stake; lay A is the inverse (A:−stake*(odds−1), the
// other three +stake). Both back and lay are quoted on every runner.
const RACE2_MARKETS = [
    { key: "main", runners: ["Player A", "Player B", "Player C", "Player D"] },
];

// teen3 — INSTANT TEENPATTI (the plain one; teen32 is "Instant Teenpatti 2.0"
// and teen33 is "3.0" — three separate tables with near-identical names, all
// booked here). A two-way Player A vs Player B market: exactly one wins, since
// teen3 settles through resolveTeen33, which matches the selection against
// t1.winnat and accepts nothing else. Backing A books A:+stake*(odds−1) and
// B:−stake; lay is the inverse — so the backed player shows the profit and the
// other the worst-case loss, instead of the legacy single row that put one
// figure under the backed player and left the opponent blank.
const TEEN3_MARKETS = [
    { key: "main", runners: ["Player A", "Player B"] },
];

// poison — TEENPATTI POISON ONE DAY. FOUR independent markets on one table, the
// feed separating them by `subtype` (poison / poisono / poisonr / poisonc) and
// the result carrying one outcome for each:
//   rdesc = "Player A#Odd#Red#Diamond"
// Verified over 10 consecutive rounds that every result has exactly these four
// parts and always names exactly one runner per market — no ties, no extra
// values — so each group is a clean book on its own.
//
// Registering them as SEPARATE keys matters: each gets its own game_type, so net
// exposure takes the worst case WITHIN a market and then SUMS across the four.
// That is right here because the markets settle independently — a punter can
// lose the winner, the odd/even, the colour and the suit all in the same round,
// and one combined worst-case figure would badly under-state that liability.
//
// Runner names are the feed's exact `nat`s, including the "Poison " prefix —
// that is what gets stored as `selection` and what BetTablePoison looks up.
// (resolvePoison strips the prefix before matching rdesc; that is its own
// business and does not reach here.)
//
// The table is back-only (`l` is 0 on every runner), so the lay branch of
// calculateCasinoBook is unreachable in practice; it stays correct regardless.
const POISON_MARKETS = [
    { key: "main", runners: ["Player A", "Player B"] },
    { key: "oddeven", runners: ["Poison Even", "Poison Odd"] },
    { key: "colour", runners: ["Poison Red", "Poison Black"] },
    {
        key: "suit",
        runners: ["Poison Spade", "Poison Heart", "Poison Diamond", "Poison Club"],
    },
];

// dolidana — DOLI DANA. A two-dice table with 25 runners in six groups, the feed
// separating them by `subtype` and the result naming one outcome per group:
//   rdesc = "Player B#No#-#8#Even#Greater than 7"
//            winner  anypair pair sum oddeven lucky7
//
// ONLY the main Player A / Player B market is booked (profit under the backed
// player, loss under the other; rdesc part 0 always names exactly one).
//
// Every other group — Sum Total 2…12, Odd / Even, Lucky 7 / Greater than 7 /
// Less than 7, 1-1…6-6 Pair, Any Pair — stays on the legacy single-row path:
// one row per selection holding that bet's liability, ADDED into the header.
// That is the reference behaviour (confirmed by the user 2026-10-07): those cells
// show only the liability, never the profit, and a bet on both Odd and Even
// shows -200 in the header, not the netted -5. Until 2026-10-07 sumtotal,
// oddeven and lucky7 were booked here and netted hedges.
// See docs/plans/2026-10-07-dolidana-liability-only-cells.md.
const DOLIDANA_MARKETS = [
    { key: "main", runners: ["Player A", "Player B"] },
];

// teen / teen62 — TEENPATTI 1-DAY / V VIP TEENPATTI 1-DAY. These two tables
// quote "Player A" / "Player B" TWICE on one feed: Main (subtype "teen", sids
// 1/2, etype "match") and Consecutive (subtype "con", sids 17/18, etype
// "fancy1") — identical nats, independent markets. ONLY Main is a two-way book:
// exactly one player wins (resolveTeen62 matches winnat), so back A books
// A:+stake*(odds−1) / B:−stake and lay is the inverse. Consecutive is an
// independent Yes/No PER PLAYER — both players can be consecutive, or neither —
// so it must NOT be booked; it stays on the legacy single-row path with its
// team_name namespaced "<runner> Consecutive" so a Main bet and a Consecutive
// bet on the same player never merge into one exposure figure.
//
// The registry matches on selection alone and CANNOT tell the two markets
// apart (the payload's mtype is the only discriminator — "match" vs "fancy"),
// so CasinoService.placeBet gates: only mtype "match" reaches this book;
// anything else falls through to the namespaced legacy path.
const TEEN_ONE_DAY_MARKETS = [
    { key: "main", runners: ["Player A", "Player B"] },
];

// goal2 — Football Studio. THREE independent books on one round, all
// back/lay except combo (back only). Settlement (resolveGoal2) decides each on
// rdesc "<Player>#<Method>" ("No Goal#No Goal" when nobody scores):
//   player — exactly one of the 11 players scores, or No Goal → exhaustive.
//   method — exactly one of the 4 methods, or No Goal → exhaustive.
//   combo  — "<Player> and <Method>" wins only if BOTH are right (confirmed
//            with the user 2026-10-07). In a no-goal round EVERY combo loses,
//            so the non-bettable GOAL2_COMBO_NO_GOAL runner books that outcome
//            (−stake of every combo back) and the worst case can never
//            under-lock. It is never a selection and no frontend cell reads it.
// "No Goal" is a runner of BOTH player and method. findCasinoMarket can only
// tell them apart through the bet's mtype (the frontend sends the feed
// subtype: "player" / "method" / "combo"); without it the bet stays on the
// legacy single-row path. See docs/plans/2026-10-07-goal2-no-goal-book-mapping.md.
const GOAL2_PLAYERS = [
    "Cristiano Ronaldo", "Lionel Messi", "Robert Lewandowski", "Karim Benzema",
    "Edinson Cavani", "Luis Suarez", "Neymar", "Sergio Aguero",
    "Olivier Giroud", "Mohamed Salah", "Kylian Mbappe",
];
const GOAL2_METHODS = ["Shot Goal", "Header Goal", "Penalty Goal", "Free Kick Goal"];
const GOAL2_COMBO_NO_GOAL = "No Goal Round";
const GOAL2_MARKETS = [
    { key: "player", runners: [...GOAL2_PLAYERS, "No Goal"] },
    { key: "method", runners: [...GOAL2_METHODS, "No Goal"] },
    {
        key: "combo",
        runners: [
            ...GOAL2_PLAYERS.flatMap((p) =>
                [...GOAL2_METHODS, "No Goal"].map((m) => `${p} and ${m}`)
            ),
            GOAL2_COMBO_NO_GOAL,
        ],
    },
];

// goal — Goal (the one-table version, back only). Two independent books on one
// round, like goal2's player / method: the reference nets the bets of each
// market in the header (worst runner), it does not add every stake (user
// 2026-10-14; plan docs/plans/2026-10-14-goal-exposure-net.md). Runner names
// are the feed's (`sub` subtype "player" / "goal"). "No Goal" is in BOTH, so
// the bet's mtype (frontend sends the subtype) picks the book; without it the
// bet keeps the legacy single-row lock (over-locks, never under-locks).
// Settlement (resolveGoal) is unchanged.
const GOAL_PLAYERS = [
    "Cristiano Ronaldo", "Lionel Messi", "Robert Lewandowski", "Neymar",
    "Harry Kane", "Zlatan Ibrahimovic", "Romelu Lukaku", "Kylian Mbappe",
    "Erling Haaland",
];
const GOAL_MARKETS = [
    { key: "player", runners: [...GOAL_PLAYERS, "No Goal"] },
    { key: "goal", runners: [...GOAL2_METHODS, "No Goal"] },
];

const MARKETS = {
    aaa: AAA_MARKETS,
    aaa2: AAA_MARKETS,
    teen: TEEN_ONE_DAY_MARKETS,
    teen62: TEEN_ONE_DAY_MARKETS,
    teen1: TEEN1_MARKETS,
    dt6: DT6_MARKETS,
    trap: TRAP_MARKETS,
    race20: RACE20_MARKETS,
    queen: QUEEN_MARKETS,
    teen6: TEEN6_MARKETS,
    patti2: PATTI2_MARKETS,
    btable: BTABLE_MARKETS,
    btable2: BTABLE2_MARKETS,
    card32: CARD32_MARKETS,
    card32eu: CARD32_MARKETS,
    poker: POKER_MARKETS,
    // teen9 (Teenpatti Test) is NOT booked: the reference locks every Winner bet in
    // full and the header is the SUM (5 x 100 -> 500), not the netted worst runner.
    // Winner bets take the legacy single-row path like the side bets. The player
    // cells are computed client-side (computeUserBook), so they are unchanged.
    // Plan: docs/plans/2026-10-13-teen9-exposure-sum.md
    teen32: TEEN32_MARKETS,
    teen33: TEEN33_MARKETS,
    dolidana: DOLIDANA_MARKETS,
    poison: POISON_MARKETS,
    // poison20 — TEENPATTI POISON 20-20. The same game as poison (One Day) in the
    // 20-20 format: it shares resolvePoison for settlement and BetTablePoison for
    // its table (Poison20.jsx → <Poison gameType="poison20" />), so the same four
    // independent books apply — main Player A/B, odd/even, colour, suit. Backed
    // runner shows the profit, the others the worst-case loss.
    poison20: POISON_MARKETS,
    race2: RACE2_MARKETS,
    teen3: TEEN3_MARKETS,
    joker1: JOKER1_MARKETS,
    // joker120 — UNLIMITED JOKER 20-20 is deliberately NOT booked (removed
    // 2026-10-07). The reference shows only the LIABILITY under the backed
    // player (Player A back 100 @1.98 → A -100, nothing under B) and adds each
    // bet's liability into the exposure, so its Player A / B bets use the legacy
    // single-row path like its Joker side bets. joker1 keeps its book.
    // See docs/plans/2026-10-07-joker120-liability-only.md.
    // joker20 / teenjoker — TEENPATTI JOKER 20-20 is deliberately NOT booked
    // (removed 2026-10-07, user: "display only the liability not the profit").
    // Player A / B back AND lay use the legacy single-row path like the Joker
    // side bets: one row per selection holding that bet's liability, added into
    // the exposure. teenjoker is the feed's alias for the same table.
    // See docs/plans/2026-10-07-joker20-liability-only.md.
    lucky15: LUCKY15_MARKETS,
    teen41: TEEN41_MARKETS,
    teen42: TEEN42_MARKETS,
    goal2: GOAL2_MARKETS,
    goal: GOAL_MARKETS,
};

const norm = (s) => String(s ?? "").trim().toLowerCase();

/**
 * Row names for a TWO-OUTCOME market that occupies a single table row.
 *
 * Same convention the sports side already uses for its fancy lines
 * (sportsbet/sportbetscontroller.js → `sel + 'back'` / `sel + 'lay'`), so the
 * two sides of the book and the worst case are stored under three rows:
 *
 *   `<sel>`      worst case — the only one that counts toward net exposure
 *   `<sel>back`  P/L if the outcome LANDS   (the back side wins)
 *   `<sel>lay`   P/L if it does NOT land    (the lay side wins)
 *
 * The suffixed rows are display aggregates: helper/netExposureHelper.js drops
 * any team_name matching `%back`/`%lay`, which is exactly why the bare `<sel>`
 * row has to carry the worst case. Note there is no separator before the
 * suffix — matching sports byte for byte.
 */
export const backRunner = (selection) => `${String(selection).trim()}back`;
export const layRunner = (selection) => `${String(selection).trim()}lay`;

// Markets whose runner names carry a per-round value and so cannot be listed
// statically. `test` decides membership. `twoWay` marks the single-row shape
// above, which books through calculateTwoWayBook instead of the runner loop.
// Matched only after the static registry above misses.
// Super Over session line with its run line, and the most runs a 6-ball
// innings can make (six sixes) — the top of its runs ladder.
const SUPEROVER_SESSION_RE = /^\d+\s+over\s+run(?:\s+bhav)?\s+(\S+)\s+(\d+(?:\.\d+)?)$/i;
const SUPEROVER_MAX_INNINGS_RUNS = 36;
// Cricket Match 20-20: at 19.4 overs the second bat is always this many runs
// short; "Run N" (ball 19.5) + the card (ball 19.6, 1-10) reaching it wins, a
// tie included — the rule resolveCmatch20 settles with.
const CMATCH20_RUNS_SHORT = 12;
const CMATCH20_RUN_RE = /^run\s+(\d+)$/i;

const DYNAMIC_MARKETS = {
    cmatch20: [
        {
            // Every "Run N" bet of a round settles on the same card, so they are
            // ONE market, booked as a ladder over the card (rows "CARD runs 1".."10")
            // and the header takes its worst row: back Run 4 100 @4.00 + lay Run 4
            // 100 @4.20 → card >= 8: +300-320 = -20, card <= 7: 0 → lock 20, not 420.
            // Plan: docs/plans/2026-10-10-cmatch20-net-exposure.md.
            test: (sel) => CMATCH20_RUN_RE.test(String(sel).trim()),
            key: "card",
            ladderOf: (sel) => ({
                team: "CARD",
                line: CMATCH20_RUNS_SHORT - Number(String(sel).trim().match(CMATCH20_RUN_RE)[1]),
                minRuns: 1,
                maxRuns: 10,
            }),
        },
    ],
    btable: [
        {
            // Bollywood Casino "Odd" is one YES/NO line (odd card / even card —
            // resolveBtable: Odd wins when the card rank is odd, lay is the
            // inverse) that takes both back and lay. Booked two-way so back + lay
            // net to the worst case: back 100 @1.32 + lay 100 @1.36 → odd:
            // +32−36 = −4, even: −100+100 = 0 → lock 4, not 136 (the legacy row
            // added both). The six movies stay in MARKETS.btable (checked first);
            // Red/Black/Card/Dulha/Barati are back-only and stay legacy.
            // Plan: docs/plans/2026-10-10-btable-odd-two-way.md.
            test: (sel) => /^odd$/i.test(String(sel).trim()),
            key: "odd",
            twoWay: true,
        },
    ],
    dum10: [
        {
            key: "main",
            // "Next Total 240 or More" — the threshold changes every round, and the
            // "it does not happen" outcome is never a selection the punter can click.
            test: (sel) => /^next\s+total\s+\d+\s+or\s+more$/i.test(sel),
            twoWay: true,
        },
    ],
    trio: [
        {
            key: "session",
            // Trio "Session" (Fancy2) is a YES/NO market that takes BOTH back and lay
            // on one row. Booked two-way so a back+lay hedge nets to the worst case
            // (min of the two sides) instead of accumulating each standalone liability.
            test: (sel) => /^session$/i.test(String(sel).trim()),
            twoWay: true,
        },
        {
            // Every other Trio line (3 Card Judgement, Two Red/Black/Odd/Even
            // Only, Pair … Straight Flush) is its own YES/NO line too: back + lay
            // on the SAME line nets to the worst case (back 100 @1.78 + lay 100
            // @1.83 → −5, not −183). `keyOf` gives each line its OWN market so
            // independent lines stay additive in TOTAL_EXPOSURE_SQL (same as
            // notenum). Plan: docs/worklog/2026-10-09.md (Trio back + lay nets).
            test: () => true,
            twoWay: true,
            keyOf: (sel) => sel,
        },
    ],
    superover: [
        {
            // Super Over session lines ("1 over run ENG 13", "1 over run bhav ENG 13"
            // — stored with the run line) ALL settle on the same number: that
            // team's innings total. So every session bet on a team is ONE market,
            // booked as a runs ladder (one row per possible total 0–36, the P/L of
            // all those bets at that total) and the header takes its worst row —
            // like ENG/RSA in the Bookmaker. Yes 100 @2.22 on run 13 + No 100
            // @1.84 on bhav 13 → ≥13: +122−84 = +38, <13: −100+100 = 0 → 0.
            // Plan: docs/worklog/2026-10-10.md item 17.
            test: (sel) => SUPEROVER_SESSION_RE.test(String(sel).trim()),
            keyOf: (sel) => `session ${String(sel).trim().match(SUPEROVER_SESSION_RE)[1].toUpperCase()}`,
            ladderOf: (sel) => {
                const m = String(sel).trim().match(SUPEROVER_SESSION_RE);
                return { team: m[1].toUpperCase(), line: Number(m[2]), maxRuns: SUPEROVER_MAX_INNINGS_RUNS };
            },
        },
        {
            // Super Over Fancy ("1 over run ENG 13", stored with its line) and
            // Fancy1 ("0.4 Over Zero RSA", "Common Wicket ENG"): every line is
            // its own YES/NO market taking back AND lay, so back + lay on the
            // SAME line nets to the worst case instead of the sum (back 100 @2.22
            // + lay 100 @1.84 on line 13 → min(122−84, −100+100) = 0, not −184).
            // `keyOf` = the exact selection: different lines / balls stay
            // separate (additive) markets in TOTAL_EXPOSURE_SQL. Bookmaker team
            // names never match (no OVER/COMMON) and keep their own book.
            // Plan: docs/worklog/2026-10-10.md item 14.
            test: (sel) => /\bover\b|^common\s/i.test(String(sel).trim()),
            twoWay: true,
            keyOf: (sel) => String(sel).trim(),
        },
    ],
    trap: [
        {
            // The Trap "Card N JQK" takes back AND lay: each card's JQK is its own
            // YES/NO line (the card is J/Q/K or it is not), so back + lay on the
            // SAME card nets to the worst case (back 100 @4.20 + lay 100 @4.53 →
            // −33, not −453; user, 2026-10-09). `keyOf` = the exact selection so
            // different cards stay additive. Card N High/Low stay legacy: they are
            // back-only and a 7 ("Tie") loses both, so summing IS the worst case.
            test: (sel) => /^card\s+\d+\s+jqk$/i.test(String(sel).trim()),
            twoWay: true,
            keyOf: (sel) => String(sel).trim(),
        },
    ],
    card32eu: [
        {
            // 32 CARDS B colour rows — Any Three Card Black / Any Three Card Red /
            // Two Black Two Red — take back AND lay (feed etype fancy1, `l` quoted).
            // Booked two-way so back + lay on the SAME row nets to the worst case:
            // back 100 @3.25 + lay 100 @3.45 on Black → black: +225−245 = −20,
            // not black: −100+100 = 0 → lock 20, not 345 (the legacy row added
            // both). `keyOf` = the exact selection so the three rows stay separate
            // (additive) markets in TOTAL_EXPOSURE_SQL. Player 8-11 keep the
            // 4-runner MARKETS.card32eu book (checked first); Odd/Even, Single,
            // Totals are back-only and stay legacy. card32 (A) untouched.
            // Plan: docs/plans/2026-10-11-card32eu-colour-two-way.md
            test: (sel) => /^(any three card (black|red)|two black two red)$/i.test(String(sel).trim()),
            twoWay: true,
            keyOf: (sel) => String(sel).trim(),
        },
    ],
    teensin: [
        {
            // 29 Card Baccarat "Lucky 9" is a YES/NO line taking back AND lay.
            // Booked two-way so back + lay nets to the worst case, not the sum
            // (back 100 @4.7 + lay 100 @5.1 → −40, not −510). The other teensin
            // markets are back-only singles and stay on the legacy single-row path.
            // Plan: docs/worklog/2026-10-09.md.
            key: "Lucky 9",
            test: (sel) => /^lucky\s*9$/i.test(String(sel).trim()),
            twoWay: true,
        },
    ],
    race17: [
        {
            // Race to 17: every line ("Race to 17", "Big Card (7,8,9) - 2", "Zero
            // Card (10,J,Q,K) - 3", "Any Zero") is its own YES/NO line taking back
            // AND lay. Booked two-way so back + lay on the SAME line nets
            // (worst case), not the sum. `keyOf` = the exact selection: "- 2" and
            // "- 3" settle on different counts, so they stay separate (additive)
            // markets in TOTAL_EXPOSURE_SQL. Plan: docs/worklog/2026-10-09.md.
            test: () => true,
            twoWay: true,
            keyOf: (sel) => sel,
        },
    ],
    notenum: [
        {
            // Note Number: every selection ("Odd Card 3", "Card 3 A", "Baccarat 1")
            // is its own YES/NO line that takes back AND lay. Booked two-way so a
            // back+lay hedge on the SAME selection nets to the worst case
            // (100 back @2 + 100 lay @2.02 → −2, not −202).
            // `keyOf` gives each selection its OWN market: TOTAL_EXPOSURE_SQL takes
            // MIN per (match_id, game_type), so a shared key would count only the
            // single worst selection and under-lock independent ones ("Odd Card 3"
            // and "Odd Card 4" settle on different cards and can both lose).
            // Plan: docs/worklog/2026-10-09.md (Note Number back + lay nets).
            test: () => true,
            twoWay: true,
            keyOf: (sel) => sel,
        },
    ],
};
// Super Over 2 (superover2, IND vs ENG) has the same Fancy / Fancy1 markets with
// the same spelling (plan: docs/plans/2026-10-11-superover2-parity-with-superover.md).
// One difference: its Fancy session ladder is per ROW, not per team — the
// reference locks "1 over run IND" and "1 over run bhav IND" separately (a Yes
// on one + a No on the other: 100 + 120 = 220, not the netted 49). Same ladder
// (team innings total 0–36), keyed by the row name; settlement is unchanged.
// Plan: docs/plans/2026-10-13-superover2-fancy-exposure-per-row.md
DYNAMIC_MARKETS.superover2 = [
    {
        ...DYNAMIC_MARKETS.superover[0],
        keyOf: (sel) => `session ${String(sel).trim().match(SUPEROVER_SESSION_RE)[0].replace(/\s+\d+(?:\.\d+)?$/, "")}`,
    },
    ...DYNAMIC_MARKETS.superover.slice(1),
];
// Bollywood Casino 2 (btable2) has the same "Odd" YES/NO line taking back AND lay
// (live 2026-10-12: b 1.32 / l 1.36; resolveBtable2: back wins on an odd card,
// lay the inverse), so it shares the Bollywood Casino two-way entry: back 100
// @1.32 + lay 100 @1.36 → −4, not 136. Approved by the user 2026-10-12.
DYNAMIC_MARKETS.btable2 = DYNAMIC_MARKETS.btable;
// Mini SuperOver (superover3, IND vs AUS): same Fancy / Fancy1 spelling, so the
// same entries, plus its Fancy1 "Tie" runner — a YES/NO line taking back AND
// lay (live 2026-10-12: b 12.72 / l 15.72) that matches neither entry above.
// Booked two-way so back + lay on Tie nets (100 @12.72 + lay 100 @15.72 → −300,
// not 1572). Plan: docs/plans/2026-10-12-mini-superover-parity.md
DYNAMIC_MARKETS.superover3 = [
    ...DYNAMIC_MARKETS.superover,
    {
        key: "Tie",
        test: (sel) => /^tie$/i.test(String(sel).trim()),
        twoWay: true,
    },
];

/**
 * Find the market a selection belongs to.
 *
 * `marketHint` (the bet's mtype) is only consulted when the name is a runner of
 * MORE THAN ONE market of the game (goal2 "No Goal": player AND method). Then
 * the market whose key equals the hint wins; with no usable hint the result is
 * null, so the bet keeps the legacy single-row lock (which can only over-lock).
 * placeBet and the undoBet guard must pass the same hint so they always agree.
 * @returns {{key: string, runners?: string[], twoWay?: boolean}|null} null →
 *          game/selection not book-managed, caller keeps the single-row path.
 *          `twoWay` markets carry no runners — book them with
 *          calculateTwoWayBook, everything else with calculateCasinoBook.
 */
export function findCasinoMarket(gameName, selection, marketHint = null) {
    const game = norm(gameName);
    const sel = String(selection ?? "").trim();
    if (!sel) return null;

    const markets = MARKETS[game];
    if (markets) {
        const hits = markets.filter((m) => m.runners.some((r) => norm(r) === norm(sel)));
        if (hits.length === 1) return hits[0];
        if (hits.length > 1) {
            return hits.find((m) => norm(m.key) === norm(marketHint)) || null;
        }
    }

    const dynamic = DYNAMIC_MARKETS[game];
    if (dynamic) {
        const hit = dynamic.find((m) => m.test(sel));
        if (hit) {
            return {
                key: hit.keyOf ? hit.keyOf(sel) : hit.key,
                twoWay: !!hit.twoWay,
                ...(hit.ladderOf && { ladder: hit.ladderOf(sel) }),
            };
        }
    }

    return null;
}

/**
 * Book delta this bet adds to every runner of its market.
 *
 * @param {object} p
 * @param {{key: string, runners: string[]}} p.market
 * @param {string} p.selection - the backed/laid runner
 * @param {number} p.stake
 * @param {number} p.odds     - decimal odds
 * @param {string} p.type     - 'back' | 'lay'
 * @returns {Array<{team_name: string, delta: number}>}
 */
export function calculateCasinoBook({ market, selection, stake, odds, type }) {
    const s = Number(stake) || 0;
    const o = Number(odds) || 0;
    const isLay = norm(type) === "lay";
    const win = round2(s * (o - 1));
    const sel = norm(selection);

    return market.runners.map((runner) => ({
        team_name: runner,
        delta: norm(runner) === sel
            ? (isLay ? -win : win)
            : (isLay ? s : -s),
    }));
}

/**
 * Book for a two-outcome market that occupies one table row.
 *
 * Returns ABSOLUTE values, not deltas: the `<sel>` row holds the worst case,
 * which is a min() over the two sides and so cannot be accumulated one bet at a
 * time. The caller must SET these rows rather than add to them. Both sides are
 * still derived additively from `oldExposures`, so a mixed back+lay book nets
 * out exactly as settlement will pay it.
 *
 * Mirrors settlement: back wins stake*(odds−1) / loses stake; lay is the inverse.
 *
 * @param {object} p
 * @param {string} p.selection
 * @param {number} p.stake
 * @param {number} p.odds        - decimal odds
 * @param {string} p.type        - 'back' | 'lay'
 * @param {Record<string, number>} p.oldExposures - team_name → amount, this
 *        market's existing rows. Absent keys are treated as 0.
 * @returns {Array<{team_name: string, value: number}>}
 */
export function calculateTwoWayBook({ selection, stake, odds, type, oldExposures = {} }) {
    const s = Number(stake) || 0;
    const o = Number(odds) || 0;
    const isLay = norm(type) === "lay";
    const win = round2(s * (o - 1));

    const backKey = backRunner(selection);
    const layKey = layRunner(selection);
    const prev = (k) => Number(oldExposures[k]) || 0;

    // Outcome lands: a back collects its winnings, a lay pays them out.
    const hit = round2(prev(backKey) + (isLay ? -win : win));
    // Outcome does not land: a back loses its stake, a lay collects it.
    const miss = round2(prev(layKey) + (isLay ? s : -s));

    return [
        { team_name: String(selection).trim(), value: round2(Math.min(hit, miss)) },
        { team_name: backKey, value: hit },
        { team_name: layKey, value: miss },
    ];
}

/**
 * Book delta for a runs-ladder market (Super Over session lines): one row per
 * possible innings total r = 0..maxRuns, named "<TEAM> runs <r>". Yes (back)
 * on line L wins when r >= L — the rule resolveSuperover3 settles with
 * (decideSuperOverSession) — and No (lay) is the inverse.
 *
 * @param {object} p
 * @param {{team: string, line: number, minRuns?: number, maxRuns: number}} p.ladder
 * @returns {Array<{team_name: string, delta: number}>}
 */
export function calculateLadderBook({ ladder, stake, odds, type }) {
    const s = Number(stake) || 0;
    const win = round2(s * ((Number(odds) || 0) - 1));
    const isLay = norm(type) === "lay";
    const rows = [];
    // Super Over totals start at 0; a cmatch20 card starts at 1 (minRuns).
    for (let r = ladder.minRuns ?? 0; r <= ladder.maxRuns; r++) {
        const yes = r >= ladder.line;
        rows.push({
            team_name: `${ladder.team} runs ${r}`,
            delta: isLay ? (yes ? -win : s) : (yes ? win : -s),
        });
    }
    return rows;
}

/** game_type tag that groups a book market's rows for net-exposure math. */
export function casinoMarketGameType(gameName, marketKey) {
    return `${norm(gameName)}:${marketKey}`;
}

// ---------------------------------------------------------------------------
// SuperOver / Five Five Cricket family
//
// These games (cricketv3 + superover1/2/3) share the SuperOver market layout: a
// two-team Bookmaker (match winner) plus a batch of independent YES/NO fancy /
// Tie / Fancy1 session lines. Unlike the static book games above, the Bookmaker
// runner NAMES change every round (India/Australia → AUS/IND …), so they cannot
// be listed in MARKETS — the caller resolves them from the live feed at
// placement (see extractBookmakerRunners) and books through calculateCasinoBook.
// The fancy/Tie/Fancy1 lines are each their own two-outcome market, booked
// two-way (worst case = min of the two sides).
// ---------------------------------------------------------------------------
const SUPEROVER_GAMES = new Set(["cricketv3", "superover", "superover2", "superover3"]);

export function isSuperOverFamily(gameName) {
    return SUPEROVER_GAMES.has(norm(gameName));
}

/**
 * Pull the Bookmaker (match-winner) runner names and the round id out of a
 * cached `casino/all-data` feed. Shape-tolerant: the provider body may nest the
 * markets under `.data` and quote t1 as an object or a one-element array.
 *
 * @returns {{ gmid: string|null, runners: string[] }} runners is [] when the
 *          Bookmaker market isn't present yet — caller must handle that.
 */
export function extractBookmakerRunners(feed) {
    const root = feed?.data && (feed.data.t1 || feed.data.t2) ? feed.data : feed || {};
    const t1 = Array.isArray(root.t1) ? root.t1[0] : root.t1;
    const t2 = Array.isArray(root.t2) ? root.t2 : [];
    const gmid = t1?.gmid ?? t1?.mid ?? null;
    const bm = t2.find((m) => Number(m?.dtype) === 2 || norm(m?.gtype) === "match1");
    const runners = (bm?.section || [])
        .map((s) => String(s?.nat ?? "").trim())
        .filter(Boolean);
    return { gmid: gmid != null ? String(gmid) : null, runners };
}

/** Normalized fancy market key so each YES/NO line groups on its own in net
 * exposure (worst case per line, summed) rather than collapsing together. */
export function superOverFancyKey(selection) {
    return `fancy_${norm(selection)}`;
}

export default {
    findCasinoMarket,
    calculateCasinoBook,
    calculateTwoWayBook,
    calculateLadderBook,
    casinoMarketGameType,
    backRunner,
    layRunner,
    isSuperOverFamily,
    extractBookmakerRunners,
    superOverFancyKey,
};
