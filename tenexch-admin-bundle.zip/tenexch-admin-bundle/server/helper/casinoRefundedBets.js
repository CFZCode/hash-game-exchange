// Casino bets the settlement REFUNDED (a tie: 20-20 Poker, Poker 6 Players,
// 32 Cards B Totals …). They end `void` like a user Undo/Clear, but only a
// settlement refund writes a BET_REFUND ledger row — that row tells them apart.
// Used with casinoBetOutcome(b, { refunded }) by the admin Result modal and
// the Account Statement "Details".
// Plan: docs/plans/2026-10-12-poker-tie-full-refund-hidden.md
import { Op } from 'sequelize';
import CreditsLedger from '../model/user/CreditsLedger.js';
import BetVoidAudit from '../model/admin/BetVoidAudit.js';

export const loadRefundedBetIds = async (rows) => {
  const ids = rows
    .filter((b) => String(b.result_status || '').toLowerCase() === 'void')
    .map((b) => b.id);
  if (!ids.length) return new Set();
  const led = await CreditsLedger.findAll({
    where: { bet_id: { [Op.in]: ids }, category: 'CASINO', reason: 'BET_REFUND' },
    attributes: ['bet_id'],
    raw: true,
  });
  return new Set(led.map((l) => String(l.bet_id)));
};

// Roulette tables: a bet the PLAYER took back (Undo / Clear) is not shown at
// all in the result modal or the statement "Details" — reference (user
// 2026-10-14). Such a bet ends `void` with no BET_REFUND ledger row (not a
// settlement refund) and no bet_void_audit row (not an admin void, which keeps
// showing under "Deleted"). Returns those bet ids (strings).
export const UNDO_HIDDEN_GAMES = new Set(['ourroullete', 'roulette11', 'roulette12', 'roulette13']);

// Exception (user 2026-10-15, all four roulettes): on the reference the undone
// bets stay in admin My Bets for their round and sit under "Deleted" in the
// admin AND player Result modal. Only the statement "Details" still hides them.
// Plan: docs/plans/2026-10-15-admin-mybets-keep-undone-roulette.md
export const UNDO_DELETED_GAMES = new Set(['ourroullete', 'roulette11', 'roulette12', 'roulette13']);
// How far back admin My Bets looks for undone bets. The admin hook then keeps
// only the round on screen, so this only needs to cover one round.
export const ADMIN_UNDONE_LOOKBACK_MINUTES = 10;

export const loadUndoneBetIds = async (rows, refunded = null) => {
  const voids = rows.filter((b) =>
    UNDO_HIDDEN_GAMES.has(String(b.game_name || '').toLowerCase())
    && String(b.result_status || '').toLowerCase() === 'void');
  if (!voids.length) return new Set();
  const refundedSet = refunded || await loadRefundedBetIds(voids);
  const candidates = voids.filter((b) => !refundedSet.has(String(b.id)));
  if (!candidates.length) return new Set();
  const audited = await BetVoidAudit.findAll({
    where: { bet_kind: 'CASINO', bet_id: { [Op.in]: candidates.map((b) => b.id) } },
    attributes: ['bet_id'],
    raw: true,
  });
  const adminVoided = new Set(audited.map((a) => String(a.bet_id)));
  return new Set(candidates.map((b) => String(b.id)).filter((id) => !adminVoided.has(id)));
};

export default loadRefundedBetIds;
