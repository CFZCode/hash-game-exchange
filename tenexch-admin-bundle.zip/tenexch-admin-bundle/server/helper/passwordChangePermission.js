import Staff from '../model/admin/Staff.js';
import { MESSAGES } from '../constants/messages.js';

/**
 * Can this account change its OWN password right now?
 *
 * One helper, two callers — services/user/userAuthService.js (players) and
 * controller/admin/StaffController.js (operators) — so the player rule and the
 * operator rule can never drift apart.
 *
 * The rule, in order:
 *
 *  1. The mandatory first-login change is ALWAYS allowed. A player has not done
 *     it while `passwordChanged === false`; an operator while
 *     `first_login === false`. Blocking it would strand a brand-new account on
 *     the change-password screen with no way forward, so the permission flag
 *     only ever gates changes AFTER that first one.
 *  2. The account's own `passwordChangeAllowed` flag, set by whoever created it
 *     (the "Password Change" tick on the admin create-account form: ticked
 *     stores false). false = blocked.
 *  3. The DIRECT parent's flag — one hop, no full walk up the tree. An operator
 *     who is blocked also blocks the accounts they created directly. A
 *     grandparent's block does not cascade.
 *
 * Owners are never blocked and carry no column: they are the top of the tree,
 * so there is nobody above them to set the flag.
 *
 * Read-only. Two queries worst case, no transaction.
 *
 * @param {object}  params
 * @param {'USER'|'STAFF'} params.type  Which table `account` came from.
 * @param {object}  params.account      The User or Staff instance/row.
 * @returns {Promise<{allowed: boolean, reason?: string}>}
 */
export const canChangePassword = async ({ type, account }) => {
  if (!account) return { allowed: true };

  const blocked = { allowed: false, reason: MESSAGES.AUTH.PASSWORD_CHANGE_NOT_ALLOWED };

  // 1️⃣ First-login change — always allowed, whatever the flags say.
  const hasChangedOnce = type === 'STAFF'
    ? account.first_login === true
    : account.passwordChanged === true;
  if (!hasChangedOnce) return { allowed: true };

  // 2️⃣ The account's own permission.
  if (account.passwordChangeAllowed === false) return blocked;

  // 3️⃣ The direct parent, one hop. A user hangs off parent_staff_id, a staff
  //    off parent_id; either may instead hang off an owner, who has no flag.
  const parentStaffId = type === 'STAFF' ? account.parent_id : account.parent_staff_id;
  if (!parentStaffId) return { allowed: true };

  const parent = await Staff.findByPk(parentStaffId, {
    attributes: ['staff_id', 'passwordChangeAllowed'],
    raw: true,
  });

  // Parent row gone (deleted/orphaned) — fail open. Never lock an account out
  // over a broken hierarchy link.
  if (!parent) return { allowed: true };

  if (parent.passwordChangeAllowed === false) return blocked;

  return { allowed: true };
};

export default canChangePassword;
