// Tiny per-key promise cache with a TTL, shared by the admin profile builders
// that feed the 2-second socket push (owner: controller/admin/userController.js,
// staff: services/admin/staffAuthService.js). Moved here verbatim from
// userController so both use one copy.

// The maps hold one entry per *logged-in account*, so they stay tiny; this only
// exists so a long-lived process can't accumulate entries for accounts that
// logged out days ago.
export const pruneCache = (cache, ttlMs) => {
  if (cache.size < 500) return;
  const cutoff = Date.now() - ttlMs;
  for (const [key, entry] of cache) if (entry.at < cutoff) cache.delete(key);
};

// A rejected promise must never be left in the cache, or every later caller
// replays the same failure until the TTL expires.
export const memoise = (cache, key, ttlMs, produce) => {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < ttlMs) return hit.promise;
  const entry = { at: Date.now(), promise: null };
  entry.promise = produce().catch((err) => {
    if (cache.get(key) === entry) cache.delete(key);
    throw err;
  });
  cache.set(key, entry);
  pruneCache(cache, ttlMs);
  return entry.promise;
};
