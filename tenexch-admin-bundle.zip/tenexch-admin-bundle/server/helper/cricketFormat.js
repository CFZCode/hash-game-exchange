// Cricket match-format detection from competition (cname) + event (ename)
// names. Test formats are the only cricket a "Oneday & T20 only" Max Odds cell
// exempts; everything else (ODI, T20, franchise T20 leagues, The Hundred) counts
// as limited-overs, which is the SAFE default (the cap applies when unsure).
// Frontend mirror: isCricketLimitedOvers() in
// frontend/src/components/betting/placeBet/placeBetRules.js.
export const TEST_FORMAT_RE = /\btest\b|ashes|first[\s-]?class|county\s+champ|sheffield\s+shield|ranji|plunket/i;

export const isCricketTestFormat = (text) => TEST_FORMAT_RE.test(String(text || ''));
