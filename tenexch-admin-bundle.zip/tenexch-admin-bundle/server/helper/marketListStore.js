// Every market a match has shown, kept in redis for the admin "More Market"
// list. The provider's gamedataPrivate only carries the markets open RIGHT NOW,
// while the reference list also keeps the ones that already closed
// (1st Period Winner, HT/FT …), so each successful read is folded in here.
//
//   marketlist:{gmid}       hash  mid → JSON { mid, mname, sno }
//   marketlist:{gmid}:miss  count of provider 404s for the match
//
// - Names are rewritten on every change (the provider renames markets).
// - 15 h absolute cap: the expiry is set once when the hash is created and
//   never pushed back, so no list outlives 15 h.
// - 10 provider 404s delete the list. At most one 404 counts per 30 s per
//   process — the match is read several times a second, and the provider's
//   short false 404s on live matches (see matchWatchService) would otherwise
//   wipe a live list in ~5 s. Any successful read resets the count.

import redis from '../config/redisClient.js';

const TTL_SEC = 15 * 60 * 60;
const MISS_LIMIT = 10;
const MISS_WINDOW_MS = 30 * 1000;
// unchanged lists are re-written at most this often (so a list that expired
// or was deleted elsewhere comes back, and the 404 count gets reset)
const REWRITE_MS = 60 * 1000;

const listKey = (gmid) => `marketlist:${gmid}`;
const missKey = (gmid) => `marketlist:${gmid}:miss`;

// gmid → { sig, at } of the last write from this process
const lastWrite = new Map();
// gmid → time of the last 404 counted by this process
const lastMissAt = new Map();

export async function recordMarkets(gmid, markets) {
  if (!gmid || !Array.isArray(markets)) return;
  const rows = markets
    .filter((m) => m && m.mid != null && m.mname)
    .map((m) => ({ mid: String(m.mid), mname: String(m.mname), sno: m.sno ?? null }));
  if (!rows.length) return;

  const sig = JSON.stringify(rows);
  const prev = lastWrite.get(String(gmid));
  if (prev && prev.sig === sig && Date.now() - prev.at < REWRITE_MS) return;
  lastWrite.set(String(gmid), { sig, at: Date.now() });
  lastMissAt.delete(String(gmid));

  const key = listKey(gmid);
  const fields = rows.flatMap((r) => [r.mid, JSON.stringify(r)]);
  const [, [, ttl]] = await redis.multi()
    .hset(key, ...fields)
    .ttl(key)
    .del(missKey(gmid))
    .exec();
  // redis 6 has no EXPIRE NX: only a hash with no expiry yet (just created) gets one
  if (ttl === -1) await redis.expire(key, TTL_SEC);
}

export async function recordMiss(gmid) {
  if (!gmid) return;
  const now = Date.now();
  if (now - (lastMissAt.get(String(gmid)) || 0) < MISS_WINDOW_MS) return;
  lastMissAt.set(String(gmid), now);

  const [[, misses]] = await redis.multi()
    .incr(missKey(gmid))
    .expire(missKey(gmid), TTL_SEC)
    .exec();
  if (misses >= MISS_LIMIT) {
    await redis.del(listKey(gmid), missKey(gmid));
    lastWrite.delete(String(gmid));
  }
}

/** Stored markets of a match, [{ mid, mname, sno }] in no particular order. */
export async function getStoredMarkets(gmid) {
  const hash = await redis.hgetall(listKey(gmid));
  return Object.values(hash || {}).map((v) => {
    try { return JSON.parse(v); } catch { return null; }
  }).filter(Boolean);
}
