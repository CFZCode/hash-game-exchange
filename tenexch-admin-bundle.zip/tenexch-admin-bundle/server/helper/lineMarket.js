// Line markets (feed gtype `fancy2` / dtype 14 — "1st Innings 6 Overs Line",
// "West Indies 1st Innings 85 Over Line", …) quote RUN LINES in `odds` and are
// priced at EVENS: the winner takes +stake, the loser -stake, on BOTH sides.
// `yes` wins when the runs reach the line, `no` wins when they fall short.
//
// Nothing on the bet row carries a rate for them: `size` is persisted 0, and a
// no-side `liability` could hold feed VOLUME rather than a real risk (8896.20
// against a 100 stake on bet 1291). So every consumer must price these off the
// STAKE alone — which is what this helper exists to guarantee.

// Matched by SUFFIX, not by the word "Over": the feed also ships whole-innings
// lines ("Sri Lanka 2nd Innings Runs Line") that carry no over count at all,
// and those were rejected outright with "bet is closed for this market" — the
// same failure the 15/25/35/45 over counts hit before, one step further out.
// Every market_type ending in "Line" in this DB carries gtype fancy2, so the
// suffix is a safe identity for the whole family.
export const isLineMarket = (marketType) =>
  /\bline$/i.test(String(marketType || '').trim());

const isYesSide = (betType) => ['yes', 'back'].includes(String(betType || '').toLowerCase());

// Did this bet win, given the settled run total?
export const lineBetWon = ({ runs, line, betType }) =>
  isYesSide(betType) ? Number(runs) >= Number(line) : Number(runs) < Number(line);

// Signed P&L of ONE line bet at a given run total. Evens, so it is only ever
// +stake or -stake — the ladder is a step, never a ramp.
export const linePnl = ({ runs, line, stake, betType }) =>
  (lineBetWon({ runs, line, betType }) ? 1 : -1) * Number(stake);

// ── Exposure row identity ────────────────────────────────────────────────────
// Every line market quotes the SAME runner name ("Total Runs" on the 6-over,
// 10-over and 20-over rows alike), so a runner-keyed exposure row cannot say
// WHICH line market it belongs to. Line exposure is therefore keyed by the
// MARKET: game_type is the literal 'fancy2' (the feed's gtype) and team_name is
// the market's mname ("1st Innings 6 Overs Line").
//
// Placement, the settlement release and the settlement destroy MUST all agree
// on this pair — settlement finds the row to refund with exactly these two
// columns, so a mismatch strands the punter's stake permanently.
export const LINE_EXPOSURE_GAME_TYPE = 'fancy2';

// The (game_type, team_name) an exposure row uses for a given bet.
//   line market -> ('fancy2', "1st Innings 6 Overs Line")
//   everything else -> (market_type, selection_name)  — unchanged
//
// `badlo` is still ACCEPTED (every caller passes it) but deliberately IGNORED:
// a badlo leg shares the runner's own session pot. It used to get its own
// ('badlo', runner) bucket because the Normal worst-case walk recomputed the
// runner row from scratch and would clobber whatever badlo wrote there. That
// walk now prices the SPIKE itself (see the `isBadlo` contribution in
// sportbetscontroller.js), so there is nothing left to clobber — and keeping
// the two pots apart DOUBLE-BLOCKED a mixed book: a -200 step worst case plus
// a -200 sum-of-stakes spike bucket showed -400 against a ladder whose true
// worst run was -300. One runner, one pot, one worst case.
export const exposureIdentity = ({ marketType, selectionName, badlo = false }) =>
  isLineMarket(marketType)
    ? { game_type: LINE_EXPOSURE_GAME_TYPE, team_name: String(marketType) }
    : { game_type: marketType, team_name: selectionName };
