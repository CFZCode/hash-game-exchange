import axios from "axios";
import http from "http";
import https from "https";
import dotenv from "dotenv";
dotenv.config();

// One place for "how do I get a casino table's live feed", shared by the
// request path (CasinoService.fetchAllData) and the warmer
// (casinobet/cron/casinoAllDataCron.js). Both MUST produce the identical shape
// — the cron writes what the request path would have returned — so the vendor
// call lives here and not in either caller.
//
// CASINO_API_BASE_URL is the live vendor and the ONLY one called here. It is
// also the only one every other casino endpoint in CasinoService (esid,
// lastresultsnew, detail_casino_results, getDetailsData) has ever used, so this
// file no longer inverts the rest of the service. DIAMOND_BASE_URL (:3009) used
// to be tried first and has been refusing connections for months — every table
// paid a doomed connect, and a breaker re-logged "primary unusable" once a
// minute forever. That path, its breaker and its cooldown are gone.
const BASE_URL = process.env.CASINO_API_BASE_URL;
const API_KEY = process.env.CASINO_API_KEY;

// The warmer re-hits this host ~100 times every pass, so a slow table must not
// hold a pool worker for long: the cron parks a table after a few straight
// failures anyway, and a stale board is worse than a missing round.
const FEED_TIMEOUT = Number(process.env.CASINO_FEED_TIMEOUT_MS || 3000);

// The cron re-hits this host ~100 times a second; without keepAlive every one
// of those would pay a fresh TCP (and TLS, if the vendor ever moves to https)
// handshake.
const httpAgent = new http.Agent({ keepAlive: true, maxSockets: 256 });
const httpsAgent = new https.Agent({ keepAlive: true, maxSockets: 256 });

// Redis key holding one table's latest feed. The cron writes it, fetchAllData
// reads it, and the ":<type>" suffix keeps every table addressable on its own.
export const casinoAllDataKey = (type) => `casinoall:${type}`;

// A feed that came back as null / [] / {} is a failed round of the vendor API,
// not a real snapshot — the warmer must not overwrite a good key with it.
export const isEmptyFeed = (data) => {
  if (data === null || data === undefined) return true;
  if (Array.isArray(data)) return data.length === 0;
  if (typeof data === "object") return Object.keys(data).length === 0;
  return false;
};

// The vendor answers { data: { data: {...}, msg, status, success }, gtype,
// lastUpdatedAt } — one level of wrapping to strip. What is returned here is
// exactly what lands in redis and what the client's res.data.data unwraps.
export const fetchCasinoTypeFeed = async (type) => {
  const response = await axios.get(`${BASE_URL}/casino/data`, {
    headers: { Accept: "*/*" },
    params: { gtype: type, key: API_KEY },
    timeout: FEED_TIMEOUT,
    httpAgent,
    httpsAgent,
  });
  return response.data?.data;
};
