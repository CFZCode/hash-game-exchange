/**
 * Format a match_start_time for display as a naive "YYYY-MM-DD HH:mm:ss" string.
 *
 * The feed sends stime as an IST wall clock with no zone marker and the bet-save
 * path stores it straight into a timestamptz, so the value is interpreted in this
 * process's local timezone on the way in. Read it back the same way, otherwise the
 * digits drift. Handing the UI a Date would serialise to ISO-Z and shift the time
 * again in the viewer's browser; a naive string parses as local wall clock
 * everywhere, so every operator sees the same digits as the reference page.
 */
export const toNaiveLocalTime = (value) => {
  if (!value) return null;
  const dt = new Date(value);
  if (Number.isNaN(dt.getTime())) return null;
  const p = (n) => String(n).padStart(2, '0');
  return `${dt.getFullYear()}-${p(dt.getMonth() + 1)}-${p(dt.getDate())} `
    + `${p(dt.getHours())}:${p(dt.getMinutes())}:${p(dt.getSeconds())}`;
};
