// The order the reference admin shows leagues in, as a pure function of the
// tree itself — no Redis, no second feed, no hardcoded names.
//
// RULE: inside a sport, leagues are ordered by the SMALLEST gmid among their
// matches, ascending. Found and verified on 2026-10-01 against the reference
// admin's live sidebar: ten rounds a minute apart, 90/90 sport-rounds, while
// the feed turned over underneath (plan docs/plans/2026-10-01-admin-events-order.md).
// Earlier attempts (start time, cid, feed order, name, match count) all failed;
// gmid had only been tried as a match key, never as a league's minimum.
//
// Two details the measurement forced:
//   • The feed can carry the SAME league name several times as separate nodes
//     (CONCACAF Nations League appeared three times, three cids, one spelled
//     with a non-breaking space). The reference keeps every node and places
//     each by its own minimum — so this sorts the nodes it is given and never
//     merges or de-duplicates by name.
//   • A league with no numeric gmid at all sorts last; ties (impossible for
//     real data — a gmid belongs to one match) keep the feed's relative order,
//     so the sort is stable by construction.
//
// Matches inside a league are not touched here: the tree already lists them in
// the reference's order (alphabetical), verified 569/569 league-rounds.

/** Smallest numeric gmid among a league's matches, or Infinity when none. */
export const minGmid = (league) => {
  let min = Number.POSITIVE_INFINITY;
  for (const match of league?.children || []) {
    const raw = match?.gmid;
    // Number(null) is 0 — an absent gmid must not read as "match 0".
    if (raw == null || raw === '') continue;
    const g = Number(raw);
    if (Number.isFinite(g) && g < min) min = g;
  }
  return min;
};

/** A sport's league nodes, reordered by minGmid ascending. Input is not mutated. */
export const sortLeaguesByMinGmid = (children) => {
  if (!Array.isArray(children) || children.length < 2) return children;
  return children
    .map((league, index) => ({ league, index, key: minGmid(league) }))
    .sort((a, b) => (a.key - b.key) || (a.index - b.index))
    .map((row) => row.league);
};
