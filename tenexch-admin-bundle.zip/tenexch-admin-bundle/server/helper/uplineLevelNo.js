// "Game is locked. Please contact Upper Level{N}" ka N — locker ke role se:
// Agent (L6) = 1, Master = 2, … Company = 6, Owner (L0) = 7.
// Shared by General Lock (SportsLockController) and Bet Lock (checkUserBetLock).
export const OWNER_UPLINE_NO = 7;

export const uplineNo = (level) => {
  const l = parseInt(String(level || '').replace(/\D/g, ''), 10);
  return Number.isNaN(l) ? OWNER_UPLINE_NO : 1 + (6 - l);
};
