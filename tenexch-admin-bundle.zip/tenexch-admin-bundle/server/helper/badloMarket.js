// Badlo is an EXACT-RUN market, not a line. A bet on 90 pays only when the
// session settles on exactly 90 — 89 and 91 pay nothing at all. The ladder is
// therefore a SPIKE, which is why neither of the other session helpers can
// price it: lineMarket.js draws a step (yes wins at every run >= the line) and
// meterMarket.js draws a ramp.
//
// A badlo click books TWO legs at once — a "swap": +stake at the run the punter
// picked and -stake at the run they gave up. Each leg is one ordinary SportsBet
// row (market_type 'badlo', `odds` = the exact run, bet_type yes/no); the
// pairing itself is decided on the frontend and is never re-derived here.
//
// Every badlo money spot goes through this file — the exposure blocked at
// placement, the per-bet liability, the settlement payout and the Run Amount
// ladder — so the spike can never drift between them.
// Badlo is a property of the BET, not of the market: these rows live inside an
// ordinary session market ("Normal") and keep its market_type, so the flag is a
// column on SportsBet (`badlo`) and a field on the placement payload.
// The FIRST implementation overloaded market_type with the literal 'badlo' —
// that gave the rows their own market bucket, printed "badlo" as the market
// name in the bet list, and split the runner's Normal book. Do not go back.
export const isBadloBet = (bet) => bet?.badlo === true || String(bet?.badlo) === 'true';

// The exposure bucket badlo rows are filed under. Deliberately NOT the bet's
// market_type: the Normal exposure walk recomputes `runner` from its
// `runnerlay`/`runnerback` step totals and would clobber anything badlo wrote
// there. Same trick line markets use (LINE_EXPOSURE_GAME_TYPE = 'fancy2').
// Placement, cancel and the settlement release must all agree on this.
export const BADLO_EXPOSURE_GAME_TYPE = 'badlo';

const isYesSide = (betType) => ['yes', 'back'].includes(String(betType || '').toLowerCase());

// Signed P&L of ONE badlo leg if the market settles on `runs`.
//   yes @ 90 -> +stake on exactly 90, 0 everywhere else
//   no  @ 95 -> -stake on exactly 95, 0 everywhere else
export function badloPnl({ runs, line, stake, betType }) {
  if (Number(runs) !== Number(line)) return 0;
  const signed = (isYesSide(betType) ? 1 : -1) * Number(stake);
  return signed === 0 ? 0 : signed;
}

// Net P&L at every run any of these legs touches.
//   legs: [{ line, stake, betType }]  ->  Map<run, net>
// Two legs on the SAME run stack; two on different runs never do, because a
// session settles on exactly one number.
export function badloLadder(legs) {
  const book = new Map();
  for (const leg of legs) {
    const run = Number(leg.line);
    if (!Number.isFinite(run)) continue;
    const pnl = badloPnl({ runs: run, line: run, stake: leg.stake, betType: leg.betType });
    book.set(run, (book.get(run) || 0) + pnl);
  }
  return book;
}

// Money to block for ONE leg — MONEY STAKED, not worst-case P&L. A `no` leg
// blocks its stake, a `yes` leg blocks nothing (it can only ever win).
//
// Operator rule, confirmed 2026-08-27: badlo legs do NOT net off against each
// other. Two swaps losing on two DIFFERENT runs block 100 each = 200, even
// though the session can only land on one of them so the true worst case is
// 100. This mirrors the line-market rule already documented in
// sportbetscontroller.js ("exposure on a line market is money staked, not
// worst-case P&L"). An earlier build blocked the worst run (a MAX over the
// ladder) and showed 100 for two swaps — rejected. Do not "fix" it back.
export function badloLiability({ stake, betType }) {
  return isYesSide(betType) ? 0 : Number(stake);
}
