import axios from "axios";
import http from "http";
import https from "https";
import dotenv from "dotenv";
dotenv.config();

import sequelize from "../config/db.js";
import { QueryTypes } from "sequelize";
import CasinoResultArchive from "../model/admin/CasinoResultArchive.js";

// "Ek casino round ka result kahan se aata hai aur DB me kaise jaata hai" —
// ek hi jagah, kyunki iske do caller hain jinko bilkul same shape chahiye:
//   • casinobet/cron/casinoResultsArchiveCron.js — har table ka har round likhta hai
//   • services/CasinoService.fetchCasinoResultReport — request par live 10 rounds
//     likhta hai aur phir poora din DB se padhta hai
// Dono same helper use karte hain isliye archiver band ho to bhi report ka
// data sahi shape me aata rahega.

const BASE_URL = process.env.CASINO_API_BASE_URL;
const API_KEY = process.env.CASINO_API_KEY;

// Archiver ek pass me ~100 tables hit karta hai — har call par naya TCP/TLS
// handshake bekaar hai (casinoFeed.js wali hi wajah).
const httpAgent = new http.Agent({ keepAlive: true, maxSockets: 64 });
const httpsAgent = new https.Agent({ keepAlive: true, maxSockets: 64 });

const RESULTS_TIMEOUT = Number(process.env.CASINO_RESULTS_TIMEOUT_MS || 8000);

// Report ek din ke saare rounds ek saath bhejti hai (frontend client-side
// paginate karta hai). Sabse tez table ~1700 rounds/din deta hai, to 5000 ek
// safety cap hai — kabhi hit nahi hona chahiye.
export const RESULTS_DAY_CAP = Number(process.env.CASINO_RESULTS_DAY_CAP || 5000);
// Bina date ke (purane callers / direct API hits) latest N.
export const RESULTS_DEFAULT_LIMIT = Number(process.env.CASINO_RESULTS_DEFAULT_LIMIT || 500);
// Table me sirf itne din ka data rehta hai — worker ka purge aur neeche ka
// write-side guard, dono yahi value padhte hain.
export const RETENTION_DAYS = Number(process.env.CASINO_RESULTS_RETENTION_DAYS || 115);

// mid = "<tableid><YYMMDDHHMMSS>", aur wo YYMMDDHHMMSS vendor ka IST wall clock
// hai (verify: mid ...260920202235 tab aaya jab IST 20:22 tha). Prefix ki
// lambai table par badalti hai (102 / 107 / 123), isliye piche se 12 digit lo.
// Kuch bhi shaq ho to nulls — row phir bhi store hogi, bas date filter me nahi
// aayegi, aur purge created_at fallback se uthayega.
export const parseMid = (mid) => {
  const s = String(mid || "").trim();
  if (!/^\d{12,}$/.test(s)) return { round_date: null, round_time: null };
  const t = s.slice(-12);
  const yy = Number(t.slice(0, 2));
  const mm = Number(t.slice(2, 4));
  const dd = Number(t.slice(4, 6));
  const hh = Number(t.slice(6, 8));
  const mi = Number(t.slice(8, 10));
  const ss = Number(t.slice(10, 12));
  if (mm < 1 || mm > 12 || dd < 1 || dd > 31 || hh > 23 || mi > 59 || ss > 59) {
    return { round_date: null, round_time: null };
  }
  const pad = (n) => String(n).padStart(2, "0");
  return {
    round_date: `20${pad(yy)}-${pad(mm)}-${pad(dd)}`,
    round_time: `${pad(hh)}:${pad(mi)}:${pad(ss)}`,
  };
};

// Abhi ka IST wall clock, process TZ se bilkul independent (ye box CEST par
// hai aur sequelize session UTC par — dono me se kisi par bharosa nahi karna).
const istNow = () => {
  const d = new Date(Date.now() + 5.5 * 60 * 60 * 1000);
  const iso = d.toISOString();
  return { round_date: iso.slice(0, 10), round_time: iso.slice(11, 19) };
};

// Har table ka mid timestamp nahi hota: ballbyball, dolidana, superover*,
// cricketv3 aur worli3 random/sequential mid dete hain. Unke liye "jab pehli
// baar dikha" hi round ka waqt hai — archiver har 20s me poll karta hai, to
// error 20s se kam hai, jo ek din ke bucket ke liye kaafi accurate hai. Bina
// iske in tables ka round_date NULL rehta aur report ke date filter me ye
// kabhi aate hi nahi.
export const resolveRoundStamp = (mid) => {
  const parsed = parseMid(mid);
  return parsed.round_date ? parsed : istNow();
};

// Vendor ke last-results. Sirf AAKHRI 10 rounds aate hain — isi limit ki wajah
// se ye poora archive exist karta hai.
export const fetchLastResultsFromVendor = async (gtype) => {
  const response = await axios.get(`${BASE_URL}/casino/lastresultsnew`, {
    headers: { Accept: "*/*" },
    // Vendors casing par alag hain: 138.68.178.21:8000 ko lowercase `gtype`
    // chahiye, avrkhub demo host ko `gType` — dono bhejna dono ko chalta hai.
    params: { gtype, gType: gtype, key: API_KEY },
    timeout: RESULTS_TIMEOUT,
    httpAgent,
    httpsAgent,
  });
  const payload = response.data?.data;
  const container = payload && (payload.res || payload.res1) ? payload : payload?.data;
  const res = Array.isArray(container?.res) ? container.res : [];
  return { res, res1: container?.res1 || null };
};

// Ek round ka winner label. last-results sirf numeric `win` deta hai; naam
// detail_casino_results ke `winnat` me hota hai.
// Ek round ka vendor detail (t1) — ya null.
export const fetchRoundDetailFromVendor = async (gtype, mid) => {
  const response = await axios.get(`${BASE_URL}/detail_casino_results`, {
    headers: { Accept: "*/*" },
    params: { gtype, mid, key: API_KEY },
    timeout: RESULTS_TIMEOUT,
    httpAgent,
    httpsAgent,
  });
  const payload = response.data?.data;
  const dd = payload && payload.t1 !== undefined ? payload : payload?.data;
  const t1raw = dd?.t1;
  return (Array.isArray(t1raw) ? t1raw[0] : t1raw) || null;
};

export const fetchWinNameFromVendor = async (gtype, mid) => {
  const t1 = await fetchRoundDetailFromVendor(gtype, mid);
  let winName = t1?.winnat || null;
  // ab3/ab4/joker1/joker120 me winnat khali ya generic "Result" hota hai —
  // asli naam rdesc ke pehle segment me.
  if (!winName || winName === "Result") {
    const first = String(t1?.rdesc || "").split("#")[0].trim();
    winName = first || winName;
  }
  return winName || null;
};

// Upsert. COALESCE jaan-boojh ke: ek round pehle bina winName ke store ho sakta
// hai (vendor ne abhi result publish nahi kiya), aur agla pass usko bharega —
// par ek maujooda naam ko NULL se kabhi overwrite nahi karna.
export const storeResults = async (gtype, rows) => {
  const stamped = (Array.isArray(rows) ? rows : [])
    .filter((r) => r && r.mid != null)
    .map((r) => ({ ...r, ...resolveRoundStamp(r.mid) }));

  // Retention se purana round store hi mat karo. Kuch dead tables (tembo
  // family — tcard32, tteen …) vendor se aaj bhi April ke wahi purane 10
  // rounds dete hain: unhe likhte rahe to hourly purge unhe delete karta aur
  // agla pass 20s baad wapas daal deta — hamesha ke liye.
  const cutoff = new Date(Date.now() + 5.5 * 60 * 60 * 1000 - RETENTION_DAYS * 86400000)
    .toISOString()
    .slice(0, 10);
  // Vendor newest-first deta hai; insert ULTA (oldest-first) karte hain taaki
  // `id` hamesha chronological rahe. Ye sirf soundar nahi hai: ballbyball /
  // superover jaise tables ka mid timestamp nahi hota aur ek batch ki saari
  // rows ka round_time ek jaisa hota hai, to `id` hi wahan ek matra bharosemand
  // tiebreaker bachta hai (readResults isi order par chalta hai).
  const list = stamped.filter((r) => r.round_date >= cutoff).reverse();
  if (!list.length) return 0;

  const values = [];
  const params = [];
  list.forEach((row, i) => {
    const { round_date, round_time } = row;
    const b = i * 6;
    values.push(`($${b + 1}, $${b + 2}, $${b + 3}, $${b + 4}, $${b + 5}, $${b + 6}, now(), now())`);
    params.push(
      gtype,
      String(row.mid),
      row.win == null ? null : String(row.win),
      row.winName == null ? null : String(row.winName).slice(0, 150),
      round_date,
      round_time
    );
  });

  await sequelize.query(
    `INSERT INTO casino_result_archive
       (gtype, mid, win, win_name, round_date, round_time, created_at, updated_at)
     VALUES ${values.join(", ")}
     ON CONFLICT (gtype, mid) DO UPDATE SET
       win        = COALESCE(EXCLUDED.win, casino_result_archive.win),
       win_name   = COALESCE(EXCLUDED.win_name, casino_result_archive.win_name),
       round_date = COALESCE(EXCLUDED.round_date, casino_result_archive.round_date),
       round_time = COALESCE(EXCLUDED.round_time, casino_result_archive.round_time),
       updated_at = now()`,
    { bind: params, type: QueryTypes.INSERT }
  );
  return list.length;
};

// Is gtype ke jo mids pehle se DB me hain — archiver inke liye detail call
// nahi karta (results immutable hain), sirf naye mids ke liye karta hai.
export const knownMids = async (gtype, mids) => {
  const list = [...new Set((mids || []).map(String))];
  if (!list.length) return new Set();
  const rows = await sequelize.query(
    `SELECT mid, win_name FROM casino_result_archive
      WHERE gtype = $1 AND mid = ANY($2::varchar[])`,
    { bind: [gtype, list], type: QueryTypes.SELECT }
  );
  // win_name abhi tak null hai to round ko "known" nahi maanenge — agle pass me
  // dobara detail call jaayegi taaki late-publish hone wala result bhi bhar jaye.
  return new Set(rows.filter((r) => r.win_name).map((r) => String(r.mid)));
};

// Drawn rounds the archiver added itself (win "0") between two mids — the
// vendor's last-results drops them (20-20 Poker), so the live strip merges
// them back. Mids of these tables are fixed-width timestamps, so a string
// range is a time range.
// Plan: docs/plans/2026-10-12-poker-tie-full-refund-hidden.md
export const readTieRounds = async (gtype, fromMid, toMid) => {
  const rows = await sequelize.query(
    `SELECT mid FROM casino_result_archive
      WHERE gtype = $1 AND win = '0' AND mid BETWEEN $2 AND $3`,
    { bind: [gtype, String(fromMid), String(toMid)], type: QueryTypes.SELECT }
  );
  return rows.map((r) => String(r.mid));
};

// Report ka read — newest round sabse upar.
//
// Order mid par NAHI: timestamp-mid wale tables ke liye wo sahi hota, par
// ballbyball/superover/cricketv3/dolidana/worli3 random mid dete hain. Isliye
// round_date + round_time (jo unke liye "pehli baar dikha" hai) aur aakhir me
// id, jo storeResults ke reverse-insert ki wajah se chronological hai.
export const readResults = async ({ gtype, date = null, limit = null }) => {
  const where = { gtype };
  if (date) where.round_date = date;
  const rows = await CasinoResultArchive.findAll({
    where,
    order: [["round_date", "DESC"], ["round_time", "DESC"], ["id", "DESC"]],
    limit: date ? RESULTS_DAY_CAP : (limit || RESULTS_DEFAULT_LIMIT),
    raw: true,
  });
  return rows.map((r) => ({
    mid: r.mid,
    win: r.win,
    // Frontend `winnat || winName || mapWinValue(win)` order me padhta hai.
    winName: r.win_name || null,
    round_date: r.round_date || null,
    round_time: r.round_time || null,
  }));
};

// 115 din se purani rows. Ek hi DELETE me lakhon rows uthana lock aur WAL
// dono ke liye bura hai — chunks me, jab tak kuch milta rahe.
export const purgeOldResults = async ({ retentionDays = RETENTION_DAYS, chunk = 5000 } = {}) => {
  let removed = 0;
  for (;;) {
    const [, meta] = await sequelize.query(
      `DELETE FROM casino_result_archive
        WHERE ctid IN (
          SELECT ctid FROM casino_result_archive
           WHERE (round_date IS NOT NULL AND round_date < (CURRENT_DATE - $1::int))
              OR (round_date IS NULL AND created_at < now() - ($1::int * INTERVAL '1 day'))
           LIMIT $2
        )`,
      { bind: [retentionDays, chunk] }
    );
    const n = Number(meta?.rowCount || 0);
    removed += n;
    if (n < chunk) break;
  }
  return removed;
};
