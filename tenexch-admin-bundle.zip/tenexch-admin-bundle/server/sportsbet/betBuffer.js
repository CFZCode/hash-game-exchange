// ─── Server-side bet buffer ──────────────────────────────────────────────────
//
// WHY: the buffer used to be a browser timer, and the API call only happened
// after it. A player who reloaded the page during the "placing bet" spinner
// destroyed that timer, so the bet never reached the server and just vanished.
// The buffer now runs HERE: the slip POSTs at once, the server holds the bet,
// and a reload or a closed tab no longer matters.
//
// FLOW (POST /user/place with a `server_buffer` block):
//   1. claim client_ref (a duplicate submit gets the first one's answer)
//   2. hold the buffer, reading the shared per-match feed poll (liveOdds.js)
//   3. post-buffer checks, a straight port of the slip's Steps 3–6
//      (betBufferRules.js): suspension, fancy drift, blocked, cashout
//      re-price, manual live check, auto bookie favour
//   4. reject → 400 with the SAME toast text the slip used to show
//      accept → patch odds / size / stake onto req.body and call placeBet,
//      whose money code is untouched
//   5. remember the answer for client_ref (betInflight.js), which the reloaded
//      page reads via GET /user/bet-result/:client_ref
//
// NO TRANSACTION IS OPEN DURING THE BUFFER. placeBet opens its transaction on
// its first line, so it is only called after the wait. Holding a DB connection
// "idle in transaction" for seconds per bet would starve the pool.
//
// A payload WITHOUT `server_buffer` is an old cached bundle which already
// buffered in the browser, so it must not wait a second time — but it still
// gets every live check (no wait). SERVER_SIDE_BET_BUFFER=false turns the
// WAIT off, never the checks.
//
// FAIL CLOSED (2026-10-08, GEN-16): a feed miss or a market/runner missing
// from the feed REJECTS the bet; it used to skip every check and book the
// client's odds — after a match ended (upstream 404) the frozen page could
// still place at stale prices. Which rules apply is read from the feed's own
// market, not from client flags. BET_FEED_FAIL_CLOSED=false reverts to fail
// open. Combined slips use checkBetLive() per leg.
//
// Plans: docs/plans/2026-09-22-server-side-bet-buffer.md
//        docs/plans/2026-10-08-bet-placement-fail-closed.md

import { placeBet } from './sportbetscontroller.js';
import BettingConfigService from '../services/BettingConfigService.js';
import { leagueNameForBet } from '../services/SportsLeagueResolver.js';
import { MESSAGES } from '../constants/messages.js';
import liveOdds from './liveOdds.js';
import { isLineMarket } from '../helper/lineMarket.js';
import { isBadloBet } from '../helper/badloMarket.js';
import inflight, { cleanRef } from './betInflight.js';
import {
  isLaySide,
  readBufferTick,
  finalSuspensionStatus,
  fancyOddsDrift,
  manualBetLiveCheck,
  autoBetCheck,
  deriveBufferFlags,
} from './betBufferRules.js';

const BUFFER_ENABLED = String(process.env.SERVER_SIDE_BET_BUFFER ?? 'true').toLowerCase() !== 'false';
// false = old fail-open behaviour (feed miss / missing market skips the checks).
const FAIL_CLOSED = String(process.env.BET_FEED_FAIL_CLOSED ?? 'true').toLowerCase() !== 'false';
// Same fallbacks the slip used (frontend VITE_BET_BUFFER_SECONDS / VITE_FANCY_BUFFER_SECONDS).
const LIVE_DEFAULT_SECONDS = Number(process.env.BET_BUFFER_DEFAULT_SECONDS) || 5;
const FANCY_DEFAULT_SECONDS = Number(process.env.FANCY_BUFFER_DEFAULT_SECONDS) || 3;
// A feed snapshot older than this is treated as "no data this tick".
const MAX_AGE_MS = Number(process.env.LIVE_ODDS_MAX_AGE_MS) || 5000;
// Longest wait for the very first feed read when the buffer itself is shorter.
const FIRST_POLL_WAIT_MS = 3000;
// The slip's monitor ticked every 500 ms.
const TICK_MS = 500;
// Frontend betHelpers.prepareBetPayload conversionRate — usd_amount on a re-priced cashout stake.
const USD_RATE = 0.0118;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const round2 = (n) => Math.round(n * 100) / 100;
const bool = (v) => v === true || v === 'true';

const reject = (message, code) => ({ accept: false, message, code });

const liveList = (gmid) => {
  const { list, ageMs } = liveOdds.snapshot(gmid);
  return list && ageMs <= MAX_AGE_MS ? list : null;
};

async function resolveBufferSeconds(body, sb, liveTracked) {
  let leagueName = null;
  try {
    leagueName = await leagueNameForBet(body.sid, body.eventid, body.league_name);
  } catch {
    leagueName = body.league_name || null;
  }
  const configured = await BettingConfigService.getSportsBufferSeconds(
    body.sid,
    { gtype: sb.gtype, market_type: sb.mname, badlo: body.badlo, league_name: leagueName },
    { allowGlobalFallback: liveTracked },
  ).catch(() => 0);
  if (configured > 0) return configured;
  return liveTracked ? LIVE_DEFAULT_SECONDS : FANCY_DEFAULT_SECONDS;
}

/**
 * Hold the buffer and decide. Returns
 *   { accept: true, odds, size, stake }   or   { accept: false, message, code }.
 *
 * opts.noWait — run every check on the current feed with no buffer wait
 * (a payload with no server_buffer, i.e. an old bundle that already waited in
 * the browser, and each leg of a combined slip).
 *
 * FAIL CLOSED (BET_FEED_FAIL_CLOSED, default on): a bet is accepted only when
 * the live feed confirms its market and runner are open and its price is
 * real. A feed miss — upstream 404 once a match is over, 502, timeout — used
 * to skip every check and book the bet at the client's odds (GEN-16).
 * Which rules apply (own line / live tracked / line side) is read from the
 * FEED's market, never from the client's server_buffer flags.
 * Plan: docs/plans/2026-10-08-bet-placement-fail-closed.md
 */
export async function runBetBuffer(body, sb, opts = {}) {
  const noWait = opts.noWait === true;
  const gmid = body.eventid;
  const marketId = body.match_id;
  const selectionId = body.selection_id;
  const betType = body.bet_type;
  const slipOdds = Number(body.odds) || 0;     // what the slip would place at (E when edited)
  const selectedOdds = Number(sb.selected_odds) || slipOdds; // X, the clicked price
  const isCashout = body.is_cashout === true;
  // A badlo leg's `odds` is the exact run the punter picked, not a feed
  // price (helper/badloMarket.js) — it is placed as chosen, like a khado line.
  const badlo = isBadloBet(body) || String(body.market_type || '').toLowerCase() === 'badlo';
  const runnerName = sb.runner_name || body.nat || body.fancy_name || body.selection_name;
  const stake = Number(body.stake_amount) || 0;

  const canPoll = gmid && body.sid;
  if (FAIL_CLOSED && (!canPoll || !marketId)) return reject(MESSAGES.BET.GAME_SUSPEND, 'NO_MARKET_REF');

  // The client's live_tracked flag only picks the buffer LENGTH here; the
  // price rules below use the feed-derived flag.
  const bufferSeconds = noWait ? 0 : await resolveBufferSeconds(body, sb, bool(sb.live_tracked));
  const started = Date.now();

  let finalSize = Number(sb.initial_size) || 0;
  let blocked = false;
  let ticks = 0;
  let liveTicks = 0;

  const firstPoll = canPoll ? liveOdds.acquire(gmid, body.sid) : null;
  try {
    // ── buffer monitoring (slip Step 3). Same early-out as monitorOddsBuffer:
    // no market id / selection id / buffer → no wait at all.
    if (marketId && selectionId && bufferSeconds > 0 && canPoll) {
      const deadline = started + bufferSeconds * 1000;
      while (Date.now() + TICK_MS <= deadline) {
        await sleep(TICK_MS);
        ticks++;
        const list = liveList(gmid);
        if (!list) continue;
        const tick = readBufferTick({
          marketList: list, marketId, selectionId, betType, feedSideInverted: bool(sb.line_market),
        });
        if (tick.state === 'blocked') { blocked = true; break; }
        if (tick.state !== 'live') continue;
        liveTicks++;
        finalSize = tick.size;
      }
      if (!blocked) {
        const rest = deadline - Date.now();
        if (rest > 0) await sleep(rest);
      }
    }

    // A 0-second buffer (or one shorter than the first upstream read) must
    // still judge the bet on real data — the slip always had its list.
    if (canPoll && !liveList(gmid)) await Promise.race([firstPoll, sleep(FIRST_POLL_WAIT_MS)]);
    const list = canPoll ? liveList(gmid) : null;
    if (!list && marketId) {
      if (FAIL_CLOSED) {
        console.warn(`[betBuffer] FEED MISS gmid=${gmid} market=${marketId} — rejected (fail closed)`);
        return reject(MESSAGES.BET.GAME_SUSPEND, 'FEED_UNAVAILABLE');
      }
      console.warn(`[betBuffer] FEED MISS gmid=${gmid} market=${marketId} — checks skipped (fail open, BET_FEED_FAIL_CLOSED=false)`);
    }

    // Rules for this bet, from the feed's market. Fail-open mode with no list
    // falls back to the client flags (the old behaviour).
    const feedFlags = list ? deriveBufferFlags({ marketList: list, marketId }) : null;
    const flags = feedFlags || (FAIL_CLOSED ? null : {
      ownLine: bool(sb.own_line), liveTracked: bool(sb.live_tracked), lineMarket: bool(sb.line_market), marketType: sb.market_type,
    });
    if (list && !flags) {
      // Market id not in the feed — over, or never real.
      if (FAIL_CLOSED) return reject(MESSAGES.BET.GAME_SUSPEND, 'SUSPENDED:CLOSED');
    }
    const ownLine = Boolean(flags?.ownLine) || badlo;
    const lineMarket = Boolean(flags?.lineMarket);
    const liveTracked = Boolean(flags?.liveTracked) && !ownLine && !lineMarket;
    // An edit is only possible where the slip lets the rate be edited (live-tracked odds).
    const edited = bool(sb.edited) && liveTracked;
    // A payload that calls itself a line market must BE one in the feed:
    // placeBet prices and settles line rows off the stake alone.
    if (feedFlags && isLineMarket(body.market_type) && !feedFlags.lineMarket) {
      return reject(MESSAGES.BET.GAME_SUSPEND, 'MARKET_TYPE_MISMATCH');
    }

    // ── Step 4: final live suspension check
    if (list && marketId) {
      const gs = finalSuspensionStatus({ marketList: list, marketId, selectionId, runnerName, strict: FAIL_CLOSED });
      if (gs) return reject(gs === 'BALL RUNNING' ? MESSAGES.BET.BALL_RUNNING : MESSAGES.BET.GAME_SUSPEND, `SUSPENDED:${gs}`);
    }

    // ── Step 5: strict drift check for locked-odds (fancy) markets; khado / badlo exempt
    if (list && !liveTracked && !ownLine && marketId) {
      const drift = fancyOddsDrift({
        marketList: list, marketId, runnerName, betType, selectedOdds: slipOdds, feedSideInverted: lineMarket, strict: FAIL_CLOSED,
      });
      if (drift.mismatch) return reject(MESSAGES.BET.ODDS_CHANGED, `FANCY_DRIFT:${slipOdds}->${drift.closest}`);
      if (drift.liveSize) finalSize = drift.liveSize;
    }

    // ── Step 6: blocked mid-buffer, then the price decision
    if (blocked) return reject(MESSAGES.BET.GAME_SUSPEND, 'BLOCKED_IN_BUFFER');

    // A live-tracked bet executes at the feed's CURRENT price — read now, on
    // the final list. No live price → the price cannot be confirmed.
    let finalOdds = slipOdds;
    if (liveTracked && list) {
      const tick = readBufferTick({ marketList: list, marketId, selectionId, betType, feedSideInverted: false });
      if (tick.state === 'live') {
        finalOdds = tick.odds;
        finalSize = tick.size;
      } else if (FAIL_CLOSED) {
        return reject(MESSAGES.BET.GAME_SUSPEND, `NO_LIVE_PRICE:${tick.status || tick.state}`);
      }
    }

    let finalStake = stake;
    if (ownLine) {
      finalOdds = slipOdds; // a named line is placed exactly as the slip shows it
    } else if (isCashout) {
      // Re-price the hedge at the live odds (slip Step 6b)
      const live = (liveTracked && finalOdds > 0) ? finalOdds : slipOdds;
      const diff = Number(sb.cashout_diff) || 0;
      if (diff > 0 && Math.abs(live - slipOdds) > 0.001) {
        const divisor = bool(sb.cashout_percent) ? live / 100 + 1 : live;
        finalStake = round2(diff / divisor);
        const maxStake = Number(sb.max_stake) || 0;
        if (!(finalStake > 0) || (maxStake > 0 && finalStake > maxStake)) {
          return reject(MESSAGES.BET.RANGE_NOT_VALID, 'CASHOUT_RANGE');
        }
      }
      finalOdds = live;
    } else if (edited) {
      const manual = manualBetLiveCheck({ betType, editedOdds: slipOdds, liveOdds: finalOdds });
      if (!manual.accept) return reject(MESSAGES.BET.UNMATCHED_NOT_ALLOWED, `MANUAL_LIMIT:${slipOdds}/${finalOdds}`);
      finalOdds = manual.finalOdds;
    } else {
      const auto = autoBetCheck({ marketType: flags?.marketType ?? sb.market_type, betType, selectedOdds, currentOdds: finalOdds });
      if (!auto.accept) return reject(MESSAGES.BET.ODDS_CHANGE_NOT_CONFIRMED, `ODDS_MOVED:${selectedOdds}->${finalOdds}`);
      finalOdds = auto.finalOdds;
    }

    return { accept: true, odds: finalOdds, size: finalSize, stake: finalStake, bufferSeconds, ticks, liveTicks };
  } finally {
    if (canPoll) liveOdds.release(gmid);
  }
}

// Write the decided price / size / stake onto the payload placeBet reads —
// the same fields the slip used to fill after its own buffer.
function applyDecision(body, d) {
  const odds = Number(Number(d.odds).toFixed(2));
  body.odds = odds;
  body.user_rate = odds;
  if (d.size > 0) {
    body.size = d.size;
    if (body.bet_type === 'back' || body.bet_type === 'yes') body.back_size = d.size;
    if (isLaySide(body.bet_type)) body.lay_size = d.size;
  }
  if (d.stake !== Number(body.stake_amount)) {
    const stake = Number(Number(d.stake).toFixed(2));
    body.stake_amount = stake;
    body.original_amount = stake;
    body.amount = stake;
    body.usd_amount = Number((stake * USD_RATE).toFixed(2));
  }
}

/** POST /user/place — buffer on the server, then the untouched placeBet. */
export const placeBetBuffered = async (req, res) => {
  let sb = req.body?.server_buffer;
  if (req.body) delete req.body.server_buffer;
  // Line markets: the suspension + line-drift checks below are the ONLY ones
  // placeBet gets, so they can't be optional. A request without a
  // server_buffer block still runs the buffer, and the flags that switch the
  // drift check off (own_line / live_tracked / edited) or read the wrong feed
  // side (line_market) are set here, never taken from the client.
  if (isLineMarket(req.body?.market_type)) {
    sb = {
      ...(sb && typeof sb === 'object' ? sb : {}),
      line_market: true, own_line: false, live_tracked: false, edited: false,
    };
  }
  // No server_buffer block (an old bundle that already waited in the browser,
  // or a hand-made request) or the buffer switched off: no wait, but the live
  // checks still run — they are the only feed checks a bet gets (GEN-16).
  const noWait = !sb || typeof sb !== 'object' || !BUFFER_ENABLED;
  if (!sb || typeof sb !== 'object') sb = {};

  const userId = req.user?.account?.id;
  const ref = cleanRef(sb.client_ref);

  if (ref) {
    const existing = inflight.begin(userId, ref);
    if (existing) {
      if (existing.state === 'pending') {
        return res.status(409).json({ success: false, pending: true, error: MESSAGES.BET.BET_ALREADY_PENDING });
      }
      return res.status(existing.status || 200).json({ ...existing.body, duplicate: true });
    }
  }

  // Remember whatever answer this request ends with, and hand the decided
  // price back so the slip's matched-bets row shows what was booked.
  let decision = null;
  const sendJson = res.json.bind(res);
  res.json = (payload) => {
    let out = payload;
    if (payload?.success && decision?.accept) {
      out = { ...payload, odds: Number(Number(decision.odds).toFixed(2)), stake: decision.stake, client_ref: ref };
    }
    if (ref) inflight.finish(userId, ref, out, res.statusCode);
    return sendJson(out);
  };

  const t0 = Date.now();
  try {
    decision = await runBetBuffer(req.body, sb, { noWait });
  } catch (err) {
    console.error('[betBuffer] decision error:', err);
    return res.status(500).json({ success: false, error: 'Bet placement failed' });
  }

  const tag = `user=${userId} gmid=${req.body.eventid} market=${req.body.match_id} sel=${req.body.selection_id} `
    + `${req.body.bet_type} ref=${ref || '-'} ${Date.now() - t0}ms`;
  if (!decision.accept) {
    console.log(`[betBuffer] ✗ rejected ${tag} code=${decision.code}`);
    return res.status(400).json({ success: false, error: decision.message, code: decision.code });
  }
  console.log(`[betBuffer] ✓ decided ${tag} X=${sb.selected_odds} slip=${req.body.odds} → ${decision.odds} `
    + `stake=${req.body.stake_amount}→${decision.stake} size=${decision.size} buffer=${decision.bufferSeconds}s `
    + `ticks=${decision.liveTicks}/${decision.ticks}`);

  applyDecision(req.body, decision);
  return placeBet(req, res);
};

/**
 * Live checks for ONE leg of a combined slip, no buffer wait. Same rules as
 * /place; on accept the decided odds / size are written onto the leg, which
 * placeCombinedBet then hands to placeBet. Returns the decision.
 */
export async function checkBetLive(body) {
  const sb = isLineMarket(body?.market_type) ? { line_market: true } : {};
  const d = await runBetBuffer(body, sb, { noWait: true });
  if (d.accept) applyDecision(body, d);
  return d;
}

/** GET /user/bet-result/:client_ref — what happened to a bet the page lost track of. */
export const getBetResult = async (req, res) => {
  const userId = req.user?.account?.id;
  const ref = cleanRef(req.params.client_ref);
  if (!ref) return res.status(400).json({ success: false, error: 'Invalid client_ref' });
  const e = inflight.get(userId, ref);
  if (!e) return res.json({ success: true, state: 'unknown' });
  return res.json({
    success: true,
    state: e.state,
    message: e.state === 'rejected' ? (e.body?.error || e.body?.message || null) : null,
    odds: e.body?.odds ?? null,
    stake: e.body?.stake ?? null,
  });
};

export default { placeBetBuffered, getBetResult, runBetBuffer, checkBetLive };
