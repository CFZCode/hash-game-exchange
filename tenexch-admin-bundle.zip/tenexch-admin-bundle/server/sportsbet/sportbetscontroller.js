
import xssClean from "xss-clean";
import fetch from "node-fetch";
import Wallet from "../model/admin/Wallet.js";
import SportsBet from "../model/user/SportsBet.js";
import UserExposure from "../model/user/UserExposure.js";
import { METER_MAX_RUNS, isMeterMarket, meterPnl, meterLiability } from "../helper/meterMarket.js";
import { isLineMarket, exposureIdentity, linePnl } from "../helper/lineMarket.js";
import { isBadloBet, badloLiability, badloPnl } from "../helper/badloMarket.js";
import TotalExposure from "../model/user/TotalExposure.js";
import sequelize from "../config/db.js";
import BetLock from "../model/admin/BetLock.js";
import PlatformGames from '../model/admin/PlatformGames.js'
import GamesMarkets from '../model/admin/GamesMarkets.js'
import axios from "axios";
import User from "../model/user/User.js";
import Staff from "../model/admin/Staff.js";
import Owner from "../model/admin/Owner.js";
import { Op, Sequelize } from "sequelize";
import UserMatchLocks from "../model/admin/UserMatchLocks.js";
import UserEventMarketLocks from "../model/admin/UserEventMarketLocks.js";
import BetLockService from "../services/BetLockService.js";
import { MESSAGES } from "../constants/messages.js";
import DebitLedger from "../model/user/DebitLedger.js";
import CreditsLedger from "../model/user/CreditsLedger.js";
import SportsLockController from "../controller/admin/SportsLockController.js";
import CricketService from "../services/CricketService.js";
import BettingConfigService from "../services/BettingConfigService.js";
import { isCricketTestFormat } from "../helper/cricketFormat.js";
import { leagueNameForBet } from "../services/SportsLeagueResolver.js";
import { sportNameById } from "../constants/sportsList.js";
import { toNaiveLocalTime } from "../helper/naiveLocalTime.js";
import CasinoBet from "../model/user/casino.js";
import TableCasino from "../model/admin/TableCasino.js";
import redis from "../config/redisClient.js";
import { casinoAllDataKey } from "../helper/casinoFeed.js";
import { OWNER_UPLINE_NO, uplineNo } from "../helper/uplineLevelNo.js";
import { TOTAL_EXPOSURE_SQL } from "../helper/totalExposure.js";
// Live feed checks for combined-slip legs (same rules as /place). Circular with
// betBuffer.js (it imports placeBet) — safe: both are only used inside handlers.
import { checkBetLive } from "./betBuffer.js";
import { clientIp } from '../utils/clientIp.js';

let cachedUsdRate = 0;
let cachedAt = 0;
const sportsDataSet = [
  { sid: 4, ename: "Cricket" },
  { sid: 1, ename: "Football" },
  { sid: 2, ename: "Tennis" },
  { sid: 8, ename: "Table Tennis" },
  { sid: 68, ename: "Esoccer" },
  { sid: 10, ename: "Horse Racing" },
  { sid: 65, ename: "Greyhound Racing" },
  { sid: 15, ename: "Basketball" },
  { sid: 69, ename: "Wrestling" },
  { sid: 18, ename: "Volleyball" },
  { sid: 22, ename: "Badminton" },
  { sid: 59, ename: "Snooker" },
  { sid: 57, ename: "Darts" },
  { sid: 6, ename: "Boxing" },
  { sid: 3, ename: "Mixed Martial Arts" },
  { sid: 58, ename: "American Football" },
  { sid: 11, ename: "E Games" },
  { sid: 19, ename: "Ice Hockey" },
  { sid: 9, ename: "Futsal" },
  { sid: 40, ename: "Politics" },
  { sid: 67, ename: "Boat Racing" },
  { sid: 52, ename: "Motor Sports" },
  { sid: 12, ename: "Greyhounds" },
  { sid: 66, ename: "Kabaddi" },
  { sid: 5, ename: "Golf" },
  { sid: 55, ename: "Rugby League" },
  { sid: 7, ename: "Beach Volleyball" },
  { sid: 13, ename: "Trotting" },
  { sid: 39, ename: "Handball" },
  { sid: 14, ename: "Speedway" },
  { sid: 16, ename: "MotoGP" },
  { sid: 17, ename: "Chess" },
  { sid: 20, ename: "Equine Sports" },
  { sid: 21, ename: "Australian Rules" },
  { sid: 23, ename: "Formula 1" },
  { sid: 24, ename: "Nascar" },
  { sid: 25, ename: "Hockey" },
  { sid: 26, ename: "Supercars" },
  { sid: 27, ename: "Netball" },
  { sid: 28, ename: "Surfing" },
  { sid: 29, ename: "Cycling" },
  { sid: 30, ename: "Gaelic Sports" },
  { sid: 31, ename: "Biathlon" },
  { sid: 32, ename: "Motorbikes" },
  { sid: 33, ename: "Athletics" },
  { sid: 34, ename: "Squash" },
  { sid: 35, ename: "Basketball 3X3" },
  { sid: 36, ename: "Floorball" },
  { sid: 37, ename: "Sumo" },
  { sid: 38, ename: "Virtual sports" },
  { sid: 41, ename: "Weather" }
];
const sportsMap = sportsDataSet.reduce((acc, item) => {
  acc[item.sid] = item.ename;
  return acc;
}, {});

function normalizeOdds(odds) {
  if (odds > 100) return Math.floor(((odds / 100) + 1) * 100) / 100;
  if (odds < 100) return Math.floor((1 + (odds / 100)) * 100) / 100;
  return 2.0;
}

// Per-runner exposure walk for MATCH_ODDS-family (and normalized BM) bets.
// Shared by placeBet (incremental: old + this bet) and cancelBet (full replay
// of the remaining bets) — one formula, one place.
function calculateRunnerExposure({
  runners,
  selectedRunner,
  stake,
  odd,
  betType,
  oldExposures = {}
}) {
  let newExposures = { ...oldExposures };

  // (odd - 1) is not exact in binary float — 1.01 - 1 is 0.010000000000000009, so a
  // 100k lay booked 1000.0000000000009 of liability and the wallet guard rejected a
  // user holding exactly 1000.00 ("Bet not confirm check balance."). Money is 2dp:
  // round the leg amounts, and round each runner's running total too, so the drift
  // never reaches user_exposures or the balance comparison.
  const profit = Math.round(stake * (odd - 1) * 100) / 100;
  const liability = Math.round(stake * (odd - 1) * 100) / 100;

  const isBack = betType === 'back' || betType === 'yes';

  for (const runner of runners) {
    const prev = oldExposures[runner] || 0;

    if (runner === selectedRunner) {
      newExposures[runner] = Math.round((isBack
        ? prev + profit
        : prev - liability) * 100) / 100;
    } else {
      newExposures[runner] = Math.round((isBack
        ? prev - stake
        : prev + stake) * 100) / 100;
    }
  }

  return newExposures;
}

// Net total-exposure query: imported from helper/totalExposure.js (the one
// copy every writer shares). Used by placeBet STEP 10 and cancelBet.

// Resolve the live min/max stake limits for the market a bet targets.
// Client-sent limits are never trusted — this reads the (redis-cached) upstream
// market feed. Precedence: max = maxb (>0) → market.max → section.max;
//                          min = section.min → market.min.
// An owner-set override (admin > Bet Limits) beats the feed on whichever side
// it sets; the other side keeps the feed value. Overrides come from the Redis
// cache layer and fail open, so a config problem can never block betting.
// Returns null when the market can't be found (caller applies env fallbacks).
async function resolveMarketLimits({ eventid, sid, match_id, mname, market_type, selection_name }) {
  const override = await BettingConfigService.getMarketLimits(eventid, match_id).catch(() => ({}));

  const pd = await CricketService.GetMatchPrivateData(eventid, sid);
  const markets = Array.isArray(pd?.data) ? pd.data : [];
  // No feed (match ended / upstream down) but an override IS set: honour the
  // override rather than dropping to the env caps.
  if (!markets.length) {
    if (override?.min > 0 || override?.max > 0) {
      return {
        minLimit: Number(override.min) || 0,
        maxLimit: Number(override.max) || 0,
        marketName: mname || market_type || '',
      };
    }
    return null;
  }

  const mkt = markets.find(m => String(m.mid) === String(match_id))
    || markets.find(m => (m.mname || '') === (mname || market_type));
  // Market not listed (just closed, or a name the feed renamed): same rule as
  // the empty-feed branch — an override still applies, otherwise env caps.
  if (!mkt) {
    if (override?.min > 0 || override?.max > 0) {
      return {
        minLimit: Number(override.min) || 0,
        maxLimit: Number(override.max) || 0,
        marketName: mname || market_type || '',
      };
    }
    return null;
  }

  const selNorm = (selection_name || '').toString().trim().toLowerCase();
  const sec = (mkt.section || []).find(s => (s.nat || '').trim().toLowerCase() === selNorm) || null;

  // Racing (horse 10 / greyhound 65): the feed's maxb is a FLAG (always 1),
  // not a stake cap — trusting it would reject every racing bet over ₹1. The
  // real cap is mkt.max (e.g. maxb:1, max:2000 on a live racecard).
  const isRacing = String(sid) === '10' || String(sid) === '65';
  const maxLimit = (!isRacing && Number(mkt.maxb) > 0) ? Number(mkt.maxb)
    : (Number(mkt.max) > 0 ? Number(mkt.max) : (Number(sec?.max) || 0));
  const minLimit = Number(sec?.min) > 0 ? Number(sec.min) : (Number(mkt.min) || 0);

  return {
    minLimit: Number(override?.min) > 0 ? Number(override.min) : minLimit,
    maxLimit: Number(override?.max) > 0 ? Number(override.max) : maxLimit,
    marketName: mkt.mname,
  };
}

//======================================================================================================
//------------------------- HORSE RACING BETTING WINDOW HELPERS ----------------------------------------
//======================================================================================================

// A horse race (sid=10) accepts bets only in the final N minutes before the off.
const RACE_BET_WINDOW_MINUTES = Number(process.env.RACE_BET_WINDOW_MINUTES) || 5;

const IST_OFFSET_MS = 5.5 * 60 * 60 * 1000;

// The feed sends stime as an IST wall-clock string with NO zone marker
// ("7/22/2026 1:44:00 AM"). This server runs in UTC, where new Date(stime)
// reads it as UTC and lands 5h30m LATE — every race would look hours away and
// every bet would be refused. Parse the parts explicitly as IST.
export function parseFeedIstTime(stime) {
  if (!stime || typeof stime !== 'string') return null;
  const m = stime.trim().match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})[ ,]+(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)?$/i);
  if (!m) {
    const d = new Date(stime);
    return Number.isNaN(d.getTime()) ? null : d.getTime();
  }
  const [, mo, day, yr, hh, mi, ss, ap] = m;
  let h = Number(hh);
  if (ap) {
    const up = ap.toUpperCase();
    if (up === 'PM' && h !== 12) h += 12;
    if (up === 'AM' && h === 12) h = 0;
  }
  return Date.UTC(Number(yr), Number(mo) - 1, Number(day), h, Number(mi), Number(ss || 0)) - IST_OFFSET_MS;
}

// Racing boards nest country → venue → race; other sports are flat.
function findRaceNode(nodes, eventid) {
  for (const n of nodes || []) {
    if (n && String(n.gmid) === String(eventid) && n.stime) return n;
    const hit = findRaceNode(Array.isArray(n?.children) ? n.children : null, eventid);
    if (hit) return hit;
  }
  return null;
}

// Race start time from the LIVE board feed (redis-cached) — NEVER from the
// client-sent match_start_time, which is forgeable. Returns ms epoch or null
// when the feed can't be read / the race isn't listed (caller fails open).
async function resolveRaceStartMs(eventid, sid) {
  const board = await CricketService.fetchCricketData(sid);
  const t1 = Array.isArray(board?.data?.t1) ? board.data.t1 : [];
  const t2 = Array.isArray(board?.data?.t2) ? board.data.t2 : [];
  const race = findRaceNode([...t1, ...t2], eventid);
  if (!race?.stime) return null;
  return parseFeedIstTime(race.stime);
}

export const getMarketNameFromGtype = ({ mname, gtype, nat, section }) => {


  console.log("market name from gtype", { mname, gtype, nat, section })
  if (!mname || !gtype) return null;

  /* =======================
     1️⃣ MATCH / MATCH1
     section se "vs" banta hai
  ======================= */
  if (gtype === "match" || gtype === "match1") {
    let sections = [];

    if (Array.isArray(section)) {
      sections = section;
    } else if (typeof section === "string") {
      try {
        sections = JSON.parse(section);
      } catch (e) {
        sections = [];
      }
    }


    const runnerNames = sections
      .map((s) => s?.nat?.trim())
      .filter(Boolean);

    if (runnerNames.length === 0) return null;

    const marketName =
      runnerNames.length > 1
        ? runnerNames.join(" vs ")
        : runnerNames[0];

    return {
      mname,
      gtype,
      marketName,
    };
  }

  /* =======================
     2️⃣ ALL OTHER TYPES
     nat is single string
     section ignored
  ======================= */
  if (!nat || typeof nat !== "string") return null;

  return {
    mname,
    gtype,
    marketName: nat.trim(),
  };
};

async function inrToUsd(inrAmount = 0) {
  const FIVE_MIN = 5 * 60 * 1000;
  const now = Date.now();
  if (!cachedUsdRate || now - cachedAt > FIVE_MIN) {
    try {
      const r = await fetch("https://api.exchangerate.host/latest?base=INR&symbols=USD");
      const j = await r.json();
      cachedUsdRate = 1 / j.rates.USD;
      cachedAt = now;
    } catch (e) {
      console.error("FX fetch failed, using fallback 83:", e.message);
      cachedUsdRate = 1 / 83;
    }
  }
  return +(inrAmount * cachedUsdRate).toFixed(2);
}

const liabilityOf = (gameType, betType, stake, odds) => {
  if (gameType === "FAN") return stake * odds / 100;
  return betType === "lay" ? stake * (odds - 1) : stake;
};




// user: betlock , is user active or not, lock for particular market 
export const checkUserBetLock = async (user_id, game_type, event_id = null, transaction = null, market_id = null) => {
  try {
    console.log('[BetLock] checkUserBetLock CALLED:', { user_id, game_type, event_id, market_id });
    if (!user_id || !game_type) {
      return {
        allowed: false,
        message: "Missing required parameters: user_id or game_type.",
      };
    }

    // 1. Check Global Lock (BetLock)
    const betLock = await BetLock.findOne({ where: { user_id }, transaction });

    if (betLock) {
      // 🔒 If Match Odds market
      if (game_type.trim().toUpperCase() === "MO") {
        if (betLock.MatchOdds === true) {
          return {
            allowed: false,
            message: "Bet not allowed, contact admin (MatchOdds locked).",
          };
        }
      }
      // 🔒 Any other market type
      else {
        if (betLock.OtherMarkets === true) {
          return {
            allowed: false,
            message: "Bet not allowed, contact admin (OtherMarkets locked).",
          };
        }
      }
    }

    // 2. Check Match-Specific Lock (UserMatchLocks)
    if (event_id) {
      const matchLock = await UserMatchLocks.findOne({
        where: { user_id, event_id: String(event_id), is_locked: true },
        transaction
      });

      if (matchLock) {
        return {
          allowed: false,
          message: "Bet not allowed, this match is locked for you.",
        };
      }
    }

    // 3. Check Market-wise Lock (UserEventMarketLocks) - uses market_id (primary), market_name (fallback)
    if (event_id) {
      // Build market condition: prefer market_id, fallback to market_name
      let marketCondition;
      if (market_id) {
        // Primary: match by market_id directly
        marketCondition = { market_id: String(market_id) };
      } else {
        // Fallback: match by market_name variations
        const marketNames = [];
        const gt = game_type.trim().toUpperCase();
        if (gt === "MO" || gt === "MATCH" || gt === "MATCH_ODDS" || gt === "MATCH1") {
          marketNames.push("MATCH_ODDS", "Match_Odds", "match_odds", "MATCH", "match", "match1");
        } else if (gt === "BM" || gt === "BOOKMAKER" || gt === "BOOKMAKER2") {
          marketNames.push("bookmaker", "Bookmaker", "BOOKMAKER", "bookmaker2", "BM");
        } else if (gt === "FAN" || gt === "FANCY" || gt === "FANCY1" || gt === "NORMAL") {
          marketNames.push("fancy1", "Fancy", "FANCY", "Normal", "normal", "FAN");
        } else {
          marketNames.push(game_type.trim());
        }
        marketCondition = { market_name: { [Op.in]: marketNames } };
      }

      console.log('[BetLock] Checking market lock for user:', { user_id, event_id, market_id, game_type, marketCondition });

      // Check if user is directly locked
      const userMarketLock = await UserEventMarketLocks.findOne({
        where: {
          account_id: user_id,
          account_type: 'user',
          event_id: String(event_id),
          ...marketCondition,
          is_locked: true
        },
        transaction
      });

      console.log('[BetLock] User market lock result:', userMarketLock ? userMarketLock.toJSON() : 'NOT FOUND');

      const user = await User.findOne({ where: { user_id }, attributes: ['parent_staff_id'], transaction });

      // Player's own lock → number of their direct parent (owner if no staff parent)
      if (userMarketLock) {
        const parent = user?.parent_staff_id
          ? await Staff.findOne({ where: { staff_id: user.parent_staff_id }, attributes: ['level'], transaction })
          : null;
        return {
          allowed: false,
          message: MESSAGES.BET.GAME_LOCKED_CONTACT_UPLINE(parent ? uplineNo(parent.level) : OWNER_UPLINE_NO),
        };
      }

      // Check if any staff in upline is locked for this market
      if (user?.parent_staff_id) {
        let staffId = user.parent_staff_id;
        const visited = new Set();
        while (staffId && !visited.has(staffId)) {
          visited.add(staffId);
          const staffLock = await UserEventMarketLocks.findOne({
            where: {
              account_id: staffId,
              account_type: 'staff',
              event_id: String(event_id),
              ...marketCondition,
              is_locked: true
            },
            transaction
          });
          const staff = await Staff.findOne({ where: { staff_id: staffId }, attributes: ['parent_id', 'level'], transaction });
          if (staffLock) {
            return {
              allowed: false,
              message: MESSAGES.BET.GAME_LOCKED_CONTACT_UPLINE(uplineNo(staff?.level)),
            };
          }
          staffId = staff?.parent_id || null;
        }
      }
    }

    // ✅ If no restrictions
    return { allowed: true };

  } catch (error) {
    console.error("Error checking user bet lock:", error);
    return {
      allowed: false,
      message: "Internal server error while checking bet lock.",
    };
  }
};

// Helper to get all ancestor staff IDs (upline)
const getAllAncestorStaffIds = async (userId, transaction = null) => {
  let ancestors = [];
  let currentUser = await User.findOne({ where: { user_id: userId }, attributes: ['parent_staff_id'], transaction });

  if (!currentUser || !currentUser.parent_staff_id) return []; // Direct under owner or invalid

  let currentStaffId = currentUser.parent_staff_id;

  while (currentStaffId) {
    ancestors.push(currentStaffId);
    const staff = await Staff.findOne({ where: { staff_id: currentStaffId }, attributes: ['parent_id'], transaction });
    if (!staff || !staff.parent_id) break;
    currentStaffId = staff.parent_id;
  }

  return ancestors;
};

import StaffMarketLocks from "../model/admin/StaffMarketLocks.js";

// Line markets quote no stake limits in the feed. Without an owner override
// they fall back to these (the slip's own defaults for a market with no quote).
const LINE_MARKET_DEFAULT_MIN_STAKE = Number(process.env.LINE_MARKET_MIN_STAKE) || 100;
const LINE_MARKET_DEFAULT_MAX_STAKE = Number(process.env.LINE_MARKET_MAX_STAKE) || 100000;

// platform betlock: check if platform betlock for this market is allowed or not for sports
export const checkPlatformBetLock = async (sportsId, game_type, user_id, transaction = null) => {

  console.log("check platform betlock ===> for ", { sportsId, game_type, user_id })
  try {
    if (!sportsId || !game_type || !user_id) {
      return {
        allowed: false,
        message: "Missing required parameters: sportsId, game_type or user_id."
      };
    }

    // 1. Get Upline (Ancestors) + Owner (null)
    const ancestors = await getAllAncestorStaffIds(user_id, transaction);
    const staffIdsToCheck = [null, ...ancestors]; // null = Owner

    let key = game_type.trim();
    if (key == "MO") { key = "Match_Odds" }

    // 2. Check for locks in StaffMarketLocks
    // We check for specific market lock OR "ALL" lock
    const locks = await StaffMarketLocks.findAll({
      where: {
        game_id: sportsId,
        staff_id: { [Op.or]: staffIdsToCheck },
        market_name: { [Op.or]: [key, 'ALL'] },
        is_locked: true
      },
      transaction
    });

    if (locks.length > 0) {
      // Found a lock!
      const lock = locks[0];
      const lockType = lock.market_name === 'ALL' ? 'ALL markets' : `${key} market`;
      const locker = lock.staff_id ? `upline staff` : `Owner`;

      return {
        allowed: false,
        message: `Bet not allowed, ${lockType} is locked by ${locker}.`
      };
    }

    return { allowed: true };

  } catch (err) {
    console.error("Error checking platform bet lock:", err);
    return {
      allowed: false,
      message: "Internal server error while checking platform lock."
    };
  }
};



// Helper to get buffer time from Owner's configuration
// Simply fetches the first owner's configuration as requested by user
const getOwnerBufferTime = async () => {
  try {
    const owner = await Owner.findOne(); // Fetch the first owner
    if (owner && owner.platform_configurations) {
      let config = owner.platform_configurations;
      // Handle potential string format if DB returns JSON as string
      if (typeof config === 'string') {
        try { config = JSON.parse(config); } catch (e) { }
      }
      // Return buffer_time (ensure it's a number)
      return Number(config.buffer_time) || 0;
    }
  } catch (error) {
    console.error("Error fetching buffer time:", error);
  }
  return 0;
};

// GET /api/user/buffer-time
// Exposes the global bet-placement buffer (Owner.platform_configurations.buffer_time)
// to the client so the user panel honours the admin setting instead of a hardcoded default.
const getBufferTime = async (req, res) => {
  try {
    const buffer_time = await getOwnerBufferTime();
    return res.json({ success: true, buffer_time });
  } catch (err) {
    console.error("getBufferTime error:", err);
    return res.json({ success: true, buffer_time: 0 });
  }
};



const walletUpdate = async (wallet, balanceChange, transaction, context = {}) => {
  const {
    user_id,
    match_title,
    selection_name,
    market_type,
    game_type,
    match_id,
    eventid,
    sid,
    newBet
  } = context;

  if (isNaN(balanceChange)) {
    console.error(`[walletUpdate] ❌ Critical: balanceChange is NaN for user ${user_id}. Context:`, context);
    return; // Abort to identify source and prevent corruption
  }

  let currentCash = Number(wallet.cash || 0);

  // Apply wallet delta only when non-zero. Zero-delta (hedge that doesn't
  // change max liability) still needs an audit ledger row below.
  if (balanceChange < 0) {
    // Negative delta = cash returned (hedging reduced max exposure)
    const amountToAdd = Math.abs(balanceChange);
    wallet.cash = currentCash + amountToAdd;
    await wallet.save({ transaction });
  } else if (balanceChange > 0) {
    // Positive delta = cash deducted (max exposure increased)
    const amountToDeduct = balanceChange;
    if (currentCash >= amountToDeduct) {
      wallet.cash = currentCash - amountToDeduct;
    }
    if (isNaN(wallet.cash)) {
      console.error(`[walletUpdate] ❌ Resulting balance is NaN! Reverting. Curr: ${currentCash}, Ded: ${amountToDeduct}`);
      throw new Error("Balance calculation resulted in NaN");
    }
    await wallet.save({ transaction });
  }

  const newBalance = Number(wallet.cash || 0);

  // ✅ DebitLedger — keep existing behavior (only when actually deducted)
  if (balanceChange > 0) {
    await DebitLedger.create({
      user_id,
      amount: balanceChange,
      currency: "INR",
      reason: "bet_placed",
      description: `${match_title} ${selection_name}`,
      balance: newBalance,
      market_type: market_type || game_type,
      match_id: match_id,
      event_id: eventid,
      sport_id: sid,
      meta: { bet_id: newBet?.id }
    }, { transaction });
  }

  // ✅ CreditsLedger — ALWAYS write a `bet_placed` audit row per bet,
  //    so per-bet history can find the placement entry by bet_id.
  //    `amount` reflects the cash impact at placement:
  //      • balanceChange > 0  → -balanceChange (debit)
  //      • balanceChange < 0  → 0 (no cash impact at placement; the
  //        exposure_release entry below carries the positive amount)
  const placedAmount = balanceChange > 0 ? -balanceChange : 0;
  // await CreditsLedger.create({
  //   user_id: String(user_id),
  //   currency: "INR",
  //   amount: placedAmount,
  //   reason: "bet_placed",
  //   description: `${match_title} ${selection_name}`,
  //   netamount: placedAmount,
  //   closing: newBalance,
  //   market_type: market_type || game_type,
  //   match_id: match_id,
  //   eventid: eventid,
  //   sport_id: sid,
  //   bet_id: newBet?.id || null,
  //   category: 'SPORTS',
  // }, { transaction });

  // ✅ CreditsLedger — exposure_release row when this bet hedged earlier
  //    exposure and freed up cash at placement time.
  if (balanceChange < 0) {
    const releaseAmount = Math.abs(balanceChange);
    // await CreditsLedger.create({
    //   user_id: String(user_id),
    //   currency: "INR",
    //   amount: releaseAmount,
    //   reason: "exposure_release",
    //   description: `${match_title} ${selection_name} (exposure release)`,
    //   netamount: releaseAmount,
    //   closing: newBalance,
    //   market_type: market_type || game_type,
    //   match_id: match_id,
    //   eventid: eventid,
    //   sport_id: sid,
    //   bet_id: newBet?.id || null,
    //   category: 'SPORTS',
    // }, { transaction });
  }

  console.log(`[walletUpdate] Delta: ${balanceChange}, Cash: ${wallet.cash}`);
};




//======================================================================================================
//-------------------------   SPORTS PLACE BET FUNCTION  -----------------------------------------------
//======================================================================================================

export const placeBet = async (req, res, opts) => {

  // As an Express handler the 3rd arg is `next` (a function), which is
  // ignored — only a plain object is treated as options. placeCombinedBet
  // passes { transaction, skipMinStake }: the caller then OWNS the
  // transaction (placeBet does not commit or roll back) so a combined slip
  // is all-or-nothing.
  const options = (opts && typeof opts === 'object' && !Array.isArray(opts)) ? opts : {};
  const externalTx = options.transaction || null;
  const skipMinStakeOpt = options.skipMinStake === true;

  const transaction = externalTx || await sequelize.transaction();

  try {


    const user_id = req.user.account.id; //set in auth middleware
    if (!user_id) {
      // Har early return se pehle local transaction chhodna zaroori hai — warna
      // session "idle in transaction" pada rehta hai aur staff/users pe lock hold
      // karke poora admin panel block kar deta hai. externalTx placeCombinedBet ka
      // hai, use wahi commit/rollback karta hai.
      if (!externalTx) await transaction.rollback();
      return res.status(400).json({ success: false, error: "User ID is required" });
    }

    let {
      game_type,
      match_id,
      match_title,
      selection_name,
      bet_type,
      odds,
      stake_amount,
      team_one,
      team_two,
      category,
      original_currency,
      original_amount,
      usd_amount,
      match_start_time,
      eventid,
      fancy_name,
      count, sid,
      market_type,
      // League/competition (feed cname) — display-only, see SportsBet.league_name
      league_name,
      // Badlo rides inside an ordinary session market and keeps its
      // market_type ('Normal'); this flag is what marks the bet.
      badlo,
      unmatched,
      unmatched_odds,
      is_cashout,
      size,
      runners,
      lay_size,
      back_size,
      runner_odds,
      mname,
      gtype,
      nat,
      section
    } = req.body;


    count = runners.length;


    console.log('PLACE BET PAYLOAD RECEIVED:', req.body);
    const ip_address = clientIp(req);
    console.log('IP ADDRESS:', ip_address);
    const browser = req.headers["user-agent"] || null;

    // League (feed cname) for this bet. The client sends it when it can, but it
    // often cannot: the match DETAIL feed returns no cname at all, so
    // GameDetails loses it the moment matchData is refreshed from that call and
    // roughly one bet in ten arrived with league_name NULL. It used to be
    // display-only; now the win commission is configured per league (cricket's
    // T5 XI / T10 XI / Virtual Cricket League and the "(e)" e-cricket league
    // are sport_id 4 exactly like a real match), so the server resolves it from
    // the cached event list instead of trusting the browser.
    // Fails open — a miss just leaves it null, as before.
    let effectiveLeagueName = null;
    try {
      effectiveLeagueName = await leagueNameForBet(sid, eventid, league_name);
    } catch (leagueErr) {
      console.warn('[PlaceBet] league resolve failed:', leagueErr.message);
      effectiveLeagueName = league_name ? String(league_name).slice(0, 255) : null;
    }




    //=============================================================================================
    // ✅ STEP 2:                 COMMON VALIDATIONS
    //=============================================================================================

    //  Hierarchical Bet Lock Check
    // on this bet's own transaction — one pooled connection per bet, not two
    const hierarchyAllowed = await BetLockService.isBettingAllowed(user_id, { transaction });
    if (!hierarchyAllowed) {
      if (!externalTx) await transaction.rollback();
      return res.status(403).json({
        success: false,
        message: MESSAGES.BET.LOCKED_CONTACT_UPLINE,
      });
    }


    // Dynamic Sport ID Lookup
    let sportsId = null;
    if (sid) {
      // If sid is provided, try to find the game by sport_id
      const platformGame = await PlatformGames.findOne({ where: { sport_id: String(sid) }, transaction });
      if (platformGame) {
        sportsId = platformGame.id;
      }
    }

    //  checking user bet lock status
    const lockStatus = await checkUserBetLock(user_id, game_type, eventid, transaction, match_id);
    if (!lockStatus.allowed) {
      if (!externalTx) await transaction.rollback();
      return res.status(403).json({
        success: false,
        message: lockStatus.message,
      });
    }


    // Fallback or additional check if needed (e.g. using category/game_type)
    if (!sportsId) {
      console.warn(`Could not resolve PlatformGame for sid: ${sid}`);
    }

    // ✅ checking platform bet lock status
    if (sportsId) {
      const platformlockStatus = await checkPlatformBetLock(sportsId, game_type, user_id, transaction);
      if (!platformlockStatus.allowed) {
        if (!externalTx) await transaction.rollback();
        return res.status(403).json({
          success: false,
          message: platformlockStatus.message,
        });
      }
    }


    // ✅ checking sports lock (Sport → Series → Match → Market hierarchy + upline staff/owner)
    if (sid) {
      const sportsLockStatus = await SportsLockController.checkSportsLock(
        user_id,
        sid,           // sport_id
        null,          // series_id (not available in bet payload, checked at sport/match/market level)
        eventid,       // match_id (event_id is the match identifier)
        match_id,      // market_id
        { transaction } // same connection as the bet (no second pool slot)
      );
      if (!sportsLockStatus.allowed) {
        if (!externalTx) await transaction.rollback();
        return res.status(403).json({
          success: false,
          message: sportsLockStatus.message,
        });
      }
    }

    //=============================================================================================
    // ✅ STEP 3:                   PLATFORM SPECIFIC VALIDATIONS DIAMOND99
    //=============================================================================================


    //==========================================================================================
    // ✅ STEP 4: Call external API first   [SELECT ONE OPTION ONLY - COMMENT OUT THE OTHER OPTION] 
    // =========================================================================================

    const placedata = getMarketNameFromGtype({ mname, gtype, nat, section });

    console.log("placedata", placedata);

    // if (placedata) {
    //   const apiPayload = {
    //     sportsid: sid,
    //     gmid: eventid,
    //     marketName: placedata.marketName,
    //     mname: placedata.mname,
    //     gtype: placedata.gtype,

    //   };

    //   if (gtype == "match" || gtype == "bookmaker" || gtype == "bookmaker2" || gtype == "match1") {
    //     match_title = placedata.marketName;
    //   }


    //   //---------------------------------------------------------------------------------------
    //   // [ PROCEEDING BET PLACEMENT ] :  despite external API failure with warning logs 
    //   //-------------------------------------------------------------------------------------

    //   let apiResponse;
    //   const placedBetsUrl =
    //     "http://cloud.turnkeyxgaming.com:8086/api/v1/post-market";

    //   console.log("External API URL:", placedBetsUrl);
    //   console.log("External API Payload:", apiPayload);


    // } else {
    //   console.warn("Skipping external API call: placedata is null (Market info missing or format invalid).");
    // }




    //-----------------------------------------------------------------------------------------
    // [ NOT PROCEEDING BET PLACEMENT ] : Throw error if bet is not saved to external api 
    //-----------------------------------------------------------------------------------------

    // let apiResponse;
    // const placedBetsUrl = `${process.env.DIAMOND_BASE_URL}/placed_bets?key=${process.env.DIAMOND_API_KEY}`;

    // console.log("External API URL:", placedBetsUrl);
    // console.log("External API Payload:", apiPayload);

    // apiResponse = await axios.post(
    //   placedBetsUrl,
    //   apiPayload,
    //   { timeout: 5000 }
    // );
    // console.log("External API Response:", apiResponse?.data);

    // if (!apiResponse.data || apiResponse.status !== 200) {
    //   throw new Error("External API rejected the bet");
    // }

    // console.log("External API Response:", apiResponse?.data);






    // Owner-set limits for VIRTUAL leagues (Dim / T5 XI / T10 XI / VCL / WWE
    // Virtual — admin Settings → Virtual Bet Limits). Keyed on the server-
    // resolved league. A set side REPLACES the feed / per-event value in the
    // checks below; null for a real match. Fails open.
    const virtualLimit = await BettingConfigService.getVirtualLimit(sid, effectiveLeagueName).catch(() => null);

    //=============================================================================================
    // ✅ STEP 4.5:                 MIN / MAX STAKE VALIDATION (server-side)
    //=============================================================================================
    // Frontend validates limits too, but the API must not trust the client —
    // limits come from the live (redis-cached) market feed. If the feed can't
    // be read (match ended / upstream down), betting stays up under env caps.
    // Line markets (fancy2) quote min 0 / max 0 in the feed, so the feed-based
    // check stays off for them. Keyed on the MARKET NAME, not the client-sent
    // gtype, so no other market can claim this branch to dodge its feed limits.
    if (isLineMarket(market_type)) {
      // An owner-set override wins; otherwise the same defaults the slip
      // applies to any market with no quote (min 100, max 100,000).
      const f2 = { ...(await BettingConfigService.getMarketLimits(eventid, match_id).catch(() => ({}))) };
      if (!(Number(f2?.min) > 0)) f2.min = LINE_MARKET_DEFAULT_MIN_STAKE;
      if (!(Number(f2?.max) > 0)) f2.max = LINE_MARKET_DEFAULT_MAX_STAKE;
      if (Number(virtualLimit?.min) > 0) f2.min = virtualLimit.min;
      if (Number(virtualLimit?.max) > 0) f2.max = virtualLimit.max;
      const f2Stake = Number(stake_amount);
      const f2SkipMin = is_cashout === true || skipMinStakeOpt;
      if (!f2SkipMin && Number(f2?.min) > 0 && f2Stake < Number(f2.min)) {
        throw new Error(`Minimum bet amount is ${Number(f2.min)}`);
      }
      if (Number(f2?.max) > 0 && f2Stake > Number(f2.max)) {
        throw new Error(`Maximum bet amount is ${Number(f2.max)}`);
      }
      console.log(`[placeBet] line market — feed min/max skipped (stake=${stake_amount}, min=${f2.min} max=${f2.max})`);
    } else {
      let limits = null;
      try {
        limits = await resolveMarketLimits({ eventid, sid, match_id, mname, market_type, selection_name });
      } catch (limitErr) {
        console.warn('[placeBet] Market limits lookup failed (non-blocking):', limitErr.message);
      }

      if (virtualLimit) {
        // No feed row → keep the env hard cap as the ceiling unless the owner set one.
        const base = limits || { marketName: mname || market_type || match_id, minLimit: 0, maxLimit: Number(process.env.MAX_STAKE_HARD_CAP) || 500000 };
        limits = {
          ...base,
          minLimit: Number(virtualLimit.min) > 0 ? Number(virtualLimit.min) : base.minLimit,
          maxLimit: Number(virtualLimit.max) > 0 ? Number(virtualLimit.max) : base.maxLimit,
        };
      }

      const stakeNum = Number(stake_amount);
      // Cashout hedge stakes are COMPUTED (not user-chosen) — a min-stake
      // reject would leave the position unbalanceable. Max still applies.
      // Combined-slip legs likewise: the MIN is enforced on the slip TOTAL by
      // placeCombinedBet (an 8.37 leg of a 100 slip must not trip a 100 min).
      const skipMin = is_cashout === true || skipMinStakeOpt;
      if (limits) {
        console.log(`[placeBet] Limits for ${limits.marketName}: min=${limits.minLimit} max=${limits.maxLimit} stake=${stakeNum}${skipMin ? ' (cashout — min skipped)' : ''}`);
        if (!skipMin && limits.minLimit > 0 && stakeNum < limits.minLimit) {
          throw new Error(`Minimum bet amount is ${limits.minLimit}`);
        }
        if (limits.maxLimit > 0 && stakeNum > limits.maxLimit) {
          throw new Error(`Maximum bet amount is ${limits.maxLimit}`);
        }
      } else {
        // Fallback safety caps (market not found in feed) — env-overridable
        const hardCap = Number(process.env.MAX_STAKE_HARD_CAP) || 500000;
        const minDefault = Number(process.env.MIN_STAKE_DEFAULT) || 0;
        console.warn(`[placeBet] Limits unavailable for market ${match_id} — fallback caps min=${minDefault} max=${hardCap}`);
        if (!skipMin && minDefault > 0 && stakeNum < minDefault) {
          throw new Error(`Minimum bet amount is ${minDefault}`);
        }
        if (stakeNum > hardCap) {
          throw new Error(`Maximum bet amount is ${hardCap}`);
        }
      }
    }

    //=============================================================================================
    // ✅ STEP 4.55:            HORSE RACING 5-MINUTE BETTING WINDOW (server-side)
    //=============================================================================================
    // A horse race (sid=10) accepts bets ONLY in the final RACE_BET_WINDOW_MINUTES
    // before the off. The start time is read from the LIVE board feed — never from
    // the client-sent match_start_time. Feed unreadable / race not listed → fails
    // OPEN (check skipped), matching the limit and rate-cap checks above.
    // Greyhound (sid=65) is not affected. Combined slips inherit this rule
    // automatically — every leg goes through placeBet.
    if (String(sid) === '10') {
      let raceStartMs = null;
      try {
        raceStartMs = await resolveRaceStartMs(eventid, sid);
      } catch (raceErr) {
        console.warn('[placeBet] Race window lookup failed (non-blocking):', raceErr.message);
      }
      if (raceStartMs != null) {
        const minutesToOff = (raceStartMs - Date.now()) / 60000;
        console.log(`[placeBet] Race window: gmid=${eventid} minutesToOff=${minutesToOff.toFixed(1)} window=${RACE_BET_WINDOW_MINUTES}`);
        if (minutesToOff > RACE_BET_WINDOW_MINUTES) {
          throw new Error(`Betting opens ${RACE_BET_WINDOW_MINUTES} minutes before the race starts`);
        }
      } else {
        console.warn(`[placeBet] Race window: start time unavailable for gmid=${eventid} — check skipped (fail open)`);
      }
    }

    //=============================================================================================
    // ✅ STEP 4.6:            OWNER-SET MAX ODDS (server-side)
    //=============================================================================================
    // "Bet Not Accept Rate Over <max> on <Sport>": the owner sets a max rate per
    // sport × Match Odds (gtype match) / Bookmaker (gtype match1) in admin
    // Settings → Max Odds. A bet whose rate is above it is refused. The frontend
    // blocks this too, but the API must not trust the client. Fancy-family
    // markets are never capped. Config is cached (BettingConfigService).
    //
    // A cricket cell may be "Oneday & T20 only" (this replaced the old hardcoded
    // 4.00 ODI/T20 rule): Test formats are exempt and the message reads
    // "... on Oneday and T20". The match FORMAT is read from the live feed
    // (getSportDataById → cname), never from a client-sent flag, and only when a
    // bet actually crosses the cap, so normal bets pay no extra feed call.
    {
      // prepareBetPayload may send gtype as the feed value ('match'/'match1') or
      // fall back to game_type ('MATCH'/'BOOKMAKER'); fancy-family → no cap.
      const gtypeForCap = ({ MATCH: 'match', MO: 'match', MATCH1: 'match1', BOOKMAKER: 'match1', BM: 'match1' })[
        String(gtype || game_type || '').toUpperCase()
      ];
      // The league picks the grid row: cricket's Dim / T10 XI / T5 XI / VCL
      // have their own Max Odds tabs. effectiveLeagueName is resolved from the
      // feed cache first (SportsLeagueResolver), so a client cannot dodge a cap
      // by sending another league name.
      const rule = await BettingConfigService.getMaxOddsRule(sid, gtypeForCap, effectiveLeagueName);
      if (rule && Number(odds) > rule.max) {
        let scope = rule.sport;
        let capApplies = true;
        if (rule.limited_overs_only) {
          scope = MESSAGES.BET.LIMITED_OVERS_SCOPE;
          let hay = String(match_title || '');
          try {
            const sd = await CricketService.getSportDataById(eventid, sid);
            const m = Array.isArray(sd?.data) ? sd.data[0] : null;
            if (m) hay = `${m.cname || ''} ${m.ename || match_title || ''}`;
          } catch (fmtErr) {
            // Feed unreadable → fall back to match_title; cap applies (safe default).
            console.warn('[placeBet] Max-odds format lookup failed (non-blocking):', fmtErr.message);
          }
          capApplies = !isCricketTestFormat(hay);
        }
        if (capApplies) {
          throw new Error(MESSAGES.BET.RATE_OVER_LIMIT(rule.max, scope));
        }
      }
    }

    //=============================================================================================
    // ✅ STEP 5:                   EXPOSURE CALCULATION & WALLET VALIDATION
    //=============================================================================================

    const stake = Number(stake_amount);
    const oddN = Number(odds);
    let betTypeLower = (bet_type || "").toLowerCase().trim();
    console.log('Bet details:', { stake, oddN, betTypeLower, game_type });
    if (game_type === "BOOKMAKER") {
      game_type = "BM"
    }
    if (game_type === "FANCY") {
      game_type = "FAN"
    }
    console.log('Normalized game_type:', game_type);



    const isYesNo = betTypeLower === 'yes' || betTypeLower === 'no';
    const isFancy = game_type === "FAN" || (game_type === "MO" && isYesNo);
    const isBookmaker = game_type === 'BM';

    // Validation
    if (stake <= 0) throw new Error("Invalid stake");
    if (isFancy) {
      if (!Number.isFinite(oddN) || oddN <= 0) throw new Error("Invalid fancy odds");
      // if (!isYesNo) throw new Error("Fancy bet must be YES or NO");
    } else {
      // Odds may EQUAL 1 but never go below it — a quote of exactly 1.00 is a
      // legal price (zero profit on a back, zero liability on a lay) and used
      // to be rejected here as "Invalid odds" after the bet was submitted.
      if (!Number.isFinite(oddN) || oddN < 1) throw new Error("Invalid odds");
    }


    // Wallet
    const wallet = await Wallet.findOne({ where: { user_id }, transaction, lock: transaction.LOCK.UPDATE });
    if (!wallet) throw new Error("Wallet not found");
    const currentInr = Number(wallet.cash);
    console.log('Current wallet balance:', currentInr);

    // Line markets key their exposure by the MARKET, not the runner — every
    // line row is called "Total Runs", so the runner cannot identify the book.
    // Settlement's refund lookup uses the SAME pair (helper/lineMarket.js).
    // A browser still holding the pre-2026-08-27 bundle posts market_type
    // 'badlo' and no flag (index.html ships no Cache-Control, so stale bundles
    // are normal for a while). Treat that as badlo too, or the leg would be
    // priced as an ordinary session bet on a market nobody settles.
    const isBadlo = isBadloBet({ badlo }) || String(market_type || '').toLowerCase() === 'badlo';
    const exposureIds = exposureIdentity({ marketType: market_type, selectionName: selection_name, badlo: isBadlo });
    const exposureGameType = exposureIds.game_type;

    // Exposures
    const oldExposuresRows = await UserExposure.findAll({
      where: {
        user_id,
        match_id,
        game_type: exposureGameType
      },
      transaction,
      lock: transaction.LOCK.UPDATE,
    });

    const oldExposures = {};
    oldExposuresRows.forEach((r) => (oldExposures[r.team_name] = Number(r.exposure_amount)));
    console.log('OLD EXPOSURES:', oldExposures);

    let newExposures = { ...oldExposures };

    // `sel` is the exposure row's team_name AND the stem of the lay/back/
    // totalstake helper keys — for a line market that is the market name.
    const sel = exposureIds.team_name != null ? String(exposureIds.team_name) : (selection_name || "").toString();
    const selLower = sel.trim().toLowerCase();
    const isDrawSel = selLower === "the draw" || selLower === "draw";
    const normGameType = isFancy ? "FAN" : game_type === "BM" ? "BM" : "MO";

    const marketsfornonfancy = [
      'Game Winner 1/2',
      'OVER_UNDER_55',
      'OVER_UNDER_45',
      'OVER_UNDER_35',
      'OVER_UNDER_25',
      'OVER_UNDER_15',
      'OVER_UNDER_05',
      'OVER_UNDER_10',

      '2nd Period Winner',
      '1st Period Winner',
      '3rd Period Winner',
      'Both Teams To Score',
      'DRAW_NO_BET',
      'Draw No Bet',

      'HALF_TIME',
      'Match Time Result 70:00',
      'Match Time Result 10:00',
      'Match Time Result 30:00',
      'Match Time Result 20:00',
      'Match Time Result 40:00',
      'Match Time Result 60:00',
      'Match Time Result 50:00',
      'Match Time Result 70:00',
      'Match Time Result 80:00',
      'Match Time Result 90:00',
      'Game Winner 1/1',
      'Game Winner 1/2',
      'Game Winner 1/3',
      'Game Winner 1/4',
      'Game Winner 1/5',
      'Game Winner 1/6',
      'Game Winner 1/7',
      'Game Winner 1/8',
      'Game Winner 1/9',
      'Game Winner 1/10',
      'Game Winner 1/11',
      'Game Winner 1/12',
      'Game Winner 1/13',
      'Game Winner 1/14',
      'Game Winner 1/15',
      'Game Winner 1/16',
      'Game Winner 1/17',
      'Game Winner 1/18',
      'Game Winner 1/19',
      'Game Winner 1/20',
      'Game Winner 2/2',
      'Game Winner 2/3',
      'Game Winner 2/4',
      'Game Winner 2/5',
      'Game Winner 2/6',
      'Game Winner 2/7',
      'Game Winner 2/8',
      'Game Winner 2/9',
      'Game Winner 2/10',
      'Game Winner 2/11',
      'Game Winner 2/12',
      'Game Winner 2/13',
      'Game Winner 2/14',
      'Game Winner 2/15',
      'Game Winner 2/16',
      'Game Winner 2/17',
      'Game Winner 2/18',
      'Game Winner 2/19',
      'Game Winner 2/20',
      'Game Winner 3/1',
      'Game Winner 3/2',
      'Game Winner 3/3',
      'Game Winner 3/4',
      'Game Winner 3/5',
      'Game Winner 3/6',
      'Game Winner 3/7',
      'Game Winner 3/8',
      'Game Winner 3/9',
      'Game Winner 3/10',
      'Game Winner 3/11',
      'Game Winner 3/12',
      'Game Winner 3/13',
      'Game Winner 3/14',
      'Game Winner 3/15',
      'Game Winner 3/16',
      'Game Winner 3/17',
      'Game Winner 3/18',
      'Game Winner 3/19',
      'Game Winner 3/20',
      'Game Winner 4/1',
      'Game Winner 4/2',
      'Game Winner 4/3',
      'Game Winner 4/4',
      'Game Winner 4/5',
      'Game Winner 4/6',
      'Game Winner 4/7',
      'Game Winner 4/8',
      'Game Winner 4/9',
      'Game Winner 4/10',
      'Game Winner 4/11',
      'Game Winner 4/12',
      'Game Winner 4/13',
      'Game Winner 4/14',
      'Game Winner 4/15',
      'Game Winner 4/16',
      'Game Winner 4/17',
      'Game Winner 4/18',
      'Game Winner 4/19',
      'Game Winner 4/20',
      'Game Winner 5/1',
      'Game Winner 5/2',
      'Game Winner 5/3',
      'Game Winner 5/4',
      'Game Winner 5/5',
      'Game Winner 5/6',
      'Game Winner 5/7',
      'Game Winner 5/8',
      'Game Winner 5/9',
      'Game Winner 5/10',
      'Game Winner 5/11',
      'Game Winner 5/12',
      'Game Winner 5/13',
      'Game Winner 5/14',
      'Game Winner 5/15',
      'Game Winner 5/16',
      'Game Winner 5/17',
      'Game Winner 5/18',
      'Game Winner 5/19',
      'Game Winner 5/20',
      'Game Winner 6/1',
      'Game Winner 6/2',
      'Game Winner 6/3',
      'Game Winner 6/4',
      'Game Winner 6/5',
      'Game Winner 6/6',
      'Game Winner 6/7',
      'Game Winner 6/8',
      'Game Winner 6/9',
      'Game Winner 6/10',
      'Game Winner 7/1',
      'Game Winner 7/2',
      'Game Winner 7/3',
      'Game Winner 7/4',
      'Game Winner 7/5',
      'Game Winner 7/6',
      'Game Winner 7/7',
      'Game Winner 2/7',
      'Game Winner 3/7',
      'Game Winner 4/7',
      'Game Winner 5/7',
      'Game Winner 6/7',
      'Game Winner 7/7',
      '1st Set Winner Home/Away',
      '2nd Set Winner Home/Away',
      '3rd Set Winner Home/Away',
      '4th Set Winner Home/Away',
      '5th Set Winner Home/Away',
      '1st Set Winner',
      '2nd Set Winner',
      '3rd Set Winner',
      '4th Set Winner',
      '5th Set Winner',
      '6th Set Winner',
      '1st Half Winner',
      '2nd Half Winner',
      '3rd Half Winner',
      '4th Half Winner',
      '5th Half Winner',
      '6th Half Winner',
      '1st Quarter Winner',
      '2nd Quarter Winner',
      '3rd Quarter Winner',
      '4th Quarter Winner',
      '5th Quarter Winner',
      '6th Quarter Winner',
      '1st Set Race To 1.0',
      '1st Set Race To 2.0',
      '1st Set Race To 3.0',
      '1st Set Race To 4.0',
      '1st Set Race To 5.0',
      '1st Set Race To 6.0',
      '1st Set Race To 7.0',
      '1st Set Race To 8.0',
      '1st Set Race To 9.0',
      '1st Set Race To 10.0',
      '1st Set Race To 11.0',
      '1st Set Race To 12.0',
      '1st Set Race To 13.0',
      '1st Set Race To 14.0',
      '1st Set Race To 15.0',
      '2nd Set Race To 1.0',
      '2nd Set Race To 2.0',
      '2nd Set Race To 3.0',
      '2nd Set Race To 4.0',
      '2nd Set Race To 5.0',
      '2nd Set Race To 6.0',
      '2nd Set Race To 7.0',
      '2nd Set Race To 8.0',
      '2nd Set Race To 9.0',
      '2nd Set Race To 10.0',
      '2nd Set Race To 11.0',
      '2nd Set Race To 12.0',
      '2nd Set Race To 13.0',
      '2nd Set Race To 14.0',
      '2nd Set Race To 15.0',
      '3rd Set Race To 1.0',
      '3rd Set Race To 2.0',
      '3rd Set Race To 3.0',
      '3rd Set Race To 4.0',
      '3rd Set Race To 5.0',
      '3rd Set Race To 6.0',
      '3rd Set Race To 7.0',
      '3rd Set Race To 8.0',
      '3rd Set Race To 9.0',
      '3rd Set Race To 10.0',
      '3rd Set Race To 11.0',
      '3rd Set Race To 12.0',
      '3rd Set Race To 13.0',
      '3rd Set Race To 14.0',
      '3rd Set Race To 15.0',
      '4th Set Race To 1.0',
      '4th Set Race To 2.0',
      '4th Set Race To 3.0',
      '4th Set Race To 4.0',
      '4th Set Race To 5.0',
      '4th Set Race To 6.0',
      '4th Set Race To 7.0',
      '4th Set Race To 8.0',
      '4th Set Race To 9.0',
      '4th Set Race To 10.0',
      '4th Set Race To 11.0',
      '4th Set Race To 12.0',
      '4th Set Race To 13.0',
      '4th Set Race To 14.0',
      '4th Set Race To 15.0',
      'Point Winner 1/1/1',
      'Point Winner 1/1/1',
      'Point Winner 1/1/2',
      'Point Winner 1/1/3',
      'Point Winner 1/1/4',
      'Point Winner 1/1/5',
      'Point Winner 1/1/6',
      'Point Winner 1/1/7',
      'Point Winner 1/1/8',
      'Point Winner 1/1/9',
      'Point Winner 1/1/10',
      'Point Winner 1/1/11',
      'Point Winner 1/1/12',
      'Point Winner 1/1/13',
      'Point Winner 1/1/14',
      'Point Winner 1/1/15',
      'Point Winner 1/1/16',
      'Point Winner 1/1/17',
      'Point Winner 1/1/18',
      'Point Winner 1/1/19',
      'Point Winner 1/1/20',
      'Point Winner 1/2/1',
      'Point Winner 1/2/2',
      'Point Winner 1/2/3',
      'Point Winner 1/2/4',
      'Point Winner 1/2/5',
      'Point Winner 1/2/6',
      'Point Winner 1/2/7',
      'Point Winner 1/2/8',
      'Point Winner 1/2/9',
      'Point Winner 1/2/10',
      'Point Winner 1/2/11',
      'Point Winner 1/2/12',
      'Point Winner 1/2/13',
      'Point Winner 1/2/14',
      'Point Winner 1/2/15',
      'Point Winner 1/2/16',
      'Point Winner 1/2/17',
      'Point Winner 1/2/18',
      'Point Winner 1/2/19',
      'Point Winner 1/2/20',
      'Point Winner 1/3/1',
      'Point Winner 1/3/2',
      'Point Winner 1/3/3',
      'Point Winner 1/3/4',
      'Point Winner 1/3/5',
      'Point Winner 1/3/6',
      'Point Winner 1/3/7',
      'Point Winner 1/3/8',
      'Point Winner 1/3/9',
      'Point Winner 1/3/10',
      'Point Winner 1/3/11',
      'Point Winner 1/3/12',
      'Point Winner 1/3/13',
      'Point Winner 1/3/14',
      'Point Winner 1/3/15',
      'Point Winner 1/3/16',
      'Point Winner 1/3/17',
      'Point Winner 1/3/18',
      'Point Winner 1/3/19',
      'Point Winner 1/3/20',
      'Point Winner 1/4/1',
      'Point Winner 1/4/2',
      'Point Winner 1/4/3',
      'Point Winner 1/4/4',
      'Point Winner 1/4/5',
      'Point Winner 1/4/6',
      'Point Winner 1/4/7',
      'Point Winner 1/4/8',
      'Point Winner 1/4/9',
      'Point Winner 1/5/1',
      'Point Winner 1/5/2',
      'Point Winner 1/5/3',
      'Point Winner 1/5/4',
      'Point Winner 1/5/5',
      'Point Winner 1/5/6',
      'Point Winner 1/5/7',
      'Point Winner 1/5/8',
      'Point Winner 1/5/9',
      'Point Winner 1/6/1',
      'Point Winner 1/6/2',
      'Point Winner 1/6/3',
      'Point Winner 1/6/4',
      'Point Winner 1/6/5',
      'Point Winner 1/6/6',
      'Point Winner 1/6/7',
      'Point Winner 1/6/8',
      'Point Winner 1/6/9',
      'Point Winner 1/7/1',
      'Point Winner 1/7/2',
      'Point Winner 1/7/3',
      'Point Winner 1/7/4',
      'Point Winner 1/7/5',
      'Point Winner 1/7/6',
      'Point Winner 1/7/7',
      'Point Winner 1/7/8',
      'Point Winner 1/7/9',
      'Point Winner 1/8/1',
      'Point Winner 1/8/2',
      'Point Winner 1/8/3',
      'Point Winner 1/8/4',
      'Point Winner 1/8/5',
      'Point Winner 1/8/6',
      'Point Winner 1/8/7',
      'Point Winner 1/8/8',
      'Point Winner 1/8/9',
      'Point Winner 1/9/1',
      'Point Winner 1/9/2',
      'Point Winner 1/9/3',
      'Point Winner 1/9/4',
      'Point Winner 1/9/5',
      'Point Winner 1/9/6',
      'Point Winner 1/9/7',
      'Point Winner 1/9/8',
      'Point Winner 1/9/9',


      'Point Winner 2/1/1',
      'Point Winner 2/1/2',
      'Point Winner 2/1/3',
      'Point Winner 2/1/4',
      'Point Winner 2/1/5',
      'Point Winner 2/1/6',
      'Point Winner 2/1/7',
      'Point Winner 2/1/8',
      'Point Winner 2/1/9',
      'Point Winner 2/2/1',
      'Point Winner 2/2/2',
      'Point Winner 2/2/3',
      'Point Winner 2/2/4',
      'Point Winner 2/2/5',
      'Point Winner 2/2/6',
      'Point Winner 2/2/7',
      'Point Winner 2/2/8',
      'Point Winner 2/2/9',
      'Point Winner 2/3/1',
      'Point Winner 2/3/2',
      'Point Winner 2/3/3',
      'Point Winner 2/3/4',
      'Point Winner 2/3/5',
      'Point Winner 2/3/6',
      'Point Winner 2/3/7',
      'Point Winner 2/3/8',
      'Point Winner 2/3/9',
      'Point Winner 2/4/1',
      'Point Winner 2/4/2',
      'Point Winner 2/4/3',
      'Point Winner 2/4/4',
      'Point Winner 2/4/5',
      'Point Winner 2/4/6',
      'Point Winner 2/4/7',
      'Point Winner 2/4/8',
      'Point Winner 2/4/9',
      'Point Winner 2/5/1',
      'Point Winner 2/5/2',
      'Point Winner 2/5/3',
      'Point Winner 2/5/4',
      'Point Winner 2/5/5',
      'Point Winner 2/5/6',
      'Point Winner 2/5/7',
      'Point Winner 2/5/8',
      'Point Winner 2/5/9',
      'Point Winner 2/6/1',
      'Point Winner 2/6/2',
      'Point Winner 2/6/3',
      'Point Winner 2/6/4',
      'Point Winner 2/6/5',
      'Point Winner 2/6/6',
      'Point Winner 2/6/7',
      'Point Winner 2/6/8',
      'Point Winner 2/6/9',
      'Point Winner 2/7/1',
      'Point Winner 2/7/2',
      'Point Winner 2/7/3',
      'Point Winner 2/7/4',
      'Point Winner 2/7/5',
      'Point Winner 2/7/6',
      'Point Winner 2/7/7',
      'Point Winner 2/7/8',
      'Point Winner 2/7/9',
      'Point Winner 2/8/1',
      'Point Winner 2/8/2',
      'Point Winner 2/8/3',
      'Point Winner 2/8/4',
      'Point Winner 2/8/5',
      'Point Winner 2/8/6',
      'Point Winner 2/8/7',
      'Point Winner 2/8/8',
      'Point Winner 2/8/9',
      'Point Winner 2/9/1',
      'Point Winner 2/9/2',
      'Point Winner 2/9/3',
      'Point Winner 2/9/4',
      'Point Winner 2/9/5',
      'Point Winner 2/9/6',
      'Point Winner 2/9/7',
      'Point Winner 2/9/8',
      'Point Winner 2/9/9',

      'Point Winner 3/1/1',
      'Point Winner 3/1/2',
      'Point Winner 3/1/3',
      'Point Winner 3/1/4',
      'Point Winner 3/1/5',
      'Point Winner 3/1/6',
      'Point Winner 3/1/7',
      'Point Winner 3/1/8',
      'Point Winner 3/1/9',
      'Point Winner 3/2/1',
      'Point Winner 3/2/2',
      'Point Winner 3/2/3',
      'Point Winner 3/2/4',
      'Point Winner 3/2/5',
      'Point Winner 3/2/6',
      'Point Winner 3/2/7',
      'Point Winner 3/2/8',
      'Point Winner 3/2/9',
      'Point Winner 3/3/1',
      'Point Winner 3/3/2',
      'Point Winner 3/3/3',
      'Point Winner 3/3/4',
      'Point Winner 3/3/5',
      'Point Winner 3/3/6',
      'Point Winner 3/3/7',
      'Point Winner 3/3/8',
      'Point Winner 3/3/9',
      'Point Winner 3/4/1',
      'Point Winner 3/4/2',
      'Point Winner 3/4/3',
      'Point Winner 3/4/4',
      'Point Winner 3/4/5',
      'Point Winner 3/4/6',
      'Point Winner 3/4/7',
      'Point Winner 3/4/8',
      'Point Winner 3/4/9',
      'Point Winner 3/5/1',
      'Point Winner 3/5/2',
      'Point Winner 3/5/3',
      'Point Winner 3/5/4',
      'Point Winner 3/5/5',
      'Point Winner 3/5/6',
      'Point Winner 3/5/7',
      'Point Winner 3/5/8',
      'Point Winner 3/5/9',
      'Point Winner 3/6/1',
      'Point Winner 3/6/2',
      'Point Winner 3/6/3',
      'Point Winner 3/6/4',
      'Point Winner 3/6/5',
      'Point Winner 3/6/6',
      'Point Winner 3/6/7',
      'Point Winner 3/6/8',
      'Point Winner 3/6/9',
      'Point Winner 3/7/1',
      'Point Winner 3/7/2',
      'Point Winner 3/7/3',
      'Point Winner 3/7/4',
      'Point Winner 3/7/5',
      'Point Winner 3/7/6',
      'Point Winner 3/7/7',
      'Point Winner 3/7/8',
      'Point Winner 3/7/9',
      'Point Winner 3/8/1',
      'Point Winner 3/8/2',
      'Point Winner 3/8/3',
      'Point Winner 3/8/4',
      'Point Winner 3/8/5',
      'Point Winner 3/8/6',
      'Point Winner 3/8/7',
      'Point Winner 3/8/8',
      'Point Winner 3/8/9',
      'Point Winner 3/9/1',
      'Point Winner 3/9/2',
      'Point Winner 3/9/3',
      'Point Winner 3/9/4',
      'Point Winner 3/9/5',
      'Point Winner 3/9/6',
      'Point Winner 3/9/7',
      'Point Winner 3/9/8',
      'Point Winner 3/9/9',

      'Point Winner 4/1/1',
      'Point Winner 4/1/2',
      'Point Winner 4/1/3',
      'Point Winner 4/1/4',
      'Point Winner 4/1/5',
      'Point Winner 4/1/6',
      'Point Winner 4/1/7',
      'Point Winner 4/1/8',
      'Point Winner 4/1/9',
      'Point Winner 4/2/1',
      'Point Winner 4/2/2',
      'Point Winner 4/2/3',
      'Point Winner 4/2/4',
      'Point Winner 4/2/5',
      'Point Winner 4/2/6',
      'Point Winner 4/2/7',
      'Point Winner 4/2/8',
      'Point Winner 4/2/9',
      'Point Winner 4/3/1',
      'Point Winner 4/3/2',
      'Point Winner 4/3/3',
      'Point Winner 4/3/4',
      'Point Winner 4/3/5',
      'Point Winner 4/3/6',
      'Point Winner 4/3/7',
      'Point Winner 4/3/8',
      'Point Winner 4/3/9',
      'Point Winner 4/4/1',
      'Point Winner 4/4/2',
      'Point Winner 4/4/3',
      'Point Winner 4/4/4',
      'Point Winner 4/4/5',
      'Point Winner 4/4/6',
      'Point Winner 4/4/7',
      'Point Winner 4/4/8',
      'Point Winner 4/4/9',
      'Point Winner 4/5/1',
      'Point Winner 4/5/2',
      'Point Winner 4/5/3',
      'Point Winner 4/5/4',
      'Point Winner 4/5/5',
      'Point Winner 4/5/6',
      'Point Winner 4/5/7',
      'Point Winner 4/5/8',
      'Point Winner 4/5/9',
      'Point Winner 4/6/1',
      'Point Winner 4/6/2',
      'Point Winner 4/6/3',
      'Point Winner 4/6/4',
      'Point Winner 4/6/5',
      'Point Winner 4/6/6',
      'Point Winner 4/6/7',
      'Point Winner 4/6/8',
      'Point Winner 4/6/9',
      'Point Winner 4/7/1',
      'Point Winner 4/7/2',
      'Point Winner 4/7/3',
      'Point Winner 4/7/4',
      'Point Winner 4/7/5',
      'Point Winner 4/7/6',
      'Point Winner 4/7/7',
      'Point Winner 4/7/8',
      'Point Winner 4/7/9',
      'Point Winner 4/8/1',
      'Point Winner 4/8/2',
      'Point Winner 4/8/3',
      'Point Winner 4/8/4',
      'Point Winner 4/8/5',
      'Point Winner 4/8/6',
      'Point Winner 4/8/7',
      'Point Winner 4/8/8',
      'Point Winner 4/8/9',
      'Point Winner 4/9/1',
      'Point Winner 4/9/2',
      'Point Winner 4/9/3',
      'Point Winner 4/9/4',
      'Point Winner 4/9/5',
      'Point Winner 4/9/6',
      'Point Winner 4/9/7',
      'Point Winner 4/9/8',
      'Point Winner 4/9/9',


      'Under/Over 5.5',
      'Under/Over 0.5',
      'Under/Over 1.5',
      'Under/Over 2.5',
      'Under/Over 3.5',
      'Under/Over 4.5',
      'Under/Over 6.5',
      // 'BM 1st Set Winner',
      // 'BM 2nd Set Winner',
      // 'BM 3rd Set Winner',
      // 'BM 4th Set Winner',
      // 'BM 5th Set Winner',
      '1st Set Race To 10.0',
      '1st Set Race To 9.0',
      '1st Set Race To 8.0',
      '1st Set Race To 7.0',
      '1st Set Race To 6.0',
      '1st Set Race To 5.0',
      '1st Set Race To 4.0',
      '1st Set Race To 3.0',
      '1st Set Race To 2.0',
      '1st Set Race To 1.0',
      '2nd Set Race To 10.0',
      '2nd Set Race To 9.0',
      '2nd Set Race To 8.0',
      '2nd Set Race To 7.0',
      '2nd Set Race To 6.0',
      '2nd Set Race To 5.0',
      '2nd Set Race To 4.0',
      '2nd Set Race To 3.0',
      '2nd Set Race To 2.0',
      '2nd Set Race To 1.0',
      '3rd Set Race To 10.0',
      '3rd Set Race To 9.0',
      '3rd Set Race To 8.0',
      '3rd Set Race To 7.0',
      '3rd Set Race To 6.0',
      '3rd Set Race To 5.0',
      '3rd Set Race To 4.0',
      '3rd Set Race To 3.0',
      '3rd Set Race To 2.0',
      '3rd Set Race To 1.0',
      '4th Set Race To 10.0',
      '4th Set Race To 9.0',
      '4th Set Race To 8.0',
      '4th Set Race To 7.0',
      '4th Set Race To 6.0',
      '4th Set Race To 5.0',
      '4th Set Race To 4.0',
      '4th Set Race To 3.0',
      '4th Set Race To 2.0',
      '4th Set Race To 1.0',
      '5th Set Race To 4.0',
      '5th Set Race To 3.0',
      '5th Set Race To 2.0',
      '5th Set Race To 1.0',
      'Total Tie Break in the Match 0.5',
      'Total Tie Break in the Match 1.0',
      'Total Tie Break in the Match 1.5',
      'Total Tie Break in the Match 2.0',
      'Total Tie Break in the Match 2.5',
      'Total Tie Break in the Match 3.5',
      'Game To Deuce 1/1',
      'Game To Deuce 1/2',
      'Game To Deuce 1/3',
      'Game To Deuce 1/4',
      'Game To Deuce 1/5',
      'Game To Deuce 1/6',
      'Game To Deuce 1/7',
      'Game To Deuce 1/8',
      'Game To Deuce 1/9',
      'Game To Deuce 1/10',
      'Game To Deuce 1/11',
      'Game To Deuce 1/12',
      'Game To Deuce 1/13',
      'Game To Deuce 1/14',
      'Game To Deuce 1/15',
      'Game To Deuce 1/16',
      'Game To Deuce 1/17',
      'Game To Deuce 1/18',
      'Game To Deuce 1/19',
      'Game To Deuce 1/20',
      'Game To Deuce 2/1',
      'Game To Deuce 2/2',
      'Game To Deuce 2/3',
      'Game To Deuce 2/4',
      'Game To Deuce 2/5',
      'Game To Deuce 2/6',
      'Game To Deuce 2/7',
      'Game To Deuce 2/8',
      'Game To Deuce 2/9',
      'Game To Deuce 2/10',
      'Game To Deuce 2/11',
      'Game To Deuce 2/12',
      'Game To Deuce 2/13',
      'Game To Deuce 2/14',
      'Game To Deuce 2/15',
      'Game To Deuce 2/16',
      'Game To Deuce 2/17',
      'Game To Deuce 2/18',
      'Game To Deuce 2/19',
      'Game To Deuce 2/20',

      'Game To Deuce 3/1',
      'Game To Deuce 3/2',
      'Game To Deuce 3/3',
      'Game To Deuce 3/4',
      'Game To Deuce 3/5',
      'Game To Deuce 3/6',
      'Game To Deuce 3/7',
      'Game To Deuce 3/8',
      'Game To Deuce 3/9',
      'Game To Deuce 3/10',
      'Game To Deuce 3/11',
      'Game To Deuce 3/12',
      'Game To Deuce 3/13',
      'Game To Deuce 3/14',
      'Game To Deuce 3/15',
      'Game To Deuce 3/16',
      'Game To Deuce 3/17',
      'Game To Deuce 3/18',
      'Game To Deuce 3/19',
      'Game To Deuce 3/20',

      'Game To Deuce 4/1',
      'Game To Deuce 4/2',
      'Game To Deuce 4/3',
      'Game To Deuce 4/4',
      'Game To Deuce 4/5',
      'Game To Deuce 4/6',
      'Game To Deuce 4/7',
      'Game To Deuce 4/8',
      'Game To Deuce 4/9',
      'Game To Deuce 4/10',
      'Game To Deuce 4/11',
      'Game To Deuce 4/12',
      'Game To Deuce 4/13',
      'Game To Deuce 4/14',
      'Game To Deuce 4/15',
      'Game To Deuce 4/16',
      'Game To Deuce 4/17',
      'Game To Deuce 4/18',
      'Game To Deuce 4/19',
      'Game To Deuce 4/20',

      'Game To Deuce 5/1',
      'Game To Deuce 5/2',
      'Game To Deuce 5/3',
      'Game To Deuce 5/4',
      'Game To Deuce 5/5',
      'Game To Deuce 5/6',
      'Game To Deuce 5/7',
      'Game To Deuce 5/8',
      'Game To Deuce 5/9',
      'Game To Deuce 5/10',
      'Game To Deuce 5/11',
      'Game To Deuce 5/12',
      'Game To Deuce 5/13',
      'Game To Deuce 5/14',
      'Game To Deuce 5/15',
      'Game To Deuce 5/16',
      'Game To Deuce 5/17',
      'Game To Deuce 5/18',
      'Game To Deuce 5/19',
      'Game To Deuce 5/20',

      'Game To Deuce 6/1',
      'Game To Deuce 6/2',
      'Game To Deuce 6/3',
      'Game To Deuce 6/4',
      'Game To Deuce 6/5',
      'Game To Deuce 6/6',
      'Game To Deuce 6/7',
      'Game To Deuce 6/8',
      'Game To Deuce 6/9',
      'Game To Deuce 6/10',
      'Game To Deuce 6/11',
      'Game To Deuce 6/12',
      'Game To Deuce 6/13',
      'Game To Deuce 6/14',
      'Game To Deuce 6/15',
      'Game To Deuce 6/16',
      'Game To Deuce 6/17',
      'Game To Deuce 6/18',
      'Game To Deuce 6/19',
      'Game To Deuce 6/20',

      'Game To Deuce 7/1',
      'Game To Deuce 7/2',
      'Game To Deuce 7/3',
      'Game To Deuce 7/4',
      'Game To Deuce 7/5',
      'Game To Deuce 7/6',
      'Game To Deuce 7/7',
      'Game To Deuce 7/8',
      'Game To Deuce 7/9',
      'Game To Deuce 7/10',

      'Game To Deuce 8/1',
      'Game To Deuce 8/2',
      'Game To Deuce 8/3',
      'Game To Deuce 8/4',
      'Game To Deuce 8/5',
      'Game To Deuce 8/6',
      'Game To Deuce 8/7',
      'Game To Deuce 8/8',
      'Game To Deuce 8/9',
      'Game To Deuce 8/10',

      'Game To Deuce 9/1',
      'Game To Deuce 9/2',
      'Game To Deuce 9/3',
      'Game To Deuce 9/4',
      'Game To Deuce 9/5',
      'Game To Deuce 9/6',
      'Game To Deuce 9/7',
      'Game To Deuce 9/8',
      'Game To Deuce 9/9',
      'Under/Over 180s 0.5',
      'Under/Over 180s 1.0',
      'Under/Over 180s 1.5',
      'Under/Over 180s 2.0',
      'Under/Over 180s 2.5',
      'Under/Over 180s 3.0',
      'Under/Over 180s 3.5',
      'Under/Over 180s 4.0',



      'Tied Match',
      "TIED_MATCH"



    ];
    function isNonFancyMarket(market_type) {

      // 1️⃣ fixed names
      if (fixedNonFancyMarkets.includes(market_type)) {
        return true;
      }

      // 2️⃣ Game Winner X/Y
      if (/^Game Winner\s+(?:[1-9]|1\d|20)\/(?:[1-9]|1\d|20)$/.test(market_type)) {
        return true;
      }

      // 3️⃣ Match Time Result 10:00, 70:00, etc
      if (/^Match Time Result\s+\d{2}:\d{2}$/.test(market_type)) {
        return true;
      }

      // 4️⃣ Set Race To 1.0 – 15.0 (all sets)
      if (/^\d+(?:st|nd|rd|th)\s+Set Race To\s+(?:[1-9]|1[0-5])\.0$/.test(market_type)) {
        return true;
      }

      // 5️⃣ Under/Over 0.5 , 1.5 , 180s etc
      if (/^Under\/Over(?: 180s)?\s+\d+(\.\d)?$/.test(market_type)) {
        return true;
      }

      // 6️⃣ Total Tie Break in the Match X.X
      if (/^Total Tie Break in the Match\s+\d+(\.\d)?$/.test(market_type)) {
        return true;
      }

      // 7️⃣ Point Winner A/B/C
      if (/^Point Winner\s+(?:[1-9]|1\d|20)\/(?:[1-9]|1\d|20)\/(?:[1-9]|1\d|20)$/.test(market_type)) {
        return true;
      }

      // 8️⃣ Game To Deuce A/B   (your current list)
      if (/^Game To Deuce\s+(?:[1-9]|1\d|20)\/(?:[1-9]|1\d|20)$/.test(market_type)) {
        return true;
      }

      // 9️⃣ Game To Deuce A/B/C (future support – as you mentioned before)
      if (/^Game To Deuce\s+(?:[1-9]|1\d|20)\/(?:[1-9]|1\d|20)\/(?:[1-9]|1\d|20)$/.test(market_type)) {
        return true;
      }

      return false;
    }

    const fixedNonFancyMarkets = [
      'OVER_UNDER_55',
      'OVER_UNDER_45',
      'OVER_UNDER_35',
      'OVER_UNDER_25',
      'OVER_UNDER_15',
      'OVER_UNDER_05',
      'OVER_UNDER_10',

      '2nd Period Winner',
      '1st Period Winner',
      '3rd Period Winner',

      'Both Teams To Score',

      'DRAW_NO_BET',
      'Draw No Bet',

      'HALF_TIME',

      '1st Set Winner Home/Away',
      '2nd Set Winner Home/Away',
      '3rd Set Winner Home/Away',
      '4th Set Winner Home/Away',
      '5th Set Winner Home/Away',

      '1st Set Winner',
      '2nd Set Winner',
      '3rd Set Winner',
      '4th Set Winner',
      '5th Set Winner',
      '6th Set Winner',

      '1st Half Winner',
      '2nd Half Winner',
      '3rd Half Winner',
      '4th Half Winner',
      '5th Half Winner',
      '6th Half Winner',

      '1st Quarter Winner',
      '2nd Quarter Winner',
      '3rd Quarter Winner',
      '4th Quarter Winner',
      '5th Quarter Winner',
      '6th Quarter Winner',

      'Tied Match',
      'TIED_MATCH'
    ];

    const marketsforfancy = [
      '1st Innings 6 Overs Line',
      '2nd Innings 6 Overs Line',
      '3rd Innings 6 Overs Line',
      '1st Innings 50 Overs Line',
      '2nd Innings 50 Overs Line',
      '3rd Innings 50 Overs Line',
      '1st Innings 40 Overs Line',
      '2nd Innings 40 Overs Line',
      '3rd Innings 40 Overs Line',
      '1st Innings 30 Overs Line',
      '2nd Innings 30 Overs Line',
      '3rd Innings 30 Overs Line',
      '1st Innings 20 Overs Line',
      '2nd Innings 20 Overs Line',
      '3rd Innings 20 Overs Line',
      '1st Innings 10 Overs Line',
      '2nd Innings 10 Overs Line',
      '3rd Innings 10 Overs Line',
      'Over By Over',
      'Ball By Ball',
      'Normal',
      'khado',
      'meter',
      'fancy1',
      'oddeven',
      'badlo',
    ];
    // The list above enumerates line markets BY OVER COUNT and misses several
    // the feed actually sends: 15, 25, 35 and 45 are absent, so
    // "2nd Innings 15 Overs Line" fell through every branch below and was
    // rejected outright with "bet is closed for this market" — unplaceable,
    // even though settlementv2's resolver already handles 15/25/35/45.
    // isLineMarket() matches ANY "... Overs Line" by SHAPE, which is what the
    // exposure and liability branches below already use. Take the union so a
    // new over count can never be placeable-nowhere again.
    const isFancyMarketType = marketsforfancy.includes(market_type) || isLineMarket(market_type);
    const marketsforBMfancy = [
      'BM 1st Set Winner',
      'BM 2nd Set Winner',
      'BM 3rd Set Winner',
      'BM 4th Set Winner',
      'BM 5th Set Winner',
      'BM 6th Set Winner',
    ]
    // Matches any innings/over session market regardless of over count or
    // team suffix, e.g. "2ND INN 15 OVER DS VS KR", "1ST INN 20 OVER".
    // Whole-innings "1ST INN LAMBI BT VS JK" is the same cricketcasino digit
    // market with no over count — it used to hit "bet is closed".
    // Keep in sync with bigRunnerSessionMarket in settlementv2.js.
    const bigRunnerSessionMarket = /\b(1ST|2ND|3RD)\s+INN\s+(\d+(\.\d+)?\s+OVER|LAMBI)\b/i;
    const marketforfancywithbigrunners = [
      bigRunnerSessionMarket,
      'TOURNAMENT_WINNER',
      'Next Goal 1.0',
      'Next Goal 2.0',
      'Next Goal 3.0',
      'Next Goal 4.0',
      'Next Goal 5.0',
      'Next Goal 6.0',
      'Next Goal 7.0',
      'Next Goal 8.0',
      'Next Goal 9.0',
      'Next Goal 10.0',
      'Match Result/Both Teams to score',
      'Correct Score 1st Set',
      'Correct Score 2nd Set',
      'Correct Score 3rd Set',
      'Correct Score 4th Set',
      'Correct Score 5th Set',
      'Correct Score 6th Set',
      'HT/FT'

      // 'oddeven'

    ];

    // calculateRunnerExposure is module-scope now (shared with cancelBet)
    function isFancyMatch(gameType = '', matchList = []) {
      const normalized = gameType.toUpperCase();

      return matchList.some(item =>
        item instanceof RegExp
          ? item.test(normalized)
          : normalized.includes(item.toUpperCase())
      );
    }


    if (isFancyMarketType) {
      console.log("marketsforfancy", marketsforfancy);
      console.log("market_type", market_type);

      const S = Number(stake);        // 100
      let L = Number(lay_size);     // 110
      let B = Number(back_size);    // 90
      // fancy1/oddeven are priced in decimal odds, and this feed puts market
      // VOLUME in size/back_size/lay_size (e.g. 1000000) rather than a bhav.
      // Derive the bhav from the runner prices instead: (odds - 1) * 100.
      if (market_type === 'fancy1' || market_type === 'oddeven') {

        console.log("runner_odds", oddN);
       
        L = (oddN - 1) * 100
        B = (oddN - 1) * 100
        console.log("oddeven hit ");
        console.log("L", L);
        console.log("B", B);
      }

      // const L = 110;     // 110
      // const B = 90;
      let layword = sel + 'lay';
      let backword = sel + 'back';
      // Line markets block the LADDER'S WORST RUN across every open bet on the
      // market plus this one (operator rule 2026-09-17 — replaces the
      // 2026-08-26 "money staked" rule). yes@41 + no@44 at 100 each reads
      // 0 / +200 / 0, so it blocks 0, not 200. Bets are filtered by
      // market_type because every line market quotes the same runner name
      // ("Total Runs"). Evens steps only change at a line, so probing
      // min(line)-1 and each line covers every region.
      if (isLineMarket(market_type)) {
        const lineBets = await SportsBet.findAll({
          where: { user_id, eventid, market_type, status: 'open' },
          attributes: ['bet_type', 'odds', 'stake_amount'],
          transaction,
        });
        const legs = [
          ...lineBets.map((b) => ({ line: Number(b.odds), stake: Number(b.stake_amount), betType: b.bet_type })),
          { line: Number(oddN), stake: S, betType: betTypeLower },
        ].filter((l) => Number.isFinite(l.line) && Number.isFinite(l.stake));
        const probes = [Math.min(...legs.map((l) => l.line)) - 1, ...legs.map((l) => l.line)];
        const worst = Math.min(
          ...probes.map((r) => legs.reduce((sum, l) => sum + linePnl({ runs: r, ...l }), 0))
        );
        newExposures[sel] = Math.min(0, Number(worst.toFixed(2)));
        newExposures[layword] = (oldExposures[layword] || 0) + stake;
        newExposures[backword] = (oldExposures[backword] || 0) - stake;
      }
      // Badlo has NO branch of its own any more. It used to block MONEY STAKED
      // (each `no` leg holding its own stake, never netting) in a separate
      // ('badlo', runner) bucket — and because the runner's step book kept its
      // own bucket, the two were SUMMED: -200 step + -200 spike = -400 against
      // a ladder whose worst run was -300. A badlo leg now falls through to the
      // shared worst-case walk below, which prices its spike alongside every
      // step and meter ramp on the same runner, so the blocked money IS the
      // ladder's worst run. Operator rule, 2026-09-12 — this replaces the
      // 2026-08-27 "money staked, not worst-case" rule for badlo (line
      // markets followed on 2026-09-17, see above).
      else {


        // Previous exposures
        console.log("oldExposures", oldExposures);
        let layExp = Number(oldExposures?.[layword] || 0);
        let backExp = Number(oldExposures?.[backword] || 0);

        console.log("layExp", layExp);
        console.log("backExp", backExp);

        // oddeven/fancy1: a losing "no" costs stake*odds — that is what
        // singleBetLiability persists and what settlementv2 pays out — not the
        // stake*(odds-1) the bhav formula gives. Existing bets already read that
        // figure from the `liability` column; keep the incoming leg in step.
        const layRisk = (market_type === 'fancy1' || market_type === 'oddeven')
          ? (S * L) /100
          : (S * L) / 100;   // 110
        const backWin = (market_type === 'fancy1' || market_type === 'oddeven')
          ? (S * B) /100
          : (S * B) / 100;  // 90

        // Session (Normal) bets arrive as yes/no, not back/lay: no==lay wins
        // the low region, yes==back wins the high region (same mapping as the
        // contribution walk below).

        if( market_type === 'oddeven') {
          if (betTypeLower === 'lay' || betTypeLower === 'no') {

          // LAY/NO impact
          layExp += layRisk;        // +100
          backExp -= S; // -110

        } else if (betTypeLower === 'back' || betTypeLower === 'yes') {

          // BACK/YES impact
          layExp -= S;        // -100
          backExp += backWin; // +90
        }
        }
        else{
        if (betTypeLower === 'lay' || betTypeLower === 'no') {

          // LAY/NO impact
          layExp += S;        // +100
          backExp -= layRisk; // -110

        } else if (betTypeLower === 'back' || betTypeLower === 'yes') {

          // BACK/YES impact
          layExp -= S;        // -100
          backExp += backWin; // +90
        }
      }
        console.log("layExp", layExp);
        console.log("backExp", backExp);

        // Legacy 2-region aggregates (kept for any other consumers)
        newExposures[layword] = layExp;
        newExposures[backword] = backExp;

        // Track total stakes (kept for reference / other consumers)
        let stakeKey = sel + 'totalstake';
        let totalStake = Number(oldExposures?.[stakeKey] || 0) + S;
        newExposures[stakeKey] = totalStake;

        // ---- TRUE worst-case liability for this selection ----------------
        // A ladder with bets on different lines has more than two outcome
        // regions, so the old `currentWorst` (2-region collapse) could
        // UNDER-block (when a middle region is the worst, e.g. No@low+Yes@high)
        // and the old `runningSel` (naive per-bet sum) could OVER-block (when a
        // middle region wins, e.g. No@high+Yes@low — the reported bug).
        // Instead compute the real minimum net P&L across every run value from
        // ALL open bets on this selection (plus the incoming bet) — the same
        // per-run-value model the ladder book uses. Each bet is a step:
        //   yes/back: wins when runValue >= line -> +stake*size/100, else -stake
        //   no/lay:   wins when runValue <  line -> +stake,          else -liability
        const IS_METER = isMeterMarket(market_type);

        // Badlo legs ARE loaded here — they share this runner and its
        // market_type ('Normal'), and their money is part of the same pot. What
        // must never happen is pricing them as STEPS: a yes@88 would then "win"
        // every run from 88 up and a no@93 every run below 93, inventing
        // regions that do not exist (that is what blocked 400 against a single
        // 100 bet). They are carried through as SPIKES instead — see the
        // `isBadlo` contribution below and helper/badloMarket.js.
        const existingBets = await SportsBet.findAll({
          where: { user_id, selection_name: sel, eventid, status: 'open' },
          attributes: ['bet_type', 'stake_amount', 'odds', 'size', 'liability', 'badlo'],
          transaction,
        });

        const toContribution = (betType, line, win, lose) => ({
          line: Number(line),
          isYes: ['yes', 'back'].includes(String(betType || '').toLowerCase()),
          winAmt: win,
          loseAmt: lose,
        });

        const contribs = existingBets.map((b) => {
          const stk = Number(b.stake_amount);
          // For fancy1/oddeven the persisted `size` is market volume, not a bhav,
          // so stk*size/100 would book a ~10,000x win and mask real losses in the
          // same region. Derive the bhav from the price, matching both the
          // incoming-bet leg above and settlementv2's payout (stake*(odds-1)).
          const sz = (market_type === 'fancy1' || market_type === 'oddeven')
            ? (Number(b.odds) - 1) * 100
            : Number(b.size);
          const liab = Number(b.liability);
          const isYes = ['yes', 'back'].includes(String(b.bet_type || '').toLowerCase());
          // A badlo leg is EVENS on ONE run, so its money can never be read off
          // `size`/`liability` (a bhav) the way a step's is. pnlAt() routes it
          // through badloPnl and prices it off `stake`; win/lose are filled
          // with the stake purely so the validContribs filter below does not
          // drop the leg as NaN.
          const legIsBadlo = isBadloBet(b);
          return {
            ...toContribution(
              b.bet_type,
              b.odds,
              legIsBadlo ? stk : (isYes ? (stk * sz) / 100 : stk),                    // win amount
              legIsBadlo ? stk : (isYes ? stk : (liab > 0 ? liab : (stk * sz) / 100)) // lose amount
            ),
            stake: stk,   // meter/line/badlo price off the stake, not a bhav
            isBadlo: legIsBadlo,
          };
        });
        // Add the incoming bet (not yet persisted). layRisk/backWin already in
        // scope — but they are bhav-derived and meaningless for a badlo leg,
        // which is evens on its own run, so it goes in as a spike instead.
        contribs.push(
          isBadlo
            ? { ...toContribution(betTypeLower, oddN, S, S), stake: S, isBadlo: true }
            : betTypeLower === 'lay' || betTypeLower === 'no'
              ? { ...toContribution(betTypeLower, oddN, S, layRisk), stake: S, isBadlo: false }
              : { ...toContribution(betTypeLower, oddN, backWin, S), stake: S, isBadlo: false }
        );

        const validContribs = contribs.filter(
          (c) => !isNaN(c.line) && c.line > 0 && !isNaN(c.winAmt) && !isNaN(c.loseAmt)
        );

        // Meter is a SPREAD, not a line: it pays the run DIFFERENCE per unit of
        // stake, so its contribution is a ramp rather than a step. Same maths
        // the Run Amount ladder draws — see helper/meterMarket.js.
        const pnlAt = (r) =>
          validContribs.reduce((sum, c) => {
            // Badlo is an EXACT-RUN spike sitting inside an ordinary session
            // market: it pays only when the run matches and is worth nothing
            // one run either side. Walking it as a step invents whole regions.
            if (c.isBadlo) {
              return sum + badloPnl({
                runs: r, line: c.line, stake: c.stake, betType: c.isYes ? 'yes' : 'no',
              });
            }
            if (IS_METER) {
              return sum + meterPnl({
                runs: r, line: c.line, stake: c.stake, betType: c.isYes ? 'yes' : 'no',
              });
            }
            return sum + ((c.isYes ? r >= c.line : r < c.line) ? c.winAmt : -c.loseAmt);
          }, 0);

        // P&L only changes at line boundaries, so evaluating each distinct line
        // plus the region just below the lowest line covers every region.
        let worstCase = 0;
        if (validContribs.length) {
          const lines = validContribs.map((c) => c.line);
          // A meter ramp has no kink at its line — it only bends where it caps.
          // A piecewise-linear sum bottoms out at an endpoint or a kink, so
          // evaluate run 0 and every line+150 instead of the line boundaries.
          // Every badlo run is already a `line`, so each spike IS evaluated.
          // But a WINNING spike parked on a step boundary masks that region's
          // real loss for every other run in it (yes@34 +100 hides the -100 the
          // step book pays at 35). Probe each boundary half a run higher too:
          // a step reads the same there, a spike is worth nothing off its exact
          // run, so the region shows its true spike-free value. Not a real run
          // — only a probe of a piecewise-constant function.
          const hasBadlo = validContribs.some((c) => c.isBadlo);
          const points = IS_METER
            ? [0, ...new Set(lines.map((l) => l + METER_MAX_RUNS))]
            : [
                Math.min(...lines) - 1,
                ...new Set(lines),
                ...(hasBadlo ? [...new Set(lines)].map((l) => l + 0.5) : []),
              ];
          worstCase = Math.min(...points.map(pnlAt));
        }
        worstCase = Math.round(worstCase * 100) / 100;

        // The two legacy aggregates above are bhav-derived and meaningless for
        // a ramp. On a meter they are the ramp's ENDS instead: runs never
        // reaching the line vs. runs running all the way to the cap.
        if (IS_METER && validContribs.length) {
          const capEnd = Math.max(...validContribs.map((c) => c.line)) + METER_MAX_RUNS;
          newExposures[layword] = Math.round(pnlAt(0) * 100) / 100;
          newExposures[backword] = Math.round(pnlAt(capEnd) * 100) / 100;
        }

        // sel holds the signed worst-case P&L (negative => liability to block)
        if(market_type === 'fancy1' || market_type === 'oddeven') {
          newExposures[sel] = Math.min(layExp, backExp);
        }
        else{
        newExposures[sel] = worstCase;
        }

        console.log('[FANCY EXPOSURE TRACK]', {
          selection: sel,
          betType: betTypeLower,
          stake: S,
          layBhav: L,
          backBhav: B,
          layExposure: layExp,
          backExposure: backExp,
          worstCase,
          openBets: existingBets.length + 1,
        });
      }
    }




    else if (normGameType === 'MO') {

      newExposures = calculateRunnerExposure({
        runners,
        selectedRunner: sel,
        stake,
        odd: oddN,
        betType: betTypeLower,
        oldExposures
      });
    } else if (normGameType === 'BM') {
      // BOOKMAKER (two-way) using normalized odds
      const newodds = normalizeOdds(oddN);
      console.log(`Normalized BM odds: ${oddN} → ${newodds}`);


      newExposures = calculateRunnerExposure({
        runners,
        selectedRunner: sel,
        stake,
        odd: newodds,
        betType: betTypeLower,
        oldExposures
      });
    } else if (isNonFancyMarket(market_type)) {
      let profit = 0
      let layLiab = 0
      // (oddN - 1) and (oddN / 100) are not exact in binary float — 1.01 - 1 is
      // 0.010000000000000009, which at a 100k stake becomes 1000.0000000000009 and
      // fails the wallet check against a real 1000.00 balance ("Bet not confirm
      // check balance." on a lay the user can afford exactly). Money is 2dp, so
      // round here: the exposure rows and the balance check both then see the true
      // amount instead of a phantom fraction of a paisa.
      if (market_type === 'Tied Match') {
        let new_odds = oddN / 100
        profit = Math.round(stake * (new_odds) * 100) / 100;
        layLiab = Math.round(stake * (new_odds) * 100) / 100;

      } else {
        profit = Math.round(stake * (oddN - 1) * 100) / 100;
        layLiab = Math.round(stake * (oddN - 1) * 100) / 100;

      }


      // ✅ If Draw is selected, ALWAYS update Draw exposure (regardless of count)
      if (isDrawSel) {

        if (betTypeLower === 'back' || betTypeLower === 'yes' || betTypeLower === 'Yes') {
          newExposures['The Draw'] = (oldExposures['The Draw'] || 0) + profit;
          newExposures[team_one] = (oldExposures[team_one] || 0) - stake;
          newExposures[team_two] = (oldExposures[team_two] || 0) - stake;
        } else {
          newExposures['The Draw'] = (oldExposures['The Draw'] || 0) - layLiab;
          newExposures[team_one] = (oldExposures[team_one] || 0) + stake;
          newExposures[team_two] = (oldExposures[team_two] || 0) + stake;
        }
      } else {
        // selection is one of the teams
        const otherTeam = sel === team_one ? team_two : team_one;

        if (betTypeLower === 'back') {
          newExposures[sel] = (oldExposures[sel] || 0) + profit;
          newExposures[otherTeam] = (oldExposures[otherTeam] || 0) - stake;
          // Update Draw if it exists in oldExposures OR if count is 3
          if (count == 3 || oldExposures['The Draw'] !== undefined) {
            newExposures['The Draw'] = (oldExposures['The Draw'] || 0) - stake;
          }
        } else {
          newExposures[sel] = (oldExposures[sel] || 0) - layLiab;
          newExposures[otherTeam] = (oldExposures[otherTeam] || 0) + stake;
          if (count == 3 || oldExposures['The Draw'] !== undefined) {
            newExposures['The Draw'] = (oldExposures['The Draw'] || 0) + stake;
          }
        }
      }
    }
    else if (isFancyMatch(market_type, marketsforBMfancy)) {
      const newodds = normalizeOdds(oddN);
      console.log(`Normalized BM odds: ${oddN} → ${newodds}`);
      newExposures = calculateRunnerExposure({
        runners,
        selectedRunner: sel,
        stake,
        odd: newodds,
        betType: betTypeLower,
        oldExposures
      });
    }
    else if (isFancyMatch(market_type, marketforfancywithbigrunners)) {

      newExposures = calculateRunnerExposure({
        runners,
        selectedRunner: sel,
        stake,
        odd: oddN,
        betType: betTypeLower,
        oldExposures
      });
    }
    else {
      throw new Error(`bet is closed for this market`);
    }

    console.log('NEW EXPOSURES:', newExposures);

    // WALLET BLOCK - Calculate balance change
    let balanceChange = 0; // +deduct, -release

    // fancy1 no longer takes a flat stake deduction — it now goes through the
    // ladder worst-case above, so the wallet must follow the same signed
    // exposure delta as every other fancy market.
    if (isFancyMarketType) {
      const oldNegs = Object.entries(oldExposures)
        .filter(([key, val]) => key === sel && val < 0)
        .map(([, val]) => val);

      const newNegs = Object.entries(newExposures)
        .filter(([key, val]) => key === sel && val < 0)
        .map(([, val]) => val);
      const oldMax = oldNegs.length ? Math.abs(Math.min(...oldNegs)) : 0;
      const newMax = newNegs.length ? Math.abs(Math.min(...newNegs)) : 0;
      const liabInc = newMax - oldMax;

      console.log('LIABILITY CALCULATION (MO/BM):');
      console.log('- Old liabilities:', oldNegs);
      console.log('- New liabilities:', newNegs);
      console.log('- Old total liability (blocked):', oldMax);
      console.log('- New total liability (to block):', newMax);
      console.log('- Liability change:', liabInc);

      if (Object.keys(oldExposures).length === 0) balanceChange = newMax;
      else if (liabInc > 0) balanceChange = liabInc;
      else if (liabInc < 0) balanceChange = liabInc; // negative → release

      if (balanceChange > 0 && currentInr < balanceChange) throw new Error('Bet Not Confirm Check Exposure Limit And Balance');

    }
    else {
      // MO/BM — max negative liability delta
      const oldNegs = Object.values(oldExposures).filter(x => x < 0);
      const newNegs = Object.values(newExposures).filter(x => x < 0);
      const oldMax = oldNegs.length ? Math.abs(Math.min(...oldNegs)) : 0;
      const newMax = newNegs.length ? Math.abs(Math.min(...newNegs)) : 0;
      const liabInc = newMax - oldMax;

      console.log('LIABILITY CALCULATION (MO/BM):');
      console.log('- Old liabilities:', oldNegs);
      console.log('- New liabilities:', newNegs);
      console.log('- Old total liability (blocked):', oldMax);
      console.log('- New total liability (to block):', newMax);
      console.log('- Liability change:', liabInc);

      if (Object.keys(oldExposures).length === 0) balanceChange = newMax;
      else if (liabInc > 0) balanceChange = liabInc;
      else if (liabInc < 0) balanceChange = liabInc; // negative → release

      if (balanceChange > 0 && currentInr < balanceChange) throw new Error('Bet not confirm check balance.');
    }

    console.log('FINAL BALANCE CHANGE:', balanceChange, '(+deduct, -release)');

    //=============================================================================================
    // ✅ STEP 6:                    UPSERT MARKET EXPOSURE OF THE USER
    //============================================================================================
    for (const [name, amt] of Object.entries(newExposures)) {
      await UserExposure.upsert(
        {
          user_id,
          match_id,
          team_name: name,
          exposure_amount: amt,
          match_title,
          game_type: exposureGameType,
          event_id: eventid,
          category: "sports"
        },
        { transaction }
      );
    }

    console.log("het");

    // Calculate single bet liability for record keeping
    let singleBetLiability;
    if (market_type === 'oddeven') {
      // Odd/Even are two backs on one 50/50 line — a losing bet costs its
      // stake on EITHER side, so both sides risk exactly `stake`. Sharing
      // fancy1's `oddN * stake` booked a 100-stake Even bet at 195 risk, which
      // is what betFinancialsHelper showed as its debit and what settlement
      // paid out. The exposure block already holds 100 either way (see the
      // oddeven branch in the fancy block above) — this brings `liability`
      // into line with it.
      singleBetLiability = stake;
    }
    else if (market_type === 'fancy1') {
      singleBetLiability = (betTypeLower === 'back' || betTypeLower === 'yes') ? stake : (stake * (oddN - 1)); // lay loses stake*(odds-1), same as the exposure block
    }
    else if (market_type === 'Tied Match') {
      let new_odds = oddN / 100
      singleBetLiability = (betTypeLower === 'back') ? stake : stake * new_odds;

    }
    else if (normGameType === 'MO' || marketsfornonfancy.includes(market_type)) {
      singleBetLiability = (betTypeLower === 'back') ? stake : stake * (oddN - 1);
    } else if ((normGameType === 'MO') || (normGameType === 'BM')) {
      const newodds = normalizeOdds(oddN);
      singleBetLiability = (betTypeLower === 'back') ? stake : stake * (newodds - 1);
    } else if (bigRunnerSessionMarket.test(market_type)) {
      // Runner-ladder session market at decimal odds — liability mirrors
      // calculateRunnerExposure, not the bhav formula below (size here is
      // feed volume, not a bhav).
      singleBetLiability = (betTypeLower === 'back' || betTypeLower === 'yes') ? stake : stake * (oddN - 1);
    } else if (isLineMarket(market_type)) {
      // Line markets are EVENS: a losing bet costs its stake on EITHER side.
      // This used to fall through to the bhav formula below, and because a line
      // market's `size` is feed VOLUME at this point (it is zeroed a few lines
      // later, AFTER this runs) a 100-stake `no` recorded liability 8896.20.
      singleBetLiability = stake;
    } else if (isMeterMarket(market_type)) {
      // Meter is a ramp, so the risk is the ramp's low point, not a bhav:
      // `no` risks the full 150-run tail, `yes` risks the run line itself
      // (runs = 0). Same number the worst-case block above blocks.
      singleBetLiability = meterLiability({ line: oddN, stake, betType: betTypeLower });
    } else if (isBadlo) {
      // Badlo is EVENS on a single run, not a bhav payout: a `no` leg loses its
      // stake if the session lands on its run and nothing otherwise, a `yes`
      // leg can only ever win. Falling through to the bhav formula below would
      // have charged a `no` stake*size/100.
      singleBetLiability = badloLiability({ stake, betType: betTypeLower });
    } else {
      // Session/fancy markets bet as yes/no: a losing YES costs its stake
      // (like back); a losing NO costs stake*bhav/100 (like lay).
      singleBetLiability = (betTypeLower === 'back' || betTypeLower === 'yes') ? stake : (size * stake) / 100;
    }
    console.log("tesr", singleBetLiability);

    let fixed = 0;
    // if (balanceChange < 0) {
    //   fixed = 1;
    // }

    if (!isFancyMarketType) {
      size = 0;
    }

    // Line markets persist size 0 — their rate lives nowhere on the row and
    // every consumer prices them off the STAKE (evens). This used to enumerate
    // over counts and, like marketsforfancy above, missed 15/25/35/45: a
    // "2nd Innings 15 Overs Line" bet kept the feed's fractional volume and the
    // INTEGER `size` column rejected the insert with
    //   invalid input syntax for type integer: "2.45"
    // Match by SHAPE so a new over count can never slip through again.
    if (isLineMarket(market_type)) {
      size = 0;
    }

    // A badlo leg carries its bhav only as back_size/lay_size, so `size` arrived
    // 0 and the statement printed "-" for it. Store the bhav of the leg's own
    // side. Display only: every badlo money path prices off the stake.
    if (isBadlo && !(Number(size) > 0)) {
      size = Number((betTypeLower === 'yes' || betTypeLower === 'back') ? back_size : lay_size) || 0;
    }

    // Belt and braces: `size` is an INTEGER column but the feed quotes volume
    // with decimals on plenty of markets. A fractional value 500s the whole
    // placement, so round it here. Bhav-carrying markets quote whole numbers
    // (100/110/95), and every money figure above was already computed from the
    // pre-rounded value — this only affects what is stored.
    size = Number.isFinite(Number(size)) ? Math.round(Number(size)) : 0;

    // Line/session markets (e.g. "1st Innings 20 Overs Line") sometimes arrive with
    // game_type='MATCH'/'MO' + bet_type back/lay because the client doesn't tag them
    // fancy. They MUST be persisted as FAN + yes/no so the settlement worker routes
    // them to resolveFancyWinner (the line math) instead of resolveMobmWinner.
    // IMPORTANT: exposure, wallet (balanceChange) and singleBetLiability above are all
    // keyed on market_type (marketsforfancy) — NOT on game_type — so they already ran
    // the correct fancy path. Overriding only these two persisted fields changes no
    // money computation; betTypeLower (used by the exposure block) is left untouched.
    const storedGameType = isFancyMarketType ? "FAN" : normGameType;

    // Insert bet (use converted bet_type for fancy)
    const finalBetType = ((game_type === "FAN" || isFancyMarketType) && bet_type)
      ? (bet_type.toLowerCase() === "back" ? "yes" : bet_type.toLowerCase() === "lay" ? "no" : bet_type)
      : bet_type;

    //=============================================================================================
    // ✅ STEP 7:                  SAVING BET TO DATABASE
    //=============================================================================================   

    const startTime = match_start_time || new Date();

    const newBet = await SportsBet.create(
      {
        user_id,
        game_type: storedGameType,
        match_id,
        match_title,
        team_one,
        team_two,
        selection_name,
        category: category || "1",
        bet_type: finalBetType,
        odds: oddN,
        stake_amount: stake,
        original_currency: original_currency || "INR",
        original_amount: original_amount || stake,
        usd_amount: usd_amount || (await inrToUsd(stake)),
        liability: singleBetLiability,
        match_start_time: startTime,
        exposure_after_bet: Math.max(0, ...Object.values(newExposures).filter(v => v < 0).map(v => Math.abs(v)), 0),
        status: "open",
        eventid,
        ip_address,
        browser,
        fancy_name: fancy_name || "NULL",
        fixed: fixed,
        counts: count,
        sport_id: sid,
        fancy_name: fancy_name || "NULL",
        fixed: fixed,
        counts: count,
        sport_id: sid,
        market_type: market_type,
        unmatched: unmatched || false,
        unmatched_odds: unmatched_odds || null,
        is_cashout: is_cashout === true,
        size: size,
        runners: runners,
        gtype: gtype || null,
        badlo: isBadlo,
        league_name: effectiveLeagueName,
        // placeCombinedBet stamps both legs of a badlo swap with ONE time — they
        // are a single click, and the statement lists them as one pair.
        ...(options.createdAt ? { created_at: options.createdAt } : {}),
      },
      { transaction }
    );

    //=============================================================================================
    // ✅ STEP 8: [PLATFORM SPECIFIC: DIAMOND] WALLET UPDATE : Deduct or Release cash+credit concept [BP]
    //=============================================================================================

    await walletUpdate(wallet, balanceChange, transaction, {
      user_id,
      match_title,
      selection_name,
      market_type,
      game_type,
      match_id,
      eventid,
      sid,
      newBet
    });

    // ========================================================================================
    // ✅ STEP 9:  CALCULATE NET EXPOSURE OF THIS BET (most negative among 2-3 outcomes)
    // ========================================================================================
    // Get all exposures for this match from newExposures
    const betExposureValues = Object.values(newExposures);
    console.log('NEW EXPOSURES FOR THIS BET:', newExposures);
    console.log('EXPOSURE VALUES:', betExposureValues);

    // Find the net exposure of this bet: pick the most negative (minimum value)
    let betNetExposure = 0;
    if (betExposureValues.length > 0) {
      // Get the minimum value (most negative = highest liability)
      const minValue = Math.min(...betExposureValues);
      // Take absolute value to represent liability magnitude
      betNetExposure = minValue < 0 ? Math.abs(minValue) : 0;
    }
    console.log('NET EXPOSURE OF THIS BET:', betNetExposure);

    // ========================================================================================
    // ✅ STEP 10:              UPSERT TOTAL EXPOSURE RECORD
    // ========================================================================================
    const exposureResults = await sequelize.query(TOTAL_EXPOSURE_SQL, {
      replacements: { user_id },
      type: sequelize.QueryTypes.SELECT,
      transaction
    });

    const totalUserExposure = parseFloat(exposureResults[0]?.total_exposure) || 0;
    console.log("Calculated Total User Exposure (Net):", totalUserExposure);



    await TotalExposure.upsert(
      {
        user_id,
        total_exposure: totalUserExposure
      },
      { transaction }
    );
    console.log(`✅ TotalExposure upserted for user ${user_id}: ${totalUserExposure}`);

    // Caller-owned transaction (combined slip): the caller commits after ALL
    // legs succeed, so the slip is all-or-nothing.
    if (!externalTx) await transaction.commit();

    const newBalance = balanceChange !== 0 ? currentInr - balanceChange : currentInr;

    console.log('Transaction completed successfully');
    console.log('Old balance:', currentInr);
    console.log('New balance:', newBalance);
    console.log('Actual balance delta:', newBalance - currentInr);

    return res.json({
      success: true,
      exposure: { [match_id]: { match_title, teams: newExposures } },
      balanceDelta: newBalance - currentInr,
      oldBalance: currentInr,
      newBalance: newBalance,
      totalExposure: totalUserExposure
    });

  } catch (err) {
    if (!externalTx) await transaction.rollback();
    console.error("PLACE BET ERROR:", err.message);
    return res.status(400).json({ success: false, error: err.message });
  }
};

//======================================================================================================
//-------------------------   COMBINED (DUTCHED) MULTI-RUNNER BET  -------------------------------------
//======================================================================================================
// POST /api/user/place-combined   { bets: [ <same payload shape as /place>, ... ] }
//
// One stake split across 2+ runners of ONE market so that whichever selected
// runner wins, the return is the same. Every leg runs through the same
// placeBet — all the usual locks, limits, exposure, wallet and ledger logic —
// inside ONE transaction, so the slip is ALL-OR-NOTHING: if any leg is
// rejected (suspended runner, over max, insufficient balance), nothing is
// stored and the wallet is untouched.

const MAX_COMBINED_LEGS = 10;

// Minimal res stub so placeBet's responses can be captured per leg.
const makeLegRes = () => ({
  statusCode: 200,
  body: null,
  status(code) { this.statusCode = code; return this; },
  json(payload) { this.body = payload; return this; },
});

export const placeCombinedBet = async (req, res) => {
  let transaction = null;
  try {
    const user_id = req.user?.account?.id;
    if (!user_id) return res.status(400).json({ success: false, error: "User ID is required" });

    const legs = Array.isArray(req.body?.bets) ? req.body.bets : null;
    if (!legs || legs.length < 2) {
      return res.status(400).json({ success: false, error: "A combined bet needs at least 2 selections" });
    }
    if (legs.length > MAX_COMBINED_LEGS) {
      return res.status(400).json({ success: false, error: `A combined bet supports at most ${MAX_COMBINED_LEGS} selections` });
    }

    const first = legs[0] || {};

    // A combined price is only meaningful inside ONE market.
    if (!legs.every(l => String(l?.eventid) === String(first.eventid) && String(l?.match_id) === String(first.match_id))) {
      return res.status(400).json({ success: false, error: "All combined selections must belong to the same market" });
    }

    // A badlo swap is the ONE combined slip that breaks both rules below: its
    // two legs sit on the SAME runner (different exact runs) and take OPPOSITE
    // sides — +stake on the run the punter took, -stake on the run they gave
    // up. Everything else here (one market, positive stakes, all-or-nothing
    // transaction) still applies. See helper/badloMarket.js.
    const isBadloSlip = legs.every(l => isBadloBet(l));

    // Mixing sides is not a dutch.
    const firstSide = String(first.bet_type || '').toLowerCase();
    if (!isBadloSlip && !legs.every(l => String(l?.bet_type || '').toLowerCase() === firstSide)) {
      return res.status(400).json({ success: false, error: "All combined selections must be the same bet type (all back or all lay)" });
    }

    // Distinct, non-empty selections — duplicates would double-count exposure
    // on one outcome.
    const selNames = legs.map(l => String(l?.selection_name || '').trim());
    if (selNames.some(s => !s)) {
      return res.status(400).json({ success: false, error: "Every combined selection needs a selection name" });
    }
    if (!isBadloSlip && new Set(selNames.map(s => s.toLowerCase())).size !== selNames.length) {
      return res.status(400).json({ success: false, error: "Combined selections must be distinct runners" });
    }
    // Badlo distinctness is per RUN, not per runner: two legs on the same run
    // would stack into one bigger spike instead of a swap.
    if (isBadloSlip) {
      const runs = legs.map(l => Number(l?.odds));
      if (runs.some(r => !Number.isFinite(r) || r <= 0)) {
        return res.status(400).json({ success: false, error: "Every badlo selection needs a run" });
      }
      if (new Set(runs).size !== runs.length) {
        return res.status(400).json({ success: false, error: "Badlo selections must be on distinct runs" });
      }
    }

    // Stakes must be finite and > 0; the exposure walk needs the full field.
    if (legs.some(l => !Number.isFinite(Number(l?.stake_amount)) || Number(l?.stake_amount) <= 0)) {
      return res.status(400).json({ success: false, error: "Invalid stake on a combined selection" });
    }
    if (legs.some(l => !Array.isArray(l?.runners) || !l.runners.length)) {
      return res.status(400).json({ success: false, error: "Combined selections are missing the runner list" });
    }

    // A dutch SPLITS one stake across its legs, so the slip total IS the money
    // at risk. A badlo swap does not split: both legs carry the SAME full
    // stake, and because the two runs are mutually exclusive only one of them
    // can ever pay — the risk is one stake, not two. Summing them would have
    // rejected a punter at half the market's real maximum.
    const totalStake = isBadloSlip
      ? Math.max(...legs.map(l => Number(l.stake_amount)))
      : legs.reduce((s, l) => s + Number(l.stake_amount), 0);

    // Market MIN and MAX are checked against the SLIP TOTAL: an 8.37 leg of a
    // 100 slip must not trip a 100 minimum, and splitting must not be a way
    // around the per-bet cap. (Per-leg min is skipped via opts.skipMinStake.)
    try {
      const limits = await resolveMarketLimits({
        eventid: first.eventid, sid: first.sid, match_id: first.match_id,
        mname: first.mname, market_type: first.market_type, selection_name: first.selection_name
      });
      if (limits) {
        console.log(`[placeCombinedBet] Limits for ${limits.marketName}: min=${limits.minLimit} max=${limits.maxLimit} total=${totalStake}`);
        if (limits.minLimit > 0 && totalStake < limits.minLimit) {
          return res.status(400).json({ success: false, error: `Minimum bet amount is ${limits.minLimit}` });
        }
        if (limits.maxLimit > 0 && totalStake > limits.maxLimit) {
          return res.status(400).json({ success: false, error: `Maximum bet amount is ${limits.maxLimit}` });
        }
      }
    } catch (limitErr) {
      console.warn('[placeCombinedBet] Market limits lookup failed (non-blocking):', limitErr.message);
    }

    // Live feed checks per leg BEFORE any transaction opens (the checks poll
    // upstream). /place gets these in betBuffer.js; a combined slip used to go
    // straight to placeBet at the client's odds (GEN-16). Any rejected leg
    // rejects the slip. On accept the leg carries the feed-decided odds.
    for (const leg of legs) {
      const d = await checkBetLive(leg);
      if (!d.accept) {
        console.log(`[placeCombinedBet] ✗ rejected user=${user_id} gmid=${leg.eventid} market=${leg.match_id} sel=${leg.selection_id} code=${d.code}`);
        return res.status(400).json({ success: false, error: `${leg.selection_name}: ${d.message}`, code: d.code });
      }
    }

    transaction = await sequelize.transaction();

    // A badlo swap is ONE click: both legs share one placement time.
    const slipCreatedAt = isBadloSlip ? new Date() : null;

    const legResults = [];
    for (const leg of legs) {
      const legReq = {
        user: req.user,
        headers: req.headers,
        connection: req.connection,
        ip: req.ip,
        body: leg,
      };
      const legRes = makeLegRes();
      await placeBet(legReq, legRes, { transaction, skipMinStake: true, createdAt: slipCreatedAt });
      if (!legRes.body || legRes.body.success !== true) {
        const msg = legRes.body?.error || legRes.body?.message || 'Bet rejected';
        throw new Error(`${leg.selection_name}: ${msg}`);
      }
      legResults.push(legRes.body);
    }

    await transaction.commit();
    transaction = null;

    const last = legResults[legResults.length - 1];
    return res.json({
      success: true,
      legs: legResults.length,
      exposure: last?.exposure,
      balanceDelta: legResults.reduce((s, r) => s + Number(r?.balanceDelta || 0), 0),
      newBalance: last?.newBalance,
      totalExposure: last?.totalExposure,
    });

  } catch (err) {
    if (transaction) {
      try { await transaction.rollback(); } catch (rbErr) { console.error('COMBINED BET ROLLBACK ERROR:', rbErr.message); }
    }
    console.error("PLACE COMBINED BET ERROR:", err.message);
    return res.status(400).json({ success: false, error: err.message });
  }
};

//=============================================================================================



// " - Sep 22 2026 2:35AM" tail of a racing match_title (upstream may double
// the space before a 1-digit hour).
const RACE_TITLE_TIME = /\s+-\s+[A-Z][a-z]{2} \d{1,2} \d{4}\s+\d{1,2}:\d{2}\s*[AP]M$/;

// Cricket-style casino tables also appear in the header's My Market modal, like
// a cricket match (user, 2026-10-10): one box per round, one row per market with
// its open-bet count, and a link to the table (`route`, which the modal follows).
// Cricket Match 20-20 (cmatch20) is left out on purpose: its bets must not show in
// the modal (user, 2026-10-10).
const CRICKET_CASINO_GAMES = ["superover", "superover2", "superover3", "cricketv3", "ballbyball"];
const SUPEROVER_SESSION_SEL = /^\d+\s+over\s+run/i;
const SUPEROVER_FANCY1_SEL = /^(0\.\d\s+over|common)\s/i;

// Market a cricket-casino bet sits in: Super Over family by the selection
// shape (Bookmaker / Fancy / Fancy1); the other tables by the bet's mtype.
const cricketCasinoMarket = (bet) => {
  const sel = String(bet.selection || "").trim();
  if (SUPEROVER_SESSION_SEL.test(sel)) return "Fancy";
  if (SUPEROVER_FANCY1_SEL.test(sel)) return "Fancy1";
  if (["superover", "superover2", "superover3", "cricketv3"].includes(bet.game_name)) return "Bookmaker";
  const m = String(bet.mtype || "").trim();
  return m ? m.charAt(0).toUpperCase() + m.slice(1) : "Match";
};

// The live event name of a table's CURRENT round ("ENG Vs RSA Super Over" —
// feed t1.ename) from the warmed feed key, or null (other round / no feed).
async function liveCasinoEventName(game, round) {
  try {
    const raw = await redis.get(casinoAllDataKey(game));
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    const feed = parsed?.data?.t1 || parsed?.data?.t2 ? parsed.data : (parsed?.data?.data || parsed);
    const t1 = Array.isArray(feed?.t1) ? feed.t1[0] : feed?.t1;
    if (!t1?.ename || String(t1.gmid ?? t1.mid ?? "") !== String(round)) return null;
    return String(t1.ename).trim();
  } catch {
    return null;
  }
}

// A bet's created_at as the IST wall clock "YYYY-MM-DD HH:mm:ss" the modal
// prints. Explicitly Asia/Kolkata — the process timezone printed it 3h30 off.
function istWallClock(value) {
  const d = new Date(value);
  if (!value || Number.isNaN(d.getTime())) return "";
  const p = Object.fromEntries(new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Kolkata", year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false,
  }).formatToParts(d).map((x) => [x.type, x.value]));
  const hour = p.hour === "24" ? "00" : p.hour;
  return `${p.year}-${p.month}-${p.day} ${hour}:${p.minute}:${p.second}`;
}

async function cricketCasinoExposureRows(userId) {
  const bets = await CasinoBet.findAll({
    where: {
      user_id: String(userId),
      game_name: { [Op.in]: CRICKET_CASINO_GAMES },
      status: { [Op.in]: ["open", "processing"] },
      [Op.or]: [{ result_status: null }, { result_status: "" }],
    },
    order: [["created_at", "ASC"], ["id", "ASC"]],
    raw: true,
  });
  // Box time = the round's FIRST bet (reference: 03:00:07 for a round whose
  // Fancy1 bets came later) — bets are read oldest first, so the first seen wins.
  const roundStart = new Map();
  for (const b of bets) {
    const k = `${b.game_name}:${String(b.event_id || b.round_id || "")}`;
    if (!roundStart.has(k)) roundStart.set(k, b.created_at);
  }
  const rows = new Map(); // `${game}:${round}::${market}` -> row
  for (const b of bets) {
    const market = cricketCasinoMarket(b);
    const round = String(b.event_id || b.round_id || "");
    const key = `${b.game_name}:${round}::${market}`;
    if (!rows.has(key)) {
      // Reference title: "cricket -> ENG Vs RSA Super Over / 62096138712" —
      // the round's live event name (table name when the feed has moved on)
      // and the round id.
      const label = (await liveCasinoEventName(b.game_name, round))
        || TableCasino.FIXED_TABLES.find((t) => t.tableid === b.game_name)?.tablename || b.game_name;
      const title = `${label} / ${round}`;
      rows.set(key, {
        sport_id: 4,
        sport_name: "cricket",
        event_type: "Casino",
        event_name: title,
        match_name: title,
        market_name: market,
        match_id: round,
        event_id: round,
        match_time: istWallClock(roundStart.get(`${b.game_name}:${round}`)),
        league_name: "",
        route: `/casino/${b.game_name}`,
        trade: 0,
      });
    }
    rows.get(key).trade += 1;
  }
  // Newest round first; inside a round Bookmaker → Fancy → Fancy1 (reference).
  const order = { Bookmaker: 0, Fancy: 1, Fancy1: 2 };
  return [...rows.values()].sort((a, b) =>
    (b.match_time || "").localeCompare(a.match_time || "")
    || String(a.event_id).localeCompare(String(b.event_id))
    || (order[a.market_name] ?? 9) - (order[b.market_name] ?? 9));
}

export const getUserBets = async (req, res) => {
  const user_id = req.user.user_id || req.user.actor.id;
  console.log("Fetching exposure breakdown for USER ID:", user_id);

  try {
    // Source of truth = the user's OPEN bets (one row PER BET). The old version
    // counted UserExposure rows, which are per-runner (a 2-runner market has 2
    // rows), so a single bet showed a count of 2 — and it grouped only by match,
    // so the desc row repeated the match title instead of the market name. We now
    // group by (match, market) and count the actual bets → one row per market
    // with the true bet count (reference "My Market" behaviour).
    const bets = await SportsBet.findAll({
      where: { user_id: String(user_id), status: "open" },
      // Reference order: latest-starting match first; markets inside a match by
      // market id (match_id) ascending, the feed's market order, the same rule as
      // Market Analysis. match_id is a digit string, so sort by length and then
      // by value to get numeric order without a cast.
      order: [
        ["match_start_time", "DESC"],
        // same start time → event id ASC, numeric (reference puts Podoroska
        // 4937… before Guyana 8952…, both 04:30)
        [sequelize.literal('LENGTH("eventid")'), "ASC"],
        ["eventid", "ASC"],
        [sequelize.literal('LENGTH("match_id")'), "ASC"],
        ["match_id", "ASC"],
        ["created_at", "ASC"],
      ],
    });

    // Racing: a bet placed from a stale tab saved the runner list as its title.
    // Use any "Venue - date" title from the same race for the whole group.
    const raceTitle = {};
    for (const b of bets) {
      if ([10, 65].includes(Number(b.sport_id)) && RACE_TITLE_TIME.test(b.match_title || '')) {
        raceTitle[b.eventid] ??= b.match_title;
      }
    }

    const byKey = {}; // key: `${matchId}::${market}`
    for (const b of bets) {
      const matchId = String(b.match_id ?? b.eventid ?? '');
      const market = b.market_type || b.game_type || '--';
      const key = `${matchId}::${market}`;
      if (!byKey[key]) {
        // Racing title is "Venue - Sep 22 2026 2:35AM" (statement format); the
        // reference My Market heading shows the venue only.
        const title = [10, 65].includes(Number(b.sport_id))
          ? String(raceTitle[b.eventid] || b.match_title || '').replace(RACE_TITLE_TIME, '')
          : b.match_title;
        byKey[key] = {
          sport_id: Number(b.sport_id) || 4,
          sport_name: sportNameById(Number(b.sport_id) || 4),
          event_type: b.category === 'casino' ? 'Casino' : (b.game_type || 'Sports'),
          event_name: title || 'Unknown Match',
          match_name: title || 'Unknown',
          market_name: market,          // the actual market (Bookmaker, Tied Match, …)
          match_id: matchId,
          event_id: b.eventid || matchId,
          // Naive IST wall clock — see helper/naiveLocalTime.js
          match_time: toNaiveLocalTime(b.match_start_time) || '',
          // feed cname — the modal picks /tp-virtual-cricket vs /gamedetails on it
          league_name: b.league_name || '',
          trade: 0,                     // number of OPEN bets in this market
        };
      }
      byKey[key].trade += 1;
    }

    const casinoRows = await cricketCasinoExposureRows(user_id);

    return res.status(200).json({
      success: true,
      // Cricket-casino rounds are live right now — list them first.
      data: [...casinoRows, ...Object.values(byKey)],
    });

  } catch (error) {
    console.error("Get User Exposure Breakdown Error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch exposure breakdown"
    });
  }
};





// ------------------------ OTHER CONTROLLER FUNCTIONS ------------------------
export const getUserExposures = async (req, res) => {
  try {
    const { user_id } = req.params;
    const exposures = await UserExposure.findAll({ where: { user_id } });

    const out = {};
    exposures.forEach((e) => {
      if (!out[e.match_id]) out[e.match_id] = { match_title: e.match_title, teams: {} };
      out[e.match_id].teams[e.team_name] = Number(e.exposure_amount);
    });

    return res.json({ success: true, exposures: out });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, error: "Could not fetch exposures" });
  }
};

export const getOpenBets = async (req, res) => {
  const { user_id, match_id } = req.params;
  try {
    const bets = await SportsBet.findAll({
      where: { user_id, match_id, status: "open" },
    });
    return res.json({ success: true, bets });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, error: "Could not fetch open bets" });
  }
};

export const getWalletBalance = async (req, res) => {
  const { uuid } = req.params;
  try {
    const wallet = await Wallet.findOne({ where: { user_id: uuid } });
    if (!wallet) return res.status(404).json({ success: false, error: "Wallet not found" });
    return res.json({ success: true, balance: +wallet.inr });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, error: "Server error" });
  }
};

export const settleBets = async () => {
  try {
    // TODO: implement using Sequelize models
    console.log("settleBets function called - migrate raw SQL to Sequelize models");
  } catch (err) {
    console.error("settleBets error:", err);
  }
};

//======================================================================================================
//-------------------------   CANCEL BET (unmatched only)   -------------------------------------------
//======================================================================================================
// POST /cancel-bet  { bet_id }
// Only the user's OWN, OPEN, UNMATCHED bets can be cancelled. The bet row is
// soft-cancelled (status='cancelled' — NEVER deleted, audit trail stays), then
// the market's exposure is RECOMPUTED from the remaining open bets in that
// market. Blindly clearing exposure would also free the user's matched-bet
// liability in the same market — that is the exact bug this replay avoids.
export const cancelBet = async (req, res) => {
  const transaction = await sequelize.transaction();
  try {
    const user_id = req.user.account.id;
    if (!user_id) throw new Error("User ID is required");

    const { bet_id } = req.body;
    if (!bet_id) throw new Error("bet_id is required");

    // ── Step 1: fetch + verify the bet ──
    const bet = await SportsBet.findOne({
      where: { id: bet_id },
      transaction,
      lock: transaction.LOCK.UPDATE,
    });
    if (!bet) {
      await transaction.rollback();
      return res.status(404).json({ success: false, error: "Bet not found" });
    }
    if (String(bet.user_id) !== String(user_id)) {
      await transaction.rollback();
      return res.status(403).json({ success: false, error: "Not your bet" });
    }
    if (bet.unmatched !== true) {
      await transaction.rollback();
      return res.status(400).json({ success: false, error: "Only unmatched bets can be cancelled" });
    }
    if (bet.status !== 'open') {
      await transaction.rollback();
      return res.status(400).json({ success: false, error: `Bet is already ${bet.status}` });
    }
    // Unmatched applies only to MATCH_ODDS-family markets — the replay below
    // uses the runner-exposure walk, which is only valid for that family.
    if (bet.game_type !== 'MO' && bet.game_type !== 'BM') {
      await transaction.rollback();
      return res.status(400).json({ success: false, error: "Only match-odds unmatched bets can be cancelled" });
    }

    console.log(`[cancelBet] user=${user_id} bet=${bet_id} market=${bet.market_type} match=${bet.match_id}`);

    // ── Step 2: soft cancel (no destroy — audit trail) ──
    bet.status = 'cancelled';
    bet.result_status = 'cancelled';
    bet.updated_at = new Date();
    await bet.save({ transaction });

    // ── Step 3: recompute exposure from the REMAINING open bets of this market ──
    // Line markets file their rows under 'fancy2' — same pair placement wrote.
    const cancelExpGameType = exposureIdentity({ marketType: bet.market_type, selectionName: bet.selection_name, badlo: isBadloBet(bet) }).game_type;
    const oldRows = await UserExposure.findAll({
      where: { user_id, match_id: bet.match_id, game_type: cancelExpGameType },
      transaction,
      lock: transaction.LOCK.UPDATE,
    });
    const oldExposures = {};
    oldRows.forEach((r) => (oldExposures[r.team_name] = Number(r.exposure_amount)));

    // Replay only the bets that share the cancelled bet's exposure BUCKET.
    // Badlo legs keep market_type 'Normal' but are filed under game_type
    // 'badlo', so replaying them into the Normal book (or vice versa) would
    // rebuild the wrong ladder — see exposureIdentity in helper/lineMarket.js.
    const remaining = await SportsBet.findAll({
      where: {
        user_id,
        match_id: bet.match_id,
        market_type: bet.market_type,
        badlo: isBadloBet(bet),
        status: 'open',
      },
      order: [['created_at', 'ASC']],
      transaction,
    });

    let replayed = {};
    for (const b of remaining) {
      const runners = Array.isArray(b.runners) ? b.runners : [];
      if (!runners.length) continue;
      const odd = b.game_type === 'BM' ? normalizeOdds(Number(b.odds)) : Number(b.odds);
      replayed = calculateRunnerExposure({
        runners,
        selectedRunner: b.selection_name,
        stake: Number(b.stake_amount),
        odd,
        betType: (b.bet_type || '').toLowerCase(),
        oldExposures: replayed,
      });
    }

    // Every runner that had a row gets a fresh value (0 when no bets remain)
    const newExposures = {};
    for (const name of new Set([...Object.keys(oldExposures), ...Object.keys(replayed)])) {
      newExposures[name] = Number((replayed[name] || 0).toFixed(2));
    }
    console.log('[cancelBet] OLD EXPOSURES:', oldExposures);
    console.log('[cancelBet] RECOMPUTED EXPOSURES:', newExposures);

    for (const [name, amt] of Object.entries(newExposures)) {
      await UserExposure.upsert(
        {
          user_id,
          match_id: bet.match_id,
          team_name: name,
          exposure_amount: amt,
          match_title: bet.match_title,
          game_type: cancelExpGameType,
          event_id: bet.eventid,
          category: "sports",
        },
        { transaction }
      );
    }

    // ── Step 4: wallet refund = drop in worst-case liability ──
    const oldNegs = Object.values(oldExposures).filter(x => x < 0);
    const newNegs = Object.values(newExposures).filter(x => x < 0);
    const oldMax = oldNegs.length ? Math.abs(Math.min(...oldNegs)) : 0;
    const newMax = newNegs.length ? Math.abs(Math.min(...newNegs)) : 0;
    const refund = Number((oldMax - newMax).toFixed(2)); // ≥ 0 (a removed bet can't raise liability)
    console.log(`[cancelBet] Liability: old=${oldMax} new=${newMax} refund=${refund}`);

    const wallet = await Wallet.findOne({
      where: { user_id },
      transaction,
      lock: transaction.LOCK.UPDATE,
    });
    if (!wallet) throw new Error("Wallet not found");

    if (refund > 0) {
      wallet.cash = Number(wallet.cash || 0) + refund;
      if (isNaN(wallet.cash)) throw new Error("Balance calculation resulted in NaN");
      await wallet.save({ transaction });
    }
    const newBalance = Number(wallet.cash || 0);

    // // Ledger: every cancel writes an audit row (even a zero-refund one)
    // await CreditsLedger.create({
    //   user_id: String(user_id),
    //   currency: "INR",
    //   amount: refund,
    //   reason: "bet_cancelled",
    //   description: `${bet.match_title} ${bet.selection_name} (bet cancelled)`,
    //   netamount: refund,
    //   closing: newBalance,
    //   market_type: bet.market_type,
    //   match_id: bet.match_id,
    //   eventid: bet.eventid,
    //   sport_id: bet.sport_id,
    //   bet_id: bet.id,
    //   category: 'SPORTS',
    // }, { transaction });

    // ── Step 5: refresh total exposure (same query as placeBet STEP 10) ──
    const exposureResults = await sequelize.query(TOTAL_EXPOSURE_SQL, {
      replacements: { user_id },
      type: sequelize.QueryTypes.SELECT,
      transaction,
    });
    const totalUserExposure = parseFloat(exposureResults[0]?.total_exposure) || 0;
    await TotalExposure.upsert({ user_id, total_exposure: totalUserExposure }, { transaction });

    await transaction.commit();
    console.log(`[cancelBet] ✅ bet=${bet_id} refund=${refund} newBalance=${newBalance} totalExposure=${totalUserExposure}`);

    return res.json({
      success: true,
      cancelled_bet_id: bet.id,
      refund,
      newBalance,
      totalExposure: totalUserExposure,
      exposure: { [bet.match_id]: { match_title: bet.match_title, teams: newExposures } },
    });
  } catch (err) {
    await transaction.rollback();
    console.error("CANCEL BET ERROR:", err.message);
    return res.status(400).json({ success: false, error: err.message });
  }
};

// Open fancy bets for one runner — raw rows only; the ladder (run-by-run P&L
// book) math lives on the client (RunAmountModal), same per-bet step model as
// the fancy exposure tracker above.
const getFancyBets = async (req, res) => {
  try {
    const user_id = req.user.account.id;
    const { runner, match_id, event_id, sport_id, market_type } = req.query;

    if (!runner || !match_id) {
      return res.status(400).json({ success: false, error: "Missing required parameters" });
    }

    const whereClause = {
      user_id,
      [Op.or]: [
        { selection_name: { [Op.iLike]: runner.trim() } },
        { fancy_name: { [Op.iLike]: runner.trim() } },
      ],
      // match_id param carries the gmid, which bets persist in `eventid`
      eventid: String(event_id || match_id),
      status: "open",
    };
    if (sport_id) whereClause.sport_id = String(sport_id);
    // Every line market (fancy2) quotes the SAME runner name — the 6-over,
    // 20-over and 85-over rows are all "Total Runs" — so runner alone would
    // merge every one of them into a single book. market_type (the feed's
    // mname, e.g. "1st Innings 6 Overs Line") is what separates them.
    // Optional: callers that don't send it keep the old behaviour.
    if (market_type) whereClause.market_type = String(market_type);

    const bets = await SportsBet.findAll({
      where: whereClause,
      // market_type included so the client can spot fancy1/oddeven, where
      // `size` is market volume rather than a bhav
      // fancy_name carries the khado band width — the ladder needs it to draw
      // the win band (see prepareBetPayload).
      // `badlo` marks the EXACT-RUN legs: the ladder draws them as spikes, not
      // as the step every other session bet draws (helper/badloMarket.js).
      attributes: ["bet_type", "stake_amount", "odds", "size", "liability", "market_type", "fancy_name", "badlo"],
    });

    return res.json({ success: true, bets });
  } catch (err) {
    console.error("GET FANCY BETS ERROR:", err.message);
    return res.status(500).json({ success: false, error: err.message });
  }
};

// ------------------------ EXPORT ------------------------
const controller = {
  placeBet,
  placeCombinedBet,
  getUserExposures,
  getOpenBets,
  getWalletBalance,
  settleBets,
  getUserBets,
  getBufferTime,
  cancelBet,
  getFancyBets
};

export default controller;
