// ─── Post-buffer bet checks — server port of the bet slip's live checks ──────
//
// Pure functions, no I/O. These used to run ONLY in the browser, after a
// browser-side buffer, which is why a page reload during the buffer lost the
// bet (the API call never happened). betBuffer.js now holds the buffer here and
// runs these on the server's own feed poll.
//
// Kept a FAITHFUL copy of the browser versions so the two can be diffed side
// by side — change one, change the other:
//   frontend/src/components/betting/placeBet/placeBetLiveChecks.js
//     monitorOddsBuffer (the per-tick read), getFinalSuspensionStatus,
//     checkFancyOddsDrift
//   frontend/src/components/betting/placeBet/placeBetRules.js
//     normalizeName, isLaySide, feedSideFor, isBlockedGameStatus
//   frontend/src/utils/bookieFavour.js
//     isBookieFavourMarket, manualBetLiveCheck, autoBetCheck
//
// Tolerances: 0.001 everywhere, EXCEPT the fancy drift check (0.01).

import { isLineMarket } from '../helper/lineMarket.js';

const EPSILON = 0.001;
const FANCY_EPSILON = 0.01;

export const normalizeName = (s) => String(s || '').trim().toLowerCase();

export const isLaySide = (betType) => betType === 'lay' || betType === 'no';

// Line markets (fancy2 / dtype 14) show the feed's BACK tiers as "No" and its
// LAY tiers as "Yes", so the side to read is the opposite of the slip's.
export const feedSideFor = (betType, inverted = false) => {
  const lay = isLaySide(betType);
  return (inverted ? !lay : lay) ? 'lay' : 'back';
};

export function isBlockedGameStatus(gs) {
  switch (gs) {
    case 'SUSPENDED':
    case 'BALL RUNNING':
    case 'INACTIVE':
      return true;
    default:
      return false;
  }
}

export function isBookieFavourMarket(marketType) {
  const mt = String(marketType || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  return mt === 'MATCHODDS' || mt === 'BOOKMAKER' || mt === 'BOOKMAKER2' || mt === 'TIEDMATCH';
}

const findMarket = (marketList, marketId) =>
  (marketList || []).find((m) => String(m?.mid) === String(marketId)) || null;

// Resolve the runner row: by selection id when we have one, otherwise by
// normalized name, falling back to a single-runner section.
export function findRunner(mkt, selectionId, runnerName) {
  if (!mkt?.section) return null;
  if (selectionId) {
    return mkt.section.find((s) => String(s.sid) === String(selectionId)) || null;
  }
  const wantNat = normalizeName(runnerName);
  return mkt.section.find((s) => normalizeName(s.nat) === wantNat)
    || (mkt.section.length === 1 ? mkt.section[0] : null);
}

const runnerGameStatus = (runner) =>
  String(runner?.gstatus || '').toUpperCase() || String(runner?.status || '').toUpperCase();

// Market-level status — bookmaker (match1) conveys suspension ONLY per-section.
const marketBlockedStatus = (mkt) => {
  if (!mkt || String(mkt.gtype || '').toLowerCase() === 'match1') return null;
  const s = String(mkt.status || '').toUpperCase();
  return isBlockedGameStatus(s) ? s : null;
};

/**
 * One buffer tick — the body of monitorOddsBuffer's setInterval.
 * Returns:
 *   { state: 'skip' }                       no market / no runner odds (keep last)
 *   { state: 'blocked', status }            market/runner suspended, or no valid price
 *   { state: 'live', odds, size }           best price for the bet's feed side
 */
export function readBufferTick({ marketList, marketId, selectionId, betType, feedSideInverted = false }) {
  const mkt = findMarket(marketList, marketId);
  if (!mkt?.section) return { state: 'skip' };

  const mktStatus = marketBlockedStatus(mkt);
  if (mktStatus) return { state: 'blocked', status: mktStatus };

  const runner = mkt.section.find((s) => String(s.sid) === String(selectionId));
  if (!runner?.odds) return { state: 'skip' };

  const gs = runnerGameStatus(runner);
  if (isBlockedGameStatus(gs)) return { state: 'blocked', status: gs };

  const feedSide = feedSideFor(betType, feedSideInverted);
  const bestObj = runner.odds.find((o) =>
    String(o.otype || '').toLowerCase() === feedSide
    && (o.tno === 0 || o.oname === (feedSide === 'lay' ? 'lay1' : 'back1')));

  if (!bestObj || !bestObj.odds || bestObj.odds <= 0) return { state: 'blocked', status: 'NO_ODDS' };
  return { state: 'live', odds: Number(bestObj.odds), size: Number(bestObj.size) || 0 };
}

/**
 * Final suspension check — the blocking status, or null (bettable / not found).
 * strict: a market or runner MISSING from a list that was read is 'CLOSED'
 * (the feed drops a market once it is over). The browser version treats
 * missing as bettable; strict is the server-only, fail-closed reading.
 */
export function finalSuspensionStatus({ marketList, marketId, selectionId, runnerName, strict = false }) {
  const mkt = findMarket(marketList, marketId);
  if (!mkt && strict) return 'CLOSED';
  const mktStatus = marketBlockedStatus(mkt);
  if (mktStatus) return mktStatus;
  const runner = findRunner(mkt, selectionId, runnerName);
  if (!runner) return strict ? 'CLOSED' : null;
  const gs = runnerGameStatus(runner);
  return isBlockedGameStatus(gs) ? gs : null;
}

/**
 * Fancy (locked-odds) strict check: the slip odds must still exist (±0.01)
 * among the live tiers of the bet's side. Rows are matched by NAME only —
 * fancy feeds reuse sids across rows.
 */
// strict: no market / row / price on the bet's side counts as a mismatch
// (closest: null) — the slip price cannot be confirmed, so it is not taken.
export function fancyOddsDrift({ marketList, marketId, runnerName, betType, selectedOdds, feedSideInverted = false, strict = false }) {
  const result = { mismatch: false, liveSize: null };
  const unconfirmed = () => (strict ? { mismatch: true, liveSize: null, closest: null } : result);
  const mkt = findMarket(marketList, marketId);
  if (!mkt?.section) return unconfirmed();

  const wantNat = normalizeName(runnerName);
  let sectionFound = mkt.section.find((s) => normalizeName(s.nat) === wantNat);
  if (!sectionFound && mkt.section.length === 1) sectionFound = mkt.section[0];
  if (!sectionFound) return unconfirmed();

  const side = feedSideFor(betType, feedSideInverted);
  const oddsArr = sectionFound.odds || [];
  const sideTiers = oddsArr
    .filter((o) => String(o.otype || '').toLowerCase() === side)
    .map((o) => Number(o.odds))
    .filter((n) => Number.isFinite(n) && n > 0);
  if (sideTiers.length === 0) return unconfirmed();

  const closest = sideTiers.reduce((best, curr) =>
    (Math.abs(curr - selectedOdds) < Math.abs(best - selectedOdds) ? curr : best));
  if (Math.abs(closest - selectedOdds) > FANCY_EPSILON) {
    result.mismatch = true;
    result.closest = closest;
    return result;
  }

  const liveObj = oddsArr.find((o) =>
    String(o.otype || '').toLowerCase() === side && Math.abs(Number(o.odds) - closest) <= FANCY_EPSILON);
  if (liveObj?.size) result.liveSize = Number(liveObj.size);
  return result;
}

/**
 * Which buffer rules a bet gets, read from the FEED's own market — never from
 * the client's server_buffer flags (a request could set own_line / live_tracked
 * to switch the price check off). Same rules the slip uses:
 *   own_line     khado (usePlaceBetPanel namesOwnLine → isKhadoPanel)
 *   live_tracked gtype 'match' (odds editable) or a bookie-favour market
 *   line_market  gtype fancy2 / an "… Line" market (feed sides inverted)
 * null when the market is not in the list (the suspension check rejects that).
 */
export function deriveBufferFlags({ marketList, marketId }) {
  const mkt = findMarket(marketList, marketId);
  if (!mkt) return null;
  const gtype = normalizeName(mkt.gtype);
  const mname = mkt.mname || '';
  return {
    ownLine: gtype === 'khado' || normalizeName(mname) === 'khado',
    liveTracked: gtype === 'match' || isBookieFavourMarket(mname),
    lineMarket: gtype === 'fancy2' || isLineMarket(mname),
    marketType: mname,
  };
}

/** Manual (edited) bet after the buffer: E is the user's LIMIT, Y executes. */
export function manualBetLiveCheck({ betType, editedOdds, liveOdds }) {
  const accept = isLaySide(betType)
    ? liveOdds <= editedOdds + EPSILON   // Y must stay ≤ E
    : liveOdds >= editedOdds - EPSILON;  // Y must stay ≥ E
  return { accept, finalOdds: liveOdds };
}

/** Untouched price: bookie favour on MO / BM / Tied, always executes at Y. */
export function autoBetCheck({ marketType, betType, selectedOdds, currentOdds }) {
  if (!isBookieFavourMarket(marketType)) return { accept: true, finalOdds: currentOdds };
  if (betType === 'back' || betType === 'yes') {
    return { accept: currentOdds >= selectedOdds - EPSILON, finalOdds: currentOdds };
  }
  if (isLaySide(betType)) {
    return { accept: currentOdds <= selectedOdds + EPSILON, finalOdds: currentOdds };
  }
  return { accept: true, finalOdds: currentOdds };
}

/**
 * Private-data bodies nest a variable number of `data` levels (see
 * frontend hooks/useRacingData.js readMarkets). Unwrap until an array.
 */
export function readMarketList(body) {
  let node = body;
  for (let i = 0; i < 6 && node && typeof node === 'object'; i++) {
    if (Array.isArray(node)) return node;
    node = node.data;
  }
  return Array.isArray(node) ? node : null;
}
