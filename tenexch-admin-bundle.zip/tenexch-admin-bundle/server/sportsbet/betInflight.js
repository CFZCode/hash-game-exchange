// ─── In-flight bet registry (client_ref → outcome) ───────────────────────────
//
// The bet slip tags every submit with a uuid (client_ref). While the server
// holds that bet's buffer the entry is 'pending'; when placeBet answers, the
// entry keeps the outcome for OUTCOME_TTL_MS. Two uses:
//   * a page reload mid-buffer — the reloaded page asks GET /bet-result/:ref
//     and toasts what happened to the bet it lost track of;
//   * a double submit with the same ref gets the first one's answer instead of
//     placing twice.
//
// In-memory on purpose: tenexch-server runs as ONE pm2 fork process, and the
// outcome only needs to outlive a reload. The open-bets list stays the durable
// truth. A server restart forgets pending refs, and a restart mid-buffer
// also means the bet never reached placeBet, so nothing was booked.

const OUTCOME_TTL_MS = Number(process.env.BET_OUTCOME_TTL_MS) || 5 * 60 * 1000;
const REF_RE = /^[A-Za-z0-9-]{8,64}$/;

const entries = new Map(); // `${userId}:${ref}` → { state, status, body, at }

const keyOf = (userId, ref) => `${userId}:${ref}`;

export const cleanRef = (ref) => (typeof ref === 'string' && REF_RE.test(ref) ? ref : null);

function sweep() {
  const now = Date.now();
  for (const [k, e] of entries) {
    if (now - e.at > OUTCOME_TTL_MS) entries.delete(k);
  }
}
setInterval(sweep, 60 * 1000).unref();

/**
 * Claim a ref. Returns null when claimed, or the existing entry when this ref
 * was already submitted (pending or finished).
 */
export function begin(userId, ref) {
  const k = keyOf(userId, ref);
  const existing = entries.get(k);
  if (existing) return existing;
  entries.set(k, { state: 'pending', status: null, body: null, at: Date.now() });
  return null;
}

/** Record the HTTP answer placeBet (or the buffer) gave for this ref. */
export function finish(userId, ref, body, status) {
  entries.set(keyOf(userId, ref), {
    state: body?.success ? 'accepted' : 'rejected',
    status,
    body,
    at: Date.now(),
  });
}

export function get(userId, ref) {
  return entries.get(keyOf(userId, ref)) || null;
}

export default { cleanRef, begin, finish, get };
