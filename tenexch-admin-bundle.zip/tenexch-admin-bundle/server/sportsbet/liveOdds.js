// ─── Shared live-market poller for the server-side bet buffer ────────────────
//
// While a bet on a match is buffering, betBuffer.js needs that match's market
// list fresh every tick. Calling upstream per bet per tick would multiply the
// feed load by the number of concurrent bets, so ONE poller runs per gmid,
// ref-counted: acquire() starts it (or joins it), release() stops it when the
// last buffering bet on that match is done. Upstream cost is per match, not
// per bet.
//
// The source is CricketService.GetMatchPrivateData — the exact call behind
// POST /user/cricket/get-match-private-data, i.e. the list the bet slip itself
// was reading in the browser.

import CricketService from '../services/CricketService.js';
import { readMarketList } from './betBufferRules.js';

const POLL_MS = Number(process.env.LIVE_ODDS_POLL_MS) || 700;

// gmid → { sid, refs, timer, list, at, inFlight }
const pollers = new Map();

async function pollOnce(gmid, p) {
  if (p.inFlight) return;
  p.inFlight = true;
  try {
    const res = await CricketService.GetMatchPrivateData(gmid, p.sid);
    const list = readMarketList(res);
    if (list && list.length) {
      p.list = list;
      p.at = Date.now();
    }
  } catch (err) {
    console.warn(`[liveOdds] poll failed gmid=${gmid}: ${err.message}`);
  } finally {
    p.inFlight = false;
  }
}

/** Join (or start) the poller for a match. Returns the first poll's promise. */
export function acquire(gmid, sid) {
  const key = String(gmid);
  let p = pollers.get(key);
  if (!p) {
    p = { sid, refs: 0, timer: null, list: null, at: 0, inFlight: false, first: null };
    pollers.set(key, p);
    p.first = pollOnce(key, p);
    p.timer = setInterval(() => { pollOnce(key, p); }, POLL_MS);
  }
  p.refs += 1;
  return p.first;
}

export function release(gmid) {
  const key = String(gmid);
  const p = pollers.get(key);
  if (!p) return;
  p.refs -= 1;
  if (p.refs <= 0) {
    clearInterval(p.timer);
    pollers.delete(key);
  }
}

/** Latest market list for a match ({ list, ageMs }), list null when never read. */
export function snapshot(gmid) {
  const p = pollers.get(String(gmid));
  if (!p || !p.list) return { list: null, ageMs: Infinity };
  return { list: p.list, ageMs: Date.now() - p.at };
}

export default { acquire, release, snapshot };
