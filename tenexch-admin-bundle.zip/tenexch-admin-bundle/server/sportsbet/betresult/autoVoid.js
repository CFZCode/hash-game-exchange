/**
 * autoVoid.js — void the stragglers once the main result is in.
 *
 * Owner rule (Settings → Auto Void): when the feed has declared an event's
 * MATCH_ODDS or BOOKMAKER result, wait `delay_seconds`, then void every bet on
 * that event that is still open with no result of its own. Those are the bets
 * the feed never declared — a fancy session it dropped, a market it renamed so
 * the matcher cannot see it — and without this they sit open with the money
 * blocked until an owner finds them.
 *
 * Runs INSIDE the results detector's scan (newjobv2.js): the detector already
 * holds one feed payload per event per scan, and it already knows which bets
 * matched a declared market. This module gets both for free, so it costs no
 * extra feed call.
 *
 * Money moves through services/admin/sportsMarketVoidService.js — the very
 * same function behind the owner's POST /void — with void_type AUTO_TIMEOUT.
 * Refund maths, exposure buckets, ledger row and bet_void_audit are identical
 * to a manual void.
 *
 * Guards:
 *  - the timer starts from OUR first sight of the anchor (sports_auto_void_state),
 *    so a detector outage can only delay a void, never fire it early;
 *  - fires only on a scan whose payload for the event was a 200 and still
 *    shows the anchor settled — a feed hiccup never voids anything;
 *  - only status 'open' bets with declared=false: 'manual' bets belong to the
 *    owner's hand-settle, declared bets belong to the settlement worker;
 *  - one transaction per market group; one bad group never blocks the rest,
 *    and the next scan retries whatever is still open.
 */
import sequelize from '../../config/db.js';
import AutoVoidConfig, { getAutoVoidConfig } from '../../model/admin/AutoVoidConfig.js';
import SportsAutoVoidState from '../../model/user/SportsAutoVoidState.js';
import { voidOpenMarket } from '../../services/admin/sportsMarketVoidService.js';
import { VOID_TYPES } from '../../services/admin/voidAuditService.js';
import { isPerSelectionMarket } from '../../helper/exposureBucket.js';

// feed mname -> config flag that enables it as an anchor
export const ANCHOR_MARKETS = {
    MATCH_ODDS: 'on_match_odds',
    BOOKMAKER: 'on_bookmaker',
};
const ANCHOR_DONE = new Set(['SETTLE', 'VOID']);
const CONFIG_TTL_MS = +(process.env.AUTO_VOID_CONFIG_TTL_MS || 10000);

/**
 * Pull the anchor markets' statuses out of one feed payload.
 * Called by newjobv2.fetchResultForEvent on the 200 branch.
 * @returns {{ MATCH_ODDS?: string, BOOKMAKER?: string }}
 */
export function anchorStatuses(markets) {
    const out = {};
    for (const m of Array.isArray(markets) ? markets : []) {
        const name = String(m?.mname || '').trim().toUpperCase();
        if (!(name in ANCHOR_MARKETS)) continue;
        const status = String(m?.status || '').toUpperCase();
        // A payload can carry the same mname twice (e.g. two bookmaker
        // boards) — a settled one wins over a pending one.
        if (!out[name] || ANCHOR_DONE.has(status)) out[name] = status;
    }
    return out;
}

export async function ensureAutoVoidTables() {
    await AutoVoidConfig.sync();
    // sync() never adds columns to an existing table.
    await sequelize.query('ALTER TABLE auto_void_config ADD COLUMN IF NOT EXISTS enabled_at TIMESTAMPTZ');
    await SportsAutoVoidState.sync();
}

/**
 * When a tracked event's stragglers get voided: the later of our first sight
 * of the anchor and the moment Auto Void was switched on, plus the delay. The
 * enabled_at leg stops a switch-on from instantly voiding events the tracker
 * armed while the setting was off. Shared with the Pending Result Tracker.
 */
export function voidDueAt(anchorSeenAt, c) {
    const seen = new Date(anchorSeenAt).getTime();
    const on = c?.enabled_at ? new Date(c.enabled_at).getTime() : 0;
    const delayMs = Math.max(0, Number(c?.delay_seconds) || 0) * 1000;
    return new Date(Math.max(seen, on) + delayMs);
}

export function createAutoVoid({ log }) {
    let cfg = null;
    let cfgAt = 0;

    async function config() {
        if (cfg && Date.now() - cfgAt < CONFIG_TTL_MS) return cfg;
        cfg = (await getAutoVoidConfig()).get({ plain: true });
        cfgAt = Date.now();
        return cfg;
    }

    // Which enabled anchor is done in this payload, if any.
    function pickAnchor(anchors, c) {
        for (const [mname, flag] of Object.entries(ANCHOR_MARKETS)) {
            if (!c[flag]) continue;
            const status = anchors?.[mname];
            if (status && ANCHOR_DONE.has(status)) return { market: mname, status };
        }
        return null;
    }

    // Group the stragglers the way the void service expects them:
    // MO/BM → one call per (match_id, market_type); fancy family → one call
    // per session, since each selection holds its own exposure pot.
    function groupBets(bets) {
        const groups = new Map();
        for (const b of bets) {
            const perSel = isPerSelectionMarket(b.market_type);
            const key = [b.match_id, b.market_type, b.game_type, perSel ? b.selection_name : ''].join('|');
            let g = groups.get(key);
            if (!g) {
                g = {
                    match_id: b.match_id,
                    market_type: b.market_type,
                    gametype: b.game_type,
                    selection_name: perSel ? b.selection_name : null,
                    betIds: [],
                };
                groups.set(key, g);
            }
            g.betIds.push(b.id);
        }
        return [...groups.values()];
    }

    /**
     * @param {Map<string, {
     *   eventid, sport_id, match_title,
     *   anchors: object|null,   // anchorStatuses() of this scan's 200 payload, null if no 200
     *   pending: object[]       // status 'open' bets this scan found NO result for
     * }>} events
     */
    async function afterScan(events) {
        let c;
        try { c = await config(); } catch (e) {
            log.error('[AutoVoid] config read failed', { error: e.message });
            return;
        }
        // Arming runs even with Auto Void OFF: the owner's Pending Result
        // Tracker lists every armed event that still has open bets. Only the
        // void itself is gated on `enabled`.

        for (const ev of events.values()) {
            try {
                // No 200 this scan → no opinion. Never arm or fire on a feed gap.
                if (!ev.anchors) continue;
                const anchor = pickAnchor(ev.anchors, c);
                if (!anchor) continue;

                const now = new Date();
                let state = await SportsAutoVoidState.findOne({ where: { eventid: String(ev.eventid) } });
                if (!state) {
                    state = await SportsAutoVoidState.create({
                        eventid: String(ev.eventid),
                        sport_id: ev.sport_id != null ? String(ev.sport_id) : null,
                        match_title: ev.match_title || null,
                        anchor_market: anchor.market,
                        anchor_status: anchor.status,
                        anchor_seen_at: now,
                    });
                    log.info('[AutoVoid] armed', {
                        eventid: ev.eventid, anchor: anchor.market, status: anchor.status,
                        enabled: !!c.enabled, fireAt: voidDueAt(now, c).toISOString(), pending: ev.pending.length,
                    });
                }

                if (!c.enabled) continue;
                if (now < voidDueAt(state.anchor_seen_at, c)) continue;
                if (!ev.pending.length) continue;
                const elapsed = now - new Date(state.anchor_seen_at);

                const groups = groupBets(ev.pending);
                const seenAt = new Date(state.anchor_seen_at).toISOString();
                const note = `auto void: ${state.anchor_market} ${state.anchor_status} seen ${seenAt}, +${Math.round(elapsed / 1000)}s`;
                const groupIds = [];
                let betsVoided = 0;
                let lastError = null;

                for (const g of groups) {
                    try {
                        const r = await voidOpenMarket({
                            match_id: g.match_id,
                            market_type: g.market_type,
                            gametype: g.gametype,
                            selection_name: g.selection_name,
                            voidType: VOID_TYPES.AUTO_TIMEOUT,
                            context: { actor: 'auto-void', actor_role: 'system' },
                            note,
                            ledgerSource: 'auto_void',
                            ledgerLabel: 'AUTO VOID',
                        });
                        groupIds.push(r.voidGroupId);
                        betsVoided += r.betsVoided;
                        log.info('[AutoVoid] voided market', {
                            eventid: ev.eventid, match_id: g.match_id, market_type: g.market_type,
                            selection: g.selection_name, users: r.userIds.length, bets: r.betsVoided,
                            voidGroupId: r.voidGroupId,
                        });
                    } catch (e) {
                        lastError = `${g.market_type}${g.selection_name ? ' / ' + g.selection_name : ''}: ${e.message}`;
                        log.error('[AutoVoid] void failed', {
                            eventid: ev.eventid, match_id: g.match_id, market_type: g.market_type,
                            selection: g.selection_name, error: e.message,
                        });
                    }
                }

                await state.update({
                    last_fired_at: now,
                    fire_count: (state.fire_count || 0) + 1,
                    bets_voided: (state.bets_voided || 0) + betsVoided,
                    void_group_ids: [...(state.void_group_ids || []), ...groupIds],
                    last_error: lastError,
                });
            } catch (e) {
                log.error('[AutoVoid] event failed', { eventid: ev.eventid, error: e.message });
            }
        }
    }

    return { afterScan };
}
