// Shared settlement-queue plumbing.
//
// A bet only settles once a row exists in SportsEventSettlementJob — the
// settlement worker polls that table every SETTLE_POLL_MS (3 s) and also
// listens on WAKE_CHANNEL for an immediate poll. Until this module existed the
// ONLY producer of those rows was the results cron (newjobv2.js), so a manual
// declare could not settle by itself: declareResult flipped the bets to
// 'manual' and then waited for the cron's next full scan to notice. When the
// upstream results feed is slow that scan takes minutes (observed 8m 45s on
// 2026-09-20 with 40 s per-event timeouts), and the scan's bet snapshot is
// loaded once at the start, so a bet declared mid-scan is not even seen until
// the pass after next.
//
// Both producers now share this file: the cron for feed-declared bets, and
// mannualSettle/controller.js for owner-declared ones.

import IORedis from 'ioredis';
import { Op } from 'sequelize';
import SportsEventSettlementJob from '../../model/user/SportsEventSettlementJobs.js';
import SportsBet from '../../model/user/SportsBet.js';

export const WAKE_CHANNEL = `sports-settle:wake:${process.env.DB_NAME || 'default'}`;

// Re-queue a done/failed job only if this old, so a stubborn bet cannot spin.
const REARM_AFTER_MS = +(process.env.REARM_AFTER_MS || 20000);

const noopLog = { info: () => { }, error: () => { }, debug: () => { } };

// ---------- settlement wake (redis pub/sub) ----------
// The worker polls its table every few seconds anyway; this just removes that
// wait. If redis is down the job still settles on the next timer poll, so a
// failure here is logged and swallowed — never fatal to the caller.
let pub = null;
function getPublisher(log = noopLog) {
    if (pub) return pub;
    try {
        pub = new IORedis({
            host: process.env.REDIS_HOST || '127.0.0.1',
            port: +(process.env.REDIS_PORT || 6379),
            password: process.env.REDIS_PASSWORD || undefined, // production Redis requires one
            maxRetriesPerRequest: null,
        });
        pub.on('error', e => log.error('[SettleQueue] redis wake error', { error: e.message }));
    } catch (e) {
        log.error('[SettleQueue] redis wake unavailable', { error: e.message });
        pub = null;
    }
    return pub;
}

export async function wakeSettlement(count, log = noopLog) {
    const p = getPublisher(log);
    if (!p) return;
    try {
        await p.publish(WAKE_CHANNEL, String(count));
        log.info('[SettleQueue] settlement worker woken', { count, channel: WAKE_CHANNEL });
    } catch (e) {
        log.error('[SettleQueue] wake publish failed', { error: e.message });
    }
}

// ---------- enqueue (idempotent) ----------
// One job row per (user, event, bet) — the unique index uniq_user_event_bet.
export async function enqueueSettlementJob(b, declared, log = noopLog) {
    const userId = String(b.user_id);
    const eid = String(b.eventid);
    const betIdStr = String(b.id);
    const betType = (b.bet_type || '').toString().toLowerCase() || 'unknown';
    const payload = { user_id: userId, eventid: eid, bet_id: betIdStr, bet_type: betType, bet: b, match_over: declared };
    const now = new Date();
    const pointBet = (jobId) => SportsBet.update(
        { job_id: jobId },
        { where: { id: b.id, status: { [Op.in]: ['open', 'manual'] } } }
    );

    const existing = await SportsEventSettlementJob.findOne({
        where: { user_id: userId, eventid: eid, bet_id: betIdStr },
        attributes: ['job_id', 'status', 'updated_at']
    });

    if (existing && (existing.status === 'queued' || existing.status === 'processing')) {
        if (String(b.job_id || '') !== String(existing.job_id)) await pointBet(existing.job_id);
        return { jobId: existing.job_id, action: 'already-live' };
    }

    if (existing) {
        // done/failed but the bet is still open: re-arm the SAME job id, but
        // not more often than REARM_AFTER_MS so a stubborn bet cannot spin.
        const age = Date.now() - new Date(existing.updated_at).getTime();
        if (age < REARM_AFTER_MS) return { jobId: existing.job_id, action: 'cooldown' };
        await existing.update({ status: 'queued', run_after: now, updated_at: now, error_msg: null, payload });
        await pointBet(existing.job_id);
        return { jobId: existing.job_id, action: 're-armed' };
    }

    let job;
    try {
        job = await SportsEventSettlementJob.create({
            user_id: userId, eventid: eid, bet_id: betIdStr, bet_type: betType,
            status: 'queued', priority: 5, run_after: now, payload,
            created_at: now, updated_at: now,
        });
    } catch (e) {
        if (e.name === 'SequelizeUniqueConstraintError') return { action: 'race-skip' };
        throw e;
    }
    await pointBet(job.job_id);
    return { jobId: job.job_id, action: 'created' };
}

/**
 * Queue every bet a manual declare just flipped to 'manual' and wake the
 * worker. Best-effort by design: the results cron still picks these up on its
 * next pass, so a failure here delays settlement rather than losing it, and
 * must not fail the declare request that the operator already committed.
 */
export async function enqueueManualBets({ eventid, match_id, market_type, log = noopLog }) {
    const where = { status: 'manual', eventid: String(eventid) };
    if (match_id) where.match_id = String(match_id);
    if (market_type) where.market_type = market_type;

    const bets = await SportsBet.findAll({
        where,
        attributes: ['id', 'user_id', 'game_type', 'bet_type', 'selection_name', 'odds',
            'stake_amount', 'match_title', 'match_id', 'fancy_name', 'eventid',
            'created_at', 'sport_id', 'market_type', 'status', 'team_one',
            'team_two', 'runners', 'job_id'],
        order: [['created_at', 'ASC']],
    });

    let queued = 0;
    for (const b of bets) {
        try {
            const r = await enqueueSettlementJob(b, true, log);
            if (r?.action === 'created' || r?.action === 're-armed') queued++;
        } catch (e) {
            log.error('[SettleQueue] manual enqueue failed', { betId: b.id, error: e.message });
        }
    }

    if (queued) await wakeSettlement(queued, log);
    log.info('[SettleQueue] manual declare queued', { eventid, match_id, market_type, bets: bets.length, queued });
    return { bets: bets.length, queued };
}
