# tenexch admin bundle

- `admin/`  — admin panel (React + Vite) source. No node_modules, no dist, no .env.
- `server/` — only the backend code behind the APIs the admin panel calls:
  all `routes/admin/*`, `routes/executive/*`, 2FA routes (telegram/google/android),
  `routes/user/gamesRoutes.js` (cricket/sports data), `routes/user/casinoRoutes.js` (/api/casino),
  `routes/user/casinoManageRoutes.js`, `d99/routes/betList.routes.js` (/api/d99),
  `mannualSettle/` (/api/internalsettle), `systemTracker/router.js`, `jsgames/routes.js`,
  `socket/socketHandler.js`, all `middleware/*`, plus every controller/service/model/helper
  they import (full relative-import chain). File list: `server/BACKEND_FILES.txt`.
- `server/server.js` is included as-is for the route mount map; it imports some user-side
  routes that are NOT in this bundle, so it will not boot standalone without them.
- No `.env` included. Create your own (admin: VITE_API_BASE_URL; server: DB/Redis/JWT vars).
