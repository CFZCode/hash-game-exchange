import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

/**
 * Dev/preview only: serve the app at the bare `/admin` too.
 *
 * Vite requires `base` to end in a slash, so it answers a request for `/admin`
 * with its "did you mean /admin/?" notice page instead of the app. That is not
 * cosmetic — `api.js` hard-redirects to `/admin` on every 401 and the login
 * page is `/admin`, so in dev a logged-out operator landed on Vite's notice
 * page rather than the login screen. Production is served by Apache and never
 * saw this.
 *
 * Rewrites internally (req.url), so the address bar keeps the bare `/admin` —
 * matching the live site — rather than bouncing through a redirect. Assets stay
 * on the `/admin/` base and are untouched. Build output is unaffected.
 */
function serveBareAdminPath() {
  const rewrite = (req, _res, next) => {
    if (req.url === '/admin' || req.url.startsWith('/admin?')) {
      req.url = '/admin/' + req.url.slice('/admin'.length);
    }
    next();
  };
  return {
    name: 'serve-bare-admin-path',
    apply: 'serve',
    // Block bodies on purpose: Vite treats anything RETURNED from these hooks
    // as a post-hook function and calls it, and `.use()` returns the connect
    // app — an arrow shorthand here crashes the dev server on boot.
    configureServer(server) {
      server.middlewares.use(rewrite);
    },
    configurePreviewServer(server) {
      server.middlewares.use(rewrite);
    },
  };
}

export default defineConfig({
  // The admin is served from https://tenexchn.com/admin, not its own subdomain,
  // so every emitted asset URL has to carry the /admin prefix. This also matches
  // the app's routes, which were already hardcoded under /admin.
  base: '/admin/',
  plugins: [react(), serveBareAdminPath()],
  resolve: {
    alias: {
      '@': './src',
    },
  },
  build: {
    outDir: 'dist',
    sourcemap: true,
  },
  server: {
    port: 5175,
    host: true,
  },
  preview: {
    port: 5175,
  },
});
