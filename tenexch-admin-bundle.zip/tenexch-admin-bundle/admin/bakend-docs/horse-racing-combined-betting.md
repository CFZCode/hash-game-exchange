# Horse Racing — Combined Betting, Settlement & Betting Window (tenexch port)

**Date:** 2026-07-21
**Ported from:** the JMD/d99 deployment's racing work (same feature spec), adapted to tenexch's own codebase (`server/` + `frontend/`).
**Status:** DEPLOYED — `pm2 restart tenexch-server undefined-sports-results-cron undefined-sports-settlement-worker`, `npm run build` in `frontend/` (live root = `frontend/dist`, backed up as `dist.bak-*`).

## What was done

1. **COMBINED (dutched) betting** — tick 2+ runners on the horse racecard → a COMBINED row
   above the market quotes `1/Σ(1/oddsᵢ)` per side; one typed stake is split
   `stakeᵢ = total × (1/oddsᵢ)/Σ(1/oddsⱼ)` (2 dp, rounding remainder to the largest leg) so the
   return is equal whichever selected runner wins. Verified: 100 @ [1.55, 4.9] → 75.97/24.03,
   both paying 117.75.
2. **`POST /api/user/place-combined`** `{ bets: [...] }` — every leg runs through the same
   `placeBet` (all locks/limits/exposure/wallet/ledger) inside ONE transaction, all-or-nothing.
   `placeBet(req, res, opts)` gained `opts.transaction` (caller owns commit/rollback) and
   `opts.skipMinStake` (market MIN/MAX are checked against the slip TOTAL in `placeCombinedBet`).
   Validation: 2–10 legs, same eventid+match_id, same bet_type, distinct selections, finite
   stakes, runners array present.
3. **Racing settlement now works** (was impossible):
   - `newjobv2.js`: sids 10/65 added to `KNOWN_VALID_SIDS` + fallbacks (a racing bet's correct
     sid was treated as garbage and re-probed as 4/1/2 → all 404).
   - `customMarketResolvers.js`: new `matchMarketByRunners` / `runnersKey` / `splitRunnerString` —
     a race is a FIELD of runners with no team_one/team_two; the bet's `runners` column is
     matched to upstream `natName` as an order-independent set, `mname` must also match, gated to
     3+ runners so 2-way markets never touch it. Wired into both the result cron and the
     settlement worker's `fetchResultForEvent`.
   - `settlementv2.js` `resolveMobmWinner`: takes `runners`; exact-match against the whole field
     (deliberately ahead of the legacy first-3-letters step), fuzzy runner pass as last resort.
     A winner outside the first two runners used to fall to "ambiguous → SUSPENDED" (silent
     refund).
   - **Multi-winner markets** ("TOP 2 FINISH", `winnerName: "Lasso,Nuedorf"`): names are split
     BEFORE `norm()` (which strips the comma and would collapse them into one unmatchable
     token). `isWinningSelection`/`moBmBetWinCredit` accept an array; a half-mapped result
     returns UNRESOLVED and requeues. Market valuation for multi-winner sums `moBmBetPnl` over
     **all open bets of (user_id, match_id, market_type)** — settlement jobs are per-BET but the
     wallet maths is per-MARKET; summing only the job's legs over-credits by exactly the missing
     legs' stakes (this caused a live over-credit on d99).
4. **5-minute betting window (horse `sid=10` only)** — `placeBet` STEP 4.55 rejects bets more
   than `RACE_BET_WINDOW_MINUTES` (env, default 5) before the off. Start time comes from the
   live board feed (`CricketService.fetchCricketData`, tree-walked country→venue→race), never
   the client payload. Feed unreadable/race unlisted → fails open. Frontend gates clicks with
   the same rule + toast. Greyhound (65) unaffected.
5. **The IST trap** — feed `stime` is an IST wall-clock string with no zone marker
   (`"7/22/2026 3:03:00 AM"`). `new Date(stime)` on the UTC server (and any non-IST browser)
   lands 5h30m off → every race looks hours away. `parseFeedIstTime` (server + frontend) parses
   the parts explicitly as IST; `formatFeedIstTime` renders the racecard time for every viewer.
   Verified: 3:03 AM IST → 21:33:00Z ✔, and the live race 3.1 min from the off ACCEPTs while
   later races REJECT.
6. **`maxb` is a feed FLAG on racing markets, not a cap** (live racecard: `maxb: 1, max: 2000`).
   tenexch's `resolveMarketLimits` preferred `maxb` — every racing bet over ₹1 would have been
   rejected. It now skips `maxb` for sids 10/65 and reads `mkt.max`. The frontend racing bet
   panel likewise passes `maxb: null` / `max_stake: market.max`. (The racing header still
   displays `maxb` — same known display gap as the reference.)
7. **Racing UI** (tenexch's `RacingDetails.jsx`, which previously had NO bet placement at all):
   odds cells are now clickable (single bets through the standard `PlaceBetPanel` pipeline —
   buffer monitoring, suspension checks, bookie-favour all included); COMBINED row quotes live
   dutched prices (each side only when every ticked runner has that side); new inline
   `CombinedBetSlip` with per-leg split preview and submit-time re-check (suspended leg rejects;
   price moved against → "Odds changed" + slip refreshes to the new price); suspended runners
   can't be ticked; COMBINED label uses 1-based board position, not cloth number; per-runner
   exposure (green/red) renders on the name line, polled every 5 s + on `bet:placed`; banner
   countdown/date use the IST parse; Matched Bets tab is now populated.
8. **"My Bet" panel on the racing page** — GameDetails' Matched Bets table (By Date / By Bet /
   Average) was inline-only there; it is now the shared
   `components/betting/MatchedBetsTable.jsx` and the racing page mounts it in its desktop right
   sidebar (renders once matched bets exist) and its mobile Matched Bets tab. Greyhound pages go
   through GameDetails, which already had the panel.

## tenexch-specific decisions

- **Greyhound stays on `GameDetails`** (`RACING_SIDS = ['10']` unchanged): tenexch's own code
  documents that its reference renders greyhound with a different block (market-13) and its feed
  ships only `nat`. Greyhound betting already works via the generic market blocks, and the
  settlement fixes cover sid 65. The racing page's checkbox/COMBINED code is already gated on
  the sport id if 65 is ever routed there.
- **Top-N-Finish (dtype 16) markets are not rendered** on tenexch's racecard (matches its
  reference), so multi-winner bets can't be placed from this UI today — the settlement support
  is in place for manual/future use.
- Racing bet rows store `match_title` = the field joined with " vs ", `game_type` MO,
  `market_type` = feed `mname` verbatim (`MATCH_ODDS` / `MATCH_BET`), and the full `runners`
  array (which settlement matching depends on).

## Files changed

**Backend (`server/`)**: `sportsbet/sportbetscontroller.js` (placeBet opts, STEP 4.55 window,
`parseFeedIstTime`/`resolveRaceStartMs`, `placeCombinedBet`, `resolveMarketLimits` racing-maxb
fix), `sportsbet/routes.js` (`POST /place-combined`), `sportsbet/betresult/newjobv2.js`,
`sportsbet/betresult/settlementv2.js`, `sportsbet/betresult/customMarketResolvers.js`.

**Frontend (`frontend/src/`)**: `utils/racingUtils.js` (new), `apiservices/sportsService.js`
(`sportsPlaceCombinedBet`), `components/betting/CombinedBetSlip.jsx` (new),
`pages/RacingDetails.jsx`, `App.css`.

## Known gaps (inherited from the spec)

1. Bets after the off are not blocked server-side — the window only gates the opening; the API
   has no SUSPENDED/odds re-check for any sport. Racing is the most exposed.
2. Race title ("R4 1m Mdn Claim") is not published by this provider — banner omits it.
3. Racing header displays `maxb` ("Max: 1") while the server enforces the real `max`.
4. Per-bet settlement jobs remain per-bet with market-level payouts — any future market-level
   value computed from the job's `bets` array alone will be wrong (see §3 multi-winner note).
