# User Rules-Acceptance (main site) — API + frontend integration

Date: 2026-07-31
Status: **backend done** (needs `pm2 restart tenexch-server` to go live). Frontend (main site) integration pending — this doc is the spec for it.

Users (players) now have the same rules-acceptance flow that staff and owners already have in the admin panel: a `rules_accepted` boolean on the account, returned by the auth/profile APIs, plus a POST endpoint that sets it to `true` when the player accepts the rules modal.

No DB migration needed — the shared helper (`server/helper/rulesAccepted.js`) auto-creates the `rules_accepted` column on the `users` table on first use (default `false`/`null`).

---

## 1. Where to GET the flag

The frontend can read `rules_accepted` from three places. **The profile API is the primary source** — the main site's `loginThunk`/`verify2FAThunk` (`frontend/src/redux/userSlice.js`) already call it right after login, so the flag arrives with no extra request.

### a) User profile (primary)

```
GET /api/admin/user/profile
Authorization: Bearer <user token>
```

Response — `rules_accepted` is inside `data.user`, alongside the wallet/exposure fields:

```json
{
  "success": true,
  "data": {
    "user": {
      "wallet_id": 1,
      "user_id": 123,
      "username": "player1",
      "inr_balance": "1000.00",
      "total_exposure": 0,
      "telegram2FAEnabled": false,
      "telegramChatId": null,
      "rules_accepted": false
    }
  }
}
```

Frontend already consumes this via `getUserProfileWithWallet()` in `frontend/src/apiservices/authService.js` (returns `data.user` directly).

### b) Login response

```
POST /api/user/login
```

```json
{
  "success": true,
  "message": "Login successful",
  "token": "…",
  "passwordChanged": true,
  "rules_accepted": false
}
```

### c) 2FA verify response (for accounts with Telegram 2FA)

```
POST /api/user/verify-2fa
```

```json
{
  "success": true,
  "message": "2FA Verified",
  "token": "…",
  "passwordChanged": true,
  "rules_accepted": false
}
```

`rules_accepted` is `false` until the player accepts once; after that it stays `true` (no un-accept endpoint).

---

## 2. How to SET the flag (player accepts the modal)

```
POST /api/user/accept-rules
Authorization: Bearer <user token>
Content-Type: application/json
```

Body is optional. `user_id` may be sent in the payload; if omitted, the id from the token is used:

```json
{ "user_id": 123 }
```

Success response (flag is re-read from the DB, so `success:true` guarantees persistence):

```json
{ "success": true, "rules_accepted": true, "user_id": 123, "updated_rows": 1 }
```

Errors: `400` if no id could be resolved, `401` from auth middleware if the token is missing/expired, `500` with `{ success:false, error }` on DB failure.

curl test:

```bash
curl -X POST https://apitenexch.codefactory.games/api/user/accept-rules \
  -H "Authorization: Bearer <user-token>" \
  -H "Content-Type: application/json"
```

---

## 3. Main-site frontend integration (what to build)

1. **API call** — add to `frontend/src/apiservices/authService.js`:

   ```js
   // Accept rules (rules modal) — sets rules_accepted=true for the logged-in user
   export const acceptRules = async () => {
     const response = await api.post('/user/accept-rules');
     return response.data;
   };
   ```

2. **State** — `rules_accepted` already lands in the user state for free: `loginThunk` and `verify2FAThunk` in `frontend/src/redux/userSlice.js` spread the profile response (`return { ...profile, token, … }`), and the profile now includes the flag. Nothing to change unless the slice whitelists fields.

3. **Modal trigger** — after login/refresh, if `user.rules_accepted === false`, show a blocking rules modal. On "Accept", call `acceptRules()`; on `success: true`, update the flag in the store and close the modal.

4. **Reference implementation (admin panel, already live)** — copy the pattern from:
   - `admin/src/components/RulesModal.jsx` — the modal + `handleAccept`
   - `admin/src/components/Layout.jsx` (~line 96) — open-on-login logic driven by `user.rules_accepted === false`
   - `admin/src/hooks/useAuth.js` (~line 90) — merging the login response's `rules_accepted` into stored user data
   - `admin/src/config/api.js` — endpoint constants (`ACCEPT_RULES_STAFF` / `ACCEPT_RULES_OWNER`); the user equivalent is `/user/accept-rules`

---

## 4. Backend source map

| Piece | File |
|---|---|
| Route `POST /api/user/accept-rules` | `server/routes/user/userAuthRoutes.js` (mounted at `/api/user` in `server/server.js`) |
| Handler `acceptRules` + login/2FA flag | `server/controller/user/userAuthController.js` |
| Profile flag | `server/controller/admin/userController.js` → `getLoggedInUserDetails` |
| Shared helper (raw-SQL read/write, column auto-create) | `server/helper/rulesAccepted.js` |
| Staff / owner equivalents (same contract) | `server/routes/admin/staffAuthRoutes.js`, `server/routes/admin/ownerAuthRoutes.js` |
