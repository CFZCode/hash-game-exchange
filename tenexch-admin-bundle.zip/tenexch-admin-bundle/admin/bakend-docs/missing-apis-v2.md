# Backend work required — TENEXCH admin panel + player site

**Version 2.0 · 7 September 2026**

This is a handover document for the backend developer. It lists only work that
is still **open**. Everything already delivered has been dropped; the full
history stays in `missing-apis.md`.

Every endpoint below was re-probed on the live servers on 7 Sep 2026 while
writing this. The status column is what those servers answered, not what an
older note claimed.

- Admin API — `https://admintenexch.codefactory.games/api`
- Player API — `https://api.tenexchn.com/api`

**How to read the probe results:** an unauthenticated request returning **401**
means the route exists and rejected us for lack of a token. **404** means the
route is not mounted at all. That is the difference between "endpoint exists,
behaviour is wrong" and "endpoint does not exist".

In every case below the frontend is already built and wired. Nothing is waiting
on UI work — these screens are blank or wrong only because the data is not
there.

---

## Priority 1 — endpoints that do not exist (screens are dead)

Each returns 404 today. The page renders and then shows nothing.

### 1.1 `POST /admin/reports/sportbook-report`

Screen: `/admin/reports/sportbookreport` · `admin/src/pages/reports/SportbookReport.jsx`

Request body:

```json
{ "username": "user1", "vendor": "provider-code",
  "date": "2026-09-07", "status": "settled" }
```

- `status` is `settled` or `unsettled`. (Alternatively use the same
  `type: 'SettleBet' | 'UnsettleBet'` contract as `casino-report` — please pick
  one shape and use it for both screens.)
- **The unsettled tab calls without a vendor.** When `vendor` is empty, return
  unsettled bets for all providers. On the settled tab the vendor is required
  and the UI already marks the field invalid when it is missing.
- Scope every query to the logged-in user's downline.

Response rows:

| tab | fields |
|---|---|
| settled | `round_id`, `transaction_type`, `amount`, `total`, `bet_id`, `timestamp` |
| unsettled | same, without `total` |

**Also needed:** an endpoint returning the sportbook provider list for the
Select dropdown. There is none today, and the reference site ships that select
empty, so we have nothing to copy.

### 1.2 `GET /admin/reports/fraud`

Screen: `/admin/reports/fraud` · `admin/src/pages/reports/FraudReport.jsx`

Query: `page`, `limit`, optional `search`.

Response: rows of
`{ sno, username, eventName, marketDate, marketName, amount, fraudDate, remark }`
plus `{ totalPages }`. Scope to the logged-in user's downline (fraud-marked
bets).

Open question for you: the reference site's Action column is empty, so we do
not know what action belongs there (unmark? void?). Tell us and we will wire it.

### 1.3 `GET /admin/reports/user-register-detail`

Screen: `/admin/reports/userregisterdetail` · `admin/src/pages/reports/UserRegisterDetail.jsx`

Query: `page`, `limit`, optional `username`, and
`type` = `1` (All) · `2` (Created Date) · `3` (Last Login Date).

Response rows carry 13 columns:

```
username, agent_name, phone_number (or mobile), created_at, last_login,
first_deposit_date, last_deposit_date, deposit, sports_balance,
casino_balance, third_party_credit_balance, sport_book_balance, referral_code
```

plus `{ totalPages }`. Scope to downline users. The UI accepts both snake_case
and camelCase, so either is fine.

### 1.4 `GET /admin/users/all-details` — one missing field

Screen: `/admin/reports/authlist`

The endpoint works, but no wallet object carries any 2FA information. The
Authentication column therefore shows `no authentication` for every user.

Add to each wallet either `telegram2FAEnabled` (boolean) or
`auth_type: 'none' | 'telegram'`, for both staff and player records. The UI
already maps it — the column will fill in the moment the field arrives.

### 1.5 `GET /admin/bank/...` — the Bank page is entirely mock data

Screen: `/admin/reports/bank`

Three endpoints needed:

| endpoint | body | purpose |
|---|---|---|
| `GET /admin/bank/list?search=` | — | rows: `username, fullName, cr, pts, pl, exposure, available, accountType` |
| `POST /admin/bank/transfer` | `{ username or user_id, amount, masterPassword }` | per-row Submit |
| `POST /admin/bank/transfer-all` | `{ masterPassword }` | the "All" transfer |

On a wrong transaction password the message must be exactly
`Master Password not valid.`

### 1.6 `GET /admin/assign-agent/list` — the Assign Agent page is entirely mock data

Screen: `/admin/assign-agent`. The table is always empty. Also needs a
CSV-download endpoint that takes a `fromDate` and returns user-creation rows.

### 1.7 `POST /admin/reports/party-win-loss`

Probed 404. The Party Win Loss screen reads `GET /admin/pl/all` instead, and
that response is missing two fields — see 2.4.

---

## Priority 2 — endpoints that exist but behave wrongly

These answered 401 to our unauthenticated probe, so the routes are live.

### 2.1 `GET /admin/reports/current-bets` — three real bugs

Controller: `server/controller/admin/reportsController.js` → `getCurrentBets`.
The UI sends the right values; the backend drops them.

1. **`matchStatus` is ignored** — it is not even destructured from the query, so
   the Matched / Unmatched / Deleted radios do nothing. The `where` clause is
   permanently `status IN (OPEN/PENDING/matched…) AND result_status = 'pending'`,
   which means **deleted bets can never be returned at all**.
   Expected: `matchbet` → matched/open · `unsettled` → unmatched/pending ·
   `deletebet` → deleted/void.
2. **`betType` is matched exactly** (`bet_type = 'back'`) but the column stores
   whatever the request sent, e.g. `BACK`, and fancy bets store `yes`/`no`
   (`sportbetscontroller.js`, `finalBetType`). The filter needs to be
   case-insensitive and to map back→yes, lay→no for fancy.
3. **The Casino tab is always empty** — the query only reads the `SportsBet`
   table with `game_type = 'casino'`, but casino bets live in a different model
   (`server/model/user/casino.js`). The casino tab needs its own source, with
   columns: Event Name, User Name, Nation, U Rate, Amount, Place Date, IP.

### 2.2 `POST /admin/reports/casino-report` — no date filter, no pagination

Contract: `{ role, username, type: 'SettleBet'|'UnsettleBet', vendor }`.

1. **The `date` param is ignored** — there is no date condition on `timestamp`
   in the SQL. The settled tab has a date picker, so `date` (or from/to) must
   filter `t.timestamp`.
2. **No pagination** — every record is returned at once
   (`ORDER BY timestamp DESC`, no limit/offset). Please add `page` / `limit`.

Note on hierarchy: `username` is resolved through
`getUserIdsByHierarchy(role, username)`, and `role` must be the logged-in user's
role, not the selected client's.

### 2.3 `POST /admin/reports/user-win-loss` — one missing field

Rows come back as
`{ user_id, username, sport, casino, third_party, profit_loss }`.

The reference table has a **SportBookpts** column. Add a `sportbook` field to
each row and include it in `profit_loss`. The column currently shows 0 for
everyone.

### 2.4 `GET /admin/pl/all` — two missing fields

Add `level` (formatted as Master/Agent/User) and `ptype`. The frontend falls
back to `user_type` and hardcodes `Ptype` to `Point` today.

### 2.5 `POST /admin/reports/turnover` — confirm the contract

Probed 401, so the route exists, but it has never returned data for us. Please
confirm it accepts:

```json
{ "user_id": "optional — a client, else the whole downline",
  "type": "sports | casino",
  "fromDate": "2026-09-01", "toDate": "2026-09-07",
  "sport_id": "sports only, optional", "gtype": "sports only, optional",
  "game_name": "casino only, optional" }
```

and returns a single summary object:
`{ loss_turn_over, loss, win_turn_over, win, total_turn_over, total_pl }`.

Only the **last 7 days** are allowed — the page says so itself; an older range
should return empty or an error.

### 2.6 Account Statement — confirm the Game Report filters

The frontend sends `statement` (all/sport/casino, and credit/pts variants),
`sportId`, `gameType` and `casinoType`. Please confirm the backend honours
these rather than ignoring them — sport/casino filtering has to happen server
side.

---

## Priority 3 — player site (`api.tenexchn.com`)

### 3.1 Two report screens have no backend at all

| screen | frontend calls | probe |
|---|---|---|
| Live Casino Bets (`/report/livecasinoresult`) | `GET /jsGames/history` | **404** |
| SportBook Bets (`/report/sportbookresult`) | `GET /jsGames/sportbook-history` | **404** |

Both pages therefore show nothing at all.

What we found in the code:

- `/api/jsGames` mounts `server/jsgames/routes.js` (server.js:334) and that file
  has no `history` route.
- A `/history` route does exist in `server/jsgamesv2/gameRoutes.js`, mounted at
  `/api/jsGamesv2` (server.js:335) — but it ignores the date entirely and
  forwards only `user_id` upstream (`jsgamesv2/GameController.js`,
  `userhistory`).

Needed: `GET /jsGames/history` and `GET /jsGames/sportbook-history`, both
taking `dateFrom`, `dateTo`, `type`, `page`, `limit`, scoped to the logged-in
player. The frontend already sends exactly those params, so both screens will
come alive as soon as the routes exist.

### 3.2 `POST /casino/casino/result-report` — no date support

Screen: Casino Results (`/report/casinoresult`).

The endpoint takes only `{ type }`. Its rows carry `mid` and a winner and **no
date field at all**, so the page cannot filter by date even client-side.

Needed: a date range on the request, and a date field on each row.

### 3.3 Casino game data — two games missing scorecard fields

Both verified against `POST /casino/casino/all-data` on the deployed API.

**SuperOver (`superover3`)** returns
`{ t1: { card: "3DD|KDD|1|1", gmid, lt, ft, scard, iplay, … }, t2: null }`.

`card` covers only the current innings' four balls. The reference admin page
shows both innings plus a result line, e.g. `IND 7-1 (0.3)`, `AUS 0-1 (0.1)`,
`IND won the match`. Neither the first-innings total nor the result message
appears in any field, so `games/superover3/SuperOver3.jsx` computes the current
innings from the card string and shows the other row as a best-effort `0-0 (0.0)`.

**5Five Cricket (`cricketv3`)** returns
`{ t1: { card: "1|1|1|1|1|1", gmid, lt, ft, scard: 1, ename, gtype, … }, t2: [Bookmaker, Fancy] }`.

The reference shows `AUS 65-6 (5.0)`, `IND 37-2 (3.0)`, `CRR 12.33`, `RR 14.50`
and `IND Needed 29 runs from 12 balls`. None of the accumulated totals, run
rates or the target message are in `t1` — `card` is the current innings only and
`scard` is just the innings number. `games/cricketv3/CricketV3.jsx` does the
same best-effort as above; RR and the "Needed" line are not rendered.

Needed for both: pass the upstream innings-wise scorecard through — runs,
wickets and overs for **both** innings, CRR/RR, and the target/result message.

---

## Priority 4 — smaller confirmations

### 4.1 Credit Activity modal — confirm two things

- `POST /admin/wallet/deposit/add` and `POST /admin/wallet/withdraw` take
  `{ userId, amount, userType, transactionPassword, remark }`. Does the backend
  actually store `remark`?
- `POST /admin/ledger/user/history` with `{ user_id, page, limit }` returned 200
  but with no rows, so we could not confirm the field names. Our table maps
  `super_user`, `user`, `transfer_from`, `amount`, `created_at` — these are
  **guesses**. Please confirm against one real record.

### 4.2 View More bets modal (game-details) — search should be server side

The reference form searches on the server (Username / Amount / IP, plus
All/Back/Lay/Deleted). We currently pull every bet through
`getMatchDownlineBets` and filter in the browser, because we could not find a
dedicated search endpoint.

Needed: a search endpoint, plus confirmation that bets with `status: "deleted"`
are returned and that each bet carries `ip_address` and `run`.

### 4.3 General Lock — no message on a blocked bet

When a bet is placed on a locked game/series/match/market, the backend should
return a clear message the UI can show. **Not scheduled — do not start this one
until we ask.**

---

## Summary

| # | Item | Status |
|---|---|---|
| 1.1 | `POST /admin/reports/sportbook-report` | 404 — build it |
| 1.2 | `GET /admin/reports/fraud` | 404 — build it |
| 1.3 | `GET /admin/reports/user-register-detail` | 404 — build it |
| 1.4 | 2FA field on `/admin/users/all-details` | add a field |
| 1.5 | Bank page — 3 endpoints | 404 — build them |
| 1.6 | Assign Agent — list + CSV | 404 — build them |
| 1.7 | Party Win Loss endpoint | 404 (see 2.4) |
| 2.1 | `current-bets` — matchStatus, betType, casino tab | 3 bugs |
| 2.2 | `casino-report` — date filter, pagination | 2 bugs |
| 2.3 | `user-win-loss` — `sportbook` field | add a field |
| 2.4 | `/admin/pl/all` — `level`, `ptype` | add fields |
| 2.5 | `turnover` — confirm contract | confirm |
| 2.6 | Account Statement — game filters | confirm |
| 3.1 | `jsGames/history`, `jsGames/sportbook-history` | 404 — build them |
| 3.2 | `result-report` — date range + row date | extend |
| 3.3 | superover3 / cricketv3 scorecard | pass through |
| 4.1 | Credit Activity — `remark`, ledger fields | confirm |
| 4.2 | View More bets — server-side search | build it |
| 4.3 | General Lock message | on hold |
