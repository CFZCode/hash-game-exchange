# Casino game pages — build loop process

Admin me casino game pages user-site (frontend/) architecture ka exact port
hain. Ye doc har naye game ko finish karne ka repeatable loop hai (~80 games).

## Architecture (already set up)

- **Route**: `/admin/casino/:gtype` → `src/pages/Casino-games/index.jsx`
  (`/admin/casino/list` aur `/admin/casino/vip` exact routes pehle match
  hote hain).
- **Folder structure (per-game)**:
  ```
  src/pages/Casino-games/
    index.jsx          # :gtype route — registry lookup, warna generic screen
    gameRegistry.js    # gtype → lazy(games/<gtype>/...) mapping
    games/
      goal2/Goal2.jsx
      worli3/Worli3.jsx
  ```
  Har game page `CasinoGameScreen` (shared) use karta hai — `React.lazy` se
  per-game chunk banta hai (code splitting). Naya game = games/<gtype>/ folder
  + gameRegistry.js me ek line.
- **Data**: user site wale hi endpoints, admin `api` instance se
  (`src/services/casinoService.js`) — `/casino/casino/all-data`,
  `last-results`, `detail-results`, `mybets`. Per-request timeout 30s
  (upstream cold-cache 15s+ le sakta hai).
- **Streaming**: exact user-site source —
  `https://stream-s-43.xink.site/casino-stream?id=<gtype>`
  (`src/hooks/casino/useCasinoStream.js`, `VITE_CASINO_STREAM_BASE` se override).
- **Hooks (logic layer)**: `src/hooks/casino/` — `useCasinoGame` (1s poll),
  `useCasinoLastResults`, `useCasinoStream`, `useCasinoMyBets` (admin-safe,
  read-only). Betting admin me no-op hai (`useCasinoBet` port nahi kiya).
- **Presentation layer**: `src/components/casino/` — `CasinoVideo`,
  `CasinoTimer` (Mobile+Desktop), `CasinoResultModal` (+`results/` switch),
  `CasinoRightSidebar`, `cards/`, `rules/`, aur per-game `BetTable*.jsx`.
- **Switch-case**: `src/components/casino/BetTableSwitch.jsx` —
  `TABLES` map me gtype → BetTable component (60 tables mapped).
  Unmapped gtype pe placeholder dikhta hai: "table UI pending…".
- **Config**: `src/config/casinoGames.js` (name/tableClass/cardLayout/dataType),
  `src/utils/casinoUtils.js`.

## Per-game loop (repeat for each gtype)

1. **Data verify** (backend compare):
   ```bash
   curl -s -m 30 -X POST "https://admintenexch.codefactory.games/api/casino/casino/all-data" \
     -H 'Content-Type: application/json' -d '{"type":"<gtype>","data":{}}'
   ```
   Response ke fields (`mid/lt/ft/sub[].nat/b/l/gstatus/card…`) ko us game ke
   `BetTable<Game>.jsx` ke expected props se compare karo.
2. **Table mapping check**: `BetTableSwitch.jsx` me gtype ki entry hai?
   Nahi → BetTable import + `TABLES` me key add karo.
3. **Table detail parity (MUST)**: reference DOM me jo bhi interactive
   elements hain wo functional hone chahiye — khaas kar:
   - **Range info tooltip**: `fa-info-circle` icon + `icon-range collapse`
     div (`R:<min>-<max>`, API ke `min`/`max` se K/L format) — click pe
     collapse toggle (BetTableTeen62 ka `RangeInfo` pattern reuse karo).
   - **Book span**: `casino-book book-black/red/green` — computeAdminBook
     se sid-scoped lookup (`sid:<sid>` pehle, phir nat fallback). 0 bhi
     dikhta hai (`book-black`), hide nahi hota.
   - **lock-top**: suspended box pe book non-zero ho to `suspended lock-top`
     class (reference: dolidana Even -95) — lock icon upar shift hota hai.
   - **Card/suit images**: hamesha
     `https://wver.sprintstaticdata.com/v230/static/front/img/...` se
     (`cardSrc` / CARD_BASE) — local `/assets/...` paths exist nahi karte.
   - **Card SEQUENCE mapping (MUST)**: card string ka order (kaunsa index
     kis player/slot ka hai) DOM dump se guess NAHI karna — hamesha
     `frontend/` ke matching component se verify karo
     (`frontend/src/components/casino/cards/<Game>Cards.jsx` /
     `CasinoCardSwitch.jsx`). E.g. poison: card[0]=Poison, baaki
     INTERLEAVED A1,B1,A2,B2,A3,B3 — dump me dono interpretations fit ho
     sakti hain, frontend authoritative hai. Cards overlay tabhi render
     hota hai jab koi real card ho (sab '1' face-down → overlay hidden).
   - **RULES content bhi frontend se (MUST)**: rules ka content/structure
     bhi wahi se lena hai — `frontend/src/components/casino/rules/
     <Game>Rules.jsx` (+ CasinoRulesSwitch.jsx mapping, ~52 components).
     Admin me naya rules component likhne se pehle frontend wala kholo aur
     content/sections usse match karo; dump aaye to dump ke game-specific
     diffs (e.g. roulette13 me Lay table nahi) upar se apply karo.
   - **Rules IMAGE path (MUST — recurring bug)**: images `public/assets/
     casino/rules/` me download karke rakho (CDN hotlink NAHI), PAR `<img src>`
     me `/admin/` base prefix zaroori hai — Vite `base: '/admin/'` hai, isliye
     `src="/assets/casino/rules/x.jpg"` domain-root pe resolve hoke 404 deta
     hai. Sahi: `src="/admin/assets/casino/rules/x.jpg"` (Race20Rules pattern).
     13 rules files is bug se toote the (25/07 → fix).
4. **Config check**: `casinoGames.js` me gtype ka entry (name, tableClass,
   dataType object/array, cardLayout) sahi hai? `dataType: 'array'` wale
   games (worli3/Matka jaise list responses) page me `gameData[0]` use karte hain.
5. **My Bets verify**: sidebar `GET /d99/bet-list/casino/open-downline
   ?gameName=<gtype>` (5s poll) se, "View More" modal (`__BVID__1920`)
   `GET /d99/bet-list/casino/all-downline?gameName=<gtype>` se — dono
   existing hain (auth + downline + username join; d99-admin same pattern).
   Row: `username, selection (Nation), amount, odds (User Rate),
   created_at (Place Date)`. IP/Browser SELECT me missing — docs point 22.
   gameName filter `cb.game_name ILIKE ya cb.type ILIKE` se match hota hai,
   isliye gtype pass karna kaafi hai.
6. **Book/exposure resolver**: koi exposure API nahi — book open downline
   bets se CALCULATE hoti hai (`src/utils/casinoBook.js`):
   - user BACK S (odds o, stake st) → admin book[S] = -(o-1)*st, usi market
     ke baaki selections +st (e.g. Ronaldo back 100@6.57 → Ronaldo -557 red,
     baaki +100 green; Header Goal back 100@4.2 → Header -320, baaki +100)
   - user LAY S → ulta
   - **Market groups AUTOMATIC hain** — `getMarketsForGame` ab `sub[].etype`
     se banata hai (reference-verified 23/07/2026, per-game case NAHI likhna):
     - `etype: match` → same `subtype` ke selections EK market (spread hota
       hai — e.g. dolidana main: Player B back 100@1.97 → B -97, A +100;
       goal2 players/method/combo groups)
     - `etype: fancy`/`fancy1` → har selection APNA single market (spread
       NAHI — e.g. dolidana Even back 100@1.95 → Even -95, Odd 0 hi rehta)
     - Naye game me bas itna check karo ki uske `sub[].etype/subtype` values
       is rule me sahi baithte hain (all-data curl me dono fields dekho).
   - **Frontend (user site) bhi same formula** — `frontend/src/utils/
     casinoBook.js` (user perspective: sign ulta) +
     `useCasinoMyBets(mid, isAuth, gameType, gameData)` — gameType/gameData
     pass karo to book calculate hoti hai aur get-exposure endpoint call
     hi nahi hota; na pass karo to legacy endpoint mapping (purane pages).
     Goal2.jsx wired hai — loop me har game ke page me 2 extra args pass
     karne hain.
   - **Backend change ki zaroorat nahi** — market membership (kaun se
     selections ek market me hain) sirf live `all-data sub[]` me hota hai,
     isliye book client-side hi banti hai; backend se sirf open bets aate
     hain (admin: /d99/bet-list/casino/open-downline, user: mybets).
     Unit-verified: Ronaldo back 100@6.57 → admin -557/+100; Header Goal
     back 100@4.2 → -320/+100 (user side +320/-100).
7. **Result type verify**: `POST /casino/casino/detail-results` ka `t1`
   (rdesc/win/winnat/mtime/card) us game ke result modal component
   (`results/<Game>Result.jsx`) se match karo — win-code → display mapping
   game-specific hoti hai (e.g. goal2 rdesc "Player#Method" →
   "Method by Player"). Mapping na banti ho to docs me add karo.
8. **Result report page (MUST har game ke liye)** —
   `/admin/reports/casinoresult/:casinoname` route generic hai (preselect +
   auto-load + Market Id click → animated result modal sab automatic), lekin
   har naye game pe 2 mappings verify/add karni hain:
   - `CasinoResult.jsx` ke `mapWinDisplay` me us game ka win-code → display
     mapping (e.g. goal/goal2: sid → player name `GOAL_WINNERS`; race: suit;
     superover: I/E). Bina mapping ke raw code dikhega.
   - `results/ResultContentSwitch.jsx` me gtype → `<Game>Result` component
     mapping (warna modal ka content khali/default aayega).
   - Game page ke `...` result-more link ko `/admin/reports/casinoresult/
     <gtype>` pe point karna (CasinoGameScreen me automatic hai; custom
     pages — worli3 jaise — me khud lagana).
9. **Missing values → docs**: agar API me koi value missing hai jo table ko
   chahiye (ya sirf frontend demo me thi), `bakend-docs/missing-apis.md` me
   point add karo.
10. **Book unit-test (MUST — Claude ki responsibility, har game pe)**:
   build se pehle node+esbuild se `getMarketsForGame` + `computeAdminBook`
   ko us game ke REAL `sub[]` (all-data curl se) pe chalao aur verify karo:
   - ek match-etype selection pe back bet → apni book -(o-1)*st, same-market
     baaki +st, DUSRE markets 0
   - ek fancy-etype selection pe back bet → sirf apni book -(o-1)*st, baaki
     SAB 0 (Odd/Even jaisa pair bhi)
   - snippet pattern (dolidana verify me use hua):
     ```bash
     node -e "const esbuild=require('esbuild'),fs=require('fs');
     const code=esbuild.transformSync(fs.readFileSync('src/utils/casinoBook.js','utf8'),{loader:'js',format:'cjs'}).code;
     const m={exports:{}};new Function('module','exports',code)(m,m.exports);
     const {computeAdminBook,getMarketsForGame}=m.exports;
     const sub=[/* all-data curl se real sub[] paste */];
     console.log(computeAdminBook([{selection:'<nat>',odds:1.97,amount:100,game_type:'back'}],getMarketsForGame('<gtype>',{sub})));"
     ```
   - Table ke `bookOf` me sid-scoped key (`sid:<sid>`) use ho rahi hai ye
     bhi confirm karo (nat-only lookup duplicate naams pe leak karta hai —
     teen62 'Player A' teen+con dono me hai).
11. **Build**: `npm run build` — user browser me verify karega
   (`http://localhost:5175/admin/casino/<gtype>`). Result report bhi khol ke
   dekhna hai (`/admin/reports/casinoresult/<gtype>`) — winner naam
   `result-report` endpoint ke `winName` se aata hai (fallback
   `mapWinDisplay`).

## CSS — NAYA MAT LIKHO (MUST)

Saara CSS reference se already `admin/src/styles/` me port hai (app.css,
style.css, responsive.css, custom.css, ten.css...). Component ke liye naya
CSS hand-roll MAT karo. Kuch bhi "toota" dikhe to:

1. Pehle `admin/src/styles/` me thoroughly search karo — **unanchored** grep
   (mid-line rules bhi), app.css bhi (804KB, minified block-form). Class
   game-prefixed ho sakti hai (`.ab2-result .owl-nav`, `.andar-bahar .ab-slider`).
2. Reference source me dekho: `../frontend/reference/*.css` aur (agar package
   CSS hai) `../frontend/src/main.jsx` ke imports. Missing rule wahan se
   **port** karo, apna banao mat.
3. Carousel plugin base ek known gap tha. Reference admin **owl-carousel**
   (Owl Carousel 2) use karta hai — DOM `owl-carousel owl-theme owl-loaded
   owl-drag > owl-stage-outer > owl-stage > owl-item`. Uska package CSS
   external CDN se aata tha, ported files me nahi tha. Ab wo package CSS
   `src/styles/owl.carousel.css` me hai (index.html me link, app.css ke baad),
   aur game-specific owl-nav overrides pehle se style.css me the. **AB4/AB3
   result sliders owl DOM use karte hain (reference exact); frontend ka React
   paging logic (state + owl-prev/owl-next transform) chalega, styling package
   se aayegi. hooper MAT use karo** — wo frontend-only tha, admin reference
   owl hai.

## Verified so far

- **goal2** (Goal 2 / football): object response, `sub[]` players with b/l,
  `lt/ft/mid` — working on both apidiamond99 and admintenexch domains.
  Pehla call slow ho sakta hai (upstream cold) — timeout 30s handle karta hai.
- **worli3** (Matka): array response (`data.data[]` with gno/mid/mname/
  mtime/mtype/ptime) — working.
- **teen62** (V VIP Teenpatti 1-day): main/suita/suitb match (spread),
  oddeven cards + con fancy (singles); RangeInfo pattern yahi se aaya.
- **dolidana** (Doli Dana): main match pair, baaki sab fancy singles; results
  strip me `resulttie` "R" spans; result modal dice imgs + rdesc 6 parts
  (Turn#AnyPair#ParticularPair#SumTotal#OddEven#Lucky7); book formula
  reference dumps se verify (B -97/A +100, Even -95/Odd 0) + lock-top.
- **teenunique** (Unique Teenpatti): dedicated page — `casino-table
  unique-teenpatti`, video overlay me 6 card slots (har card apna `<div>`,
  sequential order, API card = "5DD,5SS,1,1,1,1"), right-icons me SIRF Rules
  (home/lr-toggle nahi), koi bet-table nahi. last-results strip (`resulttie`
  "R") casino-detail me SIRF web pe — mobile pe casino-detail khali
  (`innerWidth < 768` guard). Cards frontend me showCards=false hai (React port
  cards nahi dikhata) par live admin reference dikhata hai — reference follow.
- **mogambo** (Mogambo): dedicated page (`games/mogambo/Mogambo.jsx` +
  gameRegistry) — `casino-table mogambo teenpatti2cards`, video overlay me
  Total + Daga/Teja (2 cards, card-devider) + Mogambo (1 card, text-center),
  card seq frontend MogamboCards se (cards[0..1]=Daga/Teja, cards[2]=Mogambo),
  Total = card ranks ka sum (A=1..K=13, facedown 0) ya `gameData.total`.
  Table: main pair (Mogambo/Daga match spread) + `3 Card Total` Fancy2 single
  (lay/back lbhav/bbhav dynamic); book span `mr-2 book-*` (casino-book class
  NAHI). Last-results W/L (win==1 -> W). Book unit-verified: Back Daga@1.17
  -> Daga -17/Mogambo +100/3CT 0; Back 3CT -> sirf 3CT -(o-1)*st.
- **lucky5** (Lucky 6): sab selections fancy singles; L/H/T results strip
  (win 1/2/0); result rdesc "Winner#OddEven#Color#Card"; casino-min-max
  static blocks (RangeInfo collapse nahi).

## Known backend gaps (details missing-apis.md me)

- `last-results` upstream flaky: primary 3s timeout → fallback 8s bhi kabhi
  exceed (`{"success":false,"error":"timeout of 8000ms exceeded"}` aata hai).
- Stake buttons: frontend `/user/stake-button-values` use karta hai; admin
  read-only hai isliye static `[25,50,100,200,500,1000]` rakhe hain.
