# Missing / incomplete backend APIs (admin panel)

Jo APIs frontend (admin) ko chahiye par backend pe abhi nahi hain — deployed
`https://admintenexch.codefactory.games/api` pe MASTER token se curl karke
verify kiya gaya (21/07/2026). Naya endpoint milte hi yahan se tick karke
frontend wire karna hai.

---
    
## 1. Login History — `/admin/reports/user-history` page (Login History tab)

- **Status:** ✅ DONE (22/07/2026) — `GET /admin/reports/login-history` live,
  frontend wired (`UserHistory.jsx` ab yahi use karta hai, bet-history nahi).
- Query: `username`, `fromDate`, `toDate`, `page`, `limit`
- Response rows: `{ id, username, login_at, ip }` + pagination
  (`{ total, page, limit, totalPages }`)
- Data source: `user_activity_logs` (action `LOGIN` / `LOGIN_2FA`) — USER aur
  STAFF dono targets resolve hote hain, downline scope check ke saath
  (user → `getUserIdsByHierarchy`, staff → descendant-staff walk; outside
  downline → 403 `User is not in your downline`).
- Login logging pehle se thi, isliye purana data bhi dikhta hai (~645 rows).

## 2. Change Password History — `/admin/reports/user-history` page (2nd tab)

- **Status:** ✅ DONE (22/07/2026) — `GET /admin/reports/password-history`
  live, frontend wired. Same query params + downline check as #1.
- Response rows: `{ id, username, changed_at, ip, changed_by }`
- Data source: `user_activity_logs` action `PASSWORD_CHANGE`, jo ab TARGET
  account ke against log hota hai in sab jagah:
  - user self change (`/api/user/change-password`)
  - admin → downline user/staff (`/admin/staff-user-update`)
  - staff self (`/admin/staff-update-password`), owner self
    (`/admin/owner/update-password`)
  - `details` JSON mein `changed_by` (acting admin ka username) hota hai;
    absent ho to self-change maana jata hai.
- ⚠️ Pehle PASSWORD_CHANGE kabhi log nahi hota tha, isliye history deploy
  (22/07/2026) ke baad se hi accumulate hogi — purani changes ka record nahi.

## 3. IP Detail (geo lookup) — User History "Detail" (eye) modal

- **Status:** ✅ DONE (22/07/2026) — `GET /admin/ip-detail?ip=<ip>` live,
  modal ab isko use karta hai (ipwho.is hata diya).
- Backend proxy → `http://ip-api.com/json/<ip>?fields=status,message,country,city,mobile,query`
  (free tier HTTP-only hai, isliye browser se direct nahi ho sakta tha).
- Response: `{ success, data: { ip, city, country, mobile (boolean) } }` —
  `Mobile: True/False` ab sahi dikhta hai. Private/reserved IP pe placeholders
  (`-`) aate hain, error nahi.

## 4. User bet history downline check

- **Status:** ✅ EXPECTED BEHAVIOR (verified 22/07/2026) — yeh intentional
  hierarchy guard hai (`getUserBetHistory` step 3): target user resolve karke
  `getUserIdsByHierarchy` ke set mein check hota hai, bahar ho to 403.
  Login/password history endpoints bhi yahi guard use karte hain.

## 5. Bank page (`/admin/reports/bank`) — poora mock hai

- **Status:** koi API wired nahi; MOCK_ROWS dikh rahe hain
- **Chahiye:**
  - `GET /admin/bank/list?search=` — rows: username, fullName, cr, pts,
    pl (client), exposure, available, accountType
  - `POST /admin/bank/transfer` — `{ username/user_id, amount, masterPassword }`
    (row Submit + "All" transfer)
  - `POST /admin/bank/transfer-all` — `{ masterPassword }`
  - Galat transaction password pe message: `Master Password not valid.`

## 6. Assign Agent (`/admin/assign-agent`) — poora mock hai

- **Status:** koi API wired nahi; table hamesha empty
- **Chahiye:** `GET /admin/assign-agent/list` + Download CSV endpoint
  (fromDate ke saath user-creation CSV)
- **CSV ki date window (reference se, 2026-09-21; admin form ab yahi bhejega):**
  `fromDate` = aaj se 1 calendar mahina peeche se aaj tak; `toDate` user nahi
  chunta — `fromDate + 7 din`, aaj se aage kabhi nahi. Backend ko yahi window
  dobara validate karni chahiye (client pe bharosa nahi).

## 7. Account Statement — Game Report filters

- Frontend Load pe bhejta hai: `statement` (all/sport/casino ya credit/pts
  variants), `sportId`, `gameType`, `casinoType`
- Backend `GET /admin/...account-statement` in params ko support karta hai ya
  ignore — verify karna hai; sport/casino filtering server side chahiye.

## 8. Party Win Loss — `Level` / `Ptype` fields

- `GET /admin/pl/all` response mein `level` (Master/Agent/User format) aur
  `ptype` fields aane chahiye — abhi frontend `user_type` pe fallback aur
  `Ptype` ko hamesha `Point` dikhata hai.

---

## 9. General Lock enforcement message — TODO (abhi karna NAHI, bolne pe karna)

- **Kya chahiye:** jab locked game/series/match/market pe bet place ho to
  bet-place API ka error message reference-format mein aana chahiye (user site
  toast-body mein yehi dikhta hai):
  `Game is locked. Please contact Upper Level3.`
  - digit = jis upper ne lock lagaya uska staff `level` (L3 → Level3)
  - owner ka lock → `Upper Level1`
  - user par direct lock → direct upline ka level
- **Kahan karna hai:** `server/controller/admin/SportsLockController.js` →
  `checkSportsLock` ke `Bet not allowed: ...` messages ko upar wale format se
  replace karna; blocking lock ka `staff_id` → us staff ka `level` fetch karke
  digit nikalna. Bet placement (`sportsbet/sportbetscontroller.js`) pehle se
  yehi check call karta hai — sirf message format badalna hai.
- Lock save/get APIs (`/admin/sports-lock/*`) already kaam karte hain.

---

## 10. Current Bets (`/admin/reports/current-bets`) — filter gaps (22/07/2026)

UI sahi values bhejta hai (`gameType=sports|casino`, `betType=back|lay`,
`matchStatus=matchbet|unsettled|deletebet`) — issues backend
(`controller/admin/reportsController.js` → `getCurrentBets`) mein hain:

1. **`matchStatus` param poori tarah ignore hota hai** — destructure mein hi
   nahi hai. Matched/Unmatched/Deleted radios ka server pe koi asar nahi.
   Deleted bets kabhi return ho hi nahi sakte (where hamesha
   `status IN (OPEN/PENDING/matched...) AND result_status='pending'`).
   - Chahiye: `matchbet` → matched/open bets; `unsettled` → unmatched/pending;
     `deletebet` → deleted/void bets.
2. **`betType` exact match hai (`bet_type = 'back'`)** — DB mein bet_type raw
   case mein save hota hai (request se aaya hua, e.g. `BACK`) aur fancy bets
   pe `yes`/`no` ban jata hai (`sportbetscontroller.js` finalBetType). Filter
   case-insensitive + fancy mapping (back→yes, lay→no) hona chahiye.
3. **Casino tab hamesha empty** — query sirf `SportsBet` table pe hai with
   `game_type='casino'`, par casino bets alag table/model (`model/user/casino.js`)
   mein hain. Casino tab ke liye casino-bets source se data lana hoga
   (columns: Event Name, User Name, Nation, U Rate, Amount, Place Date, IP).
4. Sports tab MASTER (MasterUser1) pe empty aana partially legit bhi ho sakta
   hai — downline mein koi OPEN/pending bet na ho (curl pe total=0, filters ke
   bina bhi).

## 11. Casino Result response shape — UI FIX ho gaya (note only)

- `POST /casino/casino/last-results` kaam karta hai; response
  `data.data.res: [{ mid, win }]` deta hai (gmid/winnat nahi).
- Frontend mapping fix kar di gayi hai (22/07/2026) — ab `mid` → Market Id,
  `win` → Winner (Player A/B / suit / I-E mapping ke saath). Backend change
  ki zaroorat nahi.

---

## 12. Casino Result — Winner ka NAAM backend se aana chahiye (22/07/2026)
### ✅ IMPLEMENTED (23/07/2026) — naya combined endpoint

- **`POST /casino/casino/result-report` `{type}`** bana diya (server:
  `routes/user/casinoRoutes.js` + `casinoController.fetchResultReport` +
  `CasinoService.fetchCasinoResultReport`). Ye `last-results` fetch karke
  har mid ka `detail-results` call karta hai (5-concurrent chunks) aur
  `t1.winnat` se **`winName`** merge karta hai:
  `res: [{ mid, win, winName }]` — baaki shape last-results jaisi hi.
- Results immutable hain isliye per-mid winName **redis me 6h cache** hota
  hai (`casino_result_winname_<type>_<mid>`) — repeat loads pe upstream
  detail calls nahi lagti. detail-results ki apni 2s cache alag hai.
- **Verification (121 games API sweep, 94 ke live results the):** `winnat`
  ~sab games me sahi display naam hai — dolidana `"3,4"` (dice), dt/pdt/tdt
  `Dragon/Tiger/Tie`, mogambo `Mogambo`/`Daga/Teja`, goal/goal2 player names,
  aaa `Amar/Akbar/Anthony`, btable movie names, card32 `Player 11`, race20
  `K Heart`, worli/worli2 3-digit patti, roulette numbers, sicbo dice, etc.
  Edge cases jahan winnat khali/`Result` tha (ab3/ab4, joker1/joker120,
  teenunique) → server rdesc ke pehle `#`-segment pe fallback karta hai
  (`Win`, `Player A/B`, `Won`). Raw sweep data:
  scratchpad `winners_raw.json` (collect_winners.py).
- **Admin UI** (`src/pages/reports/CasinoResult.jsx`): pehle `result-report`
  try karta hai, fail (purana deploy) to `last-results` fallback; Winner
  column `winName || mapWinDisplay(win)` dikhata hai — deploy se pehle bhi
  page kaam karta rahega.
- ⚠️ **Deploy pending:** deployed server pe pull + restart chahiye tabhi
  naya endpoint milega.
- **Ab bhi missing (backend/provider):** reference site ke report me ~300
  rows + pagination hai; hamara upstream `casino/result` sirf **last 10**
  results deta hai. Full history/pagination ke liye provider ka history API
  (ya server-side result archiving via settlement worker) chahiye —
  `date`/`limit`/`search` params abhi upstream pe ignore hote hain.

---

## 13. Live Casino Report (`POST /admin/reports/casino-report`) — gaps (22/07/2026)

- API kaam karti hai; contract: `{ role, username, type: 'SettleBet'|'UnsettleBet', vendor }`.
  (Frontend payload fix ho gaya — pehle `type:''` bhej rahe the → 400.)
- **`date` param backend ignore karta hai** — SQL mein timestamp pe koi date
  filter nahi hai. Settled tab pe reference datepicker hai, to backend ko
  `date` (ya from/to) se `t.timestamp` filter karna chahiye.
- **Pagination nahi hai** — saare records ek saath aate hain
  (`ORDER BY timestamp DESC`, no limit/offset). Bade data pe page/limit
  support chahiye.
- MASTER (MasterUser1) pe `total_users: 1`, data empty — downline mein abhi
  koi js_game_transactions record nahi (legit ho sakta hai). Kisi aur staff
  (jiske under users ne live casino khela ho) se verify karna.
- `username` hierarchy-resolve hota hai (`getUserIdsByHierarchy(role, username)`)
  — role hamesha LOGGED-IN wale ka bhejna hota hai, selected client ka nahi;
  Lordx jaisa user MASTER ke under nahi ho to "No users found under given
  hierarchy" aata hai.

---

## 14. SportBook Report (`/admin/reports/sportbookreport`) — API MISSING (22/07/2026)

- Frontend `POST /api/admin/reports/sportbook-report` call karta hai →
  **`Cannot POST` (404)** — endpoint backend pe hai hi nahi.
- **Chahiye:** `POST /admin/reports/sportbook-report`
  - Body: `{ username, vendor, date (settled tab pe), status: 'settled'|'unsettled' }`
    (ya casino-report jaisa `type: 'SettleBet'|'UnsettleBet'` contract — dono
    pages ek pattern pe rakhna better)
  - **Unsettled tab bina provider select kiye bhi call karta hai** — `vendor`
    empty/optional aane pe saare providers ke unsettled bets lautane hain
    (settled tab pe vendor required hai, UI wahan is-invalid dikhata hai)
  - Response rows (settled): `{ round_id, transaction_type, amount, total, bet_id, timestamp }`
  - Response rows (unsettled): same minus `total`
  - Hierarchy-scope (logged-in ke downline tak) + date filter
- **Provider (Select) dropdown ki list bhi backend se aani chahiye** —
  reference pe sportbook ke liye select khali hai (`<option value="">Select</option>`
  ke alawa kuch nahi), providers list dene wala endpoint bhi nahi hai.
- UI ready hai (`src/pages/reports/SportbookReport.jsx`) — endpoint aate hi
  chal jayega.

---

## 15. Turnover Report (`/admin/reports/turnover`) — API MISSING (22/07/2026)

- Frontend `POST /api/admin/reports/turnover` call karta hai →
  **`Cannot POST` (404)** — endpoint backend pe nahi hai.
- **Chahiye:** `POST /admin/reports/turnover`
  - Body: `{ user_id (optional — selected client, warna pura downline),
    type: 'sports'|'casino', fromDate, toDate,
    sport_id + gtype (sports pe — Sports List/Game Type dropdowns, optional),
    game_name (casino pe — Casino List dropdown, optional) }`
  - Sirf **last 7 days** ka data allowed (page ka alert bhi yehi kehta hai) —
    purani range pe empty/error
  - Response (single summary object):
    `{ loss_turn_over, loss, win_turn_over, win, total_turn_over, total_pl }`
  - Hierarchy-scope: logged-in ke downline ke bets se aggregate
- UI ready hai (`src/pages/reports/Turnover.jsx`) — Type select (Sports=1 /
  Casino=2 UI values → payload 'sports'/'casino'), 7-day default range,
  Load-only fetch, exports.

---

## 16. User Authentication list (`/admin/reports/authlist`) — 2FA field missing (22/07/2026)

- Page `GET /admin/users/all-details` use karta hai — response ke wallet
  objects mein **koi authentication/2FA field nahi aata** (curl se verify:
  username, role, balances etc. hi hain; `telegram2FAEnabled` absent).
- Reference Authentication column dikhata hai: `no authentication` /
  (2FA wale users pe telegram wala label).
- **Chahiye:** all-details ke har wallet mein `telegram2FAEnabled` (ya ek
  `auth_type` field: 'none' | 'telegram') aana chahiye — Staff/User dono ke
  records se.
- UI mapping ready hai: `telegram2FAEnabled ? 'telegram app' : 'no authentication'`
  — field aate hi sahi values dikhengi (abhi sab 'no authentication').

---

## 17. Fraud Report (`/admin/reports/fraud`) — API MISSING (22/07/2026)

- Frontend `GET /api/admin/reports/fraud?page&limit` call karta hai →
  **`Cannot GET` (404)** — endpoint backend pe nahi hai.
- **Chahiye:** `GET /admin/reports/fraud`
  - Query: `page`, `limit` (+ optional `search`)
  - Response rows: `{ sno, username, eventName, marketDate, marketName,
    amount, fraudDate, remark }` + pagination `{ totalPages }`
  - Hierarchy-scope (logged-in ke downline ke fraud-marked bets)
  - Action column ke liye ba
  ad mein kya action chahiye (unmark/void?) —
    reference pe abhi khali hai
- UI ready hai (`src/pages/reports/FraudReport.jsx`) — auto-load + loader,
  exports, search/pagination sab wired.

---

## 18. User Register Detail (`/admin/reports/userregisterdetail`) — API MISSING (22/07/2026)

- Frontend `GET /api/admin/reports/user-register-detail` call karta hai →
  **`Cannot GET` (404)** — endpoint backend pe nahi hai.
- **Chahiye:** `GET /admin/reports/user-register-detail`
  - Query: `page`, `limit`, `username` (optional — selected client),
    `type: 1 (All) | 2 (Created Date) | 3 (Last Login Date)`
  - Response rows (13 columns): `{ username, agent_name, phone_number/mobile,
    created_at, last_login, first_deposit_date, last_deposit_date, deposit,
    sports_balance, casino_balance, third_party_credit_balance,
    sport_book_balance, referral_code }` + pagination `{ totalPages }`
  - Hierarchy-scope (downline users)
- UI ready hai (`src/pages/reports/UserRegisterDetail.jsx`) — Load-only fetch
  + loader, Type filter, exports, search/pagination sab wired (snake_case aur
  camelCase dono field-names handle karta hai).

---

## 19. Total Profit Loss (`POST /admin/reports/total-profit-loss`) — WORKING, verify points (22/07/2026)

- API **maujood hai aur data de rahi hai** (MASTER token se verify — sports
  array mein real rows aaye). Frontend contract:
  `{ clientName (optional), fromDate, toDate, type: '0'|'2'|'3'|'4'|'5' }`
  → response: `{ success, sports[], casino[], thirdParty[], sportbook[] }`
  - sports row: `{ event_name (sport ka naam, e.g. Football), game_type,
    opening, closing, profit_loss }`
  - casino/thirdParty/sportbook rows: `{ casino_name|third_party_name|
    sportbook_name, opening, closing, profit_loss }`
- **Verify/complete karna:**
  1. `type` param server side respect hota hai ya nahi (2=Sports, 3=Casino,
     4=Third Party, 5=Sportbook) — abhi frontend hi sections filter karta hai,
     par type bhejne pe backend sirf wahi section compute kare to fast hoga.
  2. `thirdParty` aur `sportbook` arrays hamesha aati hain ya missing ho
     sakti hain — reference in sections ke liye bhi data dikhata hai
     (Third Party Report / Sportbook Report), abhi dono empty aa rahi thi.
  3. `fromDate`/`toDate` range filter verify karna (opening = range se pehle
     ka balance, closing = range ke end ka — reference semantics).
  4. `clientName` optional — na bheje to pura downline aggregate.

---

## 20. User Win Loss (`POST /admin/reports/user-win-loss`) — WORKING, `sportbook` field missing (22/07/2026)

- API kaam karti hai (MASTER token se verify — real row aayi:
  `{ user_id, username, sport, casino, third_party, profit_loss }`).
- **Missing:** response rows mein **`sportbook`** field nahi aata — reference
  table mein `SportBookpts` column hai. Backend ko har row mein `sportbook`
  (sportbook ka win/loss pts) add karna hai aur `profit_loss` mein include
  karna hai.
- Contract: request `{ username (optional), fromDate, toDate }` →
  `{ success, data: [{ user_id, username, sport, casino, sportbook,
  third_party, profit_loss }] }`
- UI ready hai — `sportbook` field aate hi column mein values dikhengi
  (abhi 0 dikhta hai).


---

## 22. Casino My Bets — downline APIs WIRED, IP/Browser SELECT fix APPLIED (deploy pending) (23/07/2026)

- Admin casino "My Bets" sidebar + "View More" modal ab in existing APIs se
  chalta hai (d99-admin wala hi pattern, `server/d99/routes/betList.routes.js`):
  - `GET /api/d99/bet-list/casino/open-downline?gameName=<gtype>` — sidebar,
    5s poll. Auth + downline filter + `users` join (username milta hai).
  - `GET /api/d99/bet-list/casino/all-downline?gameName=<gtype>` — View More
    modal (LIMIT 100).
  - Row fields: `id, user_id, username, created_at, description(game_name),
    selection, game_type, odds, amount(stake), status, source`.
- **IP + Browser Details blank — FIXED (23/07/2026, backend me apply kar diya):**
  - `server/d99/controller/betList.controller.js` ke dono downline SELECTs
    me `cb.ip_address, cb.browser` add kar diye
    (`getCasinoOpenBetsDownline` + `getCasinoAllBetsDownline`) —
    `node --check` pass. **Deployed server pe pull + restart karna hai.**
  - Frontend (user-site) se KUCH NAHI chahiye — placeBet payload me
    `browser` field nahi jata, lekin controller fallback
    (`browser || req.headers['user-agent']`) se browser save hota hai aur
    IP server khud capture karta hai (`x-forwarded-for`/`x-real-ip`).
    Admin UI already `bet.ip_address`/`bet.browser` map karta hai.
  - Note: purane bets (geodata capture se pehle ke) me ye NULL rahenge —
    sirf naye bets me values aayengi.
- `POST /casino/casino/mybets` (user-site wali) admin me ab use nahi hoti.

## 23. SuperOver (superover3) — first-innings score / winner message all-data me nahi (23/07/2026)

Deployed API pe verify kiya: `POST /casino/casino/all-data {type:"superover3"}` deta hai
`{ t1: { card: "3DD|KDD|1|1", gmid, lt, ft, scard, iplay, ... }, t2: null }`.

- `card` sirf CURRENT innings ke 4 balls deta hai — reference admin page dono
  innings ka score dikhata hai (e.g. "IND 7-1 (0.3)" + "AUS 0-1 (0.1)" + "IND won
  the match"). Pehli innings ka total aur match-result message kisi field me nahi
  aata, isliye admin page (`games/superover3/SuperOver3.jsx`) current innings
  card-string se score compute karta hai aur dusri row 0-0 (0.0) best-effort
  dikhata hai (`scard` = innings number 1/2 assume kiya hai).
- `t2` (bookmaker/fancy markets) rounds ke beech `null` aata hai — market-container
  tab khali rehta hai (reference dump me bhi khali tha). Live betting phase ka
  admin market DOM reference dump abhi nahi mila hai.

Fix chahiye to backend ko upstream se innings-wise scorecard (dono innings ke
runs/wickets/overs + winner message) pass-through karna hoga.

## 24. 5Five Cricket (cricketv3) — scorecard ka accumulated total/CRR/RR/"Needed" all-data me nahi (25/07/2026)

Deployed API pe verify kiya: `POST /casino/casino/all-data {type:"cricketv3"}` deta hai
`{ t1: { card: "1|1|1|1|1|1", gmid, lt, ft, scard: 1, ename: "Australia Vs India
5Five Cricket", gtype:"cricketv3", ... }, t2: [ Bookmaker(dtype2/match1),
Fancy(dtype6) ] }`.

- Reference admin DOM scorecard dikhata hai: `AUS 65-6 (5.0)`, `IND 37-2 (3.0)`,
  `CRR 12.33`, `RR 14.50`, aur row1 pe `IND Needed 29 runs from 12 balls`. Ye
  accumulated innings totals + required-run-rate + target message KISI t1 field me
  nahi aate — `t1.card` sirf current innings ke 6 cards deta hai aur `scard` sirf
  innings number (1/2) hai. Isliye admin page (`games/cricketv3/CricketV3.jsx`)
  #23 wale superover3 jaisa best-effort karta hai: current card-string se score
  compute + dusri row 0-0 (0.0); RR aur "Needed" message render nahi hote.
- Markets (`t2`) SuperOverMarkets se render hote hain (Bookmaker + Fancy) — ye
  theek aata hai.

Fix chahiye to backend ko upstream se innings-wise scorecard (dono innings ke
totals, CRR/RR, target/needed message) pass-through karna hoga — same as #23.

## View More bets modal (game-details)
- Reference search form server-side hai (Username/Amount/IP + All/Back/Lay/Deleted radio).
- Abhi `getMatchDownlineBets` se saare bets laake **client-side filter** kiya (verified endpoint yahi hai; dedicated search-bets endpoint nahi mila).
- "Deleted Bets" tab + `status:"deleted"` bets, aur per-bet `ip_address`/`run` fields — deployed API pe verify karke confirm karna (token expire tha).
- "Detail" (B Details) + Action checkbox abhi UI-only (koi delete/detail endpoint wire nahi).

## Market Analysis dashboard endpoint — ✅ RESOLVED
- `POST /admin/reports/market-analysis/dashboard` ab **backend me bana diya** (`reportsRoutes.js` + `ReportsController.getMarketAnalysisDashboard`).
- Exposure ko `event_id` pe group karta hai → ek event = ek entry (saare markets andar). Deploy ke baad frontend live chalega.

## Credit Activity modal (CR column click) — wired
- **Deposit** `POST /admin/wallet/deposit/add` · **Withdraw** `POST /admin/wallet/withdraw` — body `{ userId, amount, userType, transactionPassword, remark }` (controller: userId/amount/userType required; `transactionPassword` verifyTransactionPassword middleware se). `remark` backend consume karta hai ya nahi — confirm karna.
- **History** `POST /admin/ledger/user/history` body `{ user_id, page, limit }` — verified 200 par data empty tha. Table row fields (super_user / user / transfer_from / amount / created_at) **fallback-guess** hain; ek real record aane par exact keys confirm karke map karna.

## Report pages — date range ka backend support (2026-09-07)

Frontend ab **paanch report pages pe From/To range** deta hai (Account Statement,
Activity Log, Casino Results, Live Casino Bets, SportBook Bets). Backend har jagah
support nahi karta — deployed API (`https://api.tenexchn.com/api`) pe verify kiya:

| page | frontend bhejta hai | backend |
|---|---|---|
| Account Statement | `fromDate` / `toDate` | ✅ chalta hai |
| Activity Log | `startDate` / `endDate` → `GET /user/activity-logs` | ✅ chalta hai (401 without token, route maujood) |
| Casino Results | `dateFrom` / `dateTo` | ❌ `POST /casino/casino/result-report` **sirf `{ type }`** leta hai — date param hai hi nahi |
| Live Casino Bets | `dateFrom` / `dateTo` → `GET /jsGames/history` | ❌ **404** — route mount hi nahi hai |
| SportBook Bets | `dateFrom` / `dateTo` → `GET /jsGames/sportbook-history` | ❌ **404** — route exist nahi karta |

Detail:
- `/api/jsGames` pe `jsgames/routes.js` mounted hai (server.js:334) aur usme koi
  `history` route nahi. `/history` sirf `jsgamesv2/gameRoutes.js` me hai, jo
  `/api/jsGamesv2` pe mounted hai (server.js:335) — aur wo bhi date ignore karke
  upstream ko sirf `user_id` forward karta hai
  (`jsgamesv2/GameController.js` → `userhistory`).
- Matlab Live Casino Bets aur SportBook Bets pages **abhi koi data dikha hi nahi
  sakte**, date range se pehle. Range UI ready hai; backend banne par frontend
  ke `dateFrom`/`dateTo` params seedha kaam karenge.
- Casino Results ka data aata hai par filter nahi ho sakta: rows me sirf `mid`
  aur winner hai, koi date field nahi — client-side filter bhi possible nahi.

Chahiye: `GET /jsGames/history` aur `GET /jsGames/sportbook-history` (dateFrom,
dateTo, type, page, limit), aur `result-report` me date range + rows me date field.
