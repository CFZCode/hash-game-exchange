# Users / Active Users — Deposit & Withdraw buttons → Settlement API

Frontend-only change, no backend change. Applies to BOTH pages:

- `http://217.216.78.106:5175/admin/users`
- `http://217.216.78.106:5175/admin/activeusers`

## What to change (same on both pages)

The **D (Deposit)** and **W (Withdraw)** action buttons should open the
settlement-style modal (same design as the bank WITHDRAW/DEPOSIT modal) and
call the settlement API instead of the old deposit/withdraw API.

## API (same endpoint for both buttons)

```
POST /api/admin/wallet/points/settle
```

## Payload (send exactly these keys)

```json
{
  "userId": "<child user id>",
  "username": "<child username>",
  "points": 100,
  "remark": "<remark text>",
  "transactionPassword": "<transaction code>"
}
```

## Amount sign rule (important)

- **Deposit** → `points` must be **positive** (e.g. `100`)
- **Withdraw** → `points` must always be **negative** (e.g. `-100`), even
  though the user types a positive number in the input.
  So for withdraw: `points = -Math.abs(amount)`

## Modal layout (same as the bank module)

- Row 1: logged-in parent username — current balance | projected new balance
- Row 2: child username — current balance | projected new balance
- Row 3: **Profit/Loss** — current | after settlement (same as it shows in the bank modal)
- Then: Amount input, Remark textarea, Transaction Code (password) input, Submit button

## Error handling

The transaction code is verified server-side. On a wrong code the API returns
400 with a message and `attemptsLeft` — show that message in the modal.

On success it returns:

```json
{ "success": true, "message": "Settlement done" }
```

Close the modal and refresh the row balances.
