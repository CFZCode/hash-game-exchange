# Casino game — verify / check process (repeatable)

Jab bhi user bole **"check <gtype>"** / "isko dekh" / "verify karo", ye poora loop
chalao — **live API call karke** data se, aur reference DOM se cross-check karke.
Ye doc [[casino-build-process.md]] ka **QA/verification** counterpart hai.

> Rule: guess mat karo. Har claim **live all-data API** + **frontend/reference se
> verify** karke hi bolo. Build ke saath khatam karo.

---

## STEP 0 — Identify (10s)
- Route slug vs API gtype nikaalo (e.g. `teenpattit20c` → `teen20c`,
  `jokerteenpatti1` → `joker1`, `poisonteenpatti20` → `poison20`).
- `gameRegistry.js` me dedicated page registered hai? Nahi → **register karo**
  (generic screen galat/aadha render karta hai — mogambo/joker20 case).
- `config/casinoGames.js` me `name`/`tableClass`/`cardLayout`/`dataType` sahi?

## STEP 1 — LIVE DATA (MUST, hamesha)
```bash
curl -s -m 40 -X POST "https://admintenexch.codefactory.games/api/casino/casino/all-data" \
  -H 'Content-Type: application/json' -d '{"type":"<gtype>","data":{}}' \
  | python3 -m json.tool | head -120
```
- `sub[]` / `child[]` / `t2[].section[]` ke fields (`nat/b/l/bs/gstatus/min/max/
  card/odds`) ko us game ke BetTable ke expected props se match karo.
- **Naam/label API se lo** (e.g. "Teenpatti Joker 20-20" vs "Poison Teenpatti" —
  live title API/reference se, config se andha nahi).
- `visible`, `gstatus` (OPEN/SUSPENDED/0) note karo — suspended rendering ke liye.

## STEP 2 — Card mapping (MUST — frontend authoritative)
- Card sequence **frontend se verify** karo (`frontend/src/components/casino/
  cards/<X>Cards.jsx`), dump se guess NAHI:
  - teenpatti layout: A=`[0,2,4]`, B=`[1,3,5]` (NO leading joker).
  - poison: leading Poison card index 0, phir interleaved A=`[1,3,5]` B=`[2,4,6]`.
  - **joker120 (Unlimited Joker 20-20)**: NO leading joker — offset 0, A=`[0,2,4]`
    B=`[1,3,5]` (reference+data se verified). JokerPage default `cardOffset=1`
    GALAT hai iske liye — `cardOffset={0}` pass karna zaroori. Result already
    Joker1Result (parseJoker1Cards [0,2,4]/[1,3,5]) use karta hai = sahi.
  - joker1 bhi offset 0 (cardLayout `teenpatti`). Shared page me `cardOffset` prop.
- Node se compute karke actual API card string pe cross-check karo.

## STEP 3 — Structure vs reference (mobile + web dono)
Reference DOM (production tenexch.com admin) se in cheezon ko match karo:
- **Video section**: `casino-video-title`/`game-header`, iframe, cards overlay
  (hide-cards jab sab facedown), `casino-timer` + mobile `casino-time-digit
  d-none-desktop`, right-icons (game ke hisaab se Home/Rules/LR — kuch me sirf
  Rules).
- **Last-results strip POSITION (bahut common bug)**:
  - teenpatti-joker family (poison/joker20): **web → casino-video me
    (`!isMobile`)**, **mobile → table `footer`/casino-detail me**.
  - five-cricket/super-over (lucky15/superover2/ballbyball/goal): strip
    **market-container ke BAAD** (+ casino-remark ke baad), casino-video me NAHI.
  - teen20b/teen20c style: video me `d-none-small`, casino-detail me
    `d-none-desktop` (dono render, CSS switch).
- **Last-results strip `win` mapping (common bug)**: `win` field = **winning
  sid**, NOT 1/2/3. Multi-outcome games (dtl20: Winner D=1/T=21/L=41) — sid
  all-data se verify karo, warna T/L jaise outcomes fallback me gir ke galat
  letter dikhate hain. Letter spacing bhi reference se match (`'D '`/`' T '`/
  `' L '`, teen20 A/B jaisa).
- **Bet table columns**: reference grid exact (`col-12 col-md-6` vs `col-6
  col-md-6` vs `col-6 col-md-4`) — mobile column count galat aata hai.
- **Mobile rows**: `bet-table-mobile-row d-none-desktop` (team-name + book) +
  desktop `nation-name d-none-mobile`.
- **Book span**: hamesha visible — `book-black` at 0 (d-none/hide NAHI),
  minus red / plus green. teenpatti book span = `mr-2 book-*` (casino-book class
  reference me kabhi nahi hota — check karo).
- **Range info**: `fa-info-circle` + `icon-range collapse` (R:min-max, K/L).
  Main title me bhi ho sakta (teen41 mobile).
- **Extra sections**: reference me jo NAHI hai wo mat dikhao (teen41 mobile me
  Under/Over nahi, mogambo me casino-book class nahi) — API me ho tab bhi
  reference-faithful raho, aur user ko batao.

## STEP 3.5 — Right sidebar (MUST — aksar miss hota hai)
- `casino-right-sidebar` me My Bets card ke **neeche extra cards** check karo:
  Pair Plus payouts table (teen20/teen20c/teen41), ya koi game-specific rules
  card. Page se `<CasinoMyBetsSidebar ... extra={...card} />` pass hona chahiye
  (sidebar `extra` prop support karta hai). Bet-table pe focus karke sidebar
  skip mat karo.

## STEP 4 — Suspended / no-val / odds-color (MUST)
- **Suspended box**: `bl-box back no-val suspended` + `data-title="SUSPENDED"`,
  odds span `—` (U+2014). CSS `.suspended:before` = **lock icon** overlay +
  `.suspended:after` gray cover — page pe grayed+lock dikhta hai, `—` peeche
  (devtools DOM tree me `—` box jaisa dikhta hai — wo page pe nahi). `lock.svg`
  `src/img/` me hona chahiye.
- **Bookmaker/match suspend**: row pe `suspendedtext` (`.suspendedtext:after`
  = "SUSPENDED" red text overlay via `content: attr(data-title)`).
- **no-val** (lay not offered) → visible `—` (lock nahi).
- **Odds color flash (super-over/fancy)**: `bg-success` (up) / `bg-danger`
  (down) SIRF genuine value-change pe, **2 second** phir gayab. Appearance
  (0/suspended→value) pe color NAHI (`before !== 0` guard) — warna load pe
  "itna saara color" (sab green).

## STEP 5 — Remark / marquee (MUST)
- Har `casino-remark`: `const REMARK_ICON = 'https://wver.sprintstaticdata.com/
  v230/static/front/img/icons/remark.png'` + `<img src={REMARK_ICON} />` +
  **`<marquee>{remark}</marquee>`** (marquee-wrapper/marquee-content NAHI).

## STEP 6 — Rules images (MUST)
- `<img src="/admin/assets/casino/rules/...">` — **`/admin/` prefix zaroori**
  (Vite base `/admin/`; bina prefix 404). Image `public/assets/casino/rules/`
  me downloaded honi chahiye. Rules content frontend `rules/<X>Rules.jsx` se.

## STEP 7 — Book unit-test (MUST — jahan betting/exposure hai)
- `getMarketsForGame` + `computeAdminBook` ko REAL `sub[]` pe node+esbuild se
  chalao: match-etype → spread; fancy/fancy1/Fancy2 → single; sid-scoped
  (`sid:<sid>`) lookup.

## STEP 8 — BUILD
```bash
cd admin && npm run build 2>&1 | grep -iE "error|✓ built"
```
Error zero, `<Game>-*.js` chunk banna chahiye (dedicated page code-split
confirm).

---

## 2ND-LEVEL VERIFICATION (MUST — pehle pass ke baad)
Pehla pass ho jane ke baad, dobara **live API se aur reference DOM se**
independently cross-check — apne output pe bharosa mat karo:
1. **Re-curl all-data** — fields abhi bhi map ho rahe (round badalne pe
   suspended/odds badalte hain)?
2. **Reference DOM diff** — normalized (numbers → `#`) karke admin render vs
   reference: koi class/attr/structure mismatch? (`casino-book` extra,
   `float-right` missing, column count, strip jagah, extra section).
3. **Mobile + web dono** — `d-none-desktop` / `d-none-small` / `d-none-mobile`
   sahi switch kar rahe?
4. **Suspended + active dono states** — API me OPEN aur SUSPENDED dono pe
   render sahi (lock/—/color)?
5. **Card mapping** — frontend component se ek aur baar confirm (offset/
   interleave).
6. Jo bhi mismatch mile → fix → build → phir se 2nd-level. Zero-mismatch tak.

## Verified games (is process se) — running log
- teen20c, lucky15, superover2, ballbyball: strip position fix (market ke baad).
- teen41: mobile Main-only (Under/Over desktop-only), range-info + book float-right.
- ballbyball: col-12 col-md-6 grid, bl-box odds+size, collapse header.
- joker1: cardOffset 0 (teenpatti layout).
- poison20/joker20/mogambo: registered + full structure.
- superover*: odds bg-success/danger 2s flash, value-change only.
- sab games: `<marquee>` + REMARK_ICON; rules img `/admin/` prefix.
