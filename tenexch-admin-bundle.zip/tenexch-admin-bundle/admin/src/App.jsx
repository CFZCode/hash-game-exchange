import { BrowserRouter as Router, Routes, Route, useLocation, useNavigate, Navigate } from 'react-router-dom'
import { useEffect } from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { setCredentials, logout } from './store/slices/authSlice'
import { authService } from './services/authService'
import { tokenExpiresAt } from './utils/tokenExpiry'
import useHiddenTabLogout, { HIDDEN_TAB_LOGOUT_20_MIN } from './hooks/useHiddenTabLogout'
import { getAdminSocket, setAdminSessionId } from './services/socketClient'
import Login from './pages/login/Login'
import ChangePassword from './pages/login/ChangePassword'
import ChangePasswordSuccess from './pages/login/ChangePasswordSuccess'
import TwoFactorAuth from './pages/login/TwoFactorAuth'
import ProtectedRoute from './components/ProtectedRoute'
import SystemTracker from './pages/system-tracker/SystemTracker'
import Layout from './components/Layout'
import Home from './pages/Home'
import MarketAnalysis from './pages/MarketAnalysis'
import InsertUser from './pages/users/InsertUser'
import ActiveUsers from './pages/users/ActiveUsers'
import Users from './pages/users/Users'
import MultiLogin from './pages/MultiLogin'
import AssignAgent from './pages/AssignAgent'
import CasinoGamePage from './pages/Casino-games'
import Bank from './pages/reports/Bank'
import AccountStatement from './pages/reports/AccountStatement'
import ProfitLoss from './pages/reports/ProfitLoss'
import CurrentBets from './pages/reports/CurrentBets'
import UserHistory from './pages/reports/UserHistory'
import UserLock from './pages/settings/UserLock'
import SecureAuthBot from './pages/settings/SecureAuthBot'
import SecureAuth from './pages/settings/SecureAuth'
import BufferTime from './pages/settings/BufferTime'
import Commission from './pages/settings/Commission'
import MaxOdds from './pages/settings/MaxOdds'
import AutoVoid from './pages/settings/AutoVoid'
import VirtualBetLimits from './pages/settings/VirtualBetLimits'
import BetLimits from './pages/settings/BetLimits'
import ThirdPartyGameLimit from './pages/settings/ThirdPartyGameLimit'
import CasinoResult from './pages/reports/CasinoResult'
import LiveCasinoReport from './pages/reports/LiveCasinoReport'
import SportbookReport from './pages/reports/SportbookReport'
import Turnover from './pages/reports/Turnover'
import AuthList from './pages/reports/AuthList'
import FraudReport from './pages/reports/FraudReport'
import UserRegisterDetail from './pages/reports/UserRegisterDetail'
import TotalProfitLoss from './pages/reports/TotalProfitLoss'
import UserWinLoss from './pages/reports/UserWinLoss'
import CasinoList from './pages/casino/CasinoList'
import VipCasino from './pages/casino/VipCasino'
import VirtualCasino from './pages/casino/VirtualCasino'
import PremiumCasino from './pages/casino/PremiumCasino'
import TemboCasino from './pages/casino/TemboCasino'
import CasinoManage from './pages/casino/CasinoManage'
import GameDetails from './pages/game-details/GameDetails'
import MatchSettlement from './pages/settlement/MatchSettlement'
import CarouselPanel from './pages/carousel/CarouselPanel'
import Fixtures from './pages/settings/Fixtures'
import HomeSliderPanel from './pages/homeslider/HomeSliderPanel'
import GamePriorityPanel from './pages/game-priority/GamePriorityPanel'
import FancySettlement from './pages/settlement/FancySettlement'
import VoidBets from './pages/settlement/VoidBets'
import CasinoSettlement from './pages/settlement/CasinoSettlement'
import NoAccess from './pages/NoAccess'
import BToastContainer from './components/BToast'

function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  )
}

function AppContent() {
  const location = useLocation()
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const { isAuthenticated, user, token } = useSelector((state) => state.auth)
  // Apache aliases /admin to this SPA, so '/admin' and '/admin/' are both the
  // login URL — the bare form only survives client-side navigation, since a hard
  // load gets a 301 to the trailing-slash form.
  const isLoginPage = location.pathname === '/admin' || location.pathname === '/admin/'
  const isChangePasswordPage = location.pathname === '/admin/change-password'
  const isPublicPage = isLoginPage || isChangePasswordPage
    || location.pathname === '/admin/loginauth/2'
    || location.pathname === '/admin/loginauth/3'

  // Fetch profile on app initialization if token exists but user is not loaded
  useEffect(() => {
    const initializeAuth = async () => {
      const activeRole = localStorage.getItem('activeRole')
      const storedToken = activeRole === 'owner'
        ? localStorage.getItem('ownerToken')
        : activeRole === 'staff'
          ? localStorage.getItem('staffToken')
          : activeRole === 'executive'
            ? localStorage.getItem('executiveToken')
            : localStorage.getItem('adminToken')

      // Executives have NO profile endpoint — restore the session straight
      // from localStorage and never call getProfile (it would 401 and log
      // the executive out on every hard refresh)
      if (activeRole === 'executive') {
        if (storedToken) {
          dispatch(setCredentials({
            token: storedToken,
            user: user || JSON.parse(localStorage.getItem('adminUser') || 'null'),
            role: 'executive'
          }))
        }
        return
      }

      if (storedToken && !user) {
        try {
          console.log('Initializing auth: Fetching profile...', { role: activeRole })
          const profileResponse = activeRole === 'owner'
            ? await authService.getOwnerProfile()
            : await authService.getProfile()

          const userData = activeRole === 'owner'
            ? profileResponse.data
            : profileResponse.data?.user

          if (profileResponse && profileResponse.success && userData) {
            dispatch(setCredentials({
              token: storedToken,
              user: userData,
              role: activeRole || 'staff'
            }))
          } else {
            console.warn('Invalid profile response, logging out')
            dispatch(logout())
          }
        } catch (error) {
          console.error('Failed to fetch profile on init:', error)
          if (error.response?.status === 401) {
            dispatch(logout())
          }
        }
      } else if (storedToken && user) {
        dispatch(setCredentials({
          token: storedToken,
          user: user,
          role: activeRole || 'staff'
        }))
      }
    }

    if (!isPublicPage) {
      initializeAuth()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Session auto-logout: every JWT (owner / staff / executive) now carries a
  // 30-minute `exp` (server/.env JWT_EXPIRATION). authMiddleware rejects the
  // token past that instant, so log out at the same moment instead of leaving
  // a dead session on screen until the next API call 401s. Reads the token's
  // own `exp`, not a local clock, so a refresh or a slept tab still ends at the
  // right time; an already-expired token on boot logs out before the profile
  // fetch above can fire. The 401 interceptor in services/api.js stays as the
  // backstop.
  useEffect(() => {
    if (!token) return undefined
    const expiresAt = tokenExpiresAt(token)
    if (!expiresAt) return undefined
    const endSession = () => {
      dispatch(logout())
      navigate('/admin', { replace: true })
    }
    const remaining = expiresAt - Date.now()
    if (remaining <= 0) { endSession(); return undefined }
    const t = setTimeout(endSession, remaining)
    return () => clearTimeout(t)
  }, [token, dispatch, navigate])

  // Hidden-tab auto-logout: the panel minimised / switched away from and only
  // seen again 20 minutes or more later ends the session. A panel that stays
  // open and visible is never logged out by it (see the hook). Same exit as the
  // JWT timer above. Plan: docs/plans/2026-09-17-hidden-tab-logout.md.
  useHiddenTabLogout(HIDDEN_TAB_LOGOUT_20_MIN, {
    enabled: isAuthenticated,
    onExpire: () => {
      dispatch(logout())
      navigate('/admin', { replace: true })
    },
  })

  /* Upline lock: an admin above this account (or this account itself) was
     locked and the server revoked the session. Until now nothing told the
     screen, so the admin sat there until its next request 401'd — the logout
     only appeared after navigating somewhere.

     The socket is opened here rather than in useOwnerProfileSocket because that
     hook only runs for an OWNER (or an executive under one); a plain staff
     session had no socket at all. getAdminSocket is a per-token singleton, so
     both callers share one connection.

     Owners are included as well: an upline cannot lock them, but a login from
     another device takes their session over the same way (login_id). */
  useEffect(() => {
    const staffId = user?.staff_id
    const ownerId = user?.owner_id
    if (!isAuthenticated || !token || (!staffId && !ownerId)) return undefined
    setAdminSessionId({ staffId, ownerId })
    getAdminSocket(token)
    const onForceLogout = () => {
      dispatch(logout())
      navigate('/admin', { replace: true })
    }
    window.addEventListener('forceLogout', onForceLogout)
    return () => {
      window.removeEventListener('forceLogout', onForceLogout)
      setAdminSessionId({})
    }
  }, [isAuthenticated, token, user?.staff_id, user?.owner_id, dispatch, navigate])

  // Manage body classes based on current route
  useEffect(() => {
    if (isLoginPage || isChangePasswordPage) {
      document.body.removeAttribute('data-sidebar')
      document.body.classList.add('login')
    } else {
      document.body.setAttribute('data-sidebar', 'dark')
      document.body.classList.remove('login')
    }
    return () => {
      document.body.classList.remove('login')
    }
  }, [isLoginPage, isChangePasswordPage])

  return (
    <>
      <Routes>
        {/* Every route lives under /admin — '/' and '/login' belong to the
            public site now that both share the tenexchn.com origin. */}
        <Route path="/admin" element={<Login />} />
        {/* Telegram on /2, Google Authenticator on /3 — the reference splits
            them by URL, and the route (not history state) is what tells the
            screen which method it is, so a refresh cannot lose it. */}
        <Route path="/admin/loginauth/2" element={<TwoFactorAuth />} />
        <Route path="/admin/loginauth/3" element={<TwoFactorAuth />} />
        <Route path="/admin/change-password" element={<ChangePassword />} />
        <Route path="/admin/change-password-success/:transactionPassword" element={<ChangePasswordSuccess />} />

        {/* Protected layout routes */}
        <Route element={<ProtectedRoute><Layout /></ProtectedRoute>}>
          <Route path="/admin/home" element={<Home />} />
          <Route path="/admin/market-analysis" element={<MarketAnalysis />} />
          <Route path="/admin/users/insertuser" element={<InsertUser />} />
          <Route path="/admin/users" element={<Users />} />
          {/* Drill-down: same list, but scoped to this staff's direct children */}
          <Route path="/admin/users/:parentId" element={<Users />} />
          <Route path="/admin/activeusers" element={<ActiveUsers />} />
          <Route path="/admin/createaccount" element={<MultiLogin />} />
          <Route path="/admin/assign-agent" element={<AssignAgent />} />
          <Route path="/admin/reports/bank" element={<Bank />} />
          <Route path="/admin/reports/accountstatement" element={<AccountStatement />} />
          <Route path="/admin/reports/profitloss" element={<ProfitLoss />} />
          <Route path="/admin/reports/currentbets" element={<CurrentBets />} />
          <Route path="/admin/reports/userhistory" element={<UserHistory />} />
          <Route path="/admin/settings/userlock" element={<UserLock />} />
          <Route path="/admin/settings/secureauthbot" element={<SecureAuthBot />} />
          {/* The logged-in owner/staff's own 2FA — reached from the header
              dropdown, not the sidebar. Not permission-gated: every non-
              executive account may secure its own login. */}
          <Route path="/admin/secureauth" element={<SecureAuth />} />
          <Route path="/admin/settings/buffer-time" element={<BufferTime />} />
          <Route path="/admin/settings/commission" element={<Commission />} />
          <Route path="/admin/settings/max-odds" element={<MaxOdds />} />
          <Route path="/admin/settings/auto-void" element={<AutoVoid />} />
          <Route path="/admin/settings/virtual-limits" element={<VirtualBetLimits />} />
          <Route path="/admin/settings/bet-limits" element={<BetLimits />} />
          <Route path="/admin/settings/third-party-limit" element={<ThirdPartyGameLimit />} />
          <Route path="/admin/reports/casinoresult" element={<CasinoResult />} />
          <Route path="/admin/reports/casinoresult/:casinoname" element={<CasinoResult />} />
          <Route path="/admin/reports/livecasinoreport" element={<LiveCasinoReport />} />
          <Route path="/admin/reports/sportbookreport" element={<SportbookReport />} />
          <Route path="/admin/reports/turnover" element={<Turnover />} />
          <Route path="/admin/reports/authlist" element={<AuthList />} />
          <Route path="/admin/reports/fraud" element={<FraudReport />} />
          <Route path="/admin/reports/userregisterdetail" element={<UserRegisterDetail />} />
          <Route path="/admin/reports/totalprofitloss" element={<TotalProfitLoss />} />
          <Route path="/admin/reports/userwinloss" element={<UserWinLoss />} />
          <Route path="/admin/casino/list" element={<CasinoList />} />
          <Route path="/admin/casino/:gtype" element={<CasinoGamePage />} />
          <Route path="/admin/casino/vip" element={<VipCasino />} />
          <Route path="/admin/casino/vip/:gtype" element={<CasinoGamePage variant="vip" />} />
          <Route path="/admin/vcasino/list" element={<VirtualCasino />} />
          <Route path="/admin/vcasino/:gtype" element={<CasinoGamePage variant="vcasino" />} />
          <Route path="/admin/pcasino/list" element={<PremiumCasino />} />
          <Route path="/admin/pcasino/:gtype" element={<CasinoGamePage variant="pcasino" />} />
          <Route path="/admin/tcasino/list" element={<TemboCasino />} />
          <Route path="/admin/casino-manage" element={<CasinoManage />} />
          <Route path="/admin/game-details/:sportId/:eventId" element={<GameDetails />} />
          <Route path="/admin/game-details/:sportId/:eventId/:marketId" element={<GameDetails />} />
          <Route path="/admin/settlement/match" element={<MatchSettlement />} />
          <Route path="/admin/settlement/fancy" element={<FancySettlement />} />
          <Route path="/admin/settlement/void-bets" element={<VoidBets />} />
          <Route path="/admin/settlement/casino" element={<CasinoSettlement />} />
          <Route path="/admin/system-tracker" element={<SystemTracker />} />
          <Route path="/admin/carousel" element={<CarouselPanel />} />
          <Route path="/admin/fixtures" element={<Fixtures />} />
          <Route path="/admin/home-slider" element={<HomeSliderPanel />} />
          <Route path="/admin/game-priority" element={<GamePriorityPanel />} />
          {/* Landing for an executive whose permission map allows nothing
              routable — protected but never permission-gated */}
          <Route path="/admin/no-access" element={<NoAccess />} />
        </Route>

        <Route
          path="*"
          element={
            <Navigate
              to={isAuthenticated
                ? (sessionStorage.getItem('needPasswordChange') === 'true' ? "/admin/change-password" : "/admin/home")
                : "/admin"
              }
              replace
            />
          }
        />
      </Routes>
      {/* Renders nothing until a bToast* call fires — see components/BToast */}
      <BToastContainer />
    </>
  )
}

export default App
