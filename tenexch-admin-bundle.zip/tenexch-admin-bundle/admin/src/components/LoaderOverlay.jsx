// Common page loader (reference markup): shown over .page-content while a
// page is fetching data — render `{loading && <LoaderOverlay />}` at page top.
function LoaderOverlay() {
  return (
    <div className="loader-overlay">
      <i className="fas fa-spinner fa-spin"></i>
    </div>
  )
}

export default LoaderOverlay
