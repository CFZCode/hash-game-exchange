import { useState } from 'react'
import Swal from 'sweetalert2'
import { authService } from '../services/authService'
import useModalEnter from '../hooks/useModalEnter'

function ChangePasswordModal({ onClose }) {

  const [formData, setFormData] = useState({
    password: '',
    NewPassword: '',
    ConfirmNewPassword: ''
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  // Reference (vee-validate) texts — validated live on change/blur + submit,
  // same pattern as pages/users/InsertUser.jsx. An empty submit used to raise
  // one toast; the reference marks every empty field red with its own
  // message under it (user's screenshot, 2026-09-18).
  const [errors, setErrors] = useState({})
  const [touched, setTouched] = useState({})

  const validateField = (name, value, all = formData) => {
    switch (name) {
      case 'password':
        if (!value) return 'The Transaction Code field is required'
        return ''
      case 'NewPassword':
        if (!value) return 'The New Password field is required'
        return ''
      case 'ConfirmNewPassword':
        if (!value) return 'The Confirm Password field is required'
        if (value !== all.NewPassword) return 'The Confirm Password confirmation does not match'
        return ''
      default:
        return ''
    }
  }

  const validateAll = (data) => {
    const next = {}
    for (const f of ['password', 'NewPassword', 'ConfirmNewPassword']) {
      const msg = validateField(f, data[f], data)
      if (msg) next[f] = msg
    }
    return next
  }

  const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: false,
  })

  const handleChange = (e) => {
    const { name, value } = e.target
    const next = { ...formData, [name]: value }
    setFormData(next)
    // Re-check the touched fields only, so an untouched field is not flagged
    // while the operator is still typing in the first one
    if (touched[name] || errors[name]) {
      setErrors((prev) => {
        const out = { ...prev }
        const msg = validateField(name, value, next)
        if (msg) out[name] = msg; else delete out[name]
        // The confirm field depends on the new password
        if (name === 'NewPassword' && (touched.ConfirmNewPassword || prev.ConfirmNewPassword)) {
          const c = validateField('ConfirmNewPassword', next.ConfirmNewPassword, next)
          if (c) out.ConfirmNewPassword = c; else delete out.ConfirmNewPassword
        }
        return out
      })
    }
  }

  const handleBlur = (e) => {
    const { name, value } = e.target
    setTouched((prev) => ({ ...prev, [name]: true }))
    setErrors((prev) => {
      const out = { ...prev }
      const msg = validateField(name, value)
      if (msg) out[name] = msg; else delete out[name]
      return out
    })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    const found = validateAll(formData)
    setTouched({ password: true, NewPassword: true, ConfirmNewPassword: true })
    setErrors(found)
    if (Object.keys(found).length) return

    setIsSubmitting(true)
    try {
      // First box is the TRANSACTION CODE (reference), checked server-side
      // with the usual attempt counter. Owners and staff share the staff
      // endpoint — the owner one is PUT-only and 404'd this POST.
      const response = await authService.changePassword({
        transactionPassword: formData.password,
        newPassword: formData.NewPassword,
        confirmPassword: formData.ConfirmNewPassword
      })

      if (response?.success) {
        Toast.fire({ icon: 'success', title: 'Password changed successfully' })
        onClose()
      } else {
        Toast.fire({ icon: 'error', title: response?.message || 'Failed to change password' })
      }
    } catch (error) {
      Toast.fire({ icon: 'error', title: error?.response?.data?.message || 'Failed to change password' })
    } finally {
      setIsSubmitting(false)
    }
  }

  const { modalClass, backdropClass, onBackdropClick } = useModalEnter(onClose)

  return (
    <div style={{ position: 'absolute', zIndex: 1040 }}>
      <div role="dialog" className={modalClass} aria-modal="true" style={{ display: 'block' }} onClick={onBackdropClick}>
        <div className="modal-dialog modal-md">
          <span tabIndex="0"></span>
          <div tabIndex="-1" className="modal-content">
            <header className="modal-header bg-default">
              <h5 className="modal-title text-uppercase">Change Password</h5>
              <button type="button" data-dismiss="modal" className="close" onClick={onClose}>&times;</button>
            </header>
            <div className="modal-body">
              <form method="post" onSubmit={handleSubmit}>
                <div className="form-group">
                  <input placeholder="Transaction Code" type="password" name="password" data-vv-as="Transaction Code" className={`form-control${errors.password ? ' is-invalid' : ''}`} aria-required="true" aria-invalid={errors.password ? 'true' : 'false'} value={formData.password} onChange={handleChange} onBlur={handleBlur} disabled={isSubmitting} />
                  {errors.password && <small className="error">{errors.password}</small>}
                </div>
                <div className="form-group">
                  <input placeholder="New Password" type="password" name="NewPassword" data-vv-as="New Password" className={`form-control${errors.NewPassword ? ' is-invalid' : ''}`} aria-required="true" aria-invalid={errors.NewPassword ? 'true' : 'false'} value={formData.NewPassword} onChange={handleChange} onBlur={handleBlur} disabled={isSubmitting} />
                  {errors.NewPassword && <small className="error">{errors.NewPassword}</small>}
                </div>
                <div className="form-group">
                  <input placeholder="Confirm New Password" type="password" name="ConfirmNewPassword" data-vv-as="Confirm Password" className={`form-control${errors.ConfirmNewPassword ? ' is-invalid' : ''}`} aria-required="true" aria-invalid={errors.ConfirmNewPassword ? 'true' : 'false'} value={formData.ConfirmNewPassword} onChange={handleChange} onBlur={handleBlur} disabled={isSubmitting} />
                  {errors.ConfirmNewPassword && <small className="error">{errors.ConfirmNewPassword}</small>}
                </div>
                <div className="form-group">
                  <button type="submit" className="btn btn-primary btn-block" disabled={isSubmitting}>
                    {isSubmitting ? 'Change Password' : 'Change Password'}
                    <i className="fas fa-chevron-circle-right ml-2"></i>
                  </button>
                </div>
              </form>
            </div>
          </div>
          <span tabIndex="0"></span>
        </div>
      </div>
      <div className={backdropClass}></div>
    </div>
  )
}

export default ChangePasswordModal
