import { Fragment, memo, useState } from 'react';
import { CARD_IMG_BASE } from './cards/cardUtils';
import { roundBook, fmtBook } from '../../utils/casinoBook';

// V-1 Day Dragon Tiger (vdt6) admin board — reference DOM
// (tenexch.com-admin-vcasino-dt6 capture, 2026-09-19):
//   .main-odds
//     .dragon-box.dpt-box / .pair-box.dpt-box / .tiger-box.dpt-box:
//       <div> [ .dt-name "Dragon" + info icon + #demoN.collapse.icon-range "R:min-max"
//              + .dt-odds [ .back-box b (, .lay-box l) ] ] + .dt-book.w-100.book-*
//   .other-odds
//     .dragon-section: .w-100.playera.mb-2.text-center DRAGON, four
//       .even-box.back-box (EVEN, ODD, ♠♣, ♥♦), "R:" line, four suit boxes
//       (♠ ♥ ♣ ♦), "R:" line
//     .dt-divider
//     .tiger-section: same with playerb TIGER
// Feed (live all-data, verified): 1 Dragon / 2 Tiger (etype match, b + l,
// max 25K); fancy back-only, max 10K: 3 Pair; per player Even/Odd/Red/Black/
// Spade/Heart/Diamond/Club = Dragon 4–11, Tiger 12–19. Suspended → the
// `suspended` class on .back-box / .lay-box / .even-box.back-box and odd 0.

const IMG = (n) => <img src={`${CARD_IMG_BASE}/${n}.png`} />;
const PLAYERS = [
  { key: 'dragon', title: 'DRAGON', cls: 'playera', base: 4 },
  { key: 'tiger', title: 'TIGER', cls: 'playerb', base: 12 },
];
// fancy offsets from each player's base: Even 0, Odd 1, Red 2, Black 3,
// Spade 4, Heart 5, Diamond 6, Club 7 — reference order below
const ROW1 = [
  { off: 0, name: 'EVEN' },
  { off: 1, name: 'ODD' },
  { off: 3, name: <>{IMG('spade')} {IMG('club')}</> },
  { off: 2, name: <>{IMG('heart')} {IMG('diamond')}</> },
];
const ROW2 = [
  { off: 4, name: IMG('spade') },
  { off: 5, name: IMG('heart') },
  { off: 7, name: IMG('club') },
  { off: 6, name: IMG('diamond') },
];

function isSusp(s) {
  return !s || s.gstatus !== 'OPEN';
}
function bookOf(exposures, sid) {
  return roundBook(exposures?.[`sid:${sid}`] ?? 0);
}
function bookCls(v) {
  return v < 0 ? 'book-red' : v > 0 ? 'book-green' : 'book-black';
}
function fmtAmt(n) {
  const x = Number(n) || 0;
  if (x >= 100000) return `${x / 100000}L`;
  if (x >= 1000) return `${x / 1000}K`;
  return String(x);
}

function Range({ id, sel }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="d-inline-block ml-2">
      <i
        data-toggle="collapse"
        data-target={`#${id}`}
        className={`fas fa-info-circle${open ? '' : ' collapsed'}`}
        onClick={() => setOpen((o) => !o)}
      ></i>
      {' '}
      <div id={id} className={`collapse icon-range${open ? ' show' : ''}`}>
        {'                        R:'}
        <span>{fmtAmt(sel?.min ?? 25)}</span>
        -
        <span>{fmtAmt(sel?.max ?? 0)}</span>
      </div>
    </div>
  );
}

// `.<box>.dpt-box` — name + range, back (+ lay) cell, book line
function MainBox({ box, name, id, sel, lay, exposures }) {
  const susp = isSusp(sel);
  const book = bookOf(exposures, sel?.sid);
  return (
    <div className={`${box} dpt-box`}>
      <div>
        <div className="dt-name">
          {`                    ${name}                    `}
          <Range id={id} sel={sel} />
        </div>
        {' '}
        <div className="dt-odds">
          <div className={`back-box${susp ? ' suspended' : ''}`}>
            {`                      ${susp ? 0 : sel.b}                    `}
          </div>
          {lay && (
            <>
              {' '}
              <div className={`lay-box${susp ? ' suspended' : ''}`}>
                {`                      ${susp ? 0 : sel.l}                    `}
              </div>
            </>
          )}
        </div>
      </div>
      {' '}
      <div className={`dt-book w-100 ${bookCls(book)}`}>{fmtBook(book)}</div>
    </div>
  );
}

// `.even-box.back-box` — name/suit art + odd, book under
function FancyBox({ sel, name, exposures }) {
  const susp = isSusp(sel);
  const book = bookOf(exposures, sel?.sid);
  return (
    <div className={`even-box back-box${susp ? ' suspended' : ''}`}>
      <div>
        <div className="dt-name">{name}</div>
        {' '}
        <div className="dt-odds">{susp ? 0 : sel.b}</div>
      </div>
      {' '}
      <div className={`dt-book w-100 ${bookCls(book)}`}>{fmtBook(book)}</div>
    </div>
  );
}

function RangeLine({ sel }) {
  return (
    <div className="w-100 text-right mb-3">
      {'                  R:'}
      <span>{fmtAmt(sel?.min ?? 25)}</span>
      -
      <span>{fmtAmt(sel?.max ?? 0)}</span>
    </div>
  );
}

const BetTableVDt6 = memo(function BetTableVDt6({ gameData, exposures }) {
  const sub = gameData?.sub || [];
  const bySid = new Map(sub.map((s) => [Number(s.sid), s]));
  const sel = (sid) => bySid.get(sid);

  return (
    <>
      <div className="main-odds">
        <MainBox box="dragon-box" name="Dragon" id="demo0" sel={sel(1)} lay exposures={exposures} />
        {' '}
        <MainBox box="pair-box" name="Pair" id="demof0" sel={sel(3)} exposures={exposures} />
        {' '}
        <MainBox box="tiger-box" name="Tiger" id="demo1" sel={sel(2)} lay exposures={exposures} />
      </div>
      {' '}
      <div className="other-odds">
        {PLAYERS.map((p, pi) => (
          <Fragment key={p.key}>
            {pi === 1 && <><div className="dt-divider"></div>{' '}</>}
            <div className={`${p.key}-section`}>
              <div className={`w-100 ${p.cls} mb-2 text-center`}>{p.title}</div>
              {ROW1.map((c) => (
                <Fragment key={c.off}>
                  {' '}
                  <FancyBox sel={sel(p.base + c.off)} name={c.name} exposures={exposures} />
                </Fragment>
              ))}
              {' '}
              <RangeLine sel={sel(p.base)} />
              {ROW2.map((c) => (
                <Fragment key={c.off}>
                  {' '}
                  <FancyBox sel={sel(p.base + c.off)} name={c.name} exposures={exposures} />
                </Fragment>
              ))}
              {' '}
              <RangeLine sel={sel(p.base + 4)} />
            </div>
          </Fragment>
        ))}
      </div>
    </>
  );
});

export default BetTableVDt6;
