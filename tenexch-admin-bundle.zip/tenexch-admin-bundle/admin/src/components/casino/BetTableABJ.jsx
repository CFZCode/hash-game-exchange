import { memo, useCallback, useMemo, useState } from 'react';
import { cardSrc, parseCards } from './cards/cardUtils';
import { roundBook, fmtBook } from '../../utils/casinoBook';

const CDN = 'https://wver.sprintstaticdata.com/v230/static/front/img/cards/';
const CARD_FACES = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
const SUITS = [
  { name: 'spade', img: 'spade.png', sid: 20 },
  { name: 'heart', img: 'heart.png', sid: 22 },
  { name: 'club', img: 'club.png', sid: 21 },
  { name: 'diamond', img: 'diamond.png', sid: 23 },
];

function isSusp(item) {
  return !item || item.gstatus === 'SUSPENDED' || item.gstatus === '0';
}

function bookOf(exposures, name, sid) {
  return roundBook(exposures?.[`sid:${sid}`] ?? exposures?.[name] ?? 0);
}

function bookCls(v) {
  return v < 0 ? 'book-red' : v > 0 ? 'book-green' : 'book-black';
}

const ITEM_W = 23.246;

// Owl Carousel 2 replica (dealt cards) — item margin-left 10px (reference).
const Owl = memo(function Owl({ id, cards }) {
  const [page, setPage] = useState(0);
  const list = cards.length ? cards : [];
  const perView = 3;
  const maxPage = Math.max(0, Math.ceil(list.length / perView) - 1);
  const cur = Math.min(page, maxPage);
  const atStart = cur <= 0;
  const atEnd = cur >= maxPage;
  // owl-rtl (float:right) => positive translate direction
  const translateX = cur * perView * (ITEM_W + 10);
  const stageWidth = list.length * (ITEM_W + 10);
  const prev = useCallback(() => setPage((p) => Math.max(0, p - 1)), []);
  const next = useCallback(() => setPage((p) => p + 1), []);

  if (list.length === 0) {
    return (
      <div id={id} className="ab-slider owl-carousel owl-theme owl-rtl owl-loaded owl-drag">
        <div className="owl-stage-outer">
          <div className="owl-stage" style={{ transform: 'translate3d(0px, 0px, 0px)', transition: 'all', width: '0px' }}>
            <div className="owl-item active" style={{ width: `${ITEM_W}px`, marginLeft: '10px' }}><div></div></div>
          </div>
        </div>
        <div className="owl-nav disabled">
          <button type="button" role="presentation" className="owl-prev disabled"><span aria-label="Previous">‹</span></button>
          <button type="button" role="presentation" className="owl-next disabled"><span aria-label="Next">›</span></button>
        </div>
        <div className="owl-dots disabled"></div>
      </div>
    );
  }

  return (
    <div id={id} className="ab-slider owl-carousel owl-theme owl-rtl owl-loaded owl-drag">
      <div className="owl-stage-outer">
        {/* Only the slide animates: 'all' also eased the stage WIDTH, so for 0.25s after
            a new card the stage was too narrow and the new card wrapped to a 2nd row (user). */}
        <div className="owl-stage" style={{ transform: `translate3d(${translateX}px, 0px, 0px)`, transition: 'transform 0.25s ease', width: `${stageWidth}px` }}>
          {list.map((code, i) => {
            const active = i >= cur * perView && i < (cur + 1) * perView;
            return (
              <div key={i} className={`owl-item${active ? ' active' : ''}`} style={{ width: `${ITEM_W}px`, marginLeft: '10px' }}>
                <div className="item"><span><img src={cardSrc(code)} /></span></div>
              </div>
            );
          })}
        </div>
      </div>
      <div className={`owl-nav${list.length <= perView ? ' disabled' : ''}`}>
        <button type="button" role="presentation" className={`owl-prev${atStart ? ' disabled' : ''}`} onClick={atStart ? undefined : prev}><span aria-label="Previous">‹</span></button>
        <button type="button" role="presentation" className={`owl-next${atEnd ? ' disabled' : ''}`} onClick={atEnd ? undefined : next}><span aria-label="Next">›</span></button>
      </div>
      <div className="owl-dots disabled"></div>
    </div>
  );
});

// Cards overlay (trump + A/B first card + owl slider of rest).
// className = 'd-none-small' (web, shuffle grip) ya 'd-none-desktop' (mobile).
export const ABJVideoCards = memo(function ABJVideoCards({ trumpCard, aCards, bCards, className, sliderSuffix = '', showCards = true, onToggle }) {
  const web = className === 'd-none-small';
  const aFirst = aCards[0];
  const aRest = aCards.slice(1);
  const bFirst = bCards[0];
  const bRest = bCards.slice(1);
  // koi real card nahi (betting window) -> web pe hide-cards (reference), structure
  // (A/B labels + facedown) phir bhi render hota hai. Mobile pe hide-cards nahi.
  const hasCards = !!trumpCard || aCards.length > 0 || bCards.length > 0;
  const hide = web && (!showCards || !hasCards);

  return (
    <div className={`casino-video-cards ${className}${hide ? ' hide-cards' : ''}`}>
      {web && <div className="casino-cards-shuffle" onClick={onToggle}><i className="fas fa-grip-lines-vertical"></i></div>}
      {web && ' '}
      <div className="casino-video-cards-container">
        <div className="row row5 align-items-center">
          <div className="col-1">
            <div className="row row5"><div className={`col-12${web ? ' mb-3' : ''}`}><b>A</b></div></div>
            {' '}
            <div className="row row5"><div className="col-12"><b>B</b></div></div>
          </div>
          {' '}
          <div className="col-2">
            <span><img src={cardSrc(trumpCard || '1')} className="card-right" /></span>
          </div>
          {' '}
          <div className="col-9">
            <div className={`card-inner${web ? ' mb-1' : ''}`}>
              <div className="row row5">
                <div className="col-3"><span><img src={cardSrc(aFirst || '1')} /></span></div>
                {' '}
                <div className="col-9"><Owl id={`andarSlider${sliderSuffix}`} cards={aRest} /></div>
              </div>
            </div>
            {' '}
            <div className="card-inner">
              <div className={`row row5${web ? '' : ' mt-1'}`}>
                <div className="col-3"><span><img src={cardSrc(bFirst || '1')} /></span></div>
                {' '}
                <div className="col-9"><Owl id={`baharSlider${sliderSuffix}`} cards={bRest} /></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
});

// SA/SB + 1st/2nd Bet column
function BetSide({ title, items, onBet, exposures }) {
  const suffix = title === 'A' ? 'SA' : 'SB';
  return (
    <div className={title === 'A' ? 'teen20left' : 'teen20right'}>
      <div className="ab2-title">{title}</div>
      {items.map((item) => {
        const isSaSb = item.nat === 'SA' || item.nat === 'SB';
        const label = isSaSb ? item.nat : item.nat.replace('1st', '1st').replace('2nd', '2nd');
        const boxClass = isSaSb ? 'sa-sb-box' : 'ab2-bet';
        const apiNat = isSaSb ? item.nat : `${item.nat} ${suffix}`;
        const book = bookOf(exposures, apiNat, item.sid);
        return (
          <div
            key={item.sid}
            className={`${boxClass}${isSusp(item) ? ' suspended' : ''}`}
            onClick={isSusp(item) ? undefined : () => onBet(item.sid, 'back', item.b, { ...item, nat: apiNat })}
          >
            <div>{label}</div>
            <div>{item.b || 0}</div>
            <div className={`ab-book ${bookCls(book)}`}>{fmtBook(book)}</div>
          </div>
        );
      })}
      <div className="ab2-title">{title}</div>
    </div>
  );
}

// Odd/Even/suit back box: book sibling span of back item
function BackBox({ item, onBet, exposures }) {
  const book = bookOf(exposures, item?.nat, item?.sid);
  return (
    <div className="casino-bl-box">
      <div
        className={`back casino-bl-box-item${isSusp(item) ? ' suspended' : ''}`}
        onClick={isSusp(item) ? undefined : () => onBet(item.sid, 'back', item.b, item)}
      >
        <span className="casino-box-odd">{item?.b || 0}</span>
      </div>
      {' '}
      <span className={`casino-book ${bookCls(book)}`}>{fmtBook(book)}</span>
    </div>
  );
}

const BetTableABJ = memo(function BetTableABJ({ gameData, onBet, exposures }) {
  const sub = gameData?.sub ?? [];
  const handleBet = onBet || (() => {});
  const all = parseCards(gameData?.card ?? '');

  const trumpCard = all[0] && all[0] !== '1' ? all[0] : null;
  const dealt = all.slice(1).filter((c) => c !== '1' && c !== '0');
  const aCards = dealt.filter((_, i) => i % 2 === 1);
  const bCards = dealt.filter((_, i) => i % 2 === 0);

  const byId = useMemo(() => {
    const m = {};
    sub.forEach((s) => { m[s.sid] = s; });
    return m;
  }, [sub]);

  const aItems = [byId[1], byId[2], byId[3]].filter(Boolean);
  const bItems = [byId[4], byId[5], byId[6]].filter(Boolean);
  const oddItem = byId[24];
  const evenItem = byId[25];
  const jokerOddsTitle = byId[7]?.b || 0;

  return (
    <>
      {/* mobile cards overlay (casino-detail top) */}
      <ABJVideoCards trumpCard={trumpCard} aCards={aCards} bCards={bCards} className="d-none-desktop" sliderSuffix="Mob" />

      {/* SA/SB + Bets */}
      <div className="teen20casino-container">
        <BetSide title="A" items={aItems} onBet={handleBet} exposures={exposures} />
        <div className="teen20center"></div>
        <BetSide title="B" items={bItems} onBet={handleBet} exposures={exposures} />
      </div>

      {/* Odd/Even + Suits */}
      <div className="teen20casino-container">
        <div className="teen20left ab2oddeven">
          <div className="casino-box-row">
            <div className="casino-bl-box"><div className="casino-bl-box-item"><b>Odd</b></div></div>
            <div className="casino-bl-box"><div className="casino-bl-box-item"><b>Even</b></div></div>
          </div>
          <div className="casino-box-row">
            <BackBox item={oddItem} onBet={handleBet} exposures={exposures} />
            <BackBox item={evenItem} onBet={handleBet} exposures={exposures} />
          </div>
        </div>
        <div className="teen20center"></div>
        <div className="teen20left ab2cards">
          <div className="casino-box-row">
            {SUITS.map((suit) => (
              <div key={suit.name} className="casino-bl-box">
                <div className="casino-bl-box-item casino-card-img"><img src={`${CDN}${suit.img}`} /></div>
              </div>
            ))}
          </div>
          <div className="casino-box-row">
            {SUITS.map((suit) => (
              <BackBox key={suit.name} item={byId[suit.sid]} onBet={handleBet} exposures={exposures} />
            ))}
          </div>
        </div>
      </div>

      {/* 13 cards A-K */}
      <div className="teen20casino-container ab2allcards">
        <div className="text-center w-100">
          <div className="casino-bl-box casino-cards-odds-title">
            <div className="casino-bl-box-item"><b>{jokerOddsTitle}</b></div>
          </div>
        </div>
        <div className="casino-cards text-center mt-1">
          {CARD_FACES.map((face, i) => {
            const item = byId[7 + i];
            const book = bookOf(exposures, item?.nat, item?.sid);
            return (
              <div
                key={face}
                className="casino-card-item"
                onClick={isSusp(item) ? undefined : () => handleBet(item.sid, 'back', item.b, item)}
              >
                <div className={`card-image${isSusp(item) ? ' suspended' : ''}`}>
                  <img src={`${CDN}${face}.png`} />
                </div>
                {' '}
                <div className={`casino-book ${bookCls(book)}`}>{fmtBook(book)}</div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="text-right casino-min-max">
        R:
        <span>10</span>
        -
        <span>1L</span>
      </div>
    </>
  );
});

export default BetTableABJ;
