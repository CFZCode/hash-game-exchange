import { memo, useEffect, useRef, useState } from 'react';

// Reference thresholds (reference bundle `warning: 6, alert: 3`): green while
// 7s or more remain, orange at 6-4, red at 3 and below.
function timerColor(timeLeft) {
  if (timeLeft <= 3) return 'red';
  if (timeLeft <= 6) return 'orange';
  return 'green';
}

// The reference wraps every timer digit in <transition name="component-fade"
// mode="out-in">: the old digit fades down and out (300ms), only then the new
// one fades in from above (300ms). The classes are the reference's own
// (.component-fade-*); this only walks them in the same order. Display only —
// what the timer counts is untouched. Ported from frontend CasinoTimer.jsx.
const FADE_MS = 300;
const FADE_CLASS = {
  leave: 'component-fade-leave component-fade-leave-active',
  'leave-to': 'component-fade-leave-active component-fade-leave-to',
  enter: 'component-fade-enter component-fade-enter-active',
  'enter-to': 'component-fade-enter-active component-fade-enter-to',
};

// Two frames, so the start class is painted before the end class replaces it.
function afterNextFrame(fn) {
  let id = requestAnimationFrame(() => {
    id = requestAnimationFrame(fn);
  });
  return () => cancelAnimationFrame(id);
}

export const FadeDigit = memo(function FadeDigit({ value }) {
  const [state, setState] = useState({ shown: value, phase: 'idle' });
  const { shown, phase } = state;
  const latest = useRef(value);

  useEffect(() => {
    latest.current = value;
  }, [value]);

  // A changed digit starts leaving in the same render. A slot that had no
  // digit shows the new one at once (the reference has no "appear" fade).
  if (value !== shown && phase !== 'leave' && phase !== 'leave-to') {
    setState(shown == null ? { shown: value, phase: 'idle' } : { shown, phase: 'leave' });
  }

  useEffect(() => {
    if (phase === 'leave') {
      return afterNextFrame(() => setState((s) => (s.phase === 'leave' ? { ...s, phase: 'leave-to' } : s)));
    }
    if (phase === 'enter') {
      return afterNextFrame(() => setState((s) => (s.phase === 'enter' ? { ...s, phase: 'enter-to' } : s)));
    }
    if (phase === 'leave-to') {
      const t = setTimeout(() => {
        const next = latest.current;
        setState(next == null ? { shown: null, phase: 'idle' } : { shown: next, phase: 'enter' });
      }, FADE_MS);
      return () => clearTimeout(t);
    }
    if (phase === 'enter-to') {
      const t = setTimeout(() => setState((s) => (s.phase === 'enter-to' ? { ...s, phase: 'idle' } : s)), FADE_MS);
      return () => clearTimeout(t);
    }
    return undefined;
  }, [phase]);

  if (shown == null) return null;
  // key = the digit: the entering digit is a NEW element (as Vue's out-in
  // inserts one), so it starts at the enter state instead of transitioning
  // there from the old digit's leave-to position.
  return <span key={shown} className={FADE_CLASS[phase]}>{shown}</span>;
});

// Circular SVG countdown — wrapperClass 'casino-timer' (both views, admin
// reference) or 'casino-timer d-none-mobile' (desktop-only, user site)
export const CircularTimer = memo(function CircularTimer({ timeLeft = 0, fullTime = 30, wrapperClass = 'casino-timer' }) {
  const color = timerColor(timeLeft);
  // The reference's base-timer formula: one step ahead of the plain ratio, so
  // the ring goes negative at 0 — an invalid dash array, which draws the full
  // red circle (reference shows `-9 283` at 0).
  const f = fullTime > 0 ? timeLeft / fullTime : 0;
  const dashArray = fullTime > 0 ? ((f - (1 / fullTime) * (1 - f)) * 283).toFixed(0) : 0;
  const digits = String(timeLeft).split('');
  // Keep a slot mounted after its digit is gone (10 -> 9) so it can fade out.
  const [slots, setSlots] = useState(digits.length);
  if (digits.length > slots) setSlots(digits.length);

  return (
    <div className={wrapperClass}>
      <div className="base-timer">
        <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" className="base-timer__svg">
          <g className="base-timer__circle">
            <circle cx="50" cy="50" r="45" className="base-timer__path-elapsed"></circle>
            <path
              strokeDasharray={`${dashArray} 283`}
              d={`
        M 50, 50
        m -45, 0
        a 45,45 0 1,0 90,0
        a 45,45 0 1,0 -90,0
      `}
              className={`base-timer__path-remaining ${color}`}
            ></path>
          </g>
        </svg>
        <span className={`base-timer__label ${color}`}>
          {Array.from({ length: Math.max(slots, digits.length) }, (_, i) => (
            <FadeDigit key={i} value={digits[i] ?? null} />
          ))}
        </span>
      </div>
    </div>
  );
});

export const DesktopTimer = memo(function DesktopTimer(props) {
  return <CircularTimer {...props} wrapperClass="casino-timer d-none-mobile" />;
});

export const MobileTimer = memo(function MobileTimer({ timeLeft = 0, fullTime = 30 }) {
  const color = timerColor(timeLeft);
  const pct = fullTime > 0 ? ((timeLeft / fullTime) * 100).toFixed(2) : 0;

  return (
    <div className="progress mobile-timer d-none-big">
      <div className={`progress-bar bg-${color === 'green' ? 'success' : color === 'orange' ? 'warning' : 'danger'}`} style={{ width: `${pct}%` }}></div>
    </div>
  );
});

export const MobileDigitTimer = memo(function MobileDigitTimer({ timeLeft = 0 }) {
  if (timeLeft <= 0 || timeLeft > 3) return null;

  return (
    <div className="casino-time-digit d-none-desktop">
      {timeLeft}
    </div>
  );
});

// Default export for backwards compat
const CasinoTimer = memo(function CasinoTimer({ timeLeft = 0, fullTime = 30 }) {
  return (
    <>
      <DesktopTimer timeLeft={timeLeft} fullTime={fullTime} />
      <MobileTimer timeLeft={timeLeft} fullTime={fullTime} />
    </>
  );
});

export default CasinoTimer;
