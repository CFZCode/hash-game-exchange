import { useState, memo, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { getDetailResults, getCasinoRoundBets } from '../../services/casinoService';
import ResultContentSwitch from './results/ResultContentSwitch';
import RoundBetsTable from './RoundBetsTable';
import LoaderOverlay from '../LoaderOverlay';
import useModalEnter from '../../hooks/useModalEnter';

// Games whose reference Result modal shows the bets block (radios + zero
// totals) even for a round with no downline bets.
// Beach Roulette (roulette12) is not one of them: its reference modal shows
// only the result when nobody bet (user screenshot 2026-10-15).
const EMPTY_BETS_BLOCK_GAMES = new Set(['roulette11', 'roulette13']);

const CasinoResultModal = memo(function CasinoResultModal({
  show,
  onClose,
  gameType,
  gameName,
  mid,
}) {
  const [detail, setDetail] = useState(null);
  // Downline bets on this round (reference: radios + totals + bets table under
  // the result). No bets (or a failed fetch) → the block is not shown.
  const [bets, setBets] = useState([]);
  const [loading, setLoading] = useState(false);
  // Open animation + outside click: hooks/useModalEnter. Not "entered" while
  // the loader overlay is up — the modal mounts only once data is here.
  const { entered, backdropClass, onBackdropClick } = useModalEnter(onClose, show && !loading);

  const formatMatchTime = (mtime) => {
    if (!mtime) return '';
    try {
      const d = new Date(mtime);
      if (isNaN(d)) return mtime;
      const dd = String(d.getDate()).padStart(2, '0');
      const mm = String(d.getMonth() + 1).padStart(2, '0');
      const yyyy = d.getFullYear();
      const hh = String(d.getHours()).padStart(2, '0');
      const min = String(d.getMinutes()).padStart(2, '0');
      const ss = String(d.getSeconds()).padStart(2, '0');
      return `${dd}/${mm}/${yyyy} ${hh}:${min}:${ss}`;
    } catch { return mtime; }
  };

  useEffect(() => {
    if (!show || !mid || !gameType) return;
    let cancelled = false;
    setLoading(true);
    setDetail(null);
    setBets([]);
    Promise.all([
      getDetailResults(gameType, mid.toString())
        .then((res) => res?.data?.data?.t1 || res?.data?.t1 || res?.data || null)
        .catch((err) => { console.error('Detail results error:', err); return null; }),
      getCasinoRoundBets(gameType, mid.toString())
        .then((res) => (res?.success && Array.isArray(res.bets) ? res.bets : []))
        .catch((err) => { console.error('Round bets error:', err); return []; }),
      new Promise((r) => setTimeout(r, 1000)),
    ]).then(([t1, roundBets]) => {
      if (!cancelled) {
        setDetail(t1);
        setBets(roundBets);
        setLoading(false);
      }
    });
    return () => { cancelled = true; };
  }, [show, mid, gameType]);

  // modal-open hides the page scrollbar (overflow: hidden); keep its width as
  // body padding, like Bootstrap, so the page behind does not shift right
  // while the modal is open (user 2026-10-14, every game).
  useEffect(() => {
    if (!show) return undefined;
    const gutter = window.innerWidth - document.documentElement.clientWidth;
    document.body.classList.add('modal-open');
    if (gutter > 0) document.body.style.paddingRight = `${gutter}px`;
    return () => {
      document.body.classList.remove('modal-open');
      document.body.style.paddingRight = '';
    };
  }, [show]);

  if (!show) return null;

  // Result click → pehle loader overlay chalti hai, data aane pe modal
  if (loading) {
    return createPortal(<LoaderOverlay />, document.body);
  }

  // Reference shows a bare "Result" title on these tables (no game name).
  const PLAIN_RESULT_TITLE = ['cricketv3', 'superover', 'superover2', 'superover3'];
  const isPlainResult = PLAIN_RESULT_TITLE.includes(gameType);

  const MODAL_ID = '__BVID__1977';

  return createPortal(
    <>
      <div className={backdropClass}></div>
      <div
        id={MODAL_ID}
        role="dialog"
        aria-labelledby={`${MODAL_ID}___BV_modal_title_`}
        aria-describedby={`${MODAL_ID}___BV_modal_body_`}
        className={`modal fade${entered ? ' show' : ''} casino-result`}
        aria-modal="true"
        style={{ display: 'block' }}
        onClick={onBackdropClick}
      >
        <div className="modal-dialog modal-xl" onClick={(e) => e.stopPropagation()}>
          <span tabIndex="0"></span>
          <div id={`${MODAL_ID}___BV_modal_content_`} tabIndex="-1" className="modal-content">
            <header id={`${MODAL_ID}___BV_modal_header_`} className="modal-header">
              <h5 id={`${MODAL_ID}___BV_modal_title_`} className="modal-title">{isPlainResult ? 'Result' : `${gameName} Result`}</h5>
              <button type="button" aria-label="Close" className="close" onClick={onClose}>
                &times;
              </button>
            </header>
            <div id={`${MODAL_ID}___BV_modal_body_`} className="modal-body">
              {detail ? (
                <>
                  <div>
                    <div className="casino-result-round">
                      <div>Round-ID: {detail.rid || mid}</div>
                      {' '}
                      <div>
                        {'\n      Match Time: '}
                        <span>{formatMatchTime(detail.mtime)}</span>
                      </div>
                    </div>
                    {' '}
                    <ResultContentSwitch gameType={gameType} detail={detail} />
                  </div>
                  {' '}
                  {/* Reference: a round without downline bets shows only the result —
                      except VIP Roulette / Roulette, which keep the radios + "Total Bets: 0 /
                      Total Win: 0" (user screenshot 2026-10-14; no table, emptyRow). */}
                  {(bets.length > 0 || EMPTY_BETS_BLOCK_GAMES.has(gameType)) && <RoundBetsTable bets={bets} idPrefix="result-bet" gameType={gameType} emptyRow={false} />}
                </>
              ) : (
                <div className="text-center p-3">No result data available</div>
              )}
            </div>
          </div>
          <span tabIndex="0"></span>
        </div>
      </div>
    </>,
    document.body
  );
});

export default CasinoResultModal;
