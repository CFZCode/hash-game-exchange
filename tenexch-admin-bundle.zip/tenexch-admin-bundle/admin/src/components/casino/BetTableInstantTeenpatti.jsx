import { memo, useState } from 'react';
import { roundBook, fmtBook } from '../../utils/casinoBook';

function findByNat(sub, nat) {
  return sub.find((s) => s.nat === nat);
}
function isSusp(item) {
  return !item || item.gstatus === 'SUSPENDED' || item.gstatus === '0';
}
function suspCls(item) {
  return isSusp(item) ? ' suspended' : '';
}
function bookOf(exposures, nat) {
  return roundBook(exposures?.[nat] ?? 0);
}
function bookCls(v) {
  return v < 0 ? 'book-red' : v > 0 ? 'book-green' : 'book-black';
}

// Range collapse (info-circle + collapsible R:min-max). Desktop/mobile me class
// order thoda alag hai reference me — mobile prop se handle.
function Rng({ id, min, max, mobile }) {
  const [open, setOpen] = useState(false);
  const iCls = mobile
    ? 'fas fa-info-circle float-right'
    : `fas fa-info-circle${open ? '' : ' collapsed'}`;
  const dCls = mobile ? 'collapse icon-range' : 'icon-range collapse';
  return (
    <>
      <i
        data-toggle="collapse"
        data-target={`#${id}`}
        aria-expanded={open ? 'true' : 'false'}
        className={iCls}
        onClick={() => setOpen((v) => !v)}
      ></i>
      {' '}
      <div id={id} className={`${dCls}${open ? ' show' : ''}`}>
        {'\n                          R:'}<span>{min}</span>-<span>{max}</span>
      </div>
    </>
  );
}

// Instant Teenpatti (teen3) — table teenpatti1day. Sirf Player A/B "Main"
// back/lay (match spread). book-black hamesha, range collapse R:100-2L
// (Player A #range1, Player B #range7). Desktop teen1dayleft/right, mobile
// teen1daycasino-container d-none-big.
const BetTableInstantTeenpatti = memo(function BetTableInstantTeenpatti({ gameData, onBet, exposures }) {
  const sub = gameData?.sub || [];
  const handleBet = onBet || (() => {});
  const playerA = findByNat(sub, 'Player A');
  const playerB = findByNat(sub, 'Player B');
  const bookA = bookOf(exposures, 'Player A');
  const bookB = bookOf(exposures, 'Player B');

  const side = (player, book, title, playerCls, rangeId) => (
    <>
      <div className="casino-box-row">
        <div className="casino-nation-name no-border casino-bl-box-title">
          <div className={playerCls}>{title}</div>
        </div>
        {' '}
        <div className="casino-bl-box casino-bl-box-title">
          <div className="casino-bl-box-item"><b>Back</b></div>
          {' '}
          <div className="casino-bl-box-item"><b>Lay</b></div>
        </div>
      </div>
      {' '}
      <div className="casino-box-row">
        <div className="casino-nation-name">
          <b>Main</b>
          {' '}
          <div className="float-right">
            <span className={`mr-2 casino-book ${bookCls(book)}`}>{fmtBook(book)}</span>
            {' '}
            <Rng id={rangeId} min="100" max="2L" />
          </div>
        </div>
        {' '}
        <div className="casino-bl-box">
          <div
            className={`back casino-bl-box-item${suspCls(player)}`}
            onClick={isSusp(player) ? undefined : () => handleBet(player.sid, 'back', player.b, player)}
          >
            <span className="casino-box-odd">{player?.b || 0}</span>
          </div>
          {' '}
          <div
            className={`lay casino-bl-box-item${suspCls(player)}`}
            onClick={isSusp(player) ? undefined : () => handleBet(player.sid, 'lay', player.l, player)}
          >
            <span className="casino-box-odd">{player?.l || 0}</span>
          </div>
        </div>
      </div>
    </>
  );

  const mobBox = (player, book, title) => (
    <div className="casino-bl-box">
      <div className="casino-bl-box-item casino-odds-name">
        <span>{title}</span>
        {' '}
        <span className={`float-right ${bookCls(book)}`}>{fmtBook(book)}</span>
      </div>
      {' '}
      <div
        className={`back casino-bl-box-item${suspCls(player)}`}
        onClick={isSusp(player) ? undefined : () => handleBet(player.sid, 'back', player.b, player)}
      >
        <span className="casino-box-odd">{player?.b || 0}</span>
      </div>
      {' '}
      <div
        className={`lay casino-bl-box-item${suspCls(player)}`}
        onClick={isSusp(player) ? undefined : () => handleBet(player.sid, 'lay', player.l, player)}
      >
        <span className="casino-box-odd">{player?.l || 0}</span>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop */}
      <div className="teen1daycasino-container d-none-small">
        <div className="teen1dayleft">{side(playerA, bookA, 'Player A', 'playera', 'range1')}</div>
        {' '}
        <div className="teen1daycenter"></div>
        {' '}
        <div className="teen1dayright">{side(playerB, bookB, 'Player B', 'playerb', 'range7')}</div>
      </div>

      {/* Mobile */}
      <div className="teen1daycasino-container d-none-big">
        <div className="casino-box-row">
          <div className="casino-bl-box casino-bl-box-title">
            <div className="casino-bl-box-item">
              <b>Main</b>
              {' '}
              <div className="float-right">
                <Rng id="range1" min="100" max="2L" mobile />
              </div>
            </div>
            {' '}
            <div className="casino-bl-box-item"><b>Back</b></div>
            {' '}
            <div className="casino-bl-box-item"><b>Lay</b></div>
          </div>
          {' '}
          {mobBox(playerA, bookA, 'Player A')}
          {mobBox(playerB, bookB, 'Player B')}
        </div>
      </div>
    </>
  );
});

export default BetTableInstantTeenpatti;
