import { memo } from 'react';
import { roundBook, fmtBook } from '../../utils/casinoBook';

function findByNat(sub, nat) {
  return sub.find((s) => s.nat === nat);
}

// Reference: suspended sirf gstatus != OPEN pe (b-value pe nahi)
function isSusp(item) {
  return !item || item.gstatus !== 'OPEN';
}

function suspCls(item) {
  return isSusp(item) ? ' suspended' : '';
}

// v-kvalpoint replica: 500000 -> 5L, 100000 -> 1L, 100 -> 100
function formatAmount(n) {
  const num = Number(n) || 0;
  if (num >= 100000) return `${num / 100000}L`;
  if (num >= 1000) return `${num / 1000}K`;
  return String(num);
}

// Book (exposure) — sid-scoped key pehle, phir nat fallback (computeAdminBook
// output). Match rows v-casinobook, 3 Card Total v-casinofancybook — dono ki
// value yahi exposures map se aati hai.
function bookOf(exposures, item) {
  const v = exposures?.[`sid:${item?.sid}`] ?? exposures?.[item?.nat];
  return v ? roundBook(v) : 0;
}

function bookCls(v) {
  if (!v) return 'book-black';
  return v < 0 ? 'book-red' : 'book-green';
}

// Reference (excepted.txt): <span class="mr-2 book-black">0</span> — casino-book
// class NAHI (v-casinobook/v-casinofancybook sirf mr-2 + book-* deta hai).
// 0 bhi dikhta hai (book-black), hide nahi hota.
function BookSpan({ exposures, item }) {
  const v = bookOf(exposures, item);
  return <span className={`mr-2 ${bookCls(v)}`}>{fmtBook(v)}</span>;
}

// Static R:<min>-<max> block (reference: text-right casino-min-max — lucky5
// jaisa static, RangeInfo collapse NAHI). extraCls: total row pe ' w-100'.
function MinMax({ item, extraCls = '' }) {
  return (
    <div className={`text-right casino-min-max${extraCls}`}>
      {'\n                      R:'}
      <span>{formatAmount(item?.min)}</span>
      -
      <span>{formatAmount(item?.max)}</span>
    </div>
  );
}

const BetTableMogambo = memo(function BetTableMogambo({ gameData, onBet, exposures = {} }) {
  const sub = gameData?.sub || [];
  const handleBet = onBet || (() => {});

  const dagaTeja = findByNat(sub, 'Daga / Teja');
  const mogamboItem = findByNat(sub, 'Mogambo');
  const cardTotal = findByNat(sub, '3 Card Total');

  // Single back selection (Daga/Teja, Mogambo). boxCls: desktop split me
  // ' casino-bl-boxfull', mobile stacked me ''.
  const singleRow = (label, item, boxCls) => (
    <div className="casino-box-row">
      <div className="casino-nation-name">
        <b>{label}</b>
        {' '}
        <div className="float-right">
          <BookSpan exposures={exposures} item={item} />
        </div>
      </div>
      {' '}
      <div className={`casino-bl-box${boxCls}`}>
        <div
          className={`back casino-bl-box-item${suspCls(item)}`}
          onClick={isSusp(item) ? undefined : () => handleBet(item?.sid, 'back', item?.b, item)}
        >
          <span className="casino-box-odd">{item?.b || 0}</span>
        </div>
      </div>
    </div>
  );

  // 3 Card Total lay/back box. Reference me desktop aur mobile me span ORDER
  // ulta hai: desktop = odd(l/b) pehle phir bhav; mobile = bhav pehle phir odd.
  const totalBoxes = (mobile) => {
    const layOdd = <span className="casino-box-odd">{cardTotal?.l || 0}</span>;
    const layBhav = <span>{cardTotal?.lbhav || 0}</span>;
    const backOdd = <span className="casino-box-odd">{cardTotal?.b || 0}</span>;
    const backBhav = <span>{cardTotal?.bbhav || 0}</span>;
    return (
      <div className={`casino-bl-box${mobile ? ' total-odds' : ''}`}>
        <div
          className={`lay casino-bl-box-item${suspCls(cardTotal)}`}
          onClick={isSusp(cardTotal) ? undefined : () => handleBet(cardTotal?.sid, 'lay', cardTotal?.l, cardTotal)}
        >
          {mobile ? <>{layBhav}{' '}{layOdd}</> : <>{layOdd}{' '}{layBhav}</>}
        </div>
        {' '}
        <div
          className={`back casino-bl-box-item${suspCls(cardTotal)}`}
          onClick={isSusp(cardTotal) ? undefined : () => handleBet(cardTotal?.sid, 'back', cardTotal?.b, cardTotal)}
        >
          {mobile ? <>{backBhav}{' '}{backOdd}</> : <>{backOdd}{' '}{backBhav}</>}
        </div>
      </div>
    );
  };

  const totalNameCell = (
    <div className="casino-nation-name">
      <b className="pointer">3 Card Total</b>
      {' '}
      <div className="float-right">
        <BookSpan exposures={exposures} item={cardTotal} />
      </div>
    </div>
  );

  return (
    <>
      {/* DESKTOP (d-none-small): teen1day split — Daaga/Teja | Mogambo side-by-side
          (casino-bl-boxfull) + casino-min-max R blocks, three-card-total neeche. */}
      <div className="d-none-small">
        <div className="teen1daycasino-container">
          <div className="teen1dayleft">
            {singleRow('Daaga / Teja', dagaTeja, ' casino-bl-boxfull')}
            <MinMax item={dagaTeja} />
          </div>
          <div className="teen1dayright">
            {singleRow('Mogambo', mogamboItem, ' casino-bl-boxfull')}
            <MinMax item={mogamboItem} />
          </div>
        </div>
        <div className="casino-box-row three-card-total">
          {totalNameCell}
          {' '}
          {totalBoxes(false)}
          {' '}
          <MinMax item={cardTotal} extraCls=" w-100" />
        </div>
      </div>

      {/* MOBILE (d-none-big): plain stacked, 3 Card Total total-odds (bhav pehle). */}
      <div className="d-none-big">
        {singleRow('Daga / Teja', dagaTeja, '')}
        {singleRow('Mogambo', mogamboItem, '')}
        <div className="casino-box-row">
          {totalNameCell}
          {' '}
          {totalBoxes(true)}
        </div>
      </div>
    </>
  );
});

export default BetTableMogambo;
