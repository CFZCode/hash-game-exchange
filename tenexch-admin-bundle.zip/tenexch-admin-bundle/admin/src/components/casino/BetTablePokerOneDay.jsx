import { memo, useState, Fragment } from 'react';
import { cardSrc, parseCards } from './cards/cardUtils';
import { roundBook, fmtBook } from '../../utils/casinoBook';
const REMARK_ICON = 'https://wver.sprintstaticdata.com/v230/static/front/img/icons/remark.png'

const CDN = 'https://wver.sprintstaticdata.com/v230/static/front/img';

function findBySid(sub, sid) {
  return sub.find((s) => s.sid === sid);
}

function isSusp(item) {
  return !item || item.gstatus === 'SUSPENDED' || item.gstatus === '0';
}

function suspCls(item) {
  return isSusp(item) ? ' suspended' : '';
}

function fmtAmt(n) {
  const x = Number(n) || 0;
  if (x >= 100000) return `${x / 100000}L`;
  if (x >= 1000) return `${x / 1000}K`;
  return String(x);
}

function bookOf(exposures, name, sid) {
  return roundBook(exposures?.[`sid:${sid}`] ?? exposures?.[name] ?? 0);
}

function bookCls(v) {
  return v < 0 ? 'book-red' : v > 0 ? 'book-green' : 'book-black';
}

// range collapse (info + icon-range div)
function Range({ rangeId, min, max }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <i
        data-toggle="collapse"
        data-target={`#${rangeId}`}
        aria-expanded={open ? 'true' : 'false'}
        className={`fas fa-info-circle${open ? '' : ' collapsed'}`}
        onClick={() => setOpen((o) => !o)}
      ></i>
      {' '}
      <div id={rangeId} className={`collapse icon-range${open ? ' show' : ''}`}>
        {'\n                      R:'}
        <span>{fmtAmt(min ?? 100)}</span>
        -
        <span>{fmtAmt(max ?? 0)}</span>
      </div>
    </>
  );
}

const BetTablePokerOneDay = memo(function BetTablePokerOneDay({ gameData, onBet, exposures }) {
  const sub = gameData?.sub || [];
  const codes = parseCards(gameData?.card ?? '');
  const remark = gameData?.remark || 'Play Our New Game Premium Teenpatti 1 Day';
  const handleBet = onBet || (() => {});

  // Cards: 0,1 = Player A hole; 2,3 = Player B hole; 4-8 = Board (video)
  const cardA = [codes[0] || '1', codes[1] || '1'];
  const cardB = [codes[2] || '1', codes[3] || '1'];

  const playerA = findBySid(sub, 1);
  const playerB = findBySid(sub, 2);
  const a2card  = findBySid(sub, 3);
  const a7card  = findBySid(sub, 4);
  const b2card  = findBySid(sub, 5);
  const b7card  = findBySid(sub, 6);

  // one player box (A or B)
  const playerBox = (side, main, c2, c7, cls, r) => {
    const mainBook = bookOf(exposures, main?.nat, main?.sid);
    const book2 = bookOf(exposures, c2?.nat, c2?.sid);
    const book7 = bookOf(exposures, c7?.nat, c7?.sid);
    return (
      <div className={side === 'a' ? 'playerabox' : 'playerbbox'}>
        <div className={`casino-box-row ${cls}`}>
          <div className="casino-nation-name">
            <div className="float-left mr-2">
              <Range rangeId={r[0]} min={main?.min} max={main?.max ?? 300000} />
            </div>
            {' '}
            <b>Player {side.toUpperCase()}</b>
          </div>
          <div className="casino-bl-box">
            <div
              className={`back casino-bl-box-item${suspCls(main)}`}
              onClick={isSusp(main) ? undefined : () => handleBet(main.sid, 'back', main.b, main)}
            >
              <span className="casino-box-odd">{main?.b || 0}</span>
            </div>
            <div
              className={`lay casino-bl-box-item${suspCls(main)}`}
              onClick={isSusp(main) ? undefined : () => handleBet(main.sid, 'lay', main.l, main)}
            >
              <span className="casino-box-odd">{main?.l || 0}</span>
            </div>
          </div>
        </div>
        <div className="casino-nation-name text-center w-100">
          <span className={`casino-book ${bookCls(mainBook)}`}>{fmtBook(mainBook)}</span>
        </div>
        <div className="casino-box poker1dayother mt-2">
          <div className="casino-bl-box">
            <div className="odds-min-max">
              <span className="float-right casino-min-max pr-2">
                <Range rangeId={r[1]} min={c2?.min} max={c2?.max ?? 50000} />
              </span>
            </div>
            <div className="odds-min-max pl-2">
              <span className="float-right casino-min-max">
                <Range rangeId={r[2]} min={c7?.min} max={c7?.max ?? 50000} />
              </span>
            </div>
          </div>
          <div className="casino-bl-box">
            <div
              className={`casino-bl-box-item back${suspCls(c2)}`}
              onClick={isSusp(c2) ? undefined : () => handleBet(c2.sid, 'back', c2.b, c2)}
            >
              <span className="casino-box-odd">2 Cards Bonus</span>
            </div>
            <div
              className={`casino-bl-box-item back${suspCls(c7)}`}
              onClick={isSusp(c7) ? undefined : () => handleBet(c7.sid, 'back', c7.b, c7)}
            >
              <span className="casino-box-odd">7 Cards Bonus</span>
            </div>
          </div>
          <div className="casino-bl-box">
            <div className="odds-min-max">
              <span className={`casino-book ${bookCls(book2)}`}>{fmtBook(book2)}</span>
            </div>
            <div className="odds-min-max">
              <span className={`casino-book ${bookCls(book7)}`}>{fmtBook(book7)}</span>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <>
      {playerBox('a', playerA, a2card, a7card, 'playerafabcy', ['demo1', 'demo2', 'demo3'])}

      {/* Player A & B hole cards */}
      <div className="playerabcardbox">
        <div className="poker-icon"><img src={`${CDN}/poker.png`} /></div>
        <div className="row row5 w-100">
          <div className="col-12 col-md-6">
            <div className="dealer-name playera">Player A</div>
            <div className="mt-1">
              {cardA.map((c, i) => (
                <Fragment key={i}>{i > 0 && ' '}<span data-v-b64efdfa=""><img data-v-b64efdfa="" src={cardSrc(c)} /></span></Fragment>
              ))}
            </div>
          </div>
          <div className="col-12 col-md-6 text-right">
            <div className="dealer-name playerb">Player B</div>
            <div className="mt-1">
              {cardB.map((c, i) => (
                <Fragment key={i}>{i > 0 && ' '}<span data-v-b64efdfa=""><img data-v-b64efdfa="" src={cardSrc(c)} /></span></Fragment>
              ))}
            </div>
          </div>
        </div>
      </div>

      {playerBox('b', playerB, b2card, b7card, 'playerbfabcy', ['demo4', 'demo5', 'demo6'])}

      {/* Remark marquee */}
      <div className="casino-remark mt-3">
        <div className="remark-icon"><img src={REMARK_ICON} /></div>
        {' '}
        <marquee>{remark}</marquee>
      </div>
    </>
  );
});

export default BetTablePokerOneDay;
