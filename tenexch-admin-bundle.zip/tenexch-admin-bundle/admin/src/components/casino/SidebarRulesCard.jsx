// Sidebar "Rules" card with one static table — `.card.m-b-10 > .card-header h6
// "Rules" + .card-body table.table-bordered.rules-table` (reference DOM of the
// teenmuf / vteenmuf and vteen20 pages; the reference fills it from its
// `casino/rules` API: `{hed, child:[{nat, resval}]}`).
export default function SidebarRulesCard({ title, rows }) {
  return (
    <div className="card m-b-10">
      <div className="card-header">
        <h6 className="card-title d-inline-block">{'\n          Rules\n          '}</h6>
      </div>
      {' '}
      <div className="card-body" style={{ padding: '10px' }}>
        <table className="table table-bordered rules-table">
          <tbody>
            <tr className="text-center"><th colSpan="2">{title}</th></tr>
            {rows.map(([name, val]) => (
              <tr key={name}>
                <td width="60%">{name}</td><td>{val}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
