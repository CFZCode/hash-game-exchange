import { memo, useMemo } from 'react';
import { roundBook, fmtBook } from '../../utils/casinoBook';
const REMARK_ICON = 'https://wver.sprintstaticdata.com/v230/static/front/img/icons/remark.png'

const CDN = 'https://wver.sprintstaticdata.com/v230/static/front/img';
const CARD_BASE = `${CDN}/cards/`;
const CARD_FACES = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];

const DEFAULT_YES = 'Select any 3 card and you will win if you will get at least 1 card from the 3 cards you have selected.';
const DEFAULT_NO = 'Select any 3 card and you will win If you do not get any card from the 3 cards you have selected.';

function isSusp(item) {
  return !item || item.gstatus === 'SUSPENDED' || item.b === 0 || item.b === '0';
}

function bookOf(exposures, name, sid) {
  return roundBook(exposures?.[`sid:${sid}`] ?? exposures?.[name] ?? 0);
}

function bookCls(v) {
  return v < 0 ? 'book-red' : v > 0 ? 'book-green' : 'book-black';
}

// Yes/No box — 13-card grid (Select any 3). Cards click = bet.
function JudgeBox({ boxClass, title, side, item, rule, onBet, exposures }) {
  const book = bookOf(exposures, item?.nat, item?.sid);
  const susp = isSusp(item);
  const click = (face) => {
    if (!susp && onBet) onBet(item.sid, side, item.b, { ...item, selectedCard: face });
  };
  return (
    <div className={`threecardj-bl-box ${boxClass}`}>
      <div className="threecardj-title">
        <b>{title}</b>
        {' '}
        <span className={`casino-book ${bookCls(book)}`}>{fmtBook(book)}</span>
      </div>
      {' '}
      <div className={`threecardj-cards${susp ? ' suspended' : ''}`}>
        <div className="threecardj-odds text-center"><b>{item?.b || 0}</b></div>
        {' '}
        <div className="casino-cards text-center mt-1">
          {CARD_FACES.map((face) => (
            <div key={face} className="casino-card-item" onClick={() => click(face)}>
              <div className="card-image">
                <span data-v-b64efdfa=""><img data-v-b64efdfa="" src={`${CARD_BASE}${face}.png`} /></span>
              </div>
            </div>
          ))}
        </div>
        {' '}
        <div className="casino-min-max text-right"><span>{rule}</span></div>
      </div>
    </div>
  );
}

const BetTable3CardJ = memo(function BetTable3CardJ({ gameData, onBet, exposures }) {
  const sub = gameData?.sub ?? [];
  const remark = gameData?.remark || '';
  const remarks = remark.split('|');

  const byId = useMemo(() => {
    const m = {};
    sub.forEach((s) => { m[s.sid] = s; });
    return m;
  }, [sub]);

  const yesItem = byId[1];
  const noItem = byId[2];

  return (
    <>
      <div className="threecardj-container">
        <JudgeBox
          boxClass="back"
          title="Yes"
          side="back"
          item={yesItem}
          rule={remarks[0] || DEFAULT_YES}
          onBet={onBet}
          exposures={exposures}
        />
        <JudgeBox
          boxClass="lay"
          title="No"
          side="lay"
          item={noItem}
          rule={remarks[1] || DEFAULT_NO}
          onBet={onBet}
          exposures={exposures}
        />
      </div>
      {' '}
      <div className="text-right casino-min-max">
        R:
        <span>100</span>
        -
        <span>2L</span>
      </div>
      {' '}
      <div className="casino-remark mt-3">
        <div className="remark-icon"><img src={REMARK_ICON} /></div>
        {' '}
        <marquee>{remark || `${DEFAULT_YES}|${DEFAULT_NO}`}</marquee>
      </div>
    </>
  );
});

export default BetTable3CardJ;
