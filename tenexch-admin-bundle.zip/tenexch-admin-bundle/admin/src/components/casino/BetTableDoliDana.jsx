import { memo, useState } from 'react';
import { roundBook, fmtBook } from '../../utils/casinoBook';

function isSusp(item) {
  return !item || item.gstatus === 'SUSPENDED' || item.gstatus === '0';
}

function suspCls(item) {
  return isSusp(item) ? ' suspended' : '';
}

// 300000 -> 3L, 100000 -> 1L, 100 -> 100 (reference range formatting)
function formatAmount(n) {
  const num = Number(n) || 0;
  if (num >= 100000) return `${num / 100000}L`;
  if (num >= 1000) return `${num / 1000}K`;
  return String(num);
}

function bookOf(exposures, item) {
  const v = exposures?.[`sid:${item?.sid}`] ?? exposures?.[item?.nat];
  return v ? roundBook(v) : 0;
}

function bookCls(v) {
  if (!v) return 'book-black';
  return v < 0 ? 'book-red' : 'book-green';
}

// Info icon + R:<min>-<max> collapse tooltip (reference: collapsed icon +
// aria-expanded, div `icon-range collapse`)
function RangeInfo({ id, item, open, onToggle }) {
  return (
    <>
      <i
        data-toggle="collapse"
        data-target={`#${id}`}
        aria-expanded={open ? 'true' : 'false'}
        className={`fas fa-info-circle${open ? '' : ' collapsed'}`}
        onClick={onToggle}
        style={{ cursor: 'pointer' }}
      ></i>
      {' '}
      <div id={id} className={`icon-range collapse${open ? ' show' : ''}`}>
        {'\n                        R:'}
        <span>{formatAmount(item?.min)}</span>
        -
        <span>{formatAmount(item?.max)}</span>
      </div>
    </>
  );
}

// Doli Dana (dice) — reference: doli-main (players-bet + side-bets) +
// doli-other-bets (Particular Pair + Odds of Sum Total). Range ids sid se
// match hain (sid 1 -> #range1 ... sid 25 -> #range25).
const BetTableDoliDana = memo(function BetTableDoliDana({ gameData, onBet, exposures }) {
  const sub = gameData?.sub || [];
  const handleBet = onBet || (() => {});
  const [openRanges, setOpenRanges] = useState({});
  const toggle = (id) => setOpenRanges((p) => ({ ...p, [id]: !p[id] }));

  const bySid = (sid) => sub.find((s) => s.sid === sid);

  const playerA = bySid(1);
  const playerB = bySid(2);
  const anyPair = bySid(3);
  const sumPairs = sub.filter((s) => s.subtype === 'sumpair');
  const sumTotals = sub.filter((s) => s.subtype === 'sumtotal');
  const oddItem = bySid(21);
  const evenItem = bySid(22);
  const lucky7Item = bySid(23);
  const gt7Item = bySid(24);
  const lt7Item = bySid(25);

  const rangeFor = (item) => (item ? `range${item.sid}` : 'range0');

  // side-bets / pairs / sums: doli-odds-box with odds + book span
  const oddsBox = (label, item, oddsCls = 'casino-box-odd', bookExtraCls = '') => {
    if (!item) return null;
    const book = bookOf(exposures, item);
    const rid = rangeFor(item);
    const lockTop = isSusp(item) && book ? ' lock-top' : '';
    return (
      <div key={item.sid} className="doli-odds-box">
        <div className="odd-name">
          {'\n                        ' + label + '\n                        '}
          <div className="float-right">
            <RangeInfo id={rid} item={item} open={!!openRanges[rid]} onToggle={() => toggle(rid)} />
          </div>
        </div>
        {' '}
        <div className="casino-bl-box">
          <div
            className={`back casino-bl-box-item${suspCls(item)}${lockTop}`}
            onClick={isSusp(item) ? undefined : () => handleBet(item.sid, 'back', item.b, item)}
          >
            <span className={oddsCls}>{item?.b || 0}</span>
            {' '}
            <span className={`${bookExtraCls}${bookCls(book)}`}>{fmtBook(book)}</span>
          </div>
        </div>
      </div>
    );
  };

  return (
    <>
      <div className="doli-main">
        <div className="players-bet">
          {[playerA, playerB].map((item, i) => {
            const book = bookOf(exposures, item);
            const rid = rangeFor(item);
            return (
              <div key={item?.sid ?? i} className="casino-box-row">
                <div className="casino-nation-name">
                  <b>{item?.nat || ''}</b>
                  {' '}
                  <div className="float-right">
                    <span className={`mr-2 ${bookCls(book)}`}>{fmtBook(book)}</span>
                    {' '}
                    <RangeInfo id={rid} item={item} open={!!openRanges[rid]} onToggle={() => toggle(rid)} />
                  </div>
                </div>
                {' '}
                <div className="casino-bl-box">
                  <div
                    className={`back casino-bl-box-item${suspCls(item)}`}
                    onClick={isSusp(item) ? undefined : () => handleBet(item.sid, 'back', item.b, item)}
                  >
                    <span className="casino-box-odd">{item?.b || 0}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        {' '}
        <div className="side-bets">
          <div className="any-pair">
            {/* reference: Any Pair me suspended class bl-box pe hota hai */}
            <div className="doli-odds-box">
              <div className="odd-name">
                {'\n                      Any Pair\n                      '}
                <div className="float-right">
                  <RangeInfo id="range3" item={anyPair} open={!!openRanges.range3} onToggle={() => toggle('range3')} />
                </div>
              </div>
              {' '}
              <div className={`casino-bl-box${suspCls(anyPair)}`}>
                <div
                  className="back casino-bl-box-item"
                  onClick={isSusp(anyPair) ? undefined : () => handleBet(anyPair.sid, 'back', anyPair.b, anyPair)}
                >
                  <span className="casino-box-odd">{anyPair?.b || 0}</span>
                  {' '}
                  <span className={bookCls(bookOf(exposures, anyPair))}>{fmtBook(bookOf(exposures, anyPair))}</span>
                </div>
              </div>
            </div>
          </div>
          {' '}
          <div className="odd-even-pair">
            <div className="bets-box">
              {oddsBox('Odd', oddItem)}
              {oddsBox('Even', evenItem)}
            </div>
          </div>
          {' '}
          <div className="lucky7-pair">
            <div className="bets-box">
              {oddsBox('< 7', lt7Item)}
              {' '}
              {oddsBox('Lucky 7', lucky7Item)}
              {' '}
              {oddsBox('> 7', gt7Item)}
            </div>
          </div>
        </div>
      </div>
      {' '}
      <div className="doli-other-bets">
        <div className="particular-pair">
          <h4>Particular Pair</h4>
          {' '}
          <div className="bets-box">
            {sumPairs.map((item) => oddsBox(item.nat, item, 'casino-odds'))}
          </div>
        </div>
        {' '}
        <div className="sum-odds">
          <h4>Odds of Sum Total</h4>
          {' '}
          <div className="bets-box">
            {sumTotals.map((item) => oddsBox(item.nat, item, 'casino-odds', 'casino-volume '))}
          </div>
        </div>
      </div>
    </>
  );
});

export default BetTableDoliDana;
