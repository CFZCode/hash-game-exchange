import { Fragment, memo, useState } from 'react';
import { roundBook, fmtBook } from '../../utils/casinoBook';

function fmtAmt(n) {
  const x = Number(n) || 0;
  if (x >= 100000) return `${x / 100000}L`;
  if (x >= 1000) return `${x / 1000}K`;
  return String(x);
}

// book hamesha visible: 0 pe book-black, minus red / plus green
function bookOf(exposures, item) {
  return roundBook(exposures?.[`sid:${item?.sid}`] ?? exposures?.[item?.nat] ?? 0);
}

// Odd / Even cells: bets are stored as "Card N Odd" / "Card N Even" (player
// site), a name no feed runner carries — the page books them per exact
// selection (applyAdminLineBook). Falls back to the card's own book on pages
// that don't (pteen).
function oddEvenBookOf(exposures, item, label) {
  const v = exposures?.[`${item?.nat} ${label}`];
  return v === undefined ? bookOf(exposures, item) : roundBook(v);
}

function bookCls(v) {
  return v < 0 ? 'book-red' : v > 0 ? 'book-green' : 'book-black';
}

// mobile title range-info collapse (reference: fa-info-circle float-right +
// collapse icon-range R:min-max)
function MobileRange({ id, min, max, open, onToggle }) {
  return (
    <div className="float-right">
      <i
        data-toggle="collapse"
        data-target={`#${id}`}
        className="fas fa-info-circle float-right"
        onClick={onToggle}
      ></i>
      {' '}
      <div id={id} className={`collapse icon-range${open ? ' show' : ''}`}>
        {'\n                          R:'}
        <span>{fmtAmt(min)}</span>
        -
        <span>{fmtAmt(max)}</span>
      </div>
    </div>
  );
}

function findByNatAndType(sub, nat, subtype) {
  return sub.find((s) => s.nat === nat && s.subtype === subtype);
}

function findByNat(sub, nat) {
  return sub.find((s) => s.nat === nat);
}

function isSusp(item) {
  if (!item) return true;
  if (item.gstatus === 'SUSPENDED' || item.gstatus === '0') return true;
  // Card items have odds array — check that instead of top-level b/l
  if (item.odds && Array.isArray(item.odds)) return false;
  if ((!item.b || item.b === 0) && (!item.l || item.l === 0)) return true;
  return false;
}

function getCardOdd(card) {
  const odds = card?.odds;
  if (!odds || !Array.isArray(odds)) return { odd: card?.b || 0, even: card?.l || 0 };
  const oddItem = odds.find((o) => o.nat === 'Odd') || odds[0];
  const evenItem = odds.find((o) => o.nat === 'Even') || odds[1];
  return { odd: oddItem?.b || 0, even: evenItem?.b || 0 };
}

function isCardSusp(card) {
  if (!card) return true;
  if (card.gstatus === 'SUSPENDED' || card.gstatus === '0') return true;
  const { odd, even } = getCardOdd(card);
  return odd === 0 && even === 0;
}

function suspCls(item) {
  return isSusp(item) ? ' suspended' : '';
}

// desktop nation-name range (reference: book `mr-2 casino-book` + info icon
// `collapsed` + `icon-range collapse` R:min-max; Odd/Even rows: plain icon +
// `collapse icon-range`, no book)
function DesktopRange({ id, min, max, open, onToggle, book, plain }) {
  return (
    <div className="float-right">
      {!plain && <span className={`mr-2 casino-book ${bookCls(book)}`}>{fmtBook(book)}</span>}
      {!plain && ' '}
      <i
        data-toggle="collapse"
        data-target={`#${id}`}
        aria-expanded={plain ? undefined : String(open)}
        className={`fas fa-info-circle${plain || open ? '' : ' collapsed'}`}
        onClick={onToggle}
      ></i>
      {' '}
      <div id={id} className={`${plain ? 'collapse icon-range' : 'icon-range collapse'}${open ? ' show' : ''}`}>
        {'\n                          R:'}
        <span>{fmtAmt(min)}</span>
        -
        <span>{fmtAmt(max)}</span>
      </div>
    </div>
  );
}

// ─── Desktop layout (d-none-small) ───────────────────────────────────────────

const DesktopLayout = memo(function DesktopLayout({ sub, onBet, exposures }) {
  const playerA = findByNatAndType(sub, 'Player A', 'teen');
  const playerB = findByNatAndType(sub, 'Player B', 'teen');
  const conA = findByNatAndType(sub, 'Player A', 'con');
  const conB = findByNatAndType(sub, 'Player B', 'con');
  const [ranges, setRanges] = useState({});
  const toggle = (id) => setRanges((r) => ({ ...r, [id]: !r[id] }));

  const cardItems = [];
  for (let i = 1; i <= 6; i++) {
    cardItems.push(findByNat(sub, `Card ${i}`));
  }
  const cardMin = cardItems.find(Boolean)?.min ?? 100;
  const cardMax = cardItems.find(Boolean)?.max ?? 25000;

  // Main / Consecutive row: nation name + book/range, back + lay
  const playerRow = (item, label, rangeId, titleCls) => (
    <div className="casino-box-row">
      <div className={`casino-nation-name${titleCls}`}>
        <b>{label}</b>
        {' '}
        <DesktopRange
          id={rangeId}
          min={item?.min}
          max={item?.max}
          book={bookOf(exposures, item)}
          open={!!ranges[rangeId]}
          onToggle={() => toggle(rangeId)}
        />
      </div>
      {' '}
      <div className="casino-bl-box">
        <div className={`back casino-bl-box-item${suspCls(item)}`} onClick={isSusp(item) ? undefined : () => onBet(item.sid, 'back', item.b, item)}>
          <span className="casino-box-odd">{item?.b || 0}</span>
        </div>
        {' '}
        <div className={`lay casino-bl-box-item${suspCls(item)}`} onClick={isSusp(item) ? undefined : () => onBet(item.sid, 'lay', item.l, item)}>
          <span className="casino-box-odd">{item?.l || 0}</span>
        </div>
      </div>
    </div>
  );

  const titleRow = (cls, label) => (
    <div className="casino-box-row">
      <div className="casino-nation-name no-border casino-bl-box-title">
        <div className={cls}>{label}</div>
      </div>
      {' '}
      <div className="casino-bl-box casino-bl-box-title">
        <div className="casino-bl-box-item"><b>Back</b></div>
        {' '}
        <div className="casino-bl-box-item"><b>Lay</b></div>
      </div>
    </div>
  );

  // Odd / Even row: back box + casino-book under it (book-black 0 hamesha)
  const oddEvenRow = (label, rowCls, rangeId, side) => (
    <div className={`casino-box-row${rowCls}`}>
      <div className="casino-nation-name mb-4">
        <b>{label}</b>
        {' '}
        <DesktopRange
          id={rangeId}
          min={cardMin}
          max={cardMax}
          plain
          open={!!ranges[rangeId]}
          onToggle={() => toggle(rangeId)}
        />
      </div>
      {' '}
      {cardItems.map((c, i) => {
        const { odd, even } = getCardOdd(c);
        const val = side === 'back' ? odd : even;
        const susp = isCardSusp(c);
        const book = oddEvenBookOf(exposures, c, label);
        return (
          <div key={i} className="casino-bl-box">
            <div className={`back casino-bl-box-item${susp ? ' suspended' : ''}`} onClick={susp ? undefined : () => onBet(c.sid, side, val, { ...c, nat: c.nat, etype: 'fancy' })}>
              <span className="casino-box-odd">{val || 0}</span>
            </div>
            {' '}
            <div className={`casino-book ${bookCls(book)}`}>{fmtBook(book)}</div>
          </div>
        );
      })}
    </div>
  );

  return (
    <div className="teen1daycasino-container d-none-small">
      {/* LEFT: Player A */}
      <div className="teen1dayleft">
        {titleRow('playera', 'Player A')}
        {' '}
        {playerRow(playerA, 'Main', 'range1', '')}
        {' '}
        {playerRow(conA, 'Consecutive', 'range6', ' casino-card-img')}
      </div>
      {' '}
      {/* CENTER divider */}
      <div className="teen1daycenter"></div>
      {' '}
      {/* RIGHT: Player B */}
      <div className="teen1dayright">
        {titleRow('playerb', 'Player B')}
        {' '}
        {playerRow(playerB, 'Main', 'range7', '')}
        {' '}
        {playerRow(conB, 'Consecutive', 'range12', ' casino-card-img')}
      </div>
      {' '}
      {/* ODD/EVEN Cards */}
      <div className="teen1dayother">
        <div className="casino-box-row">
          <div className="casino-nation-name no-border"></div>
          {cardItems.map((c, i) => (
            <Fragment key={i}>
              {' '}
              <div className="casino-bl-box">
                <div className="casino-bl-box-item"><b>Card {i + 1}</b></div>
              </div>
            </Fragment>
          ))}
        </div>
        {' '}
        {oddEvenRow('Odd', ' mb-3', 'range13', 'back')}
        {' '}
        {oddEvenRow('Even', '', 'range14', 'lay')}
      </div>
    </div>
  );
});

// ─── Mobile layout (d-none-big) ──────────────────────────────────────────────

const MobileLayout = memo(function MobileLayout({ sub, onBet, exposures }) {
  const mainPlayers = sub.filter((s) => s.subtype === 'teen');
  const consecutive = sub.filter((s) => s.subtype === 'con');
  const oddEvenCards = [];
  for (let i = 1; i <= 6; i++) {
    const c = sub.find((s) => s.nat === `Card ${i}`);
    if (c) oddEvenCards.push(c);
  }
  const [ranges, setRanges] = useState({});
  const toggle = (id) => setRanges((r) => ({ ...r, [id]: !r[id] }));

  // Main / Consecutive player back+lay row: book float-right book-black (0 bhi)
  const playerRow = (item) => {
    const book = bookOf(exposures, item);
    return (
      <div key={item.sid} className="casino-bl-box">
        <div className="casino-bl-box-item casino-odds-name">
          <span>{item.nat}</span>
          {' '}
          <span className={`float-right ${bookCls(book)}`}>{fmtBook(book)}</span>
        </div>
        <div className={`back casino-bl-box-item${suspCls(item)}`} onClick={isSusp(item) ? undefined : () => onBet(item.sid, 'back', item.b, item)}>
          <span className="casino-box-odd">{item.b || 0}</span>
        </div>
        <div className={`lay casino-bl-box-item${suspCls(item)}`} onClick={isSusp(item) ? undefined : () => onBet(item.sid, 'lay', item.l, item)}>
          <span className="casino-box-odd">{item.l || 0}</span>
        </div>
      </div>
    );
  };

  return (
    <div className="teen1daycasino-container d-none-big">
      {/* MAIN */}
      <div className="casino-box-row">
        <div className="casino-bl-box casino-bl-box-title">
          <div className="casino-bl-box-item">
            <b>Main</b>
            {' '}
            <MobileRange id="range1" min={mainPlayers[0]?.min} max={mainPlayers[0]?.max} open={!!ranges.range1} onToggle={() => toggle('range1')} />
          </div>
          <div className="casino-bl-box-item"><b>Back</b></div>
          <div className="casino-bl-box-item"><b>Lay</b></div>
        </div>
        {mainPlayers.map((item) => playerRow(item))}
      </div>

      {/* CONSECUTIVE */}
      <div className="casino-box-row">
        <div className="casino-bl-box casino-bl-box-title">
          <div className="casino-bl-box-item casino-card-img">
            <b>Consecutive</b>
            {' '}
            <MobileRange id="range6" min={consecutive[0]?.min} max={consecutive[0]?.max} open={!!ranges.range6} onToggle={() => toggle('range6')} />
          </div>
          <div className="casino-bl-box-item"><b>Back</b></div>
          <div className="casino-bl-box-item"><b>Lay</b></div>
        </div>
        {consecutive.map((item) => playerRow(item))}
      </div>

      {/* CARDS ODD/EVEN */}
      <div className="casino-box-row teen1dayodev">
        <div className="casino-bl-box casino-bl-box-title">
          <div className="casino-bl-box-item casino-card-img">
            <b>Cards</b>
            {' '}
            <MobileRange id="range7" min={oddEvenCards[0]?.min ?? 100} max={oddEvenCards[0]?.max ?? 25000} open={!!ranges.range7} onToggle={() => toggle('range7')} />
          </div>
          <div className="casino-bl-box-item"><b>Odd</b></div>
          <div className="casino-bl-box-item"><b>Even</b></div>
        </div>
        {oddEvenCards.map((item) => {
          const { odd, even } = getCardOdd(item);
          const susp = isCardSusp(item);
          const oddBook = oddEvenBookOf(exposures, item, 'Odd');
          const evenBook = oddEvenBookOf(exposures, item, 'Even');
          return (
            <div key={item.sid} className="casino-bl-box">
              <div className="casino-bl-box-item casino-odds-name">
                <span>{item.nat}</span>
              </div>
              <div className={`back casino-bl-box-item${susp ? ' suspended' : ''}`} onClick={susp ? undefined : () => onBet(item.sid, 'back', odd, { ...item, etype: 'fancy' })}>
                <span className="casino-box-odd">{odd || 0}</span>
                {' '}
                <span className={bookCls(oddBook)}>{fmtBook(oddBook)}</span>
              </div>
              <div className={`back casino-bl-box-item${susp ? ' suspended' : ''}`} onClick={susp ? undefined : () => onBet(item.sid, 'lay', even, { ...item, etype: 'fancy' })}>
                <span className="casino-box-odd">{even || 0}</span>
                {' '}
                <span className={bookCls(evenBook)}>{fmtBook(evenBook)}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
});

// ─── Main export ─────────────────────────────────────────────────────────────

const BetTableTeen1Day = memo(function BetTableTeen1Day({ gameData, onBet, exposures }) {
  const sub = gameData?.sub || [];
  const handleBet = onBet || (() => {});

  return (
    <>
      <DesktopLayout sub={sub} onBet={handleBet} exposures={exposures} />
      <MobileLayout sub={sub} onBet={handleBet} exposures={exposures} />
    </>
  );
});

export default BetTableTeen1Day;
