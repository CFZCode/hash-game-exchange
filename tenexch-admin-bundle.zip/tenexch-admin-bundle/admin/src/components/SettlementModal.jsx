import { useState, useEffect } from 'react'
import { declareResult, voidBet } from '../services/api'
import useModalEnter from '../hooks/useModalEnter'

function SettlementModal({ show, onHide, mode, match, onSubmit }) {
  const counts = match?.counts ?? 2
  const totalBets = match?.totalBets ?? 0
  const isThreeWay = counts >= 3 || totalBets >= 3
  const teamOne = match?.teamOne ?? 'Team 1'
  const teamTwo = match?.teamTwo ?? 'Team 2'
  // /momatches now returns the market's real runner list. Bets placed before
  // that carry no runners, so keep a 3-way fallback — otherwise the draw has
  // no button and cannot be declared, while the hint below still promises one.
  // 'The Draw' is the label exposure and settlement key on, not 'Draw'.
  const runners = match?.runners?.length
    ? match.runners
    : isThreeWay
      ? [teamOne, teamTwo, 'The Draw']
      : [teamOne, teamTwo]
  const matchTitle = match?.matchTitle || `${teamOne} vs ${teamTwo}`

  const [selectedOutcome, setSelectedOutcome] = useState(null)
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    if (show) {
      setSelectedOutcome(null)
      setSubmitting(false)
    }
  }, [show, mode])

  const handleSubmit = async () => {
    if (mode === 'declare' && selectedOutcome == null) return
    setSubmitting(true)
    try {
      if (mode === 'void') {
        const payload = {
          eventid: match.eventId,
          match_id: match.matchId,
          market_type: match.marketType,
          gametype: match.gameType || 'FAN',
        }
        await voidBet(payload)
        await onSubmit?.({ success: true })
      } else {
        const wName = runners[selectedOutcome] ?? ''
        const payload = {
          eventid: match.eventId,
          match_id: match.matchId,
          match_title: matchTitle,
          game_type: match.gameType,
          market_type: match.marketType,
          winnerName: wName,
        }
        await declareResult(payload)
        await onSubmit?.({ success: true })
      }
      onHide?.()
    } catch (e) {
      console.error(e)
      alert(e.response?.data?.error || e.message)
    } finally {
      setSubmitting(false)
    }
  }

  const { modalClass, backdropClass, onBackdropClick } = useModalEnter(onHide, show)

  if (!show) return null

  const title = mode === 'void' ? 'Void Match' : 'Declare Result'
  const canSubmit = mode === 'void' || selectedOutcome != null
  const isSubmitDisabled = !canSubmit || submitting

  const handleFormSubmit = (e) => {
    e.preventDefault()
    if (isSubmitDisabled) return
    handleSubmit()
  }

  const renderOutcomeBox = (label, idx) => (
    <button
      key={idx}
      type="button"
      onClick={() => setSelectedOutcome(idx)}
      className={`btn ${selectedOutcome === idx ? 'btn-primary' : 'btn-outline-secondary'} mx-1 my-1 px-3 py-2 font-weight-bold`}
      style={{ minWidth: 110 }}
    >
      {label}
    </button>
  )

  return (
    <div style={{ position: 'absolute', zIndex: 1040 }}>
      <div role="dialog" className={modalClass} aria-modal="true" onClick={onBackdropClick} style={{ display: 'block' }}>
        <div className="modal-dialog modal-md">
          <div tabIndex="-1" className="modal-content">
            <header className="modal-header">
              <h5 className="modal-title">{title}</h5>
              <button type="button" aria-label="Close" className="close" onClick={onHide}>×</button>
            </header>
            <form onSubmit={handleFormSubmit}>
              <div className="modal-body">
                <div className="mb-3 text-center font-weight-bold">{matchTitle}</div>

                {mode === 'declare' && (
                  <>
                    <div className="d-flex flex-wrap justify-content-center align-items-center mb-2">
                      {isThreeWay
                        ? runners.map((runner, idx) => renderOutcomeBox(runner, idx))
                        : runners.map((runner, idx) => (
                            <span key={idx} className="d-inline-flex align-items-center">
                              {idx > 0 && <span className="mx-2 text-muted">VS</span>}
                              {renderOutcomeBox(runner, idx)}
                            </span>
                          ))}
                    </div>
                    <div className="text-center mt-2">
                      {selectedOutcome != null ? (
                        <>Result: <strong>{runners[selectedOutcome]}</strong></>
                      ) : (
                        <span className="text-muted">{runners.length > 2 ? 'Select a runner' : 'Select winner'}</span>
                      )}
                    </div>
                  </>
                )}

                {mode === 'void' && (
                  <div className="alert alert-warning">
                    Do you really want to cancel or refund the bets? All stakes will be refunded to the users. This action cannot be undone.
                  </div>
                )}
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={onHide}>Cancel</button>
                <button
                  type="submit"
                  className={`btn ${mode === 'void' ? 'btn-danger' : 'btn-primary'}`}
                  disabled={isSubmitDisabled}
                >
                  {submitting ? 'Submitting...' : mode === 'void' ? 'Confirm Void' : 'Submit'}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div className={backdropClass}></div>
    </div>
  )
}

export default SettlementModal
