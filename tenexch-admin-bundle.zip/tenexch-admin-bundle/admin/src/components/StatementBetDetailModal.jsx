import { useEffect } from 'react'
import { createPortal } from 'react-dom'
import useModalEnter from '../hooks/useModalEnter'
import ResultContentSwitch from './casino/results/ResultContentSwitch'
import { cardSrc } from './casino/results/resultParsers'
import RoundBetsTable from './casino/RoundBetsTable'

// Andar Bahar 50 cards: one bet per statement row. Like the player modal and
// tenexch.com: the card that DECIDED the bet (first card of its rank dealt
// at/after its position "Bahar 2/30" -> 2S at #33), a Winner box with the
// side it fell on, and the round id with that card number appended.
function ab50Decision(result, bet) {
  const sel = String(bet?.selection || '').trim().match(/^(Andar|Bahar)\s+(10|[2-9]|[AJQK])$/i)
  if (!sel) return null
  const rank = sel[2].toUpperCase()
  const pm = String(bet?.player_name || '').match(/\/\s*(\d+)\s*$/)
  const start = pm ? Number(pm[1]) - 1 : 0
  const cards = String(result?.card || '').split(',').map((c) => c.trim())
  for (let i = Math.max(0, start); i < cards.length; i += 1) {
    const r = (cards[i].toUpperCase().match(/^(10|[2-9]|[AJQK])/) || [])[1]
    if (r === rank) return { index: i, code: cards[i], side: i % 2 === 0 ? 'Bahar' : 'Andar' }
  }
  return null
}

// Account Statement (Game Report) — "Details" modal behind a game row.
// Reference layout: breadcrumb, Winner / Game Time, All-Back-Lay-Deleted
// radios, Total Bets / Total Win, then the bets table (Username / Nation /
// Rate / Bhav / Amount / Win / Date / IP / B Details / Action).
//
// A CASINO row shows the round itself on top instead — Round-ID, Match Time and
// the game's own result renderer (cards + result box), the same block the
// Casino Result report draws — and has no Bhav column. `detail.result` is the
// detail-results `t1`; when it is missing the text line stays.
//
// Render-only on purpose: the page fetches (its loader runs over the statement
// table) and mounts this once the bets are in, so it never opens on a spinner.
// Data: POST /admin/reports/statementv2/bet-detail.

const pad = (n) => String(n).padStart(2, '0')

// Bet dates are real timestamps -> browser local time, same as the statement table
const fmtDate = (value) => {
  if (!value) return ''
  const d = new Date(value)
  if (isNaN(d)) return String(value)
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`
}

// Game time comes as a NAIVE "YYYY-MM-DD HH:mm:ss" (the feed's wall clock) —
// print the digits as they are; parsing it as a Date would shift it by the
// browser's offset.
const fmtGameTime = (value) => {
  if (!value) return ''
  const m = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?$/.exec(String(value))
  if (m) return `${m[3]}/${m[2]}/${m[1]} ${m[4]}:${m[5]}:${m[6] || '00'}`
  return fmtDate(value)
}

function StatementBetDetailModal({ detail, onHide }) {
  const { modalClass, backdropClass, onBackdropClick } = useModalEnter(onHide)

  useEffect(() => {
    document.body.classList.add('modal-open')
    return () => document.body.classList.remove('modal-open')
  }, [])

  const bets = detail?.bets || []
  const isCasino = !!detail?.casino
  // an empty object / array from the feed is not a result
  const result = detail?.result && typeof detail.result === 'object' && Object.keys(detail.result).length
    ? detail.result
    : null
  const showResult = isCasino && !!result
  const abDecision = showResult && detail.casino.gameCode === 'ab3' && bets.length > 0 && bets.every((b) => String(b.selection || '').trim().match(/(10|[2-9]|[AJQK])$/i)?.[1]?.toUpperCase() === String(bets[0].selection || '').trim().match(/(10|[2-9]|[AJQK])$/i)?.[1]?.toUpperCase())
    ? ab50Decision(result, bets[0])
    : null

  return createPortal(
    <div style={{ position: 'absolute', zIndex: 1040 }}>
      <div role="dialog" className={`${modalClass}${showResult ? ' casino-result' : ''}`} aria-modal="true" onClick={onBackdropClick} style={{ display: 'block' }}>
        <div className="modal-dialog modal-xl">
          <span tabIndex="0"></span>
          <div tabIndex="-1" className="modal-content">
            <header className="modal-header">
              <h5 className="modal-title">Details</h5>
              <button type="button" aria-label="Close" className="close" onClick={onHide}>×</button>
            </header>
            <div className="modal-body">
              {showResult ? (
                <div>
                  <div className="casino-result-round">
                    <div>Round-ID: {abDecision ? `${result.rid || detail.casino.roundId}${abDecision.index + 1}` : (result.rid || detail.casino.roundId)}</div>
                    {' '}
                    <div>
                      Match Time:{' '}
                      <span>{fmtDate(result.mtime || detail?.gameTime)}</span>
                    </div>
                  </div>
                  {' '}
                  {abDecision ? (
                    <div className="row row5">
                      <div className="col-12 text-center mt-2 mb-2">
                        <div className="casino-result-cards-item d-inline-block">
                          <img src={cardSrc(abDecision.code)} alt={abDecision.code} />
                        </div>
                      </div>
                      <div className="col-12">
                        <div className="casino-result-desc">
                          <div className="casino-result-desc-item">
                            <div>Winner</div>
                            <div>{abDecision.side}</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <ResultContentSwitch gameType={detail.casino.gameCode} detail={result} />
                  )}
                </div>
              ) : (
                <>
                  <div className="mt-1">{detail?.breadcrumb || ''}</div>
                  <div className="mt-1">
                    <div className="row">
                      <div className="col-6">Winner: {detail?.winner ?? ''}</div>
                      {/* Reference: label on one line, the time under it */}
                      <div className="col-6 text-right">
                        <div>Game Time:</div>
                        <div>{fmtGameTime(detail?.gameTime)}</div>
                      </div>
                    </div>
                  </div>
                </>
              )}
              {/* Reference: ~24px more air between the result card and the radios */}
              <div className={showResult ? 'mt-4' : undefined}>
                <RoundBetsTable bets={bets} showBhav={!isCasino} idPrefix="stmt-bet" gameType={detail?.casino?.gameCode} />
              </div>
            </div>
          </div>
          <span tabIndex="0"></span>
        </div>
      </div>
      <div className={backdropClass}></div>
    </div>,
    document.body,
  )
}

export default StatementBetDetailModal
