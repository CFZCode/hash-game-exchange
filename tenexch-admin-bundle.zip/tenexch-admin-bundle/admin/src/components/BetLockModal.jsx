import { createPortal } from 'react-dom'
import { useState, useEffect } from 'react'
import Swal from 'sweetalert2'
import api from '../services/api'
import useModalEnter from '../hooks/useModalEnter'
import LoaderOverlay from './LoaderOverlay'

/* The reference's toast, read off the user's DOM dump (2026-09-23):

     div.swal2-container.swal2-top-end.swal2-backdrop-show
       div.swal2-popup.swal2-toast.swal2-icon-error.swal2-show
         div.swal2-icon.swal2-error.swal2-icon-show   (display: flex)
         h2.swal2-title                               (display: none)
         div.swal2-html-container                     "Transaction Code is required"
         div.swal2-actions                            (display: none)
         div.swal2-timer-progress-bar                 (display: none)

   → toast, top-end, icon `error`, no title (the words go in the html
   container, so they are passed as `text`), no buttons, no progress bar.
   Same mixin the rest of the admin uses. */
const Toast = Swal.mixin({
  toast: true,
  position: 'top-end',
  showConfirmButton: false,
  timer: 3000,
  timerProgressBar: false,
})

function BetLockModal({ show, onHide, eventId, marketId, marketName }) {
  const [children, setChildren] = useState([])
  const [loading, setLoading] = useState(false)
  // a tick is in flight — the reference dims the modal and spins over it for
  // the whole call, then toasts (recording, 2026-09-23)
  const [busy, setBusy] = useState(false)
  /* The modal does not appear until its list is here: Bet Lock opens on a
     full-screen loader and swaps to the modal when the fetch lands — the same
     order every other modal in here follows (View More, User Book) and what the
     user asked for on 2026-09-23 ("bet lock open karne se pehle loader aana
     chahiye"). */
  const [booted, setBooted] = useState(false)
  const [selectAll, setSelectAll] = useState(false)
  const [transactionCode, setTransactionCode] = useState('')

  useEffect(() => {
    if (!show) { setBooted(false); return }
    if (!eventId) return
    fetchChildren()
    setTransactionCode('')
  }, [show, eventId, marketId, marketName])

  const fetchChildren = async () => {
    setLoading(true)
    try {
      const params = {}
      if (marketId) params.market_id = marketId
      if (marketName) params.market_name = marketName
      const response = await api.get(`/admin/betlock/market-locks/${eventId}`, { params })
      if (response.data?.success) {
        const data = response.data.data || []
        setChildren(data)
        setSelectAll(data.length > 0 && data.every((c) => c.is_locked))
      } else {
        setChildren([])
      }
    } catch (err) {
      console.error('Error fetching children:', err)
      setChildren([])
    } finally {
      setLoading(false)
      setBooted(true)
    }
  }

  /* No Submit button any more: a tick IS the action (user, 2026-09-23 —
     "button hata de, API instantly call kar jab checkbox pe click kare").
     The Transaction Code guards it; empty means nothing is sent and the box
     does not move. */
  const guard = () => {
    if (transactionCode.trim()) return true
    Toast.fire({ icon: 'error', text: 'Transaction Code is required' })
    return false
  }

  const marketBase = () => {
    const base = { event_id: eventId }
    if (marketId) base.market_id = marketId
    if (marketName) base.market_name = marketName
    return base
  }

  /* One tick = one call, and the reference's own sequence around it
     (recording 2026-09-23, 10 fps):

       t+0.0  the box fills in
       t+0.1  the modal greys out and a spinner sits over it
       t+0.8  spinner goes, a swal2 toast drops in: green check,
              "User locked" / "User unlocked"
       t+0.9  the list has re-rendered in the server's new order

     so: loader for the whole call, then the toast, then a refetch — no
     optimistic tick, the list comes back from the server. */
  const runLock = async (call, next) => {
    setBusy(true)
    try {
      await call()
      Toast.fire({ icon: 'success', text: next ? 'User locked' : 'User unlocked' })
      await fetchChildren()
    } catch (err) {
      /* The server's own words, verbatim — a rejected transaction code comes
         back as "Master Password not valid." and that is what the operator must
         see. No local string may shadow it (user, 2026-09-23). */
      Toast.fire({ icon: 'error', text: err?.response?.data?.message || err?.message || '' })
    } finally {
      setBusy(false)
    }
  }

  const handleToggle = (child) => {
    if (!guard()) return
    const next = !child.is_locked
    return runLock(() => api.post('/admin/betlock/toggle-market-lock', {
      ...marketBase(),
      account_id: child.id,
      account_type: child.type,
      is_locked: next,
      transactionPassword: transactionCode,
    }), next)
  }

  const handleSelectAll = () => {
    if (!guard()) return
    const next = !selectAll
    return runLock(() => api.post('/admin/betlock/bulk-toggle-market-lock', {
      ...marketBase(),
      accounts: children.map((c) => ({ account_id: c.id, account_type: c.type })),
      is_locked: next,
      transactionPassword: transactionCode,
    }), next)
  }

  const handleClose = () => {
    setChildren([])
    setSelectAll(false)
    onHide()
  }

  // `show && booted`, so the open animation runs when the modal actually
  // appears — not behind the loader
  const { modalClass, backdropClass, onBackdropClick } = useModalEnter(handleClose, show && booted)

  if (!show) return null
  if (!booted) return createPortal(<LoaderOverlay />, document.body)

  /* Portaled to <body>, like BootstrapVue's own `b-modal`
     (`…___BV_modal_outer_` is a direct child of body in the reference capture).
     In place it would sit inside `.detail-page-container`, whose
     `font-family: "Noto Sans"` (style.css:732) would beat the `body`
     rule — the reference renders its modals in Poppins. */
  return createPortal(
    <div style={{ position: 'absolute', zIndex: 1040 }}>
      <div role="dialog" className={modalClass} aria-modal="true" onClick={onBackdropClick} style={{ display: 'block' }}>
        <div className="modal-dialog modal-md">
          <span tabIndex="0"></span>
          <div tabIndex="-1" className="modal-content">
            {/* The reference greys the MODAL and spins over it while a tick is
                in flight — not the whole page. `.inside-loader-overlay` is that
                loader, copied verbatim from admin/layout.html into
                styles/index.css: absolute, 100%x100%, white 50%, centred. It
                lands inside `.modal-content` (position: relative), so nothing
                around it moves. */}
            {busy && <div className="inside-loader-overlay"><i className="fas fa-spinner fa-spin"></i></div>}
            <header className="modal-header">
              <h5 className="modal-title">Bet Lock</h5>
              <button type="button" aria-label="Close" className="close" onClick={handleClose}>×</button>
            </header>
            <div className="modal-body">
              <div className="row">
                <div className="col-6"></div>
                <div className="col-6">
                  <div className="form-group">
                    <input
                      type="password"
                      name="ulockmpass"
                      placeholder="Transaction Code"
                      className="form-control"
                      value={transactionCode}
                      onChange={(e) => setTransactionCode(e.target.value)}
                    />
                  </div>
                </div>
              </div>
              <div className="table-responsive">
                <table className="table table-bordered">
                  <thead>
                    <tr>
                      <th>
                        <div className="custom-control custom-checkbox">
                          <input
                            type="checkbox"
                            className="custom-control-input"
                            id="betlock-select-all"
                            checked={selectAll}
                            onChange={handleSelectAll}
                            disabled={loading || children.length === 0}
                          />
                          <label className="custom-control-label" htmlFor="betlock-select-all"></label>
                        </div>
                      </th>
                      <th>All Account</th>
                    </tr>
                  </thead>
                  <tbody>
                    {/* The rows STAY while a refetch runs. This used to be
                        `loading ? <one Loading row> : rows`, so every tick
                        collapsed the table to a single line and then grew it
                        back — the modal jumping up and down after each toggle
                        (user, 2026-09-23: "dance of the modal and jerking").
                        The spinner above already says the page is working. */}
                    {loading && children.length === 0 ? (
                      <tr><td colSpan="2" className="text-center">Loading...</td></tr>
                    ) : children.length === 0 ? (
                      <tr><td colSpan="2" className="text-center">No accounts found</td></tr>
                    ) : (
                      children.map((child) => {
                        const key = `${child.type}_${child.id}`
                        return (
                          <tr key={key}>
                            <td>
                              <div className="custom-control custom-checkbox">
                                <input
                                  type="checkbox"
                                  name="locku"
                                  className="custom-control-input"
                                  value={child.id}
                                  id={`betlock-${key}`}
                                  checked={child.is_locked}
                                  onChange={() => handleToggle(child)}
                                />
                                <label className="custom-control-label" htmlFor={`betlock-${key}`}></label>
                              </div>
                            </td>
                            <td>{child.username || child.name || child.id}</td>
                          </tr>
                        )
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <span tabIndex="0"></span>
        </div>
      </div>
      <div className={backdropClass}></div>
    </div>,
    document.body,
  )
}

export default BetLockModal
