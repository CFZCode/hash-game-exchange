import { useEffect, useState } from 'react'
import { createPortal } from 'react-dom'

/* 18+ modal — opens from the 18+ badge in the login footer's gambling-icons
   row. Markup mirrors the reference BootstrapVue modal the user supplied
   (2026-09-21): id "eighteenPlus", `modal-18plus` on the .modal layer, a
   `modal-md` dialog, an EMPTY title (so no aria-labelledby, only
   aria-describedby) and the whole text inside one `.modal-18plus.p-5` block.

   Fade-in matches the player site's Plus18Modal: mount as `.modal.fade`, add
   `.show` on the next frame so Bootstrap's transitions actually play. */
const bvid = 'eighteenPlus'

// Reference body text, verbatim. The site name is genuinely blank in the
// reference DOM ("...to gamble on ." / " takes its age-verification..."), so
// it is left blank here too rather than filled in with a guess.
const PARAS = [
  'It is an offence for anyone under the age of 18 to open an account or to gamble on . takes its age-verification responsibilities very seriously. We carry out age-verification checks on all customers who use payment mechanisms which are available to under 18s and additionally perform random age-verification checks on customers using other forms of funding mechanisms. We may ask for information to verify your age and could restrict or suspend your account until your age is confirmed.',
  'PLEASE NOTE THAT ANYONE UNDER THE AGE OF 18 YEARS OLD FOUND TO BE USING THIS SITE WILL HAVE ANY WINNINGS FORFEITED AND MAY ALSO BE REPORTED TO THE POLICE.',
]

const FILTER_INTRO = ' advises and encourages its customers to prevent minors from accessing gambling websites.'
const FILTER_BODY = "Filtering solutions allow parents to regulate access to the internet, based on chosen criteria. Parents can use filters to prevent their children from accessing, amongst other things, gambling websites. Because our pages are 'labelled', filtering solutions being used to prevent gambling access are able to detect our site content, and block our pages. If you share your computer with friends or family who are under the legal age to register or bet with our site, please consider parental filtering solutions such as:"

function EighteenPlusModal({ show, onClose }) {
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    if (!show) { setVisible(false); return }
    let raf2
    const raf1 = requestAnimationFrame(() => {
      raf2 = requestAnimationFrame(() => setVisible(true))
    })
    return () => { cancelAnimationFrame(raf1); if (raf2) cancelAnimationFrame(raf2) }
  }, [show])

  // Esc closes, the way BootstrapVue's own modal does.
  useEffect(() => {
    if (!show) return
    const onKey = (e) => { if (e.key === 'Escape') onClose() }
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [show, onClose])

  if (!show) return null

  return createPortal(
    <div data-v-442ae592="" id={`${bvid}___BV_modal_outer_`} style={{ position: 'absolute', zIndex: 1040 }}>
      <div
        id={bvid}
        role="dialog"
        aria-describedby={`${bvid}___BV_modal_body_`}
        className={`modal fade${visible ? ' show' : ''} modal-18plus`}
        aria-modal="true"
        style={{ display: 'block' }}
        // Click outside the dialog closes it — BootstrapVue's own onClickOut
        // rule. It belongs on `.modal`, which covers the viewport above the
        // backdrop, so the backdrop is never the click target.
        onClick={(e) => { if (!e.target.closest('.modal-content')) onClose() }}
      >
        <div className="modal-dialog modal-md">
          <span tabIndex={0}></span>
          <div id={`${bvid}___BV_modal_content_`} tabIndex={-1} className="modal-content">
            <header id={`${bvid}___BV_modal_header_`} className="modal-header">
              <h5 id={`${bvid}___BV_modal_title_`} className="modal-title"></h5>
              <button type="button" aria-label="Close" className="close" onClick={onClose}>×</button>
            </header>
            <div id={`${bvid}___BV_modal_body_`} className="modal-body">
              <div data-v-442ae592="" className="modal-18plus p-5">
                <div>
                  {/* The reference's own modal image, front/img/18plus.png,
                      downloaded to admin/public/assets/18plus-modal.png rather
                      than hotlinked (repo rule). It is a DIFFERENT file from
                      the footer badge's icons/point/18plus.png — 50x50 vs
                      80x80 — so it keeps its own name. Nothing sizes it: the
                      admin stylesheets carry no `.modal-18plus` rule at all
                      (checked across the whole capture), so it renders at its
                      natural 50x50. */}
                  <img src="/admin/assets/18plus-modal.png" alt="18+" />
                </div>{' '}
                <p>
                  <b>Over 18s only</b> <br /> <br />{PARAS[0]}
                  <br /> <br />{PARAS[1]}
                  <br /> <br /> <b>Filtering systems</b> <br /> <br />{FILTER_INTRO}
                  <br /> <br />{FILTER_BODY}
                  <br /> <br />Net Nanny™{' '}
                  <a href="https://www.netnanny.com" target="_blank" rel="noreferrer">www.netnanny.com</a> <br /> <br />CyberPatrol{' '}
                  <a href="https://www.cyberpatrol.com" target="_blank" rel="noreferrer">www.cyberpatrol.com</a>
                </p>
              </div>
            </div>
            {/* the reference's empty footer slot */}
          </div>
          <span tabIndex={0}></span>
        </div>
      </div>
      <div
        id={`${bvid}___BV_modal_backdrop_`}
        className="modal-backdrop"
        style={{ transition: 'opacity 0.15s linear', opacity: visible ? '' : '0' }}
      ></div>
    </div>,
    document.body
  )
}

export default EighteenPlusModal
