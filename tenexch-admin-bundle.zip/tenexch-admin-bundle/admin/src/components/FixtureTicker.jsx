import { useState, useEffect, useRef } from 'react'
import { Link } from 'react-router-dom'

const SLIDE_H = 42 // slick-list height (one visible fixture row)

// Reference header slider (vue-slick, sliderSetting in the admin bundle):
// autoplay, autoplaySpeed 3000, speed 2000, vertical, default cssEase "ease".
// Slick fires its autoplay interval every 3000 ms from slide-start to
// slide-start; the slide itself takes 2000 ms, so ~1 s at rest in between.
// Measured on the reference recording (2026-09-19): motion 1.60s→3.55s
// (2 s, ease tail), next slide starts at 4.65s (3.05 s later).
const STEP_MS = 3000 // autoplaySpeed
const SLIDE_MS = 2000 // speed

// Vertical auto-rotating fixtures ticker — same DOM as the reference header's
// vue-slick slider: .slick-slider.slick-vertical > .slick-list > .slick-track
// with one pre-clone, the real slides, and a full set of post-clones. Slides
// bottom -> up. Items are the collector's fixtures ({ etid, gmid, name, stime },
// stime already formatted); the collector's event id IS our gmid, so each item
// opens our game-details page.
function FixtureTicker({ fixtures }) {
  const N = fixtures.length
  const [idx, setIdx] = useState(0) // 0..N (N = sitting on the first post-clone)
  const [anim, setAnim] = useState(false)
  const listRef = useRef(null)
  const [slideW, setSlideW] = useState(305)

  useEffect(() => {
    const measure = () => {
      if (listRef.current && listRef.current.offsetWidth) setSlideW(listRef.current.offsetWidth)
    }
    measure()
    window.addEventListener('resize', measure)
    return () => window.removeEventListener('resize', measure)
  }, [N])

  // a refreshed list can be shorter than where we are -- start over
  useEffect(() => {
    setAnim(false)
    setIdx(0)
  }, [N])

  // advance every 3 s (autoplaySpeed), 2 s slide (speed) like the reference
  useEffect(() => {
    if (N < 2) return
    const t = setInterval(() => {
      setAnim(true)
      setIdx((i) => i + 1)
    }, STEP_MS)
    return () => clearInterval(t)
  }, [N])

  // after the slide lands: drop the transition; wrap clone -> real first slide
  useEffect(() => {
    if (!anim) return
    const t = setTimeout(() => {
      setAnim(false)
      setIdx((i) => (i >= N ? 0 : i))
    }, SLIDE_MS + 50)
    return () => clearTimeout(t)
  }, [idx, anim, N])

  if (!N) return null

  const active = idx % N

  const renderSlide = (fixture, dataIndex, { cloned = false, activeSlide = false } = {}) => (
    <div
      key={`${dataIndex}`}
      data-v-e4caeaf8=""
      tabIndex="-1"
      data-index={dataIndex}
      aria-hidden={activeSlide ? 'false' : 'true'}
      className={`slick-slide${activeSlide ? ' slick-active slick-current' : ''}${cloned ? ' slick-cloned' : ''}`}
      style={cloned ? { width: `${slideW}px` } : { outline: 'none', width: `${slideW}px` }}
    >
      <div data-v-e4caeaf8="">
        <Link
          to={`/admin/game-details/${fixture.etid}/${fixture.gmid}`}
          className=""
          tabIndex="-1"
          data-v-e4caeaf8=""
          style={{ width: '100%', display: 'inline-block' }}
        >
          <div className="fixure-box">
            <div className="f-title">
              <i className={`d-icon mr-2 icon-${fixture.etid}`}></i>
              {`\n                    ${fixture.name}\n                  `}
            </div>{' '}
            <div>{fixture.stime}</div>
          </div>
        </Link>
      </div>
    </div>
  )

  return (
    <div data-v-3d1a4f76="" dir="ltr" className="slick-slider slick-initialized slick-vertical">
      <div data-v-3d1a4f76="" className="slick-list" style={{ height: `${SLIDE_H}px` }} ref={listRef}>
        <div
          data-v-e4caeaf8=""
          data-v-3d1a4f76=""
          className="slick-track"
          style={{
            opacity: 1,
            transform: `translate3d(0px, -${(idx + 1) * SLIDE_H}px, 0px)`,
            height: `${(N + 2) * SLIDE_H}px`,
            ...(anim ? { transition: `transform ${SLIDE_MS}ms ease` } : {}),
          }}
        >
          {renderSlide(fixtures[N - 1], -1, { cloned: true })}
          {fixtures.map((f, i) => renderSlide(f, i, { activeSlide: i === active }))}
          {fixtures.map((f, i) => renderSlide(f, N + i, { cloned: true }))}
        </div>
      </div>
    </div>
  )
}

export default FixtureTicker
