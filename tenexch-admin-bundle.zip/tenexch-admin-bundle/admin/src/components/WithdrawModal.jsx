import { createPortal } from 'react-dom'
import { useState, useEffect, useRef } from 'react'
import { useSelector } from 'react-redux'
import useModalEnter from '../hooks/useModalEnter'

// BootstrapVue-style incrementing component ids (same pattern as the
// frontend reference modals)
let bvidCounter = 1580

function WithdrawModal({ show, onHide, userData, onSubmit }) {
  const bvid = useRef(`__BVID__${++bvidCounter}`).current

  // BootstrapVue marks the body while a modal is open
  useEffect(() => {
    if (!show) return
    document.body.classList.add('modal-open')
    document.body.setAttribute('data-modal-open-count', '1')
    return () => {
      document.body.classList.remove('modal-open')
      document.body.removeAttribute('data-modal-open-count')
    }
  }, [show])

  // Inside loader — modal opens with an empty pane, content loads after 1s
  const [insideLoading, setInsideLoading] = useState(false)
  useEffect(() => {
    if (show) {
      setInsideLoading(true)
      const timer = setTimeout(() => setInsideLoading(false), 1000)
      return () => clearTimeout(timer)
    }
  }, [show])
  const currentUser = useSelector((state) => state.auth.user)
  const [amount, setAmount] = useState('')
  const [remark, setRemark] = useState('')
  const [transactionPassword, setTransactionPassword] = useState('')
  const [submitting, setSubmitting] = useState(false)
  // Reference: empty submit marks Amount/Remark/Transaction Code is-invalid
  // (red outline only, no message text)
  const [fieldErrors, setFieldErrors] = useState({})

  useEffect(() => {
    if (show) {
      setAmount('')
      setFieldErrors({})
      setRemark('')
      setTransactionPassword('')
      setSubmitting(false)
    }
  }, [show])

  const { modalClass, backdropClass, onBackdropClick } = useModalEnter(onHide, show)

  if (!show) return null

  const loginAmt = Number(currentUser?.inr_balance ?? currentUser?.AvailableBalance) || 0
  const targetAmt = Number(userData?.cash ?? userData?.inr_balance) || 0
  const pl = Number(userData?.settlement_points ?? userData?.profit_loss) || 0
  const num = Number(amount) || 0
  const loginNew = loginAmt + num
  const targetNew = targetAmt - num
  // settlement me lena (-) -> child ka pending utna neeche jayega
  const plNew = pl - num

  const loginName = currentUser?.username || 'user'
  const targetName = userData?.username || ''

  const handleSubmit = async (e) => {
    e.preventDefault()
    const errs = {
      amount: !num || num <= 0,
      remark: !remark,
      mpassword: !transactionPassword,
    }
    setFieldErrors(errs)
    if (errs.amount || errs.remark || errs.mpassword) return
    setSubmitting(true)
    try {
      await onSubmit({ amount: num, remark, transactionPassword })
    } finally {
      setSubmitting(false)
    }
  }

  return createPortal(
    <>
      <div id={`${bvid}___BV_modal_outer_`} style={{ position: 'absolute', zIndex: 1040 }}>
        <div id={bvid} role="dialog" aria-describedby={`${bvid}___BV_modal_body_`} className={modalClass} aria-modal="true" onClick={onBackdropClick} style={{ display: 'block' }}>
          <div className="modal-dialog modal-md modal-dialog-scrollable">
            <span tabIndex="0"></span>
            <div id={`${bvid}___BV_modal_content_`} tabIndex="-1" className="modal-content">
              <header id={`${bvid}___BV_modal_header_`} className="modal-header bg-danger">
                <h5 className="modal-title text-uppercase text-white">Withdraw</h5>
                <button type="button" data-dismiss="modal" className="close text-white" onClick={onHide}>×</button>
              </header>
              <div id={`${bvid}___BV_modal_body_`} className="modal-body">
                <div className="tabs">
                  <div className="">
                    <ul role="tablist" className="nav nav-tabs">
                      <li role="presentation" className="nav-item">
                        <a role="tab" aria-selected="true" href="#" target="_self" className="nav-link active tab-bg-success">Withdraw</a>
                      </li>
                    </ul>
                  </div>
                  <div className="tab-content text-muted">
                    <div role="tabpanel" aria-hidden="false" className="tab-pane active">
                      {!insideLoading && (
                      <form data-vv-scope="userWithdrawFrm" method="post" onSubmit={handleSubmit}>
                        <div className="form-group row">
                          <label className="col-form-label col-4">{loginName}</label>
                          <div className="col-8">
                            <div className="row">
                              <div className="col-6">
                                <input placeholder="Amount" type="text" readOnly name="userWithdrawFrmloginusramount" className="form-control txt-right" value={loginAmt.toLocaleString()} />
                              </div>
                              <div className="col-6">
                                <input placeholder="Amount" type="text" readOnly name="userWithdrawFrmloginusrNamount" className="form-control txt-right" value={loginNew.toLocaleString()} />
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="form-group row">
                          <label className="col-form-label col-4">{targetName}</label>
                          <div className="col-8">
                            <div className="row">
                              <div className="col-6">
                                <input placeholder="Amount" type="text" readOnly name="userWithdrawFrmusrnameamount" className="form-control txt-right" value={targetAmt.toLocaleString()} />
                              </div>
                              <div className="col-6">
                                <input placeholder="Amount" type="text" readOnly name="userWithdrawFrmusrnameNamount" className="form-control txt-right" value={targetNew.toLocaleString()} />
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="form-group row">
                          <label className="col-form-label col-4">Profit/Loss</label>
                          <div className="col-8">
                            <div className="row">
                              <div className="col-6">
                                <input placeholder="P/L" type="text" readOnly name="userDipositepl" className="form-control txt-right" value={pl.toLocaleString()} />
                              </div>
                              <div className="col-6">
                                <input placeholder="P/L" type="text" readOnly name="userDipositeplnew" className="form-control txt-right" value={plNew.toLocaleString()} />
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="form-group row">
                          <label className="col-form-label col-4">Amount</label>
                          <div className="col-8 form-group-feedback form-group-feedback-right">
                            <input
                              placeholder="Amount"
                              type="text"
                              name="userWithdrawFrmamount"
                              className={`form-control txt-right${fieldErrors.amount ? ' is-invalid' : ''}`}
                              value={amount}
                              onChange={(e) => { const v = e.target.value.replace(/[^0-9.]/g, ''); setAmount(v); setFieldErrors((p) => ({ ...p, amount: false })) }}
                              onBlur={(e) => setFieldErrors((p) => ({ ...p, amount: !e.target.value || Number(e.target.value) <= 0 }))}
                              aria-required="true"
                              aria-invalid={fieldErrors.amount ? 'true' : 'false'}
                            />
                          </div>
                        </div>
                        <div className="form-group row">
                          <label className="col-form-label col-4">Remark</label>
                          <div className="col-8 form-group-feedback form-group-feedback-right">
                            <textarea placeholder="Remark" name="userWithdrawFrmremark" className={`form-control${fieldErrors.remark ? ' is-invalid' : ''}`} aria-required="true" aria-invalid={fieldErrors.remark ? 'true' : 'false'} value={remark} onChange={(e) => { setRemark(e.target.value); setFieldErrors((p) => ({ ...p, remark: false })) }} onBlur={(e) => setFieldErrors((p) => ({ ...p, remark: !e.target.value }))} />
                          </div>
                        </div>
                        <div className="form-group row">
                          <label className="col-form-label col-4">Transaction Code</label>
                          <div className="col-8 form-group-feedback form-group-feedback-right">
                            <input
                              placeholder="Transaction Code"
                              name="userWithdrawFrmmpassword"
                              type="password"
                              className={`form-control${fieldErrors.mpassword ? ' is-invalid' : ''}`}
                              value={transactionPassword}
                              onChange={(e) => { setTransactionPassword(e.target.value); setFieldErrors((p) => ({ ...p, mpassword: false })) }}
                              onBlur={(e) => setFieldErrors((p) => ({ ...p, mpassword: !e.target.value }))}
                              aria-required="true"
                              aria-invalid={fieldErrors.mpassword ? 'true' : 'false'}
                            />
                          </div>
                        </div>
                        <div className="form-group row">
                          <div className="col-12 text-right">
                            <button type="submit" className="btn btn-danger" disabled={submitting}>
                              submit
                              <i className="fas fa-sign-in-alt ml-1"></i>
                            </button>
                          </div>
                        </div>
                      </form>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <span tabIndex="0"></span>
          </div>
        </div>
        <div id={`${bvid}___BV_modal_backdrop_`} className={backdropClass}></div>
      </div>
    </>,
    document.body
  )
}

export default WithdrawModal
