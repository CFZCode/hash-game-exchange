import { useState, useEffect } from 'react'
import { declareResult, voidBet } from '../services/api'
import useModalEnter from '../hooks/useModalEnter'

const MARKETS_FOR_FANCY = [
  '1st Innings 6 Overs Line', '2nd Innings 6 Overs Line', '3rd Innings 6 Overs Line',
  '1st Innings 50 Overs Line', '2nd Innings 50 Overs Line', '3rd Innings 50 Overs Line',
  '1st Innings 40 Overs Line', '2nd Innings 40 Overs Line', '3rd Innings 40 Overs Line',
  '1st Innings 30 Overs Line', '2nd Innings 30 Overs Line', '3rd Innings 30 Overs Line',
  '1st Innings 20 Overs Line', '2nd Innings 20 Overs Line', '3rd Innings 20 Overs Line',
  '1st Innings 10 Overs Line', '2nd Innings 10 Overs Line', '3rd Innings 10 Overs Line',
  'Over By Over', 'Ball By Ball', 'Normal', 'khado', 'meter', 'fancy1', 'oddeven',
]

// The list above names line markets by their OVER COUNT and so misses every
// team-prefixed one ("Sri Lanka 2nd Innings 95 Over Line") and every
// whole-innings one ("Sri Lanka 2nd Innings Runs Line"). Those fell through to
// the team-winner form, which declares a WINNER NAME on a market that settles
// on a RUN TOTAL. Match the "... Line" suffix by shape, the same way the server
// does (server/helper/lineMarket.js).
const isRunResultMarket = (marketType) =>
  MARKETS_FOR_FANCY.includes(marketType) || /\bline$/i.test(String(marketType || '').trim())

function FancySettlementModal({ show, onHide, mode, row, onSubmit }) {
  const matchTitle = row?.eventName || row?.matchTitle || ''
  const marketType = row?.marketType ?? ''
  const counts = row?.counts ?? 1
  const firstBet = row?.bets?.[0]
  const runners = firstBet?.runners || null
  const useTeamSelection = mode === 'declare' && !isRunResultMarket(marketType) && counts >= 2
  const isBinaryFancy = mode === 'declare' && ['fancy1', 'oddeven'].includes(marketType)
  const isThreeWay = counts >= 3
  const teamOne = row?.teamOne || firstBet?.teamOne || 'Team 1'
  const teamTwo = row?.teamTwo || firstBet?.teamTwo || 'Team 2'

  const [winnerId, setWinnerId] = useState('')
  const [selectedOutcome, setSelectedOutcome] = useState(null)
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    if (show) {
      setWinnerId('')
      setSelectedOutcome(null)
      setSubmitting(false)
    }
  }, [show, mode, row])

  const handleSubmit = async () => {
    if (mode === 'declare') {
      if (useTeamSelection && selectedOutcome == null) return
      if (!useTeamSelection && !winnerId.trim()) return
    }
    setSubmitting(true)
    try {
      let payload
      if (mode === 'void') {
        payload = {
          eventid: row.eventId,
          match_id: row.matchId,
          market_type: marketType,
          gametype: row.gameType || 'FAN',
        }
        if (isRunResultMarket(marketType)) {
          payload.selection_name = row.selectionName
        }
        await voidBet(payload)
        await onSubmit?.({ success: true })
      } else {
        const common = {
          eventid: row.eventId,
          match_id: row.matchId,
          match_title: row.matchTitle,
          game_type: row.gameType || 'FAN',
          market_type: marketType,
        }
        if (useTeamSelection) {
          payload = { ...common, winnerName: selectedOutcome }
        } else if (['fancy1', 'oddeven'].includes(marketType)) {
          payload = { ...common, winnerName: winnerId.trim(), fancyName: row.selectionName }
        } else if (isRunResultMarket(marketType)) {
          payload = { ...common, winnerId: winnerId.trim(), fancyName: row.selectionName }
        } else {
          payload = { ...common, winnerName: winnerId.trim() }
        }
        await declareResult(payload)
        await onSubmit?.({ success: true })
      }
      onHide?.()
    } catch (e) {
      console.error(e)
      alert(e.response?.data?.error || e.message)
    } finally {
      setSubmitting(false)
    }
  }

  const { modalClass, backdropClass, onBackdropClick } = useModalEnter(onHide, show)

  if (!show) return null

  const title = mode === 'void' ? 'Void Match' : 'Declare Result'
  const isDeclareReady = useTeamSelection ? selectedOutcome != null : winnerId.trim() !== ''
  const isSubmitDisabled = (mode === 'declare' && !isDeclareReady) || submitting

  const handleFormSubmit = (e) => {
    e.preventDefault()
    if (isSubmitDisabled) return
    handleSubmit()
  }

  const renderOutcomeBox = (label) => (
    <button
      key={label}
      type="button"
      onClick={() => setSelectedOutcome(label)}
      className={`btn ${selectedOutcome === label ? 'btn-primary' : 'btn-outline-secondary'} mx-1 my-1 px-3 py-2 font-weight-bold`}
      style={{ minWidth: 110 }}
    >
      {label}
    </button>
  )

  return (
    <div style={{ position: 'absolute', zIndex: 1040 }}>
      <div role="dialog" className={modalClass} aria-modal="true" onClick={onBackdropClick} style={{ display: 'block' }}>
        <div className="modal-dialog modal-md">
          <div tabIndex="-1" className="modal-content">
            <header className="modal-header">
              <h5 className="modal-title">{title}</h5>
              <button type="button" aria-label="Close" className="close" onClick={onHide}>×</button>
            </header>
            <form onSubmit={handleFormSubmit}>
              <div className="modal-body">
                <div className="mb-3 text-center font-weight-bold">
                  {marketType ? `${marketType} — ${matchTitle}` : matchTitle}
                </div>

                {mode === 'declare' && useTeamSelection && (
                  <>
                    <div className="d-flex flex-wrap justify-content-center align-items-center mb-2">
                      {runners && runners.length > 0
                        ? runners.map((r) => renderOutcomeBox(r))
                        : isThreeWay
                          ? [teamOne, 'Draw', teamTwo].map((r) => renderOutcomeBox(r))
                          : [teamOne, teamTwo].map((r, i) => (
                              <span key={r} className="d-inline-flex align-items-center">
                                {i > 0 && <span className="mx-2 text-muted">VS</span>}
                                {renderOutcomeBox(r)}
                              </span>
                            ))}
                    </div>
                    <div className="text-center mt-2">
                      {selectedOutcome != null ? (
                        <>Result: <strong>{selectedOutcome}</strong></>
                      ) : (
                        <span className="text-muted">
                          {runners?.length > 0 ? 'Select a runner' : isThreeWay ? 'Select Team 1, Draw, or Team 2' : 'Select winner'}
                        </span>
                      )}
                    </div>
                  </>
                )}

                {mode === 'declare' && !useTeamSelection && (
                  <div className="form-group">
                    <label className="font-weight-bold">{isBinaryFancy ? 'Winner Name' : 'Winner id'}</label>
                    {isBinaryFancy ? (
                      <div className="d-flex">
                        <button
                          type="button"
                          onClick={() => setWinnerId('Yes')}
                          className={`btn flex-fill mr-2 ${winnerId === 'Yes' ? 'btn-primary' : 'btn-outline-secondary'}`}
                        >
                          Yes
                        </button>
                        <button
                          type="button"
                          onClick={() => setWinnerId('No')}
                          className={`btn flex-fill ${winnerId === 'No' ? 'btn-primary' : 'btn-outline-secondary'}`}
                        >
                          No
                        </button>
                      </div>
                    ) : (
                      <input
                        type="text"
                        className="form-control"
                        value={winnerId}
                        onChange={(e) => setWinnerId(e.target.value)}
                        placeholder="Enter winner id"
                        autoFocus
                      />
                    )}
                  </div>
                )}

                {mode === 'void' && (
                  <div className="alert alert-warning">
                    Do you really want to cancel or refund the bets? All stakes will be refunded to the users. This action cannot be undone.
                  </div>
                )}
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={onHide}>Cancel</button>
                <button
                  type="submit"
                  className={`btn ${mode === 'void' ? 'btn-danger' : 'btn-primary'}`}
                  disabled={isSubmitDisabled}
                >
                  {submitting ? 'Submitting...' : mode === 'void' ? 'Confirm Void' : 'Submit'}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div className={backdropClass}></div>
    </div>
  )
}

export default FancySettlementModal
