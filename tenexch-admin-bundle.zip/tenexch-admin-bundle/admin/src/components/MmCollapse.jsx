import Collapse from './Collapse'

/* metisMenu's open/close slide for a sidebar submenu.
 *
 * The reference admin runs metisMenu, whose CSS we already ship
 * (`src/styles/app.css` → `.metismenu .mm-collapsing`):
 *
 *     .metismenu .mm-collapse, .metismenu .mm-collapse:not(.mm-show) { display:none }
 *     .metismenu .mm-collapse.mm-show                                { display:block }
 *     .metismenu .mm-collapsing { position:relative; height:0; overflow:hidden;
 *         transition-timing-function:ease; transition-duration:.35s;
 *         transition-property:height,visibility }
 *
 * metisMenu's collapse is Bootstrap's collapse with renamed classes, and its
 * JS walks the same closed → opening → open → preclose → closing phases. That
 * logic lives once, in components/Collapse.jsx (the rules modal's accordion
 * uses it with Bootstrap's own class names); this file only supplies the
 * `mm-*` names and the `<ul>` tag the sidebar markup expects. The comment
 * history of the phases — why `preclose` exists, why two frames — is there.
 */

const MM_CLASSES = { collapse: 'mm-collapse', collapsing: 'mm-collapsing', show: 'mm-show' }

export default function MmCollapse(props) {
  return <Collapse as="ul" classNames={MM_CLASSES} {...props} />
}
