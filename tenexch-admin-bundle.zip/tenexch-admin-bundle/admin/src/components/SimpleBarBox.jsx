import { useCallback, useEffect, useRef, useState } from 'react'

// SimpleBar DOM replica (styles already in app.css). Renders the exact
// wrapper/mask/offset/placeholder/track structure and keeps a live vertical
// scrollbar in sync with the real scrolling element (.simplebar-content-wrapper).
// className / autoHide: the reference sidebar is itself a SimpleBar root
// (`div.right-sidebar[data-simplebar]`) and its inner one carries
// data-simplebar-auto-hide="true".
export default function SimpleBarBox({ maxHeight = 470, className, autoHide = false, children }) {
  const scrollRef = useRef(null)
  const contentRef = useRef(null)
  const hideTimerRef = useRef(null)
  const [bar, setBar] = useState({ height: 0, translate: 0, visible: false, placeholder: 0 })
  const [thumbVisible, setThumbVisible] = useState(false)

  const sync = useCallback(() => {
    const el = scrollRef.current
    if (!el) return
    const { scrollTop, scrollHeight, clientHeight } = el
    const visible = scrollHeight > clientHeight + 1
    const height = visible ? Math.max(Math.round((clientHeight / scrollHeight) * clientHeight), 20) : 0
    const maxTranslate = clientHeight - height
    const translate = visible ? Math.round((scrollTop / (scrollHeight - clientHeight)) * maxTranslate) : 0
    setBar({ height, translate, visible, placeholder: scrollHeight })
  }, [])

  const handleScroll = useCallback(() => {
    sync()
    setThumbVisible(true)
    clearTimeout(hideTimerRef.current)
    hideTimerRef.current = setTimeout(() => setThumbVisible(false), 1000)
  }, [sync])

  useEffect(() => {
    sync()
    const ro = new ResizeObserver(sync)
    if (contentRef.current) ro.observe(contentRef.current)
    if (scrollRef.current) ro.observe(scrollRef.current)
    window.addEventListener('resize', sync)
    return () => {
      ro.disconnect()
      window.removeEventListener('resize', sync)
      clearTimeout(hideTimerRef.current)
    }
  }, [sync])

  return (
    <div
      data-simplebar-auto-hide={autoHide ? 'true' : undefined}
      data-simplebar="init"
      className={className}
      style={maxHeight == null ? undefined : { maxHeight: `${maxHeight}px` }}
    >
      <div className="simplebar-wrapper" style={{ margin: '0px' }}>
        <div className="simplebar-height-auto-observer-wrapper">
          <div className="simplebar-height-auto-observer"></div>
        </div>
        <div className="simplebar-mask">
          <div className="simplebar-offset" style={{ right: '0px', bottom: '0px' }}>
            <div
              ref={scrollRef}
              className="simplebar-content-wrapper"
              tabIndex="0"
              role="region"
              aria-label="scrollable content"
              style={{ height: 'auto', overflow: 'hidden scroll' }}
              onScroll={handleScroll}
            >
              <div ref={contentRef} className="simplebar-content" style={{ padding: '0px' }}>
                {children}
              </div>
            </div>
          </div>
        </div>
        <div className="simplebar-placeholder" style={{ width: 'auto', height: `${bar.placeholder}px` }}></div>
      </div>
      <div className="simplebar-track simplebar-horizontal" style={{ visibility: 'hidden' }}>
        <div className="simplebar-scrollbar" style={{ width: '0px', display: 'none' }}></div>
      </div>
      <div
        className="simplebar-track simplebar-vertical"
        style={{ visibility: bar.visible ? 'visible' : 'hidden' }}
        onMouseEnter={() => setThumbVisible(true)}
        onMouseLeave={() => setThumbVisible(false)}
      >
        <div
          className={`simplebar-scrollbar${thumbVisible ? ' simplebar-visible' : ''}`}
          style={{
            height: `${bar.height}px`,
            display: bar.visible ? 'block' : 'none',
            transform: `translate3d(0px, ${bar.translate}px, 0px)`,
          }}
        ></div>
      </div>
    </div>
  )
}
