// ─── Toast strings for the admin's own Secure Auth page ──────────────────────
// Single source of truth — used by pages/settings/SecureAuth.jsx. Add new
// secure-auth toasts here first rather than inlining them.

export const SECURE_AUTH_TOAST = {
  PASSWORD_REQUIRED: 'Please enter your login password',
  CONNECTION_ID_GENERATED: 'Connection ID Generated Successfully',
  CONNECTION_ID_FAILED: 'Failed to generate connection ID',
  // Fired by the link poll once the bot confirms, just before the logout.
  ENABLED: 'Secure Auth Allow.',
  // Clicking Enabled sends a disable code to Telegram. Reference wording,
  // "Sucessfully" typo included — same string the login OTP uses.
  DISABLE_CODE_SENT: 'Sucessfully Code Generate.',
  DISABLE_CODE_SEND_FAILED: 'Failed to send code',
  // Fired right before the session ends and the operator lands on /admin.
  DISABLE_SUCCESS: 'User removed',
  DISABLE_FAILED: 'Failed to disable secure auth',
  // Telegram disable only: the code lives 5 minutes, and taking longer than
  // that used to surface the server's own "OTP expired or not requested".
  // The operator is told the account was NOT removed instead (user,
  // 2026-09-20) — they just press Enabled again for a fresh code.
  DISABLE_EXPIRED: 'User Not Remove',
  // Correct code on the login 2FA screen, just before home (user, 2026-09-22).
  LOGIN_VERIFIED: 'Success',

  // ── Google Authenticator ───────────────────────────────────────────────────
  GOOGLE_PASSWORD_VERIFIED: 'Sucessfully Auth Allow.',
  GOOGLE_SETUP_FAILED: 'Invalid Password',
  GOOGLE_INVALID_CODE: 'Invalid authentication code',
  GOOGLE_SECRET_COPIED: 'copied',
  GOOGLE_SECRET_COPY_FAILED: 'Could not copy — please select the code manually',
}
