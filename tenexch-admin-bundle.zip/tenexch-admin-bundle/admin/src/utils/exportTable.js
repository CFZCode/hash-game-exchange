/**
 * Export a table as Excel or PDF — as a FILE DOWNLOAD on the same page.
 *
 * Admin twin of frontend/src/utils/exportTable.js (same theme, same shape,
 * kept in step by hand — the two apps share no package). Callers pass
 *   columns: [{ label, getValue(row, i), width?, align? }]
 *
 * Excel is the reference's HTML `.xls` — the format iPhone Safari renders
 * inline, full width (see exportToExcel for why not a real .xlsx).
 * PDF is jsPDF + autoTable, loaded on demand so a page doesn't carry it until
 * someone actually clicks. Neither opens a new tab/window.
 */

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  a.style.display = 'none'
  // Firefox ignores click() on an anchor that is not in the document.
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  // Revoke after the click has been handed to the download manager.
  setTimeout(() => URL.revokeObjectURL(url), 1000)
}

const escapeXml = (v) => String(v ?? '-')
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')

// A newline in a value becomes a line break inside the cell.
const cellHtml = (v) => escapeXml(v).replace(/\n/g, '<br>')

/**
 * Excel export = the reference's `.xls`: an HTML table served with the Excel
 * MIME type (what vue-json-excel emits). Chosen over a real .xlsx on purpose:
 * on iPhone Safari the download opens inline as a web page, full width and
 * readable — a genuine .xlsx goes through Quick Look, which shrinks the whole
 * sheet to fit the page and is unreadable on a phone. Excel/Numbers/Sheets
 * open this format fine (Excel shows a one-time "format doesn't match" note).
 *
 * Column options: `width` (characters, becomes a <col> width hint) and
 * `align: 'right'`. Header bold, no borders/gridlines, long text wraps.
 *
 * @param {object} [opts]
 * @param {boolean} [opts.fitContent] table takes its natural content width
 *   (compact, left) instead of stretching to the page.
 */
export function exportToExcel(rows, columns, filename = 'export', { fitContent = false } = {}) {
  if (!rows.length) return
  const colTags = columns.map((c) => `<col${c.width ? ` width="${Math.round(c.width * 7)}"` : ''}>`).join('')
  const head = columns.map((c) => `<th>${escapeXml(c.label)}</th>`).join('')
  const body = rows.map((row, i) =>
    `<tr>${columns.map((c) => `<td${c.align === 'right' ? ' class="r"' : ''}>${cellHtml(c.getValue(row, i))}</td>`).join('')}</tr>`
  ).join('')
  // NO viewport meta on purpose: with one, iPhone Safari lays the table out
  // in 390px (dates break mid-word, huge text); without, it uses the desktop
  // 980px canvas and scales it to fit — whole table in view, readable.
  const html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
<head><meta charset="UTF-8"><title>${escapeXml(filename)}</title>
<!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>${escapeXml(String(filename).slice(0, 31))}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]-->
<style>table{border-collapse:collapse;${fitContent ? '' : 'width:100%'}}th{font-weight:bold;text-align:center;padding:${fitContent ? '1px 3px' : '3px 5px'};vertical-align:middle}td{padding:${fitContent ? '1px 3px' : '3px 5px'};vertical-align:middle}td.r{text-align:right;white-space:nowrap}</style></head>
<body><table><colgroup>${colTags}</colgroup><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></body></html>`
  /* A real download, on every platform including iOS — an `<a download>` is
     what raises Safari's own «Do you want to download …?» sheet.

     Two details are load-bearing on a phone (learned on the player site):
     1. the mime must agree with the `.xls` name. Labelled `text/html` Safari
        renames the download "….xls.html" and hides View.
     2. no BOM. Tapping VIEW navigates to the blob url, and Safari sniffs the
        first bytes to decide page vs Quick Look. A BOM in front of `<html`
        sends it to Quick Look, which sees `.xls`, finds HTML and answers
        "This file cannot be previewed". `<meta charset>` already tells Excel
        the encoding. */
  downloadBlob(new Blob([html], { type: 'application/vnd.ms-excel;charset=utf-8;' }), `${filename}.xls`)
}

// PDF theme — matched to the reference's exported reports (colours read out
// of their PDF streams): header #2980BA / white bold, odd rows #F5F5F5, body
// text #505050, title 16pt regular black, table 10pt Helvetica, margins
// 55px top / 38px sides (jsPDF defaults) → 41pt / 28.5pt.
const PDF_THEME = {
  headerBg: [41, 128, 186],
  headerText: [255, 255, 255],
  stripeBg: [245, 245, 245],
  rowBg: [255, 255, 255],
  bodyText: [80, 80, 80],
  titleText: [0, 0, 0],
  marginX: 28.5,
  marginTop: 41,
}

/**
 * @param {object} [opts]
 * @param {'p'|'l'} [opts.orientation] page orientation — 'l' for wide tables
 *   (the reference's User List is landscape)
 * @param {'left'|'center'} [opts.titleAlign] where the title sits
 */
export async function exportToPDF(rows, columns, title = 'Report', { orientation = 'p', titleAlign = 'left' } = {}) {
  if (!rows.length) return
  const { default: jsPDF } = await import('jspdf')
  const { default: autoTable } = await import('jspdf-autotable')
  const doc = new jsPDF({ orientation, unit: 'pt', format: 'a4' })
  const pageWidth = doc.internal.pageSize.getWidth()

  // The title repeats on EVERY page, like the reference PDFs:
  //   · didDrawPage runs per page (the first included), so the title is painted
  //     each time. The font/size/colour are re-set inside because autoTable
  //     leaves the document on the table's own 10pt body style.
  //   · margin.top is what positions the table on every page AFTER the first
  //     (startY only governs page 1). Leaving it at marginTop would let page 2's
  //     table start above the title and overlap it.
  const titleBaseline = PDF_THEME.marginTop + 12
  const tableTop = titleBaseline + 14

  autoTable(doc, {
    startY: tableTop,
    margin: { left: PDF_THEME.marginX, right: PDF_THEME.marginX, top: tableTop },
    didDrawPage: () => {
      doc.setFont('helvetica', 'normal')
      doc.setFontSize(16)
      doc.setTextColor(...PDF_THEME.titleText)
      if (titleAlign === 'center') doc.text(title, pageWidth / 2, titleBaseline, { align: 'center' })
      else doc.text(title, PDF_THEME.marginX, titleBaseline)
    },
    head: [columns.map((c) => c.label)],
    body: rows.map((r, i) => columns.map((c) => String(c.getValue(r, i) ?? '-'))),
    theme: 'plain',
    styles: {
      font: 'helvetica',
      fontSize: 10,
      cellPadding: { top: 5.25, bottom: 5.25, left: 4.5, right: 4.5 },
      textColor: PDF_THEME.bodyText,
      lineWidth: 0,
      halign: 'left',
      overflow: 'linebreak',
    },
    headStyles: { fillColor: PDF_THEME.headerBg, textColor: PDF_THEME.headerText, fontStyle: 'bold' },
    // "striped": 1st, 3rd, 5th… rows grey, as in the reference PDFs. autoTable
    // v5 applies the ALTERNATE style to the 1st, 3rd… body rows — so the
    // alternate is the stripe and the base body is white.
    bodyStyles: { fillColor: PDF_THEME.rowBg },
    alternateRowStyles: { fillColor: PDF_THEME.stripeBg },
  })
  doc.save(`${title.replace(/\s+/g, '_')}.pdf`)
}
