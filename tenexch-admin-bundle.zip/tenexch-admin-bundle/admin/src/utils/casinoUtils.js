export const SP_PANA = {
  1: [128, 137, 146, 236, 245, 290, 380, 470, 489, 560, 579, 678],
  2: [129, 138, 147, 156, 237, 246, 345, 390, 480, 570, 589, 679],
  3: [120, 139, 148, 157, 238, 247, 256, 346, 490, 580, 670, 689],
  4: [130, 149, 158, 167, 239, 248, 257, 347, 356, 590, 680, 789],
  5: [140, 159, 168, 230, 249, 258, 267, 348, 357, 456, 690, 780],
  6: [123, 150, 169, 178, 240, 259, 268, 349, 358, 367, 457, 790],
  7: [124, 160, 179, 250, 269, 278, 340, 359, 368, 458, 467, 890],
  8: [125, 134, 170, 189, 260, 279, 350, 369, 378, 459, 468, 567],
  9: [126, 135, 180, 234, 270, 289, 360, 379, 450, 469, 478, 568],
  0: [127, 136, 145, 190, 235, 280, 370, 389, 460, 479, 569, 578],
};

export const DP_PANA = {
  1: [100, 119, 155, 227, 335, 344, 399, 588, 669],
  2: [110, 200, 228, 255, 336, 499, 660, 688, 778],
  3: [166, 229, 300, 337, 355, 445, 599, 779, 788],
  4: [112, 220, 266, 338, 400, 446, 455, 699, 770],
  5: [113, 122, 177, 339, 366, 447, 500, 799, 889],
  6: [114, 277, 330, 448, 466, 556, 600, 880, 899],
  7: [115, 133, 188, 223, 377, 449, 557, 566, 700],
  8: [116, 224, 233, 288, 440, 477, 558, 800, 990],
  9: [117, 144, 199, 225, 388, 559, 577, 667, 900],
  0: [118, 226, 244, 299, 334, 488, 550, 668, 677],
};

export const TP_PANA = [777, 444, 111, 888, 555, 222, 999, 666, 333, '000'];

export const MATKA_TABS = [
  { id: 'jodi', label: 'Jodi' },
  { id: 'single', label: 'Single' },
  { id: 'pana', label: 'Pana' },
  { id: 'sp', label: 'SP' },
  { id: 'dp', label: 'DP' },
  { id: 'trio', label: 'Trio' },
  { id: 'cycle', label: 'Cycle' },
  { id: 'motorsp', label: 'Motor SP' },
  { id: 'card56', label: '56 Charts' },
  { id: 'card64', label: '64 Charts' },
  { id: 'abr', label: 'ABR' },
  { id: 'commonsp', label: 'Common SP' },
  { id: 'commondp', label: 'Common DP' },
  { id: 'colordp', label: 'Color DP' },
];

export const DIGITS = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0];

export const CHIP_VALUES = [10, 20, 50, 100, 200, 500];
export const CHIP_COLOR = '#1f6179';
export const TOTAL_CHIP_COLOR = '#502b63';

// Casino bet stake / rate comes from Postgres DECIMAL as "100.00" / "1.40" - show it like the
// player site (formatStake): 100.00 -> 100, 150.50 -> 150.5, 1.40 -> 1.4, 2.00 -> 2.
export function formatStake(v) {
  if (v === null || v === undefined || v === '') return ''
  const n = Number(String(v).replace(/,/g, ''))
  return Number.isFinite(n) ? String(n) : String(v)
}

// My Bets amount: comma-grouped like the casino book figures (en-IN, same as
// fmtBook): 1000 -> "1,000", 150.5 -> "150.5". Non-numbers print as-is.
export function formatBetAmount(v) {
  if (v === null || v === undefined || v === '') return ''
  const n = Number(String(v).replace(/,/g, ''))
  return Number.isFinite(n) ? n.toLocaleString('en-IN', { maximumFractionDigits: 2 }) : String(v)
}

// Instant Teenpatti (teen3 / teen32 / teen33) and The Trap (trap): bets are stored under the feed nat
// ("Player A"), but the reference My Bets / View More show the main market as
// "Player A-Main". Display only - the stored nat must stay as-is for the book.
export function formatMainNation(nat) {
  const n = String(nat || '').trim()
  return n === 'Player A' || n === 'Player B' ? `${n}-Main` : n
}

// Note Number card-value bets are stored as "Card 2 A" (the shape settlement
// parses); shown as "Card 2 - Card A" — same as the player site. Display only.
export function formatNoteNumNation(nat) {
  const n = String(nat || '').trim()
  const m = n.match(/^Card\s+(\d+)\s+(A|10|[2-9])$/i)
  return m ? `Card ${m[1]} - Card ${m[2].toUpperCase()}` : n
}

// Teenpatti Joker 20-20: the reference names a bet "<name> - <market>" with the
// market in its own spelling (user screenshot 2026-10-14, admin result modal):
//   "Player B - Player", "Joker Black - redblack", "Joker Even - oddeven",
//   "Joker Club - card". Same map as the player site (frontend casinoUtils).
// Display only — settlement reads the stored bare name.
const JOKER20_MARKETS = {
  'player a': 'Player', 'player b': 'Player',
  'joker even': 'oddeven', 'joker odd': 'oddeven',
  'joker red': 'redblack', 'joker black': 'redblack',
  'joker spade': 'card', 'joker heart': 'card', 'joker diamond': 'card', 'joker club': 'card',
}
export function formatJoker20Nation(nat) {
  const s = String(nat ?? '').trim()
  const market = JOKER20_MARKETS[s.toLowerCase()]
  return market ? `${s} - ${market}` : nat
}

// Unlimited Joker 20-20 / One Day (joker120 / joker1): a bet with the player's own joker is
// stored with player_name "Player A - Joker 11" (settlement reads the number —
// resolveJoker1); `selection` / `nation` stay the bare "Player A". The reference
// prints the face card: 1 → A, 11 → J, 12 → Q, 13 → K (user 2026-10-14). Display only.
const UNLIMITED_JOKER_FACES = { 1: 'A', 11: 'J', 12: 'Q', 13: 'K' }
const UNLIMITED_JOKER_RE = /-\s*Joker\s+(\d{1,2})\s*$/i
// The picked joker (1–13) of a bet, 0 when none.
export function unlimitedJokerOf(bet) {
  const m = String(bet?.player_name || '').match(UNLIMITED_JOKER_RE)
  const n = m ? Number(m[1]) : 0
  return n >= 1 && n <= 13 ? n : 0
}
// Row pair of joker N on the admin table (BetTableJoker120): A = N, B = N×10;
// the 10th pair is the vendor's 101 / 100.
export function unlimitedJokerSids(n) {
  return { sidA: n === 10 ? 101 : n, sidB: n === 10 ? 100 : n * 10 }
}
export function formatUnlimitedJokerNation(nat, bet) {
  const name = bet?.player_name || nat
  return String(name ?? '').replace(UNLIMITED_JOKER_RE, (m, n) => `- Joker ${UNLIMITED_JOKER_FACES[n] || n}`)
}

// Teenpatti 2.0 (teen6) bet names the reference way (My Bets + result modals):
// "Player A" → "Player A-Main", "Player A Under 21" → "Player A Under 21-UO",
// "Card 5 Diamond" → "Card 5 - Diamond", "Card 1 Odd" → "Card 1 - Odd",
// "Card 1 A" → "Card 1 - Card A". Display only — settlement reads the stored name.
export function formatTeen6Nation(nat) {
  const n = String(nat || '').trim()
  if (/^Player [AB]$/i.test(n)) return `${n}-Main`
  if (/^Player [AB] (Under|Over) \d+$/i.test(n)) return `${n}-UO`
  const side = n.match(/^Card (\d) (Spade|Heart|Club|Diamond|Odd|Even)$/i)
  if (side) return `Card ${side[1]} - ${side[2]}`
  const face = n.match(/^Card (\d) (A|J|Q|K|\d{1,2})$/i)
  if (face) return `Card ${face[1]} - Card ${face[2].toUpperCase()}`
  return n
}

// Worli / Instant Worli bet names the reference way (bet slip, My Bets, result
// modals). The boards store a hyphenated key — "single-3", "single-line1",
// "pana-590", "sp-pana-590", "sp-all", "trio-all" — and settlement matches on
// that key, so this is display only: "single-3" → "3 Single",
// "single-line1" → "Line 1 Single", "single-odd" → "Odd Single",
// "pana-590" → "590 Pana", "sp-pana-590" → "590 SP", "sp-all" → "All SP".
const WORLI_SUFFIX = { line1: 'Line 1', line2: 'Line 2', odd: 'Odd', even: 'Even', all: 'ALL', cut: 'Cut' }
const WORLI_LABELS = {
  single: 'Single', pana: 'Pana', sp: 'SP', dp: 'DP', tp: 'TP', trio: 'Trio',
  cycle: 'Cycle', motorsp: 'Motor SP', c56: '56', c64: '64', abr: 'ABR',
  commonsp: 'Common SP', commondp: 'Common DP', colordp: 'color DP', // reference result modal: "1 color DP" (slip keeps "Color DP - 1")
}
// Matka order for a digit set: ascending, 0 last (4-2-5 → 245, 6-0-4 → 460) — twin of the frontend helper.
export function formatMatkaPana(digits) {
  const d = (digits || []).map(Number).sort((a, b) => a - b)
  return d.filter((x) => x !== 0).join('') + '0'.repeat(d.filter((x) => x === 0).length)
}
export function formatWorliNation(nat) {
  const m = String(nat || '').trim().match(/^([a-z0-9]+)-(.+)$/i)
  if (!m) return nat
  const label = WORLI_LABELS[m[1].toLowerCase()]
  if (!label) return nat
  const raw = m[2].replace(/^pana-/i, '')
  // Motor SP digits print in Matka order — ascending, 0 last ("0137" → "1370"), like the strip (user).
  if (label === 'Motor SP' && /^\d+$/.test(raw)) return `${formatMatkaPana(raw.split(''))} ${label}`
  const val = WORLI_SUFFIX[raw.toLowerCase()] || raw.charAt(0).toUpperCase() + raw.slice(1)
  // 56 / 64 charts: My Bets / result modals read "1 - Chart 56" on the reference
  // (the bet slip reads "56 - 1" — see formatWorliSlipName).
  // ALL cells print the word in caps everywhere (user): "ALL SP", "ALL - Chart 56".
  // 56 / 64 charts' ALL cell drops the dash (user): "ALL Chart 56" / "ALL Chart 64".
  if ((label === '56' || label === '64') && raw.toLowerCase() === 'all') return `${val} Chart ${label}`
  if (label === '56' || label === '64') return `${val} - Chart ${label}`
  // ABR (reference result modal): "A Only ABR" / "B Only ABR" / "R Only ABR", the ABR cell "ABR Only".
  if (label === 'ABR') {
    if (raw.toLowerCase() === 'all') return 'ABR Only'
    if (raw.toLowerCase() === 'cut') return 'ABR Cut Only'
    if (/^(a|b|r|ab|ar|br)$/i.test(raw)) return `${raw.toUpperCase()} Only ABR` // combos too: "AB Only ABR"
    return `${raw.toUpperCase()} ABR`
  }
  return `${val} ${label}`
}
const WORLI_SLIP_ALL_LABELS = { sp: 'SP', dp: 'DP', c56: '56', c64: '64' }
// Bet-slip name: same as formatWorliNation except the 56 / 64 charts, which the
// reference's slip prints label-first ("56 - 1", "64 - All").
export function formatWorliSlipName(nat) {
  // "ALL" cells print label-first with ALL in caps on the slip (user): "SP - ALL",
  // "DP - ALL". Exceptions (user): 56 / 64 charts "56CHART" / "64CHART", Color DP
  // "Color DP - 11", Trio "ALL Trio"; ABR's keeps the reference's "ABR - ABR". My Bets / result modals unchanged.
  if (/^colordp-all$/i.test(String(nat || '').trim())) return 'Color DP - 11' // user: Color DP's ALL cell slip
  const chartAll = String(nat || '').trim().match(/^c(56|64)-all$/i)
  if (chartAll) return `${chartAll[1]}CHART` // user: 56 / 64 chart's ALL cell slip → "56CHART" / "64CHART"
  const all = String(nat || '').trim().match(/^(sp|dp|c56|c64)-all$/i)
  if (all) return `${WORLI_SLIP_ALL_LABELS[all[1].toLowerCase()]} - ALL`
  const cm = String(nat || '').trim().match(/^common(sp|dp)-(\d)$/i)
  if (cm) return `Common ${cm[1].toUpperCase()} - ${cm[2]}` // reference slip: "Common SP - 1"
  const col = String(nat || '').trim().match(/^colordp-(.+)$/i)
  if (col) return `Color DP - ${WORLI_SUFFIX[col[1].toLowerCase()] || col[1]}` // reference slip: "Color DP - 1"
  const ab = String(nat || '').trim().match(/^abr-(.+)$/i)
  if (ab) return `ABR - ${ab[1].toLowerCase() === 'all' ? 'ABR' : ab[1].toLowerCase() === 'cut' ? 'ABR Cut' : ab[1].toUpperCase()}` // reference slip: "ABR - A", "ABR - ABR", "ABR - ABR Cut"
  const m = String(nat || '').trim().match(/^c(56|64)-(.+)$/i)
  if (!m) return formatWorliNation(nat)
  const raw = m[2]
  return `${m[1]} - ${raw.toLowerCase() === 'all' ? 'all' : raw}` // "56 - all" on the reference
}

// Per-game bet name for the shared round bets table (result modal + statement
// details). Only Note Number is formatted for now; everything else prints as stored.
// 20-20 Poker: the Winner row is stored as "Player A" / "Player B" (the feed
// names both sides "Winner"; settlement reads "Player X"). The reference shows
// "Winner A" / "Winner B". Hand bets ("One Pair B") already read right.
export function formatPoker20Nation(nat) {
  const m = String(nat || '').trim().match(/^Player ([AB])$/i)
  return m ? `Winner ${m[1].toUpperCase()}` : nat
}

// Teenpatti 1-day (teen): bets store the raw feed nat — "Player A" for both the
// main market (mtype "match") and Consecutive (feed etype fancy1 → mtype
// "fancy"), and "Card 2 Odd". The reference admin prints "Player A-Main",
// "Player B-CON" and "Card 2 - Odd" (user screenshots 2026-10-13). Display only.
export function formatTeenOneDayNation(nat, bet) {
  const n = String(nat || '').trim()
  if (n === 'Player A' || n === 'Player B') {
    const main = String(bet?.mtype || 'match').toLowerCase() === 'match'
    return `${n}-${main ? 'Main' : 'CON'}`
  }
  const m = n.match(/^(Card \d+) (Odd|Even)$/i)
  return m ? `${m[1]} - ${m[2]}` : n
}

// Unique Teenpatti: a bet stores the picked positions ("234"); the reference
// names it "Your card 234" (user 2026-10-14, admin; same as the player site).
// Display only — settlement reads the bare digits.
export function formatUniqueTeenNation(nat) {
  const s = String(nat ?? '').trim()
  return /^[1-6]{3}$/.test(s) ? `Your card ${s}` : nat
}

// Unique Roulette: the reference admin names a bet with its type, like the
// player site (frontend utils/casinoUtils.js formatUniqueRouletteNation):
//   inside  — "10 - Single", "1,2 - Split", "…,… - Street", "…,… - Corner"
//             (count of numbers covered);
//   dozens  — "1st 12 - Dozen";  even-money — "19 to 36 - Half", "Odd - Half",
//             "Red - Half", "Black - Half" (user screenshot 2026-10-14);
//   columns stay plain. Display only.
const ROULETTE_INSIDE_TYPES = { 1: 'Single', 2: 'Split', 3: 'Street', 4: 'Corner' }
const ROULETTE_OUTSIDE_TYPES = {
  '1st 12': 'Dozen', '2nd 12': 'Dozen', '3rd 12': 'Dozen',
  '1 to 18': 'Half', '19 to 36': 'Half', red: 'Half', black: 'Half', odd: 'Half', even: 'Half',
}
// Bets placed since 2026-10-14 carry the reference's rate-tier label in
// player_name ("5,6 - Street": priced at the round's Street rate) — that wins
// over the count rule, which stays for older bets.
export function storedRouletteName(bet) {
  const p = String(bet?.player_name ?? '').trim()
  return /^\d+(\s*,\s*\d+)* - (Single|Split|Street|Corner)$/.test(p) ? p : null
}

// `columns`: VIP / Beach / Roulette (roulette11/12/13) also suffix columns —
// "3rd Column - Column", as the player site (formatVipRouletteNation).
export function formatUniqueRouletteNation(nat, { columns = false } = {}) {
  const s = String(nat ?? '').trim()
  if (/^\d+(\s*,\s*\d+)*$/.test(s)) {
    const type = ROULETTE_INSIDE_TYPES[s.split(',').length]
    return type ? `${s} - ${type}` : nat
  }
  if (columns && /^(1st|2nd|3rd) column$/i.test(s)) return `${s} - Column`
  const outside = ROULETTE_OUTSIDE_TYPES[s] || ROULETTE_OUTSIDE_TYPES[s.toLowerCase()]
  return outside ? `${s} - ${outside}` : nat
}
export const VIP_ROULETTE_GAMES = new Set(['roulette11', 'roulette12', 'roulette13'])
// One entry point for every roulette table's bet name (admin My Bets / result modal).
export function formatRouletteBetName(gameType, nat, bet) {
  if (gameType === 'ourroullete') return storedRouletteName(bet) || formatUniqueRouletteNation(nat)
  if (VIP_ROULETTE_GAMES.has(gameType)) return formatUniqueRouletteNation(nat, { columns: true })
  return nat
}

export function formatBetNation(gameType, nat, bet) {
  if (gameType === 'ourroullete' || VIP_ROULETTE_GAMES.has(gameType)) return formatRouletteBetName(gameType, nat, bet)
  if (gameType === 'teen') return formatTeenOneDayNation(nat, bet)
  if (gameType === 'poker20') return formatPoker20Nation(nat)
  if (gameType === 'trap') return formatTrapNation(nat)
  if (gameType === 'notenum') return formatNoteNumNation(nat)
  if (gameType === 'trio') return formatTrioNation(nat, bet)
  if (gameType === 'patti2') return formatPatti2Nation(nat, bet)
  if (gameType === 'race20') return formatRace20Nation(nat, bet)
  if (gameType === 'teen6') return formatTeen6Nation(nat)
  if (gameType === 'joker20') return formatJoker20Nation(nat)
  if (gameType === 'teenunique') return formatUniqueTeenNation(nat)
  if (gameType === 'joker120' || gameType === 'joker1') return formatUnlimitedJokerNation(nat, bet)
  // Jack Top Open Teenpatti (teen42): reference prints "Player B-Main" /
  // "Player B Under 21-UO" (user screenshot 2026-10-13), same as the player side.
  if (gameType === 'teen42') return formatTeen6Nation(nat)
  if (gameType === 'worli2' || gameType === 'worli') return formatWorliNation(nat)
  // Andar Bahar 150: the reference prints the name with its deal position
  // ("Bahar A/136", user screenshot 2026-10-14), i.e. the stored player_name.
  if (gameType === 'ab4' && /\/\s*\d+\s*$/.test(String(bet?.player_name || ''))) return bet.player_name
  return nat
}

// Worli Matka / Instant Worli Line 1 / Line 2 / Odd / Even: the reference places ONE bet per
// number in the group (5 numbers) at the board rate 9 — stake 100 → 500 placed,
// a hit pays 800 on one number and loses 400 on the other four (net +400), a
// miss loses all 500. We store that as one bet: stake × 5 at 9 ÷ 5 = 1.8, so the
// generic book (stake) and settlement (stake × odds − stake) land on the same
// 500 / +400 / −500 with no server change. The rate cell shows the board's 9.
export const WORLI_LINE_UNITS = 5
export const isWorliLineSelection = (nat) => /^single-(line1|line2|odd|even)$/i.test(String(nat || '').trim())
// My Bets rate cell only: the reference prints 0 for a Cycle bet there (its result
// modal and statement print the stored 140). Everything else as formatWorliOdds.
export function formatWorliMyBetsOdds(bet, fallback) {
  const name = bet?.selection || bet?.player_name || bet?.nation || bet?.nat
  if (/^cycle-/i.test(String(name || '').trim())) return '0'
  return formatWorliOdds(bet, fallback)
}
export function formatWorliOdds(bet, fallback) {
  const name = bet?.selection || bet?.player_name || bet?.nation || bet?.nat
  const odds = Number(bet?.odds ?? bet?.rate)
  if (!isWorliLineSelection(name) || !(odds > 0)) return fallback
  return String(Math.round(odds * WORLI_LINE_UNITS * 100) / 100)
}

// Rate cell of the same table: Trio Session shows its line (21); everything
// else keeps the caller's formatted rate.
// Andar Bahar 2 (abj) 1st / 2nd Bet: an early end (1st Bet on card 1-2, 2nd Bet
// on card 3-4) pays 1 : 0.5 while the bet stays stored at 2. A settled row whose
// win is half the stake shows rate 1.5 like the reference (user); open, lost and
// full-pay rows show the stored odds. Display only.
export function formatAbjOdds(bet, fallback) {
  const name = String(bet?.player_name || bet?.selection || bet?.nation || bet?.nat || '').trim()
  if (!/^(1st|2nd) Bet\b/i.test(name)) return fallback
  const stake = Number(bet?.stake ?? bet?.amount)
  const win = Number(bet?.win)
  return stake > 0 && win > 0 && Math.abs(win - stake * 0.5) < 0.01 ? 1.5 : fallback
}

// Baccarat / Baccarat 2: the board quotes "to 1" rates (Player 1:1, Pair 11:1)
// but the player site places the bet at the DECIMAL b+1 so settlement pays
// stake × (odds-1) — Tie too since 2026-10-13 (older Tie bets were stored @8 and
// paid 7×, so they show 7). My Bets / round bets show the board rate like the
// reference: stored odds − 1. Display only.
export function formatBaccaratOdds(bet, fallback) {
  const odds = Number(bet?.odds ?? bet?.rate)
  if (!(odds > 1)) return fallback
  return Math.round((odds - 1) * 100) / 100
}

// Super Over 2 Fancy (session) bets are stored with their run line
// ("1 over run IND 13") and priced at the decimal rate/100 + 1 (1.84). Current
// Bets / result modals show the run LINE as the rate, like the reference (13),
// the same as the game page's My Bets. Display only — settlement reads the
// stored odds.
const SUPEROVER_SESSION_LINE_RE = /^\d+\s+over\s+run(?:\s+bhav)?\s+\S+\s+(\d+(?:\.\d+)?)$/i
export function formatSuperOverSessionOdds(bet, fallback) {
  const m = String(bet?.selection || bet?.nation || bet?.player_name || '').trim().match(SUPEROVER_SESSION_LINE_RE)
  return m ? m[1] : fallback
}

export function formatBetOdds(gameType, bet, fallback) {
  if (gameType === 'baccarat' || gameType === 'baccarat2') return formatBaccaratOdds(bet, fallback)
  if (gameType === 'superover2') return formatSuperOverSessionOdds(bet, fallback)
  // Sic Bo stores the decimal (net + 1); show the board's net rate (Triple 150, not 151).
  if (gameType === 'sicbo' || gameType === 'sicbo2') return formatBaccaratOdds(bet, fallback)
  if (gameType === 'abj') return formatAbjOdds(bet, fallback)
  if (gameType === 'teenmuf') return formatMuflisOdds(bet, fallback)
  if (gameType === 'patti2') return formatPatti2Odds(bet, fallback)
  if (gameType === 'race20') return formatRace20Odds(bet, fallback)
  if (gameType === 'worli2' || gameType === 'worli') return formatWorliOdds(bet, fallback)
  return gameType === 'trio' && isTrioSession(bet?.nation ?? bet?.selection) ? TRIO_SESSION_LINE : fallback
}

// Trio Session is a run line (rules: "session 21 Yes or No"). The bet is stored
// as "Session" priced at the decimal rate/100 + 1; My Bets shows it the
// reference way — nation "Session-<rate>" (back 80 / lay 100), odds = the line.
export const TRIO_SESSION_LINE = 21
const isTrioSession = (name) => /^session$/i.test(String(name || '').trim())
export function formatTrioNation(name, bet) {
  const odds = Number(bet?.odds ?? bet?.rate)
  if (!isTrioSession(name) || !(odds > 1)) return name
  return `Session-${Math.round((odds - 1) * 100)}`
}
export function formatTrioOdds(bet) {
  const name = bet?.selection || bet?.player_name || bet?.nation
  return isTrioSession(name) ? TRIO_SESSION_LINE : formatStake(bet?.odds ?? bet?.rate)
}

// Muflis Teenpatti Top 9: the feed quotes b = 2 and the bet is stored at 2, but
// it pays by the hand's highest card (×3 … ×30 profit, server helper/
// muflisSettle.js). A WON bet shows the rate of its multiplier (profit ÷ stake
// + 1: ×3 → 4 … ×30 → 31); open and lost bets show the stored odds (user).
const isMuflisTop9 = (name) => /^top\s*9\s*[ab]$/i.test(String(name || '').trim())
export function formatMuflisOdds(bet, fallback) {
  const name = bet?.player_name || bet?.selection || bet?.nation || bet?.nat
  if (!isMuflisTop9(name)) return fallback
  const stake = Number(bet?.stake ?? bet?.amount)
  const win = Number(bet?.win)
  return stake > 0 && win > 0 ? Math.round(win / stake) + 1 : fallback
}

// 2 Cards Teenpatti (patti2) bet names the reference way (My Bets + result
// modals): "Player A" → "Player A-Main", "Color Plus" → "Color Plus-Plus", "Mini Baccarat A" → "Mini Baccarat
// A-Baccarat", a Total bet (stored "Total A 14" = side + LINE, priced at the
// decimal bhav/100 + 1) → "Total A-95" with the line (14) as its rate.
// Display only — the stored selection is what settlement reads.
const PATTI2_TOTAL = /^Total ([AB]) (\d+)$/i
const patti2Sel = (name, bet) => String(bet?.selection || name || '').trim()
export function formatPatti2Nation(name, bet) {
  const sel = patti2Sel(name, bet)
  const t = sel.match(PATTI2_TOTAL)
  const odds = Number(bet?.odds ?? bet?.rate)
  if (t && odds > 1) return `Total ${t[1].toUpperCase()}-${Math.round((odds - 1) * 100)}`
  if (/^Player [AB]$/i.test(sel)) return `${sel}-Main`
  if (/^Mini Baccarat [AB]$/i.test(sel)) return `${sel}-Baccarat`
  if (/^Color Plus$/i.test(sel)) return 'Color Plus-Plus'
  return name
}
export function formatPatti2Odds(bet, fallback) {
  const t = patti2Sel(bet?.player_name || bet?.nation, bet).match(PATTI2_TOTAL)
  return t ? Number(t[2]) : fallback
}

// Race 20 Total points / Total cards: stored "Total cards 13" (LINE) at the
// decimal rate/100 + 1; the reference prints "Total cards / 90" (the rate) with
// the line (13) in the Rate column. Display only — settlement reads the stored
// selection. Plan: docs/plans/2026-10-10-race20-total-points-cards-open.md
const RACE20_TOTAL = /^Total (points|cards) (\d+)$/i
export function formatRace20Nation(name, bet) {
  const t = String(bet?.selection || name || '').trim().match(RACE20_TOTAL)
  const odds = Number(bet?.odds ?? bet?.rate)
  return t && odds > 1 ? `Total ${t[1].toLowerCase()} / ${Math.round((odds - 1) * 100)}` : name
}
export function formatRace20Odds(bet, fallback) {
  const t = String(bet?.selection || bet?.player_name || bet?.nation || '').trim().match(RACE20_TOTAL)
  return t ? Number(t[2]) : fallback
}

// The Trap: side bets are stored per card ("Card 1 JQK", "Card 3 Low"); the
// reference prints them "Card 1 - JQK" / "Card 3 - Low". Main bets keep
// formatMainNation ("Player A-Main"). Display only.
export function formatTrapNation(nat) {
  const m = String(nat || '').trim().match(/^Card\s+(\d+)\s+(Low|High|JQK)$/i)
  return m ? `Card ${m[1]} - ${m[2].toUpperCase() === 'JQK' ? 'JQK' : m[2][0].toUpperCase() + m[2].slice(1).toLowerCase()}` : formatMainNation(nat)
}
