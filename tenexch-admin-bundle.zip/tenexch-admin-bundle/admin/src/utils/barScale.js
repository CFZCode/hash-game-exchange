// Dashboard bar charts mix values that sit orders of magnitude apart — e.g.
// Credit pts 100,000,000 right next to Settlement pts −290. On a linear axis
// that small negative bar is less than a pixel wide, so it reads as "the graph
// is not showing minus values at all".
//
// So: when the spread is extreme we plot the bars on a signed-log scale. Only
// the bar *lengths* get compressed — axis labels, tooltips and the legend row
// under the chart keep the exact numbers. When the values are comparable
// (the normal case) nothing changes and the chart stays plain linear.

// max/min magnitude ratio above which linear bars stop being readable
const LOG_SPREAD_THRESHOLD = 100

const toLog = (v) => Math.sign(v) * Math.log10(1 + Math.abs(v))

// the real value a log tick stands for, rounded to a clean 10^n-style number
const fromLog = (v) => {
  if (!Number.isFinite(v) || Math.abs(v) < 0.5) return 0
  const raw = Math.sign(v) * 10 ** Math.abs(v)
  const mag = 10 ** Math.floor(Math.log10(Math.abs(raw)))
  return Math.round(raw / mag) * mag
}

const compactFmt = new Intl.NumberFormat('en-US', { notation: 'compact', maximumFractionDigits: 1 })
const axisLabel = (v) => (Math.abs(v) >= 100000 ? compactFmt.format(v) : Number(v).toLocaleString())
const exact = (v) => Number(v ?? 0).toLocaleString()

/**
 * Builds the value-axis pieces of an ApexCharts bar chart for `values`.
 * Returns { data, xaxis, tooltip } to be spread into the chart options.
 */
export const buildBarScale = (values) => {
  const magnitudes = values.map((v) => Math.abs(Number(v) || 0)).filter((v) => v > 0)
  const spread = magnitudes.length ? Math.max(...magnitudes) / Math.min(...magnitudes) : 0

  if (spread <= LOG_SPREAD_THRESHOLD) {
    return {
      data: values,
      // Reference value-axis format: "20000.00" / "-5000.00" (2 decimals, no
      // thousands separator) — ApexCharts default numeric look.
      xaxis: { labels: { formatter: (v) => Number(v).toFixed(2) } },
      tooltip: { y: { formatter: exact } },
    }
  }

  const logs = values.map(toLog)
  const min = Math.floor(Math.min(0, ...logs))
  const step = Math.ceil((Math.ceil(Math.max(0, ...logs)) - min) / 8) || 1
  const tickAmount = Math.ceil((Math.ceil(Math.max(0, ...logs)) - min) / step)

  return {
    data: logs.map((v) => Number(v.toFixed(4))),
    xaxis: {
      min,
      max: min + step * tickAmount,
      tickAmount,
      labels: { formatter: (v) => axisLabel(fromLog(Number(v))) },
      title: {
        text: 'Log scale — bar lengths are compressed, values are exact',
        style: { fontSize: '11px', fontWeight: 400, color: '#74788d' },
      },
    },
    // the plotted value is the log one, so read the real number off the index
    tooltip: { y: { formatter: (_v, opts) => exact(values[opts?.dataPointIndex]) } },
  }
}
