// Helpers for the collector-fed upcoming fixtures (header ticker + Fixtures page).

const pad = (n) => String(n).padStart(2, '0')

// The collector sends "MM/DD/YYYY hh:mm:ss AM/PM" with no timezone. Reformat the
// text as-is to "DD/MM/YYYY HH:mm:ss" -- going through Date would shift it by
// the viewer's timezone.
export const formatFixtureTime = (dt) => {
  const m = /^(\d{1,2})\/(\d{1,2})\/(\d{4})\s+(\d{1,2}):(\d{2}):(\d{2})\s*(AM|PM)?$/i.exec(String(dt || '').trim())
  if (!m) return String(dt || '')
  const [, mo, d, y, hh, mi, ss, ap] = m
  let h = Number(hh)
  if (ap) {
    const pm = ap.toUpperCase() === 'PM'
    if (pm && h < 12) h += 12
    if (!pm && h === 12) h = 0
  }
  return `${pad(d)}/${pad(mo)}/${y} ${pad(h)}:${mi}:${ss}`
}

export const SPORT_NAMES = {
  1: 'Football',
  2: 'Tennis',
  4: 'Cricket',
  8: 'Table Tennis',
  10: 'Horse Racing',
  11: 'E Games',
  15: 'Basketball',
  18: 'Volleyball',
  22: 'Badminton',
  59: 'Snooker',
  65: 'Greyhound Racing',
  68: 'Esoccer',
}

// Collector row -> the { etid, gmid, name, stime } shape FixtureTicker renders.
export const toTickerItem = (r) => ({
  etid: r.sportid,
  gmid: r.eid,
  name: r.ename,
  stime: formatFixtureTime(r.dt),
})
