// ─── Toast strings for the admin's Create Account page ───────────────────────
// Single source of truth — used by pages/users/InsertUser.jsx. Add new
// insert-user toasts here first rather than inlining them.

export const INSERT_USER_TOAST = {
  // Fired FIRST on Submit, before any other validation, when the username is
  // already taken by a user, staff or owner (server check-username → 202).
  // The text SHOWN is the server's (server/constants/messages.js
  // ADMIN.USERS.USERNAME_EXISTS); this copy is the fallback for a 202 that
  // carries no message. Reference wording and casing, verbatim (2026-09-16).
  USERNAME_EXISTS: 'User Name Already Exists',
  // Reference wording, "Sucessfully" typo included.
  INSERTED: 'User Sucessfully Inserted',
  // User Type not picked, or a value the API does not know. The text SHOWN is
  // the server's (server/constants/messages.js ADMIN.USERS.
  // SELECT_PROPER_USER_TYPE); this copy is only the fallback for a request
  // that never reached it. Reference wording and casing, verbatim — lowercase
  // "type" included (user, 2026-09-21).
  SELECT_PROPER_USER_TYPE: 'Select Proper User type',
}
