// Shared mapping between the market-analysis payload and the live odds feed.
//
// POST /admin/reports/market-analysis returns exposure grouped by game_type ->
// team_name, already sign-flipped to the book's point of view. The live feed
// identifies the same market by `mname` ("MATCH_ODDS", "Bookmaker 2") for
// match-odds style markets and by `gtype` ("Normal", "oddeven", "Over By Over")
// for fancies — game_type on an exposure row is whichever of the two was sent
// as market_type when the bet was placed. So we index on both and look up by
// either.

// "Bookmaker 2" / "BOOKMAKER_2" / "bookmaker-2" all collapse to "bookmaker2".
const norm = (v) => String(v ?? '').toLowerCase().replace(/[^a-z0-9]/g, '')

/**
 * Build a lookup index from one match entry of the market-analysis response.
 * Returns null when there is nothing to map.
 */
export const buildExposureIndex = (match) => {
  if (!match || !Array.isArray(match.markets)) return null

  const byMarket = new Map()

  for (const market of match.markets) {
    const key = norm(market.game_type || market.name)
    const runners = byMarket.get(key) || new Map()
    for (const row of market.rows || []) {
      const value = Number(row.value)
      if (!Number.isFinite(value)) continue
      // team_name can carry stray whitespace from the feed ("Yaroslav Makovka ")
      runners.set(norm(row.label), value)
    }
    byMarket.set(key, runners)
  }

  return { byMarket, markets: match.markets, match_id: match.match_id }
}

/**
 * Exposure for one runner. `marketKeys` are the live-feed identifiers to try in
 * order (mname first, then gtype). The match is deliberately strict — MATCH_ODDS
 * and Bookmaker carry identical runner names, so any name-only fallback would
 * paint one market's book onto the other. No market match means no exposure.
 */
export const lookupExposure = (index, marketKeys, runnerName) => {
  if (!index) return null
  const runner = norm(runnerName)
  if (!runner) return null

  for (const key of marketKeys) {
    if (!key) continue
    const runners = index.byMarket.get(norm(key))
    if (runners?.has(runner)) return runners.get(runner)
  }
  return null
}

/** Display form: negatives in brackets, matching the book summary convention. */
export const formatExposure = (value) => {
  const n = Number(value)
  if (!Number.isFinite(n) || n === 0) return '0'
  return n < 0 ? `(${Math.abs(n).toFixed(2)})` : n.toFixed(2)
}

export const exposureColor = (value) => {
  const n = Number(value)
  if (!Number.isFinite(n) || n === 0) return 'rgb(153, 153, 153)'
  return n < 0 ? '#ff4d4f' : '#28c76f'
}
