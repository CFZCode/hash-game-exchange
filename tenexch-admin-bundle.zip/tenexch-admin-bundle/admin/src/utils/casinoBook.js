// Admin book (exposure) resolver — open downline bets se har selection ki
// book CALCULATE hoti hai (koi exposure API nahi):
//   user BACK S (odds o, stake st) → admin book[S] -= (o-1)*st, baaki +st
//   user LAY  S (odds o, stake st) → admin book[S] += (o-1)*st, baaki -st
// Reference: Ronaldo back 100 @ 6.57 → admin table me Ronaldo -557 (book-red),
// baaki sab +100 (book-green).

// markets = array of markets, har market = us market ke selections
// [{ sid, nat }] (book sirf apne market ke andar distribute hoti hai).
// Book `sid:<sid>` keys se aati hai (same naam do markets me ho — e.g.
// goal2 "No Goal" — to leak na ho); unique naam ke liye plain nat key bhi
// set hoti hai (baaki games ke BetTables nat se lookup karte hain).
// Book value for display: keep up to 2 decimals so a decimal bet shows its
// real P/L (100 @1.15 x 1.5 = 22.5 stays 22.5), whole numbers stay whole
// (15.000000000000002 -> 15). Replaces the old Math.round, which dropped .5s.
export function roundBook(v) {
  return Math.round((Number(v) || 0) * 100) / 100
}

// Book TEXT for display: comma-grouped (en-IN, same as the player site's
// formatBook), decimals only when present: 1345 -> "1,345", -22.5 -> "-22.5".
// Keep roundBook for maths / colour checks; render through this.
export function fmtBook(v) {
  return roundBook(v).toLocaleString('en-IN', { maximumFractionDigits: 2 })
}

export function computeAdminBook(bets = [], markets = []) {
  const bySid = {}
  markets.forEach((sels) => sels.forEach(({ sid }) => {
    bySid[`sid:${sid}`] = 0
  }))
  // Single-line (YES/NO) markets: admin P/L if the line lands (hit) / doesn't
  // (miss); the cell shows the admin's worst case min(hit, miss) — reference
  // admin (Trio screen: Session back 112+800 @1.8 + lay 100+400 @2 → −229.6).
  // Back only → −(odds−1)×stake (as before); lay 100 @1.83 → −100 (was +83).
  const lineSides = {}

  bets.forEach((bet) => {
    const sel = bet.selection || bet.player_name || ''
    const odds = parseFloat(bet.odds) || 0
    const stake = parseFloat(bet.amount ?? bet.stake) || 0
    const isLay = String(bet.game_type || bet.type || '').toLowerCase() === 'lay'
    if (!sel || !odds || !stake) return

    // NOTE: bet me sirf naam hota hai — same naam do markets me ho to
    // pehla matching market use hota hai
    // A name quoted in more than one market (goal2 "No Goal": player AND
    // method) is placed by the bet's mtype, which goal2 bets carry as the feed
    // subtype they were clicked in. Unique names and older bets (mtype
    // "match") fall through to the first market with that name.
    const betMarket = String(bet.mtype || '').toLowerCase()
    const market =
      markets.find((m) => m.some((x) => x.nat === sel && x.subtype && x.subtype.toLowerCase() === betMarket)) ||
      markets.find((m) => m.some((x) => x.nat === sel))
    if (!market) return

    if (market.length === 1) {
      const key = `sid:${market[0].sid}`
      const s = lineSides[key] || (lineSides[key] = { hit: 0, miss: 0 })
      const win = (odds - 1) * stake
      if (isLay) { s.hit += win; s.miss -= stake } else { s.hit -= win; s.miss += stake }
      return
    }

    market.forEach(({ sid, nat }) => {
      const delta = nat === sel
        ? (isLay ? 1 : -1) * (odds - 1) * stake
        : (isLay ? -1 : 1) * stake
      bySid[`sid:${sid}`] += delta
    })
  })
  Object.entries(lineSides).forEach(([key, { hit, miss }]) => {
    bySid[key] = Math.min(hit, miss)
  })

  // plain nat keys sirf unique naam ke liye (cross-market leak na ho)
  const natCount = {}
  markets.forEach((sels) => sels.forEach(({ nat }) => {
    natCount[nat] = (natCount[nat] || 0) + 1
  }))
  const book = { ...bySid }
  markets.forEach((sels) => sels.forEach(({ sid, nat }) => {
    if (natCount[nat] === 1) book[nat] = bySid[`sid:${sid}`]
  }))

  return book
}

// Line bets stored WITH their line ("Total points 83" — race20 Total points /
// Total cards) match no feed name, so computeAdminBook skips them. Like the
// reference's player cell (each bet ADDED, no netting), the admin cell is minus
// the SUM OF STAKES of the line's bets, back or lay. Matches the reference admin
// (2026-10-10): Total cards No 100 @ 2.05 + Yes 100 @ 1.9 + Yes 12 @ 1.9 → −212;
// Total points No 100 + Yes 100 @ 2 → −200. Shown under the bare name.
// specs: [{ name: 'Total points', re: /^Total points (\d+)$/i }]
// Plan: docs/plans/2026-10-10-race20-total-points-cards-open.md
export function computeLineTotalsBook(bets = [], specs = []) {
  const book = {}
  specs.forEach(({ name, re }) => {
    let sum = 0
    let any = false
    bets.forEach((bet) => {
      const m = String(bet.selection || bet.player_name || '').trim().match(re)
      const odds = parseFloat(bet.odds) || 0
      const stake = parseFloat(bet.amount ?? bet.stake) || 0
      if (!m || !odds || !stake) return
      sum -= stake
      any = true
    })
    if (any) book[name] = roundBook(sum)
  })
  return book
}

// dum10 "Next Total N or More" is a two-way book on ONE runner: the feed sends
// back and lay for the same nat, so computeAdminBook (which spreads a bet over
// the other runners of its market) has nothing to spread onto and the nat is
// not unique — the main row stayed 0/0. Book it directly, admin side (the
// negative of the player's): back 100@1.15 -> lands -15, misses +100.
export function computeDum10MainBook(bets = []) {
  let lands = 0
  let misses = 0
  bets.forEach((bet) => {
    const sel = bet.selection || bet.player_name || ''
    if (!/^Next Total/i.test(sel)) return
    const odds = parseFloat(bet.odds) || 0
    const stake = parseFloat(bet.amount ?? bet.stake) || 0
    if (!odds || !stake) return
    const isLay = String(bet.game_type || bet.type || '').toLowerCase() === 'lay'
    if (isLay) { lands += (odds - 1) * stake; misses -= stake }
    else { lands -= (odds - 1) * stake; misses += stake }
  })
  return { lands, misses }
}

// Market groups game data (sub[]) ke etype se bante hain (reference-verified):
//   - etype match  -> same subtype ke selections EK market (book spread hota
//     hai — e.g. goal2 players, dolidana main: B back 100@1.97 -> B -97, A +100)
//   - etype fancy* -> har selection APNA single market (spread nahi — e.g.
//     dolidana Even back 100@1.95 -> Even -95, Odd 0)
// Andar Bahar 2 (abj) 1st Bet / 2nd Bet: the feed names both cells "1st Bet" /
// "2nd Bet" (A side sid 1-3, B side 4-6) but bets are stored "1st Bet SA" /
// "1st Bet SB", so computeAdminBook's name match never finds them (cells read
// 0). The reference admin shows each cell on its own — the admin's worst case
// on that exact selection (applyAdminLineBook): 1st Bet A 20 @2 + 1st Bet B
// 20 @2 → A −20 / B −20 (reference screen), not a two-way net of 0.
// Writes `book['sid:<sid>']` for those cells; returns `book`.
export function applyAbjBetBook(book, bets = [], sub = []) {
  const lines = applyAdminLineBook({}, bets)
  sub.forEach((item) => {
    const m = String(item.nat || '').trim().match(/^(1st|2nd) Bet$/i)
    if (!m) return
    const side = Number(item.sid) <= 3 ? 'SA' : 'SB'
    const key = Object.keys(lines).find((k) => k.trim().toLowerCase() === `${m[1]} bet ${side}`.toLowerCase())
    book[`sid:${item.sid}`] = key ? lines[key] : 0
  })
  return book
}

// 20-20 Poker: the feed names BOTH sides "Winner", "One Pair", … (sids 11-19 =
// Player A, 21-29 = Player B), but bets are stored with the side — "Player A" /
// "Player B" for Winner, "<Hand> A/B" otherwise (player BetTablePoker20 selFor;
// settlement reads these). Feed names matched no bet, so the admin book stayed
// empty. Markets here use the stored names: Winner = one two-runner market,
// each hand its own single-runner line. Row label by sid's last digit, same
// order as both BetTablePoker20s.
const POKER20_ROWS = ['Winner', 'One Pair', 'Two Pair', 'Three of a Kind', 'Straight', 'Flush', 'Full House', 'Four of a Kind', 'Straight Flush']
function poker20Markets(sub) {
  const winner = []
  const hands = []
  sub.forEach((s) => {
    const sid = Number(s.sid)
    const side = sid >= 11 && sid <= 19 ? 'A' : sid >= 21 && sid <= 29 ? 'B' : null
    if (!side) return
    const label = POKER20_ROWS[(sid % 10) - 1]
    if (label === 'Winner') winner.push({ sid: s.sid, nat: `Player ${side}` })
    else hands.push([{ sid: s.sid, nat: `${label} ${side}` }])
  })
  return [...(winner.length ? [winner] : []), ...hands]
}

export function getMarketsForGame(gameType, gameObj) {
  const sub = gameObj?.sub || []
  if (!sub.length) return []
  if (gameType === 'poker20') return poker20Markets(sub)

  const groups = {}
  const singles = []
  sub.forEach((s) => {
    if (!s.nat) return
    // subtype rides along so computeUserBook/computeAdminBook can match a
    // bet's mtype to its market when a name repeats (goal2 "No Goal").
    const entry = { sid: s.sid, nat: s.nat, subtype: s.subtype }
    if (String(s.etype || '').toLowerCase().startsWith('fancy')) {
      singles.push([entry])
    } else {
      const key = s.subtype || 'main'
      ;(groups[key] = groups[key] || []).push(entry)
    }
  })
  return [...Object.values(groups), ...singles]
}

// Andar Bahar 50 cards (ab3): has this bet already been decided by the cards
// dealt so far? Same rule as server/helper/ab50Settle.js — the first card of
// the bet's rank at/after its position ("Andar Q/7"). The worker settles it
// a few seconds later; the admin list drops it as soon as the card is out,
// like the player site (which refetches on the balance push).
export function isAb50BetDecided(bet, cardString) {
  const sel = String(bet?.selection || '').trim().match(/^(Andar|Bahar)\s+(10|[2-9]|[AJQK])$/i)
  if (!sel) return false
  const rank = sel[2].toUpperCase()
  const pm = String(bet?.player_name || '').match(/\/\s*(\d+)\s*$/)
  const start = pm ? Number(pm[1]) - 1 : 0
  const cards = String(cardString || '').split(',').map((c) => c.trim())
  for (let i = Math.max(0, start); i < cards.length; i += 1) {
    const c = cards[i]
    if (!c || c === '1' || c === '0') return false
    if ((c.toUpperCase().match(/^(10|[2-9]|[AJQK])/) || [])[1] === rank) return true
  }
  return false
}

// Same single-line rule as computeAdminBook, for selections that are NOT feed
// runners (Note Number card-value bets "Card 4 A"). The reference admin shows
// the ADMIN's worst case on a line —
// hit = admin P/L if the line lands, miss = if it doesn't, cell = min(hit, miss).
// Back 100 @1.78 → −78; lay 100 @1.83 → −100; Trio Session back 112+800 @1.8 +
// lay 100+400 @2 → −229.6 (reference screen). Keyed by the EXACT selection, so
// a Race to 17 "Big Card … - 2" figure goes once the live cell reads "- 3".
// Overwrites `book[sel]` for every selection that has bets; returns `book`.
export function applyAdminLineBook(book, bets = []) {
  const sides = {}
  bets.forEach((bet) => {
    const sel = bet.selection || bet.player_name || ''
    const odds = parseFloat(bet.odds) || 0
    const stake = parseFloat(bet.amount ?? bet.stake) || 0
    if (!sel || !odds || !stake) return
    const isLay = String(bet.game_type || bet.type || '').toLowerCase() === 'lay'
    const win = (odds - 1) * stake
    const s = sides[sel] || (sides[sel] = { hit: 0, miss: 0 })
    if (isLay) { s.hit += win; s.miss -= stake } else { s.hit -= win; s.miss += stake }
  })
  Object.entries(sides).forEach(([sel, { hit, miss }]) => {
    book[sel] = Math.min(hit, miss)
  })
  return book
}
