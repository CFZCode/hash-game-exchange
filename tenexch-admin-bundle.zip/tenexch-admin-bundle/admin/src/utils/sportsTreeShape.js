import { SERIES_ORDER_SEED } from '../data/seriesOrderSeed'

/* The sports tree, in the ORDER the reference shows it.
 *
 * Lifted out of components/Layout.jsx unchanged (2026-09-21) so the sidebar and
 * the General Lock page cannot disagree: General Lock used to build its own
 * `[...t1, ...t2]` and so had racing at the bottom, races with no country level,
 * and leagues in whatever order the feed shuffled them into that minute.
 *
 *   sports   t1's own order IS the reference's; t2 (Horse 10 + Greyhound 65) is
 *            spliced in after the 4th entry — Politics · Cricket · Football ·
 *            Tennis · Horse Racing · Greyhound Racing · Table Tennis · …
 *   leagues  the feed carries no order (it reshuffles every few minutes), and no
 *            rule recreates the reference's — see data/seriesOrderSeed.js. The
 *            order is HELD: seeded from the reference, then whatever was last
 *            shown; dropped names fall out, new ones slot in beside the sibling
 *            they arrived behind. `orderMemory` (a Map, owned by the caller) is
 *            that memory.
 *   races    grouped under their country, alphabetical by label inside it.
 *   matches  `sortMatches` (General Lock): alphabetical by name inside every
 *            league — read off the reference's General Lock DOM, where every one
 *            of the leagues sampled was name-sorted while only some were in gmid
 *            order. The sidebar does not pass it, so it is exactly as it was.
 */

// Identity is the competition NAME — that is what the seed lists, and cid is
// neither unique (tennis 7062963 covers both Tiburon spellings) nor always
// present (racing rows carry none). A name that genuinely repeats inside one
// sport keeps both rows: the second becomes `name#2`.
export function keysFor(list) {
  const seen = new Map()
  return list.map((ser) => {
    const name = String(ser?.name ?? '')
    const n = (seen.get(name) || 0) + 1
    seen.set(name, n)
    return n > 1 ? `${name}#${n}` : name
  })
}

// lower-cased, plain code-point order — the comparison the reference's lists
// were checked against
const byName = (a, b) => {
  const x = String(a?.name ?? '').toLowerCase()
  const y = String(b?.name ?? '').toLowerCase()
  return x < y ? -1 : x > y ? 1 : 0
}

// Racing keeps the label sort groupRaces already gave it.
const sortMatchesByName = (sport) => {
  if (String(sport.etid) === '10' || String(sport.etid) === '65') return sport
  return {
    ...sport,
    children: (sport.children || []).map((ser) => (
      Array.isArray(ser?.children) ? { ...ser, children: [...ser.children].sort(byName) } : ser
    )),
  }
}

const raceLabel = (etid, race) => {
  const venue = String(race.name || '').replace(/\s*\([A-Z]{2,3}\)\s*$/, '').trim()
  if (String(etid) !== '10') return venue
  const m = String(race.sdatetime || '').match(/^(\d{2})\/(\d{2})\/(\d{4})\s+(\d{2}):(\d{2}):(\d{2})\s*(AM|PM)?$/i)
  if (!m) return venue
  const [, mm, dd, yyyy, hhRaw, mi, ss, ap] = m
  let hh = Number(hhRaw)
  if (ap) {
    const up = ap.toUpperCase()
    if (up === 'PM' && hh !== 12) hh += 12
    if (up === 'AM' && hh === 12) hh = 0
  }
  return `${venue}-${String(hh).padStart(2, '0')}:${mi}:${ss} ${dd}/${mm}/${yyyy}`
}
const groupRaces = (sport) => {
  const races = sport.children || []
  if (!races.length || races[0]?.children) return sport   // already nested
  const byCode = new Map()
  races.forEach((race) => {
    const code = (String(race.name || '').match(/\(([A-Z]{2,3})\)\s*$/) || [, 'ALL'])[1]
    if (!byCode.has(code)) byCode.set(code, [])
    byCode.get(code).push({ ...race, name: raceLabel(sport.etid, race) })
  })
  /* Races are listed ALPHABETICALLY BY LABEL inside a country, not in
     feed order. Verified against a same-instant reference capture
     (Horse Racing, 61 races): all four groups came back
     `alphabetical == True`, while the feed is alphabetical for IE only
     — US, GB and FR arrive interleaved by off time. The giveaway is
     `Wolverhampton-00:00:00 16/09/2026` sitting ABOVE
     `Wolverhampton-20:58:00 15/09/2026`: that is a string sort, not a
     chronological one. Same shape for greyhounds, whose labels are bare
     venue names, so this groups each venue's races together. */
  return {
    ...sport,
    children: [...byCode].map(([code, list]) => ({
      name: code,
      cid: `race-${sport.etid}-${code}`,
      children: [...list].sort((a, b) => String(a.name).localeCompare(String(b.name), 'en')),
    })),
  }
}

export function shapeSportsTree(t1, t2, orderMemory, { sortMatches = false } = {}) {
  /* Racing rows arrive FLAT: a t2 sport's children are the races
     themselves ({name:"Sheffield (GB)", gmid, sdatetime}), not
     competitions. The render below walks sport -> series -> matches, so
     it counted `sum(series[i].children)` = 0 for both and drew Horse and
     Greyhound Racing as empty rows — 76 and 105 live races invisible.
     The reference groups them under the country pulled off the race name
     ("Greyhound Racing (117) > GB (117) > Central Park"), so that shape is
     rebuilt here and the render is left alone. Labels follow the
     reference too: a horse race carries its off time
     ("Finger Lakes-02:32:00 15/09/2026"), a greyhound race is the venue
     alone ("Central Park"). */
  const racing = t2.map(groupRaces)

  /* The upstream tree hands back the SAME set of competitions in a
     different order every few minutes — measured on the live feed:
       22:34  Europa · TESTING · CHILE Ascenso · JAMAICA · PANAMA · EFL Cup …
       22:42  Europa · LaLiga · CHILE Primera · AFC CL · ARG Regional · EFL Cup …
       22:46  Europa · TESTING · CHILE Ascenso · JAMAICA · GERMANY 3. Liga …
     Rendering that raw made the sidebar reshuffle on every poll. The
     reference does not jump: two captures 8 minutes apart differed by
     exactly two rows (one new competition inserted, one moved), i.e. it
     HOLDS the order it already has and slots newcomers in.
     Same thing here: keep the order this session already showed, drop
     what the feed dropped, and insert anything new next to the sibling
     it arrived after. Identity is `cid|name` — cid alone repeats (tennis
     7062963 covers both Tiburon spellings) and the racing rows built
     above carry `race-<etid>-<code>`; neither depends on array position
     or on a child gmid, both of which churn. */
  const holdSeriesOrder = (sport) => {
    const list = sport.children || []
    if (!list.length || !list[0]?.children) return sport   // leaf level
    const sportKey = String(sport.etid ?? sport.name)
    const keys = keysFor(list)
    const incoming = new Map()
    list.forEach((ser, i) => { if (!incoming.has(keys[i])) incoming.set(keys[i], ser) })
    // First pass for this sport starts from the seeded reference order;
    // after that it is whatever we last rendered. Either way only names
    // the feed still sends survive, so a stale seed entry drops out.
    const start = orderMemory.get(sportKey) || SERIES_ORDER_SEED[sportKey] || []
    const held = start.filter((k) => incoming.has(k))
    const placed = new Set(held)
    keys.forEach((key, i) => {
      if (placed.has(key)) return
      let at = 0
      for (let j = i - 1; j >= 0; j -= 1) {
        const idx = held.indexOf(keys[j])
        if (idx !== -1) { at = idx + 1; break }
      }
      held.splice(at, 0, key)
      placed.add(key)
    })
    orderMemory.set(sportKey, held)
    return { ...sport, children: held.map((k) => incoming.get(k)) }
  }

  /* Racing (t2 = Horse 10 + Greyhound 65) belongs right after Tennis, not
     at the bottom. The reference sidebar reads
     Politics · Cricket · Football · Tennis · Horse Racing · Greyhound
     Racing · Table Tennis · Badminton · … , i.e. t2 spliced in after t1's
     4th entry; we used to append it, so racing sat at #38-39. Checked
     name-for-name against the reference DOM (2026-09-15): appended order
     diverges at #5, spliced order matches all 39. Slice, not a hardcoded
     index list: t1's own order is already the reference's. */
  const next = [...t1.slice(0, 4), ...racing, ...t1.slice(4)].map(holdSeriesOrder)
  return sortMatches ? next.map(sortMatchesByName) : next
}

/* The /user/all/sports/events shape: ONE array of sports, already in the order
 * the server decided (sports as the feed lists them with racing after Tennis;
 * leagues by their soonest match). Nothing here reorders anything — the only
 * work left is the racing regroup, which is a rendering shape rather than an
 * order, and the optional match sort that General Lock asks for.
 *
 * This is what replaces holdSeriesOrder + SERIES_ORDER_SEED on the client: the
 * order now lives in one place, on the server, instead of a list of
 * competition names baked into each app (user, 2026-09-23).
 */
export function shapeSportsEvents(sports, { sortMatches = false } = {}) {
  const shaped = (sports || []).map(groupRaces)
  return sortMatches ? shaped.map(sortMatchesByName) : shaped
}
