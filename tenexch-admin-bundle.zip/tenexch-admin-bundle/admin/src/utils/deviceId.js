// Stable per-browser id, sent with every login and 2FA verification.
//
// The backend enforces ONE active session per account: each login writes a new
// `login_id` on the row, and authMiddleware rejects any token whose `sid` no
// longer matches ("Session expired. You have been logged out because your
// account was used on another device"). api.js turns any 401 into a full
// logout + hard redirect to /admin.
//
// ownerAuthService / staffAuthService derive that session id as
// `deviceId || crypto.randomUUID()`. Sending nothing meant a FRESH random id on
// every login, so signing in again from the same browser — a second tab, a
// re-login after a blip — invalidated the session already open here and bounced
// it to the login page. Sending a stable id makes the same browser reuse its
// session; a genuinely different device still overwrites it, which is the point
// of the check.
//
// localStorage, not sessionStorage: it has to survive a tab close, and it is
// deliberately NOT cleared on logout (api.js clears the tokens, not this) —
// the whole value is that it stays put for this browser.
const KEY = 'adminDeviceId'

// crypto.randomUUID() only exists in a secure context — over plain http on a
// LAN IP (which this panel is tested on) it is undefined, so keep a fallback.
const newId = () =>
  (typeof crypto !== 'undefined' && crypto.randomUUID)
    ? crypto.randomUUID()
    : `dev-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`

export function getDeviceId() {
  try {
    let id = localStorage.getItem(KEY)
    if (!id) {
      id = newId()
      localStorage.setItem(KEY, id)
    }
    return id
  } catch {
    // Private mode / storage blocked: fall back to no id, which is exactly the
    // behaviour before this existed — the server generates a random one.
    return undefined
  }
}

export default getDeviceId
