import { exportToExcel, exportToPDF } from './exportTable'

/**
 * "User List" export — one definition for BOTH Users.jsx and ActiveUsers.jsx,
 * so the file an operator downloads is the same whichever screen they are on.
 *
 * Column set and order are the reference's PDF (tenexch.com, 2026-09-18):
 *   User Name | Full Name | CR | pts | Client(P/L) | Exposure | Available pts
 *   | B st | U st | PName | Account type
 * with a TOTALS row FIRST — sums of the five money columns, every other cell
 * blank — then one row per user. Numbers are printed raw (`10059.36`,
 * `10000`), not locale-formatted like the on-screen table.
 *
 * Field sources are the wallet rows of GET /users/all-details
 * (server/controller/admin/UserController.js getUserAllDetails):
 *   credit, all_point, settlement_points (= all_point − credit, the reference's
 *   59.36 on 10059.36 / 10000), exposure, available_points, bet_locked,
 *   active/status, user_type. The fallbacks mirror what each screen already
 *   reads for its own cells.
 */

const num = (v) => Number(v) || 0
// Two decimals, no float noise on the sums (0.1 + 0.2 → 0.3), printed raw.
const money = (v) => Math.round(num(v) * 100) / 100

// Reference prints `true` for a user who CAN bet / IS active — the status,
// not the lock the on-screen switches show (switch ON = locked).
const bool = (v) => (v ? 'true' : 'false')

const rowValues = (a) => ({
  username: a.username ?? '',
  fullname: a.fullname ?? a.full_name ?? a.fullName ?? '',
  cr: money(a.credit ?? a.credit_ref ?? a.UpperLevelCreditReference ?? a.cash_received ?? 0),
  pts: money(a.all_point ?? a.inr_balance ?? a.cash ?? 0),
  pl: money(a.settlement_points ?? a.profit_loss ?? 0),
  // Exposure is stored negative (liability); the screens show the magnitude.
  exposure: Math.abs(money(a.exposure ?? a.total_exposure ?? 0)),
  available: money(a.available_points ?? a.inr_balance ?? a.AvailableBalance ?? a.cash ?? 0),
  betOk: !(a.bet_lock ?? a.bet_locked ?? false),
  userOk: !(a.user_lock ?? (a.active === false || a.status === 'InActive')),
  userType: a.user_type ?? a.role ?? '',
})

/**
 * @param {object[]} users     the rows on screen (already sorted/filtered)
 * @param {object}   opts
 * @param {Function} opts.formatAccountType  the screen's own label mapper
 */
export function buildUserListExport(users, { formatAccountType }) {
  const rows = users.map(rowValues)
  const total = rows.reduce((t, r) => ({
    cr: t.cr + r.cr, pts: t.pts + r.pts, pl: t.pl + r.pl,
    exposure: t.exposure + r.exposure, available: t.available + r.available,
  }), { cr: 0, pts: 0, pl: 0, exposure: 0, available: 0 })

  // Totals row first, as in the reference — its non-money cells stay blank.
  const exportRows = [
    { isTotal: true, cr: money(total.cr), pts: money(total.pts), pl: money(total.pl), exposure: money(total.exposure), available: money(total.available) },
    ...rows,
  ]

  const columns = [
    { label: 'User Name', getValue: (r) => (r.isTotal ? '' : r.username) },
    { label: 'Full Name', getValue: (r) => (r.isTotal ? '' : r.fullname) },
    { label: 'CR', getValue: (r) => r.cr },
    { label: 'pts', getValue: (r) => r.pts },
    { label: 'Client(P/L)', getValue: (r) => r.pl },
    { label: 'Exposure', getValue: (r) => r.exposure },
    { label: 'Available pts', getValue: (r) => r.available },
    { label: 'B st', getValue: (r) => (r.isTotal ? '' : bool(r.betOk)) },
    { label: 'U st', getValue: (r) => (r.isTotal ? '' : bool(r.userOk)) },
    // The reference prints the point-currency name here ("Point"), not the
    // partnership figure the screen shows in this column.
    { label: 'PName', getValue: (r) => (r.isTotal ? '' : 'Point') },
    { label: 'Account type', getValue: (r) => (r.isTotal ? '' : formatAccountType(r.userType)) },
  ]

  return { rows: exportRows, columns }
}

export function exportUserListExcel(users, opts) {
  const { rows, columns } = buildUserListExport(users, opts)
  exportToExcel(rows, columns, 'User List')
}

export function exportUserListPDF(users, opts) {
  const { rows, columns } = buildUserListExport(users, opts)
  // Eleven columns: landscape, title centred — the reference's page.
  return exportToPDF(rows, columns, 'User List', { orientation: 'l', titleAlign: 'center' })
}
