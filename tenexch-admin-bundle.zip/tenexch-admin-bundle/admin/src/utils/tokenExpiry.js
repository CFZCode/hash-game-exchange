// When does a JWT expire? Returns a ms-since-epoch timestamp from the token's
// `exp` claim, or null for no token / no exp / a malformed token. App.jsx arms
// the session auto-logout off this so the panel logs out at the same instant
// the server starts rejecting the token (authMiddleware's TokenExpiredError),
// instead of sitting on a dead session until the next API call 401s.
// Same decoder as the public frontend's utils/userIdentity.js.
export function tokenExpiresAt(token) {
  try {
    if (!token) return null
    const payload = token.split('.')[1]
    if (!payload) return null
    const json = decodeURIComponent(
      atob(payload.replace(/-/g, '+').replace(/_/g, '/'))
        .split('')
        .map((c) => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
        .join('')
    )
    const exp = JSON.parse(json)?.exp
    return typeof exp === 'number' ? exp * 1000 : null
  } catch {
    return null
  }
}
