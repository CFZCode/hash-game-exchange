// Reference-site behaviour, replicated on purpose: once the user has logged
// out, EVERY login attempt in that same page load is refused with a toast
// ("Please reload page and retry !"). They reload the page themselves — no
// auto reload (user's call, 2026-09-09) — and the next attempt goes through.
//
// The SAME account is blocked too (user, 2026-09-15). An earlier version let a
// same-account re-login straight through, which is why the rule appeared to
// work once — that first test happened to use a different account — and then
// looked broken on every later try with the same one.
//
// Armed only by the LOGOUT BUTTON (components/Layout.jsx), never by the
// automatic ones: the JWT timer in App.jsx and the 401 interceptor also
// dispatch logout(), and with a 30-minute token that would force a reload on
// every ordinary session expiry. This rule is about the user logging out and
// immediately logging back in.
//
// On the reference this is a server-side 402 off a stale session; here it is
// purely client-side — no request is sent.
//
// The flag lives in MODULE MEMORY, deliberately not in storage: a JS variable
// survives SPA navigation (logout → login page) but is wiped by a full page
// reload — which is exactly the "until the user reloads" rule. Storage would
// survive the reload and keep blocking.
let loggedOutThisPageLoad = false;

export const RELOAD_AND_RETRY_MSG = 'Please reload page and retry !';

export function rememberLogout() {
  loggedOutThisPageLoad = true;
}

// True once the user has logged out in THIS page load. Never consumed — only a
// full reload clears it.
export function needsReloadAfterLogout() {
  return loggedOutThisPageLoad;
}
