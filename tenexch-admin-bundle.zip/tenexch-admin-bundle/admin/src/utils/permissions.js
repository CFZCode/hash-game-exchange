/**
 * permissions.js — the CLIENT gate of the executive permission system.
 * ---------------------------------------------------------------------------
 * An "executive" is a restricted secondary login created from the Multi Login
 * page (/admin/createaccount). Owners and staff are never gated — every helper
 * here allows everything unless the active session is an executive.
 *
 * This gate is COSMETIC (menu hiding + route bouncing for a sane UX). The real
 * enforcement is requirePermission() on the server, which 403s API calls.
 *
 * THE KEY CONTRACT: the `key` strings below must stay byte-identical with
 *   1. the permission map sent by pages/MultiLogin.jsx (it imports PERMISSIONS)
 *   2. every requirePermission('<key>') call in server/routes/**
 *   3. the JSON stored in the executives.permissions column
 * Renaming a key without migrating stored rows silently revokes that feature
 * for every existing executive.
 */

/** Canonical permission registry: key (the contract) + label (what the UI shows). */
export const PERMISSIONS = [
  { key: 'dashboard', label: 'DashBoard' },
  { key: 'marketAnalysis', label: 'Market Analysis' },
  { key: 'userList', label: 'User List' },
  { key: 'insertUser', label: 'Insert User' },
  { key: 'bank', label: 'Bank' },
  { key: 'accountStatement', label: 'Account Statement' },
  { key: 'partyWinLoss', label: 'Party Win Loss' },
  { key: 'currentBets', label: 'Current Bets' },
  { key: 'userHistory', label: 'User History' },
  { key: 'generalLock', label: 'General Lock' },
  { key: 'casinoResult', label: 'Casino Result' },
  { key: 'liveCasinoResult', label: 'Live Casino Result' },
  { key: 'ourCasino', label: 'Our Casino' },
  { key: 'events', label: 'Events' },
  { key: 'marketSearchAnalysis', label: 'Market Search Analysis' },
  { key: 'loginUserCreation', label: 'Login User creation' },
  { key: 'withdraw', label: 'Withdraw' },
  { key: 'deposit', label: 'Deposit' },
  { key: 'creditReference', label: 'Credit Reference' },
  { key: 'userInfo', label: 'User Info' },
  { key: 'userPasswordChange', label: 'User Password Change' },
  { key: 'userLock', label: 'User Lock' },
  { key: 'betLock', label: 'Bet Lock' },
  { key: 'turnOver', label: 'TurnOver' },
  { key: 'couponReport', label: 'CouponReport' },
  { key: 'activeUser', label: 'active user' },
  { key: 'fraudReport', label: 'fraud report' },
  { key: 'currencyPermission', label: 'Currency Permission' },
  { key: 'agentAssign', label: 'Agent Assign' },
  { key: 'userRegisterReport', label: 'User Register Report' },
  { key: 'totalProfitLoss', label: 'Total Profitloss' },
  { key: 'userWinLoss', label: 'User Winloss' },
]

/** key → label lookup (used by the NoAccess page and the executives table). */
export const PERMISSION_LABELS = Object.fromEntries(
  PERMISSIONS.map((p) => [p.key, p.label])
)

/**
 * Keys only an owner / top-tier staff may grant. Intentionally EMPTY — tenexch
 * has no tier distinction between privilege keys yet. To make a key owner-only,
 * add it here AND to ADMIN_TIER in server/controller/executive/executiveController.js.
 */
export const ADMIN_TIER_PERMISSIONS = []

export const isExecutive = () => localStorage.getItem('activeRole') === 'executive'

/**
 * The owner login itself — NOT staff (hierarchy accounts) and NOT executives.
 * Owner-only surfaces (settlement, carousel, game priority) key off this, so
 * no other hierarchy level ever sees or reaches them.
 */
export const isOwner = () => localStorage.getItem('activeRole') === 'owner'

/**
 * Path prefixes only the owner session may visit. Menu items for these are
 * hidden via isOwner() in Layout.jsx; ProtectedRoute bounces direct URLs; the
 * server 403s the APIs via requireOwner — same three-layer pattern as the
 * executive permission system.
 */
export const OWNER_ONLY_ROUTES = [
  '/admin/system-tracker',
  '/admin/carousel',
  '/admin/fixtures',
  '/admin/game-priority',
  '/admin/settlement',
  '/admin/casino-manage',
  '/admin/settings/buffer-time',
  '/admin/settings/commission',
  '/admin/settings/max-odds',
  '/admin/settings/auto-void',
  '/admin/settings/virtual-limits',
  '/admin/settings/bet-limits',
  '/admin/settings/third-party-limit',
]

export const isOwnerOnlyPath = (pathname) =>
  OWNER_ONLY_ROUTES.some((prefix) => pathname === prefix || pathname.startsWith(prefix + '/'))

export const getStoredPermissions = () => {
  try {
    return JSON.parse(localStorage.getItem('executivePermissions') || '{}')
  } catch {
    return {}
  }
}

/**
 * can('key') / can(['a','b']) — true when the current session may use the
 * feature. Non-executives always pass. The array form is "any-of" (used for
 * submenu parents that show when any child is granted).
 */
export const can = (key) => {
  if (!key) return true
  if (!isExecutive()) return true
  const perms = getStoredPermissions()
  return Array.isArray(key) ? key.some((k) => !!perms[k]) : !!perms[key]
}

export const isOwnerOrSuperAdmin = () => {
  if (localStorage.getItem('activeRole') === 'owner') return true
  try {
    const user = JSON.parse(localStorage.getItem('adminUser') || 'null')
    return ['OWNER', 'COMPANY', 'SUPERADMIN'].includes((user?.role || '').toUpperCase())
  } catch {
    return false
  }
}

/**
 * Route → permission map, ORDERED prefix list (first match wins), so specific
 * paths must precede their parents (/admin/users/insertuser before /admin/users).
 * A path with no entry is unguarded for executives — the owner-workflow pages
 * (settlement, carousel, game priority) are instead guarded by the stricter
 * OWNER_ONLY_ROUTES list above (owner session only, no staff/executives).
 */
export const ROUTE_PERMISSIONS = [
  ['/admin/users/insertuser', 'insertUser'],
  ['/admin/users', 'userList'],
  ['/admin/activeusers', 'activeUser'],
  ['/admin/home', 'dashboard'],
  ['/admin/market-analysis', 'marketAnalysis'],
  ['/admin/createaccount', 'loginUserCreation'],
  ['/admin/assign-agent', 'agentAssign'],
  ['/admin/reports/bank', 'bank'],
  ['/admin/reports/accountstatement', 'accountStatement'],
  ['/admin/reports/profitloss', 'partyWinLoss'],
  ['/admin/reports/currentbets', 'currentBets'],
  ['/admin/reports/userhistory', 'userHistory'],
  ['/admin/settings/userlock', 'generalLock'],
  ['/admin/reports/casinoresult', 'casinoResult'],
  ['/admin/reports/livecasinoreport', 'liveCasinoResult'],
  ['/admin/reports/turnover', 'turnOver'],
  ['/admin/reports/fraud', 'fraudReport'],
  ['/admin/reports/userregisterdetail', 'userRegisterReport'],
  ['/admin/reports/totalprofitloss', 'totalProfitLoss'],
  ['/admin/reports/userwinloss', 'userWinLoss'],
  ['/admin/casino', 'ourCasino'],
  ['/admin/vcasino', 'ourCasino'],
  ['/admin/pcasino', 'ourCasino'],
  ['/admin/tcasino', 'ourCasino'],
  ['/admin/game-details', 'events'],
]

/** The permission key guarding a pathname, or null when the path is unguarded. */
export const permissionForPath = (pathname) => {
  for (const [prefix, key] of ROUTE_PERMISSIONS) {
    if (pathname === prefix || pathname.startsWith(prefix + '/')) return key
  }
  return null
}

/**
 * Landing priority: after an executive logs in (or is bounced off a denied
 * route) send them to the first page they hold a key for.
 */
export const LANDING_ORDER = [
  ['dashboard', '/admin/home'],
  ['marketAnalysis', '/admin/market-analysis'],
  ['userList', '/admin/users'],
  ['activeUser', '/admin/activeusers'],
  ['insertUser', '/admin/users/insertuser'],
  ['agentAssign', '/admin/assign-agent'],
  ['bank', '/admin/reports/bank'],
  ['accountStatement', '/admin/reports/accountstatement'],
  ['currentBets', '/admin/reports/currentbets'],
  ['partyWinLoss', '/admin/reports/profitloss'],
  ['userHistory', '/admin/reports/userhistory'],
  ['generalLock', '/admin/settings/userlock'],
  ['casinoResult', '/admin/reports/casinoresult'],
  ['liveCasinoResult', '/admin/reports/livecasinoreport'],
  ['turnOver', '/admin/reports/turnover'],
  ['fraudReport', '/admin/reports/fraud'],
  ['userRegisterReport', '/admin/reports/userregisterdetail'],
  ['totalProfitLoss', '/admin/reports/totalprofitloss'],
  ['userWinLoss', '/admin/reports/userwinloss'],
  ['ourCasino', '/admin/casino/list'],
  ['loginUserCreation', '/admin/createaccount'],
]

/** First route the current executive may land on, else the no-access page. */
export const firstAllowedRoute = () => {
  if (!isExecutive()) return '/admin/home'
  const perms = getStoredPermissions()
  for (const [key, path] of LANDING_ORDER) {
    if (perms[key]) return path
  }
  return '/admin/no-access'
}
