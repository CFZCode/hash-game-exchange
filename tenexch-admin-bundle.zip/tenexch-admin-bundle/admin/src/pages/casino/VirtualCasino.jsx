import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import api from '../../services/api'

// /admin/vcasino/list — reference DOM (tenexch.com/admin/vcasino/list,
// 2026-09-19): PageHeader "Virtual Casino" (Home › Virtual Casino), then ONE
// .card holding .casino-banners > .casino-banner-item > router-link >
// img.img-fluid — no category tabs, no labels; empty list → "No Casino Found".
// The reference fills it from its `vcasino/list` API: exactly these NINE
// tiles, in this order (art casino_icons/vc/<gtype>.jpg).
//
// Here the rows come from the Casino Manage catalog — the same
// /user/casino-manage/games the player site's "Our Virtual" tab and the admin
// Our Casino list read — filtered to category `virtual` + enabled, then
// pinned to the reference's nine and its order, so the owner's switches still
// apply. Catalog rows outside the nine (vdt20, vbaccarat, vrace17, vtrap —
// no upstream feed) are not shown, same as the reference. Tile art is the
// bundled /assets/casino/games/<game_type>.jpg, never hotlinked. A tile links
// to /admin + the catalog route (/vcasino/teen → /admin/vcasino/teen).
const CATALOG_URL = '/user/casino-manage/games'
const ART_BASE = '/admin/assets/casino/games'
const VCASINO_ORDER = ['vdtl20', 'vaaa', 'vteenmuf', 'vdt6', 'vteen', 'vlucky7', 'vbtable', 'vteen20', 'vtrio']

function VirtualCasino() {
  const [games, setGames] = useState([])

  useEffect(() => {
    const controller = new AbortController()
    api.get(CATALOG_URL, { signal: controller.signal })
      .then((res) => {
        const rows = res.data?.payload?.games || res.data?.data || []
        setGames(
          (Array.isArray(rows) ? rows : [])
            .filter((g) => g.category === 'virtual' && g.enabled !== false && VCASINO_ORDER.includes(g.game_type))
            .sort((a, b) => VCASINO_ORDER.indexOf(a.game_type) - VCASINO_ORDER.indexOf(b.game_type))
        )
      })
      .catch(() => setGames([]))
    return () => controller.abort()
  }, [])

  return (
    <div data-v-5a10e370="">
      <div className="row">
        <div className="col-12">
          <div className="page-title-box d-flex align-items-center justify-content-between">
            <h4 className="mb-0 font-size-18">Virtual Casino</h4>
            {' '}
            <div className="page-title-right">
              <ol className="breadcrumb m-0">
                <li className="breadcrumb-item">
                  <Link to="/admin/home" className="" target="_self">Home</Link>
                </li>
                <li className="breadcrumb-item active">
                  <span aria-current="location">Virtual Casino</span>
                </li>
              </ol>
            </div>
          </div>
        </div>
      </div>
      {' '}
      <div className="card">
        {games.length > 0 ? (
          <div className="casino-banners">
            {games.map((g) => (
              <div className="casino-banner-item" key={g.game_type}>
                <Link to={`/admin${g.route || `/vcasino/${g.game_type.replace(/^v/, '')}`}`}>
                  <img className="img-fluid" src={`${ART_BASE}/${g.game_type}.jpg`} alt={g.game_name || g.game_type} />
                </Link>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center mt-5 mb-5 font-20">
            {'\n            No Casino Found\n        '}
          </div>
        )}
      </div>
    </div>
  )
}

export default VirtualCasino
