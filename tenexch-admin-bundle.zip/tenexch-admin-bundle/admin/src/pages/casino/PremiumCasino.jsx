import { useState, useMemo } from 'react'
import { Link } from 'react-router-dom'
import CasinoTabsList from '../../components/casino/CasinoTabsList'

const TABS = [
  'All Casino',
  'Teenpatti',
  'Baccarat',
  'Dragon Tiger',
  'Lucky 7',
  '32 Cards',
]

const PREMIUM_ITEMS = [
  { id: 'pteen', img: 'pteen.jpg', cat: 'Teenpatti' },
  { id: 'pteen20', img: 'pteen20.jpg', cat: 'Teenpatti' },
  { id: 'pbaccarat', img: 'pbaccarat.jpg', cat: 'Baccarat' },
  { id: 'pdt20', img: 'pdt20.jpg', cat: 'Dragon Tiger' },
  { id: 'pdt6', img: 'pdt6.jpg', cat: 'Dragon Tiger' },
  { id: 'pcard32', img: 'pcard32.jpg', cat: '32 Cards' },
  { id: 'plucky7', img: 'plucky7.jpg', cat: 'Lucky 7' },
]

function PremiumCasino() {
  const [activeTab, setActiveTab] = useState('All Casino')

  const filteredItems = useMemo(() => {
    if (activeTab === 'All Casino') return PREMIUM_ITEMS
    return PREMIUM_ITEMS.filter((item) => item.cat === activeTab)
  }, [activeTab])

  return (
    <div>
        {/* Breadcrumb */}
        <div className="row">
          <div className="col-12">
            <div className="page-title-box d-flex align-items-center justify-content-between">
              <h4 className="mb-0 font-size-18">Premium Casino</h4>
              <div className="page-title-right">
                <ol className="breadcrumb m-0">
                  <li className="breadcrumb-item">
                    <Link to="/admin/home">Home</Link>
                  </li>
                  <li className="breadcrumb-item active">
                    <span aria-current="location">Premium Casino</span>
                  </li>
                </ol>
              </div>
            </div>
          </div>
        </div>

        {/* Casino Card */}
        <div className="row">
          <div className="col-12">
            <div className="card">
              <CasinoTabsList
                tabs={TABS}
                activeTab={activeTab}
                onTabChange={setActiveTab}
                items={filteredItems}
                renderItem={(item) => (
                  <Link to={`/admin/pcasino/${item.id}`}>
                    <img
                      className="img-fluid"
                      src={`/admin/assets/casino/lc/${item.img}`}
                      alt={item.id}
                    />
                  </Link>
                )}
              />
            </div>
          </div>
        </div>
    </div>
  )
}

export default PremiumCasino
