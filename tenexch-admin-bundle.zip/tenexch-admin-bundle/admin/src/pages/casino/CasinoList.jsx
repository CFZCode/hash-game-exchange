import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import api from '../../services/api'
import { CASINO_ITEMS, CASINO_IMG_BASE } from '../../config/casinoItems'
import CasinoTabsList from '../../components/casino/CasinoTabsList'

const TABS = [
  'All Casino', 'Roulette', 'Teenpatti', 'Poker', 'Baccarat', 'Dragon Tiger',
  '32 Cards', 'Andar Bahar', 'Lucky 7', '3 Card Judgement', 'Casino War',
  'Worli', 'Sports', 'Bollywood', 'Lottery', 'Queen', 'Race', 'Others',
]

// Catalog tile_category (what the owner sets in Casino Manage, what the
// player site's tabs use) → this page's tab label.
const TAB_BY_CATEGORY = {
  roulette: 'Roulette', teenpatti: 'Teenpatti', poker: 'Poker', baccarat: 'Baccarat',
  dragontiger: 'Dragon Tiger', '32cards': '32 Cards', andarbahar: 'Andar Bahar',
  lucky7: 'Lucky 7', '3cardj': '3 Card Judgement', casinowar: 'Casino War',
  worli: 'Worli', sports: 'Sports', bollywood: 'Bollywood', lottery: 'Lottery',
  queen: 'Queen', race: 'Race', others: 'Others',
}

// The public catalog — same rows, same order and same tile_category the
// player site's Our Casino grid renders (frontend CasinoHome.jsx). Not the
// admin list endpoint: that one is owner-only, and a master/agent must see
// this page too.
const CATALOG_URL = '/user/casino-manage/games'

// Catalog game_type / route slugs that spell the table differently from the
// admin game-page id (the three Instant Teenpatti tables are the only ones).
const CATALOG_ALIASES = {
  instantteenpatti: 'teenpattiinstant',
  instantteenpatti2: 'teenpattiinstant2',
  instantteenpatti3: 'teenpattiinstant3',
}

// Per-tab sequence captured from the reference admin (tenexch.com
// /admin/casino/list DOM, user 2026-09-19). A category tab is NOT the All
// Casino order filtered — the reference lists each tab in its own order
// (teen62, teenunique, joker20, joker120, joker1 …) and its own membership
// (the Joker tables sit under Teenpatti there although the catalog files them
// under others, and the two 1 Card tables under teenpatti while the reference
// tab does not show them). Where a tab has a list here it IS the tab: exactly
// these tiles, in this order (minus any the owner disabled). Tabs without a
// list keep catalog membership + catalog order. Keys are admin game-page ids.
const TAB_REFERENCE_ORDER = {
  Teenpatti: [
    'teen62', 'teenunique', 'jokerteenpatti20', 'jokerteenpatti120', 'jokerteenpatti1',
    'teenpattit20c', 'teenpatti41', 'teenpatti42', 'teenpattiinstant3', 'teenpattiinstant',
    'teenpattiinstant2', 'teenpattit20b', 'teenmuf', 'teenpatti2cards', 'teenpattioneday',
    'teenpattit20', 'teenpattitest', 'teenpattiopen', 'teenpatti2',
  ],
  Baccarat: ['baccarat', 'baccarat2', '29cardbaccarat'],
  'Andar Bahar': ['ab4', 'ab3', 'andar-bahar', 'andar-bahar2'],
  Sports: ['goal2', 'superover2', 'goal', 'superover3', 'cmeter1', 'cricketv3', 'cmatch20', 'meter', 'superover'],
  Bollywood: ['bollywoodtable2', 'aaa2', 'aaa', 'bollywoodtable'],
  Race: ['race2', 'race20', 'raceto17'],
  Others: [
    'dolidana', 'mogambo', 'poison', 'ballbyball', 'sicbo2', 'poisonteenpatti20', 'sicbo',
    'dum10', '1card1day', '1card2020', 'notenum', 'trio', 'trap',
  ],
}

// Our Casino list (reference): breadcrumb + card > casino-tabs-admin (scroll
// arrows + category tabs) > casino-banners (goal2 first). Banner click →
// /admin/casino/<gtype> game page.
//
// ORDER and CATEGORY come from the catalog, not from casinoItems.js: the
// hardcoded `cat` there had drifted from what the owner set (10 tiles sat in
// the wrong tab — Doli Danna/Mogambo under Others instead of Bollywood, the
// Joker/Poison tables under Teenpatti instead of Others …, user 2026-09-19).
// casinoItems.js still supplies the admin game-page id and the CDN image: the
// catalog's routes are the player site's short slugs (/casino/dt20), while
// the admin game pages are keyed by the long ids (/admin/casino/dragontigert20)
// — they meet on the image name, which equals the catalog game_type minus its
// `our-` prefix. Until the catalog answers (or if it cannot) the bundled list
// renders as before, so the page is never empty.
function CasinoList() {
  const [activeTab, setActiveTab] = useState('All Casino')
  const [catalog, setCatalog] = useState(null)

  useEffect(() => {
    const controller = new AbortController()
    api.get(CATALOG_URL, { signal: controller.signal })
      .then((res) => {
        const games = res.data?.payload?.games || res.data?.data || []
        setCatalog(Array.isArray(games) ? games : [])
      })
      .catch(() => { /* keep the bundled order */ })
    return () => controller.abort()
  }, [])

  const items = useMemo(() => {
    if (!catalog?.length) return CASINO_ITEMS
    const byImg = new Map(CASINO_ITEMS.map((it) => [it.img.replace(/\.(jpg|gif)$/, '').toLowerCase(), it]))
    const byId = new Map(CASINO_ITEMS.map((it) => [it.id.toLowerCase(), it]))
    const out = []
    for (const g of catalog) {
      if (g.category !== 'our' || g.enabled === false) continue
      const key = String(g.game_type || '').replace(/^our-/, '').toLowerCase()
      const slug = String(g.route || '').replace(/\/+$/, '').split('/').pop().toLowerCase()
      const it = byImg.get(key) || byId.get(slug) || byId.get(key)
        || byId.get(CATALOG_ALIASES[key]) || byId.get(CATALOG_ALIASES[slug])
      if (!it) continue // no admin game page for it (teen20v1 is the VIP list's)
      out.push({ ...it, cat: TAB_BY_CATEGORY[String(g.tile_category || '').toLowerCase()] || it.cat })
    }
    return out.length ? out : CASINO_ITEMS
  }, [catalog])

  const filteredItems = useMemo(() => {
    if (activeTab === 'All Casino') return items
    const ref = TAB_REFERENCE_ORDER[activeTab]
    if (!ref) return items.filter((item) => item.cat === activeTab)
    const byId = new Map(items.map((it) => [it.id, it]))
    return ref.map((id) => byId.get(id)).filter(Boolean)
  }, [activeTab, items])

  return (
    <div data-v-5a10e370="">
      <div className="row">
        <div className="col-12">
          <div className="page-title-box d-flex align-items-center justify-content-between">
            <h4 className="mb-0 font-size-18">Our Casino</h4>
            {' '}
            <div className="page-title-right">
              <ol className="breadcrumb m-0">
                <li className="breadcrumb-item">
                  <Link to="/admin/home" className="" target="_self">Home</Link>
                </li>
                <li className="breadcrumb-item active">
                  <span aria-current="location">Our Casino</span>
                </li>
              </ol>
            </div>
          </div>
        </div>
      </div>
      {' '}
      <div className="card">
        <CasinoTabsList
          tabs={TABS}
          activeTab={activeTab}
          onTabChange={setActiveTab}
          items={filteredItems}
          renderItem={(item) => (
            <Link to={`/admin/casino/${item.id}`} className="">
              <img
                className="img-fluid"
                data-src={`${CASINO_IMG_BASE}/${item.img}`}
                src={`${CASINO_IMG_BASE}/${item.img}`}
                lazy="loaded"
              />
            </Link>
          )}
        />
      </div>
    </div>
  )
}

export default CasinoList
