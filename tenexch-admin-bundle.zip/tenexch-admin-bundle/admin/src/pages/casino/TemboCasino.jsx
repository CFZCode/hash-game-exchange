import { Link } from 'react-router-dom'

function TemboCasino() {
  return (
    <div className="container-fluid">
        <div className="row">
          <div className="col-12">
            <div className="page-title-box d-flex align-items-center justify-content-between">
              <h4 className="mb-0 font-size-18">Tembo Casino</h4>
              <div className="page-title-right">
                <ol className="breadcrumb m-0">
                  <li className="breadcrumb-item">
                    <Link to="/admin/home">Home</Link>
                  </li>
                  <li className="breadcrumb-item active">Tembo Casino</li>
                </ol>
              </div>
            </div>
          </div>
        </div>

        <div className="row">
          <div className="col-12">
            <div className="card">
              <div className="casino-tabs-admin p-2">
                <div className="casino-tabs-menu w-100">
                  <a href="javascript:void(0)" className="arrow-tabs arrow-left"><i className="mdi mdi-chevron-left"></i></a>
                  <ul className="nav nav-tabs nav-tabs-custom"></ul>
                  <a href="javascript:void(0)" className="arrow-tabs arrow-right"><i className="mdi mdi-chevron-right"></i></a>
                </div>
              </div>
              <div className="casino-banners"></div>
            </div>
          </div>
        </div>
    </div>
  )
}

export default TemboCasino
