import { useState, useEffect, useMemo } from 'react'
import { Link } from 'react-router-dom'
import Swal from 'sweetalert2'
import casinoManageService from '../../services/casinoManageService'
import useModalEnter from '../../hooks/useModalEnter'

// Casino Manage — owner-only switchboard for the whole in-house casino:
// the Our Casino grid plus the VIP / Virtual / Premium tables. Per game: an
// enable toggle (off = gone from the frontend), an entry threshold, and —
// via Add/Edit — name, route, grid tab and tile image. Uploaded images are
// converted to base64 data: URIs in the browser and stored in the row, so
// no file ever has to reach the web root.

const CATEGORY_TABS = [
  { id: 'our', label: 'Our Casino' },
  { id: 'vip', label: 'VIP Casino' },
  { id: 'virtual', label: 'Virtual Casino' },
  { id: 'premium', label: 'Premium Casino' },
]

// The frontend grid's category tabs — what tile_category can point at.
const TILE_CATEGORIES = [
  'roulette', 'teenpatti', 'poker', 'baccarat', 'dragontiger', '32cards',
  'andarbahar', 'lucky7', '3cardj', 'casinowar', 'worli', 'sports',
  'bollywood', 'lottery', 'queen', 'race', 'others',
]

const MAX_IMG_BYTES = 5 * 1024 * 1024

const emptyForm = { name: '', route: '', tile_category: '', min_balance: 0, img: '', launch_type: 'table', game_uid: '' }

// How a tile opens. Separate from the category tabs above, which only decide
// which grid the tile appears in — so a 3rd-party game can live in any tab.
const LAUNCH_TYPES = [
  { id: 'table', label: 'Casino Table' },
  { id: 'third_party', label: '3rd Party Casino' },
]

// data:/http(s) URIs render as-is (the API serves stored base64 art from
// /api/user/casino-manage/img/:id as an absolute URL). Bare filenames live in
// the FRONTEND's asset folder, which this panel doesn't ship — those fall to
// the local default tile via onError. Run
// server/scripts/import-casino-tile-images.mjs to move them into the backend.
// This panel is served under /admin/ (vite base), so its own files must be
// addressed through BASE_URL — a bare "/assets/..." 404s here.
const TILE_DIR = `${import.meta.env.BASE_URL}assets/casino/games/`
const FALLBACK_TILE = `${TILE_DIR}default-2.jpeg`
const imgSrc = (img) => {
  if (!img) return null
  if (/^(data:|https?:)/i.test(img)) return img
  return `${TILE_DIR}${img}`
}
const fallbackToDefault = (e) => {
  if (!e.currentTarget.src.endsWith(FALLBACK_TILE)) e.currentTarget.src = FALLBACK_TILE
}

// A serving URL can 404 when the row stores a filename the API host doesn't
// have on disk (every virtual tile today). Before giving up on the grey
// default, try the art this panel ships under the row's game_type
// (`vteen` → vteen.jpg; Our Casino files are stored unprefixed).
const bundledArt = (game) =>
  game?.game_type ? `${TILE_DIR}${String(game.game_type).replace(/^our-/, '')}.jpg` : null

const makeImgFallback = (game) => (e) => {
  const el = e.currentTarget
  const art = bundledArt(game)
  if (art && !el.dataset.triedArt && !el.src.endsWith(art)) {
    el.dataset.triedArt = '1'
    el.src = art
    return
  }
  fallbackToDefault(e)
}

function CasinoManage() {
  const [games, setGames] = useState([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('our')
  // Draft min-balance edits, keyed by game id — committed on Save, so a
  // half-typed number is never PUT to the server.
  const [drafts, setDrafts] = useState({})
  const [savingId, setSavingId] = useState(null)
  // Add/Edit modal: null = closed, 'new' = adding, otherwise the row being edited
  const [editing, setEditing] = useState(null)
  // Add/Edit modal open animation + outside click (hooks/useModalEnter)
  const editEnter = useModalEnter(() => closeModal(), editing !== null)
  const [form, setForm] = useState(emptyForm)
  // What img the modal opened with — the list API hands back a SERVING URL
  // for stored base64 art, and echoing that URL into a save would overwrite
  // the real image with a pointer to itself. img only goes in the payload
  // when the owner actually changed it (picked a file / removed).
  const [initialImg, setInitialImg] = useState('')
  const [formSaving, setFormSaving] = useState(false)

  const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: false,
  })

  const fetchGames = async () => {
    setLoading(true)
    try {
      const response = await casinoManageService.list()
      if (response.success) setGames(response.data || [])
    } catch (error) {
      Toast.fire({ icon: 'error', title: error.response?.data?.error || error.message })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchGames()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const visibleGames = useMemo(
    () => games.filter((g) => g.category === activeTab),
    [games, activeTab]
  )

  const applyUpdate = async (game, payload, successTitle) => {
    setSavingId(game.id)
    try {
      const response = await casinoManageService.update(game.id, payload)
      if (response.success) {
        setGames((prev) => prev.map((g) => (g.id === game.id ? response.data : g)))
        Toast.fire({ icon: 'success', title: successTitle })
      }
    } catch (error) {
      Toast.fire({ icon: 'error', title: error.response?.data?.error || error.message })
    } finally {
      setSavingId(null)
    }
  }

  const handleToggle = (game) => {
    applyUpdate(
      game,
      { enabled: !game.enabled },
      `${game.name} ${game.enabled ? 'disabled' : 'enabled'}`
    )
  }

  const handleMinBalanceSave = (game) => {
    const raw = drafts[game.id]
    const value = Number(raw)
    if (!Number.isFinite(value) || value < 0) {
      Toast.fire({ icon: 'error', title: 'Min balance must be a number ≥ 0' })
      return
    }
    applyUpdate(game, { min_balance: value }, `${game.name} min balance saved`).then(() => {
      setDrafts((prev) => {
        const next = { ...prev }
        delete next[game.id]
        return next
      })
    })
  }

  // ── Add / Edit modal ──
  const openAdd = () => {
    setForm(emptyForm)
    setInitialImg('')
    setEditing('new')
  }

  const openEdit = (game) => {
    setForm({
      name: game.name || '',
      route: game.route || '',
      tile_category: game.tile_category || '',
      min_balance: Number(game.min_balance) || 0,
      img: game.img || '',
      launch_type: game.launch_type || 'table',
      game_uid: game.game_uid || '',
    })
    setInitialImg(game.img || '')
    setEditing(game)
  }

  const closeModal = () => {
    if (formSaving) return
    setEditing(null)
    setForm(emptyForm)
  }

  // File → server (multer, multipart) → base64 dataUrl back. The server owns
  // the conversion; the browser only previews what came back, so what you see
  // is exactly the string that will be stored on the row.
  const [uploading, setUploading] = useState(false)
  const handleImageFile = async (e) => {
    const file = e.target.files?.[0]
    if (!file) return
    if (!file.type.startsWith('image/')) {
      Toast.fire({ icon: 'error', title: 'Pick an image file' })
      return
    }
    if (file.size > MAX_IMG_BYTES) {
      Toast.fire({ icon: 'error', title: 'Image must be under 5MB' })
      return
    }
    setUploading(true)
    try {
      const response = await casinoManageService.uploadImage(file)
      if (response.success && response.dataUrl) {
        setForm((prev) => ({ ...prev, img: response.dataUrl }))
      } else {
        Toast.fire({ icon: 'error', title: response.error || 'Upload failed' })
      }
    } catch (error) {
      Toast.fire({ icon: 'error', title: error.response?.data?.error || error.message })
    } finally {
      setUploading(false)
      e.target.value = ''
    }
  }

  const handleFormSubmit = async (e) => {
    e.preventDefault()
    if (!form.name.trim()) {
      Toast.fire({ icon: 'error', title: 'Name is required' })
      return
    }
    const minBalance = Number(form.min_balance)
    if (!Number.isFinite(minBalance) || minBalance < 0) {
      Toast.fire({ icon: 'error', title: 'Min balance must be a number ≥ 0' })
      return
    }
    // Blocked here as well as server-side: the owner should be told at the
    // form, not after a round trip, and a 3rd-party tile with no game id
    // launches nothing while looking exactly like a working one.
    const gameUid = form.game_uid.trim()
    if (form.launch_type === 'third_party' && !gameUid) {
      Toast.fire({ icon: 'error', title: 'Game ID is required for a 3rd party casino' })
      return
    }
    const payload = {
      name: form.name.trim(),
      route: form.route.trim(),
      tile_category: form.tile_category,
      min_balance: minBalance,
      launch_type: form.launch_type,
      game_uid: gameUid,
    }
    if (form.img !== initialImg) payload.img = form.img || null
    setFormSaving(true)
    try {
      if (editing === 'new') {
        const response = await casinoManageService.create({ ...payload, category: activeTab })
        if (response.success) {
          setGames((prev) => [...prev, response.data])
          Toast.fire({ icon: 'success', title: `${payload.name} added` })
        }
      } else {
        const response = await casinoManageService.update(editing.id, payload)
        if (response.success) {
          setGames((prev) => prev.map((g) => (g.id === editing.id ? response.data : g)))
          Toast.fire({ icon: 'success', title: `${payload.name} saved` })
        }
      }
      setEditing(null)
      setForm(emptyForm)
    } catch (error) {
      Toast.fire({ icon: 'error', title: error.response?.data?.error || error.message })
    } finally {
      setFormSaving(false)
    }
  }

  return (
    <div className="container-fluid">
      {/* Breadcrumb */}
      <div className="row">
        <div className="col-12">
          <div className="page-title-box d-flex align-items-center justify-content-between">
            <h4 className="mb-0 font-size-18">Casino Manage</h4>
            <div className="page-title-right">
              <ol className="breadcrumb m-0">
                <li className="breadcrumb-item">
                  <Link to="/admin/home">Home</Link>
                </li>
                <li className="breadcrumb-item active">Casino Manage</li>
              </ol>
            </div>
          </div>
        </div>
      </div>

      <div className="row">
        <div className="col-12">
          <div className="card">
            <div className="card-body">
              <div className="casino-manage-header mb-3">
                {/* Category tabs — their own scrollable strip on mobile, so
                    they never overlap the Add button */}
                <div className="casino-manage-tabs-scroll">
                  <ul className="nav nav-tabs nav-tabs-custom flex-nowrap">
                    {CATEGORY_TABS.map((tab) => (
                      <li className="nav-item" key={tab.id}>
                        <a
                          href="javascript:void(0)"
                          className={`nav-link ${activeTab === tab.id ? 'active' : ''}`}
                          onClick={() => setActiveTab(tab.id)}
                        >
                          {tab.label}
                        </a>
                      </li>
                    ))}
                  </ul>
                </div>
                <button type="button" className="btn btn-primary btn-sm casino-manage-add" onClick={openAdd}>
                  <i className="mdi mdi-plus"></i> Add Game
                </button>
              </div>

              {loading ? (
                <div className="text-center p-4">Loading...</div>
              ) : (
                <>
                {/* ── Mobile: stacked cards (no sideways cramming) ── */}
                <div className="casino-manage-cards d-md-none">
                  {visibleGames.length === 0 && (
                    <div className="text-center p-3">no records found</div>
                  )}
                  {visibleGames.map((game) => {
                    const draft = drafts[game.id]
                    const dirty = draft !== undefined && Number(draft) !== Number(game.min_balance)
                    const src = imgSrc(game.img)
                    return (
                      <div className={`casino-manage-card${game.enabled ? '' : ' is-disabled'}`} key={`m-${game.id}`}>
                        <div className="cm-card-top">
                          {src ? (
                            <img src={src} alt={game.name} onError={makeImgFallback(game)} className="cm-card-thumb" />
                          ) : (
                            <div className="cm-card-thumb cm-card-thumb-empty">no image</div>
                          )}
                          <div className="cm-card-title">
                            <div className="cm-card-name">{game.name}</div>
                            {game.route ? <code className="cm-card-route">{game.route}</code> : null}
                          </div>
                          <div className="custom-control custom-switch cm-card-switch">
                            <input
                              type="checkbox"
                              className="custom-control-input"
                              id={`cmm-toggle-${game.id}`}
                              checked={!!game.enabled}
                              onChange={() => handleToggle(game)}
                              disabled={savingId === game.id}
                            />
                            <label className="custom-control-label" htmlFor={`cmm-toggle-${game.id}`}></label>
                          </div>
                        </div>
                        <div className="cm-card-bottom">
                          <div className="cm-card-minbal">
                            <span className="cm-card-label">Min Balance</span>
                            <input
                              type="number"
                              min="0"
                              className="form-control form-control-sm"
                              value={draft !== undefined ? draft : Number(game.min_balance)}
                              onChange={(e) =>
                                setDrafts((prev) => ({ ...prev, [game.id]: e.target.value }))
                              }
                              disabled={savingId === game.id}
                            />
                            {dirty && (
                              <button
                                type="button"
                                className="btn btn-sm btn-primary"
                                onClick={() => handleMinBalanceSave(game)}
                                disabled={savingId === game.id}
                              >
                                Save
                              </button>
                            )}
                          </div>
                          <button
                            type="button"
                            className="btn btn-sm btn-outline-secondary"
                            onClick={() => openEdit(game)}
                          >
                            <i className="mdi mdi-pencil"></i> Edit
                          </button>
                        </div>
                      </div>
                    )
                  })}
                </div>

                {/* ── Desktop: the table ── */}
                <div className="table-responsive d-none d-md-block">
                  <table className="table table-centered table-nowrap mb-0">
                    <thead className="thead-light">
                      <tr>
                        <th style={{ width: 90 }}>Image</th>
                        <th>Game Name</th>
                        <th>Route</th>
                        <th style={{ width: 220 }}>Min Balance</th>
                        <th style={{ width: 100 }} className="text-center">Enabled</th>
                        <th style={{ width: 80 }} className="text-center">Edit</th>
                      </tr>
                    </thead>
                    <tbody>
                      {visibleGames.length === 0 && (
                        <tr>
                          <td colSpan={6} className="text-center">no records found</td>
                        </tr>
                      )}
                      {visibleGames.map((game) => {
                        const draft = drafts[game.id]
                        const dirty = draft !== undefined && Number(draft) !== Number(game.min_balance)
                        const src = imgSrc(game.img)
                        return (
                          <tr key={game.id} style={game.enabled ? undefined : { opacity: 0.55 }}>
                            <td>
                              {src ? (
                                <img src={src} alt={game.name} onError={makeImgFallback(game)} style={{ width: 72, height: 40, objectFit: 'cover', borderRadius: 4, background: '#222' }} />
                              ) : (
                                <div style={{ width: 72, height: 40, borderRadius: 4, background: '#222', color: '#bbb', fontSize: 10, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>no image</div>
                              )}
                            </td>
                            <td>{game.name}</td>
                            <td><code>{game.route || '—'}</code></td>
                            <td>
                              <div className="d-flex align-items-center">
                                <input
                                  type="number"
                                  min="0"
                                  className="form-control form-control-sm"
                                  style={{ maxWidth: 120 }}
                                  value={draft !== undefined ? draft : Number(game.min_balance)}
                                  onChange={(e) =>
                                    setDrafts((prev) => ({ ...prev, [game.id]: e.target.value }))
                                  }
                                  disabled={savingId === game.id}
                                />
                                {dirty && (
                                  <button
                                    type="button"
                                    className="btn btn-sm btn-primary ml-2"
                                    onClick={() => handleMinBalanceSave(game)}
                                    disabled={savingId === game.id}
                                  >
                                    Save
                                  </button>
                                )}
                              </div>
                            </td>
                            <td className="text-center">
                              {/* Same switch markup the theme ships (custom-switch) */}
                              <div className="custom-control custom-switch d-inline-block">
                                <input
                                  type="checkbox"
                                  className="custom-control-input"
                                  id={`cm-toggle-${game.id}`}
                                  checked={!!game.enabled}
                                  onChange={() => handleToggle(game)}
                                  disabled={savingId === game.id}
                                />
                                <label className="custom-control-label" htmlFor={`cm-toggle-${game.id}`}></label>
                              </div>
                            </td>
                            <td className="text-center">
                              <button
                                type="button"
                                className="btn btn-sm btn-outline-secondary"
                                onClick={() => openEdit(game)}
                              >
                                <i className="mdi mdi-pencil"></i>
                              </button>
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Add / Edit modal */}
      {editing !== null && (
        <>
          <div className={editEnter.modalClass} style={{ display: 'block' }} role="dialog" aria-modal="true" onClick={editEnter.onBackdropClick}>
            <div className="modal-dialog modal-dialog-centered" role="document">
              <div className="modal-content">
                <div className="modal-header">
                  <h5 className="modal-title">
                    {editing === 'new'
                      ? `Add Game — ${CATEGORY_TABS.find((t) => t.id === activeTab)?.label}`
                      : `Edit — ${editing.name}`}
                  </h5>
                  <button type="button" className="close" aria-label="Close" onClick={closeModal}>
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <form onSubmit={handleFormSubmit}>
                  <div className="modal-body">
                    <div className="form-group">
                      <label>Game Name</label>
                      <input
                        type="text"
                        className="form-control"
                        value={form.name}
                        maxLength={80}
                        onChange={(e) => setForm((prev) => ({ ...prev, name: e.target.value }))}
                        disabled={formSaving}
                      />
                    </div>
                    <div className="form-group">
                      <label>Launch Type</label>
                      <select
                        className="form-control"
                        value={form.launch_type}
                        onChange={(e) => setForm((prev) => ({ ...prev, launch_type: e.target.value }))}
                        disabled={formSaving}
                      >
                        {LAUNCH_TYPES.map((t) => (
                          <option key={t.id} value={t.id}>{t.label}</option>
                        ))}
                      </select>
                      <small className="text-muted">
                        {form.launch_type === 'third_party'
                          ? 'Opening the route launches the 3rd party game below.'
                          : 'Opening the route shows our own casino table.'}
                      </small>
                    </div>
                    {form.launch_type === 'third_party' && (
                      <div className="form-group">
                        <label>Game ID</label>
                        <input
                          type="text"
                          className="form-control"
                          placeholder="e.g. JILI-Aviator"
                          value={form.game_uid}
                          maxLength={255}
                          onChange={(e) => setForm((prev) => ({ ...prev, game_uid: e.target.value }))}
                          disabled={formSaving}
                        />
                        <small className="text-muted">The provider game id to launch. The tile's page becomes /casino/slot/&lt;id&gt;.</small>
                      </div>
                    )}
                    {form.launch_type === 'third_party' ? (
                      <div className="form-group">
                        <label>Route</label>
                        <input
                          type="text"
                          className="form-control"
                          value={form.game_uid.trim() ? `/casino/slot/${form.game_uid.trim()}` : ''}
                          placeholder="— set automatically from the Game ID —"
                          readOnly
                          disabled
                        />
                        <small className="text-muted">
                          Built from the Game ID, so there is nothing to type and nothing to clash
                          with a table route.
                        </small>
                      </div>
                    ) : (
                      <div className="form-group">
                        <label>Route</label>
                        <input
                          type="text"
                          className="form-control"
                          placeholder="/casino/teen20"
                          value={form.route}
                          onChange={(e) => setForm((prev) => ({ ...prev, route: e.target.value }))}
                          disabled={formSaving}
                        />
                        <small className="text-muted">Frontend path the tile opens. Leave empty for a display-only tile.</small>
                      </div>
                    )}
                    <div className="form-group">
                      <label>Grid Tab (category)</label>
                      <select
                        className="form-control"
                        value={form.tile_category}
                        onChange={(e) => setForm((prev) => ({ ...prev, tile_category: e.target.value }))}
                        disabled={formSaving}
                      >
                        <option value="">— none —</option>
                        {TILE_CATEGORIES.map((c) => (
                          <option key={c} value={c}>{c}</option>
                        ))}
                      </select>
                    </div>
                    <div className="form-group">
                      <label>Min Balance</label>
                      <input
                        type="number"
                        min="0"
                        className="form-control"
                        value={form.min_balance}
                        onChange={(e) => setForm((prev) => ({ ...prev, min_balance: e.target.value }))}
                        disabled={formSaving}
                      />
                    </div>
                    <div className="form-group">
                      <label>Tile Image</label>
                      <input
                        type="file"
                        accept="image/*"
                        className="form-control-file d-block"
                        onChange={handleImageFile}
                        disabled={formSaving || uploading}
                      />
                      <small className="text-muted">
                        {uploading ? 'Uploading…' : 'Uploaded image is stored as a base64 URL. Max 5MB.'}
                      </small>
                      {form.img && (
                        <div className="mt-2 d-flex align-items-center">
                          <img
                            src={imgSrc(form.img)}
                            alt="preview"
                            onError={fallbackToDefault}
                            style={{ width: 144, height: 80, objectFit: 'cover', borderRadius: 4, background: '#222' }}
                          />
                          <button
                            type="button"
                            className="btn btn-sm btn-outline-danger ml-2"
                            onClick={() => setForm((prev) => ({ ...prev, img: '' }))}
                            disabled={formSaving}
                          >
                            Remove
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="modal-footer">
                    <button type="button" className="btn btn-secondary" onClick={closeModal} disabled={formSaving}>
                      Cancel
                    </button>
                    <button type="submit" className="btn btn-primary" disabled={formSaving || uploading}>
                      {formSaving ? 'Saving...' : editing === 'new' ? 'Add Game' : 'Save Changes'}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <div className={editEnter.backdropClass}></div>
        </>
      )}
    </div>
  )
}

export default CasinoManage
