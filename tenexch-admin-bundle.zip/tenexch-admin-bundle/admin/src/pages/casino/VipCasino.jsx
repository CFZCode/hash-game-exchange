import { useState, useMemo } from 'react'
import { Link } from 'react-router-dom'
import CasinoTabsList from '../../components/casino/CasinoTabsList'

const TABS = [
  'All Casino',
  'Teenpatti',
]

const VIP_CASINO_ITEMS = [
  { id: 'teenpattit20', img: 'teen20v1_admin.gif', cat: 'Teenpatti' },
]

function VipCasino() {
  const [activeTab, setActiveTab] = useState('All Casino')

  const filteredItems = useMemo(() => {
    if (activeTab === 'All Casino') return VIP_CASINO_ITEMS
    return VIP_CASINO_ITEMS.filter((item) => item.cat === activeTab)
  }, [activeTab])

  return (
    <div>
        {/* Breadcrumb */}
        <div className="row">
          <div className="col-12">
            <div className="page-title-box d-flex align-items-center justify-content-between">
              <h4 className="mb-0 font-size-18">Our Casino</h4>
              <div className="page-title-right">
                <ol className="breadcrumb m-0">
                  <li className="breadcrumb-item">
                    <Link to="/admin/home">Home</Link>
                  </li>
                  <li className="breadcrumb-item active">
                    <span aria-current="location">Our Casino</span>
                  </li>
                </ol>
              </div>
            </div>
          </div>
        </div>

        {/* Casino Card */}
        <div className="row">
          <div className="col-12">
            <div className="card">
              <CasinoTabsList
                tabs={TABS}
                activeTab={activeTab}
                onTabChange={setActiveTab}
                items={filteredItems}
                renderItem={(item) => (
                  <Link to={`/admin/casino/vip/${item.id}`}>
                    <img
                      className="img-fluid"
                      src={`/admin/assets/casino/lc/${item.img}`}
                      alt={item.id}
                    />
                  </Link>
                )}
              />
            </div>
          </div>
        </div>
    </div>
  )
}

export default VipCasino
