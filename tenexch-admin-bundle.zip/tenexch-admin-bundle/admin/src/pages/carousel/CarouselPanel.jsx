import { useState, useEffect } from 'react'
import Swal from 'sweetalert2'
import carouselService from '../../services/carouselService'
import posterService from '../../services/posterService'
import BannerAutoUpdateCard from './BannerAutoUpdateCard'

const emptyForm = {
  image_url: '',
  category: 'sports',
  sport_id: '',
  event_id: '',
  game_name: '',
  game_uid: '',
}

function CarouselPanel() {
  const [formData, setFormData] = useState(emptyForm)
  const [errors, setErrors] = useState({})
  const [submitting, setSubmitting] = useState(false)
  const [carousels, setCarousels] = useState([])
  const [loading, setLoading] = useState(true)
  const [editingId, setEditingId] = useState(null)
  const [reordering, setReordering] = useState(false)
  const [activeTab, setActiveTab] = useState('carousel')
  const [posters, setPosters] = useState({ web: null, mobile: null })
  const [posterInput, setPosterInput] = useState('')
  const [posterMobileInput, setPosterMobileInput] = useState('')
  const [posterLoading, setPosterLoading] = useState(true)
  const [posterSaving, setPosterSaving] = useState(false)

  const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: false,
  })

  const fetchCarousels = async () => {
    setLoading(true)
    try {
      const response = await carouselService.list()
      if (response.success) setCarousels(response.data || [])
    } catch (error) {
      Toast.fire({ icon: 'error', title: error.response?.data?.error || error.message })
    } finally {
      setLoading(false)
    }
  }

  const fetchPoster = async () => {
    setPosterLoading(true)
    try {
      const response = await posterService.get()
      if (response.success) {
        const rows = Array.isArray(response.data) ? response.data : response.data ? [response.data] : []
        const web = rows.find((p) => !p.is_mobile) || null
        const mobile = rows.find((p) => p.is_mobile) || null
        setPosters({ web, mobile })
        setPosterInput(web?.image_url || '')
        setPosterMobileInput(mobile?.image_url || '')
      }
    } catch (error) {
      Toast.fire({ icon: 'error', title: error.response?.data?.error || error.message })
    } finally {
      setPosterLoading(false)
    }
  }

  useEffect(() => {
    fetchCarousels()
    fetchPoster()
  }, [])


  const handlePosterSave = async (e) => {
    e.preventDefault()
    const web = posterInput.trim()
    const mobile = posterMobileInput.trim()
    if (!web && !mobile) {
      Toast.fire({ icon: 'error', title: 'Enter at least one poster link' })
      return
    }
    setPosterSaving(true)
    try {
      if (web) await posterService.update({ image_url: web, is_mobile: false })
      if (mobile) await posterService.update({ image_url: mobile, is_mobile: true })
      Toast.fire({ icon: 'success', title: 'Poster links saved' })
      fetchPoster()
    } catch (error) {
      Toast.fire({ icon: 'error', title: error.response?.data?.error || error.message })
    } finally {
      setPosterSaving(false)
    }
  }

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
    setErrors((prev) => ({ ...prev, [name]: '' }))
  }

  const validate = () => {
    const newErrors = {}
    if (!formData.image_url.trim()) newErrors.image_url = 'Image link is required'
    if (formData.category === 'sports') {
      if (!formData.sport_id.trim()) newErrors.sport_id = 'Sport ID is required'
      if (!formData.event_id.trim()) newErrors.event_id = 'Event ID is required'
    } else if (formData.category === 'casino' && !formData.game_name.trim()) {
      newErrors.game_name = 'Game name is required'
    } else if (formData.category === 'thirdparty' && !formData.game_uid.trim()) {
      newErrors.game_uid = 'Game ID is required'
    }
    return newErrors
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    const newErrors = validate()
    setErrors(newErrors)
    if (Object.keys(newErrors).length) return

    setSubmitting(true)
    try {
      const payload = {
        image_url: formData.image_url.trim(),
        category: formData.category,
      }
      if (formData.category === 'sports') {
        payload.sport_id = formData.sport_id.trim()
        payload.event_id = formData.event_id.trim()
      } else if (formData.category === 'casino') {
        payload.game_name = formData.game_name.trim()
      } else if (formData.category === 'thirdparty') {
        payload.game_uid = formData.game_uid.trim()
      }
      const response = editingId
        ? await carouselService.update(editingId, payload)
        : await carouselService.create(payload)
      if (response.success) {
        Toast.fire({ icon: 'success', title: editingId ? 'Carousel updated successfully' : 'Carousel added successfully' })
        setFormData(emptyForm)
        setEditingId(null)
        fetchCarousels()
      } else {
        Toast.fire({ icon: 'error', title: response.error || 'Unknown error' })
      }
    } catch (error) {
      Toast.fire({ icon: 'error', title: error.response?.data?.error || error.message })
    } finally {
      setSubmitting(false)
    }
  }

  const handleEdit = (item) => {
    setEditingId(item.carousel_id)
    setErrors({})
    setFormData({
      image_url: item.image_url || '',
      category: item.category || 'sports',
      sport_id: item.sport_id || '',
      event_id: item.event_id || '',
      game_name: item.game_name || '',
      game_uid: item.game_uid || '',
    })
  }

  const handleCancelEdit = () => {
    setEditingId(null)
    setErrors({})
    setFormData(emptyForm)
  }

  const handleMove = async (index, delta) => {
    const target = index + delta
    if (target < 0 || target >= carousels.length) return
    const next = [...carousels]
    ;[next[index], next[target]] = [next[target], next[index]]
    setCarousels(next)
    setReordering(true)
    try {
      const response = await carouselService.reorder(next.map((c) => c.carousel_id))
      if (!response.success) {
        Toast.fire({ icon: 'error', title: response.error || 'Reorder failed' })
        fetchCarousels()
      }
    } catch (error) {
      Toast.fire({ icon: 'error', title: error.response?.data?.error || error.message })
      fetchCarousels()
    } finally {
      setReordering(false)
    }
  }

  const handleDelete = async (item) => {
    const result = await Swal.fire({
      title: 'Delete this carousel?',
      text: item.category === 'thirdparty'
        ? `3rd Party — ${item.game_uid}`
        : item.category === 'sports'
        ? `Sports — Sport ID ${item.sport_id}, Event ID ${item.event_id}`
        : item.category === 'casino'
          ? `Casino — ${item.game_name}`
          : 'Others',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      confirmButtonText: 'Delete',
    })
    if (!result.isConfirmed) return
    try {
      const response = await carouselService.remove(item.carousel_id)
      if (response.success) {
        Toast.fire({ icon: 'success', title: 'Carousel deleted' })
        setCarousels((prev) => prev.filter((c) => c.carousel_id !== item.carousel_id))
        if (item.carousel_id === editingId) handleCancelEdit()
      }
    } catch (error) {
      Toast.fire({ icon: 'error', title: error.response?.data?.error || error.message })
    }
  }

  return (
    <div>
      <div className="row">
        <div className="col-12">
          <div className="page-title-box d-flex align-items-center justify-content-between">
            <h4 className="mb-0 font-size-18">Carousel</h4>
          </div>
        </div>
      </div>

      <BannerAutoUpdateCard
        onSynced={() => {
          fetchCarousels()
          fetchPoster()
        }}
      />

      <ul className="nav nav-tabs mb-3">
        <li className="nav-item">
          <button
            type="button"
            className={`nav-link${activeTab === 'carousel' ? ' active' : ''}`}
            onClick={() => setActiveTab('carousel')}
          >
            Carousel
          </button>
        </li>
        <li className="nav-item">
          <button
            type="button"
            className={`nav-link${activeTab === 'posters' ? ' active' : ''}`}
            onClick={() => setActiveTab('posters')}
          >
            Posters
          </button>
        </li>
      </ul>

      <div style={activeTab === 'carousel' ? {} : { display: 'none' }}>

        <div className="row">
          <div className="col-lg-4">
            <div className="card">
              <div className="card-body">
                <h4 className="card-title mb-3">{editingId ? `Edit Carousel #${editingId}` : 'Add Carousel'}</h4>
                <form onSubmit={handleSubmit}>
                  <div className="mb-3">
                    <label className="form-label">Image Link</label>
                    <input
                      type="text"
                      name="image_url"
                      className={`form-control${errors.image_url ? ' is-invalid' : ''}`}
                      placeholder="https://example.com/banner.jpg"
                      value={formData.image_url}
                      onChange={handleChange}
                    />
                    {errors.image_url && <div className="invalid-feedback">{errors.image_url}</div>}
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Category</label>
                    <select
                      name="category"
                      className="form-select"
                      value={formData.category}
                      onChange={handleChange}
                    >
                      <option value="sports">Sports</option>
                      <option value="casino">Casino</option>
                      <option value="thirdparty">3rd Party Casino</option>
                      <option value="others">Others</option>
                    </select>
                  </div>

                  {formData.category === 'sports' ? (
                    <>
                      <div className="mb-3">
                        <label className="form-label">Sport ID</label>
                        <input
                          type="text"
                          name="sport_id"
                          className={`form-control${errors.sport_id ? ' is-invalid' : ''}`}
                          placeholder="e.g. 4"
                          value={formData.sport_id}
                          onChange={handleChange}
                        />
                        {errors.sport_id && <div className="invalid-feedback">{errors.sport_id}</div>}
                      </div>
                      <div className="mb-3">
                        <label className="form-label">Event ID</label>
                        <input
                          type="text"
                          name="event_id"
                          className={`form-control${errors.event_id ? ' is-invalid' : ''}`}
                          placeholder="e.g. 34461783"
                          value={formData.event_id}
                          onChange={handleChange}
                        />
                        {errors.event_id && <div className="invalid-feedback">{errors.event_id}</div>}
                      </div>
                    </>
                  ) : formData.category === 'casino' ? (
                    <div className="mb-3">
                      <label className="form-label">Game Name</label>
                      <input
                        type="text"
                        name="game_name"
                        className={`form-control${errors.game_name ? ' is-invalid' : ''}`}
                        placeholder="e.g. teenpatti"
                        value={formData.game_name}
                        onChange={handleChange}
                      />
                      {errors.game_name && <div className="invalid-feedback">{errors.game_name}</div>}
                    </div>
                  ) : formData.category === 'thirdparty' ? (
                    <div className="mb-3">
                      <label className="form-label">Game ID</label>
                      <input
                        type="text"
                        name="game_uid"
                        className={`form-control${errors.game_uid ? ' is-invalid' : ''}`}
                        placeholder="e.g. 5cb6aa4e2ce1c775c568561401ffdfca"
                        value={formData.game_uid}
                        onChange={handleChange}
                      />
                      {errors.game_uid && <div className="invalid-feedback">{errors.game_uid}</div>}
                      <small className="text-muted">
                        The provider game id. Tapping the banner opens
                        {' '}<code>/casino/slot/{formData.game_uid.trim() || '<id>'}</code> and launches it.
                      </small>
                    </div>
                  ) : null}

                  {formData.image_url.trim() && (
                    <div className="mb-3">
                      <label className="form-label">Preview</label>
                      <div>
                        <img
                          src={formData.image_url}
                          alt="preview"
                          style={{ maxWidth: '100%', maxHeight: '120px', objectFit: 'contain' }}
                          onError={(e) => { e.target.style.display = 'none' }}
                          onLoad={(e) => { e.target.style.display = '' }}
                        />
                      </div>
                    </div>
                  )}

                  <button type="submit" className="btn btn-primary w-100" disabled={submitting}>
                    {submitting ? 'Saving...' : editingId ? 'Update Carousel' : 'Add Carousel'}
                  </button>
                  {editingId && (
                    <button type="button" className="btn btn-secondary w-100 mt-2" onClick={handleCancelEdit} disabled={submitting}>
                      Cancel
                    </button>
                  )}
                </form>
              </div>
            </div>
          </div>

          <div className="col-lg-8">
            <div className="card">
              <div className="card-body">
                <h4 className="card-title mb-3">All Carousels</h4>
                <div className="table-responsive">
                  <table className="table b-table align-middle">
                    <thead>
                      <tr>
                        <th style={{ width: '90px' }}>Order</th>
                        <th>Image</th>
                        <th>Category</th>
                        <th>Details</th>
                        <th>Created</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {loading ? (
                        <tr><td colSpan="6" className="text-center">Loading...</td></tr>
                      ) : carousels.length === 0 ? (
                        <tr><td colSpan="6" className="text-center">No carousels added yet</td></tr>
                      ) : (
                        carousels.map((item, index) => (
                          <tr key={item.carousel_id} className={item.carousel_id === editingId ? 'table-active' : ''}>
                            <td>
                              <div className="d-flex align-items-center gap-1">
                                <span className="me-1">{index + 1}</span>
                                <button
                                  type="button"
                                  className="btn btn-sm btn-light px-1 py-0"
                                  title="Move up"
                                  disabled={reordering || index === 0}
                                  onClick={() => handleMove(index, -1)}
                                >
                                  <i className="bx bx-up-arrow-alt"></i>
                                </button>
                                <button
                                  type="button"
                                  className="btn btn-sm btn-light px-1 py-0"
                                  title="Move down"
                                  disabled={reordering || index === carousels.length - 1}
                                  onClick={() => handleMove(index, 1)}
                                >
                                  <i className="bx bx-down-arrow-alt"></i>
                                </button>
                              </div>
                            </td>
                            <td>
                              <a href={item.image_url} target="_blank" rel="noreferrer">
                                <img
                                  src={item.image_url}
                                  alt="carousel"
                                  style={{ width: '90px', height: '48px', objectFit: 'cover', borderRadius: '4px' }}
                                />
                              </a>
                            </td>
                            <td>
                              <span className={`badge ${item.category === 'sports' ? 'bg-success' : item.category === 'casino' ? 'bg-info' : 'bg-secondary'}`}>
                                {item.category}
                              </span>
                            </td>
                            <td>
                              {item.category === 'sports' ? (
                                <>Sport ID: {item.sport_id} | Event ID: {item.event_id}</>
                              ) : item.category === 'casino' ? (
                                <>Game: {item.game_name}</>
                              ) : (
                                <>-</>
                              )}
                            </td>
                            <td>{item.createdAt ? new Date(item.createdAt).toLocaleString() : '-'}</td>
                            <td>
                              <button
                                type="button"
                                className="btn btn-sm btn-primary me-1"
                                title="Edit"
                                onClick={() => handleEdit(item)}
                              >
                                <i className="bx bx-edit-alt"></i>
                              </button>
                              <button
                                type="button"
                                className="btn btn-sm btn-danger"
                                title="Delete"
                                onClick={() => handleDelete(item)}
                              >
                                <i className="bx bx-trash"></i>
                              </button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div style={activeTab === 'posters' ? {} : { display: 'none' }}>
        <div className="row">
          <div className="col-lg-8">
            <div className="card">
              <div className="card-body">
                <h4 className="card-title mb-3">Welcome Poster</h4>
                {posterLoading ? (
                  <p className="mb-0">Loading...</p>
                ) : (
                  <form onSubmit={handlePosterSave}>
                    <div className="mb-3">
                      <label className="form-label">Web Poster Image Link</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="https://sitethemedata.com/common/wel-banner/wel-1784402468255.png"
                        value={posterInput}
                        onChange={(e) => setPosterInput(e.target.value)}
                      />
                    </div>

                    <div className="mb-3">
                      <label className="form-label">Mobile Poster Image Link</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="https://sitethemedata.com/common/wel-banner/wel-1784402490047.png"
                        value={posterMobileInput}
                        onChange={(e) => setPosterMobileInput(e.target.value)}
                      />
                    </div>

                    <div className="row mb-3">
                      {posterInput.trim() && (
                        <div className="col-md-6">
                          <label className="form-label">Web Preview</label>
                          <div>
                            <img
                              src={posterInput}
                              alt="web poster preview"
                              style={{ maxWidth: '100%', maxHeight: '260px', objectFit: 'contain' }}
                              onError={(e) => { e.target.style.display = 'none' }}
                              onLoad={(e) => { e.target.style.display = '' }}
                            />
                          </div>
                        </div>
                      )}
                      {posterMobileInput.trim() && (
                        <div className="col-md-6">
                          <label className="form-label">Mobile Preview</label>
                          <div>
                            <img
                              src={posterMobileInput}
                              alt="mobile poster preview"
                              style={{ maxWidth: '100%', maxHeight: '260px', objectFit: 'contain' }}
                              onError={(e) => { e.target.style.display = 'none' }}
                              onLoad={(e) => { e.target.style.display = '' }}
                            />
                          </div>
                        </div>
                      )}
                    </div>

                    <button type="submit" className="btn btn-primary" disabled={posterSaving}>
                      {posterSaving ? 'Saving...' : 'Save Posters'}
                    </button>
                    {(posters.web?.updatedAt || posters.mobile?.updatedAt) && (
                      <p className="text-muted mt-2 mb-0">
                        {posters.web?.updatedAt && <>Web updated: {new Date(posters.web.updatedAt).toLocaleString()}</>}
                        {posters.web?.updatedAt && posters.mobile?.updatedAt && <> | </>}
                        {posters.mobile?.updatedAt && <>Mobile updated: {new Date(posters.mobile.updatedAt).toLocaleString()}</>}
                      </p>
                    )}
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default CarouselPanel
