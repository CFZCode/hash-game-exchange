import { useState, useEffect, useRef } from 'react'
import Swal from 'sweetalert2'
import carouselService from '../../services/carouselService'

// Auto-update status for the carousel + poster mirror (server:
// services/BannerSyncService.js). The server re-reads the reference site every
// 4 h; this card shows when that last happened, when it happens next, and
// offers "Update now". onSynced lets the page reload its tables afterwards.

const fmt = (value) =>
  value
    ? new Date(value).toLocaleString('en-IN', {
        timeZone: 'Asia/Kolkata',
        day: '2-digit',
        month: 'short',
        hour: '2-digit',
        minute: '2-digit',
        hour12: true,
      })
    : '-'

const countdown = (value, now) => {
  if (!value) return ''
  const ms = new Date(value).getTime() - now
  if (ms <= 0) return 'due now'
  const h = Math.floor(ms / 3600000)
  const m = Math.floor((ms % 3600000) / 60000)
  return `in ${h ? `${h}h ` : ''}${m}m`
}

const fileName = (url) => String(url || '').split('/').pop()

const STATUS_BADGE = {
  ok: ['bg-success', 'Up to date'],
  error: ['bg-danger', 'Last run failed'],
  running: ['bg-info', 'Updating…'],
  pending: ['bg-secondary', 'Not run yet'],
}

function BannerAutoUpdateCard({ onSynced }) {
  const [status, setStatus] = useState(null)
  const [running, setRunning] = useState(false)
  const [now, setNow] = useState(Date.now())
  const lastSuccess = useRef(null)

  const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
  })

  const load = async () => {
    try {
      const response = await carouselService.syncStatus()
      if (!response.success) return
      const data = response.data
      setStatus(data)
      // A scheduled run finished while the page was open: reload the tables.
      if (lastSuccess.current && data.last_success_at !== lastSuccess.current) onSynced?.()
      lastSuccess.current = data.last_success_at
    } catch {
      // status is informational; the tables below still work without it
    }
  }

  useEffect(() => {
    load()
    const poll = setInterval(load, 60000)
    const clock = setInterval(() => setNow(Date.now()), 30000)
    return () => {
      clearInterval(poll)
      clearInterval(clock)
    }
  }, [])

  const handleRunNow = async () => {
    setRunning(true)
    try {
      const response = await carouselService.syncNow()
      setStatus(response.data)
      lastSuccess.current = response.data?.last_success_at
      if (response.success) {
        Toast.fire({ icon: 'success', title: 'Carousel and posters updated' })
      } else {
        Toast.fire({ icon: 'error', title: response.error || 'Update failed' })
      }
      onSynced?.()
    } catch (error) {
      Toast.fire({ icon: 'error', title: error.response?.data?.error || error.message })
    } finally {
      setRunning(false)
    }
  }

  const busy = running || status?.running
  const [badgeClass, badgeText] = STATUS_BADGE[busy ? 'running' : status?.status] || STATUS_BADGE.pending
  const added = status?.added || []
  const removed = status?.removed || []

  return (
    <div className="card mb-3">
      <div className="card-body">
        <div className="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
          <h4 className="card-title mb-0">
            Auto Update <span className={`badge ${badgeClass} ms-2 align-middle`}>{badgeText}</span>
          </h4>
          <button type="button" className="btn btn-primary btn-sm" onClick={handleRunNow} disabled={busy}>
            {busy ? 'Updating…' : 'Update now'}
          </button>
        </div>

        <div className="row g-3">
          <div className="col-6 col-md-3">
            <div className="text-muted small">Last updated</div>
            <div className="fw-semibold">{fmt(status?.last_success_at)}</div>
          </div>
          <div className="col-6 col-md-3">
            <div className="text-muted small">Next update</div>
            <div className="fw-semibold">
              {fmt(status?.next_run_at)}
              {status?.next_run_at && <span className="text-muted small ms-1">({countdown(status.next_run_at, now)})</span>}
            </div>
          </div>
          <div className="col-6 col-md-3">
            <div className="text-muted small">Runs every</div>
            <div className="fw-semibold">{status?.interval_hours || 4} hours</div>
          </div>
          <div className="col-6 col-md-3">
            <div className="text-muted small">Last result</div>
            <div className="fw-semibold">
              {status?.last_success_at
                ? `${status.carousel_count} banners · +${added.length} / −${removed.length}${status.poster_changed ? ' · poster changed' : ''}`
                : '-'}
            </div>
          </div>
        </div>

        {(added.length > 0 || removed.length > 0) && (
          <div className="small text-muted mt-2">
            {added.length > 0 && <div>Added: {added.map(fileName).join(', ')}</div>}
            {removed.length > 0 && <div>Removed: {removed.map(fileName).join(', ')}</div>}
          </div>
        )}

        {status?.error && (
          <div className="alert alert-danger py-2 mt-3 mb-0 small">
            {fmt(status.last_run_at)}: {status.error}
          </div>
        )}

        <div className="small text-muted mt-2">
          The carousel and both posters are replaced with the reference site's current list on every run.
          Manual edits last only until the next update.
        </div>
      </div>
    </div>
  )
}

export default BannerAutoUpdateCard
