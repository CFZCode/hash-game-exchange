import { Link, useNavigate } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { logout } from '../store/slices/authSlice'
import { getStoredPermissions, PERMISSION_LABELS } from '../utils/permissions'

// Landing page for an executive whose permission map allows no routable page
// (or who was bounced off a denied route with nowhere better to go). Without
// this, a zero-permission executive lands on a blank screen.
function NoAccess() {
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const user = useSelector((state) => state.auth.user)

  const granted = Object.entries(getStoredPermissions())
    .filter(([, v]) => !!v)
    .map(([key]) => PERMISSION_LABELS[key] || key)

  const handleLogout = () => {
    dispatch(logout())
    navigate('/admin')
  }

  return (
    <div>
      <div className="row">
        <div className="col-12">
          <div className="page-title-box d-flex align-items-center justify-content-between">
            <h4 className="mb-0 font-size-18">No Access</h4>
            <div className="page-title-right">
              <ol className="breadcrumb m-0">
                <li className="breadcrumb-item"><Link to="/admin/home">Home</Link></li>
                <li className="breadcrumb-item active"><span aria-current="location">No Access</span></li>
              </ol>
            </div>
          </div>
        </div>
      </div>

      <div className="row">
        <div className="col-12">
          <div className="card">
            <div className="card-body text-center">
              <i className="bx bx-lock-alt" style={{ fontSize: 48 }}></i>
              <h5 className="mt-2">Your account has no page access</h5>
              <p className="mb-1">
                Logged in as <b>{user?.username || '-'}</b>
                {user?.role ? <> ({user.role})</> : null}
              </p>
              {granted.length > 0 ? (
                <p className="mb-3">
                  Granted privileges: {granted.join(', ')}
                </p>
              ) : (
                <p className="mb-3">No privileges have been granted to this login yet.</p>
              )}
              <p className="text-muted">Contact the account that created this login to grant access.</p>
              <button type="button" className="btn btn-primary" onClick={handleLogout}>
                Logout
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default NoAccess
