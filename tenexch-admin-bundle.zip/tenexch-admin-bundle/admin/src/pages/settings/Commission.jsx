import { Fragment, useState, useEffect, useMemo, useCallback } from 'react'
import { Link } from 'react-router-dom'
import Swal from 'sweetalert2'
import commissionConfigService from '../../services/commissionConfigService'

// Commission — owner-only. When a user WINS on a sports market whose cell is
// ON, settlement deducts `percent` of the NET win and shows it in the account
// statement as a separate "…- Comm" debit row (e.g. 190 win → 3.80 at 2 %).
//
// The grid has THREE dimensions:
//
//   sport   → the feed's etid
//   league  → 'default' (every ordinary league) plus the variants the feed
//             ships under the same sport id but that are a different product:
//             cricket's E-Cricket (Dim), T10 XI, T5 XI, Virtual Cricket League
//             and wrestling's WWE Virtual. A variant cell left on INHERIT
//             follows the default row; set it ON/OFF to break away.
//   market  → finer than the feed's gtype. "Match Odds" means the market
//             really is named Match Odds; everything else gtype 'match'
//             carries (Over/Under, Correct Score, Match Result, Inning
//             EvenOdd, Nth Ball Of Match…) sits under "Other Main Markets".
//
// OFF charges nothing. Losses are never charged.
// Plan: docs/plans/2026-09-12-commission-market-league-split.md

const STATE_META = {
  on: { label: 'ON', cls: 'success' },
  off: { label: 'OFF', cls: 'secondary' },
  inherit: { label: 'Inherit', cls: 'info' },
}

const cellKey = (sportId, leagueKey, marketKey) => `${sportId}:${leagueKey}:${marketKey}`

function Commission() {
  const [loading, setLoading] = useState(true)
  const [sports, setSports] = useState([])
  const [markets, setMarkets] = useState([])
  const [maxPercent, setMaxPercent] = useState(50)
  const [defaultPercent, setDefaultPercent] = useState(2)
  const [search, setSearch] = useState('')
  const [onlyActive, setOnlyActive] = useState(false)
  const [openSport, setOpenSport] = useState(null)
  // sport_id -> league_key currently shown in that sport's tab strip
  const [openLeague, setOpenLeague] = useState({})
  const [saving, setSaving] = useState(false)
  // Draft edits keyed "<sportId>:<leagueKey>:<marketKey>" → { state, percent }.
  // Committed on Save only, so a half-typed number is never POSTed.
  const [drafts, setDrafts] = useState({})

  const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: false,
  })

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const response = await commissionConfigService.getSportsCommission()
      if (response.success) {
        setSports(response.sports || [])
        setMarkets(response.markets || [])
        setMaxPercent(response.max_percent || 50)
        setDefaultPercent(response.default_percent ?? 2)
        setDrafts({})
        setOpenSport((prev) => prev ?? (response.sports?.[0]?.sport_id ?? null))
      }
    } catch (error) {
      Toast.fire({ icon: 'error', title: error.response?.data?.error || error.message })
    } finally {
      setLoading(false)
    }
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => { load() }, [load])

  // ── draft helpers ─────────────────────────────────────────────────────────
  const savedRule = (sport, league, marketKey) =>
    league.rules?.[marketKey] || { state: 'off', percent: defaultPercent, inherited: null }

  const cellRule = (key, saved) => (drafts[key] !== undefined ? drafts[key] : saved)

  const isDirty = (key, saved) => {
    const d = drafts[key]
    if (d === undefined) return false
    return d.state !== saved.state || Number(d.percent) !== Number(saved.percent)
  }

  const setDraft = (key, saved, patch) =>
    setDrafts((prev) => ({ ...prev, [key]: { ...cellRule(key, saved), ...patch } }))

  const dirtyCount = useMemo(() => {
    let n = 0
    for (const sport of sports) {
      for (const league of sport.leagues || []) {
        for (const market of markets) {
          const key = cellKey(sport.sport_id, league.key, market.key)
          if (isDirty(key, savedRule(sport, league, market.key))) n += 1
        }
      }
    }
    return n
  }, [drafts, sports, markets]) // eslint-disable-line react-hooks/exhaustive-deps

  // What settlement will actually do for a cell, after inheritance.
  const effectiveOf = (rule) => {
    if (rule.state === 'inherit') {
      const inh = rule.inherited || { state: 'off', percent: defaultPercent }
      return { on: inh.state === 'on', percent: inh.percent }
    }
    return { on: rule.state === 'on', percent: rule.percent }
  }

  // ── persistence ───────────────────────────────────────────────────────────
  const saveAll = async () => {
    const items = []
    const resets = []
    for (const sport of sports) {
      for (const league of sport.leagues || []) {
        for (const market of markets) {
          const key = cellKey(sport.sport_id, league.key, market.key)
          const saved = savedRule(sport, league, market.key)
          if (!isDirty(key, saved)) continue
          const rule = cellRule(key, saved)
          const percent = Number(rule.percent)
          if (!Number.isFinite(percent) || percent < 0 || percent > maxPercent) {
            Toast.fire({ icon: 'error', title: `${sport.name} — ${market.label}: percent must be 0–${maxPercent}` })
            return
          }
          const payload = {
            sport_id: sport.sport_id,
            league_key: league.key,
            market_key: market.key,
          }
          // "Inherit" is the ABSENCE of a row, so it is a DELETE, not a save.
          if (rule.state === 'inherit') resets.push(payload)
          else items.push({ ...payload, enabled: rule.state === 'on', percent })
        }
      }
    }
    if (!items.length && !resets.length) return

    setSaving(true)
    try {
      for (const payload of resets) await commissionConfigService.resetSportsCommission(payload)
      if (items.length) await commissionConfigService.saveSportsCommissionBulk(items)
      Toast.fire({ icon: 'success', title: `Saved ${items.length + resets.length} cell(s)` })
      await load()
    } catch (error) {
      Toast.fire({ icon: 'error', title: error.response?.data?.error || error.message })
    } finally {
      setSaving(false)
    }
  }

  // Set every market of the shown league at once.
  const applyToLeague = (sport, league, state) => {
    setDrafts((prev) => {
      const next = { ...prev }
      for (const market of markets) {
        const key = cellKey(sport.sport_id, league.key, market.key)
        const saved = savedRule(sport, league, market.key)
        const current = next[key] !== undefined ? next[key] : saved
        next[key] = { ...current, state }
      }
      return next
    })
  }

  // ── filtering ─────────────────────────────────────────────────────────────
  const visibleSports = useMemo(() => {
    const term = search.trim().toLowerCase()
    let list = sports
    if (term) list = list.filter((s) => s.name.toLowerCase().includes(term))
    if (onlyActive) {
      list = list.filter((s) => (s.leagues || []).some((l) => l.active_count > 0))
    }
    return list
  }, [sports, search, onlyActive])

  const leagueOf = (sport) => {
    const wanted = openLeague[sport.sport_id]
    return (sport.leagues || []).find((l) => l.key === wanted) || sport.leagues?.[0]
  }

  // Short "what is ON" line for the collapsed sport header.
  const sportSummary = (sport) => {
    const parts = []
    for (const league of sport.leagues || []) {
      const on = markets
        .filter((m) => {
          const r = savedRule(sport, league, m.key)
          return effectiveOf(r).on
        })
        .map((m) => m.label)
      if (!on.length) continue
      const text = on.length > 2 ? `${on.slice(0, 2).join(', ')} +${on.length - 2}` : on.join(', ')
      parts.push(league.is_default ? text : `${league.label}: ${text}`)
    }
    return parts.length ? parts.join(' · ') : 'No commission'
  }

  const groupedMarkets = useMemo(() => {
    const groups = []
    for (const market of markets) {
      const last = groups[groups.length - 1]
      if (last && last.group === market.group) last.items.push(market)
      else groups.push({ group: market.group, items: [market] })
    }
    return groups
  }, [markets])

  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-12">
          <div className="page-title-box d-flex align-items-center justify-content-between">
            <h4 className="mb-0 font-size-18">Commission</h4>
            <div className="page-title-right">
              <ol className="breadcrumb m-0">
                <li className="breadcrumb-item"><Link to="/admin/home">Home</Link></li>
                <li className="breadcrumb-item active">Commission</li>
              </ol>
            </div>
          </div>
        </div>
      </div>

      <div className="row">
        <div className="col-12">
          <div className="card">
            <div className="card-body">
              <p className="text-muted font-size-12 mb-2">
                Commission is deducted from a user&apos;s <b>net win</b> on a settled market when the
                cell is ON, and shown in the account statement as a separate &quot;- Comm&quot; debit row.
                Losses are never charged. Maximum {maxPercent}%.
              </p>
              <p className="text-muted font-size-12 mb-3">
                <b>Match Odds</b> means only the market actually named Match Odds — Over/Under,
                Correct Score, Match Result and Inning EvenOdd sit under <b>Other Main Markets</b>.
                Cricket&apos;s <b>E-Cricket, T10 XI, T5 XI</b> and <b>Virtual Cricket League</b> have
                their own tabs: leave a cell on <b>Inherit</b> to follow the main sport, or set it
                ON/OFF to charge those leagues differently.
              </p>

              <div className="d-flex flex-wrap align-items-center mb-3" style={{ gap: 12 }}>
                <input
                  type="search"
                  className="form-control form-control-sm"
                  style={{ maxWidth: 260 }}
                  placeholder="Search sport…"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
                <div className="custom-control custom-checkbox">
                  <input
                    type="checkbox"
                    className="custom-control-input"
                    id="comm-only-active"
                    checked={onlyActive}
                    onChange={(e) => setOnlyActive(e.target.checked)}
                  />
                  <label className="custom-control-label" htmlFor="comm-only-active">
                    Only sports with commission ON
                  </label>
                </div>
                <div className="ml-auto d-flex align-items-center" style={{ gap: 8 }}>
                  {dirtyCount > 0 && (
                    <button
                      type="button"
                      className="btn btn-sm btn-light"
                      disabled={saving}
                      onClick={() => setDrafts({})}
                    >
                      Discard
                    </button>
                  )}
                  <button
                    type="button"
                    className="btn btn-sm btn-primary"
                    disabled={dirtyCount === 0 || saving}
                    onClick={saveAll}
                  >
                    {saving ? 'Saving…' : `Save changes${dirtyCount ? ` (${dirtyCount})` : ''}`}
                  </button>
                </div>
              </div>

              {loading ? (
                <div className="text-center p-4">Loading...</div>
              ) : visibleSports.length === 0 ? (
                <div className="text-center p-4 text-muted">no records found</div>
              ) : (
                <div className="accordion">
                  {visibleSports.map((sport) => {
                    const isOpen = openSport === sport.sport_id
                    const league = leagueOf(sport)
                    return (
                      <div className="card mb-2" key={sport.sport_id} style={{ border: '1px solid #eff2f7' }}>
                        <div
                          className="card-header bg-transparent d-flex align-items-center"
                          style={{ cursor: 'pointer', padding: '10px 14px' }}
                          onClick={() => setOpenSport(isOpen ? null : sport.sport_id)}
                        >
                          <i className={`mdi ${isOpen ? 'mdi-chevron-down' : 'mdi-chevron-right'} mr-2`} />
                          <span className="font-weight-medium">{sport.name}</span>
                          <small className="text-muted ml-1">#{sport.sport_id}</small>
                          {sport.enabled ? (
                            <span className="badge badge-soft-success ml-2">live</span>
                          ) : null}
                          {(sport.leagues || []).length > 1 && (
                            <span className="badge badge-soft-info ml-2">
                              {sport.leagues.length - 1} extra league{sport.leagues.length - 1 > 1 ? 's' : ''}
                            </span>
                          )}
                          <small className="text-muted ml-auto text-right" style={{ maxWidth: '55%' }}>
                            {sportSummary(sport)}
                          </small>
                        </div>

                        {isOpen && league && (
                          <div className="card-body" style={{ padding: '12px 14px' }}>
                            {/* League tab strip — 'default' plus the sport's variants */}
                            {(sport.leagues || []).length > 1 && (
                              <ul className="nav nav-pills mb-3" style={{ gap: 6 }}>
                                {sport.leagues.map((l) => (
                                  <li className="nav-item" key={l.key}>
                                    <button
                                      type="button"
                                      className={`nav-link btn btn-sm ${l.key === league.key ? 'active' : ''}`}
                                      onClick={() => setOpenLeague((p) => ({ ...p, [sport.sport_id]: l.key }))}
                                    >
                                      {l.label}
                                      {l.active_count > 0 && (
                                        <span className="badge badge-light ml-1">{l.active_count}</span>
                                      )}
                                    </button>
                                  </li>
                                ))}
                              </ul>
                            )}

                            <div className="d-flex flex-wrap align-items-center mb-2" style={{ gap: 8 }}>
                              <small className="text-muted">
                                {league.is_default
                                  ? 'Applies to every league of this sport that has no tab of its own.'
                                  : 'Cells on Inherit follow the main sport tab.'}
                              </small>
                              <div className="ml-auto btn-group btn-group-sm">
                                <button type="button" className="btn btn-outline-secondary"
                                  onClick={() => applyToLeague(sport, league, 'on')}>All ON</button>
                                <button type="button" className="btn btn-outline-secondary"
                                  onClick={() => applyToLeague(sport, league, 'off')}>All OFF</button>
                                {!league.is_default && (
                                  <button type="button" className="btn btn-outline-secondary"
                                    onClick={() => applyToLeague(sport, league, 'inherit')}>All Inherit</button>
                                )}
                              </div>
                            </div>

                            <div className="table-responsive">
                              <table className="table table-sm table-bordered mb-0">
                                <thead>
                                  <tr>
                                    <th style={{ minWidth: 230 }}>Market</th>
                                    <th style={{ width: 210 }} className="text-center">Commission</th>
                                    <th style={{ width: 130 }} className="text-center">Percent</th>
                                    <th style={{ minWidth: 190 }}>Effective</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {groupedMarkets.map((group) => (
                                    <Fragment key={`${league.key}-${group.group}`}>
                                      <tr className="bg-light">
                                        <td colSpan={4} className="font-weight-medium font-size-12 text-muted">
                                          {group.group}
                                        </td>
                                      </tr>
                                      {group.items.map((market) => {
                                        const key = cellKey(sport.sport_id, league.key, market.key)
                                        const saved = savedRule(sport, league, market.key)
                                        const rule = cellRule(key, saved)
                                        const dirty = isDirty(key, saved)
                                        const eff = effectiveOf(rule)
                                        const states = league.is_default
                                          ? ['on', 'off']
                                          : ['inherit', 'on', 'off']
                                        return (
                                          <tr key={key} className={dirty ? 'table-warning' : ''}>
                                            <td>
                                              <div>{market.label}</div>
                                              {market.hint && (
                                                <small className="text-muted font-size-11">{market.hint}</small>
                                              )}
                                            </td>
                                            <td className="text-center">
                                              <div className="btn-group btn-group-sm">
                                                {states.map((st) => (
                                                  <button
                                                    key={st}
                                                    type="button"
                                                    className={`btn btn-sm ${rule.state === st
                                                      ? `btn-${STATE_META[st].cls}`
                                                      : 'btn-outline-secondary'}`}
                                                    onClick={() => setDraft(key, saved, { state: st })}
                                                  >
                                                    {STATE_META[st].label}
                                                  </button>
                                                ))}
                                              </div>
                                            </td>
                                            <td className="text-center">
                                              <div className="d-flex align-items-center justify-content-center">
                                                <input
                                                  type="number"
                                                  min="0"
                                                  max={maxPercent}
                                                  step="0.5"
                                                  className="form-control form-control-sm"
                                                  style={{ maxWidth: 80 }}
                                                  disabled={rule.state !== 'on'}
                                                  value={rule.percent}
                                                  onChange={(e) => setDraft(key, saved, { percent: e.target.value })}
                                                />
                                                <span className="ml-1">%</span>
                                              </div>
                                            </td>
                                            <td>
                                              {eff.on ? (
                                                <span className="badge badge-soft-success">
                                                  charges {eff.percent}% of net win
                                                </span>
                                              ) : (
                                                <span className="badge badge-soft-secondary">no commission</span>
                                              )}
                                              {rule.state === 'inherit' && (
                                                <small className="text-muted d-block font-size-11">
                                                  following the main sport
                                                </small>
                                              )}
                                            </td>
                                          </tr>
                                        )
                                      })}
                                    </Fragment>
                                  ))}
                                </tbody>
                              </table>
                            </div>
                          </div>
                        )}
                      </div>
                    )
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Commission
