import { useState, useEffect } from 'react'
import Swal from 'sweetalert2'
import bettingConfigService from '../../services/bettingConfigService'

// Virtual Bet Limits — owner-only. Min / max stake per VIRTUAL league:
// cricket's Dim "(e)" e-cricket, T5 XI, T10 XI, Virtual Cricket League and
// wrestling's WWE Virtual. Those rounds rotate every few minutes, so the
// per-event Bet Limits screen can't reach them — this sets one limit for the
// whole league.
//
// 0 = not set: the feed's own limit (and the slip's normal floor) applies.
// A set value replaces the feed's for every market of that league, on the
// player's bet slip, on the "Min / Max" printed on the rows, and in the
// server's placeBet check. Server: controller/admin/bettingConfigController.js
// getVirtualLimits / saveVirtualLimits.

function VirtualBetLimits() {
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [rows, setRows] = useState([])

  const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: false,
  })

  const apply = (data) => {
    setRows((data || []).map((r) => ({
      ...r,
      min_stake: String(Number(r.min_stake) || 0),
      max_stake: String(Number(r.max_stake) || 0),
    })))
  }

  const load = async () => {
    setLoading(true)
    try {
      const response = await bettingConfigService.getVirtualLimits()
      if (response.success) apply(response.data)
    } catch (error) {
      Toast.fire({ icon: 'error', title: error.response?.data?.error || error.message })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
  }, [])

  const setField = (idx, field, value) => {
    setRows((prev) => prev.map((r, i) => (i === idx ? { ...r, [field]: value } : r)))
  }

  const handleSave = async (e) => {
    e.preventDefault()
    for (const r of rows) {
      const min = Number(r.min_stake)
      const max = Number(r.max_stake)
      if (!Number.isFinite(min) || min < 0 || !Number.isFinite(max) || max < 0) {
        Toast.fire({ icon: 'error', title: `${r.label}: Min and Max must be 0 or more` })
        return
      }
      if (min > 0 && max > 0 && min > max) {
        Toast.fire({ icon: 'error', title: `${r.label}: Min cannot be more than Max` })
        return
      }
    }

    setSaving(true)
    try {
      const response = await bettingConfigService.saveVirtualLimits({
        rows: rows.map((r) => ({
          sport_id: r.sport_id,
          league_key: r.league_key,
          min_stake: Number(r.min_stake) || 0,
          max_stake: Number(r.max_stake) || 0,
        })),
      })
      if (response.success) {
        apply(response.data)
        Toast.fire({ icon: 'success', title: response.message || 'Saved' })
      }
    } catch (error) {
      Toast.fire({ icon: 'error', title: error.response?.data?.error || error.message })
    } finally {
      setSaving(false)
    }
  }

  return (
    <div>
      <div className="row">
        <div className="col-12">
          <div className="page-title-box d-flex align-items-center justify-content-between">
            <h4 className="mb-0 font-size-18">Virtual Bet Limits</h4>
          </div>
        </div>
      </div>

      <div className="row">
        <div className="col-lg-8">
          <div className="card">
            <div className="card-body">
              <h5 className="card-title mb-3">Min / Max stake per virtual league</h5>

              {loading ? (
                <p className="text-muted mb-0">Loading…</p>
              ) : (
                <form onSubmit={handleSave}>
                  <div className="table-responsive">
                    <table className="table table-bordered mb-3">
                      <thead>
                        <tr>
                          <th>Sport</th>
                          <th>League</th>
                          <th style={{ width: 180 }}>Min Stake</th>
                          <th style={{ width: 180 }}>Max Stake</th>
                        </tr>
                      </thead>
                      <tbody>
                        {rows.map((r, idx) => (
                          <tr key={`${r.sport_id}:${r.league_key}`}>
                            <td>{r.sport_name}</td>
                            <td>{r.label}</td>
                            <td>
                              <input
                                type="number"
                                className="form-control"
                                min={0}
                                step={1}
                                value={r.min_stake}
                                onChange={(e) => setField(idx, 'min_stake', e.target.value)}
                              />
                            </td>
                            <td>
                              <input
                                type="number"
                                className="form-control"
                                min={0}
                                step={1}
                                value={r.max_stake}
                                onChange={(e) => setField(idx, 'max_stake', e.target.value)}
                              />
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <small className="form-text text-muted mb-3">
                    0 = not set: the feed&apos;s own limit applies. A value here replaces the
                    feed&apos;s limit for every market of that league (bet slip, the Min / Max shown
                    on the rows, and the server check). Players see the change within a minute.
                  </small>

                  <button type="submit" className="btn btn-primary" disabled={saving}>
                    {saving ? 'Saving…' : 'Save'}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default VirtualBetLimits
