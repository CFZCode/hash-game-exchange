import { Fragment, useState, useEffect, useMemo } from 'react'
import { Link } from 'react-router-dom'
import Swal from 'sweetalert2'
import bettingConfigService from '../../services/bettingConfigService'

// Max Odds — owner-only. A player's bet whose rate is ABOVE the value saved for
// its sport × league × market is refused with "Bet Not Accept Rate Over <max>
// on <Sport>". The bet slip checks it first and the server re-checks every bet.
//
// Match Odds = gtype 'match' (decimal odds, e.g. 1.85). Bookmaker = gtype
// 'match1', typed on the board's own scale (93 means 1.93). Fancy markets are
// never capped. 0 = no cap.
//
// League rows (same tabs as Settings → Commission): cricket's E-Cricket (Dim),
// T10 XI, T5 XI, Virtual Cricket League and wrestling's WWE Virtual sit under
// their sport. A league cell on INHERIT follows the sport's cap; "Own" gives
// that league its own cap (0 = no cap for that league).
//
// Cricket cells carry one extra condition, "Oneday & T20 only": Test matches
// are then exempt and the message reads "... on Oneday and T20".
// Plans: docs/plans/2026-09-11-football-rate-cap.md,
//        docs/plans/2026-09-15-buffer-maxodds-league-market-grid.md

const CATEGORY_LABELS = {
  match_odds: 'Match Odds',
  bookmaker: 'Bookmaker',
}

const EMPTY_RULE = { max_odds: 0, limited_overs_only: false }

const describe = (rule) => (Number(rule?.max_odds) > 0
  ? `max ${Number(rule.max_odds).toFixed(2)}${rule.limited_overs_only ? ' (Oneday & T20 only)' : ''}`
  : 'no limit')

function MaxOdds() {
  const [loading, setLoading] = useState(true)
  const [sports, setSports] = useState([])
  const [categories, setCategories] = useState(Object.keys(CATEGORY_LABELS))
  const [maxValue, setMaxValue] = useState(1000)
  const [limitedOversSportId, setLimitedOversSportId] = useState(4)
  const [search, setSearch] = useState('')
  const [savingKey, setSavingKey] = useState(null)
  // Draft edits keyed "<sportId>:<leagueKey>:<category>" →
  // { state, max_odds, limited_overs_only }. Committed on Save only, so a
  // half-typed number is never POSTed.
  const [drafts, setDrafts] = useState({})

  const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: false,
  })

  // silent: refresh after a save without flashing the table to "Loading...".
  const load = async ({ silent = false } = {}) => {
    if (!silent) setLoading(true)
    try {
      const response = await bettingConfigService.getSportsMaxOdds()
      if (response.success) {
        setSports(response.sports || [])
        setCategories(response.categories || categories)
        setMaxValue(response.max_value || 1000)
        setLimitedOversSportId(response.limited_overs_sport_id || 4)
      }
    } catch (error) {
      Toast.fire({ icon: 'error', title: error.response?.data?.error || error.message })
    } finally {
      if (!silent) setLoading(false)
    }
  }

  useEffect(() => {
    load()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const leaguesOf = (sport) => (sport.leagues?.length
    ? sport.leagues
    : [{ key: 'default', label: 'All other leagues', is_default: true, rules: sport.rules }])

  const savedRule = (league, category) => league.rules?.[category]
    || { state: league.is_default ? 'set' : 'inherit', ...EMPTY_RULE, inherited: EMPTY_RULE }
  const cellRule = (key, saved) => (drafts[key] !== undefined ? drafts[key] : saved)
  const isDirty = (key, saved) => {
    const d = drafts[key]
    if (d === undefined) return false
    if ((d.state || 'set') !== (saved.state || 'set')) return true
    if (d.state === 'inherit') return false
    return Number(d.max_odds) !== Number(saved.max_odds)
      || !!d.limited_overs_only !== !!saved.limited_overs_only
  }
  const setDraft = (key, saved, patch) =>
    setDrafts((prev) => ({ ...prev, [key]: { ...cellRule(key, saved), ...patch } }))
  const clearDraft = (key) => setDrafts((prev) => {
    const next = { ...prev }
    delete next[key]
    return next
  })

  const save = async (sport, league, category) => {
    const key = `${sport.sport_id}:${league.key}:${category}`
    const saved = savedRule(league, category)
    const rule = cellRule(key, saved)
    const label = `${sport.name}${league.is_default ? '' : ` / ${league.label}`} — ${CATEGORY_LABELS[category] || category}`

    setSavingKey(key)
    try {
      // "Inherit" is the ABSENCE of a row, so it is a DELETE, not a save.
      if (!league.is_default && rule.state === 'inherit') {
        const response = await bettingConfigService.resetSportsMaxOdds({
          sport_id: sport.sport_id,
          league_key: league.key,
          category,
        })
        if (response.success) {
          clearDraft(key)
          await load({ silent: true })
          Toast.fire({ icon: 'success', title: `${label}: follows ${sport.name}` })
        }
        return
      }

      const maxOdds = rule.max_odds === '' ? 0 : Number(rule.max_odds)
      if (!Number.isFinite(maxOdds) || maxOdds < 0 || maxOdds > maxValue) {
        Toast.fire({ icon: 'error', title: `Max odds must be between 0 and ${maxValue}` })
        return
      }

      const response = await bettingConfigService.saveSportsMaxOdds({
        sport_id: sport.sport_id,
        league_key: league.key,
        category,
        max_odds: maxOdds,
        limited_overs_only: sport.sport_id === limitedOversSportId && !!rule.limited_overs_only,
      })
      if (response.success) {
        clearDraft(key)
        // Reload: a main-row save changes what every inheriting league row shows.
        await load({ silent: true })
        Toast.fire({
          icon: 'success',
          title: `${label}: ${describe({
            max_odds: Number(response.max_odds) || 0,
            limited_overs_only: !!response.limited_overs_only,
          })}`,
        })
      }
    } catch (error) {
      Toast.fire({ icon: 'error', title: error.response?.data?.error || error.message })
    } finally {
      setSavingKey(null)
    }
  }

  // A league label matches too, so "t10" finds Cricket.
  const visibleSports = useMemo(() => {
    const term = search.trim().toLowerCase()
    if (!term) return sports
    return sports.filter((s) => s.name.toLowerCase().includes(term)
      || (s.leagues || []).some((l) => !l.is_default && l.label.toLowerCase().includes(term)))
  }, [sports, search])

  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-12">
          <div className="page-title-box d-flex align-items-center justify-content-between">
            <h4 className="mb-0 font-size-18">Max Odds</h4>
            <div className="page-title-right">
              <ol className="breadcrumb m-0">
                <li className="breadcrumb-item"><Link to="/admin/home">Home</Link></li>
                <li className="breadcrumb-item active">Max Odds</li>
              </ol>
            </div>
          </div>
        </div>
      </div>

      <div className="row">
        <div className="col-12">
          <div className="card">
            <div className="card-body">
              <p className="text-muted font-size-12 mb-2">
                A bet whose rate is <b>above</b> the saved value is refused with
                &quot;Bet Not Accept Rate Over 100.01 on Football&quot;. 0 = no limit.
                Bookmaker uses the board&apos;s own scale (93 means 1.93). Fancy markets are never limited.
                For Cricket, tick <b>Oneday &amp; T20 only</b> to exempt Test matches — the message
                then reads &quot;Bet Not Accept Rate Over 4.00 on Oneday and T20&quot;.
              </p>
              <p className="text-muted font-size-12 mb-3">
                Cricket&apos;s <b>E-Cricket (Dim), T10 XI, T5 XI</b> and <b>Virtual Cricket League</b> (and
                Wrestling&apos;s <b>WWE Virtual</b>) have their own rows under the sport. <b>Inherit</b> follows
                the sport&apos;s limit; <b>Own</b> sets a separate one for that league (0 = no limit there).
              </p>

              <div className="mb-3" style={{ maxWidth: 320 }}>
                <input
                  type="search"
                  className="form-control form-control-sm"
                  placeholder="Search sport or league…"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </div>

              {loading ? (
                <div className="text-center p-4">Loading...</div>
              ) : (
                <div className="table-responsive">
                  <table className="table table-sm table-bordered mb-0">
                    <thead>
                      <tr>
                        <th style={{ minWidth: 200 }}>Sport / League</th>
                        {categories.map((category) => (
                          <th key={category} className="text-center" style={{ minWidth: 260 }}>
                            {CATEGORY_LABELS[category] || category}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {visibleSports.length === 0 && (
                        <tr><td colSpan={categories.length + 1} className="text-center">no records found</td></tr>
                      )}
                      {visibleSports.map((sport) => {
                        const leagues = leaguesOf(sport)
                        return (
                          <Fragment key={sport.sport_id}>
                            {leagues.map((league) => (
                              <tr key={`${sport.sport_id}:${league.key}`} className={league.is_default ? '' : 'bg-light'}>
                                <td>
                                  {league.is_default ? (
                                    <>
                                      {sport.name}{' '}
                                      <small className="text-muted">#{sport.sport_id}</small>
                                      {sport.enabled ? (
                                        <span className="badge badge-soft-success ml-1">live</span>
                                      ) : null}
                                      {leagues.length > 1 && (
                                        <small className="text-muted d-block font-size-11">all other leagues</small>
                                      )}
                                    </>
                                  ) : (
                                    <span className="d-inline-block" style={{ paddingLeft: 16 }}>
                                      ↳ {league.label}
                                    </span>
                                  )}
                                </td>
                                {categories.map((category) => {
                                  const key = `${sport.sport_id}:${league.key}:${category}`
                                  const saved = savedRule(league, category)
                                  const rule = cellRule(key, saved)
                                  const inheriting = !league.is_default && rule.state === 'inherit'
                                  const dirty = isDirty(key, saved)
                                  return (
                                    <td key={category} className={dirty ? 'table-warning' : ''}>
                                      {!league.is_default && (
                                        <div className="btn-group btn-group-sm mb-1">
                                          <button
                                            type="button"
                                            className={`btn btn-sm ${inheriting ? 'btn-info' : 'btn-outline-secondary'}`}
                                            onClick={() => setDraft(key, saved, { state: 'inherit' })}
                                          >
                                            Inherit
                                          </button>
                                          <button
                                            type="button"
                                            className={`btn btn-sm ${inheriting ? 'btn-outline-secondary' : 'btn-primary'}`}
                                            onClick={() => {
                                              if (!inheriting) return
                                              setDraft(key, saved, {
                                                state: 'set',
                                                max_odds: saved.inherited?.max_odds ?? 0,
                                                limited_overs_only: !!saved.inherited?.limited_overs_only,
                                              })
                                            }}
                                          >
                                            Own
                                          </button>
                                        </div>
                                      )}
                                      {inheriting ? (
                                        <div className="d-flex align-items-center">
                                          <small className="text-muted mr-2">
                                            follows {sport.name}: {describe(saved.inherited)}
                                          </small>
                                          {dirty && (
                                            <button
                                              type="button"
                                              className="btn btn-sm btn-primary"
                                              disabled={savingKey === key}
                                              onClick={() => save(sport, league, category)}
                                            >
                                              {savingKey === key ? '…' : 'Save'}
                                            </button>
                                          )}
                                        </div>
                                      ) : (
                                        <>
                                          <div className="d-flex align-items-center">
                                            <input
                                              type="number"
                                              min="0"
                                              max={maxValue}
                                              step="0.01"
                                              className="form-control form-control-sm mr-2"
                                              style={{ maxWidth: 100 }}
                                              placeholder="0 = no limit"
                                              value={rule.max_odds}
                                              onChange={(e) => setDraft(key, saved, { state: 'set', max_odds: e.target.value })}
                                            />
                                            <button
                                              type="button"
                                              className="btn btn-sm btn-primary"
                                              disabled={!dirty || savingKey === key}
                                              onClick={() => save(sport, league, category)}
                                            >
                                              {savingKey === key ? '…' : 'Save'}
                                            </button>
                                          </div>
                                          {sport.sport_id === limitedOversSportId && (
                                            <div className="custom-control custom-checkbox mt-1">
                                              <input
                                                type="checkbox"
                                                className="custom-control-input"
                                                id={`maxodds-lo-${key}`}
                                                checked={!!rule.limited_overs_only}
                                                onChange={(e) => setDraft(key, saved, { state: 'set', limited_overs_only: e.target.checked })}
                                              />
                                              <label className="custom-control-label font-size-12" htmlFor={`maxodds-lo-${key}`}>
                                                Oneday &amp; T20 only (Test exempt)
                                              </label>
                                            </div>
                                          )}
                                        </>
                                      )}
                                    </td>
                                  )
                                })}
                              </tr>
                            ))}
                          </Fragment>
                        )
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default MaxOdds
