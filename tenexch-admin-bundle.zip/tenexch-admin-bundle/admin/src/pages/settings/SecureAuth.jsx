import { useState, useRef, useEffect } from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { useNavigate, Link } from 'react-router-dom'
import Swal from 'sweetalert2'
import secureAuthService from '../../services/secureAuthService'
import { authService } from '../../services/authService'
import { logout } from '../../store/slices/authSlice'
import LoaderOverlay from '../../components/LoaderOverlay'
import { bToastSuccess, bToastError } from '../../components/BToast'
import { SECURE_AUTH_TOAST as T } from '../../utils/secureAuthToastMessages'

// The reference gates the Google Auth panel on iOS exactly like this
// (admin bundle: `isIOS ? _e() : [label, <img QR>]` and `isIOS ? [note, steps]
// : _e()`): iPhone/iPad get the manual setup-code instructions INSTEAD of the
// QR, everyone else just gets the QR. Ours printed the note and the steps on
// every device, so a desktop operator saw an iPhone warning under a QR that
// worked fine.
const IS_IOS = typeof navigator !== 'undefined' && /iPhone|iPad|iPod/i.test(navigator.userAgent);

// Our own signed build (secure-auth-app/). The admin lives at tenexchn.com/admin,
// so this is the player site's copy (frontend/public/apk/) on the same origin —
// the vendor's APK only ever talked to the vendor's servers.
const APK_URL = '/apk/SecureAuthApp.apk'
const emptyOtp = () => new Array(6).fill('')

/**
 * The 6-box code input, in the reference's markup: a centred flex row, one
 * flex-centred div per box, `input.otp-input`. Sizing comes from the
 * `.login-auth input` rules (style.css) — callers wrap this in `.login-auth`,
 * so there is no inline styling here.
 *
 * Fires onComplete as soon as the last digit lands — no Verify button.
 */
function OtpBoxes({ value, onChange, onComplete, disabled }) {
  const refs = useRef([])

  const handleChange = (el, index) => {
    if (isNaN(el.value)) return
    const next = value.map((digit, i) => (i === index ? el.value : digit))
    onChange(next)
    if (el.value && index < 5) refs.current[index + 1]?.focus()
    if (next.every((digit) => digit !== '')) onComplete(next.join(''))
  }

  const handleKeyDown = (e, index) => {
    if (e.key === 'Backspace' && !value[index] && index > 0) refs.current[index - 1]?.focus()
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'center' }}>
      <div style={{ display: 'flex' }}>
        {value.map((digit, index) => (
          <div key={index} style={{ display: 'flex', alignItems: 'center' }}>
            <input
              min="0"
              max="9"
              maxLength={1}
              pattern="[0-9]"
              type="tel"
              className="otp-input"
              inputMode="numeric"
              autoComplete="off"
              value={digit}
              ref={(el) => { refs.current[index] = el }}
              onChange={(e) => handleChange(e.target, index)}
              onKeyDown={(e) => handleKeyDown(e, index)}
              onFocus={(e) => e.target.select()}
              disabled={disabled}
              autoFocus={index === 0}
            />
          </div>
        ))}
      </div>
    </div>
  )
}

/**
 * The bot handle is set by the owner under Secure Auth Bot. If it has not been
 * configured yet, say so instead of rendering a dead "@undefined" link.
 */
function TelegramBotLink({ link }) {
  if (!link?.botUsername) {
    return <span className="text-warning">(bot not configured — set it in Secure Auth Bot first)</span>
  }
  // `?start` is what the reference links to — it makes Telegram pre-fill the
  // /start command the instructions below ask for. The server returns the plain
  // t.me link (shared with the player page), so the suffix is added here.
  return (
    <a target="_blank" rel="noopener noreferrer" href={`${link.botLink}?start`} className="text-primary">
      @{link.botUsername}
    </a>
  )
}

/**
 * The logged-in owner/staff turning secure auth on or off for THEIR OWN login.
 *
 * Not to be confused with Secure Auth Bot (`/admin/settings/secureauthbot`),
 * which is the owner configuring WHICH bot delivers the codes.
 *
 * All three methods talk to a backend. The Mobile App tab shows a server
 * PAIRING code; the Secure Auth app redeems it (with username + password),
 * which switches secure auth on server-side and ends this session.
 */
function SecureAuth() {
  // No tab is opened until the operator picks one
  const [activeTab, setActiveTab] = useState(null)
  const [isLoading, setIsLoading] = useState(false)

  // Mobile App tab — a new server pairing code on every visit to the tab
  const [mobileAuthCode, setMobileAuthCode] = useState('')
  const [pairExpiresAt, setPairExpiresAt] = useState(0)
  // Opening the Mobile App tab shows the loader overlay for ~1s. The FIRST time
  // the pane is empty underneath it (reference: `.text-center` holds only the
  // two v-if placeholders); once it has resolved the content stays, so a later
  // re-open shows the overlay on top of the already-rendered block.
  const [tabLoading, setTabLoading] = useState(false)
  const [mobileLoaded, setMobileLoaded] = useState(false)

  // Telegram tab
  const [password, setPassword] = useState('')
  const [telegramLink, setTelegramLink] = useState(null) // { code, botUsername, botLink }

  // Google Auth tab
  const [googlePassword, setGooglePassword] = useState('')
  const [googleSetup, setGoogleSetup] = useState(null) // { qrCode, secret }
  const [googleOtp, setGoogleOtp] = useState(emptyOtp)

  // Disable flow (shown after clicking the Enabled badge)
  const [showDisableInput, setShowDisableInput] = useState(false)
  const [otp, setOtp] = useState(emptyOtp)

  const user = useSelector((state) => state.auth.user)
  const role = useSelector((state) => state.auth.role)
  const dispatch = useDispatch()
  const navigate = useNavigate()

  // securityAuthType is the source of truth ('telegram' | 'google' | 'android' | null);
  // telegram2FAEnabled is the fallback for a profile from before that column.
  const authType = user?.securityAuthType || (user?.telegram2FAEnabled ? 'telegram' : null)
  const isEnabled = !!authType

  /**
   * Read the logged-in account's profile straight from the API.
   *
   * Deliberately NOT useProfileRefresh(): for an owner session that hook short
   * circuits to `return user` whenever the profile socket is live, handing back
   * the CACHED user — so the linked flag never changed and this page waited for
   * ever. Its REST branch also reads `res.data.user`, which is the STAFF shape;
   * an owner profile sits at `res.data` (App.jsx picks the shape the same way).
   */
  const fetchProfile = async () => {
    const isOwner = role === 'owner'
    const res = isOwner ? await authService.getOwnerProfile() : await authService.getProfile()
    return isOwner ? res?.data : res?.data?.user
  }

  const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: false,
  })

  /**
   * Enabling or disabling changes how this account logs in, so the session ends
   * and the operator comes back through the login flow — which now asks for the
   * Telegram code (staffAuthService/ownerAuthService already branch on
   * telegram2FAEnabled).
   */
  const endSession = () => {
    dispatch(logout())
    navigate('/admin', { replace: true })
  }

  /**
   * Linking completes on Telegram's side — the bot calls the webhook, so this
   * page never hears about it. Poll the profile while the instructions are on
   * screen and end the session the moment the account flips to linked.
   *
   * Stops on success, on unmount, and after the link code's 10-minute lifetime
   * (pendingCodes in telegram2faController expires at exactly that).
   */
  useEffect(() => {
    if (!telegramLink) return undefined

    let stopped = false
    const startedAt = Date.now()
    const LINK_CODE_TTL_MS = 10 * 60 * 1000

    const interval = setInterval(async () => {
      if (Date.now() - startedAt > LINK_CODE_TTL_MS) {
        clearInterval(interval)
        return
      }
      try {
        const profile = await fetchProfile()
        if (stopped) return
        if (profile?.telegram2FAEnabled || profile?.securityAuthType) {
          clearInterval(interval)
          Toast.fire({ icon: 'success', title: T.ENABLED })
          endSession()
        }
      } catch {
        // A blip should not abort the wait — the next tick retries.
      }
    }, 3000)

    return () => {
      stopped = true
      clearInterval(interval)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [telegramLink])

  /**
   * Pairing completes on the PHONE, so this page never hears about it either.
   * While a pairing code is on screen, poll the profile the same way as the
   * Telegram wait above. Normally the server's forceLogout push (or the 401
   * from the rotated login_id) gets there first — this is the fallback.
   */
  useEffect(() => {
    if (activeTab !== 'mobile' || !mobileAuthCode) return undefined

    let stopped = false
    const interval = setInterval(async () => {
      try {
        const profile = await fetchProfile()
        if (stopped) return
        if (profile?.securityAuthType || profile?.telegram2FAEnabled) {
          clearInterval(interval)
          Toast.fire({ icon: 'success', title: T.ENABLED })
          endSession()
        }
      } catch {
        // A blip should not abort the wait — the next tick retries.
      }
    }, 3000)

    return () => {
      stopped = true
      clearInterval(interval)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab, mobileAuthCode])

  const handleTabClick = (tab) => {
    // A new pairing code every time the Mobile App tab is opened, with the
    // loader over it for a beat — Telegram/Google open instantly.
    if (tab === 'mobile') setTabLoading(true)
    setActiveTab(tab)
  }

  // Mobile App tab: fetch the pairing code. The loader stays at least ~1s
  // (reference timing); that same tick reveals the content on the first visit.
  useEffect(() => {
    if (!tabLoading || activeTab !== 'mobile') return undefined
    let cancelled = false
    const minWait = new Promise((resolve) => setTimeout(resolve, 1000))
    ;(async () => {
      try {
        const [data] = await Promise.all([secureAuthService.selfAndroidPair(), minWait])
        if (cancelled) return
        setMobileAuthCode(data.code)
        setPairExpiresAt(Date.now() + (data.expiresIn || 600) * 1000)
      } catch (error) {
        await minWait
        if (cancelled) return
        setMobileAuthCode('')
        Toast.fire({ icon: 'error', title: error?.response?.data?.error || error.message })
      } finally {
        if (!cancelled) {
          setTabLoading(false)
          setMobileLoaded(true)
        }
      }
    })()
    return () => { cancelled = true }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tabLoading, activeTab])

  // A pairing code lives 10 minutes server-side — swap in a fresh one when it
  // runs out, so a tab left open never shows a code the app would refuse.
  useEffect(() => {
    if (activeTab !== 'mobile' || !mobileAuthCode || !pairExpiresAt) return undefined
    const t = setTimeout(() => setTabLoading(true), Math.max(0, pairExpiresAt - Date.now()))
    return () => clearTimeout(t)
  }, [activeTab, mobileAuthCode, pairExpiresAt])

  const handleGetConnectionId = async () => {
    if (!password) {
      Toast.fire({ icon: 'error', title: T.PASSWORD_REQUIRED })
      return
    }
    setIsLoading(true)
    try {
      await secureAuthService.selfVerifyPassword(password)
      const data = await secureAuthService.selfGetLinkCode()
      setTelegramLink({ code: data.code, botUsername: data.botUsername, botLink: data.botLink })
      Toast.fire({ icon: 'success', title: T.CONNECTION_ID_GENERATED })
    } catch (error) {
      Toast.fire({
        icon: 'error',
        title: error?.response?.data?.error || error.message || T.CONNECTION_ID_FAILED,
      })
    } finally {
      setIsLoading(false)
    }
  }

  // ── Google Authenticator ──────────────────────────────────────────────────
  const handleGoogleSetup = async () => {
    if (!googlePassword) {
      Toast.fire({ icon: 'error', title: T.PASSWORD_REQUIRED })
      return
    }
    setIsLoading(true)
    try {
      const data = await secureAuthService.selfGoogleSetup(googlePassword)
      setGoogleSetup({ qrCode: data.qrCode, secret: data.secret })
      setGoogleOtp(emptyOtp())
      Toast.fire({ icon: 'success', title: T.GOOGLE_PASSWORD_VERIFIED })
    } catch (error) {
      Toast.fire({
        icon: 'error',
        title: error?.response?.data?.error || error.message || T.GOOGLE_SETUP_FAILED,
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleGoogleEnable = async (code) => {
    if (code.length !== 6) return
    setIsLoading(true)
    try {
      await secureAuthService.selfGoogleEnable(code)
      Toast.fire({ icon: 'success', title: T.ENABLED })
      endSession()
    } catch (error) {
      Toast.fire({
        icon: 'error',
        title: error?.response?.data?.error || error.message || T.GOOGLE_INVALID_CODE,
      })
      setGoogleOtp(emptyOtp())
    } finally {
      setIsLoading(false)
    }
  }

  // The reference renders THIS one as a b-toast (top-center, `.toast-body`),
  // not as the SweetAlert toast the rest of the page uses.
  const handleCopySecret = async () => {
    const secret = googleSetup?.secret || ''
    if (!secret) return

    // `navigator.clipboard` exists only in a SECURE context (https, or
    // localhost). Opened over plain http on a LAN ip — how this panel is
    // tested on a phone — it is undefined and this always failed with
    // "Could not copy…" (same bug the player site had, 2026-09-20). Fall back
    // to a hidden textarea + execCommand.
    try {
      if (window.isSecureContext && navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(secret)
        bToastSuccess(T.GOOGLE_SECRET_COPIED)
        return
      }
    } catch {
      // fall through
    }

    try {
      const ta = document.createElement('textarea')
      ta.value = secret
      ta.setAttribute('readonly', '')
      ta.style.position = 'fixed'
      ta.style.top = '0'
      ta.style.left = '0'
      ta.style.opacity = '0'
      ta.style.fontSize = '16px'
      document.body.appendChild(ta)

      const selection = document.getSelection()
      const previous = selection.rangeCount > 0 ? selection.getRangeAt(0) : null

      ta.contentEditable = 'true'
      ta.readOnly = false
      const range = document.createRange()
      range.selectNodeContents(ta)
      selection.removeAllRanges()
      selection.addRange(range)
      ta.setSelectionRange(0, secret.length)

      const ok = document.execCommand('copy')
      document.body.removeChild(ta)
      if (previous) { selection.removeAllRanges(); selection.addRange(previous) }

      if (ok) bToastSuccess(T.GOOGLE_SECRET_COPIED)
      else bToastError(T.GOOGLE_SECRET_COPY_FAILED)
    } catch {
      bToastError(T.GOOGLE_SECRET_COPY_FAILED)
    }
  }

  const handleEnabledClick = async () => {
    // Google / Secure Auth app codes come from the app — nothing to send,
    // just ask for one.
    if (authType === 'google' || authType === 'android') {
      setOtp(emptyOtp())
      setShowDisableInput(true)
      return
    }

    setIsLoading(true)
    try {
      await secureAuthService.selfSendDisableCode()
      setOtp(emptyOtp())
      setShowDisableInput(true)
      Toast.fire({ icon: 'success', title: T.DISABLE_CODE_SENT })
    } catch (error) {
      Toast.fire({
        icon: 'error',
        title: error?.response?.data?.error || error.message || T.DISABLE_CODE_SEND_FAILED,
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleDisable = async (code) => {
    if (code.length !== 6) return
    setIsLoading(true)
    try {
      if (authType === 'google') await secureAuthService.selfGoogleDisable(code)
      else if (authType === 'android') await secureAuthService.selfAndroidDisable(code)
      else await secureAuthService.selfDisable(code)
      setShowDisableInput(false)
      // The toast lives on document.body (Swal's own container), so it survives
      // the logout + redirect and is still on screen at /admin.
      Toast.fire({ icon: 'success', title: T.DISABLE_SUCCESS })
      endSession()
    } catch (error) {
      const serverMsg = error?.response?.data?.error || error.message || ''
      // Telegram: the disable code expires after 5 minutes. Show "User Not
      // Remove" rather than the server's expiry wording — the operator only
      // needs to know the account is still protected.
      const expired = authType === 'telegram' && /expired|not requested/i.test(serverMsg)
      Toast.fire({
        icon: 'error',
        title: expired ? T.DISABLE_EXPIRED : (serverMsg || T.DISABLE_FAILED),
      })
      setOtp(emptyOtp())
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="security-auth">
      <div className="row">
        <div className="col-12">
          <div className="page-title-box d-flex align-items-center justify-content-between">
            <h4 className="mb-0 font-size-18">Secure Auth Verification</h4>
            <div className="page-title-right">
              <ol className="breadcrumb m-0">
                <li className="breadcrumb-item"><Link to="/admin/home">Home</Link></li>
                <li className="breadcrumb-item active">Secure Auth</li>
              </ol>
            </div>
          </div>
        </div>
      </div>

      <div>
        <div className="card-body">
          <div className="text-center">
            <b>Secure Auth Verification Status:</b>{' '}
            {/* The reference renders Enabled two different ways, and the two
                dumps differ exactly where the method does: a TELEGRAM account
                gets the btn-success anchor (with the "click here to disable"
                title), a GOOGLE one gets the success badge. Both are clickable
                — `pointer` on the badge says so. */}
            {isEnabled && authType === 'google' && (
              <span
                className="badge badge-success pointer p-2"
                role="button"
                tabIndex={0}
                onClick={handleEnabledClick}
              >
                Enabled
              </span>
            )}
            {isEnabled && authType !== 'google' ? (
              // `href="#"` + preventDefault rather than the reference's
              // `javascript:void(0)` — React rewrites that into its blocked-URL
              // error string.
              <a
                href="#"
                title="Click here to disable secure auth verification"
                className="btn btn-success"
                onClick={(e) => { e.preventDefault(); handleEnabledClick() }}
              >
                Enabled
              </a>
            ) : null}
            {!isEnabled && (
              <span className="badge badge-danger p-2">Disabled</span>
            )}
          </div>

          {/* Enabled: the method tabs disappear, but the tab-content shell
              stays. Its empty telegram pane is what carries the loader while
              the disable code is being sent, and the disable form arrives as a
              SECOND pane beside it — not inside the status block above (that is
              where the player page puts it; the admin one does not). */}
          {isEnabled && (
            <div className="tab-content mt-4">
              {/* Telegram only: the google dump shows tab-content with no pane
                  at all, because there is no code to send and so nothing for
                  the loader to sit on. */}
              {authType === 'telegram' && (
                <div className={`tab-pane telegram active${isLoading ? ' loader-section-parent' : ''}`}>
                  {isLoading && <LoaderOverlay />}
                </div>
              )}
              {showDisableInput && (
                <div className="tab-pane active">
                  <div className="mt-2 mb-3 login-auth">
                    <h3 className="text-center">Security Code Verification</h3>{' '}
                    <div className="mt-3 text-center">
                      {authType === 'google'
                        ? 'Enter 6-digit code from your security google auth verification App'
                        : 'Enter 6-digit code from your security auth verification App'}
                    </div>{' '}
                    <form role="form" autoComplete="off" method="post" className="mt-3" onSubmit={(e) => e.preventDefault()}>
                      <OtpBoxes
                        value={otp}
                        onChange={setOtp}
                        onComplete={handleDisable}
                        disabled={isLoading}
                      />
                    </form>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Not enabled: pick a method */}
          {!isEnabled && (
            <>
              <div className="mt-2 text-center">
                Please select below option to enable secure auth verification
              </div>

              <div className="casino-report-tabs mt-3">
                <ul className="nav nav-tabs">
                  <li className="nav-item pointer">
                    <a
                      className={`nav-link${activeTab === 'mobile' ? ' active' : ''}`}
                      onClick={() => handleTabClick('mobile')}
                    >
                      Enable Using Mobile App
                    </a>
                  </li>
                  <li className="nav-item pointer">
                    <a
                      className={`nav-link${activeTab === 'telegram' ? ' active' : ''}`}
                      onClick={() => handleTabClick('telegram')}
                    >
                      Enable Using Telegram
                    </a>
                  </li>
                  <li className="nav-item pointer">
                    <a
                      className={`nav-link${activeTab === 'google' ? ' active' : ''}`}
                      onClick={() => handleTabClick('google')}
                    >
                      Enable Using Google Auth
                    </a>
                  </li>
                </ul>
              </div>

              <div className="tab-content mt-4">
                {activeTab === 'mobile' && (
                  // Reference stamps `loader-section-parent` on the pane and
                  // puts the spinner over it. On the FIRST open `.text-center`
                  // is still empty underneath; from the second open on, the
                  // content is already there and the overlay sits on top of it.
                  <div className={`tab-pane mobile-app active${tabLoading ? ' loader-section-parent' : ''}`}>
                    {tabLoading && <LoaderOverlay />}
                    <div className="text-center">
                      {mobileLoaded && (
                        <>
                          <div className="mt-3">
                            Please enter below auth code in your &apos;Secure Auth Verification App&apos;.
                          </div>
                          <div className="mt-3">
                            <div className="verify-code">{mobileAuthCode}</div>
                          </div>
                          <div className="mt-3">
                            <b>If you haven&apos;t downloaded,<br />please download &apos;Secure Auth Verification App&apos; from below link.</b>
                          </div>
                          <div className="mt-3">
                            Using this app you will receive auth code during login authentication
                          </div>
                          <div className="mt-3">
                            <a href={APK_URL}>
                              <button className="btn btn-primary">
                                <i className="fab fa-android"></i> <span>Download on the Android</span>
                              </button>
                            </a>
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                )}

                {activeTab === 'telegram' && (
                  // The `<!---->` the reference shows first inside this pane is
                  // its loader slot — the overlay goes up while Get Connection
                  // ID is in flight, with the form still rendered underneath.
                  <div className={`tab-pane telegram active${isLoading ? ' loader-section-parent' : ''}`}>
                    {isLoading && <LoaderOverlay />}
                    {/* The password form STAYS on screen after the connection
                        id lands; the instructions panel is appended below it
                        inside the same text-center block. */}
                    <div className="text-center">
                      <b>Please enter your login password to continue</b>{' '}
                      <div className="form-group mt-3 secure-password">
                        <input
                          type="password"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          placeholder="Enter your login password"
                          className="form-control"
                          autoComplete="current-password"
                          onKeyDown={(e) => e.key === 'Enter' && handleGetConnectionId()}
                        />{' '}
                        <button
                          className="btn btn-primary ml-2 vt"
                          onClick={handleGetConnectionId}
                          disabled={isLoading}
                        >
                          Get Connection ID
                        </button>
                      </div>{' '}
                      {telegramLink && (
                        // Plain `mt-3` here — the player page wraps this in
                        // `follow-instruction` (dark panel), the admin one does
                        // not. Wording is the reference's verbatim, "veriication"
                        // typo and "website account" included.
                        <div className="mt-3">
                          <b>Please follow below instructions for the telegram 2-step verification</b>{' '}
                          <p>
                            Find <TelegramBotLink link={telegramLink} /> in your telegram and type{' '}
                            <kbd>/start</kbd> command. Bot will respond you.
                          </p>{' '}
                          <p className="text-dark">
                            After this type <kbd>/connect {telegramLink.code}</kbd> and send it to BOT.
                          </p>{' '}
                          <p>
                            Now your telegram account will be linked with your website account and
                            2-Step veriication will be enabled.
                          </p>{' '}
                          <hr />
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {activeTab === 'google' && (
                  // The reference stamps `telegram` on this pane too — it is the
                  // same shell, only the body differs.
                  <div className={`tab-pane telegram active${isLoading ? ' loader-section-parent' : ''}`}>
                    {isLoading && <LoaderOverlay />}
                    <div className="text-center">
                      <b>Please enter your login password to continue</b>{' '}
                      <div className="form-group mt-3 secure-password">
                        <input
                          type="password"
                          value={googlePassword}
                          onChange={(e) => setGooglePassword(e.target.value)}
                          placeholder="Enter your login password"
                          className="form-control"
                          autoComplete="current-password"
                          onKeyDown={(e) => e.key === 'Enter' && handleGoogleSetup()}
                        />{' '}
                        <button
                          className="btn btn-primary ml-2 vt"
                          onClick={handleGoogleSetup}
                          disabled={isLoading}
                        >
                          Submit
                        </button>
                      </div>{' '}
                      {googleSetup && (
                        <>
                          <div className="mt-3">
                            {/* Not iOS: the QR is the whole story. */}
                            {!IS_IOS && googleSetup.qrCode && (
                              <>
                                <h6 className="mb-3"><b>Scan this QR code in Google Authenticator</b></h6>
                                <img
                                  src={googleSetup.qrCode}
                                  alt="Google Auth QR Code"
                                  className="img-fluid"
                                  style={{ maxWidth: '220px' }}
                                />{' '}
                              </>
                            )}
                            {/* iOS only: the warning + the manual steps that
                                point at the setup code below. */}
                            {IS_IOS && (
                              <>
                                <p className="p-2">
                                  <b className="text-danger">
                                    For security reasons, QR setup may not be available on
                                    iPhone. Please use the setup code below to add Google
                                    Authenticator manually.
                                  </b>
                                </p>{' '}
                                <div className="google-code-instructions">
                                  <p><b>Steps to set it up:</b></p>
                                  <p>1. Open the Google Authenticator app.</p>
                                  <p>2. Tap the Add (+) icon.</p>
                                  <p>3. Select Enter a setup key.</p>
                                  <p>4. Enter the setup code displayed on your screen.</p>
                                  <p>5. Enter a name for the account.</p>
                                  <p>6. Tap Add.</p>
                                </div>{' '}
                              </>
                            )}
                            <div className="mt-3"><b>Setup Code:</b></div>{' '}
                            <div className="mt-2 p-2 google-setup-code">
                              <span>
                                {googleSetup.secret}
                                <i
                                  className="fas fa-copy ml-1"
                                  style={{ cursor: 'pointer' }}
                                  title="Copy setup code"
                                  onClick={handleCopySecret}
                                ></i>
                              </span>
                            </div>
                          </div>{' '}
                          <div className="tab-pane active">
                            <div className="mt-2 mb-3 login-auth">
                              <h3 className="text-center">Security Code Verification</h3>{' '}
                              <div className="mt-3 text-center">
                                Enter 6-digit code from your security google auth verification App
                              </div>{' '}
                              <form role="form" autoComplete="off" method="post" className="mt-3" onSubmit={(e) => e.preventDefault()}>
                                <OtpBoxes
                                  value={googleOtp}
                                  onChange={setGoogleOtp}
                                  onComplete={handleGoogleEnable}
                                  disabled={isLoading}
                                />
                              </form>
                            </div>
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}

export default SecureAuth
