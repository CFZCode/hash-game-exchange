import { Fragment, useState, useEffect, useMemo } from 'react'
import { Link } from 'react-router-dom'
import Swal from 'sweetalert2'
import bettingConfigService from '../../services/bettingConfigService'

// Bet Limits — owner-only min / max stake overrides.
//
// Sports tab: every live and upcoming event from the feed; expand one to see
// its markets with the limits the FEED quotes (shown as "default") next to the
// override inputs. Leave a box empty to keep the feed's number for that side.
//
// Casino tab: the same, per game, for every Our / VIP / Virtual / Premium
// table.
//
// Nothing saved = nothing changes: the site keeps using the feed's own limits.
// Whatever is saved here is shown in the player's bet slip AND enforced by the
// API when the bet is placed.

const TABS = [
  { id: 'sports', label: 'Sports' },
  { id: 'casino', label: 'Casino' },
]

const CASINO_CATEGORY_LABELS = {
  our: 'Our Casino',
  vip: 'VIP',
  virtual: 'Virtual',
  premium: 'Premium',
}

// '' / null render as an empty box (= not overridden).
const boxValue = (value) => (value === null || value === undefined ? '' : String(value))

function BetLimits() {
  const [activeTab, setActiveTab] = useState('sports')
  // Sub-tab inside each main tab: '' = show everything. Both filter the list
  // that is ALREADY loaded, so switching is instant and costs no request.
  const [sportTab, setSportTab] = useState('')
  const [casinoTab, setCasinoTab] = useState('')
  const [search, setSearch] = useState('')

  const [events, setEvents] = useState([])
  const [eventsLoading, setEventsLoading] = useState(true)
  const [openEvent, setOpenEvent] = useState(null)   // the expanded event object
  const [markets, setMarkets] = useState([])
  const [marketsLoading, setMarketsLoading] = useState(false)

  const [games, setGames] = useState([])
  const [gamesLoading, setGamesLoading] = useState(false)

  // Draft edits keyed "<market_id>" / "casino:<game_name>" → { min, max }.
  const [drafts, setDrafts] = useState({})
  const [savingKey, setSavingKey] = useState(null)

  const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: false,
  })

  const errorToast = (error) =>
    Toast.fire({ icon: 'error', title: error.response?.data?.error || error.message })

  // ── Sports ──
  const loadEvents = async () => {
    setEventsLoading(true)
    setOpenEvent(null)
    setMarkets([])
    try {
      // Every sport in one call — the sport tabs below are built from what
      // comes back, so they always match what is actually on the board.
      const response = await bettingConfigService.getInplayEvents()
      if (response.success) setEvents(response.events || [])
    } catch (error) {
      errorToast(error)
    } finally {
      setEventsLoading(false)
    }
  }

  useEffect(() => {
    if (activeTab === 'sports') loadEvents()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab])

  const openMarkets = async (event) => {
    if (openEvent?.event_id === event.event_id) {
      setOpenEvent(null)
      setMarkets([])
      return
    }
    setOpenEvent(event)
    setMarkets([])
    setDrafts({})
    setMarketsLoading(true)
    try {
      const response = await bettingConfigService.getEventMarkets(event.event_id, event.sport_id)
      if (response.success) setMarkets(response.markets || [])
    } catch (error) {
      errorToast(error)
    } finally {
      setMarketsLoading(false)
    }
  }

  const saveMarket = async (market) => {
    const draft = drafts[market.market_id] || {}
    const key = market.market_id
    setSavingKey(key)
    try {
      const response = await bettingConfigService.saveEventLimit({
        sport_id: openEvent?.sport_id,
        event_id: openEvent?.event_id,
        event_name: openEvent?.event_name,
        market_id: market.market_id,
        market_name: market.market_name,
        gtype: market.gtype,
        min_stake: draft.min !== undefined ? draft.min : boxValue(market.min_stake),
        max_stake: draft.max !== undefined ? draft.max : boxValue(market.max_stake),
      })
      if (response.success) {
        const saved = response.override || {}
        setMarkets((prev) => prev.map((m) => (m.market_id === market.market_id
          ? {
              ...m,
              override_id: saved.id ?? m.override_id,
              min_stake: saved.min_stake != null ? Number(saved.min_stake) : null,
              max_stake: saved.max_stake != null ? Number(saved.max_stake) : null,
            }
          : m)))
        setDrafts((prev) => {
          const next = { ...prev }
          delete next[key]
          return next
        })
        Toast.fire({ icon: 'success', title: `${market.market_name || 'Market'} limits saved` })
      }
    } catch (error) {
      errorToast(error)
    } finally {
      setSavingKey(null)
    }
  }

  const resetMarket = async (market) => {
    if (!market.override_id) return
    setSavingKey(market.market_id)
    try {
      const response = await bettingConfigService.deleteEventLimit(market.override_id)
      if (response.success) {
        setMarkets((prev) => prev.map((m) => (m.market_id === market.market_id
          ? { ...m, override_id: null, min_stake: null, max_stake: null }
          : m)))
        Toast.fire({ icon: 'success', title: 'Back to feed default' })
      }
    } catch (error) {
      errorToast(error)
    } finally {
      setSavingKey(null)
    }
  }

  // ── Casino ──
  const loadGames = async () => {
    setGamesLoading(true)
    try {
      const response = await bettingConfigService.getCasinoLimits()
      if (response.success) setGames(response.games || [])
    } catch (error) {
      errorToast(error)
    } finally {
      setGamesLoading(false)
    }
  }

  useEffect(() => {
    if (activeTab === 'casino') {
      loadGames()
      setDrafts({})
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab])

  const saveGame = async (game) => {
    const key = `casino:${game.game_name}`
    const draft = drafts[key] || {}
    setSavingKey(key)
    try {
      const response = await bettingConfigService.saveCasinoLimit({
        game_name: game.game_name,
        min_stake: draft.min !== undefined ? draft.min : boxValue(game.min_stake),
        max_stake: draft.max !== undefined ? draft.max : boxValue(game.max_stake),
      })
      if (response.success) {
        const saved = response.override || {}
        setGames((prev) => prev.map((g) => (g.game_name === game.game_name
          ? {
              ...g,
              override_id: saved.id ?? g.override_id,
              min_stake: saved.min_stake != null ? Number(saved.min_stake) : null,
              max_stake: saved.max_stake != null ? Number(saved.max_stake) : null,
            }
          : g)))
        setDrafts((prev) => {
          const next = { ...prev }
          delete next[key]
          return next
        })
        Toast.fire({ icon: 'success', title: `${game.name} limits saved` })
      }
    } catch (error) {
      errorToast(error)
    } finally {
      setSavingKey(null)
    }
  }

  const resetGame = async (game) => {
    if (!game.override_id) return
    const key = `casino:${game.game_name}`
    setSavingKey(key)
    try {
      const response = await bettingConfigService.deleteCasinoLimit(game.override_id)
      if (response.success) {
        setGames((prev) => prev.map((g) => (g.game_name === game.game_name
          ? { ...g, override_id: null, min_stake: null, max_stake: null }
          : g)))
        Toast.fire({ icon: 'success', title: 'Back to feed default' })
      }
    } catch (error) {
      errorToast(error)
    } finally {
      setSavingKey(null)
    }
  }

  const setDraft = (key, side, value) =>
    setDrafts((prev) => ({ ...prev, [key]: { ...(prev[key] || {}), [side]: value } }))

  // Sport tabs are built from the events actually on the board — a sport with
  // nothing running never shows up, so the strip stays short instead of
  // listing all 40 sports. Busiest sport first; live events decide the order
  // because that is what an owner is usually looking for.
  const sportTabs = useMemo(() => {
    const counts = new Map()
    for (const event of events) {
      const id = String(event.sport_id)
      const held = counts.get(id) || { id, name: event.sport_name, count: 0, live: 0 }
      held.count += 1
      if (event.inplay) held.live += 1
      counts.set(id, held)
    }
    return [...counts.values()].sort((a, b) => b.live - a.live || b.count - a.count)
  }, [events])

  const casinoTabs = useMemo(() => {
    const counts = new Map()
    for (const game of games) {
      const id = game.category || 'our'
      counts.set(id, (counts.get(id) || 0) + 1)
    }
    return ['our', 'vip', 'virtual', 'premium']
      .filter((id) => counts.has(id))
      .map((id) => ({ id, label: CASINO_CATEGORY_LABELS[id] || id, count: counts.get(id) }))
  }, [games])

  const visibleEvents = useMemo(() => {
    const term = search.trim().toLowerCase()
    return events.filter((e) => {
      if (sportTab && String(e.sport_id) !== sportTab) return false
      if (!term) return true
      return (e.event_name || '').toLowerCase().includes(term)
        || (e.competition || '').toLowerCase().includes(term)
        || String(e.event_id).includes(term)
    })
  }, [events, search, sportTab])

  const visibleGames = useMemo(() => {
    const term = search.trim().toLowerCase()
    return games.filter((g) => {
      if (casinoTab && (g.category || 'our') !== casinoTab) return false
      if (!term) return true
      return g.name.toLowerCase().includes(term) || g.game_name.includes(term)
    })
  }, [games, search, casinoTab])

  // Collapsing the open event when the sport tab changes stops a market table
  // from hanging under a list it no longer belongs to.
  const selectSportTab = (id) => {
    setSportTab(id)
    setOpenEvent(null)
    setMarkets([])
  }

  // One horizontal strip, scrollable on mobile so it never wraps into the table.
  const TabStrip = ({ tabs, active, onSelect, allLabel, allCount }) => (
    <div className="mb-3" style={{ overflowX: 'auto' }}>
      <ul className="nav nav-pills flex-nowrap" style={{ whiteSpace: 'nowrap' }}>
        <li className="nav-item">
          <a
            href="javascript:void(0)"
            className={`nav-link py-1 px-2 ${active === '' ? 'active' : ''}`}
            onClick={() => onSelect('')}
          >
            {allLabel} <span className="badge badge-light ml-1">{allCount}</span>
          </a>
        </li>
        {tabs.map((tab) => (
          <li className="nav-item" key={tab.id}>
            <a
              href="javascript:void(0)"
              className={`nav-link py-1 px-2 ${active === tab.id ? 'active' : ''}`}
              onClick={() => onSelect(tab.id)}
            >
              {tab.label || tab.name}
              <span className="badge badge-light ml-1">{tab.count}</span>
            </a>
          </li>
        ))}
      </ul>
    </div>
  )

  const limitCell = (key, side, saved, placeholder) => (
    <input
      type="number"
      min="0"
      step="1"
      className="form-control form-control-sm"
      style={{ maxWidth: 110 }}
      placeholder={placeholder}
      value={drafts[key]?.[side] !== undefined ? drafts[key][side] : boxValue(saved)}
      onChange={(e) => setDraft(key, side, e.target.value)}
    />
  )

  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-12">
          <div className="page-title-box d-flex align-items-center justify-content-between">
            <h4 className="mb-0 font-size-18">Bet Limits</h4>
            <div className="page-title-right">
              <ol className="breadcrumb m-0">
                <li className="breadcrumb-item"><Link to="/admin/home">Home</Link></li>
                <li className="breadcrumb-item active">Bet Limits</li>
              </ol>
            </div>
          </div>
        </div>
      </div>

      <div className="row">
        <div className="col-12">
          <div className="card">
            <div className="card-body">
              <ul className="nav nav-tabs nav-tabs-custom mb-3">
                {TABS.map((tab) => (
                  <li className="nav-item" key={tab.id}>
                    <a
                      href="javascript:void(0)"
                      className={`nav-link ${activeTab === tab.id ? 'active' : ''}`}
                      onClick={() => { setActiveTab(tab.id); setSearch(''); setSportTab(''); setCasinoTab('') }}
                    >
                      {tab.label}
                    </a>
                  </li>
                ))}
              </ul>

              <p className="text-muted font-size-12 mb-3">
                Leave a box empty to keep the value the live feed quotes for that side.
                Saved limits show in the player&apos;s bet slip and are enforced when the bet
                is placed. A match&apos;s limits are cleared automatically a few minutes after
                the match finishes; casino limits stay until you change them.
              </p>

              {/* Sport / category strip — filters the loaded list, no refetch */}
              {activeTab === 'sports' ? (
                <TabStrip
                  tabs={sportTabs}
                  active={sportTab}
                  onSelect={selectSportTab}
                  allLabel="All sports"
                  allCount={events.length}
                />
              ) : (
                <TabStrip
                  tabs={casinoTabs}
                  active={casinoTab}
                  onSelect={setCasinoTab}
                  allLabel="All games"
                  allCount={games.length}
                />
              )}

              <div className="d-flex flex-wrap mb-3" style={{ gap: '0.5rem' }}>
                <input
                  type="search"
                  className="form-control form-control-sm"
                  style={{ maxWidth: 320 }}
                  placeholder={activeTab === 'sports' ? 'Search match…' : 'Search game…'}
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
                {activeTab === 'sports' && (
                  <button type="button" className="btn btn-sm btn-secondary" onClick={loadEvents}>
                    Refresh
                  </button>
                )}
              </div>

              {activeTab === 'sports' ? (
                eventsLoading ? (
                  <div className="text-center p-4">Loading...</div>
                ) : (
                  <div className="table-responsive">
                    <table className="table table-sm table-bordered mb-0">
                      <thead>
                        <tr>
                          <th style={{ minWidth: 260 }}>Match</th>
                          <th style={{ minWidth: 120 }}>Sport</th>
                          <th style={{ minWidth: 90 }}>Status</th>
                          <th style={{ minWidth: 120 }}>Limits</th>
                        </tr>
                      </thead>
                      <tbody>
                        {visibleEvents.length === 0 && (
                          <tr><td colSpan="4" className="text-center">no records found</td></tr>
                        )}
                        {visibleEvents.map((event) => (
                          <Fragment key={event.event_id}>
                            <tr style={{ cursor: 'pointer' }} onClick={() => openMarkets(event)}>
                              <td>
                                <i className={`mdi mdi-chevron-${openEvent?.event_id === event.event_id ? 'down' : 'right'} mr-1`}></i>
                                {event.event_name || `#${event.event_id}`}
                                {event.competition ? <small className="text-muted d-block">{event.competition}</small> : null}
                              </td>
                              <td>{event.sport_name}</td>
                              <td>
                                {event.inplay
                                  ? <span className="badge badge-soft-danger">LIVE</span>
                                  : <span className="badge badge-soft-secondary">upcoming</span>}
                              </td>
                              <td>
                                {event.has_overrides
                                  ? <span className="badge badge-soft-success">set</span>
                                  : <span className="text-muted">default</span>}
                              </td>
                            </tr>
                            {openEvent?.event_id === event.event_id && (
                              <tr>
                                <td colSpan="4" className="bg-light">
                                  {marketsLoading ? (
                                    <div className="text-center p-3">Loading markets...</div>
                                  ) : markets.length === 0 ? (
                                    <div className="text-center p-3">no markets in the feed for this match</div>
                                  ) : (
                                    <table className="table table-sm table-bordered mb-0 bg-white">
                                      <thead>
                                        <tr>
                                          <th style={{ minWidth: 220 }}>Market</th>
                                          <th style={{ minWidth: 110 }}>Type</th>
                                          <th style={{ minWidth: 140 }}>Feed default</th>
                                          <th style={{ minWidth: 120 }}>Min</th>
                                          <th style={{ minWidth: 120 }}>Max</th>
                                          <th style={{ minWidth: 150 }}></th>
                                        </tr>
                                      </thead>
                                      <tbody>
                                        {markets.map((market) => (
                                          <tr key={market.market_id}>
                                            <td>
                                              {market.market_name || `#${market.market_id}`}
                                              <small className="text-muted d-block">{market.market_id}</small>
                                            </td>
                                            <td>
                                              {market.gtype || '—'}
                                              <small className="text-muted d-block">{market.category}</small>
                                            </td>
                                            <td className="text-muted">
                                              {market.feed_min || 0} – {market.feed_max || 0}
                                            </td>
                                            <td>{limitCell(market.market_id, 'min', market.min_stake, String(market.feed_min || 0))}</td>
                                            <td>{limitCell(market.market_id, 'max', market.max_stake, String(market.feed_max || 0))}</td>
                                            <td>
                                              <button
                                                type="button"
                                                className="btn btn-sm btn-primary mr-1"
                                                disabled={savingKey === market.market_id}
                                                onClick={() => saveMarket(market)}
                                              >
                                                {savingKey === market.market_id ? '…' : 'Save'}
                                              </button>
                                              <button
                                                type="button"
                                                className="btn btn-sm btn-outline-secondary"
                                                disabled={!market.override_id || savingKey === market.market_id}
                                                onClick={() => resetMarket(market)}
                                              >
                                                Reset
                                              </button>
                                            </td>
                                          </tr>
                                        ))}
                                      </tbody>
                                    </table>
                                  )}
                                </td>
                              </tr>
                            )}
                          </Fragment>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )
              ) : gamesLoading ? (
                <div className="text-center p-4">Loading...</div>
              ) : (
                <div className="table-responsive">
                  <table className="table table-sm table-bordered mb-0">
                    <thead>
                      <tr>
                        <th style={{ minWidth: 220 }}>Game</th>
                        <th style={{ minWidth: 120 }}>Category</th>
                        <th style={{ minWidth: 120 }}>Min</th>
                        <th style={{ minWidth: 120 }}>Max</th>
                        <th style={{ minWidth: 150 }}></th>
                      </tr>
                    </thead>
                    <tbody>
                      {visibleGames.length === 0 && (
                        <tr><td colSpan="5" className="text-center">no records found</td></tr>
                      )}
                      {visibleGames.map((game) => {
                        const key = `casino:${game.game_name}`
                        return (
                          <tr key={game.game_name}>
                            <td>{game.name} <code className="ml-1">{game.game_name}</code></td>
                            <td>{CASINO_CATEGORY_LABELS[game.category] || game.category}</td>
                            <td>{limitCell(key, 'min', game.min_stake, 'feed')}</td>
                            <td>{limitCell(key, 'max', game.max_stake, 'feed')}</td>
                            <td>
                              <button
                                type="button"
                                className="btn btn-sm btn-primary mr-1"
                                disabled={savingKey === key}
                                onClick={() => saveGame(game)}
                              >
                                {savingKey === key ? '…' : 'Save'}
                              </button>
                              <button
                                type="button"
                                className="btn btn-sm btn-outline-secondary"
                                disabled={!game.override_id || savingKey === key}
                                onClick={() => resetGame(game)}
                              >
                                Reset
                              </button>
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default BetLimits
