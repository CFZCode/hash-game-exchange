import { useState, useEffect, useCallback } from 'react'
import { Link } from 'react-router-dom'
import Swal from 'sweetalert2'
import thirdPartyLimitService from '../../services/thirdPartyLimitService'
import Pagination from '../../components/Pagination'

// Third Party Game Limit — owner-only max stake for third-party (JS) games.
//
// The number you set on an account becomes the DEFAULT for everything below
// it: a master's limit applies to his sub-agents and all of their users, with
// nothing to copy per user. Set a different number lower down and that
// sub-tree follows the nearer one instead. 0 clears a row, so that account
// goes back to following whatever is set above it. Nothing set anywhere = no
// limit.
//
// The cap is per SINGLE bet, checked by the server on every JS-game bet
// callback. It never blocks a callback that pays a player out.

const money = (value) => Number(value || 0).toLocaleString('en-IN')

function ThirdPartyGameLimit() {
  // Drill-down trail. [0] is always the owner; pushing a staff shows that
  // staff's own direct children.
  const [trail, setTrail] = useState([{ type: 'OWNER', id: null, username: 'My hierarchy' }])
  const current = trail[trail.length - 1]

  const [parent, setParent] = useState(null)   // the node the list hangs off
  const [rows, setRows] = useState([])
  const [pagination, setPagination] = useState({ page: 1, totalPages: 1, total: 0 })
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(1)
  const [search, setSearch] = useState('')
  const [appliedSearch, setAppliedSearch] = useState('')

  // Draft edits keyed "<HOLDER_TYPE>:<id>" so a staff and a user can never
  // collide on the same id.
  const [drafts, setDrafts] = useState({})
  const [savingKey, setSavingKey] = useState(null)

  const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: false,
  })

  const errorToast = (error) =>
    Toast.fire({
      icon: 'error',
      title: error.response?.data?.message || error.message || 'Something went wrong',
    })

  const rowKey = (row) => `${row.holder_type}:${row.holder_id}`

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const response = await thirdPartyLimitService.getList({
        page,
        search: appliedSearch,
        parentId: current.type === 'STAFF' ? current.id : null,
      })
      if (response.success) {
        setParent(response.parent || null)
        setRows(response.data || [])
        setPagination(response.pagination || { page: 1, totalPages: 1, total: 0 })
        setDrafts({})
      }
    } catch (error) {
      errorToast(error)
    } finally {
      setLoading(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page, appliedSearch, current.type, current.id])

  useEffect(() => { load() }, [load])

  const setDraft = (key, value) => setDrafts((prev) => ({ ...prev, [key]: value }))

  const save = async (holderType, holderId, key, label) => {
    const raw = drafts[key]
    const amount = Number(raw === '' || raw === undefined ? 0 : raw)
    if (!Number.isFinite(amount) || amount < 0) {
      Toast.fire({ icon: 'error', title: 'Enter 0 or a positive amount' })
      return
    }

    setSavingKey(key)
    try {
      const response = await thirdPartyLimitService.setLimit({
        holder_type: holderType,
        holder_id: holderId,
        max_amount: amount,
      })
      if (response.success) {
        Toast.fire({
          icon: 'success',
          title: amount > 0
            ? `${label}: ${money(amount)} per bet — applies to everyone below too`
            : `${label}: limit cleared, now follows the limit set above`,
        })
        await load()
      }
    } catch (error) {
      errorToast(error)
    } finally {
      setSavingKey(null)
    }
  }

  const openStaff = (row) => {
    setTrail((prev) => [...prev, { type: 'STAFF', id: row.holder_id, username: row.username }])
    setPage(1)
    setSearch('')
    setAppliedSearch('')
  }

  const jumpTo = (index) => {
    if (index === trail.length - 1) return
    setTrail((prev) => prev.slice(0, index + 1))
    setPage(1)
    setSearch('')
    setAppliedSearch('')
  }

  const applySearch = (event) => {
    event.preventDefault()
    setPage(1)
    setAppliedSearch(search.trim())
  }

  // The box at the top: the limit on the node we are currently inside, i.e.
  // "everyone in this list, unless a row below says otherwise".
  const parentKey = parent ? `${parent.type}:${parent.id}` : 'parent'
  const parentDraft = drafts[parentKey] !== undefined
    ? drafts[parentKey]
    : (parent?.own_limit ? String(parent.own_limit) : '')

  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-12">
          <div className="page-title-box d-flex align-items-center justify-content-between">
            <h4 className="mb-0 font-size-18">Third Party Game Limit</h4>
            <div className="page-title-right">
              <ol className="breadcrumb m-0">
                <li className="breadcrumb-item"><Link to="/admin/home">Home</Link></li>
                <li className="breadcrumb-item active">Third Party Game Limit</li>
              </ol>
            </div>
          </div>
        </div>
      </div>

      <div className="row">
        <div className="col-12">
          <div className="card">
            <div className="card-body">
              <p className="text-muted font-size-12 mb-3">
                Max stake for <strong>one</strong> third-party (JS / slot / live casino) bet.
                Whatever you set on an account becomes the limit for that account
                <strong> and everyone under it</strong> — sub-agents and their users included,
                new accounts too. Set a different amount lower down and that part of the
                hierarchy follows the nearer amount. <strong>0 = no limit</strong>, and saving 0
                on a row clears it so the row goes back to following the limit set above it.
              </p>

              {/* Where am I in the hierarchy */}
              <nav className="mb-3">
                <ol className="breadcrumb bg-light p-2 mb-0">
                  {trail.map((node, index) => (
                    <li
                      key={`${node.type}-${node.id ?? 'root'}`}
                      className={`breadcrumb-item${index === trail.length - 1 ? ' active' : ''}`}
                    >
                      {index === trail.length - 1 ? (
                        node.username
                      ) : (
                        <a href="javascript:void(0)" onClick={() => jumpTo(index)}>{node.username}</a>
                      )}
                    </li>
                  ))}
                </ol>
              </nav>

              {/* Limit for the whole level we are looking at */}
              {parent && (
                <div className="card border mb-3">
                  <div className="card-body py-2">
                    <div className="d-flex flex-wrap align-items-center" style={{ gap: '0.75rem' }}>
                      <div>
                        <div className="font-weight-bold">
                          {parent.type === 'OWNER' ? 'Limit for my whole hierarchy' : `Limit for ${parent.username} and everyone below`}
                        </div>
                        <small className="text-muted">
                          {parent.own_limit > 0
                            ? `Currently ${money(parent.own_limit)} per bet`
                            : parent.effective_limit > 0
                              ? `Nothing set here — following ${money(parent.effective_limit)} from above`
                              : 'Nothing set — no limit'}
                        </small>
                      </div>
                      <input
                        type="number"
                        min="0"
                        step="1"
                        className="form-control form-control-sm"
                        style={{ maxWidth: 160 }}
                        placeholder="0 = no limit"
                        value={parentDraft}
                        onChange={(e) => setDraft(parentKey, e.target.value)}
                      />
                      <button
                        type="button"
                        className="btn btn-sm btn-primary"
                        disabled={savingKey === parentKey}
                        onClick={() => save(parent.type, parent.id, parentKey, parent.username)}
                      >
                        {savingKey === parentKey ? '…' : 'Save'}
                      </button>
                    </div>
                  </div>
                </div>
              )}

              <form className="d-flex flex-wrap mb-3" style={{ gap: '0.5rem' }} onSubmit={applySearch}>
                <input
                  type="search"
                  className="form-control form-control-sm"
                  style={{ maxWidth: 320 }}
                  placeholder="Search username…"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
                <button type="submit" className="btn btn-sm btn-secondary">Search</button>
                {appliedSearch && (
                  <button
                    type="button"
                    className="btn btn-sm btn-outline-secondary"
                    onClick={() => { setSearch(''); setAppliedSearch(''); setPage(1) }}
                  >
                    Clear
                  </button>
                )}
              </form>

              {loading ? (
                <div className="text-center p-4">Loading...</div>
              ) : (
                <div className="table-responsive">
                  <table className="table table-sm table-bordered mb-0">
                    <thead>
                      <tr>
                        <th style={{ minWidth: 200 }}>Username</th>
                        <th style={{ minWidth: 120 }}>Role</th>
                        <th style={{ minWidth: 150 }}>Max amount per bet</th>
                        <th style={{ minWidth: 170 }}>In force now</th>
                        <th style={{ minWidth: 120 }}></th>
                      </tr>
                    </thead>
                    <tbody>
                      {rows.length === 0 && (
                        <tr><td colSpan="5" className="text-center">no records found</td></tr>
                      )}
                      {rows.map((row) => {
                        const key = rowKey(row)
                        const draft = drafts[key] !== undefined
                          ? drafts[key]
                          : (row.own_limit ? String(row.own_limit) : '')
                        return (
                          <tr key={key}>
                            <td>
                              {row.holder_type === 'STAFF' ? (
                                <a href="javascript:void(0)" onClick={() => openStaff(row)}>
                                  <i className="mdi mdi-chevron-right mr-1"></i>{row.username}
                                </a>
                              ) : (
                                row.username
                              )}
                              {!row.active && <span className="badge badge-soft-secondary ml-1">inactive</span>}
                            </td>
                            <td>{row.role}</td>
                            <td>
                              <input
                                type="number"
                                min="0"
                                step="1"
                                className="form-control form-control-sm"
                                style={{ maxWidth: 140 }}
                                placeholder="0 = no limit"
                                value={draft}
                                onChange={(e) => setDraft(key, e.target.value)}
                              />
                            </td>
                            <td>
                              {row.effective_limit > 0 ? (
                                <>
                                  {money(row.effective_limit)}
                                  {row.inherited
                                    ? <span className="badge badge-soft-secondary ml-1">inherited</span>
                                    : <span className="badge badge-soft-success ml-1">set here</span>}
                                </>
                              ) : (
                                <span className="text-muted">no limit</span>
                              )}
                            </td>
                            <td>
                              <button
                                type="button"
                                className="btn btn-sm btn-primary"
                                disabled={savingKey === key}
                                onClick={() => save(row.holder_type, row.holder_id, key, row.username)}
                              >
                                {savingKey === key ? '…' : 'Save'}
                              </button>
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                </div>
              )}

              {pagination.totalPages > 1 && (
                <div className="d-flex align-items-center justify-content-end mt-3" style={{ gap: '0.5rem' }}>
                  <span className="text-muted font-size-12">
                    Page {pagination.page} / {pagination.totalPages} ({pagination.total} accounts)
                  </span>
                  {/* Shared block (components/Pagination) — was a Prev/Next pair. */}
                  <Pagination
                    currentPage={page}
                    totalPages={pagination.totalPages}
                    onPageChange={setPage}
                    wrap={false}
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default ThirdPartyGameLimit
