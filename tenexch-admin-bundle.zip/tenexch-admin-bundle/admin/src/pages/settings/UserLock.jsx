import { useState, useEffect, useRef, useCallback, Fragment } from 'react'
import { Link } from 'react-router-dom'
import api, { searchByUsername, getSportsTree, getMatchPrivateData } from '../../services/api'
import Swal from 'sweetalert2'
import ClientMultiselect from '../../components/ClientMultiselect'
import Collapse from '../../components/Collapse'
import { shapeSportsTree } from '../../utils/sportsTreeShape'
import { orderCasinoRows } from '../../data/casinoLockOrder'
import LoaderOverlay from '../../components/LoaderOverlay'

const Toast = Swal.mixin({
  toast: true,
  position: 'top-end',
  showConfirmButton: false,
  timer: 3000,
  timerProgressBar: false,
})

/* One level of the Events tree: the reference's
 *   <ul id="menu-…" data-parent="#…" class="sub-menu collapse [show]">
 * opened and closed with Bootstrap's height slide (.collapsing, .35s — the rule
 * is in styles/app.css, the four-step dance is components/Collapse.jsx, the same
 * one the Rules modal and the sidebar use). The reference drives it with
 * Bootstrap's own JS (data-toggle="collapse"); flipping `show` from React, which
 * is what this page did, snaps the branch open with no slide at all.
 *
 * The rows are built by `render()` only while the branch is open or still
 * sliding shut: the feed has hundreds of series and matches (racing alone is
 * 300+ rows), so a closed branch stays empty — but it must not empty itself the
 * instant it is told to close, or there would be nothing left to slide. */
const BRANCH_LINGER_MS = 450 // a little past .collapsing's .35s

function TreeBranch({ open, render, ...ulProps }) {
  const [linger, setLinger] = useState(open)
  useEffect(() => {
    if (open) { setLinger(true); return undefined }
    const t = setTimeout(() => setLinger(false), BRANCH_LINGER_MS)
    return () => clearTimeout(t)
  }, [open])
  return (
    <Collapse as="ul" open={open} {...ulProps}>
      {open || linger ? render() : null}
    </Collapse>
  )
}

// Market-group headings under a match, read off the reference's page DOM
// (2026-09-21): "Match", "Match1", "Fancy", then "oddeven", "khado", "fancy1",
// "meter" exactly as the feed's gtype spells them — and in this order.
const MARKET_GROUP_ORDER = ['match', 'match1', 'fancy', 'oddeven', 'khado', 'fancy1', 'meter']
const MARKET_GROUP_TITLES = { match: 'Match', match1: 'Match1', fancy: 'Fancy' }

// Shown only when the verify request dies before the server can answer —
// the server's message always wins.
const TXN_FALLBACK = 'Invalid transaction password'

function UserLock() {
  const [clientName, setClientName] = useState('')
  const [targetUser, setTargetUser] = useState(null)
  const [transactionCode, setTransactionCode] = useState('')
  const [verifiedPassword, setVerifiedPassword] = useState('')
  const [verified, setVerified] = useState(false)
  const [loadingVerify, setLoadingVerify] = useState(false)
  const [busy, setBusy] = useState(false)

  const [sportsTree, setSportsTree] = useState([])
  const [casinoList, setCasinoList] = useState([])
  // ONE open branch per parent — the reference's data-parent accordion: opening
  // Cricket shuts Politics, opening a match shuts the match open beside it
  // (recording, 2026-09-21). Keyed by the parent group; a branch that is not the
  // group's value is closed. A closed sport keeps its own children's state, as
  // Bootstrap does, so reopening it shows the league that was open inside.
  const [expanded, setExpanded] = useState({})
  // Bootstrap marks a trigger `collapsed` once its branch has been open and is
  // shut again; a trigger that was never used carries no such class.
  const [everOpened, setEverOpened] = useState(() => new Set())
  const [lockedIds, setLockedIds] = useState(new Set())
  const [matchCache, setMatchCache] = useState({}) // gmid → market groups
  // the league order this page has already shown — see utils/sportsTreeShape
  const seriesOrderRef = useRef(new Map())

  const loadEventsAndCasino = async () => {
    try {
      const res = await getSportsTree()
      // API shape: { success, data: { data: { data: { t1: [...], t2: [...] } } } }
      // getSportsTree already returns response.data, so drill 2 more levels.
      let node = res
      while (node && node.data && !node.t1 && !node.t2) node = node.data
      const t1 = node?.t1 || []
      const t2 = node?.t2 || []
      /* Same ORDER as the reference's tree, which is also the sidebar's
         (utils/sportsTreeShape): racing after Tennis, races under their
         country and alphabetical, leagues in the held reference order, and
         — read off the reference's General Lock DOM — matches alphabetical
         inside every league. This page used to show `[...t1, ...t2]` as it
         came: racing last, races with no country level, everything else in
         whatever order the feed had shuffled it into that minute. */
      setSportsTree(shapeSportsTree(t1, t2, seriesOrderRef.current, { sortMatches: true }))
    } catch (err) {
      console.error('Error loading sports tree:', err)
    }

    try {
      const listRes = await api.get('/admin/table-casino/list')
      if (listRes.data?.success) {
        // reference order (data/casinoLockOrder) — the API sends the DB rows
        // with no ORDER BY, i.e. insertion order, not the reference's list
        setCasinoList(orderCasinoRows(listRes.data.data).map((g) => ({ ...g, isLocked: false })))
      }
    } catch (err) {
      console.error('Error loading casino list:', err)
    }
  }

  const loadUserLocks = async (userId, userRole) => {
    try {
      const isUser = userRole === 'USER'
      const type = isUser ? 'USER' : 'OTHER'
      const res = await api.get(`/admin/table-casino/locks/${userId}`, { params: { type } })
      if (res.data?.success) {
        const locks = res.data.data || []
        const lockMap = new Map(locks.map((l) => [l.table_casino_id, l.is_locked]))
        setCasinoList((prev) => prev.map((g) => ({ ...g, isLocked: lockMap.get(g.id) || false })))
      }
    } catch (err) {
      console.error('Error fetching locks:', err)
    }

    try {
      const sportsType = userRole === 'USER' ? 'USER' : userRole === 'OWNER' ? 'OWNER' : 'STAFF'
      const res = await api.get(`/admin/sports-lock/get/${userId}`, { params: { type: sportsType } })
      if (res.data?.success) {
        const locks = res.data.data || []
        const ids = new Set()
        for (const l of locks) {
          if (!l.is_locked) continue
          let key = ''
          if (l.sport_id) key += String(l.sport_id)
          if (l.series_id) key += String(l.series_id)
          if (l.match_id) key += String(l.match_id)
          if (l.market_id) key += String(l.market_id)
          if (key) ids.add(key)
        }
        setLockedIds(ids)
      }
    } catch (err) {
      console.error('Error fetching sports locks:', err)
    }
  }

  const sportsTargetType = (role) =>
    role === 'USER' ? 'USER' : role === 'OWNER' ? 'OWNER' : 'STAFF'

  const saveSportsLock = async ({ sportId, seriesId, matchId, marketId, isLocked }) => {
    const targetType = sportsTargetType(targetUser?.role)
    const lockType = marketId ? 'MARKET' : matchId ? 'MATCH' : seriesId ? 'SERIES' : 'SPORT'
    const res = await api.post('/admin/sports-lock/update', {
      targetId: targetUser.id,
      targetType,
      sportId,
      seriesId: seriesId || null,
      matchId: matchId || null,
      marketId: marketId || null,
      isLocked,
      lockType,
    })
    if (!res.data?.success) throw new Error(res.data?.message || 'Save failed')
  }

  const handleSportsTreeToggle = async ({ key, sportId, seriesId, matchId, marketId }) => {
    if (!targetUser) return
    const wasLocked = lockedIds.has(key)
    setLockedIds((prev) => {
      const s = new Set(prev)
      if (wasLocked) s.delete(key); else s.add(key)
      return s
    })
    setBusy(true)
    try {
      await saveSportsLock({ sportId, seriesId, matchId, marketId, isLocked: !wasLocked })
    } catch (err) {
      setLockedIds((prev) => {
        const s = new Set(prev)
        if (wasLocked) s.add(key); else s.delete(key)
        return s
      })
      Toast.fire({
        icon: 'error',
        text: err?.response?.data?.message || err.message || 'Failed to update lock',
      })
    } finally {
      setBusy(false)
    }
  }

  const isOpen = (group, key) => expanded[group] === key
  const toggleExpand = (group, key) => {
    setExpanded((prev) => ({ ...prev, [group]: prev[group] === key ? null : key }))
    setEverOpened((prev) => (prev.has(key) ? prev : new Set(prev).add(key)))
  }
  const arrowClass = (group, key) => `arrow-icon${everOpened.has(key) && !isOpen(group, key) ? ' collapsed' : ''}`

  const toggleLock = (id) => {
    setLockedIds((prev) => {
      const s = new Set(prev)
      if (s.has(id)) s.delete(id)
      else s.add(id)
      return s
    })
  }

  const loadMatchMarkets = useCallback(async (gmid, sportsId) => {
    if (matchCache[gmid]) return
    try {
      const res = await getMatchPrivateData(gmid, sportsId)
      let markets = []
      const d = res
      if (d && d.data && d.data.data && Array.isArray(d.data.data)) markets = d.data.data
      else if (d && d.data && Array.isArray(d.data)) markets = d.data
      else if (Array.isArray(d)) markets = d
      else if (d && d.data && d.data.mid) markets = [d.data]
      else if (d && d.mid) markets = [d]

      /* The 4th level is the MARKET, one row each — for every group, as on the
         reference (its page DOM, 2026-09-21: under "Fancy" one row "Normal",
         under "oddeven" one row "oddeven", under "Match1" one row "Bookmaker"…),
         and the row's value is the market's `mid`.

         It used to list a fancy-type market's SECTIONS instead (every runner,
         value = the section's `sid`). That was wrong twice over: not the
         reference's tree, and a lock saved that way could never bite — at bet
         time the server compares a MARKET lock with the bet's market id
         (sportbetscontroller: checkSportsLock(…, eventid, match_id), and
         match_id there IS the `mid`), so a `sid` never matched anything. */
      const byGtype = {}
      markets.forEach((m) => {
        if (!m) return
        const gtype = m.gtype || 'Other'
        if (!byGtype[gtype]) byGtype[gtype] = []
        byGtype[gtype].push({ name: m.mname || m.marketName, id: m.mid || m.marketId })
      })
      // Inside a group the reference lists markets by ascending `mid` — true of
      // all 307 groups with 3+ markets in its DOM (only 1 was also name-sorted).
      Object.values(byGtype).forEach((list) => list.sort((a, b) => Number(a.id) - Number(b.id)))
      // Headings and their order as the reference prints them: the first three
      // capitalised, the rest as the feed spells them; anything new goes last.
      const groups = {}
      const ordered = [
        ...MARKET_GROUP_ORDER.filter((g) => byGtype[g]),
        ...Object.keys(byGtype).filter((g) => !MARKET_GROUP_ORDER.includes(g)),
      ]
      ordered.forEach((g) => { groups[MARKET_GROUP_TITLES[g] || g] = byGtype[g] })
      setMatchCache((prev) => ({ ...prev, [gmid]: groups }))
    } catch (err) {
      console.error('Error loading match markets:', err)
    }
  }, [matchCache])

  const handleSelectUser = (u) => {
    setClientName(u.username)
    setTargetUser({
      id: u.staff_id || u.user_id,
      username: u.username,
      role: u.user_type || u.role,
    })
  }

  const handleLoad = async (e) => {
    e.preventDefault()
    // Order and wording are the reference's (phone recording, 2026-09-21): Load
    // with BOTH boxes empty toasts "Transaction code is required" — the code is
    // checked first, the client second. Ours checked the client first and said
    // "Please select a user first" there. The message goes in `text`, not
    // `title`: the reference's $swal({ icon, text }) leaves the title empty, and
    // a toast's title renders bolder and larger than what the recording shows.
    if (!transactionCode) {
      Toast.fire({ icon: 'error', text: 'Transaction code is required' })
      return
    }
    if (!targetUser) {
      // wording NOT from the reference — no recording of this case yet
      Toast.fire({ icon: 'error', text: 'Please select a user first' })
      return
    }
    setLoadingVerify(true)
    try {
      const verifyRes = await api.post('/admin/transaction-password/verify', {
        transactionPassword: transactionCode,
      })
      if (verifyRes.data?.success) {
        setVerified(true)
        setVerifiedPassword(transactionCode)
        await loadEventsAndCasino()
        await loadUserLocks(targetUser.id, targetUser.role)
        Toast.fire({ icon: 'success', text: 'Verified. Events & casino loaded.' })
      } else {
        setVerified(false)
        setVerifiedPassword('')
        Toast.fire({ icon: 'error', text: verifyRes.data?.message || TXN_FALLBACK })
      }
    } catch (err) {
      // A wrong code is a 400 (403 once the attempts are used up), so it lands
      // HERE, not in the else above. The server's own line is what the
      // reference shows — "transaction code not valid. You have 7attempt left."
      // (MESSAGES.ADMIN.TXN) — and it used to be thrown away for a hardcoded
      // "Invalid transaction password", hiding the countdown from the operator.
      console.error('Verify error:', err)
      setVerified(false)
      setVerifiedPassword('')
      Toast.fire({ icon: 'error', text: err?.response?.data?.message || TXN_FALLBACK })
    } finally {
      setLoadingVerify(false)
    }
  }

  const handleReset = () => {
    setClientName('')
    setTargetUser(null)
    setTransactionCode('')
    setVerifiedPassword('')
    setVerified(false)
    setLockedIds(new Set())
    setExpanded({})
    setEverOpened(new Set())
    setSportsTree([])
    setCasinoList([])
    setMatchCache({})
  }

  const handleCasinoToggle = async (id) => {
    if (!targetUser) return
    const game = casinoList.find((g) => g.id === id)
    if (!game) return
    const nextLocked = !game.isLocked
    setCasinoList((prev) => prev.map((g) => g.id === id ? { ...g, isLocked: nextLocked } : g))
    setBusy(true)
    try {
      const isUser = targetUser.role === 'USER'
      const payload = {
        tableCasinoId: id,
        isLocked: nextLocked,
        type: isUser ? 'USER' : 'OTHER',
        transactionPassword: verifiedPassword,
      }
      if (isUser) payload.userId = targetUser.id
      else payload.staffId = targetUser.id
      const res = await api.post('/admin/table-casino/lock', payload)
      if (!res.data?.success) throw new Error(res.data?.message || 'Save failed')
    } catch (err) {
      setCasinoList((prev) => prev.map((g) => g.id === id ? { ...g, isLocked: !nextLocked } : g))
      Toast.fire({
        icon: 'error',
        text: err?.response?.data?.message || err.message || 'Failed to update lock',
      })
    } finally {
      setBusy(false)
    }
  }

  const renderSport = (sport) => {
    const sportsId = sport.etid
    const etid = String(sportsId)
    const sportKey = `sport-${etid}`
    const isExpanded = isOpen('sports', sportKey)
    const series = sport.children || []
    // The arrow belongs only to a row that has something under it. A sport
    // with no events (Badminton, Esoccer, Ice Hockey, Futsal… on the reference)
    // gets the reference's blank placeholder — same 25px slot, so the
    // checkboxes stay in one column — and no <ul> at all.
    const hasChildren = series.length > 0
    /* A lock is inherited downwards, exactly as the reference draws it
       (its template: checkLock(etid) on a league, checkGameLock(etid, cid, 0)
       on a match, checkGameLock(etid, cid, gmid) on a market): a row under a
       locked sport / league / match shows TICKED and DISABLED — it cannot be
       switched on its own while something above it holds the lock. Untick the
       parent and the rows below are free again (recording, 2026-09-21). */
    const sportLocked = lockedIds.has(etid)

    return (
      <li key={etid} className="nav-item dropdown show">
        {hasChildren ? (
          <a
            title="click here to expand"
            data-toggle="collapse"
            data-target={`#menu-${etid}`}
            role="button"
            aria-expanded={isExpanded ? 'true' : 'false'}
            className={arrowClass('sports', sportKey)}
            onClick={(e) => { e.preventDefault(); toggleExpand('sports', sportKey) }}
          >
            <i className="fas fa-angle-down"></i>
          </a>
        ) : (
          <a href="javascript:void(0)" className="arrow-icon">{'\u00a0'}</a>
        )}
        <span className="custom-control custom-checkbox">
          <input
            type="checkbox"
            id={`chk-sport-${etid}`}
            className="custom-control-input"
            value={etid}
            checked={lockedIds.has(etid)}
            onChange={() => handleSportsTreeToggle({ key: etid, sportId: etid })}
          />
          <label htmlFor={`chk-sport-${etid}`} className="custom-control-label">{sport.name}</label>
        </span>
        {hasChildren && (
        <TreeBranch
          open={isExpanded}
          id={`menu-${etid}`}
          data-parent="#accordian1"
          className="sub-menu"
          render={() => series.map((ser, serIndex) => {
            const cid = String(ser.cid)
            // Sent to the backend as the lock identity — left exactly as it was.
            const seriesCheckId = `${etid}${cid}`
            // `cid` alone cannot identify a row in the UI: the feed repeats a
            // few (tennis 8855018, basketball 8100581, snooker 7337119) and the
            // 308 racing rows carry gmid only, so every one of them produced
            // cid "undefined". That collided three ways — duplicate React keys,
            // duplicate DOM ids (a label then toggled the FIRST matching
            // checkbox), and one shared expand key. `uid` is UI-only.
            const uid = `${etid}-${serIndex}-${cid}`
            const seriesGroup = `series|${etid}`
            const seriesKey = `series-${uid}`
            const seriesExpanded = isOpen(seriesGroup, seriesKey)
            const matches = ser.children || []
            const seriesHasChildren = matches.length > 0
            const seriesLocked = sportLocked || lockedIds.has(seriesCheckId)
            return (
              <li key={uid}>
                {seriesHasChildren ? (
                  <a
                    title="click here to expand"
                    data-toggle="collapse"
                    data-target={`#menu-${uid}`}
                    role="button"
                    aria-expanded={seriesExpanded ? 'true' : 'false'}
                    className={arrowClass(seriesGroup, seriesKey)}
                    onClick={(e) => { e.preventDefault(); toggleExpand(seriesGroup, seriesKey) }}
                  >
                    <i className="fas fa-angle-down"></i>
                  </a>
                ) : (
                  <a href="javascript:void(0)" className="arrow-icon">{'\u00a0'}</a>
                )}
                <span className="custom-control custom-checkbox">
                  <input
                    type="checkbox"
                    id={`chk-series-${uid}`}
                    className="custom-control-input"
                    value={cid}
                    checked={sportLocked || lockedIds.has(seriesCheckId)}
                    disabled={sportLocked}
                    onChange={() => handleSportsTreeToggle({ key: seriesCheckId, sportId: etid, seriesId: cid })}
                  />
                  <label htmlFor={`chk-series-${uid}`} className="custom-control-label">{ser.name}</label>
                </span>
                {seriesHasChildren && (
                <TreeBranch
                  open={seriesExpanded}
                  id={`menu-${uid}`}
                  data-parent={`#menu-${etid}`}
                  className="sub-menu"
                  render={() => matches.map((match) => {
                    const gmid = String(match.gmid)
                    const matchCheckId = `${seriesCheckId}${gmid}`
                    const matchGroup = `match|${uid}`
                    const matchKey = `match-${matchCheckId}`
                    const matchExpanded = isOpen(matchGroup, matchKey)
                    const markets = matchCache[gmid]
                    const groupEntries = markets ? Object.entries(markets) : []
                    const matchLocked = seriesLocked || lockedIds.has(matchCheckId)
                    return (
                      <li key={gmid}>
                        <a
                          title="click here to expand"
                          data-toggle="collapse"
                          data-target={`#menu-${gmid}`}
                          role="button"
                          aria-expanded={matchExpanded ? 'true' : 'false'}
                          className={arrowClass(matchGroup, matchKey)}
                          onClick={(e) => {
                            e.preventDefault()
                            toggleExpand(matchGroup, matchKey)
                            if (!markets) loadMatchMarkets(gmid, sportsId)
                          }}
                        >
                          <i className="fas fa-angle-down"></i>
                        </a>
                        <span className="custom-control custom-checkbox">
                          <input
                            type="checkbox"
                            id={`chk-match-${etid}-${cid}-${gmid}`}
                            className="custom-control-input"
                            value={gmid}
                            checked={seriesLocked || lockedIds.has(matchCheckId)}
                            disabled={seriesLocked}
                            onChange={() => handleSportsTreeToggle({ key: matchCheckId, sportId: etid, seriesId: cid, matchId: gmid })}
                          />
                          <label htmlFor={`chk-match-${etid}-${cid}-${gmid}`} className="custom-control-label">{match.name}</label>
                        </span>
                        <TreeBranch
                          open={matchExpanded}
                          id={`menu-${gmid}`}
                          data-parent={`#menu-${uid}`}
                          className="sub-menu"
                          render={() => (
                          <>
                          {!markets && (
                            <li className="px-3 py-2 text-muted">Loading markets...</li>
                          )}
                          {groupEntries.map(([gtype, items]) => (
                            <Fragment key={`${matchCheckId}-${gtype}`}>
                              <h5 className="mb-0 font-size-16">{gtype}</h5>
                              {items.map((it) => {
                                const mktValue = String(it.id)
                                const mktCheckId = `${matchCheckId}${mktValue}`
                                return (
                                  <li key={mktCheckId}>
                                    <span className="custom-control custom-checkbox">
                                      <input
                                        type="checkbox"
                                        id={`chk-market-${etid}-${cid}-${gmid}-${mktValue}`}
                                        className="custom-control-input"
                                        value={mktValue}
                                        checked={matchLocked || lockedIds.has(mktCheckId)}
                                        disabled={matchLocked}
                                        onChange={() => handleSportsTreeToggle({ key: mktCheckId, sportId: etid, seriesId: cid, matchId: gmid, marketId: mktValue })}
                                      />
                                      <label htmlFor={`chk-market-${etid}-${cid}-${gmid}-${mktValue}`} className="custom-control-label">{it.name}</label>
                                    </span>
                                  </li>
                                )
                              })}
                            </Fragment>
                          ))}
                          </>
                          )}
                        />
                      </li>
                    )
                  })}
                />
                )}
              </li>
            )
          })}
        />
        )}
      </li>
    )
  }

  return (
    <div data-v-5a10e370="">
          {(busy || loadingVerify) && <LoaderOverlay />}
          <div className="row">
            <div className="col-12">
              <div className="page-title-box d-flex align-items-center justify-content-between">
                <h4 className="mb-0 font-size-18">General Lock</h4>
                <div className="page-title-right">
                  <ol className="breadcrumb m-0">
                    <li className="breadcrumb-item">
                      <Link to="/admin/home" className="" target="_self">Home</Link>
                    </li>
                    <li className="breadcrumb-item active">
                      <span aria-current="location">General Lock</span>
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col-12">
              <div className="card">
                <div className="card-body">
                  <div className="user-lock-container">
                    <div className="m-t-20">
                      <div>
                        <form method="post" className="ajaxFormSubmit" onSubmit={handleLoad}>
                          <div className="row row5">
                            <div className="col-md-3">
                              <div className="form-group user-lock-search" style={{ position: 'relative' }}>
                                <ClientMultiselect
                                  placeholder="Search By Client Name"
                                  value={clientName}
                                  onChange={(v) => { setClientName(v); setTargetUser(null) }}
                                  onSelect={handleSelectUser}
                                />
                              </div>
                            </div>
                            <div className="col-md-2">
                              <div className="form-group">
                                <input
                                  type="password"
                                  placeholder="Transaction Code"
                                  className="form-control d-inline-block"
                                  value={transactionCode}
                                  onChange={(e) => setTransactionCode(e.target.value)}
                                />
                              </div>
                            </div>
                            <div className="col-md-2">
                              <button type="submit" id="loaddata" className="btn btn-primary" disabled={loadingVerify}>
                                {loadingVerify ? 'Load' : 'Load'}
                              </button>
                              {' '}
                              <button type="button" id="reset" className="btn btn-light" onClick={handleReset}>Reset</button>
                            </div>
                          </div>
                        </form>
                      </div>
                    </div>

                    {verified && (
                      <div>
                        <div className="row mt-3">
                          <div className="col-lg-6 col-12">
                            <h4 className="ptitle">Events</h4>
                            <ul id="accordian1" className="navbar-nav user-lock-nav">
                              {sportsTree.length === 0 ? (
                                <li className="px-2 py-2 text-muted">Loading sports...</li>
                              ) : (
                                sportsTree.map(renderSport)
                              )}
                            </ul>
                          </div>

                          <div className="col-lg-6 col-12">
                            <h4 className="ptitle">Casino List</h4>
                            <ul className="user-lock-nav">
                              {casinoList.length === 0 ? (
                                <li className="text-muted">Loading casino list...</li>
                              ) : (
                                casinoList.map((game) => {
                                  const key = game.key || game.code || game.tablecode || game.table_key || String(game.id)
                                  return (
                                    <li key={key}>
                                      <span className="custom-control custom-checkbox">
                                        <input
                                          type="checkbox"
                                          id={`chk-casino-${game.id}`}
                                          className="custom-control-input"
                                          value={key}
                                          checked={game.isLocked || false}
                                          onChange={() => handleCasinoToggle(game.id)}
                                        />
                                        <label htmlFor={`chk-casino-${game.id}`} className="custom-control-label">
                                          {game.tablename}
                                        </label>
                                      </span>
                                    </li>
                                  )
                                })
                              )}
                            </ul>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
  )
}

export default UserLock
