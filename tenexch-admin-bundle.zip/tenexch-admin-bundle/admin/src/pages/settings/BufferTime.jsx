import { Fragment, useState, useEffect, useMemo, useCallback } from 'react'
import { Link } from 'react-router-dom'
import Swal from 'sweetalert2'
import bettingConfigService from '../../services/bettingConfigService'

// Buffer Time — owner-only. The buffer is how many seconds the bet slip keeps
// watching the live price after the user presses Place Bet before the bet is
// actually booked.
//
// Sports use the SAME grid as Settings → Commission:
//
//   sport   → the feed's etid
//   league  → 'default' (every ordinary league) plus the variants the feed
//             ships under the same sport id but that are a different product:
//             cricket's E-Cricket (Dim), T10 XI, T5 XI, Virtual Cricket League
//             and wrestling's WWE Virtual. A variant cell left on INHERIT
//             follows the default row; "Own" gives that league its own value.
//   market  → "Match Odds" means the market really is named Match Odds;
//             everything else gtype 'match' carries (Over/Under, Correct Score,
//             Match Result, Inning EvenOdd…) sits under "Other Main Markets",
//             then Bookmaker, Other Bookmaker Markets and every fancy type.
//
// Casino is configured per game — the same game key the bet payload carries,
// so VIP / Virtual / Premium tables are covered too.
//
// 0 means "not configured": the site falls back to the platform-wide buffer
// (Match Odds / Bookmaker) or the frontend's env default, exactly as before
// this screen.
// Plan: docs/plans/2026-09-15-buffer-maxodds-league-market-grid.md

const TABS = [
  { id: 'sports', label: 'Sports' },
  { id: 'casino', label: 'Casino' },
]

const CASINO_CATEGORY_LABELS = {
  our: 'Our Casino',
  vip: 'VIP',
  virtual: 'Virtual',
  premium: 'Premium',
}

const cellKey = (sportId, leagueKey, marketKey) => `${sportId}:${leagueKey}:${marketKey}`

function BufferTime() {
  const [activeTab, setActiveTab] = useState('sports')
  const [loading, setLoading] = useState(true)
  const [sports, setSports] = useState([])
  const [markets, setMarkets] = useState([])
  const [maxSeconds, setMaxSeconds] = useState(60)
  const [games, setGames] = useState([])
  const [search, setSearch] = useState('')
  const [openSport, setOpenSport] = useState(null)
  // sport_id -> league_key currently shown in that sport's tab strip
  const [openLeague, setOpenLeague] = useState({})
  // "Set all markets" input for the league on screen
  const [bulkSeconds, setBulkSeconds] = useState('')
  const [saving, setSaving] = useState(false)
  const [savingKey, setSavingKey] = useState(null)
  // Draft edits. Sports: "<sportId>:<leagueKey>:<marketKey>" → { state, seconds }.
  // Casino: "casino:<gameName>" → seconds. Committed on Save only, so a
  // half-typed number is never POSTed.
  const [drafts, setDrafts] = useState({})

  const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: false,
  })

  const load = useCallback(async (tab) => {
    setLoading(true)
    try {
      if (tab === 'sports') {
        const response = await bettingConfigService.getSportsBuffers()
        if (response.success) {
          setSports(response.sports || [])
          setMarkets(response.markets || [])
          setMaxSeconds(response.max_seconds || 60)
          setOpenSport((prev) => prev ?? (response.sports?.[0]?.sport_id ?? null))
          setDrafts({})
        }
      } else {
        const response = await bettingConfigService.getCasinoBuffers()
        if (response.success) {
          setGames(response.games || [])
          setMaxSeconds(response.max_seconds || 60)
          setDrafts({})
        }
      }
    } catch (error) {
      Toast.fire({ icon: 'error', title: error.response?.data?.error || error.message })
    } finally {
      setLoading(false)
    }
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    load(activeTab)
  }, [activeTab, load])

  const validSeconds = (raw) => {
    const value = Number(raw)
    if (raw === '' || !Number.isFinite(value) || value < 0 || value > maxSeconds) {
      Toast.fire({ icon: 'error', title: `Buffer must be between 0 and ${maxSeconds} seconds` })
      return null
    }
    return value
  }

  // ── sports: draft helpers ─────────────────────────────────────────────────
  const savedCell = (league, marketKey) =>
    league.cells?.[marketKey] || { state: league.is_default ? 'set' : 'inherit', seconds: 0, inherited: 0 }

  const cellOf = (key, saved) => (drafts[key] !== undefined ? drafts[key] : saved)

  const isCellDirty = (key, saved) => {
    const d = drafts[key]
    if (d === undefined) return false
    if (d.state !== saved.state) return true
    return d.state === 'set' && Number(d.seconds) !== Number(saved.seconds)
  }

  const setCellDraft = (key, saved, patch) =>
    setDrafts((prev) => ({ ...prev, [key]: { ...cellOf(key, saved), ...patch } }))

  // What the slip will actually wait for a cell, after inheritance.
  const effectiveOf = (cell) => Number(cell.state === 'inherit' ? cell.inherited : cell.seconds) || 0

  const ownCount = (league) =>
    markets.filter((m) => savedCell(league, m.key).state === 'set').length

  const dirtyCount = useMemo(() => {
    let n = 0
    for (const sport of sports) {
      for (const league of sport.leagues || []) {
        for (const market of markets) {
          const key = cellKey(sport.sport_id, league.key, market.key)
          if (isCellDirty(key, savedCell(league, market.key))) n += 1
        }
      }
    }
    return n
  }, [drafts, sports, markets]) // eslint-disable-line react-hooks/exhaustive-deps

  // ── sports: persistence ───────────────────────────────────────────────────
  const saveAll = async () => {
    const items = []
    const resets = []
    for (const sport of sports) {
      for (const league of sport.leagues || []) {
        for (const market of markets) {
          const key = cellKey(sport.sport_id, league.key, market.key)
          const saved = savedCell(league, market.key)
          if (!isCellDirty(key, saved)) continue
          const cell = cellOf(key, saved)
          const payload = { sport_id: sport.sport_id, league_key: league.key, market_key: market.key }
          // "Inherit" is the ABSENCE of a row, so it is a DELETE, not a save.
          if (cell.state === 'inherit') {
            resets.push(payload)
            continue
          }
          const seconds = Number(cell.seconds)
          if (cell.seconds === '' || !Number.isFinite(seconds) || seconds < 0 || seconds > maxSeconds) {
            Toast.fire({
              icon: 'error',
              title: `${sport.name} / ${league.label} — ${market.label}: buffer must be 0–${maxSeconds}s`,
            })
            return
          }
          items.push({ ...payload, buffer_seconds: seconds })
        }
      }
    }
    if (!items.length && !resets.length) return

    setSaving(true)
    try {
      for (const payload of resets) await bettingConfigService.resetSportsBuffer(payload)
      if (items.length) await bettingConfigService.saveSportsBufferBulk(items)
      Toast.fire({ icon: 'success', title: `Saved ${items.length + resets.length} cell(s)` })
      await load('sports')
    } catch (error) {
      Toast.fire({ icon: 'error', title: error.response?.data?.error || error.message })
    } finally {
      setSaving(false)
    }
  }

  // Put one patch on every market of the league on screen.
  const applyToLeague = (sport, league, patch) => {
    setDrafts((prev) => {
      const next = { ...prev }
      for (const market of markets) {
        const key = cellKey(sport.sport_id, league.key, market.key)
        const saved = savedCell(league, market.key)
        const current = next[key] !== undefined ? next[key] : saved
        next[key] = { ...current, ...patch }
      }
      return next
    })
  }

  // ── casino ────────────────────────────────────────────────────────────────
  const casinoValue = (key, saved) => (drafts[key] !== undefined ? drafts[key] : saved)
  const isCasinoDirty = (key, saved) => drafts[key] !== undefined && Number(drafts[key]) !== Number(saved)

  const saveGame = async (game) => {
    const key = `casino:${game.game_name}`
    const value = validSeconds(drafts[key])
    if (value === null) return

    setSavingKey(key)
    try {
      const response = await bettingConfigService.saveCasinoBuffer({
        game_name: game.game_name,
        buffer_seconds: value,
      })
      if (response.success) {
        setGames((prev) => prev.map((g) => (
          g.game_name === game.game_name ? { ...g, buffer_seconds: value } : g
        )))
        setDrafts((prev) => {
          const next = { ...prev }
          delete next[key]
          return next
        })
        Toast.fire({
          icon: 'success',
          title: value > 0 ? `${game.name} buffer set to ${value}s` : `${game.name} buffer cleared`,
        })
      }
    } catch (error) {
      Toast.fire({ icon: 'error', title: error.response?.data?.error || error.message })
    } finally {
      setSavingKey(null)
    }
  }

  // ── filtering ─────────────────────────────────────────────────────────────
  const visibleGames = useMemo(() => {
    const term = search.trim().toLowerCase()
    if (!term) return games
    return games.filter(
      (g) => g.name.toLowerCase().includes(term) || g.game_name.includes(term)
    )
  }, [games, search])

  // A league label matches too, so "t10" finds Cricket.
  const visibleSports = useMemo(() => {
    const term = search.trim().toLowerCase()
    if (!term) return sports
    return sports.filter((s) => s.name.toLowerCase().includes(term)
      || (s.leagues || []).some((l) => !l.is_default && l.label.toLowerCase().includes(term)))
  }, [sports, search])

  const leagueOf = (sport) => {
    const wanted = openLeague[sport.sport_id]
    return (sport.leagues || []).find((l) => l.key === wanted) || sport.leagues?.[0]
  }

  // Short line for the collapsed sport header.
  const sportSummary = (sport) => {
    const parts = []
    for (const league of sport.leagues || []) {
      if (league.is_default) {
        const n = markets.filter((m) => effectiveOf(savedCell(league, m.key)) > 0).length
        parts.push(n ? `${n} of ${markets.length} markets set` : 'Site default')
      } else {
        const own = ownCount(league)
        if (own) parts.push(`${league.label}: ${own} own`)
      }
    }
    return parts.join(' · ')
  }

  const groupedMarkets = useMemo(() => {
    const groups = []
    for (const market of markets) {
      const last = groups[groups.length - 1]
      if (last && last.group === market.group) last.items.push(market)
      else groups.push({ group: market.group, items: [market] })
    }
    return groups
  }, [markets])

  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-12">
          <div className="page-title-box d-flex align-items-center justify-content-between">
            <h4 className="mb-0 font-size-18">Buffer Time</h4>
            <div className="page-title-right">
              <ol className="breadcrumb m-0">
                <li className="breadcrumb-item"><Link to="/admin/home">Home</Link></li>
                <li className="breadcrumb-item active">Buffer Time</li>
              </ol>
            </div>
          </div>
        </div>
      </div>

      <div className="row">
        <div className="col-12">
          <div className="card">
            <div className="card-body">
              <ul className="nav nav-tabs nav-tabs-custom mb-3">
                {TABS.map((tab) => (
                  <li className="nav-item" key={tab.id}>
                    <a
                      href="javascript:void(0)"
                      className={`nav-link ${activeTab === tab.id ? 'active' : ''}`}
                      onClick={() => setActiveTab(tab.id)}
                    >
                      {tab.label}
                    </a>
                  </li>
                ))}
              </ul>

              <p className="text-muted font-size-12 mb-2">
                Seconds the bet slip tracks the live price before booking the bet.
                Leave 0 to keep the site default. Maximum {maxSeconds}s.
              </p>
              {activeTab === 'sports' && (
                <p className="text-muted font-size-12 mb-3">
                  <b>Match Odds</b> means only the market actually named Match Odds — Over/Under,
                  Correct Score, Match Result and Inning EvenOdd sit under <b>Other Main Markets</b>.
                  Cricket&apos;s <b>E-Cricket (Dim), T10 XI, T5 XI</b> and <b>Virtual Cricket League</b> have
                  their own tabs: leave a cell on <b>Inherit</b> to follow the main sport, or pick
                  <b> Own</b> to give that league its own buffer.
                </p>
              )}

              <div className="d-flex flex-wrap align-items-center mb-3" style={{ gap: 12 }}>
                <input
                  type="search"
                  className="form-control form-control-sm"
                  style={{ maxWidth: 260 }}
                  placeholder={activeTab === 'sports' ? 'Search sport or league…' : 'Search game…'}
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
                {activeTab === 'sports' && (
                  <div className="ml-auto d-flex align-items-center" style={{ gap: 8 }}>
                    {dirtyCount > 0 && (
                      <button
                        type="button"
                        className="btn btn-sm btn-light"
                        disabled={saving}
                        onClick={() => setDrafts({})}
                      >
                        Discard
                      </button>
                    )}
                    <button
                      type="button"
                      className="btn btn-sm btn-primary"
                      disabled={dirtyCount === 0 || saving}
                      onClick={saveAll}
                    >
                      {saving ? 'Saving…' : `Save changes${dirtyCount ? ` (${dirtyCount})` : ''}`}
                    </button>
                  </div>
                )}
              </div>

              {loading ? (
                <div className="text-center p-4">Loading...</div>
              ) : activeTab === 'sports' ? (
                visibleSports.length === 0 ? (
                  <div className="text-center p-4 text-muted">no records found</div>
                ) : (
                  <div className="accordion">
                    {visibleSports.map((sport) => {
                      const isOpen = openSport === sport.sport_id
                      const league = leagueOf(sport)
                      return (
                        <div className="card mb-2" key={sport.sport_id} style={{ border: '1px solid #eff2f7' }}>
                          <div
                            className="card-header bg-transparent d-flex align-items-center"
                            style={{ cursor: 'pointer', padding: '10px 14px' }}
                            onClick={() => setOpenSport(isOpen ? null : sport.sport_id)}
                          >
                            <i className={`mdi ${isOpen ? 'mdi-chevron-down' : 'mdi-chevron-right'} mr-2`} />
                            <span className="font-weight-medium">{sport.name}</span>
                            <small className="text-muted ml-1">#{sport.sport_id}</small>
                            {sport.enabled ? (
                              <span className="badge badge-soft-success ml-2">live</span>
                            ) : null}
                            {(sport.leagues || []).length > 1 && (
                              <span className="badge badge-soft-info ml-2">
                                {sport.leagues.length - 1} extra league{sport.leagues.length - 1 > 1 ? 's' : ''}
                              </span>
                            )}
                            <small className="text-muted ml-auto text-right" style={{ maxWidth: '55%' }}>
                              {sportSummary(sport)}
                            </small>
                          </div>

                          {isOpen && league && (
                            <div className="card-body" style={{ padding: '12px 14px' }}>
                              {/* League tab strip — 'default' plus the sport's variants */}
                              {(sport.leagues || []).length > 1 && (
                                <ul className="nav nav-pills mb-3" style={{ gap: 6 }}>
                                  {sport.leagues.map((l) => {
                                    const badge = l.is_default ? l.configured_count : ownCount(l)
                                    return (
                                      <li className="nav-item" key={l.key}>
                                        <button
                                          type="button"
                                          className={`nav-link btn btn-sm ${l.key === league.key ? 'active' : ''}`}
                                          onClick={() => setOpenLeague((p) => ({ ...p, [sport.sport_id]: l.key }))}
                                        >
                                          {l.label}
                                          {badge > 0 && <span className="badge badge-light ml-1">{badge}</span>}
                                        </button>
                                      </li>
                                    )
                                  })}
                                </ul>
                              )}

                              <div className="d-flex flex-wrap align-items-center mb-2" style={{ gap: 8 }}>
                                <small className="text-muted">
                                  {league.is_default
                                    ? 'Applies to every league of this sport that has no tab of its own.'
                                    : 'Cells on Inherit follow the main sport tab.'}
                                </small>
                                <div className="ml-auto d-flex align-items-center" style={{ gap: 6 }}>
                                  <input
                                    type="number"
                                    min="0"
                                    max={maxSeconds}
                                    step="0.5"
                                    className="form-control form-control-sm"
                                    style={{ maxWidth: 80 }}
                                    placeholder="sec"
                                    value={bulkSeconds}
                                    onChange={(e) => setBulkSeconds(e.target.value)}
                                  />
                                  <div className="btn-group btn-group-sm">
                                    <button
                                      type="button"
                                      className="btn btn-outline-secondary"
                                      onClick={() => {
                                        const value = validSeconds(bulkSeconds)
                                        if (value === null) return
                                        applyToLeague(sport, league, { state: 'set', seconds: value })
                                      }}
                                    >
                                      Set all markets
                                    </button>
                                    {!league.is_default && (
                                      <button
                                        type="button"
                                        className="btn btn-outline-secondary"
                                        onClick={() => applyToLeague(sport, league, { state: 'inherit' })}
                                      >
                                        All Inherit
                                      </button>
                                    )}
                                  </div>
                                </div>
                              </div>

                              <div className="table-responsive">
                                <table className="table table-sm table-bordered mb-0">
                                  <thead>
                                    <tr>
                                      <th style={{ minWidth: 230 }}>Market</th>
                                      <th style={{ width: 260 }} className="text-center">Buffer (seconds)</th>
                                      <th style={{ minWidth: 170 }}>Effective</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {groupedMarkets.map((group) => (
                                      <Fragment key={`${league.key}-${group.group}`}>
                                        <tr className="bg-light">
                                          <td colSpan={3} className="font-weight-medium font-size-12 text-muted">
                                            {group.group}
                                          </td>
                                        </tr>
                                        {group.items.map((market) => {
                                          const key = cellKey(sport.sport_id, league.key, market.key)
                                          const saved = savedCell(league, market.key)
                                          const cell = cellOf(key, saved)
                                          const dirty = isCellDirty(key, saved)
                                          const eff = effectiveOf(cell)
                                          const inheriting = cell.state === 'inherit'
                                          return (
                                            <tr key={key} className={dirty ? 'table-warning' : ''}>
                                              <td>
                                                <div>{market.label}</div>
                                                {market.hint && (
                                                  <small className="text-muted font-size-11">{market.hint}</small>
                                                )}
                                              </td>
                                              <td className="text-center">
                                                <div className="d-flex align-items-center justify-content-center" style={{ gap: 6 }}>
                                                  {!league.is_default && (
                                                    <div className="btn-group btn-group-sm">
                                                      <button
                                                        type="button"
                                                        className={`btn btn-sm ${inheriting ? 'btn-info' : 'btn-outline-secondary'}`}
                                                        onClick={() => setCellDraft(key, saved, { state: 'inherit' })}
                                                      >
                                                        Inherit
                                                      </button>
                                                      <button
                                                        type="button"
                                                        className={`btn btn-sm ${inheriting ? 'btn-outline-secondary' : 'btn-primary'}`}
                                                        onClick={() => {
                                                          if (inheriting) {
                                                            setCellDraft(key, saved, { state: 'set', seconds: cell.inherited ?? 0 })
                                                          }
                                                        }}
                                                      >
                                                        Own
                                                      </button>
                                                    </div>
                                                  )}
                                                  <input
                                                    type="number"
                                                    min="0"
                                                    max={maxSeconds}
                                                    step="0.5"
                                                    className="form-control form-control-sm"
                                                    style={{ maxWidth: 80 }}
                                                    disabled={inheriting}
                                                    value={inheriting ? (cell.inherited ?? 0) : cell.seconds}
                                                    onChange={(e) => setCellDraft(key, saved, { state: 'set', seconds: e.target.value })}
                                                  />
                                                </div>
                                              </td>
                                              <td>
                                                {eff > 0 ? (
                                                  <span className="badge badge-soft-success">waits {eff}s</span>
                                                ) : (
                                                  <span className="badge badge-soft-secondary">site default</span>
                                                )}
                                                {inheriting && (
                                                  <small className="text-muted d-block font-size-11">
                                                    following the main sport
                                                  </small>
                                                )}
                                              </td>
                                            </tr>
                                          )
                                        })}
                                      </Fragment>
                                    ))}
                                  </tbody>
                                </table>
                              </div>
                            </div>
                          )}
                        </div>
                      )
                    })}
                  </div>
                )
              ) : (
                <div className="table-responsive">
                  <table className="table table-sm table-bordered mb-0">
                    <thead>
                      <tr>
                        <th style={{ minWidth: 220 }}>Game</th>
                        <th style={{ minWidth: 120 }}>Category</th>
                        <th style={{ minWidth: 220 }}>Buffer (seconds)</th>
                      </tr>
                    </thead>
                    <tbody>
                      {visibleGames.length === 0 && (
                        <tr><td colSpan="3" className="text-center">no records found</td></tr>
                      )}
                      {visibleGames.map((game) => {
                        const key = `casino:${game.game_name}`
                        const saved = game.buffer_seconds || 0
                        return (
                          <tr key={game.game_name}>
                            <td>
                              {game.name} <code className="ml-1">{game.game_name}</code>
                            </td>
                            <td>{CASINO_CATEGORY_LABELS[game.category] || game.category}</td>
                            <td>
                              <div className="d-flex align-items-center">
                                <input
                                  type="number"
                                  min="0"
                                  max={maxSeconds}
                                  step="0.5"
                                  className="form-control form-control-sm mr-2"
                                  style={{ maxWidth: 90 }}
                                  value={casinoValue(key, saved)}
                                  onChange={(e) => setDrafts((prev) => ({ ...prev, [key]: e.target.value }))}
                                />
                                <button
                                  type="button"
                                  className="btn btn-sm btn-primary"
                                  disabled={!isCasinoDirty(key, saved) || savingKey === key}
                                  onClick={() => saveGame(game)}
                                >
                                  {savingKey === key ? '…' : 'Save'}
                                </button>
                              </div>
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default BufferTime
