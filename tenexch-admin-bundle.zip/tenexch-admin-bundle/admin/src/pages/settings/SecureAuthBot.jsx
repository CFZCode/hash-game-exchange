import { useState, useEffect } from 'react'
import Swal from 'sweetalert2'
import secureAuthService from '../../services/secureAuthService'

/**
 * Owner-only: which Telegram bot delivers secure-auth (2FA) codes, and which
 * handle players are told to message on the Security Auth Verification page.
 *
 * The token is write-only from here — the API returns it masked, so the field
 * is left blank on load and only sent when the owner actually types a new one.
 */
function SecureAuthBot() {
  const [botUsername, setBotUsername] = useState('')
  const [botToken, setBotToken] = useState('')
  const [current, setCurrent] = useState(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: false,
  })

  const fetchConfig = async () => {
    setLoading(true)
    try {
      const response = await secureAuthService.getBot()
      if (response.success) {
        setCurrent(response.data)
        setBotUsername(response.data.bot_username || '')
      }
    } catch (error) {
      Toast.fire({ icon: 'error', title: error.response?.data?.error || error.message })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchConfig()
  }, [])

  const handleSave = async (e) => {
    e.preventDefault()

    const payload = { bot_username: botUsername }
    // Blank means "leave the stored token alone" — never overwrite with ''.
    if (botToken.trim()) payload.bot_token = botToken.trim()

    setSaving(true)
    try {
      const response = await secureAuthService.updateBot(payload)
      if (response.success) {
        setCurrent(response.data)
        setBotToken('')
        Toast.fire({ icon: 'success', title: response.message || 'Saved' })
      }
    } catch (error) {
      Toast.fire({ icon: 'error', title: error.response?.data?.error || error.message })
    } finally {
      setSaving(false)
    }
  }

  return (
    <div>
      <div className="row">
        <div className="col-12">
          <div className="page-title-box d-flex align-items-center justify-content-between">
            <h4 className="mb-0 font-size-18">Secure Auth Bot</h4>
          </div>
        </div>
      </div>

      <div className="row">
        <div className="col-lg-7">
          <div className="card">
            <div className="card-body">
              <h5 className="card-title mb-3">Telegram Bot Settings</h5>

              {loading ? (
                <p className="text-muted mb-0">Loading…</p>
              ) : (
                <form onSubmit={handleSave}>
                  <div className="form-group mb-3">
                    <label htmlFor="botUsername">Bot Username</label>
                    <div className="input-group">
                      <div className="input-group-prepend">
                        <span className="input-group-text">@</span>
                      </div>
                      <input
                        id="botUsername"
                        type="text"
                        className="form-control"
                        value={botUsername}
                        onChange={(e) => setBotUsername(e.target.value)}
                        placeholder="securisep_auth_bot"
                        autoComplete="off"
                      />
                    </div>
                    <small className="form-text text-muted">
                      Shown to players on the Security Auth Verification page. Paste with or
                      without the @ — a full t.me link works too.
                    </small>
                  </div>

                  <div className="form-group mb-3">
                    <label htmlFor="botToken">Bot Token</label>
                    <input
                      id="botToken"
                      type="password"
                      className="form-control"
                      value={botToken}
                      onChange={(e) => setBotToken(e.target.value)}
                      placeholder={current?.has_token ? 'Leave blank to keep the current token' : '1234567890:AA…'}
                      autoComplete="new-password"
                    />
                    <small className="form-text text-muted">
                      {current?.has_token
                        ? <>Currently set: <code>{current.bot_token_masked}</code>. Leave blank to keep it.</>
                        : 'No token set yet — 2FA codes cannot be delivered until you add one.'}
                    </small>
                  </div>

                  {current?.bot_link && (
                    <div className="form-group mb-3">
                      <label>Player link</label>
                      <div>
                        <a href={current.bot_link} target="_blank" rel="noopener noreferrer">
                          {current.bot_link}
                        </a>
                      </div>
                    </div>
                  )}

                  <button type="submit" className="btn btn-primary" disabled={saving}>
                    {saving ? 'Saving…' : 'Save'}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>

        <div className="col-lg-5">
          <div className="card">
            <div className="card-body">
              <h5 className="card-title mb-3">How to create the bot</h5>
              <ol className="pl-3 mb-3">
                <li className="mb-2">
                  Open Telegram and message{' '}
                  <a href="https://t.me/BotFather" target="_blank" rel="noopener noreferrer">
                    @BotFather
                  </a>.
                </li>
                <li className="mb-2">Send <code>/newbot</code>.</li>
                <li className="mb-2">
                  Give it a display name (anything, e.g. <em>Tenexch Secure Auth</em>).
                </li>
                <li className="mb-2">
                  Give it a username. It must be unique and <b>end in <code>bot</code></b> —
                  e.g. <code>tenexch_auth_bot</code>.
                </li>
                <li className="mb-2">
                  BotFather replies with a token like{' '}
                  <code>1234567890:AAH…</code>. Paste it into <b>Bot Token</b> above, and the
                  username into <b>Bot Username</b>.
                </li>
                <li className="mb-0">Save. The change applies immediately — no restart needed.</li>
              </ol>
              <div className="alert alert-warning mb-0">
                <b>Careful:</b> changing the token points 2FA at a different bot. Players who
                linked the old bot will stop receiving codes and must re-link.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default SecureAuthBot
