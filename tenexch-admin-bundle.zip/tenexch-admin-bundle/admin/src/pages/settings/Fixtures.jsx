import { useState, useEffect } from 'react'
import fixturesService from '../../services/fixturesService'
import { formatFixtureTime, SPORT_NAMES } from '../../utils/fixtures'

const COLLECT_EVERY_MS = 4 * 60 * 60 * 1000 // collector cadence (auto-update/tenexch config.json)

const pad = (n) => String(n).padStart(2, '0')
const formatEpoch = (sec) => {
  const d = new Date(sec * 1000)
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`
}
const formatAge = (sec) => {
  if (sec == null) return '—'
  if (sec < 60) return `${sec}s ago`
  const m = Math.floor(sec / 60)
  if (m < 60) return `${m} min ago`
  return `${Math.floor(m / 60)} h ${m % 60} min ago`
}

/**
 * Owner-only: the upcoming fixtures stored by the fixtures collector
 * (auto-update/tenexch, every 4 h) and whether that data is fresh. The same
 * list drives the header "Upcoming Fixtures" ticker.
 */
function Fixtures() {
  const [rows, setRows] = useState([])
  const [meta, setMeta] = useState(null)
  const [reachable, setReachable] = useState(true)
  const [loading, setLoading] = useState(true)

  const load = async () => {
    setLoading(true)
    try {
      const response = await fixturesService.get()
      setRows(response.data || [])
      setMeta(response.meta || null)
      setReachable(Boolean(response.success))
    } catch {
      setReachable(false)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
  }, [])

  const fresh = reachable && meta?.ok && !meta?.stale
  const lastAt = meta?.fetched_at ? formatEpoch(meta.fetched_at) : '—'
  const nextAt = meta?.fetched_at ? formatEpoch(meta.fetched_at + COLLECT_EVERY_MS / 1000) : '—'

  return (
    <div>
      <div className="row">
        <div className="col-12">
          <div className="page-title-box d-flex align-items-center justify-content-between">
            <h4 className="mb-0 font-size-18">Fixtures</h4>
            <button type="button" className="btn btn-primary btn-sm" onClick={load} disabled={loading}>
              <i className="bx bx-refresh"></i> {loading ? 'Loading…' : 'Refresh'}
            </button>
          </div>
        </div>
      </div>

      <div className="row">
        <div className="col-12">
          <div className="card">
            <div className="card-body">
              <div className="row text-center">
                <div className="col-6 col-md-3 mb-2">
                  <div className="text-muted">Status</div>
                  <span className={`badge ${fresh ? 'bg-success' : 'bg-danger'} font-size-12`}>
                    {!reachable ? 'Collector down' : fresh ? 'Fresh' : 'Stale'}
                  </span>
                </div>
                <div className="col-6 col-md-3 mb-2">
                  <div className="text-muted">Last updated</div>
                  <div>{lastAt}</div>
                  <small className="text-muted">{formatAge(meta?.age_seconds)}</small>
                </div>
                <div className="col-6 col-md-3 mb-2">
                  <div className="text-muted">Next update (approx.)</div>
                  <div>{nextAt}</div>
                  <small className="text-muted">every 4 h</small>
                </div>
                <div className="col-6 col-md-3 mb-2">
                  <div className="text-muted">Fixtures</div>
                  <div className="font-size-18">{rows.length}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="row">
        <div className="col-12">
          <div className="card">
            <div className="card-body">
              <div className="table-responsive">
                <table className="table table-bordered table-striped mb-0">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Sport</th>
                      <th>Event</th>
                      <th>Event ID</th>
                      <th>Start Time</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rows.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="text-center text-muted">
                          {loading ? 'Loading…' : 'No fixtures stored yet'}
                        </td>
                      </tr>
                    ) : (
                      rows.map((r, i) => (
                        <tr key={r.eid}>
                          <td>{i + 1}</td>
                          <td>
                            <i className={`d-icon mr-2 icon-${r.sportid}`}></i>
                            {SPORT_NAMES[r.sportid] || `Sport ${r.sportid}`}
                          </td>
                          <td>{r.ename}</td>
                          <td>{r.eid}</td>
                          <td>{formatFixtureTime(r.dt)}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Fixtures
