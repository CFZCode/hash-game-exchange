import { useState, useEffect, useRef, Fragment } from 'react'
import { Link } from 'react-router-dom'
import Swal from 'sweetalert2'
import bettingConfigService from '../../services/bettingConfigService'
import { SPORTS_LIST } from '../../config/sportsList'

// Auto Void — owner-only. Once the result feed has declared an event's Match
// Odds or Bookmaker, the results cron waits the delay below and then voids
// every bet on that event that is still open with no result of its own (the
// markets the feed never declared). The void is the same one as
// Settlement → Void Market: exposure released, stake back in cash, one
// credits_ledger 'refund' row per market, bet_void_audit type AUTO_TIMEOUT.
//
// Off by default. Server: sportsbet/betresult/autoVoid.js.

const fmtDelay = (sec) => {
  const s = Number(sec) || 0
  const m = Math.floor(s / 60)
  const r = s % 60
  if (!m) return `${r} sec`
  return r ? `${m} min ${r} sec` : `${m} min`
}

const fmtLeft = (sec) => {
  const s = Math.abs(Math.round(sec))
  const h = Math.floor(s / 3600)
  const m = Math.floor((s % 3600) / 60)
  const r = s % 60
  const pad = (n) => String(n).padStart(2, '0')
  return h ? `${h}:${pad(m)}:${pad(r)}` : `${m}:${pad(r)}`
}

const fmtTime = (t) => (t ? new Date(t).toLocaleString('en-IN', { hour12: false }) : '-')
const fmtAmt = (n) => Number(n || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 })

const TRACKER_POLL_MS = 15000

// ── "What to find" for one open market ─────────────────────────────────────
// Mirrors how FancySettlementModal declares each market family, so the line
// tells the team exactly which fact to look up and what to type when declaring.
const RUN_MARKETS = new Set(['Normal', 'Over By Over', 'Ball By Ball', 'khado', 'meter'])
const isLineMarket = (t) => /\bline$/i.test(String(t || '').trim())

const KINDS = {
  runs: {
    order: 1,
    title: 'Find the final RUNS / number',
    hint: 'Look up the final figure (runs, wickets, boundaries...) and enter that number when you declare.',
    badge: 'badge-primary',
  },
  yesno: {
    order: 2,
    title: 'Find if it HAPPENED - Yes or No',
    hint: 'Did the event in the market name happen? Declare Yes or No.',
    badge: 'badge-info',
  },
  oddeven: {
    order: 3,
    title: 'Find ODD or EVEN',
    hint: 'Look up the final runs. Odd = declare Yes, Even = declare No.',
    badge: 'badge-info',
  },
  winner: {
    order: 4,
    title: 'Find the WINNER',
    hint: 'Look up which option won and pick it when you declare.',
    badge: 'badge-dark',
  },
}

const marketKind = (m) => {
  if (m.market_type === 'fancy1') return 'yesno'
  if (m.market_type === 'oddeven') return 'oddeven'
  if (m.game_type === 'FAN' && (RUN_MARKETS.has(m.market_type) || isLineMarket(m.market_type))) return 'runs'
  return 'winner'
}

// Line markets carry a generic runner ("Total Runs"); the market type is the name.
const marketTitle = (m) => (isLineMarket(m.market_type) ? m.market_type : m.market_name)

// Fancy markets are declared in Fancy Settlement under a tab named after the
// market type; everything else is in Match Settlement.
const whereToDeclare = (m) =>
  m.game_type === 'FAN'
    ? { to: '/admin/settlement/fancy', text: `Fancy Settlement → ${m.market_type} tab` }
    : { to: '/admin/settlement/match', text: 'Match Settlement' }

// Distinct positions the bets hold, so the team sees which numbers matter.
// runs: "YES 7+" wins at 7 or more, "NO under 3" wins below 3.
const positions = (m, kind) => {
  const map = new Map()
  for (const b of m.bets) {
    const side = String(b.bet_type || '').toLowerCase()
    let label
    if (kind === 'runs') label = side === 'no' ? `NO under ${b.odds}` : `YES ${b.odds}+`
    else if (kind === 'winner' && m.game_type !== 'FAN') label = `${b.selection_name} (${side})`
    else label = `${side.toUpperCase()} @ ${b.odds}`
    const cur = map.get(label) || { label, bets: 0, stake: 0 }
    cur.bets++
    cur.stake += b.stake
    map.set(label, cur)
  }
  return [...map.values()]
}

// Result Source Links: {match} / {market} are filled with the event and
// market names. Links without {market} are event-level, the rest per market.
const fillUrl = (url, ev, m) =>
  url
    .replace(/\{match\}/g, encodeURIComponent(ev.match_title || ''))
    .replace(/\{market\}/g, encodeURIComponent(m ? marketTitle(m) : ''))
const isMarketLink = (l) => l.url.includes('{market}')
const linksForSport = (links, sportId) =>
  (links || []).filter((l) => !l.sport_id || String(l.sport_id) === String(sportId))
const sportName = (id) => (SPORTS_LIST.find(([sid]) => sid === String(id)) || [null, 'All sports'])[1]

function ResultChecklist({ ev, autoVoidOn, links }) {
  const sportLinks = linksForSport(links, ev.sport_id)
  const eventLinks = sportLinks.filter((l) => !isMarketLink(l))
  const marketLinks = sportLinks.filter(isMarketLink)
  const [showBets, setShowBets] = useState({})
  const items = ev.markets
    .map((m) => ({ m, kind: marketKind(m) }))
    .sort((a, b) => KINDS[a.kind].order - KINDS[b.kind].order || b.m.total_stake - a.m.total_stake)
  const groups = []
  for (const it of items) {
    const g = groups[groups.length - 1]
    if (g && g.kind === it.kind) g.items.push(it)
    else groups.push({ kind: it.kind, items: [it] })
  }

  return (
    <div className="p-3 bg-light">
      <div className="alert alert-warning mb-3">
        <b>{ev.markets.length} result{ev.markets.length === 1 ? '' : 's'} to find</b> for{' '}
        <b>{ev.match_title || ev.eventid}</b>. Find each result below and declare it
        {autoVoidOn ? (
          <> before <b>{fmtTime(ev.void_at)}</b>. Anything still open then is refunded to the players.</>
        ) : (
          <>. Auto Void is OFF, so these bets stay open until someone declares or voids them.</>
        )}
      </div>

      {eventLinks.length > 0 && (
        <div className="mb-3">
          <b className="mr-2">Look it up:</b>
          {eventLinks.map((l) => (
            <a
              key={l.id}
              href={fillUrl(l.url, ev)}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-sm btn-outline-primary mr-2 mb-1"
            >
              {l.name} ↗
            </a>
          ))}
        </div>
      )}

      {groups.map((g) => {
        const k = KINDS[g.kind]
        return (
          <div key={g.kind} className="mb-3">
            <h6 className="mb-1">
              <span className={`badge ${k.badge} mr-2`}>{g.items.length}</span>
              {k.title}
            </h6>
            <div className="small text-muted mb-2">{k.hint}</div>
            <table className="table table-sm table-bordered bg-white mb-0">
              <thead className="thead-light">
                <tr>
                  <th style={{ width: '3%' }}>#</th>
                  <th style={{ width: '30%' }}>Market (what to look up)</th>
                  <th>Bets placed on</th>
                  <th style={{ width: '8%' }} className="text-right">Stake</th>
                  {marketLinks.length > 0 && <th style={{ width: '10%' }}>Search</th>}
                  <th style={{ width: '22%' }}>Declare in</th>
                </tr>
              </thead>
              <tbody>
                {g.items.map(({ m }, i) => {
                  const key = `${m.match_id}|${m.market_type}|${m.market_name}`
                  const where = whereToDeclare(m)
                  const shown = !!showBets[key]
                  return (
                    <Fragment key={key}>
                      <tr>
                        <td>{i + 1}</td>
                        <td>
                          <div className="font-weight-bold" style={{ fontSize: '1rem' }}>{marketTitle(m)}</div>
                          <button
                            type="button"
                            className="btn btn-link btn-sm p-0 small"
                            onClick={() => setShowBets((o) => ({ ...o, [key]: !o[key] }))}
                          >
                            {shown ? 'Hide' : 'Show'} {m.bet_count} bet{m.bet_count === 1 ? '' : 's'} ({m.users} user{m.users === 1 ? '' : 's'})
                          </button>
                          {m.manual_count > 0 && (
                            <span className="badge badge-dark ml-2">{m.manual_count} manual</span>
                          )}
                        </td>
                        <td>
                          {positions(m, g.kind).map((p) => (
                            <span key={p.label} className="badge badge-light border mr-1 mb-1 p-2" style={{ fontSize: '0.8rem' }}>
                              {p.label}
                              {p.bets > 1 && <span className="text-muted"> ×{p.bets}</span>}
                            </span>
                          ))}
                        </td>
                        <td className="text-right">{fmtAmt(m.total_stake)}</td>
                        {marketLinks.length > 0 && (
                          <td>
                            {marketLinks.map((l) => (
                              <a
                                key={l.id}
                                href={fillUrl(l.url, ev, m)}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="btn btn-sm btn-outline-secondary mr-1 mb-1"
                                title={`Search "${ev.match_title} ${marketTitle(m)}"`}
                              >
                                {l.name} ↗
                              </a>
                            ))}
                          </td>
                        )}
                        <td>
                          <Link to={where.to}>{where.text}</Link>
                        </td>
                      </tr>
                      {shown && (
                        <tr>
                          <td />
                          <td colSpan={marketLinks.length > 0 ? 5 : 4} className="p-0">
                            <table className="table table-sm mb-0 small">
                              <tbody>
                                {m.bets.map((b) => (
                                  <tr key={b.id}>
                                    <td className="text-muted">#{b.id}</td>
                                    <td>{b.username || b.user_id}</td>
                                    <td>{String(b.bet_type || '').toUpperCase()}{b.unmatched ? ' (unmatched)' : ''}</td>
                                    <td>{g.kind === 'winner' ? b.selection_name : ''} {b.odds}</td>
                                    <td className="text-right">{fmtAmt(b.stake)}</td>
                                    <td>{b.status}</td>
                                    <td className="text-muted">{fmtTime(b.created_at)}</td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </td>
                        </tr>
                      )}
                    </Fragment>
                  )
                })}
              </tbody>
            </table>
          </div>
        )
      })}
    </div>
  )
}
const URGENT_SEC = 600

// Pending Result Tracker — every event whose Match Odds / Bookmaker the feed
// has declared that still holds unsettled bets. The team finds those results
// before the countdown ends; after it, Auto Void refunds them (manual-status
// bets are never auto-voided and must be settled by hand).
function PendingResultTracker() {
  const [data, setData] = useState(null)
  const [error, setError] = useState(null)
  const [open, setOpen] = useState({})
  const [, setTick] = useState(0)
  const skew = useRef(0) // server clock minus browser clock, ms

  const load = async () => {
    try {
      const response = await bettingConfigService.getAutoVoidTracker()
      if (response.success) {
        skew.current = new Date(response.data.server_time).getTime() - Date.now()
        setData(response.data)
        setError(null)
      }
    } catch (err) {
      setError(err.response?.data?.error || err.message)
    }
  }

  useEffect(() => {
    load()
    const poll = setInterval(load, TRACKER_POLL_MS)
    const tick = setInterval(() => setTick((t) => t + 1), 1000)
    return () => {
      clearInterval(poll)
      clearInterval(tick)
    }
  }, [])

  const events = data?.events || []
  const now = Date.now() + skew.current
  const secsLeft = (ev) => (new Date(ev.void_at).getTime() - now) / 1000

  const rowState = (ev) => {
    if (ev.manual_count === ev.bet_count) return { cls: 'table-secondary', badge: 'badge-dark', text: 'MANUAL - settle by hand' }
    if (!data?.enabled) return { cls: 'table-secondary', badge: 'badge-secondary', text: 'AUTO VOID OFF' }
    const left = secsLeft(ev)
    if (left <= 0) return { cls: 'table-danger', badge: 'badge-danger', text: 'VOIDING NOW' }
    if (left <= URGENT_SEC) return { cls: 'table-danger', badge: 'badge-danger', text: `${fmtLeft(left)} left` }
    return { cls: 'table-warning', badge: 'badge-warning', text: `${fmtLeft(left)} left` }
  }

  return (
    <div className="card">
      <div className="card-body">
        <div className="d-flex align-items-center justify-content-between mb-2">
          <h5 className="card-title mb-0">
            Pending Result Tracker{' '}
            <span className={`badge badge-pill ${events.length ? 'badge-danger' : 'badge-success'}`}>{events.length}</span>
          </h5>
          <button type="button" className="btn btn-sm btn-outline-secondary" onClick={load}>Refresh</button>
        </div>
        <p className="text-muted mb-3">
          Match Odds / Bookmaker already declared, but these bets still have no result. Find the result and
          settle them in{' '}
          <Link to="/admin/settlement/fancy">Fancy</Link> / <Link to="/admin/settlement/match">Match</Link>{' '}
          Settlement before the countdown ends
          {data?.enabled ? ', or Auto Void will refund them.' : '. Auto Void is OFF, so nothing will void them.'}
          {' '}Refreshes every 15 s.
        </p>

        {error && <div className="alert alert-danger">{error}</div>}

        {!data ? (
          <p className="text-muted mb-0">Loading…</p>
        ) : !events.length ? (
          <p className="text-success mb-0">All clear: no declared event has unsettled bets.</p>
        ) : (
          <div className="table-responsive">
            <table className="table table-sm table-bordered mb-0">
              <thead>
                <tr>
                  <th>Event</th>
                  <th>Declared</th>
                  <th>First seen</th>
                  <th>Void at</th>
                  <th>Status</th>
                  <th className="text-right">Results to find</th>
                  <th className="text-right">Bets</th>
                  <th className="text-right">Users</th>
                  <th className="text-right">Stake</th>
                </tr>
              </thead>
              <tbody>
                {events.map((ev) => {
                  const st = rowState(ev)
                  const isOpen = !!open[ev.eventid]
                  return (
                    <Fragment key={ev.eventid}>
                      <tr
                        className={st.cls}
                        style={{ cursor: 'pointer' }}
                        onClick={() => setOpen((o) => ({ ...o, [ev.eventid]: !o[ev.eventid] }))}
                      >
                        <td>
                          <b>{isOpen ? '▾' : '▸'} {ev.match_title || ev.eventid}</b>
                          <div className="small text-muted">event {ev.eventid}</div>
                          {ev.last_error && <div className="small text-danger">last void error: {ev.last_error}</div>}
                        </td>
                        <td>{ev.anchor_market === 'BOOKMAKER' ? 'Bookmaker' : 'Match Odds'} ({ev.anchor_status})</td>
                        <td>{fmtTime(ev.anchor_seen_at)}</td>
                        <td>{fmtTime(ev.void_at)}</td>
                        <td>
                          <span className={`badge ${st.badge}`}>{st.text}</span>
                          {ev.manual_count > 0 && ev.manual_count < ev.bet_count && (
                            <div className="small">{ev.manual_count} manual - settle by hand</div>
                          )}
                        </td>
                        <td className="text-right">{ev.markets.length}</td>
                        <td className="text-right">{ev.bet_count}</td>
                        <td className="text-right">{ev.users}</td>
                        <td className="text-right">{fmtAmt(ev.total_stake)}</td>
                      </tr>
                      {isOpen && (
                        <tr>
                          <td colSpan={9} className="p-0">
                            <ResultChecklist ev={ev} autoVoidOn={!!data?.enabled} links={data?.links} />
                          </td>
                        </tr>
                      )}
                    </Fragment>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}

// Owner editor for the tracker's look-up sites (Cricbuzz, Flashscore...).
const EMPTY_LINK = { name: '', url: '', sport_id: '', sort_order: 0, active: true }

function ResultLinksManager() {
  const [rows, setRows] = useState([])
  const [form, setForm] = useState(EMPTY_LINK)
  const [editId, setEditId] = useState(null)
  const [saving, setSaving] = useState(false)

  const toast = (icon, title) =>
    Swal.fire({ toast: true, position: 'top-end', showConfirmButton: false, timer: 3000, icon, title })
  const errMsg = (e) => e.response?.data?.error || e.message

  const load = async () => {
    try {
      const r = await bettingConfigService.getResultLinks()
      if (r.success) setRows(r.data)
    } catch (e) {
      toast('error', errMsg(e))
    }
  }

  useEffect(() => {
    load()
  }, [])

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value }))

  const reset = () => {
    setForm(EMPTY_LINK)
    setEditId(null)
  }

  const handleSave = async (e) => {
    e.preventDefault()
    if (!/^https?:\/\//i.test(form.url.trim())) {
      toast('error', 'URL must start with http:// or https://')
      return
    }
    setSaving(true)
    try {
      const payload = { ...form, sport_id: form.sport_id || null, sort_order: Number(form.sort_order) || 0 }
      const r = editId
        ? await bettingConfigService.updateResultLink(editId, payload)
        : await bettingConfigService.createResultLink(payload)
      if (r.success) {
        toast('success', r.message || 'Saved')
        reset()
        load()
      }
    } catch (e2) {
      toast('error', errMsg(e2))
    } finally {
      setSaving(false)
    }
  }

  const handleEdit = (l) => {
    setEditId(l.id)
    setForm({ name: l.name, url: l.url, sport_id: l.sport_id || '', sort_order: l.sort_order, active: l.active })
  }

  const handleToggle = async (l) => {
    try {
      await bettingConfigService.updateResultLink(l.id, { active: !l.active })
      load()
    } catch (e) {
      toast('error', errMsg(e))
    }
  }

  const handleDelete = async (l) => {
    const ok = await Swal.fire({ title: `Delete "${l.name}"?`, icon: 'warning', showCancelButton: true, confirmButtonText: 'Delete' })
    if (!ok.isConfirmed) return
    try {
      await bettingConfigService.deleteResultLink(l.id)
      if (editId === l.id) reset()
      load()
    } catch (e) {
      toast('error', errMsg(e))
    }
  }

  return (
    <div className="card">
      <div className="card-body">
        <h5 className="card-title mb-1">Result Source Links</h5>
        <p className="text-muted mb-3">
          Websites the team opens from the tracker to find results. Put <code>{'{match}'}</code> in the URL to insert the
          event name, and <code>{'{market}'}</code> for the market name. A link with <code>{'{market}'}</code> shows on every
          market row (e.g. <code>{'https://www.google.com/search?q={match}+{market}'}</code>); the rest show once per event.
        </p>

        <form onSubmit={handleSave} className="form-row align-items-end mb-3">
          <div className="col-md-2 mb-2">
            <label className="small mb-1">Name</label>
            <input className="form-control form-control-sm" value={form.name} onChange={set('name')} maxLength={60} placeholder="Cricbuzz" required />
          </div>
          <div className="col-md-4 mb-2">
            <label className="small mb-1">URL</label>
            <input className="form-control form-control-sm" value={form.url} onChange={set('url')} placeholder="https://www.cricbuzz.com/..." required />
          </div>
          <div className="col-md-2 mb-2">
            <label className="small mb-1">Sport</label>
            <select className="form-control form-control-sm" value={form.sport_id} onChange={set('sport_id')}>
              <option value="">All sports</option>
              {SPORTS_LIST.map(([id, name]) => (
                <option key={id} value={id}>{name}</option>
              ))}
            </select>
          </div>
          <div className="col-md-1 mb-2">
            <label className="small mb-1">Order</label>
            <input type="number" className="form-control form-control-sm" value={form.sort_order} onChange={set('sort_order')} />
          </div>
          <div className="col-md-1 mb-2">
            <div className="custom-control custom-checkbox">
              <input type="checkbox" className="custom-control-input" id="rslActive" checked={form.active} onChange={set('active')} />
              <label className="custom-control-label small" htmlFor="rslActive">Active</label>
            </div>
          </div>
          <div className="col-md-2 mb-2">
            <button type="submit" className="btn btn-sm btn-primary mr-1" disabled={saving}>
              {editId ? 'Save' : 'Add link'}
            </button>
            {editId && (
              <button type="button" className="btn btn-sm btn-outline-secondary" onClick={reset}>Cancel</button>
            )}
          </div>
        </form>

        <div className="table-responsive">
          <table className="table table-sm table-bordered mb-0">
            <thead className="thead-light">
              <tr>
                <th>Name</th>
                <th>URL</th>
                <th>Sport</th>
                <th>Shows</th>
                <th className="text-right">Order</th>
                <th>Active</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {!rows.length && (
                <tr><td colSpan={7} className="text-muted">No links yet.</td></tr>
              )}
              {rows.map((l) => (
                <tr key={l.id} className={l.active ? '' : 'text-muted'}>
                  <td><b>{l.name}</b></td>
                  <td className="small" style={{ wordBreak: 'break-all' }}>{l.url}</td>
                  <td>{l.sport_id ? sportName(l.sport_id) : 'All sports'}</td>
                  <td>{isMarketLink(l) ? 'Each market' : 'Each event'}</td>
                  <td className="text-right">{l.sort_order}</td>
                  <td>
                    <button type="button" className={`btn btn-sm ${l.active ? 'btn-success' : 'btn-outline-secondary'}`} onClick={() => handleToggle(l)}>
                      {l.active ? 'On' : 'Off'}
                    </button>
                  </td>
                  <td className="text-nowrap">
                    <button type="button" className="btn btn-sm btn-outline-primary mr-1" onClick={() => handleEdit(l)}>Edit</button>
                    <button type="button" className="btn btn-sm btn-outline-danger" onClick={() => handleDelete(l)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

function AutoVoid() {
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [enabled, setEnabled] = useState(false)
  const [delay, setDelay] = useState(600)
  const [onMatchOdds, setOnMatchOdds] = useState(true)
  const [onBookmaker, setOnBookmaker] = useState(true)
  const [bounds, setBounds] = useState({ min: 30, max: 86400 })
  const [current, setCurrent] = useState(null)

  const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: false,
  })

  const apply = (data) => {
    setCurrent(data)
    setEnabled(!!data.enabled)
    setDelay(Number(data.delay_seconds) || 600)
    setOnMatchOdds(!!data.on_match_odds)
    setOnBookmaker(!!data.on_bookmaker)
    setBounds({ min: data.min_delay_seconds ?? 30, max: data.max_delay_seconds ?? 86400 })
  }

  const load = async () => {
    setLoading(true)
    try {
      const response = await bettingConfigService.getAutoVoid()
      if (response.success) apply(response.data)
    } catch (error) {
      Toast.fire({ icon: 'error', title: error.response?.data?.error || error.message })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
  }, [])

  const handleSave = async (e) => {
    e.preventDefault()
    const n = Number(delay)
    if (!Number.isInteger(n) || n < bounds.min || n > bounds.max) {
      Toast.fire({ icon: 'error', title: `Delay must be ${bounds.min}–${bounds.max} seconds` })
      return
    }
    if (enabled && !onMatchOdds && !onBookmaker) {
      Toast.fire({ icon: 'error', title: 'Pick at least one market to start the timer' })
      return
    }

    if (enabled && !current?.enabled) {
      const ok = await Swal.fire({
        title: 'Turn Auto Void on?',
        html: `Open bets with no result will be voided <b>${fmtDelay(n)}</b> after Match Odds / Bookmaker is declared. Stakes go back to the players.`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Turn on',
      })
      if (!ok.isConfirmed) return
    }

    setSaving(true)
    try {
      const response = await bettingConfigService.saveAutoVoid({
        enabled,
        delay_seconds: n,
        on_match_odds: onMatchOdds,
        on_bookmaker: onBookmaker,
      })
      if (response.success) {
        apply(response.data)
        Toast.fire({ icon: 'success', title: response.message || 'Saved' })
      }
    } catch (error) {
      Toast.fire({ icon: 'error', title: error.response?.data?.error || error.message })
    } finally {
      setSaving(false)
    }
  }

  return (
    <div>
      <div className="row">
        <div className="col-12">
          <div className="page-title-box d-flex align-items-center justify-content-between">
            <h4 className="mb-0 font-size-18">Auto Void</h4>
            {!loading && (
              <span className={`badge badge-pill ${current?.enabled ? 'badge-success' : 'badge-secondary'}`}>
                {current?.enabled ? 'ON' : 'OFF'}
              </span>
            )}
          </div>
        </div>
      </div>

      <div className="row">
        <div className="col-lg-6">
          <div className="card">
            <div className="card-body">
              <h5 className="card-title mb-3">Auto Void Settings</h5>

              {loading ? (
                <p className="text-muted mb-0">Loading…</p>
              ) : (
                <form onSubmit={handleSave}>
                  <div className="custom-control custom-switch mb-3">
                    <input
                      type="checkbox"
                      className="custom-control-input"
                      id="autoVoidEnabled"
                      checked={enabled}
                      onChange={(e) => setEnabled(e.target.checked)}
                    />
                    <label className="custom-control-label" htmlFor="autoVoidEnabled">
                      Enable auto void
                    </label>
                  </div>

                  <div className="form-group mb-3">
                    <label htmlFor="autoVoidDelay">Void after (seconds)</label>
                    <div className="input-group">
                      <input
                        id="autoVoidDelay"
                        type="number"
                        className="form-control"
                        min={bounds.min}
                        max={bounds.max}
                        step={1}
                        value={delay}
                        onChange={(e) => setDelay(e.target.value)}
                      />
                      <div className="input-group-append">
                        <span className="input-group-text">= {fmtDelay(delay)}</span>
                      </div>
                    </div>
                    <small className="form-text text-muted">
                      Counted from the moment the results cron first sees the Match Odds / Bookmaker
                      result. Allowed {bounds.min}–{bounds.max} seconds (600 = 10 minutes).
                    </small>
                  </div>

                  <div className="form-group mb-3">
                    <label className="d-block">Start the timer when the feed declares</label>
                    <div className="custom-control custom-checkbox custom-control-inline">
                      <input
                        type="checkbox"
                        className="custom-control-input"
                        id="autoVoidMO"
                        checked={onMatchOdds}
                        onChange={(e) => setOnMatchOdds(e.target.checked)}
                      />
                      <label className="custom-control-label" htmlFor="autoVoidMO">Match Odds</label>
                    </div>
                    <div className="custom-control custom-checkbox custom-control-inline">
                      <input
                        type="checkbox"
                        className="custom-control-input"
                        id="autoVoidBM"
                        checked={onBookmaker}
                        onChange={(e) => setOnBookmaker(e.target.checked)}
                      />
                      <label className="custom-control-label" htmlFor="autoVoidBM">Bookmaker</label>
                    </div>
                    <small className="form-text text-muted">
                      Whichever ticked market the feed settles (or voids) first starts the clock.
                    </small>
                  </div>

                  <button type="submit" className="btn btn-primary" disabled={saving}>
                    {saving ? 'Saving…' : 'Save'}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>

        <div className="col-lg-6">
          <div className="card">
            <div className="card-body">
              <h5 className="card-title mb-3">What it does</h5>
              <ol className="pl-3 mb-3">
                <li className="mb-2">
                  The results cron watches every event that still has open bets.
                </li>
                <li className="mb-2">
                  When the feed declares the event&apos;s <b>Match Odds</b> or <b>Bookmaker</b>{' '}
                  result, the timer for that event starts.
                </li>
                <li className="mb-2">
                  After the delay, every bet on that event that is still <b>open with no result</b>{' '}
                  (fancy sessions, other markets the feed never declared) is voided: exposure is
                  released and the stake returns to the player&apos;s cash.
                </li>
                <li className="mb-0">
                  Bets whose result has arrived are left to settlement. Bets you are settling by
                  hand (manual status) are never touched.
                </li>
              </ol>
              <div className="alert alert-info mb-2">
                Every auto void appears in <b>Settlement → Void Audit</b> as type{' '}
                <code>AUTO_TIMEOUT</code>, with the anchor market and time in the note.
              </div>
              <div className="alert alert-warning mb-0">
                <b>Careful:</b> a market the feed settled under a name our matcher does not
                recognise counts as &quot;no result&quot; and will be refunded, not paid. Keep the
                delay long enough for late fancy results to land.
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="row">
        <div className="col-12">
          <PendingResultTracker />
        </div>
      </div>

      <div className="row">
        <div className="col-12">
          <ResultLinksManager />
        </div>
      </div>
    </div>
  )
}

export default AutoVoid
