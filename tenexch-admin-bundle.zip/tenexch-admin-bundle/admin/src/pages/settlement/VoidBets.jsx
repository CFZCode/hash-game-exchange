import { Fragment, useCallback, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import {
  getSettledMarkets,
  getSettledBets,
  voidMarketAfterSettlement,
  voidBetAfterSettlement,
} from '../../services/api'
import useModalEnter from '../../hooks/useModalEnter'

const LIMIT = 200

const MARKETS_FOR_FANCY = [
  '1st Innings 6 Overs Line', '2nd Innings 6 Overs Line', '3rd Innings 6 Overs Line',
  '1st Innings 50 Overs Line', '2nd Innings 50 Overs Line', '3rd Innings 50 Overs Line',
  '1st Innings 40 Overs Line', '2nd Innings 40 Overs Line', '3rd Innings 40 Overs Line',
  '1st Innings 30 Overs Line', '2nd Innings 30 Overs Line', '3rd Innings 30 Overs Line',
  '1st Innings 20 Overs Line', '2nd Innings 20 Overs Line', '3rd Innings 20 Overs Line',
  '1st Innings 10 Overs Line', '2nd Innings 10 Overs Line', '3rd Innings 10 Overs Line',
  'Over By Over', 'Ball By Ball', 'Normal', 'khado', 'meter', 'fancy1', 'oddeven',
]

const TABS = [
  { key: 'MATCH_ODDS', label: 'Match Odds' },
  { key: 'BOOKMAKER', label: 'Bookmaker' },
  { key: 'FANCY', label: 'Fancy' },
  { key: 'OTHERS', label: 'Others' },
]

// Server market_type ko waise hi bhejta hai jaise bet me tha — 'MATCH_ODDS',
// 'Bookmaker', 'oddeven'… — isliye compare case-insensitive hona chahiye,
// warna 'Bookmaker' galti se OTHERS me chala jaata hai.
const FANCY_UPPER = MARKETS_FOR_FANCY.map((m) => m.toUpperCase())

// Upar ki list line markets ko OVER COUNT se naam deti hai, isliye team-prefixed
// ("SRI LANKA 2ND INNINGS 95 OVER LINE") aur bina-over-count wale ("... RUNS
// LINE") markets OTHERS tab me chale jaate the. Suffix se match karo — server
// bhi yahi karta hai (server/helper/lineMarket.js).
const isFancyMarketName = (mt) => FANCY_UPPER.includes(mt) || /\bLINE$/.test(mt)

function getTabForMarket(mkt) {
  const mt = String(mkt.marketType || '').toUpperCase()
  if (mt === 'MATCH_ODDS') return 'MATCH_ODDS'
  if (mt === 'BOOKMAKER') return 'BOOKMAKER'
  if (isFancyMarketName(mt)) return 'FANCY'
  return 'OTHERS'
}

function VoidBets() {
  const [activeTab, setActiveTab] = useState('MATCH_ODDS')
  const [markets, setMarkets] = useState([])
  const [loading, setLoading] = useState(false)
  const [search, setSearch] = useState('')

  const [expandedMarket, setExpandedMarket] = useState(null)
  const [bets, setBets] = useState([])
  const [betsLoading, setBetsLoading] = useState(false)

  const [confirmModal, setConfirmModal] = useState(null)
  // Confirm dialog open animation + outside click (hooks/useModalEnter)
  const confirmEnter = useModalEnter(() => setConfirmModal(null), !!confirmModal)
  const [txnPassword, setTxnPassword] = useState('')
  // ON (default) = user ke statement me "… -void" wali nayi debit line banegi.
  // OFF = silent void: settlement/commission ki entries statement se hat jaati
  // hain. Paisa dono soorat me ek hi tarah wapas jaata hai.
  const [writeStatement, setWriteStatement] = useState(true)
  const [windowHours, setWindowHours] = useState(24)

  const fetchMarkets = useCallback(async () => {
    setLoading(true)
    try {
      const resp = await getSettledMarkets({ limit: LIMIT, offset: 0, search })
      if (resp?.windowHours) setWindowHours(Number(resp.windowHours))
      if (resp?.success && Array.isArray(resp.data)) {
        setMarkets(resp.data)
      } else {
        setMarkets([])
      }
    } catch {
      setMarkets([])
    } finally {
      setLoading(false)
    }
  }, [search])

  useEffect(() => { fetchMarkets() }, [fetchMarkets])

  const filteredMarkets = markets.filter((mkt) => getTabForMarket(mkt) === activeTab)

  const tabCounts = {}
  TABS.forEach((t) => { tabCounts[t.key] = 0 })
  markets.forEach((mkt) => { tabCounts[getTabForMarket(mkt)]++ })

  const fetchBets = async (matchId, marketType) => {
    setBetsLoading(true)
    try {
      const resp = await getSettledBets({ match_id: matchId, market_type: marketType })
      if (resp?.success && Array.isArray(resp.data)) {
        setBets(resp.data)
      } else {
        setBets([])
      }
    } catch {
      setBets([])
    } finally {
      setBetsLoading(false)
    }
  }

  const isExpanded = (mkt) =>
    expandedMarket?.matchId === mkt.matchId && expandedMarket?.marketType === mkt.marketType

  const handleExpandMarket = (market) => {
    if (isExpanded(market)) {
      setExpandedMarket(null)
      setBets([])
    } else {
      setExpandedMarket({ matchId: market.matchId, marketType: market.marketType })
      fetchBets(market.matchId, market.marketType)
    }
  }

  const handleVoidMarket = (market) => { setTxnPassword(''); setWriteStatement(true); setConfirmModal({ type: 'market', data: market, loading: false }) }
  const handleVoidBet = (bet) => { setTxnPassword(''); setWriteStatement(true); setConfirmModal({ type: 'bet', data: bet, loading: false }) }

  const confirmVoid = async () => {
    if (!confirmModal) return
    setConfirmModal((prev) => ({ ...prev, loading: true }))
    try {
      if (confirmModal.type === 'market') {
        const resp = await voidMarketAfterSettlement({
          match_id: confirmModal.data.matchId,
          market_type: confirmModal.data.marketType,
          write_statement: writeStatement,
          transactionPassword: txnPassword,
        })
        if (resp?.success) {
          alert('Market voided successfully. Affected users: ' + (resp.affectedUsers || 0))
        } else {
          alert('Failed: ' + (resp?.error || 'Unknown error'))
        }
      } else {
        const resp = await voidBetAfterSettlement({
          ledger_id: confirmModal.data.ledgerId,
          write_statement: writeStatement,
          transactionPassword: txnPassword,
        })
        if (resp?.success) {
          alert('Bet voided successfully for user: ' + (confirmModal.data.username || confirmModal.data.userId))
        } else {
          alert('Failed: ' + (resp?.error || 'Unknown error'))
        }
      }
    } catch (err) {
      alert('Error: ' + (err?.response?.data?.error || err?.response?.data?.message || err.message))
    } finally {
      setConfirmModal(null)
      fetchMarkets()
      if (expandedMarket) {
        fetchBets(expandedMarket.matchId, expandedMarket.marketType)
      }
    }
  }

  const betTypeBadge = (bt) => {
    if (!bt) return <span className="text-muted">-</span>
    const isBack = bt === 'back' || bt === 'yes' || bt === 'Yes'
    return <span className={`badge ${isBack ? 'badge-primary' : 'badge-danger'} px-2`}>{bt.toUpperCase()}</span>
  }

  const resultBadge = (status) => {
    if (!status) return <span className="text-muted">-</span>
    const cls = status === 'won' ? 'badge-success' : status === 'loss' ? 'badge-danger' : 'badge-secondary'
    return <span className={`badge ${cls} px-2`}>{status.toUpperCase()}</span>
  }

  const netClass = (v) => (v >= 0 ? 'text-success font-weight-bold' : 'text-danger font-weight-bold')

  return (
    <div>
      <div className="row">
        <div className="col-12">
          <div className="page-title-box d-flex align-items-center justify-content-between">
            <h4 className="mb-0 font-size-18">Void Bets (After Settlement) — last {windowHours}h</h4>
            <div className="page-title-right">
              <ol className="breadcrumb m-0">
                <li className="breadcrumb-item"><Link to="/admin/home">Home</Link></li>
                <li className="breadcrumb-item active"><span aria-current="location">Void Bets</span></li>
              </ol>
            </div>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-body">
          <div className="row mb-3">
            <div className="col-md-8">
              <div className="input-group">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Search by match ID, market type, team name..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') fetchMarkets() }}
                />
                <div className="input-group-append">
                  <button className="btn btn-primary" onClick={fetchMarkets}>Search</button>
                </div>
              </div>
            </div>
            <div className="col-md-4 text-md-right mt-2 mt-md-0">
              <button className="btn btn-primary btn-sm" onClick={fetchMarkets} disabled={loading}>
                {loading ? 'Loading...' : 'Refresh'}
              </button>
            </div>
          </div>

          <ul className="nav nav-tabs mb-3">
            {TABS.map((tab) => (
              <li className="nav-item" key={tab.key}>
                <a
                  href="javascript:void(0)"
                  className={`nav-link ${activeTab === tab.key ? 'active' : ''}`}
                  onClick={(e) => { e.preventDefault(); setActiveTab(tab.key); setExpandedMarket(null); setBets([]) }}
                >
                  {tab.label} ({tabCounts[tab.key] || 0})
                </a>
              </li>
            ))}
          </ul>

          <div className="table-responsive">
            <table className="table table-bordered mb-0">
              <thead>
                <tr>
                  <th>Match Title</th>
                  <th>Market Type</th>
                  <th className="text-right">Entries</th>
                  <th className="text-right">Users</th>
                  <th className="text-right">Net Amount</th>
                  <th className="text-center" style={{ minWidth: 220 }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr><td colSpan={6} className="text-center">Loading...</td></tr>
                ) : filteredMarkets.length === 0 ? (
                  <tr><td colSpan={6} className="text-center">No markets settled in the last {windowHours} hours</td></tr>
                ) : (
                  filteredMarkets.map((mkt, idx) => (
                    <Fragment key={`${mkt.matchId}-${mkt.marketType}-${idx}`}>
                      <tr>
                        <td>
                          <div className="font-weight-bold">
                            {mkt.matchTitle || (mkt.teamOne && mkt.teamTwo ? `${mkt.teamOne} vs ${mkt.teamTwo}` : mkt.matchId)}
                          </div>
                          <small className="text-muted">{mkt.matchId}</small>
                        </td>
                        <td>{mkt.marketType || '-'}</td>
                        <td className="text-right">{mkt.totalEntries}</td>
                        <td className="text-right">{mkt.totalUsers}</td>
                        <td className="text-right">
                          <span className={netClass(mkt.totalNetAmount)}>
                            {mkt.totalNetAmount >= 0 ? '+' : ''}{Number(mkt.totalNetAmount || 0).toFixed(2)}
                          </span>
                        </td>
                        <td className="text-center">
                          <button onClick={() => handleExpandMarket(mkt)} className="btn btn-primary btn-sm mr-1">
                            {isExpanded(mkt) ? 'Hide Bets' : 'View Bets'}
                          </button>
                          <button onClick={() => handleVoidMarket(mkt)} className="btn btn-danger btn-sm">
                            Void Market
                          </button>
                        </td>
                      </tr>
                      {isExpanded(mkt) && (
                        <tr>
                          <td colSpan={6} className="bg-light p-3">
                            <div className="d-flex justify-content-between align-items-center mb-2">
                              <strong>Individual Bets — {mkt.marketType}</strong>
                              <small className="text-muted">{bets.length} bet{bets.length !== 1 ? 's' : ''}</small>
                            </div>
                            {betsLoading ? (
                              <div className="text-center text-muted py-3">Loading bets...</div>
                            ) : bets.length === 0 ? (
                              <div className="text-center text-muted py-3">No bets found for this market</div>
                            ) : (
                              <div className="table-responsive">
                                <table className="table table-sm table-bordered mb-0">
                                  <thead>
                                    <tr>
                                      <th>Bet ID</th>
                                      <th>User</th>
                                      <th>Selection</th>
                                      <th className="text-center">Bet Type</th>
                                      <th className="text-right">Odds</th>
                                      <th className="text-right">Stake</th>
                                      <th className="text-right">Net Amount</th>
                                      <th className="text-center">Result</th>
                                      <th className="text-center">Action</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {bets.map((bet) => (
                                      <tr key={bet.ledgerId}>
                                        <td>#{bet.betId}</td>
                                        <td>{bet.username}</td>
                                        <td>{bet.selectionName || '-'}</td>
                                        <td className="text-center">{betTypeBadge(bet.betType)}</td>
                                        <td className="text-right">{bet.odds ?? '-'}</td>
                                        <td className="text-right">{bet.stakeAmount != null ? Number(bet.stakeAmount).toFixed(2) : '-'}</td>
                                        <td className="text-right">
                                          <span className={netClass(bet.netamount)}>
                                            {bet.netamount >= 0 ? '+' : ''}{Number(bet.netamount || 0).toFixed(2)}
                                          </span>
                                        </td>
                                        <td className="text-center">{resultBadge(bet.resultStatus)}</td>
                                        <td className="text-center">
                                          <button onClick={() => handleVoidBet(bet)} className="btn btn-warning btn-sm">Void Bet</button>
                                        </td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </div>
                            )}
                          </td>
                        </tr>
                      )}
                    </Fragment>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {confirmModal && (
        <div style={{ position: 'absolute', zIndex: 1040 }}>
          <div role="dialog" className={confirmEnter.modalClass} aria-modal="true" style={{ display: 'block' }} onClick={confirmEnter.onBackdropClick}>
            <div className="modal-dialog modal-md">
              <div className="modal-content">
                <header className="modal-header">
                  <h5 className="modal-title">
                    {confirmModal.type === 'market' ? 'Void Entire Market' : 'Void Single Bet'}
                  </h5>
                  <button type="button" className="close" onClick={() => setConfirmModal(null)}>×</button>
                </header>
                <div className="modal-body">
                  <div className="alert alert-warning mb-0">
                    {confirmModal.type === 'market' ? (
                      <>
                        <p className="mb-2">
                          Void <strong>all bets</strong> in market <strong>{confirmModal.data.marketType}</strong> for match{' '}
                          <strong>{confirmModal.data.matchTitle || confirmModal.data.matchId}</strong>?
                        </p>
                        <p className="mb-0 text-muted">
                          This will reverse settled amounts for <strong>{confirmModal.data.totalEntries}</strong> entries across{' '}
                          <strong>{confirmModal.data.totalUsers}</strong> users. This action cannot be undone.
                        </p>
                      </>
                    ) : (
                      <>
                        <p className="mb-2">
                          Void bet <strong>#{confirmModal.data.betId}</strong> for user <strong>{confirmModal.data.username}</strong>?
                        </p>
                        <p className="mb-0 text-muted">
                          Net amount to reverse:{' '}
                          <span className={netClass(confirmModal.data.netamount)}>
                            {confirmModal.data.netamount >= 0 ? '+' : ''}{Number(confirmModal.data.netamount || 0).toFixed(2)}
                          </span>
                          . This action cannot be undone.
                        </p>
                      </>
                    )}
                  </div>
                  <div className="custom-control custom-checkbox mt-3">
                    <input
                      type="checkbox"
                      className="custom-control-input"
                      id="voidWriteStatement"
                      checked={writeStatement}
                      onChange={(e) => setWriteStatement(e.target.checked)}
                    />
                    <label className="custom-control-label" htmlFor="voidWriteStatement">
                      Create statement entry — a <strong>-void</strong> line in the user&apos;s account statement
                    </label>
                  </div>
                  {!writeStatement && (
                    <div className="alert alert-danger mt-2 mb-0 py-2">
                      <strong>Silent void.</strong> The settlement{' '}
                      {confirmModal.type === 'market' ? 'and commission entries' : 'and commission entry'} will be{' '}
                      <strong>deleted</strong> from the account statement — nothing will show there.
                      The money is refunded either way.
                    </div>
                  )}

                  <div className="form-group mt-3 mb-0">
                    <label>Transaction Password</label>
                    <input
                      type="password"
                      className="form-control"
                      value={txnPassword}
                      autoComplete="off"
                      onChange={(e) => setTxnPassword(e.target.value)}
                    />
                  </div>
                </div>
                <div className="modal-footer">
                  <button className="btn btn-secondary" onClick={() => setConfirmModal(null)}>Cancel</button>
                  <button className="btn btn-danger" onClick={confirmVoid} disabled={confirmModal.loading || !txnPassword}>
                    {confirmModal.loading ? 'Processing...' : 'Confirm Void'}
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div className={confirmEnter.backdropClass}></div>
        </div>
      )}
    </div>
  )
}

export default VoidBets
