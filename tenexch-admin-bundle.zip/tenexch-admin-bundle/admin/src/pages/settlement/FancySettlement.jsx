import { Fragment, useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import api, { getOpenBetsForMarket, voidSingleOpenBet } from '../../services/api'
import { API_ENDPOINTS } from '../../config/api'
import FancySettlementModal from '../../components/FancySettlementModal'
import useModalEnter from '../../hooks/useModalEnter'
import Pagination from '../../components/Pagination'

// Rows per page, per tab. The server returns every open group; each tab
// pages its own list client-side.
const PAGE_SIZE = 25

const MARKETS_FOR_FANCY = [
  '1st Innings 6 Overs Line', '2nd Innings 6 Overs Line', '3rd Innings 6 Overs Line',
  '1st Innings 50 Overs Line', '2nd Innings 50 Overs Line', '3rd Innings 50 Overs Line',
  '1st Innings 40 Overs Line', '2nd Innings 40 Overs Line', '3rd Innings 40 Overs Line',
  '1st Innings 30 Overs Line', '2nd Innings 30 Overs Line', '3rd Innings 30 Overs Line',
  '1st Innings 20 Overs Line', '2nd Innings 20 Overs Line', '3rd Innings 20 Overs Line',
  '1st Innings 10 Overs Line', '2nd Innings 10 Overs Line', '3rd Innings 10 Overs Line',
  'Over By Over', 'Ball By Ball', 'Normal', 'khado', 'meter', 'fancy1', 'oddeven',
]

// Line markets whose name carries no over count ("Sri Lanka 2nd Innings Runs
// Line") or a team prefix are missing from the list above, so they showed the
// market-type column instead of the runner name. Match the suffix by shape,
// the same way the server does (server/helper/lineMarket.js).
const isRunResultMarket = (marketType) =>
  MARKETS_FOR_FANCY.includes(marketType) || /\bline$/i.test(String(marketType || '').trim())

function getOrderedTabKeys(data) {
  if (!data || typeof data !== 'object') return []
  const keysWithData = Object.keys(data).filter((k) => Array.isArray(data[k]) && data[k].length > 0)
  const ordered = []
  for (const name of MARKETS_FOR_FANCY) {
    if (keysWithData.includes(name)) ordered.push(name)
  }
  if (keysWithData.includes('others')) ordered.push('others')
  for (const k of keysWithData) {
    if (!ordered.includes(k)) ordered.push(k)
  }
  return ordered
}

function FancySettlement() {
  const [fancyData, setFancyData] = useState(null)
  const [tabKeys, setTabKeys] = useState([])
  const [activeTab, setActiveTab] = useState(null)
  // { [tabKey]: page } — each tab remembers its own page
  const [pageByTab, setPageByTab] = useState({})
  const [loading, setLoading] = useState(false)
  const [modalShow, setModalShow] = useState(false)
  const [modalMode, setModalMode] = useState('declare')
  const [selectedRow, setSelectedRow] = useState(null)

  const [expandedRow, setExpandedRow] = useState(null)
  const [openBets, setOpenBets] = useState([])
  const [betsLoading, setBetsLoading] = useState(false)
  const [voidConfirm, setVoidConfirm] = useState(null)
  // Confirm dialog open animation + outside click (hooks/useModalEnter)
  const confirmEnter = useModalEnter(() => setVoidConfirm(null), !!voidConfirm)

  const fetchFanmatches = async (silent = false) => {
    if (!silent) setLoading(true)
    try {
      const response = await api.get(API_ENDPOINTS.INTERNALSETTLE.FANMATCHES)
      if (response.data?.success && response.data.data && typeof response.data.data === 'object') {
        const data = response.data.data
        setFancyData(data)
        const ordered = getOrderedTabKeys(data)
        setTabKeys(ordered)
        setActiveTab((prev) => (ordered.length > 0 && !ordered.includes(prev) ? ordered[0] : prev))
      } else {
        setFancyData({})
        setTabKeys([])
      }
    } catch (error) {
      if (!silent) console.error('Error fetching fancy matches:', error)
      setFancyData({})
      setTabKeys([])
    } finally {
      if (!silent) setLoading(false)
    }
  }

  useEffect(() => {
    fetchFanmatches()
    const interval = setInterval(() => fetchFanmatches(true), 2000)
    return () => clearInterval(interval)
  }, [])

  const rows = (activeTab && fancyData && Array.isArray(fancyData[activeTab])) ? fancyData[activeTab] : []

  // Declare / void shrinks a tab under the 2 s poll — clamp to the last real
  // page so a now-empty page never shows "No matches found".
  const totalPages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE))
  const currentPage = Math.min(pageByTab[activeTab] || 1, totalPages)
  const pageRows = rows.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE)

  const handlePageChange = (page) => {
    setPageByTab((prev) => ({ ...prev, [activeTab]: Math.min(Math.max(1, page), totalPages) }))
    setExpandedRow(null)
  }

  const handleDeclare = (row) => {
    setSelectedRow({ ...row, marketType: row.marketType || activeTab })
    setModalMode('declare')
    setModalShow(true)
  }

  const handleVoid = (row) => {
    setSelectedRow({ ...row, marketType: row.marketType || activeTab })
    setModalMode('void')
    setModalShow(true)
  }

  const handleSubmit = async () => {
    setModalShow(false)
    setSelectedRow(null)
  }

  const getRowKey = (row) =>
    `${row.matchId}-${row.marketType || activeTab}-${row.gameType}-${row.selectionName || ''}`

  const handleExpand = async (row) => {
    const key = getRowKey(row)
    if (expandedRow === key) {
      setExpandedRow(null)
      setOpenBets([])
      return
    }
    setExpandedRow(key)
    setBetsLoading(true)
    try {
      const resp = await getOpenBetsForMarket({
        match_id: row.matchId,
        market_type: row.marketType || activeTab,
        game_type: row.gameType || 'FAN',
        selection_name: row.selectionName || undefined,
      })
      setOpenBets(resp?.success ? resp.data : [])
    } catch {
      setOpenBets([])
    } finally {
      setBetsLoading(false)
    }
  }

  const handleVoidSingleBet = (bet) => setVoidConfirm({ ...bet, loading: false })

  const confirmVoidSingle = async () => {
    if (!voidConfirm) return
    setVoidConfirm((prev) => ({ ...prev, loading: true }))
    try {
      const resp = await voidSingleOpenBet({ bet_id: voidConfirm.id })
      if (resp?.success) {
        alert('Bet voided successfully for user: ' + (voidConfirm.username || voidConfirm.userId))
      } else {
        alert('Failed: ' + (resp?.error || 'Unknown error'))
      }
    } catch (err) {
      alert('Error: ' + (err?.response?.data?.error || err.message))
    } finally {
      setVoidConfirm(null)
      fetchFanmatches(true)
      setExpandedRow(null)
      setOpenBets([])
    }
  }

  const betTypeBadge = (bt) => {
    const isBack = bt === 'back' || bt === 'yes' || bt === 'Yes'
    return (
      <span className={`badge ${isBack ? 'badge-primary' : 'badge-danger'} px-2`}>
        {(bt || '-').toUpperCase()}
      </span>
    )
  }

  return (
    <div>
      <div className="row">
        <div className="col-12">
          <div className="page-title-box d-flex align-items-center justify-content-between">
            <h4 className="mb-0 font-size-18">Fancy Settlement</h4>
            <div className="page-title-right">
              <ol className="breadcrumb m-0">
                <li className="breadcrumb-item"><Link to="/admin/home">Home</Link></li>
                <li className="breadcrumb-item active"><span aria-current="location">Fancy Settlement</span></li>
              </ol>
            </div>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-body">
          <div className="d-flex justify-content-between align-items-center mb-3">
            <ul className="nav nav-tabs flex-wrap">
              {tabKeys.map((key) => (
                <li className="nav-item" key={key}>
                  <a
                    href="javascript:void(0)"
                    className={`nav-link ${activeTab === key ? 'active' : ''}`}
                    onClick={(e) => { e.preventDefault(); setActiveTab(key); setExpandedRow(null) }}
                  >
                    {key} ({fancyData?.[key]?.length ?? 0})
                  </a>
                </li>
              ))}
            </ul>
            <button type="button" onClick={() => fetchFanmatches()} disabled={loading} className="btn btn-primary btn-sm">
              {loading ? 'Loading...' : 'Refresh'}
            </button>
          </div>

          <div className="table-responsive">
            <table className="table table-bordered mb-0">
              <thead>
                <tr>
                  <th>Match Title</th>
                  <th>{isRunResultMarket(activeTab) ? 'Market Name' : 'Market Type'}</th>
                  <th className="text-right">Total Bets</th>
                  <th className="text-center" style={{ minWidth: 240 }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr><td colSpan={4} className="text-center">Loading...</td></tr>
                ) : rows.length === 0 ? (
                  <tr><td colSpan={4} className="text-center">No matches found</td></tr>
                ) : (
                  pageRows.map((row, index) => (
                    <Fragment key={`${row.matchId}-${row.eventId}-${index}`}>
                      <tr>
                        <td className="font-weight-bold">{row.eventName || row.matchTitle || '-'}</td>
                        <td>{isRunResultMarket(activeTab) ? (row.selectionName || '-') : (row.marketType ?? activeTab ?? '-')}</td>
                        <td className="text-right">{row.totalBets ?? 0}</td>
                        <td className="text-center">
                          <button onClick={() => handleDeclare(row)} className="btn btn-primary btn-sm mr-1">Declare</button>
                          <button onClick={() => handleVoid(row)} className="btn btn-secondary btn-sm mr-1">Void</button>
                          <button onClick={() => handleExpand(row)} className="btn btn-warning btn-sm">
                            {expandedRow === getRowKey(row) ? 'Hide' : 'Per Bet'}
                          </button>
                        </td>
                      </tr>
                      {expandedRow === getRowKey(row) && (
                        <tr>
                          <td colSpan={4} className="bg-light p-3">
                            <div className="d-flex justify-content-between align-items-center mb-2">
                              <strong>Individual Bets — {row.selectionName || row.marketType || activeTab}</strong>
                              <small className="text-muted">{openBets.length} bet{openBets.length !== 1 ? 's' : ''}</small>
                            </div>
                            {betsLoading ? (
                              <div className="text-center text-muted py-3">Loading bets...</div>
                            ) : openBets.length === 0 ? (
                              <div className="text-center text-muted py-3">No open bets found</div>
                            ) : (
                              <div className="table-responsive">
                                <table className="table table-sm table-bordered mb-0">
                                  <thead>
                                    <tr>
                                      <th>Bet ID</th>
                                      <th>User</th>
                                      <th>Selection</th>
                                      <th className="text-center">Bet Type</th>
                                      <th className="text-right">Odds</th>
                                      <th className="text-right">Stake</th>
                                      <th className="text-right">Liability</th>
                                      <th className="text-center">Action</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {openBets.map((bet) => (
                                      <tr key={bet.id}>
                                        <td>#{bet.id}</td>
                                        <td>{bet.username}</td>
                                        <td>{bet.selectionName || '-'}</td>
                                        <td className="text-center">{betTypeBadge(bet.betType)}</td>
                                        <td className="text-right">{bet.odds ?? '-'}</td>
                                        <td className="text-right">{bet.stakeAmount != null ? Number(bet.stakeAmount).toFixed(2) : '-'}</td>
                                        <td className="text-right">{bet.liability != null ? Number(bet.liability).toFixed(2) : '-'}</td>
                                        <td className="text-center">
                                          <button onClick={() => handleVoidSingleBet(bet)} className="btn btn-warning btn-sm">Void Bet</button>
                                        </td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </div>
                            )}
                          </td>
                        </tr>
                      )}
                    </Fragment>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {!loading && rows.length > 0 && (
            <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={handlePageChange} />
          )}
        </div>
      </div>

      <FancySettlementModal
        show={modalShow}
        onHide={() => { setModalShow(false); setSelectedRow(null) }}
        mode={modalMode}
        row={selectedRow}
        onSubmit={handleSubmit}
      />

      {voidConfirm && (
        <div style={{ position: 'absolute', zIndex: 1040 }}>
          <div role="dialog" className={confirmEnter.modalClass} aria-modal="true" style={{ display: 'block' }} onClick={confirmEnter.onBackdropClick}>
            <div className="modal-dialog modal-md">
              <div className="modal-content">
                <header className="modal-header">
                  <h5 className="modal-title">Void Single Bet</h5>
                  <button type="button" className="close" onClick={() => setVoidConfirm(null)}>×</button>
                </header>
                <div className="modal-body">
                  <div className="alert alert-warning mb-0">
                    <p className="mb-2">
                      Void bet <strong>#{voidConfirm.id}</strong> for user <strong>{voidConfirm.username}</strong>?
                    </p>
                    <p className="mb-2">
                      Selection: <strong>{voidConfirm.selectionName}</strong> · Stake: <strong>{Number(voidConfirm.stakeAmount || 0).toFixed(2)}</strong> · Odds: <strong>{voidConfirm.odds}</strong>
                    </p>
                    <p className="mb-0 text-muted">The stake will be refunded. This action cannot be undone.</p>
                  </div>
                </div>
                <div className="modal-footer">
                  <button className="btn btn-secondary" onClick={() => setVoidConfirm(null)}>Cancel</button>
                  <button className="btn btn-danger" onClick={confirmVoidSingle} disabled={voidConfirm.loading}>
                    {voidConfirm.loading ? 'Processing...' : 'Confirm Void'}
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div className={confirmEnter.backdropClass}></div>
        </div>
      )}
    </div>
  )
}

export default FancySettlement
