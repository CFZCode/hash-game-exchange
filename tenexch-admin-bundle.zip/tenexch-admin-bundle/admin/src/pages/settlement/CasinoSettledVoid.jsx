import { useCallback, useEffect, useState } from 'react'
import { getCasinoSettledBets, voidSettledCasinoBet } from '../../services/api'
import useModalEnter from '../../hooks/useModalEnter'

/**
 * "Settled" tab — casino bets jo settle ho chuki hain (won/lost) aur ab void
 * karni hain.
 *
 * Sirf **pichhle 24 ghante** ki bets dikhti hain — server bhi isse purani bet
 * ka void mana kar deta hai (window backend me hai, UI sirf usko dikhata hai).
 *
 * Unsettled wale case se alag: yahan sirf lock wapas nahi hota, poori
 * settlement ulti hoti hai — cash + inr_balance dono, user ke P/L counters,
 * credits ledger ki ulti entry, parent staff ka bal_up, aur all_point chain.
 * Isliye har row par "Net" dikhaya jaata hai — wahi number ulta hoga.
 */
const LIMIT = 100

const fmt = (v) => Number(v || 0).toFixed(2)

const fmtDate = (v) => {
  if (!v) return '-'
  const d = new Date(v)
  const p = (n) => String(n).padStart(2, '0')
  return `${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()} ${p(d.getHours())}:${p(d.getMinutes())}`
}

function CasinoSettledVoid() {
  const [bets, setBets] = useState([])
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(0)
  const [search, setSearch] = useState('')
  const [query, setQuery] = useState('')
  const [resultFilter, setResultFilter] = useState('')
  const [windowHours, setWindowHours] = useState(24)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [confirm, setConfirm] = useState(null)
  // Confirm dialog open animation + outside click (hooks/useModalEnter)
  const confirmEnter = useModalEnter(() => setConfirm(null), !!confirm)
  const [txnPassword, setTxnPassword] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [result, setResult] = useState(null)

  const fetchBets = useCallback(async () => {
    setLoading(true)
    setError('')
    try {
      const resp = await getCasinoSettledBets({ search: query, result: resultFilter, limit: LIMIT, offset: page * LIMIT })
      if (resp?.success) {
        setBets(Array.isArray(resp.bets) ? resp.bets : [])
        setTotal(Number(resp.total || 0))
        if (resp.windowHours) setWindowHours(Number(resp.windowHours))
      } else {
        setBets([])
        setTotal(0)
        setError(resp?.error || 'Failed to load')
      }
    } catch (err) {
      setBets([])
      setTotal(0)
      setError(err?.response?.data?.error || err.message)
    } finally {
      setLoading(false)
    }
  }, [query, page, resultFilter])

  useEffect(() => { fetchBets() }, [fetchBets])

  const submitVoid = async () => {
    if (!confirm) return
    setSubmitting(true)
    setResult(null)
    try {
      const resp = await voidSettledCasinoBet({ bet_id: confirm.betId, transactionPassword: txnPassword })
      if (resp?.success) {
        setResult({ ok: true, message: resp.message || 'Voided' })
        setConfirm(null)
        fetchBets()
      } else {
        setResult({ ok: false, message: resp?.error || resp?.message || 'Failed' })
      }
    } catch (err) {
      setResult({ ok: false, message: err?.response?.data?.error || err?.response?.data?.message || err.message })
    } finally {
      setSubmitting(false)
    }
  }

  const totalPages = Math.max(1, Math.ceil(total / LIMIT))

  return (
    <div>
      <div className="row mb-3">
        <div className="col-md-8">
          <div className="input-group">
            <input
              type="text"
              className="form-control"
              placeholder="Search last 24h by username, bet id, round id, game or selection..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') { setPage(0); setQuery(search) } }}
            />
            <div className="input-group-append">
              <button className="btn btn-primary" onClick={() => { setPage(0); setQuery(search) }}>Search</button>
            </div>
          </div>
        </div>
        <div className="col-md-4 text-md-right mt-2 mt-md-0">
          <select
            className="form-control d-inline-block mr-2"
            style={{ width: 'auto' }}
            value={resultFilter}
            onChange={(e) => { setPage(0); setResultFilter(e.target.value) }}
          >
            <option value="">All results</option>
            <option value="won">Won</option>
            <option value="lost">Lost</option>
            <option value="void">Voided</option>
          </select>
          <span className="mr-2 text-muted">{total} bet{total !== 1 ? 's' : ''} · last {windowHours}h</span>
          <button className="btn btn-primary btn-sm" onClick={fetchBets} disabled={loading}>
            {loading ? 'Loading...' : 'Refresh'}
          </button>
        </div>
      </div>

      <div className="alert alert-info py-2">
        Showing bets settled in the <strong>last {windowHours} hours</strong> only — older settled bets
        cannot be voided from here. Void reverses the <strong>whole settlement</strong>: cash <em>and</em>{' '}
        main balance (inr), user P/L, credit ledger, parent staff bal-up and the all-point chain.
      </div>

      {error && <div className="alert alert-danger py-2">{error}</div>}
      {result && !confirm && (
        <div className={`alert py-2 ${result.ok ? 'alert-success' : 'alert-danger'}`}>{result.message}</div>
      )}

      <div className="table-responsive">
        <table className="table table-bordered mb-0">
          <thead>
            <tr>
              <th>Bet ID</th>
              <th>User</th>
              <th>Game</th>
              <th>Selection</th>
              <th className="text-center">Type</th>
              <th className="text-right">Odds</th>
              <th className="text-right">Stake</th>
              <th className="text-center">Result</th>
              <th className="text-right">Net</th>
              <th>Settled</th>
              <th className="text-center">Action</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={11} className="text-center">Loading...</td></tr>
            ) : bets.length === 0 ? (
              <tr><td colSpan={11} className="text-center">No settled casino bets in the last {windowHours} hours</td></tr>
            ) : (
              bets.map((b) => (
                <tr key={b.betId}>
                  <td>#{b.betId}</td>
                  <td>
                    <div className="font-weight-bold">{b.username}</div>
                    <small className="text-muted">#{b.userId}</small>
                  </td>
                  <td>
                    <div>{b.gameName}</div>
                    <small className="text-muted">{b.roundId}</small>
                  </td>
                  <td>{b.selection}</td>
                  <td className="text-center">
                    <span className={`badge px-2 ${b.betType === 'lay' ? 'badge-danger' : 'badge-primary'}`}>
                      {String(b.betType || '-').toUpperCase()}
                    </span>
                  </td>
                  <td className="text-right">{b.odds}</td>
                  <td className="text-right">{fmt(b.stake)}</td>
                  <td className="text-center">
                    <span className={`badge px-2 ${
                      b.alreadyVoid ? 'badge-secondary' : b.resultStatus === 'won' ? 'badge-success' : 'badge-danger'
                    }`}>
                      {String(b.resultStatus || '').toUpperCase()}
                    </span>
                  </td>
                  <td className={`text-right font-weight-bold ${b.netPoint >= 0 ? 'text-success' : 'text-danger'}`}>
                    {b.netPoint >= 0 ? '+' : ''}{fmt(b.netPoint)}
                  </td>
                  <td><small>{fmtDate(b.settledAt)}</small></td>
                  <td className="text-center">
                    {b.alreadyVoid ? (
                      <small className="text-muted">already voided</small>
                    ) : (
                      <button
                        className="btn btn-danger btn-sm"
                        onClick={() => { setTxnPassword(''); setResult(null); setConfirm(b) }}
                      >
                        Void Bet
                      </button>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {totalPages > 1 && (
        <div className="d-flex justify-content-between align-items-center mt-2">
          <button className="btn btn-secondary btn-sm" disabled={page === 0} onClick={() => setPage((p) => p - 1)}>
            Prev
          </button>
          <span className="text-muted">Page {page + 1} / {totalPages}</span>
          <button
            className="btn btn-secondary btn-sm"
            disabled={page + 1 >= totalPages}
            onClick={() => setPage((p) => p + 1)}
          >
            Next
          </button>
        </div>
      )}

      {confirm && (
        <div style={{ position: 'absolute', zIndex: 1040 }}>
          <div role="dialog" className={confirmEnter.modalClass} aria-modal="true" style={{ display: 'block' }} onClick={confirmEnter.onBackdropClick}>
            <div className="modal-dialog modal-md">
              <div className="modal-content">
                <header className="modal-header">
                  <h5 className="modal-title">Void Settled Casino Bet</h5>
                  <button type="button" className="close" onClick={() => setConfirm(null)}>×</button>
                </header>
                <div className="modal-body">
                  <div className="alert alert-warning">
                    <p className="mb-2">
                      Void bet <strong>#{confirm.betId}</strong> ({confirm.selection}) for user{' '}
                      <strong>{confirm.username}</strong> on <strong>{confirm.gameName}</strong>?
                      This bet is already settled as <strong>{String(confirm.resultStatus).toUpperCase()}</strong>.
                    </p>
                    <p className="mb-0 text-muted">
                      Reversal: cash and main balance both change by{' '}
                      <span className={confirm.netPoint >= 0 ? 'text-danger font-weight-bold' : 'text-success font-weight-bold'}>
                        {confirm.netPoint >= 0 ? '-' : '+'}{fmt(Math.abs(confirm.netPoint))}
                      </span>
                      . User P/L, credit ledger, parent bal-up and all-point are reversed too.
                      This cannot be undone.
                    </p>
                  </div>
                  <div className="form-group mb-0">
                    <label>Transaction Password</label>
                    <input
                      type="password"
                      className="form-control"
                      value={txnPassword}
                      autoComplete="off"
                      onChange={(e) => setTxnPassword(e.target.value)}
                      onKeyDown={(e) => { if (e.key === 'Enter' && txnPassword) submitVoid() }}
                    />
                  </div>
                  {result && !result.ok && <div className="alert alert-danger mt-3 mb-0 py-2">{result.message}</div>}
                </div>
                <div className="modal-footer">
                  <button className="btn btn-secondary" onClick={() => setConfirm(null)}>Cancel</button>
                  <button className="btn btn-danger" onClick={submitVoid} disabled={submitting || !txnPassword}>
                    {submitting ? 'Processing...' : 'Confirm Void'}
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div className={confirmEnter.backdropClass}></div>
        </div>
      )}
    </div>
  )
}

export default CasinoSettledVoid
