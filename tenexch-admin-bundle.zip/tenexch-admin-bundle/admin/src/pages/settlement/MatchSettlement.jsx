import { Fragment, useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import api, { getOpenBetsForMarket, voidSingleOpenBet } from '../../services/api'
import { API_ENDPOINTS } from '../../config/api'
import SettlementModal from '../../components/SettlementModal'
import useModalEnter from '../../hooks/useModalEnter'

const LIMIT = 100
const DEFAULT_OFFSET = 0

function MatchSettlement() {
  const [activeTab, setActiveTab] = useState('MO')
  const [matches, setMatches] = useState([])
  const [loading, setLoading] = useState(false)
  const [modalShow, setModalShow] = useState(false)
  const [modalMode, setModalMode] = useState('declare')
  const [selectedMatch, setSelectedMatch] = useState(null)

  const [expandedRow, setExpandedRow] = useState(null)
  const [openBets, setOpenBets] = useState([])
  const [betsLoading, setBetsLoading] = useState(false)
  const [voidConfirm, setVoidConfirm] = useState(null)
  // Confirm dialog open animation + outside click (hooks/useModalEnter)
  const confirmEnter = useModalEnter(() => setVoidConfirm(null), !!voidConfirm)

  const fetchMatches = async (silent = false) => {
    if (!silent) setLoading(true)
    try {
      const response = await api.get(API_ENDPOINTS.INTERNALSETTLE.MOMATCHES, {
        params: { limit: LIMIT, offset: DEFAULT_OFFSET },
      })
      if (response.data?.success && Array.isArray(response.data.data)) {
        setMatches(response.data.data)
      } else {
        setMatches([])
      }
    } catch (error) {
      if (!silent) console.error('Error fetching MO/BM matches:', error)
      setMatches([])
    } finally {
      if (!silent) setLoading(false)
    }
  }

  useEffect(() => {
    fetchMatches()
    const interval = setInterval(() => fetchMatches(true), 2000)
    return () => clearInterval(interval)
  }, [])

  const filteredMatches = matches.filter((m) => m.gameType === activeTab)

  const handleDeclare = (row) => {
    setSelectedMatch(row)
    setModalMode('declare')
    setModalShow(true)
  }

  const handleVoid = (row) => {
    setSelectedMatch(row)
    setModalMode('void')
    setModalShow(true)
  }

  const handleSettlementSubmit = async () => {
    setModalShow(false)
    setSelectedMatch(null)
    await fetchMatches(true)
  }

  const isExpanded = (row) =>
    expandedRow === `${row.matchId}-${row.marketType}-${row.gameType}`

  const handleExpand = async (row) => {
    const key = `${row.matchId}-${row.marketType}-${row.gameType}`
    if (expandedRow === key) {
      setExpandedRow(null)
      setOpenBets([])
      return
    }
    setExpandedRow(key)
    setBetsLoading(true)
    try {
      const resp = await getOpenBetsForMarket({
        match_id: row.matchId,
        market_type: row.marketType,
        game_type: row.gameType,
      })
      setOpenBets(resp?.success ? resp.data : [])
    } catch {
      setOpenBets([])
    } finally {
      setBetsLoading(false)
    }
  }

  const handleVoidSingleBet = (bet) => setVoidConfirm({ ...bet, loading: false })

  const confirmVoidSingle = async () => {
    if (!voidConfirm) return
    setVoidConfirm((prev) => ({ ...prev, loading: true }))
    try {
      const resp = await voidSingleOpenBet({ bet_id: voidConfirm.id })
      if (resp?.success) {
        alert('Bet voided successfully for user: ' + (voidConfirm.username || voidConfirm.userId))
      } else {
        alert('Failed: ' + (resp?.error || 'Unknown error'))
      }
    } catch (err) {
      alert('Error: ' + (err?.response?.data?.error || err.message))
    } finally {
      setVoidConfirm(null)
      fetchMatches(true)
      setExpandedRow(null)
      setOpenBets([])
    }
  }

  const betTypeBadge = (bt) => {
    const isBack = bt === 'back' || bt === 'yes' || bt === 'Yes'
    return (
      <span className={`badge ${isBack ? 'badge-primary' : 'badge-danger'} px-2`}>
        {(bt || '-').toUpperCase()}
      </span>
    )
  }

  return (
    <div>
      <div className="row">
        <div className="col-12">
          <div className="page-title-box d-flex align-items-center justify-content-between">
            <h4 className="mb-0 font-size-18">Match Settlement</h4>
            <div className="page-title-right">
              <ol className="breadcrumb m-0">
                <li className="breadcrumb-item"><Link to="/admin/home">Home</Link></li>
                <li className="breadcrumb-item active"><span aria-current="location">Match Settlement</span></li>
              </ol>
            </div>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-body">
          <div className="d-flex justify-content-between align-items-center mb-3">
            <ul className="nav nav-tabs">
              <li className="nav-item">
                <a
                  href="javascript:void(0)"
                  className={`nav-link ${activeTab === 'MO' ? 'active' : ''}`}
                  onClick={(e) => { e.preventDefault(); setActiveTab('MO'); setExpandedRow(null) }}
                >
                  Match Odds
                </a>
              </li>
              <li className="nav-item">
                <a
                  href="javascript:void(0)"
                  className={`nav-link ${activeTab === 'BM' ? 'active' : ''}`}
                  onClick={(e) => { e.preventDefault(); setActiveTab('BM'); setExpandedRow(null) }}
                >
                  Bookmaker
                </a>
              </li>
            </ul>
            <button type="button" onClick={() => fetchMatches()} disabled={loading} className="btn btn-primary btn-sm">
              {loading ? 'Loading...' : 'Refresh'}
            </button>
          </div>

          <div className="table-responsive">
            <table className="table table-bordered mb-0">
              <thead>
                <tr>
                  <th>Match Title</th>
                  <th>Market Type</th>
                  <th className="text-right">Total Bets</th>
                  <th className="text-center" style={{ minWidth: 240 }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr><td colSpan={4} className="text-center">Loading...</td></tr>
                ) : filteredMatches.length === 0 ? (
                  <tr><td colSpan={4} className="text-center">No matches found</td></tr>
                ) : (
                  filteredMatches.map((row, index) => (
                    <Fragment key={`${row.matchId}-${row.eventId}-${row.gameType}-${index}`}>
                      <tr>
                        <td className="font-weight-bold">{row.matchTitle ?? `${row.teamOne} vs ${row.teamTwo}`}</td>
                        <td>{row.marketType || '-'}</td>
                        <td className="text-right">{row.totalBets ?? 0}</td>
                        <td className="text-center">
                          <button onClick={() => handleDeclare(row)} className="btn btn-primary btn-sm mr-1">Declare</button>
                          <button onClick={() => handleVoid(row)} className="btn btn-secondary btn-sm mr-1">Void</button>
                          <button onClick={() => handleExpand(row)} className="btn btn-warning btn-sm">
                            {isExpanded(row) ? 'Hide' : 'Per Bet'}
                          </button>
                        </td>
                      </tr>
                      {isExpanded(row) && (
                        <tr>
                          <td colSpan={4} className="bg-light p-3">
                            <div className="d-flex justify-content-between align-items-center mb-2">
                              <strong>Individual Bets — {row.marketType}</strong>
                              <small className="text-muted">{openBets.length} bet{openBets.length !== 1 ? 's' : ''}</small>
                            </div>
                            {betsLoading ? (
                              <div className="text-center text-muted py-3">Loading bets...</div>
                            ) : openBets.length === 0 ? (
                              <div className="text-center text-muted py-3">No open bets found</div>
                            ) : (
                              <div className="table-responsive">
                                <table className="table table-sm table-bordered mb-0">
                                  <thead>
                                    <tr>
                                      <th>Bet ID</th>
                                      <th>User</th>
                                      <th>Selection</th>
                                      <th className="text-center">Bet Type</th>
                                      <th className="text-right">Odds</th>
                                      <th className="text-right">Stake</th>
                                      <th className="text-right">Liability</th>
                                      <th className="text-center">Action</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {openBets.map((bet) => (
                                      <tr key={bet.id}>
                                        <td>#{bet.id}</td>
                                        <td>{bet.username}</td>
                                        <td>{bet.selectionName || '-'}</td>
                                        <td className="text-center">{betTypeBadge(bet.betType)}</td>
                                        <td className="text-right">{bet.odds ?? '-'}</td>
                                        <td className="text-right">{bet.stakeAmount != null ? Number(bet.stakeAmount).toFixed(2) : '-'}</td>
                                        <td className="text-right">{bet.liability != null ? Number(bet.liability).toFixed(2) : '-'}</td>
                                        <td className="text-center">
                                          <button onClick={() => handleVoidSingleBet(bet)} className="btn btn-warning btn-sm">Void Bet</button>
                                        </td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </div>
                            )}
                          </td>
                        </tr>
                      )}
                    </Fragment>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <SettlementModal
        show={modalShow}
        onHide={() => { setModalShow(false); setSelectedMatch(null) }}
        mode={modalMode}
        match={selectedMatch}
        onSubmit={handleSettlementSubmit}
      />

      {voidConfirm && (
        <div style={{ position: 'absolute', zIndex: 1040 }}>
          <div role="dialog" className={confirmEnter.modalClass} aria-modal="true" style={{ display: 'block' }} onClick={confirmEnter.onBackdropClick}>
            <div className="modal-dialog modal-md">
              <div className="modal-content">
                <header className="modal-header">
                  <h5 className="modal-title">Void Single Bet</h5>
                  <button type="button" className="close" onClick={() => setVoidConfirm(null)}>×</button>
                </header>
                <div className="modal-body">
                  <div className="alert alert-warning mb-0">
                    <p className="mb-2">
                      Void bet <strong>#{voidConfirm.id}</strong> for user <strong>{voidConfirm.username}</strong>?
                    </p>
                    <p className="mb-2">
                      Selection: <strong>{voidConfirm.selectionName}</strong> · Stake: <strong>{Number(voidConfirm.stakeAmount || 0).toFixed(2)}</strong> · Odds: <strong>{voidConfirm.odds}</strong>
                    </p>
                    <p className="mb-0 text-muted">The stake will be refunded. This action cannot be undone.</p>
                  </div>
                </div>
                <div className="modal-footer">
                  <button className="btn btn-secondary" onClick={() => setVoidConfirm(null)}>Cancel</button>
                  <button className="btn btn-danger" onClick={confirmVoidSingle} disabled={voidConfirm.loading}>
                    {voidConfirm.loading ? 'Processing...' : 'Confirm Void'}
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div className={confirmEnter.backdropClass}></div>
        </div>
      )}
    </div>
  )
}

export default MatchSettlement
