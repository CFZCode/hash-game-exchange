import { Fragment, useCallback, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { getCasinoOpenBets, voidCasinoBets } from '../../services/api'
import CasinoSettledVoid from './CasinoSettledVoid'
import useModalEnter from '../../hooks/useModalEnter'

/**
 * Casino Settlement — wo casino bets jo settle HI NAHI hue (status
 * open/processing), aur unka void.
 *
 * "Void Bets" page se alag hai: wahan bet pehle settle ho chuki hoti hai aur
 * settlement ke BAAD void karni hoti hai. Yahan bet kabhi settle hi nahi hui —
 * uska placement lock user ke cash aur exposure me atka rehta hai jab tak koi
 * void na kare.
 *
 * Void hamesha (user + round) ke level par hota hai: server aadha round void
 * karne se mana kar deta hai, kyunki book market ka exposure row poore market
 * ka min() hota hai. Isliye "Void Bet" button sirf tab dikhta hai jab us round
 * par us user ki wahi ek bet ho.
 */
const fmt = (v) => Number(v || 0).toFixed(2)

const ago = (ts) => {
  if (!ts) return '-'
  const mins = Math.floor((Date.now() - new Date(ts).getTime()) / 60000)
  if (mins < 60) return `${mins}m`
  const hrs = Math.floor(mins / 60)
  if (hrs < 24) return `${hrs}h`
  return `${Math.floor(hrs / 24)}d`
}

function CasinoSettlement() {
  // Do case hain aur dono ka paisa alag chalta hai:
  //   unsettled → sirf cash me refund, inr_balance waisa hi
  //   settled   → poori settlement ulti: cash + inr dono, P/L, points, sab
  const [tab, setTab] = useState('unsettled')
  const [rounds, setRounds] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [expanded, setExpanded] = useState(null)
  const [confirm, setConfirm] = useState(null)
  // Confirm dialog open animation + outside click (hooks/useModalEnter)
  const confirmEnter = useModalEnter(() => setConfirm(null), !!confirm)
  const [txnPassword, setTxnPassword] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [result, setResult] = useState(null)

  const fetchRounds = useCallback(async () => {
    setLoading(true)
    setError('')
    try {
      const resp = await getCasinoOpenBets()
      setRounds(resp?.success && Array.isArray(resp.data) ? resp.data : [])
      if (resp && !resp.success) setError(resp.error || 'Failed to load')
    } catch (err) {
      setRounds([])
      setError(err?.response?.data?.error || err.message)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { fetchRounds() }, [fetchRounds])

  const openConfirm = (round, bet = null) => {
    setTxnPassword('')
    setResult(null)
    setConfirm({ round, bet })
  }

  const submitVoid = async () => {
    if (!confirm) return
    setSubmitting(true)
    setResult(null)
    try {
      const betIds = confirm.bet ? [confirm.bet.betId] : confirm.round.bets.map((b) => b.betId)
      const resp = await voidCasinoBets({ bet_ids: betIds, transactionPassword: txnPassword })
      if (resp?.success) {
        setResult({ ok: true, message: resp.message || 'Voided' })
        setConfirm(null)
        fetchRounds()
      } else {
        setResult({ ok: false, message: resp?.error || resp?.message || 'Failed' })
      }
    } catch (err) {
      setResult({ ok: false, message: err?.response?.data?.error || err?.response?.data?.message || err.message })
    } finally {
      setSubmitting(false)
    }
  }

  const totalBets = rounds.reduce((s, r) => s + r.betCount, 0)
  const totalLocked = rounds.reduce((s, r) => s + Number(r.totalExposer || 0), 0)

  return (
    <div>
      <div className="row">
        <div className="col-12">
          <div className="page-title-box d-flex align-items-center justify-content-between">
            <h4 className="mb-0 font-size-18">Casino Settlement (Unsettled Bets)</h4>
            <div className="page-title-right">
              <ol className="breadcrumb m-0">
                <li className="breadcrumb-item"><Link to="/admin/home">Home</Link></li>
                <li className="breadcrumb-item active"><span aria-current="location">Casino Settlement</span></li>
              </ol>
            </div>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-body">
          <ul className="nav nav-tabs mb-3">
            <li className="nav-item">
              <a
                href="javascript:void(0)"
                className={`nav-link ${tab === 'unsettled' ? 'active' : ''}`}
                onClick={(e) => { e.preventDefault(); setTab('unsettled') }}
              >
                Unsettled (refund to cash)
              </a>
            </li>
            <li className="nav-item">
              <a
                href="javascript:void(0)"
                className={`nav-link ${tab === 'settled' ? 'active' : ''}`}
                onClick={(e) => { e.preventDefault(); setTab('settled') }}
              >
                Settled (reverse cash + inr)
              </a>
            </li>
          </ul>

          {tab === 'settled' ? <CasinoSettledVoid /> : (<>
      <div className="d-flex justify-content-between align-items-center mb-2">
        <div>
          <strong>{rounds.length}</strong> stuck round{rounds.length !== 1 ? 's' : ''} ·{' '}
          <strong>{totalBets}</strong> bet{totalBets !== 1 ? 's' : ''} · locked exposure{' '}
          <span className="text-danger font-weight-bold">{fmt(totalLocked)}</span>
        </div>
        <button className="btn btn-primary btn-sm" onClick={fetchRounds} disabled={loading}>
          {loading ? 'Loading...' : 'Refresh'}
        </button>
      </div>

      {error && <div className="alert alert-danger py-2">{error}</div>}
      {result && !confirm && (
        <div className={`alert py-2 ${result.ok ? 'alert-success' : 'alert-danger'}`}>{result.message}</div>
      )}

      <div className="table-responsive">
        <table className="table table-bordered mb-0">
          <thead>
            <tr>
              <th>User</th>
              <th>Game</th>
              <th>Round</th>
              <th className="text-right">Bets</th>
              <th className="text-right">Stake</th>
              <th className="text-right">Locked</th>
              <th className="text-center">Age</th>
              <th className="text-center" style={{ minWidth: 210 }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={8} className="text-center">Loading...</td></tr>
            ) : rounds.length === 0 ? (
              <tr><td colSpan={8} className="text-center">No unsettled casino bets 🎉</td></tr>
            ) : (
              rounds.map((r) => (
                <Fragment key={r.groupKey}>
                  <tr>
                    <td>
                      <div className="font-weight-bold">{r.username}</div>
                      <small className="text-muted">#{r.userId}</small>
                    </td>
                    <td>{r.gameName || '-'}</td>
                    <td><small className="text-muted">{r.eventId}</small></td>
                    <td className="text-right">{r.betCount}</td>
                    <td className="text-right">{fmt(r.totalStake)}</td>
                    <td className="text-right text-danger font-weight-bold">{fmt(r.totalExposer)}</td>
                    <td className="text-center">{ago(r.oldestAt)}</td>
                    <td className="text-center">
                      <button
                        className="btn btn-primary btn-sm mr-1"
                        onClick={() => setExpanded(expanded === r.groupKey ? null : r.groupKey)}
                      >
                        {expanded === r.groupKey ? 'Hide Bets' : 'View Bets'}
                      </button>
                      <button className="btn btn-danger btn-sm" onClick={() => openConfirm(r)}>
                        Void Round
                      </button>
                    </td>
                  </tr>
                  {expanded === r.groupKey && (
                    <tr>
                      <td colSpan={8} className="bg-light p-3">
                        <table className="table table-sm table-bordered mb-0">
                          <thead>
                            <tr>
                              <th>Bet ID</th>
                              <th>Selection</th>
                              <th className="text-center">Type</th>
                              <th className="text-right">Odds</th>
                              <th className="text-right">Stake</th>
                              <th className="text-right">Exposer</th>
                              <th className="text-center">Status</th>
                              <th className="text-center">Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            {r.bets.map((b) => (
                              <tr key={b.betId}>
                                <td>#{b.betId}</td>
                                <td>{b.selection}</td>
                                <td className="text-center">
                                  <span className={`badge px-2 ${b.betType === 'lay' ? 'badge-danger' : 'badge-primary'}`}>
                                    {String(b.betType || '-').toUpperCase()}
                                  </span>
                                </td>
                                <td className="text-right">{b.odds}</td>
                                <td className="text-right">{fmt(b.stake)}</td>
                                <td className="text-right">{fmt(b.exposer)}</td>
                                <td className="text-center">
                                  <span className="badge badge-secondary px-2">{String(b.status || '').toUpperCase()}</span>
                                </td>
                                <td className="text-center">
                                  {r.betCount === 1 ? (
                                    <button className="btn btn-warning btn-sm" onClick={() => openConfirm(r, b)}>
                                      Void Bet
                                    </button>
                                  ) : (
                                    <small className="text-muted">use Void Round</small>
                                  )}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </td>
                    </tr>
                  )}
                </Fragment>
              ))
            )}
          </tbody>
        </table>
      </div>
          </>)}
        </div>
      </div>

      {confirm && (
        <div style={{ position: 'absolute', zIndex: 1040 }}>
          <div role="dialog" className={confirmEnter.modalClass} aria-modal="true" style={{ display: 'block' }} onClick={confirmEnter.onBackdropClick}>
            <div className="modal-dialog modal-md">
              <div className="modal-content">
                <header className="modal-header">
                  <h5 className="modal-title">{confirm.bet ? 'Void Casino Bet' : 'Void Casino Round'}</h5>
                  <button type="button" className="close" onClick={() => setConfirm(null)}>×</button>
                </header>
                <div className="modal-body">
                  <div className="alert alert-warning">
                    <p className="mb-2">
                      {confirm.bet ? (
                        <>Void bet <strong>#{confirm.bet.betId}</strong> ({confirm.bet.selection})</>
                      ) : (
                        <>Void <strong>all {confirm.round.betCount} bet(s)</strong> of round{' '}
                          <strong>{confirm.round.eventId}</strong></>
                      )}{' '}
                      for user <strong>{confirm.round.username}</strong> on{' '}
                      <strong>{confirm.round.gameName}</strong>?
                    </p>
                    <p className="mb-0 text-muted">
                      Refund to cash:{' '}
                      <span className="text-success font-weight-bold">
                        {fmt(-(confirm.bet ? confirm.bet.exposer : confirm.round.totalExposer))}
                      </span>
                      . Main balance (inr) unchanged — no win/loss is booked. This cannot be undone.
                    </p>
                  </div>
                  <div className="form-group mb-0">
                    <label>Transaction Password</label>
                    <input
                      type="password"
                      className="form-control"
                      value={txnPassword}
                      autoComplete="off"
                      onChange={(e) => setTxnPassword(e.target.value)}
                      onKeyDown={(e) => { if (e.key === 'Enter' && txnPassword) submitVoid() }}
                    />
                  </div>
                  {result && !result.ok && <div className="alert alert-danger mt-3 mb-0 py-2">{result.message}</div>}
                </div>
                <div className="modal-footer">
                  <button className="btn btn-secondary" onClick={() => setConfirm(null)}>Cancel</button>
                  <button className="btn btn-danger" onClick={submitVoid} disabled={submitting || !txnPassword}>
                    {submitting ? 'Processing...' : 'Confirm Void'}
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div className={confirmEnter.backdropClass}></div>
        </div>
      )}
    </div>
  )
}

export default CasinoSettlement
