import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useSelector, useDispatch } from 'react-redux'
import Swal from 'sweetalert2'
import { authService } from '../../services/authService'
import { updateUser } from '../../store/slices/authSlice'

function ChangePassword() {
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const { user, role, isAuthenticated } = useSelector((state) => state.auth)

  // If no password change needed, redirect away
  useEffect(() => {
    if (sessionStorage.getItem('needPasswordChange') !== 'true') {
      navigate(isAuthenticated ? '/admin/home' : '/admin', { replace: true })
    }
  }, [isAuthenticated, navigate])

  // Leaving this page any way other than submitting the form (browser back OR a
  // page refresh) must land on the login page with the session fully dropped.
  // The hard redirect via window.location bypasses React Router, so its own
  // popstate handling can't re-render this page (the needPasswordChange guard
  // would otherwise bounce right back here).
  useEffect(() => {
    const dropSessionAndGoToLogin = () => {
      sessionStorage.removeItem('needPasswordChange')
      localStorage.removeItem('adminToken')
      localStorage.removeItem('ownerToken')
      localStorage.removeItem('staffToken')
      localStorage.removeItem('activeRole')
      localStorage.removeItem('adminUser')
      window.location.replace('/admin')
    }

    // Refresh: only bounce to login when the RELOAD itself happened on this
    // page (navEntry.name is the URL that was loaded). A session that merely
    // started with a reload elsewhere (e.g. F5 on the login page) and then
    // SPA-navigated here must NOT be treated as a change-password refresh.
    const navEntry = performance.getEntriesByType('navigation')[0]
    if (navEntry && navEntry.type === 'reload' && navEntry.name.includes('/admin/change-password')) {
      dropSessionAndGoToLogin()
      return
    }

    // Back button: push a sentinel history entry so back triggers popstate here.
    window.history.pushState(null, '', window.location.href)
    window.addEventListener('popstate', dropSessionAndGoToLogin)
    return () => window.removeEventListener('popstate', dropSessionAndGoToLogin)
  }, [])

  if (sessionStorage.getItem('needPasswordChange') !== 'true') return null

  const [formData, setFormData] = useState({
    OldPassword: '',
    NewPassword: '',
    ConfirmNewPassword: ''
  })
  const [errors, setErrors] = useState({})
  const [submitted, setSubmitted] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: false,
  })

  // Same messages/conditions as the reference site (exact text)
  const validateField = (name, value, all = formData) => {
    if (name === 'OldPassword') {
      if (!value) return 'The OldPassword field is required'
    }
    if (name === 'NewPassword') {
      if (!value) return 'The NewPassword field is required'
      if (!/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(value)) return 'The password must contain at least: 1 uppercase letter, 1 lowercase letter, 1 number'
      if (value.length < 8) return 'The NewPassword field must be at least 8 characters'
    }
    if (name === 'ConfirmNewPassword') {
      if (!value) return 'The NewPassword field is required'
      if (value !== all.NewPassword) return 'The NewPassword confirmation does not match'
    }
    return ''
  }

  const validate = () => {
    const newErrors = {}
    for (const name of ['OldPassword', 'NewPassword', 'ConfirmNewPassword']) {
      const err = validateField(name, formData[name])
      if (err) newErrors[name] = err
    }
    return newErrors
  }

  const handleChange = (e) => {
    const { name, value } = e.target
    const next = { ...formData, [name]: value }
    setFormData(next)
    // Live validation, like the reference (message appears/updates while typing)
    setErrors(prev => {
      const updated = { ...prev, [name]: validateField(name, value, next) }
      // Changing NewPassword can make/break the confirmation match too
      if (name === 'NewPassword' && next.ConfirmNewPassword) {
        updated.ConfirmNewPassword = validateField('ConfirmNewPassword', next.ConfirmNewPassword, next)
      }
      return updated
    })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setSubmitted(true)

    const newErrors = validate()
    setErrors(newErrors)
    if (Object.keys(newErrors).length > 0) return

    setIsSubmitting(true)
    try {
      const response = await authService.changePassword({
        oldPassword: formData.OldPassword,
        newPassword: formData.NewPassword
      }, role)

      if (response?.success) {
        Toast.fire({ icon: 'success', text: 'Password change successful.' })
        sessionStorage.removeItem('needPasswordChange')
        dispatch(updateUser({ ...user, first_login: true }))
        const txnPass = response.transactionPassword || response.data?.transactionPassword || ''
        navigate(`/admin/change-password-success/${txnPass}`, { replace: true })
      } else {
        Toast.fire({ icon: 'error', text: response?.message || 'Failed to change password' })
      }
    } catch (error) {
      Toast.fire({ icon: 'error', text: error?.response?.data?.message || 'Failed to change password' })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="wrapper point-login">
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-md-8">
            <div className="point-login-box">
              <div className="login-left-box">
                <img src="/admin/assets/front/logo.png" alt="TENEXCH" />
              </div>
              <div className="login-right-box">
                <div>
                  <h1>Login</h1>
                  <form data-vv-scope="form-changepassword" className="change-form p-2" onSubmit={handleSubmit}>
                    <div className="form-group">
                      <div className="input-group">
                        <div className="input-group-prepend">
                          <span className="input-group-text">
                            <i className="fa fa-lock"></i>
                          </span>
                        </div>
                        <input type="password" name="OldPassword" placeholder="Old Password" className="form-control" aria-required="true" aria-invalid={errors.OldPassword ? 'true' : 'false'} value={formData.OldPassword} onChange={handleChange} disabled={isSubmitting} />
                      </div>
                      {errors.OldPassword && <span className="error">{errors.OldPassword}</span>}
                    </div>
                    <div className="form-group">
                      <div className="input-group">
                        <div className="input-group-prepend">
                          <span className="input-group-text">
                            <i className="fa fa-lock"></i>
                          </span>
                        </div>
                        <input type="password" name="NewPassword" placeholder="New Password" className="form-control" aria-required="true" aria-invalid={errors.NewPassword ? 'true' : 'false'} value={formData.NewPassword} onChange={handleChange} disabled={isSubmitting} />
                      </div>
                      {errors.NewPassword && <span className="error">{errors.NewPassword}</span>}
                    </div>
                    <div className="form-group">
                      <div className="input-group">
                        <div className="input-group-prepend">
                          <span className="input-group-text">
                            <i className="fa fa-lock"></i>
                          </span>
                        </div>
                        <input type="password" name="ConfirmNewPassword" placeholder="Confirm Password" className="form-control" aria-required="true" aria-invalid={errors.ConfirmNewPassword ? 'true' : 'false'} value={formData.ConfirmNewPassword} onChange={handleChange} disabled={isSubmitting} />
                      </div>
                      {errors.ConfirmNewPassword && <span className="error">{errors.ConfirmNewPassword}</span>}
                    </div>
                    <div className="form-group mb-0">
                      <button type="submit" className="btn btn-block btn-theme1 btn-lg btn-submit btn-secondary" disabled={isSubmitting}>
                        {isSubmitting ? 'Changing...' : 'Change Password'}
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>

          <div className="col-md-8">
            <div className="point-footer">
              <div className="gambling-icons">
                <a href="javascript:void(0)" role="button">
                  <img src="/admin/assets/18plus.png" alt="18+" />
                </a>
                <a href="https://www.gamblingtherapy.org/en" target="_blank" rel="noreferrer">
                  <img src="/admin/assets/gt.png" alt="Gambling Therapy" />
                </a>
                <a href="https://www.gamcare.org.uk/" target="_blank" rel="noreferrer">
                  <img src="/admin/assets/gamecare.png" alt="GamCare" />
                </a>
                <a href="https://www.begambleaware.org/" target="_blank" rel="noreferrer">
                  <img src="/admin/assets/gamble-aware.png" alt="BeGambleAware" />
                </a>
                <a href="https://www.gamstop.co.uk/" target="_blank" rel="noreferrer">
                  <img src="/admin/assets/game-stop.png" alt="GamStop" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default ChangePassword
