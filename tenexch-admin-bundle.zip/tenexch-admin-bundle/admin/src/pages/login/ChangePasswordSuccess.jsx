import { useParams, useNavigate, Link } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import { logout } from '../../store/slices/authSlice'

function ChangePasswordSuccess() {
  const { transactionPassword } = useParams()
  const navigate = useNavigate()
  const dispatch = useDispatch()

  const handleBack = () => {
    dispatch(logout())
    navigate('/admin', { replace: true })
  }

  return (
    <div className="cp-success-box">
      <div className="text-center container">
        <h1><span className="text-success">Success! Your password has been updated successfully.</span></h1>
        <h1>Your transaction password is <span className="text-info token-box">{transactionPassword}</span>. </h1>
        <h2>Please remember this transaction password, from now on all transcation of the website can be done only with this password and keep one thing in mind, do not share this password with anyone.</h2>
        <h2 className="mt-3 text-dark">Thank you, Team tenexchn.com</h2>
        <div className="font-hindi">
          <h1 className="mt-5"><span className="text-success">Success! आपका पासवर्ड बदला जा चुका है।</span></h1>
          <h1>आपका लेनदेन पासवर्ड <span className="text-info token-box">{transactionPassword}</span> है।</h1>
          <h2>कृपया इस लेन-देन के पासवर्ड को याद रखें, अब से वेबसाइट के सभी हस्तांतरण केवल इस पासवर्ड से किए जा सकते हैं और एक बात का ध्यान रखें, इस पासवर्ड को किसी के साथ साझा न करें।</h2>
          {/* The Hindi block used to stop at the paragraph above — the reference
              closes it with its own sign-off, the mirror of the English one on
              line 21, same `mt-3 text-dark` h2. Domain stays OUR `tenexchn.com`
              (user, 2026-09-15), not the reference screenshot's `tenexch.com`,
              so both sign-offs read the same. */}
          <h2 className="mt-3 text-dark">धन्यवाद, टीम tenexchn.com</h2>
        </div>
        {/* Reference markup, matched: the link sits directly in the container
            with no wrapper div, and it is `btn btn-dark btn-lg mt-5` — ours was
            a `btn-primary` inside an extra `mt-4` div, so it rendered blue,
            smaller and at the wrong spacing.

            Two deliberate differences from the capture. The reference's
            `router-link-active` is vue-router's own marker and nothing styles it
            on this page (only .home-new-header and .tabs-mobile use it), so it
            is not reproduced. And the click still clears the session before
            navigating — the reference's plain link leaves it standing, which on
            a password-change screen it should not. */}
        <Link to="/admin" className="btn btn-dark btn-lg mt-5" style={{ minWidth: 200 }} onClick={handleBack}>
          <i className="fas fa-arrow-left mr-3"></i>Back
        </Link>
      </div>
    </div>
  )
}

export default ChangePasswordSuccess
