import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import Swal from 'sweetalert2'
import { useAuth } from '../../hooks/useAuth'
import { needsReloadAfterLogout, RELOAD_AND_RETRY_MSG } from '../../utils/reloginGuard'
import { isExecutive, firstAllowedRoute } from '../../utils/permissions'
import EighteenPlusModal from '../../components/EighteenPlusModal'

function Login() {
  const navigate = useNavigate()
  const { loginAsync, isLoggingIn, isAuthenticated, user, verify2FA, isVerifying2FA } = useAuth()

  // Clear any stale password change flag when landing on login page (not authenticated)
  useEffect(() => {
    if (!isAuthenticated) {
      sessionStorage.removeItem('needPasswordChange')
    }
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  const [formData, setFormData] = useState({
    username: '',
    password: ''
  })

  const [errors, setErrors] = useState({
    username: '',
    password: '',
    general: ''
  })

  // 18+ badge in the footer opens the age-verification modal. Reference binds
  // it with `v-b-modal.eighteenPlus` on the same anchor (capture, 2026-09-21).
  const [show18Plus, setShow18Plus] = useState(false)

  // Toast configuration
  const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: false,
    didOpen: (toast) => {
      toast.onmouseenter = Swal.stopTimer;
      toast.onmouseleave = Swal.resumeTimer;
    }
  });

  // Redirect after login
  useEffect(() => {
    if (!isAuthenticated) return

    // sessionStorage flag is set immediately in useAuth onSuccess,
    // so we can check it right away without waiting for profile
    const needChange = sessionStorage.getItem('needPasswordChange') === 'true'
    if (needChange) {
      navigate('/admin/change-password', { replace: true })
      return
    }

    // For normal login, wait until profile (user) is loaded. Executives land
    // on the first page their permission map allows (never a denied route).
    if (user) {
      navigate(isExecutive() ? firstAllowedRoute() : '/admin/home', { replace: true })
    }
  }, [isAuthenticated, user, navigate])

  const validateField = (name, value) => {
    let error = ''
    if (name === 'username') {
      if (!value || value.trim() === '') {
        error = 'The username field is required'
      }
    } else if (name === 'password') {
      if (!value || value.trim() === '') {
        error = 'The password field is required'
      }
    }
    return error
  }

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData({ ...formData, [name]: value })
    const error = validateField(name, value)
    setErrors({ ...errors, [name]: error })
  }

  const handleBlur = (e) => {
    const { name, value } = e.target
    const error = validateField(name, value)
    setErrors({ ...errors, [name]: error })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (isLoggingIn) return

    const usernameError = validateField('username', formData.username)
    const passwordError = validateField('password', formData.password)

    setErrors({
      username: usernameError,
      password: passwordError,
      general: ''
    })

    if (!usernameError && !passwordError) {
      // Reference: after a logout EVERY login attempt is refused with this
      // toast until the user reloads the page themselves, same account or
      // not (see utils/reloginGuard.js).
      if (needsReloadAfterLogout()) {
        Toast.fire({ icon: 'error', text: RELOAD_AND_RETRY_MSG })
        return
      }
      try {
        const isEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.username)
        const credentials = { password: formData.password }
        if (isEmail) {
          credentials.email = formData.username
        } else {
          credentials.username = formData.username
        }

        const response = await loginAsync(credentials)

        if (response?.require2FA) {
          // One-shot flag: tells the 2FA screen this landing came straight from
          // a login call, so the OTP has JUST been sent and it must not ask for
          // another. A refresh consumes it, and the absence is what makes the
          // screen re-request the code. location.state cannot be the signal —
          // it survives a reload via history state.
          sessionStorage.setItem('admin2FAFresh', '1');
          // App codes (Google Authenticator, or our Secure Auth app) get the
          // screen at /3 (reference); Telegram stays on /2.
          const isAppCode = response.method === 'google' || response.method === 'android';
          navigate(isAppCode ? '/admin/loginauth/3' : '/admin/loginauth/2', {
            state: {
              staffId: response.staffId,
              ownerId: response.ownerId,
              // 'google' | 'android' | 'telegram' — decides the heading, and whether a
              // resend applies at all (Google codes come from the app).
              method: response.method || 'telegram'
            }
          });
          // No toast — the 2FA screen shows no messages, and one fired from
          // here would land on top of it right after the navigation.
          return;
        }

        if (response?.success) {
          if (response?.first_login === false) {
            Toast.fire({ icon: 'success', text: 'Welcome, You are logged in first time. Please change your password to continue.' });
          } else {
            Toast.fire({ icon: 'success', text: 'success' });
          }
          // useEffect will handle redirect after profile loads
        } else {
          const raw = response?.message || response?.error
          const msg = /not found/i.test(raw || '') ? 'UserName not available' : (raw || 'Login failed. Please try again.')
          setErrors({ ...errors, general: msg })
          Toast.fire({ icon: 'error', text: msg });
        }
      } catch (error) {
        const raw = error?.response?.data?.message || error?.response?.data?.error || error?.message
        const msg = /not found/i.test(raw || '') ? 'UserName not available' : (raw || 'Login failed. Please check your credentials.')
        setErrors({ ...errors, general: msg })
        Toast.fire({ icon: 'error', text: msg });
      }
    }
  }

  return (
    <div className="wrapper point-login">
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-md-8">
            <div className="point-login-box">
              <div className="login-left-box">
                <img src="/admin/assets/logo.png" />
              </div>
              <div className="login-right-box">
                <div>
                  <h1>Login</h1>
                  <form
                    autoComplete="off"
                    data-vv-scope="form-login"
                    action=""
                    method="POST"
                    className="p-2 mt-4"
                    onSubmit={handleSubmit}
                  >
                    <p className="text-muted">Sign In to your account</p>

                    <div className="form-group">
                      <div className="input-group">
                        <div className="input-group-prepend">
                          <span className="input-group-text">
                            <i className="fas fa-user"></i>
                          </span>
                        </div>
                        <input
                          id="input-1"
                          name="username"
                          type="text"
                          placeholder="Enter Username"
                          className="form-control-lg form-control"
                          value={formData.username}
                          onChange={handleChange}
                          onBlur={handleBlur}
                        />
                      </div>
                      {errors.username && <span className="error">{errors.username}</span>}
                    </div>

                    <div className="form-group">
                      <div className="input-group">
                        <div className="input-group-prepend">
                          <span className="input-group-text">
                            <i className="fa fa-lock"></i>
                          </span>
                        </div>
                        <input
                          id="input-2"
                          name="password"
                          type="password"
                          placeholder="Enter password"
                          className="form-control-lg form-control"
                          value={formData.password}
                          onChange={handleChange}
                          onBlur={handleBlur}
                        />
                      </div>
                      {errors.password && <span className="error">{errors.password}</span>}
                    </div>

                    <div className="row">
                      <div className="col-12">
                        <button
                          type="submit"
                          className="btn btn-block btn-theme1 btn-lg btn-submit btn-secondary"
                        >
                          Sign In
                        </button>
                      </div>
                    </div>

                  </form>
                </div>
              </div>
            </div>
          </div>

          <div className="col-md-8">
            <div className="point-footer">
              <div className="gambling-icons">
                <a href="#" role="button" onClick={(e) => { e.preventDefault(); setShow18Plus(true) }}>
                  <img src="/admin/assets/18plus.png" />
                </a>
                <a href="https://www.gamblingtherapy.org/en" target="_blank" rel="noreferrer">
                  <img src="/admin/assets/gt.png" />
                </a>
                <a href="https://www.gamcare.org.uk/" target="_blank" rel="noreferrer">
                  <img src="/admin/assets/gamecare.png" />
                </a>
                <a href="https://www.begambleaware.org/" target="_blank" rel="noreferrer">
                  <img src="/admin/assets/gamble-aware.png" />
                </a>
                <a href="https://www.gamstop.co.uk/" target="_blank" rel="noreferrer">
                  <img src="/admin/assets/game-stop.png" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      <EighteenPlusModal show={show18Plus} onClose={() => setShow18Plus(false)} />
    </div>
  )
}

export default Login
