import { Suspense } from 'react'
import { useParams } from 'react-router-dom'
import CasinoGameScreen from '../../components/casino/CasinoGameScreen'
import { GAME_PAGES, VIP_GAME_PAGES, VCASINO_GAME_PAGES, PCASINO_GAME_PAGES } from './gameRegistry'

// /admin/casino/:gtype — dedicated game page (games/<gtype>/) if registered,
// warna generic screen. Data + streaming user-site wale hi sources se
// (CasinoGameScreen ke hooks me).
// variant: 'vip' → /admin/casino/vip/:gtype (VIP_GAME_PAGES), 'vcasino' →
// /admin/vcasino/:gtype (VCASINO_GAME_PAGES), 'pcasino' → /admin/pcasino/:gtype
// (PCASINO_GAME_PAGES), default Our Casino.
const REGISTRY = { vip: VIP_GAME_PAGES, vcasino: VCASINO_GAME_PAGES, pcasino: PCASINO_GAME_PAGES }
export default function CasinoGamePage({ variant = '' }) {
  const { gtype } = useParams()
  const GamePage = (REGISTRY[variant] || GAME_PAGES)[gtype]

  // reference structure: page-content > <div> > detail-page-container
  return (
    <div data-v-5a10e370="">
      <div data-v-5a10e370="" className="detail-page-container">
        {GamePage ? (
          <Suspense fallback={null}>
            <GamePage />
          </Suspense>
        ) : (
          <CasinoGameScreen gtype={gtype} />
        )}
      </div>
    </div>
  )
}
