import { Fragment } from 'react'
import BetTableVTeen20 from '../../../../components/casino/BetTableVTeen20'
import VCasinoTable from '../../../../components/casino/VCasinoTable'
import SidebarRulesCard from '../../../../components/casino/SidebarRulesCard'
import { computeAdminBook, getMarketsForGame } from '../../../../utils/casinoBook'
import { cardSrc } from '../../../../components/casino/cards/cardUtils'

const GAME_TYPE = 'vteen20'
const GAME_NAME = 'V-20-20 Teenpatti'

// Sidebar Rules card (capture): Pair Plus table
const PAIR_PLUS_RULES = [
  ['Pair', '1 TO 1'],
  ['Flush', '1 TO 4'],
  ['Straight', '1 TO 6'],
  ['Trio', '1 TO 30'],
  ['Straight Flush', '1 TO 40'],
]

// Overlay: `.player-card.playera-card` / `.playerb-card`, label + three cards
// each; feed `card` = six codes dealt alternately, A = 1st/3rd/5th, B =
// 2nd/4th/6th (same split as the non-virtual Teen20 page); face-down 1.png.
const PLAYERS = [
  { key: 'a', label: 'Player A', cls: 'playera', idx: [0, 2, 4] },
  { key: 'b', label: 'Player B', cls: 'playerb', idx: [1, 3, 5] },
]

const renderCards = (gameData) => {
  const cards = String(gameData?.card || '').split(',').map((c) => c.trim())
  return PLAYERS.map((p, pi) => (
    <Fragment key={p.key}>
      {pi > 0 && ' '}
      <div className={`player-card ${p.cls}-card`}>
        {' '}
        <div className={`w-100 ${p.cls} mb-2`}>{p.label}</div>
        {p.idx.map((i) => (
          <Fragment key={i}>
            {' '}
            <span data-v-b64efdfa="">
              <img data-v-b64efdfa="" src={cardSrc(cards[i])} />
            </span>
          </Fragment>
        ))}
      </div>
    </Fragment>
  ))
}

// last-results `win` 1 → "A " resulta, else " B " resultb (capture A B B B A A)
const renderResult = (r, i, onClick) => (
  String(r.win) === '1'
    ? <span key={i} className="resulta" onClick={onClick}>{'A '}</span>
    : <span key={i} className="resultb" onClick={onClick}>{' B '}</span>
)

// V-20-20 Teenpatti — /admin/vcasino/teen20. Reference DOM (capture
// 2026-09-19): shell VCasinoTable (.casino-table.vcasino.vteen20), board
// BetTableVTeen20, sidebar My Bets + Pair Plus Rules card. Book:
// getMarketsForGame (all Fancy → single markets, as the non-virtual page).
export default function VTeen20() {
  return (
    <VCasinoTable
      gameType={GAME_TYPE}
      gameName={GAME_NAME}
      tableClass="vteen20"
      cards={renderCards}
      renderResult={renderResult}
      sidebarExtra={<SidebarRulesCard title="Pair Plus" rows={PAIR_PLUS_RULES} />}
    >
      {(gameData, myBets) => (
        <BetTableVTeen20
          gameData={gameData}
          exposures={computeAdminBook(myBets, getMarketsForGame(GAME_TYPE, gameData))}
        />
      )}
    </VCasinoTable>
  )
}
