import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import CasinoMyBetsSidebar from '../../../../components/casino/CasinoMyBetsSidebar'
import MatkaCalendarModal from '../../../../components/casino/MatkaCalendarModal'
import useCasinoGame from '../../../../hooks/casino/useCasinoGame'
import useCasinoLastResults from '../../../../hooks/casino/useCasinoLastResults'
import useCasinoMyBets from '../../../../hooks/casino/useCasinoMyBets'
import useCasinoStream from '../../../../hooks/casino/useCasinoStream'

const GAME_TYPE = 'worli3'

// Worli 3 (Matka) — reference layout goal2 se alag hai: `casino-table worli
// matka`, bazar tabs (nav-pills, countdown `ptime` API se + `mtime`), video
// (timer khali, sirf Home icon), results strip me bazar names
// (last-results: [{ mid, win: "Diamond" }, ...]). Bet table nahi hota.
export default function Worli3() {
  const isAuth = useSelector((s) => Boolean(s.auth.token))
  const [activeIdx, setActiveIdx] = useState(0)
  const [showLr, setShowLr] = useState(true)
  // Reference: a market chip opens that market's month calendar (not a round result).
  const [calendarMarket, setCalendarMarket] = useState(null)
  const [isMobile, setIsMobile] = useState(() => typeof window !== 'undefined' && window.innerWidth < 768)

  useEffect(() => {
    const onResize = () => setIsMobile(window.innerWidth < 768)
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  const { data: bazars = [] } = useCasinoGame(GAME_TYPE, { isArray: true })
  const { data: lastResults = [] } = useCasinoLastResults(GAME_TYPE)
  const { streamUrl } = useCasinoStream(GAME_TYPE)
  const { myBets } = useCasinoMyBets(GAME_TYPE, isAuth)

  const resultsStrip = (
    <div className={`casino-video-last-results matka-result${showLr ? '' : ' hide-lr'}`}>
      {lastResults.map((r, i) => (
        <span key={i} className="resultb" onClick={() => setCalendarMarket(r.win || null)}>{r.win}</span>
      ))}
      {' '}
      <Link to="/admin/reports/casinoresult/worli3" className="result-more">
        {'\n    ...\n  '}
      </Link>
      {' '}
    </div>
  )

  return (
    <>
      <div className="center-main-container">
        <div className="center-content">
          <div className="casino-container">
            <div className="casino-table worli matka">

              <div className="matka-tabs">
                <ul className="nav nav-pills">
                  {bazars.map((b, i) => (
                    <li key={b.mid || i} className="nav-item pointer" onClick={() => setActiveIdx(i)}>
                      <a className={`nav-link${i === activeIdx ? ' active' : ''}`}>
                        {'\n                  ' + (b.mname || '') + '\n                  '}
                        <div className="remaining-time">
                          <img src="https://wver.sprintstaticdata.com/v230/static/front/img/clock.png" alt="" />
                          {' '}
                          <span>{b.ptime || ''}</span>
                        </div>
                        {' '}
                        <div className="game-time"><span>{b.mtime || ''}</span></div>
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
              {' '}
              <div className="casino-video">
                <div className="video-box-container">
                  <div className="video-box">
                    {streamUrl && <iframe src={streamUrl}></iframe>}
                  </div>
                </div>
                {' '}
                <div className="casino-timer"></div>
                {' '}
                <div className="casino-video-right-icons">
                  <div title="Home" className="casino-video-home-icon">
                    <Link to="/admin/casino/list" className="" style={{ color: 'var(--text-highlight)' }}>
                      <i className="fas fa-home"></i>
                    </Link>
                  </div>
                </div>
                {' '}
                {!isMobile && resultsStrip}
                {' '}
                <div
                  title="Last Results"
                  className="casino-video-lr-icon worli3-last-result"
                  onClick={() => setShowLr((v) => !v)}
                >
                  <i className={`fas ${showLr ? 'fa-chevron-circle-down' : 'fa-chevron-circle-up'}`}></i>
                </div>
              </div>
              {' '}
              {isMobile && resultsStrip}

            </div>
          </div>
        </div>
        {' '}
        <CasinoMyBetsSidebar myBets={myBets} gameName={GAME_TYPE} />
      </div>

      <MatkaCalendarModal
        show={!!calendarMarket}
        onClose={() => setCalendarMarket(null)}
        marketName={calendarMarket}
      />
    </>
  )
}
