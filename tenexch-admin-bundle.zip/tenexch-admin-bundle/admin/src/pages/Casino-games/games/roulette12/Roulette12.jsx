import RoulettePage from '../../../../components/casino/RoulettePage'

export default function Roulette12() {
  return <RoulettePage gameType="roulette12" gameName="Beach Roulette" />
}
