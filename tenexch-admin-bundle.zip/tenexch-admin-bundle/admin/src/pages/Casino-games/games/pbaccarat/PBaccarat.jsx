import { BaccaratBase } from '../baccarat/Baccarat'

// Premium Baccarat — /admin/pcasino/pbaccarat (Premium Casino list).
// Reference DOM (capture tenexch.com-admin-pcasino-pbaccarat, 2026-09-19) =
// the baccarat page: .casino-table.baccarat, iframe stream, no card overlay
// (cards inside the Player / Banker bets), circular timer, Home / Rules /
// Last Results, BetTableBaccarat (4 odds blocks + Player Pair / Player / Tie /
// Banker / Banker Pair, R:1K-2L from the feed), strip P / B, sidebar My Bets
// only. Feed pbaccarat = baccarat's 9 rows (verified live). Type, title and
// Home link differ.
export default function PBaccarat() {
  return <BaccaratBase gameType="pbaccarat" gameName="Premium Baccarat" homePath="/admin/pcasino/list" />
}
