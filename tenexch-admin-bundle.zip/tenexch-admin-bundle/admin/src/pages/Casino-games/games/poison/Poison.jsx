import PoisonPage from '../../../../components/casino/PoisonPage'

export default function Poison() {
  return <PoisonPage gameType="poison" gameName="Teenpatti Poison One Day" stripInVideo />
}
