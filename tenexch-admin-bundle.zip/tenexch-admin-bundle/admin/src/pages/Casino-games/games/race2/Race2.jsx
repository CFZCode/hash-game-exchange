import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { CircularTimer } from '../../../../components/casino/CasinoTimer'
import BetTableRace2 from '../../../../components/casino/BetTableRace2'
import Race2Cards from '../../../../components/casino/cards/Race2Cards'
import CasinoMyBetsSidebar from '../../../../components/casino/CasinoMyBetsSidebar'
import CasinoResultModal from '../../../../components/casino/CasinoResultModal'
import useCasinoGame from '../../../../hooks/casino/useCasinoGame'
import useCasinoLastResults from '../../../../hooks/casino/useCasinoLastResults'
import useCasinoMyBets from '../../../../hooks/casino/useCasinoMyBets'
import useCasinoStream from '../../../../hooks/casino/useCasinoStream'
import { computeAdminBook, getMarketsForGame } from '../../../../utils/casinoBook'
import { parseCards } from '../../../../components/casino/cards/cardUtils'

const GAME_TYPE = 'race2'
const GAME_NAME = 'Race to 2nd'

// Race to 2nd — route slug race2, API race2. Table class casino-queen. Video: 4
// labelled cards (Player A-D). Detail: BetTableRace2 (4 players back+lay,
// book-black always, min-max R:100-50K). video-right-icons me sirf Home + Last
// Results (koi Rules icon nahi). Strip resultb A/B/C. Dual-strip.
export default function Race2() {
  const isAuth = useSelector((s) => Boolean(s.auth.token))
  const [resultMid, setResultMid] = useState(null)
  const [showLr, setShowLr] = useState(true)
  const [showCards, setShowCards] = useState(true)

  const { data: gameData } = useCasinoGame(GAME_TYPE)
  const { data: lastResults = [], refetch: refetchLastResults } = useCasinoLastResults(GAME_TYPE)
  const { streamUrl } = useCasinoStream(GAME_TYPE)
  const { myBets } = useCasinoMyBets(GAME_TYPE, isAuth)

  const mid = gameData?.mid ?? ''
  const lt = gameData?.lt ?? 0
  const ft = gameData?.ft ?? 30

  const exposures = computeAdminBook(myBets, getMarketsForGame(GAME_TYPE, gameData))

  // koi bhi real card dealt hai? card "1,1,1,1" (sab placeholder) => nahi =>
  // video-cards closed (hide-cards)
  const hasCards = parseCards(gameData?.card || '').some((c) => c && c !== '1' && c !== '0')

  useEffect(() => {
    if (mid) refetchLastResults()
  }, [mid, refetchLastResults])

  // win: 1=A, 2=B, 3=C, 4=D — sab resultb, letter A/B/C/D
  const renderResult = (r, i) => {
    const letter = ['', 'A', 'B', 'C', 'D'][Number(r.win)] || 'A'
    return (
      <span key={i} className="resultb" onClick={() => setResultMid(r.mid || null)}>{letter}</span>
    )
  }

  const resultsStrip = (extraCls) => (
    <div className={`casino-video-last-results${extraCls}${showLr ? '' : ' hide-lr'}`}>
      {lastResults.map(renderResult)}
      {' '}
      <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
        {'\n    ...\n  '}
      </Link>
      {' '}
    </div>
  )

  return (
    <>
      <div className="center-main-container">
        <div className="center-content">
          <div className="casino-container">
            <div className="casino-table casino-queen">

              <div className="casino-video">
                <div className="casino-video-title">
                  <span className="casino-name">{GAME_NAME}</span>
                  {' '}
                  <div className="casino-video-rid">Round ID: {mid}</div>
                </div>
                {' '}
                <div className="video-box-container">
                  <div className="video-box">
                    {streamUrl && <iframe src={streamUrl}></iframe>}
                  </div>
                </div>
                {' '}
                <div className={`casino-video-cards${showCards && hasCards ? '' : ' hide-cards'}`}>
                  <div className="casino-cards-shuffle" onClick={() => setShowCards((v) => !v)}>
                    <i className="fas fa-grip-lines-vertical"></i>
                  </div>
                  {' '}
                  <Race2Cards cardString={gameData?.card || ''} />
                </div>
                {' '}
                <CircularTimer timeLeft={lt} fullTime={ft} />
                {' '}
                <div className="casino-video-right-icons">
                  <div title="Home" className="casino-video-home-icon">
                    <Link to="/admin/casino/list" className="" style={{ color: 'var(--text-highlight)' }}>
                      <i className="fas fa-home"></i>
                    </Link>
                  </div>
                  {' '}
                  <div title="Last Results" className="casino-video-lr-icon" onClick={() => setShowLr((v) => !v)}>
                    <i className={`fas ${showLr ? 'fa-chevron-circle-up' : 'fa-chevron-circle-down'}`}></i>
                  </div>
                </div>
                {' '}
                {/* web: strip video me (mobile pe hidden) */}
                {resultsStrip(' d-none-small')}
              </div>
              {' '}
              <div className="casino-detail">
                <BetTableRace2
                  gameData={gameData}
                  onBet={() => {}}
                  exposures={exposures}
                />
                {' '}
                {/* mobile: strip casino-detail ke bottom me */}
                {resultsStrip(' d-none-desktop')}
              </div>

            </div>
          </div>
        </div>
        {' '}
        <CasinoMyBetsSidebar myBets={myBets} gameName={GAME_TYPE} />
      </div>

      <CasinoResultModal
        show={!!resultMid}
        onClose={() => setResultMid(null)}
        gameType={GAME_TYPE}
        gameName={GAME_NAME}
        mid={resultMid}
      />
    </>
  )
}
