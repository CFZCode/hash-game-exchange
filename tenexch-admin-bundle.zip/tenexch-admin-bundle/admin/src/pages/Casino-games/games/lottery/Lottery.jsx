import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { CircularTimer } from '../../../../components/casino/CasinoTimer'
import CasinoMyBetsSidebar from '../../../../components/casino/CasinoMyBetsSidebar'
import CasinoResultModal from '../../../../components/casino/CasinoResultModal'
import useCasinoGame from '../../../../hooks/casino/useCasinoGame'
import useCasinoLastResults from '../../../../hooks/casino/useCasinoLastResults'
import useCasinoMyBets from '../../../../hooks/casino/useCasinoMyBets'
import useCasinoStream from '../../../../hooks/casino/useCasinoStream'
import { cardSrc, parseCards } from '../../../../components/casino/cards/cardUtils'

const GAME_TYPE = 'lottcard'
const GAME_NAME = 'Lottery'
const REMARK_ICON = 'https://wver.sprintstaticdata.com/v230/static/front/img/icons/remark.png'

function parseWin(winStr) {
  if (!winStr) return []
  return String(winStr).split(/\s+/).filter(Boolean)
}

// Lottery — route slug lottery, API lottcard. Table class lottery. Minimal:
// video + 3-card overlay + casino-remark marquee + last-results strip (koi bet
// table/tabs/rules nahi). Right-icons sirf Home (no LR icon → strip always shown,
// mb-3 wrapper me). Strip resultb = win digits "0  5  3". Web/mobile same.
export default function Lottery() {
  const isAuth = useSelector((s) => Boolean(s.auth.token))
  const [resultMid, setResultMid] = useState(null)
  const [showCards, setShowCards] = useState(false)

  const { data: gameData } = useCasinoGame(GAME_TYPE)
  const { data: lastResults = [], refetch: refetchLastResults } = useCasinoLastResults(GAME_TYPE)
  const { streamUrl } = useCasinoStream(GAME_TYPE)
  const { myBets } = useCasinoMyBets(GAME_TYPE, isAuth)

  const mid = gameData?.mid ?? ''
  const lt = gameData?.lt ?? 0
  const ft = gameData?.ft ?? 60
  const remark = gameData?.remark ?? ''

  const codes = parseCards(gameData?.card || '')

  useEffect(() => {
    if (mid) refetchLastResults()
  }, [mid, refetchLastResults])

  return (
    <>
      <div className="center-main-container">
        <div className="center-content">
          <div className="casino-container">
            <div className="casino-table lottery">

              <div className="casino-video">
                <div className="casino-video-title">
                  <span className="casino-name">{GAME_NAME}</span>
                  {' '}
                  <div className="casino-video-rid">Round ID: {mid}</div>
                </div>
                {' '}
                <div className="video-box-container">
                  <div className="video-box">
                    {streamUrl && <iframe src={streamUrl}></iframe>}
                  </div>
                </div>
                {' '}
                <div className={`casino-video-cards${showCards ? '' : ' hide-cards'}`}>
                  <div className="casino-cards-shuffle" onClick={() => setShowCards((v) => !v)}>
                    <i className="fas fa-grip-lines-vertical"></i>
                  </div>
                  {' '}
                  <div className="casino-video-cards-container">
                    <div>
                      <span data-v-b64efdfa=""><img data-v-b64efdfa="" src={cardSrc(codes[0] || '1')} /></span>
                      {' '}
                      <span data-v-b64efdfa=""><img data-v-b64efdfa="" src={cardSrc(codes[1] || '1')} /></span>
                      {' '}
                      <span data-v-b64efdfa=""><img data-v-b64efdfa="" src={cardSrc(codes[2] || '1')} /></span>
                    </div>
                  </div>
                </div>
                {' '}
                <CircularTimer timeLeft={lt} fullTime={ft} />
                {' '}
                <div className="casino-video-right-icons">
                  <div title="Home" className="casino-video-home-icon">
                    <Link to="/admin/casino/list" className="" style={{ color: 'var(--text-highlight)' }}>
                      <i className="fas fa-home"></i>
                    </Link>
                  </div>
                </div>
              </div>
              {' '}
              <div className="casino-remark mt-1">
                <div className="remark-icon"><img src={REMARK_ICON} /></div>
                {' '}
                <marquee>{remark}</marquee>
              </div>
              {' '}
              <div className="mb-3">
                <div className="casino-video-last-results">
                  {lastResults.map((r, i) => (
                    <span key={i} className="resultb" onClick={() => setResultMid(r.mid || null)}>
                      {parseWin(r.win).join('  ')}
                    </span>
                  ))}
                  {' '}
                  <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
                    {'\n    ...\n  '}
                  </Link>
                </div>
              </div>

            </div>
          </div>
        </div>
        {' '}
        <CasinoMyBetsSidebar myBets={myBets} gameName={GAME_TYPE} />
      </div>

      <CasinoResultModal
        show={!!resultMid}
        onClose={() => setResultMid(null)}
        gameType={GAME_TYPE}
        gameName={GAME_NAME}
        mid={resultMid}
      />
    </>
  )
}
