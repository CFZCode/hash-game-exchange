import { Fragment } from 'react'
import BetTableVTeen1Day from '../../../../components/casino/BetTableVTeen1Day'
import VCasinoTable from '../../../../components/casino/VCasinoTable'
import { computeAdminBook, getMarketsForGame } from '../../../../utils/casinoBook'
import { cardSrc } from '../../../../components/casino/cards/cardUtils'

const GAME_TYPE = 'vteen'
const GAME_NAME = 'V-Teenpatti 1-day'

// Overlay: `.player-card.playera-card` / `.playerb-card`, label + three cards
// each. Feed `card` = six codes dealt alternately, A = 1st/3rd/5th, B =
// 2nd/4th/6th (same split as the non-virtual TeenOneDay page); face-down 1.png.
const PLAYERS = [
  { key: 'a', label: 'Player A', cls: 'playera', idx: [0, 2, 4] },
  { key: 'b', label: 'Player B', cls: 'playerb', idx: [1, 3, 5] },
]

const renderCards = (gameData) => {
  const cards = String(gameData?.card || '').split(',').map((c) => c.trim())
  return PLAYERS.map((p, pi) => (
    <Fragment key={p.key}>
      {pi > 0 && ' '}
      <div className={`player-card ${p.cls}-card`}>
      {' '}
      <div className={`w-100 ${p.cls} mb-2`}>{p.label}</div>
      {p.idx.map((i) => (
        <Fragment key={i}>
          {' '}
          <span data-v-b64efdfa="">
            <img data-v-b64efdfa="" src={cardSrc(cards[i])} />
          </span>
        </Fragment>
      ))}
    </div>
    </Fragment>
  ))
}

// last-results `win` 1 → "A " resulta, 2 → " B " resultb (capture B B B B A A …)
const renderResult = (r, i, onClick) => (
  String(r.win) === '1'
    ? <span key={i} className="resulta" onClick={onClick}>{'A '}</span>
    : <span key={i} className="resultb" onClick={onClick}>{' B '}</span>
)

// V-Teenpatti 1-Day — /admin/vcasino/teen. Reference DOM (capture 2026-09-19):
// shell VCasinoTable (.casino-table.vcasino.vteen1day), board
// BetTableVTeen1Day, sidebar My Bets only. Book: getMarketsForGame (Player
// A/B match → one market; Consecutive fancy1 + Card N fancy → single markets).
export default function VTeen1Day() {
  return (
    <VCasinoTable
      gameType={GAME_TYPE}
      gameName={GAME_NAME}
      tableClass="vteen1day"
      cards={renderCards}
      renderResult={renderResult}
    >
      {(gameData, myBets) => (
        <BetTableVTeen1Day
          gameData={gameData}
          exposures={computeAdminBook(myBets, getMarketsForGame(GAME_TYPE, gameData))}
        />
      )}
    </VCasinoTable>
  )
}
