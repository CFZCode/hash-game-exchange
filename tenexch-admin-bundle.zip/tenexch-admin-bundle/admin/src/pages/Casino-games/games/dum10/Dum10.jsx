import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { CircularTimer } from '../../../../components/casino/CasinoTimer'
import BetTableDum10 from '../../../../components/casino/BetTableDum10'
import { VideoOwl } from '../../../../components/casino/BetTableAB4'
import CasinoMyBetsSidebar from '../../../../components/casino/CasinoMyBetsSidebar'
import CasinoResultModal from '../../../../components/casino/CasinoResultModal'
import useCasinoGame from '../../../../hooks/casino/useCasinoGame'
import useCasinoLastResults from '../../../../hooks/casino/useCasinoLastResults'
import useCasinoMyBets from '../../../../hooks/casino/useCasinoMyBets'
import useCasinoStream from '../../../../hooks/casino/useCasinoStream'
import { computeAdminBook, computeDum10MainBook, getMarketsForGame } from '../../../../utils/casinoBook'
import { cardSrc, parseCards } from '../../../../components/casino/cards/cardUtils'

const GAME_TYPE = 'dum10'
const GAME_NAME = 'Dus ka Dum'

// Dus ka Dum — route slug dum10, API dum10. Table duskadum. Title me dkd-total
// (Current Total: csum). Video: dum-slider owl (dealt cards lcard, owl-rtl) +
// casino-video-current-card (current card). Detail: BetTableDum10 (main total
// back/lay + Even/Odd/Red/Black, book-black always). video-right-icons me sirf
// Home + Last Results (Rules nahi). Strip resultb Y/N. Dual-strip.
export default function Dum10() {
  const isAuth = useSelector((s) => Boolean(s.auth.token))
  const [resultMid, setResultMid] = useState(null)
  const [showLr, setShowLr] = useState(true)
  const [showCards, setShowCards] = useState(true)

  const { data: gameData } = useCasinoGame(GAME_TYPE)
  const { data: lastResults = [], refetch: refetchLastResults } = useCasinoLastResults(GAME_TYPE)
  const { streamUrl } = useCasinoStream(GAME_TYPE)
  const { myBets } = useCasinoMyBets(GAME_TYPE, isAuth)

  const mid = gameData?.mid ?? ''
  const lt = gameData?.lt ?? 0
  const ft = gameData?.ft ?? 20
  const csum = gameData?.csum ?? 0
  const currentCard = gameData?.card || '1'

  const exposures = computeAdminBook(myBets, getMarketsForGame(GAME_TYPE, gameData))
  const mainBook = computeDum10MainBook(myBets)

  // dealt cards slider (lcard). Real card na ho to overlay closed.
  const dealtCards = parseCards(gameData?.lcard || '').filter((c) => c && c !== '1' && c !== '0')
  const hasCards = dealtCards.length > 0

  useEffect(() => {
    if (mid) refetchLastResults()
  }, [mid, refetchLastResults])

  // win 1 => Y, else N (dono resultb)
  const renderResult = (r, i) => (
    <span key={i} className="resultb" onClick={() => setResultMid(r.mid || null)}>
      {String(r.win) === '1' ? 'Y' : 'N'}
    </span>
  )

  const strip = (extraCls) => (
    <div className={`casino-video-last-results${extraCls}${showLr ? '' : ' hide-lr'}`}>
      {lastResults.map(renderResult)}
      {' '}
      <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
        {'\n    ...\n  '}
      </Link>
      {' '}
    </div>
  )

  return (
    <>
      <div className="center-main-container">
        <div className="center-content">
          <div className="casino-container">
            <div className="casino-table duskadum">

              <div className="casino-video">
                <div className="casino-video-title">
                  <span className="casino-name">{GAME_NAME}</span>
                  {' '}
                  <div className="casino-video-rid">Round ID: {mid}</div>
                  {' '}
                  <div className="dkd-total">
                    <div>Current Total:</div>
                    {' '}
                    <div className="numeric text-playerb">{csum}</div>
                  </div>
                </div>
                {' '}
                <div className="video-box-container">
                  <div className="video-box">
                    {streamUrl && <iframe src={streamUrl}></iframe>}
                  </div>
                </div>
                {' '}
                <div className={`casino-video-cards andar-bahar2${showCards && hasCards ? '' : ' hide-cards'}`}>
                  <div className="casino-cards-shuffle" onClick={() => setShowCards((v) => !v)}>
                    <i className="fas fa-grip-lines-vertical"></i>
                  </div>
                  {' '}
                  <div className="casino-video-cards-container">
                    <VideoOwl cards={dealtCards} sliderId="andarSlider" extraClass="dum-slider" variant="dum" />
                  </div>
                </div>
                {' '}
                <div className="casino-video-current-card">
                  <div>
                    <span data-v-b64efdfa=""><img data-v-b64efdfa="" src={cardSrc(currentCard)} /></span>
                  </div>
                </div>
                {' '}
                <CircularTimer timeLeft={lt} fullTime={ft} />
                {' '}
                <div className="casino-video-right-icons">
                  <div title="Home" className="casino-video-home-icon">
                    <Link to="/admin/casino/list" className="" style={{ color: 'var(--text-highlight)' }}>
                      <i className="fas fa-home"></i>
                    </Link>
                  </div>
                  {' '}
                  <div title="Last Results" className="casino-video-lr-icon" onClick={() => setShowLr((v) => !v)}>
                    <i className={`fas ${showLr ? 'fa-chevron-circle-up' : 'fa-chevron-circle-down'}`}></i>
                  </div>
                </div>
                {' '}
                {/* web: strip video me (mobile pe hidden) */}
                {strip(' d-none-small')}
              </div>
              {' '}
              <div className="casino-detail">
                <BetTableDum10
                  gameData={gameData}
                  onBet={() => {}}
                  exposures={exposures}
                  mainBook={mainBook}
                />
                {' '}
                {/* mobile: strip casino-detail ke bottom me */}
                {strip(' d-none-desktop')}
              </div>

            </div>
          </div>
        </div>
        {' '}
        <CasinoMyBetsSidebar myBets={myBets} gameName={GAME_TYPE} />
      </div>

      <CasinoResultModal
        show={!!resultMid}
        onClose={() => setResultMid(null)}
        gameType={GAME_TYPE}
        gameName={GAME_NAME}
        mid={resultMid}
      />
    </>
  )
}
