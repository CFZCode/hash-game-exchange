import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { CircularTimer } from '../../../../components/casino/CasinoTimer'
import { parseBalls, rankFromCode } from '../../../../components/casino/SuperOverBalls'
import SuperOverMarkets from '../../../../components/casino/SuperOverMarkets'
import CasinoResultModal from '../../../../components/casino/CasinoResultModal'
import CasinoRulesModal from '../../../../components/casino/CasinoRulesModal'
import CasinoRulesSwitch from '../../../../components/casino/rules/CasinoRulesSwitch'
import useCasinoGame from '../../../../hooks/casino/useCasinoGame'
import useCasinoLastResults from '../../../../hooks/casino/useCasinoLastResults'
import useCasinoMyBets from '../../../../hooks/casino/useCasinoMyBets'
import useCasinoStream from '../../../../hooks/casino/useCasinoStream'
import { computeAdminBook, getMarketsForGame } from '../../../../utils/casinoBook'
import { formatStake } from '../../../../utils/casinoUtils'
import useCardStripToggle from '../../../../hooks/casino/useCardStripToggle'

const GAME_TYPE = 'cricketv3'
const GAME_NAME = '5Five Cricket'
const CDN = 'https://wver.sprintstaticdata.com/v230/static/front/img/cards'

function rankToRuns(rank) {
  if (!rank) return null
  if (rank === 'K') return 'W'
  if (rank === '10') return 0
  if (rank === 'A') return 1
  const n = parseInt(rank, 10)
  return isNaN(n) ? null : n
}

// current innings card string se best-effort score
function computeScore(cardString) {
  let runs = 0
  let wickets = 0
  let deliveries = 0
  const ballValues = []
  for (const code of parseBalls(cardString)) {
    if (code === null) continue
    deliveries++
    const val = rankToRuns(rankFromCode(code))
    if (val === 'W') {
      wickets++
      ballValues.push('ww')
    } else if (val !== null) {
      runs += val
      ballValues.push(String(val))
    }
  }
  const overs = `${Math.floor(deliveries / 4)}.${deliveries % 4}`
  const crr = deliveries > 0 ? ((runs / deliveries) * 4).toFixed(2) : '0.00'
  return { score: `${runs}-${wickets}`, overs, crr, ballValues }
}

// 5Five Cricket (cricketv3) — API shape { t1: {card:"a|b|..6", gmid, lt, ft,
// scard, ename, gtype}, t2: [markets: Bookmaker dtype2 + Fancy dtype6] }.
// Table class five-cricket detail-page-container; game-header (ename) +
// col-xl-2 scorecard (score-top-row) + col-xl-10 video (6-card overlay,
// /cards/<code>.png); market-container = SuperOverMarkets(t2); strip
// resulta team1[0] / resultb team2[0] / resulttie T; sidebar my-game-bets card.
// NOTE: scorecard ka accumulated total/CRR/RR/"Needed" message all-data me
// nahi aata (bakend-docs/missing-apis.md #23) — best-effort current-innings.
export default function CricketV3() {
  const isAuth = useSelector((s) => Boolean(s.auth.token))
  const [resultMid, setResultMid] = useState(null)
  const [showRules, setShowRules] = useState(false)
  const [showLr, setShowLr] = useState(true)
  const [isMobile, setIsMobile] = useState(() => typeof window !== 'undefined' && window.innerWidth < 768)

  useEffect(() => {
    const onResize = () => setIsMobile(window.innerWidth < 768)
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  const { data: raw } = useCasinoGame(GAME_TYPE)
  const { data: lastResults = [] } = useCasinoLastResults(GAME_TYPE)
  const { streamUrl } = useCasinoStream(GAME_TYPE)
  const { myBets } = useCasinoMyBets(GAME_TYPE, isAuth)

  const t1 = (Array.isArray(raw?.t1) ? raw.t1[0] : raw?.t1) || {}
  const t2 = Array.isArray(raw?.t2) ? raw.t2 : []

  const gmid = t1.gmid ?? ''
  const [stripCollapsed, toggleStrip] = useCardStripToggle(gmid)
  const lt = t1.lt ?? 0
  const ft = t1.ft ?? 40
  const card = t1.card ?? ''
  const ename = t1.ename ?? ''

  const bookmakerMarket = t2.find((m) => m.dtype === 2 || m.gtype === 'match1')
  const sections = bookmakerMarket?.section || []
  const team1 = sections[0]?.nat || 'AUS'
  const team2 = sections[1]?.nat || 'IND'

  // t1.scard current innings batata hai (1 = team1 batting, 2 = team2)
  const innings = Number(t1.scard) === 2 ? 2 : 1

  const { score, overs, crr, ballValues } = computeScore(card)

  // t2 markets ko book-resolver ke sub[] format me le jao
  const exposures = useMemo(() => {
    const sub = []
    for (const m of t2) {
      const etype = m.dtype === 2 || m.gtype === 'match1' ? 'match' : (m.gtype || 'fancy')
      for (const s of m.section || []) {
        sub.push({ sid: s.sid, nat: s.nat, subtype: m.gtype || 'bookmaker', etype })
      }
    }
    return computeAdminBook(myBets, getMarketsForGame(GAME_TYPE, { sub }))
  }, [t2, myBets])

  const cardCodes = String(card).split('|')
  const hideCards = !card || cardCodes.every((c) => c === '1')

  const resultsStrip = (
    <div className={`casino-video-last-results${showLr ? '' : ' hide-lr'}`}>
      {lastResults.map((r, i) => {
        const w = String(r.win)
        const cls = w === '1' ? 'resulta' : w === '2' ? 'resultb' : 'resulttie'
        const letter = w === '1' ? `${team1.charAt(0)} ` : w === '2' ? ` ${team2.charAt(0)} ` : ' T'
        return (
          <span key={i} className={cls} onClick={() => setResultMid(r.mid || null)}>
            {letter}
          </span>
        )
      })}
      {' '}
      <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
        {'\n    ...\n  '}
      </Link>
      {' '}
    </div>
  )

  const crrDiv = (
    <div>
      <span>
        {'\n                            CRR\n                            ' + crr + '\n                          '}
      </span>
      {' '}
    </div>
  )

  const scoreText = (batting) =>
    batting
      ? `\n                          ${score} (${overs})\n                        `
      : '\n                          0-0 (0.0)\n                        '

  return (
    <>
      <div className="center-main-container">
        <div className="center-content">
          <div className="casino-container">
            <div className="casino-table five-cricket detail-page-container">

              <div className="game-header">
                <span className="game-header-name">{ename || `${team1} Vs ${team2} ${GAME_NAME}`}</span>
                {' '}
                <span className="float-right game-header-date">Round ID: {gmid}</span>
              </div>
              {' '}
              <div className="container-fluid container-fluid-5">
                <div className="row row5">
                  <div className="col-xl-2 banner d-flex align-items-center mb-1">
                    <div className="scorecard">
                      <div className="scorecard-row">
                        <div className="score-top-row">
                          <div className="score-team">
                            <b>{team1}</b>
                            {scoreText(innings === 1)}
                          </div>
                          {' '}
                          {innings === 1 ? crrDiv : <div>{' '}</div>}
                          {' '}
                        </div>
                      </div>
                      {' '}
                      <div className="scorecard-row">
                        <div className="score-top-row">
                          <div className="score-team">
                            <b>{team2}</b>
                            {scoreText(innings === 2)}
                          </div>
                          {' '}
                          {innings === 2 ? crrDiv : <div>{' '}</div>}
                          {' '}
                          <div className="score-message">
                            {ballValues.map((v, i) => (
                              <span key={i} className={`ball-runs mr-1${v === '6' ? ' six' : v === '4' ? ' four' : v === 'ww' ? ' wicket' : ''}`}>{v}</span>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  {' '}
                  <div className="col-xl-10">
                    <div className="casino-video mt-0">
                      <div className="video-box-container">
                        <div className="video-box">
                          {streamUrl && <iframe src={streamUrl}></iframe>}
                        </div>
                      </div>
                      {' '}
                      <div className={`casino-video-cards${hideCards || stripCollapsed ? ' hide-cards' : ''}`}>
                        <div className="casino-cards-shuffle" role="button" style={{ cursor: 'pointer' }} onClick={toggleStrip}>
                          <i className="fas fa-grip-lines-vertical"></i>
                        </div>
                        {' '}
                        <div className="casino-video-cards-container">
                          {cardCodes.map((c, i) => (
                            <div key={i}>
                              <span data-v-b64efdfa=""><img data-v-b64efdfa="" src={`${CDN}/${c || '1'}.png`} /></span>
                            </div>
                          ))}
                        </div>
                      </div>
                      {' '}
                      <CircularTimer timeLeft={lt} fullTime={ft} />
                      {' '}
                      <div className="casino-video-right-icons">
                        <div title="Home" className="casino-video-home-icon">
                          <Link to="/admin/casino/list" className="" style={{ color: 'var(--text-highlight)' }}>
                            <i className="fas fa-home"></i>
                          </Link>
                        </div>
                        {' '}
                        <div title="Rules" className="casino-video-rules-icon" onClick={() => setShowRules((v) => !v)}>
                          <i className="fas fa-info-circle"></i>
                        </div>
                        {' '}
                        <div title="Last Results" className="casino-video-lr-icon" onClick={() => setShowLr((v) => !v)}>
                          <i className={`fas ${showLr ? 'fa-chevron-circle-up' : 'fa-chevron-circle-down'}`}></i>
                        </div>
                      </div>
                      {' '}
                      <div>{showRules && (
                        <div
                          id="casino-vieo-rules"
                          aria-modal="true"
                          className="casino-vieo-rules show d-none-small show-rules"
                          style={{ display: 'block' }}
                        >
                          <div className="rules-header">
                            <div>Rules</div>
                            {' '}
                            <i className="fas fa-times" onClick={() => setShowRules(false)}></i>
                          </div>
                          {' '}
                          <div className="rules-body">
                            <CasinoRulesSwitch gameType={GAME_TYPE} />
                          </div>
                        </div>
                      )}</div>
                      {' '}
                      {!isMobile && resultsStrip}
                    </div>
                  </div>
                </div>
              </div>
              {' '}
              <div className="market-container">
                {t2.length > 0 && (
                  <SuperOverMarkets markets={t2} onBet={() => {}} exposures={exposures} />
                )}
              </div>
              {' '}
              {isMobile && resultsStrip}

            </div>
          </div>
        </div>
        {' '}
        <div data-simplebar="init" className="right-sidebar">
          <div className="simplebar-wrapper" style={{ margin: '0px' }}>
          <div className="simplebar-height-auto-observer-wrapper"><div className="simplebar-height-auto-observer"></div></div>
          <div className="simplebar-mask">
          <div className="simplebar-offset" style={{ right: '0px', bottom: '0px' }}>
          <div className="simplebar-content-wrapper" tabIndex="0" role="region" aria-label="scrollable content" style={{ height: 'auto', overflow: 'hidden' }}>
          <div className="simplebar-content" style={{ padding: '0px' }}>
          <div id="my-game-bets" className="card m-b-10 my-bet">
            <div className="card-header">
              <h6 className="card-title float-left">My Bets</h6>
              {' '}
              <a href="javascript:void(0)" className="btn btn-back float-right">View More</a>
            </div>
            {' '}
            <div className="card-body1">
              <div className="tab-content">
                <div id="matched-bet" className="tab-pane active">
                  <div className="table-responsive1">
                    <table className="table coupon-table mb-0">
                      <thead>
                        <tr>
                          <th style={{ minWidth: '90px' }}>UserName</th>
                          <th style={{ minWidth: '90px' }}>Nation</th>
                          <th className="text-right" style={{ minWidth: '50px' }}>Rate</th>
                          <th className="text-right" style={{ minWidth: '70px' }}>
                            {'\n                        Amount\n                      '}
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {myBets.map((bet, i) => (
                          <tr key={bet.id || bet._id || i} className={String(bet.game_type || bet.type || '').toLowerCase() === 'lay' ? 'lay-border' : 'back-border'}>
                            <td>{bet.username || bet.user_name || bet.user_id || ''}</td>
                            <td>{bet.selection || bet.player_name || ''}</td>
                            <td className="text-right">{formatStake(bet.odds ?? bet.rate)}</td>
                            <td className="text-right">{formatStake(bet.amount ?? bet.stake)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          </div>
          </div>
          </div>
          </div>
          <div className="simplebar-placeholder" style={{ width: 'auto', height: '84px' }}></div>
          </div>
          <div className="simplebar-track simplebar-horizontal" style={{ visibility: 'hidden' }}><div className="simplebar-scrollbar" style={{ width: '0px', display: 'none' }}></div></div>
          <div className="simplebar-track simplebar-vertical" style={{ visibility: 'hidden' }}><div className="simplebar-scrollbar" style={{ height: '0px', display: 'none' }}></div></div>
        </div>
        {' '}
        <div className="market-show-icon d-none-desktop">
          <div className="bet-cnt">
            {'\n        ' + Math.min(myBets.length, 10) + '\n      '}
          </div>
          {' '}
          <div className="bet-title">Bets</div>
        </div>
      </div>

      <CasinoRulesModal
        show={showRules}
        onClose={() => setShowRules(false)}
        tableClass=""
        gameType={GAME_TYPE}
      >
        <CasinoRulesSwitch gameType={GAME_TYPE} />
      </CasinoRulesModal>

      <CasinoResultModal
        show={!!resultMid}
        onClose={() => setResultMid(null)}
        gameType={GAME_TYPE}
        gameName={GAME_NAME}
        mid={resultMid}
      />
    </>
  )
}
