import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { CircularTimer } from '../../../../components/casino/CasinoTimer'
import SuperOverMarkets from '../../../../components/casino/SuperOverMarkets'
import CasinoResultModal from '../../../../components/casino/CasinoResultModal'
import CasinoRulesModal from '../../../../components/casino/CasinoRulesModal'
import CasinoRulesSwitch from '../../../../components/casino/rules/CasinoRulesSwitch'
import useCasinoGame from '../../../../hooks/casino/useCasinoGame'
import useCasinoLastResults from '../../../../hooks/casino/useCasinoLastResults'
import useCasinoMyBets from '../../../../hooks/casino/useCasinoMyBets'
import useCasinoStream from '../../../../hooks/casino/useCasinoStream'
import useSuperOverScorecard from '../../../../hooks/casino/useSuperOverScorecard'
import useStickySidebar from '../../../../hooks/useStickySidebar'
import { computeAdminBook, getMarketsForGame } from '../../../../utils/casinoBook'
import { formatStake } from '../../../../utils/casinoUtils'

const GAME_TYPE = 'superover2'
// Fancy session bet stored with its run line: "1 over run [bhav] IND 13".
const SESSION_RE = /^(\d+\s+over\s+run(?:\s+bhav)?\s+\S+)\s+(\d+(?:\.\d+)?)$/i
// My Bets: the market name printed on a bet's header row.
const marketOfBet = (sel) => (/^\d+\s+over\s+run/i.test(sel) ? 'Fancy'
  : /^(0\.\d\s+over|common)\s/i.test(sel) ? 'Fancy1' : 'Bookmaker')
// Bet time as the reference prints it: "10/10/2026 02:19:17" (IST).
const betTime = (v) => {
  const d = new Date(v)
  if (!v || isNaN(d.getTime())) return ''
  return new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Asia/Kolkata', day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false,
  }).format(d).replace(',', '')
}

// Super Over 2 (superover2) — casino-table five-cricket super-over super-over2.
// superover3 ke ulat SCORECARD nahi (full col-xl-12 video), balls overlay bhi
// nahi. Markets Bookmaker + Fancy + Fancy1 (Tie nahi) — wahi SuperOverMarkets
// component. Strip resulta/resultb/resulttie me team-initial (IND=I, ENG=E, tie=T).
// Book / Fancy1 / My Bets rules are the Super Over (superover) ones
// (docs/plans/2026-10-11-superover2-parity-with-superover.md). The server
// scorecard is read ONLY for the first-batting team (Fancy1 colours); nothing of
// it is rendered.
export default function SuperOver2() {
  const isAuth = useSelector((s) => Boolean(s.auth.token))
  const [resultMid, setResultMid] = useState(null)
  const [showRules, setShowRules] = useState(false)
  const [showLr, setShowLr] = useState(true)
  // sticky (position:fixed) sirf desktop pe — mobile pe My Bets ko overlap se bachao
  const [isMobile, setIsMobile] = useState(() => typeof window !== 'undefined' && window.innerWidth < 768)
  const stickyClass = useStickySidebar()
  useEffect(() => {
    const onResize = () => setIsMobile(window.innerWidth < 768)
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  const { data: raw } = useCasinoGame(GAME_TYPE)
  const { data: lastResults = [] } = useCasinoLastResults(GAME_TYPE)
  const { streamUrl } = useCasinoStream(GAME_TYPE)
  const { myBets } = useCasinoMyBets(GAME_TYPE, isAuth)
  const serverCard = useSuperOverScorecard(GAME_TYPE)

  const t1 = (Array.isArray(raw?.t1) ? raw.t1[0] : raw?.t1) || {}
  const t2 = Array.isArray(raw?.t2) ? raw.t2 : []

  const gmid = t1.gmid ?? ''
  const lt = t1.lt ?? 0
  const ft = t1.ft ?? 20
  const gameName = t1.ename || 'Super Over 2'

  const bookmakerMarket = t2.find((m) => m.dtype === 2 || m.gtype === 'match1')
  const sections = bookmakerMarket?.section || []
  const t1Init = (sections[0]?.nat || 'IND').charAt(0).toUpperCase()
  const t2Init = (sections[1]?.nat || 'ENG').charAt(0).toUpperCase()

  // Fancy1 colours are first-innings only. The server card can still describe
  // the previous round until the new one folds — use it only for this round.
  const fancy1ColourTeam = serverCard && String(serverCard.gmid ?? '') === String(gmid) ? (serverCard.firstTeam || '') : ''

  // t2 markets -> book-resolver sub[]: bookmaker match-spread, fancy/fancy1 singles
  const exposures = useMemo(() => {
    const sub = []
    for (const m of t2) {
      const etype = m.dtype === 2 || m.gtype === 'match1' ? 'match' : (m.gtype || 'fancy')
      for (const s of m.section || []) {
        sub.push({ sid: s.sid, nat: s.nat, subtype: m.gtype || 'bookmaker', etype })
      }
    }
    const book = computeAdminBook(myBets, getMarketsForGame(GAME_TYPE, { sub }))
    // Fancy session bets carry their run line ("1 over run IND 13") so they
    // match no feed row above. All bets on a row settle on the same innings
    // total, so the row shows the ADMIN's worst P/L over every total 0–36
    // (runs ladder; Yes wins at total >= line) — same as the player page.
    const ladders = {}
    for (const b of myBets) {
      const m = String(b.selection || '').trim().match(SESSION_RE)
      const odds = parseFloat(b.odds) || 0
      const stake = parseFloat(b.amount ?? b.stake) || 0
      if (!m || !odds || !stake) continue
      const isLay = String(b.game_type || b.type || '').toLowerCase() === 'lay'
      const win = (odds - 1) * stake
      const line = Number(m[2])
      const pl = ladders[m[1].toLowerCase()] || (ladders[m[1].toLowerCase()] = new Array(37).fill(0))
      for (let r = 0; r <= 36; r++) {
        const yes = r >= line
        // admin P/L = the user's, negated
        pl[r] -= isLay ? (yes ? -win : stake) : (yes ? win : -stake)
      }
    }
    for (const s of sub) {
      const pl = ladders[String(s.nat || '').trim().toLowerCase()]
      if (pl) book[`sid:${s.sid}`] = Math.round(Math.min(...pl) * 100) / 100
    }
    return book
  }, [t2, myBets])

  // reference: desktop strip casino-video me (rules slot ke baad), phone pe
  // market-container ke BAAD (casino-table level) — SuperOver.jsx jaisa
  const resultsStrip = (
    <div className={`casino-video-last-results${showLr ? '' : ' hide-lr'}`}>
      {lastResults.map((r, i) => {
        const w = String(r.win)
        const cls = w === '1' ? 'resulta' : w === '2' ? 'resultb' : 'resulttie'
        const letter = w === '1' ? `${t1Init} ` : w === '2' ? ` ${t2Init} ` : ' T'
        return (
          <span key={i} className={cls} onClick={() => setResultMid(r.mid || null)}>
            {letter}
          </span>
        )
      })}
      {' '}
      <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
        {'\n    ...\n  '}
      </Link>
      {' '}
    </div>
  )

  // Reference order: every bet newest first, whatever its market.
  const myBetsSorted = [...myBets].sort((a, b) =>
    (new Date(b.created_at) - new Date(a.created_at)) || (Number(b.id) - Number(a.id)))

  return (
    <>
      <div className="center-main-container">
        <div className="center-content">
          <div className="casino-container">
            <div className="casino-table five-cricket super-over super-over2 detail-page-container">

              <div className="game-header">
                <span className="game-header-name">{gameName}</span>
                {' '}
                <span className="float-right game-header-date">Round ID: {gmid}</span>
              </div>
              {' '}
              <div className="container-fluid container-fluid-5">
                <div className="row row5">
                  <div className="col-xl-12">
                    <div className="casino-video mt-0">
                      <div className="video-box-container">
                        <div className="video-box">
                          {streamUrl && <iframe src={streamUrl}></iframe>}
                        </div>
                      </div>
                      {' '}
                      <CircularTimer timeLeft={lt} fullTime={ft} />
                      {' '}
                      <div className="casino-video-right-icons">
                        <div title="Home" className="casino-video-home-icon">
                          <Link to="/admin/casino/list" className="" style={{ color: 'var(--text-highlight)' }}>
                            <i className="fas fa-home"></i>
                          </Link>
                        </div>
                        {' '}
                        <div title="Rules" className="casino-video-rules-icon" onClick={() => setShowRules((v) => !v)}>
                          <i className="fas fa-info-circle"></i>
                        </div>
                        {' '}
                        <div title="Last Results" className="casino-video-lr-icon" onClick={() => setShowLr((v) => !v)}>
                          <i className={`fas ${showLr ? 'fa-chevron-circle-up' : 'fa-chevron-circle-down'}`}></i>
                        </div>
                      </div>
                      {' '}
                      <div>{showRules && (
                        <div
                          id="casino-vieo-rules"
                          aria-modal="true"
                          className="casino-vieo-rules show d-none-small show-rules"
                          style={{ display: 'block' }}
                        >
                          <div className="rules-header">
                            <div>Rules</div>
                            {' '}
                            <i className="fas fa-times" onClick={() => setShowRules(false)}></i>
                          </div>
                          {' '}
                          <div className="rules-body">
                            <CasinoRulesSwitch gameType={GAME_TYPE} />
                          </div>
                        </div>
                      )}</div>
                      {' '}
                      {!isMobile && resultsStrip}
                    </div>
                  </div>
                </div>
              </div>
              {' '}
              <div className="market-container">
                {t2.length > 0 && (
                  <SuperOverMarkets markets={t2} onBet={() => {}} exposures={exposures} bookRatio ratioTrim referenceFancy1 firstTeam={fancy1ColourTeam} />
                )}
              </div>
              {' '}
              {isMobile && resultsStrip}

            </div>
          </div>
        </div>
        {' '}
        {/* My Bets sidebar like Super Over: the static simplebar markup (fixed
            84px placeholder + overflow hidden) clipped every bet below the header. */}
        <div className={`right-sidebar${isMobile ? '' : stickyClass}`}>
          <div id="my-game-bets" className="card m-b-10 my-bet">
            <div className="card-header">
              <h6 className="card-title float-left">My Bets</h6>
              {' '}
              <a href="javascript:void(0)" className="btn btn-back float-right">View More</a>
            </div>
            {' '}
            <div className="card-body1">
              <div className="tab-content">
                <div id="matched-bet" className="tab-pane active">
                  <div className="table-responsive1">
                    <table className="table coupon-table mb-0">
                      <thead>
                        <tr>
                          <th style={{ minWidth: '90px' }}>UserName</th>
                          <th style={{ minWidth: '90px' }}>Nation</th>
                          <th className="text-right" style={{ minWidth: '50px' }}>Rate</th>
                          <th className="text-right" style={{ minWidth: '70px' }}>
                            {'\n                        Amount\n                      '}
                          </th>
                        </tr>
                      </thead>
                      {/* Reference: every bet is its own block — a header row with the
                          market name + bet time, then the bet; newest bet first. A session
                          bet reads "1 over run IND / 84" with its line (13) as the rate. */}
                      {myBetsSorted.map((bet, i) => {
                        const sel = String(bet.selection || bet.player_name || '').trim()
                        const market = marketOfBet(sel)
                        const sm = sel.match(SESSION_RE)
                        const nation = sm ? `${sm[1]} / ${Math.round(((parseFloat(bet.odds) || 0) - 1) * 100)}` : sel
                        const rate = sm ? sm[2] : formatStake(bet.odds ?? bet.rate)
                        const cls = String(bet.game_type || bet.type || '').toLowerCase() === 'lay' ? 'lay-border' : 'back-border'
                        return (
                          <tbody key={bet.id || bet._id || i}>
                            <tr className={cls}>
                              <td colSpan={2}><b>{market}</b></td>
                              <td colSpan={2} className="text-right">{betTime(bet.created_at)}</td>
                            </tr>
                            <tr className={cls}>
                              <td>{bet.username || bet.user_name || bet.user_id || ''}</td>
                              <td>{nation}</td>
                              <td className="text-right">{rate}</td>
                              <td className="text-right">{formatStake(bet.amount ?? bet.stake)}</td>
                            </tr>
                          </tbody>
                        )
                      })}
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {' '}
          <div className="market-show-icon d-none-desktop">
            <div className="bet-cnt">{Math.min(myBets.length, 10)}</div>
            {' '}
            <div className="bet-title">Bets</div>
          </div>
        </div>
      </div>

      <CasinoRulesModal
        show={showRules}
        onClose={() => setShowRules(false)}
        tableClass=""
        gameType={GAME_TYPE}
      >
        <CasinoRulesSwitch gameType={GAME_TYPE} />
      </CasinoRulesModal>

      <CasinoResultModal
        show={!!resultMid}
        onClose={() => setResultMid(null)}
        gameType={GAME_TYPE}
        gameName={gameName}
        mid={resultMid}
      />
    </>
  )
}
