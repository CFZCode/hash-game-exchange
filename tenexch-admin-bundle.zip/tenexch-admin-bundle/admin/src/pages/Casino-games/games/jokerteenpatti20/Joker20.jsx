import PoisonPage from '../../../../components/casino/PoisonPage'

// Teenpatti Joker 20-20 (joker20) — poison20 jaisa exact layout, sirf label
// "Joker" (card overlay h4 + table teen1dayright). nats: "Joker Even/Odd/..".
export default function Joker20() {
  return (
    <PoisonPage
      gameType="joker20"
      gameName="Teenpatti Joker 20-20"
      stripInVideo
      cardHeader="Joker"
      tablePrefix="Joker"
    />
  )
}
