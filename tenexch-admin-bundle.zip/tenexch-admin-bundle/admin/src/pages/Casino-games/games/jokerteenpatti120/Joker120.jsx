import JokerPage from '../../../../components/casino/JokerPage'

export default function Joker120() {
  // NO leading joker — cards interleaved offset 0: Player A = card[0,2,4], B = card[1,3,5]
  return <JokerPage gameType="joker120" gameName="Unlimited Joker 20-20" cardOffset={0} />
}
