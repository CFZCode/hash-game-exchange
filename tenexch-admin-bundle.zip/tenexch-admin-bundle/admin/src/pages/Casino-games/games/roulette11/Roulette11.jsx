import RoulettePage from '../../../../components/casino/RoulettePage'

export default function Roulette11() {
  return <RoulettePage gameType="roulette11" gameName="VIP Roulette" />
}
