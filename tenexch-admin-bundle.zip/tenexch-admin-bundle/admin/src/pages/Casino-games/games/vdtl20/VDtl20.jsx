import { Fragment } from 'react'
import BetTableVDtl20, { VDTL_PLAYERS } from '../../../../components/casino/BetTableVDtl20'
import VCasinoTable from '../../../../components/casino/VCasinoTable'
import { computeAdminBook } from '../../../../utils/casinoBook'
import { cardSrc } from '../../../../components/casino/cards/cardUtils'

const GAME_TYPE = 'vdtl20'
const GAME_NAME = 'V-20-20 D T L'

// last-results `win` = winning sid: 1 Dragon, 21 Tiger, 41 Lion (verified live
// against the capture's strip: L L D L L L T D L L).
const RESULT_BY_WIN = {
  1: { cls: 'resulta', text: 'D ' },
  21: { cls: 'resultb', text: ' T ' },
  41: { cls: 'resultc', text: ' L ' },
}

// Video overlay: one .player-card per player — label (playera / tie /
// playerb colour classes, reference order) + the dealt card.
const CARD_SLOTS = [
  { label: 'DRAGON', cls: 'playera' },
  { label: 'TIGER', cls: 'tie' },
  { label: 'LION', cls: 'playerb' },
]

// Admin book markets. getMarketsForGame groups by subtype, and this feed
// files all 57 selections under one subtype — that would spread a Winner D
// stake over every other cell. The real exclusive sets: Winner (D/T/L), and per
// player Black/Red, Odd/Even, cards A..K.
const MARKETS = (() => {
  const nat = (sid, name) => ({ sid, nat: name })
  const suffix = { dragon: 'D', tiger: 'T', lion: 'L' }
  const ranks = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K']
  const markets = [VDTL_PLAYERS.map((p) => nat(p.base, `Winner ${suffix[p.key]}`))]
  VDTL_PLAYERS.forEach((p) => {
    const s = suffix[p.key]
    markets.push([nat(p.base + 1, `Black ${s}`), nat(p.base + 2, `Red ${s}`)])
    markets.push([nat(p.base + 3, `Odd ${s}`), nat(p.base + 4, `Even ${s}`)])
    markets.push(ranks.map((r, i) => nat(p.base + 5 + i, `${p.name} ${r}`)))
  })
  return markets
})()

const renderCards = (gameData) => {
  const cards = String(gameData?.card || '').split(',').map((c) => c.trim())
  return CARD_SLOTS.map((slot, i) => (
    <Fragment key={slot.label}>
      {i > 0 && ' '}
      <div className="player-card playera-card">
      {' '}
      <div className={`w-100 ${slot.cls} mb-2`}>{slot.label}</div>
      {' '}
      <span data-v-b64efdfa="">
        <img data-v-b64efdfa="" src={cardSrc(cards[i])} />
      </span>
    </div>
    </Fragment>
  ))
}

const renderResult = (r, i, onClick) => {
  const res = RESULT_BY_WIN[Number(r.win)] || RESULT_BY_WIN[1]
  return <span key={i} className={res.cls} onClick={onClick}>{res.text}</span>
}

// V-20-20 D T L — /admin/vcasino/dtl20 (Virtual Casino list). Reference DOM
// (capture 2026-09-19): shell in VCasinoTable (.casino-table.vcasino.vdtl);
// board BetTableVDtl20; overlay = 3 labelled cards; strip D/T/L.
export default function VDtl20() {
  return (
    <VCasinoTable
      gameType={GAME_TYPE}
      gameName={GAME_NAME}
      tableClass="vdtl"
      cards={renderCards}
      renderResult={renderResult}
    >
      {(gameData, myBets) => (
        <BetTableVDtl20 gameData={gameData} exposures={computeAdminBook(myBets, MARKETS)} />
      )}
    </VCasinoTable>
  )
}
