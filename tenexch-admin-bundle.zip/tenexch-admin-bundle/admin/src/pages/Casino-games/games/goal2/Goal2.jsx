import CasinoGameScreen from '../../../../components/casino/CasinoGameScreen'

// Goal 2 — football next-goal game (players/methods/combination markets)
export default function Goal2() {
  return <CasinoGameScreen gtype="goal2" />
}
