import { Fragment, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { CircularTimer } from '../../../../components/casino/CasinoTimer'
import BetTableDoliDana from '../../../../components/casino/BetTableDoliDana'
import CasinoMyBetsSidebar from '../../../../components/casino/CasinoMyBetsSidebar'
import CasinoResultModal from '../../../../components/casino/CasinoResultModal'
import CasinoRulesModal from '../../../../components/casino/CasinoRulesModal'
import CasinoRulesSwitch from '../../../../components/casino/rules/CasinoRulesSwitch'
import useCasinoGame from '../../../../hooks/casino/useCasinoGame'
import useCasinoLastResults from '../../../../hooks/casino/useCasinoLastResults'
import useCasinoMyBets from '../../../../hooks/casino/useCasinoMyBets'
import useCasinoStream from '../../../../hooks/casino/useCasinoStream'
import { computeAdminBook, getMarketsForGame } from '../../../../utils/casinoBook'

const GAME_TYPE = 'dolidana'
const GAME_NAME = 'Doli Dana'

// Doli Dana (dice) — reference: casino-table doli-dana, video-title me rid
// DIV hota hai (span nahi), koi cards overlay nahi, casino-detail me
// doli-main/doli-other-bets layout (BetTableDoliDana).
export default function Dolidana() {
  const isAuth = useSelector((s) => Boolean(s.auth.token))
  const [resultMid, setResultMid] = useState(null)
  const [showRules, setShowRules] = useState(false)
  const [showLr, setShowLr] = useState(true)
  const [isMobile, setIsMobile] = useState(() => typeof window !== 'undefined' && window.innerWidth < 768)

  useEffect(() => {
    const onResize = () => setIsMobile(window.innerWidth < 768)
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  const { data: gameData } = useCasinoGame(GAME_TYPE)
  const { data: lastResults = [], refetch: refetchLastResults } = useCasinoLastResults(GAME_TYPE)
  const { streamUrl } = useCasinoStream(GAME_TYPE)
  const { myBets } = useCasinoMyBets(GAME_TYPE, isAuth)

  const mid = gameData?.mid ?? ''
  const lt = gameData?.lt ?? 0
  const ft = gameData?.ft ?? 25

  const exposures = computeAdminBook(myBets, getMarketsForGame(GAME_TYPE, gameData))

  // card = "2,1" jab dice roll ho jaye, warna ""
  const diceValues = String(gameData?.card || '')
    .split(',')
    .map((v) => parseInt(v.trim(), 10))
    .filter((n) => !isNaN(n) && n >= 1 && n <= 6)

  useEffect(() => {
    if (mid) refetchLastResults()
  }, [mid, refetchLastResults])

  // last-results: reference me har result `resulttie` class ke saath "R"
  // dikhta hai (sum number nahi)
  const renderResult = (r, i) => (
    <span key={i} className="resulttie" onClick={() => setResultMid(r.mid || null)}>
      R
    </span>
  )

  const resultsStrip = (
    <div className={`casino-video-last-results${showLr ? '' : ' hide-lr'}`}>
      {lastResults.map(renderResult)}
      {' '}
      <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
        {'\n    ...\n  '}
      </Link>
      {' '}
    </div>
  )

  return (
    <>
      <div className="center-main-container">
        <div className="center-content">
          <div className="casino-container">
            <div className="casino-table doli-dana">

              <div className="casino-video">
                <div className="casino-video-title">
                  <span className="casino-name">{GAME_NAME}</span>
                  {' '}
                  <div className="casino-video-rid">
                    {'\n                Round ID: ' + mid + '\n              '}
                  </div>
                </div>
                {' '}
                <div className="video-box-container">
                  <div className="video-box">
                    {streamUrl && <iframe src={streamUrl}></iframe>}
                  </div>
                </div>
                {' '}
                {diceValues.length > 0 && (
                  <div className="casino-video-cards">
                    <div className="casino-video-cards-container">
                      <div>
                        <span>
                          {diceValues.map((n, i) => (
                            <Fragment key={i}>
                              {i > 0 && ' '}
                              <img src={`https://wver.sprintstaticdata.com/v230/static/front/img/dolidana/dice${n}.png`} />
                            </Fragment>
                          ))}
                        </span>
                      </div>
                    </div>
                  </div>
                )}
                {' '}
                <CircularTimer timeLeft={lt} fullTime={ft} />
                {' '}
                <div className="casino-video-right-icons">
                  <div title="Home" className="casino-video-home-icon">
                    <Link to="/admin/casino/list" className="" style={{ color: 'var(--text-highlight)' }}>
                      <i className="fas fa-home"></i>
                    </Link>
                  </div>
                  {' '}
                  <div title="Rules" className="casino-video-rules-icon" onClick={() => setShowRules((v) => !v)}>
                    <i className="fas fa-info-circle"></i>
                  </div>
                  {' '}
                  <div title="Last Results" className="casino-video-lr-icon" onClick={() => setShowLr((v) => !v)}>
                    <i className={`fas ${showLr ? 'fa-chevron-circle-up' : 'fa-chevron-circle-down'}`}></i>
                  </div>
                </div>
              </div>
              {' '}
              <div>{showRules && (
                <div
                  id="casino-vieo-rules"
                  aria-modal="true"
                  className="casino-vieo-rules show d-none-small show-rules"
                  style={{ display: 'block' }}
                >
                  <div className="rules-header">
                    <div>Rules</div>
                    {' '}
                    <i className="fas fa-times" onClick={() => setShowRules(false)}></i>
                  </div>
                  {' '}
                  <div className="rules-body">
                    <CasinoRulesSwitch gameType={GAME_TYPE} />
                  </div>
                </div>
              )}</div>
              {' '}
              {!isMobile && resultsStrip}
              {' '}
              <div className="casino-detail">
                <BetTableDoliDana
                  gameData={gameData}
                  onBet={() => {}}
                  exposures={exposures}
                />
              </div>

            </div>
          </div>
        </div>
        {' '}
        <CasinoMyBetsSidebar myBets={myBets} gameName={GAME_TYPE} />
      </div>

      <CasinoRulesModal
        show={showRules}
        onClose={() => setShowRules(false)}
        tableClass=""
        gameType={GAME_TYPE}
      >
        <CasinoRulesSwitch gameType={GAME_TYPE} />
      </CasinoRulesModal>

      <CasinoResultModal
        show={!!resultMid}
        onClose={() => setResultMid(null)}
        gameType={GAME_TYPE}
        gameName={GAME_NAME}
        mid={resultMid}
      />
    </>
  )
}
