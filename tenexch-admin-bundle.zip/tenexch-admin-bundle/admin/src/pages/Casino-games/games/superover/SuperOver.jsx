import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { CircularTimer } from '../../../../components/casino/CasinoTimer'
import SuperOverBalls, { rankFromCode } from '../../../../components/casino/SuperOverBalls'
import SuperOverMarkets from '../../../../components/casino/SuperOverMarkets'
import CasinoResultModal from '../../../../components/casino/CasinoResultModal'
import CasinoRulesModal from '../../../../components/casino/CasinoRulesModal'
import CasinoRulesSwitch from '../../../../components/casino/rules/CasinoRulesSwitch'
import useCasinoGame from '../../../../hooks/casino/useCasinoGame'
import useCasinoLastResults from '../../../../hooks/casino/useCasinoLastResults'
import useCasinoMyBets from '../../../../hooks/casino/useCasinoMyBets'
import useCasinoStream from '../../../../hooks/casino/useCasinoStream'
import useSuperOverScorecard from '../../../../hooks/casino/useSuperOverScorecard'
import { computeAdminBook, getMarketsForGame } from '../../../../utils/casinoBook'
import { formatStake } from '../../../../utils/casinoUtils'
import useCardStripToggle from '../../../../hooks/casino/useCardStripToggle'

const GAME_TYPE = 'superover'
// Fancy session bet stored with its run line: "1 over run [bhav] ENG 13".
const SESSION_RE = /^(\d+\s+over\s+run(?:\s+bhav)?\s+\S+)\s+(\d+(?:\.\d+)?)$/i
// My Bets: the market name printed on a bet's header row.
const marketOfBet = (sel) => (/^\d+\s+over\s+run/i.test(sel) ? 'Fancy'
  : /^(0\.\d\s+over|common)\s/i.test(sel) ? 'Fancy1' : 'Bookmaker')
// Bet time as the reference prints it: "10/10/2026 02:19:17" (IST).
const betTime = (v) => {
  const d = new Date(v)
  if (!v || isNaN(d.getTime())) return ''
  return new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Asia/Kolkata', day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false,
  }).format(d).replace(',', '')
}
const SO = 'https://wver.sprintstaticdata.com/v230/static/front/img/superOver'

// Inning's Card Rules (static): card image → ball value
const CARD_RULES = [
  { card: 'cardA', ball: 'ball1' },
  { card: 'card2', ball: 'ball2' },
  { card: 'card3', ball: 'ball3' },
  { card: 'card4', ball: 'ball4' },
  { card: 'card6', ball: 'ball6' },
  { card: 'card10', ball: 'ball0' },
  { card: 'cardK', ball: 'wicket', wicket: true },
]

function rankToRuns(rank) {
  if (!rank) return null
  if (rank === 'K') return 'W'
  if (rank === '10') return 0
  if (rank === 'A') return 1
  const n = parseInt(rank, 10)
  return isNaN(n) ? null : n
}

// Super Over = one 6-ball over per innings, 2 wickets end it.
const OVER_BALLS = 6
const MAX_WICKETS = 2

const oversStr = (d) => `${Math.floor(d / OVER_BALLS)}.${d % OVER_BALLS}`
const crrOf = (s) => (s && s.deliveries > 0 ? ((s.runs / s.deliveries) * OVER_BALLS).toFixed(2) : '0.00')

// Current innings only (fallback when the server scorecard is missing). Reads
// every slot of the 6-slot card; "1" / empty = not yet bowled.
function computeScore(cardString) {
  let runs = 0
  let wickets = 0
  let deliveries = 0
  const ballValues = []
  for (const code of (cardString ? String(cardString).split('|') : [])) {
    if (!code || code === '1') continue
    deliveries++
    const val = rankToRuns(rankFromCode(code))
    if (val === 'W') {
      wickets++
      ballValues.push('W')
    } else if (val !== null) {
      runs += val
      ballValues.push(String(val))
    }
  }
  return { runs, wickets, deliveries, ballValues }
}

// Super Over (superover) — API { t1: {ename, card, gmid, lt, ft, scard}, t2:
// [markets] }. Dynamic game name t1.ename ("ENG Vs RSA Super Over"). Same layout
// as SuperOver3 (five-cricket super-over) PLUS ek "Inning's Card Rules" card
// sidebar me my-game-bets ke baad. Strip resulta team1[0] / resultb team2[0] /
// resulttie T. Scorecard = server two-innings scorecard (superover-scorecard
// poller), with a current-innings-only fallback from t1.card.
export default function SuperOver() {
  const isAuth = useSelector((s) => Boolean(s.auth.token))
  const [resultMid, setResultMid] = useState(null)
  const [showRules, setShowRules] = useState(false)
  const [showLr, setShowLr] = useState(true)
  const [isMobile, setIsMobile] = useState(() => typeof window !== 'undefined' && window.innerWidth < 768)

  useEffect(() => {
    const onResize = () => setIsMobile(window.innerWidth < 768)
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  const { data: raw } = useCasinoGame(GAME_TYPE)
  const { data: lastResults = [] } = useCasinoLastResults(GAME_TYPE)
  const { streamUrl } = useCasinoStream(GAME_TYPE)
  const { myBets } = useCasinoMyBets(GAME_TYPE, isAuth)
  const serverCard = useSuperOverScorecard(GAME_TYPE)

  const t1 = (Array.isArray(raw?.t1) ? raw.t1[0] : raw?.t1) || {}
  const t2 = Array.isArray(raw?.t2) ? raw.t2 : []

  const gameName = t1.ename || 'Super Over'
  const gmid = t1.gmid ?? ''
  const [stripCollapsed, toggleStrip] = useCardStripToggle(gmid)
  const lt = t1.lt ?? 0
  const ft = t1.ft ?? 50
  const card = t1.card ?? ''

  const bookmakerMarket = t2.find((m) => m.dtype === 2 || m.gtype === 'match1')
  const sections = bookmakerMarket?.section || []
  const team1 = sections[0]?.nat || 'ENG'
  const team2 = sections[1]?.nat || 'RSA'

  const fancy1Market = t2.find((m) => m.dtype === 7 || m.gtype === 'fancy1')
  const fancyNats = (fancy1Market?.section || []).map((s) => String(s.nat || ''))
  const battingSecond = fancyNats.some((n) => n !== 'Tie' && n.endsWith(` ${team2}`))
  const innings = battingSecond ? 2 : 1

  // Two-innings model. The server scorecard keeps the first innings' total
  // after the chase starts; without it only the current innings is known.
  const fallbackBatting = innings === 2 ? team2 : team1
  const model = serverCard?.scoreByTeam
    ? serverCard
    : {
        phase: innings,
        battingTeam: fallbackBatting,
        firstTeam: team1,
        scoreByTeam: { [fallbackBatting]: computeScore(card) },
      }
  const scTeam1 = model.team1 || team1
  const scTeam2 = model.team2 || team2
  const scoreByTeam = model.scoreByTeam || {}
  const battingTeam = model.battingTeam
  const firstTeam = model.firstTeam
  // Fancy1 colours are first-innings only. The server card can still describe
  // the previous round until the new one folds — use it only for this round.
  const fancy1ColourTeam = !serverCard || String(serverCard.gmid ?? '') === String(gmid) ? firstTeam : ''
  const batScore = scoreByTeam[battingTeam]
  const crr = crrOf(batScore)
  const ballValues = batScore?.ballValues || []

  // Chase maths (same rules as the user site's SuperOverScorecard).
  const chase = model.phase === 2
  const firstRuns = scoreByTeam[firstTeam]?.runs ?? 0
  const chaseRuns = chase ? (batScore?.runs ?? 0) : 0
  const needed = firstRuns + 1 - chaseRuns
  const ballsLeft = OVER_BALLS - (chase ? (batScore?.deliveries ?? 0) : 0)
  const chaseEnded = chase && batScore && (
    chaseRuns > firstRuns || batScore.deliveries >= OVER_BALLS || batScore.wickets >= MAX_WICKETS
  )
  const rr = chase && !chaseEnded && ballsLeft > 0 ? ((needed / ballsLeft) * OVER_BALLS).toFixed(2) : null
  let scoreMessage = ''
  if (chaseEnded) {
    scoreMessage = chaseRuns > firstRuns ? `${battingTeam} won the match`
      : chaseRuns < firstRuns ? `${firstTeam} won the match`
      : 'Match Tied'
  } else if (chase) {
    scoreMessage = chaseRuns === firstRuns ? 'Score level' : `${battingTeam} Needed ${needed} runs from ${ballsLeft} balls`
  }

  const exposures = useMemo(() => {
    const sub = []
    for (const m of t2) {
      const etype = m.dtype === 2 || m.gtype === 'match1' ? 'match' : (m.gtype || 'fancy')
      for (const s of m.section || []) {
        sub.push({ sid: s.sid, nat: s.nat, subtype: m.gtype || 'bookmaker', etype })
      }
    }
    const book = computeAdminBook(myBets, getMarketsForGame(GAME_TYPE, { sub }))
    // Fancy session bets carry their run line ("1 over run ENG 13") so they
    // match no feed row above. All bets on a row settle on the same innings
    // total, so the row shows the ADMIN's worst P/L over every total 0–36
    // (runs ladder; Yes wins at total >= line) — same as the player page.
    const ladders = {}
    for (const b of myBets) {
      const m = String(b.selection || '').trim().match(SESSION_RE)
      const odds = parseFloat(b.odds) || 0
      const stake = parseFloat(b.amount ?? b.stake) || 0
      if (!m || !odds || !stake) continue
      const isLay = String(b.game_type || b.type || '').toLowerCase() === 'lay'
      const win = (odds - 1) * stake
      const line = Number(m[2])
      const pl = ladders[m[1].toLowerCase()] || (ladders[m[1].toLowerCase()] = new Array(37).fill(0))
      for (let r = 0; r <= 36; r++) {
        const yes = r >= line
        // admin P/L = the user's, negated
        pl[r] -= isLay ? (yes ? -win : stake) : (yes ? win : -stake)
      }
    }
    for (const s of sub) {
      const pl = ladders[String(s.nat || '').trim().toLowerCase()]
      if (pl) book[`sid:${s.sid}`] = Math.round(Math.min(...pl) * 100) / 100
    }
    return book
  }, [t2, myBets])

  const hideBalls = !card || card.split('|').every((c) => c === '1')

  const resultsStrip = (
    <div className={`casino-video-last-results${showLr ? '' : ' hide-lr'}`}>
      {lastResults.map((r, i) => {
        const w = String(r.win)
        const cls = w === '1' ? 'resulta' : w === '2' ? 'resultb' : 'resulttie'
        const letter = w === '1' ? `${team1.charAt(0)} ` : w === '2' ? ` ${team2.charAt(0)} ` : ' T'
        return (
          <span key={i} className={cls} onClick={() => setResultMid(r.mid || null)}>
            {letter}
          </span>
        )
      })}
      {' '}
      <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
        {'\n    ...\n  '}
      </Link>
      {' '}
    </div>
  )

  const crrDiv = (
    <div>
      <span>
        {'\n                            CRR\n                            ' + crr + '\n                          '}
      </span>
      {' '}
      {rr != null && <span>{'RR ' + rr}</span>}
    </div>
  )

  const scoreText = (team) => {
    const s = scoreByTeam[team]
    return s
      ? `\n                          ${s.runs}-${s.wickets} (${oversStr(s.deliveries)})\n                        `
      : '\n                          0-0 (0.0)\n                        '
  }

  const scorecardRows = (
    <>
      <div className="scorecard-row">
        <div className="score-top-row">
          <div className="score-team">
            <b>{scTeam1}</b>
            {scoreText(scTeam1)}
          </div>
          {' '}
          {battingTeam === scTeam1 ? crrDiv : <div>{' '}</div>}
          {' '}
        </div>
        {scoreMessage && <div className="score-message">{scoreMessage}</div>}
      </div>
      {' '}
      <div className="scorecard-row">
        <div className="score-top-row">
          <div className="score-team">
            <b>{scTeam2}</b>
            {scoreText(scTeam2)}
          </div>
          {' '}
          {battingTeam === scTeam2 ? crrDiv : <div>{' '}</div>}
          {' '}
          <div className="score-message">
            {ballValues.map((v, i) => (
              <span key={i} className={`ball-runs mr-1${v === '6' ? ' six' : ''}`}>{v}</span>
            ))}
          </div>
        </div>
      </div>
    </>
  )

  const cricketRuleCard = (
    <div className="card mb-2 my-bet cricket-rule">
      <div className="card-header text-center">
        <span>{team1} vs {team2}<br />Inning's Card Rules</span>
      </div>
      {' '}
      <div className="card-body">
        <div className="card">
          <div className="card-header">
            <div className="row row5 mt-1">
              <div className="col-4">Cards</div>
              {' '}
              <div className="col-3 text-center">Count</div>
              {' '}
              <div className="col-5 text-right">Value</div>
            </div>
          </div>
          {' '}
          <div className="card-body">
            {CARD_RULES.map((r) => (
              <div key={r.card} className="row row5 mt-1">
                <div className="col-4">
                  <img src={`${SO}/cards/${r.card}.png`} /> <span className="ml-2">X</span>
                </div>
                {' '}
                <div className="col-3 text-center">5</div>
                {' '}
                <div className="col-5 text-right value">
                  {r.wicket ? (
                    <>
                      {'\n                  WICKET\n                  '}
                      <img src={`${SO}/balls/wicket.png`} />
                    </>
                  ) : (
                    <img src={`${SO}/balls/${r.ball}.png`} />
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )

  // Reference order: every bet newest first, whatever its market.
  const myBetsSorted = [...myBets].sort((a, b) =>
    (new Date(b.created_at) - new Date(a.created_at)) || (Number(b.id) - Number(a.id)))

  const myBetsCard = (
    <div id="my-game-bets" className="card m-b-10 my-bet">
      <div className="card-header">
        <h6 className="card-title float-left">My Bets</h6>
        {' '}
        <a href="javascript:void(0)" className="btn btn-back float-right">View More</a>
      </div>
      {' '}
      <div className="card-body1">
        <div className="tab-content">
          <div id="matched-bet" className="tab-pane active">
            <div className="table-responsive1">
              <table className="table coupon-table mb-0">
                <thead>
                  <tr>
                    <th style={{ minWidth: '90px' }}>UserName</th>
                    <th style={{ minWidth: '90px' }}>Nation</th>
                    <th className="text-right" style={{ minWidth: '50px' }}>Rate</th>
                    <th className="text-right" style={{ minWidth: '70px' }}>
                      {'\n                        Amount\n                      '}
                    </th>
                  </tr>
                </thead>
                {/* Reference: every bet is its own block — a header row with the
                    market name + bet time, then the bet; newest bet first. A session bet reads
                    "1 over run ENG / 84" with its line (13) as the rate. */}
                {myBetsSorted.map((bet, i) => {
                  const sel = String(bet.selection || bet.player_name || '').trim()
                  const market = marketOfBet(sel)
                  const sm = sel.match(SESSION_RE)
                  const nation = sm ? `${sm[1]} / ${Math.round(((parseFloat(bet.odds) || 0) - 1) * 100)}` : sel
                  const rate = sm ? sm[2] : formatStake(bet.odds ?? bet.rate)
                  const cls = String(bet.game_type || bet.type || '').toLowerCase() === 'lay' ? 'lay-border' : 'back-border'
                  return (
                    <tbody key={bet.id || bet._id || i}>
                      <tr className={cls}>
                        <td colSpan={2}><b>{market}</b></td>
                        <td colSpan={2} className="text-right">{betTime(bet.created_at)}</td>
                      </tr>
                      <tr className={cls}>
                        <td>{bet.username || bet.user_name || bet.user_id || ''}</td>
                        <td>{nation}</td>
                        <td className="text-right">{rate}</td>
                        <td className="text-right">{formatStake(bet.amount ?? bet.stake)}</td>
                      </tr>
                    </tbody>
                  )
                })}
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  )

  return (
    <>
      <div className="center-main-container">
        <div className="center-content">
          <div className="casino-container">
            <div className="casino-table five-cricket super-over detail-page-container">

              <div className="game-header">
                <span className="game-header-name">{gameName}</span>
                {' '}
                <span className="float-right game-header-date">Round ID: {gmid}</span>
              </div>
              {' '}
              <div className="container-fluid container-fluid-5">
                <div className="row row5">
                  <div className="col-xl-2 banner d-flex align-items-center mb-1">
                    <div className="scorecard">
                      {scorecardRows}
                    </div>
                  </div>
                  {' '}
                  <div className="col-xl-10">
                    <div className="casino-video mt-0">
                      <div className="video-box-container">
                        <div className="video-box">
                          {streamUrl && <iframe src={streamUrl}></iframe>}
                        </div>
                      </div>
                      {' '}
                      <div className={`casino-video-cards${hideBalls || stripCollapsed ? ' hide-cards' : ''}`}>
                        <div className="casino-cards-shuffle" role="button" style={{ cursor: 'pointer' }} onClick={toggleStrip}>
                          <i className="fas fa-grip-lines-vertical"></i>
                        </div>
                        {' '}
                        <SuperOverBalls cardString={card} slots={OVER_BALLS} />
                      </div>
                      {' '}
                      <CircularTimer timeLeft={lt} fullTime={ft} />
                      {' '}
                      <div className="casino-video-right-icons">
                        <div title="Home" className="casino-video-home-icon">
                          <Link to="/admin/casino/list" className="" style={{ color: 'var(--text-highlight)' }}>
                            <i className="fas fa-home"></i>
                          </Link>
                        </div>
                        {' '}
                        <div title="Rules" className="casino-video-rules-icon" onClick={() => setShowRules((v) => !v)}>
                          <i className="fas fa-info-circle"></i>
                        </div>
                        {' '}
                        <div title="Last Results" className="casino-video-lr-icon" onClick={() => setShowLr((v) => !v)}>
                          <i className={`fas ${showLr ? 'fa-chevron-circle-up' : 'fa-chevron-circle-down'}`}></i>
                        </div>
                      </div>
                      {' '}
                      <div>{showRules && (
                        <div
                          id="casino-vieo-rules"
                          aria-modal="true"
                          className="casino-vieo-rules show d-none-small show-rules"
                          style={{ display: 'block' }}
                        >
                          <div className="rules-header">
                            <div>Rules</div>
                            {' '}
                            <i className="fas fa-times" onClick={() => setShowRules(false)}></i>
                          </div>
                          {' '}
                          <div className="rules-body">
                            <CasinoRulesSwitch gameType={GAME_TYPE} />
                          </div>
                        </div>
                      )}</div>
                      {' '}
                      {!isMobile && resultsStrip}
                    </div>
                  </div>
                </div>
              </div>
              {' '}
              <div className="market-container">
                {t2.length > 0 && (
                  <SuperOverMarkets markets={t2} onBet={() => {}} exposures={exposures} bookRatio referenceFancy1 firstTeam={fancy1ColourTeam} />
                )}
              </div>
              {' '}
              {isMobile && resultsStrip}

            </div>
          </div>
        </div>
        {' '}
        {isMobile ? (
          <div className="right-sidebar">
            {myBetsCard}
            {' '}
            {cricketRuleCard}
            {' '}
            <div className="market-show-icon d-none-desktop">
              <div className="bet-cnt">{'\n        ' + Math.min(myBets.length, 10) + '\n      '}</div>
              {' '}
              <div className="bet-title">Bets</div>
            </div>
          </div>
        ) : (
          <div data-simplebar="true" className="right-sidebar">
            {myBetsCard}
            {' '}
            {cricketRuleCard}
            {' '}
            {/* Bets badge: also between 768px and desktop (the reference shows it
                there); its d-none-desktop class hides it on a real desktop. */}
            <div className="market-show-icon d-none-desktop">
              <div className="bet-cnt">{Math.min(myBets.length, 10)}</div>
              {' '}
              <div className="bet-title">Bets</div>
            </div>
          </div>
        )}
      </div>

      <CasinoRulesModal
        show={showRules}
        onClose={() => setShowRules(false)}
        tableClass=""
        gameType={GAME_TYPE}
      >
        <CasinoRulesSwitch gameType={GAME_TYPE} />
      </CasinoRulesModal>

      <CasinoResultModal
        show={!!resultMid}
        onClose={() => setResultMid(null)}
        gameType={GAME_TYPE}
        gameName={gameName}
        mid={resultMid}
      />
    </>
  )
}
