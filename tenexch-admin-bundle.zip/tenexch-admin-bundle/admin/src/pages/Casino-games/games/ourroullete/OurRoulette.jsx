import RoulettePage from '../../../../components/casino/RoulettePage'

export default function OurRoulette() {
  return <RoulettePage gameType="ourroullete" gameName="Unique Roulette" />
}
