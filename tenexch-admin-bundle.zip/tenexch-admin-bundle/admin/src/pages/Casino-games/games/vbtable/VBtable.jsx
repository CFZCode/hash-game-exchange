import BetTableVBtable from '../../../../components/casino/BetTableVBtable'
import VCasinoTable from '../../../../components/casino/VCasinoTable'
import { computeAdminBook, getMarketsForGame } from '../../../../utils/casinoBook'
import { cardSrc } from '../../../../components/casino/cards/cardUtils'

const GAME_TYPE = 'vbtable'
const GAME_NAME = 'V-Bollywood Casino'

// Overlay: `.text-center.w-100 > span > img` — one card, no label (capture).
const renderCards = (gameData) => (
  <div className="text-center w-100">
    <span data-v-b64efdfa="">
      <img data-v-b64efdfa="" src={cardSrc(String(gameData?.card || '').split(',')[0])} />
    </span>
  </div>
)

// last-results `win` 1..6 → film letter A..F, always `resultb` (capture strip
// F B C D D A …; same rule as the non-virtual btable page).
const LETTERS = ['A', 'B', 'C', 'D', 'E', 'F']
const renderResult = (r, i, onClick) => {
  const n = Number(r.win)
  const letter = LETTERS[n - 1] || ''
  return <span key={i} className="resultb" onClick={onClick}>{n === 1 ? `${letter} ` : ` ${letter} `}</span>
}

// V-Bollywood Casino — /admin/vcasino/btable. Reference DOM (capture
// 2026-09-19): shell VCasinoTable (.casino-table.vcasino.vbt), board
// BetTableVBtable, sidebar My Bets only. Book: getMarketsForGame (films etype
// match → one market with lay; Odd fancy1 + the rest fancy → single markets).
export default function VBtable() {
  return (
    <VCasinoTable
      gameType={GAME_TYPE}
      gameName={GAME_NAME}
      tableClass="vbt"
      cards={renderCards}
      renderResult={renderResult}
    >
      {(gameData, myBets) => (
        <BetTableVBtable
          gameData={gameData}
          exposures={computeAdminBook(myBets, getMarketsForGame(GAME_TYPE, gameData))}
        />
      )}
    </VCasinoTable>
  )
}
