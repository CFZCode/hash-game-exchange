import { Card32ABase } from '../card32a/Card32A'

// Premium 32 Cards A — /admin/pcasino/pcard32 (Premium Casino list).
// Reference capture (tenexch.com-admin-pcasino-pcard32, 2026-09-20) was taken
// between rounds, so it holds only the shell: .casino-table.cards32a, title
// "Premium 32 Cards A", iframe stream, Home / Rules / Last Results, sidebar My
// Bets only, no remark. That shell is the 32 Cards A page; the pcard32 feed is
// card32's shape (Player 8/9/10/11 back+lay, 36 cards, ft 25; min 1000 max
// 200000, which BetTableCard32 reads from the feed). Type, title, Home differ.
export default function PCard32() {
  return <Card32ABase gameType="pcard32" gameName="Premium 32 Cards" homePath="/admin/pcasino/list" />
}
