import { Teen20Base } from './Teen20'

// 20-20 Teenpatti VIP — /admin/casino/vip/teenpattit20 (Vip Casino list).
// Reference DOM (2026-09-19) = teenpatti20 page ka hi markup: table
// teenpatti20, same BetTableTeen20, same Pair Plus card, strip A/B, result
// link /admin/reports/casinoresult/teen20v1. Sirf feed type teen20v1 aur
// naam alag — isliye Teen20Base ko props de kar reuse.
const GAME_TYPE = 'teen20v1'
const GAME_NAME = '20-20 Teenpatti VIP'

export default function Teen20Vip() {
  return <Teen20Base gameType={GAME_TYPE} gameName={GAME_NAME} />
}
