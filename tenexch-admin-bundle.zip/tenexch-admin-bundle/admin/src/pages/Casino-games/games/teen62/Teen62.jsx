import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { CircularTimer } from '../../../../components/casino/CasinoTimer'
import BetTableTeen62 from '../../../../components/casino/BetTableTeen62'
import CasinoMyBetsSidebar from '../../../../components/casino/CasinoMyBetsSidebar'
import CasinoResultModal from '../../../../components/casino/CasinoResultModal'
import CasinoRulesModal from '../../../../components/casino/CasinoRulesModal'
import CasinoRulesSwitch from '../../../../components/casino/rules/CasinoRulesSwitch'
import useCasinoGame from '../../../../hooks/casino/useCasinoGame'
import useCasinoLastResults from '../../../../hooks/casino/useCasinoLastResults'
import useCasinoMyBets from '../../../../hooks/casino/useCasinoMyBets'
import useCasinoStream from '../../../../hooks/casino/useCasinoStream'
import { computeAdminBook, getMarketsForGame } from '../../../../utils/casinoBook'
import useCardStripToggle from '../../../../hooks/casino/useCardStripToggle'

const GAME_TYPE = 'teen62'
const GAME_NAME = 'V VIP Teenpatti 1-day'
const CARD_BASE = 'https://wver.sprintstaticdata.com/v230/static/front/img/cards'

// card string "6SS,6CC,4SS,5SS,8CC,1" — alternate deal: A = 0,2,4 / B = 1,3,5
// ('1' = face-down card)
const splitHands = (cardStr) => {
  const codes = String(cardStr || '').split(',').filter(Boolean)
  while (codes.length < 6) codes.push('1')
  return {
    handA: [codes[0], codes[2], codes[4]],
    handB: [codes[1], codes[3], codes[5]],
  }
}

// V VIP Teenpatti 1-day — reference: casino-table teenpatti1day, video ke
// andar title (casino-video-title), cards overlay (A/B teen hands),
// teen1day layout wala BetTableTeen62 casino-detail me, last results A/B.
export default function Teen62() {
  const isAuth = useSelector((s) => Boolean(s.auth.token))
  const [resultMid, setResultMid] = useState(null)
  const [showRules, setShowRules] = useState(false)
  const [showLr, setShowLr] = useState(true)
  const [isMobile, setIsMobile] = useState(() => typeof window !== 'undefined' && window.innerWidth < 768)

  useEffect(() => {
    const onResize = () => setIsMobile(window.innerWidth < 768)
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  const { data: gameData } = useCasinoGame(GAME_TYPE)
  const { data: lastResults = [], refetch: refetchLastResults } = useCasinoLastResults(GAME_TYPE)
  const { streamUrl } = useCasinoStream(GAME_TYPE)
  const { myBets } = useCasinoMyBets(GAME_TYPE, isAuth)

  const mid = gameData?.mid ?? ''
  const [stripCollapsed, toggleStrip] = useCardStripToggle(mid)
  const lt = gameData?.lt ?? 0
  const ft = gameData?.ft ?? 30
  const { handA, handB } = splitHands(gameData?.card)

  const exposures = computeAdminBook(myBets, getMarketsForGame(GAME_TYPE, gameData))

  useEffect(() => {
    if (mid) refetchLastResults()
  }, [mid, refetchLastResults])

  const renderResult = (r, i) => {
    const isA = String(r.win) === '1'
    return (
      <span key={i} className={isA ? 'resulta' : 'resultb'} onClick={() => setResultMid(r.mid || null)}>
        {isA ? 'A ' : ' B '}
      </span>
    )
  }

  const resultsStrip = (
    <div className={`casino-video-last-results${showLr ? '' : ' hide-lr'}`}>
      {lastResults.map(renderResult)}
      {' '}
      <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
        {'\n    ...\n  '}
      </Link>
      {' '}
    </div>
  )

  return (
    <>
      <div className="center-main-container">
        <div className="center-content">
          <div className="casino-container">
            <div className="casino-table teenpatti1day">

              <div className="casino-video">
                <div className="casino-video-title">
                  <span className="casino-name">{GAME_NAME}</span>
                  {' '}
                  <span className="casino-video-rid">Round ID: {mid}</span>
                </div>
                {' '}
                <div className="video-box-container">
                  <div className="video-box">
                    {streamUrl && <iframe src={streamUrl}></iframe>}
                  </div>
                </div>
                {' '}
                <div className={`casino-video-cards${[...handA, ...handB].some((c) => c && c !== '1' && c !== '0') && !stripCollapsed ? '' : ' hide-cards'}`}>
                  <div className="casino-cards-shuffle" role="button" style={{ cursor: 'pointer' }} onClick={toggleStrip}>
                    <i className="fas fa-grip-lines-vertical"></i>
                  </div>
                  {' '}
                  <div className="casino-video-cards-container">
                    <div>
                      {handA.map((c, i) => (
                        <span key={i} data-v-b64efdfa="">
                          <img data-v-b64efdfa="" src={`${CARD_BASE}/${c}.png`} />
                        </span>
                      ))}
                    </div>
                    {' '}
                    <div>
                      {handB.map((c, i) => (
                        <span key={i} data-v-b64efdfa="">
                          <img data-v-b64efdfa="" src={`${CARD_BASE}/${c}.png`} />
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
                {' '}
                <CircularTimer timeLeft={lt} fullTime={ft} />
                {' '}
                <div className="casino-video-right-icons">
                  <div title="Home" className="casino-video-home-icon">
                    <Link to="/admin/casino/list" className="" style={{ color: 'var(--text-highlight)' }}>
                      <i className="fas fa-home"></i>
                    </Link>
                  </div>
                  {' '}
                  <div title="Rules" className="casino-video-rules-icon" onClick={() => setShowRules((v) => !v)}>
                    <i className="fas fa-info-circle"></i>
                  </div>
                  {' '}
                  <div title="Last Results" className="casino-video-lr-icon" onClick={() => setShowLr((v) => !v)}>
                    <i className={`fas ${showLr ? 'fa-chevron-circle-up' : 'fa-chevron-circle-down'}`}></i>
                  </div>
                </div>
                {' '}
                <div></div>
                {' '}
                {!isMobile && resultsStrip}
                {' '}
                {showRules && (
                  <div
                    id="casino-vieo-rules"
                    aria-modal="true"
                    className="casino-vieo-rules show d-none-small show-rules"
                    style={{ display: 'block' }}
                  >
                    <div className="rules-header">
                      <div>Rules</div>
                      {' '}
                      <i className="fas fa-times" onClick={() => setShowRules(false)}></i>
                    </div>
                    {' '}
                    <div className="rules-body">
                      <CasinoRulesSwitch gameType={GAME_TYPE} />
                    </div>
                  </div>
                )}
              </div>
              {' '}
              <div className="casino-detail">
                <BetTableTeen62
                  gameData={gameData}
                  onBet={() => {}}
                  exposures={exposures}
                />
                {' '}
                {isMobile && resultsStrip}
              </div>

            </div>
          </div>
        </div>
        {' '}
        <CasinoMyBetsSidebar myBets={myBets} gameName={GAME_TYPE} />
      </div>

      <CasinoRulesModal
        show={showRules}
        onClose={() => setShowRules(false)}
        tableClass=""
        gameType={GAME_TYPE}
      >
        <CasinoRulesSwitch gameType={GAME_TYPE} />
      </CasinoRulesModal>

      <CasinoResultModal
        show={!!resultMid}
        onClose={() => setResultMid(null)}
        gameType={GAME_TYPE}
        gameName={GAME_NAME}
        mid={resultMid}
      />
    </>
  )
}
