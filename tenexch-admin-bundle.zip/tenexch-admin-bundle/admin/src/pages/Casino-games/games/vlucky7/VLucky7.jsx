import BetTableVLucky7 from '../../../../components/casino/BetTableVLucky7'
import VCasinoTable from '../../../../components/casino/VCasinoTable'
import { computeAdminBook, getMarketsForGame } from '../../../../utils/casinoBook'
import { cardSrc } from '../../../../components/casino/cards/cardUtils'

const GAME_TYPE = 'vlucky7'
const GAME_NAME = 'V-Lucky 7 - A'

// Overlay: `.text-center.w-100 > .w-100.playera.mb-2 "Card" + span > img`
// (single card; face-down 1.png as the reference).
const renderCards = (gameData) => (
  <div className="text-center w-100">
    <div className="w-100 playera mb-2">Card</div>
    {' '}
    <span data-v-b64efdfa="">
      <img data-v-b64efdfa="" src={cardSrc(String(gameData?.card || '').split(',')[0])} />
    </span>
  </div>
)

// last-results `win` 1 → Low ("L " resultlow), 2 → High (" H " resulthigh),
// 0 → 7 = Tie (resulttie, as the non-virtual lucky7 page). Capture strip
// H H L H L H L L …
const renderResult = (r, i, onClick) => {
  const w = String(r.win)
  if (w === '1') return <span key={i} className="resultlow" onClick={onClick}>{'L '}</span>
  if (w === '2') return <span key={i} className="resulthigh" onClick={onClick}>{' H '}</span>
  return <span key={i} className="resulttie" onClick={onClick}>T</span>
}

// V-Lucky 7 - A — /admin/vcasino/lucky7. Reference DOM (capture 2026-09-19):
// shell VCasinoTable (.casino-table.vcasino.vlucky7), board BetTableVLucky7,
// sidebar My Bets only. Book: getMarketsForGame (all Fancy → single markets,
// as the non-virtual lucky7 page).
export default function VLucky7() {
  return (
    <VCasinoTable
      gameType={GAME_TYPE}
      gameName={GAME_NAME}
      tableClass="vlucky7"
      cards={renderCards}
      renderResult={renderResult}
    >
      {(gameData, myBets) => (
        <BetTableVLucky7
          gameData={gameData}
          exposures={computeAdminBook(myBets, getMarketsForGame(GAME_TYPE, gameData))}
        />
      )}
    </VCasinoTable>
  )
}
