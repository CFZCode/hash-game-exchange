import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { CircularTimer } from '../../../../components/casino/CasinoTimer'
import SuperOverBalls, { parseBalls, rankFromCode } from '../../../../components/casino/SuperOverBalls'
import SuperOverMarkets from '../../../../components/casino/SuperOverMarkets'
import CasinoResultModal from '../../../../components/casino/CasinoResultModal'
import CasinoRulesModal from '../../../../components/casino/CasinoRulesModal'
import CasinoRulesSwitch from '../../../../components/casino/rules/CasinoRulesSwitch'
import useCasinoGame from '../../../../hooks/casino/useCasinoGame'
import useCasinoLastResults from '../../../../hooks/casino/useCasinoLastResults'
import useCasinoMyBets from '../../../../hooks/casino/useCasinoMyBets'
import useCasinoStream from '../../../../hooks/casino/useCasinoStream'
import useSuperOverScorecard from '../../../../hooks/casino/useSuperOverScorecard'
import useStickySidebar from '../../../../hooks/useStickySidebar'
import { computeAdminBook, getMarketsForGame } from '../../../../utils/casinoBook'
import { formatStake } from '../../../../utils/casinoUtils'
import useCardStripToggle from '../../../../hooks/casino/useCardStripToggle'

const GAME_TYPE = 'superover3'
const GAME_NAME = 'Mini SuperOver'
// Book / Fancy1 / My Bets rules are the Super Over ones, fitted to Mini's
// market (Tie sits in Fancy1 and takes back + lay).
// Plan: docs/plans/2026-10-12-mini-superover-parity.md
// Fancy session bet stored with its run line: "1 over run [bhav] IND 8".
const SESSION_RE = /^(\d+\s+over\s+run(?:\s+bhav)?\s+\S+)\s+(\d+(?:\.\d+)?)$/i
// My Bets: the market name printed on a bet's header row.
const marketOfBet = (sel) => (/^\d+\s+over\s+run/i.test(sel) ? 'Fancy'
  : /^(0\.\d\s+over|common)\s/i.test(sel) || /^tie$/i.test(sel) ? 'Fancy1' : 'Bookmaker')
// Bet time as the reference prints it: "10/10/2026 02:19:17" (IST).
const betTime = (v) => {
  const d = new Date(v)
  if (!v || isNaN(d.getTime())) return ''
  return new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Asia/Kolkata', day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false,
  }).format(d).replace(',', '')
}

function rankToRuns(rank) {
  if (!rank) return null
  if (rank === 'K') return 'W'
  if (rank === '10') return 0
  if (rank === 'A') return 1
  const n = parseInt(rank, 10)
  return isNaN(n) ? null : n
}

// current innings score card string ("3DD|KDD|1|1") se
function computeScore(cardString) {
  let runs = 0
  let wickets = 0
  let deliveries = 0
  const ballValues = []
  for (const code of parseBalls(cardString)) {
    if (code === null) continue
    deliveries++
    const val = rankToRuns(rankFromCode(code))
    if (val === 'W') {
      wickets++
      ballValues.push('W')
    } else if (val !== null) {
      runs += val
      ballValues.push(String(val))
    }
  }
  const overs = `${Math.floor(deliveries / 4)}.${deliveries % 4}`
  const crr = deliveries > 0 ? ((runs / deliveries) * 4).toFixed(2) : '0.00'
  return { score: `${runs}-${wickets}`, overs, crr, ballValues }
}

// Mini SuperOver (superover3) — API shape { t1: {card, gmid, lt, ft, scard},
// t2: [markets] } (sub nahi). Reference: casino-table five-cricket super-over
// detail-page-container; game-header + col-xl-2 scorecard (score-top-row) +
// col-xl-10 video (balls overlay, superOver/balls/<rank>.png); market-container
// t2 se; strip resulta I / resultb A / resulttie T; sidebar simple
// my-game-bets card (UserName/Nation/Rate/Amount).
// NOTE: pehli innings ka total/winner message all-data me nahi aata
// (bakend-docs/missing-apis.md) — dono innings rows current-innings data se
// best-effort render hoti hain.
export default function SuperOver3() {
  const isAuth = useSelector((s) => Boolean(s.auth.token))
  const [resultMid, setResultMid] = useState(null)
  const [showRules, setShowRules] = useState(false)
  const [showLr, setShowLr] = useState(true)
  const [isMobile, setIsMobile] = useState(() => typeof window !== 'undefined' && window.innerWidth < 768)
  const stickyClass = useStickySidebar()

  useEffect(() => {
    const onResize = () => setIsMobile(window.innerWidth < 768)
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  const { data: raw } = useCasinoGame(GAME_TYPE)
  const { data: lastResults = [] } = useCasinoLastResults(GAME_TYPE)
  const { streamUrl } = useCasinoStream(GAME_TYPE)
  const { myBets } = useCasinoMyBets(GAME_TYPE, isAuth)
  const serverCard = useSuperOverScorecard(GAME_TYPE)

  const t1 = (Array.isArray(raw?.t1) ? raw.t1[0] : raw?.t1) || {}
  const t2 = Array.isArray(raw?.t2) ? raw.t2 : []

  const gmid = t1.gmid ?? ''
  const [stripCollapsed, toggleStrip] = useCardStripToggle(gmid)
  const lt = t1.lt ?? 0
  const ft = t1.ft ?? 35
  const card = t1.card ?? ''

  const bookmakerMarket = t2.find((m) => m.dtype === 2 || m.gtype === 'match1')
  const sections = bookmakerMarket?.section || []
  const team1 = sections[0]?.nat || 'IND'
  const team2 = sections[1]?.nat || 'AUS'

  // batting team fancy1 selection names se ("0.2 Over Wicket AUS" -> AUS
  // batting = innings 2); t1.scard innings nahi batata (missing-apis #23)
  const fancy1Market = t2.find((m) => m.dtype === 7 || m.gtype === 'fancy1')
  const fancyNats = (fancy1Market?.section || []).map((s) => String(s.nat || ''))
  const battingSecond = fancyNats.some((n) => n !== 'Tie' && n.endsWith(` ${team2}`))
  const innings = battingSecond ? 2 : 1

  const { score, overs, crr, ballValues } = computeScore(card)

  // Fancy1 colours are first-innings only. The server card can still describe
  // the previous round until the new one folds — use it only for this round.
  const fancy1ColourTeam = serverCard && String(serverCard.gmid ?? '') === String(gmid) ? (serverCard.firstTeam || '') : ''

  // t2 markets ko book-resolver ke sub[] format me le jao: bookmaker ek
  // match-spread market, fancy/fancy1 singles
  const exposures = useMemo(() => {
    const sub = []
    for (const m of t2) {
      const etype = m.dtype === 2 || m.gtype === 'match1' ? 'match' : (m.gtype || 'fancy')
      for (const s of m.section || []) {
        sub.push({ sid: s.sid, nat: s.nat, subtype: m.gtype || 'bookmaker', etype })
      }
    }
    const book = computeAdminBook(myBets, getMarketsForGame(GAME_TYPE, { sub }))
    // Fancy session bets carry their run line ("1 over run IND 8") so they
    // match no feed row above. All bets on a row settle on the same innings
    // total, so the row shows the ADMIN's worst P/L over every total 0–36
    // (runs ladder; Yes wins at total >= line) — same as Super Over.
    // Tie (Fancy1, back + lay): one YES/NO line, back + lay nets (server
    // DYNAMIC_MARKETS.superover3) — the admin's worst of tie / no tie.
    const ladders = {}
    const tie = { hit: 0, miss: 0, any: false }
    for (const b of myBets) {
      const sel = String(b.selection || '').trim()
      const odds = parseFloat(b.odds) || 0
      const stake = parseFloat(b.amount ?? b.stake) || 0
      if (!odds || !stake) continue
      const isLay = String(b.game_type || b.type || '').toLowerCase() === 'lay'
      const win = (odds - 1) * stake
      if (/^tie$/i.test(sel)) {
        // admin P/L = the user's, negated
        tie.any = true
        if (isLay) { tie.hit += win; tie.miss -= stake } else { tie.hit -= win; tie.miss += stake }
        continue
      }
      const m = sel.match(SESSION_RE)
      if (!m) continue
      const line = Number(m[2])
      const pl = ladders[m[1].toLowerCase()] || (ladders[m[1].toLowerCase()] = new Array(37).fill(0))
      for (let r = 0; r <= 36; r++) {
        const yes = r >= line
        pl[r] -= isLay ? (yes ? -win : stake) : (yes ? win : -stake)
      }
    }
    for (const s of sub) {
      const nat = String(s.nat || '').trim()
      const pl = ladders[nat.toLowerCase()]
      if (pl) book[`sid:${s.sid}`] = Math.round(Math.min(...pl) * 100) / 100
      if (tie.any && /^tie$/i.test(nat)) book[`sid:${s.sid}`] = Math.round(Math.min(tie.hit, tie.miss) * 100) / 100
    }
    return book
  }, [t2, myBets])

  // Reference order: every bet newest first, whatever its market.
  const myBetsSorted = [...myBets].sort((a, b) =>
    (new Date(b.created_at) - new Date(a.created_at)) || (Number(b.id) - Number(a.id)))

  const hideBalls = !card || card.split('|').every((c) => c === '1')

  // reference: web view me strip casino-video ke andar, mobile pe
  // market-container ke baad
  const resultsStrip = (
    <div className={`casino-video-last-results${showLr ? '' : ' hide-lr'}`}>
      {lastResults.map((r, i) => {
        const w = String(r.win)
        const cls = w === '1' ? 'resulta' : w === '2' ? 'resultb' : 'resulttie'
        const letter = w === '1' ? 'I ' : w === '2' ? ' A ' : ' T'
        return (
          <span key={i} className={cls} onClick={() => setResultMid(r.mid || null)}>
            {letter}
          </span>
        )
      })}
      {' '}
      <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
        {'\n    ...\n  '}
      </Link>
      {' '}
    </div>
  )

  // reference rows: CRR batting team ki row pe; ball-runs (current over)
  // HAMESHA row2 ki score-message me; row1 pe score-message div sirf
  // innings 2 me hota hai (needed/won msg — backend me nahi, missing-apis #23)
  const crrDiv = (
    <div>
      <span>
        {'\n                            CRR\n                            ' + crr + '\n                          '}
      </span>
      {' '}
    </div>
  )

  const scoreText = (batting) =>
    batting
      ? `\n                          ${score} (${overs})\n                        `
      : '\n                          0-0 (0.0)\n                        '

  const scorecardRows = (
    <>
      <div className="scorecard-row">
        <div className="score-top-row">
          <div className="score-team">
            <b>{team1}</b>
            {scoreText(innings === 1)}
          </div>
          {' '}
          {innings === 1 ? crrDiv : <div>{' '}</div>}
          {' '}
        </div>
      </div>
      {' '}
      <div className="scorecard-row">
        <div className="score-top-row">
          <div className="score-team">
            <b>{team2}</b>
            {scoreText(innings === 2)}
          </div>
          {' '}
          {innings === 2 ? crrDiv : <div>{' '}</div>}
          {' '}
          <div className="score-message">
            {ballValues.map((v, i) => (
              <span key={i} className="ball-runs mr-1">{v}</span>
            ))}
          </div>
        </div>
      </div>
    </>
  )

  return (
    <>
      <div className="center-main-container">
        <div className="center-content">
          <div className="casino-container">
            <div className="casino-table five-cricket super-over detail-page-container">

              <div className="game-header">
                <span className="game-header-name">{GAME_NAME}</span>
                {' '}
                <span className="float-right game-header-date">Round ID: {gmid}</span>
              </div>
              {' '}
              <div className="container-fluid container-fluid-5">
                <div className="row row5">
                  <div className="col-xl-2 banner d-flex align-items-center mb-1">
                    <div className="scorecard">
                      {scorecardRows}
                    </div>
                  </div>
                  {' '}
                  <div className="col-xl-10">
                    <div className="casino-video mt-0">
                      <div className="video-box-container">
                        <div className="video-box">
                          {streamUrl && <iframe src={streamUrl}></iframe>}
                        </div>
                      </div>
                      {' '}
                      <div className={`casino-video-cards${hideBalls || stripCollapsed ? ' hide-cards' : ''}`}>
                        <div className="casino-cards-shuffle" role="button" style={{ cursor: 'pointer' }} onClick={toggleStrip}>
                          <i className="fas fa-grip-lines-vertical"></i>
                        </div>
                        {' '}
                        <SuperOverBalls cardString={card} />
                      </div>
                      {' '}
                      <CircularTimer timeLeft={lt} fullTime={ft} />
                      {' '}
                      <div className="casino-video-right-icons">
                        <div title="Home" className="casino-video-home-icon">
                          <Link to="/admin/casino/list" className="" style={{ color: 'var(--text-highlight)' }}>
                            <i className="fas fa-home"></i>
                          </Link>
                        </div>
                        {' '}
                        <div title="Rules" className="casino-video-rules-icon" onClick={() => setShowRules((v) => !v)}>
                          <i className="fas fa-info-circle"></i>
                        </div>
                        {' '}
                        <div title="Last Results" className="casino-video-lr-icon" onClick={() => setShowLr((v) => !v)}>
                          <i className={`fas ${showLr ? 'fa-chevron-circle-up' : 'fa-chevron-circle-down'}`}></i>
                        </div>
                      </div>
                      {' '}
                      <div>{showRules && (
                        <div
                          id="casino-vieo-rules"
                          aria-modal="true"
                          className="casino-vieo-rules show d-none-small show-rules"
                          style={{ display: 'block' }}
                        >
                          <div className="rules-header">
                            <div>Rules</div>
                            {' '}
                            <i className="fas fa-times" onClick={() => setShowRules(false)}></i>
                          </div>
                          {' '}
                          <div className="rules-body">
                            <CasinoRulesSwitch gameType={GAME_TYPE} />
                          </div>
                        </div>
                      )}</div>
                      {' '}
                      {!isMobile && resultsStrip}
                    </div>
                  </div>
                </div>
              </div>
              {' '}
              <div className="market-container">
                {t2.length > 0 && (
                  <SuperOverMarkets markets={t2} onBet={() => {}} exposures={exposures} bookRatio referenceFancy1 firstTeam={fancy1ColourTeam} />
                )}
              </div>
              {' '}
              {isMobile && resultsStrip}

            </div>
          </div>
        </div>
        {' '}
        <div data-simplebar="init" className={`right-sidebar${stickyClass}`}>
          <div className="simplebar-wrapper" style={{ margin: '0px' }}>
          <div className="simplebar-height-auto-observer-wrapper"><div className="simplebar-height-auto-observer"></div></div>
          <div className="simplebar-mask">
          <div className="simplebar-offset" style={{ right: '0px', bottom: '0px' }}>
          <div className="simplebar-content-wrapper" tabIndex="0" role="region" aria-label="scrollable content" style={{ height: 'auto', overflow: 'hidden' }}>
          <div className="simplebar-content" style={{ padding: '0px' }}>
          <div id="my-game-bets" className="card m-b-10 my-bet">
            <div className="card-header">
              <h6 className="card-title float-left">My Bets</h6>
              {' '}
              <a href="javascript:void(0)" className="btn btn-back float-right">View More</a>
            </div>
            {' '}
            <div className="card-body1">
              <div className="tab-content">
                <div id="matched-bet" className="tab-pane active">
                  <div className="table-responsive1">
                    <table className="table coupon-table mb-0">
                      <thead>
                        <tr>
                          <th style={{ minWidth: '90px' }}>UserName</th>
                          <th style={{ minWidth: '90px' }}>Nation</th>
                          <th className="text-right" style={{ minWidth: '50px' }}>Rate</th>
                          <th className="text-right" style={{ minWidth: '70px' }}>
                            {'\n                        Amount\n                      '}
                          </th>
                        </tr>
                      </thead>
                      {/* Reference: every bet is its own block — a header row with the
                          market name + bet time, then the bet; newest bet first. A session
                          bet reads "1 over run IND / 84" with its line (8) as the rate. */}
                      {myBetsSorted.map((bet, i) => {
                        const sel = String(bet.selection || bet.player_name || '').trim()
                        const market = marketOfBet(sel)
                        const sm = sel.match(SESSION_RE)
                        const nation = sm ? `${sm[1]} / ${Math.round(((parseFloat(bet.odds) || 0) - 1) * 100)}` : sel
                        const rate = sm ? sm[2] : formatStake(bet.odds ?? bet.rate)
                        const cls = String(bet.game_type || bet.type || '').toLowerCase() === 'lay' ? 'lay-border' : 'back-border'
                        return (
                          <tbody key={bet.id || bet._id || i}>
                            <tr className={cls}>
                              <td colSpan={2}><b>{market}</b></td>
                              <td colSpan={2} className="text-right">{betTime(bet.created_at)}</td>
                            </tr>
                            <tr className={cls}>
                              <td>{bet.username || bet.user_name || bet.user_id || ''}</td>
                              <td>{nation}</td>
                              <td className="text-right">{rate}</td>
                              <td className="text-right">{formatStake(bet.amount ?? bet.stake)}</td>
                            </tr>
                          </tbody>
                        )
                      })}
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          </div>
          </div>
          </div>
          </div>
          <div className="simplebar-placeholder" style={{ width: 'auto', height: '84px' }}></div>
          </div>
          <div className="simplebar-track simplebar-horizontal" style={{ visibility: 'hidden' }}><div className="simplebar-scrollbar" style={{ width: '0px', display: 'none' }}></div></div>
          <div className="simplebar-track simplebar-vertical" style={{ visibility: 'hidden' }}><div className="simplebar-scrollbar" style={{ height: '0px', display: 'none' }}></div></div>
        </div>
        {' '}
        <div className="market-show-icon d-none-desktop">
          <div className="bet-cnt">
            {'\n        ' + Math.min(myBets.length, 10) + '\n      '}
          </div>
          {' '}
          <div className="bet-title">Bets</div>
        </div>
      </div>

      <CasinoRulesModal
        show={showRules}
        onClose={() => setShowRules(false)}
        tableClass=""
        gameType={GAME_TYPE}
      >
        <CasinoRulesSwitch gameType={GAME_TYPE} />
      </CasinoRulesModal>

      <CasinoResultModal
        show={!!resultMid}
        onClose={() => setResultMid(null)}
        gameType={GAME_TYPE}
        gameName={GAME_NAME}
        mid={resultMid}
      />
    </>
  )
}
