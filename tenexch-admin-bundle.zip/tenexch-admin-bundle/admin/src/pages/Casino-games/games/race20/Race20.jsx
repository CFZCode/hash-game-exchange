import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { CircularTimer } from '../../../../components/casino/CasinoTimer'
import BetTableRace20 from '../../../../components/casino/BetTableRace20'
import Race20Cards from '../../../../components/casino/cards/Race20Cards'
import CasinoMyBetsSidebar from '../../../../components/casino/CasinoMyBetsSidebar'
import CasinoResultModal from '../../../../components/casino/CasinoResultModal'
import CasinoRulesModal from '../../../../components/casino/CasinoRulesModal'
import CasinoRulesSwitch from '../../../../components/casino/rules/CasinoRulesSwitch'
import useCasinoGame from '../../../../hooks/casino/useCasinoGame'
import useCasinoLastResults from '../../../../hooks/casino/useCasinoLastResults'
import useCasinoMyBets from '../../../../hooks/casino/useCasinoMyBets'
import useCasinoStream from '../../../../hooks/casino/useCasinoStream'
import { computeAdminBook, computeLineTotalsBook, getMarketsForGame } from '../../../../utils/casinoBook'
import { parseCards } from '../../../../components/casino/cards/cardUtils'
import { formatRace20Nation, formatRace20Odds, formatStake } from '../../../../utils/casinoUtils'

const GAME_TYPE = 'race20'
const RACE20_LINE_TOTALS = [
  { name: 'Total points', re: /^Total points (\d+)$/i },
  { name: 'Total cards', re: /^Total cards (\d+)$/i },
]
const GAME_NAME = 'Race 20'
const CDN = 'https://wver.sprintstaticdata.com/v230/static/front/img/cards'

// strip: win suit -> img + class. 1 spade(resulta) 2 heart(resultb) 3 club 4 diamond
const SUIT_ICONS = { 1: `${CDN}/spade.png`, 2: `${CDN}/heart.png`, 3: `${CDN}/club.png`, 4: `${CDN}/diamond.png` }
const SUIT_CLASS = { 1: 'resulta', 2: 'resultb', 3: '', 4: '' }

// Race20 point value, as the reference sums it: A=1, 2-10=face, J=11, Q=12
// (K is never dealt — the Ks are the horses).
const FACE_POINTS = { A: 1, J: 11, Q: 12, K: 13 }
function cardPoint(code) {
  if (!code || code === '1' || code === '0') return 0
  const rank = String(code).replace(/(CC|DD|HH|SS)$/i, '').toUpperCase()
  if (FACE_POINTS[rank]) return FACE_POINTS[rank]
  const n = Number(rank)
  return Number.isNaN(n) ? 0 : n
}

// Race 20 — route+API race20. Table class race20. Video: total-points in title
// (web only) + 4 suit-row card overlay (Race20Cards). Detail: BetTableRace20
// (K-of-suit boxes + Total points/cards Yes-No + Win-with fancy). Rules icon.
// Strip = winning suit img. Dual-strip (web video / mobile detail).
export default function Race20() {
  const isAuth = useSelector((s) => Boolean(s.auth.token))
  const [resultMid, setResultMid] = useState(null)
  const [showRules, setShowRules] = useState(false)
  const [showLr, setShowLr] = useState(true)
  const [showCards, setShowCards] = useState(true)
  const [isMobile, setIsMobile] = useState(() => typeof window !== 'undefined' && window.innerWidth < 768)
  // Reference IS_MOBILE is < 1280: the Total Card / Total Point box in the video
  // title only shows from 1280 up (below that BetTableRace20 prints a text line).
  const [isWide, setIsWide] = useState(() => typeof window !== 'undefined' && window.innerWidth >= 1280)

  useEffect(() => {
    const onResize = () => { setIsMobile(window.innerWidth < 768); setIsWide(window.innerWidth >= 1280) }
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  const { data: gameData } = useCasinoGame(GAME_TYPE)
  const { data: lastResults = [], refetch: refetchLastResults } = useCasinoLastResults(GAME_TYPE)
  const { streamUrl } = useCasinoStream(GAME_TYPE)
  const { myBets } = useCasinoMyBets(GAME_TYPE, isAuth)

  const mid = gameData?.mid ?? ''
  const lt = gameData?.lt ?? 0
  const ft = gameData?.ft ?? 40
  const card = gameData?.card ?? ''

  // Total points / Total cards bets carry their line ("Total points 83"), so
  // computeAdminBook can't match them to a feed name — book them separately.
  const exposures = {
    ...computeAdminBook(myBets, getMarketsForGame(GAME_TYPE, gameData)),
    ...computeLineTotalsBook(myBets, RACE20_LINE_TOTALS),
  }

  // Reference: the card panel exists only once there is a card string, and stays
  // collapsed (just the handle) until the first card is dealt ("1" = none yet);
  // the handle does nothing before that.
  const firstCard = parseCards(card)[0]
  const noCardYet = firstCard === '1'

  const { totalCards, totalPoints } = useMemo(() => {
    const dealt = parseCards(card).filter((c) => c && c !== '1' && c !== '0')
    return { totalCards: dealt.length, totalPoints: dealt.reduce((s, c) => s + cardPoint(c), 0) }
  }, [card])

  useEffect(() => {
    if (mid) refetchLastResults()
  }, [mid, refetchLastResults])

  const renderResult = (r, i) => {
    const win = String(r.win)
    return (
      <span key={i} className={SUIT_CLASS[win] ?? ''} onClick={() => setResultMid(r.mid || null)}>
        {['1', '2', '3', '4'].map((s) => (s === win ? <img key={s} src={SUIT_ICONS[s]} /> : null))}
      </span>
    )
  }

  const resultsStrip = (
    <div className={`casino-video-last-results${showLr ? '' : ' hide-lr'}`}>
      {lastResults.map(renderResult)}
      {' '}
      <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
        {'\n    ...\n  '}
      </Link>
      {' '}
    </div>
  )

  return (
    <>
      <div className="center-main-container">
        <div className="center-content">
          <div className="casino-container">
            <div className="casino-table race20">

              <div className="casino-video">
                <div className="casino-video-title">
                  <span className="casino-name">{GAME_NAME}</span>
                  {' '}
                  <div className="casino-video-rid">Round ID: {mid}</div>
                  {' '}
                  {/* >= 1280: total-points title me; below: detail me (BetTableRace20) */}
                  {isWide && (
                    <div className="total-points">
                      <div>
                        <div>Total Card:</div>
                        {' '}
                        <div>{totalCards}</div>
                      </div>
                      {' '}
                      <div>
                        <div>Total Point:</div>
                        {' '}
                        <div>{totalPoints}</div>
                      </div>
                    </div>
                  )}
                </div>
                {' '}
                <div className="video-box-container">
                  <div className="video-box">
                    {streamUrl && <iframe src={streamUrl}></iframe>}
                  </div>
                </div>
                {' '}
                {firstCard && (
                  <div className={`casino-video-cards${!showCards || noCardYet ? ' hide-cards' : ''}`}>
                    <div className="casino-cards-shuffle" onClick={() => { if (!noCardYet) setShowCards((v) => !v) }}>
                      <i className="fas fa-grip-lines-vertical"></i>
                    </div>
                    {' '}
                    <Race20Cards cardString={card} />
                  </div>
                )}
                {' '}
                <CircularTimer timeLeft={lt} fullTime={ft} />
                {' '}
                <div className="casino-video-right-icons">
                  <div title="Home" className="casino-video-home-icon">
                    <Link to="/admin/casino/list" className="" style={{ color: 'var(--text-highlight)' }}>
                      <i className="fas fa-home"></i>
                    </Link>
                  </div>
                  {' '}
                  <div title="Rules" className="casino-video-rules-icon" onClick={() => setShowRules((v) => !v)}>
                    <i className="fas fa-info-circle"></i>
                  </div>
                  {' '}
                  <div title="Last Results" className="casino-video-lr-icon" onClick={() => setShowLr((v) => !v)}>
                    <i className={`fas ${showLr ? 'fa-chevron-circle-up' : 'fa-chevron-circle-down'}`}></i>
                  </div>
                </div>
                {' '}
                <div>{showRules && (
                  <div
                    id="casino-vieo-rules"
                    aria-modal="true"
                    className="casino-vieo-rules show d-none-small show-rules"
                    style={{ display: 'block' }}
                  >
                    <div className="rules-header">
                      <div>Rules</div>
                      {' '}
                      <i className="fas fa-times" onClick={() => setShowRules(false)}></i>
                    </div>
                    {' '}
                    <div className="rules-body">
                      <CasinoRulesSwitch gameType={GAME_TYPE} />
                    </div>
                  </div>
                )}</div>
                {' '}
                {/* web: strip video ke andar */}
                {!isMobile && resultsStrip}
              </div>
              {' '}
              <div className="casino-detail">
                <BetTableRace20
                  gameData={gameData}
                  onBet={() => {}}
                  exposures={exposures}
                  totalCards={totalCards}
                  totalPoints={totalPoints}
                />
                {' '}
                {/* mobile: strip detail ke bottom me */}
                {isMobile && resultsStrip}
              </div>

            </div>
          </div>
        </div>
        {' '}
        <CasinoMyBetsSidebar
          myBets={myBets}
          gameName={GAME_TYPE}
          formatNation={formatRace20Nation}
          formatOdds={(bet) => formatRace20Odds(bet, formatStake(bet.odds ?? bet.rate))}
        />
      </div>

      <CasinoRulesModal
        show={showRules}
        onClose={() => setShowRules(false)}
        tableClass=""
        gameType={GAME_TYPE}
      >
        <CasinoRulesSwitch gameType={GAME_TYPE} />
      </CasinoRulesModal>

      <CasinoResultModal
        show={!!resultMid}
        onClose={() => setResultMid(null)}
        gameType={GAME_TYPE}
        gameName={GAME_NAME}
        mid={resultMid}
      />
    </>
  )
}
