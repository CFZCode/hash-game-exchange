import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { CircularTimer } from '../../../../components/casino/CasinoTimer'
import BetTablePoker20 from '../../../../components/casino/BetTablePoker20'
import CasinoMyBetsSidebar from '../../../../components/casino/CasinoMyBetsSidebar'
import CasinoResultModal from '../../../../components/casino/CasinoResultModal'
import CasinoRulesModal from '../../../../components/casino/CasinoRulesModal'
import CasinoRulesSwitch from '../../../../components/casino/rules/CasinoRulesSwitch'
import useCasinoGame from '../../../../hooks/casino/useCasinoGame'
import useCasinoLastResults from '../../../../hooks/casino/useCasinoLastResults'
import useCasinoMyBets from '../../../../hooks/casino/useCasinoMyBets'
import useCasinoStream from '../../../../hooks/casino/useCasinoStream'
import { computeAdminBook, getMarketsForGame } from '../../../../utils/casinoBook'
import { formatPoker20Nation } from '../../../../utils/casinoUtils'
import { cardSrc, parseCards } from '../../../../components/casino/cards/cardUtils'

const GAME_TYPE = 'poker20'
const GAME_NAME = '20-20 Poker'

// 20-20 Poker — route slug poker20, API poker20. Table poker20. Video: Player A
// (codes[0,1]), Player B (codes[2,3]), Board (codes[4-8]). Detail:
// BetTablePoker20 (Player A/B x 9 poker-hand markets). Strip A/B. Mobile strip
// casino-detail bottom (video wala d-none-small).
export default function Poker20() {
  const isAuth = useSelector((s) => Boolean(s.auth.token))
  const [resultMid, setResultMid] = useState(null)
  const [showRules, setShowRules] = useState(false)
  const [showLr, setShowLr] = useState(true)
  const [showCards, setShowCards] = useState(true)

  const { data: gameData } = useCasinoGame(GAME_TYPE)
  const { data: lastResults = [], refetch: refetchLastResults } = useCasinoLastResults(GAME_TYPE)
  const { streamUrl } = useCasinoStream(GAME_TYPE)
  const { myBets } = useCasinoMyBets(GAME_TYPE, isAuth)

  const mid = gameData?.mid ?? ''
  const lt = gameData?.lt ?? 0
  const ft = gameData?.ft ?? 30

  const exposures = computeAdminBook(myBets, getMarketsForGame(GAME_TYPE, gameData))

  const codes = parseCards(gameData?.card || '')
  // sab card face-down ('1'/'0') → overlay band (reference: hide-cards)
  const hasCards = codes.some((c) => c && c !== '1' && c !== '0')
  const cardA = [codes[0] || '1', codes[1] || '1']
  const cardB = [codes[2] || '1', codes[3] || '1']
  const board = [codes[4] || '1', codes[5] || '1', codes[6] || '1', codes[7] || '1', codes[8] || '1']

  useEffect(() => {
    if (mid) refetchLastResults()
  }, [mid, refetchLastResults])

  // win "0" = drawn round (the archiver adds it; the vendor list drops it):
  // an empty circle, as on the reference.
  // Plan: docs/plans/2026-10-12-poker-tie-full-refund-hidden.md
  const renderResult = (r, i) => {
    const w = String(r.win)
    if (w === '1') return <span key={i} className="resulta" onClick={() => setResultMid(r.mid || null)}>{'A '}</span>
    if (w === '2') return <span key={i} className="resultb" onClick={() => setResultMid(r.mid || null)}>{' B '}</span>
    return <span key={i} className="resulttie" onClick={() => setResultMid(r.mid || null)}></span>
  }

  const cardSpan = (code, i) => (
    <span key={i} data-v-b64efdfa=""><img data-v-b64efdfa="" src={cardSrc(code)} /></span>
  )

  return (
    <>
      <div className="center-main-container">
        <div className="center-content">
          <div className="casino-container">
            <div className="casino-table poker20">

              <div className="casino-video">
                <div className="casino-video-title">
                  <span className="casino-name">{GAME_NAME}</span>
                  {' '}
                  <div className="casino-video-rid">Round ID: {mid}</div>
                </div>
                {' '}
                <div className="video-box-container">
                  <div className="video-box">
                    {streamUrl && <iframe src={streamUrl}></iframe>}
                  </div>
                </div>
                {' '}
                <div className={`casino-video-cards${showCards && hasCards ? '' : ' hide-cards'}`}>
                  <div className="casino-cards-shuffle" onClick={() => setShowCards((v) => !v)}>
                    <i className="fas fa-grip-lines-vertical"></i>
                  </div>
                  {' '}
                  <div className="casino-video-cards-container">
                    <div className="playeracards">
                      <div className="dealer-name w-100 mb-1">Player A</div>
                      {' '}
                      <div className="d-flex">{cardA.map(cardSpan)}</div>
                    </div>
                    {' '}
                    <div className="playerbcards">
                      <div className="dealer-name w-100 mb-1">Player B</div>
                      {' '}
                      <div className="d-flex">{cardB.map(cardSpan)}</div>
                    </div>
                    {' '}
                    <div className="playerboardcards">
                      <div className="dealer-name w-100 mb-1">Board</div>
                      {' '}
                      <div className="d-flex">{board.map(cardSpan)}</div>
                    </div>
                  </div>
                </div>
                {' '}
                <CircularTimer timeLeft={lt} fullTime={ft} />
                {' '}
                <div className="casino-video-right-icons">
                  <div title="Home" className="casino-video-home-icon">
                    <Link to="/admin/casino/list" className="" style={{ color: 'var(--text-highlight)' }}>
                      <i className="fas fa-home"></i>
                    </Link>
                  </div>
                  {' '}
                  <div title="Rules" className="casino-video-rules-icon" onClick={() => setShowRules((v) => !v)}>
                    <i className="fas fa-info-circle"></i>
                  </div>
                  {' '}
                  <div title="Last Results" className="casino-video-lr-icon" onClick={() => setShowLr((v) => !v)}>
                    <i className={`fas ${showLr ? 'fa-chevron-circle-up' : 'fa-chevron-circle-down'}`}></i>
                  </div>
                </div>
                {' '}
                <div>{showRules && (
                  <div
                    id="casino-vieo-rules"
                    aria-modal="true"
                    className="casino-vieo-rules show d-none-small show-rules"
                    style={{ display: 'block' }}
                  >
                    <div className="rules-header">
                      <div>Rules</div>
                      {' '}
                      <i className="fas fa-times" onClick={() => setShowRules(false)}></i>
                    </div>
                    {' '}
                    <div className="rules-body">
                      <CasinoRulesSwitch gameType={GAME_TYPE} />
                    </div>
                  </div>
                )}</div>
                {' '}
                {/* web: strip video me (mobile pe hidden) */}
                <div className={`casino-video-last-results d-none-small${showLr ? '' : ' hide-lr'}`}>
                  {lastResults.map(renderResult)}
                  {' '}
                  <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
                    {'\n    ...\n  '}
                  </Link>
                  {' '}
                </div>
              </div>
              {' '}
              <div className="casino-detail">
                <BetTablePoker20
                  gameData={gameData}
                  onBet={() => {}}
                  exposures={exposures}
                />
                {' '}
                {/* mobile: strip casino-detail ke bottom me (video wala d-none-small) */}
                <div className="casino-video-last-results d-none-desktop">
                  {lastResults.map(renderResult)}
                  {' '}
                  <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
                    {'\n    ...\n  '}
                  </Link>
                </div>
              </div>

            </div>
          </div>
        </div>
        {' '}
        {/* Winner row stored "Player A/B" reads "Winner A/B" like the reference */}
        <CasinoMyBetsSidebar myBets={myBets} gameName={GAME_TYPE} formatNation={(n) => formatPoker20Nation(n)} />
      </div>

      <CasinoRulesModal
        show={showRules}
        onClose={() => setShowRules(false)}
        tableClass=""
        gameType={GAME_TYPE}
      >
        <CasinoRulesSwitch gameType={GAME_TYPE} />
      </CasinoRulesModal>

      <CasinoResultModal
        show={!!resultMid}
        onClose={() => setResultMid(null)}
        gameType={GAME_TYPE}
        gameName={GAME_NAME}
        mid={resultMid}
      />
    </>
  )
}
