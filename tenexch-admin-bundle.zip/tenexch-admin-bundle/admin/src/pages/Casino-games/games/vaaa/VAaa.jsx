import BetTableVAaa from '../../../../components/casino/BetTableVAaa'
import VCasinoTable from '../../../../components/casino/VCasinoTable'
import { computeAdminBook, getMarketsForGame } from '../../../../utils/casinoBook'
import { cardSrc } from '../../../../components/casino/cards/cardUtils'

const GAME_TYPE = 'vaaa'
const GAME_NAME = 'V-Amar Akbar Anthony'

// last-results `win` = winning sid: 1 Amar (A), 2 Akbar (B), 3 Anthony (C) —
// same rule as the non-virtual aaa page; capture strip C A B A A B A C A B.
const RESULT_BY_WIN = {
  1: { cls: 'resulta', text: 'A' },
  2: { cls: 'resultb', text: 'B' },
  3: { cls: 'resultc', text: 'C' },
}

// Overlay: one card, `.text-center.w-100 > span > img` (face-down = 1.png,
// reference shows it, no hide-cards on virtual tables).
const renderCards = (gameData) => (
  <div className="text-center w-100">
    <span data-v-b64efdfa="">
      <img data-v-b64efdfa="" src={cardSrc(String(gameData?.card || '').split(',')[0])} />
    </span>
  </div>
)

const renderResult = (r, i, onClick) => {
  const res = RESULT_BY_WIN[Number(r.win)] || RESULT_BY_WIN[3]
  return <span key={i} className={res.cls} onClick={onClick}>{res.text}</span>
}

// V-Amar Akbar Anthony — /admin/vcasino/aaa. Reference DOM (capture
// 2026-09-19): shell VCasinoTable (.casino-table.vcasino.vaaa), board
// BetTableVAaa. Book: getMarketsForGame — subtype vaaa is etype match (one
// exclusive market A/B/C), vaaafancy is etype fancy (single-selection
// markets), which is exactly this board's structure.
export default function VAaa() {
  return (
    <VCasinoTable
      gameType={GAME_TYPE}
      gameName={GAME_NAME}
      tableClass="vaaa"
      cards={renderCards}
      renderResult={renderResult}
    >
      {(gameData, myBets) => (
        <BetTableVAaa
          gameData={gameData}
          exposures={computeAdminBook(myBets, getMarketsForGame(GAME_TYPE, gameData))}
        />
      )}
    </VCasinoTable>
  )
}
