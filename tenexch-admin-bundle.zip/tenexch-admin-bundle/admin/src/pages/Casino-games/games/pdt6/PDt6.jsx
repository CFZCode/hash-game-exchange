import { DragonTigerOneDayBase } from '../dragontigeroneday/DragonTigerOneDay'

// Premium 1 Day Dragon Tiger — /admin/pcasino/pdt6 (Premium Casino list).
// Reference DOM (capture tenexch.com-admin-pcasino-pdt6, 2026-09-19) = the dt6
// page: .casino-table.dt1day, iframe stream, 2-card overlay with hide-cards
// while face-down, circular timer, Home / Rules / Last Results, BetTableDT6
// (Dragon / Tiger back+lay R:1K-2L, Pair R:1K-20K, per-side Even/Odd/Red/Black/
// suits R:1K-50K — all from the feed), strip D / T, sidebar My Bets only. Feed
// pdt6 = dt6's 19 rows (verified live). Type, title and Home link differ.
export default function PDt6() {
  return <DragonTigerOneDayBase gameType="pdt6" gameName="Premium 1 Day Dragon Tiger" homePath="/admin/pcasino/list" />
}
