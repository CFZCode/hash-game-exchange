import { Fragment } from 'react'
import BetTableVDt6 from '../../../../components/casino/BetTableVDt6'
import VCasinoTable from '../../../../components/casino/VCasinoTable'
import { computeAdminBook, getMarketsForGame } from '../../../../utils/casinoBook'
import { cardSrc } from '../../../../components/casino/cards/cardUtils'

const GAME_TYPE = 'vdt6'
const GAME_NAME = 'V-1 Day Dragon Tiger'

// Overlay: `.player-card.playera-card` Dragon (card[0]) / `.playerb-card`
// Tiger (card[1]); face-down = 1.png (capture: Dragon 10DD dealt, Tiger 1).
const PLAYERS = [
  { key: 'dragon', label: 'Dragon', cls: 'playera', idx: 0 },
  { key: 'tiger', label: 'Tiger', cls: 'playerb', idx: 1 },
]

const renderCards = (gameData) => {
  const cards = String(gameData?.card || '').split(',').map((c) => c.trim())
  return PLAYERS.map((p, pi) => (
    <Fragment key={p.key}>
      {pi > 0 && ' '}
      <div className={`player-card ${p.cls}-card`}>
      {' '}
      <div className={`w-100 ${p.cls} mb-2`}>{p.label}</div>
      {' '}
      <span data-v-b64efdfa="">
        <img data-v-b64efdfa="" src={cardSrc(cards[p.idx])} />
      </span>
    </div>
    </Fragment>
  ))
}

// last-results `win` 1 → "D " resulta, 2 → " T " resultb (capture strip
// D D T T T T D D T T); anything else → tie, as the non-virtual dt6 page.
const renderResult = (r, i, onClick) => {
  const w = String(r.win)
  if (w === '1') return <span key={i} className="resulta" onClick={onClick}>{'D '}</span>
  if (w === '2') return <span key={i} className="resultb" onClick={onClick}>{' T '}</span>
  return <span key={i} className="resulttie" onClick={onClick}>T</span>
}

// V-1 Day Dragon Tiger — /admin/vcasino/dt6. Reference DOM (capture
// 2026-09-19): shell VCasinoTable (.casino-table.vcasino.vdt1day), board
// BetTableVDt6, sidebar My Bets only. Book: getMarketsForGame (Dragon/Tiger
// etype match → one market with lay; fancy → single markets).
export default function VDt6() {
  return (
    <VCasinoTable
      gameType={GAME_TYPE}
      gameName={GAME_NAME}
      tableClass="vdt1day"
      cards={renderCards}
      renderResult={renderResult}
    >
      {(gameData, myBets) => (
        <BetTableVDt6
          gameData={gameData}
          exposures={computeAdminBook(myBets, getMarketsForGame(GAME_TYPE, gameData))}
        />
      )}
    </VCasinoTable>
  )
}
