import RoulettePage from '../../../../components/casino/RoulettePage'

export default function Roulette13() {
  return <RoulettePage gameType="roulette13" gameName="Roulette" />
}
