import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { CircularTimer } from '../../../../components/casino/CasinoTimer'
import BetTableTeenpatti2Cards from '../../../../components/casino/BetTableTeenpatti2Cards'
import CasinoMyBetsSidebar from '../../../../components/casino/CasinoMyBetsSidebar'
import { formatPatti2Nation, formatPatti2Odds, formatStake } from '../../../../utils/casinoUtils'
import CasinoResultModal from '../../../../components/casino/CasinoResultModal'
import CasinoRulesModal from '../../../../components/casino/CasinoRulesModal'
import CasinoRulesSwitch from '../../../../components/casino/rules/CasinoRulesSwitch'
import useCasinoGame from '../../../../hooks/casino/useCasinoGame'
import useCasinoLastResults from '../../../../hooks/casino/useCasinoLastResults'
import useCasinoMyBets from '../../../../hooks/casino/useCasinoMyBets'
import useCasinoStream from '../../../../hooks/casino/useCasinoStream'
import { computeAdminBook, getMarketsForGame } from '../../../../utils/casinoBook'
import { cardSrc, parseCards } from '../../../../components/casino/cards/cardUtils'

// route slug teenpatti2cards, par API type patti2 (bollywoodtable→btable pattern)
const GAME_TYPE = 'patti2'
const GAME_NAME = '2 Cards Teenpatti'
const REMARK_ICON = 'https://wver.sprintstaticdata.com/v230/static/front/img/icons/remark.png'

// static Color Plus Rules card (sidebar)
const COLOR_PLUS_RULES = [
  ['Three card Sequence', '1 TO 3'],
  ['Four card color', '1 TO 9'],
  ['Four card Sequence', '1 TO 9'],
  ['Three of a kind', '1 TO 12'],
  ['Three card pure Sequence', '1 TO 15'],
  ['Four card pure Sequence', '1 TO 150'],
  ['Four of a kind', '1 TO 200'],
]

// 2 Cards Teenpatti — table class teenpatti2cards. Video: 2x2 card overlay
// (row1 = Player A ke 2 cards, row2 = Player B ke 2). Detail: BetTableTeenpatti2Cards
// (Player A/B, Mini Baccarat A/B, Total A/B, Color Plus) + remark. Sidebar:
// my-bets + Color Plus Rules card. Strip resulta A / resultb B. Dual-strip.
export default function Teenpatti2Cards() {
  const isAuth = useSelector((s) => Boolean(s.auth.token))
  const [resultMid, setResultMid] = useState(null)
  const [showRules, setShowRules] = useState(false)
  const [showLr, setShowLr] = useState(true)
  const [showCards, setShowCards] = useState(true)
  const [isMobile, setIsMobile] = useState(() => typeof window !== 'undefined' && window.innerWidth < 768)

  useEffect(() => {
    const onResize = () => setIsMobile(window.innerWidth < 768)
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  const { data: gameData } = useCasinoGame(GAME_TYPE)
  const { data: lastResults = [], refetch: refetchLastResults } = useCasinoLastResults(GAME_TYPE)
  const { streamUrl } = useCasinoStream(GAME_TYPE)
  const { myBets } = useCasinoMyBets(GAME_TYPE, isAuth)

  const mid = gameData?.mid ?? ''
  const lt = gameData?.lt ?? 0
  const ft = gameData?.ft ?? 35
  const card = gameData?.card ?? ''
  const remark = gameData?.remark ?? ''

  const exposures = computeAdminBook(myBets, getMarketsForGame(GAME_TYPE, gameData))
  // "Total A" / "Total B" bets are stored WITH the line ("Total A 15" back =
  // total ≥ 15, "Total A 14" lay = total < 14), so computeAdminBook found no
  // market for them and the cell stayed empty. Show the admin's worst P/L over
  // every possible total under the bare name the table reads.
  ;['Total A', 'Total B'].forEach((name) => {
    const legs = []
    myBets.forEach((b) => {
      const m = String(b.selection || '').trim().match(/^Total ([AB]) (\d+)$/i)
      if (!m || `Total ${m[1].toUpperCase()}` !== name) return
      const odds = parseFloat(b.odds) || 0
      const stake = parseFloat(b.amount ?? b.stake) || 0
      if (!odds || !stake) return
      legs.push({ line: Number(m[2]), lay: String(b.game_type || b.type || '').toLowerCase() === 'lay', odds, stake })
    })
    if (!legs.length) return
    let worst = Infinity
    for (let t = 0; t <= 60; t += 1) {
      const userPl = legs.reduce((sum, l) => {
        // Yes wins at total >= its line, No only BELOW its line (14 loses both)
        const wins = l.lay ? t < l.line : t >= l.line
        if (l.lay) return sum + (wins ? l.stake : -(l.odds - 1) * l.stake)
        return sum + (wins ? (l.odds - 1) * l.stake : -l.stake)
      }, 0)
      worst = Math.min(worst, -userPl)
    }
    exposures[name] = worst
  })

  const codes = parseCards(card)
  const cc = [codes[0] || '1', codes[1] || '1', codes[2] || '1', codes[3] || '1']
  const hasCards = cc.some((c) => c && c !== '1')

  useEffect(() => {
    if (mid) refetchLastResults()
  }, [mid, refetchLastResults])

  const renderResult = (r, i) => {
    const w = String(r.win)
    const on = () => setResultMid(r.mid || null)
    if (w === '1') return <span key={i} className="resulta" onClick={on}>A</span>
    return <span key={i} className="resultb" onClick={on}>B</span>
  }

  const resultsStrip = (
    <div className={`casino-video-last-results${showLr ? '' : ' hide-lr'}`}>
      {lastResults.map(renderResult)}
      {' '}
      <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
        {'\n    ...\n  '}
      </Link>
      {' '}
    </div>
  )

  const cardCol = (c) => (
    <span data-v-b64efdfa=""><img data-v-b64efdfa="" src={cardSrc(c)} /></span>
  )

  const rulesCard = (
    <div className="card m-b-10">
      <div className="card-header">
        <h6 className="card-title d-inline-block">{'\n          Rules\n          '}</h6>
      </div>
      {' '}
      <div className="card-body" style={{ padding: '10px' }}>
        <table className="table table-bordered rules-table">
          <tbody>
            <tr className="text-center"><th colSpan="2">Color Plus Rules</th></tr>
            {COLOR_PLUS_RULES.map(([name, val]) => (
              <tr key={name}>
                <td width="60%">{name}</td><td>{val}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )

  return (
    <>
      <div className="center-main-container">
        <div className="center-content">
          <div className="casino-container">
            <div className="casino-table teenpatti2cards">

              <div className="casino-video">
                <div className="casino-video-title">
                  <span className="casino-name">{GAME_NAME}</span>
                  {' '}
                  <div className="casino-video-rid">Round ID: {mid}</div>
                </div>
                {' '}
                <div className="video-box-container">
                  <div className="video-box">
                    {streamUrl && <iframe src={streamUrl}></iframe>}
                  </div>
                </div>
                {' '}
                <div className={`casino-video-cards${showCards && hasCards ? '' : ' hide-cards'}`}>
                  <div className="casino-cards-shuffle" onClick={() => setShowCards((v) => !v)}>
                    <i className="fas fa-grip-lines-vertical"></i>
                  </div>
                  {' '}
                  <div className="casino-video-cards-container">
                    {/* teenpatti interleaved: Player A = codes[0,2], Player B = codes[1,3] */}
                    <div>{cardCol(cc[0])} {cardCol(cc[2])}</div>
                    {' '}
                    <div>{cardCol(cc[1])} {cardCol(cc[3])}</div>
                  </div>
                </div>
                {' '}
                <CircularTimer timeLeft={lt} fullTime={ft} />
                {' '}
                <div className="casino-video-right-icons">
                  <div title="Home" className="casino-video-home-icon">
                    <Link to="/admin/casino/list" className="" style={{ color: 'var(--text-highlight)' }}>
                      <i className="fas fa-home"></i>
                    </Link>
                  </div>
                  {' '}
                  <div title="Rules" className="casino-video-rules-icon" onClick={() => setShowRules((v) => !v)}>
                    <i className="fas fa-info-circle"></i>
                  </div>
                  {' '}
                  <div title="Last Results" className="casino-video-lr-icon" onClick={() => setShowLr((v) => !v)}>
                    <i className={`fas ${showLr ? 'fa-chevron-circle-up' : 'fa-chevron-circle-down'}`}></i>
                  </div>
                </div>
                {' '}
                <div>{showRules && (
                  <div
                    id="casino-vieo-rules"
                    aria-modal="true"
                    className="casino-vieo-rules show d-none-small show-rules"
                    style={{ display: 'block' }}
                  >
                    <div className="rules-header">
                      <div>Rules</div>
                      {' '}
                      <i className="fas fa-times" onClick={() => setShowRules(false)}></i>
                    </div>
                    {' '}
                    <div className="rules-body">
                      <CasinoRulesSwitch gameType={GAME_TYPE} />
                    </div>
                  </div>
                )}</div>
                {' '}
                {/* web: strip video ke andar */}
                {!isMobile && resultsStrip}
              </div>
              {' '}
              <div className="casino-detail">
                <BetTableTeenpatti2Cards
                  gameData={gameData}
                  onBet={() => {}}
                  exposures={exposures}
                />
                {' '}
                <div className="casino-remark mt-3">
                  <div className="remark-icon"><img src={REMARK_ICON} /></div>
                  {' '}
                  <marquee>{remark}</marquee>
                </div>
                {' '}
                {/* mobile: strip detail ke bottom me */}
                {isMobile && resultsStrip}
              </div>

            </div>
          </div>
        </div>
        {' '}
        <CasinoMyBetsSidebar myBets={myBets} gameName={GAME_TYPE} extra={rulesCard} formatNation={formatPatti2Nation} formatOdds={(bet) => formatPatti2Odds(bet, formatStake(bet.odds ?? bet.rate))} />
      </div>

      <CasinoRulesModal
        show={showRules}
        onClose={() => setShowRules(false)}
        tableClass=""
        gameType={GAME_TYPE}
      >
        <CasinoRulesSwitch gameType={GAME_TYPE} />
      </CasinoRulesModal>

      <CasinoResultModal
        show={!!resultMid}
        onClose={() => setResultMid(null)}
        gameType={GAME_TYPE}
        gameName={GAME_NAME}
        mid={resultMid}
      />
    </>
  )
}
