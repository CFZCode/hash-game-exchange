import PoisonPage from '../../../../components/casino/PoisonPage'

export default function Poison20() {
  return (
    <PoisonPage
      gameType="poison20"
      gameName="Teenpatti Poison 20-20"
      stripInVideo
    />
  )
}
