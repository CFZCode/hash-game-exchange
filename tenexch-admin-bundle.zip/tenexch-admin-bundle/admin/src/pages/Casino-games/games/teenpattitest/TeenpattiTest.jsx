import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { CircularTimer } from '../../../../components/casino/CasinoTimer'
import BetTableTeenpattiTest from '../../../../components/casino/BetTableTeenpattiTest'
import CasinoMyBetsSidebar from '../../../../components/casino/CasinoMyBetsSidebar'
import CasinoResultModal from '../../../../components/casino/CasinoResultModal'
import CasinoRulesModal from '../../../../components/casino/CasinoRulesModal'
import CasinoRulesSwitch from '../../../../components/casino/rules/CasinoRulesSwitch'
import useCasinoGame from '../../../../hooks/casino/useCasinoGame'
import useCasinoLastResults from '../../../../hooks/casino/useCasinoLastResults'
import useCasinoMyBets from '../../../../hooks/casino/useCasinoMyBets'
import useCasinoStream from '../../../../hooks/casino/useCasinoStream'
import { computeAdminBook, getMarketsForGame } from '../../../../utils/casinoBook'
import { cardSrc } from '../../../../components/casino/cards/cardUtils'

const GAME_TYPE = 'teen9'
const GAME_NAME = 'Teenpatti Test'

// Teenpatti Test — route slug teenpattitest, API type teen9. Table teenpattitest.
// 3 dealer (Tiger/Lion/Dragon) x 6 bets (Winner/Pair/Flush/Straight/Trio/Straight
// Flush) — BetTableTeenpattiTest (desktop teentestother + mobile teen1dayodev).
// Cards round-robin: Tiger=0,3,6 / Lion=1,4,7 / Dragon=2,5,8 (facedown '1'), har
// dealer pe dealer-name label. Strip T/L/D/Tie. Koi remark nahi. Mobile strip
// casino-detail bottom (video wala d-none-small).
export default function TeenpattiTest() {
  const isAuth = useSelector((s) => Boolean(s.auth.token))
  const [resultMid, setResultMid] = useState(null)
  const [showRules, setShowRules] = useState(false)
  const [showLr, setShowLr] = useState(true)
  const [showCards, setShowCards] = useState(true)

  const { data: gameData } = useCasinoGame(GAME_TYPE)
  const { data: lastResults = [], refetch: refetchLastResults } = useCasinoLastResults(GAME_TYPE)
  const { streamUrl } = useCasinoStream(GAME_TYPE)
  const { myBets } = useCasinoMyBets(GAME_TYPE, isAuth)

  const mid = gameData?.mid ?? ''
  const lt = gameData?.lt ?? 0
  const ft = gameData?.ft ?? 35

  const exposures = computeAdminBook(myBets, getMarketsForGame(GAME_TYPE, gameData))

  const cards = String(gameData?.card || '').split(',').map((c) => c.trim())
  // betting window me sab '1' (face-down) → overlay band (reference: hide-cards)
  const hasCards = cards.some((c) => c && c !== '1' && c !== '0')
  const dealers = [
    { name: 'Tiger', cards: [cards[0], cards[3], cards[6]].map((c) => c || '1') },
    { name: 'Lion', cards: [cards[1], cards[4], cards[7]].map((c) => c || '1') },
    { name: 'Dragon', cards: [cards[2], cards[5], cards[8]].map((c) => c || '1') },
  ]

  useEffect(() => {
    if (mid) refetchLastResults()
  }, [mid, refetchLastResults])

  const renderResult = (r, i) => {
    const w = String(r.win)
    const on = () => setResultMid(r.mid || null)
    if (w === '1') return <span key={i} className="resulta" onClick={on}>{'T '}</span>
    if (w === '2') return <span key={i} className="resultb" onClick={on}>{' L '}</span>
    if (w === '3') return <span key={i} className="resultc" onClick={on}>{' D '}</span>
    return <span key={i} className="resulttie" onClick={on}>{' T'}</span>
  }

  return (
    <>
      <div className="center-main-container">
        <div className="center-content">
          <div className="casino-container">
            <div className="casino-table teenpattitest">

              <div className="casino-video">
                <div className="casino-video-title">
                  <span className="casino-name">{GAME_NAME}</span>
                  {' '}
                  <div className="casino-video-rid">Round ID: {mid}</div>
                </div>
                {' '}
                <div className="video-box-container">
                  <div className="video-box">
                    {streamUrl && <iframe src={streamUrl}></iframe>}
                  </div>
                </div>
                {' '}
                <div className={`casino-video-cards${showCards && hasCards ? '' : ' hide-cards'}`}>
                  <div className="casino-cards-shuffle" onClick={() => setShowCards((v) => !v)}>
                    <i className="fas fa-grip-lines-vertical"></i>
                  </div>
                  {' '}
                  <div className="casino-video-cards-container">
                    {dealers.map((d) => (
                      <div key={d.name}>
                        <div className="dealer-name w-100 mb-1">{d.name}</div>
                        {' '}
                        {d.cards.map((code, i) => (
                          <span key={i} data-v-b64efdfa="">
                            <img data-v-b64efdfa="" src={cardSrc(code)} />
                          </span>
                        ))}
                      </div>
                    ))}
                  </div>
                </div>
                {' '}
                <CircularTimer timeLeft={lt} fullTime={ft} />
                {' '}
                <div className="casino-video-right-icons">
                  <div title="Home" className="casino-video-home-icon">
                    <Link to="/admin/casino/list" className="" style={{ color: 'var(--text-highlight)' }}>
                      <i className="fas fa-home"></i>
                    </Link>
                  </div>
                  {' '}
                  <div title="Rules" className="casino-video-rules-icon" onClick={() => setShowRules((v) => !v)}>
                    <i className="fas fa-info-circle"></i>
                  </div>
                  {' '}
                  <div title="Last Results" className="casino-video-lr-icon" onClick={() => setShowLr((v) => !v)}>
                    <i className={`fas ${showLr ? 'fa-chevron-circle-up' : 'fa-chevron-circle-down'}`}></i>
                  </div>
                </div>
                {' '}
                <div>{showRules && (
                  <div
                    id="casino-vieo-rules"
                    aria-modal="true"
                    className="casino-vieo-rules show d-none-small show-rules"
                    style={{ display: 'block' }}
                  >
                    <div className="rules-header">
                      <div>Rules</div>
                      {' '}
                      <i className="fas fa-times" onClick={() => setShowRules(false)}></i>
                    </div>
                    {' '}
                    <div className="rules-body">
                      <CasinoRulesSwitch gameType={GAME_TYPE} />
                    </div>
                  </div>
                )}</div>
                {' '}
                {/* web: strip video me (mobile pe hidden) */}
                <div className={`casino-video-last-results d-none-small${showLr ? '' : ' hide-lr'}`}>
                  {lastResults.map(renderResult)}
                  {' '}
                  <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
                    {'\n    ...\n  '}
                  </Link>
                  {' '}
                </div>
              </div>
              {' '}
              <div className="casino-detail">
                <BetTableTeenpattiTest
                  gameData={gameData}
                  onBet={() => {}}
                  exposures={exposures}
                />
                {' '}
                {/* mobile: strip casino-detail ke bottom me (video wala d-none-small) */}
                <div className="casino-video-last-results d-none-desktop">
                  {lastResults.map(renderResult)}
                  {' '}
                  <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
                    {'\n    ...\n  '}
                  </Link>
                </div>
              </div>

            </div>
          </div>
        </div>
        {' '}
        <CasinoMyBetsSidebar myBets={myBets} gameName={GAME_TYPE} />
      </div>

      <CasinoRulesModal
        show={showRules}
        onClose={() => setShowRules(false)}
        tableClass=""
        gameType={GAME_TYPE}
      >
        <CasinoRulesSwitch gameType={GAME_TYPE} />
      </CasinoRulesModal>

      <CasinoResultModal
        show={!!resultMid}
        onClose={() => setResultMid(null)}
        gameType={GAME_TYPE}
        gameName={GAME_NAME}
        mid={resultMid}
      />
    </>
  )
}
