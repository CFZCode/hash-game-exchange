import { Fragment } from 'react'
import BetTableVTrio from '../../../../components/casino/BetTableVTrio'
import VCasinoTable from '../../../../components/casino/VCasinoTable'
import { computeAdminBook, getMarketsForGame } from '../../../../utils/casinoBook'
import { cardSrc } from '../../../../components/casino/cards/cardUtils'

const GAME_TYPE = 'vtrio'
const GAME_NAME = 'V-Trio'

// Overlay: `.vcasino-cards.w-100.text-center` holding three `span > img`
// (no player labels); face-down 1.png as the reference.
const renderCards = (gameData) => {
  const cards = String(gameData?.card || '').split(',').map((c) => c.trim())
  return [0, 1, 2].map((i) => (
    <Fragment key={i}>
      {i > 0 && ' '}
      <span data-v-b64efdfa="">
        <img data-v-b64efdfa="" src={cardSrc(cards[i])} />
      </span>
    </Fragment>
  ))
}

// last-results: multi-market game, `win` is always 0 — the strip prints a
// plain " R " per round (capture; same as the non-virtual trio page).
const renderResult = (r, i, onClick) => <span key={i} onClick={onClick}>{' R '}</span>

// V-Trio — /admin/vcasino/trio. Reference DOM (capture 2026-09-19): shell
// VCasinoTable (.casino-table.vcasino.vtrio), board BetTableVTrio, sidebar
// My Bets only. Book: getMarketsForGame (every selection Fancy* → its own market).
export default function VTrio() {
  return (
    <VCasinoTable
      gameType={GAME_TYPE}
      gameName={GAME_NAME}
      tableClass="vtrio"
      cards={renderCards}
      cardsClass="w-100 text-center"
      renderResult={renderResult}
    >
      {(gameData, myBets) => (
        <BetTableVTrio
          gameData={gameData}
          exposures={computeAdminBook(myBets, getMarketsForGame(GAME_TYPE, gameData))}
        />
      )}
    </VCasinoTable>
  )
}
