import { Fragment, useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { CircularTimer } from '../../../../components/casino/CasinoTimer'
import CasinoMyBetsSidebar from '../../../../components/casino/CasinoMyBetsSidebar'
import CasinoResultModal from '../../../../components/casino/CasinoResultModal'
import useCasinoGame from '../../../../hooks/casino/useCasinoGame'
import useCasinoLastResults from '../../../../hooks/casino/useCasinoLastResults'
import useCasinoMyBets from '../../../../hooks/casino/useCasinoMyBets'
import useCasinoStream from '../../../../hooks/casino/useCasinoStream'
import { computeAdminBook, getMarketsForGame, roundBook, fmtBook } from '../../../../utils/casinoBook'
import { cardSrc } from '../../../../components/casino/cards/cardUtils'

const GAME_TYPE = 'queen'
const GAME_NAME = 'Queen'
const REMARK_ICON = 'https://wver.sprintstaticdata.com/v230/static/front/img/icons/remark.png'
const TOTAL_LABELS = ['Total 0', 'Total 1', 'Total 2', 'Total 3']

function fmtAmt(n) {
  const v = Number(n) || 0
  if (v >= 100000) return `${v / 100000}L`
  if (v >= 1000) return `${v / 1000}K`
  return String(v)
}
function isSusp(item) {
  return !item || item.gstatus === 'SUSPENDED' || item.gstatus === '0'
}
function bookOf(exposures, name, sid) {
  return roundBook(exposures?.[`sid:${sid}`] ?? exposures?.[name] ?? 0)
}
function bookCls(v) {
  return v < 0 ? 'book-red' : v > 0 ? 'book-green' : 'book-black'
}

// 16 comma-codes round-robin (i % 4) -> 4 totals
function parseQueenCards(cardStr) {
  const codes = String(cardStr || '').split(',').map((c) => c.trim())
  const totals = [[], [], [], []]
  for (let i = 0; i < codes.length; i++) {
    if (codes[i] && codes[i] !== '1') totals[i % 4].push(codes[i])
  }
  return totals
}
// Reference: a card counts its face (2–6), the Queen 12 (was 0 here).
function cardSum(cards) {
  return cards.reduce((s, c) => {
    if (/^Q/i.test(String(c))) return s + 12
    const m = String(c).match(/^(\d+)/)
    return s + (m ? parseInt(m[1], 10) : 0)
  }, 0)
}

// Queen — route slug queen, API queen. Table class casino-queen. Video overlay:
// 4 "Total N" groups (label + count + dealt cards). count = card-values-sum +
// N (Total N N points se start). Winner (highest count) label text-success.
// Detail: 4 col-3 back/lay boxes (Total 0-3) + book + min-max R:100-3L + remark
// marquee. NO Rules icon. Strip resultb = win total index. Dual-strip.
export default function Queen() {
  const isAuth = useSelector((s) => Boolean(s.auth.token))
  const [resultMid, setResultMid] = useState(null)
  const [showLr, setShowLr] = useState(true)
  const [showCards, setShowCards] = useState(true)
  const [isMobile, setIsMobile] = useState(() => typeof window !== 'undefined' && window.innerWidth < 768)

  useEffect(() => {
    const onResize = () => setIsMobile(window.innerWidth < 768)
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  const { data: gameData } = useCasinoGame(GAME_TYPE)
  const { data: lastResults = [], refetch: refetchLastResults } = useCasinoLastResults(GAME_TYPE)
  const { streamUrl } = useCasinoStream(GAME_TYPE)
  const { myBets } = useCasinoMyBets(GAME_TYPE, isAuth)

  const mid = gameData?.mid ?? ''
  const lt = gameData?.lt ?? 0
  const ft = gameData?.ft ?? 40
  const remark = gameData?.remark ?? ''
  const sub = gameData?.sub || []

  const exposures = computeAdminBook(myBets, getMarketsForGame(GAME_TYPE, gameData))

  useEffect(() => {
    if (mid) refetchLastResults()
  }, [mid, refetchLastResults])

  const totals = useMemo(() => parseQueenCards(gameData?.card || ''), [gameData?.card])
  // count = card-values-sum + Total-index, but empty total shows 0 (no index)
  const counts = useMemo(() => totals.map((cards, i) => (cards.length ? cardSum(cards) + i : 0)), [totals])
  const hasCards = totals.some((t) => t.length > 0)
  const maxCount = Math.max(...counts)

  const findBySid = (sid) => sub.find((s) => s.sid === sid || s.sid === String(sid))

  const resultsStrip = (
    <div className={`casino-video-last-results${showLr ? '' : ' hide-lr'}`}>
      {lastResults.map((r, i) => {
        // win = winning sid (1-4) -> Total index (0-3) = win - 1
        const t = Number(r.win)
        const label = Number.isFinite(t) && t > 0 ? t - 1 : (r.win ?? '')
        return (
          <span key={i} className="resultb" onClick={() => setResultMid(r.mid || null)}>
            {label}
          </span>
        )
      })}
      {' '}
      <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
        {'\n    ...\n  '}
      </Link>
      {' '}
    </div>
  )

  return (
    <>
      <div className="center-main-container">
        <div className="center-content">
          <div className="casino-container">
            <div className="casino-table casino-queen">

              <div className="casino-video">
                <div className="casino-video-title">
                  <span className="casino-name">{GAME_NAME}</span>
                  {' '}
                  <div className="casino-video-rid">Round ID: {mid}</div>
                </div>
                {' '}
                <div className="video-box-container">
                  <div className="video-box">
                    {streamUrl && <iframe src={streamUrl}></iframe>}
                  </div>
                </div>
                {' '}
                <div className={`casino-video-cards${showCards && hasCards ? '' : ' hide-cards'}`}>
                  <div className="casino-cards-shuffle" onClick={() => setShowCards((v) => !v)}>
                    <i className="fas fa-grip-lines-vertical"></i>
                  </div>
                  {' '}
                  <div className="casino-video-cards-container">
                    {TOTAL_LABELS.map((label, i) => {
                      // reference: every label tied for the top total is text-success (all of them when all are 0)
                      const isWinner = counts[i] === maxCount
                      return (
                        <Fragment key={i}>
                        {i > 0 && ' '}
                        <div>
                          <div className="dealer-name w-100 mb-1">
                            <span className={isWinner ? 'text-success' : ''}>{label}:{'\n                      '}</span>
                            {' '}
                            <span className="text-warning ml-1">{counts[i]}</span>
                          </div>
                          {' '}
                          <div>
                            {totals[i].map((c, j) => (
                              <span key={j} data-v-b64efdfa=""><img data-v-b64efdfa="" src={cardSrc(c)} /></span>
                            ))}
                          </div>
                        </div>
                        </Fragment>
                      )
                    })}
                  </div>
                </div>
                {' '}
                <CircularTimer timeLeft={lt} fullTime={ft} />
                {' '}
                <div className="casino-video-right-icons">
                  <div title="Home" className="casino-video-home-icon">
                    <Link to="/admin/casino/list" className="" style={{ color: 'var(--text-highlight)' }}>
                      <i className="fas fa-home"></i>
                    </Link>
                  </div>
                  {' '}
                  <div title="Last Results" className="casino-video-lr-icon" onClick={() => setShowLr((v) => !v)}>
                    <i className={`fas ${showLr ? 'fa-chevron-circle-up' : 'fa-chevron-circle-down'}`}></i>
                  </div>
                </div>
                {' '}
                {/* web: strip video ke andar */}
                {!isMobile && resultsStrip}
              </div>
              {' '}
              <div className="casino-detail">
                {/* web: 4 col-3 boxes; mobile: casino-bl-box stack */}
                {!isMobile ? (
                  <div className="row">
                    {TOTAL_LABELS.map((label, i) => {
                      const item = findBySid(i + 1)
                      const susp = isSusp(item)
                      const book = bookOf(exposures, item?.nat, i + 1)
                      return (
                        <div key={i} className="col-3">
                          <div className="casino-box-row">
                            <div className="casino-nation-name"><b>{label}</b></div>
                            {' '}
                            <div className="casino-bl-box">
                              <div
                                data-toggle="modal"
                                data-target="#casino-betslip"
                                className={`back casino-bl-box-item${susp ? ' suspended' : ''}`}
                              >
                                <span className="casino-box-odd">{item?.b ?? 0}</span>
                              </div>
                              {' '}
                              <div className={`lay casino-bl-box-item${susp ? ' suspended' : ''}`}>
                                <span className="casino-box-odd">{item?.l ?? 0}</span>
                              </div>
                            </div>
                            {' '}
                            <div className="casino-nation-name">
                              <span className={`casino-book ${bookCls(book)}`}>{fmtBook(book)}</span>
                            </div>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                ) : (
                  <div className="row row5 d-none-big">
                    {TOTAL_LABELS.map((label, i) => {
                      const item = findBySid(i + 1)
                      const susp = isSusp(item)
                      const book = bookOf(exposures, item?.nat, i + 1)
                      return (
                        <div key={i} className="casino-bl-box">
                          <div className="casino-bl-box-item casino-odds-name">
                            <b>{label}</b>
                            {' '}
                            <span className={`float-right ${bookCls(book)}`}>{fmtBook(book)}</span>
                          </div>
                          {' '}
                          <div className={`back casino-bl-box-item${susp ? ' suspended' : ''}`}>
                            <span className="casino-box-odd">{item?.b ?? 0}</span>
                          </div>
                          {' '}
                          <div className={`lay casino-bl-box-item${susp ? ' suspended' : ''}`}>
                            <span className="casino-box-odd">{item?.l ?? 0}</span>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                )}
                {' '}
                <div className="col-12 text-right casino-min-max">
                  {'\n              R:'}
                  <span>{fmtAmt(sub[0]?.min ?? 100)}</span>
                  -
                  <span>{fmtAmt(sub[0]?.max ?? 300000)}</span>
                </div>
                {' '}
                <div className="casino-remark mt-3">
                  <div className="remark-icon"><img src={REMARK_ICON} /></div>
                  {' '}
                  <marquee>{remark}</marquee>
                </div>
                {' '}
                {/* mobile: strip detail ke bottom me */}
                {isMobile && resultsStrip}
              </div>

            </div>
          </div>
        </div>
        {' '}
        <CasinoMyBetsSidebar myBets={myBets} gameName={GAME_TYPE} />
      </div>

      <CasinoResultModal
        show={!!resultMid}
        onClose={() => setResultMid(null)}
        gameType={GAME_TYPE}
        gameName={GAME_NAME}
        mid={resultMid}
      />
    </>
  )
}
