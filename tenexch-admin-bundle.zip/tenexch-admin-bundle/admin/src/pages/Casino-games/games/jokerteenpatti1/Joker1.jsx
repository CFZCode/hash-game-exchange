import JokerPage from '../../../../components/casino/JokerPage'

export default function Joker1() {
  // joker1 = teenpatti card layout (no leading joker): A=[0,2,4], B=[1,3,5]
  return <JokerPage gameType="joker1" gameName="Unlimited Joker Oneday" cardOffset={0} />
}
