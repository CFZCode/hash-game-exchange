import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { CircularTimer } from '../../../../components/casino/CasinoTimer'
import BetTableTeen6 from '../../../../components/casino/BetTableTeen6'
import CasinoMyBetsSidebar from '../../../../components/casino/CasinoMyBetsSidebar'
import CasinoResultModal from '../../../../components/casino/CasinoResultModal'
import CasinoRulesModal from '../../../../components/casino/CasinoRulesModal'
import CasinoRulesSwitch from '../../../../components/casino/rules/CasinoRulesSwitch'
import useCasinoGame from '../../../../hooks/casino/useCasinoGame'
import useCasinoLastResults from '../../../../hooks/casino/useCasinoLastResults'
import useCasinoMyBets from '../../../../hooks/casino/useCasinoMyBets'
import useCasinoStream from '../../../../hooks/casino/useCasinoStream'
import { computeAdminBook, getMarketsForGame } from '../../../../utils/casinoBook'
import { cardSrc, parseCards } from '../../../../components/casino/cards/cardUtils'
import { formatTeen6Nation } from '../../../../utils/casinoUtils'

const GAME_TYPE = 'teen6'
const GAME_NAME = 'Teenpatti - 2.0'

// Teenpatti 2.0 — route slug teenpatti2, API teen6. Table class teenpatti2.
// 6-card overlay (cards dealt alternately: Player A = 1st/3rd/5th, B = 2nd/4th/6th). Detail: BetTableTeen6
// (Main A/B back-lay + Under21/Over22, suit, Odd/Even, A-K cards; book-black
// always + collapse ranges + casino-min-max). Rules icon. Strip resulta A /
// resultb B / resulttie T. Dual-strip (web video, mobile detail).
export default function Teenpatti2() {
  const isAuth = useSelector((s) => Boolean(s.auth.token))
  const [resultMid, setResultMid] = useState(null)
  const [showRules, setShowRules] = useState(false)
  const [showLr, setShowLr] = useState(true)
  const [showCards, setShowCards] = useState(true)
  const [isMobile, setIsMobile] = useState(() => typeof window !== 'undefined' && window.innerWidth < 768)

  useEffect(() => {
    const onResize = () => setIsMobile(window.innerWidth < 768)
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  const { data: gameData } = useCasinoGame(GAME_TYPE)
  const { data: lastResults = [], refetch: refetchLastResults } = useCasinoLastResults(GAME_TYPE)
  const { streamUrl } = useCasinoStream(GAME_TYPE)
  const { myBets } = useCasinoMyBets(GAME_TYPE, isAuth)

  const mid = gameData?.mid ?? ''
  const lt = gameData?.lt ?? 0
  const ft = gameData?.ft ?? 30

  // Side bets (suit / Odd-Even / card face) are stored per card — "Card 1 Spade",
  // "Card 1 Odd", "Card 1 A" — names the feed doesn't list, so computeAdminBook
  // skipped them. Give each such name its own single-line market (as the player
  // side does for teen6) so the cells show their book.
  const markets = getMarketsForGame(GAME_TYPE, gameData)
  const known = new Set(markets.flat().map((x) => x.nat))
  const sideNats = [...new Set(myBets.map((b) => String(b.selection || b.player_name || '').trim()))]
    .filter((nat) => nat && !known.has(nat))
  const exposures = computeAdminBook(myBets, [...markets, ...sideNats.map((nat) => [{ sid: `teen6:${nat}`, nat }])])

  const codes = parseCards(gameData?.card || '')
  // teenpatti interleaved layout (frontend TeenpattiCards): A = codes[0,2,4], B = codes[1,3,5]
  const rowA = [codes[0] || '1', codes[2] || '1', codes[4] || '1']
  const rowB = [codes[1] || '1', codes[3] || '1', codes[5] || '1']

  useEffect(() => {
    if (mid) refetchLastResults()
  }, [mid, refetchLastResults])

  const renderResult = (r, i) => {
    const w = String(r.win)
    const on = () => setResultMid(r.mid || null)
    if (w === '1') return <span key={i} className="resulta" onClick={on}>A</span>
    if (w === '2') return <span key={i} className="resultb" onClick={on}>B</span>
    return <span key={i} className="resulttie" onClick={on}>T</span>
  }

  const resultsStrip = (
    <div className={`casino-video-last-results${showLr ? '' : ' hide-lr'}`}>
      {lastResults.map(renderResult)}
      {' '}
      <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
        {'\n    ...\n  '}
      </Link>
      {' '}
    </div>
  )

  const cardRow = (row) => (
    <div>
      {row.map((c, i) => (
        <span key={i} data-v-b64efdfa=""><img data-v-b64efdfa="" src={cardSrc(c)} /></span>
      )).reduce((acc, el, i) => (i === 0 ? [el] : [...acc, ' ', el]), [])}
    </div>
  )

  return (
    <>
      <div className="center-main-container">
        <div className="center-content">
          <div className="casino-container">
            <div className="casino-table teenpatti2">

              <div className="casino-video">
                <div className="casino-video-title">
                  <span className="casino-name">{GAME_NAME}</span>
                  {' '}
                  <div className="casino-video-rid">Round ID: {mid}</div>
                </div>
                {' '}
                <div className="video-box-container">
                  <div className="video-box">
                    {streamUrl && <iframe src={streamUrl}></iframe>}
                  </div>
                </div>
                {' '}
                <div className={`casino-video-cards${showCards ? '' : ' hide-cards'}`}>
                  <div className="casino-cards-shuffle" onClick={() => setShowCards((v) => !v)}>
                    <i className="fas fa-grip-lines-vertical"></i>
                  </div>
                  {' '}
                  <div className="casino-video-cards-container">
                    {cardRow(rowA)}
                    {' '}
                    {cardRow(rowB)}
                  </div>
                </div>
                {' '}
                <CircularTimer timeLeft={lt} fullTime={ft} />
                {' '}
                <div className="casino-video-right-icons">
                  <div title="Home" className="casino-video-home-icon">
                    <Link to="/admin/casino/list" className="" style={{ color: 'var(--text-highlight)' }}>
                      <i className="fas fa-home"></i>
                    </Link>
                  </div>
                  {' '}
                  <div title="Rules" className="casino-video-rules-icon" onClick={() => setShowRules((v) => !v)}>
                    <i className="fas fa-info-circle"></i>
                  </div>
                  {' '}
                  <div title="Last Results" className="casino-video-lr-icon" onClick={() => setShowLr((v) => !v)}>
                    <i className={`fas ${showLr ? 'fa-chevron-circle-up' : 'fa-chevron-circle-down'}`}></i>
                  </div>
                </div>
                {' '}
                <div>{showRules && (
                  <div
                    id="casino-vieo-rules"
                    aria-modal="true"
                    className="casino-vieo-rules show d-none-small show-rules"
                    style={{ display: 'block' }}
                  >
                    <div className="rules-header">
                      <div>Rules</div>
                      {' '}
                      <i className="fas fa-times" onClick={() => setShowRules(false)}></i>
                    </div>
                    {' '}
                    <div className="rules-body">
                      <CasinoRulesSwitch gameType={GAME_TYPE} />
                    </div>
                  </div>
                )}</div>
                {' '}
                {/* web: strip video ke andar */}
                {!isMobile && resultsStrip}
              </div>
              {' '}
              <div className="casino-detail">
                <BetTableTeen6
                  gameData={gameData}
                  onBet={() => {}}
                  exposures={exposures}
                />
                {' '}
                {/* mobile: strip detail ke bottom me */}
                {isMobile && resultsStrip}
              </div>

            </div>
          </div>
        </div>
        {' '}
        <CasinoMyBetsSidebar myBets={myBets} gameName={GAME_TYPE} formatNation={formatTeen6Nation} />
      </div>

      <CasinoRulesModal
        show={showRules}
        onClose={() => setShowRules(false)}
        tableClass=""
        gameType={GAME_TYPE}
      >
        <CasinoRulesSwitch gameType={GAME_TYPE} />
      </CasinoRulesModal>

      <CasinoResultModal
        show={!!resultMid}
        onClose={() => setResultMid(null)}
        gameType={GAME_TYPE}
        gameName={GAME_NAME}
        mid={resultMid}
      />
    </>
  )
}
