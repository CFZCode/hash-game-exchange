import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { CircularTimer } from '../../../../components/casino/CasinoTimer'
import BetTableMogambo from '../../../../components/casino/BetTableMogambo'
import CasinoMyBetsSidebar from '../../../../components/casino/CasinoMyBetsSidebar'
import CasinoResultModal from '../../../../components/casino/CasinoResultModal'
import CasinoRulesModal from '../../../../components/casino/CasinoRulesModal'
import CasinoRulesSwitch from '../../../../components/casino/rules/CasinoRulesSwitch'
import { cardSrc, parseCards } from '../../../../components/casino/cards/cardUtils'
import useCasinoGame from '../../../../hooks/casino/useCasinoGame'
import useCasinoLastResults from '../../../../hooks/casino/useCasinoLastResults'
import useCasinoMyBets from '../../../../hooks/casino/useCasinoMyBets'
import useCasinoStream from '../../../../hooks/casino/useCasinoStream'
import { computeAdminBook, getMarketsForGame } from '../../../../utils/casinoBook'
import useCardStripToggle from '../../../../hooks/casino/useCardStripToggle'

const GAME_TYPE = 'mogambo'
const GAME_NAME = 'Mogambo'

// "3 Card Total" point value (reference Total: 14 = 9CC+5SS, Mogambo facedown).
// A=1, 2-10=face, J=11, Q=12, K=13; facedown (1/0) = 0.
function cardTotalValue(code) {
  if (!code || code === '1' || code === '0') return 0
  const rank = code.replace(/(CC|DD|HH|SS)$/i, '').toUpperCase()
  if (rank === 'A') return 1
  if (rank === 'J') return 11
  if (rank === 'Q') return 12
  if (rank === 'K') return 13
  const n = parseInt(rank, 10)
  return isNaN(n) ? 0 : n
}

// Mogambo — reference: casino-table mogambo teenpatti2cards. Video overlay me
// shuffle icon + Total + Daga/Teja (2 cards, card-devider) + Mogambo (1 card,
// text-center). Card sequence frontend MogamboCards se: cards[0..1]=Daga/Teja,
// cards[2]=Mogambo. Last-results W/L (win==1 -> W). Table = BetTableMogambo.
export default function Mogambo() {
  const isAuth = useSelector((s) => Boolean(s.auth.token))
  const [resultMid, setResultMid] = useState(null)
  const [showRules, setShowRules] = useState(false)
  const [showLr, setShowLr] = useState(true)
  const [isMobile, setIsMobile] = useState(() => typeof window !== 'undefined' && window.innerWidth < 768)

  useEffect(() => {
    const onResize = () => setIsMobile(window.innerWidth < 768)
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  const { data: gameData } = useCasinoGame(GAME_TYPE)
  const { data: lastResults = [], refetch: refetchLastResults } = useCasinoLastResults(GAME_TYPE)
  const { streamUrl } = useCasinoStream(GAME_TYPE)
  const { myBets } = useCasinoMyBets(GAME_TYPE, isAuth)

  const mid = gameData?.mid ?? ''
  const [stripCollapsed, toggleStrip] = useCardStripToggle(mid)
  const lt = gameData?.lt ?? 0
  const ft = gameData?.ft ?? 30

  const codes = parseCards(gameData?.card || '')
  const dagaA = codes[0] || '1'
  const dagaB = codes[1] || '1'
  const mogamboCard = codes[2] || '1'
  const hideCards = [dagaA, dagaB, mogamboCard].every((c) => c === '1' || c === '0')
  const total = gameData?.total ?? [dagaA, dagaB, mogamboCard].reduce((s, c) => s + cardTotalValue(c), 0)

  const exposures = computeAdminBook(myBets, getMarketsForGame(GAME_TYPE, gameData))

  useEffect(() => {
    if (mid) refetchLastResults()
  }, [mid, refetchLastResults])

  // reference: win==1 -> resultb "W", warna resulta "L"
  const renderResult = (r, i) => (
    String(r.win) === '1'
      ? <span key={i} className="resultb" onClick={() => setResultMid(r.mid || null)}>W</span>
      : <span key={i} className="resulta" onClick={() => setResultMid(r.mid || null)}>L</span>
  )

  // reference: desktop strip casino-video me (rules slot ke baad), phone pe
  // casino-detail ke andar sabse neeche
  const resultsStrip = (
    <div className={`casino-video-last-results${showLr ? '' : ' hide-lr'}`}>
      {lastResults.map(renderResult)}
      {' '}
      <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
        {'\n    ...\n  '}
      </Link>
      {' '}
    </div>
  )

  return (
    <>
      <div className="center-main-container">
        <div className="center-content">
          <div className="casino-container">
            <div className="casino-table mogambo teenpatti2cards">

              <div className="casino-video">
                <div className="casino-video-title">
                  <span className="casino-name">{GAME_NAME}</span>
                  {' '}
                  <div className="casino-video-rid">
                    {'\n                Round ID: ' + mid + '\n              '}
                  </div>
                </div>
                {' '}
                <div className="video-box-container">
                  <div className="video-box">
                    {streamUrl && <iframe src={streamUrl}></iframe>}
                  </div>
                </div>
                {' '}
                <div className={`casino-video-cards${hideCards || stripCollapsed ? ' hide-cards' : ''}`}>
                  <div className="casino-cards-shuffle" role="button" style={{ cursor: 'pointer' }} onClick={toggleStrip}>
                    <i className="fas fa-grip-lines-vertical"></i>
                  </div>
                  {' '}
                  <div className="casino-video-cards-container">
                    <h5 className="text-white">{`Total: ${total}`}</h5>
                    {' '}
                    <h5 className="text-white">Daga / Teja</h5>
                    {' '}
                    <div>
                      <span><img src={cardSrc(dagaA)} alt={dagaA} /></span>
                      {' '}
                      <span className="card-devider"></span>
                      {' '}
                      <span><img src={cardSrc(dagaB)} alt={dagaB} /></span>
                    </div>
                    {' '}
                    <h5 className="text-white">Mogambo</h5>
                    {' '}
                    <div className="text-center">
                      <span><img src={cardSrc(mogamboCard)} alt={mogamboCard} /></span>
                    </div>
                  </div>
                </div>
                {' '}
                <CircularTimer timeLeft={lt} fullTime={ft} />
                {' '}
                <div className="casino-video-right-icons">
                  <div title="Home" className="casino-video-home-icon">
                    <Link to="/admin/casino/list" className="" style={{ color: 'var(--text-highlight)' }}>
                      <i className="fas fa-home"></i>
                    </Link>
                  </div>
                  {' '}
                  <div title="Rules" className="casino-video-rules-icon" onClick={() => setShowRules((v) => !v)}>
                    <i className="fas fa-info-circle"></i>
                  </div>
                  {' '}
                  <div title="Last Results" className="casino-video-lr-icon" onClick={() => setShowLr((v) => !v)}>
                    <i className={`fas ${showLr ? 'fa-chevron-circle-up' : 'fa-chevron-circle-down'}`}></i>
                  </div>
                </div>
                {' '}
                <div>{showRules && (
                  <div
                    id="casino-vieo-rules"
                    aria-modal="true"
                    className="casino-vieo-rules show d-none-small show-rules"
                    style={{ display: 'block' }}
                  >
                    <div className="rules-header">
                      <div>Rules</div>
                      {' '}
                      <i className="fas fa-times" onClick={() => setShowRules(false)}></i>
                    </div>
                    {' '}
                    <div className="rules-body">
                      <CasinoRulesSwitch gameType={GAME_TYPE} />
                    </div>
                  </div>
                )}</div>
                {' '}
                {!isMobile && resultsStrip}
              </div>
              {' '}
              <div className="casino-detail">
                <BetTableMogambo
                  gameData={gameData}
                  onBet={() => {}}
                  exposures={exposures}
                />
                {' '}
                {isMobile && resultsStrip}
              </div>

            </div>
          </div>
        </div>
        {' '}
        <CasinoMyBetsSidebar myBets={myBets} gameName={GAME_TYPE} />
      </div>

      <CasinoRulesModal
        show={showRules}
        onClose={() => setShowRules(false)}
        tableClass=""
        gameType={GAME_TYPE}
      >
        <CasinoRulesSwitch gameType={GAME_TYPE} />
      </CasinoRulesModal>

      <CasinoResultModal
        show={!!resultMid}
        onClose={() => setResultMid(null)}
        gameType={GAME_TYPE}
        gameName={GAME_NAME}
        mid={resultMid}
      />
    </>
  )
}
