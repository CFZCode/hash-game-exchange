import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { CircularTimer } from '../../../../components/casino/CasinoTimer'
import BetTableTeen1 from '../../../../components/casino/BetTableTeen1'
import CasinoMyBetsSidebar from '../../../../components/casino/CasinoMyBetsSidebar'
import CasinoResultModal from '../../../../components/casino/CasinoResultModal'
import CasinoRulesModal from '../../../../components/casino/CasinoRulesModal'
import CasinoRulesSwitch from '../../../../components/casino/rules/CasinoRulesSwitch'
import useCasinoGame from '../../../../hooks/casino/useCasinoGame'
import useCasinoLastResults from '../../../../hooks/casino/useCasinoLastResults'
import useCasinoMyBets from '../../../../hooks/casino/useCasinoMyBets'
import useCasinoStream from '../../../../hooks/casino/useCasinoStream'
import { computeAdminBook, getMarketsForGame } from '../../../../utils/casinoBook'
import { cardSrc, parseCards } from '../../../../components/casino/cards/cardUtils'

// route slug 1card1day, API type teen1
const GAME_TYPE = 'teen1'
const GAME_NAME = '1 CARD ONE-DAY'

// 1 CARD ONE-DAY — table teen1oneday. Video: 2 labelled cards (Player/Dealer).
// Detail: BetTableTeen1 (Player/Dealer back-lay + 7 up/down boxes) + strip
// (P/D). Sidebar: my-bets only. book-black hamesha. Dual-strip (web video me,
// mobile detail me).
export default function OneCardOneDay() {
  const isAuth = useSelector((s) => Boolean(s.auth.token))
  const [resultMid, setResultMid] = useState(null)
  const [showRules, setShowRules] = useState(false)
  const [showLr, setShowLr] = useState(true)
  const [showCards, setShowCards] = useState(true)

  const { data: gameData } = useCasinoGame(GAME_TYPE)
  const { data: lastResults = [], refetch: refetchLastResults } = useCasinoLastResults(GAME_TYPE)
  const { streamUrl } = useCasinoStream(GAME_TYPE)
  const { myBets } = useCasinoMyBets(GAME_TYPE, isAuth)

  const mid = gameData?.mid ?? ''
  const lt = gameData?.lt ?? 0
  const ft = gameData?.ft ?? 30
  const card = gameData?.card ?? ''

  const exposures = computeAdminBook(myBets, getMarketsForGame(GAME_TYPE, gameData))

  const codes = parseCards(card)
  const playerCard = codes[0] || '1'
  const dealerCard = codes[1] || '1'
  const hasCards = codes.some((c) => c && c !== '1')

  useEffect(() => {
    if (mid) refetchLastResults()
  }, [mid, refetchLastResults])

  // 1=Player(P), 2=Dealer(D), 3=Tie(T, bare span) — same chips as the player site.
  // The old "else D" painted every tie as a Dealer win.
  const renderResult = (r, i) => {
    const w = String(r.win)
    if (w === '1') return <span key={i} className="resulta" onClick={() => setResultMid(r.mid || null)}>P</span>
    if (w === '2') return <span key={i} className="resultb" onClick={() => setResultMid(r.mid || null)}>D</span>
    return <span key={i} className="" onClick={() => setResultMid(r.mid || null)}>T</span>
  }

  const resultsStrip = (extraCls) => (
    <div className={`casino-video-last-results ${extraCls}${showLr ? '' : ' hide-lr'}`}>
      {lastResults.map(renderResult)}
      {' '}
      <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
        {'\n    ...\n  '}
      </Link>
      {' '}
    </div>
  )

  const labelledCard = (label, code) => (
    <div>
      <div className="dealer-name w-100 mb-1">{label}</div>
      {' '}
      <div>
        <span>
          <span data-v-b64efdfa=""><img data-v-b64efdfa="" src={cardSrc(code)} /></span>
        </span>
      </div>
    </div>
  )

  return (
    <>
      <div className="center-main-container">
        <div className="center-content">
          <div className="casino-container">
            <div className="casino-table teen1oneday">

              <div className="casino-video">
                <div className="casino-video-title">
                  <span className="casino-name">{GAME_NAME}</span>
                  {' '}
                  <div className="casino-video-rid">Round ID: {mid}</div>
                </div>
                {' '}
                <div className="video-box-container">
                  <div className="video-box">
                    {streamUrl && <iframe src={streamUrl}></iframe>}
                  </div>
                </div>
                {' '}
                <div className={`casino-video-cards${showCards && hasCards ? '' : ' hide-cards'}`}>
                  <div className="casino-cards-shuffle" onClick={() => setShowCards((v) => !v)}>
                    <i className="fas fa-grip-lines-vertical"></i>
                  </div>
                  {' '}
                  <div className="casino-video-cards-container">
                    {labelledCard('Player', playerCard)}
                    {' '}
                    {labelledCard('Dealer', dealerCard)}
                  </div>
                </div>
                {' '}
                <CircularTimer timeLeft={lt} fullTime={ft} />
                {' '}
                <div className="casino-video-right-icons">
                  <div title="Home" className="casino-video-home-icon">
                    <Link to="/admin/casino/list" className="" style={{ color: 'var(--text-highlight)' }}>
                      <i className="fas fa-home"></i>
                    </Link>
                  </div>
                  {' '}
                  <div title="Rules" className="casino-video-rules-icon" onClick={() => setShowRules((v) => !v)}>
                    <i className="fas fa-info-circle"></i>
                  </div>
                  {' '}
                  <div title="Last Results" className="casino-video-lr-icon" onClick={() => setShowLr((v) => !v)}>
                    <i className={`fas ${showLr ? 'fa-chevron-circle-up' : 'fa-chevron-circle-down'}`}></i>
                  </div>
                </div>
                {' '}
                <div>{showRules && (
                  <div
                    id="casino-vieo-rules"
                    aria-modal="true"
                    className="casino-vieo-rules show d-none-small show-rules"
                    style={{ display: 'block' }}
                  >
                    <div className="rules-header">
                      <div>Rules</div>
                      {' '}
                      <i className="fas fa-times" onClick={() => setShowRules(false)}></i>
                    </div>
                    {' '}
                    <div className="rules-body">
                      <CasinoRulesSwitch gameType={GAME_TYPE} />
                    </div>
                  </div>
                )}</div>
                {' '}
                {/* web: strip video ke andar (mobile pe CSS hide) */}
                {resultsStrip('d-none-small')}
              </div>
              {' '}
              <div className="casino-detail">
                <BetTableTeen1
                  gameData={gameData}
                  onBet={() => {}}
                  exposures={exposures}
                />
                {' '}
                {/* mobile: strip detail ke bottom me (web pe CSS hide) */}
                {resultsStrip('d-none-desktop')}
              </div>

            </div>
          </div>
        </div>
        {' '}
        <CasinoMyBetsSidebar myBets={myBets} gameName={GAME_TYPE} />
      </div>

      <CasinoRulesModal
        show={showRules}
        onClose={() => setShowRules(false)}
        tableClass=""
        gameType={GAME_TYPE}
      >
        <CasinoRulesSwitch gameType={GAME_TYPE} />
      </CasinoRulesModal>

      <CasinoResultModal
        show={!!resultMid}
        onClose={() => setResultMid(null)}
        gameType={GAME_TYPE}
        gameName={GAME_NAME}
        mid={resultMid}
      />
    </>
  )
}
