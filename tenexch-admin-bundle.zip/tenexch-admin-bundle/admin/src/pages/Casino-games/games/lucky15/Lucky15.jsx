import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { CircularTimer, MobileDigitTimer } from '../../../../components/casino/CasinoTimer'
import BetTableLucky15 from '../../../../components/casino/BetTableLucky15'
import CasinoMyBetsSidebar from '../../../../components/casino/CasinoMyBetsSidebar'
import CasinoResultModal from '../../../../components/casino/CasinoResultModal'
import CasinoRulesModal from '../../../../components/casino/CasinoRulesModal'
import CasinoRulesSwitch from '../../../../components/casino/rules/CasinoRulesSwitch'
import useCasinoGame from '../../../../hooks/casino/useCasinoGame'
import useCasinoLastResults from '../../../../hooks/casino/useCasinoLastResults'
import useCasinoMyBets from '../../../../hooks/casino/useCasinoMyBets'
import useCasinoStream from '../../../../hooks/casino/useCasinoStream'
import { computeAdminBook, getMarketsForGame } from '../../../../utils/casinoBook'

const GAME_TYPE = 'lucky15'
const GAME_NAME = 'Lucky 15'

// win sid 1-6 -> strip label (positional): 0/1/2/4/6 Runs + Wicket
const LABELS = ['0', '1', '2', '4', '6', 'W']

// Lucky 15 (lucky15) — casino-table five-cricket super-over detail-page-container
// lucky15. Single "Runs" market (6 back-only selections). col-xl-12 video +
// casino-time-digit (mobile), strip video me (resultb positional 0/1/2/4/6/W),
// market-container me BetTableLucky15.
export default function Lucky15() {
  const isAuth = useSelector((s) => Boolean(s.auth.token))
  const [resultMid, setResultMid] = useState(null)
  const [showRules, setShowRules] = useState(false)
  const [showLr, setShowLr] = useState(true)
  const [isMobile, setIsMobile] = useState(() => typeof window !== 'undefined' && window.innerWidth < 768)

  useEffect(() => {
    const onResize = () => setIsMobile(window.innerWidth < 768)
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  const { data: gameData } = useCasinoGame(GAME_TYPE)
  const { data: lastResults = [], refetch: refetchLastResults } = useCasinoLastResults(GAME_TYPE)
  const { streamUrl } = useCasinoStream(GAME_TYPE)
  const { myBets } = useCasinoMyBets(GAME_TYPE, isAuth)

  const mid = gameData?.mid ?? ''
  const lt = gameData?.lt ?? 0
  const ft = gameData?.ft ?? 20

  const exposures = computeAdminBook(myBets, getMarketsForGame(GAME_TYPE, gameData))

  useEffect(() => {
    if (mid) refetchLastResults()
  }, [mid, refetchLastResults])

  // reference: desktop strip casino-video me (rules slot ke baad), phone pe
  // market-container ke BAAD (casino-table level)
  const resultsStrip = (
    <div className={`casino-video-last-results${showLr ? '' : ' hide-lr'}`}>
      {lastResults.map((r, i) => {
        const idx = Number(r.win) - 1
        return (
          <span key={i} className="resultb" onClick={() => setResultMid(r.mid || null)}>
            {LABELS.map((lab, j) => (j === idx ? lab : '')).join(' ')}
          </span>
        )
      })}
      {' '}
      <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
        {'\n    ...\n  '}
      </Link>
      {' '}
    </div>
  )

  return (
    <>
      <div className="center-main-container">
        <div className="center-content">
          <div className="casino-container">
            <div className="casino-table five-cricket super-over detail-page-container lucky15">

              <div className="game-header">
                <span className="game-header-name">{GAME_NAME}</span>
                {' '}
                <span className="float-right game-header-date">Round ID: {mid}</span>
              </div>
              {' '}
              <div className="container-fluid container-fluid-5">
                <div className="row row5">
                  <div className="col-xl-12">
                    <div className="casino-video mt-0">
                      <div className="video-box-container">
                        <div className="video-box">
                          {streamUrl && <iframe src={streamUrl}></iframe>}
                          {' '}
                        </div>
                      </div>
                      {' '}
                      <CircularTimer timeLeft={lt} fullTime={ft} />
                      {' '}
                      <MobileDigitTimer timeLeft={lt} />
                      {' '}
                      <div className="casino-video-right-icons">
                        <div title="Home" className="casino-video-home-icon">
                          <Link to="/admin/casino/list" className="" style={{ color: 'var(--text-highlight)' }}>
                            <i className="fas fa-home"></i>
                          </Link>
                        </div>
                        {' '}
                        <div title="Rules" className="casino-video-rules-icon" onClick={() => setShowRules((v) => !v)}>
                          <i className="fas fa-info-circle"></i>
                        </div>
                        {' '}
                        <div title="Last Results" className="casino-video-lr-icon" onClick={() => setShowLr((v) => !v)}>
                          <i className={`fas ${showLr ? 'fa-chevron-circle-up' : 'fa-chevron-circle-down'}`}></i>
                        </div>
                      </div>
                      {' '}
                      <div>{showRules && (
                        <div
                          id="casino-vieo-rules"
                          aria-modal="true"
                          className="casino-vieo-rules show d-none-small show-rules"
                          style={{ display: 'block' }}
                        >
                          <div className="rules-header">
                            <div>Rules</div>
                            {' '}
                            <i className="fas fa-times" onClick={() => setShowRules(false)}></i>
                          </div>
                          {' '}
                          <div className="rules-body">
                            <CasinoRulesSwitch gameType={GAME_TYPE} />
                          </div>
                        </div>
                      )}</div>
                      {' '}
                      {!isMobile && resultsStrip}
                    </div>
                  </div>
                </div>
              </div>
              {' '}
              <div className="market-container">
                <BetTableLucky15
                  gameData={gameData}
                  onBet={() => {}}
                  exposures={exposures}
                />
              </div>
              {' '}
              {isMobile && resultsStrip}

            </div>
          </div>
        </div>
        {' '}
        <CasinoMyBetsSidebar myBets={myBets} gameName={GAME_TYPE} outerSimpleBar />
      </div>

      <CasinoRulesModal
        show={showRules}
        onClose={() => setShowRules(false)}
        tableClass=""
        gameType={GAME_TYPE}
      >
        <CasinoRulesSwitch gameType={GAME_TYPE} />
      </CasinoRulesModal>

      <CasinoResultModal
        show={!!resultMid}
        onClose={() => setResultMid(null)}
        gameType={GAME_TYPE}
        gameName={GAME_NAME}
        mid={resultMid}
      />
    </>
  )
}
