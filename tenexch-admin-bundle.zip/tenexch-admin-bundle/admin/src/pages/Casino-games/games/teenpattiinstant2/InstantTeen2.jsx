import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { CircularTimer } from '../../../../components/casino/CasinoTimer'
import BetTableInstantTeenpatti3 from '../../../../components/casino/BetTableInstantTeenpatti3'
import CasinoMyBetsSidebar from '../../../../components/casino/CasinoMyBetsSidebar'
import CasinoResultModal from '../../../../components/casino/CasinoResultModal'
import CasinoRulesModal from '../../../../components/casino/CasinoRulesModal'
import CasinoRulesSwitch from '../../../../components/casino/rules/CasinoRulesSwitch'
import useCasinoGame from '../../../../hooks/casino/useCasinoGame'
import useCasinoLastResults from '../../../../hooks/casino/useCasinoLastResults'
import useCasinoMyBets from '../../../../hooks/casino/useCasinoMyBets'
import useCasinoStream from '../../../../hooks/casino/useCasinoStream'
import { computeAdminBook, getMarketsForGame } from '../../../../utils/casinoBook'
import { cardSrc } from '../../../../components/casino/cards/cardUtils'
import useCardStripToggle from '../../../../hooks/casino/useCardStripToggle'
const REMARK_ICON = 'https://wver.sprintstaticdata.com/v230/static/front/img/icons/remark.png'

const GAME_TYPE = 'teen32'
const GAME_NAME = 'Instant Teenpatti 2.0'

// Instant Teenpatti 2.0 — route slug teenpattiinstant2, API type teen32. teen33
// ka exact twin: table teenpatti1day, sirf Player A/B Main (match spread), koi
// Under/Over nahi — BetTableInstantTeenpatti3 reuse. Cards A=0,2,4 / B=1,3,5
// (teenpatti, B facedown '1'). Strip A/B.
export default function InstantTeen2() {
  const isAuth = useSelector((s) => Boolean(s.auth.token))
  const [resultMid, setResultMid] = useState(null)
  const [showRules, setShowRules] = useState(false)
  const [showLr, setShowLr] = useState(true)

  const { data: gameData } = useCasinoGame(GAME_TYPE)
  const { data: lastResults = [], refetch: refetchLastResults } = useCasinoLastResults(GAME_TYPE)
  const { streamUrl } = useCasinoStream(GAME_TYPE)
  const { myBets } = useCasinoMyBets(GAME_TYPE, isAuth)

  const mid = gameData?.mid ?? ''
  const [stripCollapsed, toggleStrip] = useCardStripToggle(mid)
  const lt = gameData?.lt ?? 0
  const ft = gameData?.ft ?? 25
  const remark = gameData?.remark || ''

  const exposures = computeAdminBook(myBets, getMarketsForGame(GAME_TYPE, gameData))

  const cards = String(gameData?.card || '').split(',').map((c) => c.trim())
  const cardsA = [cards[0], cards[2], cards[4]].map((c) => c || '1')
  const cardsB = [cards[1], cards[3], cards[5]].map((c) => c || '1')

  useEffect(() => {
    if (mid) refetchLastResults()
  }, [mid, refetchLastResults])

  const cardSpan = (code, i) => (
    <span key={i} data-v-b64efdfa="">
      <img data-v-b64efdfa="" src={cardSrc(code)} />
    </span>
  )

  return (
    <>
      <div className="center-main-container">
        <div className="center-content">
          <div className="casino-container">
            <div className="casino-table teenpatti1day">

              <div className="casino-video">
                <div className="casino-video-title">
                  <span className="casino-name">{GAME_NAME}</span>
                  {' '}
                  <span className="casino-video-rid">Round ID: {mid}</span>
                </div>
                {' '}
                <div className="video-box-container">
                  <div className="video-box">
                    {streamUrl && <iframe src={streamUrl}></iframe>}
                  </div>
                </div>
                {' '}
                <div className={`casino-video-cards${[...cardsA, ...cardsB].some((c) => c && c !== '1' && c !== '0') && !stripCollapsed ? '' : ' hide-cards'}`}>
                  <div className="casino-cards-shuffle" role="button" style={{ cursor: 'pointer' }} onClick={toggleStrip}>
                    <i className="fas fa-grip-lines-vertical"></i>
                  </div>
                  {' '}
                  <div className="casino-video-cards-container">
                    <div>{cardsA.map((c, i) => cardSpan(c, i))}</div>
                    {' '}
                    <div>{cardsB.map((c, i) => cardSpan(c, i))}</div>
                  </div>
                </div>
                {' '}
                <CircularTimer timeLeft={lt} fullTime={ft} />
                {' '}
                <div className="casino-video-right-icons">
                  <div title="Home" className="casino-video-home-icon">
                    <Link to="/admin/casino/list" className="" style={{ color: 'var(--text-highlight)' }}>
                      <i className="fas fa-home"></i>
                    </Link>
                  </div>
                  {' '}
                  <div title="Rules" className="casino-video-rules-icon" onClick={() => setShowRules((v) => !v)}>
                    <i className="fas fa-info-circle"></i>
                  </div>
                  {' '}
                  <div title="Last Results" className="casino-video-lr-icon" onClick={() => setShowLr((v) => !v)}>
                    <i className={`fas ${showLr ? 'fa-chevron-circle-up' : 'fa-chevron-circle-down'}`}></i>
                  </div>
                </div>
                {' '}
                <div>{showRules && (
                  <div
                    id="casino-vieo-rules"
                    aria-modal="true"
                    className="casino-vieo-rules show d-none-small show-rules"
                    style={{ display: 'block' }}
                  >
                    <div className="rules-header">
                      <div>Rules</div>
                      {' '}
                      <i className="fas fa-times" onClick={() => setShowRules(false)}></i>
                    </div>
                    {' '}
                    <div className="rules-body">
                      <CasinoRulesSwitch gameType={GAME_TYPE} card={gameData?.card} gameName={GAME_NAME} />
                    </div>
                  </div>
                )}</div>
                {' '}
                <div className={`casino-video-last-results d-none-small${showLr ? '' : ' hide-lr'}`}>
                  {lastResults.map((r, i) => (
                    String(r.win) === '1'
                      ? <span key={i} className="resulta" onClick={() => setResultMid(r.mid || null)}>{'A '}</span>
                      : <span key={i} className="resultb" onClick={() => setResultMid(r.mid || null)}>{' B '}</span>
                  ))}
                  {' '}
                  <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
                    {'\n    ...\n  '}
                  </Link>
                  {' '}
                </div>
              </div>
              {' '}
              <div className="casino-detail">
                <BetTableInstantTeenpatti3
                  gameData={gameData}
                  onBet={() => {}}
                  exposures={exposures}
                />
                {' '}
                <div className="casino-remark mt-3">
                  <div className="remark-icon">
                    <img src={REMARK_ICON} />
                  </div>
                  {' '}
                  <marquee>{remark}</marquee>
                </div>
                {' '}
                {/* mobile: strip casino-detail ke bottom me (video wala d-none-small) */}
                <div className="casino-video-last-results d-none-desktop">
                  {lastResults.map((r, i) => (
                    String(r.win) === '1'
                      ? <span key={i} className="resulta" onClick={() => setResultMid(r.mid || null)}>{'A '}</span>
                      : <span key={i} className="resultb" onClick={() => setResultMid(r.mid || null)}>{' B '}</span>
                  ))}
                  {' '}
                  <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
                    {'\n    ...\n  '}
                  </Link>
                </div>
              </div>

            </div>
          </div>
        </div>
        {' '}
        {/* My Bets: plain "Player A" / "Player B" — no "-Main" (user, 2026-10-13) */}
        <CasinoMyBetsSidebar myBets={myBets} gameName={GAME_TYPE} />
      </div>

      <CasinoRulesModal
        show={showRules}
        onClose={() => setShowRules(false)}
        tableClass=""
        gameType={GAME_TYPE}
      >
        <CasinoRulesSwitch gameType={GAME_TYPE} card={gameData?.card} gameName={GAME_NAME} />
      </CasinoRulesModal>

      <CasinoResultModal
        show={!!resultMid}
        onClose={() => setResultMid(null)}
        gameType={GAME_TYPE}
        gameName={GAME_NAME}
        mid={resultMid}
      />
    </>
  )
}
