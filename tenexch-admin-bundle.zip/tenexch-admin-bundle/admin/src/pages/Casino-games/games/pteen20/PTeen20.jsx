import { Teen20Base } from '../teenpatti20/Teen20'

// Premium 20-20 Teenpatti — /admin/pcasino/pteen20 (Premium Casino list).
// Reference DOM (capture tenexch.com-admin-pcasino-pteen20, 2026-09-19) = the
// teenpatti20 page: .casino-table.teenpatti20, iframe stream, 2x3 overlay with
// hide-cards while face-down, circular timer, Home / Rules / Last Results,
// BetTableTeen20 (Player, 3 Baccarat, Total, Pair Plus A/B, ♠♣, ♥♦ — R:1K-2L /
// 1K-50K from the feed), A/B strip, sidebar My Bets + Pair Plus card. Feed
// pteen20 = teen20's 12 rows (verified live). Type, title and Home link differ.
export default function PTeen20() {
  return <Teen20Base gameType="pteen20" gameName="Premium 20-20 Teenpatti" homePath="/admin/pcasino/list" />
}
