import { DragonTiger20Base } from '../dragontigert20/DragonTiger20'

// Premium 20-20 Dragon Tiger — /admin/pcasino/pdt20 (Premium Casino list).
// Reference DOM (capture tenexch.com-admin-pcasino-pdt20, 2026-09-19) = the
// dt20 page: .casino-table.dt20, iframe stream, 2-card overlay, circular
// timer, Home / Rules / Last Results, BetTableDT20 (Dragon / Tie / Tiger / Pair
// + per-side Even/Odd/Red/Black + A-K; ranges 1K-2L / 20K / 10K from the feed),
// remark marquee while the feed carries one, strip D / T, sidebar My Bets only.
// Feed pdt20 = dt20's 38 rows (verified live). Type, title and Home link differ.
export default function PDt20() {
  return <DragonTiger20Base gameType="pdt20" gameName="Premium 20-20 Dragon Tiger" homePath="/admin/pcasino/list" />
}
