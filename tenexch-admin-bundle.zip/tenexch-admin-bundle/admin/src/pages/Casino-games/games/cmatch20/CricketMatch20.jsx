import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { CircularTimer } from '../../../../components/casino/CasinoTimer'
import CasinoMyBetsSidebar from '../../../../components/casino/CasinoMyBetsSidebar'
import CasinoResultModal from '../../../../components/casino/CasinoResultModal'
import CasinoRulesModal from '../../../../components/casino/CasinoRulesModal'
import CasinoRulesSwitch from '../../../../components/casino/rules/CasinoRulesSwitch'
import useCasinoGame from '../../../../hooks/casino/useCasinoGame'
import useCasinoLastResults from '../../../../hooks/casino/useCasinoLastResults'
import useCasinoMyBets from '../../../../hooks/casino/useCasinoMyBets'
import useCasinoStream from '../../../../hooks/casino/useCasinoStream'
import { cardSrc, parseCards } from '../../../../components/casino/cards/cardUtils'

const GAME_TYPE = 'cmatch20'
const GAME_NAME = 'Cricket Match 20-20'
const ADMIN_BALLS = 'https://wver.sprintstaticdata.com/v230/static/admin/img/balls'
const FRONT_BALLS = 'https://wver.sprintstaticdata.com/v230/static/front/img/balls'
const REMARK_ICON = 'https://wver.sprintstaticdata.com/v230/static/front/img/icons/remark.png'

function fmtAmt(n) {
  const v = Number(n) || 0
  if (v >= 100000) return `${v / 100000}L`
  if (v >= 1000) return `${v / 1000}K`
  return String(v)
}

function isSusp(item) {
  return !item || item.gstatus === 'SUSPENDED' || item.gstatus === '0'
}

// sid 1-9 = Run 2..Run 10; ballNum = sid + 1. Left: sid 1-5 (balls 2-6,
// range id minmax0-4), Right: sid 6-9 (balls 7-10, range id minmaxr0-3).
function ScoreBox({ item, ballNum, rangeId, onBet }) {
  const [open, setOpen] = useState(false)
  const susp = isSusp(item)
  return (
    <div className="score-box">
      <div className="team-score"><div></div> <div></div></div>
      {' '}
      <div className="ball-icon"><img src={`${ADMIN_BALLS}/ball${ballNum}.png`} /></div>
      {' '}
      <div className={`blbox${susp ? ' suspended' : ''}`}>
        <div className="back" onClick={susp ? undefined : () => onBet(item.sid, 'back', item.b, item)}>
          <span className="odds d-block">{item?.b ?? 0}</span>
        </div>
        {' '}
        <div className="lay" onClick={susp ? undefined : () => onBet(item.sid, 'lay', item.l, item)}>
          <span className="odds d-block">{item?.l ?? 0}</span>
        </div>
      </div>
      {' '}
      <div className="c20minmax">
        <i
          data-toggle="collapse"
          data-target={`#${rangeId}`}
          aria-expanded={open ? 'true' : 'false'}
          className={`fas fa-info-circle float-right${open ? '' : ' collapsed'}`}
          onClick={() => setOpen((v) => !v)}
        ></i>
        {' '}
        <div id={rangeId} className={`icon-range collapse${open ? ' show' : ''}`}>
          {'\n                        R:'}
          <span>{fmtAmt(item?.min ?? 100)}</span>
          -
          <span>{fmtAmt(item?.max ?? 300000)}</span>
        </div>
      </div>
    </div>
  )
}

// Cricket Match 20-20 — route slug cmatch20, API cmatch20. Table class cricket20.
// Single card overlay. Detail: teen20casino-container (teen20left sid 1-5 /
// teen20right sid 6-9, har box ScoreBox = team-score(empty) + ball-icon +
// blbox back/lay + c20minmax collapse R:100-3L) + casino-remark marquee.
// Rules icon. Strip cricket20lastresult ball<win>.png. Dual-strip (web video,
// mobile detail).
export default function CricketMatch20() {
  const isAuth = useSelector((s) => Boolean(s.auth.token))
  const [resultMid, setResultMid] = useState(null)
  const [showRules, setShowRules] = useState(false)
  const [showLr, setShowLr] = useState(true)
  const [showCards, setShowCards] = useState(true)
  const [isMobile, setIsMobile] = useState(() => typeof window !== 'undefined' && window.innerWidth < 768)

  useEffect(() => {
    const onResize = () => setIsMobile(window.innerWidth < 768)
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  const { data: gameData } = useCasinoGame(GAME_TYPE)
  const { data: lastResults = [], refetch: refetchLastResults } = useCasinoLastResults(GAME_TYPE)
  const { streamUrl } = useCasinoStream(GAME_TYPE)
  const { myBets } = useCasinoMyBets(GAME_TYPE, isAuth)

  const mid = gameData?.mid ?? ''
  const lt = gameData?.lt ?? 0
  const ft = gameData?.ft ?? 20
  const remark = gameData?.remark ?? ''
  const sub = gameData?.sub || []

  const codes = parseCards(gameData?.card || '')
  const card = codes[0] || '1'

  useEffect(() => {
    if (mid) refetchLastResults()
  }, [mid, refetchLastResults])

  const findBySid = (sid) => sub.find((s) => s.sid === sid || s.sid === String(sid))

  const resultsStrip = (
    <div className={`casino-video-last-results${showLr ? '' : ' hide-lr'}`}>
      {lastResults.map((r, i) => (
        <span key={i} className="cricket20lastresult" onClick={() => setResultMid(r.mid || null)}>
          <img src={`${FRONT_BALLS}/ball${String(r.win)}.png`} />
        </span>
      ))}
      {' '}
      <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
        {'\n    ...\n  '}
      </Link>
      {' '}
    </div>
  )

  return (
    <>
      <div className="center-main-container">
        <div className="center-content">
          <div className="casino-container">
            <div className="casino-table cricket20">

              <div className="casino-video">
                <div className="casino-video-title">
                  <span className="casino-name">{GAME_NAME}</span>
                  {' '}
                  <div className="casino-video-rid">Round ID: {mid}</div>
                </div>
                {' '}
                <div className="video-box-container">
                  <div className="video-box">
                    {streamUrl && <iframe src={streamUrl}></iframe>}
                  </div>
                </div>
                {' '}
                <div className={`casino-video-cards${card === '1' || !showCards ? ' hide-cards' : ''}`}>
                  <div className="casino-cards-shuffle" onClick={() => setShowCards((v) => !v)}>
                    <i className="fas fa-grip-lines-vertical"></i>
                  </div>
                  {' '}
                  <div className="casino-video-cards-container">
                    <span data-v-b64efdfa=""><img data-v-b64efdfa="" src={cardSrc(card)} /></span>
                  </div>
                </div>
                {' '}
                <CircularTimer timeLeft={lt} fullTime={ft} />
                {' '}
                <div className="casino-video-right-icons">
                  <div title="Home" className="casino-video-home-icon">
                    <Link to="/admin/casino/list" className="" style={{ color: 'var(--text-highlight)' }}>
                      <i className="fas fa-home"></i>
                    </Link>
                  </div>
                  {' '}
                  <div title="Rules" className="casino-video-rules-icon" onClick={() => setShowRules((v) => !v)}>
                    <i className="fas fa-info-circle"></i>
                  </div>
                  {' '}
                  <div title="Last Results" className="casino-video-lr-icon" onClick={() => setShowLr((v) => !v)}>
                    <i className={`fas ${showLr ? 'fa-chevron-circle-up' : 'fa-chevron-circle-down'}`}></i>
                  </div>
                </div>
                {' '}
                <div>{showRules && (
                  <div
                    id="casino-vieo-rules"
                    aria-modal="true"
                    className="casino-vieo-rules show d-none-small show-rules"
                    style={{ display: 'block' }}
                  >
                    <div className="rules-header">
                      <div>Rules</div>
                      {' '}
                      <i className="fas fa-times" onClick={() => setShowRules(false)}></i>
                    </div>
                    {' '}
                    <div className="rules-body">
                      <CasinoRulesSwitch gameType={GAME_TYPE} />
                    </div>
                  </div>
                )}</div>
                {' '}
                {/* web: strip video ke andar */}
                {!isMobile && resultsStrip}
              </div>
              {' '}
              <div className="casino-detail">
                <div className="teen20casino-container">
                  <div className="teen20left">
                    {[1, 2, 3, 4, 5].map((sid, i) => (
                      <ScoreBox key={sid} item={findBySid(sid)} ballNum={sid + 1} rangeId={`minmax${i}`} onBet={() => {}} />
                    ))}
                  </div>
                  <div className="teen20right">
                    {[6, 7, 8, 9].map((sid, i) => (
                      <ScoreBox key={sid} item={findBySid(sid)} ballNum={sid + 1} rangeId={`minmaxr${i}`} onBet={() => {}} />
                    ))}
                  </div>
                </div>
                {' '}
                <div className="casino-remark mt-3">
                  <div className="remark-icon"><img src={REMARK_ICON} /></div>
                  {' '}
                  <marquee>{remark}</marquee>
                </div>
                {' '}
                {/* mobile: strip remark ke baad */}
                {isMobile && resultsStrip}
              </div>

            </div>
          </div>
        </div>
        {' '}
        <CasinoMyBetsSidebar myBets={myBets} gameName={GAME_TYPE} />
      </div>

      <CasinoRulesModal
        show={showRules}
        onClose={() => setShowRules(false)}
        tableClass=""
        gameType={GAME_TYPE}
      >
        <CasinoRulesSwitch gameType={GAME_TYPE} />
      </CasinoRulesModal>

      <CasinoResultModal
        show={!!resultMid}
        onClose={() => setResultMid(null)}
        gameType={GAME_TYPE}
        gameName={GAME_NAME}
        mid={resultMid}
      />
    </>
  )
}
