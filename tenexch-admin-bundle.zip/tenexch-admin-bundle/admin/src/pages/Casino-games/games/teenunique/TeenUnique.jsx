import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { CircularTimer } from '../../../../components/casino/CasinoTimer'
import CasinoMyBetsSidebar from '../../../../components/casino/CasinoMyBetsSidebar'
import CasinoResultModal from '../../../../components/casino/CasinoResultModal'
import CasinoRulesModal from '../../../../components/casino/CasinoRulesModal'
import CasinoRulesSwitch from '../../../../components/casino/rules/CasinoRulesSwitch'
import useCasinoGame from '../../../../hooks/casino/useCasinoGame'
import useCasinoLastResults from '../../../../hooks/casino/useCasinoLastResults'
import useCasinoMyBets from '../../../../hooks/casino/useCasinoMyBets'
import useCasinoStream from '../../../../hooks/casino/useCasinoStream'
import { cardSrc } from '../../../../components/casino/cards/cardUtils'
import useCardStripToggle from '../../../../hooks/casino/useCardStripToggle'
import { formatUniqueTeenNation } from '../../../../utils/casinoUtils'

const GAME_TYPE = 'teenunique'
const GAME_NAME = 'Unique Teenpatti'

// Unique Teenpatti — admin reference: casino-table unique-teenpatti; rid DIV
// single-line; cards overlay me 6 card slots (har card apna div, partial deal
// me face-down '1' bhi dikhte hain, API card = "5DD,5SS,1,1,1,1"); right icons
// me SIRF Rules; casino-detail me last-results strip SIRF web pe (mobile pe
// casino-detail khali — reference: mobile <!----> <!---->, web me R strip).
export default function TeenUnique() {
  const isAuth = useSelector((s) => Boolean(s.auth.token))
  const [showRules, setShowRules] = useState(false)
  const [resultMid, setResultMid] = useState(null)
  const [isMobile, setIsMobile] = useState(() => typeof window !== 'undefined' && window.innerWidth < 768)

  useEffect(() => {
    const onResize = () => setIsMobile(window.innerWidth < 768)
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  const { data: gameData } = useCasinoGame(GAME_TYPE)
  const { data: lastResults = [], refetch: refetchLastResults } = useCasinoLastResults(GAME_TYPE)
  const { streamUrl } = useCasinoStream(GAME_TYPE)
  const { myBets } = useCasinoMyBets(GAME_TYPE, isAuth)

  const mid = gameData?.mid ?? ''
  const [stripCollapsed, toggleStrip] = useCardStripToggle(mid)
  const lt = gameData?.lt ?? 0
  const ft = gameData?.ft ?? 30

  useEffect(() => {
    if (mid) refetchLastResults()
  }, [mid, refetchLastResults])

  // reference hamesha 6 slot dikhata hai — parse karke 6 tak pad karo
  const parsed = String(gameData?.card || '')
    .split(',')
    .map((c) => c.trim())
    .filter(Boolean)
  const cards = Array.from({ length: 6 }, (_, i) => parsed[i] || '1')
  const hasCards = cards.some((c) => c && c !== '1' && c !== '0')

  return (
    <>
      <div className="center-main-container">
        <div className="center-content">
          <div className="casino-container">
            <div className="casino-table unique-teenpatti">

              <div className="casino-video">
                <div className="casino-video-title">
                  <span className="casino-name">{GAME_NAME}</span>
                  {' '}
                  <div className="casino-video-rid">Round ID: {mid}</div>
                </div>
                {' '}
                <div className="video-box-container">
                  <div className="video-box">
                    {streamUrl && <iframe src={streamUrl}></iframe>}
                  </div>
                </div>
                {' '}
                <div className={`casino-video-cards${hasCards && !stripCollapsed ? '' : ' hide-cards'}`}>
                  <div className="casino-cards-shuffle" role="button" style={{ cursor: 'pointer' }} onClick={toggleStrip}>
                    <i className="fas fa-grip-lines-vertical"></i>
                  </div>
                  {' '}
                  <div className="casino-video-cards-container">
                    {cards.map((c, i) => (
                      <div key={i}>
                        <span data-v-b64efdfa="">
                          <img data-v-b64efdfa="" src={cardSrc(c)} />
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
                {' '}
                <CircularTimer timeLeft={lt} fullTime={ft} />
                {' '}
                <div className="casino-video-right-icons">
                  <div title="Rules" className="casino-video-rules-icon" onClick={() => setShowRules((v) => !v)}>
                    <i className="fas fa-info-circle"></i>
                  </div>
                </div>
                {' '}
                <div>{showRules && (
                  <div
                    id="casino-vieo-rules"
                    aria-modal="true"
                    className="casino-vieo-rules show d-none-small show-rules"
                    style={{ display: 'block' }}
                  >
                    <div className="rules-header">
                      <div>Rules</div>
                      {' '}
                      <i className="fas fa-times" onClick={() => setShowRules(false)}></i>
                    </div>
                    {' '}
                    <div className="rules-body">
                      <CasinoRulesSwitch gameType={GAME_TYPE} />
                    </div>
                  </div>
                )}</div>
              </div>
              {' '}
              <div className="casino-detail">
                {' '}
                {/* last-results strip SIRF web pe (reference: mobile casino-detail khali) */}
                {!isMobile && (
                  <div className="casino-video-last-results">
                    {lastResults.map((r, i) => (
                      <span key={i} className="resulttie" onClick={() => setResultMid(r.mid || null)}>R</span>
                    ))}
                    {' '}
                    <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
                      {'\n    ...\n  '}
                    </Link>
                    {' '}
                  </div>
                )}
              </div>

            </div>
          </div>
        </div>
        {' '}
        {/* "Your card 234", as the reference (stored "234"). */}
        <CasinoMyBetsSidebar myBets={myBets} gameName={GAME_TYPE} formatNation={formatUniqueTeenNation} />
      </div>

      <CasinoRulesModal
        show={showRules}
        onClose={() => setShowRules(false)}
        tableClass=""
        gameType={GAME_TYPE}
      >
        <CasinoRulesSwitch gameType={GAME_TYPE} />
      </CasinoRulesModal>

      <CasinoResultModal
        show={!!resultMid}
        onClose={() => setResultMid(null)}
        gameType={GAME_TYPE}
        gameName={GAME_NAME}
        mid={resultMid}
      />
    </>
  )
}
