import { TeenOneDayBase } from '../teenpattioneday/TeenOneDay'

// Premium Teenpatti 1-day — /admin/pcasino/pteen (Premium Casino list).
// Reference DOM (capture tenexch.com-admin-pcasino-pteen, 2026-09-19): the
// Teenpatti 1-day page as is — .casino-table.teenpatti1day, iframe stream,
// 2x3 card overlay, circular timer, Home / Rules / Last Results icons,
// BetTableTeen1Day (Main, Consecutive, Card 1-6 Odd/Even; R:1K-2L from the
// feed), A/B strip, sidebar My Bets only. Feed pteen = teen's 18-row shape
// (verified live). Only the type, the title and the Home link differ.
export default function PTeen() {
  return <TeenOneDayBase gameType="pteen" gameName="Premium Teenpatti 1-day" homePath="/admin/pcasino/list" />
}
