import { Lucky7Base } from '../lucky7/Lucky7'

// Premium Lucky 7 — /admin/pcasino/plucky7 (Premium Casino list).
// Reference DOM (capture tenexch.com-admin-pcasino-plucky7, 2026-09-20) = the
// lucky7 page: .casino-table.lucky7, iframe stream, one-card overlay with
// hide-cards while face-down, circular timer, Home / Rules / Last Results,
// BetTableLucky7 (ranges from the feed: 1K-2L / 50K / 10K), strip L / H, sidebar
// My Bets only, no remark. Feed plucky7 = lucky7's 23 rows (verified live).
export default function PLucky7() {
  return <Lucky7Base gameType="plucky7" gameName="Premium Lucky 7" homePath="/admin/pcasino/list" />
}
