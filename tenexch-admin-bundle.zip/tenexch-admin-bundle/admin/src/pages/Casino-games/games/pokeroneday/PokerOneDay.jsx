import { Fragment, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { CircularTimer } from '../../../../components/casino/CasinoTimer'
import BetTablePokerOneDay from '../../../../components/casino/BetTablePokerOneDay'
import CasinoMyBetsSidebar from '../../../../components/casino/CasinoMyBetsSidebar'
import CasinoResultModal from '../../../../components/casino/CasinoResultModal'
import CasinoRulesModal from '../../../../components/casino/CasinoRulesModal'
import CasinoRulesSwitch from '../../../../components/casino/rules/CasinoRulesSwitch'
import useCasinoGame from '../../../../hooks/casino/useCasinoGame'
import useCasinoLastResults from '../../../../hooks/casino/useCasinoLastResults'
import useCasinoMyBets from '../../../../hooks/casino/useCasinoMyBets'
import useCasinoStream from '../../../../hooks/casino/useCasinoStream'
import { computeAdminBook, getMarketsForGame } from '../../../../utils/casinoBook'
import { cardSrc, parseCards } from '../../../../components/casino/cards/cardUtils'

const GAME_TYPE = 'poker'
const GAME_NAME = 'Poker 1-Day'

// sidebar My Bets card ke neeche Bonus payouts card (reference: 2 tables)
const bonusRulesCard = (
  <div className="card m-b-10">
    <div className="card-header">
      <h6 className="card-title d-inline-block">
        {'\n          Rules\n          '}
      </h6>
    </div>
    {' '}
    <div className="card-body" style={{ padding: '10px' }}>
      <table className="table table-bordered rules-table">
        <tbody>
          <tr className="text-center"><th colSpan="2">Bonus 1 (2 Cards Bonus)</th></tr>
          <tr><td width="60%">Pair (2-10)</td><td>1 TO 3</td></tr>
          <tr><td width="60%">A/Q or A/J Off Suited</td><td>1 TO 5</td></tr>
          <tr><td width="60%">Pair (JQK)</td><td>1 TO 10</td></tr>
          <tr><td width="60%">A/K Off Suited</td><td>1 TO 15</td></tr>
          <tr><td width="60%">A/Q or A/J Suited</td><td>1 TO 20</td></tr>
          <tr><td width="60%">A/K Suited</td><td>1 TO 25</td></tr>
          <tr><td width="60%">A/A</td><td>1 TO 30</td></tr>
        </tbody>
      </table>
      <table className="table table-bordered rules-table">
        <tbody>
          <tr className="text-center"><th colSpan="2">Bonus 2 (7 Cards Bonus)</th></tr>
          <tr><td width="60%">Three of a Kind</td><td>1 TO 3</td></tr>
          <tr><td width="60%">Straight</td><td>1 TO 4</td></tr>
          <tr><td width="60%">Flush</td><td>1 TO 6</td></tr>
          <tr><td width="60%">Full House</td><td>1 TO 8</td></tr>
          <tr><td width="60%">Four of a Kind</td><td>1 TO 30</td></tr>
          <tr><td width="60%">Straight Flush</td><td>1 TO 50</td></tr>
          <tr><td width="60%">Royal Flush</td><td>1 TO 100</td></tr>
        </tbody>
      </table>
    </div>
  </div>
)

// Poker 1-Day — route slug pokeroneday, API type poker. Table poker1day.
// Video: Board 5 cards (codes[4-8]). Detail: BetTablePokerOneDay (Player A/B
// back/lay + 2/7 Cards Bonus, A/B hole cards codes[0,1]/[2,3], remark). Strip
// A/B. Mobile strip casino-detail bottom (video wala d-none-small).
export default function PokerOneDay() {
  const isAuth = useSelector((s) => Boolean(s.auth.token))
  const [resultMid, setResultMid] = useState(null)
  const [showRules, setShowRules] = useState(false)
  const [showLr, setShowLr] = useState(true)
  const [showCards, setShowCards] = useState(true)

  const { data: gameData } = useCasinoGame(GAME_TYPE)
  const { data: lastResults = [], refetch: refetchLastResults } = useCasinoLastResults(GAME_TYPE)
  const { streamUrl } = useCasinoStream(GAME_TYPE)
  const { myBets } = useCasinoMyBets(GAME_TYPE, isAuth)

  const mid = gameData?.mid ?? ''
  const lt = gameData?.lt ?? 0
  const ft = gameData?.ft ?? 30

  const exposures = computeAdminBook(myBets, getMarketsForGame(GAME_TYPE, gameData))

  const codes = parseCards(gameData?.card || '')
  const board = [codes[4] || '1', codes[5] || '1', codes[6] || '1', codes[7] || '1', codes[8] || '1']

  useEffect(() => {
    if (mid) refetchLastResults()
  }, [mid, refetchLastResults])

  const renderResult = (r, i) => (
    String(r.win) === '1'
      ? <span key={i} className="resulta" onClick={() => setResultMid(r.mid || null)}>{'A '}</span>
      : <span key={i} className="resultb" onClick={() => setResultMid(r.mid || null)}>{' B '}</span>
  )

  return (
    <>
      <div className="center-main-container">
        <div className="center-content">
          <div className="casino-container">
            <div className="casino-table poker1day">

              <div className="casino-video">
                <div className="casino-video-title">
                  <span className="casino-name">{GAME_NAME}</span>
                  {' '}
                  <div className="casino-video-rid">Round ID: {mid}</div>
                </div>
                {' '}
                <div className="video-box-container">
                  <div className="video-box">
                    {streamUrl && <iframe src={streamUrl}></iframe>}
                  </div>
                </div>
                {' '}
                <div className={`casino-video-cards${showCards ? '' : ' hide-cards'}`}>
                  <div className="casino-cards-shuffle" onClick={() => setShowCards((v) => !v)}>
                    <i className="fas fa-grip-lines-vertical"></i>
                  </div>
                  {' '}
                  <div className="casino-video-cards-container">
                    <div className="playerboardcards">
                      <div className="dealer-name w-100 mb-1">Board</div>
                      {' '}
                      <div className="d-flex">
                        {board.map((code, i) => (
                          <Fragment key={i}>
                            {i > 0 && ' '}
                            <span data-v-b64efdfa="">
                              <img data-v-b64efdfa="" src={cardSrc(code)} />
                            </span>
                          </Fragment>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
                {' '}
                <CircularTimer timeLeft={lt} fullTime={ft} />
                {' '}
                <div className="casino-video-right-icons">
                  <div title="Home" className="casino-video-home-icon">
                    <Link to="/admin/casino/list" className="" style={{ color: 'var(--text-highlight)' }}>
                      <i className="fas fa-home"></i>
                    </Link>
                  </div>
                  {' '}
                  <div title="Rules" className="casino-video-rules-icon" onClick={() => setShowRules((v) => !v)}>
                    <i className="fas fa-info-circle"></i>
                  </div>
                  {' '}
                  <div title="Last Results" className="casino-video-lr-icon" onClick={() => setShowLr((v) => !v)}>
                    <i className={`fas ${showLr ? 'fa-chevron-circle-up' : 'fa-chevron-circle-down'}`}></i>
                  </div>
                </div>
                {' '}
                <div>{showRules && (
                  <div
                    id="casino-vieo-rules"
                    aria-modal="true"
                    className="casino-vieo-rules show d-none-small show-rules"
                    style={{ display: 'block' }}
                  >
                    <div className="rules-header">
                      <div>Rules</div>
                      {' '}
                      <i className="fas fa-times" onClick={() => setShowRules(false)}></i>
                    </div>
                    {' '}
                    <div className="rules-body">
                      <CasinoRulesSwitch gameType={GAME_TYPE} />
                    </div>
                  </div>
                )}</div>
                {' '}
                {/* web: strip video me (mobile pe hidden) */}
                <div className={`casino-video-last-results d-none-small${showLr ? '' : ' hide-lr'}`}>
                  {lastResults.map(renderResult)}
                  {' '}
                  <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
                    {'\n    ...\n  '}
                  </Link>
                  {' '}
                </div>
              </div>
              {' '}
              <div className="casino-detail">
                <BetTablePokerOneDay
                  gameData={gameData}
                  onBet={() => {}}
                  exposures={exposures}
                />
                {' '}
                {/* mobile: strip casino-detail ke bottom me (video wala d-none-small).
                    d-none-big (hidden >= 768px) is the exact complement of the
                    video strip's d-none-small; d-none-desktop only hid it at
                    >= 1280px, so 768-1279px showed the strip twice. */}
                <div className="casino-video-last-results d-none-big">
                  {lastResults.map(renderResult)}
                  {' '}
                  <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
                    {'\n    ...\n  '}
                  </Link>
                </div>
              </div>

            </div>
          </div>
        </div>
        {' '}
        <CasinoMyBetsSidebar myBets={myBets} gameName={GAME_TYPE} extra={bonusRulesCard} />
      </div>

      <CasinoRulesModal
        show={showRules}
        onClose={() => setShowRules(false)}
        tableClass=""
        gameType={GAME_TYPE}
      >
        <CasinoRulesSwitch gameType={GAME_TYPE} />
      </CasinoRulesModal>

      <CasinoResultModal
        show={!!resultMid}
        onClose={() => setResultMid(null)}
        gameType={GAME_TYPE}
        gameName={GAME_NAME}
        mid={resultMid}
      />
    </>
  )
}
