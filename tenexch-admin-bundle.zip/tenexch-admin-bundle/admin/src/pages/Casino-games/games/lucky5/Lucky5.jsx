import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { CircularTimer } from '../../../../components/casino/CasinoTimer'
import BetTableLucky6 from '../../../../components/casino/BetTableLucky6'
import CasinoMyBetsSidebar from '../../../../components/casino/CasinoMyBetsSidebar'
import CasinoResultModal from '../../../../components/casino/CasinoResultModal'
import CasinoRulesModal from '../../../../components/casino/CasinoRulesModal'
import CasinoRulesSwitch from '../../../../components/casino/rules/CasinoRulesSwitch'
import useCasinoGame from '../../../../hooks/casino/useCasinoGame'
import useCasinoLastResults from '../../../../hooks/casino/useCasinoLastResults'
import useCasinoMyBets from '../../../../hooks/casino/useCasinoMyBets'
import useCasinoStream from '../../../../hooks/casino/useCasinoStream'
import { computeAdminBook, getMarketsForGame } from '../../../../utils/casinoBook'
import useCardStripToggle from '../../../../hooks/casino/useCardStripToggle'

const GAME_TYPE = 'lucky5'
const GAME_NAME = 'Lucky 6'
const CARD_BASE = 'https://wver.sprintstaticdata.com/v230/static/front/img/cards'

// win code -> results strip span (1 Low, 2 High, 0 Tie)
const RESULT_SPANS = {
  1: { cls: 'resultlow', text: 'L ' },
  2: { cls: 'resulthigh', text: ' H ' },
  0: { cls: 'resulttie', text: ' T' },
}

// Lucky 6 (lucky5) — reference: casino-table lucky7; video pe shuffle icon +
// current card overlay (hide-cards jab card '1' face-down ho), results strip
// casino-detail ke andar sabse neeche.
export default function Lucky5() {
  const isAuth = useSelector((s) => Boolean(s.auth.token))
  const [resultMid, setResultMid] = useState(null)
  const [showRules, setShowRules] = useState(false)
  const [showLr, setShowLr] = useState(true)
  const [isMobile, setIsMobile] = useState(() => typeof window !== 'undefined' && window.innerWidth < 768)

  useEffect(() => {
    const onResize = () => setIsMobile(window.innerWidth < 768)
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  const { data: gameData } = useCasinoGame(GAME_TYPE)
  const { data: lastResults = [], refetch: refetchLastResults } = useCasinoLastResults(GAME_TYPE)
  const { streamUrl } = useCasinoStream(GAME_TYPE)
  const { myBets } = useCasinoMyBets(GAME_TYPE, isAuth)

  const mid = gameData?.mid ?? ''
  const [stripCollapsed, toggleStrip] = useCardStripToggle(mid)
  const lt = gameData?.lt ?? 0
  const ft = gameData?.ft ?? 20
  const card = String(gameData?.card || '1')

  const exposures = computeAdminBook(myBets, getMarketsForGame(GAME_TYPE, gameData))

  useEffect(() => {
    if (mid) refetchLastResults()
  }, [mid, refetchLastResults])

  // reference: desktop strip casino-video me (rules slot ke baad), phone pe
  // casino-detail ke andar sabse neeche
  const resultsStrip = (
    <div className={`casino-video-last-results${showLr ? '' : ' hide-lr'}`}>
      {lastResults.map((r, i) => {
        const cfg = RESULT_SPANS[Number(r.win)] || RESULT_SPANS[0]
        return (
          <span key={i} className={cfg.cls} onClick={() => setResultMid(r.mid || null)}>
            {cfg.text}
          </span>
        )
      })}
      {' '}
      <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
        {'\n    ...\n  '}
      </Link>
      {' '}
    </div>
  )

  return (
    <>
      <div className="center-main-container">
        <div className="center-content">
          <div className="casino-container">
            <div className="casino-table lucky7">

              <div className="casino-video">
                <div className="casino-video-title">
                  <span className="casino-name">{GAME_NAME}</span>
                  {' '}
                  <div className="casino-video-rid">
                    {'\n                Round ID: ' + mid + '\n              '}
                  </div>
                </div>
                {' '}
                <div className="video-box-container">
                  <div className="video-box">
                    {streamUrl && <iframe src={streamUrl}></iframe>}
                  </div>
                </div>
                {' '}
                <div className={`casino-video-cards${card === '1' || !card || stripCollapsed ? ' hide-cards' : ''}`}>
                  <div className="casino-cards-shuffle" role="button" style={{ cursor: 'pointer' }} onClick={toggleStrip}>
                    <i className="fas fa-grip-lines-vertical"></i>
                  </div>
                  {' '}
                  <div className="casino-video-cards-container">
                    <div>
                      <span data-v-b64efdfa="">
                        <img data-v-b64efdfa="" src={`${CARD_BASE}/${card}.png`} />
                      </span>
                    </div>
                  </div>
                </div>
                {' '}
                <CircularTimer timeLeft={lt} fullTime={ft} />
                {' '}
                <div className="casino-video-right-icons">
                  <div title="Home" className="casino-video-home-icon">
                    <Link to="/admin/casino/list" className="" style={{ color: 'var(--text-highlight)' }}>
                      <i className="fas fa-home"></i>
                    </Link>
                  </div>
                  {' '}
                  <div title="Rules" className="casino-video-rules-icon" onClick={() => setShowRules((v) => !v)}>
                    <i className="fas fa-info-circle"></i>
                  </div>
                  {' '}
                  <div title="Last Results" className="casino-video-lr-icon" onClick={() => setShowLr((v) => !v)}>
                    <i className={`fas ${showLr ? 'fa-chevron-circle-up' : 'fa-chevron-circle-down'}`}></i>
                  </div>
                </div>
                {' '}
                <div>{showRules && (
                <div
                  id="casino-vieo-rules"
                  aria-modal="true"
                  className="casino-vieo-rules show d-none-small show-rules"
                  style={{ display: 'block' }}
                >
                  <div className="rules-header">
                    <div>Rules</div>
                    {' '}
                    <i className="fas fa-times" onClick={() => setShowRules(false)}></i>
                  </div>
                  {' '}
                  <div className="rules-body">
                    <CasinoRulesSwitch gameType={GAME_TYPE} />
                  </div>
                </div>
              )}</div>
              {' '}
              {!isMobile && resultsStrip}
              </div>
              {' '}
              <div className="casino-detail">
                <BetTableLucky6
                  gameData={gameData}
                  onBet={() => {}}
                  exposures={exposures}
                />
                {' '}
                {isMobile && resultsStrip}
              </div>

            </div>
          </div>
        </div>
        {' '}
        <CasinoMyBetsSidebar myBets={myBets} gameName={GAME_TYPE} />
      </div>

      <CasinoRulesModal
        show={showRules}
        onClose={() => setShowRules(false)}
        tableClass=""
        gameType={GAME_TYPE}
      >
        <CasinoRulesSwitch gameType={GAME_TYPE} />
      </CasinoRulesModal>

      <CasinoResultModal
        show={!!resultMid}
        onClose={() => setResultMid(null)}
        gameType={GAME_TYPE}
        gameName={GAME_NAME}
        mid={resultMid}
      />
    </>
  )
}
