import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { CircularTimer } from '../../../../components/casino/CasinoTimer'
import BetTableCard32EU from '../../../../components/casino/BetTableCard32EU'
import Card32Cards from '../../../../components/casino/cards/Card32Cards'
import CasinoMyBetsSidebar from '../../../../components/casino/CasinoMyBetsSidebar'
import CasinoResultModal from '../../../../components/casino/CasinoResultModal'
import CasinoRulesModal from '../../../../components/casino/CasinoRulesModal'
import CasinoRulesSwitch from '../../../../components/casino/rules/CasinoRulesSwitch'
import useCasinoGame from '../../../../hooks/casino/useCasinoGame'
import useCasinoLastResults from '../../../../hooks/casino/useCasinoLastResults'
import useCasinoMyBets from '../../../../hooks/casino/useCasinoMyBets'
import useCasinoStream from '../../../../hooks/casino/useCasinoStream'
import { computeAdminBook, getMarketsForGame } from '../../../../utils/casinoBook'

const GAME_TYPE = 'card32eu'
const GAME_NAME = '32 Cards B'

// 32 Cards B — route slug card32b, API card32eu. Table class cards32b. Detail:
// BetTableCard32EU (desktop 2 containers: Winner back/lay + Odd/Even; colors +
// totals; then single-digit strip. Mobile single container stacked). Ranges
// #demo-winner/odd-evan/fancy1/fancy-18-19/single, book-black always. Video:
// Card32Cards overlay (4 players). Strip resultb = winning player number.
export default function Card32B() {
  const isAuth = useSelector((s) => Boolean(s.auth.token))
  const [resultMid, setResultMid] = useState(null)
  const [showRules, setShowRules] = useState(false)
  const [showLr, setShowLr] = useState(true)
  const [showCards, setShowCards] = useState(true)

  const { data: gameData } = useCasinoGame(GAME_TYPE)
  const { data: lastResults = [], refetch: refetchLastResults } = useCasinoLastResults(GAME_TYPE)
  const { streamUrl } = useCasinoStream(GAME_TYPE)
  const { myBets } = useCasinoMyBets(GAME_TYPE, isAuth)

  const mid = gameData?.mid ?? ''
  const lt = gameData?.lt ?? 0
  const ft = gameData?.ft ?? 30

  const exposures = computeAdminBook(myBets, getMarketsForGame(GAME_TYPE, gameData))

  // koi card dealt hai? (betting window me sab '1' → hide-cards)
  const hasCards = String(gameData?.card || '').split(',').some((c) => c.trim() && c.trim() !== '1' && c.trim() !== '0')

  useEffect(() => {
    if (mid) refetchLastResults()
  }, [mid, refetchLastResults])

  // win = winning sid (1-4) → Player 8-11 (sid + 7). All results resultb.
  const renderResult = (r, i) => {
    const n = Number(r.win)
    const label = n >= 1 && n <= 4 ? String(n + 7) : String(r.win ?? '')
    return <span key={i} className="resultb" onClick={() => setResultMid(r.mid || null)}>{label}</span>
  }

  return (
    <>
      <div className="center-main-container">
        <div className="center-content">
          <div className="casino-container">
            <div className="casino-table cards32b">

              <div className="casino-video">
                <div className="casino-video-title">
                  <span className="casino-name">{GAME_NAME}</span>
                  {' '}
                  <div className="casino-video-rid">Round ID: {mid}</div>
                </div>
                {' '}
                <div className="video-box-container">
                  <div className="video-box">
                    {streamUrl && <iframe src={streamUrl}></iframe>}
                  </div>
                </div>
                {' '}
                <div className={`casino-video-cards${showCards && hasCards ? '' : ' hide-cards'}`}>
                  <div className="casino-cards-shuffle" onClick={() => setShowCards((v) => !v)}>
                    <i className="fas fa-grip-lines-vertical"></i>
                  </div>
                  {' '}
                  <Card32Cards cardString={gameData?.card || ''} />
                </div>
                {' '}
                <CircularTimer timeLeft={lt} fullTime={ft} />
                {' '}
                <div className="casino-video-right-icons">
                  <div title="Home" className="casino-video-home-icon">
                    <Link to="/admin/casino/list" className="" style={{ color: 'var(--text-highlight)' }}>
                      <i className="fas fa-home"></i>
                    </Link>
                  </div>
                  {' '}
                  <div title="Rules" className="casino-video-rules-icon" onClick={() => setShowRules((v) => !v)}>
                    <i className="fas fa-info-circle"></i>
                  </div>
                  {' '}
                  <div title="Last Results" className="casino-video-lr-icon" onClick={() => setShowLr((v) => !v)}>
                    <i className={`fas ${showLr ? 'fa-chevron-circle-up' : 'fa-chevron-circle-down'}`}></i>
                  </div>
                </div>
                {' '}
                <div>{showRules && (
                  <div
                    id="casino-vieo-rules"
                    aria-modal="true"
                    className="casino-vieo-rules show d-none-small show-rules"
                    style={{ display: 'block' }}
                  >
                    <div className="rules-header">
                      <div>Rules</div>
                      {' '}
                      <i className="fas fa-times" onClick={() => setShowRules(false)}></i>
                    </div>
                    {' '}
                    <div className="rules-body">
                      <CasinoRulesSwitch gameType={GAME_TYPE} />
                    </div>
                  </div>
                )}</div>
                {' '}
                {/* web: strip video me (mobile pe hidden) */}
                <div className={`casino-video-last-results d-none-small${showLr ? '' : ' hide-lr'}`}>
                  {lastResults.map(renderResult)}
                  {' '}
                  <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
                    {'\n    ...\n  '}
                  </Link>
                  {' '}
                </div>
              </div>
              {' '}
              <div className="casino-detail">
                <BetTableCard32EU
                  gameData={gameData}
                  onBet={() => {}}
                  exposures={exposures}
                />
                {' '}
                {/* mobile: strip casino-detail ke bottom me (video wala d-none-small) */}
                <div className="casino-video-last-results d-none-desktop">
                  {lastResults.map(renderResult)}
                  {' '}
                  <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
                    {'\n    ...\n  '}
                  </Link>
                </div>
              </div>

            </div>
          </div>
        </div>
        {' '}
        <CasinoMyBetsSidebar myBets={myBets} gameName={GAME_TYPE} />
      </div>

      <CasinoRulesModal
        show={showRules}
        onClose={() => setShowRules(false)}
        tableClass=""
        gameType={GAME_TYPE}
      >
        <CasinoRulesSwitch gameType={GAME_TYPE} />
      </CasinoRulesModal>

      <CasinoResultModal
        show={!!resultMid}
        onClose={() => setResultMid(null)}
        gameType={GAME_TYPE}
        gameName={GAME_NAME}
        mid={resultMid}
      />
    </>
  )
}
