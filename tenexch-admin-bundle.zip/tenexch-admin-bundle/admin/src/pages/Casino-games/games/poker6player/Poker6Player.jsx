import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { CircularTimer } from '../../../../components/casino/CasinoTimer'
import BetTablePoker6 from '../../../../components/casino/BetTablePoker6'
import CasinoMyBetsSidebar from '../../../../components/casino/CasinoMyBetsSidebar'
import CasinoResultModal from '../../../../components/casino/CasinoResultModal'
import CasinoRulesModal from '../../../../components/casino/CasinoRulesModal'
import CasinoRulesSwitch from '../../../../components/casino/rules/CasinoRulesSwitch'
import useCasinoGame from '../../../../hooks/casino/useCasinoGame'
import useCasinoLastResults from '../../../../hooks/casino/useCasinoLastResults'
import useCasinoMyBets from '../../../../hooks/casino/useCasinoMyBets'
import useCasinoStream from '../../../../hooks/casino/useCasinoStream'
import { computeAdminBook, getMarketsForGame } from '../../../../utils/casinoBook'
import { cardSrc, parseCards } from '../../../../components/casino/cards/cardUtils'

const GAME_TYPE = 'poker6'
const GAME_NAME = 'Poker 6 Players'

// Poker 6 Players — route slug poker6player, API poker6. Table poker6player.
// Video: Board 5 cards (codes[12-16]). Detail: BetTablePoker6 (Hands/Pattern
// tabs on mobile, teen1dayleft/right on desktop). Player N cards = codes[2(N-1),
// 2(N-1)+1]. Strip resulttie player-number. Mobile strip casino-detail bottom.
export default function Poker6Player() {
  const isAuth = useSelector((s) => Boolean(s.auth.token))
  const [resultMid, setResultMid] = useState(null)
  const [showRules, setShowRules] = useState(false)
  const [showLr, setShowLr] = useState(true)
  const [showCards, setShowCards] = useState(true)

  const { data: gameData } = useCasinoGame(GAME_TYPE)
  const { data: lastResults = [], refetch: refetchLastResults } = useCasinoLastResults(GAME_TYPE)
  const { streamUrl } = useCasinoStream(GAME_TYPE)
  const { myBets } = useCasinoMyBets(GAME_TYPE, isAuth)

  const mid = gameData?.mid ?? ''
  const lt = gameData?.lt ?? 0
  const ft = gameData?.ft ?? 30

  const exposures = computeAdminBook(myBets, getMarketsForGame(GAME_TYPE, gameData))

  const codes = parseCards(gameData?.card || '')
  // sab card face-down ('1'/'0') → overlay band (reference: hide-cards)
  const hasCards = codes.some((c) => c && c !== '1' && c !== '0')
  const board = [codes[12] || '1', codes[13] || '1', codes[14] || '1', codes[15] || '1', codes[16] || '1']

  // Round-over board text from the feed's root rdesc (admin twin of the player
  // page frontend/src/pages/casino/Poker6.jsx). Live feed: "Player 5 Won ||
  // Pattern : Pair"; results API: "Player 5#Two pairs"; a draw is "Tie Game"
  // with no pattern. Winner before the separator (" Won" added if missing),
  // pattern after it with any "Pattern :" label stripped.
  const resultBoard = (() => {
    const raw = String(gameData?.rdesc || '').trim()
    if (!raw) return null
    const [whoRaw = '', handRaw = ''] = raw.split(/\s*(?:\|\||#)\s*/)
    const who = whoRaw.trim()
    const hand = handRaw.replace(/^pattern\s*:\s*/i, '').trim()
    if (!who) return null
    const winner = /^player\s+\d+$/i.test(who) ? `${who} Won` : who
    return { winner, pattern: hand }
  })()

  useEffect(() => {
    if (mid) refetchLastResults()
  }, [mid, refetchLastResults])

  const renderResult = (r, i) => (
    <span key={i} className="resulttie" onClick={() => setResultMid(r.mid || null)}>{String(r.win ?? '')}</span>
  )

  return (
    <>
      <div className="center-main-container">
        <div className="center-content">
          <div className="casino-container">
            <div className="casino-table poker6player">

              <div className="casino-video">
                <div className="casino-video-title">
                  <span className="casino-name">{GAME_NAME}</span>
                  {' '}
                  <div className="casino-video-rid">Round ID: {mid}</div>
                </div>
                {' '}
                <div className="video-box-container">
                  <div className="video-box">
                    {streamUrl && <iframe src={streamUrl}></iframe>}
                  </div>
                </div>
                {' '}
                <div className={`casino-video-cards${showCards && hasCards ? '' : ' hide-cards'}`}>
                  <div className="casino-cards-shuffle" onClick={() => setShowCards((v) => !v)}>
                    <i className="fas fa-grip-lines-vertical"></i>
                  </div>
                  {' '}
                  <div className="casino-video-cards-container">
                    <div>
                      {board.map((code, i) => (
                        <span key={i} data-v-b64efdfa=""><img data-v-b64efdfa="" src={cardSrc(code)} /></span>
                      ))}
                    </div>
                  </div>
                </div>
                {' '}
                <CircularTimer timeLeft={lt} fullTime={ft} />
                {' '}
                <div className="casino-video-right-icons">
                  <div title="Home" className="casino-video-home-icon">
                    <Link to="/admin/casino/list" className="" style={{ color: 'var(--text-highlight)' }}>
                      <i className="fas fa-home"></i>
                    </Link>
                  </div>
                  {' '}
                  <div title="Rules" className="casino-video-rules-icon" onClick={() => setShowRules((v) => !v)}>
                    <i className="fas fa-info-circle"></i>
                  </div>
                  {' '}
                  <div title="Last Results" className="casino-video-lr-icon" onClick={() => setShowLr((v) => !v)}>
                    <i className={`fas ${showLr ? 'fa-chevron-circle-up' : 'fa-chevron-circle-down'}`}></i>
                  </div>
                </div>
                {' '}
                <div>{showRules && (
                  <div
                    id="casino-vieo-rules"
                    aria-modal="true"
                    className="casino-vieo-rules show d-none-small show-rules"
                    style={{ display: 'block' }}
                  >
                    <div className="rules-header">
                      <div>Rules</div>
                      {' '}
                      <i className="fas fa-times" onClick={() => setShowRules(false)}></i>
                    </div>
                    {' '}
                    <div className="rules-body">
                      <CasinoRulesSwitch gameType={GAME_TYPE} />
                    </div>
                  </div>
                )}</div>
                {' '}
                {/* web: strip video me (mobile pe hidden) */}
                <div className={`casino-video-last-results d-none-small${showLr ? '' : ' hide-lr'}`}>
                  {lastResults.map(renderResult)}
                  {' '}
                  <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
                    {'\n    ...\n  '}
                  </Link>
                  {' '}
                </div>
              </div>
              {' '}
              <div className="casino-detail">
                {/* Round-over board (reference admin, 2026-10-13): div.poker-result-board
                    > [span "Player 5 Won"] [b "Pattern : Two pairs"], first child of
                    .casino-detail; style.css already styles it. */}
                {resultBoard && (
                  <div className="poker-result-board">
                    <div className="d-inline-block">
                      <div className="d-inline-block"><span>{resultBoard.winner}</span></div>
                    </div>
                    {resultBoard.pattern && (
                      <div className="d-inline-block ml-2"><b>Pattern : {resultBoard.pattern}</b></div>
                    )}
                  </div>
                )}
                <BetTablePoker6
                  gameData={gameData}
                  onBet={() => {}}
                  exposures={exposures}
                />
                {' '}
                {/* mobile: strip casino-detail ke bottom me (video wala d-none-small) */}
                <div className="casino-video-last-results d-none-desktop">
                  {lastResults.map(renderResult)}
                  {' '}
                  <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
                    {'\n    ...\n  '}
                  </Link>
                </div>
              </div>

            </div>
          </div>
        </div>
        {' '}
        <CasinoMyBetsSidebar myBets={myBets} gameName={GAME_TYPE} />
      </div>

      <CasinoRulesModal
        show={showRules}
        onClose={() => setShowRules(false)}
        tableClass=""
        gameType={GAME_TYPE}
      >
        <CasinoRulesSwitch gameType={GAME_TYPE} />
      </CasinoRulesModal>

      <CasinoResultModal
        show={!!resultMid}
        onClose={() => setResultMid(null)}
        gameType={GAME_TYPE}
        gameName={GAME_NAME}
        mid={resultMid}
      />
    </>
  )
}
