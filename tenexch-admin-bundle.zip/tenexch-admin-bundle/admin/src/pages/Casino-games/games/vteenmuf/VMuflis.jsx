import { Fragment } from 'react'
import BetTableVMuflis from '../../../../components/casino/BetTableVMuflis'
import VCasinoTable from '../../../../components/casino/VCasinoTable'
import Top9RulesCard from '../../../../components/casino/Top9RulesCard'
import { computeAdminBook, getMarketsForGame } from '../../../../utils/casinoBook'
import { cardSrc } from '../../../../components/casino/cards/cardUtils'

const GAME_TYPE = 'vteenmuf'
const GAME_NAME = 'V-Muflis Teenpatti'

// Overlay: `.player-card.playera-card` / `.playerb-card` — label
// (`.w-100.playera|playerb.mb-2`) + three cards each. Feed `card` is six
// codes dealt alternately (A B A B A B — the split MuflisResult and the
// non-virtual Muflis page use); face-down = 1.png, shown as the reference does.
const PLAYERS = [
  { key: 'a', label: 'Player A', cls: 'playera', idx: [0, 2, 4] },
  { key: 'b', label: 'Player B', cls: 'playerb', idx: [1, 3, 5] },
]

const renderCards = (gameData) => {
  const cards = String(gameData?.card || '').split(',').map((c) => c.trim())
  return PLAYERS.map((p, pi) => (
    <Fragment key={p.key}>
      {pi > 0 && ' '}
      <div className={`player-card ${p.cls}-card`}>
      {' '}
      <div className={`w-100 ${p.cls} mb-2`}>{p.label}</div>
      {p.idx.map((i) => (
        <Fragment key={i}>
          {' '}
          <span data-v-b64efdfa="">
            <img data-v-b64efdfa="" src={cardSrc(cards[i])} />
          </span>
        </Fragment>
      ))}
    </div>
    </Fragment>
  ))
}

// last-results `win` 1 → A (resulta), 2 → B (resultb); capture strip
// B A A A B B A B A A.
const renderResult = (r, i, onClick) => (
  Number(r.win) === 2
    ? <span key={i} className="resultb" onClick={onClick}>B</span>
    : <span key={i} className="resulta" onClick={onClick}>A</span>
)

// V-Muflis Teenpatti — /admin/vcasino/teenmuf. Reference DOM (capture
// 2026-09-19): shell VCasinoTable (.casino-table.vcasino.vmuflis), board
// BetTableVMuflis; sidebar My Bets + Top 9 Rules card (capture). Book: getMarketsForGame (every selection etype fancy →
// its own market, as the non-virtual teenmuf page).
export default function VMuflis() {
  return (
    <VCasinoTable
      gameType={GAME_TYPE}
      gameName={GAME_NAME}
      tableClass="vmuflis"
      cards={renderCards}
      renderResult={renderResult}
      sidebarExtra={<Top9RulesCard />}
    >
      {(gameData, myBets) => (
        <BetTableVMuflis
          gameData={gameData}
          exposures={computeAdminBook(myBets, getMarketsForGame(GAME_TYPE, gameData))}
        />
      )}
    </VCasinoTable>
  )
}
