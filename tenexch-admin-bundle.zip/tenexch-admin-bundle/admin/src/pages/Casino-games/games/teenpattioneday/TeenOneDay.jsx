import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { CircularTimer } from '../../../../components/casino/CasinoTimer'
import BetTableTeen1Day from '../../../../components/casino/BetTableTeen1Day'
import CasinoMyBetsSidebar from '../../../../components/casino/CasinoMyBetsSidebar'
import CasinoResultModal from '../../../../components/casino/CasinoResultModal'
import CasinoRulesModal from '../../../../components/casino/CasinoRulesModal'
import CasinoRulesSwitch from '../../../../components/casino/rules/CasinoRulesSwitch'
import useCasinoGame from '../../../../hooks/casino/useCasinoGame'
import useCasinoLastResults from '../../../../hooks/casino/useCasinoLastResults'
import useCasinoMyBets from '../../../../hooks/casino/useCasinoMyBets'
import useCasinoStream from '../../../../hooks/casino/useCasinoStream'
import { applyAdminLineBook, computeAdminBook, getMarketsForGame } from '../../../../utils/casinoBook'
import { formatTeenOneDayNation } from '../../../../utils/casinoUtils'
import { cardSrc } from '../../../../components/casino/cards/cardUtils'
import useCardStripToggle from '../../../../hooks/casino/useCardStripToggle'

const DEFAULT_GAME_TYPE = 'teen'
const DEFAULT_GAME_NAME = 'Teenpatti 1-day'
const DEFAULT_HOME = '/admin/casino/list'

// Teenpatti 1-day — route slug teenpattioneday, API type teen. Table
// teenpatti1day. BetTableTeen1Day: Player A/B Main + Consecutive, Card 1-6
// Odd/Even (teen1dayother) — desktop d-none-small + mobile d-none-big. Cards
// A=0,2,4 / B=1,3,5 (B facedown '1'). Strip A/B. Koi remark nahi. Mobile pe
// strip casino-detail ke bottom me (video wala d-none-small).
//
// TeenOneDayBase: the same page for the Premium twin — /admin/pcasino/pteen
// (reference capture 2026-09-19: identical DOM, name "Premium Teenpatti 1-day",
// feed pteen, Home icon → its own list). Default export = Teenpatti 1-day.
export function TeenOneDayBase({
  gameType = DEFAULT_GAME_TYPE,
  gameName = DEFAULT_GAME_NAME,
  homePath = DEFAULT_HOME,
}) {
  const GAME_TYPE = gameType
  const GAME_NAME = gameName
  const isAuth = useSelector((s) => Boolean(s.auth.token))
  const [resultMid, setResultMid] = useState(null)
  const [showRules, setShowRules] = useState(false)
  const [showLr, setShowLr] = useState(true)

  const { data: gameData } = useCasinoGame(GAME_TYPE)
  const { data: lastResults = [], refetch: refetchLastResults } = useCasinoLastResults(GAME_TYPE)
  const { streamUrl } = useCasinoStream(GAME_TYPE)
  const { myBets } = useCasinoMyBets(GAME_TYPE, isAuth)

  const mid = gameData?.mid ?? ''
  const [stripCollapsed, toggleStrip] = useCardStripToggle(mid)
  const lt = gameData?.lt ?? 0
  const ft = gameData?.ft ?? 45

  // Odd / Even bets are stored as "Card N Odd" / "Card N Even" — no feed runner
  // carries that name, so computeAdminBook skips them; book them per exact
  // selection (admin worst case, like Note Number) for the board's Odd/Even cells.
  // Consecutive bets carry the Main runner names ("Player A" / "Player B", mtype
  // "fancy" — feed etype fancy1), so computeAdminBook fell back to the Main market
  // and added them to it: back A + back B @1.98 showed 12, not 2 (reference, user
  // 2026-10-13). Keep only Main bets (mtype "match") on the Main book.
  const isConsecutiveBet = (b) =>
    /^Player [AB]$/.test(String(b.selection || b.player_name || '').trim()) &&
    String(b.mtype || 'match').toLowerCase() !== 'match'
  const exposures = applyAdminLineBook(
    computeAdminBook(myBets.filter((b) => !isConsecutiveBet(b)), getMarketsForGame(GAME_TYPE, gameData)),
    myBets.filter((b) => /^Card \d+ (Odd|Even)$/i.test(String(b.selection || b.player_name || '').trim())),
  )
  // Consecutive: one YES/NO line per player (server teen:conA / teen:conB) — back
  // + lay on the same player net, A and B separate. Admin worst case per line,
  // written on the row's sid (the board reads `sid:` first). Back 100 @2.43 +
  // lay 100 @2.53 on a player → min(+10, 0) = 0, as the reference admin shows.
  ;(gameData?.sub || []).filter((r) => r.subtype === 'con').forEach((r) => {
    const line = applyAdminLineBook({}, myBets.filter((b) => isConsecutiveBet(b) && String(b.selection || '').trim() === r.nat))
    exposures[`sid:${r.sid}`] = line[r.nat] ?? 0
  })


  const cards = String(gameData?.card || '').split(',').map((c) => c.trim())
  const cardsA = [cards[0], cards[2], cards[4]].map((c) => c || '1')
  const cardsB = [cards[1], cards[3], cards[5]].map((c) => c || '1')
  // Reference collapses the panel (hide-cards) while every card is face-down.
  const allFaceDown = [...cardsA, ...cardsB].every((c) => c === '1' || c === '0')

  useEffect(() => {
    if (mid) refetchLastResults()
  }, [mid, refetchLastResults])

  const cardSpan = (code, i) => (
    <span key={i} data-v-b64efdfa="">
      <img data-v-b64efdfa="" src={cardSrc(code)} />
    </span>
  )

  const renderResult = (r, i) => (
    String(r.win) === '1'
      ? <span key={i} className="resulta" onClick={() => setResultMid(r.mid || null)}>{'A '}</span>
      : <span key={i} className="resultb" onClick={() => setResultMid(r.mid || null)}>{' B '}</span>
  )

  return (
    <>
      <div className="center-main-container">
        <div className="center-content">
          <div className="casino-container">
            <div className="casino-table teenpatti1day">

              <div className="casino-video">
                <div className="casino-video-title">
                  <span className="casino-name">{GAME_NAME}</span>
                  {' '}
                  <span className="casino-video-rid">Round ID: {mid}</span>
                </div>
                {' '}
                <div className="video-box-container">
                  <div className="video-box">
                    {streamUrl && <iframe src={streamUrl}></iframe>}
                  </div>
                </div>
                {' '}
                <div className={`casino-video-cards${allFaceDown || stripCollapsed ? ' hide-cards' : ''}`}>
                  <div className="casino-cards-shuffle" role="button" style={{ cursor: 'pointer' }} onClick={toggleStrip}>
                    <i className="fas fa-grip-lines-vertical"></i>
                  </div>
                  {' '}
                  <div className="casino-video-cards-container">
                    <div>{cardsA.map((c, i) => cardSpan(c, i))}</div>
                    {' '}
                    <div>{cardsB.map((c, i) => cardSpan(c, i))}</div>
                  </div>
                </div>
                {' '}
                <CircularTimer timeLeft={lt} fullTime={ft} />
                {' '}
                <div className="casino-video-right-icons">
                  <div title="Home" className="casino-video-home-icon">
                    <Link to={homePath} className="" style={{ color: 'var(--text-highlight)' }}>
                      <i className="fas fa-home"></i>
                    </Link>
                  </div>
                  {' '}
                  <div title="Rules" className="casino-video-rules-icon" onClick={() => setShowRules((v) => !v)}>
                    <i className="fas fa-info-circle"></i>
                  </div>
                  {' '}
                  <div title="Last Results" className="casino-video-lr-icon" onClick={() => setShowLr((v) => !v)}>
                    <i className={`fas ${showLr ? 'fa-chevron-circle-up' : 'fa-chevron-circle-down'}`}></i>
                  </div>
                </div>
                {' '}
                <div>{showRules && (
                  <div
                    id="casino-vieo-rules"
                    aria-modal="true"
                    className="casino-vieo-rules show d-none-small show-rules"
                    style={{ display: 'block' }}
                  >
                    <div className="rules-header">
                      <div>Rules</div>
                      {' '}
                      <i className="fas fa-times" onClick={() => setShowRules(false)}></i>
                    </div>
                    {' '}
                    <div className="rules-body">
                      <CasinoRulesSwitch gameType={GAME_TYPE} />
                    </div>
                  </div>
                )}</div>
                {' '}
                <div className={`casino-video-last-results d-none-small${showLr ? '' : ' hide-lr'}`}>
                  {lastResults.map(renderResult)}
                  {' '}
                  <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
                    {'\n    ...\n  '}
                  </Link>
                  {' '}
                </div>
              </div>
              {' '}
              <div className="casino-detail">
                <BetTableTeen1Day
                  gameData={gameData}
                  onBet={() => {}}
                  exposures={exposures}
                />
                {' '}
                {/* mobile: strip casino-detail ke bottom me (video wala d-none-small) */}
                <div className="casino-video-last-results d-none-desktop">
                  {lastResults.map(renderResult)}
                  {' '}
                  <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
                    {'\n    ...\n  '}
                  </Link>
                </div>
              </div>

            </div>
          </div>
        </div>
        {' '}
        <CasinoMyBetsSidebar myBets={myBets} gameName={GAME_TYPE} formatNation={(n, b) => formatTeenOneDayNation(n, b)} />
      </div>

      <CasinoRulesModal
        show={showRules}
        onClose={() => setShowRules(false)}
        tableClass=""
        gameType={GAME_TYPE}
      >
        <CasinoRulesSwitch gameType={GAME_TYPE} />
      </CasinoRulesModal>

      <CasinoResultModal
        show={!!resultMid}
        onClose={() => setResultMid(null)}
        gameType={GAME_TYPE}
        gameName={GAME_NAME}
        mid={resultMid}
      />
    </>
  )
}

export default function TeenOneDay() {
  return <TeenOneDayBase />
}
