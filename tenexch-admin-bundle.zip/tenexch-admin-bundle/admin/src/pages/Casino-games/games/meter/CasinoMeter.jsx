import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { CircularTimer } from '../../../../components/casino/CasinoTimer'
import CasinoMyBetsSidebar from '../../../../components/casino/CasinoMyBetsSidebar'
import CasinoResultModal from '../../../../components/casino/CasinoResultModal'
import CasinoRulesModal from '../../../../components/casino/CasinoRulesModal'
import CasinoRulesSwitch from '../../../../components/casino/rules/CasinoRulesSwitch'
import useCasinoGame from '../../../../hooks/casino/useCasinoGame'
import useCasinoLastResults from '../../../../hooks/casino/useCasinoLastResults'
import useCasinoMyBets from '../../../../hooks/casino/useCasinoMyBets'
import useCasinoStream from '../../../../hooks/casino/useCasinoStream'
import { computeAdminBook, getMarketsForGame, roundBook, fmtBook } from '../../../../utils/casinoBook'
import { cardSrc } from '../../../../components/casino/cards/cardUtils'

const GAME_TYPE = 'cmeter'
const GAME_NAME = 'Casino Meter'

const LOW_CARDS = ['A', '2', '3', '4', '5', '6', '7', '8', '9']
const CARD_VALUES = { A: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8, 9: 9, 10: 10, J: 11, Q: 12, K: 13 }

function extractRank(code) {
  if (!code || code === '1') return null
  const m = String(code).match(/^(\d+|[AJQK])/)
  return m ? m[1] : null
}

function fmtAmt(n) {
  const v = Number(n) || 0
  if (v >= 100000) return `${v / 100000}L`
  if (v >= 1000) return `${v / 1000}K`
  return String(v)
}

function bookOf(exposures, name, sid) {
  return roundBook(exposures?.[`sid:${sid}`] ?? exposures?.[name] ?? 0)
}
function bookCls(v) {
  return v < 0 ? 'book-red' : v > 0 ? 'book-green' : 'book-black'
}

function MeterCard({ code }) {
  return (
    <div className="casino-card-item">
      <div className="card-image">
        <span data-v-b64efdfa=""><img data-v-b64efdfa="" src={cardSrc(code)} /></span>
      </div>
    </div>
  )
}

// Casino Meter — route slug meter, API cmeter. Table class cmeter. Minimal:
// video + Low/High dealt-card columns (teen1day layout) + strip (koi betting
// grid nahi). card = 11 comma-codes ('1' = empty); Low column low-value cards
// (A-9), High column (10/J/Q/K); total = card values ka sum. min-max R:10-25K
// + book. Rules icon. Strip resultb win 1→L / else H. Dual-strip.
export default function CasinoMeter() {
  const isAuth = useSelector((s) => Boolean(s.auth.token))
  const [resultMid, setResultMid] = useState(null)
  const [showRules, setShowRules] = useState(false)
  const [showLr, setShowLr] = useState(true)
  const [isMobile, setIsMobile] = useState(() => typeof window !== 'undefined' && window.innerWidth < 768)

  useEffect(() => {
    const onResize = () => setIsMobile(window.innerWidth < 768)
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  const { data: gameData } = useCasinoGame(GAME_TYPE)
  const { data: lastResults = [], refetch: refetchLastResults } = useCasinoLastResults(GAME_TYPE)
  const { streamUrl } = useCasinoStream(GAME_TYPE)
  const { myBets } = useCasinoMyBets(GAME_TYPE, isAuth)

  const mid = gameData?.mid ?? ''
  const lt = gameData?.lt ?? 0
  const ft = gameData?.ft ?? 3
  const card = gameData?.card ?? ''
  const sub = gameData?.sub || []

  const lowItem = sub.find((s) => s.sid === 1 || s.sid === '1')
  const highItem = sub.find((s) => s.sid === 2 || s.sid === '2')

  const exposures = computeAdminBook(myBets, getMarketsForGame(GAME_TYPE, gameData))

  useEffect(() => {
    if (mid) refetchLastResults()
  }, [mid, refetchLastResults])

  const { cells, lowTotal, highTotal, hasCards } = useMemo(() => {
    const codes = String(card || '').split(',')
    let lt2 = 0
    let ht = 0
    let any = false
    const cs = codes.map((code) => {
      const rank = extractRank(code)
      if (!rank) return { code, low: false, high: false }
      any = true
      const low = LOW_CARDS.includes(rank)
      const val = CARD_VALUES[rank] || 0
      if (low) lt2 += val
      else ht += val
      return { code, low, high: !low }
    })
    return { cells: cs, lowTotal: lt2, highTotal: ht, hasCards: any }
  }, [card])

  const lowBook = bookOf(exposures, lowItem?.nat, lowItem?.sid ?? 1)
  const highBook = bookOf(exposures, highItem?.nat, highItem?.sid ?? 2)

  const resultsStrip = (
    <div className={`casino-video-last-results${showLr ? '' : ' hide-lr'}`}>
      {lastResults.map((r, i) => {
        const isLow = String(r.win) === '1'
        return (
          <span key={i} className="resultb" onClick={() => setResultMid(r.mid || null)}>
            {isLow ? 'L ' : ' H '}
          </span>
        )
      })}
      {' '}
      <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
        {'\n    ...\n  '}
      </Link>
      {' '}
    </div>
  )

  const minMax = (book, item) => (
    <div className="casino-min-max">
      <span className={`casino-book ${bookCls(book)}`}>{fmtBook(book)}</span>
      {' '}
      <span className="float-right">
        R:
        <span>{fmtAmt(item?.min ?? 10)}</span>
        -
        <span>{fmtAmt(item?.max ?? 25000)}</span>
      </span>
    </div>
  )

  return (
    <>
      <div className="center-main-container">
        <div className="center-content">
          <div className="casino-container">
            <div className="casino-table cmeter">

              <div className="casino-video">
                <div className="casino-video-title">
                  <span className="casino-name">{GAME_NAME}</span>
                  {' '}
                  <div className="casino-video-rid">Round ID: {mid}</div>
                </div>
                {' '}
                <div className="video-box-container">
                  <div className="video-box">
                    {streamUrl && <iframe src={streamUrl}></iframe>}
                  </div>
                </div>
                {' '}
                <CircularTimer timeLeft={lt} fullTime={ft} />
                {' '}
                <div className="casino-video-right-icons">
                  <div title="Home" className="casino-video-home-icon">
                    <Link to="/admin/casino/list" className="" style={{ color: 'var(--text-highlight)' }}>
                      <i className="fas fa-home"></i>
                    </Link>
                  </div>
                  {' '}
                  <div title="Rules" className="casino-video-rules-icon" onClick={() => setShowRules((v) => !v)}>
                    <i className="fas fa-info-circle"></i>
                  </div>
                  {' '}
                  <div title="Last Results" className="casino-video-lr-icon" onClick={() => setShowLr((v) => !v)}>
                    <i className={`fas ${showLr ? 'fa-chevron-circle-up' : 'fa-chevron-circle-down'}`}></i>
                  </div>
                </div>
                {' '}
                <div>{showRules && (
                  <div
                    id="casino-vieo-rules"
                    aria-modal="true"
                    className="casino-vieo-rules show d-none-small show-rules"
                    style={{ display: 'block' }}
                  >
                    <div className="rules-header">
                      <div>Rules</div>
                      {' '}
                      <i className="fas fa-times" onClick={() => setShowRules(false)}></i>
                    </div>
                    {' '}
                    <div className="rules-body">
                      <CasinoRulesSwitch gameType={GAME_TYPE} />
                    </div>
                  </div>
                )}</div>
                {' '}
                {/* web: strip video ke andar */}
                {!isMobile && resultsStrip}
              </div>
              {' '}
              <div className="casino-detail">
                <div className="teen1daycasino-container">
                  <div className="teen1dayleft">
                    <div className="text-center">
                      <b className="text-playerb">Low</b>
                      {' '}
                      <span className="text-success ml-2">{hasCards ? lowTotal : ''}</span>
                    </div>
                    {' '}
                    <div className="w-100">
                      <div className="casino-cards text-center mt-1">
                        {cells.map((c, i) => (c.low ? <MeterCard key={i} code={c.code} /> : null))}
                      </div>
                      {' '}
                      {minMax(lowBook, lowItem)}
                    </div>
                  </div>
                  {' '}
                  <div className="teen1daycenter"></div>
                  {' '}
                  <div className="teen1dayright">
                    <div className="text-center">
                      <b className="text-playerb">High</b>
                      {' '}
                      <span className="text-success ml-2">{hasCards ? highTotal : ''}</span>
                    </div>
                    {' '}
                    <div className="w-100">
                      <div className="casino-cards text-center mt-1">
                        {cells.map((c, i) => (c.high ? <MeterCard key={i} code={c.code} /> : null))}
                      </div>
                      {' '}
                      {minMax(highBook, highItem)}
                    </div>
                  </div>
                </div>
                {' '}
                {/* mobile: strip detail ke andar */}
                {isMobile && resultsStrip}
              </div>

            </div>
          </div>
        </div>
        {' '}
        <CasinoMyBetsSidebar myBets={myBets} gameName={GAME_TYPE} />
      </div>

      <CasinoRulesModal
        show={showRules}
        onClose={() => setShowRules(false)}
        tableClass=""
        gameType={GAME_TYPE}
      >
        <CasinoRulesSwitch gameType={GAME_TYPE} />
      </CasinoRulesModal>

      <CasinoResultModal
        show={!!resultMid}
        onClose={() => setResultMid(null)}
        gameType={GAME_TYPE}
        gameName={GAME_NAME}
        mid={resultMid}
      />
    </>
  )
}
