import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { CircularTimer } from '../../../../components/casino/CasinoTimer'
import BetTableSicBo2 from '../../../../components/casino/BetTableSicBo2'
import CasinoMyBetsSidebar from '../../../../components/casino/CasinoMyBetsSidebar'
import CasinoResultModal from '../../../../components/casino/CasinoResultModal'
import CasinoRulesModal from '../../../../components/casino/CasinoRulesModal'
import CasinoRulesSwitch from '../../../../components/casino/rules/CasinoRulesSwitch'
import useCasinoGame from '../../../../hooks/casino/useCasinoGame'
import useCasinoLastResults from '../../../../hooks/casino/useCasinoLastResults'
import useCasinoMyBets from '../../../../hooks/casino/useCasinoMyBets'
import useCasinoStream from '../../../../hooks/casino/useCasinoStream'
import { formatBetOdds, formatStake } from '../../../../utils/casinoUtils'

const GAME_TYPE = 'sicbo2'
const GAME_NAME = 'Sic Bo 2'

// Sic Bo 2 (sicbo2) — casino-table sicbo. Static dice board: BetTableSicBo2 khud
// casino-detail (d-none d-xl-block desktop + d-xl-none mobile) render karta hai.
// rid `casino-video-rid` DIV hai (span nahi), cards nahi. Strip web-only
// (d-none-small) — mobile me reference me strip hai hi nahi. Result number = win
// (3 dice ka total, e.g. 18/12/11), sab resultb.
export default function SicBo2() {
  const isAuth = useSelector((s) => Boolean(s.auth.token))
  const [resultMid, setResultMid] = useState(null)
  const [showRules, setShowRules] = useState(false)
  const [showLr, setShowLr] = useState(true)

  const { data: gameData } = useCasinoGame(GAME_TYPE)
  const { data: lastResults = [], refetch: refetchLastResults } = useCasinoLastResults(GAME_TYPE)
  const { streamUrl } = useCasinoStream(GAME_TYPE)
  const { myBets } = useCasinoMyBets(GAME_TYPE, isAuth)

  const mid = gameData?.mid ?? ''
  const lt = gameData?.lt ?? 0
  const ft = gameData?.ft ?? 25

  useEffect(() => {
    if (mid) refetchLastResults()
  }, [mid, refetchLastResults])

  return (
    <>
      <div className="center-main-container">
        <div className="center-content">
          <div className="casino-container">
            <div className="casino-table sicbo">

              <div className="casino-video">
                <div className="casino-video-title">
                  <span className="casino-name">{GAME_NAME}</span>
                  {' '}
                  <div className="casino-video-rid">
                    {'\n                Round ID: ' + mid + '\n              '}
                  </div>
                </div>
                {' '}
                <div className="video-box-container">
                  <div className="video-box">
                    {streamUrl && <iframe src={streamUrl}></iframe>}
                  </div>
                </div>
                {' '}
                <CircularTimer timeLeft={lt} fullTime={ft} />
                {' '}
                <div className="casino-video-right-icons">
                  <div title="Home" className="casino-video-home-icon">
                    <Link to="/admin/casino/list" className="" style={{ color: 'var(--text-highlight)' }}>
                      <i className="fas fa-home"></i>
                    </Link>
                  </div>
                  {' '}
                  <div title="Rules" className="casino-video-rules-icon" onClick={() => setShowRules((v) => !v)}>
                    <i className="fas fa-info-circle"></i>
                  </div>
                  {' '}
                  <div title="Last Results" className="casino-video-lr-icon" onClick={() => setShowLr((v) => !v)}>
                    <i className={`fas ${showLr ? 'fa-chevron-circle-up' : 'fa-chevron-circle-down'}`}></i>
                  </div>
                </div>
              </div>
              {' '}
              <div>{showRules && (
                <div
                  id="casino-vieo-rules"
                  aria-modal="true"
                  className="casino-vieo-rules show d-none-small show-rules"
                  style={{ display: 'block' }}
                >
                  <div className="rules-header">
                    <div>Rules</div>
                    {' '}
                    <i className="fas fa-times" onClick={() => setShowRules(false)}></i>
                  </div>
                  {' '}
                  <div className="rules-body">
                    <CasinoRulesSwitch gameType={GAME_TYPE} />
                  </div>
                </div>
              )}</div>
              {' '}
              {/* strip web-only (reference mobile me strip nahi) — dice total */}
              <div className={`casino-video-last-results d-none-small${showLr ? '' : ' hide-lr'}`}>
                {lastResults.map((r, i) => (
                  <span key={i} className="resultb" onClick={() => setResultMid(r.mid || null)}>
                    {String(r.win ?? r.result ?? '')}
                  </span>
                ))}
                {' '}
                <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
                  {'\n    ...\n  '}
                </Link>
                {' '}
              </div>
              {' '}
              <BetTableSicBo2 gameData={gameData} onBet={() => {}} />

            </div>
          </div>
        </div>
        {' '}
        <CasinoMyBetsSidebar myBets={myBets} gameName={GAME_TYPE} formatOdds={(b) => formatBetOdds(GAME_TYPE, b, formatStake(b.odds ?? b.rate))} />
      </div>

      <CasinoRulesModal
        show={showRules}
        onClose={() => setShowRules(false)}
        tableClass=""
        gameType={GAME_TYPE}
      >
        <CasinoRulesSwitch gameType={GAME_TYPE} />
      </CasinoRulesModal>

      <CasinoResultModal
        show={!!resultMid}
        onClose={() => setResultMid(null)}
        gameType={GAME_TYPE}
        gameName={GAME_NAME}
        mid={resultMid}
      />
    </>
  )
}
