import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { CircularTimer } from '../../../../components/casino/CasinoTimer'
import BetTableTeen20b from '../../../../components/casino/BetTableTeen20b'
import CasinoMyBetsSidebar from '../../../../components/casino/CasinoMyBetsSidebar'
import CasinoResultModal from '../../../../components/casino/CasinoResultModal'
import CasinoRulesModal from '../../../../components/casino/CasinoRulesModal'
import CasinoRulesSwitch from '../../../../components/casino/rules/CasinoRulesSwitch'
import useCasinoGame from '../../../../hooks/casino/useCasinoGame'
import useCasinoLastResults from '../../../../hooks/casino/useCasinoLastResults'
import useCasinoMyBets from '../../../../hooks/casino/useCasinoMyBets'
import useCasinoStream from '../../../../hooks/casino/useCasinoStream'
import { computeAdminBook, getMarketsForGame } from '../../../../utils/casinoBook'
import { cardSrc } from '../../../../components/casino/cards/cardUtils'
import useCardStripToggle from '../../../../hooks/casino/useCardStripToggle'

// route slug teenpattit20b, API type teen20b
const GAME_TYPE = 'teen20b'
const GAME_NAME = '20-20 Teenpatti B'

// static Pair Plus Rules card (sidebar)
const PAIR_PLUS_RULES = [
  ['Pair', '1 TO 1'],
  ['Flush', '1 TO 4'],
  ['Straight', '1 TO 6'],
  ['Trio', '1 TO 30'],
  ['Straight Flush', '1 TO 40'],
]

// 20-20 Teenpatti B — table teenpatti20. Video: 2x3 card overlay (A=0,2,4 /
// B=1,3,5). Detail: BetTableTeen20b (web teen20left/right + mobile stack).
// Sidebar: my-bets + Pair Plus Rules. Strip A/B (web video me, mobile detail me).
export default function Teen20b() {
  const isAuth = useSelector((s) => Boolean(s.auth.token))
  const [resultMid, setResultMid] = useState(null)
  const [showRules, setShowRules] = useState(false)
  const [showLr, setShowLr] = useState(true)

  const { data: gameData } = useCasinoGame(GAME_TYPE)
  const { data: lastResults = [], refetch: refetchLastResults } = useCasinoLastResults(GAME_TYPE)
  const { streamUrl } = useCasinoStream(GAME_TYPE)
  const { myBets } = useCasinoMyBets(GAME_TYPE, isAuth)

  const mid = gameData?.mid ?? ''
  const [stripCollapsed, toggleStrip] = useCardStripToggle(mid)
  const lt = gameData?.lt ?? 0
  const ft = gameData?.ft ?? 25

  const exposures = computeAdminBook(myBets, getMarketsForGame(GAME_TYPE, gameData))

  const cards = String(gameData?.card || '').split(',').map((c) => c.trim())
  const cardsA = [cards[0], cards[2], cards[4]].map((c) => c || '1')
  const cardsB = [cards[1], cards[3], cards[5]].map((c) => c || '1')
  // betting window me sab '1' (face-down) → overlay band (reference: hide-cards)
  const hasCards = cards.some((c) => c && c !== '1' && c !== '0')

  useEffect(() => {
    if (mid) refetchLastResults()
  }, [mid, refetchLastResults])

  const cardSpan = (code, i) => (
    <span key={i} data-v-b64efdfa="">
      <img data-v-b64efdfa="" src={cardSrc(code)} />
    </span>
  )

  const renderResult = (r, i) => (
    String(r.win) === '1'
      ? <span key={i} className="resulta" onClick={() => setResultMid(r.mid || null)}>{'A '}</span>
      : <span key={i} className="resultb" onClick={() => setResultMid(r.mid || null)}>{' B '}</span>
  )

  const rulesCard = (
    <div className="card m-b-10">
      <div className="card-header">
        <h6 className="card-title d-inline-block">{'\n          Rules\n          '}</h6>
      </div>
      {' '}
      <div className="card-body" style={{ padding: '10px' }}>
        <table className="table table-bordered rules-table">
          <tbody>
            <tr className="text-center"><th colSpan="2">Pair Plus</th></tr>
            {PAIR_PLUS_RULES.map(([name, val]) => (
              <tr key={name}>
                <td width="60%">{name}</td><td>{val}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )

  return (
    <>
      <div className="center-main-container">
        <div className="center-content">
          <div className="casino-container">
            <div className="casino-table teenpatti20">

              <div className="casino-video">
                <div className="casino-video-title">
                  <span className="casino-name">{GAME_NAME}</span>
                  {' '}
                  <div className="casino-video-rid">Round ID: {mid}</div>
                </div>
                {' '}
                <div className="video-box-container">
                  <div className="video-box">
                    {streamUrl && <iframe src={streamUrl}></iframe>}
                  </div>
                </div>
                {' '}
                <div className={`casino-video-cards${hasCards && !stripCollapsed ? '' : ' hide-cards'}`}>
                  <div className="casino-cards-shuffle" role="button" style={{ cursor: 'pointer' }} onClick={toggleStrip}>
                    <i className="fas fa-grip-lines-vertical"></i>
                  </div>
                  {' '}
                  <div className="casino-video-cards-container">
                    <div>{cardsA.map((c, i) => cardSpan(c, i))}</div>
                    {' '}
                    <div>{cardsB.map((c, i) => cardSpan(c, i))}</div>
                  </div>
                </div>
                {' '}
                <CircularTimer timeLeft={lt} fullTime={ft} />
                {' '}
                <div className="casino-video-right-icons">
                  <div title="Home" className="casino-video-home-icon">
                    <Link to="/admin/casino/list" className="" style={{ color: 'var(--text-highlight)' }}>
                      <i className="fas fa-home"></i>
                    </Link>
                  </div>
                  {' '}
                  <div title="Rules" className="casino-video-rules-icon" onClick={() => setShowRules((v) => !v)}>
                    <i className="fas fa-info-circle"></i>
                  </div>
                  {' '}
                  <div title="Last Results" className="casino-video-lr-icon" onClick={() => setShowLr((v) => !v)}>
                    <i className={`fas ${showLr ? 'fa-chevron-circle-up' : 'fa-chevron-circle-down'}`}></i>
                  </div>
                </div>
                {' '}
                <div>{showRules && (
                  <div
                    id="casino-vieo-rules"
                    aria-modal="true"
                    className="casino-vieo-rules show d-none-small show-rules"
                    style={{ display: 'block' }}
                  >
                    <div className="rules-header">
                      <div>Rules</div>
                      {' '}
                      <i className="fas fa-times" onClick={() => setShowRules(false)}></i>
                    </div>
                    {' '}
                    <div className="rules-body">
                      <CasinoRulesSwitch gameType={GAME_TYPE} />
                    </div>
                  </div>
                )}</div>
                {' '}
                {/* web: strip video me (mobile pe hidden) */}
                <div className={`casino-video-last-results d-none-small${showLr ? '' : ' hide-lr'}`}>
                  {lastResults.map(renderResult)}
                  {' '}
                  <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
                    {'\n    ...\n  '}
                  </Link>
                  {' '}
                </div>
              </div>
              {' '}
              <div className="casino-detail">
                <BetTableTeen20b
                  gameData={gameData}
                  onBet={() => {}}
                  exposures={exposures}
                />
                {' '}
                {/* mobile: strip casino-detail ke bottom me (video wala d-none-small) */}
                <div className="casino-video-last-results d-none-desktop">
                  {lastResults.map(renderResult)}
                  {' '}
                  <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
                    {'\n    ...\n  '}
                  </Link>
                </div>
              </div>

            </div>
          </div>
        </div>
        {' '}
        <CasinoMyBetsSidebar myBets={myBets} gameName={GAME_TYPE} extra={rulesCard} />
      </div>

      <CasinoRulesModal
        show={showRules}
        onClose={() => setShowRules(false)}
        tableClass=""
        gameType={GAME_TYPE}
      >
        <CasinoRulesSwitch gameType={GAME_TYPE} />
      </CasinoRulesModal>

      <CasinoResultModal
        show={!!resultMid}
        onClose={() => setResultMid(null)}
        gameType={GAME_TYPE}
        gameName={GAME_NAME}
        mid={resultMid}
      />
    </>
  )
}
