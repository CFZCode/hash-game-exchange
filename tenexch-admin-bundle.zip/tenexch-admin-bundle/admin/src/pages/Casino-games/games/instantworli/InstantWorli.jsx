import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { CircularTimer } from '../../../../components/casino/CasinoTimer'
import CasinoMyBetsSidebar from '../../../../components/casino/CasinoMyBetsSidebar'
import CasinoResultModal from '../../../../components/casino/CasinoResultModal'
import useCasinoGame from '../../../../hooks/casino/useCasinoGame'
import useCasinoLastResults from '../../../../hooks/casino/useCasinoLastResults'
import useCasinoMyBets from '../../../../hooks/casino/useCasinoMyBets'
import useCasinoStream from '../../../../hooks/casino/useCasinoStream'
import { cardSrc, parseCards } from '../../../../components/casino/cards/cardUtils'
import { formatWorliNation, formatBetOdds, formatStake } from '../../../../utils/casinoUtils'

const GAME_TYPE = 'worli2'
const GAME_NAME = 'Instant Worli'

// Instant Worli — route slug instantworli, API worli2. Table class worli.
// Worli Matka jaisa minimal: video + 3-card overlay + strip (koi bet table/rules
// nahi). Web: strip video ke andar; mobile: strip sibling. Right-icons Home + LR.
export default function InstantWorli() {
  const isAuth = useSelector((s) => Boolean(s.auth.token))
  const [resultMid, setResultMid] = useState(null)
  const [showLr, setShowLr] = useState(true)
  const [showCards, setShowCards] = useState(true)
  const [isMobile, setIsMobile] = useState(() => typeof window !== 'undefined' && window.innerWidth < 768)

  useEffect(() => {
    const onResize = () => setIsMobile(window.innerWidth < 768)
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  const { data: gameData } = useCasinoGame(GAME_TYPE)
  const { data: lastResults = [], refetch: refetchLastResults } = useCasinoLastResults(GAME_TYPE)
  const { streamUrl } = useCasinoStream(GAME_TYPE)
  const { myBets } = useCasinoMyBets(GAME_TYPE, isAuth)

  const mid = gameData?.mid ?? ''
  const lt = gameData?.lt ?? 0
  const ft = gameData?.ft ?? 30

  const codes = parseCards(gameData?.card || '')
  // Reference: the card panel closes by itself once the round is over (new
  // round, feed card string back to 1,1,1) and reopens when cards are dealt.
  const hasCards = codes.some((c) => c && c !== '1')

  useEffect(() => {
    if (mid) refetchLastResults()
  }, [mid, refetchLastResults])

  const resultsStrip = (
    <div className={`casino-video-last-results${showLr ? '' : ' hide-lr'}`}>
      {lastResults.map((r, i) => (
        <span key={i} className="resultb" onClick={() => setResultMid(r.mid || null)}>R</span>
      ))}
      {' '}
      <Link to={`/admin/reports/casinoresult/${GAME_TYPE}`} className="result-more">
        {'\n    ...\n  '}
      </Link>
      {' '}
    </div>
  )

  return (
    <>
      <div className="center-main-container">
        <div className="center-content">
          <div className="casino-container">
            <div className="casino-table worli">

              <div className="casino-video">
                <div className="casino-video-title">
                  <span className="casino-name">{GAME_NAME}</span>
                  {' '}
                  <div className="casino-video-rid">Round ID: {mid}</div>
                </div>
                {' '}
                <div className="video-box-container">
                  <div className="video-box">
                    {streamUrl && <iframe src={streamUrl}></iframe>}
                  </div>
                </div>
                {' '}
                <div className={`casino-video-cards${showCards && hasCards ? '' : ' hide-cards'}`}>
                  <div className="casino-cards-shuffle" onClick={() => setShowCards((v) => !v)}>
                    <i className="fas fa-grip-lines-vertical"></i>
                  </div>
                  {' '}
                  <div className="casino-video-cards-container">
                    <div>
                      <span data-v-b64efdfa=""><img data-v-b64efdfa="" src={cardSrc(codes[0] || '1')} /></span>
                      {' '}
                      <span data-v-b64efdfa=""><img data-v-b64efdfa="" src={cardSrc(codes[1] || '1')} /></span>
                      {' '}
                      <span data-v-b64efdfa=""><img data-v-b64efdfa="" src={cardSrc(codes[2] || '1')} /></span>
                    </div>
                  </div>
                </div>
                {' '}
                <CircularTimer timeLeft={lt} fullTime={ft} />
                {' '}
                <div className="casino-video-right-icons">
                  <div title="Home" className="casino-video-home-icon">
                    <Link to="/admin/casino/list" className="" style={{ color: 'var(--text-highlight)' }}>
                      <i className="fas fa-home"></i>
                    </Link>
                  </div>
                  {' '}
                  <div title="Last Results" className="casino-video-lr-icon" onClick={() => setShowLr((v) => !v)}>
                    <i className={`fas ${showLr ? 'fa-chevron-circle-up' : 'fa-chevron-circle-down'}`}></i>
                  </div>
                </div>
                {' '}
                {/* web: strip video ke andar */}
                {!isMobile && resultsStrip}
              </div>
              {' '}
              {/* mobile: strip casino-video ke bahar sibling */}
              {isMobile && resultsStrip}

            </div>
          </div>
        </div>
        {' '}
        <CasinoMyBetsSidebar myBets={myBets} gameName={GAME_TYPE} formatNation={formatWorliNation} formatOdds={(b) => formatBetOdds(GAME_TYPE, b, formatStake(b.odds ?? b.rate))} />
      </div>

      <CasinoResultModal
        show={!!resultMid}
        onClose={() => setResultMid(null)}
        gameType={GAME_TYPE}
        gameName={GAME_NAME}
        mid={resultMid}
      />
    </>
  )
}
