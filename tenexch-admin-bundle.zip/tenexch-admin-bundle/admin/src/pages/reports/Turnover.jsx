import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import api from '../../services/api'
import ClientMultiselect from '../../components/ClientMultiselect'
import MxDatePicker from '../../components/MxDatePicker'
import LoaderOverlay from '../../components/LoaderOverlay'
import useExportLoader from '../../hooks/useExportLoader'
import { CASINO_LIST } from '../../config/casinoList'
import { SPORTS_LIST, GAME_TYPES } from '../../config/sportsList'

const toDateString = (d) => {
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

const defaultRange = () => {
  const today = new Date()
  const sevenDaysAgo = new Date()
  sevenDaysAgo.setDate(today.getDate() - 7)
  return [toDateString(sevenDaysAgo), toDateString(today)]
}

function Turnover() {
  const [clientName, setClientName] = useState('')
  // Excel button: page loader for a second, then the download (hooks/useExportLoader)
  const { exporting, withExportLoader } = useExportLoader()
  const [selectedUsername, setSelectedUsername] = useState('')
  const [selectedUserId, setSelectedUserId] = useState('')
  const [fromDate, setFromDate] = useState('')
  const [toDate, setToDate] = useState('')
  const [typeVal, setTypeVal] = useState('')
  const [casinoGame, setCasinoGame] = useState('')
  const [sportsListVal, setSportsListVal] = useState('')
  const [gameTypeVal, setGameTypeVal] = useState('')
  // Load without Type selected -> red is-invalid outline (live-clearing)
  const [typeInvalid, setTypeInvalid] = useState(false)
  // Sports type me sport list select karna compulsory hai
  const [sportsInvalid, setSportsInvalid] = useState(false)
  const [tableData, setTableData] = useState([])
  const [loading, setLoading] = useState(false)
  const [showLoader, setShowLoader] = useState(false)

  useEffect(() => {
    const [f, t] = defaultRange()
    setFromDate(f)
    setToDate(t)
  }, [])

  const fetchData = async () => {
    setLoading(true)
    try {
      const payload = {
        user_id: selectedUserId,
        type: typeVal === '2' ? 'casino' : 'sports',
        fromDate,
        toDate,
        ...(typeVal === '2'
          ? { game_name: casinoGame }
          : { sport_id: sportsListVal, gtype: gameTypeVal }),
      }
      const response = await api.post('/admin/reports/turnover', payload)
      const item = response.data
      if (item?.success) {
        setTableData([{
          lossTurnOver: item.loss_turnover ?? '-',
          loss: item.loss ?? '-',
          winTurnOver: item.win_turnover ?? '-',
          win: item.win ?? '-',
          totalTurnOver: item.total_turnover ?? '-',
          totalPL: item.total_pl ?? '-',
        }])
      } else {
        setTableData([])
      }
    } catch (err) {
      console.error('Error loading turnover report:', err)
      setTableData([])
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!typeVal) {
      setTypeInvalid(true)
      return
    }
    setTypeInvalid(false)
    if (typeVal === '1' && !sportsListVal) {
      setSportsInvalid(true)
      return
    }
    setSportsInvalid(false)
    setShowLoader(true)
    Promise.all([fetchData(), new Promise((r) => setTimeout(r, 1000))])
      .finally(() => setShowLoader(false))
  }

  const handleReset = () => {
    setClientName('')
    setSelectedUsername('')
    setSelectedUserId('')
    const [f, t] = defaultRange()
    setFromDate(f)
    setToDate(t)
    setTypeVal('')
    setCasinoGame('')
    setSportsListVal('')
    setGameTypeVal('')
    setTypeInvalid(false)
    setSportsInvalid(false)
    setShowLoader(true)
    setTimeout(() => {
      setTableData([])
      setShowLoader(false)
    }, 1000)
  }

  const EXPORT_COLS = ['Loss Turn Over', 'Loss', 'Win Turn Over', 'Win', 'Total Turn Over', 'Total P/L']
  const exportRows = () => tableData.map((r) => [r.lossTurnOver, r.loss, r.winTurnOver, r.win, r.totalTurnOver, r.totalPL])

  const handleExportExcel = () => {
    const head = EXPORT_COLS.map((c) => `<th>${c}</th>`).join('')
    const body = exportRows().map((r) => `<tr>${r.map((v) => `<td>${v}</td>`).join('')}</tr>`).join('')
    const html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="UTF-8"></head><body><table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></body></html>`
    const blob = new Blob([html], { type: 'application/vnd.ms-excel' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = 'turnover.xls'
    a.click()
    URL.revokeObjectURL(a.href)
  }

  const handleExportPdf = async () => {
    const { default: jsPDF } = await import('jspdf')
    const { default: autoTable } = await import('jspdf-autotable')
    const doc = new jsPDF('l', 'pt')
    const pageWidth = doc.internal.pageSize.getWidth()
    doc.setFontSize(14)
    doc.setTextColor(51, 51, 51)
    doc.text('Turnover Report', pageWidth / 2, 30, { align: 'center' })
    autoTable(doc, {
      head: [EXPORT_COLS],
      body: exportRows(),
      startY: 45,
      theme: 'striped',
      styles: { fontSize: 10, cellPadding: 6 },
      headStyles: { fillColor: [41, 128, 185], textColor: 255, fontStyle: 'bold', halign: 'left' },
      bodyStyles: { textColor: [85, 85, 85] },
    })
    doc.save('turnover.pdf')
  }

  return (
    <div data-v-5a10e370="">
      {(showLoader || exporting) && <LoaderOverlay />}
      <div data-v-5a10e370="">
          <div className="row">
            <div className="col-12">
              <div className="page-title-box d-flex align-items-center justify-content-between">
                <h4 className="mb-0 font-size-18">Turnover Report</h4>
                <div className="page-title-right">
                  <ol className="breadcrumb m-0">
                    <li className="breadcrumb-item">
                      <Link to="/admin/home" className="" target="_self">Home</Link>
                    </li>
                    <li className="breadcrumb-item active">
                      <span aria-current="location">Turnover Report</span>
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col-12">
              <div className="card">
                <div className="card-body">
                  <div role="alert" aria-live="polite" aria-atomic="true" className="alert alert-info">
                    <div direction="right">You will be able to see the data of last 7 days only.</div>
                  </div>
                  {' '}
                  <form method="post" data-vv-scope="toReport" className="ajaxFormSubmit" onSubmit={handleSubmit}>
                    <div className="row row5">
                      <div className="col-md-4 col-xl-2">
                        <div className="form-group user-lock-search" style={{ position: 'relative' }}>
                          <label htmlFor="d-inline-block">Search By Client Name</label>{' '}
                          <ClientMultiselect
                            value={clientName}
                            onChange={(v) => { setClientName(v); setSelectedUsername(''); setSelectedUserId('') }}
                            onSelect={(u) => { setClientName(u.username); setSelectedUsername(u.username); setSelectedUserId(u.user_id || u.wallet_id || '') }}
                          />
                        </div>
                      </div>
                      {' '}
                      <div className="col-md-2">
                        <label>From Date:</label>{' '}
                        <MxDatePicker value={fromDate} onChange={setFromDate} disableFuture />
                      </div>
                      {' '}
                      <div className="col-md-2">
                        <label>To Date:</label>{' '}
                        <MxDatePicker value={toDate} onChange={setToDate} disableFuture />
                      </div>
                      {' '}
                      <div className="col-md-4 col-xl-2">
                        <div className="form-group">
                          <label>Type</label>{' '}
                          <select name="type" className={`form-control${typeInvalid ? ' is-invalid' : ''}`} aria-required="true" aria-invalid={typeInvalid ? 'true' : 'false'} value={typeVal} onChange={(e) => { setTypeVal(e.target.value); setTypeInvalid(!e.target.value); setCasinoGame(''); setSportsListVal(''); setGameTypeVal(''); setSportsInvalid(false) }}>
                            <option value="">Select Type</option>
                            {' '}
                            <option value="1">Sports</option>
                            {' '}
                            <option value="2">Casino</option>
                          </select>
                        </div>
                      </div>
                      {typeVal === '1' && (
                        <>
                          {' '}
                          <div className="col-md-4 col-xl-2">
                            <div className="form-group">
                              <label>Sports List</label>{' '}
                              <select className={`form-control${sportsInvalid ? ' is-invalid' : ''}`} name="etid" aria-required="true" aria-invalid={sportsInvalid ? 'true' : 'false'} value={sportsListVal} onChange={(e) => { setSportsListVal(e.target.value); setSportsInvalid(!e.target.value) }}>
                                <option value="">Select Sports List</option>
                                {' '}
                                {SPORTS_LIST.map(([v, n]) => (
                                  <option key={v} value={v}>{n}</option>
                                ))}
                              </select>
                            </div>
                          </div>
                          {' '}
                          <div className="col-md-4 col-xl-2">
                            <div className="form-group">
                              <label>Game Type</label>{' '}
                              <select className="form-control" value={gameTypeVal} onChange={(e) => setGameTypeVal(e.target.value)}>
                                <option value="">Select Game Type</option>
                                {' '}
                                {GAME_TYPES.map(([v, n]) => (
                                  <option key={v} value={v}>{n}</option>
                                ))}
                              </select>
                            </div>
                          </div>
                        </>
                      )}
                      {typeVal === '2' && (
                        <>
                          {' '}
                          <div className="col-md-4 col-xl-2">
                            <div className="form-group">
                              <label>Casino List</label>{' '}
                              <select className="form-control" value={casinoGame} onChange={(e) => setCasinoGame(e.target.value)}>
                                <option value="">Select Casino</option>
                                {' '}
                                {CASINO_LIST.map(([v, n]) => (
                                  <option key={v} value={v}>{n}</option>
                                ))}
                              </select>
                            </div>
                          </div>
                        </>
                      )}
                    </div>
                    {' '}
                    <div className="row row5">
                      <div className="col-md-12 col-xl-3">
                        <button type="submit" id="loaddata" className="btn btn-primary">Load</button>
                        {' '}
                        <button type="button" id="reset" className="btn btn-light" onClick={handleReset}>Reset</button>
                        {' '}
                        <div className="d-inline-block ml-1">
                          <div id="export_1776320551636" className={`d-inline-block${tableData.length === 0 ? ' disabled' : ''}`}>
                            <button type="button" disabled={tableData.length === 0} className={`btn mr-1 btn-success${tableData.length === 0 ? ' disabled' : ''}`} onClick={withExportLoader(handleExportExcel)}><i className="fas fa-file-excel"></i></button>
                          </div>
                          {' '}
                          <button type="button" disabled={tableData.length === 0} className={`btn btn-danger${tableData.length === 0 ? ' disabled' : ''}`} onClick={handleExportPdf}><i className="fas fa-file-pdf"></i></button>
                        </div>
                      </div>
                    </div>
                  </form>
                  {' '}
                  <div className="table-responsive mb-0 mt-3">
                    <table className="table table-bordered">
                      <thead>
                        <tr>
                          <th className="text-right">Loss Turn Over</th>
                          {' '}
                          <th className="text-right">Loss</th>
                          {' '}
                          <th className="text-right">Win Turn Over</th>
                          {' '}
                          <th className="text-right">Win</th>
                          {' '}
                          <th className="text-right">Total Turn Over</th>
                          {' '}
                          <th className="text-right">Total P/L</th>
                        </tr>
                      </thead>
                      {' '}
                      <tbody>
                        {tableData.length === 0 ? (
                          <tr>
                            <td colSpan="6" className="text-center">{'\n                    There are no records to show\n                  '}</td>
                          </tr>
                        ) : (
                          tableData.map((r, idx) => (
                            <tr key={idx}>
                              {[r.lossTurnOver, r.loss, r.winTurnOver, r.win, r.totalTurnOver, r.totalPL].map((v, i) => (
                                <td key={i} className="text-right">{`\n                    ${v}\n                  `}</td>
                              ))}
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>
  )
}

export default Turnover
