import { useState, useEffect, useCallback } from 'react'
import { Link } from 'react-router-dom'
import { getStatementV2, getStatementBetExport, getStatementBetDetail } from '../../services/reportService'
import { getDetailResults } from '../../services/casinoService'
import LoaderOverlay from '../../components/LoaderOverlay'
import useExportLoader from '../../hooks/useExportLoader'
import MxDatePicker from '../../components/MxDatePicker'
import ClientMultiselect from '../../components/ClientMultiselect'
import Swal from 'sweetalert2'
import { CASINO_LIST } from '../../config/casinoList'
import { SPORTS_LIST, GAME_TYPES } from '../../config/sportsList'
import Pagination from '../../components/Pagination'
import StatementBetDetailModal from '../../components/StatementBetDetailModal'

const formatDate = (d) => {
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

const formatDisplay = (dateStr) => {
  if (!dateStr) return ''
  const d = new Date(dateStr)
  if (isNaN(d)) return dateStr
  return d.toLocaleString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }).replace(',', '')
}

const Toast = Swal.mixin({
  toast: true,
  position: 'top-end',
  showConfirmButton: false,
  timer: 3000,
  timerProgressBar: false,
})

function AccountStatement() {
  const [entriesPerPage, setEntriesPerPage] = useState(25)
  // Excel button: page loader for a second, then the download (hooks/useExportLoader)
  const { exporting, withExportLoader } = useExportLoader()
  const [searchValue, setSearchValue] = useState('')
  const [clientName, setClientName] = useState('')
  const [typeVal, setTypeVal] = useState('2')
  const [statementVal, setStatementVal] = useState('all')
  // Game Report extra hierarchy (reference shows these only for type 3)
  const [sportVal, setSportVal] = useState('0')
  const [gameTypeVal, setGameTypeVal] = useState('all')
  const [casinoVal, setCasinoVal] = useState('all')

  const [fromDate, setFromDate] = useState('')
  const [toDate, setToDate] = useState('')

  const [tableData, setTableData] = useState([])
  const [loading, setLoading] = useState(false)
  // Full-page loader only for explicit Load/Reset presses — the reference
  // does NOT show it on the initial page load
  const [showLoader, setShowLoader] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)


  useEffect(() => {
    const today = new Date()
    const weekAgo = new Date()
    weekAgo.setDate(today.getDate() - 7)
    setFromDate(formatDate(weekAgo))
    setToDate(formatDate(today))
  }, [])

  const fetchData = useCallback(async (page) => {
    if (!fromDate || !toDate) return
    // >10-day ranges never load (Load shows the notice toast instead)
    if ((new Date(`${toDate}T00:00:00`) - new Date(`${fromDate}T00:00:00`)) / 86400000 > 10) return
    setLoading(true)
    try {
      let reportType = 'ALL'
      if (typeVal === '2') reportType = 'TRANSACTION'
      else if (typeVal === '3') reportType = 'SPORTS'

      const response = await getStatementV2({
        reportType,
        clientName,
        fromDate,
        toDate,
        page,
        limit: entriesPerPage,
        statement: statementVal,
        sportId: sportVal,
        gameType: gameTypeVal,
        casinoType: casinoVal,
      })
      if (response.success) {
        setTableData(response.data || [])
        setTotalPages(response.totalPages || 1)
        if (response.currentPage && response.currentPage !== page) {
          setCurrentPage(response.currentPage)
        }
      } else {
        setTableData([])
        setTotalPages(1)
      }
    } catch (err) {
      console.error('Error loading account statement:', err)
      setTableData([])
      setTotalPages(1)
    } finally {
      setLoading(false)
    }
  }, [fromDate, toDate, entriesPerPage, clientName, typeVal, statementVal, sportVal, gameTypeVal, casinoVal])

  useEffect(() => {
    if (fromDate && toDate) fetchData(currentPage)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentPage, entriesPerPage])

  const handleLoad = (e) => {
    e.preventDefault()
    // Reference: ranges longer than 10 days only show the notice — no data loads
    const days = (new Date(`${toDate}T00:00:00`) - new Date(`${fromDate}T00:00:00`)) / 86400000
    if (days > 10) {
      Toast.fire({ icon: 'error', text: 'Sorry for inconvenience! You will see statement of 10 days date range in 3 months timeslot.' })
      setTableData([])
      setTotalPages(1)
      setCurrentPage(1)
      return
    }
    setCurrentPage(1)
    setShowLoader(true)
    Promise.all([fetchData(1), new Promise((r) => setTimeout(r, 1000))])
      .finally(() => setShowLoader(false))
  }

  const handleReset = () => {
    setClientName('')
    const today = new Date()
    const weekAgo = new Date()
    weekAgo.setDate(today.getDate() - 7)
    setFromDate(formatDate(weekAgo))
    setToDate(formatDate(today))
    setTypeVal('2')
    setStatementVal('all')
    setSportVal('0')
    setGameTypeVal('all')
    setCasinoVal('all')
    setSearchValue('')
    setCurrentPage(1)
    setShowLoader(true)
    setTimeout(() => {
      // Reset clears the loaded table too — data comes back only on Load
      setTableData([])
      setTotalPages(1)
      setShowLoader(false)
    }, 1000)
  }

  // ── Row ke saamne wala Excel icon ─────────────────────────────────────────
  // Reference panel me har game row (casino round / sports market) ke remark ke
  // aage chhota excel icon hota hai; click par us row ke peeche ke saare bets
  // CSV me utarte hain. Columns server se aate hain (13-column reference shape)
  // taaki naam/order ek hi jagah tay ho.
  const [betExportId, setBetExportId] = useState(null)

  // CSV field: comma/quote/newline wali value ko quote karo (excel ka apna rule)
  const csvCell = (v) => {
    const t = v == null ? '' : String(v)
    return /[",\n\r]/.test(t) ? `"${t.replace(/"/g, '""')}"` : t
  }

  const handleBetExport = async (row) => {
    if (!row?.betId || betExportId) return
    setBetExportId(row.betId)
    try {
      const res = await getStatementBetExport({ betId: row.betId, category: row.category })
      if (!res?.success || !res.rows?.length) {
        Toast.fire({ icon: 'info', title: res?.message || 'No bets found for this entry' })
        return
      }
      const csv = [res.columns, ...res.rows].map((r) => r.map(csvCell).join(',')).join('\n')
      // Blob (data-URI nahi): bade rounds par URI length limit nahi lagti
      const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8;' }))
      const link = document.createElement('a')
      link.href = url
      link.download = res.filename || 'bets.csv'
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      URL.revokeObjectURL(url)
    } catch (err) {
      console.error('Bet export failed:', err)
      Toast.fire({ icon: 'error', title: err?.response?.data?.message || 'Download failed' })
    } finally {
      setBetExportId(null)
    }
  }

  // ── Row click -> "Details" modal ──────────────────────────────────────────
  // Reference: game row par click se us row ke peeche ke bets ka modal khulta
  // hai. Loader pehle, modal tabhi jab data aa jaaye (kabhi spinner par nahi
  // khulta). Sirf un rows par jinke peeche asli bet hai.
  const hasBets = (r) => !!r?.betId && (r.category === 'CASINO' || r.category === 'SPORTS')
  const [betDetail, setBetDetail] = useState(null)
  const [detailLoading, setDetailLoading] = useState(false)

  const handleRowClick = async (row) => {
    if (!hasBets(row) || detailLoading) return
    setDetailLoading(true)
    try {
      const res = await getStatementBetDetail({ betId: row.betId, category: row.category })
      if (!res?.success) {
        Toast.fire({ icon: 'info', title: res?.message || 'No bets found for this entry' })
        return
      }
      // CASINO row: round ka result (cards / winner box) bhi — usi loader ke
      // neeche. Result na mile (purana round, feed error) to modal phir bhi
      // khulta hai, bas cards ki jagah text line rehti hai.
      let result = null
      if (res.casino?.gameCode && res.casino?.roundId) {
        result = await getDetailResults(res.casino.gameCode, String(res.casino.roundId))
          .then((r) => r?.data?.data?.t1 || r?.data?.t1 || r?.data || null)
          .catch(() => null)
      }
      setBetDetail({ ...res, result })
    } catch (err) {
      console.error('Bet detail failed:', err)
      Toast.fire({ icon: 'error', title: err?.response?.data?.message || 'Could not load bets' })
    } finally {
      setDetailLoading(false)
    }
  }

  const handleExportExcel = () => {
    const headers = ['Date', 'Credit', 'Debit', 'Closing', 'Description', 'From/To']
    const rows = tableData.map((r) => [
      formatDisplay(r.date),
      r.credit !== 0 && r.credit != null ? r.credit : '',
      r.debit !== 0 && r.debit != null ? r.debit : '',
      r.closing ?? '-',
      (r.description || '-').replace(/,/g, ' '),
      r.fromto || '-',
    ])
    const csv = 'data:text/csv;charset=utf-8,' + headers.join(',') + '\n' + rows.map((e) => e.join(',')).join('\n')
    const link = document.createElement('a')
    link.setAttribute('href', encodeURI(csv))
    link.setAttribute('download', `account_statement_${formatDate(new Date())}.csv`)
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const handleExportPDF = async () => {
    const { default: jsPDF } = await import('jspdf')
    const { default: autoTable } = await import('jspdf-autotable')
    const cols = ['Date', 'Sr No', 'Credit', 'Debit', 'pts', 'Remark', 'Fromto']
    const body = filtered.map((r, idx) => [
      formatDisplay(r.date),
      r.sr ?? idx + 1,
      Number(r.credit) || '',
      Number(r.debit) || '',
      r.closing ?? r.pts ?? '',
      r.description || r.remark || '',
      r.fromto || '',
    ])
    const doc = new jsPDF('l', 'pt')
    const pageWidth = doc.internal.pageSize.getWidth()
    doc.setFontSize(14)
    doc.setTextColor(51, 51, 51)
    doc.text('Account Statement', pageWidth / 2, 30, { align: 'center' })
    autoTable(doc, {
      head: [cols],
      body,
      startY: 45,
      theme: 'striped',
      styles: { fontSize: 10, cellPadding: 6 },
      headStyles: { fillColor: [41, 128, 185], textColor: 255, fontStyle: 'bold', halign: 'left' },
      bodyStyles: { textColor: [85, 85, 85] },
    })
    doc.save('accountstatement.pdf')
  }

  const filtered = tableData.filter((r) =>
    !searchValue ||
    (r.description || '').toLowerCase().includes(searchValue.toLowerCase()) ||
    (r.fromto || '').toLowerCase().includes(searchValue.toLowerCase())
  )

  const handlePageChange = (p) => {
    if (p >= 1 && p <= totalPages) setCurrentPage(p)
  }

  return (
    <div data-v-5a10e370="">
      {(showLoader || exporting || detailLoading) && <LoaderOverlay />}
      {betDetail && <StatementBetDetailModal detail={betDetail} onHide={() => setBetDetail(null)} />}
      <div data-v-5a10e370="">
          <div className="row">
            <div className="col-12">
              <div className="page-title-box d-flex align-items-center justify-content-between">
                <h4 className="mb-0 font-size-18">Account Statement</h4>
                <div className="page-title-right">
                  <ol className="breadcrumb m-0">
                    <li className="breadcrumb-item">
                      <Link to="/admin/home" className="" target="_self">Home</Link>
                    </li>
                    <li className="breadcrumb-item active">
                      <span aria-current="location">Account Statement</span>
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col-12">
              <div className="card">
                <div className="card-body">
                  <div className="report-form mb-3">
                    <form method="post" className="ajaxFormSubmit" onSubmit={handleLoad}>
                      <div className="row row5">
                        <div className="col-lg-3">
                          <div className="form-group user-lock-search" style={{ position: 'relative' }}>
                            <label htmlFor="d-inline-block">Search By Client Name</label>{' '}
                            <ClientMultiselect
                              value={clientName}
                              onChange={setClientName}
                              onSelect={(u) => setClientName(u.username)}
                            />
                          </div>
                        </div>

                        <div className="col-lg-3">
                          <label>Select Date Range</label>{' '}
                          <MxDatePicker
                            range
                            disableFuture
                            rootClassName="mb-3 mx-datepicker mx-datepicker-range"
                            rangeValue={[fromDate, toDate]}
                            onRangeChange={(f, t) => { setFromDate(f); setToDate(t) }}
                          />
                        </div>

                        <div className="col-lg-2">
                          <div className="form-group">
                            <label>Type</label>{' '}
                            <select className="form-control" value={typeVal} onChange={(e) => { setTypeVal(e.target.value); setStatementVal('all'); setSportVal('0'); setGameTypeVal('all'); setCasinoVal('all') }}>
                              <option value="2">Deposit/Withdraw Report</option>
                              <option value="3">Game Report</option>
                            </select>
                          </div>
                        </div>

                        <div className="col-lg-2">
                          <div className="form-group">
                            <label>Statement</label>{' '}
                            <select className="form-control" value={statementVal} onChange={(e) => { setStatementVal(e.target.value); setSportVal('0'); setGameTypeVal('all'); setCasinoVal('all') }}>
                              {typeVal === '3' ? (
                                <>
                                  <option value="all">All</option>
                                  <option value="sport">Sports</option>
                                  <option value="casino">Casino</option>
                                </>
                              ) : (
                                <>
                                  <option value="all">All</option>
                                  <option value="allcredit">Credit - All</option>
                                  <option value="creditupper">Credit - Upper</option>
                                  <option value="creditdown">Credit - Down</option>
                                  <option value="allbalance">pts - All</option>
                                  <option value="balanceupper">pts - Upper</option>
                                  <option value="balancedown">pts - Down</option>
                                </>
                              )}
                            </select>
                          </div>
                        </div>

                        {typeVal === '3' && statementVal === 'sport' && (
                          <>
                            <div className="col-lg-2">
                              <div className="form-group">
                                <label>Sports List</label>{' '}
                                <select className="form-control" value={sportVal} onChange={(e) => setSportVal(e.target.value)}>
                                  <option value="0">All</option>
                                  {' '}
                                  {SPORTS_LIST.map(([v, n]) => (
                                    <option key={v} value={v}>{`\n                              ${n}\n                            `}</option>
                                  ))}
                                </select>
                              </div>
                            </div>
                            <div className="col-lg-2">
                              <div className="form-group">
                                <label>Game Type</label>{' '}
                                <select className="form-control" value={gameTypeVal} onChange={(e) => setGameTypeVal(e.target.value)}>
                                  <option value="all">All</option>
                                  {' '}
                                  {GAME_TYPES.map(([v, n]) => (
                                    <option key={v} value={v}>{`\n                              ${n}\n                            `}</option>
                                  ))}
                                </select>
                              </div>
                            </div>
                          </>
                        )}

                        {typeVal === '3' && statementVal === 'casino' && (
                          <div className="col-lg-2">
                            <div className="form-group">
                              <label>Casino List</label>{' '}
                              <select className="form-control" value={casinoVal} onChange={(e) => setCasinoVal(e.target.value)}>
                                <option value="all">All</option>
                                {' '}
                                {CASINO_LIST.map(([v, n]) => (
                                  <option key={v} value={v}>{`\n                              ${n}\n                            `}</option>
                                ))}
                              </select>
                            </div>
                          </div>
                        )}
                      </div>

                      <div className="row row5">
                        <div className="col-lg-3">
                          <button type="submit" id="loaddata" className="btn btn-primary">Load</button>
                          {' '}
                          <button type="button" id="reset" className="btn btn-light" onClick={handleReset}>Reset</button>
                          {' '}
                          <div id="export_1776278069031" className={`d-inline-block${filtered.length === 0 ? ' disabled' : ''}`}>
                            <button type="button" disabled={filtered.length === 0} className={`btn btn-success${filtered.length === 0 ? ' disabled' : ''}`} onClick={withExportLoader(handleExportExcel)}><i className="fas fa-file-excel"></i></button>
                          </div>
                          {' '}
                          <button type="button" disabled={filtered.length === 0} className={`btn btn-danger${filtered.length === 0 ? ' disabled' : ''}`} onClick={handleExportPDF}><i className="fas fa-file-pdf"></i></button>
                        </div>
                      </div>
                    </form>
                  </div>

                  <div className="row">
                    <div className="col-6">
                      <div id="tickets-table_length" className="dataTables_length">
                        <label className="d-inline-flex align-items-center">
                          Show&nbsp;
                          <select
                            className="custom-select custom-select-sm"
                            id="__BVID__1687"
                            value={entriesPerPage}
                            onChange={(e) => { setEntriesPerPage(Number(e.target.value)); setCurrentPage(1) }}
                          >
                            <option value="25">25</option>
                            <option value="50">50</option>
                            <option value="75">75</option>
                            <option value="100">100</option>
                            <option value="125">125</option>
                            <option value="150">150</option>
                          </select>&nbsp;entries
                        </label>
                      </div>
                    </div>
                    <div className="col-6 text-right">
                      <div id="tickets-table_filter" className="dataTables_filter text-md-right">
                        <label className="d-inline-flex align-items-center">
                          <input
                            type="search"
                            placeholder="Search..."
                            className="form-control form-control-sm ml-2 form-control"
                            id="__BVID__1688"
                            value={searchValue}
                            onChange={(e) => setSearchValue(e.target.value)}
                          />
                        </label>
                      </div>
                    </div>
                  </div>

                  <div className="table-responsive mb-0">
                    <div className="table no-footer table-hover table-responsive-sm">
                      <table id="accStmtTable" role="table" aria-busy={loading} aria-colcount="7" className="table b-table table-bordered">
                        <colgroup>
                          <col style={{ width: 'auto' }} />
                          <col style={{ width: '100px' }} />
                          <col style={{ width: 'auto' }} />
                          <col style={{ width: 'auto' }} />
                          <col style={{ width: 'auto' }} />
                          <col style={{ width: '350px' }} />
                          <col style={{ width: 'auto' }} />
                        </colgroup>
                        <thead role="rowgroup" className="">
                          <tr role="row" className="">
                            <th role="columnheader" scope="col" tabIndex="0" aria-colindex="1" aria-sort="none" className="position-relative">
                              <div>Date</div>
                              <span className="sr-only"> (Click to sort ascending)</span>
                            </th>
                            <th role="columnheader" scope="col" tabIndex="0" aria-colindex="2" aria-sort="none" className="position-relative text-right">
                              <div>Sr No</div>
                              <span className="sr-only"> (Click to sort ascending)</span>
                            </th>
                            <th role="columnheader" scope="col" tabIndex="0" aria-colindex="3" aria-sort="none" className="position-relative text-right">
                              <div>Credit</div>
                              <span className="sr-only"> (Click to sort ascending)</span>
                            </th>
                            <th role="columnheader" scope="col" tabIndex="0" aria-colindex="4" aria-sort="none" className="position-relative text-right">
                              <div>Debit</div>
                              <span className="sr-only"> (Click to sort ascending)</span>
                            </th>
                            <th role="columnheader" scope="col" tabIndex="0" aria-colindex="5" aria-sort="none" className="position-relative text-right">
                              <div>pts</div>
                              <span className="sr-only"> (Click to sort ascending)</span>
                            </th>
                            <th role="columnheader" scope="col" tabIndex="0" aria-colindex="6" aria-sort="none" className="position-relative">
                              <div>Remark</div>
                              <span className="sr-only"> (Click to sort ascending)</span>
                            </th>
                            <th role="columnheader" scope="col" tabIndex="0" aria-colindex="7" aria-sort="none" className="position-relative">
                              <div>Fromto</div>
                              <span className="sr-only"> (Click to sort ascending)</span>
                            </th>
                          </tr>
                        </thead>
                        <tbody role="rowgroup">
                          {filtered.length === 0 ? (
                            <tr role="row" className="b-table-empty-row">
                              <td colSpan="7" role="cell" className="">
                                <div role="alert" aria-live="polite">
                                  <div className="text-center my-2">There are no records to show</div>
                                </div>
                              </td>
                            </tr>
                          ) : (
                            filtered.map((r, idx) => {
                              const credit = Number(r.credit) || 0
                              const debit = Number(r.debit) || 0
                              const closing = r.closing ?? r.pts
                              return (
                                <tr
                                  key={r.id || r.sr || idx}
                                  role="row"
                                  tabIndex="0"
                                  aria-rowindex={idx + 1}
                                  className={hasBets(r) ? '' : 'nocursor'}
                                  style={hasBets(r) ? { cursor: 'pointer' } : undefined}
                                  onClick={() => handleRowClick(r)}
                                >
                                  <td aria-colindex="1" role="cell">{formatDisplay(r.date)}</td>
                                  <td aria-colindex="2" role="cell">
                                    <div className="text-right">{r.sr ?? idx + 1}</div>
                                  </td>
                                  <td aria-colindex="3" role="cell">
                                    <div className={`text-right ${credit !== 0 ? 'text-success' : ''}`}>
                                      <span>{credit !== 0 ? credit.toLocaleString() : ''}</span>
                                    </div>
                                  </td>
                                  <td aria-colindex="4" role="cell">
                                    <div className={`text-right ${debit !== 0 ? 'text-danger' : ''}`}>
                                      {/* Debit hamesha negative dikhana hai — -Math.abs se API ka sign kuch bhi ho, minus hi rahega */}
                                      <span>{debit !== 0 ? (-Math.abs(debit)).toLocaleString() : ''}</span>
                                    </div>
                                  </td>
                                  <td aria-colindex="5" role="cell">
                                    {/* pts: negative => red, positive => green, exact 0 => plain
                                        (reference site par zero bina colour ke aata hai) */}
                                    <div className={`text-right ${Number(closing) < 0 ? 'text-danger' : Number(closing) > 0 ? 'text-success' : ''}`}>
                                      <span>{closing != null ? Number(closing).toLocaleString() : ''}</span>
                                    </div>
                                  </td>
                                  <td aria-colindex="6" role="cell">
                                    <div>
                                      {r.description || r.remark || ''}
                                      {/* Sirf un rows par jinke peeche asli bet hai — THIRD_PARTY
                                          aur synthetic (Opening pts / Live Casino) rows par nahi */}
                                      {hasBets(r) ? (
                                        <button
                                          type="button"
                                          className="btn btn-link p-0 ml-1 align-baseline"
                                          title="Download bets"
                                          disabled={betExportId === r.betId}
                                          onClick={(e) => { e.stopPropagation(); handleBetExport(r) }}
                                        >
                                          <i className={`fas ${betExportId === r.betId ? 'fa-spinner fa-spin' : 'fa-file-excel'} text-success`}></i>
                                        </button>
                                      ) : null}
                                    </div>
                                  </td>
                                  <td aria-colindex="7" role="cell">{r.fromto || ''}</td>
                                </tr>
                              )
                            })
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={handlePageChange} />
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>
  )
}

export default AccountStatement
