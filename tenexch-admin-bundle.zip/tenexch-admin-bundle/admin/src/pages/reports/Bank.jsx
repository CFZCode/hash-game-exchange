import { useState, useEffect, useCallback } from 'react'
import { Link } from 'react-router-dom'
import LoaderOverlay from '../../components/LoaderOverlay'
import useExportLoader from '../../hooks/useExportLoader'
import userService from '../../services/userService'
import walletService from '../../services/walletService'
import Pagination from '../../components/Pagination'

// users/all-details ki row → is page ki table shape (wahi keys jo baaki panel me)
const toBankRow = (w) => ({
  id: w.wallet_id,
  childId: w.user_id || w.staff_id,   // settle API ke liye
  username: w.username,
  fullName: w.fullname || w.username,
  cr: w.credit ?? 0,                   // CR
  pts: w.all_point ?? 0,               // pts = all_point
  pl: w.settlement_points ?? 0,        // Client(P/L)
  // Stored negative (liability); table + export show the magnitude, no minus sign.
  exposure: Math.abs(Number(w.exposure ?? 0)) || 0,
  available: w.available_points ?? 0,  // Available pts (user: cash, staff: inr_balance)
  accountType: w.user_type === 'USER'
    ? 'User'
    : String(w.role || w.user_type || '').charAt(0).toUpperCase() + String(w.role || w.user_type || '').slice(1).toLowerCase(),
})

function Bank() {
  // Same page loader as /admin/activeusers. On a hard refresh the 2s boot
  // splash covers the app, so the 1s countdown starts only once `app-loading`
  // leaves <body> — otherwise the loader would finish underneath the splash.
  const [loading, setLoading] = useState(true)
  // Excel button: page loader for a second, then the download (hooks/useExportLoader)
  const { exporting, withExportLoader } = useExportLoader()
  useEffect(() => {
    let timer
    const start = () => { timer = setTimeout(() => setLoading(false), 1000) }
    if (document.body.classList.contains('app-loading')) {
      const obs = new MutationObserver(() => {
        if (!document.body.classList.contains('app-loading')) {
          obs.disconnect()
          start()
        }
      })
      obs.observe(document.body, { attributes: true, attributeFilter: ['class'] })
      return () => { obs.disconnect(); clearTimeout(timer) }
    }
    start()
    return () => clearTimeout(timer)
  }, [])

  const [searchKey, setSearchKey] = useState('')
  const [masterPassword, setMasterPassword] = useState('')
  // Transfer All: empty Transaction Code -> red outline only (reference)
  const [mpassInvalid, setMpassInvalid] = useState(false)
  const [pageSize, setPageSize] = useState(25)
  const [amounts, setAmounts] = useState({})
  // Per-row Status column message (reference shows it on the submitted row)
  const [rowErrors, setRowErrors] = useState({})
  const [rowSuccess, setRowSuccess] = useState({})
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [rows, setRows] = useState([])

  const fmt = (v) => Number(v).toLocaleString()

  // Wahi users/all-details API jo /admin/activeusers use karti hai — direct children ki list
  const fetchRows = useCallback(async (page, limit, search) => {
    setLoading(true)
    try {
      const data = await userService.getAllDetails(page, limit, search)
      if (data.success && data.data?.wallets) {
        setRows(data.data.wallets.map(toBankRow))
        setTotalPages(data.data.pagination?.total_pages || 1)
      } else {
        setRows([])
        setTotalPages(1)
      }
    } catch (err) {
      console.error('Error loading bank list:', err)
      setRows([])
      setTotalPages(1)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchRows(currentPage, pageSize, searchKey)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentPage, pageSize])

  const handleLoad = (e) => {
    e.preventDefault()
    setCurrentPage(1)
    fetchRows(1, pageSize, searchKey)
  }

  const handleReset = () => {
    setSearchKey('')
    setCurrentPage(1)
    fetchRows(1, pageSize, '')
  }

  const handleTransferAll = (e) => {
    e.preventDefault()
    if (!masterPassword) {
      setMpassInvalid(true)
      return
    }
    setMpassInvalid(false)
    setLoading(true)
    setTimeout(() => setLoading(false), 1000)
  }

  // Export (excel/pdf) — same columns/format as the reference bankuserlist.pdf:
  // "User Name" is "username (Full Name)", raw numbers, "Account type"
  const EXPORT_COLS = ['User Name', 'CR', 'pts', 'Client(P/L)', 'Exposure', 'Available pts', 'Account type']
  const exportRows = () => rows.map((r) => [`${r.username} (${r.fullName})`, r.cr, r.pts, r.pl, r.exposure, r.available, r.accountType])

  const handleExportExcel = () => {
    const head = EXPORT_COLS.map((c) => `<th>${c}</th>`).join('')
    const body = exportRows().map((r) => `<tr>${r.map((v) => `<td>${v}</td>`).join('')}</tr>`).join('')
    const html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="UTF-8"></head><body><table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></body></html>`
    const blob = new Blob([html], { type: 'application/vnd.ms-excel' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = 'bankuserlist.xls'
    a.click()
    URL.revokeObjectURL(a.href)
  }

  const handleExportPdf = async () => {
    const { default: jsPDF } = await import('jspdf')
    const { default: autoTable } = await import('jspdf-autotable')
    // Reference layout: landscape, centered title, blue striped table
    const doc = new jsPDF('l', 'pt')
    const pageWidth = doc.internal.pageSize.getWidth()
    doc.setFontSize(14)
    doc.setTextColor(51, 51, 51)
    doc.text('Bank User List', pageWidth / 2, 30, { align: 'center' })
    autoTable(doc, {
      head: [EXPORT_COLS],
      body: exportRows(),
      startY: 45,
      theme: 'striped',
      styles: { fontSize: 10, cellPadding: 6 },
      headStyles: { fillColor: [41, 128, 185], textColor: 255, fontStyle: 'bold', halign: 'left' },
      bodyStyles: { textColor: [85, 85, 85] },
    })
    doc.save('bankuserlist.pdf')
  }

  const setAmount = (id, val) => {
    setAmounts((prev) => ({ ...prev, [id]: val }))
  }

  // Action SETTLEMENT par hota hai — "All" = pending ka ULTA sign (wahi jo API me jayega).
  // Client(P/L) -100 → box me +100 (dena hai) | Client(P/L) +10 → box me -10 (lena hai)
  const handleAll = (row) => {
    setAmount(row.id, (-(Number(row.pl) || 0)).toFixed(2))
  }

  const handleSubmitRow = async (row) => {
    setRowSuccess((prev) => ({ ...prev, [row.id]: '' }))
    if (!masterPassword) {
      setRowErrors((prev) => ({ ...prev, [row.id]: 'Please enter master password' }))
      return
    }
    const pts = Number(amounts[row.id])
    if (!pts) {
      setRowErrors((prev) => ({ ...prev, [row.id]: 'Enter points' }))
      return
    }
    setRowErrors((prev) => ({ ...prev, [row.id]: '' }))
    setLoading(true)
    try {
      const res = await walletService.settlePoints({
        userId: row.childId,   // backend isi naam se leta hai (user ho ya staff, dono ki id)
        username: row.username,
        points: pts,
        transactionPassword: masterPassword,
      })
      if (res.success) {
        setRowErrors((prev) => ({ ...prev, [row.id]: '' }))
        setRowSuccess((prev) => ({ ...prev, [row.id]: 'Sucessful Balance Transfer' }))
        setAmount(row.id, '')
        fetchRows(currentPage, pageSize, searchKey)
      } else {
        setRowErrors((prev) => ({ ...prev, [row.id]: res.message || res.error || 'Failed' }))
      }
    } catch (e) {
      setRowErrors((prev) => ({ ...prev, [row.id]: e.response?.data?.message || e.response?.data?.error || e.message }))
    } finally {
      setLoading(false)
    }
  }

  return (
    <div data-v-5a10e370="">
      {(loading || exporting) && <LoaderOverlay />}
      <div data-v-5a10e370="">
          <div className="row">
            <div className="col-12">
              <div className="page-title-box d-flex align-items-center justify-content-between">
                <h4 className="mb-0 font-size-18">Bank</h4>
                <div className="page-title-right">
                  <ol className="breadcrumb m-0">
                    <li className="breadcrumb-item">
                      <Link to="/admin/home" className="" target="_self">Home</Link>
                    </li>
                    <li className="breadcrumb-item active">
                      <span aria-current="location">Bank</span>
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>

          <div className="row bank-panel">
            <div className="col-12">
              <div className="card">
                <div className="card-body">
                  <div className="report-form mb-1">
                    <div className="row row5">
                      <div className="col-md-6 mb-2 search-form">
                        <form method="post" className="ajaxFormSubmit" onSubmit={handleLoad}>
                          <div className="d-inline-block form-group form-group-feedback form-group-feedback-right">
                            <input
                              type="text"
                              name="searchKey"
                              placeholder="Search User"
                              className="form-control"
                              value={searchKey}
                              onChange={(e) => setSearchKey(e.target.value)}
                            />
                          </div>{' '}
                          <div className="d-inline-block">
                            <button type="submit" id="submit" className="btn btn-primary">Load</button>{' '}
                            <button type="button" id="reset" className="btn btn-light" onClick={handleReset}>Reset</button>
                          </div>
                        </form>
                      </div>
                      <div className="col-md-6 text-right">
                        <div className="d-inline-block">
                          <div id="export_1776276568785" className="d-inline-block">
                            <button type="button" className={`btn mr-1 btn-success${rows.length === 0 ? ' disabled' : ''}`} disabled={rows.length === 0} onClick={withExportLoader(handleExportExcel)}><i className="fas fa-file-excel"></i></button>
                          </div>{' '}
                          <button type="button" className={`btn btn-danger${rows.length === 0 ? ' disabled' : ''}`} disabled={rows.length === 0} onClick={handleExportPdf}><i className="fas fa-file-pdf"></i></button>
                        </div>{' '}
                        <form data-vv-scope="transferAll" method="post" className="d-inline-block" onSubmit={handleTransferAll}>
                          <div className="d-inline-block form-group form-group-feedback form-group-feedback-right">
                            <input
                              type="password"
                              name="masterPassword"
                              placeholder="Transaction Code"
                              data-vv-as="Transaction Code"
                              className={`form-control${mpassInvalid ? ' is-invalid' : ''}`}
                              aria-required="true"
                              aria-invalid={mpassInvalid ? 'true' : 'false'}
                              value={masterPassword}
                              onChange={(e) => { setMasterPassword(e.target.value); setMpassInvalid(!e.target.value) }}
                              onBlur={(e) => setMpassInvalid(!e.target.value && mpassInvalid)}
                            />
                          </div>{' '}
                          <div className="d-inline-block">
                            <button type="submit" id="transferSubmit" className="btn btn-primary">Transfer All</button>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>

                  <div className="row">
                    <div className="col-6">
                      <div id="tickets-table_length" className="dataTables_length">
                        <label className="d-inline-flex align-items-center">
                          Show&nbsp;
                          <select
                            className="custom-select custom-select-sm"
                            id="__BVID__1596"
                            value={pageSize}
                            onChange={(e) => setPageSize(Number(e.target.value))}
                          >
                            <option value="25">25</option>
                            <option value="50">50</option>
                            <option value="100">100</option>
                            <option value="250">250</option>
                            <option value="500">500</option>
                            <option value="750">750</option>
                            <option value="1000">1000</option>
                          </select>&nbsp;entries
                        </label>
                      </div>
                    </div>
                  </div>

                  <div className="table-responsive mb-0">
                    <div className="table no-footer table-hover table-responsive-sm">
                      <table id="eventsListTbl" role="table" aria-busy="false" aria-colcount="9" className="table b-table">
                        <colgroup>
                          <col style={{ width: '200px' }} />
                          <col style={{ width: 'auto' }} />
                          <col style={{ width: 'auto' }} />
                          <col style={{ width: 'auto' }} />
                          <col style={{ width: 'auto' }} />
                          <col style={{ width: 'auto' }} />
                          <col style={{ width: 'auto' }} />
                          <col style={{ width: '250px' }} />
                          <col style={{ width: '200px' }} />
                        </colgroup>
                        <thead role="rowgroup" className="">
                          <tr role="row" className="">
                            <th role="columnheader" scope="col" aria-colindex="1" className=""><div>User Name</div></th>
                            <th role="columnheader" scope="col" aria-colindex="2" className="text-right"><div>CR</div></th>
                            <th role="columnheader" scope="col" aria-colindex="3" className="text-right"><div>pts</div></th>
                            <th role="columnheader" scope="col" aria-colindex="4" className="text-right"><div>Client(P/L)</div></th>
                            <th role="columnheader" scope="col" aria-colindex="5" className="text-right"><div>Exposure</div></th>
                            <th role="columnheader" scope="col" aria-colindex="6" className="text-right"><div>Available pts</div></th>
                            <th role="columnheader" scope="col" aria-colindex="7" className=""><div>Account Type</div></th>
                            <th role="columnheader" scope="col" aria-colindex="8" className=""><div>Action</div></th>
                            <th role="columnheader" scope="col" aria-colindex="9" className=""><div>Status</div></th>
                          </tr>
                        </thead>
                        <tbody role="rowgroup">
                          {rows.length === 0 ? (
                            <tr role="row" className="b-table-empty-row">
                              <td colSpan="9" role="cell" className="">
                                <div role="alert" aria-live="polite">
                                  <div className="text-center my-2">There are no records to show</div>
                                </div>
                              </td>
                            </tr>
                          ) : (
                            rows.map((row) => (
                              <tr key={row.id} role="row" className="">
                                <td aria-colindex="1" role="cell" className="">
                                  <span title={`${row.username} (${row.fullName})`} className="text-ellipsis">{row.username}</span>
                                </td>
                                <td aria-colindex="2" role="cell" className=""><p className="text-right mb-0">{fmt(row.cr)}</p></td>
                                <td aria-colindex="3" role="cell" className=""><p className="text-right mb-0">{fmt(row.pts)}</p></td>
                                <td aria-colindex="4" role="cell" className=""><p className="text-right mb-0">{fmt(row.pl)}</p></td>
                                <td aria-colindex="5" role="cell" className=""><p className="text-right mb-0">{fmt(row.exposure)}</p></td>
                                <td aria-colindex="6" role="cell" className=""><p className="text-right mb-0">{fmt(row.available)}</p></td>
                                <td aria-colindex="7" role="cell" className="">{row.accountType}</td>
                                <td aria-colindex="8" role="cell" className="">
                                  <a href="javascript:void(0)" className="text-success" onClick={(e) => { e.preventDefault(); handleAll(row) }}>
                                    All <i className="fas fa-arrow-right"></i>
                                  </a>
                                  {' '}
                                  <input
                                    type="number"
                                    name="amount"
                                    placeholder="0"
                                    className="form-control form-control-sm transfer-amt"
                                    value={amounts[row.id] ?? ''}
                                    onChange={(e) => setAmount(row.id, e.target.value)}
                                  />
                                  {' '}
                                  <button type="button" className="btn btn-info btn-sm" onClick={() => handleSubmitRow(row)}>Submit</button>
                                </td>
                                <td aria-colindex="9" role="cell" className="">{rowErrors[row.id]
                                  ? <span className="text-danger">{rowErrors[row.id]}</span>
                                  : rowSuccess[row.id]
                                    ? <span className="text-success">{rowSuccess[row.id]}</span>
                                    : null}</td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={setCurrentPage} />
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>
  )
}

export default Bank
