import { useState, useEffect, useMemo } from 'react'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import api from '../../services/api'
import ClientMultiselect from '../../components/ClientMultiselect'
import MxDatePicker from '../../components/MxDatePicker'
import LoaderOverlay from '../../components/LoaderOverlay'
import useExportLoader from '../../hooks/useExportLoader'
import Pagination from '../../components/Pagination'

// Reference provider list (order + labels from tenexch.com)
const VENDOR_OPTIONS = [
  { value: 'ezugi', label: 'Ezugi' }, { value: 'ss', label: 'Super Spade' },
  { value: 'qt', label: 'Slot 3 | Holi' }, { value: 'evo', label: 'Evolution' },
  { value: 'cockfight', label: 'CockFight' }, { value: 'ludo', label: 'Ludo Classic' },
  { value: 'pop-the-ball', label: 'PopTheBall' }, { value: 'binary', label: 'Binary' },
  { value: 'tgs', label: 'Slot 2' }, { value: 'slot', label: 'Slot' },
  { value: 'tgslive', label: 'vivogamepoints-LuckyStreak' }, { value: 'rummy', label: 'Rummy' },
  { value: 'ludo-lands', label: 'Ludo Lands' }, { value: 'vivo', label: 'vivo gaming' },
  { value: 'snakes-and-ladders', label: 'snakes and ladders' }, { value: 'smart', label: 'Smart Soft' },
  { value: 'astar', label: 'Astar Game' }, { value: 'ds', label: 'Dragoon soft' },
  { value: 'bc', label: 'Creedroomz' }, { value: 'tembo', label: 'Tembo' },
  { value: 'bcslot', label: 'Pascal Game | Popok' }, { value: 'av', label: 'Spribe' },
  { value: 'lottery', label: 'Lottery' }, { value: 'scratch', label: 'Scratch' },
  { value: 'bet', label: 'Bet Core' }, { value: 'darwin', label: 'Darwin' },
  { value: 'jilli', label: 'Jilli' }, { value: 'amigo', label: 'Amigo' },
  { value: 'win', label: 'Red Carat' }, { value: 'gemini1', label: 'Gemini' },
  { value: 'studio21', label: 'Studio 21' }, { value: 'egt', label: 'EGT' },
  { value: 'beon', label: 'Beon Game' }, { value: 'king', label: 'King Midas' },
  { value: 'avnew', label: 'Aviator' },
]

function formatTimestamp(ts) {
  if (!ts) return '-'
  const d = new Date(ts)
  if (isNaN(d)) return ts
  const day = String(d.getDate()).padStart(2, '0')
  const month = String(d.getMonth() + 1).padStart(2, '0')
  return `${day}/${month}/${d.getFullYear()}`
}

// status: 'settled' shows datepicker + exports + entries/search and a 7-col
// table (Game Name first); 'unsettled' is the reference's slimmer variant
function ReportPane({ status }) {
  const isSettled = status === 'settled'
  const { user } = useSelector((state) => state.auth)
  const [clientName, setClientName] = useState('')
  // Excel button: page loader for a second, then the download (hooks/useExportLoader)
  const { exporting, withExportLoader } = useExportLoader()
  const [selectedUsername, setSelectedUsername] = useState('')
  const [selectedDate, setSelectedDate] = useState('')
  const [vendor, setVendor] = useState('')
  const [vendorInvalid, setVendorInvalid] = useState(false)
  const [entriesPerPage, setEntriesPerPage] = useState(25)
  const [searchValue, setSearchValue] = useState('')
  const [tableData, setTableData] = useState([])
  const [loading, setLoading] = useState(false)
  const [showLoader, setShowLoader] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)

  useEffect(() => {
    const d = new Date()
    const y = d.getFullYear()
    const m = String(d.getMonth() + 1).padStart(2, '0')
    const day = String(d.getDate()).padStart(2, '0')
    setSelectedDate(`${y}-${m}-${day}`)
  }, [])

  const fetchData = async () => {
    setLoading(true)
    try {
      const activeRole = localStorage.getItem('activeRole') || 'staff'
      // Backend contract: type must be 'SettleBet' | 'UnsettleBet'
      const payload = {
        role: activeRole.toUpperCase(),
        username: selectedUsername || clientName || user?.username || '',
        type: isSettled ? 'SettleBet' : 'UnsettleBet',
        vendor,
        date: selectedDate,
      }
      const response = await api.post('/admin/reports/casino-report', payload)
      if (response.data?.success && Array.isArray(response.data.data)) {
        const mapped = response.data.data.map((item) => ({
          id: item.id,
          gameName: item.game_name || '-',
          type: item.transaction_type || item.game_type || '-',
          amount: item.amount != null ? parseFloat(item.amount).toFixed(2) : '-',
          total: item.total != null ? parseFloat(item.total).toFixed(2) : (item.amount != null ? parseFloat(item.amount).toFixed(2) : '-'),
          date: item.timestamp ? formatTimestamp(item.timestamp) : '-',
          roundId: item.serial_number || item.round_id || '-',
          transactionId: item.external_transaction_id || item.transaction_id || '-',
        }))
        setTableData(mapped)
      } else {
        setTableData([])
      }
    } catch (err) {
      console.error('Error loading live casino report:', err)
      setTableData([])
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!vendor) {
      setVendorInvalid(true)
      return
    }
    setVendorInvalid(false)
    setShowLoader(true)
    Promise.all([fetchData(), new Promise((r) => setTimeout(r, 1000))])
      .finally(() => setShowLoader(false))
  }

  const handleReset = () => {
    setClientName('')
    setSelectedUsername('')
    setVendor('')
    // After Reset the reference shows the select as REQUIRED-and-empty: red
    // outline + the is-invalid × glyph on "Select" (screenshot, 2026-09-22 —
    // vee-validate re-validates on reset). We were clearing the flag, so the
    // field went plain grey after Reset.
    setVendorInvalid(true)
    setSearchValue('')
    setCurrentPage(1)
    setShowLoader(true)
    setTimeout(() => {
      setTableData([])
      setShowLoader(false)
    }, 1000)
  }

  const filteredData = useMemo(() => {
    if (!searchValue.trim()) return tableData
    const q = searchValue.toLowerCase()
    return tableData.filter((r) => Object.values(r).some((v) => String(v || '').toLowerCase().includes(q)))
  }, [tableData, searchValue])

  const totalPages = Math.max(1, Math.ceil(filteredData.length / entriesPerPage))
  const startIdx = (currentPage - 1) * entriesPerPage
  const paged = filteredData.slice(startIdx, startIdx + entriesPerPage)

  useEffect(() => { setCurrentPage(1) }, [searchValue, entriesPerPage, tableData.length])

  const handlePageChange = (p) => {
    if (p >= 1 && p <= totalPages) setCurrentPage(p)
  }

  const EXPORT_COLS = isSettled
    ? ['Game Name', 'Type', 'Amount', 'Total', 'Date', 'Round Id', 'Transaction Id']
    : ['Type', 'Amount', 'Total', 'Date', 'Round Id', 'Transaction Id']
  const exportRows = () => filteredData.map((r) => (
    isSettled
      ? [r.gameName, r.type, r.amount, r.total, r.date, r.roundId, r.transactionId]
      : [r.type, r.amount, r.total, r.date, r.roundId, r.transactionId]
  ))

  const handleExportExcel = () => {
    const head = EXPORT_COLS.map((c) => `<th>${c}</th>`).join('')
    const body = exportRows().map((r) => `<tr>${r.map((v) => `<td>${v}</td>`).join('')}</tr>`).join('')
    const html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="UTF-8"></head><body><table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></body></html>`
    const blob = new Blob([html], { type: 'application/vnd.ms-excel' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = 'livecasinoreport.xls'
    a.click()
    URL.revokeObjectURL(a.href)
  }

  const handleExportPdf = async () => {
    const { default: jsPDF } = await import('jspdf')
    const { default: autoTable } = await import('jspdf-autotable')
    const doc = new jsPDF('l', 'pt')
    const pageWidth = doc.internal.pageSize.getWidth()
    doc.setFontSize(14)
    doc.setTextColor(51, 51, 51)
    doc.text('Live Casino Result', pageWidth / 2, 30, { align: 'center' })
    autoTable(doc, {
      head: [EXPORT_COLS],
      body: exportRows(),
      startY: 45,
      theme: 'striped',
      styles: { fontSize: 9, cellPadding: 5 },
      headStyles: { fillColor: [41, 128, 185], textColor: 255, fontStyle: 'bold', halign: 'left' },
      bodyStyles: { textColor: [85, 85, 85] },
    })
    doc.save('livecasinoreport.pdf')
  }

  const headers = isSettled
    ? [['Game Name'], ['Type'], ['Amount', ' text-right'], ['Total', ' text-right'], ['Date'], ['Round Id'], ['Transaction Id']]
    : [['Type'], ['Amount', ' text-right'], ['Total', ' text-right'], ['Date'], ['Round Id'], ['Transaction Id']]
  const colCount = headers.length

  const tableBlock = (
    <>
      <div className="table-responsive mb-0">
        <div className="table no-footer table-hover table-responsive-sm">
          <table id="eventsListTbl" role="table" aria-busy={loading} aria-colcount={colCount} className="table b-table table-bordered">
            <thead role="rowgroup" className="">
              <tr role="row" className="">
                {headers.map(([label, extra], i) => (
                  <th key={label} role="columnheader" scope="col" tabIndex="0" aria-colindex={i + 1} aria-sort="none" className={`position-relative${extra || ''}`}>
                    <div>{label}</div>
                    <span className="sr-only"> (Click to sort ascending)</span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody role="rowgroup">
              {paged.length === 0 ? (
                <tr role="row" className="b-table-empty-row">
                  <td colSpan={colCount} role="cell" className="">
                    <div role="alert" aria-live="polite">
                      <div className="text-center my-2">{searchValue ? 'There are no records matching your request' : 'There are no records to show'}</div>
                    </div>
                  </td>
                </tr>
              ) : (
                paged.map((r, idx) => (
                  <tr key={r.id || idx} role="row" className="">
                    {(isSettled
                      ? [[r.gameName], [r.type], [r.amount, 'text-right'], [r.total, 'text-right'], [r.date], [r.roundId], [r.transactionId]]
                      : [[r.type], [r.amount, 'text-right'], [r.total, 'text-right'], [r.date], [r.roundId], [r.transactionId]]
                    ).map(([val, cls], i) => (
                      <td key={i} aria-colindex={i + 1} role="cell" className={cls || ''}>{val}</td>
                    ))}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
      {' '}
      <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={handlePageChange} />
    </>
  )

  return (
    <>
      {(showLoader || exporting) && <LoaderOverlay />}
      <form method="post" data-vv-scope="casinoResult" className="ajaxFormSubmit" onSubmit={handleSubmit}>
        <div className="row row5 mb-3">
          <div className="form-group col-xl-2">
            <ClientMultiselect
              value={clientName}
              onChange={(v) => { setClientName(v); setSelectedUsername('') }}
              onSelect={(u) => { setClientName(u.username); setSelectedUsername(u.username) }}
            />
          </div>
          {' '}
          {isSettled && (
            <div className="col-xl-2 mb-3">
              <MxDatePicker value={selectedDate} onChange={setSelectedDate} readonlyInput={false} disableFuture />
            </div>
          )}
          {' '}
          <div className="col-xl-2 mb-3">
            <select name="gtype" className={`form-control${vendorInvalid ? ' is-invalid' : ''}`} aria-required="true" aria-invalid={vendorInvalid ? 'true' : 'false'} value={vendor} onChange={(e) => { setVendor(e.target.value); setVendorInvalid(!e.target.value) }}>
              <option value="">Select</option>
              {' '}
              {VENDOR_OPTIONS.map((o) => (
                <option key={o.value} value={o.value}>{`\n                        ${o.label}\n                      `}</option>
              ))}
            </select>
          </div>
          {' '}
          <div className="col-xl-5 mb-3">
            <button type="submit" id="loaddata" className="btn btn-primary">Load</button>
            {' '}
            <button type="button" id="reset" className="btn btn-light" onClick={handleReset}>Reset</button>
            {isSettled && (
              <>
                {' '}
                <div className="d-inline-block ml-3">
                  <div id="export_1776290159128" className={`d-inline-block${filteredData.length === 0 ? ' disabled' : ''}`}>
                    <button type="button" disabled={filteredData.length === 0} className={`btn mr-1 btn-success${filteredData.length === 0 ? ' disabled' : ''}`} onClick={withExportLoader(handleExportExcel)}><i className="fas fa-file-excel"></i></button>
                  </div>
                  {' '}
                  <button type="button" disabled={filteredData.length === 0} className={`btn btn-danger${filteredData.length === 0 ? ' disabled' : ''}`} onClick={handleExportPdf}><i className="fas fa-file-pdf"></i></button>
                </div>
              </>
            )}
          </div>
        </div>
      </form>
      {' '}
      {isSettled ? (
        <>
          <div className="row">
            <div className="col-6">
              <div id="tickets-table_length" className="dataTables_length">
                <label className="d-inline-flex align-items-center">
                  Show&nbsp;
                  <select
                    className="custom-select custom-select-sm"
                    id="__BVID__68"
                    value={entriesPerPage}
                    onChange={(e) => setEntriesPerPage(Number(e.target.value))}
                  >
                    <option value="25">25</option>
                    <option value="50">50</option>
                    <option value="75">75</option>
                    <option value="100">100</option>
                    <option value="125">125</option>
                    <option value="150">150</option>
                  </select>&nbsp;entries
                </label>
              </div>
            </div>
            {' '}
            <div className="col-6 text-right">
              <div id="tickets-table_filter" className="dataTables_filter text-md-right">
                <label className="d-inline-flex align-items-center">
                  <input
                    type="search"
                    placeholder="Search..."
                    className="form-control form-control-sm ml-2 form-control"
                    id="__BVID__69"
                    value={searchValue}
                    onChange={(e) => setSearchValue(e.target.value)}
                  />
                </label>
              </div>
            </div>
          </div>
          {' '}
          {tableBlock}
        </>
      ) : (
        <div>{tableBlock}</div>
      )}
    </>
  )
}

function LiveCasinoReport() {
  const [activeTab, setActiveTab] = useState('settled')

  return (
    <div data-v-5a10e370="">
      <div data-v-5a10e370="" className="live-bets-report">
        <div className="row">
          <div className="col-12">
            <div className="page-title-box d-flex align-items-center justify-content-between">
              <h4 className="mb-0 font-size-18">Live Casino Result</h4>
              <div className="page-title-right">
                <ol className="breadcrumb m-0">
                  <li className="breadcrumb-item">
                    <Link to="/admin/home" className="" target="_self">Home</Link>
                  </li>
                  <li className="breadcrumb-item active">
                    <span aria-current="location">Casino Result</span>
                  </li>
                </ol>
              </div>
            </div>
          </div>
        </div>

        <div className="row">
          <div className="col-12">
            <div className="card">
              <div className="card-body">
                <div className="tabs" id="__BVID__57">
                  <div className="">
                    <ul role="tablist" className="nav nav-tabs" id="__BVID__57__BV_tab_controls_">
                      <li role="presentation" className="nav-item">
                        <a
                          role="tab"
                          aria-selected={activeTab === 'settled' ? 'true' : 'false'}
                          aria-setsize="2"
                          aria-posinset="1"
                          href="#"
                          target="_self"
                          className={`nav-link${activeTab === 'settled' ? ' active tab-bg-primary' : ''}`}
                          id="__BVID__58___BV_tab_button__"
                          aria-controls="__BVID__58"
                          {...(activeTab === 'settled' ? {} : { tabIndex: '-1' })}
                          onClick={(e) => { e.preventDefault(); setActiveTab('settled') }}
                        >Settled Bets</a>
                      </li>
                      <li role="presentation" className="nav-item">
                        <a
                          role="tab"
                          aria-selected={activeTab === 'unsettled' ? 'true' : 'false'}
                          aria-setsize="2"
                          aria-posinset="2"
                          href="#"
                          target="_self"
                          className={`nav-link${activeTab === 'unsettled' ? ' active tab-bg-primary' : ''}`}
                          id="__BVID__84___BV_tab_button__"
                          aria-controls="__BVID__84"
                          {...(activeTab === 'unsettled' ? {} : { tabIndex: '-1' })}
                          onClick={(e) => { e.preventDefault(); setActiveTab('unsettled') }}
                        >Unsettled Bets</a>
                      </li>
                    </ul>
                  </div>
                  <div className="tab-content p-3 text-muted" id="__BVID__57__BV_tab_container_">
                    <div role="tabpanel" aria-hidden={activeTab !== 'settled' ? 'true' : 'false'} className={`tab-pane${activeTab === 'settled' ? ' active' : ''}`} id="__BVID__58" aria-labelledby="__BVID__58___BV_tab_button__" style={activeTab === 'settled' ? {} : { display: 'none' }}>
                      <ReportPane status="settled" />
                    </div>
                    <div role="tabpanel" aria-hidden={activeTab !== 'unsettled' ? 'true' : 'false'} className={`tab-pane${activeTab === 'unsettled' ? ' active' : ''}`} id="__BVID__84" aria-labelledby="__BVID__84___BV_tab_button__" style={activeTab === 'unsettled' ? {} : { display: 'none' }}>
                      <ReportPane status="unsettled" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default LiveCasinoReport
