import { useState, useEffect, useCallback, useRef } from 'react'
import { Link } from 'react-router-dom'
import { getBetList } from '../../services/api'
import LoaderOverlay from '../../components/LoaderOverlay'
import useExportLoader from '../../hooks/useExportLoader'
import Tooltip from '../../components/Tooltip'
import Pagination from '../../components/Pagination'

// Place Date reference format: DD/MM/YYYY HH:mm:ss
function fmtPlaceDate(raw) {
  if (!raw) return ''
  const d = new Date(raw)
  if (isNaN(d)) return String(raw)
  const p = (n) => String(n).padStart(2, '0')
  return `${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`
}

function CurrentBets() {
  const [activeTab, setActiveTab] = useState('sports')
  // Excel button: page loader for a second, then the download (hooks/useExportLoader)
  const { exporting, withExportLoader } = useExportLoader()
  const [matchStatus, setMatchStatus] = useState('matchbet')
  const [betType, setBetType] = useState('all')
  const [entriesPerPage, setEntriesPerPage] = useState(25)
  const [searchValue, setSearchValue] = useState('')
  const [tableData, setTableData] = useState([])
  const [loading, setLoading] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [totalSoda, setTotalSoda] = useState(0)
  const [totalAmount, setTotalAmount] = useState(0)
  const [showLoader, setShowLoader] = useState(false)
  // Data loads ONLY on Load press — never automatically
  const hasLoadedRef = useRef(false)

  const fetchData = useCallback(async () => {
    setLoading(true)
    try {
      // NOTE: `search` API ko NAHI bhejte — search purely client-side hai
      // (loaded data par filter). Load sirf tab/betType/matchStatus se fetch.
      const params = {
        page: currentPage,
        limit: entriesPerPage,
        gameType: activeTab,
        betType: betType !== 'all' ? betType : undefined,
        matchStatus,
      }
      const response = await getBetList(params)
      if (response?.success) {
        const bets = (response.data || []).map((b) => ({
          id: b.id,
          eventType: b.sport_name || b.game_type,         // "Cricket"
          eventName: b.match_title,
          userName: b.user?.username,
          mName: b.market_type,                           // "MATCH_ODDS"
          nation: b.selection_name,
          userRate: b.odds,
          amount: b.stake_amount,
          placeDate: fmtPlaceDate(b.created_at),
          ip: b.ip_address || b.ip || '',
          browser: b.browser || '',
          betType: String(b.bet_type || '').toLowerCase(), // back/lay -> row border
        }))
        setTableData(bets)
        setTotalPages(response.pagination?.totalPages || 1)
        setTotalSoda(bets.length)
        setTotalAmount(bets.reduce((acc, r) => acc + (parseFloat(r.amount) || 0), 0))
      } else {
        setTableData([])
        setTotalPages(1)
        setTotalSoda(0)
        setTotalAmount(0)
      }
    } catch (err) {
      console.error('Error loading current bets:', err)
      setTableData([])
      setTotalPages(1)
      setTotalSoda(0)
      setTotalAmount(0)
    } finally {
      setLoading(false)
    }
  }, [currentPage, entriesPerPage, activeTab, betType, matchStatus])

  useEffect(() => {
    setCurrentPage(1)
  }, [activeTab, betType, matchStatus, entriesPerPage])

  // tab switch clears the table (columns differ) — press Load to fetch again
  useEffect(() => {
    setTableData([])
    setTotalPages(1)
    setTotalSoda(0)
    setTotalAmount(0)
  }, [activeTab])

  // pagination refetches only after the first explicit Load
  useEffect(() => {
    if (hasLoadedRef.current) fetchData()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentPage])

  const handleLoad = () => {
    hasLoadedRef.current = true
    setCurrentPage(1)
    setShowLoader(true)
    Promise.all([fetchData(), new Promise((r) => setTimeout(r, 1000))])
      .finally(() => setShowLoader(false))
  }

  const handlePageChange = (p) => {
    if (p >= 1 && p <= totalPages) setCurrentPage(p)
  }

  const fmt = (v) => Number(v || 0).toLocaleString()
  // odds/amount: trailing zeros strip ("3.4000" -> "3.4", "100.00" -> "100")
  const num = (v) => { const n = parseFloat(v); return Number.isFinite(n) ? String(n) : '' }

  // Casino tab: no Matched/Unmatched/Deleted radios, 9-column table
  const isCasino = activeTab === 'casino'

  // Search box ab live client-side filter (state se) — loaded rows me se saare
  // dikhne wale columns par case-insensitive match.
  const q = searchValue.trim().toLowerCase()
  const filteredData = q
    ? tableData.filter((b) => [
        b.eventType, b.eventName, b.userName, b.mName, b.nation,
        b.userRate, b.amount, b.placeDate, b.ip, b.browser,
      ].some((v) => String(v ?? '').toLowerCase().includes(q)))
    : tableData

  const EXPORT_COLS = ['Event Type', 'Event Name', 'User Name', 'M Name', 'Nation', 'U Rate', 'Amount', 'Place Date', 'IP', 'Browser']
  const exportRows = () => tableData.map((b) => [
    b.eventType || '', b.eventName || '', b.userName || '', b.mName || '', b.nation || '',
    b.userRate ?? '', fmt(b.amount), b.placeDate, b.ip, b.browser,
  ])

  const handleExportExcel = () => {
    const head = EXPORT_COLS.map((c) => `<th>${c}</th>`).join('')
    const body = exportRows().map((r) => `<tr>${r.map((v) => `<td>${v}</td>`).join('')}</tr>`).join('')
    const html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="UTF-8"></head><body><table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></body></html>`
    const blob = new Blob([html], { type: 'application/vnd.ms-excel' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = 'currentbets.xls'
    a.click()
    URL.revokeObjectURL(a.href)
  }

  const handleExportPdf = async () => {
    const { default: jsPDF } = await import('jspdf')
    const { default: autoTable } = await import('jspdf-autotable')
    const doc = new jsPDF('l', 'pt')
    const pageWidth = doc.internal.pageSize.getWidth()
    doc.setFontSize(14)
    doc.setTextColor(51, 51, 51)
    doc.text('Current Bets', pageWidth / 2, 30, { align: 'center' })
    autoTable(doc, {
      head: [EXPORT_COLS],
      body: exportRows(),
      startY: 45,
      theme: 'striped',
      styles: { fontSize: 8, cellPadding: 5 },
      headStyles: { fillColor: [41, 128, 185], textColor: 255, fontStyle: 'bold', halign: 'left' },
      bodyStyles: { textColor: [85, 85, 85] },
    })
    doc.save('currentbets.pdf')
  }

  return (
    <div data-v-5a10e370="">
      {(showLoader || exporting) && <LoaderOverlay />}
      <div data-v-5a10e370="">
          <div className="row">
            <div className="col-12">
              <div className="page-title-box d-flex align-items-center justify-content-between">
                <h4 className="mb-0 font-size-18">Current Bets</h4>
                <div className="page-title-right">
                  <ol className="breadcrumb m-0">
                    <li className="breadcrumb-item">
                      <Link to="/admin/home" className="" target="_self">Home</Link>
                    </li>
                    <li className="breadcrumb-item active">
                      <span aria-current="location">Current Bets</span>
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>

          <div className="casino-report-tabs">
            <ul className="nav nav-tabs">
              <li className="nav-item">
                <a
                  data-toggle="tab"
                  href="javascript:void(0)"
                  className={`nav-link${activeTab === 'sports' ? ' active' : ''}`}
                  onClick={(e) => { e.preventDefault(); setActiveTab('sports') }}
                >
                  Sports
                </a>
              </li>{' '}
              <li className="nav-item">
                <a
                  data-toggle="tab"
                  href="javascript:void(0)"
                  className={`nav-link${activeTab === 'casino' ? ' active' : ''}`}
                  onClick={(e) => { e.preventDefault(); setActiveTab('casino') }}
                >
                  Casino
                </a>
              </li>
            </ul>
          </div>

          <div className="row">
            <div className="col-12">
              <div className="card">
                <div className="card-body">
                  <div className="report-form mb-3 row align-items-center">
                    <div className="col-md-4 col-lg-3">
                      {!isCasino && (<>
                      <div className="custom-control custom-radio custom-control-inline">
                        <input type="radio" id="customRadio" name="example" value="matchbet"
                          checked={matchStatus === 'matchbet'}
                          onChange={(e) => setMatchStatus(e.target.value)}
                          className="custom-control-input" />{' '}
                        <label htmlFor="customRadio" className="custom-control-label">Matched</label>
                      </div>{' '}
                      <div className="custom-control custom-radio custom-control-inline">
                        <input type="radio" id="customRadio1" name="example" value="unsettled"
                          checked={matchStatus === 'unsettled'}
                          onChange={(e) => setMatchStatus(e.target.value)}
                          className="custom-control-input" />{' '}
                        <label htmlFor="customRadio1" className="custom-control-label">Unmatched</label>
                      </div>{' '}
                      <div className="custom-control custom-radio custom-control-inline">
                        <input type="radio" id="customRadio2" name="example" value="deletebet"
                          checked={matchStatus === 'deletebet'}
                          onChange={(e) => setMatchStatus(e.target.value)}
                          className="custom-control-input" />{' '}
                        <label htmlFor="customRadio2" className="custom-control-label">Deleted</label>
                      </div>
                      </>)}
                    </div>

                    <div className="col-md-8 col-lg-4">
                      <div className="custom-control custom-radio custom-control-inline pl-0">
                        <div className="custom-control custom-radio custom-control-inline">
                          <input type="radio" id="soda-all" name="bettype" value="all"
                            checked={betType === 'all'}
                            onChange={(e) => setBetType(e.target.value)}
                            className="custom-control-input" />{' '}
                          <label htmlFor="soda-all" className="custom-control-label">All</label>
                        </div>{' '}
                        <div className="custom-control custom-radio custom-control-inline">
                          <input type="radio" id="soda-back" name="bettype" value="back"
                            checked={betType === 'back'}
                            onChange={(e) => setBetType(e.target.value)}
                            className="custom-control-input" />{' '}
                          <label htmlFor="soda-back" className="custom-control-label">Back</label>
                        </div>{' '}
                        <div className="custom-control custom-radio custom-control-inline">
                          <input type="radio" id="soda-lay" name="bettype" value="lay"
                            checked={betType === 'lay'}
                            onChange={(e) => setBetType(e.target.value)}
                            className="custom-control-input" />{' '}
                          <label htmlFor="soda-lay" className="custom-control-label">Lay</label>
                        </div>
                      </div>{' '}

                      <div className="custom-control-inline">
                        <button title="Refresh Data" type="button" className="btn mr-2 btn-primary" onClick={handleLoad}>Load</button>{' '}
                        <div id="export_1776286855300" className={`d-inline-block${tableData.length === 0 ? ' disabled' : ''}`}>
                          <button type="button" disabled={tableData.length === 0} className={`btn mr-1 btn-success${tableData.length === 0 ? ' disabled' : ''}`} onClick={withExportLoader(handleExportExcel)}><i className="fas fa-file-excel"></i></button>
                        </div>{' '}
                        <button type="button" disabled={tableData.length === 0} className={`btn btn-danger${tableData.length === 0 ? ' disabled' : ''}`} onClick={handleExportPdf}><i className="fas fa-file-pdf"></i></button>
                      </div>
                    </div>

                    <div className="col-md-12 col-lg-5 text-right">
                      <div className="custom-control-inlinemr-0 mt-1">
                        <h5>Total Soda: <span className="mr-2">{q ? filteredData.length : totalSoda}</span> Total Amount: <span>{fmt(q ? filteredData.reduce((a, r) => a + (parseFloat(r.amount) || 0), 0) : totalAmount)}</span></h5>
                      </div>
                    </div>
                  </div>

                  <div className="row w-100">
                    <div className="col-6">
                      <div id="tickets-table_length" className="dataTables_length">
                        <label className="d-inline-flex align-items-center">
                          Show&nbsp;
                          <select
                            className="custom-select custom-select-sm"
                            id="__BVID__2048"
                            value={entriesPerPage}
                            onChange={(e) => setEntriesPerPage(Number(e.target.value))}
                          >
                            <option value="25">25</option>
                            <option value="50">50</option>
                            <option value="75">75</option>
                            <option value="100">100</option>
                            <option value="125">125</option>
                            <option value="150">150</option>
                          </select>&nbsp;entries
                        </label>
                      </div>
                    </div>
                    <div className="col-6 text-right">
                      <div id="tickets-table_filter" className="dataTables_filter text-md-right">
                        <label className="d-inline-flex align-items-center">
                          <input
                            type="search"
                            placeholder="Search..."
                            className="form-control form-control-sm ml-2 form-control"
                            id="__BVID__2049"
                            value={searchValue}
                            onChange={(e) => setSearchValue(e.target.value)}
                          />
                        </label>
                      </div>
                    </div>
                  </div>

                  <div className="table-responsive mb-0">
                    <div className="table no-footer table-responsive-sm">
                      <table id="eventsListTbl" role="table" aria-busy={loading} aria-colcount={isCasino ? 9 : 11} className="table b-table table-bordered">
                        <colgroup>
                          {(isCasino
                            ? ['200px', 'auto', 'auto', 'auto', 'auto', 'auto', 'auto', 'auto', 'auto']
                            : ['auto', '200px', 'auto', 'auto', 'auto', 'auto', 'auto', 'auto', 'auto', 'auto', 'auto']
                          ).map((w, i) => <col key={i} style={{ width: w }} />)}
                        </colgroup>
                        <thead role="rowgroup" className="">
                          <tr role="row" className="">
                            {(isCasino
                              ? [['Event Name'], ['User Name'], ['Nation'], ['U Rate', ' text-right'], ['Amount', ' text-right'], ['Place Date'], ['IP']]
                              : [['Event Type'], ['Event Name'], ['User Name'], ['M Name'], ['Nation'], ['U Rate', ' text-right'], ['Amount', ' text-right'], ['Place Date'], ['IP']]
                            ).map(([label, extra], i) => (
                              <th key={label} role="columnheader" scope="col" tabIndex="0" aria-colindex={i + 1} aria-sort="none" className={`position-relative${extra || ''}`}>
                                <div>{label}</div>
                                <span className="sr-only"> (Click to sort ascending)</span>
                              </th>
                            ))}
                            <th role="columnheader" scope="col" aria-colindex={isCasino ? 8 : 10} className=""><div>Browser</div></th>
                            <th role="columnheader" scope="col" aria-colindex={isCasino ? 9 : 11} className=""><div>Action</div></th>
                          </tr>
                        </thead>
                        <tbody role="rowgroup">
                          {filteredData.length === 0 ? (
                            <tr role="row" className="b-table-empty-row">
                              <td colSpan={isCasino ? 9 : 11} role="cell" className="">
                                <div role="alert" aria-live="polite">
                                  <div className="text-center my-2">There are no records to show</div>
                                </div>
                              </td>
                            </tr>
                          ) : (
                            filteredData.map((b, ri) => {
                              const rowCls = b.betType === 'lay' ? 'lay-border' : 'back-border'
                              const lead = isCasino
                                ? [b.eventName, b.userName]
                                : [b.eventType, b.eventName, b.userName, b.mName]
                              const cells = [
                                ...lead.map((v) => v),                                     // plain text cells
                                <p className="mb-0">{b.nation}</p>,                        // Nation
                                <p className="text-right mb-0">{num(b.userRate)}</p>,      // U Rate
                                <p className="text-right mb-0">{num(b.amount)}</p>,        // Amount
                                <div>{b.placeDate}</div>,                                  // Place Date
                                <p className="mb-0 pointer">{b.ip}</p>,                    // IP
                                b.browser                                                  // Browser -> Detail + bottom tooltip
                                  ? <Tooltip text={b.browser} placement="bottom"><a href="javascript:void(0)" className="text-success">Detail</a></Tooltip>
                                  : <a href="javascript:void(0)" className="text-success">Detail</a>,
                                <div className="custom-control custom-checkbox">          {/* Action */}
                                  <input type="checkbox" className="custom-control-input" value={String(b.id)} id={`cb-${b.id}`} />
                                  <label className="custom-control-label" htmlFor={`cb-${b.id}`}></label>
                                </div>,
                              ]
                              return (
                                <tr key={b.id} role="row" aria-rowindex={ri + 1} className={rowCls}>
                                  {cells.map((content, i) => (
                                    <td key={i} aria-colindex={i + 1} role="cell" className="">{content}</td>
                                  ))}
                                </tr>
                              )
                            })
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={handlePageChange} />
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>
  )
}

export default CurrentBets
