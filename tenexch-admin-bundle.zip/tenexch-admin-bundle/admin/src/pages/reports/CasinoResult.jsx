import { useState, useEffect, useMemo, useRef } from 'react'
import { Link, useParams } from 'react-router-dom'
import api from '../../services/api'
import LoaderOverlay from '../../components/LoaderOverlay'
import useExportLoader from '../../hooks/useExportLoader'
import CasinoResultModal from '../../components/casino/CasinoResultModal'
import MxDatePicker from '../../components/MxDatePicker'
import Pagination from '../../components/Pagination'
import { API_ENDPOINTS } from '../../config/api'
import { orderCasinoRows } from '../../data/casinoLockOrder'

/* The "Select Casino" options come from GET /admin/table-casino/list — the
   same list General Lock shows (user, 2026-09-22: "dropdown mein bhi same list
   daal, list wali API"): 171 tables, reference order, reference labels
   (server/model/admin/TableCasino.js). An option's value is the table's
   `tableid`, which is exactly the `type` /casino/casino/result-report takes.
   The rows go through orderCasinoRows for a server that predates the seed.
   FALLBACK_OPTIONS is the old hardcoded list — shown only until the API
   answers, or if it fails, so the page is never left with an empty select. */
const FALLBACK_OPTIONS = [
  { value: 'teen', label: 'Teenpatti 1-day' }, { value: 'poker', label: 'Poker 1-Day' },
  { value: '3cardj', label: '3 Cards Judgement' }, { value: 'aaa', label: 'Amar Akbar Anthony' },
  { value: 'ab20', label: 'Andar Bahar' }, { value: 'abj', label: 'Andar Bahar 2' },
  { value: 'baccarat', label: 'Baccarat' }, { value: 'baccarat2', label: 'Baccarat 2' },
  { value: 'btable', label: 'Bollywood Casino' }, { value: 'card32', label: '32 Cards A' },
  { value: 'card32eu', label: '32 Cards B' }, { value: 'cmatch20', label: 'Cricket Match 20-20' },
  { value: 'cmeter', label: 'Casino Meter' }, { value: 'cricketv', label: 'Cricket V' },
  { value: 'cricketv2', label: 'Cricket V2' }, { value: 'cricketv3', label: '5Five Cricket' },
  { value: 'dt20', label: '20-20 Dragon Tiger' }, { value: 'dt202', label: '20-20 Dragon Tiger 2' },
  { value: 'dt6', label: '1 Day Dragon Tiger' }, { value: 'dtl20', label: '20-20 D T L' },
  { value: 'lottcard', label: 'lottcard' }, { value: 'lucky7', label: 'Lucky 7 - A' },
  { value: 'lucky7eu', label: 'Lucky 7 - B' }, { value: 'poker20', label: '20-20 Poker' },
  { value: 'poker6', label: 'Poker 6 Players' }, { value: 'teen20', label: '20-20 Teenpatti' },
  { value: 'teen8', label: 'Teenpatti Open' }, { value: 'teen9', label: 'Teenpatti Test' },
  { value: 'war', label: 'Casino War' }, { value: 'worli', label: 'Worli Matka' },
  { value: 'worli2', label: 'Instant Worli' }, { value: 'teen6', label: 'Teenpatti - 2.0' },
  { value: 'queen', label: 'Queen' }, { value: 'race20', label: 'Race20' },
  { value: 'lucky7eu2', label: 'Lucky 7 - C' }, { value: 'superover', label: 'Super Over' },
  { value: 'trap', label: 'The Trap' }, { value: 'patti2', label: '2 Cards Teenpatti' },
  { value: 'teensin', label: '29Card Baccarat' }, { value: 'teenmuf', label: 'Muflis Teenpatti' },
  { value: 'race17', label: 'Race to 17' }, { value: 'teen20b', label: '20-20 Teenpatti B' },
  { value: 'trio', label: 'Trio' }, { value: 'notenum', label: 'Note Number' },
  { value: 'teen2024', label: 'Teen 20 24' }, { value: 'kbc', label: 'K.B.C' },
  { value: 'teen120', label: '1 CARD 20-20' }, { value: 'teen1', label: '1 CARD ONE-DAY' },
  { value: 'vteen20', label: 'V-20-20 Teenpatti' }, { value: 'vteen', label: 'V-Teenpatti 1-day' },
  { value: 'vdt6', label: 'V-1 Day Dragon Tiger' }, { value: 'vdt20', label: 'V-20-20 Dragon Tiger' },
  { value: 'vlucky7', label: 'V-Lucky 7 - A' }, { value: 'vrace17', label: 'V-Race to 17' },
  { value: 'vteenmuf', label: 'V-Muflis Teenpatti' }, { value: 'vaaa', label: 'V-Amar Akbar Anthony' },
  { value: 'vbtable', label: 'V-Bollywood Casino' }, { value: 'vbaccarat', label: 'V-Baccarat' },
  { value: 'vtrio', label: 'V-Trio' }, { value: 'vtrap', label: 'V-The Trap' },
  { value: 'ab3', label: 'ANDAR BAHAR 50 CARDS' }, { value: 'vdtl20', label: 'V-20-20 D T L' },
  { value: 'aaa2', label: 'Amar Akbar Anthony 2' }, { value: 'roulette', label: 'roulette' },
  { value: 'race2', label: 'Race to 2nd' }, { value: 'teen3', label: 'Instant Teenpatti' },
  { value: 'dum10', label: 'Dus ka Dum' }, { value: 'cmeter1', label: '1 Card Meter' },
  { value: 'teen32', label: 'Instant Teenpatti 2.0' }, { value: 'sicbo', label: 'Sic Bo' },
  { value: 'ballbyball', label: 'Ball by ball' }, { value: 'roulette1', label: 'roulette1' },
  { value: 'teen33', label: 'Instant Teenpatti 3.0' }, { value: 'roulette2', label: 'roulette2' },
  { value: 'superover2', label: 'Super Over2' }, { value: 'roulette3', label: 'roulette3' },
  { value: 'sicbo2', label: 'Sic Bo 2' }, { value: 'teen41', label: 'Queen top open teenpatti' },
  { value: 'teen42', label: 'Jack top open teenpatti' }, { value: 'lucky15', label: 'Lucky 15' },
  { value: 'goal', label: 'Goal' }, { value: 'ab4', label: 'Andar-Bahar 150 card' },
  { value: 'superover3', label: 'Mini SuperOver' }, { value: 'ourroullete', label: 'Unique Roulette' },
  { value: 'teen20c', label: '20-20 Teenpatti C' }, { value: 'btable2', label: 'Bollywood Casino 2' },
  { value: 'teenjoker', label: 'Teenpatti Joker' }, { value: 'joker1', label: 'Unlimited Joker One Day' },
  { value: 'joker20', label: 'Teenpatti Joker 20-20' }, { value: 'joker120', label: 'Unlimited Joker 20-20' },
  { value: 'poison20', label: 'Teenpatti Poison 20-20' }, { value: 'teenunique', label: 'Unique Teenpatti' },
  { value: 'poison', label: 'Teenpatti Poison One Day' }, { value: 'roulette11', label: 'VIP Roulette' },
  { value: 'roulette12', label: 'Beach Roulette' }, { value: 'roulette13', label: 'Regular Roulette' },
  { value: 'pteen', label: 'Premium Teenpatti 1-day' }, { value: 'pteen20', label: 'Premium 20-20 Teenpatti' },
  { value: 'pdt6', label: 'Premium 1 Day Dragon Tiger' }, { value: 'pdt20', label: 'Premium 20-20 Dragon Tiger' },
  { value: 'plucky7', label: 'Premium Lucky 7' }, { value: 'pcard32', label: 'Premium 32 Cards' },
  { value: 'pbaccarat', label: 'Premium Baccarat' }, { value: 'tteen', label: 'Tembo Teenpatti 1-day' },
  { value: 'tteen20', label: 'Tembo 20-20 Teenpatti' }, { value: 'tdt6', label: 'Tembo 1 Day Dragon Tiger' },
  { value: 'tdt20', label: 'Tembo 20-20 Dragon Tiger' }, { value: 'tlucky7', label: 'Tembo Lucky 7' },
  { value: 'tcard32', label: 'Tembo 32 Cards' }, { value: 'tbaccarat', label: 'Tembo Baccarat' },
  { value: 'lucky5', label: 'Lucky 6' }, { value: 'mogambo', label: 'Mogambo' },
  { value: 'dolidana', label: 'Dolidana' }, { value: 'teen20v', label: '20-20 Teenpatti VIP' },
  { value: 'worli3', label: 'Matka' }, { value: 'teen62', label: 'V VIP Teenpatti 1-day' },
  { value: 'bb', label: 'DimCL' }, { value: 'goal2', label: 'Goal 2' },
  { value: 'exanew1', label: 'EXA Live' }, { value: 'exanew2', label: 'EXA Fantasy' },
  { value: 'exanew3', label: 'EXA Slot' },
]

const GOAL_WINNERS = {
  1: 'Cristiano Ronaldo', 2: 'Lionel Messi', 3: 'Robert Lewandowski',
  4: 'Karim Benzema', 5: 'Edinson Cavani', 6: 'Luis Suarez', 7: 'Neymar',
  8: 'Sergio Aguero', 9: 'Olivier Giroud', 10: 'Mohamed Salah',
  11: 'Kylian Mbappe', 12: 'No Goal',
}

const mapWinDisplay = (win, gameType) => {
  const norm = (gameType || '').toLowerCase().trim()
  if (norm === 'goal' || norm === 'goal2') {
    return GOAL_WINNERS[Number(win)] || win || '-'
  }
  if (norm === 'dolidana') {
    // win = sum total (2-12) — as-is
    return win || '-'
  }
  if (norm === 'superover2' || norm === 'superover3') {
    return win === '1' ? 'I' : win === '2' ? 'E' : win || '-'
  }
  if (['race20', 'race17', 'vrace17', 'race2'].includes(norm)) {
    const suitMap = { '1': 'Spade', '2': 'Heart', '3': 'Club', '4': 'Diamond' }
    return suitMap[win] || win || '-'
  }
  const isPlayer = win === '1' ? 'Player A' : win === '2' ? 'Player B' : null
  return isPlayer || win || '-'
}

function CasinoResult() {
  // /admin/reports/casinoresult/:casinoname — game pages ke "..." link se
  // aane par casino preselect hoke data auto-load hota hai
  const { casinoname } = useParams()
  const paramLoadedRef = useRef(false)
  const [gameType, setGameType] = useState(casinoname || '')
  // Excel button: page loader for a second, then the download (hooks/useExportLoader)
  const { exporting, withExportLoader } = useExportLoader()
  const [selectedDate, setSelectedDate] = useState('')
  const [entriesPerPage, setEntriesPerPage] = useState(25)
  const [searchValue, setSearchValue] = useState('')
  const [tableData, setTableData] = useState([])
  const [loading, setLoading] = useState(false)
  const [showLoader, setShowLoader] = useState(false)
  // Select Casino shows the red is-invalid outline from the start (reference)
  // until a casino is picked
  const [gtypeInvalid, setGtypeInvalid] = useState(!casinoname)
  /* Reference (recording, 2026-09-22): on first load the field is BLANK (no
     text, red outline); only after Reset does it read "Select Casino". The
     placeholder option is therefore blank until Reset has happened. */
  const [wasReset, setWasReset] = useState(false)
  const [casinoOptions, setCasinoOptions] = useState(FALLBACK_OPTIONS)
  useEffect(() => {
    let alive = true
    api.get(API_ENDPOINTS.TABLE_CASINO.LIST)
      .then((res) => {
        const rows = res.data?.success ? res.data.data : null
        if (!alive || !Array.isArray(rows) || rows.length === 0) return
        setCasinoOptions(orderCasinoRows(rows).map((r) => ({ value: r.tableid, label: r.tablename })))
      })
      .catch(() => { /* keep the fallback */ })
    return () => { alive = false }
  }, [])
  // Market Id click -> wahi casino result modal (game pages wala)
  const [resultMid, setResultMid] = useState(null)
  const [currentPage, setCurrentPage] = useState(1)

  useEffect(() => {
    const d = new Date()
    const y = d.getFullYear()
    const m = String(d.getMonth() + 1).padStart(2, '0')
    const day = String(d.getDate()).padStart(2, '0')
    setSelectedDate(`${y}-${m}-${day}`)
  }, [])

  const fetchResults = async (type) => {
    if (!type) return
    setLoading(true)
    try {
      const payload = {
        type,
        date: selectedDate,
        limit: entriesPerPage,
        search: searchValue,
      }
      // result-report winner ka NAAM bhi deta hai (winName = detail-results
      // ka winnat, server-merged); purane deploy pe endpoint na ho to
      // last-results pe fallback
      let res
      try {
        res = await api.post('/casino/casino/result-report', payload)
      } catch (err) {
        res = await api.post('/casino/casino/last-results', payload)
      }
      // API shape (live api.tenexchn.com, verified 2026-09-19 for every casino
      // type incl. v*): { success, data: { g, res: [{ mid, win, winName }] } }
      // → axios res.data.data.res. Older/other deploys wrapped it one level
      // deeper ({ data: { data: { res } } }), so accept both.
      const body = res?.data
      const rows = body?.data?.res ?? body?.data?.data?.res ?? body?.res
      if (Array.isArray(rows)) {
        setTableData(rows.map((r) => ({
          marketId: r.mid,
          // 20-20 Poker drawn round (win "0", archived by us): no winner shown.
          winner: type === 'poker20' && String(r.win) === '0'
            ? ''
            : r.winName || mapWinDisplay(String(r.win ?? ''), type),
        })))
      } else {
        setTableData([])
      }
    } catch (err) {
      console.error('Error loading casino results:', err)
      setTableData([])
    } finally {
      setLoading(false)
    }
  }

  // URL param wala casino — date set hote hi ek baar auto-load
  useEffect(() => {
    if (!casinoname || !selectedDate || paramLoadedRef.current) return
    paramLoadedRef.current = true
    setShowLoader(true)
    Promise.all([fetchResults(casinoname), new Promise((r) => setTimeout(r, 1000))])
      .finally(() => setShowLoader(false))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [casinoname, selectedDate])

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!gameType) {
      setGtypeInvalid(true)
      return
    }
    setGtypeInvalid(false)
    setShowLoader(true)
    Promise.all([fetchResults(gameType), new Promise((r) => setTimeout(r, 1000))])
      .finally(() => setShowLoader(false))
  }

  const handleReset = () => {
    setGameType('')
    setGtypeInvalid(true)
    setWasReset(true)   // from now on the empty choice reads "Select Casino" (reference)
    setSearchValue('')
    setCurrentPage(1)
    setShowLoader(true)
    setTimeout(() => {
      setTableData([])
      setShowLoader(false)
    }, 1000)
  }

  const EXPORT_COLS = ['Market Id', 'Winner']
  const exportRows = () => filteredData.map((r) => [r.marketId, r.winner])

  const handleExportExcel = () => {
    const head = EXPORT_COLS.map((c) => `<th>${c}</th>`).join('')
    const body = exportRows().map((r) => `<tr>${r.map((v) => `<td>${v}</td>`).join('')}</tr>`).join('')
    const html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="UTF-8"></head><body><table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></body></html>`
    const blob = new Blob([html], { type: 'application/vnd.ms-excel' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = 'casinoresult.xls'
    a.click()
    URL.revokeObjectURL(a.href)
  }

  const handleExportPdf = async () => {
    const { default: jsPDF } = await import('jspdf')
    const { default: autoTable } = await import('jspdf-autotable')
    const doc = new jsPDF('l', 'pt')
    const pageWidth = doc.internal.pageSize.getWidth()
    doc.setFontSize(14)
    doc.setTextColor(51, 51, 51)
    doc.text('Our Casino Result', pageWidth / 2, 30, { align: 'center' })
    autoTable(doc, {
      head: [EXPORT_COLS],
      body: exportRows(),
      startY: 45,
      theme: 'striped',
      styles: { fontSize: 10, cellPadding: 6 },
      headStyles: { fillColor: [41, 128, 185], textColor: 255, fontStyle: 'bold', halign: 'left' },
      bodyStyles: { textColor: [85, 85, 85] },
    })
    doc.save('casinoresult.pdf')
  }

  const filteredData = useMemo(() => {
    if (!searchValue.trim()) return tableData
    const q = searchValue.toLowerCase()
    return tableData.filter((r) =>
      String(r.marketId || '').toLowerCase().includes(q) ||
      String(r.winner || '').toLowerCase().includes(q)
    )
  }, [tableData, searchValue])

  const totalPages = Math.max(1, Math.ceil(filteredData.length / entriesPerPage))
  const startIndex = (currentPage - 1) * entriesPerPage
  const pagedData = filteredData.slice(startIndex, startIndex + entriesPerPage)

  useEffect(() => { setCurrentPage(1) }, [searchValue, entriesPerPage, tableData.length])

  const handlePageChange = (p) => {
    if (p >= 1 && p <= totalPages) setCurrentPage(p)
  }

  const pageNumbers = []
  for (let i = 1; i <= totalPages; i++) pageNumbers.push(i)

  return (
    <div data-v-5a10e370="">
      {(showLoader || exporting) && <LoaderOverlay />}
      <div data-v-5a10e370="">
          <div className="row">
            <div className="col-12">
              <div className="page-title-box d-flex align-items-center justify-content-between">
                <h4 className="mb-0 font-size-18">Our Casino Result</h4>
                <div className="page-title-right">
                  <ol className="breadcrumb m-0">
                    <li className="breadcrumb-item">
                      <Link to="/admin/home" className="" target="_self">Home</Link>
                    </li>
                    <li className="breadcrumb-item active">
                      <span aria-current="location">Our Casino Result</span>
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col-12">
              <div className="card">
                <div className="card-body">
                  <form method="post" data-vv-scope="casinoResult" className="ajaxFormSubmit" onSubmit={handleSubmit}>
                    <div className="row row5 mb-3">
                      <div className="col-md-3 mb-2">
                        <MxDatePicker value={selectedDate} onChange={setSelectedDate} readonlyInput={false} disableFuture />
                      </div>
                      <div className="col-md-3 mb-2">
                        <select name="gtype" className={`form-control${gtypeInvalid ? ' is-invalid' : ''}`} aria-required="true" aria-invalid={gtypeInvalid ? 'true' : 'false'} value={gameType} onChange={(e) => { setGameType(e.target.value); setGtypeInvalid(!e.target.value) }}>
                          {/* The empty choice: blank on first load, "Select Casino" once
                              Reset has been pressed — exactly the reference's two states
                              (recording, 2026-09-22). Ours had no empty option at all and
                              faked "nothing chosen" with selectedIndex = -1, which kept the
                              last pick on screen after Reset. */}
                          <option value="">{wasReset ? 'Select Casino' : ''}</option>
                          {casinoOptions.map((o) => (
                            <option key={o.value} value={o.value}>{o.label}</option>
                          ))}
                        </select>
                      </div>
                      <div className="col-md-6 mb-2">
                        <button type="submit" id="loaddata" className="btn btn-primary">Load</button>
                        {' '}
                        <button type="button" id="reset" className="btn btn-light" onClick={handleReset}>Reset</button>
                        {' '}
                        <div className="d-inline-block ml-3">
                          <div id="export_1776289801651" className={`d-inline-block${filteredData.length === 0 ? ' disabled' : ''}`}>
                            <button type="button" disabled={filteredData.length === 0} className={`btn mr-1 btn-success${filteredData.length === 0 ? ' disabled' : ''}`} onClick={withExportLoader(handleExportExcel)}><i className="fas fa-file-excel"></i></button>
                          </div>
                          {' '}
                          <button type="button" disabled={filteredData.length === 0} className={`btn btn-danger${filteredData.length === 0 ? ' disabled' : ''}`} onClick={handleExportPdf}><i className="fas fa-file-pdf"></i></button>
                        </div>
                      </div>
                    </div>
                  </form>

                  <div className="row">
                    <div className="col-6">
                      <div id="tickets-table_length" className="dataTables_length">
                        <label className="d-inline-flex align-items-center">
                          Show&nbsp;
                          <select
                            className="custom-select custom-select-sm"
                            id="__BVID__62"
                            value={entriesPerPage}
                            onChange={(e) => setEntriesPerPage(Number(e.target.value))}
                          >
                            <option value="25">25</option>
                            <option value="50">50</option>
                            <option value="75">75</option>
                            <option value="100">100</option>
                            <option value="125">125</option>
                            <option value="150">150</option>
                          </select>&nbsp;entries
                        </label>
                      </div>
                    </div>
                    <div className="col-6 text-right">
                      <div id="tickets-table_filter" className="dataTables_filter text-md-right">
                        <label className="d-inline-flex align-items-center">
                          <input
                            type="search"
                            placeholder="Search..."
                            className="form-control form-control-sm ml-2 form-control"
                            id="__BVID__63"
                            value={searchValue}
                            onChange={(e) => setSearchValue(e.target.value)}
                          />
                        </label>
                      </div>
                    </div>
                  </div>

                  <div className="table-responsive mb-0">
                    <div className="table no-footer table-hover table-responsive-sm">
                      <table
                        id="eventsListTbl"
                        role="table"
                        aria-busy={loading}
                        aria-colcount="2"
                        className="table b-table table-bordered b-table-fixed"
                      >
                        <thead role="rowgroup" className="">
                          <tr role="row" className="">
                            <th role="columnheader" scope="col" tabIndex="0" aria-colindex="1" aria-sort="none" className="position-relative">
                              <div>Market Id</div>
                              <span className="sr-only"> (Click to sort ascending)</span>
                            </th>
                            <th role="columnheader" scope="col" tabIndex="0" aria-colindex="2" aria-sort="none" className="position-relative">
                              <div>Winner</div>
                              <span className="sr-only"> (Click to sort ascending)</span>
                            </th>
                          </tr>
                        </thead>
                        <tbody role="rowgroup">
                          {pagedData.length === 0 ? (
                            <tr role="row" className="b-table-empty-row">
                              <td colSpan="2" role="cell" className="">
                                <div role="alert" aria-live="polite">
                                  <div className="text-center my-2">There are no records to show</div>
                                </div>
                              </td>
                            </tr>
                          ) : (
                            pagedData.map((row, idx) => (
                              <tr key={row.marketId || idx} role="row" aria-rowindex={startIndex + idx + 1} className="">
                                <td aria-colindex="1" role="cell" className="">
                                  <a href="javascript:void(0)" className="link-default" onClick={() => setResultMid(row.marketId)}>{row.marketId}</a>
                                </td>
                                <td aria-colindex="2" role="cell" className="">{row.winner}</td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={handlePageChange} />
                </div>
              </div>
            </div>
          </div>
      </div>

      <CasinoResultModal
        show={!!resultMid}
        onClose={() => setResultMid(null)}
        gameType={gameType}
        gameName={casinoOptions.find((o) => o.value === gameType)?.label || gameType}
        mid={resultMid}
      />
    </div>
  )
}

export default CasinoResult
