import { useState, useMemo } from 'react'
import { Link } from 'react-router-dom'
import api from '../../services/api'
import ClientMultiselect from '../../components/ClientMultiselect'
import LoaderOverlay from '../../components/LoaderOverlay'
import useExportLoader from '../../hooks/useExportLoader'
import Pagination from '../../components/Pagination'

const HEADERS = [
  ['User Name'], ['Agent Name'], ['Created Date'], ['Last Login'],
  ['First Deposit Date'], ['Last Deposit Date'], ['Deposit'],
  ['Sports Balance', ' text-right'], ['Casino Balance', ' text-right'],
  ['Third Party Credit Balance', ' text-right'], ['Sport Book Balance', ' text-right'],
  ['Referral Code'],
]

function UserRegisterDetail() {
  const [clientName, setClientName] = useState('')
  // Excel button: page loader for a second, then the download (hooks/useExportLoader)
  const { exporting, withExportLoader } = useExportLoader()
  const [selectedUsername, setSelectedUsername] = useState('')
  const [typeVal, setTypeVal] = useState('1')
  const [entriesPerPage, setEntriesPerPage] = useState(25)
  const [searchValue, setSearchValue] = useState('')
  const [tableData, setTableData] = useState([])
  const [loading, setLoading] = useState(false)
  const [showLoader, setShowLoader] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)

  const fetchData = async (page) => {
    setLoading(true)
    try {
      const response = await api.get('/admin/reports/user-register-detail', {
        params: { page, limit: entriesPerPage, username: selectedUsername || clientName, type: typeVal },
      })
      if (response.data?.success && Array.isArray(response.data.data)) {
        setTableData(response.data.data)
        setTotalPages(response.data.pagination?.totalPages || 1)
      } else {
        setTableData([])
        setTotalPages(1)
      }
    } catch (err) {
      console.error('Error loading user register detail:', err)
      setTableData([])
      setTotalPages(1)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    setCurrentPage(1)
    setShowLoader(true)
    Promise.all([fetchData(1), new Promise((r) => setTimeout(r, 1000))])
      .finally(() => setShowLoader(false))
  }

  const handleReset = () => {
    setClientName('')
    setSelectedUsername('')
    setTypeVal('1')
    setSearchValue('')
    setCurrentPage(1)
    setShowLoader(true)
    setTimeout(() => {
      setTableData([])
      setTotalPages(1)
      setShowLoader(false)
    }, 1000)
  }

  // Balance columns: reference me value ke sign se color — >=0 green (text-success),
  // <0 red (text-danger). Empty/non-numeric -> sirf text-right (no color, reference
  // Sport Book Balance jaisa).
  const balCls = (v) => {
    const n = Number(v)
    if (v === '' || v == null || Number.isNaN(n)) return 'text-right'
    return `text-right ${n < 0 ? 'text-danger' : 'text-success'}`
  }

  const rowCells = (r) => {
    const sportsBal = r.sportsBalance ?? r.sports_balance ?? ''
    const casinoBal = r.casinoBalance ?? r.casino_balance ?? ''
    const tpBal = r.thirdPartyCreditBalance ?? r.third_party_credit_balance ?? ''
    const sbBal = r.sportBookBalance ?? r.sport_book_balance ?? ''
    return [
      [r.username || ''], [r.agentName || r.agent_name || ''],
      [r.createdDate || r.created_at || ''], [r.lastLogin || r.last_login || ''],
      [r.firstDepositDate || r.first_deposit_date || ''], [r.lastDepositDate || r.last_deposit_date || ''],
      [r.deposit ?? ''], [sportsBal, balCls(sportsBal)],
      [casinoBal, balCls(casinoBal)],
      [tpBal, balCls(tpBal)],
      [sbBal, balCls(sbBal)],
      [r.referralCode || r.referral_code || ''],
    ]
  }

  const filteredData = useMemo(() => {
    if (!searchValue.trim()) return tableData
    const q = searchValue.toLowerCase()
    return tableData.filter((r) => Object.values(r).some((v) => String(v || '').toLowerCase().includes(q)))
  }, [tableData, searchValue])

  const handlePageChange = (p) => {
    if (p >= 1 && p <= totalPages) {
      setCurrentPage(p)
      fetchData(p)
    }
  }

  const EXPORT_COLS = HEADERS.map(([label]) => label)
  const exportRows = () => filteredData.map((r) => rowCells(r).map(([v]) => v))

  const handleExportExcel = () => {
    const head = EXPORT_COLS.map((c) => `<th>${c}</th>`).join('')
    const body = exportRows().map((r) => `<tr>${r.map((v) => `<td>${v ?? ''}</td>`).join('')}</tr>`).join('')
    const html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="UTF-8"></head><body><table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></body></html>`
    const blob = new Blob([html], { type: 'application/vnd.ms-excel' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = 'userregisterdetail.xls'
    a.click()
    URL.revokeObjectURL(a.href)
  }

  const handleExportPdf = async () => {
    const { default: jsPDF } = await import('jspdf')
    const { default: autoTable } = await import('jspdf-autotable')
    const doc = new jsPDF('l', 'pt')
    const pageWidth = doc.internal.pageSize.getWidth()
    doc.setFontSize(14)
    doc.setTextColor(51, 51, 51)
    doc.text('User Register Detail', pageWidth / 2, 30, { align: 'center' })
    autoTable(doc, {
      head: [EXPORT_COLS],
      body: exportRows(),
      startY: 45,
      theme: 'striped',
      styles: { fontSize: 7, cellPadding: 4 },
      headStyles: { fillColor: [41, 128, 185], textColor: 255, fontStyle: 'bold', halign: 'left' },
      bodyStyles: { textColor: [85, 85, 85] },
    })
    doc.save('userregisterdetail.pdf')
  }

  return (
    <div data-v-5a10e370="">
      {(showLoader || exporting) && <LoaderOverlay />}
      <div data-v-5a10e370="">
          <div className="row">
            <div className="col-12">
              <div className="page-title-box d-flex align-items-center justify-content-between">
                <h4 className="mb-0 font-size-18">User Register Detail</h4>
                <div className="page-title-right">
                  <ol className="breadcrumb m-0">
                    <li className="breadcrumb-item">
                      <Link to="/admin/home" className="" target="_self">Home</Link>
                    </li>
                    <li className="breadcrumb-item active">
                      <span aria-current="location">User Registration Report</span>
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col-12">
              <div className="card">
                <div className="card-body">
                  <div className="report-form mb-3">
                    <form method="post" className="ajaxFormSubmit" onSubmit={handleSubmit}>
                      <div className="row row5">
                        <div className="col-2">
                          <div className="form-group user-lock-search" style={{ position: 'relative' }}>
                            <label htmlFor="d-inline-block">Search By Client Name</label>{' '}
                            <ClientMultiselect
                              value={clientName}
                              onChange={(v) => { setClientName(v); setSelectedUsername('') }}
                              onSelect={(u) => { setClientName(u.username); setSelectedUsername(u.username) }}
                            />
                          </div>
                        </div>
                        {' '}
                        <div className="col-2">
                          <div className="form-group">
                            <label>Type</label>{' '}
                            <select className="form-control" value={typeVal} onChange={(e) => setTypeVal(e.target.value)}>
                              <option value="1">All</option>
                              {' '}
                              <option value="2">Created Date</option>
                              {' '}
                              <option value="3">Last Login Date</option>
                            </select>
                          </div>
                        </div>
                        {' '}
                        <div className="col-3">
                          <label style={{ width: '100%' }}>&nbsp;</label>{' '}
                          <button type="submit" id="loaddata" className="btn btn-primary">Load</button>
                          {' '}
                          <button type="button" id="reset" className="btn btn-light" onClick={handleReset}>Reset</button>
                          {' '}
                          <div id="export_1776323055834" className={`d-inline-block${filteredData.length === 0 ? ' disabled' : ''}`}>
                            <button type="button" disabled={filteredData.length === 0} className={`btn btn-success${filteredData.length === 0 ? ' disabled' : ''}`} onClick={withExportLoader(handleExportExcel)}><i className="fas fa-file-excel"></i></button>
                          </div>
                          {' '}
                          <button type="button" disabled={filteredData.length === 0} className={`btn btn-danger${filteredData.length === 0 ? ' disabled' : ''}`} onClick={handleExportPdf}><i className="fas fa-file-pdf"></i></button>
                        </div>
                      </div>
                    </form>
                  </div>
                  {' '}
                  <div className="row">
                    <div className="col-sm-12 col-md-6">
                      <div id="tickets-table_length" className="dataTables_length">
                        <label className="d-inline-flex align-items-center">
                          Show&nbsp;
                          <select
                            className="custom-select custom-select-sm"
                            id="__BVID__1752"
                            value={entriesPerPage}
                            onChange={(e) => { setEntriesPerPage(Number(e.target.value)); setCurrentPage(1) }}
                          >
                            <option value="25">25</option>
                            <option value="50">50</option>
                            <option value="75">75</option>
                            <option value="100">100</option>
                            <option value="125">125</option>
                            <option value="150">150</option>
                          </select>&nbsp;entries
                        </label>
                      </div>
                    </div>
                    {' '}
                    <div className="col-sm-12 col-md-6">
                      <div id="tickets-table_filter" className="dataTables_filter text-md-right">
                        <label className="d-inline-flex align-items-center">
                          Search:{' '}
                          <input
                            type="search"
                            placeholder="Search..."
                            className="form-control form-control-sm ml-2 form-control"
                            id="__BVID__1753"
                            value={searchValue}
                            onChange={(e) => setSearchValue(e.target.value)}
                          />
                        </label>
                      </div>
                    </div>
                  </div>
                  {' '}
                  <div className="table-responsive mb-0" style={{ whiteSpace: 'nowrap' }}>
                    <div className="table no-footer table-hover table-responsive-sm">
                      <table id="accStmtTable" role="table" aria-busy={loading} aria-colcount="12" className="table b-table table-bordered">
                        <colgroup>
                          {HEADERS.map((_, i) => <col key={i} style={{ width: 'auto' }} />)}
                        </colgroup>
                        <thead role="rowgroup" className="">
                          <tr role="row" className="">
                            {HEADERS.map(([label, extra], i) => (
                              <th key={label} role="columnheader" scope="col" tabIndex="0" aria-colindex={i + 1} aria-sort="none" className={`position-relative${extra || ''}`}>
                                <div>{label}</div>
                                <span className="sr-only"> (Click to sort ascending)</span>
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody role="rowgroup">
                          {filteredData.length === 0 ? (
                            <tr role="row" className="b-table-empty-row">
                              <td colSpan="12" role="cell" className="">
                                <div role="alert" aria-live="polite">
                                  <div className="text-center my-2">{searchValue ? 'There are no records matching your request' : 'There are no records to show'}</div>
                                </div>
                              </td>
                            </tr>
                          ) : (
                            filteredData.map((r, idx) => (
                              <tr key={idx} role="row" className="">
                                {rowCells(r).map(([val, cls], i) => (
                                  <td key={i} aria-colindex={i + 1} role="cell" className={cls || ''}>{val}</td>
                                ))}
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                  {' '}
                  <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={handlePageChange} />
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>
  )
}

export default UserRegisterDetail
