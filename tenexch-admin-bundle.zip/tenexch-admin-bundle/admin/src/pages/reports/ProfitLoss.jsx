import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import api from '../../services/api'
import LoaderOverlay from '../../components/LoaderOverlay'
import useExportLoader from '../../hooks/useExportLoader'
import Pagination from '../../components/Pagination'

// Display labels for account types (API sends uppercase e.g. "AGENT")
const ACCOUNT_TYPE_LABELS = {
  USER: 'User', AGENT: 'Agent', MASTER: 'Master', SUPERMASTER: 'SuperMaster',
  SUPERADMIN: 'SuperAdmin', COMPANY: 'Company', ADMIN: 'Admin', STAFF: 'Staff', OWNER: 'Owner',
}
const accountType = (t) => {
  const key = String(t || '').toUpperCase()
  if (ACCOUNT_TYPE_LABELS[key]) return ACCOUNT_TYPE_LABELS[key]
  const s = String(t || '')
  return s ? s.charAt(0).toUpperCase() + s.slice(1).toLowerCase() : s
}

function ProfitLoss() {
  const [filterType, setFilterType] = useState('all')
  // Excel button: page loader for a second, then the download (hooks/useExportLoader)
  const { exporting, withExportLoader } = useExportLoader()
  const [searchValue, setSearchValue] = useState('')
  const [tableData, setTableData] = useState([])
  const [loading, setLoading] = useState(false)
  // Full-page loader only on explicit Load/Reset presses (not initial load)
  const [showLoader, setShowLoader] = useState(false)
  // Client-side paging — /admin/profitloss/all poora set ek hi baar deta hai
  // (koi page/limit param nahi). Footer totals aur export jaan-boojh kar
  // filteredData par rehte hain, page slice par nahi.
  const [entriesPerPage, setEntriesPerPage] = useState(25)
  const [currentPage, setCurrentPage] = useState(1)

  const fetchData = async () => {
    setLoading(true)
    try {
      const response = await api.get('/admin/profitloss/all', { params: { search: searchValue, type: filterType } })
      if (response.data?.success) {
        setTableData(response.data.data || [])
      } else {
        setTableData([])
      }
    } catch (err) {
      console.error('Error loading profit/loss:', err)
      setTableData([])
    } finally {
      setLoading(false)
    }
  }

  const handleLoad = () => {
    setShowLoader(true)
    Promise.all([fetchData(), new Promise((r) => setTimeout(r, 1000))])
      .finally(() => setShowLoader(false))
  }

  const handleReset = () => {
    setFilterType('all')
    setSearchValue('')
    setShowLoader(true)
    setTimeout(() => {
      setTableData([])
      setShowLoader(false)
    }, 1000)
  }

  // Export — same columns as the visible table, bank-style pdf layout
  const EXPORT_COLS = ['No', 'User Name', 'Level', 'Casino pts', 'Sport pts', 'Third Party pts', 'Profit/Loss', 'Ptype']
  const exportRows = () => filteredData.map((r, idx) => [
    idx + 1, r.username || '-', accountType(r.level || r.user_type) || '-',
    fmt(r.casino_pts), fmt(r.sport_pts), fmt(r.third_party_pts), fmt(r.profit_loss),
    r.ptype || r.partnership_type || 'Point',
  ])

  const handleExportExcel = () => {
    const head = EXPORT_COLS.map((c) => `<th>${c}</th>`).join('')
    const body = exportRows().map((r) => `<tr>${r.map((v) => `<td>${v}</td>`).join('')}</tr>`).join('')
    const html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="UTF-8"></head><body><table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></body></html>`
    const blob = new Blob([html], { type: 'application/vnd.ms-excel' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = 'partywinloss.xls'
    a.click()
    URL.revokeObjectURL(a.href)
  }

  const handleExportPdf = async () => {
    const { default: jsPDF } = await import('jspdf')
    const { default: autoTable } = await import('jspdf-autotable')
    const doc = new jsPDF('l', 'pt')
    const pageWidth = doc.internal.pageSize.getWidth()
    doc.setFontSize(14)
    doc.setTextColor(51, 51, 51)
    doc.text('Party Win Loss', pageWidth / 2, 30, { align: 'center' })
    autoTable(doc, {
      head: [EXPORT_COLS],
      body: exportRows(),
      startY: 45,
      theme: 'striped',
      styles: { fontSize: 10, cellPadding: 6 },
      headStyles: { fillColor: [41, 128, 185], textColor: 255, fontStyle: 'bold', halign: 'left' },
      bodyStyles: { textColor: [85, 85, 85] },
    })
    doc.save('partywinloss.pdf')
  }

  const filteredData = searchValue
    ? tableData.filter((r) => (r.username || '').toLowerCase().includes(searchValue.toLowerCase()))
    : tableData

  const totalPages = Math.max(1, Math.ceil(filteredData.length / entriesPerPage))
  const startIdx = (currentPage - 1) * entriesPerPage
  const paged = filteredData.slice(startIdx, startIdx + entriesPerPage)

  useEffect(() => { setCurrentPage(1) }, [searchValue, entriesPerPage, tableData.length])

  const handlePageChange = (p) => {
    if (p >= 1 && p <= totalPages) setCurrentPage(p)
  }

  const fmt = (v) => {
    const n = parseFloat(v)
    if (isNaN(n)) return '0'
    return n.toLocaleString()
  }

  const totals = filteredData.reduce(
    (acc, r) => ({
      casino_pts: acc.casino_pts + (parseFloat(r.casino_pts) || 0),
      sport_pts: acc.sport_pts + (parseFloat(r.sport_pts) || 0),
      third_party_pts: acc.third_party_pts + (parseFloat(r.third_party_pts) || 0),
      profit_loss: acc.profit_loss + (parseFloat(r.profit_loss) || 0),
    }),
    { casino_pts: 0, sport_pts: 0, third_party_pts: 0, profit_loss: 0 }
  )

  return (
    <div data-v-5a10e370="">
      {(showLoader || exporting) && <LoaderOverlay />}
      <div data-v-5a10e370="">
          <div className="row">
            <div className="col-12">
              <div className="page-title-box d-flex align-items-center justify-content-between">
                <h4 className="mb-0 font-size-18">Party Win Loss</h4>
                <div className="page-title-right">
                  <ol className="breadcrumb m-0">
                    <li className="breadcrumb-item">
                      <Link to="/admin/home" className="" target="_self">Home</Link>
                    </li>
                    <li className="breadcrumb-item active">
                      <span aria-current="location">Profit Loss</span>
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col-12">
              <div className="card">
                <div className="card-body">
                  <form data-vv-scope="InserUserAccount" method="post" onSubmit={(e) => { e.preventDefault(); handleLoad() }}>
                    <div className="row row5">
                      <div className="form-group col-md-3">
                        <select
                          className="custom-select"
                          id="__BVID__2024"
                          value={filterType}
                          onChange={(e) => setFilterType(e.target.value)}
                        >
                          <option value="all">All</option>
                          <option value="user">User</option>
                        </select>
                      </div>
                      <div className="form-group col-md-9">
                        <button type="button" className="btn btn-primary" onClick={handleLoad}>Load</button>
                        {' '}
                        <button type="button" id="reset" className="btn btn-light" onClick={handleReset}>Reset</button>
                        {' '}
                        <div id="export_1776286482578" className={`d-inline-block${filteredData.length === 0 ? ' disabled' : ''}`}>
                          <button type="button" disabled={filteredData.length === 0} className={`btn btn-success${filteredData.length === 0 ? ' disabled' : ''}`} onClick={withExportLoader(handleExportExcel)}><i className="fas fa-file-excel"></i></button>
                        </div>
                        {' '}
                        <button type="button" disabled={filteredData.length === 0} className={`btn btn-danger${filteredData.length === 0 ? ' disabled' : ''}`} onClick={handleExportPdf}><i className="fas fa-file-pdf"></i></button>
                      </div>
                    </div>
                  </form>

                  <div className="row">
                    <div className="col-6">
                      <div id="tickets-table_length" className="dataTables_length">
                        <label className="d-inline-flex align-items-center">
                          Show&nbsp;
                          <select
                            className="custom-select custom-select-sm"
                            value={entriesPerPage}
                            onChange={(e) => setEntriesPerPage(Number(e.target.value))}
                          >
                            <option value="25">25</option>
                            <option value="50">50</option>
                            <option value="75">75</option>
                            <option value="100">100</option>
                            <option value="125">125</option>
                            <option value="150">150</option>
                          </select>&nbsp;entries
                        </label>
                      </div>
                    </div>
                    <div className="col-6">
                      <div id="tickets-table_filter" className="dataTables_filter text-md-right">
                        <label className="d-inline-flex align-items-center">
                          <input
                            type="search"
                            placeholder="Search..."
                            className="form-control form-control-sm ml-2 form-control"
                            id="__BVID__2026"
                            value={searchValue}
                            onChange={(e) => setSearchValue(e.target.value)}
                          />
                        </label>
                      </div>
                    </div>
                  </div>

                  <div className="table-responsive mb-0">
                    <table
                      id="plTbl"
                      role="table"
                      aria-busy={loading}
                      aria-colcount="8"
                      className="table b-table table no-footer table-hover table-bordered"
                    >
                      <thead role="rowgroup" className="">
                        <tr role="row" className="">
                          <th role="columnheader" scope="col" aria-colindex="1" className=""><div>No</div></th>
                          <th role="columnheader" scope="col" aria-colindex="2" className=""><div>User Name</div></th>
                          <th role="columnheader" scope="col" aria-colindex="3" className=""><div>Level</div></th>
                          <th role="columnheader" scope="col" aria-colindex="4" className="text-right"><div>Casino pts</div></th>
                          <th role="columnheader" scope="col" aria-colindex="5" className="text-right"><div>Sport pts</div></th>
                          <th role="columnheader" scope="col" aria-colindex="6" className="text-right"><div>Third Party pts</div></th>
                          <th role="columnheader" scope="col" aria-colindex="7" className="text-right"><div>Profit/Loss</div></th>
                          <th role="columnheader" scope="col" aria-colindex="8" className="text-left"><div>Ptype</div></th>
                        </tr>
                      </thead>
                      <tbody role="rowgroup">
                        {filteredData.length === 0 ? (
                          <tr role="row" className="b-table-empty-row">
                            <td colSpan="8" role="cell" className="">
                              <div role="alert" aria-live="polite">
                                <div className="text-center my-2">{searchValue ? 'There are no records matching your request' : 'There are no records to show'}</div>
                              </div>
                            </td>
                          </tr>
                        ) : (
                          paged.map((row, idx) => (
                            <tr key={row.user_id || row.username || idx} role="row" className="">
                              <td aria-colindex="1" role="cell" className="">{startIdx + idx + 1}</td>
                              <td aria-colindex="2" role="cell" className="">{row.username || '-'}</td>
                              <td aria-colindex="3" role="cell" className="">{accountType(row.level || row.user_type) || '-'}</td>
                              <td aria-colindex="4" role="cell" className="text-right"><p className="mb-0">{fmt(row.casino_pts)}</p></td>
                              <td aria-colindex="5" role="cell" className="text-right"><p className="mb-0">{fmt(row.sport_pts)}</p></td>
                              <td aria-colindex="6" role="cell" className="text-right"><p className="mb-0">{fmt(row.third_party_pts)}</p></td>
                              <td aria-colindex="7" role="cell" className="text-right"><p className="mb-0">{fmt(row.profit_loss)}</p></td>
                              <td aria-colindex="8" role="cell" className="text-left">{row.ptype || row.partnership_type || 'Point'}</td>
                            </tr>
                          ))
                        )}
                      </tbody>
                      <tfoot role="rowgroup" className="">
                        <tr role="row" className="">
                          <th role="columnheader" scope="col" aria-colindex="1" className=""><span></span></th>
                          <th role="columnheader" scope="col" aria-colindex="2" className=""><span></span></th>
                          <th role="columnheader" scope="col" aria-colindex="3" className=""><span></span></th>
                          <th role="columnheader" scope="col" aria-colindex="4" className="text-right"><span>{fmt(totals.casino_pts)}</span></th>
                          <th role="columnheader" scope="col" aria-colindex="5" className="text-right"><span>{fmt(totals.sport_pts)}</span></th>
                          <th role="columnheader" scope="col" aria-colindex="6" className="text-right"><span>{fmt(totals.third_party_pts)}</span></th>
                          <th role="columnheader" scope="col" aria-colindex="7" className="text-right"><span>{fmt(totals.profit_loss)}</span></th>
                          <th role="columnheader" scope="col" aria-colindex="8" className="text-left"><span></span></th>
                        </tr>
                      </tfoot>
                    </table>
                  </div>

                  <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={handlePageChange} />
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>
  )
}

export default ProfitLoss
