import { useState, useEffect, useCallback } from 'react'
import { Link } from 'react-router-dom'
import api from '../../services/api'
import LoaderOverlay from '../../components/LoaderOverlay'
import useExportLoader from '../../hooks/useExportLoader'
import Pagination from '../../components/Pagination'

function FraudReport() {
  const [entriesPerPage, setEntriesPerPage] = useState(25)
  // Excel button: page loader for a second, then the download (hooks/useExportLoader)
  const { exporting, withExportLoader } = useExportLoader()
  const [searchValue, setSearchValue] = useState('')
  const [tableData, setTableData] = useState([])
  const [loading, setLoading] = useState(false)
  const [showLoader, setShowLoader] = useState(true)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)

  // NOTE: GET /admin/reports/fraud abhi backend pe nahi hai (404) —
  // see bakend-docs/missing-apis.md; endpoint aate hi data aa jayega
  const fetchData = useCallback(async (page, limit) => {
    setLoading(true)
    try {
      const response = await api.get('/admin/reports/fraud', { params: { page, limit } })
      if (response.data?.success && Array.isArray(response.data.data)) {
        setTableData(response.data.data)
        setTotalPages(response.data.pagination?.totalPages || 1)
      } else {
        setTableData([])
        setTotalPages(1)
      }
    } catch (err) {
      console.error('Error loading fraud report:', err)
      setTableData([])
      setTotalPages(1)
    } finally {
      setLoading(false)
    }
  }, [])

  // Auto-load with the page loader; on a hard refresh wait for the boot
  // splash to lift first (else the loader finishes underneath it)
  useEffect(() => {
    let timer
    const run = () => {
      setShowLoader(true)
      Promise.all([
        fetchData(currentPage, entriesPerPage),
        new Promise((r) => { timer = setTimeout(r, 1000) }),
      ]).finally(() => setShowLoader(false))
    }
    if (document.body.classList.contains('app-loading')) {
      const obs = new MutationObserver(() => {
        if (!document.body.classList.contains('app-loading')) {
          obs.disconnect()
          run()
        }
      })
      obs.observe(document.body, { attributes: true, attributeFilter: ['class'] })
      return () => { obs.disconnect(); clearTimeout(timer) }
    }
    run()
    return () => clearTimeout(timer)
  }, [fetchData, currentPage, entriesPerPage])

  const filteredData = tableData.filter((row) => {
    if (!searchValue) return true
    const s = searchValue.toLowerCase()
    return Object.values(row).some((v) => String(v || '').toLowerCase().includes(s))
  })

  const handlePageChange = (p) => {
    if (p >= 1 && p <= totalPages) setCurrentPage(p)
  }

  const EXPORT_COLS = ['S.No.', 'User Name', 'Event Name', 'Market Date', 'Market Name', 'Amount', 'Fraud Date', 'Remark']
  const exportRows = () => filteredData.map((r, idx) => [
    r.sno ?? idx + 1, r.username, r.eventName, r.marketDate, r.marketName, r.amount, r.fraudDate, r.remark,
  ])

  const handleExportExcel = () => {
    const head = EXPORT_COLS.map((c) => `<th>${c}</th>`).join('')
    const body = exportRows().map((r) => `<tr>${r.map((v) => `<td>${v ?? ''}</td>`).join('')}</tr>`).join('')
    const html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="UTF-8"></head><body><table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></body></html>`
    const blob = new Blob([html], { type: 'application/vnd.ms-excel' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = 'fraudreport.xls'
    a.click()
    URL.revokeObjectURL(a.href)
  }

  const handleExportPdf = async () => {
    const { default: jsPDF } = await import('jspdf')
    const { default: autoTable } = await import('jspdf-autotable')
    const doc = new jsPDF('l', 'pt')
    const pageWidth = doc.internal.pageSize.getWidth()
    doc.setFontSize(14)
    doc.setTextColor(51, 51, 51)
    doc.text('Fraud Report', pageWidth / 2, 30, { align: 'center' })
    autoTable(doc, {
      head: [EXPORT_COLS],
      body: exportRows(),
      startY: 45,
      theme: 'striped',
      styles: { fontSize: 9, cellPadding: 5 },
      headStyles: { fillColor: [41, 128, 185], textColor: 255, fontStyle: 'bold', halign: 'left' },
      bodyStyles: { textColor: [85, 85, 85] },
    })
    doc.save('fraudreport.pdf')
  }

  return (
    <div data-v-5a10e370="">
      {(showLoader || exporting) && <LoaderOverlay />}
      <div data-v-5a10e370="">
          <div className="row">
            <div className="col-12">
              <div className="page-title-box d-flex align-items-center justify-content-between">
                <h4 className="mb-0 font-size-18">Fraud Report</h4>
                <div className="page-title-right">
                  <ol className="breadcrumb m-0">
                    <li className="breadcrumb-item">
                      <Link to="/admin/home" className="" target="_self">Home</Link>
                    </li>
                    <li className="breadcrumb-item active">
                      <span aria-current="location">Fraud Report</span>
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col-12">
              <div className="card">
                <div className="card-body">
                  <div className="mb-3 text-right">
                    <div className="d-inline-block ml-3">
                      <div id="export_1776322721000" className={`d-inline-block${filteredData.length === 0 ? ' disabled' : ''}`}>
                        <button type="button" disabled={filteredData.length === 0} className={`btn mr-1 btn-success${filteredData.length === 0 ? ' disabled' : ''}`} onClick={withExportLoader(handleExportExcel)}><i className="fas fa-file-excel"></i></button>
                      </div>
                      {' '}
                      <button type="button" disabled={filteredData.length === 0} className={`btn btn-danger${filteredData.length === 0 ? ' disabled' : ''}`} onClick={handleExportPdf}><i className="fas fa-file-pdf"></i></button>
                    </div>
                  </div>
                  {' '}
                  <div className="row">
                    <div className="col-sm-12 col-md-6">
                      <div id="tickets-table_length" className="dataTables_length">
                        <label className="d-inline-flex align-items-center">
                          Show&nbsp;
                          <select
                            className="custom-select custom-select-sm"
                            id="__BVID__1726"
                            value={entriesPerPage}
                            onChange={(e) => { setEntriesPerPage(Number(e.target.value)); setCurrentPage(1) }}
                          >
                            <option value="25">25</option>
                            <option value="50">50</option>
                            <option value="75">75</option>
                            <option value="100">100</option>
                            <option value="125">125</option>
                            <option value="150">150</option>
                          </select>&nbsp;entries
                        </label>
                      </div>
                    </div>
                    {' '}
                    <div className="col-sm-12 col-md-6">
                      <div id="tickets-table_filter" className="dataTables_filter text-md-right">
                        <label className="d-inline-flex align-items-center">
                          Search:{' '}
                          <input
                            type="search"
                            placeholder="Search..."
                            className="form-control form-control-sm ml-2 form-control"
                            id="__BVID__1727"
                            value={searchValue}
                            onChange={(e) => setSearchValue(e.target.value)}
                          />
                        </label>
                      </div>
                    </div>
                  </div>
                  {' '}
                  <div className="table-responsive mb-0" style={{ whiteSpace: 'nowrap' }}>
                    <div className="table no-footer table-responsive-sm">
                      <table id="eventsListTbl" role="table" aria-busy={loading} aria-colcount="9" className="table b-table table-bordered">
                        <thead role="rowgroup" className="">
                          <tr role="row" className="">
                            {[['S.No.'], ['User Name'], ['Event Name'], ['Market Date'], ['Market Name'], ['Amount', ' text-right'], ['Fraud Date'], ['Remark'], ['Action']].map(([label, extra], i) => (
                              <th key={label} role="columnheader" scope="col" tabIndex="0" aria-colindex={i + 1} aria-sort="none" className={`position-relative${extra || ''}`}>
                                <div>{label}</div>
                                <span className="sr-only"> (Click to sort ascending)</span>
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody role="rowgroup">
                          {filteredData.length === 0 ? (
                            <tr role="row" className="b-table-empty-row">
                              <td colSpan="9" role="cell" className="">
                                <div role="alert" aria-live="polite">
                                  <div className="text-center my-2">{searchValue ? 'There are no records matching your request' : 'There are no records to show'}</div>
                                </div>
                              </td>
                            </tr>
                          ) : (
                            filteredData.map((row, idx) => (
                              <tr key={idx} role="row" className="">
                                <td aria-colindex="1" role="cell" className="">{row.sno ?? idx + 1}</td>
                                <td aria-colindex="2" role="cell" className="">{row.username}</td>
                                <td aria-colindex="3" role="cell" className="">{row.eventName}</td>
                                <td aria-colindex="4" role="cell" className="">{row.marketDate}</td>
                                <td aria-colindex="5" role="cell" className="">{row.marketName}</td>
                                <td aria-colindex="6" role="cell" className="text-right">{row.amount}</td>
                                <td aria-colindex="7" role="cell" className="">{row.fraudDate}</td>
                                <td aria-colindex="8" role="cell" className="">{row.remark}</td>
                                <td aria-colindex="9" role="cell" className=""></td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                  {' '}
                  <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={handlePageChange} />
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>
  )
}

export default FraudReport
