import { useState, useEffect, useCallback } from 'react'
import { Link } from 'react-router-dom'
import api from '../../services/api'
import LoaderOverlay from '../../components/LoaderOverlay'
import useExportLoader from '../../hooks/useExportLoader'
import Pagination from '../../components/Pagination'

// securityAuthType is the source of truth ('telegram' | 'google' | 'android' | null).
// telegram2FAEnabled is the pre-securityAuthType fallback for older rows.
const AUTH_LABELS = {
  telegram: 'telegram authentication',
  google: 'google authentication',
  android: 'android authentication',
}

const authLabel = (row) => {
  if (row.securityAuthType) return AUTH_LABELS[row.securityAuthType] || `${row.securityAuthType} authentication`
  if (row.telegram2FAEnabled) return AUTH_LABELS.telegram
  return 'no authentication'
}

function AuthList() {
  const [entriesPerPage, setEntriesPerPage] = useState(25)
  // Excel button: page loader for a second, then the download (hooks/useExportLoader)
  const { exporting, withExportLoader } = useExportLoader()
  const [searchValue, setSearchValue] = useState('')
  const [tableData, setTableData] = useState([])
  const [loading, setLoading] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  // Same page loader as /admin/activeusers while the list loads
  const [showLoader, setShowLoader] = useState(true)

  const fetchData = useCallback(async (page, limit) => {
    setLoading(true)
    try {
      const response = await api.get('/admin/users/all-details', { params: { page, limit } })
      const wallets = response.data?.data?.wallets
      if (response.data?.success && Array.isArray(wallets)) {
        const rows = wallets.map((w) => ({
          username: w.username,
          authentication: authLabel(w),
        }))
        setTableData(rows)
        // Same fix as ActiveUsers/Users: total_pages hi asli key hai.
        setTotalPages(response.data.data.pagination?.total_pages || 1)
      } else {
        setTableData([])
        setTotalPages(1)
      }
    } catch (err) {
      console.error('Error loading auth list:', err)
      setTableData([])
      setTotalPages(1)
    } finally {
      setLoading(false)
    }
  }, [])

  // Reference loads the list as soon as the page opens (no Load button here).
  // On a hard refresh the 2s boot splash covers the app, so the loader starts
  // only once `app-loading` leaves <body> — else it would finish underneath.
  useEffect(() => {
    let timer
    const run = () => {
      setShowLoader(true)
      Promise.all([
        fetchData(currentPage, entriesPerPage),
        new Promise((r) => { timer = setTimeout(r, 1000) }),
      ]).finally(() => setShowLoader(false))
    }
    if (document.body.classList.contains('app-loading')) {
      const obs = new MutationObserver(() => {
        if (!document.body.classList.contains('app-loading')) {
          obs.disconnect()
          run()
        }
      })
      obs.observe(document.body, { attributes: true, attributeFilter: ['class'] })
      return () => { obs.disconnect(); clearTimeout(timer) }
    }
    run()
    return () => clearTimeout(timer)
  }, [fetchData, currentPage, entriesPerPage])

  const filteredData = tableData.filter((row) => {
    if (!searchValue) return true
    const s = searchValue.toLowerCase()
    return (
      (row.username || '').toLowerCase().includes(s) ||
      (row.authentication || '').toLowerCase().includes(s)
    )
  })

  const handlePageChange = (p) => {
    if (p >= 1 && p <= totalPages) setCurrentPage(p)
  }

  const EXPORT_COLS = ['Username', 'Authentication']
  const exportRows = () => filteredData.map((r) => [r.username, r.authentication])

  const handleExportExcel = () => {
    const head = EXPORT_COLS.map((c) => `<th>${c}</th>`).join('')
    const body = exportRows().map((r) => `<tr>${r.map((v) => `<td>${v}</td>`).join('')}</tr>`).join('')
    const html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="UTF-8"></head><body><table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></body></html>`
    const blob = new Blob([html], { type: 'application/vnd.ms-excel' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = 'authlist.xls'
    a.click()
    URL.revokeObjectURL(a.href)
  }

  const handleExportPdf = async () => {
    const { default: jsPDF } = await import('jspdf')
    const { default: autoTable } = await import('jspdf-autotable')
    const doc = new jsPDF('l', 'pt')
    const pageWidth = doc.internal.pageSize.getWidth()
    doc.setFontSize(14)
    doc.setTextColor(51, 51, 51)
    doc.text('User Authentication', pageWidth / 2, 30, { align: 'center' })
    autoTable(doc, {
      head: [EXPORT_COLS],
      body: exportRows(),
      startY: 45,
      theme: 'striped',
      styles: { fontSize: 10, cellPadding: 6 },
      headStyles: { fillColor: [41, 128, 185], textColor: 255, fontStyle: 'bold', halign: 'left' },
      bodyStyles: { textColor: [85, 85, 85] },
    })
    doc.save('authlist.pdf')
  }

  return (
    <div data-v-5a10e370="">
      {(showLoader || exporting) && <LoaderOverlay />}
      <div data-v-5a10e370="">
          <div className="row">
            <div className="col-12">
              <div className="page-title-box d-flex align-items-center justify-content-between">
                <h4 className="mb-0 font-size-18">User Authentication</h4>
                <div className="page-title-right">
                  <ol className="breadcrumb m-0">
                    <li className="breadcrumb-item">
                      <Link to="/admin/home" className="" target="_self">Home</Link>
                    </li>
                    <li className="breadcrumb-item active">
                      <span aria-current="location">User Authentication</span>
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col-12">
              <div className="card">
                <div className="card-body">
                  <div className="row mb-3">
                    <div className="col-md-12">
                      <div className="d-inline-block">
                        <div id="export_1776321939841" className={`d-inline-block${filteredData.length === 0 ? ' disabled' : ''}`}>
                          <button type="button" disabled={filteredData.length === 0} className={`btn mr-1 btn-success${filteredData.length === 0 ? ' disabled' : ''}`} onClick={withExportLoader(handleExportExcel)}><i className="fas fa-file-excel"></i></button>
                        </div>
                        {' '}
                        <button type="button" disabled={filteredData.length === 0} className={`btn btn-danger${filteredData.length === 0 ? ' disabled' : ''}`} onClick={handleExportPdf}><i className="fas fa-file-pdf"></i></button>
                      </div>
                    </div>
                  </div>
                  {' '}
                  <div className="row">
                    <div className="col-6">
                      <div id="tickets-table_length" className="dataTables_length">
                        <label className="d-inline-flex align-items-center">
                          Show&nbsp;
                          <select
                            className="custom-select custom-select-sm"
                            id="__BVID__2111"
                            value={entriesPerPage}
                            onChange={(e) => { setEntriesPerPage(Number(e.target.value)); setCurrentPage(1) }}
                          >
                            <option value="25">25</option>
                            <option value="50">50</option>
                            <option value="75">75</option>
                            <option value="100">100</option>
                            <option value="125">125</option>
                            <option value="150">150</option>
                          </select>&nbsp;entries
                        </label>
                      </div>
                    </div>
                    {' '}
                    <div className="col-6 text-right">
                      <div id="tickets-table_filter" className="dataTables_filter text-md-right">
                        <label className="d-inline-flex align-items-center">
                          <input
                            type="search"
                            placeholder="Search..."
                            className="form-control form-control-sm ml-2 form-control"
                            id="__BVID__2112"
                            value={searchValue}
                            onChange={(e) => setSearchValue(e.target.value)}
                          />
                        </label>
                      </div>
                    </div>
                  </div>
                  {' '}
                  <div className="table-responsive mb-0">
                    <div className="table no-footer table-hover table-responsive-sm">
                      <table id="eventsListTbl" role="table" aria-busy={loading} aria-colcount="2" className="table b-table table-bordered b-table-fixed">
                        <thead role="rowgroup" className="">
                          <tr role="row" className="">
                            <th role="columnheader" scope="col" tabIndex="0" aria-colindex="1" aria-sort="none" className="position-relative">
                              <div>Username</div>
                              <span className="sr-only"> (Click to sort ascending)</span>
                            </th>
                            <th role="columnheader" scope="col" tabIndex="0" aria-colindex="2" aria-sort="none" className="position-relative">
                              <div>Authentication</div>
                              <span className="sr-only"> (Click to sort ascending)</span>
                            </th>
                          </tr>
                        </thead>
                        <tbody role="rowgroup">
                          {filteredData.length === 0 ? (
                            <tr role="row" className="b-table-empty-row">
                              <td colSpan="2" role="cell" className="">
                                <div role="alert" aria-live="polite">
                                  <div className="text-center my-2">{searchValue ? 'There are no records matching your request' : 'There are no records to show'}</div>
                                </div>
                              </td>
                            </tr>
                          ) : (
                            filteredData.map((row, idx) => (
                              <tr key={row.username || idx} role="row" aria-rowindex={idx + 1} className="">
                                <td aria-colindex="1" role="cell" className="">{row.username}</td>
                                <td aria-colindex="2" role="cell" className="">{row.authentication}</td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                  {' '}
                  <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={handlePageChange} />
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>
  )
}

export default AuthList
