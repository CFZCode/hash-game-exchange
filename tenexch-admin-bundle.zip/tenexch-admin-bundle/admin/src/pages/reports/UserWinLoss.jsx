import { useState, useMemo } from 'react'
import { Link } from 'react-router-dom'
import { getPointCategoryReport } from '../../services/reportService'
import ClientMultiselect from '../../components/ClientMultiselect'
import MxDatePicker from '../../components/MxDatePicker'
import LoaderOverlay from '../../components/LoaderOverlay'
import useExportLoader from '../../hooks/useExportLoader'

const toDateString = (d) => {
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

const defaultRange = () => {
  const today = new Date()
  const sevenDaysAgo = new Date()
  sevenDaysAgo.setDate(today.getDate() - 7)
  return [toDateString(sevenDaysAgo), toDateString(today)]
}

const fmt = (v) => {
  const n = parseFloat(v)
  if (isNaN(n)) return '0'
  return n.toLocaleString()
}

function UserWinLoss() {
  const [initFrom, initTo] = defaultRange()
  // Excel button: page loader for a second, then the download (hooks/useExportLoader)
  const { exporting, withExportLoader } = useExportLoader()
  const [clientName, setClientName] = useState('')
  const [selectedUsername, setSelectedUsername] = useState('')
  const [fromDate, setFromDate] = useState(initFrom)
  const [toDate, setToDate] = useState(initTo)
  const [searchValue, setSearchValue] = useState('')
  const [tableData, setTableData] = useState([])
  const [loading, setLoading] = useState(false)
  const [showLoader, setShowLoader] = useState(false)

  const fetchData = async () => {
    setLoading(true)
    try {
      const res = await getPointCategoryReport({
        clientName: selectedUsername || clientName || '',
        fromDate,
        toDate,
      })
      if (res?.success && Array.isArray(res?.data)) {
        setTableData(res.data)
      } else {
        setTableData([])
      }
    } catch (err) {
      console.error('Error loading user win/loss:', err)
      setTableData([])
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    setShowLoader(true)
    Promise.all([fetchData(), new Promise((r) => setTimeout(r, 1000))])
      .finally(() => setShowLoader(false))
  }

  const handleReset = () => {
    setClientName('')
    setSelectedUsername('')
    const [f, t] = defaultRange()
    setFromDate(f)
    setToDate(t)
    setSearchValue('')
    setShowLoader(true)
    setTimeout(() => {
      setTableData([])
      setShowLoader(false)
    }, 1000)
  }

  const filteredData = useMemo(() => {
    if (!searchValue) return tableData
    const s = searchValue.toLowerCase()
    return tableData.filter((r) => (r.username || '').toLowerCase().includes(s))
  }, [tableData, searchValue])

  const totals = useMemo(() => filteredData.reduce(
    (acc, r) => ({
      casino: acc.casino + (parseFloat(r.casino_pts) || 0),
      sport: acc.sport + (parseFloat(r.sports_pts) || 0),
      sportbook: acc.sportbook + (parseFloat(r.sportsbook_pts) || 0),
      thirdParty: acc.thirdParty + (parseFloat(r.thirdparty_pts) || 0),
      profitLoss: acc.profitLoss + (parseFloat(r.total) || 0),
    }),
    { casino: 0, sport: 0, sportbook: 0, thirdParty: 0, profitLoss: 0 }
  ), [filteredData])

  const EXPORT_COLS = ['No', 'User Name', 'Casinopts', 'Sportpts', 'SportBookpts', 'Third Party pts', 'Profit/Loss']
  const exportRows = () => filteredData.map((r, idx) => [
    idx + 1, r.username, fmt(r.casino_pts), fmt(r.sports_pts), fmt(r.sportsbook_pts), fmt(r.thirdparty_pts), fmt(r.total),
  ])

  const handleExportExcel = () => {
    const head = EXPORT_COLS.map((c) => `<th>${c}</th>`).join('')
    const body = exportRows().map((r) => `<tr>${r.map((v) => `<td>${v ?? ''}</td>`).join('')}</tr>`).join('')
    const html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="UTF-8"></head><body><table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></body></html>`
    const blob = new Blob([html], { type: 'application/vnd.ms-excel' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = 'userwinloss.xls'
    a.click()
    URL.revokeObjectURL(a.href)
  }

  const handleExportPdf = async () => {
    const { default: jsPDF } = await import('jspdf')
    const { default: autoTable } = await import('jspdf-autotable')
    const doc = new jsPDF('l', 'pt')
    const pageWidth = doc.internal.pageSize.getWidth()
    doc.setFontSize(14)
    doc.setTextColor(51, 51, 51)
    doc.text('User Win Loss', pageWidth / 2, 30, { align: 'center' })
    autoTable(doc, {
      head: [EXPORT_COLS],
      body: exportRows(),
      startY: 45,
      theme: 'striped',
      styles: { fontSize: 10, cellPadding: 6 },
      headStyles: { fillColor: [41, 128, 185], textColor: 255, fontStyle: 'bold', halign: 'left' },
      bodyStyles: { textColor: [85, 85, 85] },
    })
    doc.save('userwinloss.pdf')
  }

  return (
    <div data-v-5a10e370="">
      {(showLoader || exporting) && <LoaderOverlay />}
      <div data-v-5a10e370="">
          <div className="row">
            <div className="col-12">
              <div className="page-title-box d-flex align-items-center justify-content-between">
                <h4 className="mb-0 font-size-18">User Win Loss</h4>
                <div className="page-title-right">
                  <ol className="breadcrumb m-0">
                    <li className="breadcrumb-item">
                      <Link to="/admin/home" className="" target="_self">Home</Link>
                    </li>
                    <li className="breadcrumb-item active">
                      <span aria-current="location">User Win Loss</span>
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col-12">
              <div className="card">
                <div className="card-body">
                  <div className="report-form mb-3">
                    <form method="post" className="ajaxFormSubmit" onSubmit={handleSubmit}>
                      <div className="row row5">
                        <div className="col-2">
                          <div className="form-group user-lock-search" style={{ position: 'relative' }}>
                            <label htmlFor="d-inline-block">Search By Client Name</label>{' '}
                            <ClientMultiselect
                              value={clientName}
                              onChange={(v) => { setClientName(v); setSelectedUsername('') }}
                              onSelect={(u) => { setClientName(u.username); setSelectedUsername(u.username) }}
                            />
                          </div>
                        </div>
                        {' '}
                        <div className="col-3">
                          <label>Select Date Range</label>{' '}
                          <MxDatePicker
                            range
                            disableFuture
                            rootClassName="mb-3 mx-datepicker mx-datepicker-range"
                            rangeValue={[fromDate, toDate]}
                            onRangeChange={(f, t) => { setFromDate(f); setToDate(t) }}
                          />
                        </div>
                        {' '}
                        <div className="col-3">
                          <label style={{ width: '100%' }}>&nbsp;</label>{' '}
                          <button type="submit" id="loaddata" className="btn btn-primary">Load</button>
                          {' '}
                          <button type="button" id="reset" className="btn btn-light" onClick={handleReset}>Reset</button>
                          {' '}
                          <div id="export_1776324598729" className={`d-inline-block${filteredData.length === 0 ? ' disabled' : ''}`}>
                            <button type="button" disabled={filteredData.length === 0} className={`btn btn-success${filteredData.length === 0 ? ' disabled' : ''}`} onClick={withExportLoader(handleExportExcel)}><i className="fas fa-file-excel"></i></button>
                          </div>
                          {' '}
                          <button type="button" disabled={filteredData.length === 0} className={`btn btn-danger${filteredData.length === 0 ? ' disabled' : ''}`} onClick={handleExportPdf}><i className="fas fa-file-pdf"></i></button>
                        </div>
                      </div>
                    </form>
                  </div>
                  {' '}
                  <div className="row">
                    <div className="col-sm-12 col-md-12">
                      <div id="tickets-table_filter" className="dataTables_filter text-md-right">
                        <label className="d-inline-flex align-items-center">
                          Search:{' '}
                          <input
                            type="search"
                            placeholder="Search..."
                            className="form-control form-control-sm ml-2 form-control"
                            id="__BVID__1824"
                            value={searchValue}
                            onChange={(e) => setSearchValue(e.target.value)}
                          />
                        </label>
                      </div>
                    </div>
                  </div>
                  {' '}
                  <div className="table-responsive mb-0">
                    <table
                      id="plTbl"
                      role="table"
                      aria-busy={loading}
                      aria-colcount="7"
                      className="table b-table table no-footer table-hover table-bordered"
                    >
                      <thead role="rowgroup" className="">
                        <tr role="row" className="">
                          <th role="columnheader" scope="col" aria-colindex="1" className=""><div>No</div></th>
                          <th role="columnheader" scope="col" aria-colindex="2" className=""><div>User Name</div></th>
                          <th role="columnheader" scope="col" aria-colindex="3" className="text-right"><div>Casinopts</div></th>
                          <th role="columnheader" scope="col" aria-colindex="4" className="text-right"><div>Sportpts</div></th>
                          <th role="columnheader" scope="col" aria-colindex="5" className="text-right"><div>SportBookpts</div></th>
                          <th role="columnheader" scope="col" aria-colindex="6" className="text-right"><div>Third Party pts</div></th>
                          <th role="columnheader" scope="col" aria-colindex="7" className="text-right"><div>Profit/Loss</div></th>
                        </tr>
                      </thead>
                      <tbody role="rowgroup">
                        {filteredData.length === 0 ? (
                          <tr role="row" className="b-table-empty-row">
                            <td colSpan="7" role="cell" className="">
                              <div role="alert" aria-live="polite">
                                <div className="text-center my-2">{searchValue ? 'There are no records matching your request' : 'There are no records to show'}</div>
                              </div>
                            </td>
                          </tr>
                        ) : (
                          filteredData.map((row, idx) => (
                            <tr key={row.user_id || row.username || idx} role="row" className="">
                              <td aria-colindex="1" role="cell" className="">{idx + 1}</td>
                              <td aria-colindex="2" role="cell" className="">{row.username}</td>
                              <td aria-colindex="3" role="cell" className="text-right"><p className="mb-0">{fmt(row.casino_pts)}</p></td>
                              <td aria-colindex="4" role="cell" className="text-right"><p className="mb-0">{fmt(row.sports_pts)}</p></td>
                              <td aria-colindex="5" role="cell" className="text-right"><p className="mb-0">{fmt(row.sportsbook_pts)}</p></td>
                              <td aria-colindex="6" role="cell" className="text-right"><p className="mb-0">{fmt(row.thirdparty_pts)}</p></td>
                              <td aria-colindex="7" role="cell" className="text-right"><p className="mb-0">{fmt(row.total)}</p></td>
                            </tr>
                          ))
                        )}
                      </tbody>
                      <tfoot role="rowgroup" className="">
                        <tr role="row" className="">
                          <th role="columnheader" scope="col" aria-colindex="1" className=""><span></span></th>
                          <th role="columnheader" scope="col" aria-colindex="2" className=""><span></span></th>
                          <th role="columnheader" scope="col" aria-colindex="3" className="text-right"><span>{fmt(totals.casino)}</span></th>
                          <th role="columnheader" scope="col" aria-colindex="4" className="text-right"><span>{fmt(totals.sport)}</span></th>
                          <th role="columnheader" scope="col" aria-colindex="5" className="text-right"><span>{fmt(totals.sportbook)}</span></th>
                          <th role="columnheader" scope="col" aria-colindex="6" className="text-right"><span>{fmt(totals.thirdParty)}</span></th>
                          <th role="columnheader" scope="col" aria-colindex="7" className="text-right"><span>{fmt(totals.profitLoss)}</span></th>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>
  )
}

export default UserWinLoss
