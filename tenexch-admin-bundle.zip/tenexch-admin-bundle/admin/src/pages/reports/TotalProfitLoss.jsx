import { useState, useMemo } from 'react'
import { Link } from 'react-router-dom'
import { getTotalProfitLoss } from '../../services/api'
import ClientMultiselect from '../../components/ClientMultiselect'
import MxDatePicker from '../../components/MxDatePicker'
import LoaderOverlay from '../../components/LoaderOverlay'
import useExportLoader from '../../hooks/useExportLoader'

const toDateString = (d) => {
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

const defaultRange = () => {
  const today = new Date()
  const sevenDaysAgo = new Date()
  sevenDaysAgo.setDate(today.getDate() - 7)
  return [toDateString(sevenDaysAgo), toDateString(today)]
}

function fmt(v) {
  const n = parseFloat(v)
  if (isNaN(n)) return '0.00'
  return n.toFixed(2)
}

// body cells show the raw number (reference: 35.28, -1, 572.3 — no padding)
function raw(v) {
  const n = parseFloat(v)
  if (isNaN(n)) return '0'
  return String(n)
}

function TotalProfitLoss() {
  const [initFrom, initTo] = defaultRange()
  // Excel button: page loader for a second, then the download (hooks/useExportLoader)
  const { exporting, withExportLoader } = useExportLoader()
  const [clientName, setClientName] = useState('')
  const [selectedUsername, setSelectedUsername] = useState('')
  const [fromDate, setFromDate] = useState(initFrom)
  const [toDate, setToDate] = useState(initTo)
  const [typeVal, setTypeVal] = useState('0')
  const [searchValue, setSearchValue] = useState('')
  const [sportsData, setSportsData] = useState([])
  const [casinoData, setCasinoData] = useState([])
  const [thirdPartyData, setThirdPartyData] = useState([])
  const [sportbookData, setSportbookData] = useState([])
  const [loading, setLoading] = useState(false)
  const [showLoader, setShowLoader] = useState(false)

  const fetchData = async () => {
    setLoading(true)
    try {
      const res = await getTotalProfitLoss({
        clientName: selectedUsername || clientName || '',
        fromDate,
        toDate,
        type: typeVal,
      })
      if (res?.success) {
        const sports = Array.isArray(res.sports) ? res.sports : []
        const casino = Array.isArray(res.casino) ? res.casino : []
        const thirdParty = Array.isArray(res.thirdParty) ? res.thirdParty : []
        const sportbook = Array.isArray(res.sportbook) ? res.sportbook : []

        setSportsData(sports.map((r) => ({
          eventName: r.event_name,
          gameType: r.game_type,
          opening: r.opening,
          closing: r.closing,
          profitLoss: r.profit_loss,
        })))
        setCasinoData(casino.map((r) => ({
          name: r.casino_name,
          opening: r.opening,
          closing: r.closing,
          profitLoss: r.profit_loss,
        })))
        setThirdPartyData(thirdParty.map((r) => ({
          name: r.third_party_name,
          opening: r.opening,
          closing: r.closing,
          profitLoss: r.profit_loss,
        })))
        setSportbookData(sportbook.map((r) => ({
          name: r.sportbook_name,
          opening: r.opening,
          closing: r.closing,
          profitLoss: r.profit_loss,
        })))
      } else {
        setSportsData([])
        setCasinoData([])
        setThirdPartyData([])
        setSportbookData([])
      }
    } catch (err) {
      console.error('Error loading total profit loss:', err)
      setSportsData([])
      setCasinoData([])
      setThirdPartyData([])
      setSportbookData([])
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    setShowLoader(true)
    Promise.all([fetchData(), new Promise((r) => setTimeout(r, 1000))])
      .finally(() => setShowLoader(false))
  }

  const handleReset = () => {
    setClientName('')
    setSelectedUsername('')
    const [f, t] = defaultRange()
    setFromDate(f)
    setToDate(t)
    setTypeVal('0')
    setSearchValue('')
    setShowLoader(true)
    setTimeout(() => {
      setSportsData([])
      setCasinoData([])
      setThirdPartyData([])
      setSportbookData([])
      setShowLoader(false)
    }, 1000)
  }

  const bySearch = (rows) => {
    if (!searchValue.trim()) return rows
    const q = searchValue.toLowerCase()
    return rows.filter((r) => Object.values(r).some((v) => String(v || '').toLowerCase().includes(q)))
  }

  const sportsRows = useMemo(() => bySearch(sportsData), [sportsData, searchValue])
  const casinoRows = useMemo(() => bySearch(casinoData), [casinoData, searchValue])
  const thirdPartyRows = useMemo(() => bySearch(thirdPartyData), [thirdPartyData, searchValue])
  const sportbookRows = useMemo(() => bySearch(sportbookData), [sportbookData, searchValue])

  const totalOf = (rows) => rows.reduce((acc, r) => acc + (parseFloat(r.profitLoss) || 0), 0)
  const hasAnyData = sportsRows.length + casinoRows.length + thirdPartyRows.length + sportbookRows.length > 0

  // Type filter: 0=All, 2=Sports, 3=Casino, 4=Third Party, 5=Sportbook
  const showSports = typeVal === '0' || typeVal === '2'
  const showCasino = typeVal === '0' || typeVal === '3'
  const showThirdParty = typeVal === '0' || typeVal === '4'
  const showSportbook = typeVal === '0' || typeVal === '5'

  const handleExportExcel = () => {
    const section = (title, cols, rows) =>
      `<tr><th colspan="${cols.length}">${title}</th></tr><tr>${cols.map((c) => `<th>${c}</th>`).join('')}</tr>` +
      rows.map((r) => `<tr>${r.map((v) => `<td>${v ?? ''}</td>`).join('')}</tr>`).join('')
    const html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="UTF-8"></head><body><table>` +
      (showSports ? section('Sports Report', ['Event Name', 'Game Type', 'Opening', 'Closing', 'Profit/Loss'], sportsRows.map((r) => [r.eventName, r.gameType, fmt(r.opening), fmt(r.closing), fmt(r.profitLoss)])) : '') +
      (showCasino ? section('Casino Report', ['Casino Name', 'Opening', 'Closing', 'Profit/Loss'], casinoRows.map((r) => [r.name, fmt(r.opening), fmt(r.closing), fmt(r.profitLoss)])) : '') +
      (showThirdParty ? section('Third Party Report', ['Third Party Name', 'Opening', 'Closing', 'Profit/Loss'], thirdPartyRows.map((r) => [r.name, fmt(r.opening), fmt(r.closing), fmt(r.profitLoss)])) : '') +
      (showSportbook ? section('Sportbook Report', ['Sportbook Name', 'Opening', 'Closing', 'Profit/Loss'], sportbookRows.map((r) => [r.name, fmt(r.opening), fmt(r.closing), fmt(r.profitLoss)])) : '') +
      `</table></body></html>`
    const blob = new Blob([html], { type: 'application/vnd.ms-excel' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = 'totalprofitloss.xls'
    a.click()
    URL.revokeObjectURL(a.href)
  }

  const handleExportPdf = async () => {
    const { default: jsPDF } = await import('jspdf')
    const { default: autoTable } = await import('jspdf-autotable')
    const doc = new jsPDF('l', 'pt')
    const pageWidth = doc.internal.pageSize.getWidth()
    doc.setFontSize(14)
    doc.setTextColor(51, 51, 51)
    doc.text('Total Profit Loss', pageWidth / 2, 30, { align: 'center' })
    let y = 45
    const addSection = (title, cols, rows) => {
      doc.setFontSize(11)
      doc.text(title, 40, y + 12)
      autoTable(doc, {
        head: [cols],
        body: rows,
        startY: y + 20,
        theme: 'striped',
        styles: { fontSize: 9, cellPadding: 5 },
        headStyles: { fillColor: [41, 128, 185], textColor: 255, fontStyle: 'bold', halign: 'left' },
        bodyStyles: { textColor: [85, 85, 85] },
      })
      y = doc.lastAutoTable.finalY + 20
    }
    if (showSports) addSection('Sports Report', ['Event Name', 'Game Type', 'Opening', 'Closing', 'Profit/Loss'], sportsRows.map((r) => [r.eventName, r.gameType, fmt(r.opening), fmt(r.closing), fmt(r.profitLoss)]))
    if (showCasino) addSection('Casino Report', ['Casino Name', 'Opening', 'Closing', 'Profit/Loss'], casinoRows.map((r) => [r.name, fmt(r.opening), fmt(r.closing), fmt(r.profitLoss)]))
    if (showThirdParty) addSection('Third Party Report', ['Third Party Name', 'Opening', 'Closing', 'Profit/Loss'], thirdPartyRows.map((r) => [r.name, fmt(r.opening), fmt(r.closing), fmt(r.profitLoss)]))
    if (showSportbook) addSection('Sportbook Report', ['Sportbook Name', 'Opening', 'Closing', 'Profit/Loss'], sportbookRows.map((r) => [r.name, fmt(r.opening), fmt(r.closing), fmt(r.profitLoss)]))
    doc.save('totalprofitloss.pdf')
  }

  const sortableTh = (label, i, extra) => (
    <th key={label} role="columnheader" scope="col" tabIndex="0" aria-colindex={i + 1} aria-sort="none" className={`position-relative${extra ? ` ${extra}` : ''}`}>
      <div>{label}</div>
      <span className="sr-only"> (Click to sort ascending)</span>
    </th>
  )

  const emptyRow = (colSpan) => (
    <tr role="row" className="b-table-empty-row">
      <td colSpan={colSpan} role="cell" className="">
        <div role="alert" aria-live="polite">
          <div className="text-center my-2">{searchValue ? 'There are no records matching your request' : 'There are no records to show'}</div>
        </div>
      </td>
    </tr>
  )

  const tfootRow = (colSpan, total) => (
    <tfoot role="rowgroup" className="">
      <tr>
        <td colSpan={colSpan} className="text-right"><strong>Total Profit/Loss</strong></td>
        {' '}
        <td className="text-right"><strong>{fmt(total)}</strong></td>
      </tr>
    </tfoot>
  )

  return (
    <div data-v-5a10e370="">
      {(showLoader || exporting) && <LoaderOverlay />}
      <div data-v-5a10e370="">
          <div className="row">
            <div className="col-12">
              <div className="page-title-box d-flex align-items-center justify-content-between">
                <h4 className="mb-0 font-size-18">Total Profit Loss</h4>
                <div className="page-title-right">
                  <ol className="breadcrumb m-0">
                    <li className="breadcrumb-item">
                      <Link to="/admin/home" className="" target="_self">Home</Link>
                    </li>
                    <li className="breadcrumb-item active">
                      <span aria-current="location">Total Profit Loss</span>
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col-12">
              <div className="card">
                <div className="card-body">
                  <div className="report-form mb-3">
                    <form method="post" className="ajaxFormSubmit" onSubmit={handleSubmit}>
                      <div className="row row5">
                        <div className="col-lg-3">
                          <div className="form-group user-lock-search" style={{ position: 'relative' }}>
                            <label htmlFor="d-inline-block">Search By Client Name</label>{' '}
                            <ClientMultiselect
                              value={clientName}
                              onChange={(v) => { setClientName(v); setSelectedUsername('') }}
                              onSelect={(u) => { setClientName(u.username); setSelectedUsername(u.username) }}
                            />
                          </div>
                        </div>
                        {' '}
                        <div className="col-lg-3">
                          <label>Select Date Range</label>{' '}
                          <MxDatePicker
                            range
                            disableFuture
                            rootClassName="mb-3 mx-datepicker mx-datepicker-range"
                            rangeValue={[fromDate, toDate]}
                            onRangeChange={(f, t) => { setFromDate(f); setToDate(t) }}
                          />
                        </div>
                        {' '}
                        <div className="col-lg-2">
                          <div className="form-group">
                            <label>Type</label>{' '}
                            <select className="form-control" value={typeVal} onChange={(e) => setTypeVal(e.target.value)}>
                              <option value="0">All</option>
                              {' '}
                              <option value="2">Sports Report</option>
                              {' '}
                              <option value="3">Casino Report</option>
                              {' '}
                              <option value="4">Third Party Casino Report</option>
                              {' '}
                              <option value="5">Sportbook</option>
                            </select>
                          </div>
                        </div>
                      </div>
                      {' '}
                      <div className="row row5">
                        <div className="col-lg-3">
                          <button type="submit" id="loaddata" className="btn btn-primary">Load</button>
                          {' '}
                          <button type="button" id="reset" className="btn btn-light" onClick={handleReset}>Reset</button>
                          {' '}
                          <button type="button" disabled={!hasAnyData} className={`btn btn-success${!hasAnyData ? ' disabled' : ''}`} onClick={withExportLoader(handleExportExcel)}><i className="fas fa-file-excel"></i></button>
                          {' '}
                          <button type="button" disabled={!hasAnyData} className={`btn btn-danger${!hasAnyData ? ' disabled' : ''}`} onClick={handleExportPdf}><i className="fas fa-file-pdf"></i></button>
                        </div>
                      </div>
                    </form>
                  </div>
                  {' '}
                  <div className="row">
                    <div className="col-6"></div>
                    {' '}
                    <div className="col-6 text-right">
                      <div id="tickets-table_filter" className="dataTables_filter text-md-right">
                        <label className="d-inline-flex align-items-center">
                          <input
                            type="search"
                            placeholder="Search..."
                            className="form-control form-control-sm ml-2 form-control"
                            id="__BVID__1839"
                            value={searchValue}
                            onChange={(e) => setSearchValue(e.target.value)}
                          />
                        </label>
                      </div>
                    </div>
                  </div>
                  {' '}
                  <div className="table-responsive mb-0">
                    {showSports && (
                    <div>
                      <h4>Sports Report</h4>
                      {' '}
                      <div className="table no-footer table-hover table-responsive-sm">
                        <table role="table" aria-busy={loading} aria-colcount="5" className="table b-table table-bordered" id="__BVID__1840">
                          <colgroup>
                            {[0, 1, 2, 3, 4].map((i) => <col key={i} style={{ width: 'auto' }} />)}
                          </colgroup>
                          <thead role="rowgroup" className="">
                            <tr role="row" className="">
                              {[['Event Name'], ['Game Type'], ['Opening', 'text-right'], ['Closing', 'text-right'], ['Profit/Loss', 'text-right']].map(([l, e], i) => sortableTh(l, i, e))}
                            </tr>
                          </thead>
                          <tbody role="rowgroup">
                            {sportsRows.length === 0 ? emptyRow(5) : sportsRows.map((r, idx) => (
                              <tr key={idx} role="row" className="nocursor">
                                <td aria-colindex="1" role="cell" className=""><div>{r.eventName}</div></td>
                                <td aria-colindex="2" role="cell" className="">{r.gameType}</td>
                                <td aria-colindex="3" role="cell" className=""><div className="text-right">{raw(r.opening)}</div></td>
                                <td aria-colindex="4" role="cell" className=""><div className="text-right">{raw(r.closing)}</div></td>
                                <td aria-colindex="5" role="cell" className=""><div className="text-right">{raw(r.profitLoss)}</div></td>
                              </tr>
                            ))}
                          </tbody>
                          {tfootRow(4, totalOf(sportsRows))}
                        </table>
                      </div>
                    </div>
                    )}
                    {' '}
                    {showCasino && (
                    <div>
                      <h4>Casino Report</h4>
                      {' '}
                      <div className="table table-hover table-responsive-sm">
                        <table role="table" aria-busy={loading} aria-colcount="4" className="table b-table table-bordered" id="__BVID__1852">
                          <colgroup>
                            {[0, 1, 2, 3].map((i) => <col key={i} style={{ width: 'auto' }} />)}
                          </colgroup>
                          <thead role="rowgroup" className="">
                            <tr role="row" className="">
                              {[['Casino Name'], ['Opening', 'text-right'], ['Closing', 'text-right'], ['Profit/Loss', 'text-right']].map(([l, e], i) => sortableTh(l, i, e))}
                            </tr>
                          </thead>
                          <tbody role="rowgroup">
                            {casinoRows.length === 0 ? emptyRow(4) : casinoRows.map((r, idx) => (
                              <tr key={idx} role="row" className="nocursor">
                                <td aria-colindex="1" role="cell" className=""><div>{r.name}</div></td>
                                <td aria-colindex="2" role="cell" className=""><div className="text-right">{raw(r.opening)}</div></td>
                                <td aria-colindex="3" role="cell" className=""><div className="text-right">{raw(r.closing)}</div></td>
                                <td aria-colindex="4" role="cell" className=""><div className="text-right">{raw(r.profitLoss)}</div></td>
                              </tr>
                            ))}
                          </tbody>
                          {tfootRow(3, totalOf(casinoRows))}
                        </table>
                      </div>
                    </div>
                    )}
                    {' '}
                    {showThirdParty && (
                    <div>
                      <h4>Third Party Report</h4>
                      {' '}
                      <div className="table no-footer table-hover table-responsive-sm">
                        <table role="table" aria-busy={loading} aria-colcount="4" className="table b-table table-bordered" id="__BVID__1863">
                          <colgroup>
                            {[0, 1, 2, 3].map((i) => <col key={i} style={{ width: 'auto' }} />)}
                          </colgroup>
                          <thead role="rowgroup" className="">
                            <tr role="row" className="">
                              {[['Third Party Name'], ['Opening', 'text-right'], ['Closing', 'text-right'], ['Profit/Loss', 'text-right']].map(([l, e], i) => sortableTh(l, i, e))}
                            </tr>
                          </thead>
                          <tbody role="rowgroup">
                            {thirdPartyRows.length === 0 ? emptyRow(4) : thirdPartyRows.map((r, idx) => (
                              <tr key={idx} role="row" className="nocursor">
                                <td aria-colindex="1" role="cell" className=""><div>{r.name}</div></td>
                                <td aria-colindex="2" role="cell" className=""><div className="text-right">{raw(r.opening)}</div></td>
                                <td aria-colindex="3" role="cell" className=""><div className="text-right">{raw(r.closing)}</div></td>
                                <td aria-colindex="4" role="cell" className=""><div className="text-right">{raw(r.profitLoss)}</div></td>
                              </tr>
                            ))}
                          </tbody>
                          {tfootRow(3, totalOf(thirdPartyRows))}
                        </table>
                      </div>
                    </div>
                    )}
                    {' '}
                    {showSportbook && (
                    <div>
                      <h4>Sportbook Report</h4>
                      {' '}
                      <div className="table no-footer table-hover table-responsive-sm">
                        <table role="table" aria-busy={loading} aria-colcount="4" className="table b-table table-bordered" id="__BVID__1874">
                          <colgroup>
                            {[0, 1, 2, 3].map((i) => <col key={i} style={{ width: 'auto' }} />)}
                          </colgroup>
                          <thead role="rowgroup" className="">
                            <tr role="row" className="">
                              {[['Sportbook Name'], ['Opening', 'text-right'], ['Closing', 'text-right'], ['Profit/Loss', 'text-right']].map(([l, e], i) => sortableTh(l, i, e))}
                            </tr>
                          </thead>
                          <tbody role="rowgroup">
                            {sportbookRows.length === 0 ? emptyRow(4) : sportbookRows.map((r, idx) => (
                              <tr key={idx} role="row" className="nocursor">
                                <td aria-colindex="1" role="cell" className=""><div>{r.name}</div></td>
                                <td aria-colindex="2" role="cell" className=""><div className="text-right">{raw(r.opening)}</div></td>
                                <td aria-colindex="3" role="cell" className=""><div className="text-right">{raw(r.closing)}</div></td>
                                <td aria-colindex="4" role="cell" className=""><div className="text-right">{raw(r.profitLoss)}</div></td>
                              </tr>
                            ))}
                          </tbody>
                          {tfootRow(3, totalOf(sportbookRows))}
                        </table>
                      </div>
                    </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>
  )
}

export default TotalProfitLoss
