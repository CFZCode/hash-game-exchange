import { useState, useRef, useEffect, useCallback } from 'react'
import { useSelector } from 'react-redux'
import { Link } from 'react-router-dom'
import Swal from 'sweetalert2'
import { getLoginHistory, getPasswordHistory, getIpDetail } from '../../services/reportService'
import LoaderOverlay from '../../components/LoaderOverlay'
import useExportLoader from '../../hooks/useExportLoader'
import MxDatePicker from '../../components/MxDatePicker'
import ClientMultiselect from '../../components/ClientMultiselect'
import { createPortal } from 'react-dom'
import useModalEnter from '../../hooks/useModalEnter'
import Pagination from '../../components/Pagination'

const Toast = Swal.mixin({
  toast: true,
  position: 'top-end',
  showConfirmButton: false,
  timer: 3000,
  timerProgressBar: false,
})

const formatDateTime = (v) => {
  if (!v) return ''
  const d = new Date(v)
  if (isNaN(d)) return v
  const dd = String(d.getDate()).padStart(2, '0')
  const mm = String(d.getMonth() + 1).padStart(2, '0')
  const yyyy = d.getFullYear()
  const hh = String(d.getHours()).padStart(2, '0')
  const mi = String(d.getMinutes()).padStart(2, '0')
  const ss = String(d.getSeconds()).padStart(2, '0')
  return `${dd}/${mm}/${yyyy} ${hh}:${mi}:${ss}`
}

// BootstrapVue-style "Ip Detail" modal — same DOM as the reference (__BVID__1579)
function IpDetailModal({ show, onHide, detail }) {
  useEffect(() => {
    if (!show) return
    document.body.classList.add('modal-open')
    document.body.setAttribute('data-modal-open-count', '1')
    return () => {
      document.body.classList.remove('modal-open')
      document.body.removeAttribute('data-modal-open-count')
    }
  }, [show])

  const { modalClass, backdropClass, onBackdropClick } = useModalEnter(onHide, show)

  if (!show) return null
  const bvid = '__BVID__1579'
  const rows = [
    ['IP:', detail.ip],
    ['City:', detail.city],
    ['Country:', detail.country],
    ['Mobile:', detail.mobile],
  ]
  return createPortal(
    <div id={`${bvid}___BV_modal_outer_`} style={{ position: 'absolute', zIndex: 1040 }}>
      <div id={bvid} role="dialog" aria-describedby={`${bvid}___BV_modal_body_`} className={modalClass} aria-modal="true" onClick={onBackdropClick} style={{ display: 'block' }}>
        <div className="modal-dialog modal-sm">
          <span tabIndex="0"></span>
          <div id={`${bvid}___BV_modal_content_`} tabIndex="-1" className="modal-content">
            <header id={`${bvid}___BV_modal_header_`} className="modal-header bg-success">
              <h5 className="modal-title text-uppercase text-white">Ip Detail</h5>{' '}
              <button type="button" data-dismiss="modal" className="close text-white" onClick={onHide}>×</button>
            </header>
            <div id={`${bvid}___BV_modal_body_`} className="modal-body">
              {' '}
              <div className="table-responsive">
                <table role="table" className="table b-table table-striped table-hover table-bordered table-sm b-table-caption-top" id="__BVID__1799">
                  <thead role="rowgroup" className="thead-dark">
                    <tr role="row" className="">
                      <th role="columnheader" scope="col" className="">Key</th>
                      {' '}
                      <th role="columnheader" scope="col" className="">Value</th>
                    </tr>
                  </thead>
                  {' '}
                  <tbody role="rowgroup">
                    {rows.map(([k, v], i) => (
                      <tr key={k} role="row" className="">
                        <td role="cell" className=""><b>{k}</b></td>
                        {' '}
                        <td role="cell" className="">{v}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <span tabIndex="0"></span>
        </div>
      </div>
      <div id={`${bvid}___BV_modal_backdrop_`} className={backdropClass}></div>
    </div>,
    document.body
  )
}

function HistoryPane({ scope, mode, resetId, buttonsCol, rowClass, selectId, searchId }) {
  // Logged-in account ka apna username — khaali form ka default (neeche fetchData).
  const ownUsername = useSelector((state) => state.auth.user?.username) || ''
  const [clientName, setClientName] = useState('')
  // Excel button: page loader for a second, then the download (hooks/useExportLoader)
  const { exporting, withExportLoader } = useExportLoader()
  const [selectedUsername, setSelectedUsername] = useState('')
  const [fromDate, setFromDate] = useState('')
  const [toDate, setToDate] = useState('')
  const [entriesPerPage, setEntriesPerPage] = useState(25)
  const [tableSearch, setTableSearch] = useState('')
  const [rows, setRows] = useState([])
  const [loading, setLoading] = useState(false)
  const [showLoader, setShowLoader] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  // Data loads ONLY on Load press
  const hasLoadedRef = useRef(false)
  const [ipModal, setIpModal] = useState({ show: false, ip: '', city: '-', country: '-', mobile: 'False' })

  const openIpDetail = async (ip) => {
    setIpModal({ show: true, ip: ip || '-', city: '-', country: '-', mobile: 'False' })
    if (!ip) return
    try {
      const res = await getIpDetail(ip)
      if (res?.success && res.data) {
        setIpModal({
          show: true,
          ip: res.data.ip || ip,
          city: res.data.city || '-',
          country: res.data.country || '-',
          mobile: res.data.mobile ? 'True' : 'False',
        })
      }
    } catch { /* keep placeholders */ }
  }

  const defaultRange = () => {
    const pad2 = (n) => String(n).padStart(2, '0')
    const f = (d) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`
    const today = new Date()
    const weekAgo = new Date()
    weekAgo.setDate(today.getDate() - 7)
    return [f(weekAgo), f(today)]
  }

  // Default range: last week -> today
  useEffect(() => {
    const [f, t] = defaultRange()
    setFromDate(f)
    setToDate(t)
  }, [])

  const fetchData = useCallback(async (page) => {
    // Kuch select/type nahi kiya to APNA hi account — is page ka default "meri
    // history" hai, downline user chunna zaroori nahi. Backend self ko allow
    // karta hai: staff apni downline list me khud shaamil hota hai, aur owner ke
    // liye resolveHistoryTarget ka OWNER branch.
    const username = selectedUsername || clientName || ownUsername
    if (!username || !username.trim()) {
      Toast.fire({ icon: 'error', text: 'Please select a user from the downline' })
      setRows([])
      setTotalPages(1)
      return
    }
    setLoading(true)
    try {
      const params = { username, page, limit: entriesPerPage }
      if (fromDate) params.fromDate = fromDate
      if (toDate) params.toDate = toDate
      const fetcher = mode === 'password' ? getPasswordHistory : getLoginHistory
      const response = await fetcher(params)
      if (response?.success) {
        const mapped = (response.data || []).map((b, i) => ({
          id: b.id || i,
          username: b.username || username,
          date: formatDateTime(b.login_at || b.changed_at),
          ip: b.ip || '',
        }))
        setRows(mapped)
        setTotalPages(response.pagination?.totalPages || 1)
      } else {
        setRows([])
        setTotalPages(1)
      }
    } catch (err) {
      console.error('Error loading user history:', err)
      const msg = err?.response?.data?.message
      if (msg) Toast.fire({ icon: 'error', text: msg })
      setRows([])
      setTotalPages(1)
    } finally {
      setLoading(false)
    }
  }, [selectedUsername, clientName, ownUsername, fromDate, toDate, entriesPerPage, mode])

  // pagination refetches only after the first explicit Load
  useEffect(() => {
    if (hasLoadedRef.current) fetchData(currentPage)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentPage, entriesPerPage])

  const handleLoad = () => {
    hasLoadedRef.current = true
    setCurrentPage(1)
    setShowLoader(true)
    Promise.all([fetchData(1), new Promise((r) => setTimeout(r, 1000))])
      .finally(() => setShowLoader(false))
  }

  const handleReset = () => {
    setClientName('')
    setSelectedUsername('')
    const [f, t] = defaultRange()
    setFromDate(f)
    setToDate(t)
    setTableSearch('')
    setCurrentPage(1)
    setShowLoader(true)
    setTimeout(() => {
      setRows([])
      setTotalPages(1)
      setShowLoader(false)
    }, 1000)
  }

  const filtered = tableSearch
    ? rows.filter((r) => Object.values(r).some((v) => String(v || '').toLowerCase().includes(tableSearch.toLowerCase())))
    : rows

  const handlePageChange = (p) => {
    if (p >= 1 && p <= totalPages) setCurrentPage(p)
  }

  const EXPORT_COLS = ['Username', 'Date', 'IP']
  const exportRows = () => filtered.map((r) => [r.username, r.date, r.ip])

  const handleExportExcel = () => {
    const head = EXPORT_COLS.map((c) => `<th>${c}</th>`).join('')
    const body = exportRows().map((r) => `<tr>${r.map((v) => `<td>${v}</td>`).join('')}</tr>`).join('')
    const html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="UTF-8"></head><body><table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></body></html>`
    const blob = new Blob([html], { type: 'application/vnd.ms-excel' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = 'userhistory.xls'
    a.click()
    URL.revokeObjectURL(a.href)
  }

  const handleExportPdf = async () => {
    const { default: jsPDF } = await import('jspdf')
    const { default: autoTable } = await import('jspdf-autotable')
    const doc = new jsPDF('l', 'pt')
    const pageWidth = doc.internal.pageSize.getWidth()
    doc.setFontSize(14)
    doc.setTextColor(51, 51, 51)
    doc.text('User History', pageWidth / 2, 30, { align: 'center' })
    autoTable(doc, {
      head: [EXPORT_COLS],
      body: exportRows(),
      startY: 45,
      theme: 'striped',
      styles: { fontSize: 10, cellPadding: 6 },
      headStyles: { fillColor: [41, 128, 185], textColor: 255, fontStyle: 'bold', halign: 'left' },
      bodyStyles: { textColor: [85, 85, 85] },
    })
    doc.save('userhistory.pdf')
  }

  return (
    <>
      {(showLoader || exporting) && <LoaderOverlay />}
      <IpDetailModal show={ipModal.show} detail={ipModal} onHide={() => setIpModal((p) => ({ ...p, show: false }))} />
      {' '}
      <form data-vv-scope={scope} method="post" onSubmit={(e) => { e.preventDefault(); handleLoad() }}>
        <div className={rowClass}>
          <div className="form-group col-xl-3">
            <ClientMultiselect
              value={clientName}
              onChange={(v) => { setClientName(v); setSelectedUsername('') }}
              onSelect={(u) => { setClientName(u.username); setSelectedUsername(u.username) }}
            />
          </div>
          {' '}
          <div className="form-group col-xl-3">
            <MxDatePicker
              range
              disableFuture
              rootClassName="mx-datepicker mx-datepicker-range"
              rangeValue={[fromDate, toDate]}
              onRangeChange={(f, t) => { setFromDate(f); setToDate(t) }}
            />
          </div>
          {' '}
          <div className={`form-group ${buttonsCol}`}>
            <button type="button" className="btn btn-primary" onClick={handleLoad}>Load</button>
            {' '}
            <button type="button" id={resetId} className="btn btn-light" onClick={handleReset}>Reset</button>
            {' '}
            <div id={`export_${scope}`} className={`d-inline-block${filtered.length === 0 ? ' disabled' : ''}`}>
              <button type="button" disabled={filtered.length === 0} className={`btn btn-success${filtered.length === 0 ? ' disabled' : ''}`} onClick={withExportLoader(handleExportExcel)}><i className="fas fa-file-excel"></i></button>
            </div>
            {' '}
            <button type="button" disabled={filtered.length === 0} className={`btn btn-danger${filtered.length === 0 ? ' disabled' : ''}`} onClick={handleExportPdf}><i className="fas fa-file-pdf"></i></button>
          </div>
        </div>
      </form>
      {' '}
      <div className="row">
        <div className="col-6">
          <div id="tickets-table_length" className="dataTables_length">
            <label className="d-inline-flex align-items-center">
              Show&nbsp;
              <select
                className="custom-select custom-select-sm"
                id={selectId}
                value={entriesPerPage}
                onChange={(e) => { setEntriesPerPage(Number(e.target.value)); setCurrentPage(1) }}
              >
                <option value="25">25</option>
                <option value="50">50</option>
                <option value="75">75</option>
                <option value="100">100</option>
                <option value="125">125</option>
                <option value="150">150</option>
              </select>&nbsp;entries
            </label>
          </div>
        </div>
        {' '}
        <div className="col-6 text-right">
          <div id="tickets-table_filter" className="dataTables_filter text-md-right">
            <label className="d-inline-flex align-items-center">
              <input
                type="search"
                placeholder="Search..."
                className="form-control form-control-sm ml-2 form-control"
                id={searchId}
                value={tableSearch}
                onChange={(e) => setTableSearch(e.target.value)}
              />
            </label>
          </div>
        </div>
      </div>
      {' '}
      <div className="table-responsive mb-0">
        <div className="table no-footer table-hover table-responsive-sm">
          <table id="eventsListTbl" role="table" aria-busy={loading} aria-colcount="4" className="table b-table">
            <thead role="rowgroup" className="">
              <tr role="row" className="">
                <th role="columnheader" scope="col" tabIndex="0" aria-colindex="1" aria-sort="none" className="position-relative">
                  <div>Username</div>
                  <span className="sr-only"> (Click to sort ascending)</span>
                </th>
                <th role="columnheader" scope="col" aria-colindex="2" className=""><div>Date</div></th>
                <th role="columnheader" scope="col" aria-colindex="3" className=""><div>IP</div></th>
                <th role="columnheader" scope="col" aria-colindex="4" className=""><div>Detail</div></th>
              </tr>
            </thead>
            <tbody role="rowgroup">
              {filtered.length === 0 ? (
                <tr role="row" className="b-table-empty-row">
                  <td colSpan="4" role="cell" className="">
                    <div role="alert" aria-live="polite">
                      <div className="text-center my-2">{tableSearch ? 'There are no records matching your request' : 'There are no records to show'}</div>
                    </div>
                  </td>
                </tr>
              ) : (
                filtered.map((r, idx) => (
                  <tr key={r.id || idx} role="row" aria-rowindex={idx + 1} className="">
                    <td aria-colindex="1" role="cell" className="">{r.username}</td>
                    <td aria-colindex="2" role="cell" className=""><div>{r.date}</div></td>
                    <td aria-colindex="3" role="cell" className="">{r.ip}</td>
                    <td aria-colindex="4" role="cell" className="">
                      <p className="text-center pointer mb-0" onClick={() => openIpDetail(r.ip)}><i className="fas fa-eye"></i></p>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
      {' '}
      <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={handlePageChange} />
    </>
  )
}

function UserHistory() {
  const [activeTab, setActiveTab] = useState('login')

  return (
    <div data-v-5a10e370="">
      <div data-v-5a10e370="">
          <div className="row">
            <div className="col-12">
              <div className="page-title-box d-flex align-items-center justify-content-between">
                <h4 className="mb-0 font-size-18">User History</h4>
                <div className="page-title-right">
                  <ol className="breadcrumb m-0">
                    <li className="breadcrumb-item">
                      <Link to="/admin/home" className="" target="_self">Home</Link>
                    </li>
                    <li className="breadcrumb-item active">
                      <span aria-current="location">User History</span>
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col-12">
              <div className="card">
                <div className="card-body">
                  <div className="tabs" id="__BVID__1479">
                    <div className="">
                      <ul role="tablist" className="nav nav-tabs" id="__BVID__1479__BV_tab_controls_">
                        <li role="presentation" className="nav-item">
                          <a
                            role="tab"
                            aria-selected={activeTab === 'login' ? 'true' : 'false'}
                            aria-setsize="2"
                            aria-posinset="1"
                            href="#"
                            target="_self"
                            className={`nav-link${activeTab === 'login' ? ' active tab-bg-primary' : ''}`}
                            id="__BVID__1480___BV_tab_button__"
                            aria-controls="__BVID__1480"
                            {...(activeTab === 'login' ? {} : { tabIndex: '-1' })}
                            onClick={(e) => { e.preventDefault(); setActiveTab('login') }}
                          >
                            <span>Login History</span>
                          </a>
                        </li>
                        <li role="presentation" className="nav-item">
                          <a
                            role="tab"
                            aria-selected={activeTab === 'cpw' ? 'true' : 'false'}
                            aria-setsize="2"
                            aria-posinset="2"
                            href="#"
                            target="_self"
                            className={`nav-link${activeTab === 'cpw' ? ' active tab-bg-primary' : ''}`}
                            id="__BVID__1503___BV_tab_button__"
                            aria-controls="__BVID__1503"
                            {...(activeTab === 'cpw' ? {} : { tabIndex: '-1' })}
                            onClick={(e) => { e.preventDefault(); setActiveTab('cpw') }}
                          >
                            <span>Change Password History</span>
                          </a>
                        </li>
                      </ul>
                    </div>
                    <div className="tab-content p-2 text-muted" id="__BVID__1479__BV_tab_container_">
                      <div role="tabpanel" aria-hidden={activeTab !== 'login' ? 'true' : 'false'} className={`tab-pane${activeTab === 'login' ? ' active' : ''}`} id="__BVID__1480" aria-labelledby="__BVID__1480___BV_tab_button__" style={activeTab === 'login' ? {} : { display: 'none' }}>
                        <HistoryPane scope="InserUserAccount" mode="login" resetId="reset" buttonsCol="col-xl-6" rowClass="row row5" selectId="__BVID__1490" searchId="__BVID__1491" />
                      </div>
                      <div role="tabpanel" aria-hidden={activeTab !== 'cpw' ? 'true' : 'false'} className={`tab-pane${activeTab === 'cpw' ? ' active' : ''}`} id="__BVID__1503" aria-labelledby="__BVID__1503___BV_tab_button__" style={activeTab === 'cpw' ? {} : { display: 'none' }}>
                        <HistoryPane scope="cpAccount" mode="password" resetId="reset1" buttonsCol="col-xl-4" rowClass="row" selectId="__BVID__1513" searchId="__BVID__1514" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>
  )
}

export default UserHistory
