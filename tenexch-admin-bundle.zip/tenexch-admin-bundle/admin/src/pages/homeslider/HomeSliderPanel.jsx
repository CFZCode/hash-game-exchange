import { useState, useEffect, useMemo } from 'react'
import Swal from 'sweetalert2'
import homeSliderService from '../../services/homeSliderService'
import useModalEnter from '../../hooks/useModalEnter'

// Home Sliders — owner-only control of the two image strips at the bottom of
// the MOBILE home page. Per tile: the artwork, the app path it opens, an
// enable toggle (off = gone from the strip) and its position. Uploaded images
// are converted to base64 data: URIs by the server and stored in the row, so
// no file ever has to reach the web root.

const SECTION_TABS = [
  { id: 'our_casino', label: 'Our Casino' },
  { id: 'new_games', label: 'New Games' },
]

const MAX_IMG_BYTES = 5 * 1024 * 1024

const emptyForm = { title: '', route: '', img: '', link_type: 'path', game_uid: '' }

// A 3rd-party slot opens at /casino/slot/<game id> — a real app path, which is
// why this needs no new column: the tile still stores a route like any other.
// The two helpers are inverses, so a saved tile reopens on the right tab with
// its id filled in rather than showing players a raw path to edit by hand.
const THIRD_PARTY_PREFIX = '/casino/slot/'
const thirdPartyRoute = (gameUid) => `${THIRD_PARTY_PREFIX}${gameUid}`
const gameUidFromRoute = (route) =>
  route && route.startsWith(THIRD_PARTY_PREFIX)
    ? route.slice(THIRD_PARTY_PREFIX.length).replace(/\/+$/, '')
    : ''

const LINK_TYPES = [
  { id: 'path', label: 'App Path' },
  { id: 'third_party', label: '3rd Party Casino' },
]

function HomeSliderPanel() {
  const [sliders, setSliders] = useState([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('our_casino')
  const [savingId, setSavingId] = useState(null)
  const [reordering, setReordering] = useState(false)
  // Add/Edit modal: null = closed, 'new' = adding, otherwise the row being edited
  const [editing, setEditing] = useState(null)
  // Edit modal open animation + outside click (hooks/useModalEnter)
  const editEnter = useModalEnter(() => closeModal(), !!editing)
  const [form, setForm] = useState(emptyForm)
  // What img the modal opened with — the list API hands back a SERVING URL
  // for stored art, and echoing that URL into a save would overwrite the real
  // image with a pointer to itself. img only goes in the payload when the
  // owner actually picked a new file (CasinoManage.jsx guards the same way).
  const [initialImg, setInitialImg] = useState('')
  const [formSaving, setFormSaving] = useState(false)
  const [uploading, setUploading] = useState(false)
  // Name of a freshly uploaded file. The <input type="file"> is reset after
  // every upload (so re-picking the same file fires onChange again), which
  // leaves it reading "No file chosen" — this is what confirms the pick landed.
  const [pickedName, setPickedName] = useState('')

  const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: false,
  })

  const fetchSliders = async () => {
    setLoading(true)
    try {
      const response = await homeSliderService.list()
      if (response.success) setSliders(response.data || [])
    } catch (error) {
      Toast.fire({ icon: 'error', title: error.response?.data?.error || error.message })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchSliders()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const visibleSliders = useMemo(
    () => sliders.filter((s) => s.section === activeTab),
    [sliders, activeTab]
  )

  const handleToggle = async (slider) => {
    setSavingId(slider.id)
    try {
      const response = await homeSliderService.update(slider.id, { enabled: !slider.enabled })
      if (response.success) {
        setSliders((prev) => prev.map((s) => (s.id === slider.id ? response.data : s)))
        Toast.fire({
          icon: 'success',
          title: `${slider.title} ${slider.enabled ? 'hidden' : 'shown'}`,
        })
      }
    } catch (error) {
      Toast.fire({ icon: 'error', title: error.response?.data?.error || error.message })
    } finally {
      setSavingId(null)
    }
  }

  // Swap two tiles of the ACTIVE section and post that section's full id list.
  // The server rejects any id from the other strip, so the payload is built
  // from visibleSliders only.
  const handleMove = async (index, delta) => {
    const target = index + delta
    if (target < 0 || target >= visibleSliders.length) return
    const next = [...visibleSliders]
    ;[next[index], next[target]] = [next[target], next[index]]
    // Optimistic: re-lay the active section in its new order, other section untouched.
    setSliders((prev) => [...prev.filter((s) => s.section !== activeTab), ...next])
    setReordering(true)
    try {
      const response = await homeSliderService.reorder(activeTab, next.map((s) => s.id))
      if (!response.success) {
        Toast.fire({ icon: 'error', title: response.error || 'Reorder failed' })
      }
    } catch (error) {
      Toast.fire({ icon: 'error', title: error.response?.data?.error || error.message })
    } finally {
      setReordering(false)
      fetchSliders()
    }
  }

  const handleDelete = async (slider) => {
    const result = await Swal.fire({
      title: 'Delete this slider?',
      text: `${slider.title} — ${SECTION_TABS.find((t) => t.id === slider.section)?.label}`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      confirmButtonText: 'Delete',
    })
    if (!result.isConfirmed) return
    try {
      const response = await homeSliderService.remove(slider.id)
      if (response.success) {
        Toast.fire({ icon: 'success', title: 'Slider deleted' })
        setSliders((prev) => prev.filter((s) => s.id !== slider.id))
      }
    } catch (error) {
      Toast.fire({ icon: 'error', title: error.response?.data?.error || error.message })
    }
  }

  // ── Add / Edit modal ──
  const openAdd = () => {
    setForm(emptyForm)
    setInitialImg('')
    setPickedName('')
    setEditing('new')
  }

  const openEdit = (slider) => {
    const uid = gameUidFromRoute(slider.route || '')
    setForm({
      title: slider.title || '',
      route: slider.route || '',
      img: slider.img || '',
      link_type: uid ? 'third_party' : 'path',
      game_uid: uid,
    })
    setInitialImg(slider.img || '')
    setPickedName('')
    setEditing(slider)
  }

  const closeModal = () => {
    if (formSaving) return
    setEditing(null)
    setForm(emptyForm)
    setPickedName('')
  }

  // File → server (multer, multipart) → base64 dataUrl back. The server owns
  // the conversion; the browser only previews what came back, so what you see
  // is exactly the string that will be stored on the row.
  const handleImageFile = async (e) => {
    const file = e.target.files?.[0]
    if (!file) return
    if (!file.type.startsWith('image/')) {
      Toast.fire({ icon: 'error', title: 'Pick an image file' })
      return
    }
    if (file.size > MAX_IMG_BYTES) {
      Toast.fire({ icon: 'error', title: 'Image must be under 5MB' })
      return
    }
    setUploading(true)
    try {
      const response = await homeSliderService.uploadImage(file)
      if (response.success && response.dataUrl) {
        setForm((prev) => ({ ...prev, img: response.dataUrl }))
        setPickedName(response.name || file.name)
      } else {
        Toast.fire({ icon: 'error', title: response.error || 'Upload failed' })
      }
    } catch (error) {
      Toast.fire({ icon: 'error', title: error.response?.data?.error || error.message })
    } finally {
      setUploading(false)
      e.target.value = ''
    }
  }

  const handleFormSubmit = async (e) => {
    e.preventDefault()
    const title = form.title.trim()
    if (!title) {
      Toast.fire({ icon: 'error', title: 'Title is required' })
      return
    }
    // A 3rd-party tile's link is built from the game id, so there is no path to
    // type and none to get wrong. Everything else keeps the free-text field.
    let route
    if (form.link_type === 'third_party') {
      const gameUid = form.game_uid.trim()
      if (!gameUid) {
        Toast.fire({ icon: 'error', title: 'Game ID is required for a 3rd party casino' })
        return
      }
      route = thirdPartyRoute(gameUid)
    } else {
      route = form.route.trim()
    }
    if (route && !/^\/[\w/-]*$/.test(route)) {
      Toast.fire({ icon: 'error', title: 'Link must be an app path like /casino/teen20' })
      return
    }
    const imgChanged = form.img !== initialImg
    if (editing === 'new' && !form.img) {
      Toast.fire({ icon: 'error', title: 'Pick an image' })
      return
    }

    setFormSaving(true)
    try {
      let response
      if (editing === 'new') {
        response = await homeSliderService.create({ section: activeTab, title, route, img: form.img })
      } else {
        const payload = { title, route }
        if (imgChanged) payload.img = form.img
        response = await homeSliderService.update(editing.id, payload)
      }
      if (response.success) {
        Toast.fire({ icon: 'success', title: editing === 'new' ? 'Slider added' : 'Slider saved' })
        setEditing(null)
        setForm(emptyForm)
        setPickedName('')
        fetchSliders()
      }
    } catch (error) {
      Toast.fire({ icon: 'error', title: error.response?.data?.error || error.message })
    } finally {
      setFormSaving(false)
    }
  }

  const activeLabel = SECTION_TABS.find((t) => t.id === activeTab)?.label

  return (
    <div>
      <div className="row">
        <div className="col-12">
          <div className="page-title-box d-flex align-items-center justify-content-between">
            <h4 className="mb-0 font-size-18">Home Sliders</h4>
            <button type="button" className="btn btn-primary btn-sm" onClick={openAdd}>
              <i className="bx bx-plus"></i> Add to {activeLabel}
            </button>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-body">
          <p className="text-muted mb-3">
            The two image strips at the bottom of the <strong>mobile</strong> home page.
            Tiles show in the order below; a disabled tile disappears from the strip.
          </p>

          <ul className="nav nav-tabs mb-3">
            {SECTION_TABS.map((tab) => (
              <li className="nav-item" key={tab.id}>
                <button
                  type="button"
                  className={`nav-link${activeTab === tab.id ? ' active' : ''}`}
                  onClick={() => setActiveTab(tab.id)}
                >
                  {tab.label}
                </button>
              </li>
            ))}
          </ul>

          <div className="table-responsive">
            <table className="table table-bordered table-striped align-middle mb-0">
              <thead>
                <tr>
                  <th style={{ width: '110px' }}>Order</th>
                  <th style={{ width: '130px' }}>Image</th>
                  <th>Title</th>
                  <th>Link</th>
                  <th style={{ width: '110px' }}>Show</th>
                  <th style={{ width: '120px' }}>Action</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr><td colSpan="6" className="text-center">Loading...</td></tr>
                ) : visibleSliders.length === 0 ? (
                  <tr><td colSpan="6" className="text-center">No sliders in {activeLabel} yet</td></tr>
                ) : (
                  visibleSliders.map((slider, index) => (
                    <tr key={slider.id}>
                      <td>
                        <div className="d-flex align-items-center gap-1">
                          <span className="me-1">{index + 1}</span>
                          <button
                            type="button"
                            className="btn btn-sm btn-light px-1 py-0"
                            title="Move up"
                            disabled={reordering || index === 0}
                            onClick={() => handleMove(index, -1)}
                          >
                            <i className="bx bx-up-arrow-alt"></i>
                          </button>
                          <button
                            type="button"
                            className="btn btn-sm btn-light px-1 py-0"
                            title="Move down"
                            disabled={reordering || index === visibleSliders.length - 1}
                            onClick={() => handleMove(index, 1)}
                          >
                            <i className="bx bx-down-arrow-alt"></i>
                          </button>
                        </div>
                      </td>
                      <td>
                        {slider.img ? (
                          <img
                            src={slider.img}
                            alt={slider.title}
                            style={{ width: '110px', height: '58px', objectFit: 'cover', borderRadius: '4px' }}
                          />
                        ) : (
                          <span className="text-muted">-</span>
                        )}
                      </td>
                      <td>{slider.title}</td>
                      <td>
                        {slider.route ? <code>{slider.route}</code> : <span className="text-muted">no link</span>}
                      </td>
                      <td>
                        <div className="form-check form-switch">
                          <input
                            type="checkbox"
                            className="form-check-input"
                            role="switch"
                            checked={!!slider.enabled}
                            disabled={savingId === slider.id}
                            onChange={() => handleToggle(slider)}
                          />
                        </div>
                      </td>
                      <td>
                        <button
                          type="button"
                          className="btn btn-sm btn-primary me-1"
                          title="Edit"
                          onClick={() => openEdit(slider)}
                        >
                          <i className="bx bx-edit-alt"></i>
                        </button>
                        <button
                          type="button"
                          className="btn btn-sm btn-danger"
                          title="Delete"
                          onClick={() => handleDelete(slider)}
                        >
                          <i className="bx bx-trash"></i>
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {editing && (
        <>
          <div className={`${editEnter.modalClass} d-block`} tabIndex="-1" role="dialog" onClick={editEnter.onBackdropClick}>
            <div className="modal-dialog modal-dialog-centered" role="document">
              <div className="modal-content">
                <form onSubmit={handleFormSubmit}>
                  <div className="modal-header">
                    <h5 className="modal-title">
                      {editing === 'new' ? `Add to ${activeLabel}` : `Edit ${editing.title}`}
                    </h5>
                    <button type="button" className="btn-close" onClick={closeModal}></button>
                  </div>
                  <div className="modal-body">
                    <div className="mb-3">
                      <label className="form-label">Title</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="e.g. Super Over 2"
                        value={form.title}
                        onChange={(e) => setForm((prev) => ({ ...prev, title: e.target.value }))}
                      />
                      <small className="text-muted">Admin label only — players never see it.</small>
                    </div>

                    <div className="mb-3">
                      <label className="form-label">Link Type</label>
                      <select
                        className="form-control"
                        value={form.link_type}
                        onChange={(e) => setForm((prev) => ({ ...prev, link_type: e.target.value }))}
                      >
                        {LINK_TYPES.map((t) => (
                          <option key={t.id} value={t.id}>{t.label}</option>
                        ))}
                      </select>
                      <small className="text-muted">
                        {form.link_type === 'third_party'
                          ? 'Tapping the tile opens the 3rd party game straight away.'
                          : 'Tapping the tile goes to a page inside the app.'}
                      </small>
                    </div>

                    {form.link_type === 'third_party' ? (
                      <>
                        <div className="mb-3">
                          <label className="form-label">Game ID</label>
                          <input
                            type="text"
                            className="form-control"
                            placeholder="e.g. 5cb6aa4e2ce1c775c568561401ffdfca"
                            value={form.game_uid}
                            maxLength={160}
                            onChange={(e) => setForm((prev) => ({ ...prev, game_uid: e.target.value }))}
                          />
                          <small className="text-muted">The provider game id. Tapping the tile launches this game.</small>
                        </div>
                        <div className="mb-3">
                          <label className="form-label">Link (app path)</label>
                          <input
                            type="text"
                            className="form-control"
                            value={form.game_uid.trim() ? thirdPartyRoute(form.game_uid.trim()) : ''}
                            placeholder="— set automatically from the Game ID —"
                            readOnly
                            disabled
                          />
                          <small className="text-muted">Built from the Game ID — nothing to type.</small>
                        </div>
                      </>
                    ) : (
                      <div className="mb-3">
                        <label className="form-label">Link (app path)</label>
                        <input
                          type="text"
                          className="form-control"
                          placeholder="/casino/superover2"
                          value={form.route}
                          onChange={(e) => setForm((prev) => ({ ...prev, route: e.target.value }))}
                        />
                        <small className="text-muted">
                          Where tapping the tile goes, e.g. <code>/casino/teen41</code>,
                          {' '}<code>/fantasy/darwin/AVIATSR</code> or <code>/o_casino</code>. Leave blank for image only.
                        </small>
                      </div>
                    )}

                    <div className="mb-3">
                      <label className="form-label">Image</label>
                      <input
                        type="file"
                        accept="image/*"
                        className="form-control"
                        disabled={uploading}
                        onChange={handleImageFile}
                      />
                      <small className="text-muted">PNG / JPG / WEBP / GIF, up to 5MB. Wide banner art (about 2:1) fits the strip best.</small>
                      {uploading && <div className="mt-2 text-muted">Uploading...</div>}
                      {form.img && (
                        <div className="mt-2">
                          <img
                            src={form.img}
                            alt="preview"
                            style={{ width: '100%', maxHeight: '150px', objectFit: 'cover', borderRadius: '4px' }}
                          />
                          <div className="mt-1 small">
                            {pickedName ? (
                              <span className="text-success">
                                <i className="bx bx-check"></i> New image ready: {pickedName} — click Save Changes to apply.
                              </span>
                            ) : (
                              <span className="text-muted">Current image. Choose a file to replace it.</span>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="modal-footer">
                    <button type="button" className="btn btn-secondary" onClick={closeModal} disabled={formSaving}>
                      Cancel
                    </button>
                    <button type="submit" className="btn btn-primary" disabled={formSaving || uploading}>
                      {formSaving ? 'Saving...' : editing === 'new' ? 'Add Slider' : 'Save Changes'}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <div className={editEnter.backdropClass}></div>
        </>
      )}
    </div>
  )
}

export default HomeSliderPanel
