import { useState, useEffect, useMemo } from 'react'
import { useSelector } from 'react-redux'
import { Link } from 'react-router-dom'
import ReactApexChart from 'react-apexcharts'
import { CASINO_ITEMS, CASINO_IMG_BASE } from '../config/casinoItems'
import SimpleBarBox from '../components/SimpleBarBox'

// How long ONE bar takes to grow, bump past its mark and come back.
// ApexCharts' own default — what the reference runs at — is 800. The user asked
// for the bump to be slower (2026-09-21: "dheere se bump rakh"), so this is a
// deliberate deviation: same swing curve, same 10% overshoot, just stretched.
// At 1400 the peak lands at ~810ms and the come-back takes ~590ms (it was
// 464 / 336 — over before the eye caught it). This is the only knob: raise it
// for slower, 800 puts it back on the reference.
const CHART_BAR_MS = 1400
// Bars start one after another (apex's default, same as the reference).
const CHART_STAGGER_MS = 150

// How long the whole load animation runs: one bar, plus the head start of the
// 4 later bars, and a little slack.
const CHART_INTRO_MS = CHART_BAR_MS + 4 * CHART_STAGGER_MS + 200

// A bar chart whose props are HELD for the length of its load animation.
//
// react-apexcharts turns any change in `options` / `series` into
// chart.updateOptions() / updateSeries(). ApexCharts answers that by redrawing
// every bar from its previous *target* path to the new one — and mid-intro the
// previous target is already the full-length bar, so the chart snaps straight
// to the end and the swing is never seen (recording, 2026-09-21: empty chart,
// one frame of a stub, next frame every bar full). It is the only way in: a
// parent resize is ignored by apex until `animationEnded`, and nothing here
// fires a window resize. What lands in that window is a `user` refresh — the
// profile fetch or the owner socket — and when it lands is a race, which is
// why the same build animated in one recording and snapped in the next.
//
// So the first props are kept until the intro is over, then the live ones take
// over; if they differ, that update animates normally (dynamicAnimation).
function IntroBarChart({ options, series }) {
  const [intro] = useState({ options, series })
  const [live, setLive] = useState(false)
  useEffect(() => {
    const t = setTimeout(() => setLive(true), CHART_INTRO_MS)
    return () => clearTimeout(t)
  }, [])
  const shown = live ? { options, series } : intro
  return <ReactApexChart options={shown.options} series={shown.series} type="bar" height={350} />
}

function Home() {
  const user = useSelector((state) => state.auth.user)

  // Web (>=768px) pe horizontal bars (legend bottom, categories y-axis pe),
  // mobile pe vertical columns (legend top, categories x-axis -45°). Reference
  // dono views ka alag hai.
  const [isMobile, setIsMobile] = useState(typeof window !== 'undefined' && window.innerWidth < 768)
  useEffect(() => {
    const onResize = () => setIsMobile(window.innerWidth < 768)
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])
  const horizontal = !isMobile

  // Chart tabhi mount ho jab splash/boot loader khatam ho — warna graph loader
  // ke PEECHE render+animate ho jaata tha aur user ko animation dikhti hi nahi.
  // main.jsx boot pe body se `app-loading` class hataata hai (~2s) — usi ka
  // wait. SPA-navigation pe class hoti hi nahi -> turant render.
  const [chartsReady, setChartsReady] = useState(
    typeof document === 'undefined' || !document.body.classList.contains('app-loading'),
  )
  useEffect(() => {
    if (chartsReady) return
    const check = () => {
      if (!document.body.classList.contains('app-loading')) { setChartsReady(true); return true }
      return false
    }
    if (check()) return
    const obs = new MutationObserver(check)
    obs.observe(document.body, { attributes: true, attributeFilter: ['class'] })
    return () => obs.disconnect()
  }, [chartsReady])

  // Home ke charts async render hote hain (ReactApexChart) — is se initial
  // scroll-to-top ke baad page reflow hoke beech me aa jaata tha. Mount pe aur
  // chart-render ke baad (delays) top pe force karo.
  useEffect(() => {
    const toTop = () => {
      window.scrollTo({ top: 0, left: 0, behavior: 'instant' }) // instant, warna smooth-scroll visible
      if (document.scrollingElement) document.scrollingElement.scrollTop = 0
      document.querySelectorAll('.main-content, .page-content').forEach((el) => { el.scrollTop = 0 })
    }
    toTop()
    const timers = [50, 200, 500, 900].map((ms) => setTimeout(toTop, ms))
    return () => timers.forEach(clearTimeout)
  }, [])

  const fmt = (val) => {
    if (val == null) return '0'
    return Number(val).toLocaleString()
  }

  const creditPts = Number(user?.credit ?? user?.creditPoints) || 0
  const allPts = Number(user?.all_point ?? user?.allPoints) || 0
  const settlementPts = Number(user?.settlement_points ?? user?.settlementPoints) || 0
  const upperPts = Number(user?.upper_point ?? user?.UpperLevel) || 0
  const downPts = Number(user?.down_point ?? user?.DownOb) || 0

  // Reference y-axis: plain LINEAR scale, clean round gaps. NO log-scale.
  // Label decimals differ per view (two reference captures, 2026-09-17):
  //   WEB (horizontal bars) — ALWAYS bare on a round tick, even with decimal
  //     data: jack0014 (All pts 90,905.44, Settlement -9,094.56) shows
  //     `-5000 0 5000 … 100000`. Printing `.00` here also made the owner's
  //     `-5000000.00 0.00 5000000.00 …` overlap across the axis.
  //   MOBILE (vertical cols) — decimals follow the DATA: All pts 10,059.36 /
  //     Settlement 59.36 → `12000.00 … 0.00`; all whole numbers → bare
  //     (user's rule). Same as ApexCharts' own `yValueDecimal` default.
  //   A fractional TICK on whole-number data (all-zero P/L → 0 0.5 1 1.5 2)
  //     prints bare too: reference shows `1.5` / `0.5`, not `1.50` (2026-09-18).
  //     parseFloat(toFixed(2)) also drops float noise (0.30000000000000004 → 0.3).
  const fmtAxisWeb = (v) => String(parseFloat(Number(v).toFixed(2)))
  const fmtAxisMobile = (data) => {
    const hasDecimals = data.some((v) => Number(v) % 1 !== 0)
    return hasDecimals ? (v) => Number(v || 0).toFixed(2) : fmtAxisWeb
  }
  const fmtExact = (v) => Number(v ?? 0).toLocaleString()

  // Breakpoints: ApexCharts ka apna niceScale, koi min/max nahi. Pehle yahan
  // ek `niceAxis` tha jo ~5 round ticks banata tha (10,006 → 0 2500 … 12500);
  // reference (tenexch.com admin, saluagent 10,006 pts, 2026-09-17) usi data
  // pe `0 500 1000 … 10500` dikhata hai — apexcharts 3.x ka default.
  //
  // WEB tick count = FORMULA on the size of the numbers, not on svg width
  // (apex's default picks the count from width — Scales.js: maxTicks =
  // (svgWidth-100)/25 — so the same data gave step 500 on a wide screen and
  // step 1000 on the user's narrower one; that was the "500 ka difference").
  //
  // Bands (user, 2026-09-17: "1 lakh tak fine rakho, uske upar kam karo —
  // 5 crore, 10 crore, 100 crore tak ja sakta hai, UI break na ho"):
  //
  //   largest |value|        ticks   result (apex niceScale, simulated)
  //   ≤ 1 lakh (100,000)      24     10,006 → 0 500 … 10500 (22 labels)
  //                                  1 lakh / -9,094 → -10000 -5000 … 100000  = reference jack0014
  //   1 lakh – 1 crore (1e7)  12     10 lakh → -100000 0 100000 … 1000000 (12 labels)
  //                                  1 crore → -1000000 0 … 10000000 (12 labels, 8 chars)
  //   > 1 crore               10     5 crore → 0 10000000 … 50000000 (6 labels)
  //                                  10 crore → -20000000 0 … 100000000 (7 labels)
  //                                  100 crore → 0 200000000 … 1000000000 (6–7 labels, 10 chars)
  //
  // Why it steps down: a label is ~7.5px per digit; 22 labels across a
  // ~1500px axis leave ~68px each, so 9-digit labels (`100000000`) overlapped
  // into one smear on the owner's dashboard. Fewer ticks for bigger numbers
  // keep every label readable at any width; the ≤ 1 lakh band is the one the
  // reference captures cover, so it is untouched. One Math.max over five
  // numbers — nothing to optimise.
  const webTickAmount = (data) => {
    const big = Math.max(0, ...data.map((v) => Math.abs(Number(v) || 0)))
    if (big <= 100000) return 24
    if (big <= 10000000) return 12
    return 10
  }

  // Jab ek bar dusre ke mukable bahut chhota ho (owner: -360 vs 100,000,000) to
  // linear axis pe uski length sub-pixel ho jaati hai -> bar dikhta hi nahi.
  // Isliye CHART ko di jaane wali value me har non-zero ko kam se kam
  // MIN_BAR_PCT * range kar dete hain (sirf DISPLAY ke liye). Tooltip aur niche
  // ke stat numbers HAMESHA original value se aate hain (niche fmtExact +
  // dataPointIndex se raw data lookup), to koi galat number nahi dikhta.
  // Floor sirf display value badalta hai; axis ApexCharts khud data se banata hai.
  // 5% ne -200 wali bar ko (range 4200 ka floor = 210) -210 bana diya tha, jisse
  // apex ka niceScale axis min -200 se -400 kar deta tha. Reference capture
  // (2026-09-20) -200 se shuru hota hai. 1% pe owner ka -360 vs 10-crore wala
  // bar ab bhi ~15px chauda rehta hai, yaani dikhta hai.
  const MIN_BAR_PCT = 0.01
  const withMinBar = (values) => {
    const max = Math.max(0, ...values)
    const min = Math.min(0, ...values)
    const floor = (max - min) * MIN_BAR_PCT
    if (!Number.isFinite(floor) || floor <= 0) return values
    return values.map((v) => (!v || Math.abs(v) >= floor ? v : Math.sign(v) * floor))
  }

  const barChartOptions = (categories, colors, data) => {
    // value-axis config (scale + formatter) — horizontal me x-axis pe, vertical me y-axis pe
    const valueAxis = horizontal
      // rotate: 0 — apex's default is -45 and it tilted the owner's 8-digit
      // labels into the legend (2026-09-17 capture); dimensions/XAxis.js only
      // skips the tilt when rotate is exactly 0. Overlap, if any, is handled
      // by hideOverlappingLabels (default true), and the tick formula above
      // keeps the count low enough that there is none.
      ? { tickAmount: webTickAmount(data), labels: { rotate: 0, formatter: fmtAxisWeb } }
      : { labels: { formatter: fmtAxisMobile(data) } }
    return {
      chart: {
        type: 'bar',
        height: 350,
        toolbar: { show: true },
        // The load "bump" is ApexCharts' own, exactly as on the reference.
        // The reference passes NO animations block: apex v3 gives every bar
        // chart `easing: 'swing'` by itself (its per-type defaults) on top of
        // the global speed 800 / animateGradually 150ms / dynamicAnimation 350.
        // These are those values, written out so nobody has to dig for them.
        //   swing = (t-=1)*t*((1.70158+1)*t+1.70158)+1 -> peaks at 1.10x the
        //   target 58% of the way in (464ms), then comes back: 83,753 rises to
        //   ~92,100 and settles. Measured frame by frame on the reference
        //   recordings (phone + web, 2026-09-21) — peak, timing and the 150ms
        //   bar-after-bar start all match.
        // Two things that are the reference's behaviour too, not bugs:
        //   - the bar that IS the axis max never shows its bump: bars are
        //     clipped to the grid, so its overshoot is cut off at the edge
        //   - the axis is final from the first frame and never moves
        // This replaced a hand-made two-phase bump (mount at 112%, swap the
        // real values in 600ms later). That inflated the axis — 100000000
        // became 120000000 — and re-drew it mid-animation, so the labels and
        // the whole plot jumped; and every bar moved at once.
        animations: {
          enabled: true,
          easing: 'swing',
          speed: CHART_BAR_MS,   // reference/apex default is 800 — see the constant
          animateGradually: { enabled: true, delay: CHART_STAGGER_MS },
          dynamicAnimation: { enabled: true, speed: 350 },
        },
      },
      plotOptions: {
        bar: horizontal
          ? { horizontal: true, barHeight: '65%', distributed: true }
          : { horizontal: false, columnWidth: '35%', distributed: true },
      },
      dataLabels: { enabled: false },
      colors,
      // horizontal: categories y-axis pe (plain), value bottom x-axis pe
      // vertical:   categories x-axis pe (-45° rotate), value left y-axis pe
      xaxis: horizontal
        ? { categories, ...valueAxis }
        : { categories, labels: { rotate: -45, rotateAlways: true, style: { fontSize: '12px' } } },
      yaxis: horizontal ? {} : valueAxis,
      // tooltip HAMESHA raw value se (withMinBar ki floored value se nahi)
      tooltip: {
        y: {
          formatter: (val, o) => {
            const i = o?.dataPointIndex
            return fmtExact(i != null && data[i] != null ? data[i] : val)
          },
        },
      },
      legend: {
        position: horizontal ? 'bottom' : 'top',
        horizontalAlign: 'center',
        markers: { shape: 'square' },
        labels: { colors: '#373d3f' },
      },
    }
  }

  // Chart 2: P/L overview
  // Wallet ke *_pts downline ka net MIRROR karte hain (player 200 haara -> owner
  // ke casino_pts bhi -200). Reference panel P/L ko UPLINE ke nazariye se dikhata
  // hai — downline ka loss = mera profit — isliye display par negate karte hain.
  // negPL: -0 se bachne ke liye, kyunki (-0).toLocaleString() === "-0".
  const negPL = (v) => { const n = Number(v) || 0; return n === 0 ? 0 : -n }
  const sportsPL = negPL(user?.sports_pts)
  const casinoPL = negPL(user?.casino_pts)
  const tpCasinoPL = negPL(user?.thirdparty_pts)
  const totalPL = Math.round((sportsPL + casinoPL + tpCasinoPL) * 100) / 100

  // Options/series memoize — warna har render pe naye objects se chart re-init
  // hoke dobara animate karta tha (laggy). Sirf data/orientation badalne pe rebuild.
  const chart1Data = [creditPts, allPts, settlementPts, upperPts, downPts]
  const chart2Data = [sportsPL, casinoPL, tpCasinoPL, totalPL]

  // Reference (user, 2026-09-21): a card whose every value is 0 is not drawn
  // at all — no graph, no legend row. The page goes straight from the stat
  // tiles to Our Live Casino. An empty axis with five 0 bars and "0" under
  // each label said nothing the tiles above had not already said. A live P/L
  // still shows while points are empty (see hasChart2Data below).
  // `user` is loaded before the charts mount (chartsGate), so this cannot flash
  // the cards on the way in.
  const hasChart1Data = chart1Data.some((v) => Number(v) !== 0)
  // Reference (user, 2026-10-11): the P/L card follows the points card — an
  // all-0 P/L still draws (empty 0.0–2.0 axis) whenever any points are non-zero.
  const hasChart2Data = hasChart1Data || chart2Data.some((v) => Number(v) !== 0)

  const chart1Options = useMemo(() => barChartOptions(
    ['Credit Pts', 'All Pts', 'Settlement Pts', 'Upper Pts', 'Down Pts'],
    ['#556ee6', '#f1b44c', '#50a5f1', '#34c38f', '#343a40'],
    chart1Data,
  ), [horizontal, creditPts, allPts, settlementPts, upperPts, downPts])

  const chart2Options = useMemo(() => barChartOptions(
    ['Sports P/L', ' Casino P/L', 'Third Party Casino P/L', 'Total P/L'],
    ['#556ee6', '#f1b44c', '#50a5f1', '#34c38f'],
    chart2Data,
  ), [horizontal, sportsPL, casinoPL, tpCasinoPL, totalPL])

  // Chart do gate ke baad hi mount ho: (1) boot-loader khatam, (2) real `user`
  // data aa gaya. Warna zero-data pe mount hoke bounce khaa leta.
  const chartsGate = chartsReady && !!user

  // ...aur gate true hone ke baad bhi ~400ms ruko taaki splash loader ka fade
  // (opacity 0.3s) POORA khatam ho jaye. Warna chart splash ke peeche mount
  // hoke apni bounce animation splash-fade ke dauraan hi chala deta tha aur
  // user ko dikhti hi nahi thi (ApexCharts JS se `d` morph karta hai — ek hi
  // baar chalti hai, CSS se kuch control nahi). 400ms baad chart mount -> poori
  // bounce screen pe fresh chalti hai.
  const [painted, setPainted] = useState(false)
  useEffect(() => {
    if (!chartsGate) { setPainted(false); return }
    const t = setTimeout(() => setPainted(true), 400)
    return () => clearTimeout(t)
  }, [chartsGate])
  const showCharts = painted

  // chart ko DISPLAY values jaati hain (chhote bars ko min length milti hai),
  // tooltip + niche ke numbers raw values se. One data set from the first
  // render — the bump comes from the easing above, not from swapping series.
  const chart1Series = [{ data: withMinBar(chart1Data) }]
  const chart2Series = [{ data: withMinBar(chart2Data) }]

  return (
    <div className="p-1">
      {/* Stats Cards */}
      <div className="row row5">
        <div className="col-6 col-md-3">
          <div className="card mini-stats-wid">
            <div className="card-body">
              <p className="text-muted fw-medium">Balance</p>
              <h4>{fmt(user?.inr_balance ?? user?.balance)}</h4>
            </div>
          </div>
        </div>
        <div className="col-6 col-md-3">
          <div className="card mini-stats-wid">
            <div className="card-body">
              <p className="text-muted fw-medium">Exposure</p>
              {/* API sends a positive payout risk; the card shows it as a loss (-). */}
              <h4>{fmt(-Math.abs(Number(user?.total_exposure) || 0) || 0)}</h4>
            </div>
          </div>
        </div>
        <div className="col-6 col-md-3">
          <div className="card mini-stats-wid">
            <div className="card-body">
              <p className="text-muted fw-medium">Credit pts</p>
              <h4>{fmt(creditPts)}</h4>
            </div>
          </div>
        </div>
        <div className="col-6 col-md-3">
          <div className="card mini-stats-wid">
            <div className="card-body">
              <p className="text-muted fw-medium">All pts</p>
              <h4>{fmt(allPts)}</h4>
            </div>
          </div>
        </div>
        <div className="col-6 col-md-3">
          <div className="card mini-stats-wid">
            <div className="card-body">
              <p className="text-muted fw-medium">Settlement pts</p>
              <h4>{fmt(settlementPts)}</h4>
            </div>
          </div>
        </div>
        <div className="col-6 col-md-3">
          <div className="card mini-stats-wid">
            <div className="card-body">
              <p className="text-muted fw-medium">Upper pts</p>
              <h4>{fmt(upperPts)}</h4>
            </div>
          </div>
        </div>
        <div className="col-6 col-md-3">
          <div className="card mini-stats-wid">
            <div className="card-body">
              <p className="text-muted fw-medium">Down pts</p>
              <h4>{fmt(downPts)}</h4>
            </div>
          </div>
        </div>
      </div>

      {/* Charts Row */}
      <div className="row">
        {/* Chart 1: Points Overview — hidden entirely while every point is 0 */}
        {hasChart1Data && (
        <div className="col-xl-12">
          <div className="card">
            <div className="card-body">
              <div style={{ minHeight: 365 }}>
                {/* key: remount on orientation change. ApexCharts keeps one
                    globals object per instance across updateOptions, and its
                    x-label "correction" (axes/XAxis.js xAxisLabelCorrections)
                    anchors every label `end` while `rotateXLabels` is true —
                    a flag only the VERTICAL chart (rotateAlways) sets and the
                    horizontal one never clears. Carried over (resize across
                    768px, or HMR), the web axis rendered with each number's
                    right edge on its tick instead of centred (2026-09-17
                    capture). A fresh instance per orientation cannot inherit
                    it. Same key on chart 2 below. */}
                {showCharts && (
                  <IntroBarChart key={horizontal ? 'web' : 'mobile'} options={chart1Options} series={chart1Series} />
                )}
              </div>
              <div className="row row5 align-self-center text-center">
                <div className="col-6 col-sm">
                  <p className="mb-2 font-size-11"><i className="mdi mdi-circle align-middle font-size-10 me-2 text-primary"></i> Credit pts</p>
                  <h5>{fmt(creditPts)}</h5>
                </div>
                <div className="col-6 col-sm">
                  <p className="mb-2 font-size-11"><i className="mdi mdi-circle align-middle font-size-10 me-2 text-warning"></i> All pts</p>
                  <h5>{fmt(allPts)}</h5>
                </div>
                <div className="col-4 col-sm">
                  <p className="mb-2 font-size-11"><i className="mdi mdi-circle align-middle font-size-10 me-2 text-info"></i> Settlement pts</p>
                  <h5>{fmt(settlementPts)}</h5>
                </div>
                <div className="col-4 col-sm">
                  <p className="mb-2 font-size-11"><i className="mdi mdi-circle align-middle font-size-10 me-2 text-success"></i> Upper pts</p>
                  <h5>{fmt(upperPts)}</h5>
                </div>
                <div className="col-4 col-sm">
                  <p className="mb-2 font-size-11"><i className="mdi mdi-circle align-middle font-size-10 me-2 text-dark"></i> Down pts</p>
                  <h5>{fmt(downPts)}</h5>
                </div>
              </div>
            </div>
          </div>
        </div>

        )}

        {/* Chart 2: P/L Overview — hidden only while every point AND every P/L is 0 */}
        {hasChart2Data && (
        <div className="col-xl-12">
          <div className="card">
            <div className="card-body">
              <div style={{ minHeight: 365 }}>
                {showCharts && (
                  <IntroBarChart key={horizontal ? 'web' : 'mobile'} options={chart2Options} series={chart2Series} />
                )}
              </div>
              <div>
                <div className="row row5 align-self-center text-center">
                  <div className="col-6 col-sm-3">
                    <p className="mb-2 font-size-11"><i className="mdi mdi-circle align-middle font-size-10 me-2 text-primary"></i> Sports P/L</p>
                    <h5>{fmt(sportsPL)}</h5>
                  </div>
                  <div className="col-6 col-sm-3">
                    <p className="mb-2 font-size-11"><i className="mdi mdi-circle align-middle font-size-10 me-2 text-warning"></i> Casino P/L</p>
                    <h5>{fmt(casinoPL)}</h5>
                  </div>
                  <div className="col-6 col-sm-3">
                    <p className="mb-2 font-size-11"><i className="mdi mdi-circle align-middle font-size-10 me-2 text-info"></i> Tp Casino P/L</p>
                    <h5>{fmt(tpCasinoPL)}</h5>
                  </div>
                  <div className="col-6 col-sm-3">
                    <p className="mb-2 font-size-11"><i className="mdi mdi-circle align-middle font-size-10 me-2 text-success"></i> Total P/L</p>
                    <h5>{fmt(totalPL)}</h5>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        )}
      </div>

      {/* Our Live Casino */}
      <div className="row">
        <div className="col-12">
          <h4 className="sport-list-title pl-2">Our Live Casino</h4>
          {' '}
          <SimpleBarBox maxHeight={470}>
            <div className="casino-banners">
              {CASINO_ITEMS.map((item) => (
                <div className="casino-banner-item" key={item.id}>
                  <Link to={`/admin/casino/${item.id}`} className="">
                    <img
                      className="img-fluid"
                      data-src={`${CASINO_IMG_BASE}/${item.img}`}
                      src={`${CASINO_IMG_BASE}/${item.img}`}
                      lazy="loaded"
                    />
                  </Link>
                </div>
              ))}
            </div>
          </SimpleBarBox>
        </div>
      </div>
    </div>
  )
}

export default Home
