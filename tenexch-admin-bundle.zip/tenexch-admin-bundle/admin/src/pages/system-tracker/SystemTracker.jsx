import { Fragment, useState, useEffect, useCallback, useRef } from 'react'
import { Link } from 'react-router-dom'
import Swal from 'sweetalert2'
import LoaderOverlay from '../../components/LoaderOverlay'
import {
  getAlerts, runScan, searchAccounts, getAccountReport, getProvenance,
  getWatchdog, runWatchdogScan, acknowledgeFinding,
} from '../../services/systemTrackerService'

/* Owner-only System Tracker.
 *
 * Three tabs over server/systemTracker:
 *   Alerts   — money-integrity findings per account (scanner.js + hierarchyChecks.js)
 *   Trace    — one account: rule-by-rule verification + where its balance came from
 *   Watchdog — markets that are not settling, each with the action that fixes it
 *
 * NOTHING HERE MOVES MONEY. The watchdog's action button deep-links to the existing
 * settlement screen for that case, so the void/settle still happens behind its own
 * owner + transaction-password gate. Reimplementing those flows here would mean a
 * second money path to keep correct, which is exactly what we don't want.
 */

const money = (v) =>
  Number(v || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })

const SEV_CLASS = { critical: 'bg-danger', high: 'bg-warning text-dark', info: 'bg-secondary', review: 'bg-secondary' }
const sevBadge = (s) => SEV_CLASS[s] || 'bg-secondary'

const ago = (ts) => {
  if (!ts) return '—'
  const mins = Math.round((Date.now() - new Date(ts).getTime()) / 60000)
  if (mins < 1) return 'just now'
  if (mins < 60) return `${mins}m ago`
  const h = Math.round(mins / 60)
  return h < 24 ? `${h}h ago` : `${Math.round(h / 24)}d ago`
}

// Which existing owner screen resolves each watchdog finding. Keeping this mapping
// here (rather than sending a URL from the server) means the settlement routes stay
// the frontend's business.
const ACTION_PAGE = {
  resultDeclaredNotSettled: { to: '/admin/settlement/match',      label: 'Open Match Settlement' },
  staleOpenMarket:          { to: '/admin/settlement/match',      label: 'Open Match Settlement' },
  staleFancy:               { to: '/admin/settlement/fancy',      label: 'Open Fancy Settlement' },
  resultNeverDeclared:      { to: '/admin/settlement/match',      label: 'Open Match Settlement' },
  stuckCasinoBet:           { to: '/admin/settlement/casino',     label: 'Open Casino Settlement' },
  settledButNotPaid:        { to: '/admin/settlement/void-bets',  label: 'Open Void Bets' },
}

function StatCard({ label, value, tone }) {
  return (
    <div className="col-md-3 col-6">
      <div className="card mini-stats-wid mb-3">
        <div className="card-body py-3">
          <p className="text-muted fw-medium mb-1" style={{ fontSize: 12 }}>{label}</p>
          <h4 className={`mb-0 ${tone || ''}`}>{value}</h4>
        </div>
      </div>
    </div>
  )
}

/* ------------------------------------------------------------------ Alerts tab */
function AlertsTab({ data, onScan, scanning, onPick }) {
  if (!data) return null
  const users = data.users || []
  return (
    <>
      <div className="row">
        <StatCard label="Accounts flagged" value={data.actionableUsers ?? data.count ?? 0}
                  tone={(data.actionable ?? data.totalIssues) ? 'text-danger' : 'text-success'} />
        <StatCard label="Actionable findings" value={data.actionable ?? data.totalIssues ?? 0}
                  tone={(data.actionable ?? 0) ? 'text-danger' : 'text-success'} />
        <StatCard label="Informational" value={data.informational ?? 0} />
        <StatCard label="Last scan" value={ago(data.lastScan)} />
        <div className="col-md-3 col-6">
          <div className="card mini-stats-wid mb-3">
            <div className="card-body py-3">
              <button className="btn btn-primary btn-sm w-100" onClick={onScan} disabled={scanning}>
                {scanning ? 'Scanning…' : 'Re-scan now'}
              </button>
            </div>
          </div>
        </div>
      </div>

      {users.length === 0 ? (
        <div className="alert alert-success mb-0">
          No integrity findings. Every account's wallet, points and hierarchy reconcile.
        </div>
      ) : (
        <div className="table-responsive">
          <table className="table table-striped table-sm align-middle mb-0">
            <thead>
              <tr>
                <th style={{ width: 60 }}>#</th>
                <th>Account</th>
                <th>Role</th>
                <th>Findings</th>
              </tr>
            </thead>
            <tbody>
              {users.map((u, i) => (
                <tr key={u.user_id}>
                  <td>{i + 1}</td>
                  <td>
                    <button className="btn btn-link p-0 align-baseline"
                            onClick={() => onPick(u.username || u.user_id)}>
                      {u.username || u.user_id}
                    </button>
                    <div className="text-muted" style={{ fontSize: 11 }}>{u.user_id}</div>
                  </td>
                  <td>{u.role || '—'}</td>
                  <td>
                    {(u.issues || []).map((is) => (
                      <div key={is.key} className="mb-1">
                        <span className={`badge ${sevBadge(is.severity)} me-2`}>
                          {is.severity === 'info' ? 'info only' : is.severity}
                        </span>
                        <strong>{is.label}</strong>
                        <div className="text-muted" style={{ fontSize: 12 }}>
                          {is.detail} <span className="ms-1">· since {ago(is.since)}</span>
                        </div>
                      </div>
                    ))}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  )
}

/* ------------------------------------------------------------- Provenance panel */
function ProvenancePanel({ prov }) {
  const [open, setOpen] = useState({})
  if (!prov) return null
  const r = prov.reconciliation || {}
  const toggle = (k) => setOpen((o) => ({ ...o, [k]: !o[k] }))

  return (
    <div className="card mt-3">
      <div className="card-body">
        <h5 className="card-title mb-1">Where this balance came from</h5>
        <p className="text-muted mb-3" style={{ fontSize: 12 }}>
          Every rupee traced to the event that moved it, and to the account on the other side.
        </p>

        {prov.upline?.length > 0 && (
          <div className="mb-3">
            <span className="text-muted me-2" style={{ fontSize: 12 }}>Chain to owner:</span>
            <strong>{prov.account.username}</strong>
            {prov.upline.map((u) => (
              <span key={`${u.kind}-${u.id}`}>
                <span className="text-muted mx-1">←</span>
                <span className={u.broken ? 'text-danger' : ''}>
                  {u.username || u.id}{u.broken ? ' (broken link)' : ''}
                </span>
              </span>
            ))}
          </div>
        )}

        <div className="table-responsive">
          <table className="table table-sm align-middle mb-0">
            <thead>
              <tr><th>Source</th><th className="text-end">Amount</th><th style={{ width: 90 }}>Events</th><th style={{ width: 40 }}></th></tr>
            </thead>
            <tbody>
              {(prov.buckets || []).filter((b) => b.amount !== 0 || b.count > 0).map((b) => (
                <Fragment key={b.key}>
                  <tr className={b.severity === 'attention' ? 'table-danger' : ''}>
                    <td>
                      {b.label}
                      {b.severity === 'attention' && (
                        <span className="badge bg-danger ms-2">manual override</span>
                      )}
                      {b.note && <div className="text-muted" style={{ fontSize: 11 }}>{b.note}</div>}
                    </td>
                    <td className={`text-end ${Number(b.amount) < 0 ? 'text-danger' : 'text-success'}`}>
                      {money(b.amount)}
                    </td>
                    <td>{b.count || 0}{b.truncated ? '+' : ''}</td>
                    <td>
                      {b.count > 0 && b.events?.length > 0 && (
                        <button className="btn btn-sm btn-link p-0" onClick={() => toggle(b.key)}>
                          {open[b.key] ? '−' : '+'}
                        </button>
                      )}
                    </td>
                  </tr>
                  {open[b.key] && (b.events || []).map((e) => (
                    <tr key={`${b.key}-${e.id}`} className="table-light">
                      <td style={{ paddingLeft: 28, fontSize: 12 }}>
                        {new Date(e.at).toLocaleString('en-IN')}
                        {e.counterparty && <> · <strong>{e.counterparty}</strong></>}
                        {e.type && <> · {e.type}</>}
                        {e.bet_id && <> · bet #{e.bet_id}</>}
                        {e.market_type && <> · {e.market_type}</>}
                        {e.remark && <div className="text-muted">{e.remark}</div>}
                        {e.balance_before != null && (
                          <div className="text-muted">
                            balance {money(e.balance_before)} → {money(e.balance_after)}
                          </div>
                        )}
                      </td>
                      <td className={`text-end ${Number(e.amount) < 0 ? 'text-danger' : 'text-success'}`} style={{ fontSize: 12 }}>
                        {money(e.amount)}
                      </td>
                      <td colSpan={2}></td>
                    </tr>
                  ))}
                </Fragment>
              ))}
            </tbody>
          </table>
        </div>

        <div className={`alert mt-3 mb-0 ${r.pass ? 'alert-success' : 'alert-danger'}`}>
          <div className="d-flex justify-content-between flex-wrap">
            <div>
              <strong>{r.pass ? 'Balance fully accounted for' : 'Balance does not reconcile'}</strong>
              <div style={{ fontSize: 12 }}>{r.note}</div>
            </div>
            <div className="text-end" style={{ fontSize: 12 }}>
              <div>opening {money(r.opening)} + transfers {money(r.transactions)} + game activity {money(r.settlement)}</div>
              <div>= <strong>{money(r.derived)}</strong> vs stored <strong>{money(r.stored)}</strong></div>
              {!r.pass && <div className="text-danger">residual {money(r.residual)}</div>}
            </div>
          </div>
        </div>

        {/* Secondary, and deliberately NOT an alarm: whether the ledger's P/L rows
            describe the whole of the game activity above. The balance has already
            reconciled at this point — a gap here is bookkeeping detail, not lost money. */}
        {r.ledger && !r.ledger.complete && (
          <div className="alert alert-secondary mt-2 mb-0 py-2">
            <div className="d-flex justify-content-between flex-wrap">
              <div style={{ fontSize: 12 }}>
                <strong>Ledger detail incomplete</strong> — not a money problem
                <div>{r.ledger.note}</div>
              </div>
              <div className="text-end" style={{ fontSize: 12 }}>
                <div>ledger P/L rows {money(r.ledger.recordedPL)} · actual movement {money(r.ledger.observedMovement)}</div>
                <div>not described by P/L rows: {money(r.ledger.undescribed)}</div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

/* ------------------------------------------------------------------- Trace tab */
function TraceTab({ query, setQuery, report, prov, onSearch, suggestions, onPick, loading }) {
  return (
    <>
      <div className="row mb-3">
        <div className="col-md-6 position-relative">
          <div className="input-group">
            <input className="form-control" placeholder="Search username or ID…"
                   value={query}
                   onChange={(e) => { setQuery(e.target.value); onSearch(e.target.value) }}
                   onKeyDown={(e) => { if (e.key === 'Enter' && query.trim()) onPick(query.trim()) }} />
            <button className="btn btn-primary" onClick={() => query.trim() && onPick(query.trim())}>
              Trace
            </button>
          </div>
          {suggestions.length > 0 && (
            <div className="list-group position-absolute w-100 shadow" style={{ zIndex: 20 }}>
              {suggestions.map((s) => (
                <button key={`${s.kind}-${s.user_id}`} className="list-group-item list-group-item-action py-1"
                        onClick={() => onPick(s.username || s.user_id)}>
                  <strong>{s.username}</strong>
                  <span className="text-muted ms-2" style={{ fontSize: 12 }}>{s.role} · {s.kind}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {loading && <div className="text-muted">Loading…</div>}

      {report?.snapshot && (
        <>
          <div className="row">
            <StatCard label="Total balance" value={money(report.snapshot.total_balance)} />
            <StatCard label="Available" value={money(report.snapshot.available_balance)} />
            <StatCard label="Locked in bets" value={money(report.snapshot.locked_exposure)} />
            <StatCard label="Verdict"
                      value={report.allPass ? 'All checks pass' : 'Issues found'}
                      tone={report.allPass ? 'text-success' : 'text-danger'} />
          </div>

          {/* Ledger-derived P/L. These are the figures to trust: total win + total loss
              straight from credits_ledger. The stored users.* counters are shown only
              when they disagree, because settlement maintains them inconsistently. */}
          {report.snapshot.actual_pl != null && (
            <div className="row">
              <StatCard label="Actual P/L (ledger)" value={money(report.snapshot.actual_pl)}
                        tone={Number(report.snapshot.actual_pl) < 0 ? 'text-danger' : 'text-success'} />
              <StatCard label="Total win (ledger)" value={money(report.snapshot.total_win)} />
              <StatCard label="Total loss (ledger)" value={money(report.snapshot.total_loss)} />
              <div className="col-md-3 col-6">
                <div className="card mini-stats-wid mb-3">
                  <div className="card-body py-3">
                    <p className="text-muted fw-medium mb-1" style={{ fontSize: 12 }}>Stored counters</p>
                    {report.snapshot.counters_lag ? (
                      <>
                        <h6 className="mb-0 text-warning">Lagging</h6>
                        <div className="text-muted" style={{ fontSize: 11 }}>
                          reads {money(report.snapshot.profit_loss)} · win {money(report.snapshot.net_win)} · loss {money(report.snapshot.net_loss)}
                        </div>
                      </>
                    ) : (
                      <h6 className="mb-0 text-success">Agree with ledger</h6>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {(report.categories || []).map((c) => (
            <div className="card mb-2" key={c.key}>
              <div className="card-body py-2">
                <h6 className="mb-2">
                  <span className={`badge ${c.pass ? 'bg-success' : 'bg-danger'} me-2`}>
                    {c.pass ? 'OK' : 'FAIL'}
                  </span>
                  {c.label}
                </h6>
                <table className="table table-sm mb-0">
                  <tbody>
                    {(c.rules || []).map((ru, i) => (
                      <Fragment key={`${c.key}-${i}`}>
                        <tr>
                          <td style={{ width: 90 }}>
                            <span className={`badge ${ru.info ? 'bg-secondary' : (ru.pass ? 'bg-success' : 'bg-danger')}`}>
                              {ru.info ? 'info' : (ru.pass ? 'pass' : 'fail')}
                            </span>
                          </td>
                          <td>
                            {ru.label}
                            {ru.note && <div className="text-muted" style={{ fontSize: 11 }}>{ru.note}</div>}
                          </td>
                          <td className="text-end" style={{ width: 260, fontSize: 12 }}>
                            {!ru.info && (
                              <>expected {money(ru.expected)} · actual {money(ru.actual)}
                                {Math.abs(Number(ru.diff)) > 0.01 && (
                                  <span className="text-danger"> · diff {money(ru.diff)}</span>
                                )}
                              </>
                            )}
                          </td>
                        </tr>
                        {(ru.subs || []).map((sub, j) => (
                          <tr key={`${c.key}-${i}-${j}`} className="table-light">
                            <td></td>
                            <td style={{ paddingLeft: 24, fontSize: 12 }}>
                              {sub.label}
                              {sub.note && <span className="text-muted ms-2">{sub.note}</span>}
                            </td>
                            <td className="text-end" style={{ fontSize: 12 }}>{money(sub.actual)}</td>
                          </tr>
                        ))}
                      </Fragment>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ))}

          <ProvenancePanel prov={prov} />
        </>
      )}
    </>
  )
}

/* ---------------------------------------------------------------- Watchdog tab */
function WatchdogTab({ data, onScan, scanning, onAck }) {
  if (!data) return null
  const f = data.findings || []
  const th = data.thresholds || {}
  return (
    <>
      <div className="row">
        <StatCard label="Open findings" value={data.count ?? 0} tone={data.count ? 'text-danger' : 'text-success'} />
        <StatCard label="Critical" value={data.critical ?? 0} tone={data.critical ? 'text-danger' : ''} />
        <StatCard label="Stake at risk" value={money(data.stakeAtRisk)} />
        <div className="col-md-3 col-6">
          <div className="card mini-stats-wid mb-3">
            <div className="card-body py-3">
              <button className="btn btn-primary btn-sm w-100" onClick={onScan} disabled={scanning}>
                {scanning ? 'Sweeping…' : 'Sweep now'}
              </button>
              <div className="text-muted mt-1" style={{ fontSize: 11 }}>
                stale after {th.STALE_HOURS}h · last {ago(data.lastScan)}
              </div>
            </div>
          </div>
        </div>
      </div>

      {f.length === 0 ? (
        <div className="alert alert-success mb-0">
          Nothing stuck. Every market with open bets is within the {th.STALE_HOURS}-hour window,
          settlement jobs are moving and the result feed is live.
        </div>
      ) : (
        <div className="table-responsive">
          <table className="table table-striped table-sm align-middle mb-0">
            <thead>
              <tr>
                <th>Severity</th>
                <th>What is stuck</th>
                <th className="text-end">Bets</th>
                <th className="text-end">Stake</th>
                <th className="text-end">Age</th>
                <th>What to do</th>
                <th style={{ width: 190 }}></th>
              </tr>
            </thead>
            <tbody>
              {f.map((row) => {
                const act = ACTION_PAGE[row.kind]
                return (
                  <tr key={row.id} className={row.acknowledged_by ? 'opacity-75' : ''}>
                    <td><span className={`badge ${sevBadge(row.severity)}`}>{row.severity}</span></td>
                    <td>
                      <strong>{row.title || row.ref_key}</strong>
                      <div className="text-muted" style={{ fontSize: 12 }}>{row.detail}</div>
                      <div className="text-muted" style={{ fontSize: 11 }}>
                        {row.label}
                        {row.market_type ? ` · ${row.market_type}` : ''}
                        {row.event_id ? ` · event ${row.event_id}` : ''}
                      </div>
                    </td>
                    <td className="text-end">{row.bets_count ?? '—'}</td>
                    <td className="text-end">{money(row.stake_total)}</td>
                    <td className="text-end">{row.stale_hours != null ? `${row.stale_hours}h` : '—'}</td>
                    <td style={{ fontSize: 12 }}>
                      {row.suggested_action}
                      {row.action_endpoint && (
                        <div className="text-muted" style={{ fontSize: 11 }}>{row.action_endpoint}</div>
                      )}
                    </td>
                    <td className="text-end">
                      {act && (
                        <Link to={act.to} className="btn btn-sm btn-primary mb-1 w-100">{act.label}</Link>
                      )}
                      {row.acknowledged_by ? (
                        <div className="text-muted" style={{ fontSize: 11 }}>
                          ack by {row.acknowledged_by} {ago(row.acknowledged_at)}
                        </div>
                      ) : (
                        <button className="btn btn-sm btn-outline-secondary w-100"
                                onClick={() => onAck(row)}>
                          I am handling this
                        </button>
                      )}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}
    </>
  )
}

/* ------------------------------------------------------------------------ page */
function SystemTracker() {
  const [tab, setTab] = useState('alerts')
  const [showLoader, setShowLoader] = useState(true)
  const [alerts, setAlerts] = useState(null)
  const [watchdog, setWatchdog] = useState(null)
  const [scanning, setScanning] = useState(false)
  const [query, setQuery] = useState('')
  const [suggestions, setSuggestions] = useState([])
  const [report, setReport] = useState(null)
  const [prov, setProv] = useState(null)
  const [traceLoading, setTraceLoading] = useState(false)
  const searchTimer = useRef(null)

  const loadAlerts = useCallback(async () => {
    try { setAlerts(await getAlerts()) } catch (e) { console.error('alerts load failed:', e) }
  }, [])

  const loadWatchdog = useCallback(async () => {
    try { setWatchdog(await getWatchdog()) } catch (e) { console.error('watchdog load failed:', e) }
  }, [])

  useEffect(() => {
    Promise.all([loadAlerts(), loadWatchdog()]).finally(() => setShowLoader(false))
  }, [loadAlerts, loadWatchdog])

  const doScan = async () => {
    setScanning(true)
    try { setAlerts(await runScan()) }
    catch (e) { Swal.fire('Scan failed', e?.response?.data?.error || e.message, 'error') }
    finally { setScanning(false) }
  }

  const doWatchdogScan = async () => {
    setScanning(true)
    try { setWatchdog(await runWatchdogScan()) }
    catch (e) { Swal.fire('Sweep failed', e?.response?.data?.error || e.message, 'error') }
    finally { setScanning(false) }
  }

  // debounced so a fast typist doesn't fire a query per keystroke
  const onSearch = (v) => {
    clearTimeout(searchTimer.current)
    if (!v || v.trim().length < 2) { setSuggestions([]); return }
    searchTimer.current = setTimeout(async () => {
      try {
        const res = await searchAccounts(v.trim())
        setSuggestions(res?.results || [])
      } catch { setSuggestions([]) }
    }, 250)
  }

  const pickAccount = async (who) => {
    setSuggestions([])
    setQuery(who)
    setTab('trace')
    setTraceLoading(true)
    setReport(null); setProv(null)
    try {
      const [rep, pr] = await Promise.allSettled([getAccountReport(who), getProvenance(who)])
      if (rep.status === 'fulfilled') setReport(rep.value)
      else Swal.fire('Not found', rep.reason?.response?.data?.error || rep.reason.message, 'warning')
      if (pr.status === 'fulfilled') setProv(pr.value)
    } finally {
      setTraceLoading(false)
    }
  }

  const doAck = async (row) => {
    const ok = await Swal.fire({
      title: 'Mark as being handled?',
      text: `"${row.title || row.ref_key}" stays on the board but stops being counted as unattended. This does not settle or void anything.`,
      icon: 'question', showCancelButton: true, confirmButtonText: 'Yes, I am handling it',
    })
    if (!ok.isConfirmed) return
    try {
      await acknowledgeFinding(row.id)
      await loadWatchdog()
    } catch (e) {
      Swal.fire('Failed', e?.response?.data?.error || e.message, 'error')
    }
  }

  const alertCount = alerts?.actionable ?? alerts?.totalIssues ?? 0
  const wdCount = watchdog?.count ?? 0

  const TABS = [
    { key: 'alerts',   label: 'Alerts',        badge: alertCount },
    { key: 'trace',    label: 'Account Trace', badge: 0 },
    { key: 'watchdog', label: 'Watchdog',      badge: wdCount },
  ]

  return (
    <div>
      {showLoader && <LoaderOverlay />}
      <div className="row">
        <div className="col-12">
          <div className="page-title-box d-flex align-items-center justify-content-between">
            <h4 className="mb-0 font-size-18">System Tracker</h4>
            <div className="page-title-right">
              <ol className="breadcrumb m-0">
                <li className="breadcrumb-item"><Link to="/admin/home">Home</Link></li>
                <li className="breadcrumb-item active"><span aria-current="location">System Tracker</span></li>
              </ol>
            </div>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-body">
          <ul className="nav nav-tabs mb-3">
            {TABS.map((t) => (
              <li className="nav-item" key={t.key}>
                <button className={`nav-link${tab === t.key ? ' active' : ''}`} onClick={() => setTab(t.key)}>
                  {t.label}
                  {t.badge > 0 && <span className="badge bg-danger ms-2">{t.badge}</span>}
                </button>
              </li>
            ))}
          </ul>

          {tab === 'alerts' && (
            <AlertsTab data={alerts} onScan={doScan} scanning={scanning} onPick={pickAccount} />
          )}
          {tab === 'trace' && (
            <TraceTab query={query} setQuery={setQuery} report={report} prov={prov}
                      onSearch={onSearch} suggestions={suggestions} onPick={pickAccount}
                      loading={traceLoading} />
          )}
          {tab === 'watchdog' && (
            <WatchdogTab data={watchdog} onScan={doWatchdogScan} scanning={scanning} onAck={doAck} />
          )}
        </div>
      </div>
    </div>
  )
}

export default SystemTracker
