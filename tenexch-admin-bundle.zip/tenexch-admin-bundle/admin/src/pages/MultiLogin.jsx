import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import Swal from 'sweetalert2'
import multiLoginService from '../services/multiLoginService'
import ExecutivePermissionsModal from '../components/ExecutivePermissionsModal'
import { PERMISSIONS } from '../utils/permissions'

const Toast = Swal.mixin({
  toast: true,
  position: 'top-end',
  showConfirmButton: false,
  timer: 3000,
  timerProgressBar: false,
})

// A row's permission value — tolerate legacy rows stored with label keys
// (pre key-contract migration) so they still render their ticks
const permValue = (perms, p) => !!(perms?.[p.key] ?? perms?.[p.label])

function MultiLogin() {
  const [formData, setFormData] = useState({
    uname: '',
    fullname: '',
    password: '',
    cpass: '',
    mpass: ''
  })
  const [checked, setChecked] = useState({})
  const [loading, setLoading] = useState(false)
  const [executives, setExecutives] = useState([])
  const [errors, setErrors] = useState({})
  const [editing, setEditing] = useState(null)

  // Reference (vee-validate) texts — "The <data-vv-as> field is required"
  const validateField = (name, value, all = formData) => {
    switch (name) {
      case 'uname':
        if (!value) return 'The Client ID field is required'
        if (value.length < 4) return 'The Client ID field must be at least 4 characters'
        return ''
      case 'fullname':
        if (!value) return 'The Full Name field is required'
        if (value.length < 4) return 'The Full Name field must be at least 4 characters'
        return ''
      case 'password':
        if (!value) return 'The Password field is required'
        if (value.length < 8) return 'The Password field must be at least 8 characters'
        if (!/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(value)) return 'The password must contain at least: 1 uppercase letter, 1 lowercase letter, 1 number'
        return ''
      case 'cpass':
        if (!value) return 'The Confirm Password field is required'
        if (value !== all.password) return 'The Confirm Password confirmation does not match'
        return ''
      case 'mpass':
        // Red outline only — the reference shows no message under this field
        if (!value) return 'required'
        return ''
      default:
        return ''
    }
  }

  const fetchExecutives = async () => {
    try {
      const res = await multiLoginService.list()
      if (res?.success && res.executives) {
        setExecutives(res.executives)
      } else if (res?.data) {
        setExecutives(res.data)
      } else {
        setExecutives([])
      }
    } catch (err) {
      console.error('Failed to fetch executives:', err)
    }
  }

  useEffect(() => { fetchExecutives() }, [])

  const handleChange = (e) => {
    const { name, value } = e.target
    const next = { ...formData, [name]: value }
    setFormData(next)
    setErrors(prev => {
      const updated = { ...prev, [name]: validateField(name, value, next) }
      // Password change can fix/break the confirm-password match
      if (name === 'password' && next.cpass) {
        updated.cpass = validateField('cpass', next.cpass, next)
      }
      return updated
    })
  }

  // Validate on blur too — leaving a field (even untouched) marks it
  const handleBlur = (e) => {
    const { name, value } = e.target
    setErrors(prev => ({ ...prev, [name]: validateField(name, value) }))
  }

  const isAllChecked = PERMISSIONS.every(p => checked[p.key])

  const handleCheckbox = (key) => {
    let next
    if (key === 'all') {
      const allOn = !isAllChecked
      next = {}
      if (allOn) PERMISSIONS.forEach(p => { next[p.key] = true })
    } else {
      next = { ...checked, [key]: !checked[key] }
    }
    setChecked(next)
    // Reference behavior: interacting with the checkboxes validates them —
    // unchecking the last one shows "The Privileges field is required"
    const anyChecked = PERMISSIONS.some(p => next[p.key])
    setErrors(prev => ({ ...prev, plist: anyChecked ? '' : 'The Privileges field is required' }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (loading) return
    const nextErrors = {}
    for (const field of ['uname', 'fullname', 'password', 'cpass']) {
      const msg = validateField(field, formData[field])
      if (msg) nextErrors[field] = msg
    }
    if (!PERMISSIONS.some(p => checked[p.key])) {
      nextErrors.plist = 'The Privileges field is required'
    }
    if (!formData.mpass) nextErrors.mpass = 'required'
    setErrors(nextErrors)
    if (Object.keys(nextErrors).length > 0) {
      // Reference toast: error icon, text in swal2-html-container
      Toast.fire({ icon: 'error', text: 'Please fill required fields' })
      return
    }

    setLoading(true)
    try {
      // THE KEY CONTRACT: send the canonical camelCase keys from the registry —
      // these must match requirePermission('<key>') on the server byte-for-byte
      const permissions = {}
      PERMISSIONS.forEach(p => { permissions[p.key] = !!checked[p.key] })
      const res = await multiLoginService.create({
        username: formData.uname,
        full_name: formData.fullname,
        password: formData.password,
        transactionPassword: formData.mpass,
        permissions
      })
      Toast.fire({ icon: 'success', text: res?.message || 'User Sucessfully Inserted' })
      handleReset()
      fetchExecutives()
    } catch (error) {
      Toast.fire({ icon: 'error', text: error.response?.data?.error || error.response?.data?.message || error.message })
    } finally {
      setLoading(false)
    }
  }

  const handleToggleActive = async (exec) => {
    try {
      const res = await multiLoginService.setActive(exec.id)
      Toast.fire({ icon: 'success', text: res?.message || 'Status updated' })
      fetchExecutives()
    } catch (error) {
      Toast.fire({ icon: 'error', text: error.response?.data?.message || error.message })
    }
  }

  const handlePassword = async (exec) => {
    const { value: password } = await Swal.fire({
      title: `New password for ${exec.username}`,
      input: 'password',
      inputPlaceholder: 'New password',
      showCancelButton: true,
      inputValidator: (v) => (!v || v.length < 4) ? 'A password of at least 4 characters is required' : undefined,
    })
    if (!password) return
    try {
      const res = await multiLoginService.changePassword(exec.id, password)
      Toast.fire({ icon: 'success', text: res?.message || 'Password updated' })
    } catch (error) {
      Toast.fire({ icon: 'error', text: error.response?.data?.message || error.message })
    }
  }

  const handleDelete = async (exec) => {
    const result = await Swal.fire({
      title: `Delete ${exec.username}?`,
      text: 'This login will stop working immediately.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Delete',
    })
    if (!result.isConfirmed) return
    try {
      const res = await multiLoginService.remove(exec.id)
      Toast.fire({ icon: 'success', text: res?.message || 'Executive deleted' })
      fetchExecutives()
    } catch (error) {
      Toast.fire({ icon: 'error', text: error.response?.data?.message || error.message })
    }
  }

  // Outline triggers live along with the message: red (is-invalid) when the
  // field has an error. Green success (is-valid) shows ONLY on Client ID —
  // the reference keeps the other fields plain when valid.
  const fieldClass = (name) => {
    if (errors[name]) return 'form-control is-invalid'
    if (name === 'uname' && errors[name] === '') return 'form-control is-valid'
    return 'form-control'
  }

  const handleReset = () => {
    setFormData({ uname: '', fullname: '', password: '', cpass: '', mpass: '' })
    setChecked({})
    setErrors({})
  }

  return (
    <div>
      <div>
        {/* Breadcrumb */}
        <div className="row">
          <div className="col-12">
            <div className="page-title-box d-flex align-items-center justify-content-between">
              <h4 className="mb-0 font-size-18">Multi Login Account</h4>
              <div className="page-title-right">
                <ol className="breadcrumb m-0">
                  <li className="breadcrumb-item"><Link to="/admin/home">Home</Link></li>
                  <li className="breadcrumb-item active"><span aria-current="location">Multi Login Account</span></li>
                </ol>
              </div>
            </div>
          </div>
        </div>

        {/* Form Card */}
        <div className="row">
          <div className="col-12">
            <div className="card">
              <div className="card-body create-account-container">
                <form method="post" onSubmit={handleSubmit}>
                  <div className="create-account-form">
                    <div>
                      <h5 className="mb-0">Personal Information</h5>
                      <div className="row">
                        <div className="col-md-3 form-group">
                          <label>Client ID</label>
                          <input type="text" name="uname" data-vv-as="Client ID" className={fieldClass('uname')} aria-required="true" aria-invalid={errors.uname ? 'true' : 'false'} value={formData.uname} onChange={handleChange} onBlur={handleBlur} />
                          {errors.uname && <small className="error">{errors.uname}</small>}
                        </div>
                        <div className="col-md-3 form-group">
                          <label>Full Name</label>
                          <input type="text" name="fullname" data-vv-as="Full Name" className={fieldClass('fullname')} aria-required="true" aria-invalid={errors.fullname ? 'true' : 'false'} value={formData.fullname} onChange={handleChange} onBlur={handleBlur} />
                          {errors.fullname && <small className="error">{errors.fullname}</small>}
                        </div>
                        <div className="col-md-3 form-group">
                          <label>Password</label>
                          <input type="password" name="password" data-vv-as="Password" className={fieldClass('password')} aria-required="true" aria-invalid={errors.password ? 'true' : 'false'} value={formData.password} onChange={handleChange} onBlur={handleBlur} />
                          {errors.password && <small className="error">{errors.password}</small>}
                        </div>
                        <div className="col-md-3 form-group">
                          <label>Confirm Password</label>
                          <input type="password" name="cpass" data-vv-as="Confirm Password" className={fieldClass('cpass')} aria-required="true" aria-invalid={errors.cpass ? 'true' : 'false'} value={formData.cpass} onChange={handleChange} onBlur={handleBlur} />
                          {errors.cpass && <small className="error">{errors.cpass}</small>}
                        </div>
                      </div>
                    </div>

                    {/* Privileges */}
                    <div className="mt-2 previlages">
                      <h5 className="mb-0">Privileges</h5>
                      <div className="previlage-box">
                        {/* All checkbox */}
                        <div className="previlage-item">
                          <div>
                            <div className="custom-control custom-checkbox">
                              <input type="checkbox" name="plist" className="custom-control-input" value="true" id="privilege-all" checked={isAllChecked} onChange={() => handleCheckbox('all')} />
                              <label className="custom-control-label" htmlFor="privilege-all">All</label>
                            </div>
                          </div>
                        </div>
                        <br />
                        {/* Individual privileges */}
                        {PERMISSIONS.map((p) => (
                          <div className="previlage-item" key={p.key}>
                            <div>
                              <div className={`custom-control custom-checkbox${errors.plist ? ' is-invalid' : ''}`}>
                                <input data-vv-as="Privileges" type="checkbox" name="plist" className="custom-control-input" value={p.key} id={`privilege-${p.key}`} checked={!!checked[p.key]} onChange={() => handleCheckbox(p.key)} />
                                <label className="custom-control-label" htmlFor={`privilege-${p.key}`}>{p.label}</label>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                      {errors.plist && <small className="error">{errors.plist}</small>}

                      {/* Transaction Code + Submit + Reset */}
                      <div className="previlage-master mt-2">
                        <div className="form-group mb-0">
                          {/* The reference markup keeps whitespace text nodes between these
                              inline elements — that's what creates the x-axis gaps */}
                          <input type="password" name="mpass" placeholder="Transaction Code" className={`form-control mpass-text${errors.mpass ? ' is-invalid' : ''}`} aria-required="true" aria-invalid={errors.mpass ? 'true' : 'false'} value={formData.mpass} onChange={handleChange} onBlur={handleBlur} />{' '}
                          <button type="submit" className="btn btn-success">Submit</button>{' '}
                          <button type="button" id="reset" className="btn btn-light" onClick={handleReset}>Reset</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </form>

                {/* Executives Table */}
                <div className="outer mt-4">
                  <div className="inner">
                    <table className="table table-bordered">
                      <tbody>
                        <tr>
                          <th className="fixed-col-1">Action</th>
                          <th className="fixed-col-2">Username</th>
                          <th className="fixed-col-3">IsAuth</th>
                          <th className="fixed-col-4">Full Name</th>
                          {PERMISSIONS.map(p => (
                            <th key={p.key}>{p.label}</th>
                          ))}
                        </tr>
                        {executives.map((exec, idx) => (
                          <tr key={exec.id || idx}>
                            <td className="fixed-col-1" style={{ whiteSpace: 'nowrap' }}>
                              <button type="button" className="btn btn-sm btn-primary mr-1" title="Edit privileges" onClick={() => setEditing(exec)}>
                                <i className="fas fa-edit"></i>
                              </button>
                              <button type="button" className={`btn btn-sm mr-1 ${exec.active ? 'btn-success' : 'btn-secondary'}`} title={exec.active ? 'Disable login' : 'Enable login'} onClick={() => handleToggleActive(exec)}>
                                {exec.active ? 'On' : 'Off'}
                              </button>
                              <button type="button" className="btn btn-sm btn-warning mr-1" title="Change password" onClick={() => handlePassword(exec)}>
                                <i className="fas fa-key"></i>
                              </button>
                              <button type="button" className="btn btn-sm btn-danger" title="Delete" onClick={() => handleDelete(exec)}>
                                <i className="fas fa-trash"></i>
                              </button>
                            </td>
                            <td className="fixed-col-2">{exec.username || '-'}</td>
                            <td className="fixed-col-3">{exec.active ? 'Y' : 'N'}</td>
                            <td className="fixed-col-4">{exec.full_name || exec.email || '-'}</td>
                            {PERMISSIONS.map(p => (
                              <td key={p.key}>{permValue(exec.permissions, p) ? '✓' : '-'}</td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {editing && (
        <ExecutivePermissionsModal
          executive={editing}
          onClose={() => setEditing(null)}
          onSaved={() => { setEditing(null); fetchExecutives() }}
        />
      )}
    </div>
  )
}

export default MultiLogin
