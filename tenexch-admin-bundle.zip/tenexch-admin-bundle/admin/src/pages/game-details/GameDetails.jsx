import { Fragment, useState, useEffect, useCallback, useRef } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import CricketScorecard from '../../components/game-details/CricketScorecard'
import SportsScorecard from '../../components/game-details/SportsScorecard'
import MoreMarketModal from '../../components/game-details/MoreMarketModal'
import { getSportsData, getMatchPrivateData, getMarketList, getMarketAnalysis, getMatchDownlineBets, getSportsGameDetail } from '../../services/api'
import BetLockModal from '../../components/BetLockModal'
import ViewMoreBetsModal from '../../components/ViewMoreBetsModal'
import UserBookModal from '../../components/UserBookModal'
import { buildExposureIndex, lookupExposure } from '../../utils/marketExposure'
import { MarketHeader, CollapseBody } from '../../components/casino/MarketAccordion'
import Collapse from '../../components/Collapse'
import { SPORTS_STREAM_BASE } from '../../config/api'
// import './GameDetails.css'

const ARROW_FRONT = 'https://wver.sprintstaticdata.com/v230/static/front/img/arrow-down.svg'
const ARROW_ADMIN = 'https://wver.sprintstaticdata.com/v230/static/admin/img/arrow-down.svg'

// ─────────────────────────────────────────────
// Helper: parse raw market array from API response
// ─────────────────────────────────────────────
function extractMarketArray(response) {
  if (!response || !response.success) return []
  const d = response.data
  if (Array.isArray(d)) return d
  if (d && Array.isArray(d.data)) return d.data
  if (d && typeof d === 'object' && (d.mid || d.mname)) return [d]
  if (d && typeof d === 'object') {
    const vals = Object.values(d)
    if (vals.length && vals[0] && (vals[0].mid || vals[0].mname)) return vals
    if (vals.length && Array.isArray(vals[0])) return vals[0]
  }
  return []
}

/* ─────────────────────────────────────────────
 * Market rendering — one block per `dtype`
 * ─────────────────────────────────────────────
 * The reference admin picks the block by the market's `dtype`
 * (`1==dtype ? Market1 … 13==dtype ? Market13`) and sorts both markets and
 * their sections by `sno` (reference bundle `admin/layout.html`, page render
 * + Market1..Market13 components — read 2026-09-22, plan
 * docs/plans/2026-09-22-admin-game-details-all-sports.md).
 *
 * We used to route on `gtype` (match/match1 → 3-tier block, "N Number" rows →
 * market-9, EVERYTHING else → one "No/Yes" fancy block). That is why fancy1
 * (dtype 7) showed No/Yes with the lay column first instead of Back/Lay, why
 * oddeven (dtype 8) was not two blue cells, and why khado (dtype 10) lost its
 * "<name> - <lay odds>" label. Our API already sends `dtype` on every market,
 * so we read it.
 *
 * Rules shared by every block, all from the same bundle:
 *   body   data-title = market.status,  `suspendedfull` when market.gscode != 1
 *   row    data-title = section.gstatus, `suspendedtext` when
 *          market.gscode == 1 && section.gscode != 1
 *   cell   `no-val` when odds == 0; odds text "—" when 0; the size span only
 *          when size != 0. Odds are never blanked by suspension — the CSS
 *          overlay does that.
 * Cells come from the odds entries that exist (backs by tno DESC, lays ASC) —
 * never padded to three, so a soccer/tennis dtype-2 market renders its single
 * back + single lay.
 */

// sections/markets in the reference are always `_.orderBy(…, "sno")`
function sortBySno(arr) {
  return [...(arr || [])].sort((a, b) => (Number(a.sno) || 0) - (Number(b.sno) || 0))
}
function oddsBy(section, key, field = 'otype') {
  return (section.odds || []).filter((o) => String(o[field] || '').toUpperCase() === key)
}
function oddsDesc(section, key, field = 'otype') {
  return oddsBy(section, key, field).sort((a, b) => (b.tno || 0) - (a.tno || 0))
}
function oddsAsc(section, key, field = 'otype') {
  return oddsBy(section, key, field).sort((a, b) => (a.tno || 0) - (b.tno || 0))
}
function suspendedRow(market, section) {
  return Number(market.gscode) === 1 && Number(section.gscode) !== 1
}
function suspendedFull(market) {
  return Number(market.gscode) !== 1
}
// reference `v-odds`: 0 → "—", else the raw value
function oddsText(v) {
  return v && Number(v) !== 0 ? v : '—'
}

/* The odds-change flash. Every reference block keeps the PREVIOUS poll's copy
 * of its market (`marketDataOld`) beside the current one and colours a cell
 * whose price moved:
 *
 *   getClass(newOdds, otype, tno, i) {
 *     old = _.first(find(filterBy(oldMarketSections[i].odds, otype, "otype"), tno, "tno"))
 *     prev = _.get(old, "odds", newOdds)
 *     return prev < newOdds ? "bg-success" : prev > newOdds ? "bg-danger" : ""
 *   }
 *
 * Green when the price went up, red when it went down, and it clears itself on
 * the next poll (that poll's "old" is this poll's "new") — which is the flash.
 * `.bg-success` / `.bg-danger` are already in app.css:8881/8905.
 */
function flashClass(oldSection, otype, tno, newOdds) {
  if (!oldSection) return ''
  const prevEntry = (oldSection.odds || []).find(
    (o) => String(o.otype || '').toUpperCase() === otype && Number(o.tno || 0) === Number(tno || 0),
  )
  const prev = prevEntry ? prevEntry.odds : newOdds
  if (prev < newOdds) return ' bg-success'
  if (prev > newOdds) return ' bg-danger'
  return ''
}
// the same runner in the previous poll — by sid, falling back to the
// reference's own rule (same position in the sno-ordered list)
function oldSectionOf(oldMarket, section, i) {
  const list = sortBySno(oldMarket?.section)
  return list.find((s) => String(s.sid) === String(section.sid)) || list[i]
}
/* reference `v-kval` (and `v-kvalpoint*`, minus the account-rate division we
   do not have): < 1000 as is, 1000–99999 → "12.34K", >= 100000 → "1.23L".
   parseFloat drops the trailing zeros, so 100000 → "1L", 500000 → "5L",
   250000 → "2.5L", 50355.27 → "50.36K". Our old `fmtVol` gave "1.2L" for
   123456 and the fancy block's own formatter rounded 2500 up to "3K". */
function kval(v) {
  const n = Number(v)
  if (!Number.isFinite(n)) return ''
  if (n >= 100000) return `${parseFloat((n / 100000).toFixed(2))}L`
  if (n >= 1000) return `${parseFloat((n / 1000).toFixed(2))}K`
  return String(parseFloat(n))
}

// market bet-table cell me exposure — reference: integer + minus (koi bracket/
// decimal nahi), color red/green/gray. (Book Summary sidebar apna bracket
// format `formatExposure`/`exposureColor` se rakhta hai — usko chhua nahi)
function mktExpo(v) {
  const n = Number(v)
  if (!Number.isFinite(n) || n === 0) return '0'
  return String(Math.round(n))
}
function mktExpoColor(v) {
  const n = Number(v)
  if (!Number.isFinite(n) || n === 0) return 'rgb(153, 153, 153)'
  return n < 0 ? 'red' : 'green'
}

/* The "%" badge next to the book on a TWO-runner market (user, 2026-09-22 —
 * "Bookmaker pe ye % kya hai, kis basis pe calculate ho raha hai, hamare bhi
 * add kar"). Reference `v-sportbook` directive (bundle admin/layout.html):
 *
 *   if (booksForThisMid.length == 2)
 *     n = (ownBook / otherRunnerBook).toFixed(2); n = Math.abs(isNaN(n) ? "" : n)
 *     el.innerHTML = book + ' <span class="badge badge-dark book-per">' + n + '%</span>'
 *   else el.innerHTML = book
 *
 * So it is NOT a percentage of anything — it is the ratio of this runner's
 * book to the other runner's, always positive, to 2 decimals, printed with a
 * "%" sign. The user's Bookmaker: England -13 / Sri Lanka 100 → -13/100 =
 * 0.13%, and 100/-13 = 7.69%. Both sides of the same market, so the two
 * badges are reciprocals.
 *
 * Only the LEFT figure (the book, `v-sportbook`) carries it — the right-hand
 * point book (`v-sportpointbook`) never does. Fancy-style markets use
 * `v-fancybook`, which has no badge at all, so dtype 6/7/8/10 stay bare.
 * A market with one book row (only one runner bet on) also gets no badge.
 *
 * `isNaN → 0` is the reference's own guard (0/0). A non-zero book against a
 * 0 book divides to Infinity there too; kept as is rather than invented away.
 */
function bookPercent(own, other) {
  const n = Number((Number(own) / Number(other)).toFixed(2))
  return Math.abs(Number.isNaN(n) ? 0 : n)
}
// book figure + the ratio badge, exactly as `v-sportbook` writes them
function bookFigure(own, other, showBadge) {
  return (
    <>
      {mktExpo(own)}
      {showBadge ? <>{' '}<span className="badge badge-dark book-per">{bookPercent(own, other)}%</span></> : null}
    </>
  )
}
/* true when this market is the 2-runner shape the badge belongs to. Our books
   come from market-analysis (a runner with no bet reads 0), so "both runners
   read 0" is the no-bets case the reference shows without a badge. */
function hasBookBadge(exposures) {
  return exposures.length === 2 && exposures.some((e) => Number(e) !== 0)
}

/* The RIGHT-hand figure — reference `v-sportpointbook` (the point book,
 * `uamt`), which never carries the badge:
 *   >0 → green, <0 → red, ==0 → the element keeps its "0" text, gets `d-none`
 *   and no colour at all.
 * Both of the user's Bookmaker pastes prove it: with no bets
 * `<p class="mb-0 float-right d-none">0</p>`, with bets
 * `<p class="mb-0 float-right" style="color: red;">-13</p>`. We have no
 * separate point book, so the same exposure is shown — which is what the
 * reference account shows too (its book and point book are equal here: left
 * -13 / right -13, left 100 / right 100).
 */
function pointFigure(Tag, cls, v) {
  const n = Number(v) || 0
  const cx = (extra) => [cls, extra].filter(Boolean).join(' ') || undefined
  if (n === 0) return <Tag className={cx('d-none')}>0</Tag>
  return <Tag className={cx()} style={{ color: n < 0 ? 'red' : 'green' }}>{mktExpo(n)}</Tag>
}

/* ─────────────────────────────────────────────
 * RacingMarket — dtype 12  (market-12)
 * ─────────────────────────────────────────────
 * Horse / greyhound racing, and the one tiered block whose row is genuinely
 * different, so the reference gives it its own component rather than a flag on
 * Market2. Its render fn (admin/layout.html) differs from every other tiered
 * market in six ways, all of them reproduced here:
 *
 *   1. the runner line is `<span><span>{cno}</span> <span>({sdraw})</span></span>`
 *      then the name — the saddlecloth number and the stall draw. Without it
 *      the operator cannot tell which horse a row is.
 *   2. both the mobile and the desktop name sit in a `<p>`, not a `<span>`.
 *   3. there is no point book — only `v-sportbook`.
 *   4. the row dims on the SECTION's own gscode (`1 != s.gscode`), not on the
 *      market/section pair every other block uses.
 *   5. a scratched runner adds `removed` and swaps the tooltip for
 *      `REMOVED  -  {adfa}%,  {rdt} (IST)` — the deduction and when it was
 *      taken out (two spaces around the dash, exactly as the reference builds
 *      it). Capture: `data-title="REMOVED  -  5.87%,  9/22/2026 9:43:03 PM (IST)"`.
 *   6. a size prints whenever it is non-zero, even against 0 odds.
 *
 * The pair of rows is returned as siblings — the reference's `_l` returns an
 * array, so there is no wrapper element around them.
 */
export function RacingMarket({ market, oldMarket, marketIndex, exposureIndex, onBetLock, onUserBook, isMobile }) {
  const mname = market.mname || ''
  const sections = sortBySno(market.section)
  const marketKeys = [mname, market.gtype]
  const [open, setOpen] = useState(true)
  const gtype = market.gtype
  const exposures = sections.map((s) => lookupExposure(exposureIndex, marketKeys, s.nat))
  const showBadge = hasBookBadge(exposures)
  const maxVal = market.iplay ? market.maxb : market.umaxbof

  const limits = () => {
    if (gtype === 'match1') {
      return <> Min:<span>{kval(market.min)}</span>{'  '}Max:<span>{kval(market.max)}</span></>
    }
    if (gtype === 'match') return <span title={`Max : ${kval(maxVal)}`}>{kval(maxVal)}</span>
    return <>Max:<span>{kval(maxVal)}</span></>
  }

  // `<span>{cno}</span> <span>({sdraw})</span>` then a newline and the name —
  // the reference's own text node, kept whitespace-for-whitespace.
  const runnerName = (s) => (
    <p>
      <span><span>{s.cno}</span>{' '}<span>({s.sdraw})</span></span>
      {`\n                            ${s.nat}`}
    </p>
  )

  return (
    <div className="market-12">
      <div className="bet-table">
        <MarketHeader
          title={mname}
          marketId={`market${marketIndex}`}
          arrow={ARROW_FRONT}
          open={open}
          onToggle={() => setOpen((v) => !v)}
          right={(
            <>
              <a href="javascript:void(0)" className="btn btn-back" onClick={() => onBetLock(market.mid, market.mname)}>Bet Lock</a>
              {(gtype === 'match' || gtype === 'match1') && (
                <>{' '}<a href="javascript:void(0)" className="btn btn-back" onClick={() => onUserBook(mname)}>User Book</a></>
              )}
            </>
          )}
        />
        <CollapseBody
          id={`market${marketIndex}`}
          dataTitle={market.status}
          open={open}
          className={suspendedFull(market) ? 'suspendedfull ' : ''}
        >
          {isMobile ? (
            <div className="text-right d-inline-block w-100 pr-2">
              <span className="max-bet">{limits()}</span>
            </div>
          ) : (
            <div className="bet-table-row bet-table-row-top">
              <div className="text-right nation-name">
                <span className="max-bet">{limits()}</span>
              </div>
              <div className="back bl-title d-none-mobile">Back</div>
              <div className="lay bl-title d-none-mobile">Lay</div>
            </div>
          )}

          {sections.map((s, i) => {
            const backs = oddsDesc(s, 'BACK')
            const lays = oddsAsc(s, 'LAY')
            const oldSec = oldSectionOf(oldMarket, s, i)
            const exposure = exposures[i]
            const other = exposures[1 - i]
            const removed = String(s.gstatus || '').toLowerCase() === 'removed'
            const rowCls = `bet-table-row${Number(s.gscode) !== 1 ? ' suspendedtext' : ''}${removed ? ' removed' : ''}`
            const dataTitle = removed ? `${s.gstatus}  -  ${s.adfa}%,  ${s.rdt} (IST)` : s.gstatus
            return (
              <Fragment key={s.sid ?? i}>
                <div className="bet-table-mobile-row d-none-desktop">
                  <div className="bet-table-mobile-team-name">
                    {runnerName(s)}
                    {' '}
                    <span style={{ color: mktExpoColor(exposure) }}>{bookFigure(exposure, other, showBadge)}</span>
                  </div>
                </div>
                <div data-title={dataTitle} className={rowCls}>
                  <div className="nation-name d-none-mobile">
                    {runnerName(s)}
                    {' '}
                    <p className="mb-0 float-left" style={{ color: mktExpoColor(exposure) }}>{bookFigure(exposure, other, showBadge)}</p>
                  </div>
                  {backs.map((o, ti) => (
                    <div key={`b${ti}`} className={`bl-box back ${o.tno === 1 ? 'back1' : o.tno === 2 ? 'back2' : 'back'}${!o.odds ? ' no-val' : ''}${flashClass(oldSec, 'BACK', o.tno, o.odds)}`}>
                      <span className="d-block odds">{oddsText(o.odds)}</span>
                      {o.size ? <span className="d-block">{kval(o.size)}</span> : null}
                    </div>
                  ))}
                  {lays.map((o, ti) => (
                    <div key={`l${ti}`} className={`bl-box lay ${o.tno === 1 ? 'lay1' : o.tno === 2 ? 'lay2' : 'lay'}${!o.odds ? ' no-val' : ''}${flashClass(oldSec, 'LAY', o.tno, o.odds)}`}>
                      <span className="d-block odds">{oddsText(o.odds)}</span>
                      {o.size ? <span className="d-block">{kval(o.size)}</span> : null}
                    </div>
                  ))}
                </div>
              </Fragment>
            )
          })}
        </CollapseBody>
      </div>
      {market.rem && <div className="remark">{market.rem}</div>}
    </div>
  )
}

/* ─────────────────────────────────────────────
 * TieredMarket — dtype 2, 3, 4, 5, 11, 13
 * ─────────────────────────────────────────────
 * Same body everywhere (Back / Lay columns, up to three tiers by `tno`);
 * the blocks differ only in the wrapper class, the arrow, whether the header
 * carries buttons, which value the header's max-bet line shows, and whether
 * a zero-odds cell may still print its size.
 *
 * Deviation: the reference's dtype-3 header puts `data-toggle`/`data-target`
 * on `.bet-table-header` itself (every other block puts them on the inner
 * `.nation-name`), and its BACK cell prints the odds as bare text without the
 * `span.d-block.odds` wrapper the LAY cell has. We keep the shared
 * MarketHeader (toggle on `.nation-name`) for all of them; the bare-text
 * quirk is honoured through `oddsWrapped`.
 */
function TieredMarket({
  market, oldMarket, marketIndex, exposureIndex, onBetLock, onUserBook, isMobile,
  wrapperClass, arrow, showButtons = true, rowTop = false, hasMobileRow = true,
  hasIsMobileHeaderBranch = false, maxSource = 'iplay', sizeCondition = 'sizeOnly',
  remarkTag = 'div', oddsWrapped = true,
}) {
  const mname = market.mname || ''
  const sections = sortBySno(market.section)
  const marketKeys = [mname, market.gtype]
  const [open, setOpen] = useState(true)
  const gtype = market.gtype
  // every runner's book up front — the ratio badge needs the other runner's
  const exposures = sections.map((s) => lookupExposure(exposureIndex, marketKeys, s.nat))
  const showBadge = hasBookBadge(exposures)
  // dtype 5 always shows `maxb`; every other tiered block shows
  // `iplay ? maxb : umaxbof`
  const maxVal = maxSource === 'maxb' ? market.maxb : (market.iplay ? market.maxb : market.umaxbof)
  const RemarkTag = remarkTag === 'small' ? 'small' : 'div'

  // header max-bet line: match1 → Min/Max from the market, match → the value
  // alone (the reference hangs a "Max : …" tooltip on it; on mobile dtype 4
  // shows nothing), anything else → "Max:" + value
  const limits = (mobileBranch) => {
    if (gtype === 'match1') {
      return <> Min:<span>{kval(market.min)}</span>{'  '}Max:<span>{kval(market.max)}</span></>
    }
    if (gtype === 'match') {
      if (mobileBranch) return null
      return <span title={`Max : ${kval(maxVal)}`}>{kval(maxVal)}</span>
    }
    return <>Max:<span>{kval(maxVal)}</span></>
  }

  const sizeSpan = (o) => {
    const show = sizeCondition === 'sizeAndOdds' ? (o.size && o.odds) : o.size
    return show ? <span className="d-block">{kval(o.size)}</span> : null
  }

  return (
    <div className={wrapperClass}>
      <div className="bet-table">
        <MarketHeader
          title={mname}
          marketId={`market${marketIndex}`}
          arrow={arrow}
          open={open}
          onToggle={() => setOpen((v) => !v)}
          right={showButtons ? (
            <>
              <a href="javascript:void(0)" className="btn btn-back" onClick={() => onBetLock(market.mid, market.mname)}>Bet Lock</a>
              {(gtype === 'match' || gtype === 'match1') && (
                <>{' '}<a href="javascript:void(0)" className="btn btn-back" onClick={() => onUserBook(mname)}>User Book</a></>
              )}
            </>
          ) : null}
        />
        <CollapseBody
          id={`market${marketIndex}`}
          dataTitle={market.status}
          open={open}
          className={suspendedFull(market) ? 'suspendedfull ' : ''}
        >
          {/* dtype 4 is the only block whose header structure changes with the
              viewport (reference: `$store.getters.isMobile`) */}
          {hasIsMobileHeaderBranch && isMobile ? (
            <div className="text-right d-inline-block w-100 pr-2">
              <span className="max-bet">{limits(true)}</span>
            </div>
          ) : (
            <div className={`bet-table-row${rowTop ? ' bet-table-row-top' : ''}`}>
              <div className="text-right nation-name">
                <span className="max-bet">{limits(false)}</span>
              </div>
              <div className="back bl-title d-none-mobile">Back</div>
              <div className="lay bl-title d-none-mobile">Lay</div>
            </div>
          )}

          {sections.map((s, i) => {
            const susRow = suspendedRow(market, s)
            const backs = oddsDesc(s, 'BACK')
            const lays = oddsAsc(s, 'LAY')
            const oldSec = oldSectionOf(oldMarket, s, i)
            const exposure = exposures[i]
            const other = exposures[1 - i]
            return (
              /* The reference's `_l` returns the two rows as an ARRAY — they
                 are siblings inside `.bet-table-body`, with nothing around
                 them. We used to wrap each pair in a `<div>`, one extra node
                 per runner that the reference has never had. */
              <Fragment key={s.sid ?? i}>
                {hasMobileRow && (
                  <div className="bet-table-mobile-row d-none-desktop">
                    <div className="bet-table-mobile-team-name">
                      <span>{s.nat}</span>
                      {' '}
                      <span style={{ color: mktExpoColor(exposure) }}>{bookFigure(exposure, other, showBadge)}</span>
                      {' '}
                      {pointFigure('span', '', exposure)}
                    </div>
                  </div>
                )}
                <div data-title={s.gstatus} className={`bet-table-row${susRow ? ' suspendedtext' : ''}`}>
                  <div className="nation-name d-none-mobile">
                    <p>{s.nat}</p>
                    <p className="mb-0 float-left" style={{ color: mktExpoColor(exposure) }}>{bookFigure(exposure, other, showBadge)}</p>
                    {pointFigure('p', 'mb-0 float-right', exposure)}
                  </div>
                  {/* class order is the reference's: the static `bl-box back`
                      first, then the tier (tno 0 really does repeat `back`),
                      then no-val, then the change colour */}
                  {backs.map((o, ti) => (
                    <div key={`b${ti}`} className={`bl-box back ${o.tno === 1 ? 'back1' : o.tno === 2 ? 'back2' : 'back'}${!o.odds ? ' no-val' : ''}${flashClass(oldSec, 'BACK', o.tno, o.odds)}`}>
                      {oddsWrapped ? <span className="d-block odds">{oddsText(o.odds)}</span> : oddsText(o.odds)}
                      {sizeSpan(o)}
                    </div>
                  ))}
                  {lays.map((o, ti) => (
                    <div key={`l${ti}`} className={`bl-box lay ${o.tno === 1 ? 'lay1' : o.tno === 2 ? 'lay2' : 'lay'}${!o.odds ? ' no-val' : ''}${flashClass(oldSec, 'LAY', o.tno, o.odds)}`}>
                      <span className="d-block odds">{oddsText(o.odds)}</span>
                      {sizeSpan(o)}
                    </div>
                  ))}
                </div>
              </Fragment>
            )
          })}
        </CollapseBody>
      </div>
      {market.rem && <RemarkTag className="remark">{market.rem}</RemarkTag>}
    </div>
  )
}

/* ─────────────────────────────────────────────
 * Market1Block — dtype 1
 * ─────────────────────────────────────────────
 * Back-only, laid out as `.market-1-item` cards inside ONE `.bet-table-row`;
 * the max-bet value sits in the header's `.float-right` next to the buttons,
 * and suspension is a class on the CELL (there is no per-runner row to carry
 * `suspendedtext`).
 */
function Market1Block({ market, oldMarket, marketIndex, exposureIndex, onBetLock, onUserBook }) {
  const mname = market.mname || ''
  const sections = sortBySno(market.section)
  const marketKeys = [mname, market.gtype]
  const [open, setOpen] = useState(true)
  const gtype = market.gtype
  const maxVal = market.iplay ? market.maxb : market.umaxbof
  const exposures = sections.map((s) => lookupExposure(exposureIndex, marketKeys, s.nat))
  const showBadge = hasBookBadge(exposures)

  return (
    <div className="market-1">
      <div className="bet-table">
        <div className="bet-table-header">
          <span
            title={mname}
            data-toggle="collapse"
            data-target={`#market${marketIndex}`}
            onClick={() => setOpen((v) => !v)}
          >
            <a href="#" title=""><img src={ARROW_ADMIN} className="mr-1" alt="" /></a>
            {'\n                    ' + mname + '\n                '}
          </span>
          {' '}
          <div className="float-right">
            {gtype === 'match'
              ? <span className="max-bet"><span title={`Max : ${kval(maxVal)}`}>{kval(maxVal)}</span></span>
              : <span className="max-bet">Max:<span>{kval(maxVal)}</span></span>}
            {' '}
            <a href="javascript:void(0)" className="btn btn-back" onClick={() => onBetLock(market.mid, market.mname)}>Bet Lock</a>
            {(gtype === 'match' || gtype === 'match1') && (
              <>{' '}<a href="javascript:void(0)" className="btn btn-back" onClick={() => onUserBook(mname)}>User Book</a></>
            )}
          </div>
        </div>
        <CollapseBody
          id={`market${marketIndex}`}
          dataTitle={market.status}
          open={open}
          className={suspendedFull(market) ? 'suspendedfull ' : ''}
        >
          <div className="bet-table-row">
            {sections.map((s, i) => {
              const susCell = suspendedRow(market, s)
              const oldSec = oldSectionOf(oldMarket, s, i)
              const exposure = exposures[i]
              return (
                <div key={s.sid ?? i} className="market-1-item">
                  <div>
                    <span>{s.nat}</span>
                    {' '}
                    <span className="ml-2" style={{ color: mktExpoColor(exposure) }}>{bookFigure(exposure, exposures[1 - i], showBadge)}</span>
                    {pointFigure('span', 'ml-2', exposure)}
                  </div>
                  {oddsDesc(s, 'BACK').map((o, ti) => (
                    <div
                      key={ti}
                      className={`bl-box back ${o.tno === 1 ? 'back1' : o.tno === 2 ? 'back2' : 'back'}${!o.odds ? ' no-val' : ''}${susCell ? ' suspended' : ''}${flashClass(oldSec, 'BACK', o.tno, o.odds)}`}
                    >
                      <span className="d-block odds">{oddsText(o.odds)}</span>
                    </div>
                  ))}
                </div>
              )
            })}
          </div>
        </CollapseBody>
      </div>
      {market.rem && <div className="remark">{market.rem}</div>}
    </div>
  )
}

/* ─────────────────────────────────────────────
 * FancyPairMarket — dtype 6, 7, 8  (market-6)
 * ─────────────────────────────────────────────
 * Two columns per runner, taken by `oname` (BACK1 / LAY1), plus the runner's
 * own Min/Max. The three blocks differ ONLY in the column order, the column
 * classes and the titles:
 *   6 fancy / meter : No  (LAY1, lay)   | Yes  (BACK1, back)   admin arrow
 *   7 fancy1        : Back (BACK1, back)| Lay  (LAY1, lay)     front arrow
 *   8 oddeven       : Odd  (BACK1, back)| Even (LAY1, back)    front arrow
 * (dtype 8's second cell really is a `back` box in the reference — both are
 * blue.)
 */
function FancyPairMarket({ market, oldMarket, marketIndex, exposureIndex, onBetLock, arrow, titles, columns }) {
  const mname = market.mname || ''
  const sections = sortBySno(market.section)
  // fancy bets store gtype ("Normal", "oddeven") as game_type, not mname
  const marketKeys = [market.gtype, mname]
  const [open, setOpen] = useState(true)

  return (
    <div className="market-6">
      <div className="bet-table">
        <MarketHeader
          title={mname}
          marketId={`market${marketIndex}`}
          arrow={arrow}
          open={open}
          onToggle={() => setOpen((v) => !v)}
          right={<a href="javascript:void(0)" className="btn btn-back" onClick={() => onBetLock(market.mid, market.mname)}>Bet Lock</a>}
        />
        <CollapseBody
          id={`market${marketIndex}`}
          dataTitle={market.status}
          open={open}
          className={suspendedFull(market) ? 'suspendedfull ' : ''}
        >
          <div className="bet-table-row">
            <div className="text-right nation-name"></div>
            <div className={`${columns[0].cls} bl-title d-none-mobile`}>{titles[0]}</div>
            <div className={`${columns[1].cls} bl-title d-none-mobile`}>{titles[1]}</div>
          </div>

          {sections.map((s, i) => {
            const susRow = suspendedRow(market, s)
            const oldSec = oldSectionOf(oldMarket, s, i)
            const exposure = lookupExposure(exposureIndex, marketKeys, s.nat)
            return (
              <div key={s.sid ?? i} className="fancy-tripple">
                <div className="bet-table-mobile-row d-none-desktop">
                  <div className="bet-table-mobile-team-name">
                    <span>{s.nat}</span>
                    {' '}
                    <span style={{ color: mktExpoColor(exposure) }}>{mktExpo(exposure)}</span>
                  </div>
                </div>
                <div data-title={s.gstatus} className={`bet-table-row${susRow ? ' suspendedtext' : ''}`}>
                  <div className="nation-name d-none-mobile">
                    <p>{s.nat}</p>
                    <p className="mb-0" style={{ color: mktExpoColor(exposure) }}>{mktExpo(exposure)}</p>
                  </div>
                  {columns.map((col, ci) => {
                    const o = oddsDesc(s, col.oname, 'oname')[0] || {}
                    // the reference compares by OTYPE even in these blocks
                    const otype = col.oname.startsWith('BACK') ? 'BACK' : 'LAY'
                    return (
                      <div key={ci} className={`bl-box ${col.cls}${!o.odds ? ' no-val' : ''}${flashClass(oldSec, otype, o.tno, o.odds)}`}>
                        <span className="d-block odds">{oddsText(o.odds)}</span>
                        {o.size ? <span className="d-block">{kval(o.size)}</span> : null}
                      </div>
                    )
                  })}
                  <div className="fancy-min-max">
                    Min:<span>{kval(s.min)}</span> Max:<span>{kval(s.max)}</span>
                  </div>
                </div>
                {s.rem && <div className="sec-remark">{s.rem}</div>}
              </div>
            )
          })}
        </CollapseBody>
      </div>
    </div>
  )
}

/* ─────────────────────────────────────────────
 * KhadoMarket — dtype 10 (market-10)
 * ─────────────────────────────────────────────
 * One Back column. The runner's name carries the LAY odds — "10 over Khado
 * run ENG adv - 11" — and suspension is a class on the cell, not the row
 * (the row has no data-title at all in the reference).
 */
function KhadoMarket({ market, oldMarket, marketIndex, exposureIndex, onBetLock }) {
  const mname = market.mname || ''
  const sections = sortBySno(market.section)
  const marketKeys = [market.gtype, mname]
  const [open, setOpen] = useState(true)

  return (
    <div className="market-10">
      <div className="bet-table">
        <MarketHeader
          title={mname}
          marketId={`market${marketIndex}`}
          arrow={ARROW_FRONT}
          open={open}
          onToggle={() => setOpen((v) => !v)}
          right={<a href="javascript:void(0)" className="btn btn-back" onClick={() => onBetLock(market.mid, market.mname)}>Bet Lock</a>}
        />
        <CollapseBody
          id={`market${marketIndex}`}
          dataTitle={market.status}
          open={open}
          className={suspendedFull(market) ? 'suspendedfull ' : ''}
        >
          <div className="bet-table-row">
            <div className="text-right nation-name"></div>
            <div className="back bl-title d-none-mobile">Back</div>
          </div>

          {sections.map((s, i) => {
            const susCell = suspendedRow(market, s)
            const oldSec = oldSectionOf(oldMarket, s, i)
            const lay = oddsBy(s, 'LAY')[0]
            const label = lay ? `${s.nat} - ${lay.odds}` : s.nat
            const exposure = lookupExposure(exposureIndex, marketKeys, s.nat)
            return (
              <div key={s.sid ?? i}>
                <div className="bet-table-mobile-row d-none-desktop">
                  <div className="bet-table-mobile-team-name">
                    <span>{label}</span>
                    {' '}
                    <p className="mb-0" style={{ color: mktExpoColor(exposure) }}>{mktExpo(exposure)}</p>
                  </div>
                </div>
                <div className="bet-table-row">
                  <div className="nation-name d-none-mobile">
                    <p><span>{label}</span></p>
                    <p className="mb-0" style={{ color: mktExpoColor(exposure) }}>{mktExpo(exposure)}</p>
                  </div>
                  {/* khado cells carry no tier class in the reference */}
                  {oddsDesc(s, 'BACK').map((o, ti) => (
                    <div
                      key={ti}
                      className={`bl-box back${!o.odds ? ' no-val' : ''}${susCell ? ' suspended' : ''}${flashClass(oldSec, 'BACK', o.tno, o.odds)}`}
                    >
                      <span className="d-block odds">{oddsText(o.odds)}</span>
                      {o.size ? <span className="d-block">{kval(o.size)}</span> : null}
                    </div>
                  ))}
                  <div className="fancy-min-max">
                    Min:<span>{kval(s.min)}</span> Max:<span>{kval(s.max)}</span>
                  </div>
                </div>
                {s.rem && <div className="sec-remark">{s.rem}</div>}
              </div>
            )
          })}
        </CollapseBody>
      </div>
    </div>
  )
}

/* ─────────────────────────────────────────────
 * NumberMarket — dtype 9 (market-9)
 * ─────────────────────────────────────────────
 * Single Back column; the header's Min/Max comes from the FIRST section (not
 * from the market), and the rows carry no suspension class in the reference.
 */
function NumberMarket({ market, oldMarket, marketIndex, exposureIndex, onBetLock }) {
  const mname = market.mname || ''
  const sections = sortBySno(market.section)
  const marketKeys = [market.gtype, mname]
  const [open, setOpen] = useState(true)
  const first = sections[0]
  const exposures = sections.map((s) => lookupExposure(exposureIndex, marketKeys, s.nat))
  const showBadge = hasBookBadge(exposures)

  return (
    <div className="market-9">
      <div className="bet-table">
        <MarketHeader
          title={mname}
          marketId={`market${marketIndex}`}
          arrow={ARROW_FRONT}
          open={open}
          onToggle={() => setOpen((v) => !v)}
          right={<a href="javascript:void(0)" className="btn btn-back" onClick={() => onBetLock(market.mid, market.mname)}>Bet Lock</a>}
        />
        <CollapseBody
          id={`market${marketIndex}`}
          dataTitle={market.status}
          open={open}
          className={suspendedFull(market) ? 'suspendedfull ' : ''}
        >
          <div className="bet-table-row">
            <div className="text-right nation-name">
              {first && (
                <span className="max-bet"> Min:<span>{kval(first.min)}</span>{'  '}Max:<span>{kval(first.max)}</span></span>
              )}
            </div>
            <div className="back bl-title d-none-mobile">Back</div>
          </div>
          {sections.map((s, i) => {
            const exposure = exposures[i]
            const oldSec = oldSectionOf(oldMarket, s, i)
            return (
              <div key={s.sid ?? i}>
                <div className="bet-table-mobile-row d-none-desktop">
                  <div className="bet-table-mobile-team-name">
                    {s.nat}
                    {' '}
                    <span style={{ color: mktExpoColor(exposure) }}>{bookFigure(exposure, exposures[1 - i], showBadge)}</span>
                    {' '}
                    {pointFigure('span', '', exposure)}
                  </div>
                </div>
                <div className="bet-table-row">
                  <div className="nation-name d-none-mobile">
                    <p>{s.nat}</p>
                    <p className="mb-0 float-left" style={{ color: mktExpoColor(exposure) }}>{bookFigure(exposure, exposures[1 - i], showBadge)}</p>
                    {pointFigure('p', 'mb-0 float-right', exposure)}
                  </div>
                  {oddsDesc(s, 'BACK').map((o, ti) => (
                    <div key={ti} className={`bl-box back${!o.odds ? ' no-val' : ''}${flashClass(oldSec, 'BACK', o.tno, o.odds)}`}>
                      <span className="d-block odds">{oddsText(o.odds)}</span>
                      {o.size ? <span className="d-block">{kval(o.size)}</span> : null}
                    </div>
                  ))}
                </div>
              </div>
            )
          })}
        </CollapseBody>
      </div>
      {market.rem && <div className="remark">{market.rem}</div>}
    </div>
  )
}

// dtype 6 / 7 / 8 column setups (see FancyPairMarket)
const PAIR_NO_YES = { arrow: ARROW_ADMIN, titles: ['No', 'Yes'], columns: [{ oname: 'LAY1', cls: 'lay' }, { oname: 'BACK1', cls: 'back' }] }
const PAIR_BACK_LAY = { arrow: ARROW_FRONT, titles: ['Back', 'Lay'], columns: [{ oname: 'BACK1', cls: 'back' }, { oname: 'LAY1', cls: 'lay' }] }
const PAIR_ODD_EVEN = { arrow: ARROW_FRONT, titles: ['Odd', 'Even'], columns: [{ oname: 'BACK1', cls: 'back' }, { oname: 'LAY1', cls: 'back' }] }

// per-dtype TieredMarket setups
const TIER_2 = { wrapperClass: 'market-2', arrow: ARROW_ADMIN, remarkTag: 'div' }
const TIER_3 = { wrapperClass: 'market-3', arrow: ARROW_ADMIN, rowTop: true, oddsWrapped: false, remarkTag: 'div' }
const TIER_4 = { wrapperClass: 'market-4', arrow: ARROW_FRONT, rowTop: true, hasIsMobileHeaderBranch: true, remarkTag: 'small' }
const TIER_5 = { wrapperClass: 'market-5', arrow: ARROW_ADMIN, maxSource: 'maxb', remarkTag: 'div' }
const TIER_11 = { wrapperClass: 'market-11', arrow: ARROW_ADMIN, hasMobileRow: false, remarkTag: 'div' }
const TIER_13 = { wrapperClass: 'market-4', arrow: ARROW_FRONT, rowTop: true, showButtons: false, sizeCondition: 'sizeAndOdds', remarkTag: 'small' }

// ─────────────────────────────────────────────
// Utility
// ─────────────────────────────────────────────

/* Reference: `moment.tz(stime, "MM/DD/YYYY hh:mm:ss A", "Asia/Calcutta")
   .tz(moment.tz.guess()).format("DD/MM/YYYY HH:mm:ss")` — the feed's `stime`
   ("9/22/2026 5:00:00 PM") is IST, and the page shows it in the viewer's zone
   as 22/09/2026 17:00:00. `admin/` has no moment, so the IST instant is built
   by hand (IST = UTC+5:30, no DST) and read back through the Date's local
   getters. Anything that is not that shape falls back to the raw string. */
function formatMatchTime(raw) {
  if (!raw) return ''
  const m = /^(\d{1,2})\/(\d{1,2})\/(\d{4})\s+(\d{1,2}):(\d{2}):(\d{2})\s*(AM|PM)$/i.exec(String(raw).trim())
  if (!m) {
    const d = new Date(raw)
    return isNaN(d) ? String(raw) : d.toLocaleString()
  }
  let hour = Number(m[4]) % 12
  if (/pm/i.test(m[7])) hour += 12
  const ist = Date.UTC(Number(m[3]), Number(m[1]) - 1, Number(m[2]), hour, Number(m[5]), Number(m[6]))
  const d = new Date(ist - 5.5 * 3600 * 1000)
  const p = (n) => String(n).padStart(2, '0')
  return `${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`
}

// ─────────────────────────────────────────────
// Main Page
// ─────────────────────────────────────────────
function GameDetails() {
  const { sportId, eventId } = useParams()
  const navigate = useNavigate()

  const [matchInfo, setMatchInfo] = useState({ name: '', series: '', time: '' })
  const [marketsData, setMarketsData] = useState([])
  const [exposureIndex, setExposureIndex] = useState(null)
  const [matchedBets, setMatchedBets] = useState([])
  const [unmatchedBets, setUnmatchedBets] = useState([])
  const [activeTab, setActiveTab] = useState('matched')
  /* My Bets tab switch.
   *
   * Measured off the user's 60fps recording (2026-09-23), luminance of the
   * table strip per frame — the click lands at t=1.017:
   *
   *   t≤1.000   Y=246.31   old pane, fully painted
   *   t=1.017   Y=253.84   label ALREADY on the new tab, body blank
   *   …1.067    Y=253.84   still blank (4 frames — the new pane has not
   *                        painted yet; opacity is exactly 0, not ramping)
   *   t=1.083   Y=250.66   first painted frame, and it is already at opacity
   *                        0.44 = 66ms/150ms — the transition has been running
   *                        since the click
   *   t=1.167   Y≈246.4    full
   *
   * So the reference does ONE thing: swap the pane and the active label on the
   * click, and fade the new pane in over `.fade`'s 150ms (app.css:5619). There
   * is no fade-out — the old content is gone in a single frame — and the blank
   * stretch is just paint latency, not a scripted gap.
   *
   * Ours ran a 150ms fade-OUT first and only then swapped, so the whole switch
   * took 300ms and, worse, the tab highlight moved 150ms after the tap. Now the
   * swap is immediate and only the enter runs; `tabShown` goes false in the
   * same commit and back on two frames later, so `.fade` has a painted
   * opacity-0 state to transition from. */
  const [tabShown, setTabShown] = useState(true)
  const tabRaf = useRef(null)
  useEffect(() => () => cancelAnimationFrame(tabRaf.current), [])
  const switchTab = (tab) => {
    if (tab === activeTab) return
    cancelAnimationFrame(tabRaf.current)
    setActiveTab(tab)
    setTabShown(false)
    tabRaf.current = requestAnimationFrame(() => {
      tabRaf.current = requestAnimationFrame(() => setTabShown(true))
    })
  }
  const [liveOpen, setLiveOpen] = useState(false)
  // has the operator touched the Live Match header yet — see the card below
  const [liveTouched, setLiveTouched] = useState(false)
  const [betLockModal, setBetLockModal] = useState({ show: false, marketId: null, marketName: null })
  const [userBookModal, setUserBookModal] = useState({ show: false, gameType: null, marketName: null })
  const [showViewMore, setShowViewMore] = useState(false)
  // match meta (`gtv`, `scard`, `tv`, ename/cname/stime) — the only source of
  // `gtv`, which gates the score-animation banner
  const [meta, setMeta] = useState(null)
  const [moreOpen, setMoreOpen] = useState(false)
  const [moreLoading, setMoreLoading] = useState(false)
  const [moreMarkets, setMoreMarkets] = useState([])
  // which market the page is showing on a non-cricket sport (reference: `mid`)
  const [selectedMid, setSelectedMid] = useState(null)
  useEffect(() => { setSelectedMid(null) }, [eventId])
  // right-sidebar scroll-sticky sirf desktop pe (casino games jaisa) — mobile pe
  // sticky class fixed kar deti hai jo content ke upar overlap karti hai
  const [isMobile, setIsMobile] = useState(() => typeof window !== 'undefined' && window.innerWidth < 768)
  useEffect(() => {
    const onResize = () => setIsMobile(window.innerWidth < 768)
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])
  // const [isTvExpanded, setIsTvExpanded] = useState(false) // TODO: add Live TV section when needed

  const intervalRef = useRef(null)
  // the previous poll's markets — the odds-change flash compares against it
  const prevMarketsRef = useRef([])

  /* A match whose markets are gone must stop being polled. The reference
     counts and gives up:

       200 == status ? (data.length ? hasNoGameData = 0
                                    : (hasNoGameData++, 5 == hasNoGameData && stop()))
                     : (hasNoGameData++, 5 == hasNoGameData && stop())
       stop = () => { callUserBookApi = false; callGameDataApi = false;
                      store.gameId = null; router.push({name: 'home'}) }

     Ours polled for ever: the user's network tab shows 244 requests / 123 kB
     on a finished table-tennis match (gmid 554885655 — its markets 404 and it
     has already dropped out of the sid-8 list), and the four calls kept going
     round. Now the same five-strike rule stops every poll on the page. We stay
     on the (empty) page instead of bouncing to home — that is the state the
     user asked for, and pulling an operator off a page they are reading is
     worse than leaving it quiet. */
  const DEAD_LIMIT = 5
  const deadRef = useRef(0)
  // true once the markets call has answered with nothing — the page then
  // renders the reference's bare shell (see `dead` below)
  const [dead, setDead] = useState(false)
  /* The feed ANSWERED and there is simply nothing open on this event
     (Politics: `{"data":null,"msg":"No Record Found.","status":300}`). The page
     is real — header, More Market and the sidebar all render from the meta, so
     this is NOT `dead` and the shell never goes bare — but the operator is
     still sent home after the same 3 s (user, 2026-09-23: "is case me bhi
     bahar, is page pe redirect kar de"). */
  const [noMarkets, setNoMarkets] = useState(false)
  /* Has this match EVER delivered markets? The header is bare until it has,
     and never goes bare again afterwards.

     This is what killed the flicker (user's recording, 2026-09-22): the class
     came from the route, so a dead match painted `game-header sport8` (red)
     for the first ~400 ms and then flipped to `sportundefined` (dark) when the
     first poll failed. The reference never flips: its class is
     `sport${gameDetail.etid}` and `gameDetail` starts as `[]`, so the header
     is `sportundefined` from the first paint and only ever fills IN. Ours now
     keys off the same thing — data, not the URL. */
  const hadDataRef = useRef(false)
  const timersRef = useRef([])
  const stopPolls = useCallback(() => {
    timersRef.current.forEach((id) => clearInterval(id))
    timersRef.current = []
  }, [])

  /* …and then leave, the way the reference does
     (`store.gameId = null; router.push({name: 'home'})` on its fifth strike).
     It gives up after 5 × its poll interval; the user asked for 3 seconds
     (2026-09-22), so the bare page shows for that long and then the operator
     lands on /admin/home. A market arriving in the meantime cancels it. */
  const DEAD_REDIRECT_MS = 3000
  useEffect(() => {
    if (!dead && !noMarkets) return undefined
    const t = setTimeout(() => {
      stopPolls()
      navigate('/admin/home')
    }, DEAD_REDIRECT_MS)
    return () => clearTimeout(t)
  }, [dead, noMarkets, navigate, stopPolls])

  // Fetch match header info once on mount
  const fetchMatchInfo = useCallback(async () => {
    if (!sportId || !eventId) return
    try {
      const response = await getSportsData(sportId)
      const actual = response?.data?.data || response?.data || response || {}
      const allEvents = [...(actual.t1 || []), ...(actual.t2 || [])]
      const match = allEvents.find((e) => String(e.gmid) === String(eventId))
      if (match) {
        setMatchInfo({
          name: match.ename || match.name || 'Match Details',
          series: match.cname || '',
          time: match.stime || '',
        })
      } else {
        setMatchInfo({ name: 'Match Details', series: '', time: '' })
      }
    } catch {
      setMatchInfo({ name: 'Match Details', series: '', time: '' })
    }
  }, [sportId, eventId])

  // Match meta, polled like the reference does (it reads `gameDetail` the same
  // way): `gtv` decides whether a score animation exists at all.
  const fetchMeta = useCallback(async () => {
    if (!sportId || !eventId) return
    try {
      const row = await getSportsGameDetail(eventId, sportId)
      if (row && row.gmid) setMeta(row)
    } catch { /* keep the last good meta — a poll may fail transiently */ }
  }, [sportId, eventId])

  // Fetch live odds
  const fetchMarkets = useCallback(async () => {
    if (!sportId || !eventId) return
    try {
      const response = await getMatchPrivateData(eventId, sportId)
      const arr = extractMarketArray(response)
      // five strikes and the page goes quiet (see stopPolls)
      if (arr.length) { hadDataRef.current = true; deadRef.current = 0; setDead(false); setNoMarkets(false) }
      else if (++deadRef.current >= (hadDataRef.current ? DEAD_LIMIT : 1)) setNoMarkets(true)
      /* Two different empties, and they look different on screen.

         · The feed ANSWERS with nothing — Politics
           (/admin/game-details/40/891072363, Assembly Election 2026, starts
           05/05/2026) replies 200 with
             {"data": null, "msg": "No Record Found.", "status": 300}
           The event is real: the meta is full, so the page paints the way the
           reference's own DOM does — `game-header sport40` with its name and
           date, the More Market button, an EMPTY `.market-container`, the
           sidebar — and only then goes home. `noMarkets`, above.

         · The match is GONE — our API turns the upstream 404 into HTTP 500
           `{success:false, error:"Request failed with status code 404"}`, axios
           throws, and the `catch` below sets `dead`: the bare shell (empty
           header, `sportundefined`) and then home.

         Both leave after DEAD_REDIRECT_MS; only the second one blanks. */
      // keep the poll we are replacing — the blocks colour a price against it
      // (reference: `gameData.old = gameData.new` before the new one lands)
      setMarketsData((prev) => { prevMarketsRef.current = prev; return arr })
    } catch {
      // keep previous data on error; our API answers a dead match with
      // HTTP 500 `{success:false, error:"Request failed with status code 404"}`,
      // which axios throws — that counts as a strike too
      if (++deadRef.current >= (hadDataRef.current ? DEAD_LIMIT : 1)) { setDead(true); stopPolls() }
    }
  }, [sportId, eventId, stopPolls])

  const fetchBets = useCallback(async () => {
    if (!eventId) return
    try {
      const response = await getMatchDownlineBets({ eventId, limit: 100 })
      if (response?.success) {
        const allBets = response.data || []
        // `unmatched` is the authoritative flag. status='open' only means the
        // bet is live and awaiting a result — it is NOT an unmatched bet, and
        // treating it as one left the Matched tab permanently empty.
        setMatchedBets(allBets.filter((b) => b.unmatched !== true))
        setUnmatchedBets(allBets.filter((b) => b.unmatched === true))
      }
    } catch (err) {
      console.error('Error fetching bets:', err)
    }
  }, [eventId])

  // Same source as the Market Analysis page, scoped to this event — so the
  // numbers on both screens are identical, market for market.
  const fetchExposure = useCallback(async () => {
    if (!eventId) return
    try {
      const res = await getMarketAnalysis({ eventid: eventId })
      if (!res?.success) return
      // market-analysis ek hi eventid ki KAI entries de sakta hai (alag market_id
      // per market group — e.g. "Normal" fancy alag, "MATCH_ODDS" alag). Sabke
      // markets merge karo warna sirf pehla group index me aata hai (MATCH_ODDS
      // exposure map nahi hota).
      const all = res.data || []
      const entries = all.filter((m) => String(m.eventid) === String(eventId))
      const base = entries[0] || all[0]
      const merged = base
        ? { ...base, markets: (entries.length ? entries : all).flatMap((e) => e.markets || []) }
        : null
      setExposureIndex(buildExposureIndex(merged))
    } catch (err) {
      console.error('Error fetching exposure:', err)
    }
  }, [eventId])

  useEffect(() => {
    if (!sportId || !eventId) return
    fetchMatchInfo()
    fetchMeta()
    fetchMarkets()
    fetchBets()
    fetchExposure()

    deadRef.current = 0
    hadDataRef.current = false
    setDead(false)
    setNoMarkets(false)
    intervalRef.current = setInterval(fetchMarkets, 2000)
    const slowInterval = setInterval(() => { fetchBets(); fetchExposure(); fetchMeta() }, 5000)
    // both live in one list so a dead match silences the whole page at once
    // (the reference drops its user-book poll with the game-data one)
    timersRef.current = [intervalRef.current, slowInterval]
    return () => { clearInterval(intervalRef.current); clearInterval(slowInterval) }
  }, [sportId, eventId, fetchMatchInfo, fetchMeta, fetchMarkets, fetchBets, fetchExposure])

  /* Score animation: the reference shows the box when `gtv != 0` and the url
     resolved. Sticky once seen — a poll that comes back without `gtv` would
     otherwise unmount the box, and the remount mints (and burns) a second
     single-use token. Reset when the match changes. */
  const coveredRef = useRef({ gmid: null, covered: false })
  if (coveredRef.current.gmid !== eventId) coveredRef.current = { gmid: eventId, covered: false }
  if (Number(meta?.gtv) > 0) coveredRef.current.covered = true
  const scoreCovered = coveredRef.current.covered
  const etid = meta?.etid ?? sportId

  /* More Market — reference: loader overlay up, fetch the list, loader down,
     modal opens. Our stand-in for its `game/marketlist` is /market-list: every
     market the match has shown (closed ones too, kept in redis) combined with
     the live feed. Should that call fail, the live feed alone still fills the
     list. Each market's book comes from the open downline bets. */
  const openMoreMarket = async () => {
    setMoreOpen(true)
    setMoreLoading(true)
    try {
      let markets
      try {
        const listed = await getMarketList(eventId, sportId)
        markets = Array.isArray(listed?.data) ? listed.data : []
      } catch {
        markets = []
      }
      if (!markets.length) markets = extractMarketArray(await getMatchPrivateData(eventId, sportId))
      const rows = sortBySno(markets).map((m) => {
        // reference `scnt` = number of open downline bets on that market
        const book = matchedBets.filter((b) => String(b.match_id) === String(m.mid)).length
        return { mid: m.mid, mname: m.mname, book }
      })
      setMoreMarkets(rows)
    } catch {
      setMoreMarkets([])
    } finally {
      setMoreLoading(false)
    }
  }
  // reference `setMarketId(mid){ this.mid = mid; marketListModal.hide() }` —
  // the page then shows THAT market
  const pickMoreMarket = (row) => {
    setSelectedMid(row.mid)
    setMoreOpen(false)
  }

  /* Which markets the page shows.
   *
   * The reference does not render everything the feed has: `getMarketId()`
   * runs on load, reads the market list and picks ONE as the page's `mid` —
   *   match_odds → winners → 1x2 → the first row
   * — and `getGameData` then asks for that `mid` only. That is why the
   * reference's tennis page (gmid 825967218) shows MATCH_ODDS ALONE while the
   * feed also carries Bookmaker and 1st Set Winner, and why "More Market"
   * exists on every sport EXCEPT cricket: on cricket the whole board (odds,
   * bookmaker, fancy, oddeven, khado, meter) is already on the page, so there
   * is nothing to pick.
   *
   * Our `get-match-private-data` takes no `mid`, so the selection is applied
   * here: cricket shows everything, every other sport shows the selected
   * market, and More Market changes the selection.
   */
  /* Header text — the meta poll first (the reference's own `gameDetail`), the
     sports-list scan as the fallback.

     On a match whose markets are gone the header goes BARE, exactly as the
     user's capture has it (2026-09-22, "empty header rakhna hai iske aise
     mein"):

       <div class="game-header sportundefined">
         <span class="game-header-name"> &gt; </span> <div><span></span></div>
       </div>

     — no name, no time, and `sportundefined` because the reference's own
     `gameDetail` came back empty for it, so `sport${etid}` had nothing to
     interpolate.

     So the header is bare in exactly two cases: the match is DEAD, or nothing
     has arrived yet. It is NOT tied to the markets any more — an event can be
     perfectly alive with no market open (Politics: Assembly Election 2026,
     markets answer "No Record Found.", meta answers in full), and blanking its
     header would have hidden a name the reference shows. */
  const bare = dead || (!meta && !hadDataRef.current)
  const headerSeries = bare ? '' : (meta?.cname || matchInfo.series || '')
  const headerName = bare ? '' : (meta?.ename || (matchInfo.name === 'Match Details' ? '' : matchInfo.name) || '')
  const headerTime = bare ? '' : (meta?.stime || matchInfo.time || '')
  const headerSport = bare ? 'sportundefined' : `sport${sportId}`

  const allMarkets = sortBySno(marketsData)
  const isCricket = String(etid) === '4'
  const defaultMid = (() => {
    const named = (n) => allMarkets.find((m) => String(m.mname || '').toLowerCase().trim() === n)
    const sel = named('match_odds') || named('winners') || named('1x2') || allMarkets[0]
    return sel ? sel.mid : null
  })()
  const activeMid = selectedMid && allMarkets.some((m) => String(m.mid) === String(selectedMid))
    ? selectedMid
    : defaultMid
  const visibleMarkets = isCricket ? allMarkets : allMarkets.filter((m) => String(m.mid) === String(activeMid))



  // reference: har bet = market+time header row + data row + 3px spacer, back/lay
  // ke hisaab se back-border/lay-border class; fancy pe selection ke aage " / run"
  const fmtBetTime = (raw) => {
    if (!raw) return ''
    const d = new Date(raw)
    if (isNaN(d)) return String(raw)
    const p = (n) => String(n).padStart(2, '0')
    return `${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`
  }
  const num = (v) => {
    const n = parseFloat(v)
    return Number.isFinite(n) ? String(n) : (v ?? '-')
  }
  const betsTable = (bets, emptyMsg) => (
    <div className="table-responsive">
      <table className="table coupon-table mb-0">
        <thead>
          <tr>
            <th style={{ minWidth: '90px' }}>UserName</th>
            <th style={{ minWidth: '90px' }}>Nation</th>
            <th className="text-right" style={{ minWidth: '50px' }}>Rate</th>
            <th className="text-right" style={{ minWidth: '70px' }}>Amount</th>
          </tr>
        </thead>
        <tbody>
          {bets.length === 0 ? (
            <tr><td colSpan="4" className="text-center">{emptyMsg}</td></tr>
          ) : (
            bets.map((bet, i) => {
              const isLay = ['lay', 'no'].includes(String(bet.bet_type || bet.type || '').toLowerCase())
              const border = isLay ? 'lay-border' : 'back-border'
              const market = bet.market_type || bet.game_type || ''
              const user = bet.username || bet.user?.username || '-'
              const selection = bet.selection_name || bet.selection || '-'
              const run = bet.run ?? bet.line ?? bet.fancy_run
              const time = fmtBetTime(bet.created_at || bet.createdAt || bet.placed_at || bet.date)
              return (
                <Fragment key={bet.id || i}>
                  <tr className={border}>
                    <td colSpan="4"><b>{market}</b> <span className="float-right">{time}</span></td>
                  </tr>
                  <tr className={border}>
                    <td className="bt0">{user}</td>
                    <td className="bt0">{selection}{run != null && run !== '' ? ` / ${run}` : ''}</td>
                    <td className="text-right bt0">{num(bet.odds)}</td>
                    <td className="text-right bt0">{num(bet.stake_amount ?? bet.amount)}</td>
                  </tr>
                  <tr><td colSpan="4" style={{ height: '3px', padding: 0 }}></td></tr>
                </Fragment>
              )
            })
          )}
        </tbody>
      </table>
    </div>
  )

  return (
    <div className="detail-page-container">
      <div className="center-main-container">
        <div className="center-content">
          {/* Reference: `<span class="game-header-name">{{cname}} > {{ename}}</span>`
              — the " > " is unconditional, and with nothing loaded the header
              is literally " > " with an empty time span (the user's capture of
              a dead match). Ours printed a "Match Details" placeholder, which
              the reference has no notion of. The meta poll is the better
              source anyway: it answers for this match (cname "CZECH Liga Pro",
              ename "Samuel Byrtus - Alfred Rinka") when the markets are 404. */}
          <div className={`game-header ${headerSport}`}>
            <span className="game-header-name">
              {`${headerSeries} > ${headerName}`}
            </span>
            {/* Racing only: the reference appends the race itself —
                `10 == gameDetail.etid ? <span>| {{mname}}</span>`. Capture:
                `<span>23/09/2026 06:10:00</span> <span>| R5 6f Claim</span>`.
                Greyhound (65) does NOT get it; the condition is etid 10 alone. */}
            <div>
              <span>{formatMatchTime(headerTime)}</span>
              {String(etid) === '10' && !bare && <>{' '}<span>| {meta?.mname || ''}</span></>}
            </div>
          </div>
          {/* score animation — reference: `gtv != 0 && animationUrl` */}
          {scoreCovered && <SportsScorecard gmid={eventId} etid={etid} />}
          {/* More Market — reference: every sport except cricket (etid != 4) */}
          {String(etid) !== '4' && (
            <div className="more-market text-right">
              <button className="btn btn-back" onClick={openMoreMarket}>
                {'\n            More Market\n          '}
              </button>
            </div>
          )}
          {/* The container is always there and simply holds nothing when the
              feed has nothing — reference, on a match whose markets are gone:
              `<div class="market-container"></div>`. It has no "Loading…" and
              no "No markets available." state at all; ours had both. */}
          {(
            <div className="market-container">
              {visibleMarkets.map((market, idx) => {
                const key = market.mid || `${market.mname}-${idx}`
                const onBetLock = (mid, mname) => setBetLockModal({ show: true, marketId: mid, marketName: mname })
                const onUserBook = (mname) => setUserBookModal({ show: true, gameType: mname, marketName: mname })
                // the same market one poll ago, for the price-change colour
                const prev = prevMarketsRef.current || []
                const oldMarket = prev.find((p) => String(p.mid) === String(market.mid)) || sortBySno(prev)[idx]
                const common = { market, oldMarket, marketIndex: idx, exposureIndex, onBetLock, onUserBook }
                const tiered = (cfg) => <TieredMarket key={key} {...common} {...cfg} isMobile={isMobile} />
                switch (Number(market.dtype)) {
                  case 1: return <Market1Block key={key} {...common} />
                  case 2: return tiered(TIER_2)
                  case 3: return tiered(TIER_3)
                  case 4: return tiered(TIER_4)
                  case 5: return tiered(TIER_5)
                  case 6: return <FancyPairMarket key={key} {...common} {...PAIR_NO_YES} />
                  case 7: return <FancyPairMarket key={key} {...common} {...PAIR_BACK_LAY} />
                  case 8: return <FancyPairMarket key={key} {...common} {...PAIR_ODD_EVEN} />
                  case 9: return <NumberMarket key={key} {...common} />
                  case 10: return <KhadoMarket key={key} {...common} />
                  case 11: return tiered(TIER_11)
                  case 12: return <RacingMarket key={key} {...common} isMobile={isMobile} />
                  case 13: return tiered(TIER_13)
                  default:
                    // dtype 14–16 (theme-gated / horse "new market") or a market
                    // with no dtype: the reference renders nothing, we never drop
                    // a market — fall back to the old gtype choice.
                    return (market.gtype === 'match' || market.gtype === 'match1' || /bookmaker/i.test(market.mname || ''))
                      ? tiered(TIER_4)
                      : <FancyPairMarket key={key} {...common} {...PAIR_NO_YES} />
                }
              })}
            </div>
          )}
        </div>
        <div className={`right-sidebar${isMobile ? '' : ' sticky'}`}>
          {/* Live Match card — accordion: header click pe video-tv (stream iframe)
              open/close, arrow flip.

              The card's CONTENTS only exist when the feed says the match has a
              stream — reference: `gameDetail.tv ? [header, .video-tv] : _e()`
              inside a `<div class="card m-b-10">` that always stays. Both of
              the matches checked today (tennis 825967218, cricket 884614027)
              carry `tv: false`, so the reference shows an empty card there —
              exactly the `<div class="card m-b-10"><!----></div>` in the user's
              capture. Ours showed the header and an iframe that could never
              play. `tv` comes from the same meta poll as `gtv`. */}
          <div className="card m-b-10">
            {meta?.tv ? (
            <>
            {/* Before the first click the reference's header is literally
                `aria-expanded="true" class="card-header pointer"` while its
                body is `.video-tv collapse` — closed. Those two attributes are
                written into the template and only Bootstrap's JS ever changes
                them, which it does on the first toggle. Both captures show it
                (racing 1790122151171, politics 891072363), and it matters: with
                `collapsed` the arrow is rotated 180° (style.css
                `.card-header.collapsed img`), so painting it from our own state
                pointed the arrow the wrong way until the operator clicked. */}
            <div
              data-toggle="collapse"
              data-target=".video-tv"
              aria-expanded={liveTouched ? (liveOpen ? 'true' : 'false') : 'true'}
              className={`card-header pointer${liveTouched && !liveOpen ? ' collapsed' : ''}`}
              onClick={() => { setLiveTouched(true); setLiveOpen((v) => !v) }}
            >
              <h6 className="card-title">
                <a href="javascript:void(0)" title="">
                  <img src={ARROW_ADMIN} className="mr-1" alt="" />
                </a>
                Live Match
              </h6>
            </div>
            {/* The reference card is `<div class="video-tv collapse">` with
                `data-toggle="collapse" data-target=".video-tv"` on the header —
                the slide is Bootstrap's JS animating height through
                `.collapsing` (.35s ease). Flipping `show` from React, which is
                what this did, has no middle frame: the box just popped (user's
                recording, 2026-09-22 — "accordion live score ka smooth nahi
                hai"). components/Collapse.jsx is that dance, already used by
                the rules accordion and the sidebar. */}
            <Collapse open={liveOpen} className="video-tv">
              {liveOpen && eventId && (
                <iframe
                  key={eventId}
                  src={`${SPORTS_STREAM_BASE}${eventId}`}
                  title="Live Match"
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                  scrolling="no"
                  style={{ overflow: 'hidden' }}
                ></iframe>
              )}
            </Collapse>
            </>
            ) : null}
          </div>
          {/* Scorecard — socket-driven, and gated the way the reference gates
              it: the whole block is skipped for `scard == 2`, and this card is
              the `scard == 1` one. (`scard == 0` is a different, statistics
              table card we do not render.) Ours showed it for every sid-4
              match, including the `scard: 2` ones the reference leaves bare.
              Checked live: 884614027 scard 2 (no card), 462855645 scard 1. */}
          <div>
            {String(sportId) === '4' && Number(meta?.scard) === 1 && (
              <CricketScorecard gmid={eventId} started />
            )}
          </div>
          <div id="my-game-bets" className="card m-b-10 my-bet">
            <div className="card-header">
              <h6 className="card-title float-left">My Bets</h6>
              <a href="javascript:void(0)" className="btn btn-back float-right" onClick={() => setShowViewMore(true)}>View More</a>
            </div>
            <div className="card-body">
              <div className="tabs">
                <ul role="tablist" className="nav nav-tabs small">
                  <li role="presentation" className="nav-item">
                    <a role="tab" href="#" className={`nav-link ${activeTab === 'matched' ? 'active' : ''}`}
                      onClick={(e) => { e.preventDefault(); switchTab('matched') }}>Matched Bets</a>
                  </li>
                  <li role="presentation" className="nav-item">
                    <a role="tab" href="#" className={`nav-link ${activeTab === 'unmatched' ? 'active' : ''}`}
                      onClick={(e) => { e.preventDefault(); switchTab('unmatched') }}>Unmatched Bets</a>
                  </li>
                </ul>
                <div className="tab-content">
                  <div className={`tab-pane fade${tabShown ? ' show' : ''} ${activeTab === 'matched' ? 'active' : ''}`} style={activeTab !== 'matched' ? { display: 'none' } : {}}>
                    <div id="matched-bet" className="tab-pane active">{betsTable(matchedBets, 'No records found')}</div>
                  </div>
                  <div className={`tab-pane fade${tabShown ? ' show' : ''} ${activeTab === 'unmatched' ? 'active' : ''}`} style={activeTab !== 'unmatched' ? { display: 'none' } : {}}>
                    <div id="unmatched-bet" className="tab-pane">{betsTable(unmatchedBets, 'No records found')}</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Phone-only floating bet counter — reference renders it always (it reads
          "0 Bets" when there are none) and its click is
          `scrollToId("my-game-bets")` = window.scrollTo({top: offsetTop,
          behavior:'smooth'}). CSS is already in styles/ten.css:1068. */}
      <div
        className="market-show-icon d-none-desktop"
        role="button"
        tabIndex={0}
        onClick={() => {
          const el = document.getElementById('my-game-bets')
          if (el) window.scrollTo({ top: el.offsetTop, behavior: 'smooth' })
        }}
      >
        <div className="bet-cnt">{Math.min(matchedBets.length, 10)}</div>
        <div className="bet-title">Bets</div>
      </div>
      <MoreMarketModal
        show={moreOpen}
        loading={moreLoading}
        markets={moreMarkets}
        onClose={() => setMoreOpen(false)}
        onPick={pickMoreMarket}
      />
      <ViewMoreBetsModal
        show={showViewMore}
        onHide={() => setShowViewMore(false)}
        eventId={eventId}
      />
      <UserBookModal
        show={userBookModal.show}
        onHide={() => setUserBookModal({ show: false, gameType: null, marketName: null })}
        eventId={eventId}
        gameType={userBookModal.gameType}
        marketName={userBookModal.marketName}
      />
      <BetLockModal
        show={betLockModal.show}
        onHide={() => setBetLockModal({ show: false, marketId: null, marketName: null })}
        eventId={eventId}
        marketId={betLockModal.marketId}
        marketName={betLockModal.marketName}
      />
    </div>
  )
}

export default GameDetails
