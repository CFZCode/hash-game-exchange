import { useState, useEffect, useCallback, useMemo } from 'react'
import Swal from 'sweetalert2'
import jsGamesAdminService from '../../services/jsGamesAdminService'
import useModalEnter from '../../hooks/useModalEnter'
import Pagination from '../../components/Pagination'

const CATEGORIES = ['crash', 'lottery', 'slot', 'fantasy']
// Any category can be split one level deeper, into provider groups (Slot has
// Jili, Amigo, Red Tiger…; Fantasy could have SBO, SABA, BTI…). Group order is
// also the order that category shows in the app, and a game belongs to at most
// one group per category. A category with NO groups keeps its plain flat queue,
// so this whole layer stays invisible until the first + Provider click.
const UNGROUPED = 'ungrouped'
// The catalog tab is not a category, so group actions there act on slot
const SLOT_FALLBACK = 'slot'
// One level below providers: each provider has its own tab strip (Jili is
// Slot Game / Table Game / Fish Game / Crash Game, Red Tiger is New Slots and
// 3REEL…7REEL). Tab order orders the strip on the slot page — it deliberately
// does NOT touch the provider's own curated listing order.
// Pseudo-tab: the provider's games no tab claims.
const UNCATEGORIZED = 'uncategorized'
// Pseudo-tab: full catalog browser (no priority queue), incl. games outside all categories
const CATALOG = 'all'
const TABS = [...CATEGORIES, CATALOG]
const PER_PAGE = 20

const Toast = Swal.mixin({
  toast: true,
  position: 'top-end',
  showConfirmButton: false,
  timer: 3000,
  timerProgressBar: false,
})

const escapeHtml = (str) =>
  String(str ?? '').replace(/[&<>"']/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ))

function GameImage({ game, size = 48, onClick }) {
  const style = {
    width: `${size * 1.6}px`,
    height: `${size}px`,
    objectFit: 'cover',
    borderRadius: '4px',
    cursor: 'pointer',
    background: '#f1f3f6',
  }
  if (!game.game_icon) {
    return (
      <div
        className="d-flex align-items-center justify-content-center text-muted"
        style={{ ...style, border: '1px dashed #ced4da' }}
        title="Click to set image"
        onClick={onClick}
      >
        <i className="bx bx-image"></i>
      </div>
    )
  }
  return (
    <img
      src={game.game_icon}
      alt={game.game_name}
      style={style}
      title="Click to edit"
      onClick={onClick}
      onError={(e) => { e.target.style.objectFit = 'contain' }}
    />
  )
}

function GamePriorityPanel() {
  const [category, setCategory] = useState('crash')
  const [categoryCounts, setCategoryCounts] = useState({})

  // Slot provider groups
  const [providers, setProviders] = useState([])
  const [provider, setProvider] = useState('')
  const [ungroupedCount, setUngroupedCount] = useState(0)
  const [providerBusy, setProviderBusy] = useState(false)

  // Sub-categories of the selected provider. The strip payload already carries
  // them (with_ids), so there is nothing extra to fetch.
  const [slotCategory, setSlotCategory] = useState(UNCATEGORIZED)
  const [categoryBusy, setCategoryBusy] = useState(false)

  // Priority queue
  const [queue, setQueue] = useState([])
  const [queueLoading, setQueueLoading] = useState(true)
  const [queueSaving, setQueueSaving] = useState(false)

  // All games panel
  const [games, setGames] = useState([])
  const [gamesLoading, setGamesLoading] = useState(true)
  const [pagination, setPagination] = useState({ current_page: 1, total: 0, total_pages: 1 })
  const [page, setPage] = useState(1)
  const [keyword, setKeyword] = useState('')
  const [searchInput, setSearchInput] = useState('')
  const [vendor, setVendor] = useState('')
  const [vendors, setVendors] = useState([])
  const [statusFilter, setStatusFilter] = useState('')
  const [providerFilter, setProviderFilter] = useState('')

  const isCatalog = category === CATALOG
  // Grouped mode is a property of the DATA, not of which tab is open: a category
  // is grouped once it has at least one provider group.
  const isGrouped = !isCatalog && providers.length > 0
  const isUngrouped = isGrouped && provider === UNGROUPED
  // Ungrouped is a view, not a group — nothing to reorder or save there
  const queueEditable = !isCatalog && !isUngrouped && (!isGrouped || !!provider)
  const currentProvider = providers.find((p) => p.provider === provider)

  // Which category a per-game group move applies to
  const groupCategory = isCatalog ? SLOT_FALLBACK : category
  // Inside a provider group: the tab strip and which tab is open
  const inProviderGroup = isGrouped && !!provider && !isUngrouped
  const slotCategories = currentProvider?.categories || []
  const currentSlotCategory = slotCategories.find((c) => c.slug === slotCategory)
  const isUncategorized = inProviderGroup && slotCategory === UNCATEGORIZED
  const uncategorizedCount = currentProvider?.uncategorized_games || 0
  // First tab of a provider, or its untabbed list when it has none
  const defaultCategoryOf = (prov) => {
    const row = providers.find((p) => p.provider === prov)
    return row?.categories?.length ? row.categories[0].slug : UNCATEGORIZED
  }

  // game id -> the provider group holding it, for badges on the catalog list.
  // Refetched after every group change, so it beats the row's own slot_provider.
  const providerByGame = useMemo(() => {
    const map = new Map()
    for (const p of providers) {
      for (const id of p.game_ids || []) map.set(id, p)
    }
    return map
  }, [providers])

  const gameProvider = (game) => providerByGame.get(game.id) || game.slot_provider || null

  // Same idea one level down: game id -> the tab holding it, across every
  // provider, so a catalog row can say where a game already lives.
  const categoryByGame = useMemo(() => {
    const map = new Map()
    for (const p of providers) {
      for (const c of p.categories || []) {
        for (const id of c.game_ids || []) {
          map.set(id, { provider: p.provider, providerLabel: p.label, slug: c.slug, label: c.label })
        }
      }
    }
    return map
  }, [providers])

  const gameCategory = (game) => categoryByGame.get(game.id) || game.slot_category || null

  // Where a game sits today, for the "Move here" hint
  const originLabel = (game) => {
    const cat = gameCategory(game)
    if (cat) return `${cat.providerLabel || cat.provider} · ${cat.label}`
    const prov = gameProvider(game)
    return prov ? `${prov.label} · untabbed` : ''
  }

  // The group filter is only meaningful where a grouped category is listed
  const showProviderFilter = isGrouped || isCatalog

  // Edit modal
  const [editGame, setEditGame] = useState(null)
  // Edit modal open animation + outside click (hooks/useModalEnter)
  const editEnter = useModalEnter(() => setEditGame(null), !!editGame)
  const [editForm, setEditForm] = useState({ game_name: '', game_icon: '', is_active: true })
  const [editSaving, setEditSaving] = useState(false)

  const apiError = (error) =>
    Toast.fire({ icon: 'error', title: error.response?.data?.message || error.response?.data?.error || error.message })

  const fetchCategories = async () => {
    try {
      const response = await jsGamesAdminService.categories()
      if (response.success) {
        const counts = {}
        for (const c of response.payload.categories) counts[c.category] = c.total_games
        setCategoryCounts(counts)
      }
    } catch (error) {
      apiError(error)
    }
  }

  // Provider strip for the slot tab. with_ids lets the catalog list show which
  // group already owns a game. Returns the list so callers can pick a default.
  const fetchProviders = useCallback(async (cat) => {
    // The catalog tab spans every category, so its group badges and filter keep
    // working against slot — the only category that was grouped before this.
    const target = cat === CATALOG ? SLOT_FALLBACK : cat
    if (!target) { setProviders([]); setUngroupedCount(0); return [] }
    try {
      const response = await jsGamesAdminService.providers(target, { with_ids: true })
      if (response.success) {
        setProviders(response.payload.providers || [])
        setUngroupedCount(response.payload.ungrouped_games || 0)
        return response.payload.providers || []
      }
    } catch (error) {
      apiError(error)
    }
    return []
  }, [])

  // Slot pulls one tab of one provider group (slug `uncategorized` = the games
  // that provider holds outside every tab, which on a provider with no tabs is
  // simply its whole list); every other category pulls its flat queue.
  const fetchQueue = useCallback(async (cat, prov, slug, grouped) => {
    if (grouped && !prov) { setQueue([]); setQueueLoading(false); return }
    setQueueLoading(true)
    try {
      let response
      if (grouped && prov === UNGROUPED) {
        response = await jsGamesAdminService.providerGames(cat, prov)
      } else if (grouped) {
        response = await jsGamesAdminService.providerTabGames(cat, prov, slug || UNCATEGORIZED)
      } else {
        response = await jsGamesAdminService.getPriority(cat)
      }
      if (response.success) setQueue(response.payload.games || [])
    } catch (error) {
      apiError(error)
    } finally {
      setQueueLoading(false)
    }
  }, [])

  const fetchGames = useCallback(async (cat, pageNum, kw, vend, status, group) => {
    setGamesLoading(true)
    try {
      const params = { page: pageNum, per_page: PER_PAGE }
      if (cat !== CATALOG) params.category = cat
      if (kw) params.keyword = kw
      if (vend) params.vendor = vend
      if (status) params.is_active = status
      if (group) params.slot_provider = group
      const response = await jsGamesAdminService.listGames(params)
      if (response.success) {
        setGames(response.payload.games || [])
        setPagination(response.payload.pagination)
      }
    } catch (error) {
      apiError(error)
    } finally {
      setGamesLoading(false)
    }
  }, [])

  const fetchVendors = useCallback(async (cat) => {
    try {
      const response = await jsGamesAdminService.vendors(cat === CATALOG ? {} : { category: cat })
      if (response.success) setVendors((response.payload.vendors || []).filter((v) => v.vendor))
    } catch (error) {
      apiError(error)
    }
  }, [])

  useEffect(() => {
    fetchCategories()
  }, [])

  // The provider strip belongs to the open category, so it reloads with it
  useEffect(() => {
    fetchProviders(category)
  }, [category, fetchProviders])

  useEffect(() => {
    if (category === CATALOG) {
      setQueue([])
      setQueueLoading(false)
    } else {
      fetchQueue(category, provider, slotCategory, isGrouped)
    }
    fetchVendors(category)
  }, [category, provider, slotCategory, isGrouped, fetchQueue, fetchVendors])

  // Once a category's strip lands, open its first group. A category with no
  // groups keeps provider '' and renders its plain flat queue.
  useEffect(() => {
    if (isCatalog || providers.length === 0) return
    if (provider && (provider === UNGROUPED || providers.some((p) => p.provider === provider))) return
    setProvider(providers[0].provider)
    setSlotCategory(defaultCategoryOf(providers[0].provider))
  }, [isCatalog, providers, provider])

  // A tab can vanish under the selection (deleted, or the provider changed
  // before its strip arrived) — fall back to the first one it does have.
  useEffect(() => {
    if (!inProviderGroup || !currentProvider) return
    const slugs = (currentProvider.categories || []).map((c) => c.slug)
    if (slotCategory !== UNCATEGORIZED && !slugs.includes(slotCategory)) {
      setSlotCategory(slugs[0] || UNCATEGORIZED)
    }
  }, [inProviderGroup, currentProvider, slotCategory])

  const switchCategory = (cat) => {
    if (cat === category) return
    setCategory(cat)
    // The strip belongs to the new category, so the old one cannot carry over —
    // clearing it stops the "open the first group" effect below from firing
    // against the previous category's list while the new one is in flight.
    setProviders([])
    setUngroupedCount(0)
    setProvider('')
    setSlotCategory(UNCATEGORIZED)
    setPage(1)
    setKeyword('')
    setSearchInput('')
    setVendor('')
    setStatusFilter('')
    setProviderFilter('')
  }

  const switchProvider = (prov) => {
    if (prov === provider) return
    setProvider(prov)
    setSlotCategory(prov === UNGROUPED ? UNCATEGORIZED : defaultCategoryOf(prov))
    setPage(1)
  }

  const switchSlotCategory = (slug) => {
    if (slug === slotCategory) return
    setSlotCategory(slug)
    setPage(1)
  }

  useEffect(() => {
    fetchGames(category, page, keyword, vendor, statusFilter, providerFilter)
  }, [category, page, keyword, vendor, statusFilter, providerFilter, fetchGames])

  // --- Queue operations: every change saves the full ordered list ---

  const saveQueue = async (nextQueue) => {
    if (!queueEditable) return
    const prevQueue = queue
    setQueue(nextQueue)
    setQueueSaving(true)
    try {
      const ids = nextQueue.map((g) => g.id)
      const response = isGrouped
        ? await jsGamesAdminService.setProviderTabGames(category, provider, slotCategory, ids)
        : await jsGamesAdminService.setPriority(category, ids)
      if (!response.success) {
        Toast.fire({ icon: 'error', title: response.message || 'Save failed' })
        setQueue(prevQueue)
      } else if (isGrouped) {
        // Group and tab counts, and both game -> owner maps, all moved
        fetchProviders(category)
      }
    } catch (error) {
      apiError(error)
      setQueue(prevQueue)
    } finally {
      setQueueSaving(false)
    }
  }

  // On the slot tab this also pulls the game out of whatever group held it —
  // a slot game lives in exactly one provider group.
  const addToQueue = (game) => {
    if (queue.some((g) => g.id === game.id)) return
    saveQueue([...queue, game])
  }

  const removeFromQueue = (id) => {
    saveQueue(queue.filter((g) => g.id !== id))
  }

  const moveInQueue = (index, delta) => {
    const target = index + delta
    if (target < 0 || target >= queue.length) return
    const next = [...queue]
    ;[next[index], next[target]] = [next[target], next[index]]
    saveQueue(next)
  }

  const moveToPosition = (index, rawPosition) => {
    const parsed = parseInt(rawPosition)
    if (!Number.isInteger(parsed)) return
    const position = Math.min(queue.length, Math.max(1, parsed)) - 1
    if (position === index) return
    const next = [...queue]
    const [item] = next.splice(index, 1)
    next.splice(position, 0, item)
    saveQueue(next)
  }

  const queuePosition = (id) => queue.findIndex((g) => g.id === id)

  // --- Provider group management (slot tab) ---

  const runProviderOp = async (op, successTitle) => {
    setProviderBusy(true)
    try {
      const response = await op()
      if (response.success) {
        const list = await fetchProviders(category)
        Toast.fire({ icon: 'success', title: successTitle })
        return list
      }
      Toast.fire({ icon: 'error', title: response.message || 'Failed' })
    } catch (error) {
      apiError(error)
    } finally {
      setProviderBusy(false)
    }
    return null
  }

  const addProvider = async () => {
    const { isConfirmed, value } = await Swal.fire({
      title: 'New provider group',
      input: 'text',
      inputPlaceholder: 'e.g. Pragmatic Play',
      inputValidator: (v) => (v && v.trim() ? undefined : 'Enter a name'),
      showCancelButton: true,
      confirmButtonText: 'Create',
    })
    if (!isConfirmed) return
    const created = await runProviderOp(
      () => jsGamesAdminService.createProvider(category, value.trim()),
      'Provider group created',
    )
    if (created) {
      const match = created.find((p) => p.label === value.trim())
      if (match) switchProvider(match.provider)
    }
  }

  const renameProvider = async () => {
    if (!currentProvider) return
    const { isConfirmed, value } = await Swal.fire({
      title: 'Rename provider group',
      input: 'text',
      inputValue: currentProvider.label,
      inputValidator: (v) => (v && v.trim() ? undefined : 'Enter a name'),
      showCancelButton: true,
      confirmButtonText: 'Save',
    })
    if (!isConfirmed) return
    await runProviderOp(
      () => jsGamesAdminService.renameProvider(category, currentProvider.provider, value.trim()),
      'Provider renamed',
    )
  }

  const deleteProvider = async () => {
    if (!currentProvider) return
    const { isConfirmed } = await Swal.fire({
      title: `Delete "${currentProvider.label}"?`,
      html: `Its ${currentProvider.total_games} game(s) stay in the app but become <b>Ungrouped</b>.`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Delete',
      confirmButtonColor: '#f46a6a',
    })
    if (!isConfirmed) return
    const list = await runProviderOp(
      () => jsGamesAdminService.deleteProvider(category, currentProvider.provider),
      'Provider group deleted',
    )
    if (list) setProvider(list[0] ? list[0].provider : UNGROUPED)
  }

  // Provider order is slot order in the app, so this reshuffles the listing.
  const moveProvider = async (delta) => {
    const index = providers.findIndex((p) => p.provider === provider)
    const target = index + delta
    if (index < 0 || target < 0 || target >= providers.length) return
    const order = providers.map((p) => p.provider)
    ;[order[index], order[target]] = [order[target], order[index]]
    await runProviderOp(
      () => jsGamesAdminService.reorderProviders(category, order),
      'Provider order saved',
    )
  }

  // --- Sub-category management (inside one provider group) ---

  const runCategoryOp = async (op, successTitle) => {
    setCategoryBusy(true)
    try {
      const response = await op()
      if (response.success) {
        await fetchProviders(category)
        Toast.fire({ icon: 'success', title: successTitle })
        return response
      }
      Toast.fire({ icon: 'error', title: response.message || 'Failed' })
    } catch (error) {
      apiError(error)
    } finally {
      setCategoryBusy(false)
    }
    return null
  }

  const addSlotCategory = async () => {
    if (!currentProvider) return
    const { isConfirmed, value } = await Swal.fire({
      title: `New tab in ${currentProvider.label}`,
      input: 'text',
      inputPlaceholder: 'e.g. Fish Game',
      inputValidator: (v) => (v && v.trim() ? undefined : 'Enter a name'),
      showCancelButton: true,
      confirmButtonText: 'Create',
    })
    if (!isConfirmed) return
    const response = await runCategoryOp(
      () => jsGamesAdminService.createProviderTab(category, provider, value.trim()),
      'Tab created',
    )
    if (response) setSlotCategory(response.payload.category.slug)
  }

  const renameSlotCategory = async () => {
    if (!currentSlotCategory) return
    const { isConfirmed, value } = await Swal.fire({
      title: 'Rename tab',
      input: 'text',
      inputValue: currentSlotCategory.label,
      inputValidator: (v) => (v && v.trim() ? undefined : 'Enter a name'),
      showCancelButton: true,
      confirmButtonText: 'Save',
    })
    if (!isConfirmed) return
    await runCategoryOp(
      () => jsGamesAdminService.renameProviderTab(category, provider, currentSlotCategory.slug, value.trim()),
      'Tab renamed',
    )
  }

  const deleteSlotCategory = async () => {
    if (!currentSlotCategory) return
    const { isConfirmed } = await Swal.fire({
      title: `Delete the "${currentSlotCategory.label}" tab?`,
      html: `Its ${currentSlotCategory.total_games} game(s) stay in ${escapeHtml(currentProvider?.label || 'this provider')} and move to <b>Uncategorized</b>.`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Delete',
      confirmButtonColor: '#f46a6a',
    })
    if (!isConfirmed) return
    const response = await runCategoryOp(
      () => jsGamesAdminService.deleteProviderTab(category, provider, currentSlotCategory.slug),
      'Tab deleted',
    )
    if (response) setSlotCategory(UNCATEGORIZED)
  }

  // Moves the tab in the strip the player sees. The provider's own game order
  // is left alone — the two orderings are independent.
  const moveSlotCategory = async (delta) => {
    const index = slotCategories.findIndex((c) => c.slug === slotCategory)
    const target = index + delta
    if (index < 0 || target < 0 || target >= slotCategories.length) return
    const order = slotCategories.map((c) => c.slug)
    ;[order[index], order[target]] = [order[target], order[index]]
    await runCategoryOp(
      () => jsGamesAdminService.reorderProviderTabs(category, provider, order),
      'Tab order saved',
    )
  }

  // --- Edit modal ---

  const openEdit = (game) => {
    setEditGame(game)
    setEditForm({
      game_name: game.game_name || '',
      game_icon: game.game_icon || '',
      is_active: !!game.is_active,
    })
  }

  const saveEdit = async (e) => {
    e.preventDefault()
    if (!editGame) return
    setEditSaving(true)
    try {
      const response = await jsGamesAdminService.updateGame(editGame.id, {
        game_name: editForm.game_name.trim(),
        game_icon: editForm.game_icon.trim(),
        is_active: editForm.is_active,
      })
      if (response.success) {
        const updated = response.payload.game
        setGames((prev) => prev.map((g) => (g.id === updated.id ? updated : g)))
        setQueue((prev) => prev.map((g) => (g.id === updated.id ? updated : g)))
        Toast.fire({ icon: 'success', title: 'Game updated' })
        setEditGame(null)
      } else {
        Toast.fire({ icon: 'error', title: response.message || 'Update failed' })
      }
    } catch (error) {
      apiError(error)
    } finally {
      setEditSaving(false)
    }
  }

  const toggleActive = async (game) => {
    try {
      const response = await jsGamesAdminService.updateGame(game.id, { is_active: !game.is_active })
      if (response.success) {
        const updated = response.payload.game
        setGames((prev) => prev.map((g) => (g.id === updated.id ? updated : g)))
        setQueue((prev) => prev.map((g) => (g.id === updated.id ? updated : g)))
        Toast.fire({ icon: 'success', title: `${updated.game_name} is now ${updated.is_active ? 'active' : 'inactive'}` })
      } else {
        Toast.fire({ icon: 'error', title: response.message || 'Update failed' })
      }
    } catch (error) {
      apiError(error)
    }
  }

  const handleSearch = (e) => {
    e.preventDefault()
    setPage(1)
    setKeyword(searchInput.trim())
  }

  // Move one game into a provider group — and into one of that group's tabs —
  // from anywhere in the panel. Same rule at both levels: a slot game lives in
  // exactly one group, and in at most one tab of it.
  const openProviderPicker = async (game) => {
    if (providers.length === 0) {
      Toast.fire({ icon: 'info', title: 'Create a provider group on the Slot tab first' })
      return
    }
    const current = gameProvider(game)
    const currentCategory = gameCategory(game)
    const options = providers.map((p) => (
      `<option value="${p.provider}" ${current?.provider === p.provider ? 'selected' : ''}>${escapeHtml(p.label)} (${p.total_games})</option>`
    )).join('')
    const categoryOptions = (slug) => {
      const row = providers.find((p) => p.provider === slug)
      return ['<option value="">— no tab (uncategorized) —</option>'].concat(
        (row?.categories || []).map((c) => `<option value="${c.slug}">${escapeHtml(c.label)} (${c.total_games})</option>`)
      ).join('')
    }

    const { isConfirmed, value } = await Swal.fire({
      title: 'Slot provider group',
      html: `
        <p style="margin:0 0 10px;color:#666;">${escapeHtml(game.game_name)} <small>· #${game.id}</small></p>
        <select id="gp-provider-select" class="swal2-select" style="width:100%;margin:0;">
          <option value="" ${current ? '' : 'selected'}>— no group —</option>
          ${options}
        </select>
        <select id="gp-category-select" class="swal2-select" style="width:100%;margin:8px 0 0;"></select>
        <p style="font-size:12px;color:#999;margin:12px 0 0;">A slot game belongs to one group and at most one of its tabs. Moving it here does not change the order of anything already in that group.</p>`,
      focusConfirm: false,
      showCancelButton: true,
      confirmButtonText: 'Save',
      didOpen: () => {
        const providerSelect = document.getElementById('gp-provider-select')
        const categorySelect = document.getElementById('gp-category-select')
        const sync = () => {
          categorySelect.innerHTML = categoryOptions(providerSelect.value)
          categorySelect.disabled = !providerSelect.value
          categorySelect.value = providerSelect.value === current?.provider ? (currentCategory?.slug || '') : ''
        }
        providerSelect.addEventListener('change', sync)
        sync()
      },
      preConfirm: () => ({
        provider: document.getElementById('gp-provider-select').value,
        category: document.getElementById('gp-category-select').value,
      }),
    })
    if (!isConfirmed) return
    if ((value.provider || '') === (current?.provider || '') &&
        (value.category || '') === (currentCategory?.slug || '')) return

    try {
      const response = await jsGamesAdminService.setGameSlotProvider(
        game.id, value.provider || null, value.category || null, groupCategory,
      )
      if (response.success) {
        const updated = response.payload.game
        setGames((prev) => prev.map((g) => (g.id === updated.id ? updated : g)))
        await fetchProviders(category)
        if (isGrouped) fetchQueue(category, provider, slotCategory, isGrouped)
        Toast.fire({
          icon: 'success',
          title: updated.slot_provider
            ? `Moved to ${updated.slot_provider.label}${updated.slot_category ? ` · ${updated.slot_category.label}` : ''}`
            : 'Removed from its group',
        })
      } else {
        Toast.fire({ icon: 'error', title: response.message || 'Update failed' })
      }
    } catch (error) {
      apiError(error)
    }
  }

  // Pick which categories a game belongs to. Categories are normally derived
  // from game_type; this pins the game into any category regardless of type.
  const openCategoryPicker = async (game) => {
    const current = new Set(game.manual_categories || [])
    const rows = CATEGORIES.map((c) => `
      <label style="display:flex;align-items:center;gap:10px;padding:8px 4px;cursor:pointer;text-transform:capitalize;font-size:15px;">
        <input type="checkbox" class="gp-cat-box" value="${c}" ${current.has(c) ? 'checked' : ''} style="width:16px;height:16px;" />
        ${c}
      </label>`).join('')

    const { isConfirmed, value } = await Swal.fire({
      title: 'Add to categories',
      html: `
        <p style="margin:0 0 8px;color:#666;">${escapeHtml(game.game_name)} <small>· #${game.id}</small></p>
        <div style="text-align:left;max-width:240px;margin:0 auto;">${rows}</div>
        <p style="font-size:12px;color:#999;margin:12px 0 0;">Check to add, uncheck to remove.</p>`,
      focusConfirm: false,
      showCancelButton: true,
      confirmButtonText: 'Save',
      preConfirm: () =>
        Array.from(document.querySelectorAll('.gp-cat-box:checked')).map((el) => el.value),
    })
    if (!isConfirmed) return

    try {
      const response = await jsGamesAdminService.setGameCategories(game.id, value || [])
      if (response.success) {
        const updated = response.payload.game
        setGames((prev) => prev.map((g) => (g.id === updated.id ? updated : g)))
        setQueue((prev) => prev.map((g) => (g.id === updated.id ? { ...g, ...updated } : g)))
        fetchCategories()
        Toast.fire({ icon: 'success', title: 'Categories updated' })
      } else {
        Toast.fire({ icon: 'error', title: response.message || 'Update failed' })
      }
    } catch (error) {
      apiError(error)
    }
  }

  return (
    <div>
      <div className="row">
        <div className="col-12">
          <div className="page-title-box d-flex align-items-center justify-content-between">
            <h4 className="mb-0 font-size-18">Game Priority</h4>
          </div>
        </div>
      </div>

      <ul className="nav nav-tabs mb-3">
        {TABS.map((cat) => (
          <li className="nav-item" key={cat}>
            <button
              type="button"
              className={`nav-link${category === cat ? ' active' : ''}`}
              onClick={() => switchCategory(cat)}
            >
              {cat === CATALOG ? 'All Games' : cat.charAt(0).toUpperCase() + cat.slice(1)}
              {categoryCounts[cat] !== undefined && (
                <span className="badge bg-secondary ms-1">{categoryCounts[cat]}</span>
              )}
            </button>
          </li>
        ))}
      </ul>

      {/* Provider groups — the slot category is ordered provider by provider,
          and the strip order is the order slots appear in the app. */}
      {!isCatalog && (
        <div className="card mb-3">
          <div className="card-body py-2">
            <div className="d-flex align-items-center justify-content-between flex-wrap gap-2">
              <div className="d-flex align-items-center flex-wrap gap-1">
                <span className="text-muted me-2">Providers:</span>
                {providers.map((p) => (
                  <button
                    key={p.provider}
                    type="button"
                    className={`btn btn-sm ${provider === p.provider ? 'btn-primary' : 'btn-outline-secondary'}`}
                    onClick={() => switchProvider(p.provider)}
                  >
                    {p.label}
                    <span className={`badge ms-1 ${provider === p.provider ? 'bg-light text-dark' : 'bg-light text-dark'}`}>
                      {p.total_games}
                    </span>
                  </button>
                ))}
                {ungroupedCount > 0 && (
                  <button
                    type="button"
                    className={`btn btn-sm ${isUngrouped ? 'btn-dark' : 'btn-outline-dark'}`}
                    title="Prioritized slot games that no provider group claims"
                    onClick={() => switchProvider(UNGROUPED)}
                  >
                    Ungrouped
                    <span className="badge bg-light text-dark ms-1">{ungroupedCount}</span>
                  </button>
                )}
              </div>
              <div className="d-flex align-items-center gap-1">
                <button
                  type="button"
                  className="btn btn-sm btn-light"
                  title="Move this provider earlier in the app"
                  disabled={providerBusy || !currentProvider || providers[0]?.provider === provider}
                  onClick={() => moveProvider(-1)}
                >
                  <i className="bx bx-left-arrow-alt"></i>
                </button>
                <button
                  type="button"
                  className="btn btn-sm btn-light"
                  title="Move this provider later in the app"
                  disabled={providerBusy || !currentProvider || providers[providers.length - 1]?.provider === provider}
                  onClick={() => moveProvider(1)}
                >
                  <i className="bx bx-right-arrow-alt"></i>
                </button>
                <button
                  type="button"
                  className="btn btn-sm btn-light"
                  title="Rename provider"
                  disabled={providerBusy || !currentProvider}
                  onClick={renameProvider}
                >
                  <i className="bx bx-pencil"></i>
                </button>
                <button
                  type="button"
                  className="btn btn-sm btn-light text-danger"
                  title="Delete provider group"
                  disabled={providerBusy || !currentProvider}
                  onClick={deleteProvider}
                >
                  <i className="bx bx-trash"></i>
                </button>
                <button
                  type="button"
                  className="btn btn-sm btn-success"
                  disabled={providerBusy}
                  onClick={addProvider}
                >
                  <i className="bx bx-plus"></i> Provider
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Sub-categories of the selected provider — the tab strip the player sees
          after picking that provider. Tab order orders that strip only; the
          provider's curated game order is untouched by it. */}
      {inProviderGroup && (
        <div className="card mb-3">
          <div className="card-body py-2">
            <div className="d-flex align-items-center justify-content-between flex-wrap gap-2">
              <div className="d-flex align-items-center flex-wrap gap-1">
                <span className="text-muted me-2">{currentProvider?.label} tabs:</span>
                {slotCategories.map((c) => (
                  <button
                    key={c.slug}
                    type="button"
                    className={`btn btn-sm ${slotCategory === c.slug ? 'btn-info' : 'btn-outline-info'}`}
                    onClick={() => switchSlotCategory(c.slug)}
                  >
                    {c.label}
                    <span className="badge bg-light text-dark ms-1">{c.total_games}</span>
                  </button>
                ))}
                <button
                  type="button"
                  className={`btn btn-sm ${isUncategorized ? 'btn-dark' : 'btn-outline-dark'}`}
                  title={slotCategories.length
                    ? 'Games in this provider that no tab claims — still live in the app, they just have no tab of their own'
                    : 'This provider has no tabs yet, so its whole list is untabbed'}
                  onClick={() => switchSlotCategory(UNCATEGORIZED)}
                >
                  {slotCategories.length ? 'Uncategorized' : 'All games'}
                  <span className="badge bg-light text-dark ms-1">{uncategorizedCount}</span>
                </button>
                {slotCategories.length === 0 && (
                  <small className="text-muted ms-2">
                    No tabs yet — add one to split this provider the way the app shows it.
                  </small>
                )}
              </div>
              <div className="d-flex align-items-center gap-1">
                <button
                  type="button"
                  className="btn btn-sm btn-light"
                  title="Move this tab earlier in the strip the player sees"
                  disabled={categoryBusy || !currentSlotCategory || slotCategories[0]?.slug === slotCategory}
                  onClick={() => moveSlotCategory(-1)}
                >
                  <i className="bx bx-left-arrow-alt"></i>
                </button>
                <button
                  type="button"
                  className="btn btn-sm btn-light"
                  title="Move this tab later in the strip the player sees"
                  disabled={categoryBusy || !currentSlotCategory || slotCategories[slotCategories.length - 1]?.slug === slotCategory}
                  onClick={() => moveSlotCategory(1)}
                >
                  <i className="bx bx-right-arrow-alt"></i>
                </button>
                <button
                  type="button"
                  className="btn btn-sm btn-light"
                  title="Rename tab"
                  disabled={categoryBusy || !currentSlotCategory}
                  onClick={renameSlotCategory}
                >
                  <i className="bx bx-pencil"></i>
                </button>
                <button
                  type="button"
                  className="btn btn-sm btn-light text-danger"
                  title="Delete tab (its games stay in the provider)"
                  disabled={categoryBusy || !currentSlotCategory}
                  onClick={deleteSlotCategory}
                >
                  <i className="bx bx-trash"></i>
                </button>
                <button
                  type="button"
                  className="btn btn-sm btn-info"
                  disabled={categoryBusy || !currentProvider}
                  onClick={addSlotCategory}
                >
                  <i className="bx bx-plus"></i> Tab
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="row">
        {/* Priority queue (hidden on the catalog tab) */}
        <div className="col-lg-5" style={isCatalog ? { display: 'none' } : {}}>
          <div className="card">
            <div className="card-body">
              <h4 className="card-title mb-1">
                {isGrouped
                  ? isUngrouped
                    ? 'Ungrouped Queue'
                    : `${currentProvider?.label || 'Provider'} · ${currentSlotCategory?.label || (slotCategories.length ? 'Uncategorized' : 'All games')} Queue`
                  : 'Priority Queue'}
                {queueSaving && <small className="text-muted ms-2">saving…</small>}
              </h4>
              <p className="text-muted mb-3">
                {isUngrouped
                  ? 'These slot games are live but belong to no provider group. Pick a provider above, then Add them from the list on the right.'
                  : isUncategorized
                    ? slotCategories.length
                      ? `These games are in ${currentProvider?.label || 'this provider'} but in no tab. They stay live in the app — they just have no tab on the slot page. Position sets their place in the provider's own order; removing one takes it out of the provider entirely.`
                      : 'This provider has no tabs, so this is its whole list. Position 1 shows first — changes save instantly.'
                    : isGrouped
                      ? 'Position 1 shows first inside this tab on the slot page. The strip above orders the tabs themselves. The provider\'s own listing order is separate and is not touched by any of this — changes save instantly.'
                      : 'Position 1 shows first in the app. Type a number or use arrows to reorder — changes save instantly.'}
              </p>
              <div className="table-responsive">
                <table className="table b-table align-middle">
                  <thead>
                    <tr>
                      <th style={{ width: '110px' }}>Position</th>
                      <th>Image</th>
                      <th>Game</th>
                      <th style={{ width: '90px' }}>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {queueLoading ? (
                      <tr><td colSpan="4" className="text-center">Loading...</td></tr>
                    ) : queue.length === 0 ? (
                      <tr>
                        <td colSpan="4" className="text-center text-muted">
                          {isGrouped && !provider
                            ? 'Pick a provider group above'
                            : isGrouped && !isUncategorized
                              ? 'This tab is empty — add games from the list on the right'
                              : 'No games pinned yet — add from the list on the right'}
                        </td>
                      </tr>
                    ) : (
                      queue.map((item, index) => (
                        <tr key={item.id}>
                          <td>
                            <div className="d-flex align-items-center gap-1">
                              <input
                                key={`${item.id}-${index}`}
                                type="number"
                                min="1"
                                max={queue.length}
                                defaultValue={index + 1}
                                className="form-control form-control-sm px-1 text-center"
                                style={{ width: '52px' }}
                                disabled={queueSaving || !queueEditable}
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter') moveToPosition(index, e.target.value)
                                }}
                                onBlur={(e) => {
                                  const parsed = parseInt(e.target.value)
                                  if (!Number.isInteger(parsed)) { e.target.value = index + 1; return }
                                  if (parsed !== index + 1) moveToPosition(index, e.target.value)
                                }}
                              />
                              <button
                                type="button"
                                className="btn btn-sm btn-light px-1 py-0"
                                title="Move up"
                                disabled={queueSaving || !queueEditable || index === 0}
                                onClick={() => moveInQueue(index, -1)}
                              >
                                <i className="bx bx-up-arrow-alt"></i>
                              </button>
                              <button
                                type="button"
                                className="btn btn-sm btn-light px-1 py-0"
                                title="Move down"
                                disabled={queueSaving || !queueEditable || index === queue.length - 1}
                                onClick={() => moveInQueue(index, 1)}
                              >
                                <i className="bx bx-down-arrow-alt"></i>
                              </button>
                            </div>
                          </td>
                          <td>
                            <GameImage game={item} onClick={() => openEdit(item)} />
                          </td>
                          <td>
                            <div className="fw-semibold">{item.game_name}</div>
                            <small className="text-muted">{item.vendor} · #{item.id}</small>
                            {!item.is_active && <span className="badge bg-warning ms-1">inactive</span>}
                            {isUngrouped && (
                              <button
                                type="button"
                                className="btn btn-sm btn-outline-info ms-1 py-0 px-1"
                                title="Put this game in a provider group"
                                onClick={() => openProviderPicker(item)}
                              >
                                <i className="bx bx-collection"></i> Group
                              </button>
                            )}
                            {isUncategorized && slotCategories.length > 0 && (
                              <button
                                type="button"
                                className="btn btn-sm btn-outline-info ms-1 py-0 px-1"
                                title="Put this game in one of this provider's tabs"
                                onClick={() => openProviderPicker(item)}
                              >
                                <i className="bx bx-purchase-tag-alt"></i> Tab
                              </button>
                            )}
                          </td>
                          <td>
                            <button
                              type="button"
                              className="btn btn-sm btn-danger"
                              title={
                                isUncategorized
                                  ? 'Remove from this provider (game becomes ungrouped)'
                                  : isGrouped
                                    ? 'Remove from this tab (game stays in the provider, uncategorized)'
                                    : 'Remove from queue'
                              }
                              disabled={queueSaving || !queueEditable}
                              onClick={() => removeFromQueue(item.id)}
                            >
                              <i className="bx bx-x"></i>
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        {/* All games */}
        <div className={isCatalog ? 'col-12' : 'col-lg-7'}>
          <div className="card">
            <div className="card-body">
              <h4 className="card-title mb-3">
                {isCatalog ? 'Game Catalog' : `All ${category.charAt(0).toUpperCase() + category.slice(1)} Games`}
                <small className="text-muted ms-2">{pagination.total} total</small>
              </h4>

              <form className="row g-2 mb-3" onSubmit={handleSearch}>
                <div className="col-sm-6 col-lg-4">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Search game or vendor..."
                    value={searchInput}
                    onChange={(e) => setSearchInput(e.target.value)}
                  />
                </div>
                <div className="col-sm-6 col-lg-3">
                  <select
                    className="form-select"
                    value={vendor}
                    onChange={(e) => { setPage(1); setVendor(e.target.value) }}
                  >
                    <option value="">All vendors</option>
                    {vendors.map((v) => (
                      <option key={v.vendor} value={v.vendor}>
                        {v.vendor} ({v.game_count})
                      </option>
                    ))}
                  </select>
                </div>
                {showProviderFilter && (
                  <div className="col-sm-6 col-lg-3">
                    <select
                      className="form-select"
                      title="Filter by slot provider group"
                      value={providerFilter}
                      onChange={(e) => { setPage(1); setProviderFilter(e.target.value) }}
                    >
                      <option value="">All provider groups</option>
                      {providers.map((p) => (
                        <option key={p.provider} value={p.provider}>
                          {p.label} ({p.total_games})
                        </option>
                      ))}
                      <option value={UNGROUPED}>Ungrouped ({ungroupedCount})</option>
                      <option value="none">In no group</option>
                    </select>
                  </div>
                )}
                {isCatalog && (
                  <div className="col-sm-6 col-lg-3">
                    <select
                      className="form-select"
                      value={statusFilter}
                      onChange={(e) => { setPage(1); setStatusFilter(e.target.value) }}
                    >
                      <option value="">All statuses</option>
                      <option value="true">Active only</option>
                      <option value="false">Inactive only</option>
                    </select>
                  </div>
                )}
                <div className="col-sm-6 col-lg-2">
                  <button type="submit" className="btn btn-primary w-100">
                    <i className="bx bx-search"></i> Search
                  </button>
                </div>
              </form>

              <div className="table-responsive">
                <table className="table b-table align-middle">
                  <thead>
                    <tr>
                      <th>Image</th>
                      <th>Game</th>
                      <th>Type</th>
                      <th>Status</th>
                      <th style={{ width: isCatalog ? '170px' : '120px' }}>{isCatalog ? 'Action' : 'Priority'}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {gamesLoading ? (
                      <tr><td colSpan="5" className="text-center">Loading...</td></tr>
                    ) : games.length === 0 ? (
                      <tr><td colSpan="5" className="text-center text-muted">No games found</td></tr>
                    ) : (
                      games.map((game) => {
                        const pos = queuePosition(game.id)
                        return (
                          <tr key={game.id}>
                            <td>
                              <GameImage game={game} onClick={() => openEdit(game)} />
                            </td>
                            <td>
                              <div className="fw-semibold">{game.game_name}</div>
                              <small className="text-muted">{game.vendor} · #{game.id}</small>
                              {gameProvider(game) && (
                                <div className="mt-1 d-flex flex-wrap gap-1">
                                  <span
                                    className="badge bg-primary-subtle text-primary border border-primary-subtle"
                                    title="Slot provider group"
                                  >
                                    <i className="bx bx-collection me-1"></i>{gameProvider(game).label}
                                  </span>
                                  {gameCategory(game) && (
                                    <span
                                      className="badge bg-info-subtle text-info border border-info-subtle"
                                      title="Tab inside that provider"
                                    >
                                      <i className="bx bx-purchase-tag-alt me-1"></i>{gameCategory(game).label}
                                    </span>
                                  )}
                                </div>
                              )}
                              {game.manual_categories?.length > 0 && (
                                <div className="mt-1 d-flex flex-wrap gap-1">
                                  {game.manual_categories.map((c) => (
                                    <span
                                      key={c}
                                      className="badge bg-light text-dark border"
                                      style={{ textTransform: 'capitalize' }}
                                      title="Manually added to this category"
                                    >
                                      <i className="bx bx-purchase-tag-alt me-1"></i>{c}
                                    </span>
                                  ))}
                                </div>
                              )}
                            </td>
                            <td><small>{game.game_type}</small></td>
                            <td>
                              <span className={`badge ${game.is_active ? 'bg-success' : 'bg-warning'}`}>
                                {game.is_active ? 'active' : 'inactive'}
                              </span>
                            </td>
                            <td>
                              {isCatalog ? (
                                <div className="d-flex flex-wrap gap-1">
                                  <button
                                    type="button"
                                    className={`btn btn-sm ${game.is_active ? 'btn-outline-warning' : 'btn-outline-success'}`}
                                    title={game.is_active ? 'Hide from app' : 'Show in app'}
                                    onClick={() => toggleActive(game)}
                                  >
                                    {game.is_active ? 'Deactivate' : 'Activate'}
                                  </button>
                                  <button
                                    type="button"
                                    className="btn btn-sm btn-outline-primary"
                                    title="Add to a category (crash, slot, …)"
                                    onClick={() => openCategoryPicker(game)}
                                  >
                                    <i className="bx bx-category"></i>
                                  </button>
                                  <button
                                    type="button"
                                    className="btn btn-sm btn-outline-info"
                                    title="Slot provider group and tab (Jili · Slot Game, …)"
                                    onClick={() => openProviderPicker(game)}
                                  >
                                    <i className="bx bx-collection"></i>
                                  </button>
                                </div>
                              ) : pos >= 0 ? (
                                <span className="badge bg-info">position {pos + 1}</span>
                              ) : isGrouped && gameProvider(game) ? (
                                // Already in another group, or another tab of this
                                // one — adding moves it into the open tab
                                <div className="d-flex flex-column align-items-start gap-1">
                                  <span className="badge bg-light text-dark border" title="Where it sits today">
                                    <i className="bx bx-collection me-1"></i>
                                    {originLabel(game)}
                                  </span>
                                  <button
                                    type="button"
                                    className="btn btn-sm btn-outline-warning"
                                    title={`Move from ${originLabel(game)} into ${currentProvider?.label || 'this group'} · ${currentSlotCategory?.label || 'Uncategorized'}`}
                                    disabled={queueSaving || !queueEditable}
                                    onClick={() => addToQueue(game)}
                                  >
                                    <i className="bx bx-transfer"></i> Move here
                                  </button>
                                </div>
                              ) : (
                                <button
                                  type="button"
                                  className="btn btn-sm btn-outline-primary"
                                  title={
                                    isUngrouped
                                      ? 'Pick a provider group first'
                                      : isGrouped
                                        ? `Add to ${currentProvider?.label || 'this provider'} · ${currentSlotCategory?.label || 'Uncategorized'}`
                                        : 'Add to this queue'
                                  }
                                  disabled={queueSaving || !queueEditable}
                                  onClick={() => addToQueue(game)}
                                >
                                  <i className="bx bx-plus"></i> Add
                                </button>
                              )}
                            </td>
                          </tr>
                        )
                      })
                    )}
                  </tbody>
                </table>
              </div>

              {/* One pagination block for the whole panel (components/Pagination),
                  same as every report — this used to be its own Prev/Next pair. */}
              <div className="d-flex align-items-center justify-content-between">
                <span className="text-muted">
                  Page {pagination.current_page} of {pagination.total_pages || 1}
                </span>
                <Pagination
                  currentPage={page}
                  totalPages={pagination.total_pages || 1}
                  onPageChange={(p) => { if (!gamesLoading) setPage(p) }}
                  wrap={false}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Edit game modal */}
      {editGame && (
        <>
          <div className={`${editEnter.modalClass} d-block`} tabIndex="-1" role="dialog" onClick={editEnter.onBackdropClick}>
            <div className="modal-dialog modal-dialog-centered" role="document">
              <div className="modal-content">
                <form onSubmit={saveEdit}>
                  <div className="modal-header">
                    <h5 className="modal-title">Edit Game #{editGame.id}</h5>
                    <button type="button" className="btn-close" onClick={() => setEditGame(null)}></button>
                  </div>
                  <div className="modal-body">
                    <div className="mb-3">
                      <label className="form-label">Game Name</label>
                      <input
                        type="text"
                        className="form-control"
                        value={editForm.game_name}
                        onChange={(e) => setEditForm((f) => ({ ...f, game_name: e.target.value }))}
                      />
                    </div>
                    <div className="mb-3">
                      <label className="form-label">Image Link</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="https://example.com/game-icon.png"
                        value={editForm.game_icon}
                        onChange={(e) => setEditForm((f) => ({ ...f, game_icon: e.target.value }))}
                      />
                    </div>
                    {editForm.game_icon.trim() && (
                      <div className="mb-3">
                        <label className="form-label">Preview</label>
                        <div>
                          <img
                            src={editForm.game_icon}
                            alt="preview"
                            style={{ maxWidth: '100%', maxHeight: '140px', objectFit: 'contain' }}
                            onError={(e) => { e.target.style.display = 'none' }}
                            onLoad={(e) => { e.target.style.display = '' }}
                          />
                        </div>
                      </div>
                    )}
                    <div className="form-check form-switch">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        id="editGameActive"
                        checked={editForm.is_active}
                        onChange={(e) => setEditForm((f) => ({ ...f, is_active: e.target.checked }))}
                      />
                      <label className="form-check-label" htmlFor="editGameActive">Active (visible in app)</label>
                    </div>
                    <small className="text-muted d-block mt-2">
                      {editGame.vendor} · {editGame.game_type}
                    </small>
                  </div>
                  <div className="modal-footer">
                    <button type="button" className="btn btn-secondary" onClick={() => setEditGame(null)} disabled={editSaving}>
                      Cancel
                    </button>
                    <button type="submit" className="btn btn-primary" disabled={editSaving}>
                      {editSaving ? 'Saving...' : 'Save'}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <div className={editEnter.backdropClass}></div>
        </>
      )}
    </div>
  )
}

export default GamePriorityPanel
