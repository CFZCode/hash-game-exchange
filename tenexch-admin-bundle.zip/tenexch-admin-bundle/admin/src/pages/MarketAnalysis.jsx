// Presentation layer only — data/search/refresh come from useMarketAnalysis.
// DOM mirrors the reference market-analysis page: outer .market-analysis-container
// wraps per-event .market-analysis-container (title link + date, then
// .market-analysis-content > row row5 > col-lg-4 > .market-analysis-content-detail
// > table with th colspan=2 = market name).
import { Link } from 'react-router-dom'
import { useMarketAnalysis } from '../hooks/useMarketAnalysis'

// "-1200.00" → "-1,200", "200.00" → "200", "1.5" → "1.5" (reference uses commas)
function fmtVal(v) {
  const n = parseFloat(v)
  return Number.isNaN(n) ? String(v ?? '') : n.toLocaleString('en-US', { maximumFractionDigits: 2 })
}

// Racing bets are titled "Naas - Oct 11 2026 8:10PM"; the reference shows the
// venue only.
const RACE_TIME_SUFFIX = / - [A-Z][a-z]{2} \d{1,2} \d{4} \d{1,2}:\d{2}\s?[AP]M$/
const displayTitle = (t) => String(t || '').replace(RACE_TIME_SUFFIX, '')

function fmtDate(d) {
  if (!d) return ''
  const dt = new Date(d)
  if (Number.isNaN(dt.getTime())) return String(d)
  const p = (n) => String(n).padStart(2, '0')
  return `${p(dt.getDate())}/${p(dt.getMonth() + 1)}/${dt.getFullYear()} ${p(dt.getHours())}:${p(dt.getMinutes())}:${p(dt.getSeconds())}`
}

// rows come from the API in feed runner order — same as the reference
const MarketBlock = ({ market, colClass = 'col-lg-4' }) => (
  <div className={colClass}>
    <div className="market-analysis-content-detail">
      <table className="table">
        <thead>
          <tr>
            <th colSpan="2">{market.name}</th>
          </tr>
        </thead>
        <tbody>
          {(market.rows || []).map((row) => (
            <tr key={row.label}>
              <td>{row.label}</td>
              <td className="text-right">{fmtVal(row.value)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </div>
)

/* Also rendered by components/MyMarketModal.
 *
 * `inModal` is the modal's own template, which differs from this page's in two
 * places (user's DOM of the reference, 2026-09-23):
 *   · the market columns are `col-md-4`, not `col-lg-4`
 *   · the title is a bare `<a href="javascript:void(0)">…</a>` — no `ma-link`,
 *     no route to game-details
 */
export const MatchBlock = ({ match, inModal = false }) => {
  const title = displayTitle(match.match_title)
  const link = match.sport_id && match.eventid
    ? `/admin/game-details/${match.sport_id}/${match.eventid}`
    : null
  return (
    <div className="market-analysis-container">
      <div className="market-analysis-title">
        <div>
          {inModal
            ? <a href="javascript:void(0)">{title}</a>
            : link
              ? <Link to={link} className="ma-link">{title}</Link>
              : <a href="javascript:void(0)" className="ma-link">{title}</a>}
        </div>
        {' '}
        <div>{fmtDate(match.event_date)}</div>
      </div>
      <div className="market-analysis-content">
        <div className="row row5">
          {(match.markets || []).map((market) => (
            <MarketBlock key={market.name} market={market} colClass={inModal ? 'col-md-4' : 'col-lg-4'} />
          ))}
        </div>
      </div>
    </div>
  )
}

function MarketAnalysis() {
  const { matches, search, setSearch, loading, refresh } = useMarketAnalysis()

  return (
    <div className="market-analysis">
      <div className="row">
        <div className="col-12">
          <div className="page-title-box d-flex align-items-center justify-content-between">
            <h4 className="mb-0 font-size-18">
              Market Analysis
              <a href="javascript:void(0)" title="Refresh Data" className="text-dark pl-2" onClick={refresh}>
                <i className={`fa fa-sync${loading ? ' fa-spin' : ''}`}></i>
              </a>
            </h4>
            <div className="page-title-right">
              <input
                type="text"
                name="searchMarktetText"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search Event"
                className="form-control"
              />
            </div>
          </div>
        </div>
      </div>
      <div className="market-analysis-container">
        {matches.map((match) => (
          <MatchBlock key={match.eventid || match.match_title} match={match} />
        ))}
      </div>
    </div>
  )
}

export default MarketAnalysis
