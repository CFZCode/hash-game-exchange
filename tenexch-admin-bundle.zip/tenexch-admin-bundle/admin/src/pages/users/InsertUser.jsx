import { useState, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useSelector } from 'react-redux'
import Swal from 'sweetalert2'
import userService from '../../services/userService'
import { INSERT_USER_TOAST as T } from '../../utils/insertUserToastMessages'
import LoaderOverlay from '../../components/LoaderOverlay'

const ROLES = {
  OWNER: { id: 1, name: 'OWNER', label: 'Owner' },
  COMPANY: { id: 2, name: 'COMPANY', label: 'Company' },
  SUPERADMIN: { id: 3, name: 'SUPERADMIN', label: 'Super Admin' },
  ADMIN: { id: 4, name: 'ADMIN', label: 'Admin' },
  SUPERMASTER: { id: 5, name: 'SUPERMASTER', label: 'Super Master' },
  MASTER: { id: 6, name: 'MASTER', label: 'Master' },
  AGENT: { id: 7, name: 'AGENT', label: 'Agent' },
  USER: { id: 8, name: 'USER', label: 'User' }
}

function InsertUser() {
  const { user, role } = useSelector((state) => state.auth)

  const navigate = useNavigate()
  const [formData, setFormData] = useState({
    username: '',
    fullname: '',
    password: '',
    cpassword: '',
    city: '',
    mono: '',
    camt: '',
    newlvlno: '0',
    point: '1',
    remark: '',
    mpassword: '',
    // "Change Password Lock" toggle — ON means the new account is LOCKED out of
    // changing its own password, so it is sent inverted as
    // passwordChangeAllowed.
    changePasswordLock: false
  })
  const [errors, setErrors] = useState({})
  const [submitted, setSubmitted] = useState(false)
  const [loading, setLoading] = useState(false)
  const [availableRoles, setAvailableRoles] = useState([])
  // Live username availability: idle | checking | available | taken
  const [nameCheck, setNameCheck] = useState('idle')

  const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: false,
  })

  useEffect(() => {
    try {
      let roleId = null
      if (role === 'owner') {
        roleId = ROLES.OWNER.id
      } else if (user) {
        if (user.role_id) {
          roleId = parseInt(user.role_id)
        } else if (user.user_type || user.role) {
          const roleStr = (user.user_type || user.role).toUpperCase()
          const foundRole = Object.values(ROLES).find(r => r.name === roleStr)
          if (foundRole) roleId = foundRole.id
        }
      }
      if (roleId) {
        const allowed = Object.values(ROLES).filter(r => r.id > roleId)
        setAvailableRoles(allowed)
      }
    } catch (error) {
      console.error('Error parsing user role:', error)
    }
  }, [user, role])

  // Debounced live availability check (users + staff + owners) from 3 chars.
  // Cleanup aborts the in-flight request on every keystroke, so a stale
  // response can never overwrite the result for the current value.
  useEffect(() => {
    const name = formData.username
    // A value the format rule rejects is never "available" — the red
    // alpha-numeric message owns the field. Untrimmed on purpose: the
    // trim used to turn "Punjabb " into an available "Punjabb".
    if (name.length < 3 || !/^[a-zA-Z0-9]+$/.test(name)) {
      setNameCheck('idle')
      return
    }
    const controller = new AbortController()
    const timer = setTimeout(async () => {
      setNameCheck('checking')
      try {
        // 200 = available, 202 = taken
        const res = await userService.checkUsername(name, controller.signal)
        setNameCheck(res.status === 200 ? 'available' : 'taken')
      } catch {
        if (!controller.signal.aborted) setNameCheck('idle')
      }
    }, 350)
    return () => {
      clearTimeout(timer)
      controller.abort()
    }
  }, [formData.username])

  // Reference (vee-validate) texts — validated live on change/blur + submit
  const validateField = (name, value, all = formData) => {
    switch (name) {
      case 'username':
        if (!value.trim()) return 'The User Name field is required'
        // vee-validate alpha_num, on the RAW value: "Punjabb " (trailing space)
        // must fail exactly as the reference fails it. Trimming first hid the
        // space, so it read as available (user, 2026-09-16).
        if (!/^[a-zA-Z0-9]+$/.test(value)) return 'The User Name field may only contain alpha-numeric characters'
        if (value.length < 4) return 'The User Name field must be at least 4 characters'
        return ''
      case 'fullname':
        if (!value.trim()) return 'The Full Name field is required'
        if (value.trim().length < 4) return 'The Full Name field must be at least 4 characters'
        return ''
      case 'password':
        if (!value) return 'The Password field is required'
        if (value.length < 8) return 'The Password field must be at least 8 characters'
        if (!/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(value)) return 'The password must contain at least: 1 uppercase letter, 1 lowercase letter, 1 number'
        return ''
      case 'cpassword':
        if (!value) return 'The Confirm Password field is required'
        if (value !== all.password) return 'The Confirm Password confirmation does not match'
        return ''
      case 'city':
        if (value && value.length < 3) return 'The City field must be at least 3 characters'
        return ''
      case 'mono':
        // vee-validate `numeric|min:10`, on the RAW value like username above:
        // "123 4567890" or a trailing space from the phone keyboard must fail
        // with the numeric message, as the reference does (user, 2026-09-18).
        if (value && !/^\d+$/.test(value)) return 'The Mobile Number field may only contain numeric characters'
        if (value && value.length < 10) return 'The Mobile Number field must be at least 10 characters'
        return ''
      case 'point':
        // vee-validate `required|min_value:0.001` like the reference (user,
        // 2026-09-18). users/staff.percentage are DECIMAL(8,3) so 0.001 keeps.
        if (String(value).trim() === '') return 'The User Rate field is required'
        if (!/^\d*\.?\d+$/.test(String(value).trim()) || parseFloat(value) < 0.001) return 'The User Rate field must be 0.001 or more'
        return ''
      case 'mpassword':
        // Red outline only — the reference shows no message under this field
        if (!value) return 'required'
        return ''
      default:
        return ''
    }
  }

  const REQUIRED_FIELDS = ['username', 'fullname', 'password', 'cpassword', 'mpassword', 'city', 'mono', 'point']

  const validate = () => {
    const newErrors = {}
    for (const f of REQUIRED_FIELDS) {
      const msg = validateField(f, formData[f])
      if (msg) newErrors[f] = msg
    }
    return newErrors
  }

  const handleChange = (e) => {
    const { name, type, value, checked } = e.target
    const next = { ...formData, [name]: type === 'checkbox' ? checked : value }
    // The lock toggle only exists for User accounts; switching the type away
    // from User hides it, so clear it too or a stale ON would be submitted.
    if (name === 'newlvlno' && parseInt(value) !== ROLES.USER.id) {
      next.changePasswordLock = false
    }
    setFormData(next)
    if (!REQUIRED_FIELDS.includes(name)) return
    setErrors(prev => {
      const updated = { ...prev, [name]: validateField(name, value, next) }
      // Password change can fix/break the confirm-password match
      if (name === 'password' && next.cpassword) {
        updated.cpassword = validateField('cpassword', next.cpassword, next)
      }
      return updated
    })
  }

  const handleBlur = (e) => {
    const { name, value } = e.target
    if (!REQUIRED_FIELDS.includes(name)) return
    setErrors(prev => ({ ...prev, [name]: validateField(name, value) }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (loading) return
    setSubmitted(true)

    /* Duplicate username is checked FIRST, before any other validation, with a
       FRESH server answer — not the debounced live check, which may still be
       in flight (paste + Submit) or stale (someone else created the name in
       between). Taken → the reference's toast, and the field turns red; the
       form does not go further. A check that fails on the wire falls through:
       the create routes reject a duplicate on their own (400/409). */
    const name = formData.username
    if (/^[a-zA-Z0-9]+$/.test(name) && name.length >= 3) {
      setLoading(true)
      let taken = nameCheck === 'taken'
      let msg = ''
      try {
        const res = await userService.checkUsername(name)
        taken = res.status === 202
        // The toast text is the server's (constants/messages.js
        // ADMIN.USERS.USERNAME_EXISTS); the local string is only a fallback.
        msg = res.data?.message || ''
      } catch { /* wire failure — the server guard on create still stands */ }
      setLoading(false)
      if (taken) {
        setNameCheck('taken')
        Toast.fire({ icon: 'error', text: msg || T.USERNAME_EXISTS })
        return
      }
    }

    const newErrors = validate()
    if (!newErrors.username && nameCheck === 'taken') {
      newErrors.username = 'User Name is not available'
    }
    setErrors(newErrors)
    if (Object.keys(newErrors).length > 0) return

    setLoading(true)
    try {
      let response
      const selectedRoleId = parseInt(formData.newlvlno)

      if (selectedRoleId === ROLES.USER.id) {
        response = await userService.createUser({
          username: formData.username,
          // The form's Full Name and City were never sent, so every account
          // created here had fullname/city NULL — blank in More → Additional
          // Information and in the User List export (user, 2026-09-18). The
          // controller (create-under-parent) has always accepted both.
          fullname: formData.fullname,
          city: formData.city,
          email: formData.username + '@gmail.com',
          password: formData.password,
          // Mobile is optional on the form and nullable on the model — send
          // what was typed, not the old '1234567890' placeholder that then
          // showed up as a real number in More → Additional Information.
          phone_number: formData.mono || null,
          // The form has no country field; this used to send the CITY here.
          country: 'India',
          transactionPassword: formData.mpassword,
          credit_ref: formData.camt || 0,
          // User Rate was only sent for staff, so every player saved 0 and the
          // list showed "0 Pt" whatever was typed (user, 2026-09-18).
          percentage: parseFloat(formData.point) || 0,
          passwordChangeAllowed: !formData.changePasswordLock
        })
      } else {
        const targetRole = Object.values(ROLES).find(r => r.id === selectedRoleId)
        // No local guard here. An unpicked / unknown User Type is the SERVER's
        // call and it answers with the reference's own "Select Proper User
        // type" (createStaff). The guard that used to sit here threw an
        // invented 'Invalid role selected', and THAT is the string the toast
        // showed — never the reference text (user, 2026-09-21). Sending the
        // raw select value keeps one source of truth for the wording.

        response = await userService.createStaff({
          username: formData.username,
          email: formData.username + '@gmail.com',
          password: formData.password,
          role: targetRole ? targetRole.name : String(formData.newlvlno ?? '').trim(),
          fullname: formData.fullname, // same gap as createUser above
          percentage: parseFloat(formData.point) || 0,
          transactionPassword: formData.mpassword,
          phone_number: formData.mono,
          city: formData.city,
          // Blank Credit Amount means 0, same as the player path above —
          // sending '' made the server's parseFloat produce NaN.
          credit_ref: formData.camt || 0,
          passwordChangeAllowed: !formData.changePasswordLock
        })
      }

      if (response.success || response.message === 'User created successfully' || response.id) {
        if (response.creditSkipped) {
          // Created with 0 credit — parent was short; server sends the
          // message with the parent's actual balance. Longer timer: long text.
          Toast.fire({ icon: 'success', text: response.message, timer: 6000 })
        } else {
          Toast.fire({ icon: 'success', text: T.INSERTED })
        }
        // Account created — straight to Active Users (user, 2026-09-16).
        // Restored 2026-09-17: commit e17d4ae6 set this and the merge
        // 5fdc82a7 resolved the file back to /admin/users.
        navigate('/admin/activeusers')
      } else {
        Toast.fire({ icon: 'error', text: response.message || 'Unknown error' })
      }
    } catch (error) {
      // A User Type the ROLES table does not know: if the request died before
      // the server could answer (offline, 5xx with no body) fall back to the
      // same wording the server would have sent, never to an axios string.
      const pickedId = parseInt(formData.newlvlno)
      const roleUnknown = pickedId !== ROLES.USER.id
        && !Object.values(ROLES).find(r => r.id === pickedId)
      const msg = error.response?.data?.error || error.response?.data?.message
        || (roleUnknown ? T.SELECT_PROPER_USER_TYPE : error.message)
      // The server's own duplicate guard (a race with the check above) sends
      // the same text; it goes in the toast body like the check does.
      if (/user ?name already exists/i.test(msg)) {
        setNameCheck('taken')
        Toast.fire({ icon: 'error', text: msg })
        return
      }
      // Reference toast puts the message in the BODY (swal2-html-container) with
      // the title hidden — same as the duplicate-username toast above, so
      // "creditamount is invalid." / "Select Proper User type" read the same
      // way (reference DOM, user 2026-09-21).
      Toast.fire({ icon: 'error', text: msg })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div>
      {loading && <LoaderOverlay />}
      <div>
        {/* Page Title / Breadcrumb */}
        <div className="row">
          <div className="col-12">
            <div className="page-title-box d-flex align-items-center justify-content-between">
              <h4 className="mb-0 font-size-18">Create Account</h4>
              <div className="page-title-right">
                <ol className="breadcrumb m-0">
                  <li className="breadcrumb-item"><Link to="/admin/home">Home</Link></li>
                  <li className="breadcrumb-item"><Link to="/admin/activeusers">Users</Link></li>
                  <li className="breadcrumb-item active"><span aria-current="location">Create Account</span></li>
                </ol>
              </div>
            </div>
          </div>
        </div>

        {/* Form */}
        <form method="post" onSubmit={handleSubmit}>
          <div className="row">
            {/* Left Column - General Information */}
            <div className="col-md-6">
              <div className="card">
                <div className="card-body">
                  <h4 className="card-title">General Information</h4>

                  <div className="form-group">
                    <label>User name: <span className="text-danger">*</span></label>
                    <input placeholder="User Name" type="text" name="username" data-vv-as="User Name" autoComplete="new-password" className={`form-control animation${nameCheck === 'taken' || errors.username ? ' is-invalid' : nameCheck === 'available' ? ' is-valid' : ''}`} aria-required="true" aria-invalid={nameCheck === 'taken' || errors.username ? 'true' : 'false'} value={formData.username} onChange={handleChange} onBlur={handleBlur} />
                    {/* Only the FAILURE case gets a line of text. When the name
                        is free the green border + tick say it already, so no
                        "User Name is available" message (user, 2026-09-21). */}
                    {nameCheck === 'taken'
                      ? <small className="error">User Name is not available</small>
                      : errors.username
                        ? <small className="error">{errors.username}</small>
                        : null}
                  </div>

                  <div className="form-group">
                    <label>Full Name: <span className="text-danger">*</span></label>
                    <input placeholder="Full Name" data-vv-as="Full Name" type="text" name="fullname" className={`form-control animation${errors.fullname ? ' is-invalid' : ''}`} aria-required="true" aria-invalid={errors.fullname ? 'true' : 'false'} value={formData.fullname} onChange={handleChange} onBlur={handleBlur} />
                    {errors.fullname && <small className="error">{errors.fullname}</small>}
                  </div>

                  <div className="form-group">
                    <label>Password: <span className="text-danger">*</span></label>
                    <input placeholder="Password" type="password" data-vv-as="Password" name="password" className={`form-control animation${errors.password ? ' is-invalid' : ''}`} aria-required="true" aria-invalid={errors.password ? 'true' : 'false'} value={formData.password} onChange={handleChange} onBlur={handleBlur} />
                    {errors.password && <small className="error">{errors.password}</small>}
                  </div>

                  <div className="form-group">
                    <label>Confirm Password: <span className="text-danger">*</span></label>
                    <input placeholder="Confirm Password" type="password" data-vv-as="Confirm Password" name="cpassword" className={`form-control animation${errors.cpassword ? ' is-invalid' : ''}`} aria-required="true" aria-invalid={errors.cpassword ? 'true' : 'false'} value={formData.cpassword} onChange={handleChange} onBlur={handleBlur} />
                    {errors.cpassword && <small className="error">{errors.cpassword}</small>}
                  </div>

                  <div className="form-group">
                    <label>City:</label>
                    <input placeholder="City" type="text" data-vv-as="City" name="city" className={`form-control animation${errors.city ? ' is-invalid' : ''}`} aria-required="false" aria-invalid={errors.city ? 'true' : 'false'} value={formData.city} onChange={handleChange} onBlur={handleBlur} />
                    {errors.city && <small className="error">{errors.city}</small>}
                  </div>

                  <div className="form-group">
                    <label>Mobile Number:</label>
                    <input placeholder="Mobile Number" type="text" data-vv-as="Mobile Number" name="mono" maxLength="15" className={`form-control animation${errors.mono ? ' is-invalid' : ''}`} aria-required="false" aria-invalid={errors.mono ? 'true' : 'false'} value={formData.mono} onChange={handleChange} onBlur={handleBlur} />
                    {errors.mono && <small className="error">{errors.mono}</small>}
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column - Account Details */}
            <div className="col-md-6">
              <div className="card">
                <div className="card-body">
                  <div className="form-group">
                    <label>Credit Amount:</label>
                    <input placeholder="Credit Amount" type="number" name="camt" className="form-control" aria-required="false" aria-invalid="false" value={formData.camt} onChange={handleChange} />
                  </div>

                  <div className="form-group tag-select">
                    <label>User Type: <span className="text-danger">*</span></label>
                    <select name="newlvlno" className="form-control" aria-required="true" aria-invalid="false" value={formData.newlvlno} onChange={handleChange}>
                      <option value="0">Select User Type</option>
                      {availableRoles.map(r => (
                        <option key={r.id} value={r.id}>{r.label}</option>
                      ))}
                    </select>
                  </div>

                  <h4 className="card-title">Partnership Information</h4>

                  <div>
                    <div className="form-group">
                      <label>User Rate:</label>
                      <input placeholder="User Rate" type="text" name="point" className={`form-control animation${errors.point ? ' is-invalid' : ''}`} aria-required="true" aria-invalid={errors.point ? 'true' : 'false'} value={formData.point} onChange={handleChange} onBlur={handleBlur} />
                      {errors.point && <small className="error">{errors.point}</small>}
                    </div>
                  </div>

                  <div className="form-group">
                    <label>Remark:</label>
                    <textarea placeholder="Remark" name="remark" className="form-control" aria-required="false" aria-invalid="false" value={formData.remark} onChange={handleChange}></textarea>
                  </div>

                  {/* ON = this account is locked out of changing its own password.
                      Sent inverted, as passwordChangeAllowed. User accounts only. */}
                  {parseInt(formData.newlvlno) === ROLES.USER.id && (
                    <div className="form-group custom-control custom-switch">
                      <input type="checkbox" className="custom-control-input" id="changePasswordLock" name="changePasswordLock" checked={formData.changePasswordLock} onChange={handleChange} />
                      <label className="custom-control-label font-weight-bold" htmlFor="changePasswordLock">Change Password Lock</label>
                    </div>
                  )}

                  <div className="d-flex justify-content-end align-items-center">
                    <input placeholder="Transaction Code" type="password" name="mpassword" className={`form-control${errors.mpassword ? ' is-invalid' : ''}`} aria-required="true" aria-invalid={errors.mpassword ? 'true' : 'false'} value={formData.mpassword} onChange={handleChange} onBlur={handleBlur} />
                    <button type="submit" id="spinner-dark-8" className="btn btn-primary ml-2">Submit</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  )
}

export default InsertUser
