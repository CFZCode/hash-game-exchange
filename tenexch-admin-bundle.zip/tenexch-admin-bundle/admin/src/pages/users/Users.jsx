import { useState, useEffect, useCallback, useRef } from 'react'
import { Link, useParams, useSearchParams } from 'react-router-dom'
import userService from '../../services/userService'
import walletService from '../../services/walletService'
import DepositModal from '../../components/DepositModal'
import WithdrawModal from '../../components/WithdrawModal'
import MoreModal from '../../components/MoreModal'
import CreditActivityModal from '../../components/CreditActivityModal'
import Tooltip from '../../components/Tooltip'
import Swal from 'sweetalert2'
import LoaderOverlay from '../../components/LoaderOverlay'
import useExportLoader from '../../hooks/useExportLoader'
import { exportUserListExcel, exportUserListPDF } from '../../utils/userListExport'
import Pagination from '../../components/Pagination'

const Toast = Swal.mixin({
  toast: true,
  position: 'top-end',
  showConfirmButton: false,
  timer: 3000,
  timerProgressBar: false,
})


// Display labels for account types (API sends uppercase e.g. "SUPERMASTER")
const ACCOUNT_TYPE_LABELS = {
  USER: 'User',
  AGENT: 'Agent',
  MASTER: 'Master',
  SUPERMASTER: 'SuperMaster',
  SUPERADMIN: 'SuperAdmin',
  COMPANY: 'Company',
  ADMIN: 'Admin',
  STAFF: 'Staff',
}
const formatAccountType = (t) => {
  const key = String(t || '').toUpperCase()
  if (ACCOUNT_TYPE_LABELS[key]) return ACCOUNT_TYPE_LABELS[key]
  // Fallback: Capitalize first letter only
  const s = String(t || '')
  return s ? s.charAt(0).toUpperCase() + s.slice(1).toLowerCase() : s
}

function Users() {
  // /admin/users/:parentId → list that staff's direct downline instead of our own
  const { parentId } = useParams()
  // ?search=<username> — the header's Search User pick lands here with the
  // list already filtered (components/HeaderUserSearch → Layout).
  const [searchParams] = useSearchParams()
  const urlSearch = searchParams.get('search') || ''
  const [searchKey, setSearchKey] = useState(urlSearch)
  // Excel button: page loader for a second, then the download (hooks/useExportLoader)
  const { exporting, withExportLoader } = useExportLoader()
  const [pageSize, setPageSize] = useState(25)
  const [currentPage, setCurrentPage] = useState(1)
  const [users, setUsers] = useState([])
  const [totalPages, setTotalPages] = useState(1)
  const [loading, setLoading] = useState(false)

  // Reference toast text for an invalid transaction code
  const apiErrorText = (msg) => {
    if (/transaction (password|code) (invalid|not valid)/i.test(msg || '')) {
      return 'Master Password not valid.'
    }
    return msg || 'Something went wrong'
  }

  const [selectedAccount, setSelectedAccount] = useState(null)
  const [showDepositModal, setShowDepositModal] = useState(false)
  const [showWithdrawModal, setShowWithdrawModal] = useState(false)
  const [showMoreModal, setShowMoreModal] = useState(false)
  const [showCreditModal, setShowCreditModal] = useState(false)

  const fetchUsers = useCallback(async (page, limit, search) => {
    setLoading(true)
    try {
      const data = await userService.getAllDetails(page, limit, search, { parentId })
      if (data.success && data.data && data.data.wallets) {
        setUsers(data.data.wallets)
        // API `data.pagination.total_pages` bhejti hai; `data.total` kabhi tha hi
        // nahi — fallback wallets.length par girta tha aur ceil(limit/limit) hamesha
        // 1 deta tha, isliye next/last buttons permanently disabled the.
        setTotalPages(data.data.pagination?.total_pages || 1)
      } else {
        setUsers([])
        setTotalPages(1)
      }
    } catch (err) {
      console.error('Error fetching users:', err)
      setUsers([])
      setTotalPages(1)
      Toast.fire({
        icon: 'error',
        text: err.response?.data?.message || 'Failed to load users',
      })
    } finally {
      setLoading(false)
    }
  }, [parentId])

  const lastParentId = useRef(parentId)

  // A new header pick while already on this page changes only the query
  // string — re-run the search for it.
  const lastUrlSearch = useRef(urlSearch)
  useEffect(() => {
    if (lastUrlSearch.current === urlSearch) return
    lastUrlSearch.current = urlSearch
    setSearchKey(urlSearch)
    setCurrentPage(1)
    fetchUsers(1, pageSize, urlSearch)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [urlSearch])

  useEffect(() => {
    // Switching downline in the same tab restarts from page 1
    if (lastParentId.current !== parentId) {
      lastParentId.current = parentId
      if (currentPage !== 1) {
        setCurrentPage(1)
        return
      }
    }
    fetchUsers(currentPage, pageSize, searchKey)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentPage, pageSize, parentId])

  const handleLoad = (e) => {
    e.preventDefault()
    setCurrentPage(1)
    fetchUsers(1, pageSize, searchKey)
  }

  const handleReset = () => {
    setSearchKey('')
    setCurrentPage(1)
    fetchUsers(1, pageSize, '')
  }

  const handlePageSizeChange = (e) => {
    setPageSize(Number(e.target.value))
    setCurrentPage(1)
  }

  const handlePageChange = (page) => {
    if (page < 1 || page > totalPages) return
    setCurrentPage(page)
  }

  const formatNum = (val) => {
    const n = parseFloat(val)
    if (isNaN(n)) return '0'
    return n.toLocaleString()
  }

  const handleDepositClick = (account) => {
    setSelectedAccount(account)
    setShowDepositModal(true)
  }

  const handleWithdrawClick = (account) => {
    setSelectedAccount(account)
    setShowWithdrawModal(true)
  }

  // More → Additional Information reads the account fresh instead of trusting
  // the list row: the row is a wallet join and carries whatever the list query
  // selected, while this endpoint returns the profile itself. Bound to the
  // page loader, so the modal never opens on half-filled data.
  const handleMoreClick = async (account) => {
    const accountType = account?.user_id ? 'USER' : 'STAFF'
    const id = account?.user_id || account?.staff_id
    if (!id) { setSelectedAccount(account); setShowMoreModal(true); return }

    setLoading(true)
    try {
      const res = await userService.getAccountDetails(accountType, id)
      // Keep the row's own numbers as the base so nothing the modal already
      // shows can go missing if the endpoint omits a field.
      setSelectedAccount(res?.success && res.data ? { ...account, ...res.data } : account)
    } catch {
      // A failed lookup must not block the panel — fall back to the row.
      setSelectedAccount(account)
    } finally {
      setLoading(false)
      setShowMoreModal(true)
    }
  }

  const refresh = () => fetchUsers(currentPage, pageSize, searchKey)

  // Credit Activity does its own API call inside the modal; all this page owes
  // it is the list refetch (the header balance is refreshed by the modal).
  // Toast text comes from the server ("Sucessfull Balance Transfer" on a
  // deposit — reference wording); the local strings are only the fallback.
  const handleCreditSuccess = (mode, message) => {
    Toast.fire({
      icon: 'success',
      text: message || (mode === 'withdraw' ? 'Credit withdraw successful!' : 'Credit deposit successful!'),
    })
    refresh()
  }

  const handleDepositSubmit = async ({ amount, remark, transactionPassword }) => {
    setLoading(true)
    try {
      // Deposit = settlement me dena -> points positive
      const payload = {
        userId: selectedAccount.user_id || selectedAccount.staff_id,
        username: selectedAccount.username,
        points: Math.abs(amount),
        remark,
        transactionPassword,
      }
      const response = await walletService.settlePoints(payload)
      if (response.success) {
        Toast.fire({ icon: 'success', text: 'Deposit successful!' })
        setShowDepositModal(false)
        refresh()
      } else {
        Toast.fire({ icon: 'error', text: apiErrorText(response.message) })
      }
    } catch (error) {
      Toast.fire({ icon: 'error', text: apiErrorText(error.response?.data?.message || error.message) })
    } finally {
      setLoading(false)
    }
  }

  const handleWithdrawSubmit = async ({ amount, remark, transactionPassword }) => {
    setLoading(true)
    try {
      // Withdraw = settlement me lena -> points hamesha negative
      const payload = {
        userId: selectedAccount.user_id || selectedAccount.staff_id,
        username: selectedAccount.username,
        points: -Math.abs(amount),
        remark,
        transactionPassword,
      }
      const response = await walletService.settlePoints(payload)
      if (response.success) {
        Toast.fire({ icon: 'success', text: 'Withdraw successful!' })
        setShowWithdrawModal(false)
        refresh()
      } else {
        Toast.fire({ icon: 'error', text: apiErrorText(response.message) })
      }
    } catch (error) {
      Toast.fire({ icon: 'error', text: apiErrorText(error.response?.data?.message || error.message) })
    } finally {
      setLoading(false)
    }
  }

  const handleMoreChangePassword = async ({ newPassword, transactionPassword }) => {
    setLoading(true)
    try {
      const isUser = selectedAccount.user_type === 'USER'
      const payload = {
        user_type: isUser ? 'USER' : 'STAFF',
        [isUser ? 'user_id' : 'staff_id']: selectedAccount.user_id || selectedAccount.staff_id,
        newPassword,
        transactionPassword,
      }
      const response = await userService.updateStatusAndPassword(payload)
      if (response.success) {
        Toast.fire({ icon: 'success', text: 'Password change successful.' })
        setShowMoreModal(false)
      } else {
        Toast.fire({ icon: 'error', text: apiErrorText(response.message) })
      }
    } catch (error) {
      Toast.fire({ icon: 'error', text: apiErrorText(error.response?.data?.message || error.message) })
    } finally {
      setLoading(false)
    }
  }

  const handleMoreUserLock = async ({ betLock, userLock, transactionPassword }) => {
    setLoading(true)
    try {
      const isUser = selectedAccount.user_type === 'USER'
      const payload = {
        user_type: isUser ? 'USER' : 'STAFF',
        [isUser ? 'user_id' : 'staff_id']: selectedAccount.user_id || selectedAccount.staff_id,
        bet_lock: betLock,
        ...(isUser ? { status: userLock ? 'InActive' : 'Active' } : { active: !userLock }),
        transactionPassword,
      }
      const response = await userService.updateStatusAndPassword(payload)
      if (response.success) {
        Toast.fire({ icon: 'success', text: 'Status updated successfully' })
        setShowMoreModal(false)
        refresh()
      } else {
        Toast.fire({ icon: 'error', text: apiErrorText(response.message) })
      }
    } catch (error) {
      Toast.fire({ icon: 'error', text: apiErrorText(error.response?.data?.message || error.message) })
    } finally {
      setLoading(false)
    }
  }

  const handleMoreEditProfile = async ({ fullName, transactionPassword }) => {
    setLoading(true)
    try {
      const isUser = selectedAccount.user_type === 'USER'
      const payload = {
        user_type: isUser ? 'USER' : 'STAFF',
        [isUser ? 'user_id' : 'staff_id']: selectedAccount.user_id || selectedAccount.staff_id,
        full_name: fullName,
        transactionPassword,
      }
      const response = await userService.updateStatusAndPassword(payload)
      if (response.success) {
        Toast.fire({ icon: 'success', text: 'Profile updated' })
        setShowMoreModal(false)
        refresh()
      } else {
        // Edit Profile shows the backend's own text — the reference toasts
        // "transaction code not valid. You have 9attempt left" here, not the
        // "Master Password not valid." the D/W flows use (user, 2026-09-18).
        Toast.fire({ icon: 'error', text: response.message || 'Something went wrong' })
      }
    } catch (error) {
      Toast.fire({ icon: 'error', text: error.response?.data?.message || error.message || 'Something went wrong' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      {(loading || exporting) && <LoaderOverlay />}
      {/* Reference wraps the page in two nested divs */}
      <div data-v-5a10e370="">
        <div data-v-5a10e370="">
          <div className="row">
            <div className="col-12">
              <div className="page-title-box d-flex align-items-center justify-content-between">
                <h4 className="mb-0 font-size-18">Account List</h4>
                <div className="page-title-right">
                  <ol className="breadcrumb m-0">
                    <li className="breadcrumb-item">
                      <Link to="/admin/home" className="" target="_self">Home</Link>
                    </li>
                    <li className="breadcrumb-item active">
                      <span aria-current="location">Account List</span>
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>

          <div className="row account-list">
            <div className="col-12">
              <div className="card">
                <div className="card-body">
                  <div className="row row5">
                    <div className="col-md-6 mb-2 search-form">
                      <form method="post" className="ajaxFormSubmit" onSubmit={handleLoad}>
                        <div className="d-inline-block form-group form-group-feedback form-group-feedback-right">
                          <input
                            type="text"
                            name="searchKey"
                            placeholder="Search User"
                            className="form-control"
                            value={searchKey}
                            onChange={(e) => setSearchKey(e.target.value)}
                          />
                        </div>{' '}
                        <div className="d-inline-block">
                          <button type="submit" id="submit" className="btn btn-primary">
                            Load
                          </button>{' '}
                          <button type="button" id="reset" className="btn btn-light" onClick={handleReset}>
                            Reset
                          </button>
                        </div>
                      </form>
                    </div>
                    <div className="col-md-6 text-right mb-2">
                      <div className="d-inline-block mr-2">
                        <div id="export_1776252131398" className="d-inline-block">
                          <button type="button" disabled={users.length === 0} className={`btn mr-1 btn-success${users.length === 0 ? ' disabled' : ''}`} onClick={withExportLoader(() => exportUserListExcel(users, { formatAccountType }))}>
                            <i className="fas fa-file-excel"></i>
                          </button>
                        </div>{' '}
                        <button type="button" disabled={users.length === 0} className={`btn btn-danger${users.length === 0 ? ' disabled' : ''}`} onClick={() => exportUserListPDF(users, { formatAccountType })}>
                          <i className="fas fa-file-pdf"></i>
                        </button>
                      </div>{' '}
                      <div className="d-inline-block">
                        <Link to="/admin/users/insertuser" className="btn btn-success">
                          <i aria-hidden="true" className="fa fa-plus"></i> CREATE
                          ACCOUNT
                        </Link>
                      </div>
                    </div>
                  </div>

                  <div className="row">
                    <div className="col-sm-12 col-md-6">
                      <div id="tickets-table_length" className="dataTables_length">
                        <label className="d-inline-flex align-items-center">
                          Show&nbsp;
                          <select
                            className="custom-select custom-select-sm"
                            id="__BVID__2954"
                            value={pageSize}
                            onChange={handlePageSizeChange}
                          >
                            <option value="25">25</option>
                            <option value="50">50</option>
                            <option value="100">100</option>
                            <option value="250">250</option>
                            <option value="500">500</option>
                            <option value="750">750</option>
                            <option value="1000">1000</option>
                          </select>&nbsp;entries
                        </label>
                      </div>
                    </div>
                  </div>

                  <div className="table-responsive mb-0">
                    <div className="table no-footer table-responsive-sm">
                      <table
                        id="eventsListTbl"
                        role="table"
                        aria-busy="false"
                        aria-colcount="7"
                        className="table b-table"
                      >
                        <thead role="rowgroup" className="">
                          <tr role="row" className="">
                            <th role="columnheader" scope="col" tabIndex="0" aria-colindex="1" aria-sort="none" className="position-relative">
                              <div>User Name</div>
                              <span className="sr-only"> (Click to sort ascending)</span>
                            </th>
                            <th role="columnheader" scope="col" tabIndex="0" aria-colindex="2" aria-sort="none" className="position-relative text-right">
                              <div>CR</div>
                              <span className="sr-only"> (Click to sort ascending)</span>
                            </th>
                            <th role="columnheader" scope="col" aria-colindex="3" className="">
                              <div>B st</div>
                            </th>
                            <th role="columnheader" scope="col" aria-colindex="4" className="">
                              <div>U st</div>
                            </th>
                            <th role="columnheader" scope="col" aria-colindex="5" className="">
                              <div>PName</div>
                            </th>
                            <th role="columnheader" scope="col" tabIndex="0" aria-colindex="6" aria-sort="none" className="position-relative">
                              <div>Account Type</div>
                              <span className="sr-only"> (Click to sort ascending)</span>
                            </th>
                            <th role="columnheader" scope="col" aria-colindex="7" className="">
                              <div>Action</div>
                            </th>
                          </tr>
                        </thead>
                        <tbody role="rowgroup">
                          {loading ? (
                            <tr role="row">
                              <td colSpan="7" className="text-center py-4">Loading...</td>
                            </tr>
                          ) : users.length === 0 ? (
                            <tr role="row" className="b-table-empty-row">
                              <td colSpan="7" role="cell">
                                <div role="alert" aria-live="polite">
                                  <div className="text-center my-2">There are no records to show</div>
                                </div>
                              </td>
                            </tr>
                          ) : (
                            users.map((account) => {
                              const uid = account.wallet_id || account.user_id || account.staff_id || account.username
                              const creditRef = account.credit ?? account.credit_ref ?? account.cash_received ?? 0
                              // Switches show the *lock* state: ON = locked. bet_locked false /
                              // active true means nothing is locked, so both render OFF.
                              const betLock = account.bet_lock ?? account.bet_locked ?? false
                              const userLock = account.user_lock ?? (account.active === false || account.status === 'InActive')
                              const percentage = account.percentage ?? 1
                              const userType = account.user_type ?? account.role ?? ''
                              const displayName = account.full_name || account.fullName || account.username
                              // Only staff accounts have a downline — parentId on the API is a staff_id
                              const childPath = account.staff_id ? `/admin/users/${account.staff_id}` : null

                              return (
                                <tr key={uid} role="row" className="">
                                  <td aria-colindex="1" role="cell" className="">
                                    {childPath ? (
                                      <Tooltip text={displayName}>
                                        <Link
                                          to={childPath}
                                          className="wrape-text"
                                          target="_blank"
                                          rel="noopener noreferrer"
                                          data-original-title={displayName}
                                        >
                                          <span>{account.username}</span>
                                        </Link>
                                      </Tooltip>
                                    ) : (
                                      <span className="wrape-text">{account.username}</span>
                                    )}
                                  </td>
                                  <td aria-colindex="2" role="cell" className="">
                                    <p className="text-right mb-0 cp text-warning"
                                      onClick={() => { setSelectedAccount(account); setShowCreditModal(true) }}>
                                      {formatNum(creditRef)}
                                    </p>
                                  </td>
                                  <td aria-colindex="3" role="cell" className="">
                                    <div className="mb-1 custom-control custom-switch">
                                      <input
                                        type="checkbox"
                                        disabled="disabled"
                                        className="custom-control-input"
                                        value="true"
                                        id={`bst-${uid}`}
                                        checked={betLock}
                                        readOnly
                                      />
                                      <label className="custom-control-label" htmlFor={`bst-${uid}`}></label>
                                    </div>
                                  </td>
                                  <td aria-colindex="4" role="cell" className="">
                                    <div className="mb-1 custom-control custom-switch">
                                      <input
                                        type="checkbox"
                                        disabled="disabled"
                                        className="custom-control-input"
                                        value="true"
                                        id={`ust-${uid}`}
                                        checked={userLock}
                                        readOnly
                                      />
                                      <label className="custom-control-label" htmlFor={`ust-${uid}`}></label>
                                    </div>
                                  </td>
                                  <td aria-colindex="5" role="cell" className="">
                                    <p className="text-left mb-0">
                                      {percentage} Pt/ INR
                                    </p>
                                  </td>
                                  <td aria-colindex="6" role="cell" className="">{formatAccountType(userType)}</td>
                                  <td aria-colindex="7" role="cell" className="">
                                    <div role="group" className="btn-group">
                                      {/* Drill-down list is read-only: no D/W, and More collapses to P */}
                                      {parentId ? (
                                        <button type="button" className="btn btn-info" onClick={() => handleMoreClick(account)}>P</button>
                                      ) : (
                                        <>
                                          <button type="button" className="btn btn-success" onClick={() => handleDepositClick(account)}>D</button>
                                          <button type="button" className="btn btn-danger" onClick={() => handleWithdrawClick(account)}>W</button>
                                          <button type="button" className="btn btn-info" onClick={() => handleMoreClick(account)}>More</button>
                                        </>
                                      )}
                                    </div>
                                  </td>
                                </tr>
                              )
                            })
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={handlePageChange} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <DepositModal
        show={showDepositModal}
        onHide={() => setShowDepositModal(false)}
        userData={selectedAccount}
        onSubmit={handleDepositSubmit}
      />

      <WithdrawModal
        show={showWithdrawModal}
        onHide={() => setShowWithdrawModal(false)}
        userData={selectedAccount}
        onSubmit={handleWithdrawSubmit}
      />

      <MoreModal
        show={showMoreModal}
        onHide={() => setShowMoreModal(false)}
        userData={selectedAccount}
        onChangePassword={handleMoreChangePassword}
        onUserLock={handleMoreUserLock}
        onEditProfile={handleMoreEditProfile}
      />

      <CreditActivityModal
        show={showCreditModal}
        onHide={() => setShowCreditModal(false)}
        account={selectedAccount}
        onSuccess={handleCreditSuccess}
      />
    </>
  )
}

export default Users
