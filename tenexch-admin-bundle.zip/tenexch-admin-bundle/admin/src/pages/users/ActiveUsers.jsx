import { useState, useEffect, useCallback, useMemo, useRef } from 'react'
import { Link } from 'react-router-dom'
import userService from '../../services/userService'
import walletService from '../../services/walletService'
import DepositModal from '../../components/DepositModal'
import WithdrawModal from '../../components/WithdrawModal'
import MoreModal from '../../components/MoreModal'
import CreditActivityModal from '../../components/CreditActivityModal'
import Swal from 'sweetalert2'
import LoaderOverlay from '../../components/LoaderOverlay'
import useExportLoader from '../../hooks/useExportLoader'
import { exportUserListExcel, exportUserListPDF } from '../../utils/userListExport'
import Pagination from '../../components/Pagination'
import MyMarketModal from '../../components/MyMarketModal'
import { getMarketAnalysisDashboard } from '../../services/api'

const Toast = Swal.mixin({
  toast: true,
  position: 'top-end',
  showConfirmButton: false,
  timer: 3000,
  timerProgressBar: false,
})


// Display labels for account types (API sends uppercase e.g. "SUPERMASTER")
const ACCOUNT_TYPE_LABELS = {
  USER: 'User',
  AGENT: 'Agent',
  MASTER: 'Master',
  SUPERMASTER: 'SuperMaster',
  SUPERADMIN: 'SuperAdmin',
  COMPANY: 'Company',
  ADMIN: 'Admin',
  STAFF: 'Staff',
}
const formatAccountType = (t) => {
  const key = String(t || '').toUpperCase()
  if (ACCOUNT_TYPE_LABELS[key]) return ACCOUNT_TYPE_LABELS[key]
  // Fallback: Capitalize first letter only
  const s = String(t || '')
  return s ? s.charAt(0).toUpperCase() + s.slice(1).toLowerCase() : s
}

function ActiveUsers() {
  const [searchKey, setSearchKey] = useState('')
  // Excel button: page loader for a second, then the download (hooks/useExportLoader)
  const { exporting, withExportLoader } = useExportLoader()
  const [pageSize, setPageSize] = useState(25)
  const [currentPage, setCurrentPage] = useState(1)
  const [users, setUsers] = useState([])
  const [totalPages, setTotalPages] = useState(1)
  const [loading, setLoading] = useState(false)

  // Reference toast text for an invalid transaction code
  const apiErrorText = (msg) => {
    if (/transaction (password|code) (invalid|not valid)/i.test(msg || '')) {
      return 'Master Password not valid.'
    }
    return msg || 'Something went wrong'
  }

  const [selectedAccount, setSelectedAccount] = useState(null)
  /* Exposure → "My Market". A non-zero exposure is a link; clicking it loads
     that account's open book (the same dashboard call the header search uses,
     scoped by username) and shows it in the My Market modal. The user's DOM of
     the reference has only the market blocks in the body — no Game Detail /
     User Lock / Game Lock row — so `analysis` is left null here. */
  const [myMarket, setMyMarket] = useState({ show: false, matches: [] })
  const [myMarketLoading, setMyMarketLoading] = useState(false)
  const openMyMarket = (account) => {
    if (myMarketLoading) return
    setMyMarketLoading(true)
    getMarketAnalysisDashboard({ username: account.username })
      .then((res) => setMyMarket({ show: true, matches: res?.success ? res.data || [] : [] }))
      .catch(() => setMyMarket({ show: true, matches: [] }))
      .finally(() => setMyMarketLoading(false))
  }

  const [showDepositModal, setShowDepositModal] = useState(false)
  const [showWithdrawModal, setShowWithdrawModal] = useState(false)
  const [showMoreModal, setShowMoreModal] = useState(false)
  const [showCreditModal, setShowCreditModal] = useState(false)

  const fetchUsers = useCallback(async (page, limit, search) => {
    setLoading(true)
    try {
      const data = await userService.getAllDetails(page, limit, search)
      if (data.success && data.data && data.data.wallets) {
        setUsers(data.data.wallets)
        // API `data.pagination.total_pages` bhejti hai; `data.total` kabhi tha hi
        // nahi — fallback wallets.length par girta tha aur ceil(limit/limit) hamesha
        // 1 deta tha, isliye next/last buttons permanently disabled the.
        setTotalPages(data.data.pagination?.total_pages || 1)
      } else {
        setUsers([])
        setTotalPages(1)
      }
    } catch (err) {
      console.error('Error fetching users:', err)
      setUsers([])
      setTotalPages(1)
      Toast.fire({
        icon: 'error',
        text: err.response?.data?.message || 'Failed to load users',
      })
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchUsers(currentPage, pageSize, searchKey)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentPage, pageSize])

  const handleLoad = (e) => {
    e.preventDefault()
    setCurrentPage(1)
    fetchUsers(1, pageSize, searchKey)
  }

  const handleReset = () => {
    setSearchKey('')
    setCurrentPage(1)
    fetchUsers(1, pageSize, '')
  }

  // Credit Activity does its own API call inside the modal; all this page owes
  // it is the list refetch (the header balance is refreshed by the modal).
  // Toast text comes from the server ("Sucessfull Balance Transfer" on a
  // deposit — reference wording); the local strings are only the fallback.
  const handleCreditSuccess = (mode, message) => {
    Toast.fire({
      icon: 'success',
      text: message || (mode === 'withdraw' ? 'Credit withdraw successful!' : 'Credit deposit successful!'),
    })
    fetchUsers(currentPage, pageSize, searchKey)
  }

  const handlePageSizeChange = (e) => {
    const newSize = Number(e.target.value)
    setPageSize(newSize)
    setCurrentPage(1)
  }

  const handlePageChange = (page) => {
    if (page < 1 || page > totalPages) return
    setCurrentPage(page)
  }

  const formatNum = (val) => {
    const n = parseFloat(val)
    if (isNaN(n)) return '0'
    return n.toLocaleString()
  }

  // Locked accounts (status InActive / active false) stay listed so the upline
  // can see and unlock them here — their User Lock switch renders ON. Filtering
  // them out made a lock look like the user vanished, and shortened pages the
  // server had already paginated.
  const activeUsers = users

  // Header sorting (b-table style): sortable columns toggle asc/desc; clicking
  // a non-sortable header while a sort is active clears it (reference behavior)
  const [sortBy, setSortBy] = useState(null)
  const [sortDesc, setSortDesc] = useState(false)

  const SORT_ACCESSORS = {
    username: (a) => String(a.username || '').toLowerCase(),
    cr: (a) => Number(a.credit ?? a.credit_ref ?? a.UpperLevelCreditReference ?? a.cash_received ?? 0),
    pts: (a) => Number(a.all_point ?? a.inr_balance ?? a.cash ?? 0),
    pl: (a) => Number(a.settlement_points ?? a.profit_loss ?? 0),
    accountType: (a) => String(a.user_type ?? a.role ?? '').toLowerCase(),
  }

  const handleSort = (key) => {
    if (sortBy === key) {
      setSortDesc(!sortDesc)
    } else {
      setSortBy(key)
      setSortDesc(false)
    }
  }

  const clearSort = () => {
    if (sortBy) {
      setSortBy(null)
      setSortDesc(false)
    }
  }

  const sortedUsers = useMemo(() => {
    if (!sortBy) return activeUsers
    const accessor = SORT_ACCESSORS[sortBy]
    return [...activeUsers].sort((a, b) => {
      const va = accessor(a)
      const vb = accessor(b)
      if (va < vb) return sortDesc ? 1 : -1
      if (va > vb) return sortDesc ? -1 : 1
      return 0
    })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeUsers, sortBy, sortDesc])

  // Reference th markup: sortable columns carry tabindex/aria-sort + sr-only
  // hint; non-sortable ones become clear-sort targets while a sort is active
  const sortableThProps = (key) => ({
    role: 'columnheader',
    scope: 'col',
    tabIndex: 0,
    'aria-sort': sortBy === key ? (sortDesc ? 'descending' : 'ascending') : 'none',
    onClick: () => handleSort(key),
  })

  const sortHint = (key) =>
    ` (Click to sort ${sortBy === key && !sortDesc ? 'descending' : 'ascending'})`

  const handleDepositClick = (account) => {
    setSelectedAccount(account)
    setShowDepositModal(true)
  }

  const handleWithdrawClick = (account) => {
    setSelectedAccount(account)
    setShowWithdrawModal(true)
  }

  // Same loader-bound lookup as Users.jsx: the list row alone does not carry
  // fullname/city/mobile, so More fetches the account first and opens only
  // once it has an answer. Without this the panel painted straight from the
  // row and the fields sat blank (user, 2026-09-21).
  const handleMoreClick = async (account) => {
    const accountType = account?.user_id ? 'USER' : 'STAFF'
    const id = account?.user_id || account?.staff_id
    if (!id) { setSelectedAccount(account); setShowMoreModal(true); return }

    setLoading(true)
    try {
      const res = await userService.getAccountDetails(accountType, id)
      // Row stays the base so nothing already on screen can go missing.
      setSelectedAccount(res?.success && res.data ? { ...account, ...res.data } : account)
    } catch {
      setSelectedAccount(account)
    } finally {
      setLoading(false)
      setShowMoreModal(true)
    }
  }

  const handleDepositSubmit = async ({ amount, remark, transactionPassword }) => {
    setLoading(true)
    try {
      // Deposit = settlement me dena -> points positive
      const payload = {
        userId: selectedAccount.user_id || selectedAccount.staff_id,
        username: selectedAccount.username,
        points: Math.abs(amount),
        remark,
        transactionPassword,
      }
      const response = await walletService.settlePoints(payload)
      if (response.success) {
        Toast.fire({ icon: 'success', text: 'Deposit successful!' })
        setShowDepositModal(false)
        fetchUsers(currentPage, pageSize, searchKey)
      } else {
        Toast.fire({ icon: 'error', text: apiErrorText(response.message) })
      }
    } catch (error) {
      Toast.fire({ icon: 'error', text: apiErrorText(error.response?.data?.message || error.message) })
    } finally {
      setLoading(false)
    }
  }

  const handleWithdrawSubmit = async ({ amount, remark, transactionPassword }) => {
    setLoading(true)
    try {
      // Withdraw = settlement me lena -> points hamesha negative
      const payload = {
        userId: selectedAccount.user_id || selectedAccount.staff_id,
        username: selectedAccount.username,
        points: -Math.abs(amount),
        remark,
        transactionPassword,
      }
      const response = await walletService.settlePoints(payload)
      if (response.success) {
        Toast.fire({ icon: 'success', text: 'Withdraw successful!' })
        setShowWithdrawModal(false)
        fetchUsers(currentPage, pageSize, searchKey)
      } else {
        Toast.fire({ icon: 'error', text: apiErrorText(response.message) })
      }
    } catch (error) {
      Toast.fire({ icon: 'error', text: apiErrorText(error.response?.data?.message || error.message) })
    } finally {
      setLoading(false)
    }
  }

  const handleMoreChangePassword = async ({ newPassword, transactionPassword }) => {
    setLoading(true)
    try {
      const isUser = selectedAccount.user_type === 'USER'
      const payload = {
        user_type: isUser ? 'USER' : 'STAFF',
        [isUser ? 'user_id' : 'staff_id']: selectedAccount.user_id || selectedAccount.staff_id,
        newPassword,
        transactionPassword,
      }
      const response = await userService.updateStatusAndPassword(payload)
      if (response.success) {
        Toast.fire({ icon: 'success', text: 'Password updated successfully' })
        setShowMoreModal(false)
      } else {
        Toast.fire({ icon: 'error', text: apiErrorText(response.message) })
      }
    } catch (error) {
      Toast.fire({ icon: 'error', text: apiErrorText(error.response?.data?.message || error.message) })
    } finally {
      setLoading(false)
    }
  }

  const handleMoreUserLock = async ({ betLock, userLock, transactionPassword }) => {
    setLoading(true)
    try {
      const isUser = selectedAccount.user_type === 'USER'
      const payload = {
        user_type: isUser ? 'USER' : 'STAFF',
        [isUser ? 'user_id' : 'staff_id']: selectedAccount.user_id || selectedAccount.staff_id,
        bet_lock: betLock,
        ...(isUser ? { status: userLock ? 'InActive' : 'Active' } : { active: !userLock }),
        transactionPassword,
      }
      const response = await userService.updateStatusAndPassword(payload)
      if (response.success) {
        Toast.fire({ icon: 'success', text: 'Status updated successfully' })
        setShowMoreModal(false)
        fetchUsers(currentPage, pageSize, searchKey)
      } else {
        Toast.fire({ icon: 'error', text: apiErrorText(response.message) })
      }
    } catch (error) {
      Toast.fire({ icon: 'error', text: apiErrorText(error.response?.data?.message || error.message) })
    } finally {
      setLoading(false)
    }
  }

  const handleMoreEditProfile = async ({ fullName, transactionPassword }) => {
    setLoading(true)
    try {
      const isUser = selectedAccount.user_type === 'USER'
      const payload = {
        user_type: isUser ? 'USER' : 'STAFF',
        [isUser ? 'user_id' : 'staff_id']: selectedAccount.user_id || selectedAccount.staff_id,
        full_name: fullName,
        transactionPassword,
      }
      const response = await userService.updateStatusAndPassword(payload)
      if (response.success) {
        Toast.fire({ icon: 'success', text: 'Profile updated' })
        setShowMoreModal(false)
        fetchUsers(currentPage, pageSize, searchKey)
      } else {
        // Edit Profile shows the backend's own text — the reference toasts
        // "transaction code not valid. You have 9attempt left" here, not the
        // "Master Password not valid." the D/W flows use (user, 2026-09-18).
        Toast.fire({ icon: 'error', text: response.message || 'Something went wrong' })
      }
    } catch (error) {
      Toast.fire({ icon: 'error', text: error.response?.data?.message || error.message || 'Something went wrong' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div>
      {(loading || exporting) && <LoaderOverlay />}
      <div>
        {/* Breadcrumb */}
        <div className="row">
          <div className="col-12">
            <div className="page-title-box d-flex align-items-center justify-content-between">
              <h4 className="mb-0 font-size-18">Account List For Active Users</h4>
              <div className="page-title-right">
                <ol className="breadcrumb m-0">
                  <li className="breadcrumb-item">
                    <Link to="/admin/home">Home</Link>
                  </li>
                  <li className="breadcrumb-item active">
                    <span aria-current="location">Active Users</span>
                  </li>
                </ol>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="row account-list">
          <div className="col-12">
            <div className="card">
              <div className="card-body">

                {/* Search + Actions row */}
                <div className="row row5">
                  <div className="col-md-6 mb-2 search-form">
                    <form method="post" className="ajaxFormSubmit" onSubmit={handleLoad}>
                      <div className="d-inline-block form-group form-group-feedback form-group-feedback-right">
                        <input
                          type="text"
                          name="searchKey"
                          placeholder="Search User"
                          className="form-control"
                          value={searchKey}
                          onChange={(e) => setSearchKey(e.target.value)}
                        />
                      </div>{' '}
                      <div className="d-inline-block">
                        <button type="submit" id="submit" className="btn btn-primary">Load</button>{' '}
                        <button type="button" id="reset" className="btn btn-light" onClick={handleReset}>Reset</button>
                      </div>
                    </form>
                  </div>
                  <div className="col-md-6 text-right mb-2">
                    <div className="d-inline-block mr-2">
                      <div className="d-inline-block">
                        {/* Exports the rows as shown — the current sort included */}
                        <button type="button" disabled={activeUsers.length === 0} className={`btn mr-1 btn-success${activeUsers.length === 0 ? ' disabled' : ''}`} onClick={withExportLoader(() => exportUserListExcel(sortedUsers, { formatAccountType }))}>
                          <i className="fas fa-file-excel"></i>
                        </button>
                      </div>{' '}
                      <button type="button" disabled={activeUsers.length === 0} className={`btn btn-danger${activeUsers.length === 0 ? ' disabled' : ''}`} onClick={() => exportUserListPDF(sortedUsers, { formatAccountType })}>
                        <i className="fas fa-file-pdf"></i>
                      </button>
                    </div>{' '}
                    <div className="d-inline-block">
                      <Link to="/admin/users/insertuser" className="btn btn-success">
                        <i aria-hidden="true" className="fa fa-plus"></i> CREATE ACCOUNT
                      </Link>
                    </div>
                  </div>
                </div>

                {/* Page size selector */}
                <div className="row">
                  <div className="col-sm-12 col-md-6">
                    <div className="dataTables_length">
                      <label className="d-inline-flex align-items-center">
                        Show&nbsp;
                        <select
                          className="custom-select custom-select-sm"
                          value={pageSize}
                          onChange={handlePageSizeChange}
                        >
                          <option value="25">25</option>
                          <option value="50">50</option>
                          <option value="100">100</option>
                          <option value="250">250</option>
                          <option value="500">500</option>
                          <option value="750">750</option>
                          <option value="1000">1000</option>
                        </select>&nbsp;entries
                      </label>
                    </div>
                  </div>
                </div>

                {/* Table */}
                <div className="table-responsive mb-0">
                  <div className="table no-footer table-responsive-sm">
                    <table className="table b-table">
                      <thead role="rowgroup">
                        <tr role="row">
                          <th {...sortableThProps('username')} aria-colindex="1" className="position-relative">
                            <div>User Name</div><span className="sr-only">{sortHint('username')}</span>
                          </th>
                          <th {...sortableThProps('cr')} aria-colindex="2" className="position-relative text-right">
                            <div>CR</div><span className="sr-only">{sortHint('cr')}</span>
                          </th>
                          <th {...sortableThProps('pts')} aria-colindex="3" className="position-relative text-right">
                            <div>pts</div><span className="sr-only">{sortHint('pts')}</span>
                          </th>
                          <th {...sortableThProps('pl')} aria-colindex="4" className="position-relative text-right">
                            <div>Client(P/L)</div><span className="sr-only">{sortHint('pl')}</span>
                          </th>
                          <th role="columnheader" scope="col" aria-colindex="5" className={`text-right${sortBy ? ' position-relative' : ''}`} onClick={clearSort}>
                            <div>Exposure</div>{sortBy && <span className="sr-only"> (Click to clear sorting)</span>}
                          </th>
                          <th role="columnheader" scope="col" aria-colindex="6" className={`text-right${sortBy ? ' position-relative' : ''}`} onClick={clearSort}>
                            <div>Available pts</div>{sortBy && <span className="sr-only"> (Click to clear sorting)</span>}
                          </th>
                          <th role="columnheader" scope="col" aria-colindex="7" className={sortBy ? 'position-relative' : ''} onClick={clearSort}>
                            <div>B st</div>{sortBy && <span className="sr-only"> (Click to clear sorting)</span>}
                          </th>
                          <th role="columnheader" scope="col" aria-colindex="8" className={sortBy ? 'position-relative' : ''} onClick={clearSort}>
                            <div>U st</div>{sortBy && <span className="sr-only"> (Click to clear sorting)</span>}
                          </th>
                          <th role="columnheader" scope="col" aria-colindex="9" className={sortBy ? 'position-relative' : ''} onClick={clearSort}>
                            <div>PName</div>{sortBy && <span className="sr-only"> (Click to clear sorting)</span>}
                          </th>
                          <th {...sortableThProps('accountType')} aria-colindex="10" className="position-relative">
                            <div>Account Type</div><span className="sr-only">{sortHint('accountType')}</span>
                          </th>
                          <th role="columnheader" scope="col" aria-colindex="11" className={sortBy ? 'position-relative' : ''} onClick={clearSort}>
                            <div>Action</div>{sortBy && <span className="sr-only"> (Click to clear sorting)</span>}
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {loading ? (
                          <tr>
                            <td colSpan="11" className="text-center py-4">Loading...</td>
                          </tr>
                        ) : activeUsers.length === 0 ? (
                          <tr role="row" className="b-table-empty-row">
                            <td colSpan="11" role="cell">
                              <div role="alert" aria-live="polite">
                                <div className="text-center my-2">There are no records to show</div>
                              </div>
                            </td>
                          </tr>
                        ) : (
                          sortedUsers.map((account) => {
                            const uid = account.wallet_id || account.user_id || account.staff_id || account.username
                            const creditRef = account.credit ?? account.credit_ref ?? account.UpperLevelCreditReference ?? account.cash_received ?? 0
                            const pts = account.all_point ?? account.inr_balance ?? account.cash ?? 0
                            const profitLoss = account.settlement_points ?? account.profit_loss ?? 0
                            // Exposure is stored negative (liability). This column shows the
                            // magnitude only — no minus sign.
                            const exposure = Math.abs(Number(account.exposure ?? account.total_exposure ?? 0)) || 0
                            const available = account.available_points ?? account.inr_balance ?? account.AvailableBalance ?? account.cash ?? 0
                            // Switches show the *lock* state: ON = locked. bet_locked false /
                            // active true means nothing is locked, so both render OFF.
                            const betLock = account.bet_lock ?? account.bet_locked ?? false
                            const userLock = account.user_lock ?? (account.active === false || account.status === 'InActive')
                            const percentage = account.percentage ?? 0
                            const userType = account.user_type ?? account.role ?? ''

                            return (
                              <tr key={uid}>
                                <td>
                                  <span title={account.full_name || account.fullName || account.username}>
                                    {account.username}
                                  </span>
                                </td>
                                <td>
                                  <p className="text-right mb-0 cp text-warning"
                                    onClick={() => { setSelectedAccount(account); setShowCreditModal(true) }}>
                                    {formatNum(creditRef)}
                                  </p>
                                </td>
                                <td>
                                  <p className="text-right mb-0">{formatNum(pts)}</p>
                                </td>
                                <td>
                                  <p className="text-right mb-0">{formatNum(profitLoss)}</p>
                                </td>
                                {/* A non-zero exposure opens that account's book. Clickable
                                    only — the TEXT keeps its colour, no `text-warning`
                                    (user, 2026-09-23: "exposure ka text colour mat change kar"). */}
                                <td className="text-right">
                                  {exposure ? (
                                    <p className="mb-0 text-right cp" onClick={() => openMyMarket(account)}>
                                      {formatNum(exposure)}
                                    </p>
                                  ) : (
                                    <p className="mb-0 text-right">{formatNum(exposure)}</p>
                                  )}
                                </td>
                                <td>
                                  <p className="text-right mb-0">{formatNum(available)}</p>
                                </td>
                                <td>
                                  <div className="mb-1 custom-control custom-switch">
                                    <input
                                      type="checkbox"
                                      disabled
                                      className="custom-control-input"
                                      id={`bst-${uid}`}
                                      checked={betLock}
                                      readOnly
                                    />
                                    <label className="custom-control-label" htmlFor={`bst-${uid}`}></label>
                                  </div>
                                </td>
                                <td>
                                  <div className="mb-1 custom-control custom-switch">
                                    <input
                                      type="checkbox"
                                      disabled
                                      className="custom-control-input"
                                      id={`ust-${uid}`}
                                      checked={userLock}
                                      readOnly
                                    />
                                    <label className="custom-control-label" htmlFor={`ust-${uid}`}></label>
                                  </div>
                                </td>
                                <td>
                                  <p className="text-left mb-0">{percentage} Pt</p>
                                </td>
                                <td>{formatAccountType(userType)}</td>
                                <td>
                                  <div className="btn-group">
                                    <button type="button" className="btn btn-success" onClick={() => handleDepositClick(account)}>D</button>
                                    <button type="button" className="btn btn-danger" onClick={() => handleWithdrawClick(account)}>W</button>
                                    <button type="button" className="btn btn-info" onClick={() => handleMoreClick(account)}>More</button>
                                  </div>
                                </td>
                              </tr>
                            )
                          })
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Pagination */}
                <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={handlePageChange} />

              </div>
            </div>
          </div>
        </div>
      </div>

      <DepositModal
        show={showDepositModal}
        onHide={() => setShowDepositModal(false)}
        userData={selectedAccount}
        onSubmit={handleDepositSubmit}
      />

      <WithdrawModal
        show={showWithdrawModal}
        onHide={() => setShowWithdrawModal(false)}
        userData={selectedAccount}
        onSubmit={handleWithdrawSubmit}
      />

      <MoreModal
        show={showMoreModal}
        onHide={() => setShowMoreModal(false)}
        userData={selectedAccount}
        onChangePassword={handleMoreChangePassword}
        onUserLock={handleMoreUserLock}
        onEditProfile={handleMoreEditProfile}
      />

      <CreditActivityModal
        show={showCreditModal}
        onHide={() => setShowCreditModal(false)}
        account={selectedAccount}
        onSuccess={handleCreditSuccess}
      />

      {/* the book loads behind the page loader, then the modal comes up —
          same order the header search uses */}
      {myMarketLoading && <LoaderOverlay />}
      <MyMarketModal
        show={myMarket.show}
        matches={myMarket.matches}
        onHide={() => setMyMarket({ show: false, matches: [] })}
      />
    </div>
  )
}

export default ActiveUsers
