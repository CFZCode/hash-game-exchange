import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import LoaderOverlay from '../components/LoaderOverlay'
import MxDatePicker from '../components/MxDatePicker'

// User Creation CSV window — read off the reference (recordings, 2026-09-21,
// with today = 21/09/2026):
//   From  pickable from one calendar month back (21/08) up to today (21/09)
//   To    never chosen by the user — From + 7 days, and never past today
//         (21/08 → 28/08, 01/09 → 08/09, 21/09 → 21/09)
const CSV_LOOKBACK_MONTHS = 1
const CSV_RANGE_DAYS = 7

const formatDate = (date) => {
  const y = date.getFullYear()
  const m = String(date.getMonth() + 1).padStart(2, '0')
  const d = String(date.getDate()).padStart(2, '0')
  return `${y}-${m}-${d}`
}

const startOfToday = () => {
  const d = new Date()
  d.setHours(0, 0, 0, 0)
  return d
}

// Same day-of-month n months earlier, held to that month's last day:
// 31 Mar − 1 month is 28/29 Feb, not the 3 Mar that setMonth() rolls over to.
const monthsBack = (date, n) => {
  const first = new Date(date.getFullYear(), date.getMonth() - n, 1)
  const lastDay = new Date(first.getFullYear(), first.getMonth() + 1, 0).getDate()
  return new Date(first.getFullYear(), first.getMonth(), Math.min(date.getDate(), lastDay))
}

const csvToDate = (from) => {
  if (!from) return ''
  const d = new Date(`${from}T00:00:00`)
  if (isNaN(d)) return ''
  d.setDate(d.getDate() + CSV_RANGE_DAYS)
  const today = startOfToday()
  return formatDate(d > today ? today : d)
}

// Executive permission key for this page: 'agentAssign' (menu + route are
// gated in Layout.jsx / utils/permissions.js). When this page's backend API
// is built, its routes must carry requirePermission('agentAssign').
function AssignAgent() {
  // Same page loader as /admin/activeusers — shows while the page loads.
  // On a hard refresh the 2s boot splash covers the app, so the 1s countdown
  // starts only once `app-loading` leaves <body> (splash lifted) — otherwise
  // the loader would finish underneath the splash and never be seen.
  const [loading, setLoading] = useState(true)
  useEffect(() => {
    let timer
    const start = () => { timer = setTimeout(() => setLoading(false), 1000) }
    if (document.body.classList.contains('app-loading')) {
      const obs = new MutationObserver(() => {
        if (!document.body.classList.contains('app-loading')) {
          obs.disconnect()
          start()
        }
      })
      obs.observe(document.body, { attributes: true, attributeFilter: ['class'] })
      return () => { obs.disconnect(); clearTimeout(timer) }
    }
    start()
    return () => clearTimeout(timer)
  }, [])

  const [entriesPerPage, setEntriesPerPage] = useState(25)
  const [searchValue, setSearchValue] = useState('')

  // Opens on today, like the reference. To is not state: it follows From, so
  // the two can never drift apart (it used to sit on "today" whatever was picked).
  const [fromDate, setFromDate] = useState(() => formatDate(startOfToday()))
  const toDate = csvToDate(fromDate)
  const minFromDate = formatDate(monthsBack(startOfToday(), CSV_LOOKBACK_MONTHS))

  const agents = []

  const filteredAgents = agents.filter((a) => {
    if (!searchValue) return true
    const q = searchValue.toLowerCase()
    return (
      (a.userName || '').toLowerCase().includes(q) ||
      (a.mobileNumber || '').toLowerCase().includes(q) ||
      (a.depoMobileNumber || '').toLowerCase().includes(q)
    )
  })

  const pagedAgents = filteredAgents.slice(0, entriesPerPage)

  // Same page loader as the users pages while the CSV request runs
  // (mock for now — wire the real API call inside this handler later)
  const handleDownloadCSV = (e) => {
    e.preventDefault()
    setLoading(true)
    setTimeout(() => setLoading(false), 1000)
  }

  return (
    <div data-v-5a10e370="">
      {loading && <LoaderOverlay />}
      <div data-v-5a10e370="">
          <div className="row">
            <div className="col-12">
              <div className="page-title-box d-flex align-items-center justify-content-between">
                <h4 className="mb-0 font-size-18">Assign Agent List</h4>
                <div className="page-title-right">
                  <ol className="breadcrumb m-0">
                    <li className="breadcrumb-item">
                      <Link to="/admin/home" className="" target="_self">Home</Link>
                    </li>
                    <li className="breadcrumb-item active">
                      <span aria-current="location">Assign Agent List</span>
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col-12">
              <div className="card">
                <div className="card-body">
                  <div className="mb-3">
                    <div className="row row5"></div>
                  </div>

                  <div className="row">
                    <div className="col-sm-12 col-md-6">
                      <div id="tickets-table_length" className="dataTables_length">
                        <label className="d-inline-flex align-items-center">
                          Show&nbsp;
                          <select
                            className="custom-select custom-select-sm"
                            id="__BVID__1685"
                            value={entriesPerPage}
                            onChange={(e) => setEntriesPerPage(Number(e.target.value))}
                          >
                            <option value="25">25</option>
                            <option value="50">50</option>
                            <option value="75">75</option>
                            <option value="100">100</option>
                            <option value="125">125</option>
                            <option value="150">150</option>
                          </select>&nbsp;entries
                        </label>
                      </div>
                    </div>
                    <div className="col-sm-12 col-md-6">
                      <div id="tickets-table_filter" className="dataTables_filter text-md-right">
                        <label className="d-inline-flex align-items-center">
                          Search:
                          <input
                            type="search"
                            placeholder="Search..."
                            className="form-control form-control-sm ml-2 form-control"
                            id="__BVID__1686"
                            value={searchValue}
                            onChange={(e) => setSearchValue(e.target.value)}
                          />
                        </label>
                      </div>
                    </div>
                  </div>

                  <div className="table-responsive mb-0">
                    <div className="table no-footer table-responsive-sm">
                      <table
                        id="eventsListTbl"
                        role="table"
                        aria-busy="false"
                        aria-colcount="6"
                        className="table b-table table-bordered"
                      >
                        <thead role="rowgroup" className="">
                          <tr role="row" className="">
                            <th role="columnheader" scope="col" tabIndex="0" aria-colindex="1" aria-sort="none" className="position-relative">
                              <div>S.No.</div>
                              <span className="sr-only"> (Click to sort ascending)</span>
                            </th>
                            <th role="columnheader" scope="col" tabIndex="0" aria-colindex="2" aria-sort="none" className="position-relative">
                              <div>User Name</div>
                              <span className="sr-only"> (Click to sort ascending)</span>
                            </th>
                            <th role="columnheader" scope="col" tabIndex="0" aria-colindex="3" aria-sort="none" className="position-relative">
                              <div>Assign Agent Settings</div>
                              <span className="sr-only"> (Click to sort ascending)</span>
                            </th>
                            <th role="columnheader" scope="col" tabIndex="0" aria-colindex="4" aria-sort="none" className="position-relative">
                              <div>Mobile Number</div>
                              <span className="sr-only"> (Click to sort ascending)</span>
                            </th>
                            <th role="columnheader" scope="col" tabIndex="0" aria-colindex="5" aria-sort="none" className="position-relative">
                              <div>Depo Mobile Number</div>
                              <span className="sr-only"> (Click to sort ascending)</span>
                            </th>
                            <th role="columnheader" scope="col" tabIndex="0" aria-colindex="6" aria-sort="none" className="position-relative">
                              <div>First Bonus Status</div>
                              <span className="sr-only"> (Click to sort ascending)</span>
                            </th>
                          </tr>
                        </thead>
                        <tbody role="rowgroup">
                          {pagedAgents.length === 0 ? (
                            <tr role="row" className="b-table-empty-row">
                              <td colSpan="6" role="cell" className="">
                                <div role="alert" aria-live="polite">
                                  <div className="text-center my-2">There are no records to show</div>
                                </div>
                              </td>
                            </tr>
                          ) : (
                            pagedAgents.map((agent, index) => (
                              <tr key={agent.id || index} role="row" className="">
                                <td aria-colindex="1" role="cell" className="">{index + 1}</td>
                                <td aria-colindex="2" role="cell" className="">{agent.userName || '-'}</td>
                                <td aria-colindex="3" role="cell" className="">{agent.assignAgentSettings || '-'}</td>
                                <td aria-colindex="4" role="cell" className="">{agent.mobileNumber || '-'}</td>
                                <td aria-colindex="5" role="cell" className="">{agent.depoMobileNumber || '-'}</td>
                                <td aria-colindex="6" role="cell" className="">{agent.firstBonusStatus || '-'}</td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col-12">
              <div className="page-title-box d-flex align-items-center justify-content-between">
                <h4 className="mb-0 font-size-18">User Creation</h4>
                <div className="page-title-right">
                  <ol className="breadcrumb m-0"></ol>
                </div>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col-12">
              <div className="card">
                <div className="card-body">
                  <form method="post" data-vv-scope="creation" className="ajaxFormSubmit" onSubmit={handleDownloadCSV}>
                    <div className="row row5">
                      <div className="col-md-2">
                        <label>From Date:</label>{' '}
                        <MxDatePicker value={fromDate} onChange={setFromDate} minDate={minFromDate} disableFuture />
                      </div>
                      <div className="col-md-2">
                        <label>To Date:</label>{' '}
                        <MxDatePicker value={toDate} disabled />
                      </div>
                      <div className="col-md-2 mt-4">
                        <button type="submit" id="loaddata" className="btn btn-primary">
                          Download CSV
                        </button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>
  )
}

export default AssignAgent
