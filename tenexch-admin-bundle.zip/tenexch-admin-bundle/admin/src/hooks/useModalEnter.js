import { useCallback, useEffect, useState } from 'react'

// ─── Bootstrap-Vue modal behaviour, in one place ─────────────────────────────
//
// Every admin modal is hand-written markup that copies what BootstrapVue
// renders (`.modal.fade.show` + `.modal-backdrop`). Two things BV does at
// runtime were missing from most of them (user, 2026-09-18):
//
// 1. OPEN ANIMATION. BV mounts the modal WITHOUT `show`, lets the browser see
//    that state (opacity 0, dialog at -50px), then adds `show` — so the CSS
//    transitions in app.css (`.fade` opacity .15s, `.modal.fade .modal-dialog`
//    transform .3s) actually run. Mounting with `fade show` already on it
//    skips straight to the end state: no slide, no fade. `entered` here is
//    that class: false on mount, true two frames later. Two frames, not one —
//    after React commits, the first rAF can still run before the browser has
//    computed the mount-state style, in which case there is nothing to
//    transition FROM. (CreditActivityModal / CasinoResultModal carried their
//    own copies of this; they now use this hook.)
//
// 2. OUTSIDE CLICK. Every modal used to put `onClick={onHide}` on the
//    `.modal-backdrop` — but that element sits UNDER the `.modal` div
//    (z-index 1040 vs 1050), and `.modal` is fixed, full-screen and receives
//    pointer events. A click outside the dialog lands on `.modal`, never on
//    the backdrop, so those handlers never fired. `onBackdropClick` goes on
//    the `.modal` div instead and closes only when the click STARTED there
//    (target === currentTarget) — a click inside `.modal-content` bubbles up
//    with a different target and is ignored, and `.modal-dialog` is
//    `pointer-events: none`, so its margins count as outside too.
//
// Usage:
//   const { modalClass, backdropClass, onBackdropClick } = useModalEnter(onHide)
//   <div role="dialog" className={modalClass} style={{ display: 'block' }} onClick={onBackdropClick}>…</div>
//   <div className={backdropClass}></div>
//
// `show` is for modals that stay mounted and gate on a prop; components that
// are only mounted while open leave it at the default.

export default function useModalEnter(onHide, show = true) {
  const [entered, setEntered] = useState(false)

  useEffect(() => {
    if (!show) { setEntered(false); return undefined }
    let r2 = 0
    const r1 = requestAnimationFrame(() => { r2 = requestAnimationFrame(() => setEntered(true)) })
    return () => { cancelAnimationFrame(r1); cancelAnimationFrame(r2) }
  }, [show])

  const onBackdropClick = useCallback((e) => {
    if (e.target === e.currentTarget) onHide?.()
  }, [onHide])

  return {
    entered,
    modalClass: `modal fade${entered ? ' show' : ''}`,
    backdropClass: `modal-backdrop fade${entered ? ' show' : ''}`,
    onBackdropClick,
  }
}
