import { useEffect, useRef } from 'react'

// Admin twin of frontend/src/hooks/useOnResume.js — same rule, same code, kept
// in step by hand (the two apps share no package). The reasoning lives there;
// short version here.
//
// "The page is being looked at again — how long was it away?" Hidden tabs get
// their timers throttled, then frozen; the OS may drop their sockets silently.
// Four events mean "back" (platforms disagree on which they send):
// visibilitychange→visible, pageshow(persisted), focus, online. A phone fires
// several within ms — they are coalesced into ONE callback per subscriber.
// Time away = max(stamp taken on hide, gap since the last 1 s heartbeat tick);
// the heartbeat covers iOS, which sometimes never sends the hidden/visible
// pair, and a late tick on a visible page is itself a resume trigger.
// Consumers that reconnect or remount must set `minHiddenMs`.

const COALESCE_MS = 300
const TICK_MS = 1000
const TICK_GAP_MS = 5000

const subscribers = new Set()
let installed = false
let hiddenAt = null
let lastTickAt = 0
let tick = null
let timer = null
let pending = null

const gapNow = () => {
  const now = Date.now()
  const sinceHidden = hiddenAt != null ? now - hiddenAt : 0
  const sinceTick = lastTickAt ? Math.max(0, now - lastTickAt - TICK_MS) : 0
  return Math.max(sinceHidden, sinceTick)
}

const fire = () => {
  timer = null
  const info = pending
  pending = null
  hiddenAt = null
  lastTickAt = Date.now()
  if (!info) return
  subscribers.forEach((s) => {
    if (info.hiddenMs >= s.minHiddenMs) {
      try { s.cb(info) } catch (err) { console.error('[useOnResume] subscriber threw', err) }
    }
  })
}

// Measure at the FIRST event of the burst — a heartbeat tick inside the
// 300 ms window would otherwise erase the gap.
const schedule = (trigger) => {
  if (!pending) pending = { trigger, hiddenMs: gapNow() }
  if (!timer) timer = setTimeout(fire, COALESCE_MS)
}

const onHide = () => { if (hiddenAt == null) hiddenAt = Date.now() }
const onVisibility = () => {
  if (document.visibilityState === 'hidden') onHide()
  else schedule('visible')
}
const onPageShow = (e) => { if (e?.persisted) schedule('bfcache') }
const onFocus = () => schedule('focus')
const onOnline = () => schedule('online')
const onTick = () => {
  const late = lastTickAt ? Date.now() - lastTickAt - TICK_MS : 0
  if (late >= TICK_GAP_MS && document.visibilityState === 'visible') schedule('timer')
  else lastTickAt = Date.now()
}

const install = () => {
  if (installed) return
  installed = true
  hiddenAt = document.visibilityState === 'hidden' ? Date.now() : null
  lastTickAt = Date.now()
  document.addEventListener('visibilitychange', onVisibility)
  window.addEventListener('pageshow', onPageShow)
  window.addEventListener('pagehide', onHide)
  window.addEventListener('focus', onFocus)
  window.addEventListener('online', onOnline)
  tick = setInterval(onTick, TICK_MS)
}

const uninstall = () => {
  if (!installed) return
  installed = false
  document.removeEventListener('visibilitychange', onVisibility)
  window.removeEventListener('pageshow', onPageShow)
  window.removeEventListener('pagehide', onHide)
  window.removeEventListener('focus', onFocus)
  window.removeEventListener('online', onOnline)
  clearInterval(tick)
  tick = null
  clearTimeout(timer)
  timer = null
  pending = null
  hiddenAt = null
  lastTickAt = 0
}

/** Non-hook form for code that lives outside a component. Returns the unsubscribe. */
export function onResume(cb, { minHiddenMs = 0 } = {}) {
  const sub = { cb, minHiddenMs }
  subscribers.add(sub)
  install()
  return () => {
    subscribers.delete(sub)
    if (subscribers.size === 0) uninstall()
  }
}

/**
 * @param {(info: { trigger: string, hiddenMs: number }) => void} cb
 * @param {{ minHiddenMs?: number }} [opts]
 */
export default function useOnResume(cb, { minHiddenMs = 0 } = {}) {
  const cbRef = useRef(cb)
  cbRef.current = cb

  useEffect(() => onResume((info) => cbRef.current?.(info), { minHiddenMs }), [minHiddenMs])
}
