// Logic layer for the admin home dashboard: derives all point/P&L figures from
// the profile and builds the (memoized) ApexCharts configs. The Home page stays
// purely presentational.
import { useEffect, useMemo, useState } from 'react'
import { useSelector } from 'react-redux'
import { buildBarScale } from '../utils/barScale'

export const fmt = (val) => (val == null ? '0' : Number(val).toLocaleString())

// Shared chart look (reference style): vertical distributed columns, legend on
// top, tilted x labels. `scale` comes from buildBarScale so a small negative
// value stays visible next to a much larger positive one.
const baseChartOptions = (categories, colors, scale) => ({
  chart: { type: 'bar', height: 350, toolbar: { show: true } },
  plotOptions: { bar: { horizontal: false, columnWidth: '42.65%', distributed: true } },
  dataLabels: { enabled: false },
  colors,
  xaxis: {
    categories,
    labels: { rotate: -45, rotateAlways: true, style: { fontSize: '12px' } },
  },
  // vertical columns -> the value axis is the y axis here
  yaxis: { ...scale.xaxis, title: undefined },
  tooltip: scale.tooltip,
  legend: {
    show: true,
    position: 'top',
    horizontalAlign: 'center',
    markers: { shape: 'square' },
    labels: { colors: '#373d3f' },
  },
})

export const useHomeDashboard = () => {
  const user = useSelector((state) => state.auth.user)

  // The stats/charts section always reveals after a 3s delay on mount; the
  // casino images wait for the same moment (they only show once the graphs do)
  const [ready, setReady] = useState(false)
  useEffect(() => {
    const timer = setTimeout(() => setReady(true), 3000)
    return () => clearTimeout(timer)
  }, [])

  // Naye point-ledger keys (owner profile V2) — purane keys fallback me (staff profile)
  //   All pts = wallet.all_point, Settlement pts = all_point − credit (API se derived aata hai)
  const creditPts = Number(user?.credit ?? user?.UpperLevelCreditReference) || 0
  const allPts = Number(user?.all_point ?? user?.allPoints ?? user?.TotalMasterBalance) || 0
  const settlementPts = Number(user?.settlement_points ?? user?.settlementPoints ?? user?.profit_loss) || 0
  const upperPts = Number(user?.upper_point ?? user?.UpperLevel) || 0
  const downPts = Number(user?.down_point ?? user?.DownLevelProfitLoss ?? user?.DownPL) || 0

  const sportsPL = Number(user?.sports_pts) || 0
  const casinoPL = Number(user?.casino_pts) || 0
  const tpCasinoPL = Number(user?.thirdparty_pts) || 0
  const totalPL = Math.round((sportsPL + casinoPL + tpCasinoPL) * 100) / 100

  const pointsScale = useMemo(
    () => buildBarScale([creditPts, allPts, settlementPts, upperPts, downPts]),
    [creditPts, allPts, settlementPts, upperPts, downPts]
  )
  const pointsChart = {
    options: useMemo(
      () => baseChartOptions(
        ['Credit Pts', 'All Pts', 'Settlement Pts', 'Upper Pts', 'Down Pts'],
        ['#556ee6', '#f1b44c', '#50a5f1', '#34c38f', '#343a40'],
        pointsScale
      ),
      [pointsScale]
    ),
    series: useMemo(() => [{ name: 'Points', data: pointsScale.data }], [pointsScale]),
  }

  const plScale = useMemo(
    () => buildBarScale([sportsPL, casinoPL, tpCasinoPL, totalPL]),
    [sportsPL, casinoPL, tpCasinoPL, totalPL]
  )
  const plChart = {
    options: useMemo(
      () => baseChartOptions(
        ['Sports P/L', 'Casino P/L', 'Third Party Casino P/L', 'Total P/L'],
        ['#556ee6', '#f1b44c', '#50a5f1', '#34c38f'],
        plScale
      ),
      [plScale]
    ),
    series: useMemo(() => [{ name: 'P/L', data: plScale.data }], [plScale]),
  }

  // Presentation-ready collections
  const statsCards = [
    { label: 'Balance', value: fmt(user?.inr_balance ?? user?.AvailableBalance) },
    { label: 'Exposure', value: fmt(user?.total_exposure) },
    { label: 'Credit pts', value: fmt(creditPts) },
    { label: 'All pts', value: fmt(allPts) },
    { label: 'Settlement pts', value: fmt(settlementPts) },
    { label: 'Upper pts', value: fmt(upperPts) },
    { label: 'Down pts', value: fmt(downPts) },
  ]

  const pointsLegend = [
    { label: 'Credit pts', value: fmt(creditPts), color: 'text-primary', col: 'col-6 col-sm' },
    { label: 'All pts', value: fmt(allPts), color: 'text-warning', col: 'col-6 col-sm' },
    { label: 'Settlement pts', value: fmt(settlementPts), color: 'text-info', col: 'col-4 col-sm' },
    { label: 'Upper pts', value: fmt(upperPts), color: 'text-success', col: 'col-4 col-sm' },
    { label: 'Down pts', value: fmt(downPts), color: 'text-dark', col: 'col-4 col-sm' },
  ]

  const plLegend = [
    { label: 'Sports P/L', value: fmt(sportsPL), color: 'text-primary', col: 'col-6 col-sm-3' },
    { label: 'Casino P/L', value: fmt(casinoPL), color: 'text-warning', col: 'col-6 col-sm-3' },
    { label: 'Tp Casino P/L', value: fmt(tpCasinoPL), color: 'text-info', col: 'col-6 col-sm-3' },
    { label: 'Total P/L', value: fmt(totalPL), color: 'text-success', col: 'col-6 col-sm-3' },
  ]

  return { ready, statsCards, pointsChart, pointsLegend, plChart, plLegend }
}
