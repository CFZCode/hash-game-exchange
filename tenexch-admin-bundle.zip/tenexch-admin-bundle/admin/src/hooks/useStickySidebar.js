import { useEffect, useState } from 'react'

// Reference admin casino pages: `.right-sidebar` gets `sticky` (position:fixed,
// top:72px — style.css .right-sidebar.sticky) only once the page is scrolled
// past 12px, and only on wide screens (>= 1280px). Phones never get it, so the
// My Bets card stays in the flow under the table there.
// Modelled on frontend/src/hooks/casino/useStickySidebar.js.
const STICKY_AFTER_PX = 12
const STICKY_MIN_WIDTH = 1280

const isSticky = () =>
  typeof window !== 'undefined' && window.innerWidth >= STICKY_MIN_WIDTH && window.scrollY > STICKY_AFTER_PX

/**
 * Returns ' sticky' while the reference conditions hold, '' otherwise —
 * append it to the sidebar's className.
 */
export default function useStickySidebar() {
  const [sticky, setSticky] = useState(isSticky)

  useEffect(() => {
    const update = () => setSticky(isSticky())
    update()
    window.addEventListener('scroll', update, { passive: true })
    window.addEventListener('resize', update)
    return () => {
      window.removeEventListener('scroll', update)
      window.removeEventListener('resize', update)
    }
  }, [])

  return sticky ? ' sticky' : ''
}
