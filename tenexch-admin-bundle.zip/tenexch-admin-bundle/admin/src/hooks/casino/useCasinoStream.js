import { useMemo } from 'react';

const STREAM_BASE = import.meta.env.VITE_CASINO_STREAM_BASE || 'https://stream-s-43.xink.site/casino-stream?id=';

/**
 * Returns the casino stream URL for a given game type.
 */
export default function useCasinoStream(gameType) {
  const streamUrl = useMemo(() => `${STREAM_BASE}${gameType}`, [gameType]);
  return { streamUrl };
}
