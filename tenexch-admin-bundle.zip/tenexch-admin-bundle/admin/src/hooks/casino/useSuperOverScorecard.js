import { useQuery } from '@tanstack/react-query'
import { getSuperOverScorecard } from '../../services/casinoService'

/**
 * Server-held SuperOver two-innings scorecard (same endpoint the user site
 * warm-starts from: server/casinobet/cron/superOverScorecardCron.js folds each
 * round from ball one). Polled like the table feed, so the first innings stays
 * on screen after the chase starts and survives a mid-match join.
 *
 * Returns { phase, battingTeam, firstTeam, scoreByTeam, team1, team2, gmid }
 * or null while the poller has nothing.
 */
export default function useSuperOverScorecard(gameType) {
  const { data } = useQuery({
    queryKey: ['superOverScorecard', gameType],
    queryFn: () => getSuperOverScorecard(gameType),
    refetchInterval: 1000,
    enabled: Boolean(gameType),
    select: (res) => res?.data || null,
  })
  return data || null
}
