import { useQuery } from '@tanstack/react-query';
import { getLastResults } from '../../services/casinoService';

/**
 * Fetches last results once (staleTime: Infinity).
 * Optional transform function for game-specific result mapping.
 */
export default function useCasinoLastResults(gameType, { transform } = {}) {
  return useQuery({
    queryKey: ['casinoLastResults', gameType],
    queryFn: () => getLastResults(gameType),
    staleTime: Infinity,
    select: (res) => {
      const items = res?.data?.data?.res || res?.data?.res || res?.data || [];
      return transform ? items.map(transform) : items;
    },
  });
}
