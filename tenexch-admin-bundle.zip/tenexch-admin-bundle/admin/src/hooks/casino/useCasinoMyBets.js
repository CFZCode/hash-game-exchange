import { useEffect, useMemo } from 'react'
import { useQuery } from '@tanstack/react-query'
import { getCasinoOpenBets, getDetailResults, getLastResults } from '../../services/casinoService'
import useCasinoGame from './useCasinoGame'
import { isAb50BetDecided } from '../../utils/casinoBook'

/**
 * Admin "My Bets" — open downline bets for the current game via
 * GET /d99/bet-list/casino/open-downline?gameName=<gtype> (3s poll,
 * d99-admin pattern). Rows: { id, user_id, username, created_at,
 * description, selection, event_id, game_type, odds, amount, status, source }.
 *
 * A bet stays "open" until the settlement worker closes it, a few seconds
 * after the round's result — and this list used to poll every 5s on top of
 * that, so the runner book lingered well after the round was over. Now:
 *  - only bets of the round on screen (event_id === feed mid) are returned,
 *    so the old round's book drops the moment the feed moves to a new mid;
 *  - the list is refetched right away on a round change, and polled every 3s.
 *  - once the round on screen shows up in last results (polled every 1s here,
 *    same query the page strip reads), its bets drop at once — the book no
 *    longer waits for the worker + next poll or for the next round.
 * Array games (worli/matka) have no single round id here, so they are not filtered.
 */
// detail-results body → the round's win ("1", "2", …) or null while running
// ({ success: false } until the vendor publishes the result).
function detailWinOf(res) {
  const t1 = res?.data?.t1 ?? res?.data?.data?.t1
  const win = Array.isArray(t1) ? t1[0]?.win : t1?.win
  return win != null && String(win) !== '' && String(win) !== '0' ? String(win) : null
}

export default function useCasinoMyBets(gameName, isAuth) {
  const enabled = Boolean(isAuth && gameName)

  const { data, refetch } = useQuery({
    queryKey: ['casinoOpenBets', gameName],
    queryFn: () => getCasinoOpenBets(gameName),
    enabled,
    refetchInterval: enabled ? 3000 : false,
  })

  // Same query the page already polls (shared cache, no extra request).
  const { data: gameData } = useCasinoGame(gameName)
  // Round id the bets were placed with (player side: gameData.mid, or t1.gmid
  // on superover / cricketv3).
  const roundId = gameData?.mid ?? gameData?.t1?.gmid
  const mid = roundId != null ? String(roundId) : ''
  const roundKnown = Boolean(mid) && mid !== '0'

  useEffect(() => {
    if (enabled && roundKnown) refetch()
  }, [mid, enabled, roundKnown, refetch])

  // Result mid = the bet's event_id (settlement resolves by it); no match →
  // nothing changes.
  const { data: lastResults } = useQuery({
    queryKey: ['casinoLastResults', gameName],
    queryFn: () => getLastResults(gameName),
    enabled: enabled && roundKnown,
    refetchInterval: enabled && roundKnown ? 1000 : false,
    select: (res) => res?.data?.data?.res || res?.data?.res || res?.data || [],
  })
  const inLastResults = roundKnown && Array.isArray(lastResults) &&
    lastResults.some((r) => r?.mid != null && String(r.mid) === mid)

  // last-results only lists a round ~12 s after its card, at the next round
  // (measured on lucky7eu2), while the settlement worker settles from
  // detail-results ~5 s after the card and the player site clears then. So once
  // betting is closed on the round on screen (lt 0), ask detail-results — the
  // worker's own source — every 1 s until it has the result. Server caches it 2 s.
  // Plan: docs/plans/2026-10-10-admin-casino-book-clear-at-settlement.md
  // Standard-shape tables only (gameData.mid): Super Over / Cricket V3 (t1.gmid)
  // sit at lt 0 every ball and only have a result at the match end.
  const bettingClosed = roundKnown && gameData?.mid != null && Number(gameData?.lt) === 0
  const { data: detailWin } = useQuery({
    queryKey: ['casinoDetailResult', gameName, mid],
    queryFn: () => getDetailResults(gameName, mid),
    enabled: enabled && bettingClosed && !inLastResults,
    // A running round answers success:false — keep asking until a win is in.
    refetchInterval: (query) => (detailWinOf(query.state.data) ? false : 1000),
    retry: false,
    select: detailWinOf,
  })
  const roundResulted = inLastResults || Boolean(detailWin)

  const myBets = useMemo(() => {
    const rows = data?.success && Array.isArray(data?.data) ? data.data : []
    if (!roundKnown) return rows
    if (roundResulted) return []
    // Older backend without event_id → keep the row rather than hide it.
    let out = rows.filter((b) => b.event_id == null || String(b.event_id) === mid)
    // ab3 settles card by card: drop a bet as soon as its deciding card is
    // dealt instead of waiting for the worker + next poll (the player list
    // goes at once, on the balance push).
    if (gameName === 'ab3' && gameData?.card) {
      out = out.filter((b) => !isAb50BetDecided(b, gameData.card))
    }
    return out
  }, [data, roundKnown, roundResulted, mid, gameName, gameData?.card])

  return { myBets, refetch }
}
