import { useCallback, useEffect, useState } from 'react'

// The "||" grip on a casino card strip (.casino-cards-shuffle) is a toggle, as
// on the player site's CasinoVideo: a click closes the strip (hide-cards),
// another reopens it. A manual close lasts for the round — a new round id
// opens it again. The page still closes the strip on its own while no card is
// revealed (user 2026-10-14: "should close when clicked on the ||").
// Usage: const [stripCollapsed, toggleStrip] = useCardStripToggle(mid)
export default function useCardStripToggle(roundId) {
  const [collapsed, setCollapsed] = useState(false)
  useEffect(() => { setCollapsed(false) }, [roundId])
  const toggle = useCallback(() => setCollapsed((c) => !c), [])
  return [collapsed, toggle]
}
