import { useCallback, useEffect, useRef, useState } from 'react'
import userService from '../services/userService'

/* The one rule for "search a downline account by username" in the admin
 * (GET /admin/search-by-username) — shared by the header's Search User box and
 * the Search By Client Name field on the report pages, so the two can never
 * drift apart again (they had: one searched from 3 letters, one from 2, and one
 * page fired a request on every keystroke).
 *
 * Reference behaviour (vue-multiselect on tenexch.com, recordings 2026-09-19 and
 * 2026-09-21): nothing is requested under 3 letters; from the 3rd the downline
 * is searched and the list follows what is typed.
 *
 *   · USERNAME_SEARCH_MIN letters before anything is requested
 *   · DEBOUNCE_MS between the last keystroke and the request
 *   · one AbortController per request — a newer keystroke cancels the older
 *     fetch, so a slow early answer ("Bad") can never overwrite a later,
 *     correct list ("Badl")
 *   · the same query is never requested twice in a row
 *   · under the minimum the list is emptied at once
 *
 * What the box SHOWS for each state ("List is empty." / "No elements found…")
 * is the caller's business; this only owns the request.
 */

export const USERNAME_SEARCH_MIN = 3
const DEBOUNCE_MS = 300

export default function useUsernameSearch(query, { limit = 20 } = {}) {
  const abortRef = useRef(null)
  const lastQueryRef = useRef('')
  const [loading, setLoading] = useState(false)
  const [results, setResults] = useState([])

  useEffect(() => {
    const q = query.trim()
    if (q.length < USERNAME_SEARCH_MIN) {
      abortRef.current?.abort()
      lastQueryRef.current = ''
      setResults([])
      setLoading(false)
      return undefined
    }
    if (q === lastQueryRef.current) return undefined
    const timer = setTimeout(async () => {
      abortRef.current?.abort()
      const controller = new AbortController()
      abortRef.current = controller
      setLoading(true)
      try {
        const res = await userService.searchByUsername(q, controller.signal, { limit })
        if (controller.signal.aborted) return
        lastQueryRef.current = q
        setResults(res?.success ? (res.data?.results || []) : [])
      } catch {
        if (!controller.signal.aborted) setResults([])
      } finally {
        if (!controller.signal.aborted) setLoading(false)
      }
    }, DEBOUNCE_MS)
    return () => clearTimeout(timer)
  }, [query, limit])

  useEffect(() => () => abortRef.current?.abort(), [])

  // Drop whatever is in flight and forget the list — for a box that is closing.
  const reset = useCallback(() => {
    abortRef.current?.abort()
    lastQueryRef.current = ''
    setResults([])
    setLoading(false)
  }, [])

  return { results, loading, reset }
}
