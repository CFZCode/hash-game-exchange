import { useCallback, useRef, useState } from 'react'

// ─── Page loader around an Excel export ──────────────────────────────────────
//
// The reference shows the page loader (.loader-overlay over .page-content) for
// about a second when the Excel button is pressed, then the download starts
// (user's recording of /admin/activeusers, 2026-09-18). PDF does NOT get it.
// Every list/report page has an Excel button, so the second lives here once.
//
// Usage — the page already renders its own loader; OR this flag into it and
// wrap the Excel handler:
//   const { exporting, withExportLoader } = useExportLoader()
//   {(showLoader || exporting) && <LoaderOverlay />}
//   <button onClick={withExportLoader(handleExportExcel)}>
//
// `withExportLoader` returns a click handler, so an inline arrow works too:
//   onClick={withExportLoader(() => exportUserListExcel(rows, opts))}

export const EXPORT_LOADER_MS = 1000

export default function useExportLoader() {
  const [exporting, setExporting] = useState(false)
  // Ref, not state: a second click during the second must be ignored, and
  // the handler below is built once per render with the state it saw then.
  const busyRef = useRef(false)

  const withExportLoader = useCallback((run) => () => {
    if (busyRef.current) return
    busyRef.current = true
    setExporting(true)
    setTimeout(() => {
      try {
        run()
      } finally {
        busyRef.current = false
        setExporting(false)
      }
    }, EXPORT_LOADER_MS)
  }, [])

  return { exporting, withExportLoader }
}
