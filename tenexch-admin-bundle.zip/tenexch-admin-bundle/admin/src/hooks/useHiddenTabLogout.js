import { useEffect, useRef } from 'react'

// ─── "Was the tab put away for too long?" ────────────────────────────────────
//
// Admin twin of frontend/src/hooks/useHiddenTabLogout.js — same rule, same
// code, kept in step by hand (the two apps share no package).
//
// If the panel was not visible anywhere for `timeout` — tab minimised, switched
// away from, laptop asleep, phone locked — the session ends the moment it is
// seen again. A panel that stays open and visible is never touched by this.
//
// It does NOT run a countdown while hidden, and it must not: browsers freeze or
// throttle a background tab's timers, so a setTimeout cannot be trusted to fire
// (a service worker is no better — the browser stops it within seconds). So we
// keep a timestamp instead — "the panel was last visible at …" — and compare it
// when the page is seen again.
//
// Three deliberate details, all load-bearing:
//
// 1. The stamp lives in localStorage and is refreshed every 30s by any VISIBLE
//    tab. Shared storage means a second admin tab in active use keeps the stamp
//    fresh, so returning to a long-hidden first tab does not log out. The
//    heartbeat also covers a browser killing the tab without ever sending
//    `visibilitychange` — the stamp is then at most 30s stale.
//
// 2. The check also runs ONCE AT BOOT when a session is already stored. A
//    discarded tab is reloaded on return; no `visibilitychange` arrives then,
//    and boot is the only place to catch it. (A browser closed and reopened
//    looks identical, so it is treated alike.)
//
// 3. A fresh LOGIN is never checked, only stamped. `enabled` flipping on after
//    the first render means "just logged in"; whatever stamp is lying around
//    belongs to an older session and would end this one a second after it began.
//
// `onExpire` is held in a ref and kept out of the effect's dependencies: an
// inline arrow is a new function every render, and listing it would tear the
// listeners down and rebuild them on each one.

// Same limit as the player site (user, 2026-09-17).
export const HIDDEN_TAB_LOGOUT_20_MIN = 20 * 60 * 1000

// Deliberately not the player site's `lastVisibleAt`. Wherever the panel is
// served from the player site's origin (tenexchn.com/admin — see vite.config
// `base`), the two apps share one localStorage, and one app's heartbeat must
// never keep the other's session alive.
const STAMP_KEY = 'adminLastVisibleAt'
const HEARTBEAT_MS = 30 * 1000

// Storage can throw (private mode, blocked site data). A failed read returns
// null, which the check treats as "no stamp" — never as a reason to log out.
const readStamp = () => {
  try { return Number(localStorage.getItem(STAMP_KEY)) || null } catch { return null }
}
const writeStamp = () => {
  try { localStorage.setItem(STAMP_KEY, String(Date.now())) } catch { /* ignore */ }
}
const clearStamp = () => {
  try { localStorage.removeItem(STAMP_KEY) } catch { /* ignore */ }
}

/**
 * @param {number}   timeout          ms the site may stay unseen before the session ends
 * @param {object}   [opts]
 * @param {Function} [opts.onExpire]  fired once, when the page is seen again too late
 * @param {boolean}  [opts.enabled]   false → no listeners, no heartbeat (default true)
 */
export default function useHiddenTabLogout(timeout = HIDDEN_TAB_LOGOUT_20_MIN, opts = {}) {
  const { onExpire, enabled = true } = opts

  const cbRef = useRef(onExpire)
  cbRef.current = onExpire

  // True only for the very first effect run — see note 3 above.
  const bootRef = useRef(true)

  useEffect(() => {
    const isBoot = bootRef.current
    bootRef.current = false

    if (!enabled) { clearStamp(); return undefined }

    let fired = false

    // Compare first, stamp second — never the other way round, or the stale
    // stamp we came to judge would be overwritten before it is read.
    const check = () => {
      if (fired) return
      const last = readStamp()
      if (last && Date.now() - last >= timeout) {
        fired = true
        cbRef.current?.()
        return
      }
      writeStamp()
    }

    const handleVisibility = () => {
      if (document.hidden) writeStamp()
      else check()
    }

    // The heartbeat runs check(), not a bare stamp: if a frozen tab's timer
    // happens to wake before `visibilitychange` is delivered, it must judge the
    // old stamp rather than quietly refresh it.
    const beat = setInterval(() => { if (!document.hidden) check() }, HEARTBEAT_MS)

    document.addEventListener('visibilitychange', handleVisibility)
    window.addEventListener('pageshow', check)
    window.addEventListener('focus', check)
    window.addEventListener('pagehide', writeStamp)

    if (isBoot) check()
    else writeStamp()

    return () => {
      clearInterval(beat)
      document.removeEventListener('visibilitychange', handleVisibility)
      window.removeEventListener('pageshow', check)
      window.removeEventListener('focus', check)
      window.removeEventListener('pagehide', writeStamp)
    }
  }, [enabled, timeout])
}
