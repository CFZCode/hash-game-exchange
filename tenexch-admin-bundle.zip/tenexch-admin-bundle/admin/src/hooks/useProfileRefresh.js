import { useCallback } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { updateUser } from '../store/slices/authSlice'
import { getStaffProfile, getOwnerProfile } from '../services/api'
import { isOwnerProfileLive, requestOwnerProfileRefresh } from '../services/socketClient'

// Re-fetch the logged-in account's profile/wallet and push it into Redux.
//
// Layout runs this on every route change, but a route change is NOT the only
// moment the balance goes stale: anything that MOVES money (credit deposit /
// withdraw) changes the logged-in account's own credit while staying on the
// same page, so the header kept showing the pre-transfer number until the next
// navigation or a hard refresh. Those flows call this directly.
//
// Role-aware, same rules Layout established: an OWNER must hit /owner/profile
// (the staff endpoint answers with a different account), and an EXECUTIVE
// mirrors its PARENT's wallet while keeping its own identity + permission map.
export const useProfileRefresh = () => {
  const dispatch = useDispatch()
  const user = useSelector((state) => state.auth.user)
  const role = useSelector((state) => state.auth.role)

  return useCallback(async () => {
    const useOwnerProfile =
      role === 'owner' || (role === 'executive' && user?.parent_type === 'OWNER')

    // Owner AND staff sessions are fed by the 2-second `ownerProfileUpdate`
    // socket push (useOwnerProfileSocket), so hitting the REST endpoint here as
    // well would just be duplicate load — the socket has fresher data than this
    // call would return. Ask it for an immediate tick instead (callers are
    // usually right after a credit move) and let the push deliver.
    //
    // isOwnerProfileLive() goes false as soon as snapshots stop arriving, so a
    // dropped socket silently hands the job back to REST below.
    if (isOwnerProfileLive()) {
      requestOwnerProfileRefresh()
      return user || null
    }

    const call = useOwnerProfile ? getOwnerProfile : getStaffProfile
    try {
      const res = await call()
      const fresh = res?.data?.user
      if (!fresh) return null
      if (role === 'executive') {
        // Parent wallet/points, but keep the executive's own identity and
        // permission map on top (header username, can() gating)
        const { id, username, role: execRole, permissions, parent_type } = user || {}
        dispatch(updateUser({ ...(user || {}), ...fresh, id, username, role: execRole, permissions, parent_type }))
      } else {
        dispatch(updateUser({ ...(user || {}), ...fresh }))
      }
      return fresh
    } catch {
      return null
    }
  }, [dispatch, role, user])
}

export default useProfileRefresh
