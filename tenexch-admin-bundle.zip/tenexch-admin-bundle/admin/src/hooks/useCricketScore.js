import { useEffect, useRef, useState } from 'react'
import { onResume } from './useOnResume'

// Live cricket score — raw Socket.IO v2 (Engine.IO v3) over WebSocket. Frontend
// se ported (self-contained, koi socket.io-client dependency nahi). Returns latest
// summary.data (spnnation1, score1, balls, …) ya null jab tak pehla snapshot na aaye.
const SCORE_SOCKET_URL = import.meta.env.VITE_SCORE_SOCKET_URL || 'wss://dimclscore.external247services.com'

// A socket that stopped talking is dead, whatever `readyState` says. A tab that
// went to the background can lose its TCP connection without the browser ever
// firing `onclose`; the retry path used to run ONLY from `onclose`, so the
// banner froze on its last frame. Same two guards as the frontend twin
// (frontend/src/hooks/useCricketScore.js, plan
// docs/plans/2026-10-01-gamedetails-resume.md): a silence watchdog on the ping
// tick, and a rebuild on page resume when the last frame is stale.
const DEAD_AFTER_MS = 45000
const STALE_AFTER_MS = 30000

export default function useCricketScore(gmid, { enabled = true } = {}) {
  const [data, setData] = useState(null)
  const wsRef = useRef(null)

  useEffect(() => {
    if (!enabled || !gmid) { setData(null); return }

    let closedByUs = false
    let ws = null
    let pingTimer = null
    let retryTimer = null
    let lastFrameAt = 0
    const SUB = '42' + JSON.stringify(['subscribe_event', { eventId: String(gmid), providerId: '1' }])

    const cleanupSocket = () => {
      if (pingTimer) { clearInterval(pingTimer); pingTimer = null }
    }
    const scheduleRetry = () => {
      if (closedByUs) return
      retryTimer = setTimeout(connect, 2000)
    }
    // Drop the current socket and open a fresh one NOW. Handlers are detached
    // first so the old `onclose` cannot schedule a second connect.
    const reconnect = (reason) => {
      if (closedByUs) return
      if (retryTimer) { clearTimeout(retryTimer); retryTimer = null }
      cleanupSocket()
      const old = ws
      if (old) {
        old.onopen = null; old.onmessage = null; old.onclose = null; old.onerror = null
        try { old.close() } catch { /* noop */ }
      }
      if (import.meta.env.DEV) console.debug(`[cricket-score] reconnect gmid=${gmid} reason=${reason}`)
      connect()
    }

    function connect() {
      const url = `${SCORE_SOCKET_URL}/socket.io/?EIO=3&transport=websocket`
      try { ws = new WebSocket(url) } catch { scheduleRetry(); return }
      wsRef.current = ws
      lastFrameAt = Date.now()
      let subscribed = false
      const subscribe = () => { if (!subscribed && ws.readyState === 1) { subscribed = true; ws.send(SUB) } }

      ws.onopen = () => {
        lastFrameAt = Date.now()
        setTimeout(subscribe, 300)
        pingTimer = setInterval(() => {
          if (Date.now() - lastFrameAt > DEAD_AFTER_MS) { reconnect('watchdog'); return }
          if (ws.readyState === 1) ws.send('2')
        }, 20000)
      }
      ws.onmessage = (e) => {
        lastFrameAt = Date.now()
        const m = typeof e.data === 'string' ? e.data : ''
        if (!m) return
        if (m === '3') return
        if (m === '2') { ws.send('3'); return }
        if (m[0] === '0') return
        if (m.startsWith('40')) { subscribe(); return }
        if (m.startsWith('42')) {
          try {
            const [, payload] = JSON.parse(m.slice(2))
            const d = payload?.summary?.data
            if (d && typeof d === 'object') setData(d)
          } catch { /* ignore malformed frame */ }
        }
      }
      ws.onclose = () => { cleanupSocket(); if (!closedByUs) scheduleRetry() }
      ws.onerror = () => { try { ws.close() } catch { /* noop */ } }
    }

    connect()

    const offResume = onResume(({ trigger, hiddenMs }) => {
      const silentMs = Date.now() - lastFrameAt
      if (hiddenMs >= STALE_AFTER_MS || silentMs >= STALE_AFTER_MS) {
        reconnect(`${trigger} hidden=${Math.round(hiddenMs / 1000)}s silent=${Math.round(silentMs / 1000)}s`)
      }
    })

    return () => {
      closedByUs = true
      offResume()
      cleanupSocket()
      if (retryTimer) clearTimeout(retryTimer)
      if (ws) { try { ws.close() } catch { /* noop */ } }
      wsRef.current = null
    }
  }, [gmid, enabled])

  return data
}
