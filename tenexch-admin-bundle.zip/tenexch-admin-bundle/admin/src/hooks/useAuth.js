import { useDispatch, useSelector } from 'react-redux'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { setCredentials, logout } from '../store/slices/authSlice'
import { authService } from '../services/authService'

// Pull the human-readable reason out of an axios error OR a `success:false` body.
const errMessage = (e) =>
  e?.response?.data?.message || e?.response?.data?.error || e?.message || e?.error || ''

// "This username doesn't live here" — means we asked the wrong backend, not that
// the credentials were bad. Anything else (wrong password, inactive account) is
// the real answer and wins when we report a failure.
const isWrongBackend = (msg) => /not available|not exist|not found|no .*account/i.test(msg)

export const useAuth = () => {
  const dispatch = useDispatch()
  const { token, user, isAuthenticated } = useSelector((state) => state.auth)
  const queryClient = useQueryClient()

  const loginMutation = useMutation({
    mutationFn: async (credentials) => {
      const identifier = credentials.email || credentials.username

      // One login box, three backends. A username is globally unique across
      // Owners, staff and users (enforced on create), so at most one of these
      // can accept it — try them in order and take the first success. No
      // hardcoded owner name: whichever endpoint answers decides the role.
      //
      // Sequential on purpose, never parallel: api.js dispatches logout() and
      // clears localStorage on EVERY 401, so a loser's 401 could land after the
      // winner's success and wipe the token that was just stored.
      const attempts = [
        { type: 'owner', run: () => authService.ownerLogin(credentials) },
        { type: 'staff', run: () => authService.login(credentials) },
        {
          type: 'executive',
          run: () => authService.executiveLogin({
            username: identifier,
            password: credentials.password,
          }),
        },
      ]

      let realError = null // first failure that wasn't "wrong backend"
      let lastError = null

      for (const attempt of attempts) {
        try {
          const data = await attempt.run()
          // A 2FA challenge is HTTP 200 + success:true with no token — that is
          // still THIS backend answering, so stop here and let the 2FA screen
          // take over (it keys off ownerId / staffId in the payload).
          if (data?.success === false) throw new Error(errMessage(data) || 'Login failed')
          return { ...data, __loginType: attempt.type }
        } catch (error) {
          lastError = error
          if (!realError && !isWrongBackend(errMessage(error))) realError = error
        }
      }

      throw realError || lastError
    },
    onSuccess: async (data, variables) => {
      // Executive short path: the login response already carries the safe
      // executive object + permission map — there is NO profile endpoint for
      // executives, so skip the profile fetch entirely
      if (data.__loginType === 'executive' && data.success && data.token) {
        sessionStorage.removeItem('needPasswordChange')
        dispatch(setCredentials({
          token: data.token,
          user: data.executive,
          role: 'executive'
        }))
        queryClient.invalidateQueries()
        return data
      }

      if (data.success && data.token) {
        // Role comes from whichever backend accepted the login, not from the
        // typed username — so case/spelling of the owner's name is irrelevant.
        const isOwner = data.__loginType === 'owner'
        const role = isOwner ? 'owner' : 'staff'

        // Store first_login from login response in sessionStorage
        if (data.first_login === false) {
          sessionStorage.setItem('needPasswordChange', 'true')
        } else {
          sessionStorage.removeItem('needPasswordChange')
        }

        dispatch(setCredentials({
          token: data.token,
          user: null,
          role: role
        }))

        try {
          console.log(`Fetching ${role} profile after login...`)
          const profileResponse = isOwner
            ? await authService.getOwnerProfile()
            : await authService.getProfile()

          console.log('Profile response:', profileResponse)

          const userData = isOwner
            ? profileResponse.data
            : profileResponse.data?.user

          if (profileResponse && profileResponse.success && userData) {
            dispatch(setCredentials({
              token: data.token,
              // Profile's rules_accepted is the DB row and wins; the login
              // response's copy is only a fallback for a profile without the
              // flag. It used to be the other way round, and a `false` from
              // login overrode a `true` profile — the modal opened for an
              // account that had already accepted (saluagent, 2026-09-18).
              user: { ...userData, rules_accepted: userData.rules_accepted ?? data.rules_accepted },
              role: role
            }))
            console.log('Profile stored in Redux:', userData)
          } else {
            console.warn('Profile response missing user data:', profileResponse)
          }
        } catch (error) {
          console.error('Profile fetch error:', error)
          if (error.response?.status === 401) {
            dispatch(logout())
            throw new Error('Session expired. Please login again.')
          }
        }

        queryClient.invalidateQueries()
      }
      return data
    },
    onError: (error) => {
      console.error('Login error:', error)
      throw error
    },
  })

  const verify2FAMutation = useMutation({
    mutationFn: async (data) => {
      if (data.ownerId) {
        return await authService.verifyOwner2FA(data);
      } else {
        return await authService.verifyStaff2FA(data);
      }
    },
    onSuccess: async (data, variables) => {
      if (data.success && data.token) {
        const isOwner = !!variables.ownerId;
        const role = isOwner ? 'owner' : 'staff';

        if (data.first_login === false) {
          sessionStorage.setItem('needPasswordChange', 'true')
        } else {
          sessionStorage.removeItem('needPasswordChange')
        }

        dispatch(setCredentials({
          token: data.token,
          user: null,
          role: role
        }))

        try {
          console.log(`Fetching ${role} profile after 2FA...`)
          const profileResponse = isOwner
            ? await authService.getOwnerProfile()
            : await authService.getProfile()

          const userData = isOwner
            ? profileResponse.data
            : profileResponse.data?.user

          if (profileResponse && profileResponse.success && userData) {
            dispatch(setCredentials({
              token: data.token,
              // Same as login: profile flag first, login-response flag as fallback
              user: { ...userData, rules_accepted: userData.rules_accepted ?? data.rules_accepted },
              role: role
            }))
          } else {
            dispatch(logout())
          }
        } catch (error) {
          console.error('Profile fetch error:', error)
          dispatch(logout())
          throw new Error('Session expired. Please login again.')
        }

        queryClient.invalidateQueries();
      }
    },
    onError: (error) => {
      console.error('2FA Verify error:', error);
      throw error;
    }
  });

  const handleLogout = () => {
    dispatch(logout())
    queryClient.clear()
  }

  return {
    token,
    user,
    isAuthenticated,
    login: loginMutation.mutate,
    loginAsync: loginMutation.mutateAsync,
    isLoggingIn: loginMutation.isPending,
    logout: handleLogout,
    loginError: loginMutation.error,
    verify2FA: verify2FAMutation.mutateAsync,
    isVerifying2FA: verify2FAMutation.isPending,
  }
}
