// Logic layer for the Market Analysis page: fetches exposure data from
// POST /admin/reports/market-analysis (existing endpoint) and groups it by
// `eventid` client-side. The page stays purely presentational.
//
// API ek event ke har market ko ALAG entry deta hai (same `eventid`, alag
// `match_id` — e.g. Normal + MATCH_ODDS = 2 entries). Reference me ek event =
// EK container jisme andar multiple market cards. Isliye yahan `eventid` pe
// group karke saare markets ek match object me merge karte hain.
import { useCallback, useEffect, useMemo, useState } from 'react'
import { getMarketAnalysis } from '../services/api'

// per-market_id entries ko eventid pe group karo (order preserve)
function groupByEvent(data) {
  const map = new Map()
  for (const entry of data) {
    const key = String(entry.eventid || entry.match_id || entry.match_title || '')
    if (!map.has(key)) map.set(key, { ...entry, markets: [...(entry.markets || [])] })
    else map.get(key).markets.push(...(entry.markets || []))
  }
  return [...map.values()]
}

export const useMarketAnalysis = () => {
  const [matches, setMatches] = useState([])
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(false)

  const fetchData = useCallback(async () => {
    setLoading(true)
    // fa-spin takes 2s per rotation — hold the spinner for at least one full
    // turn even when the API responds instantly
    const minSpin = new Promise((resolve) => setTimeout(resolve, 2000))
    try {
      // existing endpoint har market_id ki alag entry deta hai — eventid pe group karo
      const response = await getMarketAnalysis()
      /* Reversed on purpose (user, 2026-09-23: "abhi jis order me render ho
         raha hai reversely kar de isko").

         The server hands the events back most-recently-active first —
         `reportsController.getMarketAnalysis` sorts on `last_updated`
         (MAX(updated_at) per event) DESC, then eventid, then match_id. Flipping
         the grouped list here turns that into oldest-activity-first, which is
         the order the reference's page shows. Grouping runs FIRST, so an
         event's own market cards keep their order inside the block; only the
         blocks change places. */
      /* 2026-10-11: the reference (Sheffield 20:14 → Naas 20:10 → SA v Aus
         09/10) orders events by start time, newest first — which also
         explains the 09-23 "reverse" request. `event_date` is a naive
         "YYYY-MM-DD HH:mm:ss" string, so a string compare sorts it; events
         without one go last. Stable sort keeps the server order on ties. */
      const byStart = (a, b) => String(b.event_date || '').localeCompare(String(a.event_date || ''))
      setMatches(response?.success ? groupByEvent(response.data || []).sort(byStart) : [])
    } catch (error) {
      console.error('Failed to fetch market analysis:', error)
      setMatches([])
    } finally {
      await minSpin
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchData()
  }, [fetchData])

  const filteredMatches = useMemo(() => {
    const term = search.trim().toLowerCase()
    if (!term) return matches
    return matches.filter((m) => (m.match_title || '').toLowerCase().includes(term))
  }, [matches, search])

  return { matches: filteredMatches, search, setSearch, loading, refresh: fetchData }
}
