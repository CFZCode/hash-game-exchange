import { useEffect, useRef } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { updateUser } from '../store/slices/authSlice'
import { getAdminSocket, disconnectAdminSocket, markOwnerProfileLive } from '../services/socketClient'

// Live owner profile over Socket.IO — the server pushes the SAME payload
// GET /admin/owner/profile returns, every 2 seconds.
//
// Everything on the admin side (header pts/exposure, dashboard cards in
// pages/Home.jsx) renders off Redux `state.auth.user`, so pushing each snapshot
// through updateUser makes every screen live at once — no per-page wiring.
//
// Every admin session subscribes — OWNER, STAFF (any level) and EXECUTIVE. The
// server reads the token's `account` ({ type: 'OWNER' | 'STAFF', id }; an
// executive's token already carries its parent's account) and pushes that
// account's profile: the owner payload for OWNER, the GET /admin/staff/profile
// payload for STAFF. The event names still say "owner" for history only.
export const useOwnerProfileSocket = () => {
  const dispatch = useDispatch()
  const token = useSelector((state) => state.auth.token)
  const role = useSelector((state) => state.auth.role)
  const user = useSelector((state) => state.auth.user)

  // The merge below needs the CURRENT user, but re-running the effect on every
  // 2s update would tear the socket down and rebuild it each tick.
  const userRef = useRef(user)
  userRef.current = user

  const isExecutive = role === 'executive'
  const enabled = !!token

  useEffect(() => {
    if (!enabled) return

    const socket = getAdminSocket(token)
    if (!socket) return

    const subscribe = () => socket.emit('subscribeOwnerProfile', { token })

    const handleUpdate = (payload) => {
      const fresh = payload?.data?.user
      if (!fresh) {
        if (payload?.error) console.warn('ownerProfileUpdate:', payload.error)
        return
      }
      // Tell useProfileRefresh the push is healthy — that is what stops the
      // REST endpoint from being polled on every route change.
      markOwnerProfileLive()

      const current = userRef.current || {}
      if (isExecutive) {
        // Parent's wallet/points, but keep the executive's own identity and
        // permission map on top (header username, can() gating) — identical to
        // the rule in useProfileRefresh.
        const { id, username, role: execRole, permissions, parent_type } = current
        dispatch(updateUser({ ...current, ...fresh, id, username, role: execRole, permissions, parent_type }))
      } else {
        dispatch(updateUser({ ...current, ...fresh }))
      }
    }

    socket.on('ownerProfileUpdate', handleUpdate)
    // Fires on the first connect AND on every reconnect, so the subscription
    // is re-armed after a drop (the server clears its timer on disconnect).
    socket.on('connect', subscribe)
    if (socket.connected) subscribe()

    return () => {
      socket.off('ownerProfileUpdate', handleUpdate)
      socket.off('connect', subscribe)
      socket.emit('unsubscribeOwnerProfile')
    }
  }, [enabled, token, isExecutive, dispatch])

  // Logout (or a session with nothing to subscribe to) must not leave a socket
  // ticking against the old token.
  useEffect(() => {
    if (!token) disconnectAdminSocket()
  }, [token])
}

export default useOwnerProfileSocket
