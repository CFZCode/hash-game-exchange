import { createSlice } from '@reduxjs/toolkit'

const getInitialToken = () => {
  const activeRole = localStorage.getItem('activeRole')
  if (activeRole === 'owner') return localStorage.getItem('ownerToken')
  if (activeRole === 'staff') return localStorage.getItem('staffToken')
  if (activeRole === 'executive') return localStorage.getItem('executiveToken')
  return localStorage.getItem('adminToken')
}

const getInitialUser = () => {
  try {
    const raw = localStorage.getItem('adminUser')
    return raw ? JSON.parse(raw) : null
  } catch {
    return null
  }
}

const initialState = {
  token: getInitialToken() || null,
  // Restore the user from localStorage so a page refresh doesn't depend on a
  // profile fetch succeeding before protected pages render (no logout flash)
  user: getInitialUser(),
  isAuthenticated: !!getInitialToken(),
  role: localStorage.getItem('activeRole') || null,
}

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    setCredentials: (state, action) => {
      const { token, user, role } = action.payload
      state.token = token
      state.user = user
      state.isAuthenticated = true
      state.role = role

      localStorage.setItem('activeRole', role)

      if (role === 'owner') {
        localStorage.setItem('ownerToken', token)
      } else if (role === 'executive') {
        // Executives have no profile endpoint — the permission map from the
        // login response is what utils/permissions.js `can()` reads
        localStorage.setItem('executiveToken', token)
        localStorage.setItem('adminToken', token)
        localStorage.setItem('executivePermissions', JSON.stringify(user?.permissions || {}))
      } else {
        localStorage.setItem('staffToken', token)
        localStorage.setItem('adminToken', token)
      }

      if (user) {
        localStorage.setItem('adminUser', JSON.stringify(user))
      }
    },
    logout: (state) => {
      state.token = null
      state.user = null
      state.isAuthenticated = false
      state.role = null
      localStorage.removeItem('adminToken')
      localStorage.removeItem('ownerToken')
      localStorage.removeItem('staffToken')
      localStorage.removeItem('executiveToken')
      localStorage.removeItem('executivePermissions')
      localStorage.removeItem('activeRole')
      localStorage.removeItem('adminUser')
      sessionStorage.removeItem('needPasswordChange')
    },
    updateUser: (state, action) => {
      state.user = action.payload
      localStorage.setItem('adminUser', JSON.stringify(action.payload))
    },
  },
})

export const { setCredentials, logout, updateUser } = authSlice.actions
export default authSlice.reducer
